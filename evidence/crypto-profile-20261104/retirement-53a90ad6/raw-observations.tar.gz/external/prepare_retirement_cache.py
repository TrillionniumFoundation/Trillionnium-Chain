#!/usr/bin/env python3
"""Copy only public, lock-pinned registry inputs into this task's own cache.

No Cargo command, compiler, source verifier, shared-cache write, or lock edit.
This is cache preparation, not a formal dependency-graph result for a new SHA.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
import tomllib

BASE = Path('/workspace/scratch/9d99fced0bf1')
LOCK = BASE / 'chain-current/tests/fuzz/Cargo.lock'
LOCK_SHA256 = '398cf378bd7b3bb67d0e8b0a3f303d00f981374685808428ba2138b930f051c9'
OUT = BASE / 'retirement-cache'
TASK_CARGO_HOME = OUT / 'cargo-home'
REGISTRY = 'index.crates.io-1949cf8c6b5b557f'
SOURCES = [
    Path('/workspace/scratch/79360d3567d1/cargo/registry'),
    Path('/workspace/scratch/e537ad232c79/native-runtime-acceptance/cargo/registry'),
    Path('/root/.cargo/registry'),
]


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': digest(raw)}


def index_path(name):
    if len(name) == 1:
        return name
    if len(name) == 2:
        return '2/' + name
    if len(name) == 3:
        return '3/' + name[0] + '/' + name
    return name[:2] + '/' + name[2:4] + '/' + name


def existing(paths, description):
    found = next((path for path in paths if path.is_file()), None)
    require(found is not None, 'missing existing public cache input: ' + description)
    return found


def main():
    started, clock = datetime.now(timezone.utc).isoformat(), time.monotonic_ns()
    require(not OUT.exists(), 'preserve the existing task-owned cache')
    raw_lock = LOCK.read_bytes()
    require(digest(raw_lock) == LOCK_SHA256, 'unexpected fuzz lock identity')
    packages = [p for p in tomllib.loads(raw_lock.decode())['package']
                if p.get('source', '').startswith('registry+')]
    require(len(packages) == 135, 'expected exactly 135 locked registry packages')
    require(all(p['source'] == 'registry+https://github.com/rust-lang/crates.io-index'
                for p in packages), 'unexpected registry source')
    OUT.mkdir()
    copied, package_checks = {}, []
    receipt = {
        'schema': 'trnm-retirement-cache-preparation-v1',
        'status': 'RUNNING', 'started_utc': started, 'cargo_home': str(TASK_CARGO_HOME),
        'lock_path': str(LOCK), 'lock_sha256': LOCK_SHA256,
        'preparation_script': identity(Path(__file__).resolve()),
        'prior_preparation_records': [identity(BASE / 'fuzz-cache' / name) for name in
                                      ('copy-receipt.json', 'fetch-receipt.json', 'cache-complete.json')],
        'formal_metadata_run': False, 'new_source_execution_credit': False,
        'compilation_run': False, 'source_verifier_run': False,
        'shared_cache_modified': False, 'repository_modified': False,
        'fresh_network_fetches': 0,
    }

    def copy_checked(source, destination, raw=None):
        raw = source.read_bytes() if raw is None else raw
        observed = {'source': str(source), 'destination': str(destination),
                    'bytes': len(raw), 'sha256': digest(raw)}
        key = str(destination)
        if key in copied:
            require(copied[key]['sha256'] == observed['sha256'], 'inconsistent repeated cache input')
            return observed
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as stream:
            stream.write(raw)
        require(destination.read_bytes() == raw, 'copied public cache bytes differ')
        require(source.read_bytes() == raw, 'source cache changed during copy')
        copied[key] = observed
        return observed

    try:
        (OUT / 'Cargo.lock.snapshot').write_bytes(raw_lock)
        config = existing([r / 'index' / REGISTRY / 'config.json' for r in SOURCES], 'registry config')
        copy_checked(config, TASK_CARGO_HOME / 'registry/index' / REGISTRY / 'config.json')
        for package in packages:
            name, version, checksum = package['name'], package['version'], package['checksum']
            filename = name + '-' + version + '.crate'
            archive = existing([BASE / 'fuzz-cache' / filename]
                               + [r / 'cache' / REGISTRY / filename for r in SOURCES], filename)
            archive_raw = archive.read_bytes()
            require(digest(archive_raw) == checksum, 'archive/lock checksum mismatch: ' + filename)
            archive_copy = copy_checked(archive, TASK_CARGO_HOME / 'registry/cache' / REGISTRY / filename, archive_raw)
            relative = index_path(name)
            index = existing([r / 'index' / REGISTRY / '.cache' / relative for r in SOURCES], relative)
            index_raw = index.read_bytes()
            entries = []
            for item in index_raw.split(b'\0'):
                if item.startswith(b'{'):
                    row = json.loads(item)
                    if row.get('name') == name and row.get('vers') == version:
                        entries.append(row)
            require(len(entries) == 1 and entries[0].get('cksum') == checksum,
                    'locked version missing or index checksum differs: ' + filename)
            index_copy = copy_checked(index, TASK_CARGO_HOME / 'registry/index' / REGISTRY / '.cache' / relative, index_raw)
            package_checks.append({'name': name, 'version': version, 'expected_checksum': checksum,
                                   'archive': archive_copy, 'index': index_copy,
                                   'archive_lock_index_checksum_match': True})
        require(LOCK.read_bytes() == raw_lock, 'fuzz lock changed during cache preparation')
        require(len(list((TASK_CARGO_HOME / 'registry/cache' / REGISTRY).glob('*.crate'))) == 135,
                'unexpected copied archive count')
        receipt['status'] = 'ALL_LOCKED_REGISTRY_ARCHIVES_AND_INDEX_ENTRIES_VERIFIED'
    except BaseException as error:
        receipt['status'] = 'FAILED_OR_INCOMPLETE_CACHE_PREPARATION'
        receipt['failure'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        receipt.update(finished_utc=datetime.now(timezone.utc).isoformat(),
                       elapsed_ns=time.monotonic_ns() - clock,
                       checked_registry_packages=len(package_checks),
                       copied_unique_files=len(copied), copied_bytes=sum(r['bytes'] for r in copied.values()),
                       copied_files=list(copied.values()), checks=package_checks)
        (OUT / 'cache-complete.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items()
                      if key not in ('copied_files', 'checks', 'prior_preparation_records')}, indent=2))


if __name__ == '__main__':
    main()
