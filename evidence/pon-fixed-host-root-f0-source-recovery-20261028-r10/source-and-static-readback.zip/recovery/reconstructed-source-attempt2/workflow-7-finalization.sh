set -uo pipefail
if [ "$VERIFIED_SOURCE_OUTCOME" = success ] && [ -n "${EXPECTED_TREE:-}" ]; then
  python3 scripts/ci/finalize_fixed_root_f0.py finalize --out "$OUT" \
    --expected-head "$EXPECTED_HEAD" --expected-tree "$EXPECTED_TREE" \
    > "$OUT/finalization.stdout.log" 2> "$OUT/finalization.stderr.log"
  finalization_status=$?
else
  # No unverified checkout code or guessed unit receives cleanup authority.
  python3 - <<'PY'
import json, os
from pathlib import Path
out = Path(os.environ['OUT'])
prior = json.loads((out/'workflow-predeclared.json').read_text())
with (out/'finalization-not-run.json').open('x') as stream:
    json.dump({'source_unverified': True, 'cleanup_attempted': False,
               'service_remaining': 'unknown', 'complete_success': False,
               'denominator': prior}, stream, indent=2, sort_keys=True)
    stream.write('\n')
PY
  finalization_status=1
fi
printf 'exit_code=%s\n' "$finalization_status" > "$OUT/finalization-status.txt"
exit "$finalization_status"
