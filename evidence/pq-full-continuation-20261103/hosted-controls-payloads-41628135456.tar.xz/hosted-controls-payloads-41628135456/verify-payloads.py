#!/usr/bin/env python3
"""Read back authenticated artifact bytes and all named native-control records."""
import hashlib
import json
from pathlib import Path
import re
import time
import zipfile
import tarfile
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
PACKAGE_PREFIX = 'hosted-controls-payloads-41628135456/'
PACKAGE_ARCHIVE = tarfile.open(sys.argv[1], 'r:xz') if len(sys.argv) == 2 else None


def read_file(name):
    if PACKAGE_ARCHIVE is None:
        return (ROOT / name).read_bytes()
    member = PACKAGE_ARCHIVE.getmember(PACKAGE_PREFIX + name)
    if not member.isfile():
        raise AssertionError('non-regular payload member ' + name)
    return PACKAGE_ARCHIVE.extractfile(member).read()


class PayloadFiles:
    def __init__(self, artifact_id, manifest):
        self.prefix = 'payloads/' + str(artifact_id) + '/'
        self.manifest = manifest
        self.expected = {item['name']: item for item in manifest}
        if PACKAGE_ARCHIVE is not None:
            actual = {m.name.removeprefix(PACKAGE_PREFIX + self.prefix)
                      for m in PACKAGE_ARCHIVE.getmembers()
                      if m.isfile() and m.name.startswith(PACKAGE_PREFIX + self.prefix)}
        else:
            base = ROOT / self.prefix
            actual = {str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
        if actual != set(self.expected):
            raise AssertionError('missing or extra payload members')
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def namelist(self):
        return [item['name'] for item in self.manifest]
    def read(self, name):
        data = read_file(self.prefix + name)
        expected = self.expected[name]
        if len(data) != expected['bytes'] or hashlib.sha256(data).hexdigest() != expected['sha256']:
            raise AssertionError('payload member digest mismatch: ' + self.prefix + name)
        return data
    def infolist(self):
        return [SimpleNamespace(filename=item['name'], file_size=item['bytes']) for item in self.manifest]
HEAD = '12fe5f2c1f19704fe7eb635dede6839ed8b1e91e'
TREE = 'c44112da731e3f958e55eb024e5762d6723ea2c9'
BASE = '2e72a989d001cf51bd0aed0e1401526e45db31f1'
MERGE = '0357031364787574cb7058b05329aa2e2730f947'
RUN = 41628135456
JOBS = {
    ('X64', 'head'): 125890591823,
    ('X64', 'prospective-merge'): 125890592046,
    ('ARM64', 'head'): 125890592233,
    ('ARM64', 'prospective-merge'): 125890592092,
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(name):
    return json.loads(read_file(name))


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def main():
    required = load('required-tests-source.json')
    selectors = required['tests']
    require(len(selectors) == len(set(selectors)) == required['expected_meaningful_controls'] == 45,
            'required selector cardinality')
    require(required['whole_chain_quantum_security_qualified'] is False and
            required['original_business_budgets_changed'] is False, 'qualification or budgets changed')
    require(not set(selectors) & set(required['child_process_harnesses_not_counted']), 'counted child harness')
    validator = {'__name__': 'artifact_readback_checker'}
    checker = read_file('check_required_native_test.py')
    exec(compile(checker, str(ROOT / 'check_required_native_test.py'), 'exec'), validator)
    metadata = load('source-files-metadata.json')
    actual_checker_blob = hashlib.sha1(b'blob ' + str(len(checker)).encode() + b'\0' + checker).hexdigest()
    require(actual_checker_blob == metadata['native_checker']['blob_sha'], 'checker source identity')
    head = load('api-head-commit.json')
    merge = load('api-merge-commit.json')
    run = load('api-run.json')
    require(head['sha'] == HEAD and head['commit']['tree']['sha'] == TREE, 'head GitHub binding')
    require(merge['sha'] == MERGE and merge['tree']['sha'] == TREE and
            [p['sha'] for p in merge['parents']] == [BASE, HEAD], 'prospective merge GitHub binding')
    require(run['id'] == RUN and run['run_attempt'] == 1 and run['head_sha'] == HEAD, 'run GitHub binding')
    jobs = {job['id']: job for job in load('api-jobs-raw.json')['jobs']}
    output = {
        'schema': 'trnm-pq-controls-payload-readback-v1',
        'original_zip_digest_recomputed_this_run': False,
        'original_zip_digest_previously_verified': True,
        'readback_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'run_id': RUN, 'run_attempt': 1, 'head': HEAD, 'base': BASE,
        'prospective_merge': MERGE, 'tested_tree': TREE,
        'run_status_at_snapshot': run['status'],
        'full_node_and_clippy_qualification': 'PENDING; not contained in these early controls artifacts',
        'whole_chain_quantum_security_qualified': False,
        'original_business_budgets_changed': False,
        'source_verification_scope': 'Readback verifies each producer-recorded before/after tracked-worktree identity and its GitHub commit/tree binding; it does not reconstruct 782174381 source bytes locally.',
        'checker_blob_sha1': actual_checker_blob, 'checker_sha256': digest(checker),
        'lanes': [],
    }
    artifacts = load('api-artifacts.json')
    require(len(artifacts) == 4, 'exactly four controls artifacts required')
    for artifact in sorted(artifacts, key=lambda a: a['id']):
        previous = next(lane for lane in load('original-readback.json')['lanes'] if lane['artifact_id'] == artifact['id'])
        retained_zip = next(item for item in load('original-zip-verification.json')['artifacts'] if item['artifact_id'] == artifact['id'])
        archive_sha256 = artifact['digest'].removeprefix('sha256:')
        archive_bytes = artifact['size_in_bytes']
        require(retained_zip['sha256'] == previous['artifact_sha256'] == archive_sha256 and
                retained_zip['bytes'] == previous['artifact_bytes'] == archive_bytes and
                retained_zip['matched_github_digest_and_size'] is True,
                'previously verified original ZIP digest record')
        require(artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD,
                'artifact run/head identity')
        with PayloadFiles(artifact['id'], previous['zip_manifest']) as z:
            names = z.namelist()
            require(len(names) == len(set(names)), 'duplicate ZIP members')
            source = json.loads(z.read('source.json'))
            kind = source['kind']
            require(kind in ('head', 'prospective-merge'), 'source kind')
            expected = {
                'base': BASE if kind == 'prospective-merge' else None,
                'candidate': HEAD, 'kind': kind,
                'prospective_merge': MERGE if kind == 'prospective-merge' else None,
                'schema': 'trnm-ci-source-v1',
                'tested_commit': MERGE if kind == 'prospective-merge' else HEAD,
                'tested_tree': TREE, 'tests_executed_by_identity_check': False,
                'tracked_bytes': 782174381, 'tracked_entries': 6831,
                'tracked_worktree_verified': True,
            }
            require(source == expected, 'source identity tuple')
            tsv = ''.join(f'native-{i:02d}\t{selector}\n' for i, selector in enumerate(selectors))
            require(z.read('required-tests.tsv').decode() == tsv, 'exact required45 sequence')
            provider = json.loads(z.read('pq-provider/provider.json'))
            require(provider['version'] == '3.5.9' and provider['exit_code'] == 0 and
                    provider['result'] == 'PREPARED_AND_SMOKE_VERIFIED' and
                    provider['source_digest_verified'] is True and
                    provider['whole_chain_quantum_security_qualified'] is False and
                    provider['production_activation'] is False, 'provider preparation scope')
            native = []
            command_records = []
            arch = None
            for member in names:
                if not member.endswith('.json'):
                    continue
                record = json.loads(z.read(member))
                if not isinstance(record, dict) or record.get('schema') != 'trnm-pq-native-command-v1':
                    continue
                require(record['before'] == record['after'] == source, member + ' before/after identity')
                require(record['exit_code'] == 0 and record['status'] == 'command_succeeded', member + ' status')
                require(record['whole_chain_quantum_security_qualified'] is False, member + ' qualification')
                log = z.read(record['log_file'])
                require(digest(log) == record['log_sha256'] and len(log) == record['log_bytes'], member + ' log hash')
                require(record['environment']['GITHUB_RUN_ID'] == str(RUN) and
                        record['environment']['GITHUB_RUN_ATTEMPT'] == '1', member + ' run environment')
                command_records.append({'record': member, 'record_sha256': digest(z.read(member)),
                                        'log_file': record['log_file'], 'log_sha256': digest(log)})
            for index, selector in enumerate(selectors):
                label = f'native-{index:02d}'
                record_bytes = z.read(label + '.json')
                record = json.loads(record_bytes)
                log = z.read(label + '.log')
                expected_argv = ['cargo', '+1.95.0', 'test', '--locked', '--manifest-path',
                                 'trillionnium/Cargo.toml', '-p', 'trnm-pon-node', '--lib',
                                 '--all-features', selector, '--', '--exact', '--show-output', '--test-threads=1']
                require(record['argv'] == expected_argv, label + ' exact original-profile command')
                execution = validator['validate'](log.decode().splitlines(keepends=True), selector)
                retained_execution = json.loads(z.read(label + '-execution.json'))
                require(execution == retained_execution, label + ' retained execution result')
                env = record['environment']
                if arch is None:
                    arch = env['RUNNER_ARCH']
                require(env['RUNNER_ARCH'] == arch and arch in ('X64', 'ARM64'), label + ' architecture')
                require(env['CARGO_BUILD_JOBS'] == '2' and env['CARGO_INCREMENTAL'] == '0' and
                        env['RUST_TEST_THREADS'] == '1' and env['RUSTFLAGS'] is None and
                        env['CARGO_ENCODED_RUSTFLAGS'] is None, label + ' unchanged build configuration')
                require(env['TRNM_PQ_OPENSSL_VERSION'] == provider['version'] and
                        env['TRNM_PQ_OPENSSL_SHA256'] == provider['cli_sha256'] and
                        env['TRNM_PQ_OPENSSL'] == provider['cli_executable'], label + ' provider binding')
                require('Finished `test` profile ' in log.decode(), label + ' original test profile')
                native.append({'index': index, 'selector': selector, 'result': 'PASS',
                               'executed_tests': 1, 'failed': 0, 'ignored': 0,
                               'record_sha256': digest(record_bytes), 'log_sha256': digest(log),
                               'execution_record_sha256': digest(z.read(label + '-execution.json')),
                               'log_bytes': len(log), 'command_elapsed_ns': record['elapsed_ns']})
            compiler = z.read('compiler.log').decode()
            require('release: 1.95.0\n' in compiler and
                    ('host: x86_64-unknown-linux-gnu\n' if arch == 'X64' else
                     'host: aarch64-unknown-linux-gnu\n') in compiler, 'compiler target/version')
            job_id = JOBS[(arch, kind)]
            job = jobs[job_id]
            require(job['head_sha'] == HEAD and job['run_id'] == RUN, 'job binding')
            require(any(step['name'] == 'Execute every required native effect and rejection control' and
                        step['conclusion'] == 'success' for step in job['steps']), 'job controls step')
            require('node-lib.json' not in names and 'clippy.json' not in names, 'early artifact unexpectedly includes full suite')
            manifest = [{'name': info.filename, 'bytes': info.file_size,
                         'sha256': digest(z.read(info.filename))} for info in z.infolist()]
            lane = {
                'artifact_id': artifact['id'], 'artifact_name': artifact['name'],
                'artifact_bytes': archive_bytes, 'artifact_sha256': archive_sha256,
                'original_zip_digest_verified_before_packaging': True, 'source': source, 'arch': arch,
                'job_id': job_id, 'job_status_at_snapshot': job['status'],
                'job_conclusion_at_snapshot': job['conclusion'],
                'controls': {'required': 45, 'passed': len(native), 'failed': 0, 'ignored': 0},
                'features': '--all-features', 'profile': 'original repository test profile; no --release',
                'compiler_host': 'x86_64-unknown-linux-gnu' if arch == 'X64' else 'aarch64-unknown-linux-gnu',
                'openssl_prepared_version': provider['version'],
                'openssl_cli_sha256': provider['cli_sha256'],
                'independent_crypto_implementation_claim': provider['independent_cryptographic_implementation_claim'],
                'new_controls': native[43:], 'all_controls': native,
                'all_command_records_checked': command_records, 'zip_manifest': manifest,
            }
            output['lanes'].append(lane)
    require({(lane['arch'], lane['source']['kind']) for lane in output['lanes']} == set(JOBS), 'full four-lane matrix')
    output['total_named_control_executions'] = 180
    output['all_controls_readback_passed'] = True
    (ROOT / 'payload-readback.json').write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'result': 'PASS', 'run': RUN, 'lanes': [
        {key: lane[key] for key in ('artifact_id', 'arch', 'job_id', 'controls', 'job_status_at_snapshot')}
        for lane in output['lanes']], 'total_named_control_executions': 180,
        'full_node_and_clippy': output['full_node_and_clippy_qualification']}))


if __name__ == '__main__':
    main()
