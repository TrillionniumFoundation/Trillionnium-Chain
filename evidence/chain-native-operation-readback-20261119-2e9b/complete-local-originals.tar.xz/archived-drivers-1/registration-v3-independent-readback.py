from pathlib import Path
import json,subprocess,hashlib
base=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b');src=base/'source';e=base/'current-source-registration-3'
rel='docs/architecture/TRNM_DOCUMENTATION_AUTHORITY_V1.md';raw=(src/rel).read_bytes();old=subprocess.check_output(['git','show','HEAD:'+rel],cwd=src)
a=b'resource_revision_r21_rejects_signed_old_cookies_and_preserves_control_output_reserve';b=a.replace(b'_r21_',b'_r22_')
assert old.count(a)==1 and raw==old.replace(a,b)
corpus=json.loads((src/'config/pon/pq-cross-branch-corpus-v1.json').read_text());assert rel not in corpus['pinned_blobs']
diff=subprocess.check_output(['git','diff','--binary'],cwd=src);(e/'candidate.patch').write_bytes(diff)
res={'schema':'chain-operation-applicability-navigation-correction-v1','driver_exit_code':1,'driver_error':"KeyError: document is not in existing PQ corpus pins",'partial_write_independently_checked':True,'path':rel,'sole_document_change':'existing native r21 callable to actual r22 callable','original_document_sha256':hashlib.sha256(old).hexdigest(),'current_document_sha256':hashlib.sha256(raw).hexdigest(),'no_source_pin_added_or_changed':True,'tracked_patch_sha256':hashlib.sha256(diff).hexdigest(),'qualification_changed':False}
(e/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res),flush=True)
