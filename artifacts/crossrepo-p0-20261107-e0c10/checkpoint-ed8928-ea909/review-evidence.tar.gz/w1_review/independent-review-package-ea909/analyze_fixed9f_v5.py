"""Reconcile the already retained fixed-9f V5 artifact; run no native work.

Replaying the checked-in JSONL reader checks byte/ledger consistency, not the
truth of execution, clocks, W1 transcript work, or any independent acceptance.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
import importlib
import json
from pathlib import Path
import sys
import zipfile

WORK = Path('/workspace/scratch/e0c10cd6a255')
ROOT = WORK / 'w1_review'
OUT = ROOT / 'independent-review-package-ea909'
ZIP = OUT / 'fixed9f-v5-x64-13555294305.zip'
HEAD = '9f77f4334a365387d7389735d5b67c37f12a02a0'
TREE = 'd7803f073a81e17ce4b79efca748645e12d3adff'
ZIP_SHA = 'c211b8b8bb122d6e65a00994691eadc8fbb993ddeb20fe35df7c264f0a9ad0fb'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def pin(path):
    p = Path(path)
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': sha(raw)}


def add(timings):
    timings = list(timings)
    return {axis: sum(t[axis] for t in timings) if all(t[axis] is not None for t in timings) else None
            for axis in ('cpu_ns', 'wall_ns')}


def difference(a, b):
    return {axis: a[axis] - b[axis] if a[axis] is not None and b[axis] is not None else None
            for axis in ('cpu_ns', 'wall_ns')}


tree = json.loads((ROOT / 'gate-map-ea909/tree-scripts.json').read_text())
tree_blobs = {r['path']: r['sha'] for r in tree['tree']}
reader_paths = [
    ROOT / 'gate-map-source-9f77f433/scripts/pon_w1_rank_batch_reader_v5.py',
    ROOT / 'gate-map-source-9f77f433/scripts/pon_w1_cost_matrix_reader.py',
    OUT / 'source/scripts/pon_w1_preparation_strategy_reader_v4.py',
]
for path in reader_paths:
    assert blob(path.read_bytes()) == tree_blobs[path.name], path
sys.dont_write_bytecode = True
sys.path[:0] = [str(OUT / 'source/scripts'), str(ROOT / 'gate-map-source-9f77f433/scripts')]
reader = importlib.import_module('pon_w1_rank_batch_reader_v5')

archive_pin = pin(ZIP)
assert archive_pin['bytes'] == 45038102 and archive_pin['sha256'] == ZIP_SHA
all_reports, shard_rows, all_arms = [], [], []
artifact_checks, record_kinds = [], Counter()
component_totals = defaultdict(list)
verification_totals = defaultdict(list)
purpose_counts = defaultdict(Counter)
purpose_costs = defaultdict(lambda: defaultdict(list))
command_rows = []
unknown_clock_records = 0

with zipfile.ZipFile(ZIP) as z:
    assert len(z.namelist()) == 220 and len(set(z.namelist())) == 220
    manifest = json.loads(z.read('campaign/manifest.json'))
    declaration = json.loads(z.read('campaign/declaration.json'))
    source_before = json.loads(z.read('source-before.json'))
    source_after = json.loads(z.read('source-after.json'))
    assert source_before == source_after
    assert source_before['tested_commit'] == HEAD and source_before['tested_tree'] == TREE
    assert source_before['tracked_worktree_verified'] is True
    assert manifest['expected_commit'] == HEAD
    assert declaration['grid'] == [list(x) for x in reader.grid()]
    assert manifest['planned_shards'] == declaration['grid']
    assert declaration['samples'] == 8 and declaration['limit'] == 4096
    assert declaration['rank_bound'] == 8 and declaration['batch_workers'] == 4
    assert declaration['no_retry_or_result_selection'] is True
    assert declaration['strategies'] == list(reader.STRATEGIES)
    assert len(manifest['shards']) == 66 and len(manifest['observations']) == 69
    for rel, wanted in manifest['artifact_sha256'].items():
        raw = z.read('campaign/' + rel)
        actual = sha(raw)
        assert actual == wanted, rel
        artifact_checks.append({'member': 'campaign/' + rel, 'bytes': len(raw), 'sha256': actual})
    binary_sha = sha(z.read('campaign/pon_w1_rank_batch_v5'))
    for field in ('binary_sha256_before', 'binary_sha256_after', 'retained_binary_sha256_before', 'retained_binary_sha256_after'):
        assert manifest[field] == binary_sha
    for obs in manifest['observations']:
        for field in ('source_before', 'source_after'):
            source = obs[field]
            assert source['commit'] == HEAD and source['tree'] == TREE and source['tracked_worktree_verified'] is True
        assert obs['exit_code'] == 0 and obs['process_exit_code'] == 0 and not obs['timed_out']
        for stream in ('stdout', 'stderr'):
            raw = z.read('campaign/' + obs[stream])
            assert len(raw) == obs[stream + '_bytes'] and sha(raw) == obs[stream + '_sha256']
        command_rows.append({k: obs[k] for k in ('command', 'stdout', 'stdout_bytes', 'stderr', 'stderr_bytes',
            'exit_code', 'process_exit_code', 'timed_out', 'elapsed_ns', 'wait4_cpu_ns', 'wait4_user_ns',
            'wait4_system_ns', 'wait4_maxrss_kib', 'global_cpu_complete', 'global_memory_peak_observed')})
    assert sum(r['wait4_cpu_ns'] for r in command_rows) == manifest['observed_wait4_cpu_ns_sum']
    for index, configuration in enumerate(declaration['grid']):
        basename = f'campaign/campaign-{index:02d}'
        saved = json.loads(z.read(basename + '.json'))
        assert saved == manifest['shards'][index]
        assert list(saved['configuration'].values()) != []
        records = reader.Records()
        own = {}
        counts = Counter(dict.fromkeys(reader.COUNTERS, 0))
        total_bytes = 0
        header = None
        with z.open(basename + '.stdout') as stream:
            for line in stream:
                total_bytes += len(line)
                assert len(line) <= reader.MAX_LINE and total_bytes <= reader.MAX_BYTES and line.endswith(b'\n')
                row = reader.common.decode(line)
                kind = row['kind']
                record_kinds[kind] += 1
                if kind == 'header':
                    header = row
                    assert [row['class'], row['target_index'], row['horizon']] == configuration
                    for component in ('material_setup', 'reference_setup'):
                        component_totals[component].append(row[component])
                        purpose_costs[row['purpose']][component].append(row[component])
                elif kind == 'cohort':
                    own[(row['sample'], row['strategy_index'])] = defaultdict(list)
                    acc = own[(row['sample'], row['strategy_index'])]
                    acc['paid_setup'].append(row['setup'])
                    counts['setup_calls'] += row['setup_calls']
                    counts['unsupported_setups'] += not row['supported']
                elif kind in ('search', 'verifier', 'search-cleanup', 'cohort-end'):
                    acc = own[(row['sample'], row['strategy_index'])]
                    if kind == 'search':
                        assert row['complete'] and row['errors'] == 0
                        counts['search_count'] += 1
                        counts['attempt_count'] += len(row['attempts'])
                        counts['exhausted_searches'] += row['first_hit_nonce'] is None
                        counts['speculative_attempts'] += sum(x['after_first_hit'] for x in row['attempts'])
                        counts['proof_buffers'] += sum(x['proof_materialized'] for x in row['attempts'])
                        for attempt in row['attempts']:
                            counts['hit_count' if attempt['target_hit'] else 'miss_count'] += 1
                        for component in ('producer', 'disposal', 'observation'):
                            acc['search_' + component].append(row[component])
                    elif kind == 'verifier':
                        counts['verifier_calls'] += 1
                        acc['verification'].append(row['timing'])
                        acc['verify:' + row['case'] + ':' + row['path']].append(row['timing'])
                    elif kind == 'search-cleanup':
                        acc['search_cleanup'].append(row['timing'])
                    else:
                        acc['teardown'].append(row['teardown'])
                        acc['inclusive_cohort'].append(row['total'])
                elif kind == 'footer':
                    assert all(row[k] == counts[k] for k in reader.COUNTERS)
                records.add(row)
        report = records.summary()
        assert report == saved['reader'] == manifest['reader']['reports'][index]
        assert counts == Counter(report['counts'])
        assert header is not None and len(own) == 8 * 17
        purpose_counts[header['purpose']].update(counts)
        all_reports.append(report)
        shard_arms = []
        for reported in report['arms']:
            strategy_index = reported['strategy_index']
            cohort_accs = [own[(sample, strategy_index)] for sample in range(8)]
            names = sorted(set().union(*(set(c) for c in cohort_accs)))
            components = {name: add(v for c in cohort_accs for v in c[name]) for name in names}
            producer = add(components[name] for name in ('paid_setup', 'search_producer', 'search_disposal', 'search_cleanup', 'teardown') if name in components)
            assert producer == reported['producer_total']
            assert components['paid_setup'] == reported['paid_setup']
            assert add(components[name] for name in ('search_observation',) if name in components) == reported['observation_total']
            assert add(components[name] for name in ('verification',) if name in components) == reported['verification_total']
            assert components['inclusive_cohort'] == reported['inclusive_cohort']
            charged = add([reported['producer_total'], reported['observation_total'], reported['verification_total']])
            overhead = difference(reported['inclusive_cohort'], charged)
            assert all(x is None or x >= 0 for x in overhead.values())
            for component, timing in components.items():
                if component.startswith('verify:'):
                    verification_totals[component].append(timing)
                else:
                    component_totals[component].append(timing)
                    purpose_costs[header['purpose']][component].append(timing)
                unknown_clock_records += sum(v is None for v in timing.values())
            entry = {'shard_index': index, 'class': header['class'], 'target_index': header['target_index'],
                     'horizon': header['horizon'], 'purpose': header['purpose'], **reported,
                     'components': components, 'recorded_disjoint_total': charged,
                     'inclusive_cohort_unitemized_overhead': overhead}
            all_arms.append(entry)
            shard_arms.append(entry)
        eligible = [a for a in shard_arms if a['supported'] and a['accepted_winners'] > 0 and a['producer_total']['cpu_ns'] is not None]
        observed_minimum = min(eligible, key=lambda a: Fraction(a['producer_total']['cpu_ns'], a['accepted_winners'])) if eligible else None
        shard_rows.append({'index': index, 'class': header['class'], 'target_index': header['target_index'],
            'horizon': header['horizon'], 'purpose': header['purpose'], 'counts': dict(counts),
            'accepted_winners_across_arms': sum(a['accepted_winners'] for a in shard_arms),
            'material_setup': header['material_setup'], 'reference_setup': header['reference_setup'],
            'observed_minimum_fixed_arm': None if observed_minimum is None else {
                k: observed_minimum[k] for k in ('strategy', 'strategy_index', 'accepted_winners', 'physical_attempts',
                    'speculative_attempts', 'producer_total', 'paid_setup', 'verification_total', 'inclusive_cohort', 'cpu_ns_per_accepted_winner')},
            'observed_minimum_is_exploratory_not_a_predeclared_global_strategy': True,
            'observation': command_rows[index + 3], 'raw_member': basename + '.stdout',
            'raw_sha256': sha(z.read(basename + '.stdout'))})
        if index % 6 == 5:
            print(json.dumps({'shards_reconciled': index + 1, 'of': 66}), flush=True)
    replayed = reader.campaign(all_reports)
    assert replayed == manifest['reader']
    scopes = {k: add(v) for k, v in component_totals.items()}
    purpose_scopes = {purpose: {k: add(v) for k, v in fields.items()} for purpose, fields in purpose_costs.items()}
    host = manifest['host']
    current_cgroup = host['current_cgroup']
    report = {
        'schema': 'independent-internal-fixed9f-v5-raw-reconciliation-v1',
        'review_scope': 'internal source and retained-raw audit; no native execution or external acceptance',
        'archive': archive_pin, 'run_id': 42324271643, 'run_attempt': 1, 'job_id': 128255821457,
        'artifact_id': 13555294305, 'source_head': HEAD, 'source_tree': TREE,
        'current_ea909_result_inherited': False, 'external_acceptance': False,
        'source_before': source_before, 'source_after': source_after,
        'retained_binary': {'member': 'campaign/pon_w1_rank_batch_v5', 'bytes': len(z.read('campaign/pon_w1_rank_batch_v5')), 'sha256': binary_sha},
        'reconciliation': {'archive_digest_matches_metadata': True, 'zip_entries': 220,
            'manifest_artifact_hashes_verified': len(artifact_checks), 'fixed_grid_shards_verified': 66,
            'raw_jsonl_checked_in_reader_reconciled': 66, 'complete_raw_reader_matches_saved_reports': True,
            'independent_component_sums_match_saved_arms': 66 * 17, 'commands_verified': 69,
            'failed_commands': 0, 'commands_with_missing_wait4': 0,
            'unknown_timing_components': unknown_clock_records,
            'byte_ledger_consistency_is_not_w1_replay_or_clock_authentication': True},
        'reader_source_pins': [dict(pin(p), git_blob=blob(p.read_bytes())) for p in reader_paths],
        'counts': replayed['total_counts'], 'counts_by_purpose': dict(purpose_counts),
        'record_kinds': dict(record_kinds),
        'full_grid_accounting_totals_not_comparable_strategy_rates': scopes,
        'accounting_totals_by_purpose_not_independent_samples': purpose_scopes,
        'verification_case_path_accounting': {k: add(v) for k, v in verification_totals.items()},
        'command_costs': {'rows': command_rows, 'all_wait4_cpu_ns': manifest['observed_wait4_cpu_ns_sum'],
            'native_66_commands_wait4_cpu_ns': sum(r['wait4_cpu_ns'] for r in command_rows[3:]),
            'build_wait4_cpu_ns': command_rows[2]['wait4_cpu_ns'],
            'toolchain_queries_wait4_cpu_ns': sum(r['wait4_cpu_ns'] for r in command_rows[:2]),
            'native_66_commands_elapsed_ns_sum': sum(r['elapsed_ns'] for r in command_rows[3:]),
            'native_per_process_maxrss_kib_max': max(r['wait4_maxrss_kib'] for r in command_rows[3:]),
            'whole_runner_elapsed_ns': manifest['elapsed_ns'],
            'observer_user_ns': manifest['observer_user_ns'], 'observer_system_ns': manifest['observer_system_ns'],
            'whole_job_cpu_or_global_peak_memory_established': False,
            'native_stdout_bytes': sum(r['stdout_bytes'] for r in command_rows[3:]),
            'native_stderr_bytes': sum(r['stderr_bytes'] for r in command_rows[3:]),
            'rss_scope': manifest['rss_scope'], 'native_process_rusage_scope': manifest['native_process_rusage_scope'],
            'failed_or_unreaped_descendants_may_be_missing': manifest['failed_or_unreaped_descendants_may_be_missing']},
        'host_observation': {'allowed_cpus': host['allowed_cpus'], 'logical_cpus': host['logical_cpus'],
            'machine': host['machine'], 'cgroup_root_view': host['cgroup'], 'cgroup_scope': host['cgroup_scope'],
            'current_cgroup': {k: current_cgroup[k] for k in ('status', 'subject', 'membership_path', 'resolved_path',
                'membership_resolved', 'visible_limits_complete', 'visible_ancestors', 'effective_quota_established',
                'namespace_external_ancestors_observed', 'native_child_membership_verified', 'atomic_snapshot',
                'consensus_or_model_authority', 'read_errors')}},
        'qualification_flags_as_recorded': {k: manifest[k] for k in reader.FALSE_FLAGS},
        'original_public_service_resource_contract_used': manifest['original_public_service_resource_contract_used'],
        'accounting_rules': [
            'Within an arm, setup + complete search production + disposal + winner cleanup + teardown are disjoint producer charges.',
            'Observation and actual native verifier intervals are separate; inclusive cohort contains all of them plus unitemized harness overhead.',
            'Command wait4 includes native cohort work and output/runtime overhead. Do not add it to nested component times.',
            'Observer self CPU is a separate Python runner process; not all global or child resource use is established.',
            'The 66-shard arithmetic sum is an evidence inventory, not a comparable aggregate rate across classes, targets, horizons, or controls.',
            'Horizon 1/8 prefixes are correlated. Speculative target hits are not independent accepted winners.',
            'Observed best fixed arm is a post-measurement descriptive minimum, not a globally optimal or predeclared adaptive strategy.',
            'Full fixed-grid costs are old-9f x64 component observations; no new ea909 source gate or public-service pass follows.',
        ],
        'shards': shard_rows, 'arms': all_arms, 'artifact_member_hashes': artifact_checks,
    }
    (OUT / 'fixed9f-v5-raw-analysis.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'analysis': pin(OUT / 'fixed9f-v5-raw-analysis.json'), 'counts': report['counts'],
        'counts_by_purpose': report['counts_by_purpose'], 'native_wait4_cpu_ns': report['command_costs']['native_66_commands_wait4_cpu_ns'],
        'old_9f_raw_reconciled': True, 'external_acceptance': False}, ensure_ascii=False, indent=2), flush=True)
