import ast,hashlib,importlib,json,os,pathlib,stat,sys,time,unittest
wt=pathlib.Path('/home/qian-qi/chain-bbdb-outbound-linux-20261114/source')
ev=pathlib.Path('/home/qian-qi/chain-bbdb-outbound-linux-20261114/t03-typed-pending-v1/linux-controls-v1')
import gzip
package=json.loads(gzip.decompress((ev.parent/'selected-linux-source.json.gz').read_bytes()))
expected=package['expected_project_source_blobs']
seen={};audit_busy=False;errors=[]
def blob(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def bind(path):
 rel=path.relative_to(wt).as_posix()
 if rel not in expected:raise RuntimeError('unreviewed project source input: '+rel)
 info=path.lstat()
 if not stat.S_ISREG(info.st_mode):raise RuntimeError('non-regular project source: '+rel)
 raw=path.read_bytes()
 if path.stat().st_mtime_ns!=info.st_mtime_ns or blob(raw)!=expected[rel]['git_blob']:
  raise RuntimeError('current reference source mismatch: '+rel)
 row={'path':rel,'bytes':len(raw),'git_blob':blob(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 if rel in seen and seen[rel]!=row:raise RuntimeError('project input changed between reads: '+rel)
 seen[rel]=row
def audit(event,args):
 global audit_busy
 if audit_busy or event!='open' or not args or not isinstance(args[0],(str,bytes,os.PathLike)):return
 path=pathlib.Path(os.path.abspath(os.fsdecode(args[0])))
 try:path.relative_to(wt)
 except ValueError:return
 audit_busy=True
 try:
  flags=args[2] if len(args)>2 and isinstance(args[2],int) else 0
  if flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC):raise RuntimeError('test attempted to write project source: '+str(path))
  bind(path)
 except BaseException as error:
  errors.append({'path':str(path),'type':type(error).__name__,'message':str(error)})
  raise
 finally:audit_busy=False
def flatten(suite):
 for node in suite:
  if isinstance(node,unittest.TestSuite):yield from flatten(node)
  else:yield node
def all_final():
 global audit_busy
 audit_busy=True
 try:
  for rel in list(seen):bind(wt/rel)
 finally:audit_busy=False
sys.path.insert(0,str(wt/'scripts'))
sys.addaudithook(audit)
summary={'scope':package['scope'],'reference_base':package['reference_base'],'linux_existing_base':package['linux_existing_base'],'pid':os.getpid(),'kernel':os.uname().release,'python':sys.version,'started_ns':time.time_ns(),'selected_original_new_controls':36,'model_or_campaign_qualification':False,'production_activation':False}
try:
 pilot=importlib.import_module('test_llm_runtime_pilot')
 ids=[case.id() for case in flatten(unittest.defaultTestLoader.loadTestsFromModule(pilot))]
 wanted=[]
 for group in package['original_roster']:
  wanted.extend(group['module']+'.'+group['class']+'.'+m['name'] for m in group['methods'])
 assert len(wanted)==len(set(wanted))==36
 assert all(ids.count(name)==1 for name in wanted),{name:ids.count(name) for name in wanted if ids.count(name)!=1}
 (ev/'pilot-discovery.json').write_text(json.dumps({'all_registered':len(ids),'typed_pending_registered_exactly_once':36,'typed_pending_ids':wanted},indent=2)+'\n')
 names=[g['module']+'.'+g['class'] for g in package['original_roster']]+['test_llm_runtime_exit_worker_observation.WorkerPidfdTests']
 suite=unittest.defaultTestLoader.loadTestsFromNames(names)
 selected_ids=[case.id() for case in flatten(suite)]
 assert len(selected_ids)==len(set(selected_ids))
 assert set(wanted)<=set(selected_ids)
 with (ev/'original-controls.stderr').open('w') as log:
  result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
 all_final()
 for item in package['preserved_sources']:
  raw=(wt/item['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256']
 for item in package['overlay']:
  raw=(wt/item['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256']
 summary.update(tests_run=result.testsRun,expected_tests=len(selected_ids),failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),was_successful=result.wasSuccessful(),selected_ids=selected_ids,failed_cases=[{'id':case.id(),'traceback':trace} for case,trace in result.failures+result.errors],skip_cases=[{'id':case.id(),'reason':reason} for case,reason in result.skipped],source_input_errors=errors,source_inputs=list(seen.values()),completed_ns=time.time_ns())
 summary['passed']=result.wasSuccessful() and not result.skipped and result.testsRun==len(selected_ids) and not errors
except BaseException as error:
 import traceback
 summary.update(passed=False,setup_error_type=type(error).__name__,setup_error=str(error),traceback=traceback.format_exc(),source_input_errors=errors,source_inputs=list(seen.values()),completed_ns=time.time_ns())
finally:
 (ev/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps({k:v for k,v in summary.items() if k not in ('selected_ids','source_inputs','failed_cases','traceback')}),flush=True)
 if 'traceback' in summary:print(summary['traceback'],file=sys.stderr,flush=True)
sys.exit(0 if summary.get('passed') else 1)
