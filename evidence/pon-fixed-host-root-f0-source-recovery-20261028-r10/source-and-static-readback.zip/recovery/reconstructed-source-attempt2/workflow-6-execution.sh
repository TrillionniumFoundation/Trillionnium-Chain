set -euo pipefail
test "$(id -u)" -ne 0
test -d /run/systemd/system
test -f /sys/fs/cgroup/cgroup.controllers
systemd-run --version > "$OUT/systemd-version.txt"
rustup_home="$(rustup show home)"
# The always finalizer handles both controller and separately owned
# public services, after exact receipt/manager/invocation validation.
sudo -n systemd-run --unit="$F0_UNIT" --description="$F0_DESCRIPTION" --wait --pipe --collect \
  --service-type=exec --expand-environment=no \
  --uid="$(id -u)" --gid="$(id -g)" --working-directory="$GITHUB_WORKSPACE" \
  --property=CPUAccounting=yes --property=MemoryAccounting=yes \
  --property=CPUQuota=400% --property=CPUQuotaPeriodSec=100ms \
  --property=MemoryMax=17179869184 --property=Nice=10 \
  --property=KillMode=control-group --property=TimeoutStopSec=20s --property=RuntimeMaxSec=600s \
  --setenv="PATH=$PATH" --setenv="CARGO_HOME=$CARGO_HOME" \
  --setenv="CARGO_TARGET_DIR=$CARGO_TARGET_DIR" --setenv="RUSTUP_HOME=$rustup_home" \
  --setenv=CARGO_INCREMENTAL=0 --setenv=CARGO_BUILD_JOBS=2 --setenv=RUST_TEST_THREADS=1 \
  --setenv=PYTHONDONTWRITEBYTECODE=1 --setenv=CI=true --setenv=GITHUB_ACTIONS=true \
  --setenv="GITHUB_WORKSPACE=$GITHUB_WORKSPACE" --setenv="GITHUB_RUN_ID=$GITHUB_RUN_ID" \
  --setenv="GITHUB_RUN_ATTEMPT=$GITHUB_RUN_ATTEMPT" --setenv="GITHUB_JOB=$GITHUB_JOB" \
  /usr/bin/python3 "$GITHUB_WORKSPACE/scripts/run_fixed_host_root_f0.py" execute \
  --out "$OUT/execution" --expected-head "$EXPECTED_HEAD" --expected-tree "$EXPECTED_TREE" \
  --prepared "$OUT/prepared/prepared.json" --prepared-sha256 "$PREPARED_SHA" --unit "$F0_UNIT" \
  > "$OUT/systemd-run.stdout.log" 2> "$OUT/systemd-run.stderr.log"
