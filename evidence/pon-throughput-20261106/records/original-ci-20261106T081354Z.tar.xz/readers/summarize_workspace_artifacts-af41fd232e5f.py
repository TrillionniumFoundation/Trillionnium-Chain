#!/usr/bin/env python3
"""Read retained original Workspace artifacts; do not execute repository code."""
import csv
import hashlib
import io
import json
import re
import zipfile
from collections import Counter
from pathlib import Path

BASE = Path(__file__).resolve().parent
REPO = "TrillionniumFoundation/Trillionnium-Chain"
RUN = 42179336034
HEAD = "9e50ca8e1ce655ef2f4686bd0ab58120b30c4632"
TREE = "8d67d4812661393cfc9dba2474c279d8285d6dee"


def read_json(z, path):
    return json.loads(z.read(path))


def summarize(meta_path):
    meta = json.loads(meta_path.read_text())
    if not meta.get("name", "").startswith("original-workspace-test-cpu-"):
        return None
    aid = int(meta_path.stem.split("-")[1])
    path = BASE / f"artifact-{aid}.zip"
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == meta["actual_sha256"]
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        before = read_json(z, "source-before.json")
        after = read_json(z, "source-after.json")
        assert before == after
        assert before["candidate"] == HEAD and before["tested_tree"] == TREE
        reg = read_json(z, "semantic-controls/registry-check.json")
        tsv = list(csv.DictReader(io.StringIO(z.read("semantic-controls/test-exits.tsv").decode()), delimiter="\t"))
        selected = list(csv.reader(io.StringIO(z.read("semantic-controls/selected-tests.tsv").decode()), delimiter="\t"))
        assert reg["selected_count"] == len(tsv) == len(selected)
        assert selected == [[r["crate"], r["group"], r["selector"]] for r in tsv]
        all_results, counts = [], Counter()
        for row in tsv:
            stem = row["selector"].split("::")[-1]
            matches = [n for n in z.namelist() if n.startswith("semantic-controls/") and n.endswith("-" + stem + ".log")]
            assert len(matches) == 1, (stem, matches)
            log_path = matches[0]
            log = z.read(log_path).decode()
            results = re.findall(r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out", log)
            assert len(results) == 1, (stem, results)
            result = results[0]
            count = {name: int(value) for name, value in zip(("passed", "failed", "ignored", "measured", "filtered_out"), result[1:])}
            assert count["passed"] + count["failed"] + count["ignored"] == 1
            counts["passed"] += count["passed"]
            counts["failed"] += count["failed"]
            counts["ignored"] += count["ignored"]
            item = dict(row, native_result=result[0], counts=count, log_path=log_path, log_sha256=hashlib.sha256(z.read(log_path)).hexdigest())
            if result[0] != "ok":
                item["failure_log"] = log
                item["execution_reader_stderr"] = z.read(log_path[:-4] + ".execution.stderr").decode()
                item["execution_json_bytes"] = len(z.read(log_path[:-4] + ".execution.json"))
            all_results.append(item)
        groups = []
        for group in sorted(set(r["group"] for r in tsv)):
            rr = [r for r in all_results if r["group"] == group]
            groups.append({"group": group, "selected": len(rr), "passed": sum(r["counts"]["passed"] for r in rr), "failed": sum(r["counts"]["failed"] for r in rr), "ignored": sum(r["counts"]["ignored"] for r in rr)})
        large = list(csv.DictReader(io.StringIO(z.read("test-exits.tsv").decode()), delimiter="\t"))
        growth = read_json(z, "growth-scale.readback.json")
        return {
            "run_id": RUN, "run_url": f"https://github.com/{REPO}/actions/runs/{RUN}",
            "artifact_id": aid, "artifact_name": meta["name"], "artifact_url": f"https://github.com/{REPO}/actions/runs/{RUN}/artifacts/{aid}",
            "archive_sha256": digest, "archive_bytes": len(raw), "archive_local_path": str(path),
            "source_before": before, "source_after": after, "source_before_after_equal": True,
            "registry": {key: reg[key] for key in ("result", "scope", "registry_counts", "selected_count")},
            "semantic_counts": dict(counts), "semantic_groups": groups,
            "semantic_failures": [r for r in all_results if r["native_result"] != "ok"],
            "semantic_control_results": all_results,
            "large_state_and_public_loop_exits": large,
            "growth_execution": read_json(z, "growth-scale.execution.json"),
            "growth_exits": z.read("growth-scale.exits.txt").decode(),
            "growth_readback": growth,
            "field_sources": {
                "source": "source-before.json and source-after.json",
                "registry": "semantic-controls/registry-check.json",
                "exits": "semantic-controls/test-exits.tsv",
                "semantic_counts": "Each exact selected test's own semantic-controls/*.log native libtest result; empty execution.json is not silently treated as success",
                "growth": "growth-scale.execution.json, growth-scale.exits.txt, growth-scale.readback.json",
            },
            "qualification": "Original same-head CI artifact observation only; a registry PASS is not semantic acceptance; no production TPS or public-network acceptance.",
        }


items = [v for p in sorted(BASE.glob("artifact-[0-9]*.json")) if (v := summarize(p)) is not None]
output = {"schema": "original-workspace-artifact-summary-v1", "head": HEAD, "tree": TREE, "run_id": RUN, "artifacts": items}
outpath = BASE / "workspace-original-artifact-summary.json"
outpath.write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"path": str(outpath), "sha256": hashlib.sha256(outpath.read_bytes()).hexdigest(), "matrices": [{"artifact_id": i["artifact_id"], "name": i["artifact_name"], "counts": i["semantic_counts"], "growth_result": i["growth_readback"].get("result"), "throughput_qualified": i["growth_readback"].get("throughput_qualified")} for i in items]}))
