#!/usr/bin/env python3
"""Record fresh W7 Python checks, with explicit semantic refusal assertions."""
from pathlib import Path
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import re
import subprocess
import time


OWNED = [
    "config/pon/w1-upstream-security-v1.json",
    "scripts/ci/w1_upstream_security.py",
    "scripts/ci/test_w1_upstream_security.py",
    "scripts/ci/pq_proof_profile_binding.py",
    "scripts/ci/test_pq_proof_profile_binding.py",
    "scripts/ci/ci_job.sh",
    "scripts/ci/check_ci_contract.py",
    "scripts/ci/test_ci_contract.py",
    "scripts/ci/check_pq_research_integration.py",
    "scripts/ci/test_pq_research_integration.py",
    ".github/workflows/chain-hepta-closure-candidate.yml",
]
DESCRIPTOR = "dd77d2a89bbeb0c308e49d1680020b6cb9eea82f745ac4623f9cf906d8a4bded"
MAPPING = "config/pon/w1-qrom-implementation-current-v2.json"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def source_manifest(root):
    result = {}
    for path in OWNED + [MAPPING]:
        data = (root / path).read_bytes()
        result[path] = {
            "bytes": len(data),
            "sha256": digest(data),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
        }
    return result


def semantics(name, stdout, stderr):
    if name.endswith("-tests"):
        text = stderr.decode("utf-8")
        count = re.search(r"Ran (\d+) tests? in [\d.]+s", text)
        expected = {"upstream-tests": 14, "profile-tests": 31}.get(name)
        footer = text.rstrip().splitlines()[-1] if text.strip() else ""
        skipped = re.search(r"\bskipped=(\d+)", footer)
        skipped_count = int(skipped.group(1)) if skipped else 0
        ok = bool(count) and footer == "OK" and skipped_count == 0
        if expected is not None:
            ok = ok and int(count.group(1)) == expected
        return {"passed": ok, "test_count": int(count.group(1)) if count else None,
                "expected_test_count": expected, "unittest_footer": footer,
                "skipped_test_count": skipped_count}
    if name in ("preflight", "ci-contract-reader", "diff-check"):
        return {"passed": True, "scope": "exit-status-only"}
    report = json.loads(stdout)
    upstream = report["upstream_security"] if name.startswith("profile-") else report
    checks = {
        "upstream_known_affected": upstream["status"] == "KNOWN_AFFECTED_SELECTED_PROFILE",
        "affected_package_entries_15": len(upstream["affected_locked_packages"]) == 15,
        "backend_observations_3": len(upstream["backend_observations"]) == 3,
        "current_use_refused": upstream["current_proof_use_eligible"] is False,
        "migration_not_approved": upstream["migration_approved"] is False,
        "whole_chain_not_qualified": upstream["whole_chain_pq_qualified"] is False,
        "activation_not_performed": upstream["production_activation"] is False,
        "historical_artifacts_not_modified": upstream["historical_artifacts_modified"] is False,
        "fresh_verification_not_performed": upstream["fresh_verification_performed"] is False,
    }
    if name.startswith("profile-"):
        checks.update({
            "profile_revoked_hold": report["status"] == "PROFILE_BOUND_UPSTREAM_REVOKED_HOLD",
            "descriptor_matches": report["selected_profile_descriptor_sha256"] == DESCRIPTOR,
            "profile_current_use_refused": report["current_proof_use_eligible"] is False,
            "profile_whole_chain_not_qualified": report["whole_chain_pq_qualified"] is False,
            "native_verification_not_performed": report["native_proof_verification_performed"] is False,
        })
    if name.endswith("-current-refusal"):
        refusal = json.loads(stderr)
        checks.update({
            "stderr_refuse": refusal["status"] == "REFUSE",
            "stderr_semantic_reason": refusal["reason"] == "selected proof profile is not eligible for current use",
            "stderr_current_use_refused": refusal["current_proof_use_eligible"] is False,
        })
    else:
        checks["no_stderr"] = stderr == b""
    return {"passed": all(checks.values()), "checks": checks}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root, out = args.root.resolve(), args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    dump(out / "previous-observation-boundary.json", {
        "schema": "trnm-w7-executor-disruption-observation-v1",
        "scope": "record-of-log-loss-not-reconstructed-execution-evidence",
        "previous_log_directories": ["/tmp/chain-w7-6478", "/tmp/chain-w7-scope-6478"],
        "previous_log_directories_present_after_recovery": False,
        "old_raw_logs_available": False,
        "old_complete_corpus_execution_result": "UNKNOWN",
        "previous_observations_in_conversation": [
            "Original sparse checkout checks reported missing files and failed.",
            "An exact selected-source snapshot reported 14 upstream and 31 profile tests passing and semantic current-use refusal.",
            "The executor disconnected during a sparse materialization command; its final status was not observed.",
        ],
        "qualification_inherited_from_old_results": False,
        "note": "The new run below is independently executed. No missing raw log or old terminal state is reconstructed.",
    })
    (out / "run-script.py").write_bytes(Path(__file__).read_bytes())
    before = source_manifest(root)
    dump(out / "source-before.json", before)
    base_head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
    (out / "git-status-before.txt").write_bytes(subprocess.check_output(["git", "status", "--short"], cwd=root))

    def run(case):
        name, argv, expected = case
        start = time.monotonic()
        result = {"name": name, "argv": argv, "cwd": str(root), "expected_exit": expected,
                  "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
        op, ep = out / (name + ".stdout"), out / (name + ".stderr")
        with op.open("wb") as stdout, ep.open("wb") as stderr:
            try:
                completed = subprocess.run(argv, cwd=root, stdout=stdout, stderr=stderr, timeout=600, check=False)
                result.update(returncode=completed.returncode, timeout=False)
            except subprocess.TimeoutExpired:
                result.update(returncode=None, timeout=True)
        result["duration_seconds"] = time.monotonic() - start
        result["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        stdout, stderr = op.read_bytes(), ep.read_bytes()
        result["stdout_sha256"], result["stderr_sha256"] = digest(stdout), digest(stderr)
        result["stdout_bytes"], result["stderr_bytes"] = len(stdout), len(stderr)
        try:
            result["semantic_assertions"] = semantics(name, stdout, stderr)
        except (KeyError, TypeError, ValueError, AttributeError) as error:
            result["semantic_assertions"] = {"passed": False, "error": str(error)}
        result["expectation_met"] = result["returncode"] == expected and result["semantic_assertions"]["passed"]
        dump(out / (name + ".receipt.json"), result)
        print(json.dumps(result, sort_keys=True), flush=True)
        return result

    preflight = run(("preflight", ["bash", "scripts/project-preflight.sh"], 0))
    if not preflight["expectation_met"]:
        dump(out / "summary.json", {"scope": "preflight-failed-no-test-execution", "results": [preflight]})
        return 1
    matrix = [
        ("upstream-tests", ["python3", "-B", "scripts/ci/test_w1_upstream_security.py", "-v"], 0),
        ("profile-tests", ["python3", "-B", "scripts/ci/test_pq_proof_profile_binding.py", "-v"], 0),
        ("ci-contract-tests", ["python3", "-B", "scripts/ci/test_ci_contract.py", "-v"], 0),
        ("ci-contract-reader", ["python3", "-B", "scripts/ci/check_ci_contract.py"], 0),
        ("upstream-diagnostic", ["python3", "-B", "scripts/ci/w1_upstream_security.py"], 0),
        ("upstream-current-refusal", ["python3", "-B", "scripts/ci/w1_upstream_security.py", "--require-current"], 2),
        ("profile-descriptor", ["python3", "-B", "scripts/ci/pq_proof_profile_binding.py", "--expected-profile-descriptor-sha256", DESCRIPTOR], 0),
        ("profile-current-refusal", ["python3", "-B", "scripts/ci/pq_proof_profile_binding.py", "--require-current"], 2),
        ("diff-check", ["git", "diff", "--check", "--"] + OWNED, 0),
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results = [preflight] + list(pool.map(run, matrix))
    after = source_manifest(root)
    dump(out / "source-after.json", after)
    (out / "git-status-after.txt").write_bytes(subprocess.check_output(["git", "status", "--short"], cwd=root))
    success = before == after and all(item["expectation_met"] for item in results)
    summary = {
        "schema": "trnm-w7-upstream-security-local-validation-v1",
        "scope": "precommit Python checks on shared full checkout; selected source files hashed before/after; no native execution or release qualification",
        "root": str(root), "base_head": base_head, "owned_source_unchanged": before == after,
        "all_expectations_met": success, "selected_source_file_count": len(before),
        "complete_corpus_gate_run": False, "complete_final_candidate_verified": False,
        "current_proof_use_eligible": False, "migration_approved": False,
        "native_proof_verification_performed": False, "whole_chain_pq_qualified": False,
        "production_activation": False, "results": results,
    }
    dump(out / "summary.json", summary)
    print(json.dumps({"summary": str(out / "summary.json"), "owned_source_unchanged": before == after,
                      "all_expectations_met": success}), flush=True)
    return 0 if success else 1


if __name__ == "__main__":
    raise SystemExit(main())
