# Independent review of the finite continuing-public model

## Result

No unresolved correctness defect was found in the reviewed scope. Two scope
issues raised during review were corrected by the owning agent before this
final check:

1. The maximizing policy is now explicitly an observer-census-and-complete-
   future-public-schedule-aware envelope. It is not an advice-free mining
   strategy. The declared class also explicitly excludes mid-action aborts,
   restarts and public-branch switching; search/proof/propagation are atomic
   with respect to private decisions.
2. The additive fault envelope now uses a competition-specific callback. It is
   a private-machine coupling conditional on exact external honest block
   identities, arrivals and receiver transitions. It explicitly does not bound
   honest production, receiver or network faults. This is not a complete
   mixed-network machine or settlement bound.

The two review-target files and their relevant fixture/helper definitions were
read. The check script and this note are outside the repository. No repository
source edits, native builds, commits or publication were performed in this
review.

## Exact reviewed source

| File | SHA-256 |
|---|---|
| formal/pon-nakamoto-v1/w1_competing_consensus.py | 074172317c31170ecc12570ec148e39a24fa5fb7e66bb2b2766ce174f682c9f1 |
| formal/pon-nakamoto-v1/w1_finite_consensus.py | 206b6e431f2071541dbdfefc47ab67dafbd75911872e225cd290b23e558dfba0 |

Both hashes matched before and after the final check.

## Independent checks

`independent_review.py` uses the reduced fixture constructor as input. The
fixture's 16-nonce winner inventory is a premise of these transition checks.
Expected action lists, classical phase accounting, chronological receiver
events and exact backward values are independently implemented. Production
transitions and the optimizer are systems under test, never the expected-value
oracle. The expected receiver algorithm uses chronological buckets rather
than the implementation's combined event-tuple sort. All graph states used by
the check are reached through the independent transitions.

The final run passed 29 cases comprising 458 case-state visits, 1,117 permitted
state/action pairs and 2,992 probability edges. These are totals across cases,
not counts of globally distinct states. Cases include both risk events and
early/late schedules, plus deadline minus/equal/plus 10^-12 second at setup,
nonce availability, candidate completion, proof completion and full bundle
propagation boundaries. They also include simultaneous honest admissions and
an honest event exactly at the horizon. Full phase paid/planned/completed
fields, next states and receiver event traces are compared exactly.

Independent ideal upper values were:

| Fixture scenario | Ever private replacement | Private active at horizon |
|---|---:|---:|
| Early two-block honest continuation | 0 | 0 |
| Late two-block honest continuation | 1/128 | 0 |
| One honest continuation arriving at horizon | 1/128 | 1/128 |

The one-honest-block case is an additional positive survival control. Earlier
private publication survives an equal-work honest arrival at the deadline;
publication at the identical time loses under the declared honest-first tie
order. Sixteen positive survival boundary comparisons use an exact 10^-40
second offset. A separate 16 receiver comparisons cover simultaneous honest
events, no publication, zero-time publication and deadline ties.

Eight same-observed-prefix state comparisons give identical fixed-q actions
under different future arrival schedules, including states with private
winners. The policy never chooses the future-dependent wait action. This
checks policy behavior; the simulation evaluator itself necessarily contains
the future schedule and literal nonce distribution.

Fourteen complete dense-state amplitude comparisons (two supplied domains,
q=0 through q=6) agree with the production two-dimensional rational recurrence.
This is ideal probability arithmetic, not physical quantum execution.

The classical host-envelope test independently counts reserved calls and
propagations. Its declared epsilon is exactly
1/62500000000000000000000000000. The check confirms the new external-event
condition and false whole-network-fault coverage flag. It does not validate
the physical truth of the supplied per-call fault assumptions.

## Scope that remains conditional

Action coverage is relative to the closed input DAG, supplied q choices,
serial private processor, finite attempt cap and finite horizon. It does not
cover arbitrary waits, mid-action intervention, alternative W1 algorithms,
arbitrary timestamps, adaptive public miners or long-term DAA/settlement.

The model validates honest block identities and metadata arithmetic. Complete
honest packet admission remains an external native-bridge premise. Native
receipts and the probabilistic environmental assumptions must be reported
separately. This check did not execute Node, QPU hardware or the full quantum
lifecycle timing model; the new independent phase interpreter covers the
classical q=0 path. It does not revalidate the full literal W1 predicate or
physical calibration.

The finite-module diff was also inspected: the fixed-public API supplies the
original callbacks, and competition supplies its own header, fixed policy,
source inventory and risk coupling callback to the shared writer/checker and
sampler. Fixed-policy sampling still does not consult Bellman values.

## Reproduction and retained diagnostics

Run from any working directory:

```sh
python /workspace/scratch/c9b48df754d6/validation-competing-review/independent_review.py
```

Final exit status: 0. Final stderr is empty.

| Artifact | SHA-256 |
|---|---|
| independent_review.py | 3ee78e38a57e677e586fd740f7b3695f257e8176ed805a36f041ac196f787e79 |
| independent-review-result.json | 7c8d0e99f8c3b7bd265ad3eea9b95024c2fa7bbcc84fc748406511672881278e |

Two initial harness mistakes are retained, accurately classified:
`initial-harness-invalid-horizon.stderr` used a fractional string where the
public API requires a decimal string; `harness-variable-shadowing.stderr`
overwrote the local source-hash snapshot variable with a receiver trace. Both
were fixed only in the external check script. The latter initially triggered
a mistaken source-race notice, immediately retracted after checking the
unchanged hashes. Neither is a production failure or evidence of source
instability.
