from pathlib import Path
import hashlib,io,json,os,stat,sys,tarfile,time,traceback
BASE=Path("/tmp/trnm-genesis-owner-20261116-8ppak97a");ROOT=BASE/"repo"
sys.path.insert(0,str(ROOT))
from hia.platform.genesis_store import build,rust_oracle
EXPECTED="a0fa6c27d48779ae04a7c69cb175b92e00d714e5c443e46a49483c217b870046"
SUITES=("semantic","crash","prefix","namespace","corruption")
def need(value,message):
    if not value:raise RuntimeError(message)
def identity(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def fhash(path):
    h=hashlib.sha256();size=0
    with path.open("rb") as stream:
        while block:=stream.read(1<<20):size+=len(block);h.update(block)
    return {"bytes":size,"sha256":h.hexdigest()}
receipt={"schema":"trnm.genesis-final-native-evidence.v1","status":"FAIL"}
started=time.monotonic_ns()
try:
    sources=build.source_manifest(ROOT);original=build.original_manifest(ROOT)
    need(identity(json.dumps(sources,sort_keys=True,separators=(",",":")).encode())["sha256"]==EXPECTED,"Source freeze mismatch")
    need(rust_oracle.complete_source_manifest(ROOT)==sources,"Oracle closure differs")
    summary=[]
    for kind in SUITES:
        folder=BASE/("final15-"+kind);report=json.loads((folder/"report.json").read_bytes())
        execution=json.loads((BASE/("final15-"+kind+"-execution.json")).read_bytes())
        need(report["status"]=="PASS" and execution["status"]=="PASS" and execution["exit_code"]==0,"Suite did not complete successfully: "+kind)
        need(report["build"]["source_inputs"]==sources and report["build"]["original_sources"]==original,"Suite source binding mismatch")
        need(report["verification"]=={"source_after":{"status":"PASS","source_set_sha256":EXPECTED,
             "native_source_files":len(sources),"original_source_files":len(original)},
             "primary_error":None,"cleanup_errors":[]},"Suite did not close source/cleanup verification")
        image=fhash(folder/"build/genesis-owner.elf")
        need(image=={"bytes":753794,"sha256":"304dfb77e6c4909d703995fafb523419dfb2f09ee432c2cf6a95a9956af17f85"},"Real ELF changed")
        need(all(report["build"]["executable"][k]==v for k,v in image.items()),"ELF report mismatch")
        summary.append({"suite":kind,"status":"PASS","controls":report["controls_total"],
          "real_native_processes":report["real_native_processes"],"elapsed_ns":report["elapsed_ns"],
          "execution_elapsed_ns":execution["elapsed_ns"],"report":fhash(folder/"report.json"),
          "execution":fhash(BASE/("final15-"+kind+"-execution.json")),"actual_executable":image})
    admitted=rust_oracle.validate_bundle(ROOT,BASE/"final15-semantic/bundle")
    roots=[]
    for path in sorted(BASE.iterdir()):
        if path.name.startswith(".") or path.name in ("repo","final-native-evidence.tar.xz","final-native-evidence.json"):
            continue
        roots.append(path)
    regular={};nonregular={}
    def capture(path):
        relative=path.relative_to(BASE).as_posix();meta=path.lstat()
        attrs={"mode":stat.S_IMODE(meta.st_mode),"uid":meta.st_uid,"gid":meta.st_gid,
            "links":meta.st_nlink,"device":meta.st_dev,"inode":meta.st_ino,"size":meta.st_size,
            "mtime_ns":meta.st_mtime_ns,"ctime_ns":meta.st_ctime_ns}
        if stat.S_ISREG(meta.st_mode):
            need(relative not in regular,"Duplicate evidence path")
            regular[relative]={"path":path,"identity":fhash(path),"original_attributes":attrs}
        elif stat.S_ISDIR(meta.st_mode):
            for child in sorted(path.iterdir()):
                if child.name.startswith(".hepta-lock-"):continue
                capture(child)
        else:
            kind="symlink" if stat.S_ISLNK(meta.st_mode) else "fifo" if stat.S_ISFIFO(meta.st_mode) else "socket" if stat.S_ISSOCK(meta.st_mode) else "other"
            nonregular[relative]={"type":kind,"original_attributes":attrs}
            if kind=="symlink":nonregular[relative]["link_text"]=os.readlink(path)
    for path in roots:capture(path)
    source_material={}
    for name,expected in sources.items():
        raw=(ROOT/name).read_bytes();need(identity(raw)==expected,"Source changed before archive")
        source_material["final-source/"+name]=raw
    manifest={"schema":"trnm.genesis-native-evidence-file-manifest.v1",
        "regular_files":{"evidence/"+name:{"identity":row["identity"],"original_attributes":row["original_attributes"]}
            for name,row in regular.items()},
        "final_source":{name:identity(raw) for name,raw in source_material.items()},
        "nonregular_observations_not_materialized":nonregular,
        "suite_summary":summary,"current_source_set_sha256":EXPECTED,
        "actual_original_rust_executed_by_this_collector":False,
        "not_a_physical_power_loss_test":True,"not_a_continuous_hostile_same_uid_proof":True}
    manifest_raw=(json.dumps(manifest,sort_keys=True,indent=2)+"\n").encode()
    archive_path=BASE/"final-native-evidence.tar.xz"
    expected_entries={}
    with tarfile.open(archive_path,"x:xz",preset=6) as archive:
        for name,row in sorted(regular.items()):
            member=tarfile.TarInfo("evidence/"+name);member.size=row["identity"]["bytes"];member.mode=0o600;member.mtime=0
            with row["path"].open("rb") as stream:archive.addfile(member,stream)
            expected_entries[member.name]=row["identity"]
        for name,raw in sorted(source_material.items()):
            member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o600;member.mtime=0
            archive.addfile(member,io.BytesIO(raw));expected_entries[name]=identity(raw)
        member=tarfile.TarInfo("EVIDENCE-MANIFEST.json");member.size=len(manifest_raw);member.mode=0o600;member.mtime=0
        archive.addfile(member,io.BytesIO(manifest_raw));expected_entries[member.name]=identity(manifest_raw)
    observed={}
    with tarfile.open(archive_path,"r:xz") as archive:
        for member in archive:
            need(member.isfile() and member.name not in observed,"Unsafe evidence archive member")
            h=hashlib.sha256();size=0
            with archive.extractfile(member) as stream:
                while block:=stream.read(1<<20):size+=len(block);h.update(block)
            observed[member.name]={"bytes":size,"sha256":h.hexdigest()}
    need(observed==expected_entries,"Archive full membership differs")
    for name,row in regular.items():need(fhash(row["path"])==row["identity"],"Historical/current evidence changed during archive: "+name)
    need(build.source_manifest(ROOT)==sources and build.original_manifest(ROOT)==original,"Source changed during collection")
    archive_path.chmod(0o400)
    receipt.update(status="PASS",archive_path=str(archive_path),archive=fhash(archive_path),
      source_inputs=sources,original_source_files=len(original),source_set_sha256=EXPECTED,
      suites=summary,total_controls=sum(r["controls"] for r in summary),
      total_real_native_processes=sum(r["real_native_processes"] for r in summary),
      regular_members=len(observed),nonregular_observations=len(nonregular),
      member_manifest=identity(manifest_raw),all_members_reopened_and_hashed=True,
      source_after="MATCH",original_rust="NOT_RUN_BY_THIS_COLLECTOR",
      limitations={"complete_node":False,"successor_admission":False,"physical_power_loss":False,
        "continuous_hostile_same_uid":False,"os_page_cache_flush":False,
        "same_format_as_original_sqlite":False})
except BaseException as error:
    receipt["failure"]={"error":repr(error),"traceback":traceback.format_exc()}
finally:
    receipt["collector_elapsed_ns"]=time.monotonic_ns()-started
    with (BASE/"final-native-evidence.json").open("x") as stream:stream.write(json.dumps(receipt,sort_keys=True,indent=2)+"\n")
    print(json.dumps({k:receipt.get(k) for k in ("status","archive_path","archive","source_set_sha256",
       "total_controls","total_real_native_processes","regular_members","nonregular_observations","failure")}),flush=True)
raise SystemExit(0 if receipt["status"]=="PASS" else 1)
