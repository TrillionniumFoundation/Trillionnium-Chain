# Native default-genesis persistent owner

This component is under development and has no qualification yet.

The native HIA owner constructs Settings::development(None or Some(timestamp)),
the complete seven-row initial State, the genesis catalog row, active generation
zero and slot zero. It owns the real private directory description, its process
lock, the file being initialized and the published file. There is no external
State, Delta, context, expected-root or successful-admission input.

This is a fresh native stored schema. It does not read or rewrite SQLite, the
generic StoreOwner namespace, deployed data or any other backend. The complete
admitted namespace is ng1.owner.lock and exactly one internally named pending or
state file. That filename contains the full native-computed genesis identity.

The finite catalog has one block with absent parent and packet, height zero and
64 zero chainwork bytes, one active row, one initial snapshot referring to the
same complete State, and empty deltas, events, reorganization intent and steps,
reorganization lifecycle, ancestry jumps, local pool, replay, audit and outbox
collections. Other catalogs are refused even if they claim the genesis active
tip. This unit contains no successor-admission or arbitrary COMMIT operation.

Initialization synchronizes the complete pending file, rereads it and computes
M06 over its actual stored State, then publishes by RENAME_NOREPLACE and fsyncs
the directory. The same owner opens and fully validates the published file
before an opened receipt. Explicit recovery validates every existing byte of
the context-named pending prefix before writing only its missing suffix. An
unbound lock-only namespace is not a recovery capability. Simultaneous pending
and final files, unknown entries and wrong-context filenames refuse unchanged.

Every READ repeats complete physical file reading, native root computation and
comparison with its actual stored catalog root. It checks the retained lock and
file inode against freshly opened names, along with exact directory/file
ownership, modes, regular type and one-link file ownership. Both diagnostic FDs
must be distinct real pipes with the correct access mode before any diagnostic
write. They carry pause/resume observations, not service permission or commit
authority.

The final rename attempt starts the publication uncertainty interval. It ends
only after successful directory fsync. A missing opened receipt always requires
reopening; later response I/O failure does not establish rollback. The explicit
diagnostic gate can pause physical boundaries or encounter actual EOF. It does
not introduce a cancellable checkpoint after publication or implement the
original external PQ witness CAS contract.

Only native HIA code performs construction, state interpretation, expected-root
validation, filesystem state transitions and result decisions. The HIA-emitted
Linux x86-64 adapter remains a separately trusted literal-ISA boundary. Hosted
Python only authors, builds and qualifies source.

The original initialization relation is in store.rs 2183-2254. In this exact
closed genesis catalog, cold recover has no pending reorganization and its
best-work target equals the active genesis, so original recovery makes no
successor State write. Physical schema bytes differ because this is an explicit
new native format; the original full logical State and catalog facts must be
compared with a real original Rust Node.

Settings-dependent configuration, default task material, the 65,536 classic and
1,065,536 growth limits are unchanged. Seven rows are the result of this exact
default constructor, not a replacement maximum State size.

Still OPEN: complete M06 execution and its private admitted-output owner,
validated successor block/receipt/task output persistence, branch catalog,
reorganization/cancellation lifecycle, generic hot State changes, alternate
Settings and continuity/growth constructors, GSC2, authenticated and PQ backends,
replay/outbox mutation owners, external anti-rollback witness, physical power
loss, hostile continuous same-UID mutation, and original service budgets.
Neither this unit nor its future successful tests can retire the original Node.
