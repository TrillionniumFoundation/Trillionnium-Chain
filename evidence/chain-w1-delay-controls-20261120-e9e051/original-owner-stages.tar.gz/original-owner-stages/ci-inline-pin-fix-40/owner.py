from pathlib import Path
import sys,json,subprocess,hashlib,time,resource,traceback
base=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');src=base/'source';out=base/'ci-inline-pin-fix-40';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);start=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
result={'qualification_granted':False,'reader_changed':False,'roster_changed':False}
try:
 with (out/'preflight.log').open('xb') as f:assert subprocess.call(['bash','scripts/project-preflight.sh'],cwd=src,stdout=f,stderr=subprocess.STDOUT)==0
 p=src/'.github/workflows/pon-branch-encoding-acceptance.yml';assert hashlib.sha256(p.read_bytes()).hexdigest()=='11fa74a841c9db70ccfebd50f414a56a18585a6b1552d029a3c6f61b67542704';p.write_bytes((base/'ci-inline-pin-audit-36/pon-branch-encoding-acceptance.yml.candidate').read_bytes())
 sys.path.insert(0,str(src/'scripts/ci'));import check_ci_contract
 count=check_ci_contract.check_inline_source_pins(src);assert count==26
 result.update(complete=True,all_current_inline_pins=count,source_patch_sha256=hashlib.sha256((base/'ci-inline-pin-audit-36/source.patch').read_bytes()).hexdigest(),workflow_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
except BaseException as e:result.update(complete=False,error=repr(e));(out/'error.log').write_text(traceback.format_exc());raise
finally:
 a=resource.getrusage(resource.RUSAGE_CHILDREN);result.update(wall_seconds=time.monotonic()-start,child_user_cpu_seconds=a.ru_utime-b.ru_utime,child_system_cpu_seconds=a.ru_stime-b.ru_stime,self_cpu_unknown=True);(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
