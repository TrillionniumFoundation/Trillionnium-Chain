#!/usr/bin/env python3
"""Package finite native observations after the separately frozen run completes."""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
import re
import stat
import subprocess
import tarfile
import time

ROOT=Path('/home/qian-qi/work/chain-qrom-local-20261107-7150')
OUT=Path('/home/qian-qi/work/chain-qrom-closure-20261107-evidence/native-7150')
HEAD='7150d96a2112875b4afcf3023361a5cef4a0e4b1'
ARCHIVE='native-7150-observations.tar.gz'


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()


def read(name): return json.loads((OUT/name).read_text())
def write(name, data):
    path=OUT/name
    with path.open('x') as stream:
        json.dump(data,stream,sort_keys=True,indent=2)
        stream.write('\n')


def frozen():
    actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    if actual!=HEAD: raise ValueError('frozen source HEAD changed')


def command(name, argv, expected=0, timeout=900):
    frozen()
    start=datetime.now(timezone.utc).isoformat()
    begin=time.monotonic()
    out,err=OUT/(name+'.stdout.log'),OUT/(name+'.stderr.log')
    with out.open('xb') as stdout,err.open('xb') as stderr:
        completed=subprocess.run(argv,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=timeout,
            env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',CARGO_BUILD_JOBS='2',
                CARGO_TARGET_DIR=str(OUT/'cargo-target'),CARGO_TERM_COLOR='never'))
    row={'name':name,'command':argv,'cwd':str(ROOT),'source_commit':HEAD,
        'started_utc':start,'elapsed_seconds':time.monotonic()-begin,
        'exit_code':completed.returncode,'expected_exit':expected,
        'expectation_met':completed.returncode==expected,'timeout_seconds':timeout,
        'stdout_sha256':sha(out),'stderr_sha256':sha(err),
        'stdout_bytes':out.stat().st_size,'stderr_bytes':err.stat().st_size}
    write(name+'.json',row)
    print(json.dumps(row),flush=True)
    return row


def test_results(name):
    path=OUT/(name+'.stdout.log')
    text=path.read_text()
    pattern=r'^test result: ([^.]+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;[^\n]*$'
    rows=[]
    for match in re.finditer(pattern,text,re.M):
        rows.append(dict(zip(['result','passed','failed','ignored','measured','filtered_out'],
            [match.group(1)]+[int(match.group(i)) for i in range(2,7)])))
    names=re.findall(r'^test ([^\n]+) \.\.\. FAILED$',text,re.M)
    ignored=[{'name':m.group(1),'reason':m.group(2)} for m in
        re.finditer(r'^test ([^\n]+?) \.\.\. ignored(?:, ([^\n]*))?$',text,re.M)]
    return {'aggregate':{key:sum(row[key] for row in rows) for key in ['passed','failed','ignored','measured','filtered_out']},
        'reported_test_result_blocks':len(rows),'blocks':rows,'named_failed_tests':names,
        'named_ignored_tests':ignored,
        'scope':'Only test result lines actually emitted by this command; not an independent expected-test roster.',
        'stdout_sha256':sha(path),'command_exit_code':read(name+'.json')['exit_code'],
        'timed_out':read(name+'.json')['timed_out']}


def worktree_observation():
    frozen()
    raw=subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=ROOT)
    (OUT/'source-status-final.porcelain').write_bytes(raw)
    items=raw.split(b'\0')
    rows=[]
    index=0
    while index<len(items):
        item=items[index]
        index+=1
        if not item: continue
        code=item[:2].decode('ascii')
        path=item[3:].decode('utf-8')
        row={'status':code,'path':path}
        if 'R' in code or 'C' in code:
            row['original_path']=items[index].decode('utf-8'); index+=1
        rows.append(row)
    report={'head':HEAD,'command':['git','status','--porcelain=v1','-z','--untracked-files=all'],
        'cwd':str(ROOT),'record_count':len(rows),'records':rows,
        'all_reported_changes_are_deleted_evidence':all(row['status']==' D' and row['path'].startswith('evidence/') for row in rows),
        'full_tracked_clean':not rows,'full_tracked_identity_claimed':False,
        'porcelain_sha256':sha(OUT/'source-status-final.porcelain')}
    write('source-worktree-final.json',report)
    return report


def registry_extras():
    dependencies=read('resolved-dependencies-after.json')
    packages=[]
    for key,row in sorted(dependencies['packages'].items()):
        if row['source'] is None: continue
        root=Path(row['manifest_path']).parent
        archive=root.parents[2]/'cache'/root.parent.name/(root.name+'.crate')
        with tarfile.open(archive,'r:gz') as source:
            names={m.name[len(root.name)+1:] for m in source if m.isfile() and m.name.startswith(root.name+'/')}
        extras=[]
        for p in sorted(root.rglob('*')):
            if p.is_dir(): continue
            relative=str(p.relative_to(root))
            if relative in names: continue
            entry={'path':relative,'regular_file':stat.S_ISREG(p.lstat().st_mode)}
            if entry['regular_file']:
                entry.update(bytes=p.stat().st_size,sha256=sha(p))
            extras.append(entry)
        packages.append({'package_id':key,'extras':extras})
    report={'schema':'TRNM-W1-NATIVE-REGISTRY-EXTRAS1','head':HEAD,'packages':packages,
        'package_count':len(packages),'extra_file_count':sum(len(p['extras']) for p in packages),
        'all_extras_are_cargo_cache_markers':all(e['path'] in ['.cargo-ok','.cargo-checksum.json'] and e['regular_file'] for p in packages for e in p['extras']),
        'scope':'Post-run inventory only; records files outside the lock-matched crate archive instead of silently assuming none.'}
    write('registry-extra-files-after.json',report)
    return report


def final_selected_source():
    before=read('selected-source-before.json')
    after=read('selected-source-after.json')
    for row in after['files']:
        data=(ROOT/row['path']).read_bytes()
        blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        if blob!=row['expected']['git_blob'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
            raise ValueError('selected source changed before packaging: '+row['path'])
    result={'head':HEAD,'selected_count':len(after['files']),
        'selected_bytes_rechecked_at_packaging':True,'selected_match_HEAD':all(r['matches_head'] for r in after['files']),
        'selected_before_after_same':before['files']==after['files'],
        'selected_before_sha256':sha(OUT/'selected-source-before.json'),
        'selected_after_sha256':sha(OUT/'selected-source-after.json'),
        'full_tracked_identity_claimed':False,'mode_or_hermetic_build_identity_claimed':False}
    write('selected-source-packaging-check.json',result)
    return result


def configuration_hashes():
    # Hash only these known configuration files. Never publish their contents.
    candidates=[Path.home()/'.cargo/config',Path.home()/'.cargo/config.toml',
        ROOT/'trillionnium/.cargo/config',ROOT/'trillionnium/.cargo/config.toml',
        ROOT/'.cargo/config',ROOT/'.cargo/config.toml',
        ROOT/'formal/pon-nakamoto-v1/w1_v2_verifier/.cargo/config.toml']
    rows=[]
    for p in candidates:
        row={'path':str(p),'present':p.is_file()}
        if p.is_file(): row.update(bytes=p.stat().st_size,sha256=sha(p))
        rows.append(row)
    result={'files':rows,'contents_disclosed':False,
        'scope':'Selected known configuration file hashes after run; not a hermetic compiler/environment attestation.'}
    write('selected-cargo-config-identities.json',result)
    return result


def executable_identity_recheck():
    binary=read('v2-binary-identity.json')
    official=read('official-image-comparison.json')
    context=read('compiled-feature-subscope.json')
    checks=[(Path(binary['path']),binary['sha256']),
        (OUT/'official-image',official['probe_binary_sha256']),
        (OUT/'official_image.rs',official['probe_source_sha256']),
        (OUT/'release-context',context['context_probe_binary_sha256']),
        (OUT/'release_context.rs',context['context_probe_source_sha256'])]
    for stage,expected in [('official-image-build',official['upstream_rlib_sha256']),
                           ('release-context-build',context['linked_hardened_rlib_sha256'])]:
        argv=read(stage+'.json')['command']
        extern=argv[argv.index('--extern')+1]
        checks.append((Path(extern.split('=',1)[1]),expected))
    rows=[]
    for path,expected in checks:
        got=sha(path)
        rows.append({'path':str(path),'expected_sha256':expected,'actual_sha256':got,'matches':got==expected})
    report={'head':HEAD,'files':rows,'all_match_recorded_execution_identities':all(r['matches'] for r in rows)}
    write('executable-identities-after.json',report)
    if not report['all_match_recorded_execution_identities']:
        raise ValueError('executable/probe/linked-library identity changed after execution')
    return report


def main():
    frozen()
    index=read('native-index.json')
    names=[row['name'] for row in index['records']]
    if names[-1]!='full-source-after' or not {'chain-workspace-tests','chain-strict-clippy'}<=set(names):
        raise ValueError('native runner did not finish both workspace commands and source after')
    own=[]
    own.append(command('dependencies-after-v2',['python3',str(OUT/'check_dependencies_v2.py'),'after']))
    own.append(command('rustc-version',['rustc','-Vv']))
    own.append(command('cargo-version',['cargo','-Vv']))
    worktree=worktree_observation()
    selected=final_selected_source()
    extras=registry_extras()
    configuration_hashes()
    executables=executable_identity_recheck()
    features=read('compiled-feature-subscope.json')
    more=[]
    for filename,name in [('dependencies-before-stage.json','dependencies-before'),
                          ('dependencies-before-v2-stage.json','dependencies-before-v2')]:
        value=read(filename)
        value['record_file']=filename
        value['name']=name
        value['expected_exit']=0
        value['expectation_met']=value['exit_code']==0
        more.append(value)
    initial=read('initial.json')['records']
    for value in initial:
        value['record_file']='initial.json'
        value['expected_exit']=0
        value['expectation_met']=value['exit_code']==0
    records=initial+index['records']+features['records']+more+own
    if len({r['name'] for r in records})!=len(records): raise ValueError('duplicate stage name')
    for row in records:
        for stream in ['stdout','stderr']:
            p=OUT/(row['name']+'.'+stream+'.log')
            if sha(p)!=row[stream+'_sha256']: raise ValueError('recorded log changed: '+str(p))
    tests={name:test_results(name) for name in ['v2-native-tests','chain-workspace-tests']}
    dependencies=read('resolved-dependencies-after.json')
    dep_comparison=read('resolved-dependencies-comparison.json')
    feature_check=read('v2-feature-check.json')
    fixed_build_complete=(features['all_expectations_met'] is True and
        set(feature_check['features'])=={'std','disable-dev-mode'} and
        all(next(r for r in records if r['name']==name)['expectation_met'] for name in
            ['v2-release-build','v2-fixed-receipt','v2-mutated-receipt',
             'v2-mutated-artifacts','v2-native-mutated-artifacts']))
    full_source_passed=all(next(r for r in records if r['name']==name)['expectation_met']
        for name in ['full-source-before','full-source-after'])
    summary={'schema':'TRNM-W1-NATIVE-7150-OBSERVATIONS1',
        'generated_utc':datetime.now(timezone.utc).isoformat(),'source_commit':HEAD,
        'native_job_id':'1a1b61ee33d-12894-27e','host_alias':'desktop',
        'repository':str(ROOT),'evidence_directory':str(OUT),
        'source_identity':{'selected':selected,'worktree_record_count':worktree['record_count'],
            'all_worktree_changes_are_deleted_evidence':worktree['all_reported_changes_are_deleted_evidence'],
            'full_tracked_identity_passed':full_source_passed,'original_strict_tool_results_retained':True},
        'recorded_commands':records,'additional_dependency_helper_attempts':more,
        'passing_command_expectations':[r['name'] for r in records if r['expectation_met']],
        'failed_command_expectations':[r['name'] for r in records if not r['expectation_met']],
        'all_recorded_command_expectations_met':all(r['expectation_met'] for r in records),
        'initial_dependency_helper_failure':{'record':'dependencies-before-stage.json','preserved':True,
            'reason':'The first helper assumed .cargo-checksum.json existed; the cache did not contain that file. The revised helper verified lock checksums against cached crate bytes and each archived file against extracted source.'},
        'tests':tests,'dependency_identity':{'package_count':dependencies['package_count'],
            'registry_source_files':sum(p.get('source_files_verified',0) for p in dependencies['packages'].values()),
            'all_supported_source_checks_pass':dependencies['all_supported_source_checks_pass'],
            'before_after':dep_comparison,'post_run_unarchived_files':extras['extra_file_count'],
            'all_unarchived_files_are_cache_markers':extras['all_extras_are_cargo_cache_markers']},
        'verifier_binary':read('v2-binary-identity.json'),
        'executable_and_probe_identity_after':executables,
        'v2_features':feature_check,
        'official_image_id':read('official-image-comparison.json'),
        'official_image_source_binding':read('official-image-source-binding.json'),
        'compiled_feature_subscope':{'status':'FIXED_V2_RELEASE_SUBSCOPE_COMPLETE' if fixed_build_complete else 'NOT_COMPLETE',
            'scope':'Frozen 7150 v2 release build and its accepted outer succinct verification profile only.',
            'evidence':'compiled-feature-subscope.json',
            'judgment':'Resolved risc0-zkvm features std + disable-dev-mode, default features disabled, the pinned release binary, native context excluding segment/Groth16/dev paths, fixed Poseidon2 succinct profile, and four explicit proof-environment refusals close this concrete build/profile observation. CLI --native is a separately labelled complete relation replay, not a proof fallback or consensus admission path.',
            'release_debug_symbols_are_not_dev_verification':True,
            'all_recursive_semantics_closed':False,'other_builds_or_production_supply_chain_qualified':False},
        'scope_boundaries':[
            'One fixed saved receipt is reverified; no fresh proof generation or independent proof trials are claimed.',
            'Native replay executes the complete fixed relation; timing repetitions do not create independent proof trials.',
            'Selected 2462 source/config/fixture byte identities are narrower than full tracked source cleanliness.',
            'The strict original source verifier fails because the clone retains missing historical evidence; it is not weakened or relabelled as a pass.',
            'Package archive matching and selected configuration hashes are not a hermetic build or production supply-chain attestation.',
            'No post-quantum soundness, lifetime-query bound, consensus admission, release authorization, or permitted-recursion completeness follows from these native observations.'
        ],
        'post_quantum_soundness_qualified':False,'unconditional_project_security_bits':None,
        'consensus_admission':False,'production_release_qualified':False}
    write('native-summary.json',summary)
    excluded={ARCHIVE,'manifest.json','package-result.json','official-image','release-context'}
    entries=[]
    excluded_files=[]
    for p in sorted(OUT.iterdir()):
        if p.name.startswith('.') or p.name in {ARCHIVE,'manifest.json','package-result.json'}: continue
        if p.is_dir():
            excluded_files.append({'path':p.name,'reason':'directory excluded, including Cargo target/cache output'})
            continue
        if p.name in excluded:
            excluded_files.append({'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p),'reason':'ELF payload omitted; identity retained'})
            continue
        if not stat.S_ISREG(p.lstat().st_mode): raise ValueError('unexpected nonregular evidence')
        entries.append({'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)})
    manifest={'schema':'TRNM-W1-NATIVE-EVIDENCE-MANIFEST1','source_commit':HEAD,
        'summary':'native-summary.json','entries':entries,'excluded':excluded_files,
        'payload_files':len(entries),'payload_bytes':sum(e['bytes'] for e in entries),
        'package_script_sha256':sha(Path(__file__)),
        'secret_environment_values_included':False,'cargo_target_included':False,
        'full_tracked_identity_claimed':False,'post_quantum_soundness_qualified':False}
    write('manifest.json',manifest)
    archive=OUT/ARCHIVE
    with archive.open('xb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
            with tarfile.open(mode='w',fileobj=zipped,format=tarfile.PAX_FORMAT) as tar:
                for name in ['manifest.json']+[e['path'] for e in entries]:
                    data=(OUT/name).read_bytes()
                    info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0
                    tar.addfile(info,io.BytesIO(data))
    with tarfile.open(archive,'r:gz') as tar:
        if tar.getnames()!=['manifest.json']+[e['path'] for e in entries]: raise ValueError('archive roster mismatch')
        for row in entries:
            data=tar.extractfile(row['path']).read()
            if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
                raise ValueError('archive member mismatch')
    result={'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
        'summary_sha256':sha(OUT/'native-summary.json'),'manifest_sha256':sha(OUT/'manifest.json'),
        'payload_files':len(entries),'failed_command_expectations':summary['failed_command_expectations'],
        'native_tests':{name:{key:value[key] for key in ['aggregate','reported_test_result_blocks',
            'named_failed_tests','named_ignored_tests','command_exit_code','timed_out']} for name,value in tests.items()},
        'selected_source_matches':selected,'dependency_comparison':dep_comparison}
    write('package-result.json',result)
    print(json.dumps(result),flush=True)


if __name__=='__main__': main()
