#!/usr/bin/env python3
"""Bounded Python checks, with exact source bytes and retained failure output."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/bb9b841c1d43/pq-task-renewal-v5')
OUT = Path('/workspace/scratch/bb9b841c1d43/pq-v5-evidence')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inventory():
    return {str(path.relative_to(ROOT)): digest(path)
            for prefix in ('scripts','trillionnium','config','formal/pon-nakamoto-v1','.github')
            for path in sorted((ROOT/prefix).rglob('*'))
            if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc'}

def save(path, value):
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

parser=argparse.ArgumentParser()
parser.add_argument('--stem',required=True)
parser.add_argument('--seconds',required=True,type=int)
parser.add_argument('command',nargs=argparse.REMAINDER)
args=parser.parse_args()
assert 1 <= args.seconds <= 1800
assert args.command and not (OUT/(args.stem+'.json')).exists()
command=args.command[1:] if args.command[0]=='--' else args.command
before=inventory()
start=time.monotonic_ns()
report={'command':command,'cwd':str(ROOT),'timeout_seconds':args.seconds,
        'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'source_sha256_before':before,'timed_out':False,
        'public_network_ready':False,'production_activation':False,
        'full_cargo_graph_qualified':False}
with (OUT/(args.stem+'.stdout.log')).open('wb') as out, (OUT/(args.stem+'.stderr.log')).open('wb') as err:
    child=subprocess.Popen(command,cwd=ROOT,stdout=out,stderr=err,start_new_session=True)
    report['pid']=child.pid
    save(OUT/(args.stem+'.started.json'),report)
    try:
        report['exit_code']=child.wait(timeout=args.seconds)
    except subprocess.TimeoutExpired:
        report['timed_out']=True
        os.killpg(child.pid,signal.SIGTERM)
        try: child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL)
            child.wait()
        report['process_exit_code']=child.returncode
        report['exit_code']=124
report['elapsed_ns']=time.monotonic_ns()-start
after=inventory()
report['source_sha256_after']=after
report['source_unchanged']=before==after
report['passed']=report['exit_code']==0 and not report['timed_out'] and report['source_unchanged']
for suffix in ('stdout.log','stderr.log'):
    path=OUT/(args.stem+'.'+suffix)
    report[suffix]={'path':path.name,'bytes':path.stat().st_size,'sha256':digest(path)}
save(OUT/(args.stem+'.json'),report)
print(json.dumps({key:report[key] for key in ('exit_code','elapsed_ns','timed_out','source_unchanged','passed')}),flush=True)
sys.exit(0 if report['passed'] else 1)
