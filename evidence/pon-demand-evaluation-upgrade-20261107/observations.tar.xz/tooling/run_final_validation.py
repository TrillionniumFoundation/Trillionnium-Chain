#!/usr/bin/env python3
"""Run required final gates without substituting a prior source receipt."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/525798dad3c2/Trillionnium-Chain')
BASE = ROOT.parent
RECORDER = BASE / 'record_validation.py'
CARGO = ['bash', str(BASE / 'cargo-task.sh')]
MANIFEST = ['--manifest-path', 'trillionnium/Cargo.toml']
PYTHON = ['env', 'PYTHONPATH=formal/pon-nakamoto-v1', 'python3', '-m', 'unittest', '-v']

READ_GATES = [
    ('new-references', PYTHON + ['test_demand_evidence', 'test_upgrade_policy']),
    ('retained-model-boundaries', PYTHON + [
        'test_reward_budget_oracle', 'test_model_evolution_oracle', 'test_model_task_windows_oracle',
        'test_work_utility', 'test_public_evaluation_lifecycle', 'test_evaluation',
        'test_evaluation_bundle', 'test_model_acceptance']),
    ('ci-contract', ['python3', 'scripts/ci/test_ci_contract.py']),
    ('source-integrity', ['env', 'PYTHONPATH=scripts/ci', 'python3', '-m', 'unittest', '-v',
        'test_ci_source_integrity', 'test_pq_research_integration', 'test_repository']),
    ('repository', ['python3', 'scripts/ci/check_repository.py']),
    ('pq-source-pins', ['python3', 'scripts/ci/check_pq_research_integration.py']),
    ('preflight', ['bash', 'scripts/project-preflight.sh']),
    ('patch-whitespace', ['git', 'diff', '--check', 'adebe0bd78e6e1bdb55a599179ffe2313997170e', 'HEAD']),
]
CARGO_GATES = [
    ('root-cargo-graph', CARGO + ['metadata', '--locked', '--offline'] + MANIFEST + ['--all-features', '--format-version', '1']),
    ('fuzz-cargo-graph', CARGO + ['metadata', '--locked', '--offline', '--manifest-path', 'tests/fuzz/Cargo.toml', '--format-version', '1']),
    ('m12', CARGO + ['test', '--locked', '--offline'] + MANIFEST + ['-p', 'trnm-service-settlement', '--all-targets', '--all-features']),
    ('native-no-gain', CARGO + ['test', '--locked', '--offline'] + MANIFEST + [
        '-p', 'trnm-pon-node', '--test', 'no_gain_fees', '--all-features', '--', '--nocapture', '--test-threads=1']),
    ('strict-clippy', CARGO + ['clippy', '--locked', '--offline'] + MANIFEST + ['--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings']),
    ('rustfmt', CARGO + ['fmt'] + MANIFEST + ['--all', '--', '--check']),
    ('toolchain', ['python3', str(BASE / 'observe_toolchain.py')]),
]


def gate(item):
    label, command = item
    invocation = ['python3', str(RECORDER), 'final-' + label, *command]
    result = subprocess.run(invocation, cwd=ROOT, capture_output=True, text=True)
    print(result.stdout, end='', flush=True)
    if result.stderr:
        print(result.stderr, end='', file=sys.stderr, flush=True)
    return {'label': 'final-' + label, 'exit_code': result.returncode,
            'recorder_stdout': result.stdout, 'recorder_stderr': result.stderr}


def cargo_group():
    return [gate(item) for item in CARGO_GATES]


with ThreadPoolExecutor(max_workers=4) as executor:
    futures = [executor.submit(cargo_group)] + [executor.submit(gate, item) for item in READ_GATES]
    results = []
    for future in as_completed(futures):
        item = future.result()
        results.extend(item if isinstance(item, list) else [item])
results.sort(key=lambda r: r['label'])
(BASE / 'validation/final-run-status.json').write_text(json.dumps(results, indent=2, sort_keys=True) + '\n')
raise SystemExit(0 if all(r['exit_code'] == 0 for r in results) else 1)
