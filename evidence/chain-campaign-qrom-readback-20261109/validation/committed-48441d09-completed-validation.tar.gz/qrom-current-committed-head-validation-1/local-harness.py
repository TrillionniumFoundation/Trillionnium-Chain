#!/usr/bin/env python3
"""Execute the local QROM head lane against a fixed, already-selected commit.

This is a local command harness, not an Actions emulator or hosted-run receipt.
Only executed subprocess return codes supply success outcomes to the final gate.
All reports and logs are written outside the repository.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

def digest(data):
    return hashlib.sha256(data).hexdigest()

def now():
    return datetime.now(timezone.utc).isoformat()

def write_json(path, data):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write('\n')

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo-root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--expected-head', required=True)
parser.add_argument('--expected-branch', required=True)
args = parser.parse_args()
root, out = args.repo_root.resolve(strict=True), args.out.absolute()
if out.exists() or root == out or root in out.parents:
    raise SystemExit('Output must be a fresh path outside the repository.')
environment = dict(os.environ)
environment['PYTHONDONTWRITEBYTECODE'] = '1'
records, steps, initial = [], {}, []

for label, argv, expected in (
    ('initial-head', ['git', 'rev-parse', 'HEAD'], args.expected_head + '\n'),
    ('initial-branch', ['git', 'symbolic-ref', '--short', 'HEAD'], args.expected_branch + '\n'),
    ('initial-clean-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], ''),
):
    start, tick = now(), time.monotonic()
    result = subprocess.run(argv, cwd=root, env=environment, capture_output=True, check=False)
    initial.append((label, argv, result, start, now(), time.monotonic() - tick))
    if result.returncode != 0 or result.stdout.decode() != expected:
        print(json.dumps({'result': 'PRECONDITION_FAILED', 'label': label,
            'exit_code': result.returncode, 'stdout': result.stdout.decode(errors='replace'),
            'stderr': result.stderr.decode(errors='replace')}), flush=True)
        raise SystemExit(1)

reservation = """import pathlib,sys
p=pathlib.Path(sys.argv[1])
p.mkdir()
(p/'SCOPE.txt').write_text('LOCAL committed-head QROM observations. No hosted Actions run is claimed. Current V2 mapping and real original V1 rejection are separate from fixed historical V1 positive replay. All cryptographic and production qualification flags remain false.\\n')
(p/'python-version.txt').write_text(sys.version+'\\n')
print('Reserved fresh local observation directory:',p)
"""
start, tick = now(), time.monotonic()
reserved = subprocess.run([sys.executable, '-c', reservation, str(out)], cwd=root,
    env=environment, capture_output=True, check=False)
if reserved.returncode != 0:
    sys.stdout.buffer.write(reserved.stdout)
    sys.stderr.buffer.write(reserved.stderr)
    raise SystemExit(reserved.returncode)

def retain(label, argv, result, start, ended, duration, stage=False):
    stdout, stderr = out/(label+'.stdout.log'), out/(label+'.stderr.log')
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    record = {'label': label, 'argv': argv, 'cwd': str(root),
        'started_utc': start, 'ended_utc': ended, 'elapsed_seconds': duration,
        'exit_code': result.returncode,
        'stdout': {'path': stdout.name, 'bytes': len(result.stdout), 'sha256': digest(result.stdout)},
        'stderr': {'path': stderr.name, 'bytes': len(result.stderr), 'sha256': digest(result.stderr)},
        'execution_environment': 'local', 'hosted_actions_step': False}
    records.append(record)
    write_json(out/(label+'.receipt.json'), record)
    if stage:
        outcome = 'success' if result.returncode == 0 else 'failure'
        steps[label] = {'outcome': outcome, 'conclusion': outcome}
    print(json.dumps({'label': label, 'exit_code': result.returncode,
        'elapsed_seconds': round(duration, 3)}), flush=True)
    return result.returncode == 0

retain('observations', [sys.executable, '-c', reservation, str(out)], reserved,
    start, now(), time.monotonic()-tick, stage=True)
for item in initial:
    retain(*item)

def execute(label, argv, dependencies=(), stage=True, extra_environment=None):
    failed = [name for name in dependencies if steps.get(name, {}).get('outcome') != 'success']
    if failed:
        steps[label] = {'outcome': 'skipped', 'conclusion': 'skipped'}
        record = {'label': label, 'executed': False, 'reason': 'dependency not successful',
            'dependencies': failed, 'execution_environment': 'local', 'hosted_actions_step': False}
        write_json(out/(label+'.receipt.json'), record)
        records.append(record)
        return False
    local_env = dict(environment)
    if extra_environment:
        local_env.update(extra_environment)
    start, tick = now(), time.monotonic()
    result = subprocess.run(argv, cwd=root, env=local_env, capture_output=True, check=False)
    return retain(label, argv, result, start, now(), time.monotonic()-tick, stage=stage)

execute('checkout', ['git', 'checkout', args.expected_branch], ('observations',))
source = [sys.executable, 'scripts/ci/verify_ci_source.py',
    '--kind', 'head', '--expected-head', args.expected_head]
execute('source_before', source+['--output', str(out/'source-before.json')],
    ('observations','checkout'))
execute('preflight', ['bash', 'scripts/project-preflight.sh', '--audit'], ('source_before',))
runner = [sys.executable, 'scripts/ci/w1_qrom_current_ci.py']
execute('named_tests', runner+['named', '--repo-root', str(root), '--out', str(out)], ('preflight',))
execute('historical_drift', runner+['drift', '--repo-root', str(root), '--out', str(out)], ('preflight',))
execute('implementation', [sys.executable, 'scripts/w1_qrom_current_implementation_audit.py',
    '--repo-root', str(root), '--output', str(out/'implementation.json')], ('preflight',))
execute('source_after', source+['--output', str(out/'source-after.json')], ('source_before',))
write_json(out/'local-step-results.json', steps)
verified = execute('verify', runner+['verify', '--repo-root', str(root), '--out', str(out),
    '--kind', 'head', '--expected-source', args.expected_head, '--expected-head', args.expected_head],
    stage=False, extra_environment={'W1_QROM_CURRENT_STEP_RESULTS': json.dumps(steps, sort_keys=True)})
clean = execute('final-clean-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], stage=False)
same_head = execute('final-head', ['git', 'rev-parse', 'HEAD'], stage=False)
same_branch = execute('final-branch', ['git', 'symbolic-ref', '--short', 'HEAD'], stage=False)
clean = clean and (out/'final-clean-status.stdout.log').read_bytes() == b''
same_head = same_head and (out/'final-head.stdout.log').read_text() == args.expected_head+'\n'
same_branch = same_branch and (out/'final-branch.stdout.log').read_text() == args.expected_branch+'\n'
write_json(out/'local-command-records.json', {'schema': 'TRNM-QROM-LOCAL-COMMAND-RECORDS1',
    'execution_environment': 'local', 'hosted_workflow_passed': False, 'records': records})
status_path = out/'current-ci-status.json'
status = json.loads(status_path.read_text()) if status_path.exists() else {}
passed = verified and clean and same_head and same_branch and status.get('all_required_current_observations_passed') is True
receipt = {'schema': 'TRNM-QROM-LOCAL-COMMITTED-HEAD-VALIDATION1',
    'execution_environment': 'local', 'hosted_workflow_passed': False,
    'expected_head': args.expected_head, 'expected_branch': args.expected_branch,
    'local_all_required_observations_passed': passed, 'full_committed_source_verified': passed,
    'head_unchanged': same_head, 'branch_unchanged': same_branch, 'git_status_clean': clean,
    'qualification': status.get('qualification'), 'gate_status': 'current-ci-status.json',
    'command_receipts': 'local-command-records.json',
    'step_result_origin': 'Each success is derived from the recorded exit code of an executed local subprocess; no Actions checkout or hosted run is asserted.'}
write_json(out/'LOCAL_VALIDATION.json', receipt)
print(json.dumps(receipt, indent=2, sort_keys=True), flush=True)
raise SystemExit(0 if passed else 1)

