#!/usr/bin/env python3
"""Link the actual upstream example to already locked Cargo-built native rlibs.

Supplementary native interoperability only; no new full-workspace Cargo gate.
All outputs are confined to the given new evidence directory.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
from independent_check import ROOT
from verify_research_sources import blob

def run(rustc,deps,native_source,fixture,out):
    out.mkdir()
    expected=json.loads(fixture.with_suffix(fixture.suffix+'.json').read_text())
    manifest=json.loads((ROOT/'parallel-source-manifest.json').read_text())
    names=['trillionnium/crates/trnm-crypto-primitives/examples/pon_w1_complete_relation.rs',
           'trillionnium/crates/trnm-crypto-primitives/src/pon_work/full_relation.rs']
    sources=[]
    for name in names:
        source=native_source/name
        sha=next(x['sha']for x in manifest['files']if x['path']==name)
        if blob(source.read_bytes())!=sha:raise ValueError('NATIVE_SOURCE_MISMATCH '+name)
        sources.append(dict(path=str(source),git_blob=sha,sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
    binary=out/'pon-w1-native-interop'
    command=[str(rustc),'--edition=2021','--crate-name','pon_w1_native_interop',str(native_source/names[0]),'-L','dependency='+str(deps),'-o',str(binary)]
    libraries=[]
    for name in ['anyhow','trnm_crypto_primitives','trnm_protocol','hex']:
        choices=list(deps.glob('lib'+name+'-*.rlib'))
        if len(choices)!=1:raise ValueError('AMBIGUOUS_DEPENDENCY '+name)
        lib=choices[0];command+=['--extern',name+'='+str(lib)]
        libraries.append(dict(path=str(lib),sha256=hashlib.sha256(lib.read_bytes()).hexdigest()))
    result=dict(schema='trnm-native-pwg1-interop-v1',scope='original upstream example linked to already locked-Cargo-built native libraries; supplemental interoperability',sources=sources,libraries=libraries,
                input_sha256=hashlib.sha256(fixture.read_bytes()).hexdigest(),compile_exit=None,execution_exit=None,
                exact_journal_match=False,exact_block_id_match=False,succinct_proof=False,full_workspace_gate=False)
    compiled=subprocess.run(command,capture_output=True,text=True)
    result['compile_exit']=compiled.returncode;(out/'compile.log').write_text(compiled.stdout+compiled.stderr)
    if compiled.returncode==0:
        result['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
        executed=subprocess.run([str(binary),'execute',str(fixture)],capture_output=True,text=True)
        result['execution_exit']=executed.returncode;(out/'execute.log').write_text(executed.stdout+executed.stderr)
        if executed.returncode==0:
            observed=json.loads(executed.stdout)
            result['native_observation']=observed
            result['exact_journal_match']=observed['journal_hex']==expected['expected_native_journal_hex']
            result['exact_block_id_match']=observed['block_id']==expected['expected_block_id']
    result['result']='PASS'if result['compile_exit']==result['execution_exit']==0 and result['exact_journal_match']and result['exact_block_id_match']else 'FAIL'
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ['rustc','deps','native_source','fixture','out']:p.add_argument(name,type=Path)
    a=p.parse_args();result=run(a.rustc,a.deps,a.native_source,a.fixture,a.out);print(json.dumps(result,indent=2));sys.exit(0 if result['result']=='PASS'else 1)
