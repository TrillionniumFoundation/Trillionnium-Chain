#!/usr/bin/env python3
"""Mutate actual F3 retained logs; no synthetic replacement execution receipts."""
from pathlib import Path
import unittest

import verify_joint_daa_profile_rosters as subject

HERE = Path(__file__).resolve().parent
SOURCE = (HERE / "test_pon_joint_daa_reader.py").read_bytes()
PNH = (HERE / "joint-daa-reader-controls-pnh1-authenticated.log").read_bytes()
PGH = (HERE / "joint-daa-reader-controls-pgh2-growth.log").read_bytes()


class ExactOriginalProfileControls(unittest.TestCase):
    def valid(self, raw, backend="pnh1-authenticated", code=0, source=SOURCE):
        return subject.verify_frame(raw, backend, code, source)

    def reject(self, raw, backend="pnh1-authenticated", code=0, source=SOURCE):
        with self.assertRaises(ValueError):
            self.valid(raw, backend, code, source)

    def test_actual_both_complete_rosters_retain_original_scope(self):
        pnh = self.valid(PNH)
        pgh = self.valid(PGH, "pgh2-growth")
        self.assertEqual((pnh["executed_ok"], pgh["executed_ok"]), (21, 22))
        self.assertEqual(pnh["profile_not_applicable"], [subject.GROWTH_WITNESS])
        self.assertEqual(pgh["profile_not_applicable"], [])
        self.assertEqual(pgh["outcomes"][subject.GROWTH_WITNESS], "ok")

    def test_another_skip_cannot_replace_the_original_named_skip(self):
        witness = subject.GROWTH_WITNESS.encode()
        other = subject.ROSTER[0].encode()
        self.reject(PNH.replace(witness, b"temporary").replace(other, witness).replace(b"temporary", other))

    def test_pgh2_must_execute_the_witness_test(self):
        self.reject(PNH, "pgh2-growth")
        self.reject(PGH, "pnh1-authenticated")

    def test_missing_duplicate_or_unknown_tests_are_refused(self):
        lines = PNH.splitlines(keepends=True)
        self.reject(b"".join(lines[1:]))
        self.reject(lines[0]+PNH)
        self.reject(PNH.replace(lines[1], lines[0]))
        self.reject(PNH.replace(subject.ROSTER[0].encode(), b"test_unreviewed"))

    def test_display_and_fully_qualified_identity_must_match(self):
        self.reject(PNH.replace(subject.ROSTER[0].encode(), subject.ROSTER[1].encode(), 1))
        self.reject(PNH.replace(b"__main__.RetainedJointDaaCounterexamples", b"__main__.Other", 1))
        self.reject(PNH, "pnh1")

    def test_fake_ok_and_modified_count_or_footer_do_not_pass(self):
        self.reject(PNH+b"OK\n")
        self.reject(b"OK\n"+PNH)
        self.reject(PNH.replace(b"Ran 22 tests", b"Ran 21 tests"))
        self.reject(PNH.replace(b"OK (skipped=1)", b"OK"))
        self.reject(PGH.replace(b"OK\n", b"OK (skipped=1)\n"), "pgh2-growth")

    def test_skip_reason_and_all_other_statuses_remain_exact(self):
        self.reject(PNH.replace(subject.SKIP_REASON.encode(), b"new exception"))
        for status in (b"FAIL", b"ERROR", b"expected failure", b"skipped 'unapproved'"):
            self.reject(PNH.replace(b"... ok", b"... "+status, 1))

    def test_actual_test_source_drift_is_refused(self):
        self.reject(PNH, source=SOURCE+b"\n")
        self.reject(PNH, source=SOURCE.replace(b"self.skipTest", b"self.assertTrue", 1))

    def test_failed_or_boolean_process_exit_cannot_borrow_good_log(self):
        for code in (1, 101, -9, False, None):
            self.reject(PNH, code=code)


if __name__ == "__main__":
    unittest.main(verbosity=2)
