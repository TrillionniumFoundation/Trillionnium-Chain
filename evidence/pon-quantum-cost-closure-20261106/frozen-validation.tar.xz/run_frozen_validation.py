"""Record one bounded validation group against an exact immutable source tree."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--head', required=True)
    parser.add_argument('--group', choices=('quantum', 'repository', 'rust'), required=True)
    parser.add_argument('--validation', type=Path, required=True)
    parser.add_argument('--cargo-home', type=Path, required=True)
    parser.add_argument('--cargo-target', type=Path, required=True)
    parser.add_argument('--toolchain', type=Path, required=True)
    args = parser.parse_args()
    assert re.fullmatch('[0-9a-f]{40}', args.head)
    repo, validation = args.repo.resolve(), args.validation.resolve()
    out = validation / ('frozen-' + args.group)
    out.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE='1', CARGO_HOME=str(args.cargo_home.resolve()),
               CARGO_TARGET_DIR=str(args.cargo_target.resolve()), CARGO_NET_OFFLINE='true',
               CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
               CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0',
               RUSTC=str(args.toolchain / 'rustc'), RUSTDOC=str(args.toolchain / 'rustdoc'))
    env['PATH'] = str(args.toolchain) + os.pathsep + env['PATH']
    python = sys.executable
    formal = repo / 'formal/pon-nakamoto-v1'
    commands = {
        'quantum': [
            ('quantum-retained-tests', [python, '-B', '-m', 'unittest', '-v',
             'test_quantum_oracle_resources', 'test_quantum_network_sim',
             'test_quantum_candidate_check_clock', 'test_quantum_adversarial_search',
             'test_quantum_resource_clock', 'test_w1_quantum_oracle',
             'test_w1_marked_domain', 'test_w1_preprocessing_reuse',
             'test_w1_quantum_restricted_oracle', 'test_fast_daa_reference_component'], formal),
            ('network-independent', [python, '-B', str(validation / 'network-timeout/independent_controls.py'), '--repo', str(repo)], repo),
            ('network-timeout-replay', [python, '-B', str(validation / 'network-timeout/reproduce_timeout.py'), '--repo', str(repo)], repo),
            ('physical-count-controls', [python, '-B', str(validation / 'physical-cost/control_physical_counts.py'), '--repo', str(repo)], repo),
            ('physical-width-controls', [python, '-B', str(validation / 'physical-cost/control_width_depth.py'), '--repo', str(repo)], repo),
            ('literal-32-controls', [python, '-B', str(validation / 'literal-budget/replay_literal_accounting_controls.py'), '--repo', str(repo)], repo),
            ('preprocessing-eight-controls', [python, '-B', str(validation / 'literal-budget/replay_preprocessing_controls.py'), '--repo', str(repo)], repo),
        ],
        'repository': [
            ('source-integrity-negative-tests', [python, '-B', '-m', 'unittest', 'discover', '-s', 'scripts/ci', '-p', 'test_ci_source_integrity.py', '-v'], repo),
            ('ci-contract-tests', [python, '-B', '-m', 'unittest', 'discover', '-s', 'scripts/ci', '-p', 'test_ci_contract.py', '-v'], repo),
            ('pq-integration-tests', [python, '-B', '-m', 'unittest', 'discover', '-s', 'scripts/ci', '-p', 'test_pq_research_integration.py', '-v'], repo),
            ('pq-integration-check', [python, '-B', 'scripts/ci/check_pq_research_integration.py'], repo),
            ('inventory-check', [python, '-B', 'scripts/refresh_distributed_source_inventory.py', '--check'], repo),
            ('repository-markdown-links-check', [python, '-B', 'scripts/ci/check_repository.py'], repo),
            ('diff-check', ['git', 'diff', '--check', args.head + '^', args.head], repo),
        ],
        'rust': [
            ('rust-version', ['rustc', '-vV'], repo),
            ('cargo-version', ['cargo', '-V'], repo),
            ('clippy-version', ['cargo', 'clippy', '--version'], repo),
            ('openssl-version', ['/usr/bin/openssl', 'version'], repo),
            ('openssl-pkg-config', ['pkg-config', '--modversion', 'openssl'], repo),
            ('cargo-fmt', ['cargo', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check'], repo),
            ('cargo-metadata-main', ['cargo', 'metadata', '--offline', '--locked', '--manifest-path', 'trillionnium/Cargo.toml', '--all-features', '--format-version', '1'], repo),
            ('cargo-metadata-fuzz', ['cargo', 'metadata', '--offline', '--locked', '--manifest-path', 'tests/fuzz/Cargo.toml', '--all-features', '--format-version', '1'], repo),
            ('cargo-clippy', ['cargo', 'clippy', '--offline', '--locked', '--manifest-path', 'trillionnium/Cargo.toml', '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings'], repo),
        ],
    }[args.group]
    source_command = [python, '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', args.head]
    records = []
    def run(label, argv, cwd):
        started = time.time()
        file = out / (label + '.log')
        with file.open('wb') as stream:
            result = subprocess.run(argv, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT)
        content = file.read_bytes()
        record = {'label': label, 'argv': argv, 'cwd': str(cwd), 'exit_code': result.returncode,
                  'wall_seconds': time.time() - started, 'log_file': file.name,
                  'log_bytes': len(content), 'log_sha256': hashlib.sha256(content).hexdigest()}
        records.append(record)
        (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
        print(json.dumps({key: record[key] for key in ('label', 'exit_code', 'wall_seconds')}), flush=True)
        return record
    assert run('preflight', ['bash', 'scripts/project-preflight.sh'], repo)['exit_code'] == 0
    assert run('source-before', source_command + ['--output', str(out / 'source-before.json')], repo)['exit_code'] == 0
    for command in commands:
        run(*command)
    run('source-after', source_command + ['--output', str(out / 'source-after.json')], repo)
    keys = ('CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_NET_OFFLINE',
            'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG',
            'RUSTC', 'RUSTDOC', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER',
            'RUSTC_WORKSPACE_WRAPPER', 'OPENSSL_DIR', 'OPENSSL_STATIC')
    before = json.loads((out / 'source-before.json').read_text())
    after_path = out / 'source-after.json'
    after = json.loads(after_path.read_text()) if after_path.exists() else None
    success = all(row['exit_code'] == 0 for row in records) and before == after
    summary = {'schema': 'trnm-quantum-cost-closure-frozen-validation-v1',
               'group': args.group, 'result': 'PASS' if success else 'FAIL',
               'tested_head': args.head, 'tested_tree': before['tested_tree'],
               'tracked_source_unchanged': before == after,
               'commands': records, 'environment': {key: env.get(key) for key in keys},
               'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'lockfiles': {name: hashlib.sha256((repo / name).read_bytes()).hexdigest()
                             for name in ('trillionnium/Cargo.lock', 'tests/fuzz/Cargo.lock')},
               'claims': {'native_runtime_qualification': False, 'ci_provider_parity': False,
                          'quantum_hardware_executed': False, 'same_budget_advantage_proved': False,
                          'whole_chain_quantum_security': False, 'activation_allowed': False}}
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps({'group': args.group, 'result': summary['result'], 'tested_head': args.head}), flush=True)
    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()
