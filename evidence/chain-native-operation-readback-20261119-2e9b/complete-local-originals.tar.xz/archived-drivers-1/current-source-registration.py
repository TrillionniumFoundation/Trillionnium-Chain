from pathlib import Path
import json,subprocess,hashlib,gzip,textwrap,re,traceback,time,resource,os
base=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b');src=base/'source';e=base/'current-source-registration-1';e.mkdir(exist_ok=False)
res={'schema':'chain-operation-current-source-registration-v1','base':'f088f1d4f8a50aff0c5ecd465480b2aeee6e5e94','stages':[],'historical_qualification_changed':False,'f0_qualified':False,'full_physical_cost_closed':False}
def save():(e/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def put(rel,b):
 p=src/rel;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
def replace_one(s,a,b):
 assert s.count(a)==1,a
 return s.replace(a,b)
def stage(n,cmd):
 t=time.monotonic();r0=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (e/(n+'.stdout')).open('xb') as out,(e/(n+'.stderr')).open('xb') as err:
  r=subprocess.run(cmd,cwd=src,stdout=out,stderr=err)
 r1=resource.getrusage(resource.RUSAGE_CHILDREN);res['stages'].append({'name':n,'command':cmd,'exit_code':r.returncode,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':r1.ru_utime-r0.ru_utime,'child_system_cpu_seconds':r1.ru_stime-r0.ru_stime});save();print(json.dumps(res['stages'][-1]),flush=True);return r.returncode
try:
 prev=json.loads((base/'native-validation-4/RESULT.json').read_text())
 for k in ['source_unchanged','native_authenticated_passed','detached_admission_passed','history_import_passed','clippy_passed','native_registry_passed']:assert prev[k],k
 assert stage('preflight',['bash','scripts/project-preflight.sh'])==0
 res['broader_offline_metadata_failure_retained']=next(r for r in prev['stages'] if r['name']=='locked-linux-graph')
 res['original_locked_linux_graph_passed']=stage('original-locked-linux-graph',['/home/qq/.cargo/bin/cargo','+1.95.0','tree','--offline','--locked','--manifest-path','trillionnium/Cargo.toml','--target','x86_64-unknown-linux-gnu','-p','trnm-pon-node','--edges','normal,build,dev','--prefix','depth'])==0
 assert res['original_locked_linux_graph_passed']
 before=subprocess.check_output(['git','diff','--binary'],cwd=src);assert sha(before)==prev['source_patch_sha256']
 payload=json.loads((base/'completed-graph-ci-roster-payload-1.json').read_text())
 for row in payload['files']:assert (src/row['path']).read_text()==row['old'],row['path']
 native=(base/'native-validation-4/native-authenticated.stdout').read_bytes()
 registry=(base/'native-validation-4/native-registry.stdout').read_bytes()
 names=sorted(re.findall(r'^(store::native_authenticated::[\w:]+): test$',registry.decode(),re.M))
 executed=re.findall(r'^test (store::native_authenticated::[\w:]+) \.\.\. ok$',native.decode(),re.M)
 assert names==payload['expected_roster'] and sorted(executed)==names and len(executed)==127
 summaries=[l for l in native.decode().splitlines() if l.startswith('test result:')]
 assert len(summaries)==1 and summaries[0].startswith('test result: ok. 127 passed; 0 failed; 0 ignored;')
 corpus_path=src/'config/pon/pq-cross-branch-corpus-v1.json';corpus=json.loads(corpus_path.read_text())
 tree={}
 for row in subprocess.check_output(['git','ls-tree','-r','-z','HEAD'],cwd=src).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);mode,kind,h=meta.split();tree[path.decode()]=(mode.decode(),kind.decode(),h.decode())
 fixtures={p:h for p,h in corpus['pinned_blobs'].items() if not(src/p).exists()}
 for parent in ['evidence/authenticated-suite-count-20261106/','evidence/workspace-semantic-registry-20261106/']:
  for p,(mode,kind,h) in tree.items():
   if p.startswith(parent) and p.endswith('.gz') and not(src/p).exists():fixtures[p]=h
 restored=[]
 for p,h in sorted(fixtures.items()):
  assert tree[p][1]=='blob' and tree[p][2]==h and tree[p][0] in ['100644','100755'],p
  raw=subprocess.check_output(['git','cat-file','blob',h],cwd=src);assert blob(raw)==h
  put(p,raw)
  if tree[p][0]=='100755':(src/p).chmod(0o755)
  restored.append({'path':p,'bytes':len(raw),'git_blob':h,'sha256':sha(raw)})
 (e/'restored-historical-fixture-index.json').write_text(json.dumps(restored,indent=2)+'\n')
 assert subprocess.check_output(['git','diff','--binary'],cwd=src)==before
 res['historical_files_materialized_exactly']=len(restored);res['historical_bytes_materialized']=sum(r['bytes'] for r in restored)
 roster=json.dumps({'schema':'trnm-authenticated-current-roster-v1','tests':names},indent=2).encode()+b'\n'
 wf=next(row['old'] for row in payload['files'] if row['path'].endswith('pon-original-workspace-large-state-cpu.yml'))
 historical_guard=textwrap.dedent(wf.split("<<'PYREGISTRY'\n",1)[1].split('        PYREGISTRY\n',1)[0])
 substitutions={'__ROSTER_SHA256__':sha(roster),'__NATIVE_SHA256__':sha(native),'__REGISTRY_SHA256__':sha(registry),'__HISTORICAL_REGISTRY_GUARD_SHA256__':sha(historical_guard.encode())}
 for row in payload['files']:
  text=row['text']
  for a,b in substitutions.items():text=text.replace(a,b)
  assert not re.search(r'__[A-Z_]*SHA256__',text)
  if row['path'].endswith('pon-recent-batch-acceptance.yml'):
   actual=blob((src/'trillionnium/crates/trnm-pon-node/src/store/native_authenticated.rs').read_bytes())
   text=replace_one(text,'4a17366fee9591e3229b44617064e2d13af2df33',actual)
  (src/row['path']).write_text(text)
 roster_rel='config/pon/authenticated-current-roster-v1.json';put(roster_rel,roster)
 controls='evidence/chain-native-operation-readback-20261119-2e9b/controls'
 put(controls+'/native-authenticated.log.gz',gzip.compress(native,mtime=0))
 put(controls+'/node-registry.log.gz',gzip.compress(registry,mtime=0))
 provenance={'schema':'chain-operation-native-roster-observation-v1','source_base':res['base'],'source_patch_sha256':prev['source_patch_sha256'],'source_unchanged':True,'native_execution_stage':next(r for r in prev['stages'] if r['name']=='native-authenticated'),'registry_stage':next(r for r in prev['stages'] if r['name']=='native-registry'),'native_log_sha256':sha(native),'registry_log_sha256':sha(registry),'roster_sha256':sha(roster),'actual_native_tests':127,'actual_post_write_tests':49,'native_registry_scope':'ai395 default-feature release node library, not original all-feature workspace acceptance','historical_m06_registry_is_historical':True,'four_original_97_test_logs_and_25_post_write_roster_unchanged':True,'f0_qualified':False,'physical_cost_complete':False}
 put(controls+'/PROVENANCE.json',json.dumps(provenance,indent=2).encode()+b'\n')
 put(controls+'/README.md',b'# Current native roster observation\n\nThe 127-name execution and current node libtest registry are actual ai395 release observations of the unchanged production patch named in PROVENANCE.json. The retained-delta cost observation used its original required create-new output path. These are default-feature node-library observations, not complete current all-feature workspace or four-platform acceptance.\n\nThe original four 97-control logs and original 25-name post-write registry remain byte-pinned historical fixtures. They continue to pass their original guards and fail the current 127/49 guards. Synthetic parser mutation inputs in the Python tests are explicitly labelled and are not execution evidence. The original F0 six 30-second and six scheduled four-second targets, 512-attempt assertion and prepaid credits are unchanged. Overall qualification remains open.\n')
 p=src/'config/pon/applicability-v1.json';text=p.read_text();old='resource_revision_r21_rejects_signed_old_cookies_and_preserves_control_output_reserve';new=old.replace('_r21_','_r22_')
 assert ('fn '+new+'(') in (src/'trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs').read_text()
 p.write_text(replace_one(text,old,new))
 p=src/'config/pon/pq128-source-correspondence-current-v2.json';mapping=json.loads(p.read_text());old_mapping=json.loads(p.read_text())
 current=mapping['current_source_files_sha256'];changed=[]
 for name,old in current.items():
  actual=sha((src/name).read_bytes())
  if actual!=old:changed.append(name)
  current[name]=actual
 assert set(changed)<= {'trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs','trillionnium/crates/trnm-pon-node/src/store.rs'}
 snapshot=sha(json.dumps(current,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode())
 mapping['current_source_snapshot_sha256']=snapshot
 raw=json.dumps(mapping,indent=2).encode()+b'\n';p.write_bytes(raw)
 script=src/'scripts/ci/pq_lifetime_current_v2.py';text=script.read_text()
 text=replace_one(text,'EXPECTED_MAP_SHA256 = "f7ffe7a99de743bc79d4c5af3db9571c791f8a58b404786bec1880a024982c13"','EXPECTED_MAP_SHA256 = "'+sha(raw)+'"')
 text=replace_one(text,'EXPECTED_CURRENT_FILES_SHA256 = "3c4a887761692936780bd81869e91f65cee782aabf83e14907de4e076d4fed03"','EXPECTED_CURRENT_FILES_SHA256 = "'+snapshot+'"');script.write_text(text)
 assert mapping['frozen_model']==old_mapping['frozen_model'] and mapping['qualification']==old_mapping['qualification'] and mapping['status']==old_mapping['status']
 res['pq_changed_current_paths']=changed
 p=src/'config/pon/w1-lifetime-current-source-v2.json';contract=json.loads(p.read_text());old_contract=json.loads(p.read_text());changed=[]
 for row in contract['sources']:
  raw=(src/row['path']).read_bytes()
  if len(raw)!=row['bytes'] or sha(raw)!=row['current_sha256']:
   changed.append({'path':row['path'],'previous_bytes':row['bytes'],'current_bytes':len(raw),'previous_sha256':row['current_sha256'],'current_sha256':sha(raw)})
   row['bytes']=len(raw);row['current_sha256']=sha(raw)
 assert [r['path'] for r in changed]==['trillionnium/crates/trnm-pon-node/src/store.rs']
 for k in old_contract:
  if k!='sources':assert contract[k]==old_contract[k],k
 for a,b in zip(contract['sources'],old_contract['sources']):assert a['historical_sha256']==b['historical_sha256']
 raw=json.dumps(contract,indent=2).encode()+b'\n';p.write_bytes(raw)
 script=src/'scripts/w1_lifetime_current_observation.py';text=script.read_text()
 text=replace_one(text,'CONTRACT_SHA256 = "ea0f8e2a0c82a01c0601e627cf64d8df34682457904fb00a65639138a0be46fa"','CONTRACT_SHA256 = "'+sha(raw)+'"');script.write_text(text)
 res['w1_changed_current_rows']=changed
 plan=src/'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
 plan.write_text(plan.read_text()+"""
## 2026-11-19 continuation: complete graph results remain inside their original writer

The exact source 333fe8cd89f0ec855e7b856e99e40f48f56c2137 failed original F0
44441548029: one of six confirmations in the original 30-second phases, zero
of six scheduled four-second targets, and no strict numeric depletion witness.
Complete negative evidence, all 22 automatic-CI workflow identities plus F0,
38 failed-job logs at the recorded snapshot and overlapping/unknown costs are
retained at f088f1d4f8a50aff0c5ecd465480b2aeee6e5e94. The seven preparation
controls do not qualify that business result.

The measured repeated original-operation path now remembers a completely
verified different Root only in one of the same four nominated record slots.
The result carries its actual Record.id, full Root, original frontier source
and an opaque identity minted by that exact PostWriteReadback owner. Retained
identity allocations prevent reuse after owner destruction, including identical
visible SQL/Record/Root/source tuples after transaction ABA. No derived result
becomes a frontier or crosses the sole passive metadata INSERT. Current State,
Record, Delta, schema and transaction fences remain, including no-row writes,
cancel/deadline callbacks and the final original callback. Every actual visited
physical node retains its original Host checkpoint.

A real signed-transfer fixture exposed the original repeated path: full graph
140 callbacks, first frontier use 44, repeat 44. The same deterministic fixture
with this change observes 140/44/5. Two real old-result replay controls reject
both another scope in the same transaction and a new transaction after COMMIT.
The original 512-attempt CPU assertion and all F0 credits/windows/bounds remain
unchanged. This operation-local observation does not establish F0 success.

The final local default-feature release library executed all 127 authenticated
controls, including 49 post-write controls and the original explicit retained
delta cost observation. Detached admission, History import, strict all-target
Clippy and the locked Linux graph were checked at the unchanged production
patch. The broader offline workspace metadata query still refuses the unavailable
socket2 0.6.1 cache entry; the original targeted Linux dependency-graph check
remains a separate result. The preceding E0505 compiler failure and a full 126-pass/one-fail run
whose explicit create-new cost-output environment was missing remain retained
with their actual costs. Current 127/49 source and native registry guards are
separate from four unchanged historical 97/25 logs; those logs continue to
refuse current qualification.

Refresh only current source correspondence where its bytes have changed:
the signed r22 callable, fixed 21-path PQ map, fixed 20-path W1 map's exact
store.rs byte identity, current authenticated roster and derived literal blob
pins. Frozen historical source pins, path scopes, HOLD/false/null qualification
and historical evidence keep their prior meaning. Freeze this candidate and run
the unchanged original F0 once. Business progress and complete physical cost
remain open until independently observed. This is still the sole development plan.
""")
 new_pins=[roster_rel,controls+'/native-authenticated.log.gz',controls+'/node-registry.log.gz']
 pin_changes=[]
 for name,old in list(corpus['pinned_blobs'].items()):
  p=src/name
  actual=blob(p.read_bytes())
  if actual!=old:
   pin_changes.append({'path':name,'previous':old,'current':actual});corpus['pinned_blobs'][name]=actual
 for name in new_pins:
  assert name not in corpus['pinned_blobs'];corpus['pinned_blobs'][name]=blob((src/name).read_bytes())
  assert name not in corpus['required_paths'];corpus['required_paths'].append(name)
 corpus['pinned_blobs']=dict(sorted(corpus['pinned_blobs'].items()))
 corpus['required_paths']=sorted(corpus['required_paths'])
 corpus_path.write_text(json.dumps(corpus,indent=2,sort_keys=True)+'\n')
 res['existing_source_pin_changes']=pin_changes;res['new_source_pins']=new_pins;res['pin_count']=len(corpus['pinned_blobs'])
 res['substitutions']=substitutions;res['production_patch_sha256']=sha(subprocess.check_output(['git','diff','--binary','--','trillionnium'],cwd=src))
 # Scope registration cannot change any compiled Rust source or its native tests.
 original_production=subprocess.check_output(['git','diff','--binary','--','trillionnium'],cwd=src)
 assert original_production==before
 diff=subprocess.check_output(['git','diff','--binary'],cwd=src);(e/'candidate.patch').write_bytes(diff);res['tracked_patch_sha256']=sha(diff)
 save();print(json.dumps(res),flush=True)
except BaseException as exc:
 res['error']=repr(exc);(e/'driver-error.log').write_text(traceback.format_exc());save();print(json.dumps(res),flush=True)
 raise
