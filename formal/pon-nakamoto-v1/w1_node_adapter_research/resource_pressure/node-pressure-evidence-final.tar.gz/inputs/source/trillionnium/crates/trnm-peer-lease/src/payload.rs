//! Candidate-only durable replay fencing for authenticated consensus payloads.
//!
//! The peer-lease journal fences *which session generation* owns a directed
//! edge.  It intentionally does not remember the payload sequence that was
//! consumed by that edge.  This module supplies that missing, narrow seam: a
//! node-owned append-only journal records the authenticated frame identity
//! (`peer/session/generation/sequence`) and a digest of the canonical frame
//! payload.  A receiver must durably admit a frame before exposing it to a
//! consensus consumer.
//!
//! This is deliberately not a network socket, a signer, a Core/ledger rules
//! authority, or an activation path.  The journal can be rolled back together
//! with its sidecar by an owner with filesystem authority; the external peer
//! lease remains the independent generation fence for that threat model.

use std::{
    collections::{BTreeMap, BTreeSet},
    fmt,
    fs::{self, File, OpenOptions},
    io::{self, Read, Seek, SeekFrom, Write},
    path::{Path, PathBuf},
    sync::atomic::{AtomicU64, Ordering},
};

#[cfg(unix)]
use std::os::unix::fs::{MetadataExt, OpenOptionsExt, PermissionsExt};

use fs2::FileExt;
use sha2::{Digest, Sha256};

use crate::protocol::{PeerLeaseDirectionV1, PeerLeaseScopeV1};
use crate::store::ensure_private_directory;

/// Candidate-only metadata.  This journal does not imply consensus-runtime
/// or production activation truth.
pub const PAYLOAD_REPLAY_CANDIDATE_V1: bool = true;
pub const PAYLOAD_REPLAY_APPEND_ONLY_HASH_CHAIN_V1: bool = true;
pub const PAYLOAD_REPLAY_PRODUCTION_ACTIVATION_V1: bool = false;

/// A payload digest is bounded to the same order as the authenticated mesh
/// envelope.  The journal stores the digest, not an unbounded copy of the
/// payload itself.
pub const PAYLOAD_REPLAY_MAX_PAYLOAD_BYTES_V1: usize = 8 * 1024 * 1024;
pub const PAYLOAD_REPLAY_MAX_RECORDS_V1: u64 = 1_048_576;
/// Bound the complete metadata WAL snapshot independently from the record
/// count.  Replay is intentionally a whole-snapshot operation today, so this
/// cap prevents a locally supplied record-count limit from becoming an
/// unexpectedly large allocation during open/reload.  It is a local,
/// candidate-only resource fence and does not alter the wire frame contract.
pub const PAYLOAD_REPLAY_MAX_WAL_BYTES_V1: u64 = 64 * 1024 * 1024;
/// Bound the number of retained publication temporary paths held by an
/// external recovery owner.  Excess evidence is a fail-closed condition.
pub const PAYLOAD_REPLAY_MAX_TEMPORARY_FILES_V1: usize = 64;
/// Bound directory entries inspected while looking for replay publication
/// temporaries.  This protects the no-temporary case as well as the matching
/// path collection case from an attacker-controlled directory fan-out.
pub const PAYLOAD_REPLAY_MAX_TEMPORARY_SCAN_ENTRIES_V1: usize = 4096;

/// Return the only valid successor for a persisted replay generation.
/// Saturation would make `u64::MAX` look like a legal rollover to itself;
/// checked arithmetic instead makes that boundary stale/fail closed.
pub(crate) const fn payload_replay_generation_successor_v1(previous: u64) -> Option<u64> {
    previous.checked_add(1)
}

const LOG_MAGIC_V1: [u8; 8] = *b"TRNPRW01";
const LOG_VERSION_V1: u8 = 1;
const LOG_GENESIS_KIND_V1: u8 = 0;
const LOG_FRAME_KIND_V1: u8 = 1;
const HEAD_MAGIC_V1: [u8; 8] = *b"TRNPRH01";
const HEAD_VERSION_V1: u8 = 1;
const PRIVATE_MODE_V1: u32 = 0o600;
const NAMESPACE_DOMAIN_V1: &[u8] = b"trnm.portable-g3.payload-replay.namespace.v1";
const RECORD_DOMAIN_V1: &[u8] = b"trnm.portable-g3.payload-replay.record.v1";
const HEAD_DOMAIN_V1: &[u8] = b"trnm.portable-g3.payload-replay.head.v1";
const RUN_ID_DOMAIN_V1: &[u8] = b"trnm.portable-g3.payload-replay.run-id.v1";

// Fixed record layout.  Keeping every field in every record makes a copied
// record, cross-context splice, reordering, and byte mutation observable
// before any replay state is reconstructed.
const RECORD_PREFIX_BYTES_V1: usize = 348;
const RECORD_BYTES_V1: usize = RECORD_PREFIX_BYTES_V1 + 32;
const HEAD_PREFIX_BYTES_V1: usize = 8 + 1 + 3 + 8 + 32 + 32;
const HEAD_BYTES_V1: usize = HEAD_PREFIX_BYTES_V1 + 32;

// A failed head publication is deliberately retained as recovery evidence.
// Include a process-local nonce in each temporary name so a later retry in the
// same process does not collide with that retained evidence forever.
static HEAD_TEMP_NONCE_V1: AtomicU64 = AtomicU64::new(0);

fn next_head_temp_path_v1(path: &Path, name: &str, record_count: u64) -> PathBuf {
    path.with_file_name(format!(
        ".{name}.tmp-{}-{record_count}-{}",
        std::process::id(),
        HEAD_TEMP_NONCE_V1.fetch_add(1, Ordering::Relaxed),
    ))
}

/// Re-export the lease direction under a payload-specific name.  Using the
/// exact lease enum prevents an inbound and outbound journal key from being
/// accidentally aliased by a caller.
pub type PayloadReplayDirectionV1 = PeerLeaseDirectionV1;

/// Computes the run binding used by [`PayloadReplayNamespaceV1`].  Keeping
/// this helper in the authority crate prevents mesh adapters from inventing a
/// second, subtly different run-id hash.
pub fn payload_replay_run_id_hash_v1(run_id: &str) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(RUN_ID_DOMAIN_V1);
    hasher.update((run_id.len() as u64).to_be_bytes());
    hasher.update(run_id.as_bytes());
    hasher.finalize().into()
}

/// Immutable namespace shared by every record in one node's replay journal.
/// The run and network-context digests are included in the hash-chain
/// genesis, so a journal cannot be attached to another deployment bundle.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PayloadReplayNamespaceV1 {
    local_id: [u8; 32],
    epoch: u64,
    peer_scope_id: [u8; 32],
    run_id_hash: [u8; 32],
    network_context_hash: [u8; 32],
}

impl PayloadReplayNamespaceV1 {
    pub fn new(
        local_id: [u8; 32],
        epoch: u64,
        peer_scope_id: [u8; 32],
        run_id_hash: [u8; 32],
        network_context_hash: [u8; 32],
    ) -> Result<Self, PayloadReplayErrorV1> {
        if local_id == [0; 32]
            || peer_scope_id == [0; 32]
            || run_id_hash == [0; 32]
            || network_context_hash == [0; 32]
        {
            return Err(PayloadReplayErrorV1::InvalidRequest(
                "payload replay namespace contains a zero identity",
            ));
        }
        Ok(Self {
            local_id,
            epoch,
            peer_scope_id,
            run_id_hash,
            network_context_hash,
        })
    }

    pub const fn local_id(self) -> [u8; 32] {
        self.local_id
    }

    pub const fn epoch(self) -> u64 {
        self.epoch
    }

    pub const fn peer_scope_id(self) -> [u8; 32] {
        self.peer_scope_id
    }

    pub const fn run_id_hash(self) -> [u8; 32] {
        self.run_id_hash
    }

    pub const fn network_context_hash(self) -> [u8; 32] {
        self.network_context_hash
    }

    /// Builds the exact peer-lease scope used by one directed payload edge.
    pub fn scope_for(
        self,
        remote_id: [u8; 32],
        direction: PayloadReplayDirectionV1,
    ) -> Result<PeerLeaseScopeV1, PayloadReplayErrorV1> {
        PeerLeaseScopeV1::new(
            self.local_id,
            remote_id,
            direction,
            self.epoch,
            self.peer_scope_id,
        )
        .map_err(|_| PayloadReplayErrorV1::InvalidRequest("invalid payload replay peer scope"))
    }

    fn digest(self) -> [u8; 32] {
        let mut hasher = Sha256::new();
        hasher.update(NAMESPACE_DOMAIN_V1);
        hasher.update(self.local_id);
        hasher.update(self.epoch.to_be_bytes());
        hasher.update(self.peer_scope_id);
        hasher.update(self.run_id_hash);
        hasher.update(self.network_context_hash);
        hasher.finalize().into()
    }
}

/// One authenticated frame identity ready for durable admission.  The frame
/// signature and nested consensus signatures must already have been verified
/// by the transport/collector. `frame_fingerprint` is the canonical digest of
/// the complete authenticated frame fields and payload.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PayloadReplayFrameV1 {
    scope: PeerLeaseScopeV1,
    run_id_hash: [u8; 32],
    network_context_hash: [u8; 32],
    session_id: [u8; 32],
    generation: u64,
    sequence: u64,
    frame_kind: u8,
    payload_len: u32,
    frame_fingerprint: [u8; 32],
}

impl PayloadReplayFrameV1 {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        scope: PeerLeaseScopeV1,
        run_id_hash: [u8; 32],
        network_context_hash: [u8; 32],
        session_id: [u8; 32],
        generation: u64,
        sequence: u64,
        frame_kind: u8,
        payload_len: usize,
        frame_fingerprint: [u8; 32],
    ) -> Result<Self, PayloadReplayErrorV1> {
        if run_id_hash == [0; 32] || network_context_hash == [0; 32] {
            return Err(PayloadReplayErrorV1::InvalidRequest(
                "payload replay frame has a zero context digest",
            ));
        }
        if session_id == [0; 32] {
            return Err(PayloadReplayErrorV1::InvalidRequest(
                "payload replay frame has a zero session",
            ));
        }
        if generation == 0 {
            return Err(PayloadReplayErrorV1::InvalidRequest(
                "payload replay generation must be positive",
            ));
        }
        if frame_kind == 0 {
            return Err(PayloadReplayErrorV1::InvalidRequest(
                "payload replay frame kind must be nonzero",
            ));
        }
        if payload_len > PAYLOAD_REPLAY_MAX_PAYLOAD_BYTES_V1 {
            return Err(PayloadReplayErrorV1::TooLarge);
        }
        let payload_len = u32::try_from(payload_len).map_err(|_| PayloadReplayErrorV1::TooLarge)?;
        if frame_fingerprint == [0; 32] {
            return Err(PayloadReplayErrorV1::InvalidRequest(
                "payload replay frame fingerprint is zero",
            ));
        }
        Ok(Self {
            scope,
            run_id_hash,
            network_context_hash,
            session_id,
            generation,
            sequence,
            frame_kind,
            payload_len,
            frame_fingerprint,
        })
    }

    pub const fn scope(self) -> PeerLeaseScopeV1 {
        self.scope
    }

    pub const fn run_id_hash(self) -> [u8; 32] {
        self.run_id_hash
    }

    pub const fn network_context_hash(self) -> [u8; 32] {
        self.network_context_hash
    }

    pub const fn session_id(self) -> [u8; 32] {
        self.session_id
    }

    pub const fn generation(self) -> u64 {
        self.generation
    }

    pub const fn sequence(self) -> u64 {
        self.sequence
    }

    pub const fn frame_kind(self) -> u8 {
        self.frame_kind
    }

    pub const fn payload_len(self) -> u32 {
        self.payload_len
    }

    pub const fn frame_fingerprint(self) -> [u8; 32] {
        self.frame_fingerprint
    }
}

/// Receipt returned only after the frame record and head sidecar are synced.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct PayloadReplayReceiptV1 {
    record_index: u64,
    record_hash: [u8; 32],
}

impl PayloadReplayReceiptV1 {
    pub const fn record_index(self) -> u64 {
        self.record_index
    }

    pub const fn record_hash(self) -> [u8; 32] {
        self.record_hash
    }
}

/// Errors from the candidate durable payload replay owner.
#[derive(Debug)]
pub enum PayloadReplayErrorV1 {
    InvalidRequest(&'static str),
    Io(io::Error),
    /// The WAL record was written (and may have been synced), but the
    /// admission operation could not finish publishing its exact head.  The
    /// caller must not report this as an ordinary rejection: reopening the
    /// journal is the only way to determine whether the frame is durable.
    CommitAmbiguous(Box<PayloadReplayErrorV1>),
    Protocol(&'static str),
    ContextMismatch,
    Replay,
    StaleGeneration,
    SequenceGap,
    Corrupt,
    Truncated,
    TooLarge,
    Poisoned,
}

impl PayloadReplayErrorV1 {
    /// Whether the failed call may already have appended its frame record.
    /// A fresh owner must reopen and authenticate the WAL/head pair before
    /// deciding whether a retry is a replay or a new admission.
    pub const fn commit_ambiguous(&self) -> bool {
        matches!(self, Self::CommitAmbiguous(_))
    }
}

impl fmt::Display for PayloadReplayErrorV1 {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidRequest(reason) | Self::Protocol(reason) => formatter.write_str(reason),
            Self::Io(error) => write!(formatter, "payload replay I/O error: {error}"),
            Self::CommitAmbiguous(error) => {
                write!(
                    formatter,
                    "payload replay commit outcome is ambiguous: {error}"
                )
            }
            Self::ContextMismatch => formatter.write_str("payload replay context mismatch"),
            Self::Replay => formatter.write_str("authenticated payload frame was replayed"),
            Self::StaleGeneration => formatter.write_str("payload frame generation is stale"),
            Self::SequenceGap => formatter.write_str("payload frame sequence is not contiguous"),
            Self::Corrupt => formatter.write_str("payload replay journal is corrupt"),
            Self::Truncated => formatter.write_str("payload replay journal is truncated"),
            Self::TooLarge => formatter.write_str("payload replay journal exceeds its bound"),
            Self::Poisoned => formatter.write_str("payload replay owner is permanently poisoned"),
        }
    }
}

impl std::error::Error for PayloadReplayErrorV1 {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Io(error) => Some(error),
            Self::CommitAmbiguous(error) => Some(error.as_ref()),
            _ => None,
        }
    }
}

impl From<io::Error> for PayloadReplayErrorV1 {
    fn from(error: io::Error) -> Self {
        Self::Io(error)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
struct PeerKeyV1 {
    remote_id: [u8; 32],
    direction: PeerLeaseDirectionV1,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ReplayStateV1 {
    session_id: [u8; 32],
    generation: u64,
    last_sequence: u64,
    last_fingerprint: [u8; 32],
}

/// The complete immutable identity of one admitted frame.  The replay WAL
/// stores this identity in every record; retaining it in memory lets a retry
/// recover the original receipt without appending a second record.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
struct ReplayFrameIdentityV1 {
    scope: PeerLeaseScopeV1,
    run_id_hash: [u8; 32],
    network_context_hash: [u8; 32],
    session_id: [u8; 32],
    generation: u64,
    sequence: u64,
    frame_kind: u8,
    payload_len: u32,
    frame_fingerprint: [u8; 32],
}

impl ReplayFrameIdentityV1 {
    fn from_frame(frame: PayloadReplayFrameV1) -> Self {
        Self {
            scope: frame.scope,
            run_id_hash: frame.run_id_hash,
            network_context_hash: frame.network_context_hash,
            session_id: frame.session_id,
            generation: frame.generation,
            sequence: frame.sequence,
            frame_kind: frame.frame_kind,
            payload_len: frame.payload_len,
            frame_fingerprint: frame.frame_fingerprint,
        }
    }

    fn position(self) -> ReplayFramePositionV1 {
        ReplayFramePositionV1 {
            key: PeerKeyV1 {
                remote_id: self.scope.remote_id(),
                direction: self.scope.direction(),
            },
            generation: self.generation,
            sequence: self.sequence,
        }
    }
}

/// A frame slot excludes the payload fingerprint and session.  If a caller
/// presents a different authenticated frame for an already occupied slot,
/// lookup must report `Replay` rather than allowing the caller to treat it as
/// an unseen frame.  The exact identity map above remains the authority for
/// successful idempotent lookup.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
struct ReplayFramePositionV1 {
    key: PeerKeyV1,
    generation: u64,
    sequence: u64,
}

#[derive(Debug)]
struct ReplaySnapshotV1 {
    states: BTreeMap<PeerKeyV1, ReplayStateV1>,
    seen_sessions: BTreeSet<(PeerKeyV1, [u8; 32])>,
    frame_receipts: BTreeMap<ReplayFrameIdentityV1, PayloadReplayReceiptV1>,
    frame_positions: BTreeMap<ReplayFramePositionV1, ReplayFrameIdentityV1>,
    last_hash: [u8; 32],
    record_count: u64,
}

/// Descriptor/path identity retained for every endpoint of a replay owner.
///
/// The journal and lock descriptors are kept open for the lifetime of the
/// owner, but the head sidecar (and the parent directory used by atomic
/// publication) is still addressed by pathname.  Comparing both descriptor
/// and pathname metadata before and after each operation turns a same-UID
/// rename/symlink/hard-link substitution into a fail-closed error instead of
/// silently moving the replay namespace.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct PayloadReplayPathIdentityV1 {
    #[cfg(unix)]
    device: u64,
    #[cfg(unix)]
    inode: u64,
    #[cfg(unix)]
    uid: u32,
    #[cfg(unix)]
    mode: u32,
    #[cfg(unix)]
    nlink: u64,
    #[cfg(not(unix))]
    is_file: bool,
    #[cfg(not(unix))]
    is_directory: bool,
}

impl PayloadReplayPathIdentityV1 {
    fn from_metadata(metadata: &fs::Metadata) -> Self {
        #[cfg(unix)]
        {
            Self {
                device: metadata.dev(),
                inode: metadata.ino(),
                uid: metadata.uid(),
                mode: metadata.mode(),
                nlink: metadata.nlink(),
            }
        }
        #[cfg(not(unix))]
        {
            Self {
                is_file: metadata.is_file(),
                is_directory: metadata.is_dir(),
            }
        }
    }
}

/// A directory's children may change without replacing its authority owner.
/// Keep this distinct from regular-file identity, where nlink must remain one.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct PayloadReplayDirectoryIdentityV1 {
    #[cfg(unix)]
    device: u64,
    #[cfg(unix)]
    inode: u64,
    #[cfg(unix)]
    uid: u32,
    #[cfg(unix)]
    gid: u32,
    #[cfg(unix)]
    mode: u32,
    #[cfg(not(unix))]
    is_directory: bool,
}

impl PayloadReplayDirectoryIdentityV1 {
    pub(crate) fn from_metadata(metadata: &fs::Metadata) -> Self {
        #[cfg(unix)]
        {
            Self {
                device: metadata.dev(),
                inode: metadata.ino(),
                uid: metadata.uid(),
                gid: metadata.gid(),
                mode: metadata.mode(),
            }
        }
        #[cfg(not(unix))]
        {
            Self {
                is_directory: metadata.is_dir(),
            }
        }
    }
}

/// Node-owned append-only payload replay journal.  One exclusive lock covers
/// the whole namespace; a second process cannot open the same owner while it
/// is live.  Reopening replays every record and requires an exact sidecar
/// head, so truncation to a valid prefix is rejected rather than silently
/// accepted.
#[derive(Debug)]
pub struct PayloadReplayStoreV1 {
    path: PathBuf,
    head_path: PathBuf,
    directory: File,
    directory_identity: PayloadReplayDirectoryIdentityV1,
    file: File,
    file_identity: PayloadReplayPathIdentityV1,
    lock_path: PathBuf,
    _lock: File,
    lock_identity: PayloadReplayPathIdentityV1,
    head_identity: Option<PayloadReplayPathIdentityV1>,
    namespace: PayloadReplayNamespaceV1,
    namespace_digest: [u8; 32],
    states: BTreeMap<PeerKeyV1, ReplayStateV1>,
    seen_sessions: BTreeSet<(PeerKeyV1, [u8; 32])>,
    frame_receipts: BTreeMap<ReplayFrameIdentityV1, PayloadReplayReceiptV1>,
    frame_positions: BTreeMap<ReplayFramePositionV1, ReplayFrameIdentityV1>,
    last_hash: [u8; 32],
    record_count: u64,
    poisoned: bool,
}

impl PayloadReplayStoreV1 {
    /// Opens and fully authenticates a replay journal.  No repair or
    /// truncation is attempted; an absent head, partial record, or prefix
    /// mismatch is a hard failure.
    pub fn open(
        path: impl AsRef<Path>,
        namespace: PayloadReplayNamespaceV1,
    ) -> Result<Self, PayloadReplayErrorV1> {
        let path = path.as_ref().to_path_buf();
        let (directory, parent) = private_parent(&path)?;
        let directory_identity =
            PayloadReplayDirectoryIdentityV1::from_metadata(&directory.metadata()?);
        verify_payload_replay_directory_identity(&parent, &directory, directory_identity)?;
        let lock_path = sidecar_path(&path, "lock-v1")?;
        let head_path = sidecar_path(&path, "head-v1")?;
        reject_stale_head_temps(&path)?;
        let lock = open_private_lock(&lock_path)?;
        let lock_identity = payload_replay_descriptor_identity(&lock)?;
        verify_payload_replay_file_identity(&lock_path, &lock, lock_identity)?;
        lock.try_lock_exclusive()
            .map_err(PayloadReplayErrorV1::Io)?;

        let existing = match fs::symlink_metadata(&path) {
            Ok(metadata) => {
                if !metadata.is_file() || !private_file_mode(&metadata) {
                    return Err(PayloadReplayErrorV1::InvalidRequest(
                        "payload replay journal path is not a private regular file",
                    ));
                }
                true
            }
            Err(error) if error.kind() == io::ErrorKind::NotFound => false,
            Err(error) => return Err(PayloadReplayErrorV1::Io(error)),
        };
        let head_exists = match fs::symlink_metadata(&head_path) {
            Ok(_) => true,
            Err(error) if error.kind() == io::ErrorKind::NotFound => false,
            Err(error) => return Err(PayloadReplayErrorV1::Io(error)),
        };
        // Reject a sidecar for a virgin journal before creating the journal's
        // genesis record. Otherwise a failed open would leave a misleading
        // zero-length/partial namespace which permanently changes the next
        // error from an explicit collision to a generic truncation.
        if !existing && head_exists {
            return Err(PayloadReplayErrorV1::InvalidRequest(
                "payload replay head exists for a virgin journal",
            ));
        }
        let mut options = OpenOptions::new();
        options.read(true).write(true).append(true);
        // Existing files need the same no-follow protection as newly-created
        // files.  Without this flag a same-UID rename between the metadata
        // probe above and `open` could redirect the descriptor to an alias.
        set_private_mode_options(&mut options);
        if existing {
            options.create(false);
        } else {
            options.create_new(true);
        }
        let file = options.open(&path).map_err(PayloadReplayErrorV1::Io)?;
        if !existing {
            set_private_mode(&file)?;
        }
        validate_private_file(&file)?;
        let file_identity = payload_replay_descriptor_identity(&file)?;
        verify_payload_replay_file_identity(&path, &file, file_identity)?;
        file.try_lock_exclusive()
            .map_err(PayloadReplayErrorV1::Io)?;
        if existing && file.metadata()?.len() == 0 {
            return Err(PayloadReplayErrorV1::Truncated);
        }
        let namespace_digest = namespace.digest();
        let head_identity = match payload_replay_path_identity(&head_path) {
            Ok(identity) => Some(identity),
            Err(PayloadReplayErrorV1::Io(error))
                if error.kind() == io::ErrorKind::NotFound && !existing =>
            {
                None
            }
            Err(error) => return Err(error),
        };
        let mut store = Self {
            path,
            head_path,
            directory,
            directory_identity,
            file,
            file_identity,
            lock_path,
            _lock: lock,
            lock_identity,
            head_identity,
            namespace,
            namespace_digest,
            states: BTreeMap::new(),
            seen_sessions: BTreeSet::new(),
            frame_receipts: BTreeMap::new(),
            frame_positions: BTreeMap::new(),
            last_hash: [0; 32],
            record_count: 0,
            poisoned: false,
        };
        if !existing {
            let genesis = encode_record(None, namespace, namespace_digest, 0, [0; 32]);
            store.verify_payload_replay_storage_paths_v1()?;
            store.file.write_all(&genesis)?;
            store.file.sync_all()?;
            store.directory.sync_all()?;
            store.verify_payload_replay_storage_paths_v1()?;
        }
        store.reload_from_disk()?;
        store.reconcile_head(!existing)?;
        store.refresh_head_identity_v1()?;
        store.verify_bound_paths_v1()?;
        Ok(store)
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    pub fn head_path(&self) -> &Path {
        &self.head_path
    }

    pub const fn namespace(&self) -> PayloadReplayNamespaceV1 {
        self.namespace
    }

    pub const fn last_hash(&self) -> [u8; 32] {
        self.last_hash
    }

    /// Includes the genesis record.  `accepted_frame_count` excludes it.
    pub const fn record_count(&self) -> u64 {
        self.record_count
    }

    pub const fn accepted_frame_count(&self) -> u64 {
        self.record_count.saturating_sub(1)
    }

    pub fn contains_session(
        &self,
        remote_id: [u8; 32],
        direction: PayloadReplayDirectionV1,
        session_id: [u8; 32],
    ) -> bool {
        self.seen_sessions.contains(&(
            PeerKeyV1 {
                remote_id,
                direction,
            },
            session_id,
        ))
    }

    pub fn latest_generation(
        &self,
        remote_id: [u8; 32],
        direction: PayloadReplayDirectionV1,
    ) -> Option<u64> {
        self.states
            .get(&PeerKeyV1 {
                remote_id,
                direction,
            })
            .map(|state| state.generation)
    }

    /// Revalidate the journal, lock, head and parent identities held by this
    /// owner.  A caller which performs additional work between replay
    /// operations can use this explicit fence; `admit` and `lookup_exact_v1`
    /// invoke the same check internally.
    pub fn verify_bound_endpoint_identity(&self) -> Result<(), PayloadReplayErrorV1> {
        self.verify_bound_paths_v1()
    }

    /// Durably admits one already-authenticated frame.  The frame is never
    /// exposed as accepted until both the WAL record and exact head sidecar
    /// have been synced.
    pub fn admit(
        &mut self,
        frame: &PayloadReplayFrameV1,
    ) -> Result<PayloadReplayReceiptV1, PayloadReplayErrorV1> {
        if self.poisoned {
            return Err(PayloadReplayErrorV1::Poisoned);
        }
        if let Err(error) = self.verify_live_head() {
            self.poisoned = true;
            return Err(error);
        }
        self.validate_frame_context(frame)?;
        let key = PeerKeyV1 {
            remote_id: frame.scope.remote_id(),
            direction: frame.scope.direction(),
        };
        let next_state = self.preview_state(key, *frame)?;
        if self.record_count >= PAYLOAD_REPLAY_MAX_RECORDS_V1 {
            return Err(PayloadReplayErrorV1::TooLarge);
        }
        // Compute the publication count before writing anything.  An
        // arithmetic failure is a definitive local bound violation, never a
        // post-WAL ambiguity that could be mistaken for a rejected request.
        let new_count = self
            .record_count
            .checked_add(1)
            .ok_or(PayloadReplayErrorV1::TooLarge)?;
        let index = self.record_count;
        let record = encode_record(
            Some(frame),
            self.namespace,
            self.namespace_digest,
            index,
            self.last_hash,
        );
        let current_length = self.file.metadata()?.len();
        let new_length = current_length
            .checked_add(record.len() as u64)
            .ok_or(PayloadReplayErrorV1::TooLarge)?;
        if new_length > PAYLOAD_REPLAY_MAX_WAL_BYTES_V1 {
            return Err(PayloadReplayErrorV1::TooLarge);
        }
        // Frame validation and in-memory preview happen before the append and
        // may yield to a same-UID namespace replacement.  Recheck every
        // bound endpoint immediately before crossing the durable boundary so
        // a stale pathname can never be treated as this owner's append.
        if let Err(error) = self.verify_bound_paths_v1() {
            self.poisoned = true;
            return Err(error);
        }
        if let Err(error) = self.file.write_all(&record) {
            self.poisoned = true;
            return Err(PayloadReplayErrorV1::CommitAmbiguous(Box::new(
                PayloadReplayErrorV1::Io(error),
            )));
        }
        if let Err(error) = self.file.sync_all().and_then(|_| self.directory.sync_all()) {
            self.poisoned = true;
            return Err(PayloadReplayErrorV1::CommitAmbiguous(Box::new(
                PayloadReplayErrorV1::Io(error),
            )));
        }
        let record_hash = record_digest(&record[..RECORD_PREFIX_BYTES_V1]);
        let published_head_identity = match persist_head_with_identity(
            &self.head_path,
            &self.directory,
            new_count,
            record_hash,
            self.namespace_digest,
        ) {
            Ok(identity) => identity,
            Err(error) => {
                self.poisoned = true;
                return Err(PayloadReplayErrorV1::CommitAmbiguous(Box::new(error)));
            }
        };
        // `persist_head_with_identity` publishes a replacement inode and
        // authenticates that the pathname still names the exact descriptor
        // which was written.  Keep that identity before exposing the new
        // in-memory state; any later substitution is caught by the final
        // bound-path check below.
        self.head_identity = Some(published_head_identity);
        self.states.insert(key, next_state);
        self.seen_sessions.insert((key, frame.session_id));
        let identity = ReplayFrameIdentityV1::from_frame(*frame);
        let position = identity.position();
        self.frame_receipts.insert(
            identity,
            PayloadReplayReceiptV1 {
                record_index: index,
                record_hash,
            },
        );
        self.frame_positions.insert(position, identity);
        self.last_hash = record_hash;
        self.record_count = new_count;
        if let Err(error) = self.verify_bound_paths_v1() {
            self.poisoned = true;
            return Err(PayloadReplayErrorV1::CommitAmbiguous(Box::new(error)));
        }
        Ok(PayloadReplayReceiptV1 {
            record_index: index,
            record_hash,
        })
    }

    /// Looks up an already admitted frame without appending or otherwise
    /// changing the replay journal.  The live WAL/head pair is authenticated
    /// before consulting the in-memory index, so a caller can never receive a
    /// stale receipt after an out-of-band rollback or replacement.  `None`
    /// means that the exact frame has not been admitted; an occupied frame
    /// slot with a different identity is a replay conflict.
    pub fn lookup_exact_v1(
        &mut self,
        frame: &PayloadReplayFrameV1,
    ) -> Result<Option<PayloadReplayReceiptV1>, PayloadReplayErrorV1> {
        if self.poisoned {
            return Err(PayloadReplayErrorV1::Poisoned);
        }
        if let Err(error) = self.verify_live_head() {
            self.poisoned = true;
            return Err(error);
        }
        self.validate_frame_context(frame)?;
        let result = {
            let identity = ReplayFrameIdentityV1::from_frame(*frame);
            if let Some(receipt) = self.frame_receipts.get(&identity).copied() {
                Ok(Some(receipt))
            } else if self.frame_positions.contains_key(&identity.position()) {
                Err(PayloadReplayErrorV1::Replay)
            } else {
                Ok(None)
            }
        };
        // Fence every externally visible lookup result, including an exact
        // receipt and a slot-conflict error.  Returning either one after a
        // pathname substitution would expose state that was only valid for
        // the old replay namespace.
        if let Err(error) = self.verify_bound_paths_v1() {
            self.poisoned = true;
            return Err(error);
        }
        result
    }

    fn validate_frame_context(
        &self,
        frame: &PayloadReplayFrameV1,
    ) -> Result<(), PayloadReplayErrorV1> {
        let scope = frame.scope;
        if scope.local_id() != self.namespace.local_id()
            || scope.epoch() != self.namespace.epoch()
            || scope.peer_scope_id() != self.namespace.peer_scope_id()
            || frame.run_id_hash != self.namespace.run_id_hash()
            || frame.network_context_hash != self.namespace.network_context_hash()
        {
            return Err(PayloadReplayErrorV1::ContextMismatch);
        }
        if scope.remote_id() == [0; 32] || scope.remote_id() == scope.local_id() {
            return Err(PayloadReplayErrorV1::ContextMismatch);
        }
        Ok(())
    }

    fn preview_state(
        &self,
        key: PeerKeyV1,
        frame: PayloadReplayFrameV1,
    ) -> Result<ReplayStateV1, PayloadReplayErrorV1> {
        let current_session = self.states.get(&key).map(|state| state.session_id);
        if current_session != Some(frame.session_id)
            && self.seen_sessions.contains(&(key, frame.session_id))
        {
            return Err(PayloadReplayErrorV1::Replay);
        }
        match self.states.get(&key).copied() {
            None => {
                if frame.generation != 1 || frame.sequence != 0 {
                    return Err(PayloadReplayErrorV1::StaleGeneration);
                }
            }
            Some(previous) if frame.generation == previous.generation => {
                if frame.session_id != previous.session_id {
                    return Err(PayloadReplayErrorV1::Replay);
                }
                let expected = previous
                    .last_sequence
                    .checked_add(1)
                    .ok_or(PayloadReplayErrorV1::TooLarge)?;
                if frame.sequence < expected {
                    return Err(PayloadReplayErrorV1::Replay);
                }
                if frame.sequence != expected {
                    return Err(PayloadReplayErrorV1::SequenceGap);
                }
            }
            Some(previous)
                if payload_replay_generation_successor_v1(previous.generation)
                    == Some(frame.generation) =>
            {
                if frame.session_id == previous.session_id || frame.sequence != 0 {
                    return Err(PayloadReplayErrorV1::Replay);
                }
            }
            Some(previous) if frame.generation < previous.generation => {
                return Err(PayloadReplayErrorV1::StaleGeneration)
            }
            Some(_) => return Err(PayloadReplayErrorV1::StaleGeneration),
        }
        Ok(ReplayStateV1 {
            session_id: frame.session_id,
            generation: frame.generation,
            last_sequence: frame.sequence,
            last_fingerprint: frame.frame_fingerprint,
        })
    }

    /// Revalidate the descriptor/path identity of the journal, lock and
    /// parent directory.  The head sidecar is optional only while opening a
    /// virgin journal; all externally visible operations use
    /// `verify_bound_paths_v1`, which requires a pinned head as well.
    fn verify_payload_replay_storage_paths_v1(&self) -> Result<(), PayloadReplayErrorV1> {
        let parent = self
            .path
            .parent()
            .ok_or(PayloadReplayErrorV1::InvalidRequest(
                "payload replay path has no parent",
            ))?;
        verify_payload_replay_directory_identity(parent, &self.directory, self.directory_identity)?;
        verify_payload_replay_file_identity(&self.path, &self.file, self.file_identity)?;
        verify_payload_replay_file_identity(&self.lock_path, &self._lock, self.lock_identity)?;
        Ok(())
    }

    fn verify_bound_paths_v1(&self) -> Result<(), PayloadReplayErrorV1> {
        self.verify_payload_replay_storage_paths_v1()?;
        let head_identity = self.head_identity.ok_or(PayloadReplayErrorV1::Corrupt)?;
        verify_payload_replay_path_identity(&self.head_path, head_identity)
    }

    fn refresh_head_identity_v1(&mut self) -> Result<(), PayloadReplayErrorV1> {
        let identity = payload_replay_path_identity(&self.head_path)?;
        let metadata = fs::symlink_metadata(&self.head_path)?;
        if !metadata.is_file() || !private_file_mode(&metadata) {
            return Err(PayloadReplayErrorV1::InvalidRequest(
                "payload replay head is not a private regular file",
            ));
        }
        self.head_identity = Some(identity);
        Ok(())
    }

    fn verify_live_head(&mut self) -> Result<(), PayloadReplayErrorV1> {
        self.verify_bound_paths_v1()?;
        let bytes = self.read_log_bytes()?;
        let snapshot = parse_log(&bytes, self.namespace, self.namespace_digest)?;
        if snapshot.record_count != self.record_count
            || snapshot.last_hash != self.last_hash
            || snapshot.states != self.states
            || snapshot.seen_sessions != self.seen_sessions
            || snapshot.frame_receipts != self.frame_receipts
            || snapshot.frame_positions != self.frame_positions
        {
            return Err(PayloadReplayErrorV1::Corrupt);
        }
        let head_bytes = read_private_head(&self.head_path)?;
        let (head_count, head_hash, head_namespace) = decode_head(&head_bytes)?;
        if head_count != self.record_count
            || head_hash != self.last_hash
            || head_namespace != self.namespace_digest
        {
            return Err(PayloadReplayErrorV1::Corrupt);
        }
        self.verify_bound_paths_v1()?;
        Ok(())
    }

    fn reload_from_disk(&mut self) -> Result<(), PayloadReplayErrorV1> {
        self.verify_reload_paths_v1()?;
        let bytes = self.read_log_bytes()?;
        let snapshot = parse_log(&bytes, self.namespace, self.namespace_digest)?;
        self.states = snapshot.states;
        self.seen_sessions = snapshot.seen_sessions;
        self.frame_receipts = snapshot.frame_receipts;
        self.frame_positions = snapshot.frame_positions;
        self.last_hash = snapshot.last_hash;
        self.record_count = snapshot.record_count;
        self.verify_reload_paths_v1()?;
        Ok(())
    }

    fn verify_reload_paths_v1(&self) -> Result<(), PayloadReplayErrorV1> {
        self.verify_payload_replay_storage_paths_v1()?;
        if let Some(head_identity) = self.head_identity {
            verify_payload_replay_path_identity(&self.head_path, head_identity)?;
        }
        Ok(())
    }

    fn read_log_bytes(&mut self) -> Result<Vec<u8>, PayloadReplayErrorV1> {
        let length = self.file.metadata()?.len();
        let record_maximum = PAYLOAD_REPLAY_MAX_RECORDS_V1
            .checked_mul(RECORD_BYTES_V1 as u64)
            .ok_or(PayloadReplayErrorV1::TooLarge)?;
        let maximum = record_maximum.min(PAYLOAD_REPLAY_MAX_WAL_BYTES_V1);
        if length > maximum {
            return Err(PayloadReplayErrorV1::TooLarge);
        }
        self.file.seek(SeekFrom::Start(0))?;
        let mut bytes = Vec::new();
        let capacity = usize::try_from(length).map_err(|_| PayloadReplayErrorV1::TooLarge)?;
        bytes
            .try_reserve_exact(capacity)
            .map_err(|_| PayloadReplayErrorV1::TooLarge)?;
        bytes.resize(capacity, 0);
        if let Err(error) = self.file.read_exact(&mut bytes) {
            return if error.kind() == io::ErrorKind::UnexpectedEof {
                Err(PayloadReplayErrorV1::Truncated)
            } else {
                Err(PayloadReplayErrorV1::Io(error))
            };
        }
        let mut trailing = [0_u8; 1];
        if self.file.read(&mut trailing)? != 0 {
            return Err(PayloadReplayErrorV1::TooLarge);
        }
        let observed_length = self.file.metadata()?.len();
        self.file.seek(SeekFrom::End(0))?;
        if observed_length != length {
            return Err(if observed_length > maximum {
                PayloadReplayErrorV1::TooLarge
            } else {
                PayloadReplayErrorV1::Truncated
            });
        }
        Ok(bytes)
    }

    fn reconcile_head(&self, virgin: bool) -> Result<(), PayloadReplayErrorV1> {
        self.verify_payload_replay_storage_paths_v1()?;
        let bytes = match read_private_head(&self.head_path) {
            Ok(bytes) => bytes,
            Err(PayloadReplayErrorV1::Io(error))
                if error.kind() == io::ErrorKind::NotFound && virgin =>
            {
                return persist_head(
                    &self.head_path,
                    &self.directory,
                    self.record_count,
                    self.last_hash,
                    self.namespace_digest,
                )
            }
            Err(error) => return Err(error),
        };
        if virgin {
            // A head sidecar appearing after the initial virgin-journal probe
            // is a namespace race, even if its bytes happen to describe the
            // expected genesis. Accepting it would let an uncooperating
            // writer install authority state between our checks.
            return Err(PayloadReplayErrorV1::InvalidRequest(
                "payload replay head appeared during virgin open",
            ));
        }
        let (count, hash, namespace_digest) = decode_head(&bytes)?;
        if namespace_digest != self.namespace_digest
            || count != self.record_count
            || hash != self.last_hash
        {
            // Exact equality is intentional.  A valid prefix is not a
            // recoverable state: accepting it would make an old authenticated
            // frame appear new after a rollback.
            return Err(PayloadReplayErrorV1::Corrupt);
        }
        self.verify_payload_replay_storage_paths_v1()?;
        Ok(())
    }
}

fn payload_replay_descriptor_identity(
    file: &File,
) -> Result<PayloadReplayPathIdentityV1, PayloadReplayErrorV1> {
    Ok(PayloadReplayPathIdentityV1::from_metadata(
        &file.metadata()?,
    ))
}

fn payload_replay_path_identity(
    path: &Path,
) -> Result<PayloadReplayPathIdentityV1, PayloadReplayErrorV1> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink() {
        return Err(PayloadReplayErrorV1::InvalidRequest(
            "payload replay authority path is a symlink",
        ));
    }
    Ok(PayloadReplayPathIdentityV1::from_metadata(&metadata))
}

fn map_private_directory_error(error: crate::PeerLeaseErrorV1) -> PayloadReplayErrorV1 {
    match error {
        crate::PeerLeaseErrorV1::InvalidRequest(reason)
        | crate::PeerLeaseErrorV1::Protocol(reason) => PayloadReplayErrorV1::InvalidRequest(reason),
        crate::PeerLeaseErrorV1::Io(error) => PayloadReplayErrorV1::Io(error),
        crate::PeerLeaseErrorV1::Rejected(_) => {
            PayloadReplayErrorV1::InvalidRequest("payload replay parent ancestry is not private")
        }
    }
}

fn verify_payload_replay_directory_identity(
    path: &Path,
    directory: &File,
    expected: PayloadReplayDirectoryIdentityV1,
) -> Result<(), PayloadReplayErrorV1> {
    let descriptor_metadata = directory.metadata()?;
    let named_metadata = fs::symlink_metadata(path)?;
    if named_metadata.file_type().is_symlink()
        || !descriptor_metadata.is_dir()
        || !named_metadata.is_dir()
        || !private_parent_mode(&descriptor_metadata)
        || !private_parent_mode(&named_metadata)
        || PayloadReplayDirectoryIdentityV1::from_metadata(&descriptor_metadata) != expected
        || PayloadReplayDirectoryIdentityV1::from_metadata(&named_metadata) != expected
        || fs::canonicalize(path)? != path
    {
        return Err(PayloadReplayErrorV1::InvalidRequest(
            "payload replay parent directory identity changed",
        ));
    }
    crate::store::ensure_private_directory(path).map_err(map_private_directory_error)
}

fn verify_payload_replay_file_identity(
    path: &Path,
    file: &File,
    expected: PayloadReplayPathIdentityV1,
) -> Result<(), PayloadReplayErrorV1> {
    validate_private_file(file)?;
    let descriptor_metadata = file.metadata()?;
    let named_metadata = fs::symlink_metadata(path)?;
    if named_metadata.file_type().is_symlink()
        || !descriptor_metadata.is_file()
        || !named_metadata.is_file()
        || !private_file_mode(&named_metadata)
        || PayloadReplayPathIdentityV1::from_metadata(&descriptor_metadata) != expected
        || PayloadReplayPathIdentityV1::from_metadata(&named_metadata) != expected
    {
        return Err(PayloadReplayErrorV1::InvalidRequest(
            "payload replay authority file identity changed",
        ));
    }
    Ok(())
}

fn verify_payload_replay_path_identity(
    path: &Path,
    expected: PayloadReplayPathIdentityV1,
) -> Result<(), PayloadReplayErrorV1> {
    let metadata = fs::symlink_metadata(path)?;
    if metadata.file_type().is_symlink()
        || !metadata.is_file()
        || !private_file_mode(&metadata)
        || PayloadReplayPathIdentityV1::from_metadata(&metadata) != expected
    {
        return Err(PayloadReplayErrorV1::InvalidRequest(
            "payload replay authority path identity changed",
        ));
    }
    Ok(())
}

fn encode_record(
    frame: Option<&PayloadReplayFrameV1>,
    namespace: PayloadReplayNamespaceV1,
    namespace_digest: [u8; 32],
    index: u64,
    predecessor: [u8; 32],
) -> [u8; RECORD_BYTES_V1] {
    let mut bytes = Vec::with_capacity(RECORD_BYTES_V1);
    bytes.extend_from_slice(&LOG_MAGIC_V1);
    bytes.push(LOG_VERSION_V1);
    bytes.push(if frame.is_some() {
        LOG_FRAME_KIND_V1
    } else {
        LOG_GENESIS_KIND_V1
    });
    bytes.extend_from_slice(&[0, 0]);
    bytes.extend_from_slice(&index.to_be_bytes());
    bytes.extend_from_slice(&namespace_digest);
    bytes.extend_from_slice(&namespace.local_id());
    if let Some(frame) = frame {
        let scope = frame.scope;
        bytes.extend_from_slice(&scope.remote_id());
        bytes.push(scope.direction() as u8);
        bytes.extend_from_slice(&[0; 7]);
        bytes.extend_from_slice(&scope.epoch().to_be_bytes());
        bytes.extend_from_slice(&scope.peer_scope_id());
        bytes.extend_from_slice(&frame.run_id_hash);
        bytes.extend_from_slice(&frame.network_context_hash);
        bytes.extend_from_slice(&frame.session_id);
        bytes.extend_from_slice(&frame.generation.to_be_bytes());
        bytes.extend_from_slice(&frame.sequence.to_be_bytes());
        bytes.push(frame.frame_kind);
        bytes.extend_from_slice(&[0; 3]);
        bytes.extend_from_slice(&frame.payload_len.to_be_bytes());
        bytes.extend_from_slice(&frame.frame_fingerprint);
    } else {
        bytes.extend_from_slice(&[0; 32]); // remote
        bytes.push(0); // direction
        bytes.extend_from_slice(&[0; 7]);
        bytes.extend_from_slice(&namespace.epoch().to_be_bytes());
        bytes.extend_from_slice(&namespace.peer_scope_id());
        bytes.extend_from_slice(&namespace.run_id_hash());
        bytes.extend_from_slice(&namespace.network_context_hash());
        bytes.extend_from_slice(&[0; 32]); // session
        bytes.extend_from_slice(&0u64.to_be_bytes());
        bytes.extend_from_slice(&0u64.to_be_bytes());
        bytes.push(0);
        bytes.extend_from_slice(&[0; 3]);
        bytes.extend_from_slice(&0u32.to_be_bytes());
        bytes.extend_from_slice(&[0; 32]);
    }
    bytes.extend_from_slice(&predecessor);
    debug_assert_eq!(bytes.len(), RECORD_PREFIX_BYTES_V1);
    let digest = record_digest(&bytes);
    bytes.extend_from_slice(&digest);
    bytes.try_into().expect("fixed payload replay record")
}

fn record_digest(prefix: &[u8]) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(RECORD_DOMAIN_V1);
    hasher.update((prefix.len() as u64).to_be_bytes());
    hasher.update(prefix);
    hasher.finalize().into()
}

fn parse_log(
    bytes: &[u8],
    namespace: PayloadReplayNamespaceV1,
    namespace_digest: [u8; 32],
) -> Result<ReplaySnapshotV1, PayloadReplayErrorV1> {
    if bytes.is_empty() {
        return Err(PayloadReplayErrorV1::Truncated);
    }
    if bytes.len() as u64 > PAYLOAD_REPLAY_MAX_WAL_BYTES_V1 {
        return Err(PayloadReplayErrorV1::TooLarge);
    }
    if !bytes.len().is_multiple_of(RECORD_BYTES_V1) {
        return Err(PayloadReplayErrorV1::Truncated);
    }
    let count = bytes.len() / RECORD_BYTES_V1;
    if count == 0 || count as u64 > PAYLOAD_REPLAY_MAX_RECORDS_V1 {
        return Err(PayloadReplayErrorV1::TooLarge);
    }
    let mut states = BTreeMap::<PeerKeyV1, ReplayStateV1>::new();
    let mut seen_sessions = BTreeSet::<(PeerKeyV1, [u8; 32])>::new();
    let mut frame_receipts = BTreeMap::<ReplayFrameIdentityV1, PayloadReplayReceiptV1>::new();
    let mut frame_positions = BTreeMap::<ReplayFramePositionV1, ReplayFrameIdentityV1>::new();
    let mut last_hash = [0; 32];
    for (index, bytes) in bytes.chunks_exact(RECORD_BYTES_V1).enumerate() {
        let decoded = decode_record(bytes)?;
        if decoded.index != index as u64
            || decoded.namespace_digest != namespace_digest
            || decoded.local_id != namespace.local_id()
            || decoded.epoch != namespace.epoch()
            || decoded.peer_scope_id != namespace.peer_scope_id()
            || decoded.run_id_hash != namespace.run_id_hash()
            || decoded.network_context_hash != namespace.network_context_hash()
            || decoded.predecessor != last_hash
        {
            return Err(PayloadReplayErrorV1::ContextMismatch);
        }
        if index == 0 {
            if decoded.operation != LOG_GENESIS_KIND_V1
                || decoded.remote_id != [0; 32]
                || decoded.direction.is_some()
                || decoded.session_id != [0; 32]
                || decoded.generation != 0
                || decoded.sequence != 0
                || decoded.frame_kind != 0
                || decoded.payload_len != 0
                || decoded.frame_fingerprint != [0; 32]
                || decoded.predecessor != [0; 32]
            {
                return Err(PayloadReplayErrorV1::Corrupt);
            }
        } else {
            if decoded.operation != LOG_FRAME_KIND_V1 {
                return Err(PayloadReplayErrorV1::Corrupt);
            }
            let direction = decoded.direction.ok_or(PayloadReplayErrorV1::Corrupt)?;
            if decoded.remote_id == [0; 32]
                || decoded.remote_id == decoded.local_id
                || decoded.session_id == [0; 32]
                || decoded.generation == 0
                || decoded.frame_kind == 0
                || decoded.payload_len as usize > PAYLOAD_REPLAY_MAX_PAYLOAD_BYTES_V1
                || decoded.frame_fingerprint == [0; 32]
            {
                return Err(PayloadReplayErrorV1::Corrupt);
            }
            let key = PeerKeyV1 {
                remote_id: decoded.remote_id,
                direction,
            };
            let frame = PayloadReplayFrameV1 {
                scope: PeerLeaseScopeV1::new(
                    decoded.local_id,
                    decoded.remote_id,
                    direction,
                    decoded.epoch,
                    decoded.peer_scope_id,
                )
                .map_err(|_| PayloadReplayErrorV1::Corrupt)?,
                run_id_hash: decoded.run_id_hash,
                network_context_hash: decoded.network_context_hash,
                session_id: decoded.session_id,
                generation: decoded.generation,
                sequence: decoded.sequence,
                frame_kind: decoded.frame_kind,
                payload_len: decoded.payload_len,
                frame_fingerprint: decoded.frame_fingerprint,
            };
            let new_session = states
                .get(&key)
                .map(|state| state.session_id != frame.session_id)
                .unwrap_or(true);
            if new_session && !seen_sessions.insert((key, decoded.session_id)) {
                return Err(PayloadReplayErrorV1::Corrupt);
            }
            let next = preview_replayed_state(states.get(&key).copied(), frame)?;
            states.insert(key, next);
            let identity = ReplayFrameIdentityV1::from_frame(frame);
            let position = identity.position();
            if frame_positions.insert(position, identity).is_some()
                || frame_receipts
                    .insert(
                        identity,
                        PayloadReplayReceiptV1 {
                            record_index: index as u64,
                            record_hash: decoded.record_hash,
                        },
                    )
                    .is_some()
            {
                // `preview_replayed_state` already rejects duplicate sequence
                // positions. Keep this invariant explicit so a future record
                // schema change cannot silently overwrite an older receipt.
                return Err(PayloadReplayErrorV1::Corrupt);
            }
        }
        last_hash = decoded.record_hash;
    }
    Ok(ReplaySnapshotV1 {
        states,
        seen_sessions,
        frame_receipts,
        frame_positions,
        last_hash,
        record_count: count as u64,
    })
}

fn preview_replayed_state(
    previous: Option<ReplayStateV1>,
    frame: PayloadReplayFrameV1,
) -> Result<ReplayStateV1, PayloadReplayErrorV1> {
    match previous {
        None => {
            if frame.generation != 1 || frame.sequence != 0 {
                return Err(PayloadReplayErrorV1::Corrupt);
            }
        }
        Some(previous) if frame.generation == previous.generation => {
            if frame.session_id != previous.session_id
                || frame.sequence
                    != previous
                        .last_sequence
                        .checked_add(1)
                        .ok_or(PayloadReplayErrorV1::Corrupt)?
            {
                return Err(PayloadReplayErrorV1::Corrupt);
            }
        }
        Some(previous)
            if payload_replay_generation_successor_v1(previous.generation)
                == Some(frame.generation) =>
        {
            if frame.session_id == previous.session_id || frame.sequence != 0 {
                return Err(PayloadReplayErrorV1::Corrupt);
            }
        }
        Some(_) => return Err(PayloadReplayErrorV1::Corrupt),
    }
    Ok(ReplayStateV1 {
        session_id: frame.session_id,
        generation: frame.generation,
        last_sequence: frame.sequence,
        last_fingerprint: frame.frame_fingerprint,
    })
}

#[derive(Debug, Clone, Copy)]
struct DecodedRecordV1 {
    operation: u8,
    index: u64,
    namespace_digest: [u8; 32],
    local_id: [u8; 32],
    remote_id: [u8; 32],
    direction: Option<PeerLeaseDirectionV1>,
    epoch: u64,
    peer_scope_id: [u8; 32],
    run_id_hash: [u8; 32],
    network_context_hash: [u8; 32],
    session_id: [u8; 32],
    generation: u64,
    sequence: u64,
    frame_kind: u8,
    payload_len: u32,
    frame_fingerprint: [u8; 32],
    predecessor: [u8; 32],
    record_hash: [u8; 32],
}

fn decode_record(bytes: &[u8]) -> Result<DecodedRecordV1, PayloadReplayErrorV1> {
    if bytes.len() != RECORD_BYTES_V1 {
        return Err(PayloadReplayErrorV1::Truncated);
    }
    if bytes[..8] != LOG_MAGIC_V1 || bytes[8] != LOG_VERSION_V1 {
        return Err(PayloadReplayErrorV1::Corrupt);
    }
    if bytes[10..12] != [0, 0]
        || bytes[117..124].iter().any(|byte| *byte != 0)
        || bytes[277..280].iter().any(|byte| *byte != 0)
    {
        return Err(PayloadReplayErrorV1::Corrupt);
    }
    let stored: [u8; 32] = bytes[RECORD_PREFIX_BYTES_V1..]
        .try_into()
        .expect("fixed payload replay digest");
    if stored != record_digest(&bytes[..RECORD_PREFIX_BYTES_V1]) {
        return Err(PayloadReplayErrorV1::Corrupt);
    }
    let direction = match bytes[116] {
        0 => None,
        1 => Some(PeerLeaseDirectionV1::Outbound),
        2 => Some(PeerLeaseDirectionV1::Inbound),
        _ => return Err(PayloadReplayErrorV1::Corrupt),
    };
    Ok(DecodedRecordV1 {
        operation: bytes[9],
        index: u64::from_be_bytes(bytes[12..20].try_into().expect("record index")),
        namespace_digest: bytes[20..52].try_into().expect("namespace digest"),
        local_id: bytes[52..84].try_into().expect("local id"),
        remote_id: bytes[84..116].try_into().expect("remote id"),
        direction,
        epoch: u64::from_be_bytes(bytes[124..132].try_into().expect("epoch")),
        peer_scope_id: bytes[132..164].try_into().expect("validator set"),
        run_id_hash: bytes[164..196].try_into().expect("run hash"),
        network_context_hash: bytes[196..228].try_into().expect("network context"),
        session_id: bytes[228..260].try_into().expect("session"),
        generation: u64::from_be_bytes(bytes[260..268].try_into().expect("generation")),
        sequence: u64::from_be_bytes(bytes[268..276].try_into().expect("sequence")),
        frame_kind: bytes[276],
        payload_len: u32::from_be_bytes(bytes[280..284].try_into().expect("payload length")),
        frame_fingerprint: bytes[284..316].try_into().expect("frame fingerprint"),
        predecessor: bytes[316..348].try_into().expect("predecessor"),
        record_hash: stored,
    })
}

pub(crate) fn encode_head(
    record_count: u64,
    record_hash: [u8; 32],
    namespace_digest: [u8; 32],
) -> [u8; HEAD_BYTES_V1] {
    let mut bytes = Vec::with_capacity(HEAD_BYTES_V1);
    bytes.extend_from_slice(&HEAD_MAGIC_V1);
    bytes.push(HEAD_VERSION_V1);
    bytes.extend_from_slice(&[0; 3]);
    bytes.extend_from_slice(&record_count.to_be_bytes());
    bytes.extend_from_slice(&record_hash);
    bytes.extend_from_slice(&namespace_digest);
    let mut hasher = Sha256::new();
    hasher.update(HEAD_DOMAIN_V1);
    hasher.update((bytes.len() as u64).to_be_bytes());
    hasher.update(&bytes);
    bytes.extend_from_slice(&hasher.finalize());
    bytes.try_into().expect("fixed payload replay head")
}

pub(crate) fn decode_head(bytes: &[u8]) -> Result<(u64, [u8; 32], [u8; 32]), PayloadReplayErrorV1> {
    if bytes.len() != HEAD_BYTES_V1
        || bytes[..8] != HEAD_MAGIC_V1
        || bytes[8] != HEAD_VERSION_V1
        || bytes[9..12] != [0, 0, 0]
    {
        return Err(PayloadReplayErrorV1::Corrupt);
    }
    let mut hasher = Sha256::new();
    hasher.update(HEAD_DOMAIN_V1);
    hasher.update((HEAD_PREFIX_BYTES_V1 as u64).to_be_bytes());
    hasher.update(&bytes[..HEAD_PREFIX_BYTES_V1]);
    if bytes[HEAD_PREFIX_BYTES_V1..] != hasher.finalize()[..] {
        return Err(PayloadReplayErrorV1::Corrupt);
    }
    Ok((
        u64::from_be_bytes(bytes[12..20].try_into().expect("head count")),
        bytes[20..52].try_into().expect("head hash"),
        bytes[52..84].try_into().expect("head namespace"),
    ))
}

/// Read the fixed-size head through an `O_NOFOLLOW` descriptor and pin its
/// identity before allocating.  A private pathname alone is not enough: a
/// same-UID writer can replace it with an oversized file or a symlink between
/// metadata and `read_to_end`.
pub(crate) fn read_private_head(path: &Path) -> Result<Vec<u8>, PayloadReplayErrorV1> {
    let metadata = fs::symlink_metadata(path).map_err(PayloadReplayErrorV1::Io)?;
    if !metadata.is_file() || !private_file_mode(&metadata) {
        return Err(PayloadReplayErrorV1::InvalidRequest(
            "payload replay head path is not a private regular file",
        ));
    }
    if metadata.len() != HEAD_BYTES_V1 as u64 {
        return Err(PayloadReplayErrorV1::Corrupt);
    }
    let mut options = OpenOptions::new();
    options.read(true);
    #[cfg(unix)]
    options.custom_flags(libc::O_CLOEXEC | libc::O_NOFOLLOW);
    let mut file = options.open(path).map_err(PayloadReplayErrorV1::Io)?;
    validate_private_file(&file)?;
    #[cfg(unix)]
    {
        let descriptor = file.metadata().map_err(PayloadReplayErrorV1::Io)?;
        let named = fs::symlink_metadata(path).map_err(PayloadReplayErrorV1::Io)?;
        if descriptor.dev() != named.dev()
            || descriptor.ino() != named.ino()
            || descriptor.uid() != named.uid()
        {
            return Err(PayloadReplayErrorV1::InvalidRequest(
                "payload replay head descriptor/path identity changed",
            ));
        }
    }
    let mut bytes = Vec::with_capacity(HEAD_BYTES_V1);
    std::io::Read::by_ref(&mut file)
        .take(HEAD_BYTES_V1 as u64 + 1)
        .read_to_end(&mut bytes)
        .map_err(PayloadReplayErrorV1::Io)?;
    if bytes.len() != HEAD_BYTES_V1 {
        return Err(PayloadReplayErrorV1::Corrupt);
    }
    Ok(bytes)
}

pub(crate) fn persist_head(
    path: &Path,
    directory: &File,
    record_count: u64,
    record_hash: [u8; 32],
    namespace_digest: [u8; 32],
) -> Result<(), PayloadReplayErrorV1> {
    persist_head_with_identity(path, directory, record_count, record_hash, namespace_digest)
        .map(|_| ())
}

/// Publish a replay head and return the exact inode which was written.  The
/// identity is used by the live replay owner to distinguish its own atomic
/// replacement from a same-UID pathname substitution racing the rename.
fn persist_head_with_identity(
    path: &Path,
    directory: &File,
    record_count: u64,
    record_hash: [u8; 32],
    namespace_digest: [u8; 32],
) -> Result<PayloadReplayPathIdentityV1, PayloadReplayErrorV1> {
    let name = path.file_name().and_then(|value| value.to_str()).ok_or(
        PayloadReplayErrorV1::InvalidRequest("payload replay head filename"),
    )?;
    if let Ok(metadata) = fs::symlink_metadata(path) {
        if !metadata.is_file() || !private_file_mode(&metadata) {
            return Err(PayloadReplayErrorV1::InvalidRequest(
                "payload replay head is not private",
            ));
        }
    }
    let temporary = next_head_temp_path_v1(path, name, record_count);
    let result = (|| {
        let mut options = OpenOptions::new();
        options.write(true).create_new(true);
        set_private_mode_options(&mut options);
        let mut file = options.open(&temporary)?;
        file.write_all(&encode_head(record_count, record_hash, namespace_digest))?;
        file.sync_all()?;
        let replacement_identity = PayloadReplayPathIdentityV1::from_metadata(&file.metadata()?);
        fs::rename(&temporary, path)?;
        let published = fs::symlink_metadata(path)?;
        if published.file_type().is_symlink()
            || !published.is_file()
            || !private_file_mode(&published)
            || PayloadReplayPathIdentityV1::from_metadata(&published) != replacement_identity
        {
            return Err(io::Error::other(
                "payload replay head descriptor/path identity changed",
            ));
        }
        directory.sync_all()?;
        Ok::<PayloadReplayPathIdentityV1, io::Error>(replacement_identity)
    })();
    match result {
        Ok(identity) => Ok(identity),
        Err(error) => {
            // Do not unlink the temporary by pathname after a failed
            // create/write operation: a same-UID process could have replaced
            // it.  Retaining the stale name preserves recovery evidence for
            // an explicit owner; normal retries use a fresh process-local
            // nonce.
            Err(PayloadReplayErrorV1::Io(error))
        }
    }
}

pub(crate) fn sidecar_path(path: &Path, suffix: &str) -> Result<PathBuf, PayloadReplayErrorV1> {
    let name = path.file_name().and_then(|value| value.to_str()).ok_or(
        PayloadReplayErrorV1::InvalidRequest("payload replay path filename"),
    )?;
    Ok(path.with_file_name(format!(".{name}.{suffix}")))
}

/// Failed head publications are retained for an explicit recovery owner.
/// Refuse to treat one as invisible on restart: otherwise PID reuse or a
/// stale pathname can turn a response-loss cut into a permanent liveness or
/// replay ambiguity.
pub(crate) fn reject_stale_head_temps(path: &Path) -> Result<(), PayloadReplayErrorV1> {
    let parent = path.parent().ok_or(PayloadReplayErrorV1::InvalidRequest(
        "payload replay path has no parent",
    ))?;
    let head_path = sidecar_path(path, "head-v1")?;
    let head_name = head_path
        .file_name()
        .and_then(|value| value.to_str())
        .ok_or(PayloadReplayErrorV1::InvalidRequest(
            "payload replay head filename",
        ))?;
    let prefix = format!(".{head_name}.tmp-");
    let mut scanned = 0_usize;
    for entry in fs::read_dir(parent).map_err(PayloadReplayErrorV1::Io)? {
        scanned = scanned
            .checked_add(1)
            .ok_or(PayloadReplayErrorV1::TooLarge)?;
        if scanned > PAYLOAD_REPLAY_MAX_TEMPORARY_SCAN_ENTRIES_V1 {
            return Err(PayloadReplayErrorV1::TooLarge);
        }
        let entry = entry.map_err(PayloadReplayErrorV1::Io)?;
        if entry
            .file_name()
            .to_str()
            .is_some_and(|value| value.starts_with(&prefix))
        {
            return Err(PayloadReplayErrorV1::Corrupt);
        }
    }
    Ok(())
}

pub(crate) fn private_parent(path: &Path) -> Result<(File, PathBuf), PayloadReplayErrorV1> {
    let parent = path
        .parent()
        .ok_or(PayloadReplayErrorV1::InvalidRequest(
            "payload replay path has no parent",
        ))?
        .to_path_buf();
    let metadata = fs::symlink_metadata(&parent).map_err(PayloadReplayErrorV1::Io)?;
    if metadata.file_type().is_symlink() {
        return Err(PayloadReplayErrorV1::InvalidRequest(
            "payload replay parent directory is a symlink alias",
        ));
    }
    if !metadata.is_dir() || !private_parent_mode(&metadata) {
        return Err(PayloadReplayErrorV1::InvalidRequest(
            "payload replay parent directory is not private",
        ));
    }
    if fs::canonicalize(&parent).map_err(PayloadReplayErrorV1::Io)? != parent {
        return Err(PayloadReplayErrorV1::InvalidRequest(
            "payload replay parent directory is a symlink alias",
        ));
    }
    ensure_private_directory(&parent).map_err(|error| match error {
        crate::PeerLeaseErrorV1::InvalidRequest(reason)
        | crate::PeerLeaseErrorV1::Protocol(reason) => PayloadReplayErrorV1::InvalidRequest(reason),
        crate::PeerLeaseErrorV1::Io(error) => PayloadReplayErrorV1::Io(error),
        crate::PeerLeaseErrorV1::Rejected(_) => {
            PayloadReplayErrorV1::InvalidRequest("payload replay parent ancestry is not private")
        }
    })?;
    let directory = File::open(&parent).map_err(PayloadReplayErrorV1::Io)?;
    Ok((directory, parent))
}

pub(crate) fn open_private_lock(path: &Path) -> Result<File, PayloadReplayErrorV1> {
    let mut options = OpenOptions::new();
    options.read(true).write(true).create(true);
    set_private_mode_options(&mut options);
    let file = options.open(path).map_err(PayloadReplayErrorV1::Io)?;
    validate_private_file(&file)?;
    Ok(file)
}

pub(crate) fn validate_private_file(file: &File) -> Result<(), PayloadReplayErrorV1> {
    let metadata = file.metadata().map_err(PayloadReplayErrorV1::Io)?;
    if !metadata.is_file() || !private_file_mode(&metadata) {
        return Err(PayloadReplayErrorV1::InvalidRequest(
            "payload replay file is not a private single-link regular file",
        ));
    }
    Ok(())
}

pub(crate) fn set_private_mode(file: &File) -> Result<(), PayloadReplayErrorV1> {
    #[cfg(unix)]
    {
        file.set_permissions(fs::Permissions::from_mode(PRIVATE_MODE_V1))
            .map_err(PayloadReplayErrorV1::Io)
    }
    #[cfg(not(unix))]
    {
        let _ = file;
        Ok(())
    }
}

pub(crate) fn set_private_mode_options(options: &mut OpenOptions) {
    #[cfg(unix)]
    {
        options.mode(PRIVATE_MODE_V1);
        options.custom_flags(libc::O_CLOEXEC | libc::O_NOFOLLOW);
    }
}

pub(crate) fn private_parent_mode(metadata: &fs::Metadata) -> bool {
    #[cfg(unix)]
    {
        metadata.permissions().mode() & 0o077 == 0
    }
    #[cfg(not(unix))]
    {
        let _ = metadata;
        true
    }
}

pub(crate) fn private_file_mode(metadata: &fs::Metadata) -> bool {
    #[cfg(unix)]
    {
        metadata.nlink() == 1
            && metadata.permissions().mode() & 0o7777 == PRIVATE_MODE_V1
            && metadata.uid() == rustix::process::geteuid().as_raw()
    }
    #[cfg(not(unix))]
    {
        let _ = metadata;
        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use tempfile::TempDir;

    fn namespace() -> PayloadReplayNamespaceV1 {
        PayloadReplayNamespaceV1::new([1; 32], 7, [2; 32], [3; 32], [4; 32]).unwrap()
    }

    fn frame(
        ns: PayloadReplayNamespaceV1,
        remote: [u8; 32],
        direction: PayloadReplayDirectionV1,
        session: [u8; 32],
        generation: u64,
        sequence: u64,
        fingerprint: [u8; 32],
    ) -> PayloadReplayFrameV1 {
        PayloadReplayFrameV1::new(
            ns.scope_for(remote, direction).unwrap(),
            ns.run_id_hash(),
            ns.network_context_hash(),
            session,
            generation,
            sequence,
            2,
            11,
            fingerprint,
        )
        .unwrap()
    }

    fn private_tempdir() -> TempDir {
        let directory = tempfile::Builder::new()
            .prefix("trnm-payload-replay-")
            .tempdir()
            .unwrap();
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            fs::set_permissions(directory.path(), fs::Permissions::from_mode(0o700)).unwrap();
        }
        directory
    }

    #[cfg(unix)]
    #[test]
    fn directory_owner_survives_child_publication_and_reopen_v1() {
        let dir = private_tempdir();
        let root = dir.path().canonicalize().unwrap();
        let path = root.join("frames.wal");
        let ns = namespace();
        let mut store = PayloadReplayStoreV1::open(&path, ns).unwrap();
        let first = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            0,
            [10; 32],
        );
        let receipt = store.admit(&first).unwrap();
        // Directory link counts are content metadata (including ordinary files
        // on APFS), not the identity of the pinned parent namespace.
        let child = root.join("independent-owner");
        fs::create_dir(&child).unwrap();
        fs::set_permissions(&child, fs::Permissions::from_mode(0o700)).unwrap();
        fs::write(child.join("data"), b"unrelated child").unwrap();
        assert_eq!(store.lookup_exact_v1(&first).unwrap(), Some(receipt));
        fs::remove_file(child.join("data")).unwrap();
        fs::remove_dir(&child).unwrap();
        let next = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            1,
            [11; 32],
        );
        store.admit(&next).unwrap();
        drop(store);
        let mut reopened = PayloadReplayStoreV1::open(&path, ns).unwrap();
        assert_eq!(reopened.lookup_exact_v1(&first).unwrap(), Some(receipt));
        assert!(matches!(
            reopened.admit(&next),
            Err(PayloadReplayErrorV1::Replay)
        ));
    }

    #[test]
    fn generation_and_sequence_are_durable_and_strict() {
        let dir = private_tempdir();
        let path = dir.path().join("frames.wal");
        let ns = namespace();
        let mut store = PayloadReplayStoreV1::open(&path, ns).unwrap();
        let first = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            0,
            [10; 32],
        );
        let second = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            1,
            [11; 32],
        );
        store.admit(&first).unwrap();
        store.admit(&second).unwrap();
        assert!(matches!(
            store.admit(&second),
            Err(PayloadReplayErrorV1::Replay)
        ));
        let gap = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            3,
            [12; 32],
        );
        assert!(matches!(
            store.admit(&gap),
            Err(PayloadReplayErrorV1::SequenceGap)
        ));
        drop(store);
        let mut reopened = PayloadReplayStoreV1::open(&path, ns).unwrap();
        assert_eq!(reopened.accepted_frame_count(), 2);
        let next = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [6; 32],
            2,
            0,
            [13; 32],
        );
        reopened.admit(&next).unwrap();
        assert_eq!(
            reopened.latest_generation([9; 32], PeerLeaseDirectionV1::Inbound),
            Some(2)
        );
        let old = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            2,
            [14; 32],
        );
        assert!(matches!(
            reopened.admit(&old),
            Err(PayloadReplayErrorV1::Replay)
        ));
    }

    #[test]
    fn generation_successor_fails_closed_at_u64_max() {
        assert_eq!(
            payload_replay_generation_successor_v1(u64::MAX - 1),
            Some(u64::MAX)
        );
        assert_eq!(payload_replay_generation_successor_v1(u64::MAX), None);

        let ns = namespace();
        let previous = ReplayStateV1 {
            session_id: [5; 32],
            generation: u64::MAX,
            last_sequence: 0,
            last_fingerprint: [10; 32],
        };
        let rollover = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [6; 32],
            u64::MAX,
            0,
            [11; 32],
        );
        assert!(matches!(
            preview_replayed_state(Some(previous), rollover),
            Err(PayloadReplayErrorV1::Corrupt)
        ));
    }

    #[test]
    fn oversized_payload_wal_is_rejected_before_snapshot_allocation() {
        let dir = private_tempdir();
        let path = dir.path().join("oversized-frames.wal");
        let oversized_length = PAYLOAD_REPLAY_MAX_WAL_BYTES_V1 + 1;
        let file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&path)
            .unwrap();
        file.set_len(oversized_length).unwrap();
        file.sync_all().unwrap();
        drop(file);
        #[cfg(unix)]
        use std::os::unix::fs::PermissionsExt;
        #[cfg(unix)]
        fs::set_permissions(&path, fs::Permissions::from_mode(0o600)).unwrap();
        let head = sidecar_path(&path, "head-v1").unwrap();
        fs::write(&head, vec![0_u8; HEAD_BYTES_V1]).unwrap();
        #[cfg(unix)]
        fs::set_permissions(&head, fs::Permissions::from_mode(0o600)).unwrap();

        assert!(matches!(
            PayloadReplayStoreV1::open(&path, namespace()),
            Err(PayloadReplayErrorV1::TooLarge)
        ));
        assert_eq!(fs::metadata(&path).unwrap().len(), oversized_length);
    }

    #[test]
    fn stale_head_scan_is_bounded_before_directory_fanout() {
        let dir = private_tempdir();
        let path = dir.path().join("frames.wal");
        for index in 0..=PAYLOAD_REPLAY_MAX_TEMPORARY_SCAN_ENTRIES_V1 {
            fs::write(dir.path().join(format!("unrelated-{index}")), b"x").unwrap();
        }
        assert!(matches!(
            reject_stale_head_temps(&path),
            Err(PayloadReplayErrorV1::TooLarge)
        ));
    }

    #[test]
    fn exact_lookup_recovers_receipt_across_reopen_and_rejects_slot_conflicts() {
        let dir = private_tempdir();
        let path = dir.path().join("frames.wal");
        let ns = namespace();
        let first = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            0,
            [10; 32],
        );
        let second = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            1,
            [11; 32],
        );
        let conflicting = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            0,
            [99; 32],
        );

        let mut store = PayloadReplayStoreV1::open(&path, ns).unwrap();
        let first_receipt = store.admit(&first).unwrap();
        let second_receipt = store.admit(&second).unwrap();
        let before_count = store.record_count();
        let before_hash = store.last_hash();
        assert_eq!(store.lookup_exact_v1(&first).unwrap(), Some(first_receipt));
        assert_eq!(
            store.lookup_exact_v1(&second).unwrap(),
            Some(second_receipt)
        );
        assert_eq!(store.record_count(), before_count);
        assert_eq!(store.last_hash(), before_hash);
        assert!(matches!(
            store.lookup_exact_v1(&conflicting),
            Err(PayloadReplayErrorV1::Replay)
        ));
        let unseen = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            2,
            [12; 32],
        );
        assert_eq!(store.lookup_exact_v1(&unseen).unwrap(), None);
        drop(store);

        let mut reopened = PayloadReplayStoreV1::open(&path, ns).unwrap();
        assert_eq!(
            reopened.lookup_exact_v1(&first).unwrap(),
            Some(first_receipt)
        );
        assert_eq!(
            reopened.lookup_exact_v1(&second).unwrap(),
            Some(second_receipt)
        );
        assert!(matches!(
            reopened.lookup_exact_v1(&conflicting),
            Err(PayloadReplayErrorV1::Replay)
        ));
    }

    #[test]
    fn exact_lookup_checks_context_before_index_and_poisoned_head() {
        let dir = private_tempdir();
        let path = dir.path().join("frames.wal");
        let ns = namespace();
        let first = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            0,
            [10; 32],
        );
        let mut store = PayloadReplayStoreV1::open(&path, ns).unwrap();
        let receipt = store.admit(&first).unwrap();
        let wrong_context = PayloadReplayFrameV1::new(
            ns.scope_for([9; 32], PeerLeaseDirectionV1::Inbound)
                .unwrap(),
            [8; 32],
            ns.network_context_hash(),
            first.session_id(),
            first.generation(),
            first.sequence(),
            first.frame_kind(),
            first.payload_len() as usize,
            first.frame_fingerprint(),
        )
        .unwrap();
        assert!(matches!(
            store.lookup_exact_v1(&wrong_context),
            Err(PayloadReplayErrorV1::ContextMismatch)
        ));
        assert_eq!(store.lookup_exact_v1(&first).unwrap(), Some(receipt));

        let head = fs::read(store.head_path()).unwrap();
        let mut tampered = head;
        tampered[20] ^= 1;
        fs::write(store.head_path(), tampered).unwrap();
        assert!(matches!(
            store.lookup_exact_v1(&first),
            Err(PayloadReplayErrorV1::Corrupt)
        ));
        assert!(matches!(
            store.lookup_exact_v1(&first),
            Err(PayloadReplayErrorV1::Poisoned)
        ));
    }

    #[test]
    fn truncation_mutation_and_prefix_sidecar_fail_closed() {
        let dir = private_tempdir();
        let path = dir.path().join("frames.wal");
        let ns = namespace();
        let mut store = PayloadReplayStoreV1::open(&path, ns).unwrap();
        store
            .admit(&frame(
                ns,
                [9; 32],
                PeerLeaseDirectionV1::Outbound,
                [5; 32],
                1,
                0,
                [10; 32],
            ))
            .unwrap();
        store
            .admit(&frame(
                ns,
                [9; 32],
                PeerLeaseDirectionV1::Outbound,
                [5; 32],
                1,
                1,
                [11; 32],
            ))
            .unwrap();
        drop(store);

        let original = fs::read(&path).unwrap();
        fs::write(&path, &original[..original.len() - RECORD_BYTES_V1]).unwrap();
        assert!(matches!(
            PayloadReplayStoreV1::open(&path, ns),
            Err(PayloadReplayErrorV1::Corrupt) | Err(PayloadReplayErrorV1::Truncated)
        ));
        fs::write(&path, &original).unwrap();
        let mut mutated = original.clone();
        mutated[RECORD_PREFIX_BYTES_V1 + 4] ^= 1;
        fs::write(&path, mutated).unwrap();
        assert!(matches!(
            PayloadReplayStoreV1::open(&path, ns),
            Err(PayloadReplayErrorV1::Corrupt)
        ));
        fs::write(&path, &original).unwrap();
        let mut prefix_head = fs::read(dir.path().join(".frames.wal.head-v1")).unwrap();
        prefix_head[12..20].copy_from_slice(&2u64.to_be_bytes());
        fs::write(dir.path().join(".frames.wal.head-v1"), prefix_head).unwrap();
        assert!(matches!(
            PayloadReplayStoreV1::open(&path, ns),
            Err(PayloadReplayErrorV1::Corrupt)
        ));
    }

    #[test]
    fn context_and_direction_are_part_of_the_fence() {
        let dir = private_tempdir();
        let path = dir.path().join("frames.wal");
        let ns = namespace();
        let mut store = PayloadReplayStoreV1::open(&path, ns).unwrap();
        let wrong_scope =
            PayloadReplayNamespaceV1::new([8; 32], 7, [2; 32], [3; 32], [4; 32]).unwrap();
        let wrong = frame(
            wrong_scope,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            0,
            [10; 32],
        );
        assert!(matches!(
            store.admit(&wrong),
            Err(PayloadReplayErrorV1::ContextMismatch)
        ));
        let inbound = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            0,
            [11; 32],
        );
        let outbound = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Outbound,
            [5; 32],
            1,
            0,
            [12; 32],
        );
        store.admit(&inbound).unwrap();
        store.admit(&outbound).unwrap();
        assert!(store.contains_session([9; 32], PeerLeaseDirectionV1::Inbound, [5; 32]));
        assert!(store.contains_session([9; 32], PeerLeaseDirectionV1::Outbound, [5; 32]));
    }

    #[test]
    fn head_temp_paths_use_a_process_nonce() {
        let path = Path::new("/tmp/frames.head-v1");
        let first = next_head_temp_path_v1(path, "frames.head-v1", 2);
        let second = next_head_temp_path_v1(path, "frames.head-v1", 2);
        assert_ne!(first, second);
    }

    #[test]
    fn stale_head_publication_requires_recovery() {
        let root = tempfile::tempdir().expect("temporary parent");
        #[cfg(unix)]
        fs::set_permissions(root.path(), fs::Permissions::from_mode(0o700))
            .expect("private parent");
        let path = root.path().join("frames.wal");
        let head = sidecar_path(&path, "head-v1").expect("head path");
        let name = head.file_name().and_then(|value| value.to_str()).unwrap();
        let temporary = next_head_temp_path_v1(&head, name, 0);
        fs::write(&temporary, b"retained").expect("retained head evidence");
        assert!(matches!(
            PayloadReplayStoreV1::open(&path, namespace()),
            Err(PayloadReplayErrorV1::Corrupt)
        ));
    }

    #[cfg(unix)]
    #[test]
    fn private_file_validation_rejects_directories_and_symlink_aliased_parents() {
        use std::os::unix::fs::{symlink, PermissionsExt};

        let dir = private_tempdir();
        let directory_file = File::open(dir.path()).expect("directory can be opened on Unix");
        assert!(matches!(
            validate_private_file(&directory_file),
            Err(PayloadReplayErrorV1::InvalidRequest(reason))
                if reason.contains("regular file")
        ));

        let real = dir.path().join("real");
        fs::create_dir(&real).expect("real parent");
        fs::set_permissions(&real, fs::Permissions::from_mode(0o700)).unwrap();
        let alias = dir.path().join("alias");
        symlink(&real, &alias).expect("parent alias");
        let aliased_path = alias.join("frames.wal");
        assert!(matches!(
            PayloadReplayStoreV1::open(&aliased_path, namespace()),
            Err(PayloadReplayErrorV1::InvalidRequest(reason))
                if reason.contains("symlink alias")
        ));
    }

    #[cfg(unix)]
    #[test]
    fn endpoint_identity_rejects_wal_replacement_before_lookup() {
        use std::os::unix::fs::PermissionsExt;

        let dir = private_tempdir();
        let path = dir.path().join("frames.wal");
        let ns = namespace();
        let first = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            0,
            [10; 32],
        );
        let mut store = PayloadReplayStoreV1::open(&path, ns).unwrap();
        store.admit(&first).unwrap();

        // Keep the original descriptor (and lock) alive, then substitute a
        // same-shaped private file at the authority pathname.  The next
        // operation must fence on dev/inode identity before consulting the
        // in-memory receipt index.
        let displaced = dir.path().join("frames.displaced");
        fs::rename(&path, &displaced).unwrap();
        fs::write(&path, fs::read(&displaced).unwrap()).unwrap();
        fs::set_permissions(&path, fs::Permissions::from_mode(0o600)).unwrap();
        assert!(matches!(
            store.lookup_exact_v1(&first),
            Err(PayloadReplayErrorV1::InvalidRequest(reason))
                if reason.contains("identity")
        ));
    }

    #[cfg(unix)]
    #[test]
    fn endpoint_identity_rejects_lookup_slot_conflict() {
        use std::os::unix::fs::PermissionsExt;

        let dir = private_tempdir();
        let path = dir.path().join("frames.wal");
        let ns = namespace();
        let admitted = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            0,
            [10; 32],
        );
        let conflicting = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            0,
            [99; 32],
        );
        let mut store = PayloadReplayStoreV1::open(&path, ns).unwrap();
        store.admit(&admitted).unwrap();

        // A slot conflict would ordinarily be reported as Replay.  Once the
        // journal pathname no longer names the descriptor captured at open,
        // the endpoint fence must win on every lookup result path.
        let displaced = dir.path().join("frames.conflict.displaced");
        fs::rename(&path, &displaced).unwrap();
        fs::write(&path, fs::read(&displaced).unwrap()).unwrap();
        fs::set_permissions(&path, fs::Permissions::from_mode(0o600)).unwrap();
        assert!(matches!(
            store.lookup_exact_v1(&conflicting),
            Err(PayloadReplayErrorV1::InvalidRequest(reason))
                if reason.contains("identity")
        ));
    }

    #[cfg(unix)]
    #[test]
    fn endpoint_identity_rejects_head_and_lock_replacement_before_admit() {
        use std::os::unix::fs::PermissionsExt;

        let dir = private_tempdir();
        let path = dir.path().join("frames.wal");
        let ns = namespace();
        let first = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            0,
            [10; 32],
        );
        let second = frame(
            ns,
            [9; 32],
            PeerLeaseDirectionV1::Inbound,
            [5; 32],
            1,
            1,
            [11; 32],
        );
        let mut store = PayloadReplayStoreV1::open(&path, ns).unwrap();
        store.admit(&first).unwrap();

        let head = store.head_path().to_path_buf();
        let displaced_head = dir.path().join("frames.head.displaced");
        fs::rename(&head, &displaced_head).unwrap();
        fs::write(&head, fs::read(&displaced_head).unwrap()).unwrap();
        fs::set_permissions(&head, fs::Permissions::from_mode(0o600)).unwrap();
        assert!(matches!(
            store.admit(&second),
            Err(PayloadReplayErrorV1::InvalidRequest(reason))
                if reason.contains("identity")
        ));

        // Reopen a fresh owner and perform the same deterministic substitution
        // on the lock sidecar.  The held lock descriptor must not allow a
        // pathname replacement to go unnoticed.
        drop(store);
        let mut reopened = PayloadReplayStoreV1::open(&path, ns).unwrap();
        let lock = path.with_file_name(".frames.wal.lock-v1");
        let displaced_lock = dir.path().join("frames.lock.displaced");
        fs::rename(&lock, &displaced_lock).unwrap();
        fs::write(&lock, fs::read(&displaced_lock).unwrap()).unwrap();
        fs::set_permissions(&lock, fs::Permissions::from_mode(0o600)).unwrap();
        assert!(matches!(
            reopened.lookup_exact_v1(&first),
            Err(PayloadReplayErrorV1::InvalidRequest(reason))
                if reason.contains("identity")
        ));
    }

    #[test]
    fn post_append_failures_have_an_explicit_ambiguous_commit_marker() {
        let error = PayloadReplayErrorV1::CommitAmbiguous(Box::new(PayloadReplayErrorV1::Io(
            io::Error::new(io::ErrorKind::Interrupted, "directory sync interrupted"),
        )));
        assert!(error.commit_ambiguous());
        assert!(std::error::Error::source(&error).is_some());
        assert!(error
            .to_string()
            .contains("payload replay commit outcome is ambiguous"));
        assert!(!PayloadReplayErrorV1::Replay.commit_ambiguous());
    }
}
