from pathlib import Path
import json,sys
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'next-source-inspection-17';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
paths=['trillionnium/crates/trnm-pon-node/src/host_kernel_parent.rs','trillionnium/crates/trnm-pon-node/src/store/native_authenticated.rs']
for name in paths:
 lines=(src/name).read_text().splitlines();rows=[{'line':i+1,'text':x} for i,x in enumerate(lines) if any(v in x for v in ('fn ','mod ','checkpoint','fstat','read_to','read_exact','progress()'))];(out/(Path(name).name+'.outline.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'file':name,'rows':rows}))
