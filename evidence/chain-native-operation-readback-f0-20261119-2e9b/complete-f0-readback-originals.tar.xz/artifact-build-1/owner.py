from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,tarfile,io,shutil,time,resource,sys,traceback
root=Path('/home/qian-qi/work/chain-native-operation-readback-f0-20261119-2e9b');out=root/'artifact-build-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
pub=root/'publication-1';pub.mkdir(exist_ok=False);start=time.monotonic();before=resource.getrusage(resource.RUSAGE_SELF)
res={'schema':'chain-original-f0-complete-evidence-build-v1','head':'3db79eb2682ba3bcbbf33557c5eee3b67731028f','complete':False}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,obj):
 with path.open('x') as f:json.dump(obj,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
def copy(src,dst):
 raw=src.read_bytes()
 with dst.open('xb') as f:f.write(raw)
 return {'path':dst.name,'bytes':len(raw),'sha256':sha(raw),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()}
try:
 for attempt in range(150):
  blob=json.loads((root/'zip-git-blob-1/RESULT.json').read_text())
  if blob.get('error'):raise RuntimeError('original ZIP publication failed: '+blob['error'])
  if blob['complete'] is True:break
  if attempt%15==0:print(json.dumps({'waiting_for_exact_zip_blob':True,'checks':attempt}),flush=True)
  time.sleep(2)
 else:raise RuntimeError('existing ZIP upload still running; never repeated')
 snapshot=json.loads((root/'automatic-ci-at-f0-1/SNAPSHOT.json').read_text())
 assert snapshot['head']==res['head'] and snapshot['complete_job_denominators'] is True and snapshot['all_observed_failed_job_logs_retained'] is True
 readback=json.loads((root/'f0-independent-readback.json').read_text())
 assert readback['head']==res['head'] and readback['business_pass'] is False and readback['confirmed_in_original_thirty_second_phases']==1 and readback['four_second_slo_successes']==0
 cp=json.loads((root/'current-cost-profile.json').read_text())['run'];timing=json.loads((root/'collection/timing.stdout').read_text())
 assert len(snapshot['runs'])==26 and sum(r['run']['event']!='workflow_dispatch' for r in snapshot['runs'])==25
 failures=[{'run_id':r['run']['id'],'run_name':r['run']['name'],**log} for r in snapshot['runs'] for log in r['failed_job_log_requests']]
 cost={'schema':'chain-original-operation-f0-cost-summary-v1','head':res['head'],'run_id':readback['run_id'],'scope':'observed original phase/import CPU and wall intervals; nested measurements overlap and must not be added','original_credits_and_windows_changed':False,'full_physical_cost_closed':False,'provider':timing,'provider_zero_billable_values_do_not_mean_zero_cost':True,'phases':[],'unknown_cost_dimensions':readback['unknown_cost_dimensions']}
 for p in cp['phases']:
  cost['phases'].append({k:p[k] for k in ['phase','observed_imports','history_client_cpu','history_host_cpu_nested','history_host_calls','whole_public_phase_cpu_ns','whole_public_phase_wall_ns','final_actual_cpu_credit_flow','original_controller_cgroup_resources']})
 cost['readback_execution']=json.loads((root/'readback-execution-1/RESULT.json').read_text())
 cost['ci_snapshot_aggregate']={k:snapshot[k] for k in ['total_wall_seconds','aggregate_child_user_cpu_seconds','aggregate_child_system_cpu_seconds','ended_utc']}
 cost['git_zip_publication']={k:blob[k] for k in ['post_count','bytes','sha256','expected_git_blob','exit_code','wall_seconds','child_user_cpu_seconds','child_system_cpu_seconds']}
 write(pub/'cost-summary.json',cost)
 source_map=[
  ('f0-independent-readback.json','f0-independent-readback.json'),('current-cost-profile.json','current-cost-profile.json'),
  ('automatic-ci-at-f0-1/SNAPSHOT.json','automatic-ci-snapshot.json'),('analysis-1/current-bottleneck.json','measured-bottleneck-comparison.json'),
  ('f0-readback.py','f0-readback.py'),('READERS_CONFIGS.json','READERS_CONFIGS.json'),('prior-f0-readback.py','prior-f0-readback.py'),('prior-cost-profile.py','prior-cost-profile.py'),
  ('collection/COLLECTION.json','COLLECTION.json'),('readback-execution-1/RESULT.json','readback-execution.json'),('readers-preparation-1/RESULT.json','readers-preparation.json'),
  ('dispatch-1/RESULT.json','single-dispatch.json'),('zip-git-blob-1/RESULT.json','zip-git-publication.json')]
 for origin,dest in source_map:copy(root/origin,pub/dest)
 write(pub/'failed-jobs-at-snapshot.json',{'head':res['head'],'complete_run_denominator':26,'automatic_run_denominator':25,'job_denominator':sum(len(r['jobs']['items']) for r in snapshot['runs']),'failed_job_log_count':len(failures),'all_final':snapshot['all_final'],'observed_at_roster_utc':snapshot['requests'][0]['started_utc'],'pending_run_ids_at_roster':snapshot.get('snapshot_pending_run_ids'),'all_observed_failures':failures})
 originals=[]
 for d in ['dispatch-1','collection','readers-preparation-1','readers-source','readback-execution-1','analysis-1','automatic-ci-at-f0-1','zip-git-blob-1']:
  for p in sorted((root/d).rglob('*')):
   if not p.is_file():continue
   rel=p.relative_to(root).as_posix()
   if p.is_symlink():raise RuntimeError('unexpected symlink '+rel)
   if rel.startswith('collection/artifact-') or rel=='zip-git-blob-1/blob-request.json':continue
   originals.append((rel,p.read_bytes()))
 for name in ['f0-readback.py','READERS_CONFIGS.json','prior-f0-readback.py','prior-cost-profile.py','f0-independent-readback.json','current-cost-profile.json']:
  originals.append((name,(root/name).read_bytes()))
 originals.sort();assert len(originals)==len({n for n,_ in originals})
 rows=[{'path':name,'bytes':len(raw),'sha256':sha(raw)} for name,raw in originals]
 archive=pub/'complete-f0-readback-originals.tar.xz'
 with tarfile.open(archive,'x:xz',format=tarfile.PAX_FORMAT) as tar:
  for name,raw in originals:
   item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;item.mtime=0;item.uid=0;item.gid=0;tar.addfile(item,io.BytesIO(raw))
 with tarfile.open(archive,'r:xz') as tar:
  entries=tar.getmembers();assert len(entries)==len(rows)
  for expected,entry in zip(rows,entries):
   actual=tar.extractfile(entry).read();assert entry.name==expected['path'] and len(actual)==expected['bytes'] and sha(actual)==expected['sha256']
 req=root/'zip-git-blob-1/blob-request.json'
 write(pub/'archive-index.json',{'members':rows,'all_members_independently_verified':True,'original_f0_zip_stored_separately':{'path':'f0-original.zip','bytes':blob['bytes'],'sha256':blob['sha256'],'git_blob':blob['expected_git_blob']},'duplicate_encoded_zip_request_not_in_tar':{'source_path':str(req),'bytes':req.stat().st_size,'sha256':sha(req.read_bytes()),'reason':'lossless base64 re-encoding of the separately retained original ZIP; exact request remains at owned source path'},'live_final_ci_collector_not_snapshotted':str(root/'automatic-ci-1'),'scope':'all completed original transport/readback/source/configs and full CI timepoint metadata/failed logs, plus the original full ZIP stored separately; no claim all automatic workflows are final'})
 totaljobs=sum(len(r['jobs']['items']) for r in snapshot['runs']);pending=len(snapshot.get('snapshot_pending_run_ids',[]))
 readme=f"""# Original F0 readback: operation-scoped completed graph candidate

## Actual outcome

The sole F0 run is 44451798839, attempt 1, against source 3db79eb2682ba3bcbbf33557c5eee3b67731028f (tree 4877dd4e945841e734a57234e89fb1eb0440805e), Draft #968. This evidence commit does not replace that tested source identity.

The original 30-second phases confirmed **1/6** scheduled rounds; the original four-second target passed **0/6**. Timely network ACK exposure was **17/42**. The actual native test exited **101**. The unchanged original readers refused BASELINE_MUST_PASS, F0_ALL_SIX_SCHEDULED_FOUR_SECOND_TARGETS_REQUIRED, and NUMERIC_DEPLETION_REQUIRED. All seven preparation controls passed and owned cleanup was known empty. None of these preparation/cleanup results qualifies business success.

The original 42-packet and six-round denominators include all failed and unattempted work. The first baseline confirmation completed 21.612150435 seconds after its scheduled offset; baseline round 2 and ROOT rounds 1 and 2 were unattempted. ROOT completed no independent-client History import. The original windows, credits, worker/queue limits, fixed snapshot bound and original 512-attempt CPU assertion are unchanged.

## Evidence identity and independent readback

The original provider ZIP is 17,640,478 bytes, SHA-256 744a0d353fb5055fd111cb5acae33259c0e526a8e4240a8f33752d01bfac5ccd. Its provider digest matched. All 444 ZIP members were safely retained; all 443 manifest-listed originals passed their byte/SHA checks. Native ELF, source-before/after at all three boundaries, seven actual control selectors, execution receipt, finalization and all six rounds/42 packet rows were independently rebound to the tested source.

All 12 imported reader source files and five configs were independently fetched from the exact tested head, matched the original pinned hashes, and are retained. The prior readback wrapper changed only HEAD, TREE and RUN. Readback exit 0 means the failed evidence was verified; it is not a successful workload. The workload was dispatched once and was not repeated.

## Measured remaining work

Baseline retained 10 actual imports, 80,709 Host checkpoints, 5.438173614 seconds client thread CPU and 4.517504795 seconds nested Host checkpoint CPU. The preceding F0 retained 81,454 checkpoints, so this candidate removed 745 observed checkpoints. Commit fell from 28,042 to 27,297 checkpoints; admission_prepare remained 20,802 and submit_result/activation remained 21,173. The improvement is too small to close the business gate.

Current client account_graph observations recorded 66 calls, 4.196283850 seconds CPU and 18.849457191 seconds wall time. Complete commitment recorded 111 calls and 0.087420906 seconds CPU. These nested intervals overlap and must not be added. Different provider allocations and completed work prevent a paired causal speed claim.

ROOT actual paid CPU was 6.352965233 seconds, credited refill 6.344940903 seconds, and remaining credit 1.991975670 seconds from the original 2-second opening credit. The accounting identity passed; a numeric depletion witness was absent. Full physical cost remains open.

## Complete automatic CI denominator at the retained timepoint

The exact head had **26 runs: 25 automatic workflows plus this sole F0**. The retained read-only timepoint fetched all {totaljobs} job records, all 26 artifact lists and timing responses, and all {len(failures)} observed failed job logs, without API failures. **{pending} runs were pending at the initial roster**, and all_final is false. Jobs may have reached a later state during sequential metadata/log reads; per-request times and raw bodies are retained. A separate read-only collector continues to terminal states. This snapshot is not a claim that pending jobs passed or that every provider artifact has been downloaded.

The original public-suite fixed-512 CPU-depletion failure remains preserved with the matched original-source failure in #966/#967 and the candidate source evidence. This F0 run does not reclassify that existing limit or claim a newly run full public suite.

## Files and cost scope

f0-original.zip is the exact complete native artifact. complete-f0-readback-originals.tar.xz retains {len(rows)} independently checked transport, source, configuration, readback, cost and CI-original files; archive-index.json records each byte length and SHA. The raw ZIP and its duplicate base64 upload request are represented separately to avoid duplicating the same binary in the tar. The exact upload request remains at the recorded owned path. The original readback expects the original collection paths: restore the ZIP there and safely extract the exact provider members before invoking it in a fresh output directory.

The complete local candidate validation remains at evidence/chain-native-operation-readback-20261119-2e9b/ on source 3db79eb, including the 197-member original archive and all compiler/test/registration negative results. That source-local 127-test pass does not close F0.

cost-summary.json and current-cost-profile.json preserve actual CPU/wall intervals, controller cgroup samples, complete credit identities and the provider timing receipt. The provider reports 523,000 ms run duration and zero billable fields; those fields do not establish zero monetary cost. Compiler/dependency CPU, concurrent system RSS, storage I/O and byte-seconds, physical network bytes, GPU, energy and provider charges remain unknown. No production activation, merge, deployment, or full-cost qualification is claimed.
"""
 with (pub/'README.md').open('x') as f:f.write(readme)
 files=[]
 for p in sorted(pub.iterdir()):
  raw=p.read_bytes();files.append({'path':p.name,'absolute_path':str(p),'bytes':len(raw),'sha256':sha(raw),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})
 files.append({'path':'f0-original.zip','absolute_path':str(root/'collection/artifact-14496651186.zip'),'bytes':blob['bytes'],'sha256':blob['sha256'],'git_blob':blob['expected_git_blob'],'already_published':True})
 a=resource.getrusage(resource.RUSAGE_SELF);res.update(complete=True,files=files,archive_members=len(rows),archive_sha256=sha(archive.read_bytes()),wall_seconds=time.monotonic()-start,self_user_cpu_seconds=a.ru_utime-before.ru_utime,self_system_cpu_seconds=a.ru_stime-before.ru_stime,automatic_runs=25,all_runs=26,all_jobs=totaljobs,failed_job_logs=len(failures),ci_all_final=False);save()
 print(json.dumps(res),flush=True)
except BaseException as exc:
 res['error']=repr(exc);save();(out/'error.log').write_text(traceback.format_exc());raise
