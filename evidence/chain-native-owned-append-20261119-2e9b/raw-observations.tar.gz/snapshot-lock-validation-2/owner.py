from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'snapshot-lock-validation-2';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);res={'schema':'chain-snapshot-lock-native-validation-v1','stages':[],'complete':False,'retained_prior_cli_invocation_error':'snapshot-lock-fix-1/original-observer-suite.stderr'}
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(src.parent/'target');env['PATH']='/home/qq/.cargo/bin:'+env['PATH']
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=src,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['stages'].append(row);save();print(json.dumps(row),flush=True)
 if name=='original-observer-suite' or rc:
  print((out/(name+'.stdout')).read_text(errors='replace')[-20000:],flush=True);print((out/(name+'.stderr')).read_text(errors='replace')[-6000:],flush=True)
 return rc
try:
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 relative='trillionnium/crates/trnm-pon-node/src/ingress/public_v3/request_observation.rs';p=src/relative
 assert p.read_bytes()==(src.parent/'snapshot-lock-fix-1/candidate.rs').read_bytes()
 patch=subprocess.check_output(['git','diff','--',relative],cwd=src);(out/'production.patch').write_bytes(patch)
 test=p.with_name('request_observation_snapshot_tests.rs');(out/'snapshot-tests.rs').write_bytes(test.read_bytes())
 res['production_patch']={'bytes':len(patch),'sha256':hashlib.sha256(patch).hexdigest()};res['production_file_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();res['test_file']={'path':str(test),'bytes':test.stat().st_size,'sha256':hashlib.sha256(test.read_bytes()).hexdigest()};save()
 assert run('original-observer-suite',['/home/qq/.cargo/bin/cargo','test','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--release','--locked','--offline','--lib','ingress::public_v3::request_observation::','--','--nocapture','--test-threads=1'])==0
 assert run('strict-clippy',['/home/qq/.cargo/bin/cargo','clippy','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--release','--locked','--offline','--all-targets','--','-D','warnings'])==0
 assert run('format-check',['/home/qq/.cargo/bin/cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'])==0
 assert run('locked-linux-graph',['/home/qq/.cargo/bin/cargo','metadata','--manifest-path','trillionnium/Cargo.toml','--locked','--offline','--filter-platform','x86_64-unknown-linux-gnu','--format-version','1'])==0
 assert run('diff-check',['git','diff','--check'])==0
 res['complete']=True;save();print(json.dumps(res,indent=2),flush=True)
except BaseException as e:
 res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
