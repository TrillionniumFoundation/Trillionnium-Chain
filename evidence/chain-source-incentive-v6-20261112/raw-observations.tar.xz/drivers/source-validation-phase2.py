#!/usr/bin/env python3
import subprocess,pathlib,json,os,hashlib,time,sys
root=pathlib.Path("/home/qq/chain-source-settlement-20261112-eb070ca2")
out=pathlib.Path("/home/qq/chain-source-incentive-receipts-eb070ca2")
out.mkdir(exist_ok=True)
summary={"schema":"source-incentive-validation-run-v1","phase":"preparing","checks":[],"production_activation":False,"economic_security_qualified":False}
summary_path=out/"source-validation-summary-2.json"
def save():
 summary_path.write_text(json.dumps(summary,sort_keys=True,indent=2)+"\n")
def run(cmd,**kw):
 return subprocess.run(cmd,cwd=root,text=True,capture_output=True,**kw)
env=os.environ.copy()
tool="/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin"
env.update(PATH=tool+":"+env.get("PATH",""),RUSTC=tool+"/rustc",CARGO_BUILD_JOBS="4",CARGO_INCREMENTAL="0",CARGO_TARGET_DIR="/home/qq/chain-source-incentive-target-eb070ca2",RUST_TEST_THREADS="1")
for key in ("RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS"):
 env.pop(key,None)
def checked(cmd,**kw):
 r=run(cmd,**kw)
 if r.returncode: raise RuntimeError(json.dumps({"argv":cmd,"exit_code":r.returncode,"stdout":r.stdout[-8000:],"stderr":r.stderr[-8000:]}))
 return r.stdout
try:
 summary["preflight"]=json.loads(checked(["bash","scripts/project-preflight.sh"]).strip())
 baseline="8cb8b743bccd93a5fac49a072990d18e0d4b4a21"
 prior=json.loads((out/"source-validation-summary.json").read_text())
 if prior.get("phase")!="completed" or prior.get("tested_commit")!=baseline or len(prior.get("checks",[]))!=15:
  raise RuntimeError("first source batch is not complete")
 if checked(["git","rev-parse","HEAD"]).strip()!=baseline:raise RuntimeError("unexpected continuation HEAD")
 metadata={
 "config/pon/pq-authority-effects-v1.json":"7d2d8c6cd54c6c72c22c9817a84aa691c1661c98",
 "scripts/ci/pq_authority_effect_register.py":"b35022d0e86394f583cd8f3c02351734f7456ab1",
 "scripts/ci/test_pq_authority_effect_register.py":"b0e87a63a145726415b464c148fe86ad7ff70f5c",
 "docs/security/PQ_AUTHORITY_EFFECT_REGISTER_V1.md":"48be4c785eae10cbefe01b11832e1c5586e48a1d",
 "trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs":"d70ec7401d7bfaee075d8089f2c908efd2f6ad55"}
 expected_dirty=set(metadata)|{"config/pon/pq-cross-branch-corpus-v1.json"}
 actual=set(checked(["git","diff","--name-only"]).splitlines())|set(checked(["git","ls-files","--others","--exclude-standard"]).splitlines())
 if actual!=expected_dirty:raise RuntimeError("unexpected metadata continuation set: "+repr(sorted(actual)))
 corpus_path=root/"config/pon/pq-cross-branch-corpus-v1.json"
 corpus=json.loads(corpus_path.read_text())
 for path,blob in metadata.items():
  if checked(["git","hash-object",path]).strip()!=blob or corpus["pinned_blobs"].get(path)!=blob:
   raise RuntimeError("reviewed source-gate file/pin mismatch: "+path)
 staged_reader=pathlib.Path("/home/qq/chain-incentive-reader-staging-eb070ca2/read_source_incentive_native_v6_final_v2.py")
 reader_bytes=staged_reader.read_bytes()
 expected_reader="ed7dc94dcf64d53a1ac8b17a25aba34f51293af15a56c62efeed49ce2f03838e2dabbd084ddda2e52605f959669cf822fe65a97bd5d5c481990fd7113f6153eb"
 if hashlib.sha512(reader_bytes).hexdigest()!=expected_reader:raise RuntimeError("independent reader hash mismatch")
 def replace_once(data,old,new):
  if data.count(old)!=1:raise RuntimeError("fixture replacement does not match once: "+old[:100])
  return data.replace(old,new)
 native_path="trillionnium/crates/trnm-pon-node/tests/model_composition_v6.rs"
 native=root/native_path
 data=native.read_text()
 begin=data.index("fn native_source_release_reorg_reopen_and_duplicate_claim_are_atomic()")
 end=data.index("\n#[test]\nfn signed_source_marker_and_packaging_failures_preserve_the_parent",begin)
 chunk=data[begin:end]
 chunk=replace_once(chunk,"    let mut before_release_tip = tip;\n    let mut released = [0; 32];",
 """    let mut before_release_tip = tip;
    let mut released = [0; 32];
    let mut admitted_source = None;""")
 chunk=replace_once(chunk,"        let state = node.state_at(tip).unwrap();\n        continuity_v1::check_state(&state, height, &c).unwrap();",
 """        let state = node.state_at(tip).unwrap();
        if height == 1 {
            // Parent changes retire active contribution rows. Capture the actual
            // admitted identity before that cleanup; the release keeps its own record.
            let source = read_hash(
                &object(&state, fixture.components[0].contribution_id)["model_evidence_v6"]["source"],
            );
            for component in &fixture.components {
                assert_eq!(
                    object(&state, component.contribution_id)["model_evidence_v6"]["source"],
                    hex::encode(source)
                );
            }
            admitted_source = Some(source);
        }
        continuity_v1::check_state(&state, height, &c).unwrap();""")
 chunk=replace_once(chunk,
 """    let source = read_hash(
        &object(&completed.2, fixture.components[0].contribution_id)["model_evidence_v6"]["source"],
    );""",
 """    let source = admitted_source.expect("source captured at native intake");
    assert_eq!(
        record["model_composition_v6"]["sources"][0]["source"],
        hex::encode(source)
    );""")
 native.write_text(data[:begin]+chunk+data[end:])
 reader_path="scripts/experiments/read_source_incentive_native_v6.py"
 if (root/reader_path).exists():raise RuntimeError("reader destination already exists")
 (root/reader_path).write_bytes(reader_bytes)
 contract_path="docs/development/SOURCE_INCENTIVE_RESEARCH_CONTRACT_20261112.md"
 contract=root/contract_path
 heading="## Independent retained-byte readback"
 if heading in contract.read_text():raise RuntimeError("readback section already exists")
 contract.write_text(contract.read_text().rstrip()+"\n\n"+heading+"""

The [native receipt reader](../../scripts/experiments/read_source_incentive_native_v6.py)
reads actual PNX1/ILF2 bytes, ignores fixture author ordinals, binds actual component
senders to the installed source map, reconstructs all 3,855 ILM2 coefficients,
materializes valid source-alone and source-omission models, and recomputes the
installed 25-row evaluations. It checks source delta hashes, function/contribution
IDs, the fixed-marker allocation Merkle root, the fresh V6 release ID, source
record and complete game digests, reported caps, once-only floors, internal payouts,
and the budget remainder. Reproduce after an actual native run with:

    python3 scripts/experiments/read_source_incentive_native_v6.py --self-test --repo . --log /absolute/path/to/native-v6.log

A positive readback is limited to retained bytes and reported payment arithmetic.
It does not verify Ed25519 signatures, PoN work, ledger roots, actual funding,
prepublication reservation authority, underlying source-control truth, actual
claim-account execution, or prospective efficacy. Native execution receipts own
those separately tested transition claims. A reader PASS cannot turn a failed
native suite into a passing one. The historical-domain reader refusal and its
corrected fresh-domain rerun are retained; no check was removed or relaxed.
""".rstrip()+"\n")
 plan_path="docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md"
 plan=root/plan_path
 note="""**Source V6 exact-source continuation, 2026-11-12 UTC — HOLD:**

Checkpoint 8cb8b743bccd93a5fac49a072990d18e0d4b4a21 executed 15 recorded commands:
14 succeeded and the full new native suite failed at one fixture read of a
contribution already retired after parent publication. Preserve that failed
receipt. Its other three cases passed, including complete-source split, alias,
permutation equality and two generations using the actual parent. Retained M06
tests passed 164 cases with nine pre-existing ignored cases; V4 passed five and
M10 passed 35. Strict all-feature Clippy and both locked Cargo graphs passed.
These remain source-specific observations, without production or economic acceptance.

This continuation captures the source at actual intake, preserves the later
paid/reopen/reorg assertions, adds independent retained-byte readback, and refreshes
only the affected distributed inventory and reviewed authority source lock.
That lock still covers seven routes and 44 paths, with only the executor changed;
all scope and HOLD fields remain. The next frozen-source batch must rerun the
complete V6 owner case and source gates. See the
[research contract](SOURCE_INCENTIVE_RESEARCH_CONTRACT_20261112.md) and
[liability boundary](INCENTIVE_LIABILITY_BOUNDARIES_20261112.md).

"""
 if note.splitlines()[0] in plan.read_text():raise RuntimeError("continuation note already exists")
 plan.write_text(note+plan.read_text())
 checked(["cargo","fmt","--manifest-path","trillionnium/Cargo.toml","--all"],env=env)
 checked(["python3","scripts/refresh_distributed_source_inventory.py","--check"])
 for path in (native_path,plan_path):
  if path not in corpus["pinned_blobs"]:raise RuntimeError("continuation pin absent: "+path)
  corpus["pinned_blobs"][path]=checked(["git","hash-object",path]).strip()
 for path in (reader_path,"scripts/experiments/source_incentive_reference_v6.py"):
  corpus["pinned_blobs"][path]=checked(["git","hash-object",path]).strip()
  if path not in corpus["required_paths"]:corpus["required_paths"].append(path)
 corpus_path.write_text(json.dumps(corpus,sort_keys=True,indent=2)+"\n")
 changed=expected_dirty|{native_path,reader_path,contract_path,plan_path}
 actual=set(checked(["git","diff","--name-only"]).splitlines())|set(checked(["git","ls-files","--others","--exclude-standard"]).splitlines())
 if actual!=changed:raise RuntimeError("unexpected second-source changes: "+repr(sorted(actual-changed)))
 checked(["git","diff","--check"])
 checked(["git","add","--",*sorted(changed)])
 summary["diff_stat"]=checked(["git","diff","--cached","--stat"])
 summary["prior_failed_source"]=baseline
 summary["reader_sha512"]=expected_reader
 checked(["git","-c","user.name=OpenAI Codex","-c","user.email=codex@openai.com","commit","-s","-m","test(pon): close native source retention and reviewed source gates"])
 head=checked(["git","rev-parse","HEAD"]).strip()
 tree=checked(["git","rev-parse","HEAD^{tree}"]).strip()
 if checked(["git","status","--porcelain"]).strip():raise RuntimeError("source is not clean after freeze")
 summary.update(phase="executing-frozen-source",tested_commit=head,tested_tree=tree)
 save()
 print(json.dumps({"phase":summary["phase"],"tested_commit":head,"tested_tree":tree}),flush=True)
 recorder=["python3","scripts/ci/record_pq_native_command.py","--kind","head","--candidate",head,"--tested",head,"--output",str(out/"frozen-source-2")]
 def recorded(label,cmd,elf_pin=None):
  args=recorder+["--label",label]
  if elf_pin:args+=["--native-executable-sha256",elf_pin]
  args+=["--",*cmd]
  start=time.monotonic()
  r=run(args,env=env)
  row={"label":label,"runner_exit_code":r.returncode,"elapsed_seconds":round(time.monotonic()-start,3),"stdout":r.stdout[-2500:],"stderr":r.stderr[-2500:]}
  receipt=out/"frozen-source-2"/(label+".json")
  if receipt.exists():
   d=json.loads(receipt.read_text());row.update(status=d.get("status"),command_exit_code=d.get("exit_code"),log_file=str(out/"frozen-source-2"/(label+".log")),log_sha256=d.get("log_sha256"))
  summary["checks"].append(row);save();print(json.dumps(row),flush=True)
  return r.returncode
 cargo=["cargo"]
 common=["--locked","--offline","--manifest-path","trillionnium/Cargo.toml"]
 recorded("source-identity",["python3","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",head])
 recorded("fmt",cargo+["fmt","--manifest-path","trillionnium/Cargo.toml","--all","--","--check"])
 recorded("metadata",cargo+["metadata",*common,"--format-version","1"])
 recorded("metadata-all-features",cargo+["metadata",*common,"--all-features","--format-version","1"])
 build_rc=recorded("build-native-v6",cargo+["test",*common,"-p","trnm-pon-node","--test","model_composition_v6","--no-run","--message-format=json"])
 if build_rc==0:
  binaries=[]
  for line in (out/"frozen-source-2/build-native-v6.log").read_text().splitlines():
   try:item=json.loads(line)
   except ValueError:continue
   if item.get("reason")=="compiler-artifact" and item.get("target",{}).get("name")=="model_composition_v6" and item.get("executable"):
    binaries.append(item["executable"])
  if len(binaries)!=1:raise RuntimeError("ambiguous native V6 executable")
  binary=pathlib.Path(binaries[0])
  binary_hash=hashlib.sha256(binary.read_bytes()).hexdigest()
  summary["native_binary"]={"path":str(binary),"sha256":binary_hash};save()
  recorded("native-v6", [str(binary),"--nocapture","--test-threads=1"],binary_hash)
  recorded("independent-native-readback",["python3",reader_path,"--self-test","--repo",str(root),"--log",str(out/"frozen-source-2/native-v6.log")])
 recorded("mvcc-fee-retained",cargo+["test",*common,"-p","trnm-mvcc-fee","--lib","--","--nocapture","--test-threads=1"])
 recorded("native-v4-retained",cargo+["test",*common,"-p","trnm-pon-node","--test","model_composition_v4","--","--nocapture","--test-threads=1"])
 recorded("task-kernel-retained",cargo+["test",*common,"-p","trnm-task-kernel","--lib","--","--nocapture","--test-threads=1"])
 recorded("native-error-registry",cargo+["test",*common,"-p","trnm-pon-node","--lib","error::tests","--","--nocapture","--test-threads=1"])
 recorded("strict-clippy",cargo+["clippy",*common,"--workspace","--all-targets","--all-features","--","-D","warnings"])
 recorded("source-inventory",["python3","scripts/refresh_distributed_source_inventory.py","--check"])
 recorded("authority-source-negatives",["python3","scripts/ci/test_pq_authority_effect_register.py"])
 recorded("authority-source-register",["python3","scripts/ci/pq_authority_effect_register.py"])
 recorded("repository-links",["python3","scripts/ci/check_repository.py"])
 recorded("source-corpus",["python3","scripts/ci/check_pq_research_integration.py"])
 recorded("source-integrity-negatives",["python3","scripts/ci/test_ci_source_integrity.py"])
 recorded("independent-math-self-tests",["python3","scripts/experiments/source_incentive_reference_v6.py","--self-test"])
 summary["phase"]="completed"
 summary["all_commands_succeeded"]=all(r["runner_exit_code"]==0 for r in summary["checks"])
 summary["post_status"]=checked(["git","status","--porcelain"])
 save()
 print(json.dumps({"phase":"completed","all_commands_succeeded":summary["all_commands_succeeded"],"checks":len(summary["checks"]),"tested_commit":head}),flush=True)
 sys.exit(0 if summary["all_commands_succeeded"] else 1)
except Exception as error:
 summary.update(phase="blocked",error=str(error))
 save();print(json.dumps({"phase":"blocked","error":str(error)}),flush=True);raise

