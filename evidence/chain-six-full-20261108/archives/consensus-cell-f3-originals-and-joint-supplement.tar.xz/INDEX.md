# F3 consensus and Cell original campaign with exact-profile supplement

Frozen source: 1a446a79700cc093a2b1a7f10367ef4a5ddbd680; tree 928b180bf769a813e5643827329667cb11f2a3a5.

The original campaign completed with exit 1 and remains FAIL. All 296 original files (17,868,153 bytes), every original log/report including native packet artifacts, exact full source guards, Runtime terminal receipt and lossless Runtime stdout/stderr are included. No original output was overwritten or omitted.

The sole failed original check was a wrapper treating the original PNH1 growth-witness not-applicable skip as forbidden. The separate approved supplement freshly re-executed both original readers and complete suites on the same frozen source: PNH1 had exactly 21 successes plus its one predeclared N/A; PGH2 had all 22 successes including that witness control. The complete fixed 22-name roster, exact source hash, whole verbose frame and 9 actual-log mutation controls remain bound. The skip is not counted as a success and the original FAIL is not relabelled.

Other original observations include Growth 77 successes plus its 2 original ignored controls; the full Cell crate 496 successes including all 51 original #807 names; and the #805 explicit historical frozen-baseline replay 104 original plus 13 boundary controls. The old default current-source contract still rejects SOURCE_BYTES drift. These are limited local observations, not universal work lower bounds, independent public operators, or a native cost qualification. All authority/activation gates remain HOLD/NO-GO.

MANIFEST.json lists SHA256 and byte count for every included input. Full Git checkouts, compiled caches and private Hepta material are outside this archive.
