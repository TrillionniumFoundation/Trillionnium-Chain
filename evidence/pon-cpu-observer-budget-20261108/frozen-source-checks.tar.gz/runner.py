from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
root=Path('/workspace/scratch/10366560c781/chain-risk-closure')
out=Path('/workspace/scratch/10366560c781/cpu-observer-frozen-checks')
out.mkdir(exist_ok=True)
head='d5b7c1726b7351400a46c27c836d382b43399ca5'
tc=Path('/workspace/scratch/d95a703b8dd6/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu')
env=os.environ.copy()
env.update(PATH=str(tc/'bin')+':'+env['PATH'],RUSTC=str(tc/'bin/rustc'),RUSTDOC=str(tc/'bin/rustdoc'),LD_LIBRARY_PATH=str(tc/'lib'),CARGO_HOME='/workspace/scratch/d95a703b8dd6/toolchain/cargo',CARGO_TARGET_DIR='/workspace/scratch/10366560c781/target-cpu-observer',CARGO_BUILD_JOBS='1')
commands={
 'source-before':['python3','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',head],
 'repository':['python3','scripts/ci/check_repository.py'],
 'source-negative':['python3','scripts/ci/test_ci_source_integrity.py'],
 'format':['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--check'],
 'graph':['cargo','metadata','--manifest-path','trillionnium/Cargo.toml','--locked','--offline','--format-version','1','--no-deps'],
 'source-after':['python3','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',head],
}
key=sys.argv[1];cmd=commands[key]
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
p=subprocess.run(cmd,cwd=root,env=env,capture_output=True)
end=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/(key+'.stdout')).write_bytes(p.stdout);(out/(key+'.stderr')).write_bytes(p.stderr)
r={'schema':'pon-cpu-observer-frozen-source-check-v1','kind':'source-only','head':head,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'cwd':str(root),'argv':cmd,'start_utc':start,'end_utc':end,'elapsed_seconds':time.monotonic()-t,'exit_code':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'source_still_clean':not subprocess.check_output(['git','status','--porcelain'],cwd=root),'native_runtime_qualified':False}
(out/(key+'.json')).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
print(json.dumps({'check':key,'exit_code':p.returncode,'elapsed_seconds':r['elapsed_seconds'],'source_still_clean':r['source_still_clean']}))
if p.returncode:print(p.stdout.decode(errors='replace')[-3000:],p.stderr.decode(errors='replace')[-3000:])
sys.exit(p.returncode)
