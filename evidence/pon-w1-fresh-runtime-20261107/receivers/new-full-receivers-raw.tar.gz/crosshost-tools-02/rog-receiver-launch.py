#!/usr/bin/env python3
"""Record the actual ROG allocation, then exec the qualified receiver in this PID."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path('/home/qian-qi/work/chain-w1-funded-owner-20261107-r01')
BASE = ROOT / 'independent-receiver-01'
HARNESS = BASE / 'receive_w1_on_rog.py'
HARNESS_SHA = '83a712f9accec1420a0d7f0a75a70df9e3fb8eff9e5b234813a72ad2d6bad0e1'
QUALIFICATION = BASE / 'verifier-build-A-01/qualification.json'
QUALIFICATION_SHA = '62315319c06d5070a4f339f1eeda84bff1924162d526b6da0c6100a191d5bbb5'
PYTHON = '/usr/bin/python3.14'
PYTHON_SHA = '52e0a13e60a981d8c4b6478be2ba5176f69da07948a056bf49cf6f077e30cb41'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    entered = time.monotonic_ns()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('arm', choices=('funded-balanced', 'sequential-unfunded'))
    parser.add_argument('--request-sha256', required=True)
    args = parser.parse_args()
    incoming = BASE / ('new-' + args.arm + '-inbox-01')
    request = incoming / 'request.json'
    output = BASE / ('new-' + args.arm + '-receive-01')
    record_path = BASE / ('new-' + args.arm + '-launch-01.json')
    require(not output.exists() and not record_path.exists(), 'one original receiver launch only')
    for path, expected in ((HARNESS, HARNESS_SHA), (QUALIFICATION, QUALIFICATION_SHA),
                           (Path(PYTHON), PYTHON_SHA), (request, args.request_sha256)):
        require(hashlib.sha256(path.read_bytes()).hexdigest() == expected, 'qualified launch bytes changed: ' + str(path))
    membership = Path('/proc/self/cgroup').read_text().strip().splitlines()
    require(len(membership) == 1 and membership[0].startswith('0::/'), 'one unified cgroup required')
    relative = membership[0][3:]
    group = Path('/sys/fs/cgroup') / relative.lstrip('/')
    require(group.name.startswith('hepta-runtime-job-') and group.name.endswith('.service'), 'actual Hepta job scope required')
    controls = {name: (group / name).read_text().strip()
                for name in ('cpu.max', 'memory.max', 'cpu.stat', 'memory.peak', 'cgroup.events')}
    quota, period = map(int, controls['cpu.max'].split())
    require(period > 0 and quota == 2 * period and controls['memory.max'] == str(8 * 1024**3),
            'actual requested two-CPU/eight-GiB receiver allocation required')
    require(os.environ.get('RAYON_NUM_THREADS') == '2', 'actual Rayon 2 environment required')
    proc = Path('/proc/self/stat').read_text()
    fields = proc[proc.rfind(')') + 2:].split()
    argv = [PYTHON, str(HARNESS), 'receive', '--qualification', str(QUALIFICATION),
            '--qualification-sha256', QUALIFICATION_SHA, '--request', str(request),
            '--request-sha256', args.request_sha256, '--out', str(output), '--local-seconds', '60']
    record = {'schema': 'TRNM-W1-ROG-ACTUAL-LAUNCH1', 'arm': args.arm,
              'entered_monotonic_ns': entered, 'recorded_monotonic_ns': time.monotonic_ns(),
              'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
              'hostname': os.uname().nodename, 'pid': os.getpid(), 'parent_pid': os.getppid(),
              'pid_start_ticks': int(fields[19]), 'cgroup_membership': membership[0],
              'cgroup': str(group), 'actual_controls': controls,
              'actual_affinity': sorted(os.sched_getaffinity(0)), 'rayon_num_threads': '2',
              'request_sha256': args.request_sha256, 'receiver_argv': argv,
              'receiver_harness_sha256': HARNESS_SHA, 'qualification_sha256': QUALIFICATION_SHA,
              'python_sha256': PYTHON_SHA, 'launch_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'handoff': 'os.execve replaces this process; successful exec retains PID and birth identity',
              'parent_clock_compared': False, 'parent_deadline_extended': False,
              'complete_resource_accounting_established': False}
    with record_path.open('x') as stream:
        json.dump(record, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(record_path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    os.execve(PYTHON, argv, dict(os.environ))


if __name__ == '__main__':
    main()
