#!/usr/bin/env python3
"""Execute the unmodified 45 selectors and reject zero/ignored matches."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/9d99fced0bf1/chain')
OUT = Path('/workspace/scratch/9d99fced0bf1/final-validation')
manifest = json.loads((ROOT / 'config/pon/pq-system-required-tests-v1.json').read_text())
tests = manifest['tests']
assert len(tests) == len(set(tests)) == manifest['expected_meaningful_controls'] == 45
assert not set(tests) & set(manifest['child_process_harnesses_not_counted'])
artifacts = []
build_label = sys.argv[1] if len(sys.argv) > 1 else 'node-build'
build_receipt = json.loads((OUT / (build_label + '.json')).read_text())
assert build_receipt['status'] == 'command_succeeded' and build_receipt['exit_code'] == 0
for line in (OUT / (build_label + '.log')).read_text().splitlines():
    try:
        row = json.loads(line)
    except ValueError:
        continue
    if (row.get('reason') == 'compiler-artifact'
            and row.get('target', {}).get('name') == 'trnm_pon_node'
            and row.get('profile', {}).get('test') is True and row.get('executable')):
        artifacts.append(row)
assert len(artifacts) == 1, artifacts
binary = Path(artifacts[0]['executable'])
identity = {'path': str(binary), 'bytes': binary.stat().st_size,
            'sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
            'build_receipt_label': build_label,
            'artifact': artifacts[0]}
(OUT / 'node-test-binary.json').write_text(json.dumps(identity, indent=2) + '\n')
results = []
for index, selector in enumerate(tests):
    label = f'required-{index:02d}'
    command = [str(binary), selector, '--exact', '--show-output', '--test-threads=1']
    started_utc = datetime.now(timezone.utc).isoformat()
    started = time.monotonic_ns()
    with (OUT / (label + '.log')).open('xb') as log:
        code = subprocess.run(command, cwd=ROOT, stdout=log,
                              stderr=subprocess.STDOUT).returncode
    checked = subprocess.run(['python3', 'scripts/ci/check_required_native_test.py',
                              str(OUT / (label + '.log')), '--test', selector],
                             cwd=ROOT, text=True, capture_output=True)
    (OUT / (label + '-execution.txt')).write_text(checked.stdout + checked.stderr)
    result = {'selector': selector, 'label': label,
              'argv': command, 'binary_sha256': identity['sha256'],
              'started_utc': started_utc, 'elapsed_ns': time.monotonic_ns()-started,
              'exit_code': code, 'execution_check_exit_code': checked.returncode,
              'log_sha256': hashlib.sha256((OUT / (label + '.log')).read_bytes()).hexdigest()}
    results.append(result)
    (OUT / 'required-selector-results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(result), flush=True)
assert hashlib.sha256(binary.read_bytes()).hexdigest() == identity['sha256']
raise SystemExit(0 if all(x['exit_code'] == x['execution_check_exit_code'] == 0
                         for x in results) else 1)
