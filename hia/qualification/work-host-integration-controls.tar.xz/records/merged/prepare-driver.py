from pathlib import Path
import sys,json,hashlib,subprocess,tarfile,stat,re,textwrap,ast,time,traceback,shutil
root=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo");base=root.parent/"work-components-integration-v3";base.mkdir(mode=0o700);candidate=base/"candidate";candidate.mkdir()
handoff=Path("/tmp/trnm-work-owner-canonical-326-20261116-ut1ee1rf/next-closure-v1/handoff-ded-ci-v7")
components=root.parent/"component-ci-proposal-v1/candidate";foundation=root.parent/"foundation-ci-proposal-v1/candidate"
(base/"prepare-driver.py").write_text(sys.argv[1]);started=time.monotonic_ns();report={"status":"FAIL","canonical_mutated":False,"native_runtime_executed":False}
def need(v,m):
 if not v:raise ValueError(m)
def ident(p):
 s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1,"Linked/nonregular source "+str(p));raw=p.read_bytes()
 return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
try:
 p=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=root,capture_output=True);(base/"preflight.stdout.raw").write_bytes(p.stdout);(base/"preflight.stderr.raw").write_bytes(p.stderr);need(p.returncode==0,"Preflight failed")
 need(subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()=="c3901ff19c26815205d9cdd6975fc24ecc51ae88","Head moved")
 need(subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True)=="","Canonical source dirty")
 need(ident(handoff/"source-manifest.json")=={"bytes":41857,"sha256":"86cbe9d4a1240e6dd4fc14bf3341a816daf503a8039774f00acac034fa971c1a"},"Handoff manifest changed")
 m=json.loads((handoff/"source-manifest.json").read_text());owned=m["owned_sources"];need(len(owned)==35,"Owned source count differs")
 need(ident(handoff/"complete-final-owned-source.tar.xz")=={"bytes":130696,"sha256":"f285cf1d4ec17fc75f51eef7da1d7300f635beb8ac92f75d30f10b9ade6926d6"},"Source archive changed")
 seen=set()
 with tarfile.open(handoff/"complete-final-owned-source.tar.xz","r:xz") as stream:
  for member in stream:
   need(member.isfile() and member.name in owned and member.name not in seen,"Unexpected or repeated source member")
   seen.add(member.name);raw=stream.extractfile(member).read();expected=owned[member.name]
   need({"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}=={k:expected[k] for k in ("bytes","sha256")},"Handoff archive source differs")
 need(seen==set(owned),"Handoff source roster incomplete")
 inputs={}
 for rel,entry in owned.items():
  path=Path(entry["path"]);need(ident(path)=={k:entry[k] for k in ("bytes","sha256")},"Owned source changed")
  inputs[rel]={"owner":"work-host","input":str(path),"identity":ident(path)}
 component_manifest=json.loads((components.parent/"candidate-source-v2.json").read_text())
 report["component_manifest_keys"]=list(component_manifest)
 component_names=["hia/tools/component_partition.py","hia/tools/qualify.py","hia/tools/qualify_components_ci.py","hia/tests/test_component_partition.py",".github/workflows/hia-native-migration.yml","scripts/ci/test_hia_workflow_bootstrap.py"]
 for rel in component_names:
  need(rel not in inputs,"Overlapping component ownership");inputs[rel]={"owner":"component-ci","input":str(components/rel),"identity":ident(components/rel)}
 for rel,expected in {"hia/tools/qualify_foundation_ci.py":{"bytes":27411,"sha256":"4ce280ecc52f5810b157e368b9969e0074fcf1763bc46d5053e5127281dce78f"},"hia/tests/test_foundation_ci.py":{"bytes":11771,"sha256":"02664f4a96b98a97851d0bf52422bc0ad234eaaf6f1cb80ca1a2521715d42e4b"}}.items():
  need(rel not in inputs and ident(foundation/rel)==expected,"Foundation source differs");inputs[rel]={"owner":"foundation-ci","input":str(foundation/rel),"identity":expected}
 for rel,entry in inputs.items():
  target=candidate/rel;target.parent.mkdir(parents=True,exist_ok=True)
  raw=Path(entry["input"]).read_bytes();target.write_bytes(raw);target.chmod(0o644)
  need(ident(target)==entry["identity"],"Candidate copy differs")
 import yaml
 class Unique(yaml.SafeLoader):pass
 def mapping(loader,node,deep=False):
  value={}
  for kn,vn in node.value:
   key=loader.construct_object(kn,deep=deep);need(key not in value,"Duplicate YAML key "+str(key));value[key]=loader.construct_object(vn,deep=deep)
  return value
 Unique.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,mapping)
 workflow_path=candidate/".github/workflows/hia-native-migration.yml";before_text=workflow_path.read_text();before=yaml.load(before_text,Loader=Unique)
 jobs=json.loads((handoff/"workflow-jobs.json").read_text());fragment_document=textwrap.dedent((handoff/"workflow-jobs.yml").read_text())
 document=yaml.load(fragment_document,Loader=Unique)
 need(type(document) is dict and set(document)=={"jobs"} and document["jobs"]==jobs,"Host YAML and JSON fragments differ")
 need(fragment_document.startswith("jobs:\n"),"Host fragment wrapper differs")
 fragment=textwrap.dedent(fragment_document.split("\n",1)[1])
 job_start=before_text.index("\njobs:\n")+len("\njobs:\n");prefix=before_text[:job_start];body=before_text[job_start:]
 markers=list(re.finditer(r"^  ([a-zA-Z0-9_-]+):\s*\n",body,re.M));need({x.group(1) for x in markers}==set(before["jobs"]),"Unexpected job text layout")
 chunks=[]
 for i,match in enumerate(markers):
  end=markers[i+1].start() if i+1<len(markers) else len(body);name=match.group(1);block=body[match.start():end]
  if name=="native-work-owner":chunks.append(textwrap.indent(fragment.rstrip()+"\n\n","  "))
  elif name!="native-work-owner-readback":chunks.append(block)
 merged=prefix+"".join(chunks);after=yaml.load(merged,Loader=Unique)
 need(len(after["jobs"])==46 and set(after["jobs"])==set(before["jobs"])|set(jobs),"Merged job roster differs")
 for name,job in after["jobs"].items():need(job==(jobs[name] if name in jobs else before["jobs"][name]),"Job changed unexpectedly "+name)
 workflow_path.write_text(merged)
 for rel in inputs:
  if rel.endswith(".py"):ast.parse((candidate/rel).read_text(),filename=rel)
 baseline={rel:ident(root/rel) if (root/rel).exists() else {"status":"ABSENT"} for rel in inputs}
 final={rel:ident(candidate/rel) for rel in inputs}
 report.update(status="PASS",owned_files=len(inputs),inputs=inputs,canonical_before=baseline,candidate_source=final,merged_jobs=len(after["jobs"]),host_jobs=list(jobs),source_head="c3901ff19c26815205d9cdd6975fc24ecc51ae88",host_native_source_set_sha256=m["native_source_set_sha256"],host_reader_source_transition={"before":m["reader_source_set_sha256"],"after":"TO_BE_COMPUTED_FROM_INTEGRATED_SOURCE","foundation_in_native_133":False})
 (base/"canonical-before.json").write_text(json.dumps(baseline,sort_keys=True,indent=2)+"\n")
 (base/"candidate-source.json").write_text(json.dumps(final,sort_keys=True,indent=2)+"\n")
 (base/"ownership.json").write_text(json.dumps(inputs,sort_keys=True,indent=2)+"\n")
except BaseException as e:report["failure"]={"error":repr(e),"traceback":traceback.format_exc()};raise
finally:
 report["elapsed_ns"]=time.monotonic_ns()-started;(base/"prepare-report.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
 print(json.dumps({k:v for k,v in report.items() if k not in ("inputs","canonical_before","candidate_source")}),flush=True)
