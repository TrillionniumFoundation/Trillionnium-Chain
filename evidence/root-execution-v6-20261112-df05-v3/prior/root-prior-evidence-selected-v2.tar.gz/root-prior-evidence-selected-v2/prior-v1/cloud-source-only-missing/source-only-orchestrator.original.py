#!/usr/bin/env python3
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib, json, os, re, subprocess, sys, time
root=Path("/tmp/chain-root-v6-recovered-df05")
out=Path("/workspace/scratch/df05fc75c9e2/chain-root-source-only-87bf6bb0-20261112")
expected_head="87bf6bb07c4ccdd75741cfb79c7447d8d8c54758"
expected_tree="b1882c2e46827abfd1db5f8744be043d5776df6d"
out.mkdir(exist_ok=False)
env=os.environ.copy()
env["PYTHONPYCACHEPREFIX"]=str(out/"pycache")
env["PYTHONDONTWRITEBYTECODE"]="1"
def atomic_json(path,value):
    with path.open("x",encoding="utf-8") as f:
        json.dump(value,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
def run(name, argv, cwd=root):
    started=time.time()
    atomic_json(out/(name+".command.json"),{"argv":argv,"cwd":str(cwd),"environment_overrides":{"PYTHONPYCACHEPREFIX":env["PYTHONPYCACHEPREFIX"],"PYTHONDONTWRITEBYTECODE":"1"},"started_unix":started})
    with (out/(name+".stdout")).open("xb") as stdout, (out/(name+".stderr")).open("xb") as stderr:
        result=subprocess.run(argv,cwd=cwd,env=env,stdout=stdout,stderr=stderr)
        stdout.flush();stderr.flush();os.fsync(stdout.fileno());os.fsync(stderr.fileno())
    stdout=(out/(name+".stdout")).read_bytes();stderr=(out/(name+".stderr")).read_bytes()
    summary={"name":name,"exit_code":result.returncode,"duration_seconds":time.time()-started,"stdout_bytes":len(stdout),"stdout_sha256":hashlib.sha256(stdout).hexdigest(),"stderr_bytes":len(stderr),"stderr_sha256":hashlib.sha256(stderr).hexdigest()}
    atomic_json(out/(name+".result.json"),summary)
    print(json.dumps({**summary,"stdout_tail":stdout[-1000:].decode(errors="replace"),"stderr_tail":stderr[-1500:].decode(errors="replace")}),flush=True)
    return summary
def git(*argv):
    return subprocess.check_output(["git",*argv],cwd=root,env=env,text=True).strip()
before_identity={"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"porcelain":git("status","--porcelain=v1")}
atomic_json(out/"identity-before.json",before_identity)
assert before_identity=={"head":expected_head,"tree":expected_tree,"porcelain":""},before_identity
preflight=run("preflight-before",["bash","scripts/project-preflight.sh"])
assert preflight["exit_code"]==0
verify_args=["python3","-B","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",expected_head]
before=run("verify-source-before",verify_args+["--output",str(out/"verified-source-before.json")])
assert before["exit_code"]==0
jobs=[
("source-integrity-negatives",["python3","-B","-m","unittest","-v","test_ci_source_integrity"],root/"scripts/ci"),
("repository-with-markdown-links",["python3","-B","scripts/ci/check_repository.py"],root),
("pq-research-corpus",["python3","-B","scripts/ci/check_pq_research_integration.py"],root),
("root-dependency-register",["python3","-B","scripts/ci/pq_root_dependency_register.py"],root),
("distributed-source-inventory",["python3","-B","scripts/refresh_distributed_source_inventory.py","--check"],root),
("root-register-and-runner-controls",["python3","-B","-m","unittest","-v","test_run_pq_root_witness_v5","test_pq_root_dependency_register"],root/"scripts/ci"),
]
results={}
with ThreadPoolExecutor(max_workers=3) as pool:
    futures={pool.submit(run,name,argv,cwd):name for name,argv,cwd in jobs}
    for future in as_completed(futures):
        name=futures[future]
        try:results[name]=future.result()
        except Exception as error:
            results[name]={"name":name,"error":repr(error),"exit_code":None}
            print(json.dumps(results[name]),flush=True)
after=run("verify-source-after",verify_args+["--output",str(out/"verified-source-after.json")])
after_identity={"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"porcelain":git("status","--porcelain=v1")}
atomic_json(out/"identity-after.json",after_identity)
counts={}
for name,expected in [("source-integrity-negatives",43),("root-register-and-runner-controls",52)]:
    stderr=(out/(name+".stderr")).read_text()
    found=re.findall(r"^Ran (\\d+) tests? in ",stderr,re.M)
    counts[name]={"observed_counts":[int(v) for v in found],"expected":expected,"summary_ok":bool(re.search(r"^OK$",stderr,re.M))}
verified_before=json.loads((out/"verified-source-before.json").read_text()) if before["exit_code"]==0 else None
verified_after=json.loads((out/"verified-source-after.json").read_text()) if after["exit_code"]==0 else None
json_reports={}
for name in ("repository-with-markdown-links","pq-research-corpus","root-dependency-register"):
    if results[name].get("exit_code")==0:
        json_reports[name]=json.loads((out/(name+".stdout")).read_text())
unchanged=before_identity==after_identity and verified_before==verified_after
all_exit_zero=all(r.get("exit_code")==0 for r in [preflight,before,after,*results.values()])
counts_match=all(v["observed_counts"]==[v["expected"]] and v["summary_ok"] for v in counts.values())
report={"schema":"trnm-root-v6-source-only-observations-v1","out":str(out),"identity_before":before_identity,"identity_after":after_identity,"source_identity_and_all_tracked_bytes_unchanged":unchanged,"source_verification_before":verified_before,"source_verification_after":verified_after,"commands":{r["name"]:r for r in [preflight,before,after,*results.values()]},"test_counts":counts,"all_exit_codes_zero":all_exit_zero,"test_counts_exact":counts_match,"json_reports":json_reports,"native_tests_executed":False,"production_activation":False,"whole_chain_pq_qualified":False}
atomic_json(out/"SOURCE_ONLY_REPORT.json",report)
print(json.dumps({"report":str(out/"SOURCE_ONLY_REPORT.json"),"source_unchanged":unchanged,"all_exit_zero":all_exit_zero,"test_counts_exact":counts_match,"test_counts":counts,"repository":json_reports.get("repository-with-markdown-links"),"corpus":json_reports.get("pq-research-corpus"),"dependency_count":json_reports.get("root-dependency-register",{}).get("source_file_count")}),flush=True)
raise SystemExit(0 if unchanged and all_exit_zero and counts_match else 1)
