import re, sys
from pathlib import Path
lines = Path(sys.argv[1]).read_text().splitlines()
names = [m[1] for line in lines if (m := re.fullmatch(r'test (store::native_authenticated::[A-Za-z0-9_:]+) \.\.\. ok', line))]
summaries = [line for line in lines if line.startswith('test result:')]
post_write = [name for name in names if name.startswith('store::native_authenticated::post_write_readback::tests::')]
current_accounts = {
    'store::native_authenticated::current_accounts_tests::cold_complete_reuses_actual_account_parse_and_keeps_all_graph_checkpoints',
    'store::native_authenticated::current_accounts_tests::current_projection_is_bound_to_exact_state_and_never_hides_account_changes',
    'store::native_authenticated::current_accounts_tests::current_projection_preserves_complete_root_and_late_error_priority',
    'store::native_authenticated::current_accounts_tests::current_projection_rereads_corrupt_sql_and_preserves_every_cancellation',
    'store::native_authenticated::current_accounts_tests::cold_full_validation_projection_abba_observation_without_timing_gate',
}
observed_current = {name for name in names if name.startswith('store::native_authenticated::current_accounts_tests::')}
history = {
    'store::native_authenticated::post_write_readback::history_tests::completed_parent_suffix_reduces_real_sql_reads_only_for_the_four_named_records',
    'store::native_authenticated::post_write_readback::history_tests::incomplete_history_preserves_full_walk_callbacks_and_mints_no_suffix',
    'store::native_authenticated::post_write_readback::history_tests::every_remaining_history_hit_boundary_preserves_cancellation',
    'store::native_authenticated::post_write_readback::history_tests::first_history_hit_final_write_repeats_the_original_full_verifier',
    'store::native_authenticated::post_write_readback::history_tests::full_history_final_callback_write_cannot_publish_pending_suffixes',
    'store::native_authenticated::post_write_readback::history_tests::writes_restoration_and_prepare_only_schema_changes_disable_completed_history',
    'store::native_authenticated::post_write_readback::history_tests::consumed_history_keeps_the_outer_last_write_fence',
    'store::native_authenticated::post_write_readback::history_tests::history_early_and_final_errors_cannot_hide_transaction_replacement',
    'store::native_authenticated::post_write_readback::history_tests::foreign_initial_state_with_identical_context_cannot_borrow_history',
    'store::native_authenticated::post_write_readback::history_tests::damaged_ancestors_genesis_and_graph_keep_original_errors_after_a_receipt',
    'store::native_authenticated::post_write_readback::history_tests::a_different_actual_connection_cannot_use_completed_history',
    'store::native_authenticated::post_write_readback::history_tests::completed_history_never_survives_rollback_or_cold_open',
    'store::native_authenticated::post_write_readback::history_tests::record_binding::exact_completed_record_reduces_material_and_whole_sql_work',
    'store::native_authenticated::post_write_readback::history_tests::record_binding::graph_receipts_never_authorize_start_record_binding',
    'store::native_authenticated::post_write_readback::history_tests::record_binding::unchanged_record_requires_actual_material_after_any_write',
    'store::native_authenticated::post_write_readback::history_tests::record_binding::a_probe_error_survives_cleared_history_receipts',
    'store::native_authenticated::post_write_readback::history_tests::record_binding::transaction_replacement_preserves_original_material_error_sources',
    'store::native_authenticated::post_write_readback::history_tests::record_binding::final_callback_writes_revalidate_or_refuse_original_scope',
    'store::native_authenticated::post_write_readback::history_tests::record_binding::final_callback_cancellation_keeps_ordinary_error_and_aba_source',
    'store::native_authenticated::post_write_readback::history_tests::record_binding::exact_settings_and_record_membership_keep_fifth_records_on_full_walk',
    'store::native_authenticated::post_write_readback::history_tests::record_binding::cancelled_full_walk_cannot_publish_a_start_record_proof',
}
observed_history = {name for name in names if name.startswith('store::native_authenticated::post_write_readback::history_tests::')}
if (len(names) != 118 or len(set(names)) != 118 or len(post_write) != 25
        or observed_current != current_accounts
        or observed_history != history
        or len(summaries) != 1 or not summaries[0].startswith('test result: ok. 118 passed; 0 failed; 0 ignored;')):
    raise SystemExit('current authenticated module requires all 97 retained and 21 history executions, including 25 post-write and five current-account controls, in one log')
