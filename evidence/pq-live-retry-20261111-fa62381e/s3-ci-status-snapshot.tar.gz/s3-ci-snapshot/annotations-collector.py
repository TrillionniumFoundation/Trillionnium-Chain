from pathlib import Path
import concurrent.futures, datetime, hashlib, json, os, shutil, subprocess, sys, time
ROOT = Path("/tmp/chain-pq-fa62381e")
OUT = Path("/tmp/chain-pq-fa62381e-s3-adverse-annotations")
EXPECTED = "454ae116159867ff6cddd91b964523df7f7e16f0"
JOBS = [{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596762612","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596762612,"name":"export","run_id":43042229522},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596763175","conclusion":"cancelled","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596763175,"name":"cleanup (macos-15, prospective-merge)","run_id":43042229587},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596763218","conclusion":"cancelled","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596763218,"name":"cleanup (macos-15, head)","run_id":43042229587},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596764361","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596764361,"name":"retained-pressure-failure","run_id":43042229558},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596764483","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596764483,"name":"original native campaign (x64, head, release)","run_id":43042229773},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596764953","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596764953,"name":"native priorities (ubuntu-24.04, head, service-model)","run_id":43042229558},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596764961","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596764961,"name":"native priorities (ubuntu-24.04, prospective-merge, history)","run_id":43042229558},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596765035","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596765035,"name":"native priorities (ubuntu-24.04-arm, head, service-model)","run_id":43042229558},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596765045","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596765045,"name":"W1 fresh challenge service (x64, head)","run_id":43042229751},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596765118","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596765118,"name":"native priorities (ubuntu-24.04-arm, prospective-merge, service-model)","run_id":43042229558},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596765167","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596765167,"name":"native priorities (ubuntu-24.04, prospective-merge, service-model)","run_id":43042229558},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596765271","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596765271,"name":"native priorities (ubuntu-24.04, head, history)","run_id":43042229558},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130596765526","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130596765526,"name":"W1 fresh challenge service (x64, prospective-merge)","run_id":43042229751},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130613467779","conclusion":"cancelled","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130613467779,"name":"protocol-contract","run_id":43042229392},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130613468335","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130613468335,"name":"cross-arch-cost (arm64)","run_id":43042229392},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130613468571","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130613468571,"name":"repository-truth","run_id":43042229392},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130613468622","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130613468622,"name":"prospective-merge (repository-truth)","run_id":43042229392},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130613468850","conclusion":"cancelled","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130613468850,"name":"prospective-merge (protocol-contract)","run_id":43042229392},{"check_run_url":"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/130613469277","conclusion":"failure","head_sha":"454ae116159867ff6cddd91b964523df7f7e16f0","job_id":130613469277,"name":"cross-arch-cost (x64)","run_id":43042229392}]
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(b):
    return hashlib.sha256(b).hexdigest()
OUT.mkdir(exist_ok=False)
env = dict(os.environ)
env.update(PYTHONDONTWRITEBYTECODE="1", GH_PROMPT_DISABLED="1", GH_PAGER="cat", NO_COLOR="1")
head = subprocess.run(["git","rev-parse","HEAD"],cwd=ROOT,env=env,capture_output=True,check=False)
preflight = {"started_utc": now(), "head": head.stdout.decode("utf-8").strip(), "expected": EXPECTED,
             "git_exit": head.returncode, "api_mutations": False, "source_mutations": False}
(OUT/"head.stdout").write_bytes(head.stdout)
(OUT/"head.stderr").write_bytes(head.stderr)
if head.returncode or preflight["head"] != EXPECTED:
    preflight["result"]="REFUSE_SOURCE_CONTEXT"
    (OUT/"preflight.json").write_text(json.dumps(preflight,sort_keys=True,indent=2)+"\n")
    raise SystemExit(2)
try:
    check = subprocess.run(["bash","scripts/project-preflight.sh","--audit"],cwd=ROOT,env=env,
                           capture_output=True,check=False,timeout=180)
except subprocess.TimeoutExpired as error:
    (OUT/"preflight.stdout").write_bytes(error.stdout or b"")
    (OUT/"preflight.stderr").write_bytes(error.stderr or b"")
    preflight.update(result="PREFLIGHT_TIMEOUT",timeout_seconds=180,finished_utc=now())
    (OUT/"preflight.json").write_text(json.dumps(preflight,sort_keys=True,indent=2)+"\n")
    raise SystemExit(2)
(OUT/"preflight.stdout").write_bytes(check.stdout)
(OUT/"preflight.stderr").write_bytes(check.stderr)
preflight.update(exit_code=check.returncode,stdout_sha256=digest(check.stdout),
                 stderr_sha256=digest(check.stderr),finished_utc=now())
preflight["result"]="PASS" if check.returncode==0 else "FAIL"
(OUT/"preflight.json").write_text(json.dumps(preflight,sort_keys=True,indent=2)+"\n")
if check.returncode:
    raise SystemExit(check.returncode)
gh = shutil.which("gh")
if not gh:
    (OUT/"manifest.json").write_text(json.dumps({"result":"MISSING_GH","api_mutations":False})+"\n")
    raise SystemExit(2)
def fetch(job):
    pages=[]
    complete=False
    for page in range(1,4):
        url=job["check_run_url"]+"/annotations?per_page=100&page="+str(page)
        assert url.startswith("https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/check-runs/")
        endpoint=url.removeprefix("https://api.github.com/")
        args=[gh,"api","--hostname","github.com","--method","GET",endpoint]
        began=now()
        try:
            r=subprocess.run(args,cwd=OUT,env=env,capture_output=True,check=False,timeout=35)
            stdout,stderr,code=r.stdout,r.stderr,r.returncode
            timed_out=False
        except subprocess.TimeoutExpired as error:
            stdout,stderr,code=error.stdout or b"",error.stderr or b"",None
            timed_out=True
        stem="annotations-"+str(job["job_id"])+"-page"+str(page)
        (OUT/(stem+".stdout")).write_bytes(stdout)
        (OUT/(stem+".stderr")).write_bytes(stderr)
        record={"url":url,"argv":args,"started_utc":began,"finished_utc":now(),
                "exit_code":code,"timed_out":timed_out,"stdout_sha256":digest(stdout),
                "stderr_sha256":digest(stderr),"stdout_bytes":len(stdout),"stderr_bytes":len(stderr),
                "stdout":stdout.decode("utf-8",errors="strict"),"stderr":stderr.decode("utf-8",errors="strict")}
        pages.append(record)
        if code!=0 or timed_out: break
        try:
            parsed=json.loads(stdout)
            if type(parsed) is not list: raise ValueError("annotation API response is not an array")
        except (ValueError,UnicodeError) as error:
            record["parse_error"]=str(error)
            break
        record["annotation_count"]=len(parsed)
        if len(parsed)<100:
            complete=True
            break
    result={**job,"schema":"trnm-official-check-annotations-readonly-v1","pages":pages,
            "complete":complete,"api_mutations":False,"source_mutations":False}
    path=OUT/("annotations-"+str(job["job_id"])+".json")
    encoded=(json.dumps(result,sort_keys=True,indent=2)+"\n").encode()
    path.write_bytes(encoded)
    return {"job_id":job["job_id"],"run_id":job["run_id"],"file":path.name,
            "complete":complete,"bytes":len(encoded),"sha256":digest(encoded),
            "annotation_count":sum(p.get("annotation_count",0) for p in pages)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    rows=list(pool.map(fetch,JOBS))
summary={"schema":"trnm-s3-official-check-annotations-snapshot-v1","head_sha":EXPECTED,
         "observed_utc":now(),"result":"COMPLETE" if all(x["complete"] for x in rows) else "INCOMPLETE",
         "jobs":rows,"job_count":len(rows),"preflight_file":"preflight.json",
         "api_mutations":False,"source_mutations":False,"qualification_granted":False}
(OUT/"manifest.json").write_text(json.dumps(summary,sort_keys=True,indent=2)+"\n")
print(json.dumps({"result":summary["result"],"path":str(OUT),"job_count":len(rows),
                  "complete_jobs":sum(x["complete"] for x in rows),"annotation_count":sum(x["annotation_count"] for x in rows)},sort_keys=True))
raise SystemExit(0 if summary["result"]=="COMPLETE" else 1)
