#!/usr/bin/env python3
"""Use the repository's existing exact-source recorder, without replacing gates."""
import os
from pathlib import Path
import subprocess
import sys

root = Path('/workspace/scratch/6478cdf21f8e/chain-final')
scratch = root.parent
toolchain = scratch / 'toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu'
env = os.environ.copy()
env.update({
    'PATH': str(toolchain / 'bin') + ':' + env['PATH'],
    'CARGO_HOME': str(scratch / 'toolchain/cargo'),
    'RUSTUP_HOME': str(scratch / 'toolchain/rustup'),
    'RUSTUP_TOOLCHAIN': '1.95.0-x86_64-unknown-linux-gnu',
    'RUSTUP_AUTO_INSTALL': '0',
    'RUSTC': str(toolchain / 'bin/rustc'),
    'RUSTDOC': str(toolchain / 'bin/rustdoc'),
    'RUSTFMT': str(toolchain / 'bin/rustfmt'),
    'LD_LIBRARY_PATH': str(toolchain / 'lib'),
    'CARGO_TARGET_DIR': str(scratch / 'target-final'),
    'CARGO_BUILD_JOBS': '2',
    'CARGO_INCREMENTAL': '0',
    'RUST_TEST_THREADS': '1',
})
for line in (scratch / 'provider-build/provider.env').read_text().splitlines():
    key, value = line.split('=', 1)
    assert key in {'OPENSSL_DIR','OPENSSL_STATIC','TRNM_PQ_OPENSSL','TRNM_PQ_OPENSSL_SHA256','TRNM_PQ_OPENSSL_VERSION','OPENSSL_CONF','OPENSSL_MODULES'}
    env[key] = value
label, *command = sys.argv[1:]
assert label and command
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
argv = ['python3','scripts/ci/record_pq_native_command.py','--kind','head','--candidate',head,'--tested',head,'--label',label,'--output',str(scratch/'recovered-observations/records'),'--',*command]
raise SystemExit(subprocess.run(argv,cwd=root,env=env).returncode)
