"""Offline draft only: validate one complete pre-push deletion advertisement.
This is not an executable hook or a merge/delete driver. It performs no I/O.
The future owner must verify actual archive, merge, policy, transport, hook and
plan identities, capture stdin through EOF with a byte limit, and retain receipts.
"""
import hashlib
import json
import re

_SCHEMA = "TRNM_DELETE_ADVERTISEMENT_PLAN_V1"
_URL = "https://github.com/TrillionniumFoundation/Trillionnium-Chain.git"
_ZERO = "0" * 40
_LITERAL_DENY = frozenset({
    "refs/heads/main",
    "refs/heads/fix/chain-bulk-state-tree-20261017",
})
_MAX_INPUT_BYTES = 2 * 1024 * 1024
_MAX_PLAN_BYTES = 256 * 1024

class Rejected(ValueError):
    pass

def _require(ok, why):
    if not ok:
        raise Rejected(why)

def _unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        _require(key not in result, "duplicate JSON key")
        result[key] = value
    return result

def _valid_ref(ref):
    if not isinstance(ref, str) or not ref.startswith("refs/heads/"):
        return False
    if any(ord(c) < 33 or ord(c) == 127 or c in "~^:?*[\\" for c in ref):
        return False
    if ".." in ref or "@{" in ref or ref.endswith(("/", ".")):
        return False
    return all(part and not part.startswith(".") and not part.endswith(".lock")
               for part in ref.split("/"))

def validate_deletion_advertisement(plan_bytes, expected_plan_sha256,
                                    hook_argv, complete_stdin_bytes):
    """Validate the entire already-EOF stdin. No filesystem/network/Git calls."""
    _require(isinstance(plan_bytes, bytes), "plan must be bytes")
    _require(0 < len(plan_bytes) <= _MAX_PLAN_BYTES, "plan byte limit")
    _require(isinstance(expected_plan_sha256, str)
             and re.fullmatch(r"[0-9a-f]{64}", expected_plan_sha256),
             "invalid pinned plan hash")
    _require(hashlib.sha256(plan_bytes).hexdigest() == expected_plan_sha256,
             "plan identity mismatch")
    try:
        plan = json.loads(plan_bytes.decode("utf-8"),
                          object_pairs_hook=_unique_pairs)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise Rejected("invalid plan encoding or JSON") from exc
    _require(isinstance(plan, dict) and set(plan) == {
        "schema", "remote_name", "remote_url", "protected_refs",
        "expected_deletions"
    }, "plan fields")
    _require(plan["schema"] == _SCHEMA, "plan schema")
    _require(plan["remote_name"] == "origin" and plan["remote_url"] == _URL,
             "unexpected remote")
    _require(tuple(hook_argv) == ("origin", _URL), "hook argv/URL mismatch")
    protected = plan["protected_refs"]
    _require(isinstance(protected, list)
             and all(_valid_ref(ref) for ref in protected)
             and len(protected) == len(set(protected)), "protected ref list")
    denied = _LITERAL_DENY | set(protected)
    rows = plan["expected_deletions"]
    _require(isinstance(rows, list) and 1 <= len(rows) <= 1024,
             "nonempty bounded deletion list required")
    expected = {}
    for row in rows:
        _require(isinstance(row, dict) and set(row) == {"ref", "old_oid"},
                 "deletion row fields")
        ref, old = row["ref"], row["old_oid"]
        _require(_valid_ref(ref) and ref not in denied, "denied/invalid ref")
        _require(ref not in expected, "duplicate planned ref")
        _require(isinstance(old, str)
                 and re.fullmatch(r"[0-9a-f]{40}", old) and old != _ZERO,
                 "expected old OID must be a nonzero SHA1")
        expected[ref] = old
    _require(isinstance(complete_stdin_bytes, bytes), "stdin must be bytes")
    _require(0 < len(complete_stdin_bytes) <= _MAX_INPUT_BYTES,
             "nonempty bounded stdin required")
    _require(complete_stdin_bytes.endswith(b"\n")
             and b"\r" not in complete_stdin_bytes, "stdin framing")
    try:
        lines = complete_stdin_bytes.decode("utf-8").splitlines()
    except UnicodeError as exc:
        raise Rejected("stdin encoding") from exc
    _require(len(lines) == len(expected), "incomplete/extra advertised ref set")
    actual = {}
    for line in lines:
        fields = line.split(" ")
        _require(len(fields) == 4 and all(fields), "exact four fields required")
        local_ref, new_oid, remote_ref, old_oid = fields
        _require(local_ref == "(delete)" and new_oid == _ZERO,
                 "only explicit deletions accepted")
        _require(remote_ref not in denied and remote_ref in expected,
                 "unplanned/denied remote ref")
        _require(remote_ref not in actual, "duplicate advertised ref")
        _require(old_oid == expected[remote_ref] and old_oid != _ZERO,
                 "advertised old OID differs from the frozen nonzero tip")
        actual[remote_ref] = old_oid
    _require(actual == expected, "complete advertised set differs")
    return {
        "accepted": True,
        "scope": "offline complete-stdin validation only",
        "count": len(actual),
        "plan_sha256": expected_plan_sha256,
        "stdin_sha256": hashlib.sha256(complete_stdin_bytes).hexdigest(),
        "refs": sorted(actual),
    }

if __name__ == "__main__":
    raise SystemExit("IMPORT-ONLY DRAFT: never install or execute as a Git hook")
