#!/usr/bin/env python3
"""Independent ROG full-v2 verification, with a local <=60-second budget.

Parent monotonic values are opaque provenance. Only the desktop caller may
compare ACK arrival with its original deadline. No proof, funding or admission
is performed here. The historical-smoke mode has zero fresh proof trials.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import stat
import sys
import time
import uuid

ROOT = Path("/home/qian-qi/work/chain-w1-funded-owner-20261107-r01")
REPO = ROOT / "repo"
PREPARED = ROOT / "prepared-inputs"
COMMIT = "d3037ca5dfb6f301757c159b7888dca9b0317be0"
TREE = "d4a8f84cdc896b9454ce0d03a164f8916e6afdf9"
SCHEMA = "TRNM-W1-ROG-INDEPENDENT-ACK1"
REQUEST_SCHEMA = "TRNM-W1-ROG-RECEIVE-REQUEST1"
QUALIFICATION_SCHEMA = "TRNM-W1-ROG-VERIFIER-QUALIFICATION1"
PROFILE = "trnm-w1-risc0-3.0.6-poseidon2-join-v2"
IMAGE = [1958252411, 3287394615, 1805488136, 1516578702, 78549041, 790278610, 301018785, 4279049364]
EXPECTED_SHA = "802adcdd951cfb4cd7271df22c3bca6af66fee9f40454c74f8b5ff2c98a1b683"
PREPARED_MANIFEST_SHA = "ff209bd2845671b6d52f8c68599e4cf9e3f06ccfb54c3285efe67a3a956cf718"
MATERIAL_SHA = "6a0400bbe34f342e7fc2f89221884482f5e7ec0743745ed0916053ab97a22ce3"
HEADER_TEMPLATE_SHA = "7b96038f228a1eedccf7b29ffc54802aba691be7259e33937846c6bf6126d78f"
HISTORICAL_RECEIPT_SHA = "6c72828c9d05a62175e08fa3e7e1d0d5e85e785ad96b5beb5ec7a2e2490c26ee"
REQUIRED_SOURCE = {
    "scripts/run_w1_receiver.py", "scripts/run_w1_deployment_comparison.py",
    "scripts/ci/verify_ci_source.py",
    "formal/pon-nakamoto-v1/experiments/w1_stage_measure.py",
    "formal/pon-nakamoto-v1/w1_v2_verifier/src/main.rs",
    "formal/pon-nakamoto-v1/w1_v2_verifier/src/image.rs",
    "formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.toml",
    "formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock",
}
FILES = {"header.bin": 318, "winner-result.json": 65536,
         "winner-intent.json": 65536, "succinct.bin": 16 * 1024**2}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, name, maximum=2**64 - 1):
    require(type(value) is int and 0 <= value <= maximum, "invalid integer: " + name)
    return value


def hex_value(value, length=64):
    require(type(value) is str and re.fullmatch("[0-9a-f]{%d}" % length, value), "invalid hexadecimal identity")
    return value


def strict_pairs(rows):
    result = {}
    for key, value in rows:
        require(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def stamp(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)


def file_record(path, maximum, collect=False):
    p = Path(path)
    require(p.is_absolute(), "absolute file path required")
    initial = p.lstat()
    require(stat.S_ISREG(initial.st_mode) and 0 <= initial.st_size <= maximum, "bounded regular file required")
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
    h = hashlib.sha256(); chunks = []; count = 0
    try:
        require(stamp(initial) == stamp(os.fstat(fd)), "file identity changed before read")
        while True:
            block = os.read(fd, 1024 * 1024)
            if not block:
                break
            count += len(block)
            require(count <= maximum, "file grew beyond byte bound")
            h.update(block)
            if collect:
                chunks.append(block)
        require(stamp(initial) == stamp(os.fstat(fd)) == stamp(p.lstat()), "file changed during read")
    finally:
        os.close(fd)
    require(count == initial.st_size, "file byte count changed")
    pin = {"path": str(p), "bytes": count, "sha256": h.hexdigest()}
    return (pin, b"".join(chunks)) if collect else pin


def json_object(path, maximum=65536):
    pin, raw = file_record(path, maximum, True)
    value = json.loads(raw, object_pairs_hook=strict_pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))
    require(type(value) is dict, "JSON object required")
    return value, pin


def same_pin(actual, selected):
    require(all(actual.get(k) == selected.get(k) for k in ("path", "bytes", "sha256")), "original file pin changed")


def domain(tag, parts):
    h = hashlib.sha256(b"TRNM-PON1\0" + len(tag).to_bytes(2, "little") + tag)
    for part in parts:
        h.update(len(part).to_bytes(4, "little")); h.update(part)
    return h.digest()


def validate_parent_binding(request, winner, intent, header):
    """Validate reported parent ordering only; never read the local clock here."""
    require(request.get("schema") == REQUEST_SCHEMA and request.get("source_commit") == COMMIT
            and request.get("source_tree") == TREE, "exact original request/source identity required")
    require(re.fullmatch("[A-Za-z0-9._-]{1,128}", request.get("request_id", "")), "request identity")
    origin = request["parent"]
    hex_value(origin["operation"])
    require(str(uuid.UUID(origin["original_boot_id"])) == origin["original_boot_id"], "parent boot UUID")
    deadline = integer(origin["original_deadline_ns"], "parent original deadline")
    require(winner.get("schema") == "TRNM-W1-NATIVE-WINNER2" and intent.get("schema") == winner["schema"],
            "original native result and pre-search intent required")
    for key in ("winner_observed", "native_replay_verified", "native_ticket_before_deadline", "winner_saved_before_deadline"):
        require(winner.get(key) is True, "native winner observation incomplete")
    require(winner.get("node_admission") is False and winner.get("production_qualified") is False,
            "native observation must not assert admission")
    for row in (winner, intent):
        require(type(row.get("original_deadline_monotonic_ns")) is int
                and row["original_deadline_monotonic_ns"] == deadline
                and row.get("original_deadline_boot_id") == origin["original_boot_id"],
                "parent original clock identity changed")
    entered = integer(intent["entered_monotonic_ns"], "reported parent entry")
    started = integer(winner["search_started_monotonic_ns"], "reported parent search start")
    hit = integer(winner["native_winner_monotonic_ns"], "reported parent winner")
    saved = integer(winner["winner_saved_monotonic_ns"], "reported parent save")
    require(entered <= started <= hit <= saved < deadline, "reported parent ordering invalid")
    require(winner.get("expected_artifacts_sha256") == intent.get("expected_artifacts_sha256") == EXPECTED_SHA
            and request.get("expected_artifacts_sha256") == EXPECTED_SHA, "independent artifact selection changed")
    require(intent.get("material_sha256") == MATERIAL_SHA and intent.get("header_template_sha256") == HEADER_TEMPLATE_SHA,
            "pre-search fixed material/template changed")
    require(len(header) == 318 and header[:4] == b"PNH1" and hashlib.sha256(header).hexdigest() == winner.get("header_sha256"),
            "native header binding changed")
    nonce = integer(winner["nonce"], "reported nonce")
    attempts = integer(winner["attempts"], "reported attempts", 10000)
    first = integer(intent["first_nonce"], "original nonce start")
    maximum = integer(intent["maximum_attempts"], "original nonce bound", 10000)
    require(1 <= attempts <= maximum and first == 0 and nonce == first + attempts - 1
            and int.from_bytes(header[310:318], "little") == nonce, "fixed nonce search identity")
    require(winner.get("challenge") == domain(b"challenge", [header]).hex()
            and winner.get("task_id") == header[278:310].hex(), "reported challenge/task differs from header")
    ticket = bytes.fromhex(hex_value(winner["ticket"]))
    require(header[118:150] != bytes(32) and ticket <= header[118:150], "reported native ticket fails target")
    hex_value(winner["input_sha256"])
    require(winner.get("input_bytes") == 49506, "reported complete native input length")
    return {"operation": origin["operation"], "original_boot_id": origin["original_boot_id"],
            "original_deadline_ns": deadline, "reported_native_winner_monotonic_ns": hit,
            "reported_native_input_sha256": winner["input_sha256"],
            "parent_timeliness_evaluated": False, "native_input_bytes_independently_verified": False,
            "provenance_authority": "caller-pinned original native records; remote hashing is not parent-clock authentication"}


def fixed_expected():
    manifest = file_record(PREPARED / "manifest.json", 1024 * 1024)
    require(manifest["sha256"] == PREPARED_MANIFEST_SHA, "original ROG prepared manifest changed")
    expected = file_record(PREPARED / "expected-artifacts.bin", 64)
    require(expected["bytes"] == 64 and expected["sha256"] == EXPECTED_SHA, "original independent expected64 changed")
    return expected


def receive_inputs(args):
    request, request_pin = json_object(args.request)
    require(request_pin["sha256"] == hex_value(args.request_sha256), "original transfer request changed")
    require(type(request.get("files")) is dict and set(request["files"]) == set(FILES), "exact four incoming files required")
    pins = {}
    for name, bound in FILES.items():
        p = Path(args.request).parent / name
        pins[name] = file_record(p, bound)
        selected = request["files"][name]
        require(type(selected.get("bytes")) is int and selected["bytes"] == pins[name]["bytes"]
                and hex_value(selected["sha256"]) == pins[name]["sha256"], "transferred file changed: " + name)
    winner, _ = json_object(pins["winner-result.json"]["path"])
    intent, _ = json_object(pins["winner-intent.json"]["path"])
    _, header = file_record(pins["header.bin"]["path"], 318, True)
    parent = validate_parent_binding(request, winner, intent, header)
    return {"mode": "new-receipt-candidate", "request": request_pin, "request_id": request["request_id"],
            "parent": parent, "files": pins, "header": pins["header.bin"], "receipt": pins["succinct.bin"],
            "fresh_generation_independently_established": False, "historical_receipt_smoke": False}


def historical_inputs():
    base = REPO / "evidence/pon-w1-full-v2-20261105"
    receipt = file_record(base / "succinct.bin", 16 * 1024**2)
    header = file_record(base / "header.bin", 318)
    require(receipt["bytes"] == 257014 and receipt["sha256"] == HISTORICAL_RECEIPT_SHA
            and header["bytes"] == 318 and header["sha256"] == HEADER_TEMPLATE_SHA, "historical smoke pins changed")
    return {"mode": "historical-receipt-smoke", "request": None, "request_id": None, "parent": None,
            "files": {"header.bin": header, "succinct.bin": receipt}, "header": header, "receipt": receipt,
            "fresh_generation_independently_established": False, "historical_receipt_smoke": True}


def qualification(args):
    q, pin = json_object(args.qualification, 1024 * 1024)
    require(pin["sha256"] == hex_value(args.qualification_sha256), "original receiver qualification changed")
    require(q.get("schema") == QUALIFICATION_SCHEMA and q.get("qualification_complete") is True
            and q.get("repo_path") == str(REPO) and q.get("source_commit") == COMMIT and q.get("source_tree") == TREE
            and q.get("source_clean_before") is True and q.get("source_clean_after") is True,
            "actual independent clean-A ROG build qualification required")
    for which in ("source_before", "source_after"):
        row = q[which]
        require(row["tested_commit"] == COMMIT and row["tested_tree"] == TREE, "build source guard identity")
        require(file_record(row["report_path"], 1024 * 1024)["sha256"] == hex_value(row["sha256"]), "retained source report changed")
    require(q.get("profile_id") == PROFILE and q.get("sdk") == "3.0.6" and q.get("image_id") == IMAGE
            and q.get("independent_reproducible_build_established") is False, "fixed verifier qualification profile")
    require(q["verifier"].get("kind") == "repository_build", "actual verifier build required")
    same_pin(file_record(q["verifier"]["path"], 512 * 1024**2), q["verifier"])
    same_pin(file_record(q["python"]["path"], 32 * 1024**2), q["python"])
    require(os.access(q["verifier"]["path"], os.X_OK) and os.access(q["python"]["path"], os.X_OK), "actual executable required")
    sources = q["source_files"]
    require(type(sources) is dict and REQUIRED_SOURCE <= set(sources), "receiver source closure required")
    for relative, digest in sources.items():
        require(not Path(relative).is_absolute() and ".." not in Path(relative).parts, "relative source path")
        require(file_record(REPO / relative, 8 * 1024**2)["sha256"] == hex_value(digest), "qualified receiver source changed")
    require(file_record(Path(__file__).resolve(), 256 * 1024)["sha256"] == q["receiver_harness_sha256"], "qualified harness changed")
    for key in ("RISC0_DEV_MODE", "RISC0_PROVER", "BONSAI_API_KEY", "BONSAI_API_URL"):
        require(key not in os.environ, "unexpected proof environment")
    return q, pin


def strict_stage(row):
    require(row.get("schema") == "TRNM-W1-STAGE-MEASUREMENT3" and row.get("stage_process_complete") is True
            and type(row.get("returncode")) is int and row["returncode"] == 0
            and row.get("completion_observed_before_deadline") is True
            and row.get("owned_session_observation_complete") is True
            and row.get("timed_out") is False and row.get("deadline_exhausted_at_snapshot") is False
            and row.get("final_owned_session_members") == [] and row.get("process_group_remaining_after_child_exit") is False
            and type(row.get("final_known_group_probes")) is list
            and all(x.get("state") == "ABSENT" for x in row["final_known_group_probes"])
            and all(row.get(k) is None for k in ("error", "canceled_signal", "cancellation_event"))
            and all(row.get(k) == [] for k in ("termination_reasons", "cleanup_errors", "proc_scan_errors", "group_probe_errors")),
            "actual local child has no complete uncancelled terminal observation")


def deadline_seconds(ns):
    seconds = ns / 1e9
    a, b = seconds.as_integer_ratio()
    return math.nextafter(seconds, -math.inf) if a * 1_000_000_000 > ns * b else seconds


def load_measure():
    path = REPO / "formal/pon-nakamoto-v1/experiments/w1_stage_measure.py"
    spec = importlib.util.spec_from_file_location("rog_fixed_w1_measure", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    require(module.TERMINATION_GRACE_SECONDS == 5 and module.MAX_TERMINATION_GRACE_SECONDS == 30,
            "reviewed nested termination contract changed")
    return module


def execute(args, entered, q, qpin, measure):
    budget = integer(args.local_seconds, "ROG local seconds", 60)
    require(budget >= 1, "ROG budget must be in 1..60 seconds")
    deadline_ns = entered + budget * 1_000_000_000
    local_deadline = deadline_seconds(deadline_ns)
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    out = Path(args.out)
    require(out.is_absolute() and out.parent.resolve(strict=True) / out.name == out
            and not any(out == p or p in out.parents for p in (REPO, PREPARED)), "new external output directory required")
    if args.mode == "receive":
        incoming = Path(args.request).parent.resolve(strict=True)
        require(out != incoming and incoming not in out.parents, "output must not alter incoming bundle")
    out.mkdir(mode=0o700, exist_ok=False)
    os.chdir(REPO)
    expected = fixed_expected()
    inputs = receive_inputs(args) if args.mode == "receive" else historical_inputs()
    initial = {"qualification": qpin, "expected_artifacts": expected, **inputs}
    intent = {"schema": SCHEMA, **initial, "source_commit": COMMIT, "source_tree": TREE,
              "receiver_boot_id": boot, "receiver_hostname": os.uname().nodename,
              "entered_monotonic_ns": entered, "local_deadline_monotonic_ns": deadline_ns,
              "local_budget_seconds": budget, "parent_timeliness_evaluated": False,
              "parent_deadline_satisfied": None, "cross_host_latency_ns": None,
              "new_proofs_generated": 0, "payment_authorized": False, "admission_authorized": False,
              "production_qualified": False, "resource_scope_complete": False,
              "transport_measurement_authority": "desktop original clock when the caller receives this ACK",
              "local_time_scope": "ROG harness entry through local ACK publication; no parent clock subtraction"}
    measure.write_new(out / "intent.json", intent)
    stages = []; source_checks = {}; inner_ack = None; verified = False; failure = None
    def stage(label, argv, grace=5):
        require(time.monotonic_ns() < deadline_ns, "local deadline exhausted before dispatch")
        entry = {"label": label, "argv": argv, "status": "UNKNOWN"}; stages.append(entry)
        try:
            value = measure.measure(argv, out / ("measure-" + label), budget, deadline=local_deadline,
                                    environment_overrides={"PYTHONDONTWRITEBYTECODE":"1", "RAYON_NUM_THREADS":"2"},
                                    termination_grace_seconds=grace)
            entry["result"] = file_record(out / ("measure-" + label) / "result.json", 8 * 1024**2)
            strict_stage(value); entry["status"] = "OBSERVED_COMPLETE"
            return value
        except BaseException as caught:
            entry["error"] = {"type":type(caught).__name__, "message":str(caught)}
            raise
    def source_check(which):
        path = out / ("source-" + which + ".json")
        stage("source-" + which, [q["python"]["path"], str(REPO / "scripts/ci/verify_ci_source.py"),
                                 "--kind", "head", "--expected-head", COMMIT, "--output", str(path)])
        row, pin = json_object(path)
        require(row.get("schema") == "trnm-ci-source-v1" and row.get("tested_commit") == COMMIT
                and row.get("tested_tree") == TREE and row.get("kind") == "head"
                and row.get("tracked_worktree_verified") is True, "actual exact-source observation required")
        source_checks[which] = pin
    try:
        source_check("before")
        argv = [q["python"]["path"], str(REPO / "scripts/run_w1_receiver.py"),
                "--verifier", q["verifier"]["path"], "--verifier-sha256", q["verifier"]["sha256"],
                "--receipt", inputs["receipt"]["path"], "--header", inputs["header"]["path"],
                "--expected-artifacts", expected["path"], "--out", str(out / "receiver"),
                "--wall-seconds", str(budget), "--deadline-monotonic", repr(local_deadline), "--deadline-boot-id", boot]
        stage("independent-receiver", argv, grace=12)
        inner_ack, inner_pin = json_object(out / "receiver/ack.json", 8 * 1024**2)
        require(inner_ack.get("schema") == "TRNM-W1-RECEIVER-ACK2" and inner_ack.get("verified") is True
                and inner_ack.get("receiver_operation_complete") is True and inner_ack.get("error") is None
                and inner_ack.get("cancellation_event") is None and inner_ack.get("deadline_exhausted_at_snapshot") is False
                and not (out / "receiver/operation-cancellation.json").exists(), "independent receiver did not complete")
        report = inner_ack["verifier_report"]
        require(report.get("schema") == "TRNM-W1-V2-FULL-VERIFY1" and report.get("profile_id") == PROFILE
                and report.get("sdk") == "3.0.6" and report.get("image_id") == IMAGE
                and type(report.get("iterations")) is int and report["iterations"] == 1
                and report.get("receipt_bytes") == inputs["receipt"]["bytes"]
                and report.get("receipt_sha256") == inputs["receipt"]["sha256"]
                and report.get("header_sha256") == inputs["header"]["sha256"]
                and report.get("expected_artifacts_sha256") == EXPECTED_SHA
                and report.get("parent_eligibility_checked") is False and report.get("admission_authorized") is False,
                "full independent fixed verifier report does not bind selected statement")
        verified = True
        source_check("after")
        same_pin(file_record(q["verifier"]["path"], 512 * 1024**2), q["verifier"])
        same_pin(fixed_expected(), expected)
        for pin in inputs["files"].values():
            same_pin(file_record(pin["path"], 16 * 1024**2), pin)
        if inputs["request"] is not None:
            same_pin(file_record(inputs["request"]["path"], 65536), inputs["request"])
    except BaseException as caught:
        failure = caught
    prior = failure if isinstance(failure, (measure.Canceled, KeyboardInterrupt)) else None
    with measure.DeferredCancellation(prior, phase="rog-independent-ack", live_deadline=(local_deadline, boot)) as handoff:
        complete = verified and failure is None and time.monotonic_ns() < deadline_ns and handoff.canceled_signal is None
        result = {**intent, "verified":verified, "receiver_operation_complete":complete,
                  "result_is_pre_handoff_snapshot":True, "actual_exit_zero_required":True,
                  "operation_cancellation_sidecar_always_vetoes":True,
                  "source_checks":source_checks, "stages":stages, "inner_ack":inner_ack,
                  "work_id":None if inner_ack is None else inner_ack.get("work_id"),
                  "local_ack_snapshot_monotonic_ns":time.monotonic_ns(),
                  "local_deadline_exhausted_at_snapshot":time.monotonic_ns() >= deadline_ns,
                  "cancellation_event":handoff.pending_event(),
                  "error":None if failure is None else {"type":type(failure).__name__, "message":str(failure)}}
        destination = out / ("ack.json" if complete else "failure.json")
        measure.write_new(destination, result)
        handoff.published_snapshot("rog-independent-ack", destination)
        if prior is not None:
            raise prior
    print(json.dumps({"schema":SCHEMA, "verified":verified, "receiver_operation_complete":complete,
                      "result":str(destination), "mode":inputs["mode"], "new_proofs_generated":0,
                      "parent_timeliness_evaluated":False, "payment_authorized":False}), flush=True)
    if time.monotonic_ns() >= deadline_ns:
        return 124
    return 0 if complete else 1


def main():
    entered = time.monotonic_ns()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("receive", "historical-smoke"))
    for name in ("qualification", "qualification-sha256", "out"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--request"); parser.add_argument("--request-sha256")
    parser.add_argument("--local-seconds", type=int, default=60)
    args = parser.parse_args()
    require((args.request is not None and args.request_sha256 is not None) if args.mode == "receive"
            else (args.request is None and args.request_sha256 is None), "request pair belongs only to receive mode")
    integer(args.local_seconds, "local budget", 60)
    require(args.local_seconds >= 1, "positive local budget")
    sys.dont_write_bytecode = True
    q, qpin = qualification(args)
    measure = load_measure()
    def owned():
        with measure.cancel_on_signals():
            try:
                return execute(args, entered, q, qpin, measure)
            except (measure.Canceled, KeyboardInterrupt) as canceled:
                if Path(args.out).is_dir():
                    measure.publish_cancellation(Path(args.out) / "operation-cancellation.json", canceled, "rog-independent-receiver")
                raise
    return measure.run_cli(owned)


if __name__ == "__main__":
    raise SystemExit(main())
