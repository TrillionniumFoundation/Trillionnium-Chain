import pathlib,subprocess,re,hashlib,json
s=pathlib.Path('/home/qq/chain-host-stat-20261118-2e9b-source')
pat=re.compile(r'test "\$\(git hash-object ([A-Za-z0-9_./-]+)\)" = ([0-9a-f]{40})')
res=[]
for wf in sorted((s/'.github/workflows').glob('*.yml')):
 for n,line in enumerate(wf.read_text().splitlines(),1):
  m=pat.fullmatch(line.strip())
  if m:
   p,e=m.groups();raw=(s/p).read_bytes();a=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
   if e!=a:res.append({'workflow':str(wf.relative_to(s)),'line':n,'path':p,'old':e,'new':a,'workflow_current_blob':subprocess.check_output(['git','hash-object',str(wf)],cwd=s,text=True).strip(),'workflow_d952_blob':subprocess.check_output(['git','rev-parse','d95239eda6a666458aa264ddeaf993d6d9fbf37d:'+str(wf.relative_to(s))],cwd=s,text=True).strip()})
c=json.loads((s/'config/pon/pq-cross-branch-corpus-v1.json').read_text())
print(json.dumps({'mismatches':res,'corpus_keys':list(c),'corpus_sample':{k:(v[:1] if isinstance(v,list) else list(v.items())[:3] if isinstance(v,dict) else v) for k,v in c.items()}},indent=2))
