import time
from pathlib import Path
Path('/workspace/scratch/ec265b67753e/collector-controls-local-03/test_actual_generation_dispatch_worker_exec_chain_is_wrapped_without_status_theft/actual-target-invocation').write_text('one real target child')
time.sleep(.2)
