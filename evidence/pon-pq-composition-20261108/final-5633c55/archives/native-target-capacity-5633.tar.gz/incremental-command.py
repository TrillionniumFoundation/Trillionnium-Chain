import os,stat,json,time,fnmatch
BASE='/home/qian-qi/work/chain-pq-composition-663507-20261108/final-native-5633c55/native-target-default'
REL=('debug/incremental','x86_64-unknown-linux-gnu/debug/incremental')
out={'schema':'two-incremental-directories-readonly-v1','target':BASE,'read_only':True,'deletion_authorized':False,'native_commands_executed':False,'threshold_bytes':int(1.5*1024**3),'observations':[],'started_unix':time.time()}
fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
try:
 for part in BASE.strip('/').split('/'):
  nf=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=nf
 for rel in REL:
  row={'path':BASE+'/'+rel,'exists':False}
  out['observations'].append(row)
  sub=os.dup(fd)
  try:
   try:
    for part in rel.split('/'):
     nf=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=sub);os.close(sub);sub=nf
   except FileNotFoundError:
    row['status']='ABSENT';continue
   row['exists']=True;rs=os.fstat(sub)
   row['identity']={'device':rs.st_dev,'inode':rs.st_ino,'mode':oct(stat.S_IMODE(rs.st_mode)),'uid':rs.st_uid}
   groups={};all_inodes={};dirs=0;symlinks=[];special=[];cross=[]
   def add(group,s,name):
    key=(s.st_dev,s.st_ino)
    if key not in group:group[key]={'allocated_bytes':s.st_blocks*512,'logical_bytes':s.st_size,'nlink':s.st_nlink,'kind':'regular' if stat.S_ISREG(s.st_mode) else 'directory' if stat.S_ISDIR(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'special','paths':[],'so_name':fnmatch.fnmatchcase(name,'*.so*'),'suffix_o':name.endswith('.o')}
    group[key]['paths'].append(name)
   for here,children,files,dfd in os.fwalk('.',dir_fd=sub,topdown=True,follow_symlinks=False):
    dirs+=1
    bucket=here.split('/')[1] if here!='.' else '(root)'
    group=groups.setdefault(bucket,{})
    ds=os.fstat(dfd);add(all_inodes,ds,here);add(group,ds,here)
    keep=[]
    for name in sorted(children):
     s=os.stat(name,dir_fd=dfd,follow_symlinks=False);p=os.path.normpath(os.path.join(here,name))
     if stat.S_ISLNK(s.st_mode):symlinks.append({'path':p,'mode':oct(stat.S_IMODE(s.st_mode))});add(all_inodes,s,p);add(group,s,p)
     elif s.st_dev!=rs.st_dev:cross.append(p)
     elif stat.S_ISDIR(s.st_mode):keep.append(name)
     else:raise RuntimeError('entry changed type: '+p)
    children[:]=keep
    for name in sorted(files):
     s=os.stat(name,dir_fd=dfd,follow_symlinks=False);p=os.path.normpath(os.path.join(here,name))
     add(all_inodes,s,p);add(group,s,p)
     if stat.S_ISLNK(s.st_mode):symlinks.append({'path':p,'mode':oct(stat.S_IMODE(s.st_mode))})
     elif not stat.S_ISREG(s.st_mode):special.append({'path':p,'mode':oct(stat.S_IMODE(s.st_mode))})
   def summarize(g):
    r=[x for x in g.values() if x['kind']=='regular'];safe=[x for x in r if x['nlink']==1 and not x['so_name']]
    histogram={}
    for x in r:histogram[str(x['nlink'])]=histogram.get(str(x['nlink']),0)+1
    return {'allocated_all_observed_inode_bytes':sum(x['allocated_bytes'] for x in g.values()),'unique_inodes_all_kinds':len(g),'regular_paths':sum(len(x['paths']) for x in r),'unique_regular_inodes':len(r),'regular_allocated_bytes':sum(x['allocated_bytes'] for x in r),'regular_logical_bytes':sum(x['logical_bytes'] for x in r),'regular_nlink_histogram':histogram,'regular_inodes_with_links_outside_counted_group':sum(x['nlink']>len(x['paths']) for x in r),'nlink1_non_so_regular_allocated_bytes':sum(x['allocated_bytes'] for x in safe),'so_name_regular_allocated_bytes':sum(x['allocated_bytes'] for x in r if x['so_name']),'dot_o_regular_allocated_bytes':sum(x['allocated_bytes'] for x in r if x['suffix_o'])}
   row['totals']=summarize(all_inodes);row['directories_observed']=dirs;row['symlink_entries']=symlinks;row['special_entries']=special;row['cross_device_directories_skipped']=cross
   row['immediate_subdirectory_totals']=[{'name':k,**summarize(v)} for k,v in sorted(groups.items())]
   after=os.fstat(sub);row['root_identity_after']={'device':after.st_dev,'inode':after.st_ino}
   if (rs.st_dev,rs.st_ino)!=(after.st_dev,after.st_ino):raise RuntimeError('incremental root identity changed')
   row['status']='READ_ONLY_METADATA_COMPLETE'
  except BaseException as e:row['status']='FAILED_INCOMPLETE';row['error']=type(e).__name__+': '+str(e);raise
  finally:os.close(sub)
 out['candidate_nlink1_non_so_allocated_bytes']=sum(x.get('totals',{}).get('nlink1_non_so_regular_allocated_bytes',0) for x in out['observations'])
 out['candidate_at_least_1_5gib']=out['candidate_nlink1_non_so_allocated_bytes']>=out['threshold_bytes']
 out['reclaimability_proven']=False
 v=os.fstatvfs(fd);out['available_bytes_observed']=v.f_bavail*v.f_frsize
 out['status']='READ_ONLY_OBSERVATION_COMPLETE'
finally:
 os.close(fd);out['finished_unix']=time.time();print(json.dumps(out,sort_keys=True,indent=2),flush=True)
