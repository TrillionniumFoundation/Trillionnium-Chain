from pathlib import Path
import subprocess,json,hashlib,sys,time,resource
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=s.parent/'hash-source-audit-10';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);sys.path.insert(0,str(s/'scripts/ci'));import hash_use_contract as c
t=time.monotonic();r=resource.getrusage(resource.RUSAGE_CHILDREN);m=json.loads((s/c.DEFAULT_MANIFEST).read_text());rows=[]
for rel,pin in m['source_files'].items():
 raw=(s/rel).read_bytes();frozen=subprocess.check_output(['git','show','HEAD:'+rel],cwd=s);current={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};rows.append({'path':rel,'pin':pin,'actual':current,'head_sha256':hashlib.sha256(frozen).hexdigest(),'head_bytes':len(frozen),'working_tree_equals_parent':raw==frozen,'changed_pin':current!=pin})
refs=subprocess.run(['git','grep','-n',c.REVIEWED_SOURCE_MAP_SHA256,'--','scripts','config','docs'],cwd=s,text=True,capture_output=True)
(out/'map-references.txt').write_text(refs.stdout);(out/'original-manifest.json').write_bytes((s/c.DEFAULT_MANIFEST).read_bytes())
p=subprocess.run(['/usr/bin/python3','-B','scripts/ci/hash_use_contract.py'],cwd=s,capture_output=True);(out/'original-reader.stdout').write_bytes(p.stdout);(out/'original-reader.stderr').write_bytes(p.stderr)
a=resource.getrusage(resource.RUSAGE_CHILDREN);res={'schema':'chain-reviewed-hash-source-current-audit-v1','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'rows':rows,'changed':[x for x in rows if x['changed_pin']],'original_reader_exit':p.returncode,'reference_files':refs.stdout,'uses':len(m['uses']),'sources':len(m['source_files']),'qualification':m['qualification'],'reviewed_semantics_sha256':c.REVIEWED_SEMANTICS_SHA256,'actual_semantics_sha256':c.sha(c.canonical({k:v for k,v in m.items() if k!='source_files'})),'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-r.ru_utime,'child_system_cpu_seconds':a.ru_stime-r.ru_stime}
(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k!='rows'},indent=2))
