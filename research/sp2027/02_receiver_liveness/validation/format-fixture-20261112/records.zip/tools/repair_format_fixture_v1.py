import ast,hashlib,importlib.util,json,os,re,stat,sys
from pathlib import Path
sys.dont_write_bytecode=True
BASE=Path('/home/qian-qi/work/sp27-02-e815');REPO=BASE/'chain';FROZEN=BASE/'publish_chain_a6.py'
assert hashlib.sha256(FROZEN.read_bytes()).hexdigest()=='6eecdcbdf9ee91db3fe740e0f4b00873645d7c8d8a97e8ec68fd0b265ad0f9b8'
spec=importlib.util.spec_from_file_location('D',FROZEN);D=importlib.util.module_from_spec(spec);spec.loader.exec_module(D)
OUT=BASE/'chain-format-fixture-repair-v1';OUT.mkdir(mode=0o700)
env=os.environ.copy();env.update({'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0','PYTHONDONTWRITEBYTECODE':'1'})
for k in ['GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']:env.pop(k,None)
log=D.Ledger(OUT,env);status,error='FAILED',None
TARGET='scripts/ci/test_run_from_zero_native.py'
EXPECTED='d94052e5777392461da80c3470d08222cc72f14a0e82f9b477b9fcf0da3f870b'
new_method="    def test_format_copy_retains_out_of_line_module_and_original_bytes(self):\n        # Negative control: the old flat copy cannot resolve #[path].\n        with tempfile.TemporaryDirectory() as directory:\n            root = Path(directory)\n            source = root / 'source/tests/public_v3_from_zero.rs'\n            support = root / 'source/examples/support/w1_from_zero.rs'\n            modules = {\n                'public_v3_from_zero/fresh_challenge.rs': b'pub fn fresh_trial() {}\\n',\n                'public_v3_from_zero/sp27_receiver_controls.rs': b'pub fn controls_trial() {}\\n',\n                'public_v3_from_zero/sp27_receiver_strata.rs': b'pub fn strata_trial() {}\\n',\n                'public_v3_from_zero/sp27_receiver_campaign.rs': b'pub fn campaign_trial() {}\\n',\n            }\n            source.parent.mkdir(parents=True)\n            support.parent.mkdir(parents=True)\n            (source.parent / 'public_v3_from_zero').mkdir()\n            source.write_bytes(b'#[path = \"../examples/support/w1_from_zero.rs\"]\\n'\n                               b'mod w1_from_zero;\\n'\n                               b'#[path = \"public_v3_from_zero/fresh_challenge.rs\"]\\n'\n                               b'mod fresh_challenge;\\n'\n                               b'#[path = \"public_v3_from_zero/sp27_receiver_controls.rs\"]\\n'\n                               b'mod sp27_receiver_controls;\\n'\n                               b'#[path = \"public_v3_from_zero/sp27_receiver_strata.rs\"]\\n'\n                               b'mod sp27_receiver_strata;\\n'\n                               b'#[path = \"public_v3_from_zero/sp27_receiver_campaign.rs\"]\\n'\n                               b'mod sp27_receiver_campaign;\\n')\n            support.write_bytes(b'pub fn trial() {}\\n')\n            for relative, content in modules.items():\n                (source.parent / relative).write_bytes(content)\n            out = root / 'observations'\n            out.mkdir()\n            flattened = out / 'formatted.rs'\n            flattened.write_bytes(source.read_bytes())\n            self.assertFalse((flattened.parent / '../examples/support/w1_from_zero.rs').is_file())\n            original_source, original_support = source.read_bytes(), support.read_bytes()\n            original_modules = {\n                relative: (source.parent / relative).read_bytes() for relative in modules\n            }\n\n            staged = driver.stage_format_copy(source, support, out)\n            self.assertEqual(staged, out / 'format-copy-source/tests/public_v3_from_zero.rs')\n            self.assertEqual(staged.read_bytes(), original_source)\n            self.assertEqual(\n                (staged.parent / '../examples/support/w1_from_zero.rs').resolve().read_bytes(),\n                original_support)\n            for relative, original in original_modules.items():\n                with self.subTest(relative=relative):\n                    self.assertEqual((staged.parent / relative).read_bytes(), original)\n                    self.assertEqual((source.parent / relative).read_bytes(), original)\n            self.assertEqual(source.read_bytes(), original_source)\n            self.assertEqual(support.read_bytes(), original_support)\n\n"
try:
    log.phase='PREPARE_FIXTURE_REPAIR'
    D.github_actor(log,'github-identity')
    D.clean_state(log,D.HEAD,D.TREE,'initial')
    D.remote_head(log,D.HEAD,'remote-a6-confirmed')
    D.read_pr(log,D.HEAD,'draft-pr-at-a6')
    log.run('preflight-before-fixture-repair',['bash','scripts/project-preflight.sh'])
    path=REPO/TARGET;before=path.read_bytes()
    log.require(D.sha(before)==EXPECTED,'exact-original-fixture')
    D.write_new(OUT/'test_run_from_zero_native.before.py',before)
    production=(REPO/'scripts/ci/run_from_zero_native.py').read_bytes()
    log.phase='REPRODUCE_REAL_FIXTURE_FAILURE'
    seq=log.seq+1
    try:
        log.run('fail-before-positive-fixture',['python3',TARGET,'BinarySelectionTests.test_format_copy_retains_out_of_line_module_and_original_bytes'])
    except D.Stop:
        stderr=(OUT/('%03d-fail-before-positive-fixture.stderr'%seq)).read_text()
        stdout=(OUT/('%03d-fail-before-positive-fixture.stdout'%seq)).read_text()
        log.require('FileNotFoundError' in stderr and 'sp27_receiver_controls.rs' in stderr
            and re.search(r'Ran 1 test in ',stderr) and 'FAILED (errors=1)' in stderr,
            'original-related-failure-reproduced-without-reinterpretation')
    else:
        raise D.Stop('expected original fixture failure was not reproduced')
    log.run('preflight-before-test-source-edit',['bash','scripts/project-preflight.sh'])
    log.phase='MINIMAL_POSITIVE_FIXTURE_EDIT'
    text=before.decode()
    start=text.index('    def test_format_copy_retains_out_of_line_module_and_original_bytes(self):')
    end=text.index('    def test_format_copy_covers_every_current_explicit_module_path(self):',start)
    updated=(text[:start]+new_method+text[end:]).encode()
    ast.parse(updated)
    def method_inventory(raw):
        tree=ast.parse(raw)
        return {(n.name,m.name):ast.dump(m,include_attributes=False)
                for n in tree.body if isinstance(n,ast.ClassDef)
                for m in n.body if isinstance(m,ast.FunctionDef)}
    old_methods,new_methods=method_inventory(before),method_inventory(updated)
    changed=[k for k in old_methods if old_methods[k]!=new_methods.get(k)]
    log.require(changed==[('BinarySelectionTests','test_format_copy_retains_out_of_line_module_and_original_bytes')]
                and old_methods.keys()==new_methods.keys(),'only-the-positive-fixture-method-changes',changed)
    temporary=path.with_name(path.name+'.sp27-fixture-repair-v1.tmp')
    with temporary.open('xb') as f:f.write(updated);f.flush();os.fsync(f.fileno())
    temporary.chmod(stat.S_IMODE(path.stat().st_mode))
    log.require(path.read_bytes()==before,'no-intervening-source-write')
    os.replace(temporary,path)
    D.write_new(OUT/'test_run_from_zero_native.after.py',updated)
    log.phase='RUN_ENTIRE_REAL_SUITE'
    stdout,stderr=log.run('pass-after-complete-driver-suite',['python3',TARGET],timeout=900)
    output=(stdout+b'\n'+stderr).decode(errors='replace')
    counts=[int(x) for x in re.findall(r'Ran (\d+) tests? in ',output)]
    log.require(len(counts)==1 and counts[0]>1 and re.search(r'^OK\s*$',output,re.M),
                'entire-unselected-suite-actually-passed',counts)
    log.require((REPO/'scripts/ci/run_from_zero_native.py').read_bytes()==production,
                'production-driver-unchanged')
    log.run('diff-check',['git','diff','--check'])
    diff,_=log.run('exact-fixture-diff',['git','diff','--',TARGET])
    names,_=log.run('changed-paths',['git','diff','--name-only'])
    log.require(names.decode().splitlines()==[TARGET],'only-one-test-file-changed')
    D.json_new(OUT/'REPAIR_RECEIPT.json',{
        'parent':D.HEAD,'parent_tree':D.TREE,'changed_path':TARGET,
        'before_sha256':D.sha(before),'after_sha256':D.sha(updated),
        'whole_suite_tests':counts[0],'fail_before_observed':True,
        'fail_before_missing_module':'sp27_receiver_controls.rs',
        'fail_before_is_preserved_failure':True,'whole_suite_after_passed':True,
        'production_driver_sha256':D.sha(production),'production_driver_changed':False,
        'native_experiments_rerun':0,'only_method_changed':changed,
        'git_diff_sha256':D.sha(diff),'commit_created':False,'pushed':False})
    status='SUCCESS'
except BaseException as exc:
    error=type(exc).__name__+': '+str(exc);log.event({'kind':'stopped','error':error,'no_automatic_retry':True})
finally:
    log.event({'kind':'final-result','status':status,'error':error});log.handle.close()
    files={str(p.relative_to(OUT)):D.file_identity(p) for p in sorted(OUT.rglob('*')) if p.is_file()}
    D.json_new(OUT/'FILES_MANIFEST.json',{'files':files})
    D.json_new(OUT/'RESULT.json',{'schema':'sp27-format-fixture-repair-result-v1','status':status,'error':error,
        'phase':log.phase,'parent':D.HEAD,'files_manifest':D.file_identity(OUT/'FILES_MANIFEST.json'),
        'native_experiments_rerun':0,'commits_created':0,'external_writes':0})
    print(json.dumps({'status':status,'error':error,'phase':log.phase,
        'result':str(OUT/'RESULT.json'),'result_sha256':D.file_identity(OUT/'RESULT.json')['sha256']}),flush=True)
sys.exit(0 if status=='SUCCESS' else 1)
