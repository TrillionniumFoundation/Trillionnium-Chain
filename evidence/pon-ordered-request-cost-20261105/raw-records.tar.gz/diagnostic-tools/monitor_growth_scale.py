#!/usr/bin/env python3
"""Run the unchanged native selector and retain external free-space samples."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

record = Path(sys.argv[1])
if record.exists():
    raise SystemExit("create-only diagnostic record already exists")
command = sys.argv[2:]
samples = []
started = time.monotonic_ns()

def sample():
    value = os.statvfs(record.parent)
    samples.append({"offset_ns": time.monotonic_ns() - started,
                    "free_bytes": value.f_bfree * value.f_frsize,
                    "available_bytes": value.f_bavail * value.f_frsize})

sample()
process = subprocess.Popen(command)
while process.poll() is None:
    sample()
    time.sleep(0.05)
sample()
result = {"schema": "external-native-filesystem-diagnostic-v1",
          "command": command, "exit_code": process.returncode,
          "monitor_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "sample_interval_seconds": 0.05,
          "source_or_binary_modified": False,
          "native_limits_changed": False,
          "samples": samples}
with record.open("x") as stream:
    json.dump(result, stream, sort_keys=True, indent=2)
    stream.write("\n")
raise SystemExit(process.returncode)
