/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/trnm_protocol-f0fc9fe0a932abce.d: crates/trnm-protocol/src/lib.rs crates/trnm-protocol/src/pq_frame.rs crates/trnm-protocol/src/pq_native_accounts_v2.rs crates/trnm-protocol/src/pq_transaction.rs crates/trnm-protocol/src/integer_evolution_v3.rs crates/trnm-protocol/src/integer_factor_v2.rs crates/trnm-protocol/src/pon_growth.rs crates/trnm-protocol/src/pon_wire.rs crates/trnm-protocol/src/pon_wire/state_root_arithmetic.rs crates/trnm-protocol/src/pon_state.rs crates/trnm-protocol/src/qualified_work_task.rs crates/trnm-protocol/src/qualified_work_task/lifecycle_v2.rs crates/trnm-protocol/src/qualified_work_task/lifecycle_v3.rs crates/trnm-protocol/src/qualified_work_task/lifecycle_v4.rs crates/trnm-protocol/src/qualified_work_task/pq_lifecycle_v4.rs crates/trnm-protocol/src/qualified_work_task/pq_lifecycle_v5.rs Cargo.toml

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libtrnm_protocol-f0fc9fe0a932abce.rmeta: crates/trnm-protocol/src/lib.rs crates/trnm-protocol/src/pq_frame.rs crates/trnm-protocol/src/pq_native_accounts_v2.rs crates/trnm-protocol/src/pq_transaction.rs crates/trnm-protocol/src/integer_evolution_v3.rs crates/trnm-protocol/src/integer_factor_v2.rs crates/trnm-protocol/src/pon_growth.rs crates/trnm-protocol/src/pon_wire.rs crates/trnm-protocol/src/pon_wire/state_root_arithmetic.rs crates/trnm-protocol/src/pon_state.rs crates/trnm-protocol/src/qualified_work_task.rs crates/trnm-protocol/src/qualified_work_task/lifecycle_v2.rs crates/trnm-protocol/src/qualified_work_task/lifecycle_v3.rs crates/trnm-protocol/src/qualified_work_task/lifecycle_v4.rs crates/trnm-protocol/src/qualified_work_task/pq_lifecycle_v4.rs crates/trnm-protocol/src/qualified_work_task/pq_lifecycle_v5.rs Cargo.toml

crates/trnm-protocol/src/lib.rs:
crates/trnm-protocol/src/pq_frame.rs:
crates/trnm-protocol/src/pq_native_accounts_v2.rs:
crates/trnm-protocol/src/pq_transaction.rs:
crates/trnm-protocol/src/integer_evolution_v3.rs:
crates/trnm-protocol/src/integer_factor_v2.rs:
crates/trnm-protocol/src/pon_growth.rs:
crates/trnm-protocol/src/pon_wire.rs:
crates/trnm-protocol/src/pon_wire/state_root_arithmetic.rs:
crates/trnm-protocol/src/pon_state.rs:
crates/trnm-protocol/src/qualified_work_task.rs:
crates/trnm-protocol/src/qualified_work_task/lifecycle_v2.rs:
crates/trnm-protocol/src/qualified_work_task/lifecycle_v3.rs:
crates/trnm-protocol/src/qualified_work_task/lifecycle_v4.rs:
crates/trnm-protocol/src/qualified_work_task/pq_lifecycle_v4.rs:
crates/trnm-protocol/src/qualified_work_task/pq_lifecycle_v5.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
