from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,traceback
root=Path('/home/qq/chain-system-security-20261112-306929')
expected='bac6b7659bd7e2d633e25c2da0add60f6a10c7fb'
campaign=root/'trillionnium/target/chain-system-security-receipts/incentives-bac6b7659bd7-20261112-v1'
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0')
def git(*args):return subprocess.check_output(['git',*args],cwd=root,env=env).decode().strip()
assert git('rev-parse','HEAD')==expected and git('status','--porcelain')==''
subprocess.run(['bash','scripts/project-preflight.sh'],cwd=root,env=env,check=True)
out=campaign/'python-pinned'
out.mkdir()
results=[]
def run(name,argv):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.stdout.log')).open('xb') as stdout,(out/(name+'.stderr.log')).open('xb') as stderr:
  result=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
 row={'name':name,'argv':argv,'exit_code':result.returncode,'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 results.append(row)
 (out/(name+'.receipt.json')).write_text(json.dumps(row,sort_keys=True,indent=2)+'\n')
 print(json.dumps(row,sort_keys=True),flush=True)
 assert result.returncode==0,name+' failed'
 return row
failed=None
try:
 interpreter='/home/qq/.local/bin/python3.12'
 run('interpreter',[interpreter,'-c','import json,sys;print(json.dumps({"executable":sys.executable,"version":sys.version,"version_info":list(sys.version_info)}))'])
 info=json.loads((out/'interpreter.stdout.log').read_bytes())
 assert info['version_info'][:2]==[3,12]
 run('venv',[interpreter,'-m','venv',str(out/'environment')])
 python=str(out/'environment/bin/python')
 requirements=root/'formal/pon-nakamoto-v1/requirements.txt'
 (out/'requirements.txt').write_bytes(requirements.read_bytes())
 run('install',[python,'-m','pip','install','--disable-pip-version-check','--only-binary=:all:','--no-cache-dir','--report',str(out/'pip-report.json'),'-r',str(requirements)])
 run('pip-check',[python,'-m','pip','check'])
 run('versions',[python,'-c','import json,sys,numpy,cryptography;print(json.dumps({"executable":sys.executable,"python":sys.version,"numpy":numpy.__version__,"cryptography":cryptography.__version__},sort_keys=True))'])
 versions=json.loads((out/'versions.stdout.log').read_bytes())
 assert versions['numpy']=='1.26.4' and versions['cryptography']=='50.0.2'
 run('freeze',[python,'-m','pip','freeze','--all'])
except BaseException as error:
 failed={'class':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 same=git('rev-parse','HEAD')==expected and git('status','--porcelain')==''
 summary={'schema':'chain-incentive-pinned-python-preparation-v1','source_commit':expected,'native_run_id':'incentive-'+expected+'-20261112-v1','results':results,'failure':failed,'source_unchanged':same,'requirements_path':'formal/pon-nakamoto-v1/requirements.txt','requirements_sha256':hashlib.sha256((root/'formal/pon-nakamoto-v1/requirements.txt').read_bytes()).hexdigest(),'ready':failed is None and same,'python':str(out/'environment/bin/python'),'native_tests_started':False,'global_environment_modified':False}
 (out/'preparation-terminal.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'ready':summary['ready'],'terminal':str(out/'preparation-terminal.json'),'source_unchanged':same},sort_keys=True),flush=True)
raise SystemExit(0 if summary['ready'] else 1)
