from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'snapshot-lock-fix-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);res={'schema':'chain-snapshot-lock-copy-boundary-fix-v1','stages':[],'complete':False}
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(src.parent/'target');env['PATH']='/home/qq/.cargo/bin:'+env['PATH']
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=src,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['stages'].append(row);save();print(json.dumps(row),flush=True)
 if name.endswith('controls') or name=='original-observer-suite':
  print((out/(name+'.stdout')).read_text(errors='replace')[-16000:],flush=True);print((out/(name+'.stderr')).read_text(errors='replace')[-3000:],flush=True)
 return rc
try:
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 original=json.loads((src.parent/'snapshot-lock-original-control-1/RESULT.json').read_text());assert original['complete'] and original['native_exit_code']==101
 original_log=(src.parent/'snapshot-lock-original-control-1/original-lock-controls.stdout').read_text();assert '0 passed; 3 failed; 0 ignored' in original_log
 relative='trillionnium/crates/trnm-pon-node/src/ingress/public_v3/request_observation.rs';p=src/relative;old=p.read_text();(out/'before.rs').write_text(old)
 needle='                let mut value = row.clone();\n                #[cfg(test)]';assert old.count(needle)==1
 intermediate=old.replace(needle,'                let mut value = row.clone();\n                drop(row);\n                #[cfg(test)]');p.write_text(intermediate)
 assert run('format',['/home/qq/.cargo/bin/cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all'])==0
 (out/'release-only.rs').write_bytes(p.read_bytes());testcmd=['/home/qq/.cargo/bin/cargo','test','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--release','--locked','--offline','--lib','ingress::public_v3::request_observation::snapshot_lock_tests','--','--nocapture','--test-threads=1']
 rc=run('release-only-controls',testcmd);log=(out/'release-only-controls.stdout').read_text();assert rc==101 and '2 passed; 1 failed; 0 ignored' in log
 text=p.read_text();anchor='        for cell in self.0.rows.iter().filter_map(OnceLock::get) {\n            if let Ok(row) = cell.row.lock() {';assert text.count(anchor)==1
 text=text.replace(anchor,'        for cell in self.0.rows.iter().filter_map(OnceLock::get) {\n            // Acquire each owner closure BEFORE copying any mutable row. A\n            // later close cannot make this earlier live copy look complete.\n            let connection_closed = cell.connection_closed.load(Ordering::Acquire);\n            let task_closed = cell.task_closed.load(Ordering::Acquire);\n            if let Ok(row) = cell.row.lock() {')
 text=text.replace('                drop(row);\n','                // Never retain the reactor row while waiting for another\n                // owner: reactor updates use try_lock and must not be lost.\n                drop(row);\n',1)
 before='                value.connection_closed = cell.connection_closed.load(Ordering::Acquire);\n                value.task_closed = cell.task_closed.load(Ordering::Acquire);';assert text.count(before)==1
 text=text.replace(before,'                value.connection_closed = connection_closed;\n                value.task_closed = task_closed;');p.write_text(text)
 assert run('final-format',['/home/qq/.cargo/bin/cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all'])==0
 (out/'candidate.rs').write_bytes(p.read_bytes());(out/'snapshot-tests.rs').write_bytes(p.with_name('request_observation_snapshot_tests.rs').read_bytes())
 rc=run('final-copy-boundary-controls',testcmd);assert rc==0
 suite=testcmd.copy();suite[11]='ingress::public_v3::request_observation::'
 rc=run('original-observer-suite',suite);assert rc==0
 assert run('diff-check',['git','diff','--check'])==0
 diff=subprocess.check_output(['git','diff','--',relative],cwd=src);(out/'production.patch').write_bytes(diff);res['production_patch']={'bytes':len(diff),'sha256':hashlib.sha256(diff).hexdigest()};res['test_file']={'path':str(p.with_name('request_observation_snapshot_tests.rs')),'bytes':p.with_name('request_observation_snapshot_tests.rs').stat().st_size,'sha256':hashlib.sha256(p.with_name('request_observation_snapshot_tests.rs').read_bytes()).hexdigest()};res['complete']=True;save();print(json.dumps(res,indent=2),flush=True)
except BaseException as e:
 res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
