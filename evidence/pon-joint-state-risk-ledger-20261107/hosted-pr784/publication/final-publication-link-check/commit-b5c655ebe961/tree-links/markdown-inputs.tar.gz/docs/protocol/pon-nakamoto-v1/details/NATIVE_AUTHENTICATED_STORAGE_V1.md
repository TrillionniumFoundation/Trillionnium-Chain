# Explicit native authenticated storage V1

## Status and scope

`Node::open_with_authenticated_state` selects a fresh local storage namespace.
It installs persistent account nodes and authenticated state records in the
**same `native.sqlite` database and the same native write transaction** as the
actual admitted block and its canonical deltas. No `AccountArchive` or
`AuthenticatedStateArchive` connection is opened by this backend.

The existing consensus profile, header state root, transaction signatures,
work/ticket relation, difficulty and required-work fork choice retain their
meaning. This is a local storage selection, not a new consensus revision or a
partial-State executor. The complete `State`, complete non-account partition and
independent full root construction remain required. The installed 65,536 total
state-key capacity does not change. Public service, work hardness and production
qualification remain separate acceptance obligations.

Source ownership is the native Node in
[`store.rs`](../../../../trillionnium/crates/trnm-pon-node/src/store.rs), its
[`native_authenticated` transaction component](../../../../trillionnium/crates/trnm-pon-node/src/store/native_authenticated.rs),
and the reused Patricia node implementation through
[`native_store`](../../../../trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_store.rs).
The earlier [account archive](ACCOUNT_ARCHIVE_PROTOTYPE_V1.md) and
[authenticated archive](AUTHENTICATED_STATE_ARCHIVE_V1.md) keep their independent
research namespaces; their publication APIs do not authorize native writes.

## Selection and durable identities

| Entry or identity | Meaning |
| --- | --- |
| `Node::open` and existing owner openers | Existing branch backend; its DDL and `native-branch-schema-v2` domain retain their exact bytes. |
| `Node::open_with_authenticated_state` | Explicit integrated authenticated backend. An existing legacy database is rejected rather than converted during open. |
| `Node::open_with_authenticated_state_and_fault` | The same explicit backend with the existing initialization fault hooks. |
| `native-authenticated-branch-schema-v1` | Hash domain for the exact legacy DDL plus the two integrated tables. |
| `pon-native-authenticated-state-record-v1` | Strict canonical stored record, with a separately hashed record identity. |
| `Node::authenticated_account_multiproof` | Read a compact account query from the actual integrated tree in one SQLite read snapshot. |
| `Node::migrate_to_authenticated_state` | Explicit checked legacy source to fresh destination migration; detailed below. |

The existing native CLI exposes `--state-backend authenticated-v1` through its
ordinary Node-opening helper, including local status, mining, sync and service
commands. Omitting the flag, or selecting `--state-backend legacy-v2`, preserves
the existing default backend. An authenticated selection combined with an
external task/mining/continuous-owner journal is explicitly refused until that
ownership combination has its own opener. Migration remains a separate API on
the already held source Node; an ordinary CLI open must not silently recover or
convert a source before an intended migration snapshot.

The additional tables are:

```sql
CREATE TABLE archive_nodes(id BLOB PRIMARY KEY,data BLOB NOT NULL);
CREATE TABLE native_state_commitments(block BLOB PRIMARY KEY,data BLOB NOT NULL);
```

`archive_nodes` uses the existing content-addressed Patricia node bytes and hash
domains. A leaf retains the owner, balance and nonce. Compressed forks retain
their depth, representative path, child identities and child hashes. Each child
is checked for its actual encoded identity, depth, path and lifted hash before
use. The native schema selects these rows; there is no inference from an archive
database file or from a caller's serialized checkpoint.

Each `native_state_commitments` row binds its native block and parent, the parent
record identity, height, complete packet digest, canonical delta count/root,
complete authenticated `StateCommitment`, and persistent account root node,
digest, count and balance. The complete commitment binds the existing state root,
account root/count/balance, complete non-account root/count, escrow, rewards and
issued funds. Strict decoding rejects unknown fields, noncanonical bytes,
incorrect identities and inconsistent account projections.

The default opener rejects the additional schema. The authenticated opener
rejects the old schema. Both reject a pending migration marker, including a
symbolic link at that marker name. No opener removes that marker to conceal a
failed migration. Existing protected owner markers remain mandatory; the new
plain opener cannot bypass a task, mining or continuous-owner requirement.

## Actual block admission and incremental account persistence

Admission first performs the existing full native work and application checks.
It also records qualified task output after M06 when the selected task requires
that operation. The final `output.state`, including that product record, is the
source of the new authenticated commitment. The pre-product M06 state cannot
stand in for the final header state.

The existing immediate SQLite transaction then writes the actual block,
ancestry index, canonical deltas and any scheduled full snapshot. In the new
backend that same transaction performs the following additional work:

1. Read and verify the retained parent commitment, actual complete parent state
   and required account nodes.
2. Read the actual ordered `deltas` rows and compare them with the exact native
   before/after state difference. A omitted row cannot be hidden by a full
   snapshot of the child.
3. For each changed account, authenticate its old leaf against the original
   parent root and retain its existence and nonce. Sort all changes by hash path,
   merge their compressed subtrees and save each final changed path once. A missing child node is a data error, not an absent account.
4. Derive account count and balance from those changes. A wide signed
   accumulator prevents a credit-before-debit key order from overflowing a
   valid final `u64` total. Account deletion or decreasing nonce is rejected.
5. Independently rebuild the complete final state's account/non-account roots
   and funds. Compare those results with the incrementally persisted account
   root, count and balance.
6. Write the authenticated record, then read the actual stored nodes, record,
   required delta history and genesis anchor before commit.

Genesis alone seeds the complete initial account tree. Later blocks reuse
unchanged nodes and retain prior versions for inactive branches. Neither the
reference calculation nor the stored record alone is accepted in place of the
other. The complete record is created from the actual Node execution, not from
a deserialized observation supplied by an archive caller.

Block, ancestry, delta, snapshot and authenticated-record writes check their affected
row counts. Content-addressed duplicate node writes also compare existing actual
bytes. Before COMMIT, both backends reread the exact deltas and packet, reconstruct
the stored parent and child states, and check the active state. The newly inserted
ancestry row set must exactly match its private operation-local expected rows after
all subsequent writes; each row and its visible halves remain checked. A cancelled or
failed transaction retains no subset of its new block, account paths or record.
The final cancellation fence precedes commit; there is no later cancellation
that retroactively changes a committed block into failure.

## Reads, selection, reorganization and recovery

`read_active` reads actual KV bytes and checks the installed header root as
before. With the new backend, it also checks the complete authenticated
commitment and traverses every required account node, comparing the real leaves,
count and balance with the complete state. `state_at` keeps the existing
snapshot/delta reconstruction, with the same authenticated comparison at every
reconstructed state. A missing record or node has no ordinary-KV fallback.

Non-genesis full snapshots remain declared optional accelerators under the
existing retention rule. Canonical deltas and the genesis snapshot remain the
reconstruction anchors. The integrated history check seals every required
delta record and parent relation back to genesis. Account nodes needed for an
individual state are checked when that state is read; this does not constitute
a perpetual audit of every inactive branch's physical storage.

### Explicit historical account-query pins

`Node::pin_authenticated_account_query` performs the existing complete-State
reconstruction and verification once in one read snapshot. It issues an opaque,
non-deserializable process-local `PinnedNativeAccountQuery`, binding context,
historical checkpoint, exact authenticated record and bounded native block bytes.
It is an explicitly retained historical query input, not an optional arithmetic
cache or a fresh assertion about current KV. The caller owns its lifetime and
storage; the Node adds no unbounded pin registry or durable schema.

`authenticated_account_multiproof_at_pin` rereads namespace/context, the exact
record and native block identity, then traverses actual content-checked Patricia
nodes to construct and verify AAM1. It does not replay State or history. Missing
records/nodes and changed bindings fail; missing storage cannot become proved
absence or a complete-State fallback. Each query retains the original request
bounds, cooperative cancellation, same-connection write fence and rollback.

The pin selects fixed historical content. An active-branch change does not make
it current-use authority, and a valid proof does not audit unrelated live KV or
historical deltas. There is no retention promise: required roots must still be
available. Cold open, native admission, undo/reorganization, final commit and the
original strict account query retain their full checks. Pin issuance remains
linear, default roots/wire/caps are unchanged, and neither I03 bounded-parent
execution nor complete PN2 acceptance follows. SQLite page/RSS/time costs and
total retained caller pins are not qualified by Patricia point-read counts.

Differential tests compare actual signed-block and original strict-query bytes,
prove repeated queries work while KV/snapshot/delta tables are unavailable,
check cancellation and record/context/block/node damage, and require unchanged
cold open to reject damaged live KV even when historical proof content survives.

### Bounded reuse of exact arithmetic inputs

The native Node owns one volatile arithmetic cache. It retains at most three
complete canonical State encodings, each limited to 4 MiB, together with the
network, parameters and genesis inputs to their complete commitment calculation.
Every lookup serializes the actual complete State again and compares those exact
bytes. It does not use `Value` equality, an asserted state root, a block identifier
or the active generation as proof of unchanged State. Oversized inputs and local
cache contention use the original complete calculation without retaining an entry.
An integer and a floating representation cannot alias; the original range error
for a disallowed floating value remains an error after a successful integer read.

The same owner also retains at most 8,192 compressed-path hash results. A key
contains every variable mathematical input: node path, node digest, source depth
and target depth. The omitted empty-tree table is the immutable compiled hash
grammar. Fixed eight-way buckets replace only bounded optional arithmetic entries
after checking every input field; capacity does not clear the entire cache.
Complete account-root
construction still parses, orders and rebuilds every supplied account; it can
reuse only the lift arithmetic for unchanged inputs. Stored-tree verification
still reads each actual SQL node, checks its content identity and
parent path/depth/hash relation, and compares every leaf, count and balance with
the complete State. The complete-root calculation takes accounts from actual
State and never substitutes account values retained from the stored tree.

The separate bounded decode pool may reuse a parsed node only after matching its
complete freshly read SQL bytes and expected content ID. It supplies no row or
graph-validity result. These pools retain no database validity verdict, history
prefix, selected block or execution authority. Current KV, records,
deltas, packet bytes, required archive nodes and all historical links are read
and checked as before, including after transaction triggers and during recovery.
Consequently a cache hit requires no claim that SQLite `data_version` detects
same-connection writes: no read is skipped on that basis. Warm-cache tests damage
actual rows through a second connection and require the same local-integrity
error as a cold cache. Existing late-trigger, old-delta, cancellation, branch and
reopen regressions remain required. This change reduces repeated hash arithmetic;
the State and history scans remain linear in their respective sizes.

### Account commitment without storage-record construction

The complete account-root arithmetic entry now builds a private `RootDigest`
containing only path, depth and digest. These are the same mathematical inputs
used by the original Patricia construction and exact-input lift cache. Each leaf
reuses its path from the current call's complete account ordering. Fork shape,
child lift order and branch hashes retain the original rules. A commitment-only
calculation therefore avoids creating encoded storage records and their content
IDs, which do not contribute to the final account digest.

Actual persistence and graph verification continue to construct or decode full
`Node` records and check their IDs, child links and all original progress points.
The new type has no placeholder ID, database handle or stored-node authority.
The original record-building root and an independent full sparse-tree relation
remain differential references. Exact-value, owner/nonce changes, malformed
internal shape, collision, cancellation order and lift-depth controls accompany
the paired complete-account-root observation. Its cost excludes State parsing,
SQL graph verification, Host checks, PQ authorization and client confirmation.

### Exact strings in the existing complete-root arithmetic pool

The separate complete-root arithmetic entry keeps the existing 2 MiB retained
payload and 16 MiB retained software-charge limits. Original leaf-hash and
partition-root arrays have priority. Only remaining payload space may retain
complete keys and unescaped ASCII JSON string bytes, with their original hashes.
Each key retains independently computed original key/leaf hashes. Different keys
may share one private immutable value allocation only after full canonical-byte
equality. A bounded single-candidate index uses length and edge bytes to locate
a possible allocation; it is not a fact key or a substitute for complete input
comparison. An index collision retains independently charged storage when space
allows, without an unbounded candidate bucket or cross-key hash reuse.

The charge includes all retained key bytes, entry descriptors, value descriptors,
reference-count/alignment allowance, unique value-allocation bytes and added
string-array bookkeeping. Actual allocation identity determines charging only:
equal bytes in distinct allocations are charged separately, rejected entries
cannot mark a value as paid, and a new key borrowing an old allocation still pays
for it if no prior key survives. Boxed slices retain no spare vector capacity. These are
retained-material limits, not peak RSS or an exemption for transient input work.

An opaque complete-input builder accepts actual keys and values; no public API
accepts a precomputed hash, partial update, claimed root or validity decision.
M06 first performs its original complete grammar and key-count validation.
A raw string hit requires the full current key and all current string bytes to
match a private prior canonical encoding. Every miss uses the original encoder
and original key/leaf hash domains. Escapes, controls, non-ASCII values, integers,
floats, nested values, additions, removals and changed keys cannot alias that hit.
Original cache-offer encoding and its allocation/workspace charging are unchanged.

New strings get no replacement credit while old retained bytes remain owned.
Successful complete calculation can drop unused strings and refill on a later
call; tree material remains first in the same pool. Failure, collision, an input
producer error or an abandoned builder cannot publish partial material. When the
tree itself cannot be retained, bounded candidate-string work can be discarded;
this cold cost remains part of the actual calculation and needs measurement.
The operation-local value index is lazy and bounded by prior/pending retained
entries. It is discarded with the builder and does not constitute retained
material. A complete successful publication stores its calculated string charge;
warm exact-key hits still compare every current byte and need no index build.

The local root observation uses `pon-native-complete-root-arithmetic-v3`.
It separates all input rows observed, leaves actually hashed, exact-string hits
and encodings reused. For a successful complete partition calculation,
`observed = hashed + exact hits`; a warm hit must not be reported as a fresh hash.
Current account graphs, SQL, context, nonce, liabilities, revocation and live-use
checks remain owned by their original validators. This math entry is never an
authorization cache or a promise that state access is proportional to touched keys.

### Bounded account-graph readback inside one writer

After the original transaction's writes, the private `PostWriteReadback` scope
may share graph work among its original four roles: the child, genesis, the
parent nominated by the fully verified child, and the actual active tip. Each
use first checks its current Record, block, delta bindings and **complete current
StateCommitment**, including account root, count, balance, nonce/existence and
all non-account obligations. Identical whole roots require the same exact node
identity, digest, count and balance; digest equality alone is insufficient.

The first complete graph can also produce one fixed frontier of at most sixteen
disjoint subtrees, selected by the first four account-path bits. A frontier entry
binds the actual encoded node ID, path, depth, digest, descendant-node count,
account count and checked balance. It is sealed only after the original final
callback and the scope's no-write/context/schema checks. A private access object
binds the actual Connection, current immutable State/Record and sealed frontier;
there is no externally supplied preverified root or serializable receipt.

A later different root still loads the real SQL root and every exposed edge,
preserving the original node identity, depth, prefix, side and lifted-hash checks.
Only an exact subtree match can omit descendants already checked in that same
unchanged writer. All exposed leaves must equal current State; hidden leaves
remain bound by the complete current State commitment. Covered descendants
still count toward the original graph-node bound. Potential aggregate overflow
or node-limit refusal uses the original traversal to preserve error ordering.

The final callback and original transaction fence remain mandatory. Writes,
including no-row writes, invalidate the frontier; a write after any successful
reuse refuses the owning transaction. A partial result cannot nominate another
record, become a whole-root result, replace the source, or enlarge the frontier.
No graph result survives its writer, connection, SQL epoch or schema. Ordinary
no-scope verification, cold open, recovery, required ancestry and live authority
checks retain their original paths.

This is a bounded local readback optimization. The first complete graph, current
State reconstruction/commitment and historical scans remain. Deliberately chosen
owners can occupy one path bucket and obtain no partial-reuse benefit; sixteen
buckets do not establish balanced work or O(touched-set) cost. The original
public Host and confirmation gates must measure the resulting end-to-end work.

There is one native `active` selection and one existing reorganization journal.
The backend does not introduce a second active account pointer that would need
a separate cross-database commit. Required-work selection retains its original
policy, including rejection of a lower-work requested target.

The native commit boundary also fixes concrete faults in the old backend,
without changing its schema. After the final event write, activation now checks
the expected tip, generation, slot, actual state root and exact event rows
**before** COMMIT. Reorganization staging checks the actual post-step state and
cursor, and final publication checks the active selection, events, completed
journal row and state after all writes and trigger effects. A suppressed delta,
an event trigger deleting KV, or an event trigger rewinding the active pointer
causes rollback instead of a successful unreadable head or a post-commit error.
The final active-tip ancestry levels, seals, visible half links and exact row count
are checked in that same commit fence. A late event that deletes jump rows or adds
a spurious level therefore cannot publish a successful unreadable selection.

Reorganization remains resumable through its original several transactions.
Failure during its final publication preserves the already committed pending
intent and checked cursor; it does not pretend that the whole reorganization
was one transaction. After the failing condition is removed, ordinary recovery
resumes that intent. Local replay, outbox, pool, owner facts and monotone event
generations are not restored from a branch snapshot.

## Compact proofs from the installed native tree

`authenticated_account_multiproof(block, owners)` accepts an actual retained
native block locator and the requested owners. It reads that state in one
SQLite snapshot, verifies its stored commitment and nodes, and constructs an
opaque account-query checkpoint from the actual retained root. It then derives
AAM1 bytes directly from those `archive_nodes` rows.

The returned tuple contains the opaque checkpoint, untrusted serialized
`Multiproof`, and construction observation. `CheckedMultiproof::verify` still
checks the proof before its account values can gate execution. Its checkpoint
is a binding for this native point query; it makes no assertion that a separate
AccountArchive checkpoint or archive ancestry was persisted. A caller cannot
replace the node root or account values through a report argument. The API
requires the explicit authenticated backend and has no silent legacy fallback.

`authenticated_account_multiproof_with_progress` preserves that relation while
exposing cancellation before the read snapshot, throughout historical State replay
and retained-node verification, during actual trie reads and proof hashing, and
before output. The original method delegates with a no-op callback. Oversized
requests (more than66,049 owners) and duplicate owners reject before opening a
transaction or reading State; the explicit-backend refusal retains precedence.
The existing `NATIVE_ACCOUNT_PROOF:Budget` and `InvalidWitness` diagnostics remain.
Cancellation returns the caller's original typed error and drops the read
transaction without returning a partial proof. A missing/corrupt actual node still
carries local-integrity provenance. Individual commitment and canonical-JSON
primitives remain bounded single stages; these callbacks do not preempt each hash.

This query already shares the actual native state source with compact proof
construction. It still performs a full-state verification before serving the
query. It therefore establishes source binding and format interoperability,
not a measured constant-cost proof service.

## Explicit migration into a fresh destination

[`authenticated_migration`](../../../../trillionnium/crates/trnm-pon-node/src/store/authenticated_migration.rs)
provides `migrate_to_authenticated_state` and its cooperative-progress variant.
The caller supplies an already open legacy Node and a **new destination
directory**. Existing destinations are refused. The source owner lock and an
immediate SQLite transaction fence the source snapshot; migration does not
admit, activate, acknowledge, recover or mutate anything in the source.
The destination's canonical parent must be outside the source directory, including
when a symbolic-link alias points back into the source.

Migration checks the exact source schema, metadata, integrity, local history,
replay, outbox and pool. It independently revalidates retained blocks, work,
ordered execution, task output, exact deltas, snapshots and ancestry. It copies
every legacy table, including local events, replay/outbox, pool and
`sqlite_sequence`, into the new schema. It builds the authenticated nodes and
records from those actual replayed states in the destination's transaction.
The only permitted difference in the copied cells is the explicit schema
metadata value. A typed, ordered digest and direct row comparison verify each
preserved table.

An existing pending reorganization is verified and copied as pending; migration
does not complete it in the source. A later explicit destination open may resume
it through ordinary checked recovery. Migration itself preserves the source
tip, generation, cursor and irreversible facts exactly.

Publication has two distinct filesystem boundaries:

1. Create a private `native-authenticated-migration-staging-*` sibling, write and
   synchronize `authenticated-migration.pending`, then synchronize the staging
   and parent directories. The requested destination does not exist yet.
   Safe `rustix::fs::renameat_with(..., RenameFlags::NOREPLACE)` atomically makes
   that already fenced directory visible at the destination. An existing or
   concurrently created destination is never replaced. The explicit migration
   implementation currently requires Linux; an unsupported or failed atomic
   rename returns an error without falling back to an overwriting rename.
2. In the fenced destination, commit the complete copy and authenticated records,
   close the writer, and open a new SQLite connection to verify actual committed
   disk bytes. Under its immediate transaction, directly compare every preserved
   row and both derived tables, write and synchronize `authenticated-migration.json`,
   and synchronize the database and directory. After the **last** caller progress
   callback, repeat schema/integrity, exact row and derived-table checks without
   calling user code again. Check raw database/WAL/journal/owner fingerprints,
   inode identities, exact file names, and marker/receipt bytes. Close the clean
   connection, then remove the pending marker and synchronize the directory.

Raw file checks prevent a same-inode file change from being hidden by SQLite's
cached pages. The source's durable database, WAL and owner payloads are checked
unchanged as well; SQLite shared-memory lock/read marks are coordination state,
not migrated irreversible facts. No source checkpoint, recovery or acknowledgement
is executed. These checks do not authorize bypassing the filesystem or writer
locks after the operation has completed.

Failure or cancellation after staging creation but before destination visibility
retains that private staging directory. The operation has not created the target;
an independently existing or racing target is left intact. A later failure retains
the target's pending marker, so both ordinary and authenticated openers refuse it. A retry
uses another fresh destination and never silently removes the marker or resumes
an unverified partial copy. If interruption happens after final publication, the
already fully checked target may exist without a returned receipt; that does not
turn an incomplete copy into success. The saved receipt is evidence of this local
copy, and grants no production activation or permission to delete the source.

Migration refuses external task, mining and continuous-owner configurations.
Their separate protected journals would require an explicit ownership migration
relation; copying a database must not downgrade their required owner mode.

## Native tests and independent observation

The test source is
[`native_authenticated_tests.rs`](../../../../trillionnium/crates/trnm-pon-node/src/native_authenticated_tests.rs).
Its principal fixture is
`native_authenticated_signed_growth_branches_reopen_and_compact_queries`: it
actually admits 36 non-genesis blocks with 10 signed transfers across branches,
selects a reorganization, continues to height 34 through reward maturity and
cold reopens. Every retained state is compared with an ordinary native Node
given the same real packets. AAM1 membership, nonce and nonmembership queries
come from the integrated SQLite tree.

Only that fixture honors `TRNM_NATIVE_AUTHENTICATED_STATE_EXPORT_DIR`. It requires
a nonexistent destination and exports `native.json` plus a closed SQLite copy
created by `VACUUM INTO`. The manifest contains the actual complete retained
states, initial context, active selection and compact query. Independent readers
must use the database and reconstruct the claims; a manifest's presence is not
a pass.

Additional native tests cover old/new schema separation; missing persistent
nodes and corrupted commitments; block/delta/node/record write suppression;
late final-write corruption in fast and resumable selection; cancellation;
post-M06 signed qualified task output; and process exit with code 89 at the last
pre-commit fence. The process-exit parent test cold reopens and compares every
logical table to the pre-transaction state. This is an actual no-destructor
process exit, not a hardware power-loss experiment. The separately selected
child helper returns immediately outside that parent-controlled subprocess.

Migration tests separately cover checked signed branches, preservation of local
irreversible rows, pending reorganization phases, cancellation/publication
markers and corrupted source rejection. The complete fixture migrates six
non-genesis blocks with five signed transactions, including inactive branches,
completed and pending replay, a retained outbound wire, pool consumption/removal
and the exact AUTOINCREMENT frontier. It alone honors
`TRNM_AUTHENTICATED_MIGRATION_EXPORT`, creating a new directory containing
`native.json`, `source.sqlite` and `native.sqlite` before opening or recovering
the target. The independent storage reader compares every preserved SQLite cell
and reconstructs all retained states, native signatures and authenticated nodes.

The migration tests also exercise four pending-reorganization cursors, eleven
cooperative cancellation points, racing destination creation, canonical source
aliases, an actual local external-owner journal refusal, source SQL-writer
exclusion, post-commit changes and last-callback raw database/marker/receipt
changes. Five actual child-process exits with code 87 cover pre-visibility,
visible-but-fenced, pre-COMMIT, post-COMMIT and pre-publication states. Cold reopen
checks preserve the source, refuse pending copies and allow a fresh retry. These
are no-destructor process exits, not hardware power-loss qualification.

Source tests and this document do not
claim current hosted-head or prospective-merge success; those results must be
bound to the exact delivered commit.

## Batched paths and equivalent account-check primitives

The account delta adapter checks every changed leaf against the original parent,
then recursively merges sorted updates. It retains all old nodes and branch roots;
there is no garbage collector or history rewrite. Every node newly inserted by a
successful batch is reachable from its final account root. For `A > 0` final
accounts this limits new nodes to at most `2A-1` and their encoded payload to
`49A + 163(A-1)` bytes. At `A=65,536` that payload bound is13,893,469 bytes.
This excludes SQL keys, indexes, pages, WAL and all prior versions; it is neither
a total storage bound nor a measured allocation/latency result. Empty account
states insert no nodes. The test-only serial algorithm remains an independent
root, account and complete proof-byte reference for multiple retained branches.

The shared node primitives reuse prepared SELECT/INSERT statements while actually
executing every required row operation. A full account scan borrows each JSON
`Value` during deserialization, preserving accepted objects and exact two-element
arrays and the existing arbitrary-precision dispatch. Leaf decoding retains the
actual content hash, exact49-byte grammar and all field checks, then constructs
the same fields without allocating and hashing the identical encoding again.
Fork shape, child-path checks, cancellation and complete tree comparison remain.

`native_complete_account_verification_cost` is an explicit release-only ignored
observation which CI executes separately. It compares the original primitives
with the current complete account-tree check for actual retained states, in
alternating paired order, and retains every sample. A cached statement's SQLite
`Run` counter describes executions of that particular statement; it is not a
count of total statement preparations, physical reads or omitted work in the
reference arm. The clock excludes full State commitment, whole Node admission,
historical reconstruction and lock queueing. No speed threshold grants acceptance.

The separate release-only full-capacity native fixture uses65,515 preallocated
account/fixed keys, twenty reward reservations and a real signed quota. It must
reach the actual65,536-key limit through twenty real packets, reject premature
new-account entry, execute refund/maturity, admit cleanup-dependent entry and
recover a pending heavier-branch reorganization through two cold reopens. It
contains24 admitted packets and two signed transactions. No smaller limit,
artificial intermediate snapshot or fabricated height substitutes for this gate.
The ordinary debug ignore is explicit: both exact head and merge Rust lanes run
this test with `--release --exact --ignored`, retaining its actual result. The
small exported storage fixtures' independent reader does not independently
replay this larger capacity fixture.

The [monetary range relation](MONETARY_OBLIGATION_RANGES_V1.md) is an additional
explicit execution experiment over a checked full parent. It does not replace
this backend's native complete-State or non-account checks.

## Costs and remaining work

Incremental account persistence reduces which account nodes are newly written.
It does **not** remove full-state reads, full reference root construction,
non-account scans, per-state node availability checks or retained-history
validation. Those checks add real admission/recovery cost and must remain in
subsequent measurements. Persistent versions, all retained blocks, SQLite pages,
indexes and WAL have no newly established physical global bound here.

Further work must price and assign future state, obligation, storage and proof
service responsibility at admission, make complete obligation proofs continuously
available, measure growth and tail latency, and define physical retention/recovery.
Historical `state_at` can repeat the complete-state/account O(N) portions at each
of H replayed heights; retained snapshots do not establish a global recovery bound.
Partial-state execution or a changed consensus root requires its own explicit
version, migration and complete conformance evidence. This backend leaves those
requirements visible while making authenticated state part of the actual native
store lifecycle.

## Streaming retained-delta validation and bounded reads

The integrated record verifier now hashes the actual ordered SQLite delta rows
one at a time, using the same indexed, duplicate-last sequence root as before.
It does not retain a complete second delta list, every canonical row encoding,
or all leaf hashes merely to check a retained record. The operation-local Merkle
frontier preserves the original leaf/node/empty domains, row indices, ordering
and odd-level padding. The general `sequence_root` remains an independent test
reference. Full lists are still retained where state replay and changed-account
publication need their actual values; those paths share the same checked reader.

The query projects at most161 UTF-8 key bytes and4097 bytes per present old/new
value, with independently read original byte lengths. Actual bounds remain the
existing160-byte key and4096-byte canonical value limits. Length checks include
embedded NUL and multi-byte text. SQL type errors remain errors; NULL, present
`null` and present empty bytes are not conflated. A corrupt oversized blob is
rejected before a full Rust payload allocation or JSON decode. The record's
packet projection similarly fetches at most the existing packet byte bound plus
one before its ordinary decoder. These are returned-payload limits, not bounds
on SQLite pages, physical I/O, allocator RSS or every other Node query.

The retained row bound remains131072; the next row refuses. The reader observes
the existing cancellation callback at entry, every256 checked rows and completion.
The final root has another return fence. Cancellation yields neither a partial
root nor a prefix list, preserves its original error identity, and is not changed
into retained-storage corruption. State replay, authenticated record verification
and publication use those same operation-local callbacks. Ordinary wrappers use
a no-op callback and retain their original complete results.

Controlled admission now also observes its original execution callback during
parent-state acquisition and final delta/parent/child/active-state readback before
COMMIT. Actual SQL writes remain under the same single native transaction; a
cancelled readback rolls back that transaction. Complete state/account roots,
required history and final ancestry checks are not removed or replaced by a
cached validity verdict. No post-COMMIT cancellation changes durable success.
Individual canonical encodings, complete root calculations and SQL statements
remain nonpreemptive, and every required ancestor is still checked. This changes
neither the65536-key consensus limit nor full-State/history asymptotic costs.

The ordinary post-write readback may reuse a successfully verified account graph
among its original four nominated roles: child, genesis, the fully verified
child's parent and the actual active tip. Reuse requires equality of the entire
account `Root { node, digest, count, balance }` inside the same connection, writer,
last-write epoch, schema and parameter context. The current SQL Record, block,
deltas and complete State commitment are still checked before every lookup.
Complete-State commitment and graph verification use the same strict account
parser, including nonce and zero-balance account existence. Working state and
reward liabilities remain part of the current complete-State comparison.

A different Record can therefore share an unchanged account graph without
sharing its State or authorization. A fifth block is never nominated merely
because its root matches. The original entry/delta/final callbacks remain;
cancellation retains its error, a callback write disables reuse, and a write
after a consumed hit refuses the owning publication. The result is never retained
across transactions or used as recovery authority. The actual Node regressions
include a current SQL Record with a forged node pointer but unchanged account
digest/count/balance, target-State grammar/nonce/liability changes, and cross-Record
callback writes and cancellation. This removes duplicate graph work only; first
traversals, changed roots, complete State reconstruction and required ancestry
verification remain. Original Host/service and fixed-touched-set growth gates
must still execute on the candidate source.

The existing `native_authenticated` tests compare the streamed reader with an
independent copy of the original ordered reader and general sequence root,
including131072 actual SQLite delta rows, malformed values, type/range faults,
UTF-8/NUL limits, all callback cuts and retries. The real Node controls
`controlled_parent_reconstruction_preserves_cancellation_and_complete_retry` and
`controlled_final_readback_cancels_inside_transaction_without_corruption_or_partial_rows`
create a256-transfer block through ordinary signed admission and compare every
logical SQLite table after cancellation, valid retry and cold reopen in both
backends. These fixtures do not constitute permanent-account growth beyond the
old ledger cap, physical power-loss acceptance, or public throughput measurement.


## Direct append final readback

Ordinary direct append returns an existing post-write scope after its final event
insertion, using the same final readback helper as reorganization. All actual
active State, ancestry, event and history checks remain, followed by the original
last callback and unchanged-write fence. Direct append retains its `Atomic` SQL
commit observation; reorganization retains `ReorgStep`. Cancellation before
COMMIT rolls back that transaction. A later transport cancellation does not
reverse a committed result. An unqualified optional scope retains the original
complete checks, without promising the strict write-epoch fence of a qualified
scope. Transaction replacement now uses the existing reorganization scope error:
`NATIVE_POST_WRITE_SCOPE`, preserving the earlier callback error as its source.
The observer refuses a result; it cannot undo a callback's own COMMIT. No graph
proof survives a transaction boundary.

The separately studied parent-graph continuation through native INSERTs is
**not enabled**. Its exact source, native controls and both paired cost runs are
retained in the [candidate record](../../../../evidence/pon-throughput-continuation-20261104/parent-and-tail/graph-candidate/README.md).
A small changed-state fixture still regresses after the first correction, and
the reviewed catalog checks alone do not establish physical SQLite page
ownership. No bypass was reproduced by that review; the missing justification
remains unresolved. The default publisher retains the complete parent and
post-write child checks. A future candidate must establish its actual storage
boundary and pass the original complete-cost criteria before default use.

## Growth reservation readback boundary

`store/growth_reservation_io.rs` is an operation-local reader within the existing
migration owner, not another storage backend. It opens receipt/reservation files
relative to one checked directory descriptor, refuses links, nonregular files and
unexpected permissions, and checks actual descriptor metadata before reading.
The receipt has a64KiB ceiling both before and during the read; concurrent length
or metadata changes and substituted named objects refuse. Canonical JSON, exact
candidate/source binding and physical allocation checks remain in the same owner.
Initial publication also syncs the parent directory before acknowledging readback.
A failure retains its uncertain destination and requires exact reconciliation;
recursive path-based cleanup no longer risks deleting a replacement directory.
No subsequent caller may interpret an absent/successful local reservation as a
complete native growth migration, capacity-sufficiency proof or activation grant.
This is not a physical power-loss or filesystem-snapshot-isolation claim.


## Read-only proof completion and batched nonce observations

The account multiproof reader retains its complete state, record, node, root and
callback checks. After the final callback it rejects same-connection row writes
with local `NATIVE_ACCOUNT_PROOF_WRITE`, including write-then-restore. Successful
reads end by rollback, never commit. Existing cancellation keeps its original
identity and rolls back; this is a local ownership fence, not a sandbox for an
arbitrary callback or proof against a privileged writer. No schema or consensus
bytes change. The original mutation/cancellation tests remain.

`Node::next_nonces` accepts 1..256 distinct senders, rejects malformed dimensions
before storage, and returns results in input order from one current, complete
checked SQLite snapshot. It shares exact absence/nonce/overflow arithmetic with
`next_nonce`, without changing the singleton's existing I/O path. The snapshot
ends by rollback and stores no nonce reservation. The next call rereads actual
state; a returned nonce is not a signing or final-use capability.

The existing continuous pipeline now obtains its one-to-four sender nonces in
one call per business block instead of one complete state read per sender.
All mining, admission, activation, TCP, membership and confirmation stages
remain. This removes repeated full-state acquisition within this specific caller;
full state/root/account verification and full retained history costs remain.
No constant-time state, throughput multiplier, saturated TPS, independent WAN,
physical power-loss or public work qualification follows from the source change.

The native comparison runs 16 complete four-sender calls in singleton/batch/batch/
single order on each backend, with exact result and durable-state equality. It
reports observed timings without a speed threshold. A signed transfer followed
by a genuinely heavier fork and cold reopen separately verifies nonce rollback.
These finite controls are not sustained TPS, independent operation or efficacy.
