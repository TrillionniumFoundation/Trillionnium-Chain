## Why

The joint PoN continuation needs the same source, native owner path and resource contract for cost observations, current-clock activation and receiver refusal. Three concrete implementation gaps remained on #821:

- Cost experiments emitted completed-search/cohort receipts after the work. An interrupted attempt or failed cohort could therefore disappear from the retained cost lifecycle.
- A mandatory Host resource callback could finish after the original deadline, allowing the next History owner action to start with an expired budget.
- Public PGH2 admission checked the submitted target against the current time but final activation used the unobserved History API. A currently eligible target can retain an ancestor that is ineligible under the fresh clock.

## Changes

- Add the separately named V4 native cost observer and strict reader. Setup, preparation, search, each attempt and the two complete verifiers have flushed lifecycle boundaries. Missing completion remains unknown; all observed trials are bound across producer arms by a canonical digest and count. The existing V2/V3 wrappers, signed domains and record meanings are preserved.
- Recheck the same absolute deadline after the original Host callback and before returning authority to a History owner action. Preserve the callback's original failure priority and durable-work accounting.
- Route public PGH2 activation through the existing observed-history API with a fresh current time, for both newly admitted and exactly duplicated packets.
- Add focused regressions and CI contract entries, refresh the exact-source inventory and PQ source pins, and document the joint acceptance obligations under the existing development plan.

## Exact stacked source

- Base PR: #821, branch `fix/chain-six-full-d9fb-20261108`.
- Base commit: `e798d7125724d4b9f98c24d00cc80031f2eab4a9`.
- Implementation commit: `11791e2da79b69322271be2cffe03725165151d1`.
- Implementation tree: `162552848110fda532504b78865a16930bc6d9bb`.

The bare repository used to transfer this commit is only an object transport. It is not the complete checkout used for preflight, builds or runtime observations.

## Validation snapshot — draft, HOLD / NO-GO

- The complete final implementation checkout passed source preflight: 26,124 entries / 2,485,379,627 bytes, with source-before/source-after verification.
- The final implementation's independent 15-command static matrix, native library tests, example tests, complete V4 roster, real terminated-process V4 control and strict Clippy are being rerun. Attach their exact-source command, exit, output and executable identities before changing this status.
- Historical implementation `fc5c44ca91c56e77ca2ffc9943e10f0f777a5937` has 15 passing static commands and retained example test-suite passes of 10, 9 and 11 tests. These observations do not qualify the changed final implementation.
- Two local native library test attempts ended via SIGKILL. The original failed observations remain retained; neither is a passing native result. Native library validation is moving to ai395.
- The final commit scopes the intentional retained-wrapper dead-code allowances and expresses the existing canonical-search loop with mutable enumeration, with corresponding source pins refreshed.
- Hosted checks have not yet run for this branch. Publishing the draft will permit the real hosted campaign to run against this exact source.

No qualification conclusion follows from the static results or this draft. The original public resource contract, attack inputs and independent confirmation requirements still apply.

## Remaining joint obligations

The work does not establish a lower bound over every legal classical or quantum strategy, the joint timestamp/DAA/cumulative-credit theorem, or a positive honest-service floor under the declared adversary. The V4 diagnostic target has ideal density one half and cannot fill the MU1 one-sixteenth cost points. Production/security qualification remains false or unknown, no observer event adds chain credit, and activation remains disabled.

The additional current-clock walk covers the selected history and costs O(history depth); its resource cost still belongs in the original end-to-end budget. The original 0.25-core / 2-GiB / zero-swap / 256-PID and four-second / 16-hostile service case is unchanged.

## Review references

- [Joint source, clock and resource contract](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/11791e2da79b69322271be2cffe03725165151d1/docs/research/PON_JOINT_RESOURCE_CONTRACT_20261108.md)
- [V4 lifecycle observation contract](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/11791e2da79b69322271be2cffe03725165151d1/docs/research/PON_W1_LIFECYCLE_COST_V4.md)
