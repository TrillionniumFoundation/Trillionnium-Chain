#!/usr/bin/env python3
"""Apply bounded retained-cache population and exact fixture corrections after the complete C3 observation."""
import argparse
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/chain-pq-boundary-closure-20261112-4150')
PRIOR_HEAD = 'f0fa8c3c0372d0c5dafccd2683b31fda322e42f2'
BASE = '8970e2c81abbf48e2a4d3f0802d79624ab20fadd'
INGRESS = 'de7acc8a59d77f11be4c17c380cc9c2bca91905c'
PRIOR = Path('/home/qian-qi/work/pq-boundary-validation-20261112-4150-v3')
PACKETS = (
    ('deadline-error-control', Path('/home/qian-qi/work/pq-boundary-deadline-error-package-4150.json'),
     'bdffce94a020d0f184f3a7f8f52d671ce83430d74e3711f8651d8b7c1f4efe59'),
    ('retained-population', Path('/home/qian-qi/work/pq-boundary-retention-batch-package-4150.json'),
     'dd1f66a7595f0aee62e98116491e9f1c2ae5134001906220868e5976757595cc'),
    ('short-ttl-setup', Path('/home/qian-qi/work/pq-boundary-short-ttl-package-4150.json'),
     '989bb7c9012f61d72bd8ab5ad7b80867dd06a7781e02b28043ed42c7a1c306df'),
)
PRIOR_RECEIPT_SHA256 = '5377cd204a07538e86afdc8ecc2154d925a24cd79d2a426920930b68b961e65e'
SOURCE_FILES = {
    'trillionnium/crates/trnm-data-availability/src/cell/cache_wal_tests.rs',
    'trillionnium/crates/trnm-data-availability/src/cell/retention.rs',
    'trillionnium/crates/trnm-data-availability/src/cell/discovery/sequence_tests.rs',
}
KNOWN_FAILURES = {
    'da-default-lib': (101, '1468fd8459acebd99c3edab1d4cbe77775f5f05d5f916a792d9209277d8a7e6f'),
    'da-all-features-lib': (101, '507e4d805ab205268b80bb8404d9bd323170d1613e6e114793873af630887c41'),
}
CORPUS = 'config/pon/pq-cross-branch-corpus-v1.json'
BUDGET = 'config/pon/pq128-lifetime-budget-v1.json'
LOCK = 'config/pon/pq128-source-lock-v1.json'
ROOT_REGISTER = 'config/pon/pq-root-dependency-register-v3.json'
PLAN = 'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
INVENTORY = 'trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs'
ALLOWED = SOURCE_FILES | {CORPUS, BUDGET, LOCK, PLAN, INVENTORY}
NOTE = """**Bounded retained-cache population and fixture corrections, 2026-11-12 — HOLD:**

The original complete C3 observation on
`f0fa8c3c0372d0c5dafccd2683b31fda322e42f2` remains retained. Its default DA
library reported 741 passed and one failed. The unchanged 65/128 capacity
control passed in that lane. Its all-features DA library reported 739 passed
and three failed, including the same capacity control with
Invalid("RS46 provider deadline"). A source-visible transaction reduction did
not establish success in both configurations or the exact physical latency
cause. C1/C2/C3 failures are never rewritten by a later successful observation.

Use the existing chunk batch in retained populate_cache, bounded by its original
eight-member limit and by the maximum single-chunk payload size. Keep fresh
arena reads, complete payload prevalidation, every original deadline check,
manifest publication, the existing hash/writer/WAL/quota boundary, and final
complete verification/readback. The cold capacity fixture still uses model
N-1 chunks plus one environment chunk, six slots and the original ten-second
absolute deadline. Its source-derived transaction counts change from 132/258
to 76/147 for 65/128 original chunks; these are not measured speedups or proof
of the particular C3 deadline-return branch.

Both C3 DA lanes failed the new paired-cache expired-entry test's comparison
of the CellErrorV1 wrapper with the bare underlying I/O display. Correct only
that expectation: require the typed I/O error, TimedOut kind and original
underlying message. Preserve the preceding real 250 ms writer wait, 750 ms
elapsed bound, two-table expiry/rollback and all no-write assertions.

C3's all-features short-TTL control failed its meaningful fixture phase guard:
the real request arrived just before signed expiry, and the backend frame became
ready after expiry. The later error/no-output assertions were not executed and
must not be credited. Before minting the same two-second signed TTL, wait for
one selected next wall-second within the original setup deadline. A missed
window or signing across that second refuses the fixture; there is no new
selected window, future issue time, network retry or renewed request budget.
A late wake still leaves only the selected second's actual remaining time;
the original transfer/expiry/no-publication guards decide admissibility.
Retain the original request/overall deadlines and every actual network action.

The new candidate must independently pass the same complete ninety-command
gate. Each DA lane also requires the existing retention writer-contention,
cold-cache real-peer, eight-chunk reader-refusal, and short-TTL controls by
exact name, alongside all earlier required methods. Workloads and production
budgets remain unchanged.

Re-anchor the same twenty-one directly registered implementation objects to
this checkpoint with unchanged bytes and unchanged Root dependency register.
All eight lifetime terms remain unknown/null. This partial direct inventory
does not prove transitive composition, historical migration, public WAN,
independent custody, W1/DAA hardness or whole-chain qualification. Ordinary
TCV3 caller integration and production qualification remain unchanged and unqualified.

"""


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw,
                        usedforsecurity=False).hexdigest()


def put(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')


def main():
    if sys.flags.optimize:
        raise RuntimeError('apply helper requires Python assertions enabled')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    assert args.output.is_absolute() and not out.is_relative_to(ROOT)
    out.mkdir(exist_ok=False)
    (out / 'executed-followup.py').write_bytes(Path(__file__).read_bytes())
    os.chdir(ROOT)
    os.environ['PATH'] = '/home/qian-qi/.cargo/bin:' + os.environ['PATH']
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    os.environ['GIT_NO_LAZY_FETCH'] = '1'
    os.environ['GIT_NO_REPLACE_OBJECTS'] = '1'
    sys.dont_write_bytecode = True
    records = []

    def run(label, argv, timeout=600):
        start = time.monotonic_ns()
        p = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, timeout=timeout)
        (out / (label + '.stdout')).write_bytes(p.stdout)
        (out / (label + '.stderr')).write_bytes(p.stderr)
        row = {'label': label, 'argv': argv, 'returncode': p.returncode,
               'elapsed_ns': time.monotonic_ns() - start}
        records.append(row)
        put(out / 'commands.json', records)
        print(json.dumps(row), flush=True)
        p.check_returncode()
        return p.stdout.decode().strip()

    def git(*argv):
        return subprocess.check_output(['git', *argv], cwd=ROOT, text=True).strip()

    def object_bytes(revision, name):
        return subprocess.check_output(['git', 'cat-file', 'blob', revision + ':' + name], cwd=ROOT)

    def changed():
        names = set(git('diff', '--name-only', PRIOR_HEAD).splitlines())
        names.update(git('ls-files', '--others', '--exclude-standard').splitlines())
        assert names <= ALLOWED, sorted(names - ALLOWED)
        return names

    def refresh_corpus(label):
        names = changed() - {CORPUS}
        old = json.loads((ROOT / CORPUS).read_bytes())
        value = copy.deepcopy(old)
        for name, expected in old['pinned_blobs'].items():
            actual = blob((ROOT / name).read_bytes())
            assert actual == expected or name in names, ('unrelated stale pin', name)
        rows = []
        for name in sorted(names):
            raw = (ROOT / name).read_bytes()
            assert len(raw) <= 4_194_304
            rows.append({'path': name, 'before': value['pinned_blobs'].get(name),
                         'after': blob(raw), 'sha256': sha(raw), 'bytes': len(raw)})
            value['pinned_blobs'][name] = blob(raw)
            if name not in value['required_paths']:
                value['required_paths'].append(name)
        assert all(value[k] == old[k] for k in old if k not in ('pinned_blobs', 'required_paths'))
        assert set(old['required_paths']) <= set(value['required_paths'])
        put(ROOT / CORPUS, value)
        put(out / (label + '.json'), rows)

    run('preflight-before-inspection', ['bash', 'scripts/project-preflight.sh'])
    assert git('rev-parse', 'HEAD') == PRIOR_HEAD and not git('status', '--porcelain')
    prior_raw = (PRIOR / 'validation.json').read_bytes()
    assert len(prior_raw) == 123716 and sha(prior_raw) == PRIOR_RECEIPT_SHA256
    prior = json.loads(prior_raw)
    assert prior['source'] == PRIOR_HEAD and prior['completed'] is True
    assert prior['all_requested_component_checks_passed'] is False
    assert prior['failures'] == list(KNOWN_FAILURES)
    assert [row['label'] for row in prior['commands'] if not row['component_check_passed']] == list(KNOWN_FAILURES)
    for row in prior['commands']:
        if row['label'] in KNOWN_FAILURES:
            assert (row['exit_code'], row['log_sha256']) == KNOWN_FAILURES[row['label']]
        else:
            assert row['component_check_passed'] is True and row['exit_code'] == 0
    assert prior['runtime_test_threads'] == 1
    assert len(prior['commands']) == 90 and 'error' not in prior
    assert prior['source_before'] == prior['source_after']
    assert prior['provider_before'] == prior['provider_after']
    assert prior['provider_after']['all_five_match'] is True
    for name, pin in prior['artifact_files'].items():
        raw = (PRIOR / name).read_bytes()
        assert {'bytes': len(raw), 'sha256': sha(raw)} == pin, name
    sys.path.insert(0, str(ROOT / 'scripts/ci'))
    from verify_ci_source import verify
    assert verify('head', PRIOR_HEAD, None, None, ROOT) == prior['source_after']
    put(out / 'retained-prior-observation.json', {
        'source': PRIOR_HEAD, 'directory': str(PRIOR), 'validation_sha256': sha((PRIOR / 'validation.json').read_bytes()),
        'completed': True, 'failures': prior['failures'], 'all_requested_component_checks_passed': False,
        'raw_artifacts_unchanged': True, 'new_native_execution_claimed': False})
    replacements = {}
    admitted = []
    for label, packet_path, packet_sha in PACKETS:
        raw = packet_path.read_bytes()
        assert sha(raw) == packet_sha
        package = json.loads(raw)
        (out / ('reviewed-' + label + '-package.json')).write_bytes(raw)
        for row in package['files']:
            name = row['path']
            assert name in SOURCE_FILES and name not in replacements
            before = (ROOT / name).read_bytes()
            assert sha(before) == row['before_sha256'] and before == object_bytes(PRIOR_HEAD, name)
            assert blob(before) == row['base_git_blob']
            replacement = base64.b64decode(row['content_base64'], validate=True)
            assert sha(replacement) == row['after_sha256']
            replacements[name] = replacement
            admitted.append({'path': name, 'packet_sha256': packet_sha,
                             'before_sha256': sha(before), 'reviewed_unformatted_sha256': sha(replacement)})
    assert set(replacements) == SOURCE_FILES
    run('preflight-before-edit', ['bash', 'scripts/project-preflight.sh'])
    for name, replacement in replacements.items():
        (ROOT / name).write_bytes(replacement)
    run('format-reviewed-rust', ['rustfmt', '+1.95.0', '--edition', '2021'] + sorted(SOURCE_FILES))
    for row in admitted:
        row['formatted_sha256'] = sha((ROOT / row['path']).read_bytes())
    put(out / 'reviewed-formatted-source.json', admitted)
    run('refresh-native-inventory', ['python3', '-B', 'scripts/refresh_distributed_source_inventory.py'])
    plan = ROOT / PLAN
    assert not plan.read_text().startswith(NOTE.splitlines()[0])
    plan.write_text(NOTE + plan.read_text())
    refresh_corpus('reviewed-followup-pins')
    run('workspace-fmt', ['cargo', '+1.95.0', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check'])
    run('preflight-runtime-commit', ['bash', 'scripts/project-preflight.sh'])
    run('stage-runtime', ['git', 'add', '--'] + sorted(changed()))
    run('runtime-whitespace', ['git', 'diff', '--cached', '--check'])
    run('runtime-commit', ['git', 'commit', '-s', '-m', 'fix(da): batch retained rehydration and preserve deadline fixture semantics'])
    r = git('rev-parse', 'HEAD')
    put(out / 'runtime.json', {'source': r, 'base': BASE, 'ingress_source': INGRESS})
    old_budget, old_lock = json.loads((ROOT / BUDGET).read_bytes()), json.loads((ROOT / LOCK).read_bytes())
    budget, lock = copy.deepcopy(old_budget), copy.deepcopy(old_lock)
    assert len(lock['files']) == 21
    bindings = []
    for name, expected in lock['files'].items():
        raw = object_bytes(r, name)
        assert raw == (ROOT / name).read_bytes() and sha(raw) == expected
        bindings.append({'path': name, 'sha256': expected, 'implementation_bytes_unchanged': True})
    assert object_bytes(r, ROOT_REGISTER) == object_bytes(PRIOR_HEAD, ROOT_REGISTER)
    run('preflight-source-register', ['bash', 'scripts/project-preflight.sh'])
    budget['experiment']['source_revision'] = lock['source_revision'] = r
    assert all(term['status'] == 'unknown' and term['bound'] is None for term in budget['terms'])
    assert len(budget['events']) == len(budget['terms']) == 8
    put(ROOT / BUDGET, budget)
    put(ROOT / LOCK, lock)
    put(out / 'lifetime-reviewed-source.json', bindings)
    refresh_corpus('reviewed-final-pins')
    run('stage-source-register', ['git', 'add', '--', BUDGET, LOCK, CORPUS])
    run('metadata-whitespace', ['git', 'diff', '--cached', '--check'])
    run('preflight-source-commit', ['bash', 'scripts/project-preflight.sh'])
    run('source-register-commit', ['git', 'commit', '-s', '-m', 'security(pq): rebind direct inventory after retained-cache and fixture corrections'])
    c = git('rev-parse', 'HEAD')
    assert set(git('diff', '--name-only', r, c).splitlines()) == {BUDGET, LOCK, CORPUS}
    assert not git('status', '--porcelain')
    for row in bindings:
        assert sha(object_bytes(c, row['path'])) == row['sha256']
    put(out / 'candidate.json', {'source': c, 'runtime_revision': r, 'base': BASE,
        'ingress_source': INGRESS, 'native_tests_executed_on_candidate': False,
        'whole_chain_pq_qualified': False, 'production_activation': False})
    print(json.dumps({'candidate_ready': c, 'runtime_revision': r,
                      'prior_source': PRIOR_HEAD, 'native_tests_executed': False}), flush=True)


if __name__ == '__main__':
    main()
