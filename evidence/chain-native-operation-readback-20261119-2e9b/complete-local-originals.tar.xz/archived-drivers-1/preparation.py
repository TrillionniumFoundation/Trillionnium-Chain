from pathlib import Path
import subprocess,json,time,resource,fcntl,traceback,os,hashlib
base=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b');base.mkdir(exist_ok=False)
e=base/'preparation-1';e.mkdir();src=base/'source';target=base/'target'
old=Path('/home/qq/chain-host-stat-20261118-2e9b-source')
res={'schema':'chain-native-operation-readback-preparation-v1','base_commit':'f088f1d4f8a50aff0c5ecd465480b2aeee6e5e94','base_tree':'9181b29ff0a4f90bb7b9ec99c1d79e51c10dd95e','source':str(src),'target':str(target),'stages':[],'business_requests':0}
def save():(e/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(n,cmd,cwd):
 t=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
 row={'name':n,'command':cmd,'cwd':str(cwd)};res['stages'].append(row);save()
 with (e/(n+'.stdout')).open('xb') as out,(e/(n+'.stderr')).open('xb') as err:
  p=subprocess.Popen(cmd,cwd=cwd,stdout=out,stderr=err);row['pid']=p.pid;save();rc=p.wait()
 after=resource.getrusage(resource.RUSAGE_CHILDREN);row.update(exit_code=rc,wall_seconds=time.monotonic()-t,child_user_cpu_seconds=after.ru_utime-before.ru_utime,child_system_cpu_seconds=after.ru_stime-before.ru_stime);save();print(json.dumps(row),flush=True);assert rc==0,n
try:
 run('original-preflight',['bash','scripts/project-preflight.sh'],old)
 run('fetch-frozen-negative-base',['git','fetch','--no-tags','origin',res['base_commit']],old)
 run('isolated-worktree',['git','worktree','add','--no-checkout','-b','fix/chain-native-operation-readback-20261119-2e9b',str(src),res['base_commit']],old)
 run('sparse-source',['git','sparse-checkout','set','--no-cone','/*','!/evidence/','!/docs/evidence/','!/docs/development/evidence/'],src)
 run('checkout',['git','checkout','fix/chain-native-operation-readback-20261119-2e9b'],src)
 run('candidate-preflight',['bash','scripts/project-preflight.sh'],src)
 with Path('/home/qq/chain-host-stat-20261118-2e9b-target/release/.cargo-lock').open('a+b') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  run('copy-owned-terminated-cache',['cp','-a','--reflink=auto','/home/qq/chain-host-stat-20261118-2e9b-target',str(target)],base)
 res['head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()
 res['tree']=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=src,text=True).strip()
 res['status']=subprocess.check_output(['git','status','--porcelain=v1'],cwd=src,text=True)
 assert res['head']==res['base_commit'] and res['tree']==res['base_tree'] and not res['status']
 res['ready']=True;res['unmaterialized_binary_evidence_not_used_as_source']=True
except BaseException as ex:
 res['error']=repr(ex);(e/'driver-error.log').write_text(traceback.format_exc())
finally:
 save();print(json.dumps(res),flush=True)
