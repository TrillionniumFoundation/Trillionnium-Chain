import sys,json,pathlib,subprocess,hashlib,os,stat,time,traceback
data=json.load(sys.stdin)
old=pathlib.Path("/home/qian-qi/work/chain-root-operation-20261112-df05")
root=pathlib.Path("/home/qian-qi/work/chain-root-operation-recovered-20261112-df05")
obs=pathlib.Path("/home/qian-qi/work/chain-root-reconstruction-20261112-df05")
branch="fix/chain-root-operation-recovered-20261112-df05"
base="8970e2c81abbf48e2a4d3f0802d79624ab20fadd"
cloud="87bf6bb07c4ccdd75741cfb79c7447d8d8c54758"
expected_tree="b1882c2e46827abfd1db5f8744be043d5776df6d"
plan="docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md"
corpus_path="config/pon/pq-cross-branch-corpus-v1.json"
stage="initialization"
command_results=[]
env=os.environ.copy()
env["GIT_NO_LAZY_FETCH"]="1"
env["PYTHONPYCACHEPREFIX"]=str(obs/"bootstrap-v1"/"pycache")
env["PYTHONDONTWRITEBYTECODE"]="1"
def sync_directory(path):
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
def create_json(path,value):
    with path.open("x",encoding="utf-8") as f:
        json.dump(value,f,ensure_ascii=False,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
def atomic_new_json(path,value):
    pending=path.with_name(path.name+".pending-bootstrap-v1")
    create_json(pending,value)
    os.link(pending,path)
    pending.unlink()
    sync_directory(path.parent)
def run(name,argv,cwd,accepted=(0,)):
    started=time.time()
    create_json(log/(name+".command.json"),{"argv":argv,"cwd":str(cwd),"accepted_exit_codes":list(accepted),"started_unix":started,"environment_overrides":{"GIT_NO_LAZY_FETCH":"1","PYTHONPYCACHEPREFIX":env["PYTHONPYCACHEPREFIX"],"PYTHONDONTWRITEBYTECODE":"1"}})
    with (log/(name+".stdout")).open("xb") as out,(log/(name+".stderr")).open("xb") as err:
        value=subprocess.run(argv,cwd=cwd,env=env,stdout=out,stderr=err)
        out.flush();err.flush();os.fsync(out.fileno());os.fsync(err.fileno())
    stdout=(log/(name+".stdout")).read_bytes()
    stderr=(log/(name+".stderr")).read_bytes()
    result={"name":name,"exit_code":value.returncode,"accepted":value.returncode in accepted,"duration_seconds":time.time()-started,"stdout_bytes":len(stdout),"stdout_sha256":hashlib.sha256(stdout).hexdigest(),"stderr_bytes":len(stderr),"stderr_sha256":hashlib.sha256(stderr).hexdigest()}
    create_json(log/(name+".result.json"),result)
    command_results.append(result)
    print(json.dumps({**result,"stdout_tail":stdout[-450:].decode(errors="replace"),"stderr_tail":stderr[-450:].decode(errors="replace")}),flush=True)
    if value.returncode not in accepted:raise RuntimeError("command failed: "+name)
    return stdout
def regular_bytes(path):
    s=path.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_nlink!=1:raise RuntimeError("source is not a single regular file: "+str(path))
    return path.read_bytes()
def git_blob(b):
    return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def write_source(relative,b):
    path=root/relative
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists() and (path.is_symlink() or not path.is_file()):raise RuntimeError("nonregular destination: "+relative)
    is_new=not path.exists()
    with path.open("wb") as f:f.write(b);f.flush();os.fsync(f.fileno())
    if is_new:path.chmod(0o644)
try:
    obs.mkdir(parents=True,exist_ok=True)
    if obs.is_symlink():raise RuntimeError("observation directory is a symlink")
    if (obs/"FROZEN.json").exists() or (obs/"FAILED.json").exists():raise RuntimeError("existing sentinel; reconcile original attempt")
    log=obs/"bootstrap-v1"
    log.mkdir(exist_ok=False)
    with (log/"BOOTSTRAP.py").open("x",encoding="utf-8") as f:f.write(data["bootstrap_program"]);f.flush();os.fsync(f.fileno())
    create_json(log/"BOOTSTRAP_REQUEST.json",{"idempotency_key":data["idempotency_key"],"host":"desktop","executable":"/usr/bin/python3","argument_form":["-c","BOOTSTRAP.py exact text"],"program_sha256":hashlib.sha256(data["bootstrap_program"].encode()).hexdigest(),"old_worktree":str(old),"new_worktree":str(root),"branch":branch,"base":base,"expected_cloud_source":cloud,"expected_tree":expected_tree,"expected_files_sha256":data["expected_files_sha256"],"plan_entry_sha256":hashlib.sha256(data["plan_entry"].encode()).hexdigest(),"complete_source_postimages_in_this_observation":False})
    assert len(data["expected_files_sha256"])==14
    stage="old-preflight-and-input-verification"
    run("old-preflight",["bash","scripts/project-preflight.sh"],old)
    old_head=run("old-head",["git","rev-parse","HEAD"],old).decode().strip()
    assert old_head==base,"old worktree HEAD differs from required base"
    if root.exists():raise RuntimeError("destination worktree already exists")
    run("branch-must-be-absent",["git","show-ref","--verify","--quiet","refs/heads/"+branch],old,(1,))
    copied={}
    old_hashes={}
    for relative,expected in data["expected_files_sha256"].items():
        b=regular_bytes(old/relative)
        observed=hashlib.sha256(b).hexdigest()
        old_hashes[relative]=observed
        if relative not in (plan,corpus_path):assert observed==expected,"unreviewed old-native source: "+relative
        copied[relative]=b
    assert old_hashes[plan]=="60c7e34c55ab245f591b29d0cb3f305dbd8e04439755338476509e54843c5c37","old plan is not the known native candidate"
    old_corpus=json.loads(copied[corpus_path])
    assert old_corpus["pinned_blobs"][plan]==git_blob(copied[plan]),"old corpus does not bind old native plan"
    create_json(log/"OLD_NATIVE_INPUTS.json",{"head":old_head,"state":"dirty-candidate-with-known-postimages","files_sha256":old_hashes,"old_tree_is_not_used_as_source_identity":True})
    stage="create-new-isolated-worktree"
    run("worktree-add",["git","worktree","add","-b",branch,str(root),base],old)
    run("new-base-preflight",["bash","scripts/project-preflight.sh"],root)
    stage="copy-reviewed-postimages-and-exact-plan"
    for relative,b in copied.items():write_source(relative,b)
    base_plan=run("original-plan-suffix",["git","show",base+":"+plan],root)
    new_plan=(data["plan_entry"].rstrip()+"\n\n").encode("utf-8")+base_plan
    assert hashlib.sha256(new_plan).hexdigest()==data["expected_files_sha256"][plan],"reconstructed plan differs from frozen cloud bytes"
    write_source(plan,new_plan)
    new_corpus=json.loads(copied[corpus_path])
    new_corpus["pinned_blobs"][plan]=git_blob(new_plan)
    expected_corpus=json.dumps(new_corpus,indent=2,sort_keys=True).encode()+b"\n"
    assert hashlib.sha256(expected_corpus).hexdigest()==data["expected_files_sha256"][corpus_path],"corpus differs beyond the one approved plan pin"
    write_source(corpus_path,expected_corpus)
    final_hashes={relative:hashlib.sha256(regular_bytes(root/relative)).hexdigest() for relative in data["expected_files_sha256"]}
    assert final_hashes==data["expected_files_sha256"],"postimage mismatch"
    create_json(log/"RECONSTRUCTED_POSTIMAGE_IDENTITIES.json",final_hashes)
    stage="whole-tree-gate-before-commit"
    run("diff-whitespace",["git","diff","--check"],root)
    run("stage-only-reviewed-fourteen",["git","add","--",*data["expected_files_sha256"]],root)
    tree=run("write-tree-gate",["git","write-tree"],root).decode().strip()
    assert tree==expected_tree,"TREE MISMATCH: "+tree+"; no commit, no unknown repin"
    run("precommit-preflight",["bash","scripts/project-preflight.sh"],root)
    stage="local-source-commit"
    run("source-commit",["git","commit","-m","fix(root): retain witness receipts and provider history floors"],root)
    head=run("new-head",["git","rev-parse","HEAD"],root).decode().strip()
    tree_after=run("new-tree",["git","rev-parse","HEAD^{tree}"],root).decode().strip()
    actual_branch=run("new-branch",["git","branch","--show-current"],root).decode().strip()
    assert tree_after==expected_tree and actual_branch==branch
    assert not run("new-clean-before-physical",["git","status","--porcelain=v1","--untracked-files=all"],root).strip()
    stage="complete-original-physical-source-verification"
    physical_raw=run("verify-complete-source",["/usr/bin/python3","-B","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",head,"--output",str(log/"VERIFIED_PHYSICAL_SOURCE.json")],root)
    physical=json.loads(physical_raw)
    assert physical["tested_commit"]==head and physical["tested_tree"]==expected_tree and physical["tracked_worktree_verified"] is True
    run("final-preflight",["bash","scripts/project-preflight.sh"],root)
    assert run("final-head",["git","rev-parse","HEAD"],root).decode().strip()==head
    assert run("final-tree",["git","rev-parse","HEAD^{tree}"],root).decode().strip()==expected_tree
    assert run("final-branch",["git","branch","--show-current"],root).decode().strip()==branch
    assert not run("final-clean",["git","status","--porcelain=v1","--untracked-files=all"],root).strip()
    assert {relative:hashlib.sha256(regular_bytes(root/relative)).hexdigest() for relative in final_hashes}==final_hashes
    stage="publish-frozen-sentinel"
    frozen={"head":head,"tree":expected_tree,"branch":branch,"worktree":str(root),"expected_cloud_source":cloud,"same_full_tree":True}
    create_json(log/"BOOTSTRAP_REPORT.json",{"status":"PASS_SOURCE_RECONSTRUCTION","frozen":frozen,"physical_source":physical,"commands":command_results,"rust_tests_executed":False,"old_native_worktree_modified":False,"production_activation":False,"prior_failure_observations_superseded":False})
    atomic_new_json(obs/"FROZEN.json",frozen)
    stage="complete"
    print(json.dumps({"status":"FROZEN","sentinel":str(obs/"FROZEN.json"),**frozen}),flush=True)
except BaseException as error:
    failure={"stage":stage,"error_type":type(error).__name__,"error":str(error),"expected_cloud_source":cloud,"expected_tree":expected_tree,"worktree":str(root),"idempotency_key":data.get("idempotency_key"),"commands":command_results,"rust_tests_executed":False,"old_native_worktree_modified":False}
    try:
        if obs.exists() and not (obs/"FROZEN.json").exists() and not (obs/"FAILED.json").exists():atomic_new_json(obs/"FAILED.json",failure)
    except BaseException as record_error:print(json.dumps({"failed_record_error":repr(record_error)}),file=sys.stderr,flush=True)
    print(json.dumps({"status":"FAILED",**failure}),file=sys.stderr,flush=True)
    raise
