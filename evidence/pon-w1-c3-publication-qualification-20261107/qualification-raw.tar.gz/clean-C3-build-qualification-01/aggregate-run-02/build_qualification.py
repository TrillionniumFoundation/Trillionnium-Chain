#!/usr/bin/env python3
"""Aggregate exact merge publication C3 evidence without replaying builds or proofs."""
import collections
import hashlib
import re
import resource
import json
import os
from pathlib import Path
import stat
import subprocess
import time

ROOT = Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
REPO = ROOT / "integration-repo"
BASE = ROOT / "clean-C3-build-qualification-01"
OUT = Path(__file__).resolve().parent
HEAD = "abab79dac0cb89eb2753d3f579119ac135650eb5"
TREE = "194808f4a0db5d642aa746beb251ca9e9532cebb"
SOURCE_SHA = "f64801ce2a5fd2e3e0814c4b68e5f7fdd7b740dd72aa90984eff69dcb5a1ba5f"
GUEST_SHA = "25718312ec3c6f5219d832e3516adfb5f82983156f669c5e7daa15bd22d1798f"
R0_SHA = "2acdf550f9aca4d05b74072463e4ed307c3824309c754a5cb5f93aa84f3390e6"
IMAGE = [1958252411, 3287394615, 1805488136, 1516578702, 78549041, 790278610, 301018785, 4279049364]
MANIFESTS = {
    "backend": ("backend-validation/exact-source-abab79dac0cb-02/manifest.json", "0abf8a912caac480b3f663ed695d4d3685d1ca1965e6238dc7431d16b4aae82f"),
    "native": ("clean-exact-native-verifier-abab79dac0cb-02/manifest.json", "238b2b22d3012bf4685662adf912f643d0472e09e8da62aae12bb36f94f8fd3b"),
    "owner": ("clean-C3-build-qualification-01/owner-node-m12-01/manifest.json", "520e12f0b5c8e6cb10d4698cc4d240ec4068dab72b412a12b13fbd4983fac5cf"),
    "ci": ("integration-validation/exact-c3-publication-01/aggregate.json", "85637a9cd951a5e79980d7dfc97b3cf16003942af0a28843ac4b5eea49936087"),
    "publication_map": ("integration-validation/c3-publication-freeze-02/manifest.json", "e00c1d840661ee7219b242c66c606d2885a37e1bd62cf039c3f762c95f3e051c"),
}
JOBS = {
    "backend": "1a1b871fecd-12894-f6d", "native": "1a1b8727827-12894-f74",
    "owner": "1a1b874bfc6-12894-f89", "ci": "1a1b8749be3-12894-f88", "publication_map": "1a1b872f1e0-12894-f7b",
}
C2_HEAD = "cc4dd8bdd89309c635831db30b508af2f89419d7"
C2_TREE = "161d3a4e8ab8c865869352339ec8c66f6609449a"
UPSTREAM = "cb314bb4656e5da4844325cd83994ab4764fe8e9"
ANCESTOR = "819309fd312298e099642e1253b1d4ba07113e98"
PREVIOUS_C2 = {"path": str(ROOT / "clean-C2-build-qualification-01/qualification.json"),
               "bytes": 226149, "sha256": "01947ed12ac65cd24dc4d9364f3e12af93a6539fb6abcfac26b7b43ed3587dbb"}
HISTORICAL = {
    "C1": {"path": str(ROOT / "clean-C1-build-qualification-01/qualification.json"), "bytes": 133183,
           "sha256": "5b1243d0b2b623041c1a1eba1f6043c59d20e15c2b686ada2f24d179da8e84dc"},
    "C1b": {"path": str(ROOT / "clean-C1b-build-qualification-01/qualification.json"), "bytes": 209358,
            "sha256": "e15660baf8e1728f6bb2aad5e205a5e51e03739ad370e50c8bea15e27aa89493"},
}
PUBLICATION_MAP = {"path": str(ROOT / "integration-validation/c3-publication-freeze-02/frozen-sources.json"),
                   "sha256": "519e95d67fbf083b9bd426546e6f5cf84284c72fc352682e67d465368dfecd4f"}
CACHE_PINS = {
    "backend": {"path": str(ROOT / "exact-source-cache-setups/backend-abab79dac0cb-02/manifest.json"),
                "bytes": 8487, "sha256": "8bbbc88a21785f19d75a32f92e10bc508e79460ecc75514a24def2442b039e46"},
    "native": {"path": str(ROOT / "exact-source-cache-setups/native-abab79dac0cb-02/manifest.json"), "sha256": "7736cabcf56d01f0395f082b97d3fc92c16ba57621a20f19fc3dec7fb7ed8578"},
    "owner": {"path": str(BASE / "owner-node-m12-01-cache-setup/manifest.json"), "sha256": "c5f5332843900986cbdf043751b1eb4a3779a4a8e8e7ed6708ce59e3e51d5394"},
}
FAILED_CACHE_PREPARATIONS = {
    "backend": {"job_id": "1a1b86d5f35-12894-f45", "manifest": {
        "path": str(ROOT / "exact-source-cache-setups/backend-abab79dac0cb-01/manifest.json"),
        "bytes": 4905, "sha256": "4bbdc59c9dc72488a0e83e4d90d171986a11ff14b11677c431aefdc83f86e75e"}},
    "native": {"job_id": "1a1b86e11db-12894-f4c", "manifest": {
        "path": str(ROOT / "exact-source-cache-setups/native-abab79dac0cb-01/manifest.json"),
        "bytes": 4906, "sha256": "db3c8ceee3a89097460bd46041f0bea9d4b5fedb8dbaa6f894b16750a80a140a"}},
}
FAILED_MAP_PREPARATION = {"path": str(ROOT / "integration-validation/c3-publication-freeze-01/manifest.json"),
                          "bytes": 12796, "sha256": "04bcd85dee18882f33b2681f698bfc3df5fd5c28ae24debe46e69d67d86d17bc"}
MAP_COVERAGE_DIAGNOSIS = {"path": str(ROOT / "integration-validation/c3-map-f37-set-diagnosis-01/summary.json"),
                          "sha256": "0d5c4038a37fd7ed1f506b73eb65ac3170e735c5c18e14e72c49d6d047701b7d"}
OLD_OWNER_PATH_OBSERVATION = {"path": str(BASE / "owner-original-paths-readback-02/observation.json"),
                            "sha256": "daa185c7e66cc3af6516a7f1270d9fe4cb0674f03089bc530a5a54cf69b9b2ee"}

PRIOR_AGGREGATE = {"path": str(BASE / "aggregate-run-01/result.json"), "bytes": 1765,
                   "sha256": "60f33a3d22faeb4cd8d3be160638a2e0017c84f4b3cf56e58dbeaf6d75fd0578"}
TIMEOUT_DIAGNOSTICS = [
    {"path": str(ROOT / "c3-aggregate-timeout-diagnosis-01/observation.json"), "bytes": 3249,
     "sha256": "3b163c0be5a57fd0d52bbf8528c7248eb4ac987bbad4eb690f2cec95f5d08348"},
    {"path": str(ROOT / "c3-aggregate-timeout-diagnosis-02/observation.json"), "bytes": 10456,
     "sha256": "3574397b2ee2abf3551edca4d160a61a6d75f2f916362b153e538a9592e41590"},
    {"path": str(ROOT / "c3-aggregate-timeout-diagnosis-03/observation.json"), "bytes": 6824,
     "sha256": "0f87e2552bd5b43da9961bd8225da9f266960e8bfde4921fc5472cd9669c170f"},
]





def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path, elf=False):
    p = Path(path)
    before = p.lstat()
    require(stat.S_ISREG(before.st_mode), "ordinary file required: " + str(p))
    digest = hashlib.sha256()
    with p.open("rb") as f:
        if elf:
            header = f.read(64)
            require(header[:6] == b"\x7fELF\x02\x01" and int.from_bytes(header[18:20], "little") == 62
                    and before.st_mode & 0o111, "actual executable x86_64 ELF required")
            f.seek(0)
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    after = p.lstat()
    fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    require(all(getattr(before, k) == getattr(after, k) for k in fields), "file changed while hashing")
    return {"path": str(p), "bytes": before.st_size, "sha256": digest.hexdigest()}


def check(record, elf=False):
    p = pin(record["path"], elf)
    require(p["sha256"] == record["sha256"]
            and ("bytes" not in record or p["bytes"] == record["bytes"]), "retained file pin mismatch")
    return p


def save(path, value):
    path = Path(path)
    with path.open("x") as f:
        json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
        f.write("\n"); f.flush(); os.fsync(f.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return pin(path)


def guard(row):
    path = row.get("report_path", row.get("path"))
    p = check({"path": path, "sha256": row["sha256"]})
    data = json.loads(Path(path).read_bytes())
    require(p["sha256"] == SOURCE_SHA and data["schema"] == "trnm-ci-source-v1"
            and data["kind"] == "head" and data["tested_commit"] == HEAD
            and data["candidate"] == HEAD and data["tested_tree"] == TREE
            and data["tracked_worktree_verified"] is True
            and data["tests_executed_by_identity_check"] is False, "full raw C3 source identity required")
    if "report" in row:
        require(data == row["report"], "embedded source report differs from raw report")
    return {"report_path": path, "sha256": p["sha256"], "bytes": p["bytes"],
            "tested_commit": HEAD, "tested_tree": TREE}


def normalize(name, row, manifest_pin):
    exit_code = row["exit_code"] if "exit_code" in row else row["exit"]
    require(type(exit_code) is int and exit_code == 0 and not row.get("timed_out", False)
            and row.get("error") is None and row.get("accepted", True) is True,
            "all actual constituent commands must succeed")
    require(isinstance(row["argv"], list) and row["argv"] and all(type(x) is str for x in row["argv"]),
            "raw command argv required")
    logs = {}
    for key in ("stdout", "stderr"):
        if key + ".log" in row:
            selected = row[key + ".log"]
        elif key in row and isinstance(row[key], dict):
            selected = row[key]
        else:
            selected = {"path": row[key + "_path"], "sha256": row[key + "_sha256"]}
        logs[key] = check(selected)
    return {"component": name, "label": name + "/" + row["label"], "original_label": row["label"],
            "argv": row["argv"], "cwd": row.get("cwd", str(REPO)), "exit": 0,
            "stdout_path": logs["stdout"]["path"], "stdout_sha256": logs["stdout"]["sha256"],
            "stderr_path": logs["stderr"]["path"], "stderr_sha256": logs["stderr"]["sha256"],
            "raw_component_manifest": manifest_pin}


def resource_observation(label):
    observed = {"observed_monotonic_ns": time.monotonic_ns(), "observed_unix_ns": time.time_ns(),
                "pid": os.getpid(), "affinity": sorted(os.sched_getaffinity(0)),
                "complete_resource_accounting": False, "errors": []}
    for key, path in (("loadavg_raw", "/proc/loadavg"), ("cpu_pressure_raw", "/proc/pressure/cpu"),
                      ("self_stat_raw", "/proc/self/stat"), ("self_cgroup_raw", "/proc/self/cgroup")):
        try: observed[key] = Path(path).read_text()
        except OSError as error: observed["errors"].append({"path": path, "type": type(error).__name__, "message": str(error)})
    membership = observed.get("self_cgroup_raw", "").strip()
    if membership.startswith("0::/") and "\n" not in membership:
        group = Path("/sys/fs/cgroup") / membership[3:].lstrip("/")
        observed["own_cgroup_path"] = str(group)
        observed["own_cgroup_raw"] = {}
        for name in ("cpu.max", "cpu.stat", "cpu.pressure", "memory.max", "cgroup.events"):
            try: observed["own_cgroup_raw"][name] = (group / name).read_text()
            except OSError as error: observed["errors"].append({"path": str(group / name), "type": type(error).__name__, "message": str(error)})
    for name, who in (("self", resource.RUSAGE_SELF), ("waited_children", resource.RUSAGE_CHILDREN)):
        usage = resource.getrusage(who)
        observed[name + "_rusage"] = {"user_seconds": usage.ru_utime, "system_seconds": usage.ru_stime,
                                      "max_rss_kib": usage.ru_maxrss}
    return save(OUT / (label + ".resource.json"), observed)


def main():
    os.sched_setaffinity(0, {10, 11})
    attempt = {"schema": "TRNM-W1-C3-AGGREGATE-ATTEMPT1", "source_commit": HEAD, "source_tree": TREE,
               "completed": False, "commands": [], "errors": [], "wrapper": pin(__file__),
               "fresh_proof_generations": 0, "test_bodies_executed": False, "attempt_id": "02"}
    env = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C", "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        def run(label, argv, timeout=180):
            stdout, stderr = OUT / (label + ".stdout"), OUT / (label + ".stderr")
            trace = OUT / (label + ".git-trace2.json")
            command_env = dict(env)
            command_env["GIT_TRACE2_EVENT"] = str(trace)
            started = time.monotonic_ns()
            before_resource = resource_observation(label + "-before")
            print(json.dumps({"event": "COMMAND_STARTED", "label": label, "argv": argv,
                              "timeout_seconds": timeout, "resource_before": before_resource}), flush=True)
            completed = None
            caught = None
            with stdout.open("xb") as so, stderr.open("xb") as se:
                try:
                    completed = subprocess.run(argv, cwd=REPO, env=command_env, stdout=so, stderr=se,
                                               stdin=subprocess.DEVNULL, timeout=timeout, check=False)
                except BaseException as error:
                    caught = error
                finally:
                    so.flush(); os.fsync(so.fileno()); se.flush(); os.fsync(se.fileno())
            row = {"label": "aggregate/" + label, "argv": argv, "cwd": str(REPO),
                   "exit": completed.returncode if completed is not None else None,
                   "timeout_seconds": timeout, "elapsed_ns": time.monotonic_ns() - started,
                   "timed_out": isinstance(caught, subprocess.TimeoutExpired),
                   "error": {"type": type(caught).__name__, "message": str(caught)} if caught else None,
                   "stdout_path": str(stdout), "stdout_sha256": pin(stdout)["sha256"],
                   "stderr_path": str(stderr), "stderr_sha256": pin(stderr)["sha256"],
                   "resource_before": before_resource,
                   "git_trace2": pin(trace) if trace.exists() else None,
                   "complete_resource_accounting": False, "all_descendants_reaped": None}
            try: row["resource_after"] = resource_observation(label + "-after")
            except Exception as error:
                row["resource_after_error"] = {"type": type(error).__name__, "message": str(error)}
            attempt["commands"].append(row)
            print(json.dumps({"event": "COMMAND_FINISHED", "label": label, "exit": row["exit"],
                              "timed_out": row["timed_out"], "elapsed_ns": row["elapsed_ns"],
                              "error": row["error"], "git_trace2": row["git_trace2"]}), flush=True)
            if caught is not None: raise caught
            require(row["exit"] == 0, label + " failed")
            return stdout, stderr

        prior_pin = check(PRIOR_AGGREGATE)
        prior = json.loads(Path(prior_pin["path"]).read_bytes())
        require(prior["completed"] is False and prior["source_commit"] == HEAD
                and prior["source_tree"] == TREE and prior["errors"], "retain original failed aggregate")
        prior_terminal = OUT / "terminal-prior-aggregate.json"
        prior_status = json.loads(prior_terminal.read_bytes())
        require(prior_status["job_id"] == "1a1b8866fca-12894-fee" and prior_status["state"] == "failed"
                and prior_status["exit_code"] == 1 and prior_status["output_complete"] is True
                and prior_status["output_durable"] is True, "retain actual failed aggregate terminal")
        attempt_history = {"prior_failed_result": prior_pin, "prior_failed_terminal": pin(prior_terminal),
                           "bounded_diagnostics": [check(row) for row in TIMEOUT_DIAGNOSTICS],
                           "cause": "UNDETERMINED; environment and CPU causation were not established",
                           "historical_affinity_and_load_not_reconstructed": True,
                           "earlier_source_guard_timeout_seconds": 180,
                           "metadata_status_timeouts_seconds": [15, 15],
                           "later_traced_status_exit": 0, "later_traced_status_elapsed_seconds": 0.213262,
                           "same_original_qualification_logic_and_timeouts": True}
        attempt["attempt_history"] = attempt_history

        run("preflight", ["/usr/bin/bash", "scripts/project-preflight.sh", "--dev"])
        run("source-before", ["/usr/bin/python3", "scripts/ci/verify_ci_source.py", "--kind", "head",
                             "--expected-head", HEAD, "--output", str(OUT / "source-before.json")])
        source_before = guard(pin(OUT / "source-before.json"))
        statuses = {}
        for name, job_id in JOBS.items():
            raw = OUT / ("terminal-" + name + ".json")
            value = json.loads(raw.read_bytes())
            require(value["job_id"] == job_id and value["output_complete"] is True
                    and value["output_durable"] is True and value["timed_out"] is False
                    and value["cancelled"] is False, "actual complete durable terminal required")
            require((value["state"], value["exit_code"]) == ("succeeded", 0)
                    and value["terminal_publication_confirmed"] is True
                    and value["log_errors"] == {"stdout": None, "stderr": None}
                    and value["log_synced"] == {"stdout": True, "stderr": True}
                    and value["log_truncated"] == {"stdout": False, "stderr": False},
                    "actual successful untruncated durable terminal required")
            statuses[name] = {"raw": pin(raw), "status": value}
        status_pin = save(OUT / "gate-job-statuses.json", statuses)
        manifests, manifest_pins = {}, {}
        for name, (relative, digest) in MANIFESTS.items():
            p = check({"path": str(ROOT / relative), "sha256": digest})
            value = json.loads(Path(p["path"]).read_bytes())
            if name == "ci":
                require(value["expected_head"] == HEAD and value["expected_tree"] == TREE,
                        "CI expected source identity")
            else:
                require(value["source_commit"] == HEAD and value["source_tree"] == TREE,
                        "component exact source identity")
            manifests[name], manifest_pins[name] = value, p
        b, n, o, ci = [manifests[k] for k in ("backend", "native", "owner", "ci")]
        previous_pin = check(PREVIOUS_C2)
        previous = json.loads(Path(previous_pin["path"]).read_bytes())
        require(previous["schema"] == "TRNM-W1-CLEAN-BUILD-QUALIFICATION1"
                and previous["qualification_complete"] is True and previous["source_commit"] == C2_HEAD
                and previous["source_tree"] == C2_TREE
                and set(previous["binaries"]) == {"native_winner", "verifier", "owner_test", "runner", "r0vm"},
                "original exact C2 qualification remains immutable")
        previous_before = {role: check(row, elf=True) for role, row in previous["binaries"].items()}
        historical_pins = {name: check(row) for name, row in HISTORICAL.items()}
        old_owner_observation = check(OLD_OWNER_PATH_OBSERVATION)
        failed_cache_records = {}
        for name, retained in FAILED_CACHE_PREPARATIONS.items():
            mp = check(retained["manifest"])
            failure = json.loads(Path(mp["path"]).read_bytes())
            require(failure["cache_setup_complete"] is False and failure["errors"]
                    and failure["source_commit"] == HEAD and failure["source_tree"] == TREE,
                    "original failed cache preparation must remain a failure")
            raw = OUT / ("terminal-failed-" + name + ".json")
            terminal = json.loads(raw.read_bytes())
            require(terminal["job_id"] == retained["job_id"] and terminal["state"] == "failed"
                    and terminal["exit_code"] == 1 and terminal["output_complete"] is True
                    and terminal["output_durable"] is True, "original failed terminal required")
            failed_cache_records[name] = {"manifest": mp, "raw_terminal": pin(raw), "terminal": terminal,
                                          "qualification_commands_started": False}
        failed_map_pin = check(FAILED_MAP_PREPARATION)
        failed_map = json.loads(Path(failed_map_pin["path"]).read_bytes())
        require(failed_map["source_commit"] == HEAD and failed_map["source_tree"] == TREE
                and failed_map["preparation_complete"] is False and failed_map["errors"],
                "first map preparation failure must remain retained as failure")
        coverage_diagnosis = check(MAP_COVERAGE_DIAGNOSIS)
        publication = manifests["publication_map"]
        require(publication["schema"] == "TRNM-W1-C3-PUBLICATION-MERGE-MAP-PREPARATION2"
                and publication["preparation_complete"] is True and publication["errors"] == []
                and publication["actual_parents"] == [C2_HEAD, UPSTREAM]
                and publication["expected_parents"] == [C2_HEAD, UPSTREAM]
                and publication["previous_publication_commit"] == C2_HEAD
                and publication["previous_publication_tree"] == C2_TREE
                and publication["common_ancestor"] == ANCESTOR
                and publication["full_tree_matches_reviewed_composition"] is True
                and publication["C2_unaffected_entries_preserved"] is True
                and publication["inherited_experiment_qualification_reassigned"] is False
                and publication["source_identity_equal_before_after"] is True
                and publication["frozen_path_count"] == 3057
                and len(publication["changed_paths"]) == 2354
                and len(publication["added_evidence_paths"]) == 2346
                and len(publication["added_frozen_paths"]) == 2348
                and publication["exact_CI_executed"] is False and publication["fresh_proof_generations"] == 0,
                "actual closed exact two-parent C3 merge identity and byte coverage")
        publication_map_pin = check(PUBLICATION_MAP)
        require(check(publication["frozen_source_record"]) == publication_map_pin, "actual publication map pin")
        publication_map = json.loads(Path(publication_map_pin["path"]).read_bytes())
        require(publication_map["schema"] == "TRNM-W1-MERGE-PUBLICATION-FROZEN-SOURCES2"
                and publication_map["publication_commit"] == HEAD and publication_map["publication_tree"] == TREE
                and publication_map["parents"] == [C2_HEAD, UPSTREAM]
                and publication_map["previous_publication_commit"] == C2_HEAD
                and publication_map["previous_publication_tree"] == C2_TREE
                and publication_map["common_ancestor"] == ANCESTOR
                and len(publication_map["paths"]) == 3057,
                "C3 exact frozen publication map identity")
        difference_pin = check(publication["merge_differences"])
        differences = json.loads(Path(difference_pin["path"]).read_bytes())
        require(differences["parents"] == [C2_HEAD, UPSTREAM]
                and differences["source_commit"] == HEAD and differences["source_tree"] == TREE
                and differences["changed_path_count"] == 2354 and differences["added_path_count"] == 2347
                and differences["modified_path_count"] == 7 and differences["added_evidence_count"] == 2346,
                "actual merge difference counts")
        ci_declaration_pin = check(ci["declaration"])
        ci_declaration = json.loads(Path(ci_declaration_pin["path"]).read_bytes())
        require(ci["qualification_phase"] == "publication-head"
                and ci_declaration["candidate_source_record"] == publication_map_pin["path"]
                and ci_declaration["candidate_source_record_sha256"] == publication_map_pin["sha256"],
                "actual exact CI consumed this publication map")
        require(len(publication["commands"]) == 12, "twelve actual publication map observations")
        publication_commands = [normalize("publication_map", row, manifest_pins["publication_map"])
                                for row in publication["commands"]]
        publication_source_guards = {phase: guard(publication[phase])
                                     for phase in ("source_before", "source_after")}
        caches = {}
        for role, expected_pin in CACHE_PINS.items():
            retained = check(expected_pin)
            value = json.loads(Path(retained["path"]).read_bytes())
            require(value["cache_setup_complete"] is True and value["errors"] == []
                    and value["source_commit"] == HEAD and value["source_tree"] == TREE
                    and value["copied_cache_from_C2"] is True and value["fresh_cargo_target"] is False
                    and value["independent_reproducible_build_established"] is False
                    and value["shared_original_regular_inodes"] == 0
                    and value["original_cache_snapshot_unchanged"] is True,
                    "actual isolated copied C2 cache; no independent rebuild claim")
            if role != "owner":
                require(manifests[role]["copied_cache_setup"]["path"] == retained["path"]
                        and manifests[role]["copied_cache_setup"]["sha256"] == retained["sha256"]
                        and manifests[role]["original_C2_binaries_unchanged_after"] is True,
                        "gate bound the isolated copy and original ELF readback")
            caches[role] = {"manifest": retained, "observation": value}

        require(b["qualification_complete"] is True and b["errors"] == []
                and b["test_result"]["passed"] == 22 and b["test_result"]["failed"] == 0
                and b["test_result"]["ignored"] == 0, "backend exact gates")
        require(o["qualification_complete"] is True and o["errors"] == [] and o["fresh_cargo_target"] is False
                and o["test_counts"] == {"node_passed": 15, "node_explicit_ignored": 3, "m12_passed": 10, "m12_ignored": 0,
                    "legacy_admission_passed": 1, "legacy_admission_ignored": 0, "legacy_reorg_passed": 5, "legacy_reorg_ignored": 0},
                "owner exact gates")
        require(o["retained_upstream_commit"] == UPSTREAM, "retained upstream source identity")
        retained_counts = {}
        for label, count in (("legacy-admission-root-tests", 1), ("legacy-reorg-root-tests", 5)):
            row = o["retained_test_counts"][label]
            require(row["source_commit"] == HEAD and row["source_tree"] == TREE
                    and row["upstream_commit"] == UPSTREAM
                    and row["passed"] == count and row["failed"] == 0 and row["ignored"] == 0,
                    "retained upstream actual test counts")
            raw_pin = check(row["stdout"])
            observed = re.findall(r"^test (\S+) \.\.\. ok$", Path(raw_pin["path"]).read_text(), re.M)
            require(collections.Counter(observed) == collections.Counter(row["required_exact_selectors"])
                    and len(observed) == count and all(v == 1 for v in collections.Counter(observed).values())
                    and observed == row["observed_passed"], "all six retained test names from actual raw logs")
            retained_counts[label] = {"passed": count, "actual_stdout": raw_pin,
                                      "exact_selectors": row["required_exact_selectors"]}
        require(ci["all_passed"] is True and ci["executed_checks"] == ci["planned_checks_including_source_after"] == 19
                and ci["source_identity_equal_before_after"] is True and ci["frozen_candidate_bytes_unchanged"] is True
                and ci["selected_test_methods_planned"] == 471 and ci["mandatory_test_methods_planned"] == 104,
                "CI exact nineteen checks and method counts")
        require(n["passed"] is True and n["source_clean_after"] is True and n["locks_unchanged"] is True
                and n["fresh_cargo_target"] is False and b["fresh_cargo_target"] is False
                and set(n["binaries"]) == {"native_winner", "verifier"}
                and n["test_counts"]["10-native-tests"] == {"groups": 26, "passed": 243, "failed": 0, "ignored": 0}
                and n["test_counts"]["12-verifier-tests"] == {"groups": 1, "passed": 2, "failed": 0, "ignored": 0},
                "current exact native/verifier gate must succeed normally")
        roster = n["strict_native_roster"]
        require(roster["count"] == 243 and roster["exact_actual_names_equal"] is True
                and roster["actual_groups"] == 26 and roster["actual_receiver_controls"] == 7,
                "strict current 243 roster and real seven receiver controls")
        roster_pin = check(roster["expected_roster"])
        roster_data = json.loads(Path(roster_pin["path"]).read_bytes())
        expected_names = collections.Counter({row["name"]: row["count"] for row in roster_data["tests"]})
        require(sum(expected_names.values()) == 243, "fixed exact native roster length")
        native_log = Path(manifest_pins["native"]["path"]).parent / "10-native-tests.stdout"
        native_text = native_log.read_text()
        actual_names = collections.Counter(line[5:-7] for line in native_text.splitlines()
                                           if line.startswith("test ") and line.endswith(" ... ok"))
        groups = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;", native_text)
        require(actual_names == expected_names and len(groups) == 26
                and all(tuple(map(int, row))[1:] == (0, 0, 0, 0) for row in groups),
                "current actual native log must equal the predeclared roster with no skipped tests")
        receiver_log = Path(manifest_pins["native"]["path"]).parent / "15-real-receiver-controls.stderr"
        receiver_text = receiver_log.read_text()
        require(re.findall(r"^Ran ([0-9]+) tests in .+$", receiver_text, re.M) == ["7"]
                and "OK" in receiver_text.splitlines(), "seven actual receiver controls")
        require(n["receiver_control_uses_historical_receipt"] is True and n["proof_launched"] is False,
                "receiver controls do not establish a fresh full proof")
        normalized = []
        source_guards = {}
        for name, expected_count in (("backend", 13), ("native", 21), ("owner", 16), ("ci", 19)):
            value = manifests[name]
            require(len(value["commands"]) == expected_count, "complete retained command set required")
            normalized.extend(normalize(name, row, manifest_pins[name]) for row in value["commands"])
            source_guards[name] = {phase: guard(value[phase]) for phase in ("source_before", "source_after")}
        for raw in ci["raw_files"]:
            check(raw)
        require(len(normalized) == 69, "exact current component command count")
        binaries = {}
        for role, row in (("native_winner", n["binaries"]["native_winner"]),
                          ("verifier", n["binaries"]["verifier"]), ("owner_test", o["binaries"]["owner_test"]),
                          ("runner", b["runner"])):
            p = check(row, elf=True)
            expected_target = Path(caches[{"native_winner": "native", "verifier": "native", "owner_test": "owner", "runner": "backend"}[role]]["observation"]["destination_target"])
            require(Path(p["path"]).is_relative_to(expected_target)
                    and p["path"] != previous_before[role]["path"], "role must use its distinct actual C3 Cargo target")
            require((Path(p["path"]).stat().st_dev, Path(p["path"]).stat().st_ino)
                    != (Path(previous_before[role]["path"]).stat().st_dev, Path(previous_before[role]["path"]).stat().st_ino),
                    "new qualified role must not share original C2 executable inode")
            binaries[role] = {**p, "kind": "repository_build", "source_commit": HEAD, "source_tree": TREE,
                              "raw_role_record": row}
        r0 = pin(ROOT / "fixed-backend-01/r0vm", elf=True)
        require(r0["sha256"] == R0_SHA and r0["bytes"] == 108764424, "fixed original upstream r0vm")
        version_out, _ = run("r0vm-version", [r0["path"], "--version"], 60)
        require(version_out.read_text().strip() == "risc0-r0vm 3.0.3", "actual fixed r0vm version")
        binaries["r0vm"] = {**r0, "kind": "fixed_upstream_release", "upstream_version": "3.0.3",
                            "version_stdout": pin(version_out), "newly_built_for_C3": False}
        lock_paths = [
            "trillionnium/Cargo.lock", "formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock",
            "formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock",
            "formal/pon-nakamoto-v1/w1_zkvm/methods/guest/Cargo.lock",
            "formal/pon-nakamoto-v1/w1_zkvm/methods/guest-v2/Cargo.lock",
        ]
        locks = {relative: pin(REPO / relative) for relative in lock_paths}
        nb = json.loads((Path(manifest_pins["native"]["path"]).parent / "locks-before.json").read_bytes())
        na = json.loads((Path(manifest_pins["native"]["path"]).parent / "locks-after.json").read_bytes())
        require(nb == na and all(locks[k]["sha256"] == v for k, v in nb.items()), "native locks changed")
        require(o["locks_before"] == o["locks_after"]
                and locks["trillionnium/Cargo.lock"]["sha256"] == o["locks_before"]["trillionnium/Cargo.lock"]["sha256"],
                "owner lock closure")
        for relative in lock_paths:
            if relative in b["owned_source_before"]:
                require(b["owned_source_before"][relative]["sha256"] == b["owned_source_after"][relative]["sha256"]
                        == locks[relative]["sha256"], "backend lock closure")
        guest = pin(REPO / "evidence/pon-w1-full-v2-20261105/guest.bin")
        require(guest["sha256"] == GUEST_SHA and guest["bytes"] == 375928, "original retained guest bytes")
        require(b["guest_build_provenance"], "actual current build provenance required")
        for row in b["guest_build_provenance"]:
            check(row["original"]); check(row["raw_copy"]); check(row["retained_guest"]); check(row["generated_methods"])
            value = json.loads(Path(row["raw_copy"]["path"]).read_bytes())
            require(value == row["value"] and value["mode"] == "retained-v2-guest"
                    and value["sha256"] == GUEST_SHA and value["image_id"] == IMAGE
                    and value["sdk_image_checked"] is True and value["guest_compilation_performed"] is False,
                    "retained guest SDK qualification")
        guest.update(image_id=IMAGE, guest_compilation_performed=False,
                     build_provenance=b["guest_build_provenance"])
        run("source-after", ["/usr/bin/python3", "scripts/ci/verify_ci_source.py", "--kind", "head",
                            "--expected-head", HEAD, "--output", str(OUT / "source-after.json")])
        source_after = guard(pin(OUT / "source-after.json"))
        require(source_before["sha256"] == source_after["sha256"], "aggregate source changed")
        for name, p in manifest_pins.items():
            check(p)
        for row in binaries.values():
            check(row, elf=True)
        previous_after = {role: check(row, elf=True) for role, row in previous["binaries"].items()}
        require(previous_before == previous_after, "all five actual original C2 qualified ELF pins changed")
        check(previous_pin)
        for retained in historical_pins.values(): check(retained)
        check(old_owner_observation); check(publication_map_pin); check(ci_declaration_pin)
        for expected_pin in CACHE_PINS.values():
            check(expected_pin)
        qualification = {
            "schema": "TRNM-W1-CLEAN-BUILD-QUALIFICATION1", "source_commit": HEAD, "source_tree": TREE,
            "repo_path": str(REPO), "qualification_complete": True,
            "source_clean_before": True, "source_clean_after": True,
            "source_before": source_before, "source_after": source_after,
            "commands": normalized + publication_commands + attempt["commands"], "component_successful_command_count": len(normalized),
            "publication_map_observation_command_count": len(publication_commands),
            "aggregate_observation_command_count": len(attempt["commands"]),
            "binaries": binaries, "locks": locks, "guest": guest,
            "gate_manifests": manifest_pins, "gate_jobs": status_pin, "component_source_guards": source_guards,
            "native_current_roster": {"count": 243, "roster": roster_pin,
                                      "actual_native_run": pin(native_log), "actual_groups": 26,
                                      "actual_real_receiver_log": pin(receiver_log), "actual_real_receiver_controls": 7,
                                      "native_wrapper_passed": True, "native_wrapper_terminal": statuses["native"],
                                      "historical_receipt_used_only_for_receiver_controls": True},
            "historical_qualification_records": historical_pins,
            "historical_C1_C1b_current_binary_reverification": {
                "all_five_pins_unchanged": None, "qualification_reperformed": False,
                "status": "UNKNOWN_UNAVAILABLE_OR_NOT_REOBSERVED",
                "original_failed_C1_cache_attempts": failed_cache_records,
                "actual_old_owner_path_observation": old_owner_observation,
                "scope": "Historical qualification records remain pinned. Current missing C1 cache files and old owner target roots do not establish current binary preservation; no old path was rebuilt or backfilled."},
            "original_C2_binaries_preservation": {"observed_after_all_four_exact_gates": True,
                "before_aggregation": previous_before, "after_aggregation": previous_after,
                "all_five_pins_unchanged": True, "raw_original_qualification": previous_pin},
            "publication_preparation_history": {
                "first_map_failed": failed_map_pin, "coverage_diagnosis": coverage_diagnosis,
                "first_map_failure_not_credited_to_successful_command_count": True,
                "successful_second_map": manifest_pins["publication_map"]},
            "publication_identity": {"phase": "publication-head", "parents": [C2_HEAD, UPSTREAM],
                "common_ancestor": ANCESTOR, "map_preparation_manifest": manifest_pins["publication_map"],
                "frozen_map": publication_map_pin, "ci_declaration": ci_declaration_pin,
                "frozen_paths": len(publication_map["paths"]), "merge_differences": difference_pin,
                "changed_paths": 2354, "modified_paths": 7, "added_paths": 2347,
                "added_upstream_evidence_files": 2346, "newly_covered_paths": 2348,
                "newly_covered_existing_modified_paths": ["docs/protocol/pon-nakamoto-v1/details/STATE_RECOVERY.md"],
                "full_tree_matches_reviewed_composition": True, "map_source_guards": publication_source_guards,
                "experimental_runs_not_reexecuted_for_C3": True},
            "retained_upstream_tests": retained_counts,
            "test_methods_reported": {"backend": 22, "native": 243, "verifier": 2, "real_receiver_controls": 7,
                                      "node": 15, "m12": 10, "legacy_admission_root": 1, "legacy_reorg_root": 5, "ci": 471, "sum": 776,
                                      "owner_heavy_entries_explicitly_ignored": 3},
            "fresh_cargo_target": False,
            "fresh_cargo_target_basis": "All three build targets were independent inode copies of qualified C2 caches; actual Cargo artifact fresh/rebuilt fields remain in each component manifest. This is not an independent rebuild.",
            "target_observations": {
                "native": {"path": n["target_dir"], "fresh_cargo_target": False,
                           "copied_cache_setup": caches["native"], "actual_binaries": n["binaries"]},
                "owner": {"path": o["target"], "fresh_cargo_target": False,
                          "copied_cache_setup": caches["owner"], "actual_binaries": o["binaries"]},
                "backend": {"path": b["target_dir"], "fresh_cargo_target": False,
                            "copied_cache_setup": caches["backend"],
                            "owned_release_fingerprint_observation_before": b["cargo_fingerprints_before"],
                            "cargo_artifact_fresh_rebuilt_readback": b["cargo_json_artifacts"]}
            },
            "fresh_proof_generations": 0, "guest_compilation_performed": False,
            "independent_reproducible_build_established": False, "original_business_budget_qualified": False,
            "security_qualified": False, "production_qualified": False, "payment_qualified": False,
            "complete_process_tree_resource_accounting_qualified": False,
            "scope": "Exact C3 two-parent merge source/build identities and retained development gates only. The six added retained native tests are separate from the fifteen async Node tests. Retained experimental runs keep their actual A or C1b identity. No new full proof, deployment, original business-budget, full resource-accounting, payment or cryptographic-security qualification.",
            "aggregation_attempt_history": attempt_history,
            "aggregate_wrapper": pin(__file__), "observed_monotonic_ns": time.monotonic_ns(),
        }
        require(set(binaries) == {"owner_test", "native_winner", "runner", "verifier", "r0vm"}, "exact five roles")
        require(len(attempt["commands"]) == 4 and len(qualification["commands"]) == 85,
                "69 actual component plus 12 map plus four aggregate commands required")
        require(sum(v for k, v in qualification["test_methods_reported"].items()
                    if k not in ("sum", "owner_heavy_entries_explicitly_ignored")) == 776,
                "actual separated test method total")
        qpin = save(BASE / "qualification.json", qualification)
        attempt.update(completed=True, qualification=qpin)
    except BaseException as exc:
        attempt["errors"].append({"type": type(exc).__name__, "message": str(exc)})
    attempt["completed_monotonic_ns"] = time.monotonic_ns()
    record = save(OUT / "result.json", attempt)
    print(json.dumps({"completed": attempt["completed"], "result": record,
                      "qualification": attempt.get("qualification"), "errors": attempt["errors"]}), flush=True)
    return 0 if attempt["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

