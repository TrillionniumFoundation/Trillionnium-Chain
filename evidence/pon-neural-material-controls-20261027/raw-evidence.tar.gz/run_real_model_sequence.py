"""One controlled observation using original owners; never ordinary I10 authority."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
CHAIN = ROOT / 'chain-native-c96022'
HEPTA = ROOT / 'hepta-native-e153'
MATERIALS = ROOT / 'materials-legacy-i09'
OUT = ROOT / 'real-model-run-001'
PYTHON = ROOT / 'model-env-3123-offline/bin/python'
sys.path.insert(0, str(CHAIN / 'scripts'))
import llm_runtime_pilot as runtime
import llm_initial_trainable_setup_v2 as setup
import llm_inherited_runtime as inherited
import llm_parent_material as parent
import llm_runtime_parent_step_v2 as producer

OUT.mkdir(mode=0o700)
os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
                  PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1',
                  OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2')
summary = dict(schema='controlled-real-neural-sequence-observation-v1',
               source_chain='c96022b897c1235fdbdbfcfa32764403511c6aab',
               source_hepta='e1537d7deea32f29ec9612c0a7b90655b14aa904',
               scope='unselected-fixed-initial-material-training-evaluation-tcp-fetch-and-backend-readback',
               ordinary_installation_qualified=False, ordinary_task_used=False,
               independent_evaluation=False, public_reward_eligible=False, phases=[])


def command(name, args):
    start = time.monotonic_ns()
    with (OUT / (name + '.log')).open('xb') as log:
        result = subprocess.run([str(x) for x in args], cwd=CHAIN,
                                stdout=log, stderr=subprocess.STDOUT)
    observed = dict(name=name, command=[str(x) for x in args],
                    exit_code=result.returncode, wall_ns=time.monotonic_ns()-start)
    summary['phases'].append(observed)
    runtime.save(OUT / 'run-summary.json', summary)
    print(json.dumps(observed), flush=True)
    return result.returncode


try:
    for repository, expected in [(CHAIN, summary['source_chain']), (HEPTA, summary['source_hepta'])]:
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repository, text=True).strip() == expected
        assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repository, text=True).strip()
    material, _ = runtime.verify_materials(MATERIALS)
    initial_plan = runtime.validate_plan(runtime.experiment_plan(material, threads=1, steps=10))
    training_plan = runtime.validate_plan(runtime.experiment_plan(material, threads=2, steps=10))
    runtime.save(OUT / 'initial-plan.json', initial_plan)
    runtime.save(OUT / 'training-plan.json', training_plan)
    runtime.save(OUT / 'frozen-sequence.json', dict(summary,
        initial_plan=runtime.identity(initial_plan), training_plan=runtime.identity(training_plan),
        intended_phases=['actual-loader', 'fixed-initial-material', 'original-v2-parent-train',
                         'original-candidate-observer', 'original-I09-handoff', 'post-fetch-backend-request'],
        initial_parent_installed=False, training_steps=10, inference_requests=8,
        next_request='Answer with only yes or no. Is 103 greater than 102?',
        no_installer_or_issuer_constructed=True))
    loader = OUT / 'loader'
    result = runtime.supervise([str(PYTHON), str(CHAIN / 'scripts/llm_runtime_pilot.py'), '_child',
        '--materials', str(MATERIALS), '--plan', str(OUT/'initial-plan.json'), '--output', str(loader),
        '--phase', 'loader', '--role', 'current-backbone'], loader, initial_plan['inference_budget'])
    summary['phases'].append(dict(name='actual-loader', result=result))
    runtime.save(OUT / 'run-summary.json', summary)
    print(json.dumps(dict(phase='actual-loader', outcome=result['outcome'], stop_reason=result['stop_reason'])), flush=True)
    runtime.require(result['outcome'] == 'success', 'REAL_SEQUENCE_LOADER_FAILED')
    loaded = runtime.read_json(loader / 'actual-receipt.json')
    runtime.require(loaded['outcome'] == 'success' and loaded['forward_executed'] is True,
                    'REAL_SEQUENCE_ACTUAL_LOADER')
    initial = OUT / 'initial-parent'
    initial.mkdir()
    raw = parent.read_regular(loader / 'target-contract.json', 1024**2)
    contract = runtime.contract_module().verify_target_contract(raw, loaded['contract'])
    zero = setup.canonical_zero_parent()
    factors = parent.factor_bytes(zero, contract)
    wrapper, adapter = runtime.contract_module().freeze_wrapped_adapter(
        setup._wrapped(contract, loaded['contract'], factors), contract, loaded['contract'])
    (initial / 'target-contract.json').write_bytes(raw)
    (initial / 'artifact.safetensors').write_bytes(zero)
    (initial / 'wrapped-adapter.json').write_bytes(wrapper)
    descriptor = dict(schema=inherited.PARENT_SCHEMA, generation=1,
        operation_id='controlled-fixed-initial-material-001', directory=str(initial),
        contract=loaded['contract'], adapter=adapter, file_sha256=setup.PARENT_SHA256)
    inherited.read_parent(descriptor)
    runtime.save(initial / 'parent-material.json', descriptor)
    train = OUT / 'parent-train'
    args = [PYTHON, CHAIN/'scripts/llm_runtime_pilot.py', 'parent-step', '--operation', 'train',
        '--materials', MATERIALS, '--plan', OUT/'training-plan.json', '--expected-plan', runtime.identity(training_plan),
        '--output', train, '--attempt-id', runtime.identity('real-parent-train-001'),
        '--parent-contract', initial/'target-contract.json', '--parent-adapter', initial/'wrapped-adapter.json',
        '--parent-artifact', initial/'artifact.safetensors', '--expected-contract', descriptor['contract'],
        '--expected-parent-adapter', descriptor['adapter'], '--expected-parent-file-sha256', descriptor['file_sha256'],
        '--initial-setup-profile', producer.NEW_TASK_PROFILE,
        '--parent-material', initial/'parent-material.json', '--parent-material-sha256', runtime.file_sha(initial/'parent-material.json')]
    runtime.require(command('parent-train', args) == 0, 'REAL_SEQUENCE_TRAIN_FAILED')
    actual = runtime.read_json(train/'execution/actual-receipt.json')
    runtime.require(actual['training_changed_from_setup'] is True, 'REAL_SEQUENCE_NO_TRAINING_CHANGE')
    candidate = actual['candidate']
    args = [PYTHON, CHAIN/'scripts/llm_runtime_candidate_observation_v1.py', 'evaluate',
        '--training-directory', train, '--expected-training-result-sha256', runtime.file_sha(train/'parent-step-result-v2.json'),
        '--expected-candidate-record-sha256', runtime.file_sha(train/'execution/parent-candidate-v2.json'),
        '--expected-contract', descriptor['contract'], '--expected-parent-adapter', descriptor['adapter'],
        '--expected-parent-file-sha256', descriptor['file_sha256'], '--expected-candidate-adapter', candidate['adapter'],
        '--expected-candidate-file-sha256', candidate['file_sha256'], '--output', OUT/'candidate-observe',
        '--attempt-id', runtime.identity('real-candidate-observe-001')]
    runtime.require(command('candidate-observe', args) == 0, 'REAL_SEQUENCE_OBSERVATION_FAILED')
    candidate_descriptor = dict(descriptor, generation=2, directory=str(train/'execution'),
        operation_id='controlled-unselected-candidate-material-001', **candidate)
    inherited.read_parent(candidate_descriptor)
    candidate_path = train/'execution/parent-material.json'
    runtime.save(candidate_path, candidate_descriptor)
    handoff = OUT / 'cell-handoff'
    args = [PYTHON, CHAIN/'scripts/run_llm_cell_native_handoff.py', '--chain', CHAIN, '--hepta', HEPTA,
        '--source-parent', candidate_path, '--source-materials', MATERIALS, '--output', handoff,
        '--python', PYTHON, '--cell-bin', ROOT/'chain-target/debug/trnm-cell',
        '--just', Path(shutil.which('just') or '/usr/bin/just'), '--hepta-target', ROOT/'hepta-target',
        '--cache-max-bytes', '536870912', '--cache-max-chunks', '4096',
        '--cache-max-manifests', '256', '--cache-max-db-bytes', '536870912']
    code = command('cell-handoff', args)
    transfer = runtime.read_json(handoff/'handoff.json')
    runtime.require(code != 0 and transfer['status'] == 'failed' and
        transfer.get('transfer', {}).get('all_members_verified') is True and
        transfer['transfer']['within_original_deadline'] is True and
        transfer['native_consumer_status'] == 'UNAVAILABLE', 'REAL_SEQUENCE_CELL_BOUNDARY')
    summary['original_I10_handoff_outcome'] = 'FAILED_UNAVAILABLE_RETAINED'
    request = dict(schema='hepta-smollm-inference-input-v1', request_id='post-fetch-readback-001',
                   prompt='Answer with only yes or no. Is 103 greater than 102?')
    request_path = OUT / 'next-request.json'
    runtime.save(request_path, request)
    fetched_parent = handoff/'consumer-parent/parent-material.json'
    args = [PYTHON, CHAIN/'scripts/llm_inherited_runtime.py', 'infer', '--materials', handoff/'consumer-materials',
        '--parent', fetched_parent, '--parent-sha256', runtime.file_sha(fetched_parent),
        '--input', request_path, '--input-sha256', runtime.file_sha(request_path),
        '--operation-id', request['request_id'], '--output', OUT/'next-readback', '--threads', '2', '--steps', '10']
    runtime.require(command('post-fetch-readback', args) == 0, 'REAL_SEQUENCE_READBACK_FAILED')
    next_receipt = runtime.read_json(OUT/'next-readback/worker/actual-receipt.json')
    runtime.require(next_receipt['actual_loaded_parent'] == candidate['adapter'] and
        next_receipt['artifact'] == candidate['adapter'] and next_receipt['forward_executed'] is True and
        all(value is False for value in next_receipt['authority'].values()), 'REAL_SEQUENCE_READBACK_IDENTITY')
    summary.update(controlled_backend_sequence_observed=True,
        trained_candidate=candidate, next_task_loaded_adapter=next_receipt['actual_loaded_parent'],
        next_task_output=next_receipt['prediction']['response']['decoded_outputs'],
        original_I10_failure_preserved=True)
except BaseException as error:
    summary.update(controlled_backend_sequence_observed=False, error_type=type(error).__name__, error=str(error))
    raise
finally:
    runtime.save(OUT/'run-summary.json', summary)
