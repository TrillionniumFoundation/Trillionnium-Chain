from pathlib import Path
from collections import Counter
import json,hashlib,sys,time,resource
root=Path('/home/qian-qi/work/chain-native-operation-readback-f0-20261119-2e9b');out=root/'automatic-ci-final-readback-2';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);p=root/'automatic-ci-1/SNAPSHOT.json';raw=p.read_bytes();x=json.loads(raw)
assert x['all_final'] is True and x['complete_job_denominators'] is True and x['all_observed_failed_job_logs_retained'] is True and not x['api_failures']
runs=x['runs'];assert len(runs)==26 and sum(r['run']['event']!='workflow_dispatch' for r in runs)==25
jobs=[j for r in runs for j in r['jobs']['items']];logs=[{'run_id':r['run']['id'],**v} for r in runs for v in r['failed_job_log_requests']]
for item in logs:
 b=(root/'automatic-ci-1'/item['file']).read_bytes();assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
rows=[]
for r in runs:
 rows.append({'run_id':r['run']['id'],'name':r['run']['name'],'event':r['run']['event'],'status':r['run']['status'],'conclusion':r['run']['conclusion'],'job_denominator':len(r['jobs']['items']),'job_conclusions':dict(Counter(j['conclusion'] for j in r['jobs']['items'])),'artifacts':r['artifacts']['total_count'],'failed_job_logs':r['failed_job_log_requests'],'timing':r.get('timing')})
value={'schema':'chain-original-3db-complete-ci-terminal-readback-v1','head':x['head'],'all_final':True,'runs':26,'automatic_runs':25,'job_denominator':len(jobs),'run_conclusions':dict(Counter(r['run']['conclusion'] for r in runs)),'job_conclusions':dict(Counter(j['conclusion'] for j in jobs)),'failed_job_logs':len(logs),'all_failed_job_logs_full_bytes_verified':True,'api_failures':0,'snapshot':{'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'collector_cost':{k:x[k] for k in ('ended_utc','total_wall_seconds','aggregate_child_user_cpu_seconds','aggregate_child_system_cpu_seconds')},'provider_duration_ms_sum':sum(r.get('timing',{}).get('run_duration_ms',0) for r in runs),'provider_duration_sum_is_not_cpu_or_money':True,'monetary_cost':None,'full_physical_cost_closed':False,'rows':rows}
d=json.dumps(value,indent=2)+'\n';(out/'SUMMARY.json').write_text(d);print(json.dumps({k:v for k,v in value.items() if k!='rows'},indent=2));print(json.dumps({'path':str(out/'SUMMARY.json'),'bytes':len(d.encode()),'sha256':hashlib.sha256(d.encode()).hexdigest()}))
