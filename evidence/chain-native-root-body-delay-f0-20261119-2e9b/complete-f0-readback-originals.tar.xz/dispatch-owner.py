import pathlib,subprocess,json,time,resource,hashlib
out=pathlib.Path.home()/'work/chain-native-root-delay-f0-20261119-2e9b';assert not out.exists();out.mkdir(parents=True)
repo='TrillionniumFoundation/Trillionnium-Chain';branch='fix/chain-native-root-body-delay-20261119-2e9b';head='333fe8cd89f0ec855e7b856e99e40f48f56c2137'
pre=subprocess.run(['/usr/bin/gh','api','repos/'+repo+'/git/ref/heads/'+branch,'--jq','.object.sha'],capture_output=True,text=True,timeout=60)
(out/'source-ref.stdout').write_text(pre.stdout);(out/'source-ref.stderr').write_text(pre.stderr);assert pre.returncode==0 and pre.stdout.strip()==head
args=['/usr/bin/gh','workflow','run','pon-fixed-host-root-f0.yml','--repo',repo,'--ref',branch]
record={'schema':'chain-original-f0-single-dispatch-v1','repo':repo,'branch':branch,'head':head,'tree':'0cb8caca353b0eac5263cf31fd35c58c031c104f','pr':966,'command':args,'automatic_retry':False,'planned_dispatches':1,'planned_confirmations':6,'planned_business_packet_exposures':42,'f0_qualified':False,'dispatch_started_ns':str(time.time_ns())}
(out/'DISPATCH.json').write_text(json.dumps(record,indent=2)+'\n');t=time.monotonic();ru=resource.getrusage(resource.RUSAGE_CHILDREN)
with (out/'dispatch.stdout').open('xb') as so,(out/'dispatch.stderr').open('xb') as se:
 p=subprocess.Popen(args,stdout=so,stderr=se);record['dispatch_pid']=p.pid;(out/'DISPATCH.json').write_text(json.dumps(record,indent=2)+'\n');rc=p.wait()
ra=resource.getrusage(resource.RUSAGE_CHILDREN);record.update({'dispatch_returncode':rc,'dispatch_ended_ns':str(time.time_ns()),'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':ra.ru_utime-ru.ru_utime,'child_system_cpu_seconds':ra.ru_stime-ru.ru_stime,'files':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in out.iterdir() if p.is_file() and p.name!='DISPATCH.json'}});(out/'DISPATCH.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'receipt':record,'stdout':(out/'dispatch.stdout').read_text(),'stderr':(out/'dispatch.stderr').read_text(),'path':str(out)}),flush=True)
