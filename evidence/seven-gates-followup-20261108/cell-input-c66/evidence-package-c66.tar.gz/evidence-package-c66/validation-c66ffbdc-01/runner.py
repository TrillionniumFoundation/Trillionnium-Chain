#!/usr/bin/env python3
"""Run the original Cell component gates on the newly merged exact source.

Raw subprocess output is retained. This runner makes no WAN, model training,
payment, installation, production, or whole-chain qualification claim.
"""
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import signal
import subprocess
import time
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/3a200666069f/hepta_cell/chain-native')
OUT = Path(__file__).resolve().parent
SOURCE = 'c66ffbdc46312f80f4d0faf829d37e43356a3799'
HEPTA = '36d5eff44f4071bb1f250b1c7706dc690cf0a875'
TOOLCHAIN = Path('/workspace/scratch/5faaca703596/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu')
PROVIDER = Path('/workspace/scratch/2b54b253422c/validation/provider-setup/trnm-pq-provider-3.5.9.05OylHhu/install')
CARGO_HOME = OUT.parent / 'cargo-home'
TARGET = OUT.parent / 'cargo-target'


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    sha = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            sha.update(chunk)
    return sha.hexdigest()


def identity(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path))


def write(name, value, exclusive=False):
    with (OUT / name).open('x' if exclusive else 'w') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def source():
    return dict(head=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'),
                index_tree=git('write-tree'), status=git('status', '--porcelain=v1'),
                cargo_lock=identity(ROOT / 'trillionnium/Cargo.lock'))


ENV = os.environ.copy()
SELECTED_ENV = dict(
    PATH=str(TOOLCHAIN / 'bin') + os.pathsep + ENV['PATH'],
    CARGO_HOME=str(CARGO_HOME), CARGO_TARGET_DIR=str(TARGET),
    CARGO_BUILD_JOBS='2', CARGO_TERM_COLOR='never',
    OPENSSL_DIR=str(PROVIDER), OPENSSL_STATIC='1',
    TRNM_PQ_OPENSSL=str(PROVIDER / 'bin/openssl'),
    TRNM_PQ_OPENSSL_SHA256=digest(PROVIDER / 'bin/openssl'),
    TRNM_PQ_OPENSSL_VERSION='3.5.9', OPENSSL_CONF='/dev/null',
    OPENSSL_MODULES=str(PROVIDER / 'lib/ossl-modules'))
ENV.update(SELECTED_ENV)

commands = [
    ('preflight', ['bash', 'scripts/project-preflight.sh', '--audit'], 120),
    ('source-before', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', SOURCE, '--output', str(OUT / 'source-before.json')], 180),
    ('graph-default', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1', '--manifest-path', 'trillionnium/Cargo.toml'], 180),
    ('graph-all-features', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1', '--manifest-path', 'trillionnium/Cargo.toml', '--all-features'], 180),
    ('graph-fuzz', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1', '--manifest-path', 'tests/fuzz/Cargo.toml'], 180),
    ('format', ['cargo', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check'], 180),
    ('version-vector', ['python3', '-B', 'scripts/cell_complete_version_vector.py', '--check'], 120),
    ('p2p-complete', ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml', '-p', 'trnm-data-availability', '--', '--test-threads=1'], 1800),
    ('clippy-workspace', ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml', '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings'], 1800),
    ('source-negative', ['python3', '-B', 'scripts/ci/test_ci_source_integrity.py'], 300),
    ('pq-source-negative', ['python3', '-B', 'scripts/ci/test_pq_research_integration.py'], 300),
    ('ci-contract', ['python3', '-B', 'scripts/ci/test_ci_contract.py'], 300),
    ('repository', ['python3', '-B', 'scripts/ci/check_repository.py'], 300),
    ('pq-source-pins', ['python3', '-B', 'scripts/ci/check_pq_research_integration.py'], 120),
    ('inventory', ['python3', '-B', 'scripts/refresh_distributed_source_inventory.py', '--check'], 120),
    ('legacy-readback', ['python3', '-B', 'scripts/test_cell_adoption_readback.py', '-v'], 120),
    ('learning-join', ['python3', '-B', 'scripts/test_cell_learning_iteration_join.py', '-v'], 120),
    ('source-after', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', SOURCE, '--output', str(OUT / 'source-after.json')], 180),
    ('diff', ['git', 'diff', '--exit-code'], 120),
]

before = source()
assert before['head'] == SOURCE and not before['status']
environment = dict(
    schema='chain-hepta-cell-integration-environment-v1', captured_at=now(),
    scope='shared Linux component regression; no fixed-resource/WAN/device/full-learning acceptance',
    source=before, paired_hepta_source=HEPTA, paired_hepta_executed_by_this_run=False,
    system=platform.uname()._asdict(), python=platform.python_version(), cpu_count=os.cpu_count(),
    selected_environment={k: v for k, v in SELECTED_ENV.items() if k != 'PATH'},
    toolchain=[identity(TOOLCHAIN / 'bin' / name) for name in ('cargo', 'rustc', 'rustfmt', 'clippy-driver', 'rustdoc')]
              + [identity(p) for p in sorted((TOOLCHAIN / 'lib').glob('librustc_driver-*.so'))],
    rustc_version=subprocess.check_output([str(TOOLCHAIN / 'bin/rustc'), '-vV'], env=ENV, text=True),
    cargo_version=subprocess.check_output([str(TOOLCHAIN / 'bin/cargo'), '-V'], env=ENV, text=True),
    provider=[identity(PROVIDER / name) for name in ('bin/openssl', 'include/openssl/opensslv.h', 'include/openssl/configuration.h', 'lib/libcrypto.a', 'lib/libssl.a')],
    provider_reused_read_only=True, provider_preparation_reexecuted=False,
    provider_version=subprocess.check_output([str(PROVIDER / 'bin/openssl'), 'version', '-a'], env=ENV, text=True),
    original_required_test_manifest=identity(ROOT / 'evidence/cell-six-capabilities-20261108/required-new-tests.json'),
    commands=[dict(label=label, argv=argv, timeout_seconds=limit) for label, argv, limit in commands])
write('environment.json', environment, exclusive=True)
results = []
for label, argv, limit in commands:
    start, started = time.monotonic(), now()
    log = OUT / (label + '.log')
    timed_out = False
    print(json.dumps(dict(event='start', label=label, started_at=started)), flush=True)
    with log.open('xb') as output:
        process = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdout=output,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = process.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait()
    result = dict(label=label, argv=argv, started_at=started,
                  elapsed_seconds=time.monotonic()-start, timeout_seconds=limit,
                  timeout=timed_out, exit_code=code, passed=code == 0 and not timed_out,
                  log=log.name, bytes=log.stat().st_size, sha256=digest(log))
    results.append(result)
    write('progress.json', dict(source=SOURCE, commands=results))
    print(json.dumps(dict(event='complete', **result)), flush=True)

native = (OUT / 'p2p-complete.log').read_text(errors='replace')
required = json.loads((ROOT / 'evidence/cell-six-capabilities-20261108/required-new-tests.json').read_text())
assert isinstance(required, list)
succeeded = set(re.findall(r'^test ([^ ]+) \.\.\. ok$', native, re.M))
test_results = re.findall(r'^test result: .+$', native, re.M)
binaries = []
for value in re.findall(r'^\s*Running .+ \(([^()]+)\)\s*$', native, re.M):
    path = Path(value)
    if not path.is_absolute():
        path = ROOT / path
    if path.is_file():
        binaries.append(identity(path))
after = source()
summary = dict(
    schema='chain-hepta-cell-integration-regression-v1', source=SOURCE, paired_hepta_source=HEPTA,
    source_before=before, source_after=after, source_unchanged=before == after,
    commands=results, required_new_test_count=len(required),
    missing_successful_new_tests=sorted(set(required)-succeeded),
    native_result_lines=test_results, native_successful_named_tests=len(succeeded),
    executed_test_binaries=binaries,
    all_commands_passed=all(r['passed'] for r in results),
    prior_branch_results_reused_as_pass=False,
    paired_hepta_native_reexecuted=False, independent_wan_recovery_qualified=False,
    training_qualified=False, settlement_qualified=False, physical_loading_qualified=False,
    full_learning_iteration_qualified=False, production_activation=False,
    qualification='HOLD_NO_GO')
write('summary.json', summary, exclusive=True)
print(json.dumps({k: v for k, v in summary.items() if k not in ('commands', 'source_before', 'source_after', 'executed_test_binaries')}), flush=True)
raise SystemExit(0 if summary['all_commands_passed'] and summary['source_unchanged'] and not summary['missing_successful_new_tests'] else 1)
