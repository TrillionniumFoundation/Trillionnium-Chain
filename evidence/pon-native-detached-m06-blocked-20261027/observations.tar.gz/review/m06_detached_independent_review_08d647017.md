# Independent source review: M06 candidate 08d647017

**Disposition: BLOCKED isolated draft. This candidate is not approved for inclusion in the main candidate.**

Reviewed commit: `08d647017c38eb0213f8d60db938222df4f59195`. Tree: `b44ea2d1f35c79995ce26a1a27ed9b9cb912bb8d`. Baseline: `bb2d444a3f5fe24b0077c1f01ed1d0953c2b6ff1`.

All 19 changed files were read from the immutable commit and matched the clean worktree. Their SHA256 and Git blob identities are recorded in `m06_detached_review_source_08d647017.json` (SHA256 `46167b36a7180da952aa374e9c7a067175ae40abc180f65fcc20bd41c9eec05a`). This reviewer did not edit implementation files or run builds/tests. Earlier interim reviews and failed attempts are preserved separately. References below are repository-relative paths at the exact commit above.

## Open blockers and exact boundaries

### R5: the original requester can disappear after a durable intent

A nontrivial activation commits a `done=0` reorganization intent before separately completing its steps (`store.rs:4781–4843,4965–5100`). Cancellation can leave that intent incomplete. `ready()` then refuses ordinary operations (`store.rs:2660–2667`). The new exact-frame recovery exception helps a cooperative original requester; it does not drive the intent when that requester never returns. No independent bounded online reconciler using all required original owner/CPU/durable-operation authority was found.

This is an availability blocker, not a demonstrated invalid-root or forged-PoN acceptance. The source includes an explicit ignored test with two real authenticated loopback clients, actual admitted work, a durable-intent cut and no original-frame retry (`ingress/authenticated_recovery_tests.rs:260–288`). It asks that the unrelated honest mutation succeed and preserves that assertion. Its expected refusal must remain a real failing test, not be inverted into an acceptance PASS. Execution was still pending when this review was frozen. The initial cut is a `cfg(test)` typed-cancellation cut; it is not itself evidence that a production timer was exercised.

The call graph does permit more than cold restart: `Node::open` invokes recovery, and configured peer polling can conditionally call `activate_observed` following suitable remote responses. That peer path depends on remote input/configuration and uses the uncontrolled activation wrapper. It does not establish guaranteed, budgeted local recovery. `RecoveryIngress` is only a capacity/deduplication token; legacy `serve_inner` discards it (`ingress.rs:1527`). It confers no CPU credit, request deadline, durable operation or consensus authority.

V3 already has a same-Node scalar account, service epoch and service lifetime. A research correction could have an existing proof worker attempt an owner-selected durable-intent step before dequeue, sharing the same account and original service end. An idle-only hook can starve under saturated queues. The existing resume function loops over all remaining steps and is not that bounded-step API. A new recovery worker, a free read-worker loop, continuation after a cancelled request, or a newly invented standalone account would cross resource boundaries. Legacy authenticated mode may lack the required scalar binding. Continuous mode requires original exact `activate`/`receiver-activate` claims and a durable operation/allowance; `parent-reconcile` intentionally refuses a pending intent. No universal safe reconciler can simply be enabled by calling `cpu.begin()`.

### R4b: the real legacy timeout is not the test's typed cancellation

This is a concrete additional source defect in 08d and was acknowledged by the implementer.

The actual legacy `serve_inner` progress closure returns strings `CANCELLED` and `REQUEST_DEADLINE` (`ingress.rs:1682–1684`). Neither string is in this commit's exact `ErrorCode` table. `Error::from(String)` therefore assigns `ErrorKind::Unclassified` (`error.rs:376–386`). The new nonterminal response/preserve-pending-nonce branch selects only `ErrorKind::Cancelled` (`ingress.rs:1824–1842`). In contrast, the test-only intent cut returns typed `PublicRequestCancelled` (`store.rs:4836–4842`), which does select it.

Consequently the typed-hook socket control can pass while the real legacy timer/stop still misses the intended branch. For an actual expired monotonic deadline or stop, subsequent `lock_owner` immediately checks the still-expired original progress (`ingress.rs:1114–1126,1847`) and propagates the error out of the worker. This review does **not** claim a terminal ACK is persisted: finalization is blocked by that check. It finds a missing real nonterminal-response/healthy-worker path and a test-provenance mismatch. A separate successor with typed local origins preserving the original wire strings, and an actual original-deadline test, was proposed but is not in 08d. It must not be credited to this source or measurement.

## Corrections verified in the 08d source

| Finding | Current source assessment | Execution qualification at freeze |
|---|---|---|
| R1: initial two-second bound omitted nested mutex wait | `ingress.rs:1237–1266` now calls original caller progress, original execution control and the same `wait_end` during acquisition and after the guard. Reacquisition at 1295–1302 retains the original business deadline. | Real held-mutex/control-only deadline test source present; final result pending. |
| R2: 8 MiB acceleration ceiling rejected otherwise valid parents | A private `SnapshotPayload::HeldRequired` returns only the exact original W1-checked packet to the unchanged held checked-M06 schedule; no M06 has run and the prior State/lease are dropped. Callback, canonical encoding and overflow errors remain errors. | Actual custom-genesis >8 MiB parity source present; final result pending. |
| R3: History clock wording | Documentation distinguishes original page observation from newly sampled Submit time. Original deadlines are unchanged. | Source clarification; no invalid acceptance established. |
| R4: authenticated ready gate prevented exact pending recovery | A narrow private exception verifies original pending frame, original replay owner, exact payload/packet, exact already-admitted reorg target, owner/time context and stable epoch, without nonce/journal writes. | Typed-hook signed-socket controls present; actual legacy timeout remains R4b; independent liveness remains R5. |

For R2, see `store/detached_admission.rs:69–82,111–130,200–224` and `ingress.rs:1274–1289`. This is an explicit scheduling branch using the same consensus checks, CPU operation and deadline. It does not switch work primitives. The actual test (`store/detached_admission/tests.rs:467–578`) names a custom genesis with 2,100 padding cells, validates a signed seed block, then tests actual W1 and four signed transfers against held/shared/reopen paths on legacy and authenticated backends. The test's diagnostic original-domain scope is not A03 paidHost or default-genesis historical growth. Parent materialization occurs before counting and the held branch repeats validation; no resource-edge performance guarantee follows.

For R4, `begin_authenticated_dispatch` (`ingress.rs:551–573`) first uses the original begin. Only its typed `ReorgInProgress` and an already-authenticated Submit can invoke `store/authenticated_pending_activation.rs:9–63`. The original ordinary `ready()` remains. The private method requires `state.pending() == Some(frame)`, original `recover_verified`, `ExactFrameSource`, exact canonical Submit bytes, and `pending_exact_activation_replay`; it writes nothing. Original ingress already accepts lowercase hex only, so canonical lowercase reconstruction does not narrow a previously valid encoding set. The controls include same header ID with altered payload, another target, another nonce, Head and wrong context, plus byte-identical cached response and one W1. These boundaries appeared sound in source review; none closes R5.

## Snapshot, publication, accounting and reuse review

The private preparation/result exposes no Clone, Deserialize, public-output field or arbitrary-result constructor. A unique capacity lease retains the original Node Arc identity; deliberate leakage can only hold the slot busy. Commit checks directory/DB/owner inode identity, backend and immutable network/parameters/genesis. The original connection's `data_version` refuses cooperating SQLite foreign writes including write-and-restore. A same-owner `total_changes` increase triggers complete parent/task/material rereading, allowing valid competing forks without treating an obsolete active tip as commit authority.

`CommitFence::validate` (`store/detached_admission.rs:44–66`) runs inside the original `BEGIN IMMEDIATE` before any insertion. The extracted persistence body (`store.rs::persist_admission_execution`, starting at 3939) retains complete delta/packet readback, parent/successor State reconstruction, ancestry, active-tip validation and precommit cancellation. No additional forged-artifact, reuse, foreign-writer publication gap or invalid-work acceptance defect was established. This statement is a source-review result, not a concurrency proof.

The dispatcher creates no CPU account, credit or reservation. The same control/scoped-worker accounting continues across the released Node mutex and the final original SQL transaction. History retains its original operation and durable epoch marker; continuous History's existing denial is unchanged. Restricted/mining/continuous/growth/ROOT-cache contexts retain their original held entrypoints and cannot manufacture an ordinary detached artifact.

The older post-admission cancellation test legitimately changes from forced success to preserving the committed packet and stopping subsequent activation, provided pending-intent liveness is later resolved. The two foreign-CPU-domain assertion changes match the baseline's existing owner-stop classification, while still preserving the healthy original domain/server and zero foreign reservation/W1. They do not justify changing production classification.

## Evidence observed and not observed

Implementer raw receipts were read independently. Latest strict native all-target Clippy (`clippy-attempt2`, 57.988 seconds), workspace fmt (`fmt-attempt3`) and 34 source-negative controls passed. The committed-source repository checker still exited 2 with the original work-cost/DAA reader-lane contract failure. Its failure remains a failure. These raw command receipts alone do not provide a before/after source fence; the separate 19-file clean source snapshot establishes the bytes reviewed here.

The final native build was still incomplete at freeze. No final initial-wait, >8 MiB, exact-socket or withheld-frame execution is credited here. Earlier detached tests passed 11 after a retained observer-contention failure; earlier History tests passed 8 including real kill cuts. The earlier full native regression was stopped by SIGTERM, exit -15, `timed_out=false`, after 341.768 seconds and contained old assertion failures. It is not a full PASS.

The earlier precommit cost fixture had 1,024 signed seed transfers, 1,035 keys and 98,565 canonical bytes, with approximately 23.124 ms preparation, 7.067 ms M06 and 107.961 ms SQL commit. It is not a final-08d measurement, >8 MiB case, or throughput/saturation claim. The SQL writer still dominated that observation.

One detached slot is no RSS bound: full State materialization, executor copies and SQL readback remain. Existing SQLite busy timeout, root work and fsync can run between cooperative checks. No hard realtime, fairness, WAN, paidHost or continuous durable-History qualification follows. Keep 08d on a separate blocked branch; any successor, actual timer result and actual withheld-frame failure need their own immutable source/receipt record.
