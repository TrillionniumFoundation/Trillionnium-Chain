import time
from pathlib import Path
Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/collector-controls-desktop-ec265-01/test_actual_generation_dispatch_worker_exec_chain_is_wrapped_without_status_theft/actual-target-invocation').write_text('one real target child')
time.sleep(.2)
