#!/usr/bin/env python3
"""Read original retained bytes with two readers; never execute a native binary."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import tempfile
import time
import zipfile


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1] / 'chain-system-safety'
ARCHIVE = Path('/dev/shm/trnm-system-safety-20261030/raw-history-b23-fence.zip')
EXPECTED_ARCHIVE_SHA256 = '754e3cd072d14f608051898a6e00a13469c51f73e75e4ae6fa38ef8a761e54f0'
EXPECTED_SOURCE = 'b23c0ef85f058507185b2ccb404a5d648e447c06'
EXPECTED_TREE = 'cbb7f34ef9a84df3653f4d3adbe57725b7740a37'
sys.dont_write_bytecode = True
sys.path[:0] = [str(REPO / 'scripts/ci'), str(REPO / 'scripts')]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        for part in iter(lambda: source.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    source_manifest = json.loads((ROOT / 'original-source-manifest.json').read_bytes())
    for entry in source_manifest['original_files']:
        assert sha(REPO / entry['path']) == entry['sha256'], entry['path']
    original = load('original_raw_history_reader', REPO / 'scripts/ci/read_pure_history_raw_campaign_v1.py')
    candidate = load('candidate_raw_history_reader', ROOT / 'scripts/ci/read_pure_history_raw_campaign_v1.py')
    record = {
        'scope': 'independent readback of original b23 retained bytes; not native execution, a new source run, or qualification',
        'source': EXPECTED_SOURCE, 'tree': EXPECTED_TREE,
        'archive': str(ARCHIVE), 'archive_sha256': sha(ARCHIVE),
        'original_reader_sha256': sha(REPO / 'scripts/ci/read_pure_history_raw_campaign_v1.py'),
        'candidate_reader_sha256': sha(ROOT / 'scripts/ci/read_pure_history_raw_campaign_v1.py'),
        'history_reader_sha256': sha(REPO / 'scripts/ci/read_native_history_verifier.py'),
        'native_executed': False, 'original_artifact_modified': False,
        'production_qualified': False, 'runs': [],
    }
    assert record['archive_sha256'] == EXPECTED_ARCHIVE_SHA256
    members = []
    started = time.monotonic()
    with zipfile.ZipFile(ARCHIVE) as archive, tempfile.TemporaryDirectory(
            prefix='original-readback-', dir=ROOT) as temporary:
        temporary = Path(temporary)
        results = json.loads(archive.read('results.json'))
        before = json.loads(archive.read('source-before.json'))
        after = json.loads(archive.read('source-after.json'))
        assert before == after
        assert before['tested_commit'] == EXPECTED_SOURCE and before['tested_tree'] == EXPECTED_TREE
        assert before['tracked_worktree_verified'] is True
        record['original_workflow_complete_success'] = results['complete_success']
        record['history_resource_profile'] = results['history_resource_profile']
        assert results['history_resource_profile'] == candidate.history_reader.GRAPH_PROFILE
        binary = results['binary']
        binary_hash = hashlib.sha256(archive.read(binary['retained'])).hexdigest()
        assert binary_hash == binary['sha256_before'] == binary['sha256_after']
        record['original_binary_sha256'] = binary_hash
        selected = [info for info in archive.infolist()
                    if any(info.filename.startswith(f'run-{number}-raw/') for number in (1, 2, 3))
                    and ((info.filename.endswith('/report.json') and info.filename.count('/') == 1)
                         or '/independent-client/' in info.filename)
                    and not info.is_dir()]
        assert sum(info.file_size for info in selected) < 200 * 1024 * 1024
        assert len({info.filename for info in selected}) == len(selected)
        for info in selected:
            path = PurePosixPath(info.filename)
            assert not path.is_absolute() and '..' not in path.parts
            assert stat.S_IFMT(info.external_attr >> 16) in (0, stat.S_IFREG)
            data = archive.read(info)
            assert len(data) == info.file_size
            target = temporary / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            members.append({'path': info.filename, 'bytes': len(data),
                            'sha256': hashlib.sha256(data).hexdigest()})
        for number in (1, 2, 3):
            name = f'run-{number}-raw/report.json'
            path = temporary / name
            report_sha256 = sha(path)
            resource = json.loads(archive.read(f'run-{number}-resource-before.json'))
            original_result = json.loads(archive.read(f'run-{number}-result.json'))
            row = {'number': number, 'report_sha256': report_sha256,
                   'original_native_returncode': original_result['step']['returncode'],
                   'original_recorded_result': original_result,
                   'outer_cgroup': resource['cgroup'], 'readers': {}}
            for label, reader in [('original', original), ('candidate', candidate)]:
                try:
                    value = reader.read_report(path, report_sha256, reader.POLICY_ID, binary_hash,
                                               resource['cgroup'], results['history_resource_profile'])
                    row['readers'][label] = {'readback_completed': True, 'result': value}
                except (ValueError, KeyError, TypeError, AssertionError) as error:
                    row['readers'][label] = {'readback_completed': False,
                                            'error_type': type(error).__name__, 'error': str(error)}
                assert sha(path) == report_sha256
            record['runs'].append(row)
            print(json.dumps({'run': number, 'readers': {
                label: {'readback_completed': value['readback_completed'],
                        'original_criteria_met': value.get('result', {}).get('original_criteria_met'),
                        'error': value.get('error')}
                for label, value in row['readers'].items()}}, sort_keys=True), flush=True)
    for entry in source_manifest['original_files']:
        assert sha(REPO / entry['path']) == entry['sha256'], entry['path']
    record['original_source_unchanged'] = True
    record['elapsed_seconds'] = time.monotonic() - started
    manifest_data = json.dumps(members, sort_keys=True, indent=2).encode() + b'\n'
    (ROOT / 'original-readback-members.json').write_bytes(manifest_data)
    record['readback_members_sha256'] = hashlib.sha256(manifest_data).hexdigest()
    (ROOT / 'candidate-original-artifact-readback.json').write_text(
        json.dumps(record, sort_keys=True, indent=2) + '\n')


if __name__ == '__main__':
    main()
