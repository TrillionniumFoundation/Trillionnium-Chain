# Terminal History diagnostic integrity: unpublished patch

Base: Draft PR #880, bcc0d2369e81d85c001190ea4c8ee0b1778e178d.

Only two offline Python files change. No runtime, Host decision, original resource budget, signed domain or output schema changes. A malformed or contradictory terminal-stage record remains unknown instead of producing a definite boundary or no-failure diagnostic. A successful last import never qualifies the campaign.

Isolated validation on the exact two upstream Git blobs: original 12 controls pass; three added negative-control methods fail before the fix (seven failing subcases), then all 15 controls pass after it. A positive coherent-success control is also retained. The patch applies cleanly to both original files.

The fixed CLI reread all three raw reports from original artifact 13761459229, run 42781760995 at aaa3c53965bf0cf472e52451e205e9a020e834ab. ZIP SHA256 715587a56f595588c4eca4b36ba6e0a326b78e69078a4240cc878959e1f02cfe. Complete campaigns remain 0/3. The three baseline last imports are successful; six hostile last imports retain submit_result deadline observations. These are offline readbacks, not new native executions or useful-task/TPS measurements.

Mac publication is NOT complete: HeptaRuntime returned tunnel_client_not_connected. The original 1505 preflight request used idempotency key throughput-20261110-1505-preflight-v1; its launch acknowledgement was uncertain, and a same-key reconciliation returned the disconnected-tunnel error. Do not invent a completed preflight, new Mac test pass, commit, PR or push. Do not bypass the required ProfHepta/Mac channel. No Cargo, Clippy, full-source closure, native service or new CI success is claimed.

After the Mac channel recovers, first re-read #880 and successors; reconcile the original preflight key, run project-preflight, apply in an isolated child branch, run the relevant controls and source checks, push normally and independently read back. Preserve Draft/HOLD and all historical failures.

Reproduce controls: cd source && python3 -m unittest -v test_inspect_native_campaign_failure

The original campaign ZIP/reports remain at their GitHub artifact; this package contains only source, patch and compact diagnostic/test evidence.
