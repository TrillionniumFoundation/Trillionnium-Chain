#!/usr/bin/env python3
"""Retain this attempt's raw evidence without source/target/cache directories."""
import hashlib
import json
from pathlib import Path
import tarfile
import time


def sha(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main():
    base = Path(__file__).resolve().parent
    final = json.loads((base / "native-02/result.json").read_text())
    rows = []
    selected = [path for path in base.iterdir() if path.is_file() and path.suffix in (".py", ".json")]
    for directory in ("setup", "build-01", "native-01", "native-02", "nextest-version-source"):
        selected.extend(path for path in (base / directory).rglob("*") if path.is_file())
    for path in sorted(set(selected)):
        if path.is_symlink():
            raise RuntimeError("evidence must be regular retained files")
        before = path.stat()
        value = sha(path)
        after = path.stat()
        if (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            raise RuntimeError("evidence changed during collection")
        rows.append({"path": str(path.relative_to(base)), "bytes": after.st_size, "sha256": value})
    manifest = {"schema": "hepta-36d5-raw-evidence-index-v1", "collected_ns": time.time_ns(),
                "chain_sha_input": final["paired_chain_sha"], "hepta_sha_verified": final["expected_hepta_sha"],
                "native_result_status": final["status"], "native_result_exit": final["exit_code"],
                "historical_results_reused": False, "engineering_controls_only": True,
                "complete_build_load_closure_verified": False,
                "independent_crypto_review": False, "files": rows}
    manifest_path = base / "raw-evidence-index.json"
    with manifest_path.open("x") as stream:
        json.dump(manifest, stream, indent=2, sort_keys=True)
        stream.write("\n")
    destination = base / "hepta-36d5-bb026-native-controls.tar.xz"
    with tarfile.open(destination, "x:xz", preset=6) as archive:
        archive.add(manifest_path, arcname=manifest_path.name, recursive=False)
        for row in rows:
            path = base / row["path"]
            if sha(path) != row["sha256"]:
                raise RuntimeError("evidence changed before archive")
            archive.add(path, arcname=row["path"], recursive=False)
            if sha(path) != row["sha256"]:
                raise RuntimeError("evidence changed during archive")
    result = {"path": str(destination), "bytes": destination.stat().st_size,
              "sha256": sha(destination), "file_count": len(rows) + 1,
              "manifest_sha256": sha(manifest_path), "native_result_status": final["status"]}
    with (base / "archive.json").open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
