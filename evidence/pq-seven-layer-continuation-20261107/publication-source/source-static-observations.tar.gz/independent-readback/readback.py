#!/usr/bin/env python3
"""Read existing exact-source records and immutable Git objects; run no tests."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tomllib

HEAD = "276a1e26f1989aef4b3d75263ff5b55e073b46e9"
TREE = "d2a3d83d2800c8e0829e3a951cb2f0f6aa233e56"
NATIVE = "e36cfb88956a0e35e53d74c5ab71c94c628439d9"
RIGHT = "adebe0bd78e6e1bdb55a599179ffe2313997170e"
DIAGNOSTIC = "3d1b6507671ec694ce58e86d4063a125c8deeb66"
HISTORY = "evidence/pon-w1-work-security-20261101/matching-direct-deps"
CHILD = HISTORY + "/harness/crypto/Cargo.lock"
SUITES = ["test_ci_source_integrity", "test_record_pq_native_command",
          "test_pq_research_integration", "test_pq_chain_claim_guard",
          "test_pq_authority_surface_scan", "test_ci_contract", "test_codeql_retention"]
COMMON = ["--offline", "--locked", "--manifest-path", "trillionnium/Cargo.toml"]
SOURCE = {label: ["python3", "-m", "unittest", "discover", "-s", "scripts/ci", "-p", label + ".py", "-v"] for label in SUITES}
SOURCE.update({
    "pq-source": ["python3", "scripts/ci/check_pq_research_integration.py"],
    "pq-hold": ["python3", "scripts/ci/pq_chain_claim_guard.py"],
    "repository": ["python3", "scripts/ci/check_repository.py"],
    "inventory": ["python3", "scripts/refresh_distributed_source_inventory.py", "--check"],
    "locked-graph": ["cargo", "metadata", *COMMON, "--format-version=1"],
    "format": ["cargo", "fmt", "--manifest-path", "trillionnium/Cargo.toml", "--all", "--check"],
})
SUPPLEMENT = {
    "standalone-locked-graph": ["cargo", "metadata", "--locked", "--offline", "--format-version", "1",
                              "--manifest-path", HISTORY + "/harness/crypto/Cargo.toml"],
    "workspace-all-features-graph": ["cargo", "metadata", "--locked", "--offline", "--format-version", "1",
                                   "--manifest-path", "trillionnium/Cargo.toml", "--all-features"],
    "strict-clippy": ["cargo", "clippy", "--locked", "--offline", "--manifest-path", "trillionnium/Cargo.toml",
                     "--workspace", "--all-targets", "--all-features", "--", "-D", "warnings"],
}

def need(ok, reason):
    if not ok:
        raise ValueError(reason)

def unique(pairs):
    value = {}
    for key, item in pairs:
        need(key not in value, "duplicate JSON key: " + key)
        value[key] = item
    return value

def decode(data):
    return json.loads(data, object_pairs_hook=unique)

def raw(path):
    need(path.is_file() and not path.is_symlink(), "missing/nonregular record: " + str(path))
    return path.read_bytes()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def evidence(path):
    data = raw(path)
    return {"path": str(path), "bytes": len(data), "sha256": sha(data)}

def load(path):
    return decode(raw(path))

def key(package):
    return package["name"], package["version"], package.get("source")

def identity(package):
    return {name: package.get(name) for name in ("name", "version", "source", "checksum")}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--validation", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root, validation = args.root.resolve(strict=True), args.validation.resolve(strict=True)
    output = args.output.absolute()
    need(not output.exists() and not output.resolve().is_relative_to(root), "new scratch output required")
    report = {"schema": "task-final-source-independent-readback-v1",
              "observed_utc": datetime.now(timezone.utc).isoformat(), "tested_commit": HEAD, "tested_tree": TREE,
              "reader": evidence(Path(__file__).resolve()), "native_tests_executed_by_reader": False,
              "source_or_record_inputs_modified": False, "native_tests_executed_at_final_source": False,
              "native_observations_inherited_by_final_source": False, "claim_guard": "HOLD",
              "whole_chain_pq_qualified": False, "pq_128_qualified": False, "public_wan_qualified": False,
              "production_activation": False, "new_codeql_execution_claimed": False}
    def git(*argv):
        return subprocess.check_output(["git", "--no-replace-objects", *argv], cwd=root)
    def blob(path, commit=HEAD):
        return git("show", commit + ":" + path)
    def object_id(path, commit=HEAD):
        return git("rev-parse", commit + ":" + path).decode().strip()
    def object_info(path, commit=HEAD):
        data = blob(path, commit)
        return {"commit": commit, "path": path, "git_blob": object_id(path, commit),
                "bytes": len(data), "sha256": sha(data)}
    def read_receipt(directory, label, command, row, allow_failed=False):
        path = directory / (label + ".json")
        receipt = load(path)
        need(receipt.get("schema") == "trnm-pq-native-command-v1", label + ": receipt schema")
        need(receipt.get("status") in ("command_succeeded", "command_failed")
             and type(receipt.get("exit_code")) is int
             and (receipt["exit_code"] == 0) == (receipt["status"] == "command_succeeded"),
             label + ": incomplete or contradictory command")
        if not allow_failed:
            need(receipt["exit_code"] == 0, label + ": required command failed")
        need(receipt.get("argv") == ["timeout", "1500", *command], label + ": command mismatch")
        need(receipt.get("whole_chain_quantum_security_qualified") is False, label + ": PQ promotion")
        before, after = receipt["before"], receipt["after"]
        need(before == after and before["kind"] == "head" and before["candidate"] == HEAD
             and before["tested_commit"] == HEAD and before["tested_tree"] == TREE
             and before["tracked_worktree_verified"] is True
             and before["tests_executed_by_identity_check"] is False, label + ": exact-source receipt")
        need(receipt["cwd"] == str(root) and receipt["log_file"] == label + ".log", label + ": execution path")
        log = raw(directory / receipt["log_file"])
        need(receipt["log_sha256"] == sha(log) and receipt["log_bytes"] == len(log), label + ": log identity")
        need(row["command"] == command and row["command_exit"] == receipt["exit_code"]
             and row["recorder_exit"] == receipt["exit_code"]
             and row["status"] == receipt["status"] and row["receipt_sha256"] == sha(raw(path)), label + ": controller mismatch")
        controller = raw(directory / (label + ".recorder.log"))
        controller_rows = [decode(line) for line in controller.splitlines() if line.startswith(b"{")]
        need(len(controller_rows) == 1 and controller_rows[0]["status"] == receipt["status"]
             and controller_rows[0]["exit_code"] == receipt["exit_code"]
             and controller_rows[0]["receipt"] == str(path),
             label + ": recorder terminal output")
        detail = {"label": label, "argv": receipt["argv"], "exit_code": receipt["exit_code"],
                  "status": "PASS" if receipt["exit_code"] == 0 else "FAIL",
                  "receipt_consistency": "PASS", "elapsed_ns": receipt["elapsed_ns"],
                  "before": before, "after": after, "source_before_equals_after": True,
                  "receipt": evidence(path), "log": evidence(directory / receipt["log_file"]),
                  "recorder_log": evidence(directory / (label + ".recorder.log"))}
        return log, detail
    def graph_check(raw_json, lock_packages, expected_root, expected_members):
        graph = decode(raw_json)
        packages, nodes = graph["packages"], graph["resolve"]["nodes"]
        ids = {p["id"] for p in packages}
        need(len(ids) == len(packages) == len(nodes) and ids == {n["id"] for n in nodes}, "metadata node coverage")
        need(all(d["pkg"] in ids for n in nodes for d in n["deps"]), "metadata unresolved dependency")
        locked = {key(p): p for p in lock_packages}
        need(all(key(p) in locked for p in packages), "metadata package/version/source absent from lock")
        need(len(graph["workspace_members"]) == expected_members and set(graph["workspace_members"]) <= ids,
             "metadata workspace members")
        need(graph["workspace_root"] == str(expected_root), "metadata workspace root")
        inventory = [identity(locked[key(p)]) for p in sorted(packages, key=key)]
        return graph, {"packages": len(packages), "resolve_nodes": len(nodes), "workspace_members": expected_members,
                       "all_identities_match_committed_lock": True, "selected_package_identities": inventory}

    try:
        need(git("rev-parse", HEAD + "^{tree}").decode().strip() == TREE, "frozen commit tree mismatch")
        parents = git("show", "-s", "--format=%P", HEAD).decode().split()
        need(len(parents) == 2 and parents[0].startswith("d1e6e2795") and parents[1] == RIGHT, "composition parents")
        subtrees = {path: {"e36": object_id(path, NATIVE), "final": object_id(path)} for path in ("trillionnium", "formal")}
        need(all(row["e36"] == row["final"] for row in subtrees.values()), "runtime/formal source differs")
        report["composition"] = {"parents": parents, "runtime_formal_subtrees": subtrees,
            "runtime_formal_tree_objects_equal": True, "does_not_transfer_native_execution": True}

        original_raw = blob(HISTORY + "/manifest.json")
        original = decode(original_raw)
        old_files = original["harness_before"]
        need(len(old_files) == 5 and old_files == original["harness_after"]
             and "crypto/Cargo.lock" not in old_files, "historical five-input manifest changed")
        proof = {}
        for relative, digest in old_files.items():
            path = HISTORY + "/harness/" + relative
            rows = [object_info(path, commit) for commit in (NATIVE, DIAGNOSTIC, RIGHT, HEAD)]
            need(all(row["sha256"] == digest for row in rows), "historical harness input changed: " + path)
            proof[relative] = rows
        history_records = {}
        for path, expected in ((HISTORY + "/manifest.json", sha(original_raw)),
                               (HISTORY + "/campaign.jsonl.xz", original["compressed_sha256"])):
            rows = [object_info(path, commit) for commit in (NATIVE, DIAGNOSTIC, RIGHT, HEAD)]
            need(all(row["sha256"] == expected for row in rows), "historical evidence changed: " + path)
            history_records[path] = rows
        parent_raw = blob(HISTORY + "/harness/Cargo.lock")
        child_raw = blob(CHILD)
        parent, child = tomllib.loads(parent_raw.decode()), tomllib.loads(child_raw.decode())
        parent_packages = {key(p): p for p in parent["package"]}
        need(len(parent_packages) == len(parent["package"]), "duplicate retained parent package")
        need(len({key(p) for p in child["package"]}) == len(child["package"]), "duplicate standalone package")
        need(all(parent_packages.get(key(p)) == p for p in child["package"]), "standalone package record differs from parent")
        child_names = {p["name"] for p in child["package"]}
        need(all(d in child_names for p in child["package"] for d in p.get("dependencies", [])), "standalone graph not closed")
        vpath = "evidence/codeql-standalone-lock-20261107/validation.json"
        retained = decode(blob(vpath))
        need(retained["original_five_harness_hashes"] == old_files, "lock validation five-input declaration")
        need(retained["standalone_lock_sha256"] == sha(child_raw) and retained["standalone_lock_bytes"] == len(child_raw),
             "new lock bytes/hash mismatch")
        identities = sorted([identity(p) for p in child["package"]], key=lambda p: (p["name"], p["version"]))
        need(retained["package_identities"] == identities and retained["standalone_packages"] == len(identities),
             "new lock identity inventory mismatch")
        need(retained["original_manifest_sha256"] == sha(original_raw)
             and retained["original_campaign_archive_sha256"] == original["compressed_sha256"], "retained history hashes")
        need(all(original[k] is False and retained[k] is False
                 for k in ("original_lockfile_matched", "original_workspace_graph_verified")), "historical qualification upgraded")
        need(blob(CHILD, RIGHT) == child_raw and git("ls-tree", DIAGNOSTIC, "--", CHILD) == b"", "new lock introduction scope")
        report["standalone_lock"] = {"status": "PASS", "new_lock": object_info(CHILD),
            "parent_lock": object_info(HISTORY + "/harness/Cargo.lock"), "parent_packages": len(parent["package"]),
            "packages": len(identities), "registry_packages": sum(p["source"] is not None for p in identities),
            "all_package_records_equal_retained_parent": True, "dependency_closure_preserved": True,
            "package_identities": identities, "original_five_inputs": proof, "historical_evidence": history_records,
            "retained_validation": object_info(vpath), "original_lockfile_matched": False,
            "original_workspace_graph_verified": False, "new_lock_is_original_campaign_input": False,
            "historical_native_campaign_rerun": False, "historical_generated_ci_lock_body_recovered": False}

        source_dir, supplement_dir = validation / "source", validation / "supplement"
        runner = load(source_dir / "runner.json")
        result = load(source_dir / "result.json")
        need(runner["runner_sha256"] == evidence(validation.parent / "run_frozen_validation.py")["sha256"],
             "source runner identity")
        need(runner["head"] == result["head"] == HEAD and runner["tree"] == result["tree"] == TREE, "source phase identity")
        need(runner["planned_commands"] == result["planned_commands"] == list(SOURCE)
             and result["not_executed"] == [] and result["all_commands_succeeded"] is True, "source coverage/completion")
        need(result["commands"] == load(source_dir / "progress.json"), "source progress/final mismatch")
        need([r["label"] for r in result["commands"]] == list(SOURCE), "source command order")
        need(all(result[k] is False for k in ("whole_chain_pq_qualified", "public_wan_qualified", "production_activation")),
             "source qualification upgraded")
        source_logs, command_details, all_names, suite_counts = {}, [], set(), {}
        for row in result["commands"]:
            label = row["label"]
            log, detail = read_receipt(source_dir, label, SOURCE[label], row)
            need(row["execution_readback_ok"] is True and row["cap_seconds"] == 1500, label + ": source execution gate")
            source_logs[label] = log
            if label in SUITES:
                text = log.decode()
                matches = list(re.finditer(r"^Ran ([0-9]+) tests? in ([0-9.]+)s\n\nOK(?:\n|$)", text, re.M))
                names = re.findall(r"^test\S* \(([^)\n]+)\) \.\.\. ok$", text, re.M)
                need(len(matches) == 1, label + ": ambiguous/missing successful parent unittest summary")
                count = int(matches[0].group(1))
                need(count > 0 and len(names) == len(set(names)) == count == row["unittest_parent_count"],
                     label + ": unittest name/count mismatch")
                need(all(name.startswith(label + ".") for name in names) and not (all_names & set(names)),
                     label + ": wrong or duplicate suite identities")
                all_names.update(names)
                suite_counts[label] = count
                detail["unittest"] = {"parent_count": count, "seconds": float(matches[0].group(2)), "passed_names": names,
                    "trailing_fixture_output_bytes": len(text[matches[0].end():].encode()),
                    "negative_fixture_outputs_do_not_count_as_product_failures_or_passes": True}
            command_details.append(detail)
        corpus, guard, repository = [decode(source_logs[k]) for k in ("pq-source", "pq-hold", "repository")]
        need(corpus["status"] == "HOLD_NO_GO" and corpus["cryptographic_acceptance"] is False
             and corpus["node_activated"] is False, "source corpus promoted")
        need(guard["status"] == "HOLD" and all(guard[k] is False for k in
             ("whole_chain_pq_qualified", "pq_128_qualified", "production_activation")), "claim guard promoted")
        need(all(v["status"] == "UNQUALIFIED" for v in guard["gates"].values()), "guard gates promoted")
        need(repository["head"] == HEAD and repository["tree"] == TREE and repository["result"] == "PASS"
             and repository["source_state"] == "committed-clean" and repository["activation"] is False, "repository observation")
        need(source_logs["inventory"].strip() == b"distributed source inventory: PASS", "inventory result")
        report["source_phase"] = {"status": "PASS", "commands_verified": len(command_details),
            "unittest_suites": suite_counts, "distinct_passed_unittest_names": len(all_names), "commands": command_details,
            "runner": evidence(source_dir / "runner.json"), "terminal_result": evidence(source_dir / "result.json"),
            "corpus_observation": corpus, "claim_guard_observation": guard, "repository_observation": repository,
            "native_tests_executed": False, "codeql_test_cases_are_local_controls": True}

        final = load(supplement_dir / "result.json")
        need(final["schema"] == "trnm-final-source-static-supplement-v1" and final["head"] == HEAD
             and final["tree"] == TREE
             and final["native_tests_executed"] is False, "supplement identity/disposition")
        need([r["label"] for r in final["commands"]] == list(SUPPLEMENT), "supplement command coverage")
        supplemental_logs, supplemental_details = {}, []
        for row in final["commands"]:
            need(row["native_tests_executed"] is False, "supplement native execution claim")
            log, detail = read_receipt(supplement_dir, row["label"], SUPPLEMENT[row["label"]], row,
                                       allow_failed=row["label"] == "strict-clippy")
            supplemental_logs[row["label"]] = log
            supplemental_details.append(detail)
        workspace_lock = tomllib.loads(blob("trillionnium/Cargo.lock").decode())["package"]
        default_graph, default_summary = graph_check(source_logs["locked-graph"], workspace_lock, root / "trillionnium", 26)
        full_graph, full_summary = graph_check(supplemental_logs["workspace-all-features-graph"], workspace_lock, root / "trillionnium", 26)
        solo_graph, solo_summary = graph_check(supplemental_logs["standalone-locked-graph"], child["package"],
                                              root / HISTORY / "harness/crypto", 1)
        need({key(p) for p in solo_graph["packages"]} == {key(p) for p in child["package"]}, "standalone metadata/lock set differs")
        need({key(p) for p in full_graph["packages"]} == {key(p) for p in workspace_lock}, "all-features metadata/lock set differs")
        default_keys, full_keys = [{key(p) for p in graph["packages"]} for graph in (default_graph, full_graph)]
        need(default_keys <= full_keys, "default graph not a subset of all-features graph")
        graph_difference = sorted(full_keys - default_keys)
        clippy = supplemental_logs["strict-clippy"].decode()
        finished = re.findall(r"^\s+Finished \x60dev\x60 profile \[unoptimized \+ debuginfo\] target\(s\) in (.+)$", clippy, re.M)
        clippy_record = supplemental_details[-1]
        failed_labels = [row["label"] for row in supplemental_details if row["status"] == "FAIL"]
        need(final["all_commands_succeeded"] is (not failed_labels), "supplement completion contradicts receipts")
        errors = [line for line in clippy.splitlines() if re.match(r"error(?:\[|:)", line)]
        if clippy_record["exit_code"] == 0:
            need(len(finished) == 1 and not errors, "strict Clippy successful terminal log")
        else:
            need(not finished and clippy_record["exit_code"] == 101
                 and "error: could not compile \x60trnm-pon-node\x60 (lib test)" in errors
                 and "(signal: 9, SIGKILL: kill)" in clippy, "strict Clippy failure signature")
        report["static_supplement"] = {"status": "FAIL" if failed_labels else "PASS",
            "receipt_consistency": "PASS", "commands_verified": len(supplemental_details),
            "passed_commands": len(supplemental_details) - len(failed_labels), "failed_commands": failed_labels,
            "commands": supplemental_details, "terminal_result": evidence(supplement_dir / "result.json"),
            "standalone_metadata": solo_summary, "workspace_default_metadata": default_summary,
            "workspace_all_features_metadata": full_summary,
            "all_features_only": [{"name": n, "version": v, "source": s} for n, v, s in graph_difference],
            "strict_clippy_finished": finished, "strict_clippy_error_lines": errors,
            "strict_clippy_failed_process_signal": 9 if "(signal: 9, SIGKILL: kill)" in clippy else None,
            "strict_clippy_failed_target": "trnm-pon-node (lib test)" if failed_labels else None,
            "strict_clippy_termination_cause": "UNATTRIBUTED" if failed_labels else None,
            "strict_clippy_timeout_observed": clippy_record["exit_code"] == 124,
            "strict_clippy_qualified": clippy_record["exit_code"] == 0,
            "strict_clippy_warning_lines": [
                line for line in clippy.splitlines() if line.startswith("warning:")],
            "native_tests_executed": False, "whole_storage_or_release_qualified": False}
        retirement_path = validation.parent / "completed-build-cache-retirement-276a1e26.json"
        retirement = load(retirement_path)
        need(retirement["retired"] is True and retirement["executables_logs_receipts_and_source_untouched"] is True,
             "retirement scope")
        need(len(retirement["items"]) == 2 and all(Path(i["path"]).suffix == ".rlib" for i in retirement["items"]),
             "unexpected retired object kind")
        report["build_cache_retirement"] = {"record": evidence(retirement_path), "declared_record": retirement,
            "retired_body_hashes_not_recomputed_by_this_reader": True, "native_execution_evidence_replaced": False}
        report["earlier_native_observation"] = {"commit": NATIVE, "status": "FAIL",
            "remains_attached_only_to_original_execution": True, "runtime_tree_identity_does_not_change_that_status": True}
        old_dir = validation.parent / "validation-e36cfb88/native"
        old_clippy, old_log = load(old_dir / "strict-clippy.json"), raw(old_dir / "strict-clippy.log")
        need(old_clippy["before"] == old_clippy["after"] and old_clippy["before"]["tested_commit"] == NATIVE
             and old_clippy["exit_code"] == 0 and old_clippy["status"] == "command_succeeded"
             and old_clippy["log_sha256"] == sha(old_log) and old_clippy["log_bytes"] == len(old_log),
             "earlier e36 Clippy record")
        report["earlier_e36_clippy"] = {"commit": NATIVE, "status": "PASS", "exit_code": 0,
            "receipt": evidence(old_dir / "strict-clippy.json"), "log": evidence(old_dir / "strict-clippy.log"),
            "does_not_override_final_source_failure": True}
        report["status"] = "RECEIPT_CONSISTENCY_PASS"
        report["source_disposition"] = "PASS"
        report["static_supplement_disposition"] = report["static_supplement"]["status"]
    except Exception as error:
        report["status"] = "FAIL"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"status": report["status"], "output": str(output),
        "source_cases": report.get("source_phase", {}).get("distinct_passed_unittest_names"),
        "source_commands": report.get("source_phase", {}).get("commands_verified"),
        "supplement_commands": report.get("static_supplement", {}).get("commands_verified"),
        "static_supplement_disposition": report.get("static_supplement_disposition"),
        "native_observations_inherited": False, "error": report.get("error")}, sort_keys=True))
    return 0 if report["status"] == "RECEIPT_CONSISTENCY_PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
