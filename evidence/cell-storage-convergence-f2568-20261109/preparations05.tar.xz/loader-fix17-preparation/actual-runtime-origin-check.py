import hashlib,importlib.util,json,pathlib,sys,time,types
r=pathlib.Path('/home/qq/work/chain-cell-storage-convergence-f2568-20261109');o=r.parent/'chain-cell-storage-convergence-loader-fix17-preparation/actual-runtime-observation';o.mkdir(exist_ok=False);p=r/'scripts/llm_python_runtime_contract.py';s=r.parent/'chain-cell-storage-convergence-f2568-20261109-sealed-prep-01/runtime-snapshot.v2.json';H=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
z={'schema':'cell-original-pinned-torch-virtual-origin-observation-v1','passed':False,'model_executed':False,'started_unix':time.time()}
try:
 assert H(p)=='b947b8eaee6dcf4f2f932c22df7e4d989f27171702314e59b03f391ceebe7bbc'
 spec=importlib.util.spec_from_file_location('original_runtime_verifier',p);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
 wp=o.parent/'scripts/llm_cell_sealed_worker_v1.py';assert H(wp)=='e93bfc47f8055786f2088fc65f61c1f0d2482a0b8b4e5b8b9e30e8707fbb8c1b';ws=importlib.util.spec_from_file_location('sealed_profile_control',wp);worker=importlib.util.module_from_spec(ws);sys.modules[ws.name]=worker;ws.loader.exec_module(worker)
 v=m.load_snapshot(s,'e87a3658675836c130ba2a97a805bc6d86cc435135e72f4b6e40747e9271b9eb');m.configure(v);m.verify_files(v);guard=m.install_import_guard(v,{str(p):H(p),str(wp):H(wp)})
 import torch
 from transformers import AutoModelForCausalLM,AutoTokenizer
 from transformers.models.llama import modeling_llama
 rows=[]
 for name,module in tuple(sys.modules.items()):
  path=getattr(module,'__file__',None)
  if path is not None and (type(path) is not str or not pathlib.Path(path).is_absolute()):
   rows.append({'name':name,'file':str(path),'class_module':type(module).__module__,'class_name':type(module).__name__})
 z['relative_origins']=rows;z['owner_sources']={}
 for owner_name,alias,cls in [('torch._ops','ops','_Ops'),('torch._classes','classes','_Classes')]:
  owner=sys.modules[owner_name];virtual=sys.modules['torch.'+alias];loader=owner.__loader__;origin=owner.__file__
  resolved=worker.runtime_module_origin(types.SimpleNamespace(helper=m,snapshot=v,guard=guard),'torch.'+alias,virtual);assert resolved==origin
  z['owner_sources'][owner_name]={'origin':origin,'sha256':H(pathlib.Path(origin)),'snapshot_matches':v['files'][origin]==H(pathlib.Path(origin)),'loader_class':type(loader).__name__,'loader_expected':loader.expected,'loader_path':loader.path,'spec_origin':owner.__spec__.origin,'resolved_by_corrected_worker':resolved,'exact_class':type(virtual) is vars(owner)[cls],'same_owner_singleton':virtual is vars(owner)[alias],'same_root_alias':virtual is vars(torch)[alias],'class_initializer_filename':type(virtual).__init__.__code__.co_filename}
 z['passed']=len(rows)==2 and {row['name'] for row in rows}=={'torch.ops','torch.classes'} and all(row['snapshot_matches'] and row['exact_class'] and row['same_owner_singleton'] and row['same_root_alias'] for row in z['owner_sources'].values())
finally:
 z['ended_unix']=time.time();(o/'receipt.json').write_text(json.dumps(z,indent=2,sort_keys=True)+'\n');print(json.dumps(z))
sys.exit(0 if z['passed'] else 1)
