#!/usr/bin/env python3
from pathlib import Path
import ast, hashlib, io, json, os, stat, subprocess, tarfile, yaml
D=Path(__file__).resolve().parent
ROOT=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo")
def need(ok,m):
 if not ok:raise ValueError(m)
def ident(p):
 b=Path(p).read_bytes();return {"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
def put(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+"\n")
report=json.loads((D/"verification-v1-report.json").read_text());need(report["status"]=="PASS","Actual controls not PASS")
out=D/"deliverable-v1";out.mkdir()
raw=b"";pages=json.loads((D/"verification-v1-pty-pages.json").read_text())
for row in pages:
 need(row["offset"]==len(raw),"PTY pages not contiguous")
 b=bytes.fromhex(row["bytes_hex"]);need(hashlib.sha256(b).hexdigest()==row["chunk_sha256"],"PTY bytes hash")
 raw+=b
need(pages[-1]["status"]["exit_code"]==0 and pages[-1]["output_complete"] and len(raw)==pages[-1]["available_end"],"No full terminal")
(D/"verification-v1-terminal.raw").write_bytes(raw)
data=yaml.safe_load((D/"candidate-workflow.yml").read_text())
before=yaml.safe_load((D/"upstream-workflow.yml").read_text())
need(len(data["jobs"])==len(before["jobs"])==46,"Job roster changed")
changed=[n for n in before["jobs"] if data["jobs"][n]!=before["jobs"][n]]
need(changed==["native-work-owner","native-work-owner-original"],"Unexpected job semantic change")
for name in before["jobs"]:
 need(data["jobs"][name]["timeout-minutes"]==20,"20-minute gate differs")
for p in (D/"prepare_and_run_v1.py",D/"download_verified_artifact.py"):ast.parse(p.read_text())
cp=subprocess.run(["git","diff","--no-index","--check",str(D/"upstream-workflow.yml"),str(D/"candidate-workflow.yml")],capture_output=True)
(D/"workflow-diff-check.stdout").write_bytes(cp.stdout);(D/"workflow-diff-check.stderr").write_bytes(cp.stderr)
need(cp.returncode in (0,1) and not cp.stdout and not cp.stderr,"Workflow whitespace check failed")
calls={
 "native":{"actual_std":"native-controls -> controls -> unittest test_clock_evidence.test_actual_normal_compiler_loader_identity -> captured_std + capture_loader","new_install_and_selection":True},
 "original":{"actual_std":"rust_oracle.original_comparison/check plus original-pack -> original(live=True) -> captured_std/executable_interpreter; sqlite_and_loader(live=True) -> capture_loader","new_install_and_selection":True},
 "qualification":{"actual_std":False,"path":"qualify-pack -> transfer.qualify_pack -> assess(..., live=False) -> original(..., live=False) -> stored std sources/binaries and captured dependencies","installation_added":False},
 "readback":{"actual_std":False,"path":"readback -> assess(...,live=False); validate_controls re-reads all raw results and discovers IDs without executing tests","installation_added":False},
}
summary={"schema":"trnm.work-owner.bd620-toolchain-diagnosis.v1","status":"OBSERVED_AND_LOCAL_CORRECTION_VERIFIED",
 "head":"bd6201646f92a37edc641b2ab0ae8032507b5784","tree":"8a273894649be8393e2b1dc493d7482b2a07d6c0",
 "failed_job_url":"https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/44041831642/job/133897989699",
 "original_run_remains":"FAILURE","original_prerequisite_jobs_skipped":[133899939617,133899939629,133899939474],
 "native_runtime_in_failed_job":"NOT_RUN","observed_root_cause":"65 mandatory controls executed; only actual pinned compiler/std identity test failed. Native producer had no locked Rust installation/selection.",
 "hosted_actual_default_rustc_version":"NOT_CAPTURED; not inferred from local control",
 "diagnostic_zip":ident(D/"diagnostics-original.zip"),"full_job_log":ident(D/"upstream-job133897989699.log"),
 "local_true_wrong_compiler_control":report["wrong_default_control"],"local_explicit_pinned_control":report["explicit_pinned_control"],
 "local_selected_toolchain_install_seconds":29.260055434,
 "local_full_65_control_seconds":23.73697791,
 "native133":report["native_source_set_sha256"],"reader6":report["reader_source_set_sha256"],
 "exact_current_full_source_before_after":"MATCH","frozen_runtime_and_reader_files_changed":False,
 "workflow_patch":ident(D/"workflow.patch"),"candidate_workflow":ident(D/"candidate-workflow.yml"),
 "only_changed_jobs":changed,"workflow_total_jobs":46,"all_job_timeouts_minutes":20,
 "four_stage_call_graph":calls,"future_hosted_run":"NOT_RUN","whole_Node_or_service_success_claimed":False,
 "rustup_install_stderr_preserved":True,"rustup_install_observation":"Existing pinned 1.95/rust-src unchanged; installer logged tool-manager self-update discovery/download. No compiler/std contract was relaxed."}
put(D/"diagnosis.json",summary)
files={}
for p in sorted(D.rglob("*")):
 if out in p.parents or p==out:continue
 if p.is_file():
  s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1,"No special/shared file")
  files[p.relative_to(D).as_posix()]={**ident(p),"mode":stat.S_IMODE(s.st_mode)}
manifest={"schema":"trnm.work-owner.bd620-complete-diagnosis-archive.v1","entries":files}
packed=out/"complete-diagnosis.tar.xz"
with tarfile.open(packed,"w:xz",preset=6) as t:
 for name,row in files.items():
  p=D/name;b=p.read_bytes();need(ident(p)=={k:row[k] for k in ("bytes","sha256")},"Input changed")
  h=tarfile.TarInfo(name);h.size=len(b);h.mode=row["mode"];h.mtime=0;t.addfile(h,io.BytesIO(b))
with tarfile.open(packed,"r:xz") as t:
 roster=t.getmembers();need([x.name for x in roster]==list(files),"Archive roster differs")
 for item in roster:
  b=t.extractfile(item).read();r=files[item.name]
  need(len(b)==r["bytes"] and hashlib.sha256(b).hexdigest()==r["sha256"],"Archive member bytes differ")
manifest["archive"]=ident(packed);manifest["write_then_complete_readback"]="PASS"
put(out/"archive-index.json",manifest)
put(out/"handoff.json",{"status":"PASS","archive":manifest["archive"],"index":ident(out/"archive-index.json"),
 "diagnosis":ident(D/"diagnosis.json"),"patch":ident(D/"workflow.patch"),"report":ident(D/"verification-v1-report.json"),
 "members":len(files),"current_exact_ci_success_claimed":False})
print(json.dumps({"status":"PASS","archive":str(packed),**manifest["archive"],"members":len(files),"handoff":ident(out/"handoff.json")}))
