#!/usr/bin/env python3
"""Publish reviewed C2 through the local ProfHepta channel, preserving failures."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
import traceback

ROOT = Path('/data/chain-pq-closure-20261111-d4d2-publish')
OUT = Path('/data/pq-closure-publish-0e554f36ff-d4d2')
BODY = Path('/data/pq-closure-pr-body-0e554f36ff-d4d2.md')
BODY_SHA = '859bd019bfad528e9269980eee5717d6f5d7de2a6ac8781b22a00ae070c7cb95'
INITIAL_BODY_NORMALIZED_SHA = 'baba4259d0d412e85b4a3c9178c67e9b8bb4686444de8a05fe6bcd2277dd99e4'
ORIGINAL = Path('/data/pq-closure-c2-publish-validation-0e554f36ff-d4d2')
SUPPLEMENT = Path('/data/pq-closure-c2-inventory-correction-0e554f36ff-d4d2')
C1 = 'c09dbbe9921da12db8bf7240a8a95a0e9a789e50'
C2 = '0e554f36ffdde3053a5eb1756eb5e526b1935032'
TREE = '753cdbad6714f00d8ccb9ddbb47f0fd71280ee62'
BASE = '31543fb6dde565b62b47436e0b1d399b6d0bd772'
BRANCH = 'fix/chain-pq-closure-20261111-d4d2'
BASE_BRANCH = 'fix/chain-pq-authority-complete-20261110-5778'
REPO = 'TrillionniumFoundation/Trillionnium-Chain'
ENV = dict(os.environ, GIT_TERMINAL_PROMPT='0', GIT_NO_REPLACE_OBJECTS='1')
ROWS = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def write(name, data):
    with (OUT / name).open('x') as stream:
        json.dump(data, stream, sort_keys=True, indent=2)
        stream.write('\n')


def run(name, argv, timeout=120):
    row = {'name': name, 'argv': argv, 'cwd': str(ROOT), 'started_utc': now(), 'timeout_seconds': timeout}
    write(name + '.started.json', row)
    began = time.monotonic()
    with (OUT / (name + '.stdout.log')).open('xb') as normal, (OUT / (name + '.stderr.log')).open('xb') as errors:
        result = subprocess.run(argv, cwd=ROOT, env=ENV, stdin=subprocess.DEVNULL,
                                stdout=normal, stderr=errors, timeout=timeout, check=False)
    row.update(exit_code=result.returncode, elapsed_seconds=time.monotonic() - began, finished_utc=now())
    for key in ('stdout', 'stderr'):
        path = OUT / (name + '.' + key + '.log')
        row[key] = {'name': path.name, 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
    write(name + '.receipt.json', row)
    ROWS.append(row)
    print(json.dumps({'command': name, 'exit_code': result.returncode}), flush=True)
    require(result.returncode == 0, 'command failed: ' + name)
    return (OUT / (name + '.stdout.log')).read_text()


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', '--no-optional-locks', *args],
                                   cwd=ROOT, env=ENV, text=True, timeout=120).strip()


def identity():
    result = {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
              'branch': git('branch', '--show-current'),
              'status': git('status', '--porcelain=v1', '--untracked-files=all')}
    require(result == {'commit': C2, 'tree': TREE, 'branch': BRANCH, 'status': ''}, 'C2 checkout identity')
    return result


def main():
    require(ROOT.is_dir() and ROOT.resolve() == ROOT and not OUT.exists(), 'fresh canonical publish paths')
    require(sha(BODY.read_bytes()) == BODY_SHA, 'reviewed body changed')
    original = json.loads((ORIGINAL / 'summary.json').read_text())
    supplement = json.loads((SUPPLEMENT / 'summary.json').read_text())
    require(original['source'] == supplement['source'] == {'commit': C2, 'tree': TREE}, 'validation source')
    failed = [r for r in original['commands'] if not r['passed']]
    require(original['all_commands_passed'] is False and len(failed) == 1
            and failed[0]['name'] == 'distributed-inventory' and failed[0]['exit_code'] == 2
            and failed[0]['argv'] == ['/usr/bin/python3', '-B',
                 'scripts/ci/refresh_distributed_source_inventory.py', '--check'], 'original failure not retained')
    require(original['original_c1_identity_unchanged'] is True
            and original['full_c2_source_before_after_equal'] is True, 'original source observation')
    tests = next(r for r in original['commands'] if r['name'] == 'public-readiness-tests')
    require(tests['passed'] is True and tests['exit_code'] == 0 and tests['timed_out'] is False
            and tests['outer_tests'] == 71 and tests['complete_71_without_skip'] is True
            and len(tests['success_ids']) == len(set(tests['success_ids'])) == 71, 'full readiness roster')
    require(supplement['original_all_commands_passed'] is False
            and all(supplement[k] is True for k in ['original_failure_preserved', 'original_71_tests_passed',
                'supplemental_all_commands_passed', 'full_source_before_after_equal',
                'original_c1_identity_unchanged', 'combined_required_publish_validation_complete']),
            'corrected command/source observation missing')
    corrected = next(r for r in supplement['supplemental_commands'] if r['name'] == 'distributed-inventory-corrected')
    require(corrected['argv'] == ['/usr/bin/python3', '-B', 'scripts/refresh_distributed_source_inventory.py', '--check']
            and corrected['passed'] is True and corrected['exit_code'] == 0
            and corrected['timed_out'] is False, 'actual corrected inventory did not pass')
    for directory, rows in [(ORIGINAL, original['commands']), (SUPPLEMENT, supplement['supplemental_commands'])]:
        require((directory / 'source-before.json').read_bytes() == (directory / 'source-after.json').read_bytes(),
                'validation source snapshots changed')
        for row in rows:
            require(json.loads((directory / (row['name'] + '.receipt.json')).read_text()) == row, 'validation receipt changed')
            for key in ('stdout', 'stderr'):
                path = directory / (row['name'] + '.' + key + '.log')
                require(path.stat().st_size == row[key]['bytes'] and sha(path.read_bytes()) == row[key]['sha256'],
                        'validation raw stream changed')
    OUT.mkdir(mode=0o700)
    write('validation-bindings.json', {
        'original_summary': {'path': str(ORIGINAL / 'summary.json'), 'sha256': sha((ORIGINAL / 'summary.json').read_bytes())},
        'supplement_summary': {'path': str(SUPPLEMENT / 'summary.json'), 'sha256': sha((SUPPLEMENT / 'summary.json').read_bytes())},
        'original_failure_retained': True, 'complete_readiness_tests': 71,
        'corrected_inventory_passed': True, 'body_sha256': BODY_SHA})
    try:
        write('source-before.json', identity())
        run('preflight', ['bash', 'scripts/project-preflight.sh'])
        actor = run('actor', ['gh', 'api', 'user', '--jq', '.login']).strip()
        require(actor == 'ProfHepta', 'wrong GitHub actor')
        origin = git('remote', 'get-url', 'origin')
        require(origin in {'https://github.com/' + REPO, 'https://github.com/' + REPO + '.git',
                           'git@github.com:' + REPO + '.git'}, 'noncanonical origin')
        prior = json.loads(run('pr-before', ['gh', 'api', 'repos/' + REPO + '/pulls/901']))
        require(prior['state'] == 'open' and prior['draft'] is True
                and prior['head']['sha'] == C1 and prior['head']['ref'] == BRANCH
                and prior['base']['sha'] == BASE and prior['base']['ref'] == BASE_BRANCH,
                'PR identity changed; preserve concurrent changes')
        require(sha(prior['body'].strip().encode()) == INITIAL_BODY_NORMALIZED_SHA, 'PR body changed concurrently')
        remote = run('remote-before', ['git', 'ls-remote', 'origin', 'refs/heads/' + BRANCH]).strip()
        require(remote.split() == [C1, 'refs/heads/' + BRANCH], 'remote branch changed')
        run('enable-project-hooks', ['git', 'config', '--local', 'core.hooksPath', '.githooks'])
        require(git('config', '--get', 'core.hooksPath') == '.githooks', 'project hooks not active')
        require((ROOT / '.githooks/pre-push').is_file(), 'project pre-push hook missing')
        run('push-c2', ['git', 'push', 'origin', 'HEAD:refs/heads/' + BRANCH], timeout=600)
        remote = run('remote-after', ['git', 'ls-remote', 'origin', 'refs/heads/' + BRANCH]).strip()
        require(remote.split() == [C2, 'refs/heads/' + BRANCH], 'published source mismatch')
        run('update-pr-body', ['gh', 'pr', 'edit', '901', '--repo', REPO, '--body-file', str(BODY)])
        after = json.loads(run('pr-after', ['gh', 'api', 'repos/' + REPO + '/pulls/901']))
        require(after['head']['sha'] == C2 and after['head']['ref'] == BRANCH
                and after['base']['sha'] == BASE and after['draft'] is True
                and after['body'].strip() == BODY.read_text().strip(), 'PR readback mismatch')
        write('source-after.json', identity())
        summary = {'schema': 'TRNM-C2-LOCAL-GITHUB-PUBLISH1', 'actor': actor,
                   'source': {'commit': C2, 'tree': TREE}, 'remote_head': C2,
                   'pull_request': after['html_url'], 'draft': True,
                   'normal_fast_forward_push': True, 'project_hooks_enabled': True,
                   'original_validation_failure_retained': True, 'readiness_tests_passed': 71,
                   'whole_chain_pq_qualified': False, 'production_activation': False,
                   'commands': ROWS, 'finished_utc': now()}
        write('summary.json', summary)
        print(json.dumps({k: v for k, v in summary.items() if k != 'commands'}), flush=True)
    except BaseException as error:
        write('failure.json', {'error_type': type(error).__name__, 'message': str(error),
                               'traceback': traceback.format_exc(), 'commands': ROWS,
                               'finished_utc': now(), 'inspect_actual_remote_before_any_retry': True})
        raise


if __name__ == '__main__':
    main()
