import sys,json,sqlite3,hashlib
from pathlib import Path
P=Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/owner-cancel-state-audit-02")
sys.path.insert(0,str(P))
import readback_helpers as h
h.OUT=P
db=lambda n:sqlite3.connect("file:"+str(P/"private-analysis-only"/(n+".sqlite"))+"?mode=ro&immutable=1",uri=True)
m=db("m12-generation"); raw=m.execute("SELECT payload FROM native_generation_events_v2 ORDER BY sequence LIMIT 1").fetchone()[0];prep=h.prepare(raw);m.close()
s=prep["statement"];n=db("native-node")
blocks=[{"id":row[0].hex(),"parent":row[1].hex() if row[1] is not None else None,"height":row[2],"packet_bytes":len(row[3]) if row[3] is not None else None,"packet_sha256":hashlib.sha256(row[3]).hexdigest() if row[3] is not None else None,"state_root":row[4].hex()} for row in n.execute("SELECT id,parent,height,packet,state_root FROM blocks ORDER BY height")]
public_keys={"task:"+s["task"],"account:"+s["owner"],"account:"+s["provider"]}
deltas=[{"block":row[0].hex(),"key":row[1],"before":json.loads(row[2]) if row[2] is not None and row[1] in public_keys else None,"after":json.loads(row[3]) if row[3] is not None and row[1] in public_keys else None,"values_omitted":row[1] not in public_keys} for row in n.execute("SELECT block,key,before,after FROM deltas ORDER BY block,key")]
active=[{"tip":r[0].hex(),"generation":r[1],"state_slot":r[2]} for r in n.execute("SELECT tip,generation,state_slot FROM active")]
events=[{"generation":r[0],"ordinal":r[1],"kind":r[2],"block":r[3].hex()} for r in n.execute("SELECT generation,ordinal,kind,block FROM events ORDER BY generation,ordinal")]
n.close()
reqpath=P/"public/raw/owner-cancel-run-02/target-request.json";rr=reqpath.read_bytes();r=json.loads(rr)
c=json.dumps(r,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
normal=json.dumps({k:v for k,v in r.items() if k!="statement"},sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
o={"schema":"TRNM-W1-OWNER02-PRIVATE-COPY-PUBLIC-ROWS1","prep":prep,"native_blocks":blocks,"native_deltas":deltas,"native_active":active,"native_events":events,"request":{"raw_bytes":len(rr),"raw_sha256":hashlib.sha256(rr).hexdigest(),"canonical_bytes":len(c),"canonical_sha256":hashlib.sha256(c).hexdigest(),"normalized_sha256":hashlib.sha256(normal).hexdigest(),"file_pins":len(r["file_pins"]),"top_keys":sorted(r),"file_pin_shape":type(r["file_pins"]).__name__},"scope":"Only public task and owner/provider account delta values; all other values omitted. Queries immutable private copies only."}
h.write(P/"public/public-rows-observation.json",h.encode(o))
print(json.dumps(o,sort_keys=True),flush=True)
