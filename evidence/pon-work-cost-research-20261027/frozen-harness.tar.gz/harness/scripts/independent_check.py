#!/usr/bin/env python3
"""Independent scalar Python full replay, never a succinct proof verifier."""
from pathlib import Path
import argparse,hashlib,json,struct,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'upstream/formal/pon-nakamoto-v1'))
import work_oracle as w
from contract_wire import H,header_decode
def read_exact(path,size):
    with path.open('rb')as f:data=f.read(size+1)
    if len(data)!=size:raise ValueError('LENGTH '+path.name)
    return data
def verify_export(directory):
    s=json.loads((directory/'statement.json').read_text())
    if s['schema']!='trnm-w1-complete-statement-research-v1':raise ValueError('SCHEMA')
    if s['source_commit']!='4b6b8a91b6dfe41fbd7f40f40b359d535c2c4251':raise ValueError('SOURCE_COMMIT')
    if s['profile']!='pon-matmul-transcript-64-v1':raise ValueError('PROFILE')
    if s['status']!='COMPLETE_W1_WITNESS_ONLY_NOT_SUCCINCT_PROOF':raise ValueError('MISREPRESENTED_PROOF')
    for key in ['fri_commit_grinding_bits','fri_query_grinding_bits','proof_grinding_bits']:
        if type(s[key])is not int or s[key]!=0:raise ValueError('GRINDING_NOT_ZERO')
    for key in ['independent_work_puzzle','transparent_backend_executed','succinct_proof_generated','computational_hardness_qualified','post_quantum_qualified','parent_state_or_chain_validity_checked','node_task_eligibility_checked']:
        if s[key]is not False:raise ValueError('UNSUPPORTED_ACCEPTANCE_CLAIM')
    header=read_exact(directory/'header.bin',318);h=header_decode(header);challenge=H('challenge',header)
    proof=read_exact(directory/'pnw1.bin',w.PROOF_BYTES)
    ticket,product=w.verify(challenge,h['work_task'],h['target'],proof)
    a,b,_,_=w.precheck(challenge,h['work_task'],h['target'],proof)
    expected_ids=dict(challenge=challenge,task=h['work_task'],target=h['target'],trace=proof[-32:],ticket=ticket,semantic_block_id=H('block',header,proof[-32:]),pnw1_sha256=hashlib.sha256(proof).digest())
    expected_ids['statement_id']=H('w1-complete-statement-research-v1',b'pon-matmul-transcript-64-v1',header,expected_ids['pnw1_sha256'])
    for key,value in expected_ids.items():
        if s[key]!=value.hex():raise ValueError('STATEMENT_BINDING '+key)
    noise=[w.expand(challenge,label,w.N*w.R)for label in range(4)]
    if read_exact(directory/'noise.bin',4*w.N*w.R*4)!=w.field_bytes(sum(noise,[])):raise ValueError('NOISE')
    el,er,fl,fr=noise
    ap=[(x+y)%w.Q for x,y in zip(a,w.mm(el,er,w.N,w.R,w.N))]
    bp=[(x+y)%w.Q for x,y in zip(b,w.mm(fl,fr,w.N,w.R,w.N))]
    if read_exact(directory/'noised-a.bin',w.CELLS*4)!=w.field_bytes(ap):raise ValueError('NOISED_A')
    if read_exact(directory/'noised-b.bin',w.CELLS*4)!=w.field_bytes(bp):raise ValueError('NOISED_B')
    transcript=read_exact(directory/'transcript.bin',131072);position=0;cp=[0]*w.CELLS
    for bi in range(0,w.N,w.R):
        for bj in range(0,w.N,w.R):
            for bk in range(0,w.N,w.R):
                for i in range(bi,bi+w.R):
                    for j in range(bj,bj+w.R):
                        p=i*w.N+j
                        cp[p]=(cp[p]+sum(ap[i*w.N+k]*bp[k*w.N+j]for k in range(bk,bk+w.R)))%w.Q
                        if struct.unpack_from('<I',transcript,position)[0]!=cp[p]:raise ValueError('TRACE_RELATION')
                        position+=4
    if hashlib.sha256(b'TRNM-PON-TRACE1\0'+challenge+transcript).digest()!=proof[-32:]:raise ValueError('TRACE_HASH')
    for artifact in s['artifacts']:
        if artifact['path']not in {'header.bin','pnw1.bin','noise.bin','noised-a.bin','noised-b.bin','transcript.bin'}:raise ValueError('ARTIFACT_PATH')
        data=(directory/artifact['path']).read_bytes()
        if len(data)!=artifact['bytes']or hashlib.sha256(data).hexdigest()!=artifact['sha256']:raise ValueError('ARTIFACT_HASH')
    return dict(result='PASS',full_python_w1_replay=True,full_prefix_values_checked=position//4,semantic_block_id=expected_ids['semantic_block_id'].hex(),succinct_proof=False,chain_validity=False)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('directory',type=Path);args=p.parse_args()
    print(json.dumps(verify_export(args.directory),indent=2))
