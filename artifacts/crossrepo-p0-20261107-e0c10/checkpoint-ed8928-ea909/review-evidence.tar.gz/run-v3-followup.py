#!/usr/bin/env python3
"""Sequential additional native and real SQLite-cache checks on frozen ea909."""
import hashlib, json, os, pathlib, subprocess, time

TASK = pathlib.Path('/data/chain-p0-crossrepo-e0c10-v3')
SRC = TASK / 'source'
HEAD = 'ea909124cc460f364bd17b009073306014133f48'
TREE = '96712231eba3d333bdfebefa9c22c80ea1794d04'
OUT = TASK / 'records/followup-v1'

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(path):
    before = path.stat()
    with path.open('rb') as stream:
        value = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.stat()
    need((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns) ==
         (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns), 'file changed while hashing')
    return value

def git(*argv):
    return subprocess.check_output(['git','--no-replace-objects',*argv],cwd=SRC,text=True).strip()

def identity():
    need(git('rev-parse','HEAD') == HEAD and git('rev-parse','HEAD^{tree}') == TREE and not git('status','--porcelain'), 'frozen source differs')

def save(path, value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2,sort_keys=True)
        stream.write('\n')

identity()
need(not OUT.exists(), 'followup output must be fresh')
original_path = TASK/'records/controlled-integrated-v1/summary.json'
original = json.loads(original_path.read_text())
need(original.get('source') == HEAD and original.get('tree') == TREE and original.get('native_invocations') == 89, 'original denominator must be complete before followup')
need(sha(TASK/'environment.json') == '956dfeaaf93608bab10386ccdc821e54317832c629a8b77d3601291b38d1e8e4', 'environment changed')
need(sha(TASK/'extra-native-v1.py') == '0f3ebf41304c7eb755c46ebd5dfe53a7bbd67974bc423588d917528889335488', 'extra runner changed')
env = os.environ.copy()
env.update(json.loads((TASK/'environment.json').read_text()))
need(env['CARGO_BUILD_JOBS'] == '2', 'build quota differs')
OUT.mkdir()
rustup = '/home/qian-qi/.cargo/bin/rustup'
compiler = subprocess.check_output([rustup,'which','--toolchain','1.95.0','rustc'],cwd=SRC,env=env,text=True).strip()
cargo = subprocess.check_output([rustup,'which','--toolchain','1.95.0','cargo'],cwd=SRC,env=env,text=True).strip()
need(compiler == env['RUSTC'], 'pinned compiler differs')
commands = [
    ('additional-native', ['python3',str(TASK/'extra-native-v1.py'),HEAD]),
    ('sqlite-requalification', ['python3','scripts/ci/check_sqlite_build_requalification.py',
        '--root',str(SRC),'--output',str(TASK/'records/sqlite-requalification-v1'),
        '--target',str(TASK/'target-sqlite-requalification-v1'),
        '--rustc',compiler,'--cargo',cargo,'--rustup',rustup]),
]
rows = []
for label, argv in commands:
    identity()
    subprocess.run(['bash','scripts/project-preflight.sh'],cwd=SRC,env=env,check=True)
    print(json.dumps({'stage':'start','label':label,'source':HEAD}),flush=True)
    start = time.monotonic()
    log = OUT/(label+'.log')
    with log.open('xb') as stream:
        result = subprocess.run(argv,cwd=SRC,env=env,stdout=stream,stderr=subprocess.STDOUT,check=False)
    row = {'label':label,'argv':argv,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start,
           'log_path':str(log),'log_sha256':sha(log),'log_bytes':log.stat().st_size}
    identity()
    rows.append(row)
    save(OUT/(label+'.json'),row)
    print(json.dumps({'stage':'finish',**row}),flush=True)
    if result.returncode:
        print(log.read_text(errors='replace')[-8000:],flush=True)
extra_path = TASK/'records/extra-native-v1/summary.json'
sqlite_path = TASK/'records/sqlite-requalification-v1/summary.json'
extra = json.loads(extra_path.read_text()) if extra_path.is_file() else None
sqlite = json.loads(sqlite_path.read_text()) if sqlite_path.is_file() else None
accepted = all(r['exit_code'] == 0 for r in rows) and extra is not None and extra.get('accepted') is True and sqlite is not None and sqlite.get('passed') is True
summary = {'schema':'frozen-candidate-followup-v1','source':HEAD,'tree':TREE,'rows':rows,
           'original_89':{'path':str(original_path),'sha256':sha(original_path),'executed':original['native_invocations'],'accepted':original['native_accepted'],'complete_result_inherited_as_followup':False},
           'additional_native':{'path':str(extra_path),'sha256':sha(extra_path) if extra is not None else None,'accepted':extra.get('accepted') if extra else False},
           'sqlite_cache':{'path':str(sqlite_path),'sha256':sha(sqlite_path) if sqlite is not None else None,'original_commands':len(sqlite.get('commands',[])) if sqlite else 0,'additional_loader_controls':len(sqlite.get('loader_controls',[])) if sqlite else 0,'passed':sqlite.get('passed') if sqlite else False},
           'accepted':accepted,'whole_system_qualified':False,'production_activation':False}
save(OUT/'summary.json',summary)
print(json.dumps({'complete':True,'accepted':accepted,'original_89_accepted':original['native_accepted']}),flush=True)
raise SystemExit(0 if accepted else 1)
