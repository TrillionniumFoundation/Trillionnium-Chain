#!/usr/bin/env python3
"""Transport only the six explicitly approved terminal History ELF paths."""
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import stat
import sys
import time

HELPER = Path('/tmp/history-r8-elf-preserve-20261028.py')
HELPER_SHA = '9a877b7779d636e46fcbbd456935c4a9a2ffb5c51cec06056067a2f6949dc3bb'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == HELPER_SHA
spec = importlib.util.spec_from_file_location('verified_history_transport_helpers', HELPER)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
ROOT = Path('/tmp/target-history-56818e4fba76')
DEPS = ROOT/'debug/deps'
OUT = ROOT/'preserved-r8-deps-elf-gzip-20261028'
h.OUT = OUT
BINDINGS = Path('/tmp/history-six-deps-source-bindings-r8.json')
BINDINGS_SHA = '230b636166562199a80ea51a5b5df1b2ea647d3ac4beeff84fc762b6d9f364a8'
APPROVED = [
    ('trnm_pon_node-08929c1b7ad6a8fb',164356936,'250cef359cbb8c7ef7763e3e195d0868c5d2836ddad6951dca6246b0ff84f65a'),
    ('public_v3_service_campaign-e481bec33ffabc71',157904688,'5bb64ec566ce0e10709fa1f42f5efd6892dca8e004f6332e223144c53450da21'),
    ('trnm_pon_node-9e86f7cb7a9d0a67',126556056,'0f82f1a43c785ac6610789df27379c3bba166036bb39b5589d75b92ef6fdc927'),
    ('trnm_pon_node-e4b33f49275e9dec',126461128,'3aae89ff283f8329625363bbfa95b366b36492e0be5de07354a6a9b696719db4'),
    ('trnm_pon_node-71eea7016073a858',76400896,'4a2e3c4bfd5e2d7c994ad9915704467a973cac92593c7e631cb5bfd188f74423'),
    ('public_v3_multiprocess-b925461c415cbaf8',75283280,'5cb30a8ebad891bf7181c9ae0eed72abd811e137741789010ff31da76670087d'),
]
REUSED_NAME = 'trnm_pon_node-e4b33f49275e9dec'
REUSED_ARCHIVE = ROOT/'preserved-r8-elf-gzip-20261028/history-r8-candidate-corrected-node.gz'
REUSED_SHA = 'd634e84e31eafdfbff9d73162595ad79b644303f547fe73ad6a4c80ace264bfe'
BLOCK = 1024*1024
START = time.monotonic()

def main():
    h.require(ROOT.resolve(strict=True)==ROOT and DEPS.resolve(strict=True)==DEPS,'exact owner/deps roots required')
    h.require(not os.path.lexists(OUT),'fresh archive directory only; no retry')
    h.require(h.digest(BINDINGS)==BINDINGS_SHA,'source bindings changed')
    OUT.mkdir(mode=0o700)
    os.nice(19)
    resource.setrlimit(resource.RLIMIT_CPU,(45,50))
    resource.setrlimit(resource.RLIMIT_AS,(256*BLOCK,256*BLOCK))
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGXCPU,signal.SIGALRM):
        signal.signal(sig,h.interrupted)
    signal.alarm(120)
    before_free=h.free_bytes()
    before_usage=resource.getrusage(resource.RUSAGE_SELF)
    complete=[]
    result={}
    try:
        for original,name in ((Path(__file__),'preserve.py'),(HELPER,'transport-helper.py'),(BINDINGS,'source-bindings.json')):
            with (OUT/name).open('xb') as f:
                f.write(original.read_bytes());f.flush();os.fsync(f.fileno())
        h.write_json('plan.json',dict(schema='history-six-deps-lossless-transport-r8-v1',
            approved=[dict(path=str(DEPS/name),bytes=size,sha256=sha) for name,size,sha in APPROVED],
            free_before_bytes=before_free,process_scope=h.ownership_snapshot(),
            script_sha256=h.digest(Path(__file__)),helper_sha256=HELPER_SHA,source_bindings_sha256=BINDINGS_SHA,
            argv=sys.argv,python_executable=sys.executable,native_executed=False,
            budget=dict(wall_seconds=120,cpu_soft_seconds=45,cpu_hard_seconds=50,address_space_bytes=256*BLOCK,free_floor_bytes=h.FLOOR),
            retained_unapproved_hardlink_alias=str(ROOT/'debug/trnm-pon-node')))
        for name,size,expected in APPROVED:
            source=DEPS/name
            original=source.lstat()
            identity=h.identity(original)
            h.require(stat.S_ISREG(original.st_mode) and not source.is_symlink() and source.resolve(strict=True)==source,'source regular exact containment')
            h.require(original.st_size==size,'approved source size changed')
            reused=name==REUSED_NAME
            archive=REUSED_ARCHIVE if reused else OUT/(name+'.gz.partial')
            final=archive if reused else OUT/(name+'.gz')
            h.require(reused or h.free_bytes()>=h.FLOOR+size+4*BLOCK,'temporary compression would violate floor')
            raw_hash=hashlib.sha256();raw_bytes=0
            with os.fdopen(os.open(source,os.O_RDONLY|os.O_NOFOLLOW),'rb') as raw:
                h.require(h.identity(os.fstat(raw.fileno()))==identity,'source identity changed at open')
                h.require(raw.read(4)==b'\x7fELF','source not ELF');raw.seek(0)
                if reused:
                    for chunk in iter(lambda:raw.read(BLOCK),b''):
                        raw_hash.update(chunk);raw_bytes+=len(chunk)
                else:
                    with archive.open('xb') as output:
                        with gzip.GzipFile(filename='',mode='wb',compresslevel=6,fileobj=output,mtime=0) as zipped:
                            for chunk in iter(lambda:raw.read(BLOCK),b''):
                                h.require(h.free_bytes()>=h.FLOOR+2*BLOCK,'disk floor before compression write')
                                zipped.write(chunk);raw_hash.update(chunk);raw_bytes+=len(chunk)
                        output.flush();os.fsync(output.fileno())
                h.require(h.identity(os.fstat(raw.fileno()))==identity,'source fd changed during read')
            h.require(raw_bytes==size and raw_hash.hexdigest()==expected,'source no longer matches exact read-only inventory')
            archive_stat=archive.lstat()
            h.require(stat.S_ISREG(archive_stat.st_mode) and not archive.is_symlink() and archive.resolve(strict=True)==archive,'compressed archive path identity')
            archive_sha=h.digest(archive)
            h.require(not reused or archive_sha==REUSED_SHA,'existing preserved archive changed')
            restored_hash=hashlib.sha256();restored_bytes=0
            with gzip.open(archive,'rb') as restored:
                for chunk in iter(lambda:restored.read(BLOCK),b''):
                    restored_hash.update(chunk);restored_bytes+=len(chunk)
                    h.require(restored_bytes<=size,'decompression exceeds exact original bytes')
            h.require(restored_bytes==size and restored_hash.hexdigest()==expected,'full decompress byte/SHA mismatch')
            h.require(h.identity(archive.lstat())==h.identity(archive_stat),'archive changed while reverified')
            h.require(h.identity(source.lstat())==identity,'source inode/mtime changed before preservation')
            if not reused:
                h.require(not os.path.lexists(final),'no archive overwrite')
                archive.rename(final);h.fsync_dir(OUT)
            record=dict(source_path=str(source),source_identity=identity,source_sha256=expected,
                source_allocated_bytes=original.st_blocks*512,compressed_path=str(final),
                compressed_bytes=final.stat().st_size,compressed_allocated_bytes=final.stat().st_blocks*512,
                compressed_sha256=archive_sha,full_decompressed_bytes=restored_bytes,
                full_decompressed_sha256=restored_hash.hexdigest(),reused_identical_archive=reused,
                source_identity_unchanged=True,source_unlinked=False,
                process_scope_before_unlink=h.ownership_snapshot(),free_before_unlink_bytes=h.free_bytes(),
                remaining_hardlink_payload_is_not_freed=original.st_nlink>1)
            h.write_json(name+'.verified.json',record)
            h.require(h.identity(source.lstat())==identity,'source changed immediately before unlink')
            source.unlink();h.fsync_dir(DEPS)
            record.update(source_unlinked=True,free_after_unlink_bytes=h.free_bytes())
            complete.append(record)
            h.event(dict(stage='VERIFIED_REDUNDANT_RAW_UNLINKED',source_path=str(source),
                compressed_path=str(final),reused_identical_archive=reused,
                original_sha256=expected,free_bytes=h.free_bytes(),remaining_hardlink_payload_is_not_freed=original.st_nlink>1))
        result=dict(outcome='ALL_SIX_VERIFIED_LOSSLESS_TRANSPORT_COMPLETE',completed=complete)
    except BaseException as error:
        result=dict(outcome='FAILED_RETAIN_ALL_COMPLETED_AND_PARTIAL_ARCHIVES',error=repr(error),completed=complete)
        raise
    finally:
        signal.alarm(0)
        usage=resource.getrusage(resource.RUSAGE_SELF)
        result.update(wall_seconds=time.monotonic()-START,user_cpu_seconds=usage.ru_utime-before_usage.ru_utime,
            system_cpu_seconds=usage.ru_stime-before_usage.ru_stime,peak_rss_bytes=usage.ru_maxrss*1024,
            free_before_bytes=before_free,free_after_bytes=h.free_bytes(),free_net_change_bytes=h.free_bytes()-before_free,
            native_executed=False,unlink_scope=[str(DEPS/name) for name,_,_ in APPROVED],
            unapproved_hardlink_alias_preserved=str(ROOT/'debug/trnm-pon-node'))
        h.write_json('result.json',result)
        print(json.dumps({k:v for k,v in result.items() if k!='completed'}),flush=True)

if __name__=='__main__':
    main()
