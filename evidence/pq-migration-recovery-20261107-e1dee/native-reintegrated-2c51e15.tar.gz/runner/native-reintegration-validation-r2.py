#!/usr/bin/env python3
"""Validate the reintegrated frozen source while retaining the prior source and ELF bodies."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
TASK = Path('/home/qian-qi/work/chain-pq-migration-recovery-e1dee-20261106')
ORIGINAL = TASK / 'source'
ORIGINAL_HEAD = '2058225aa0d50ca57b1eb0d5f520d7f4eefae69b'
SOURCE = TASK / 'reintegrated-source'
PRIOR_SOURCE = TASK / 'corrected-source'
CLONE_SOURCE = TASK / 'publication-source'
HEAD = '2c51e15e5b4f57b133b53cc9c386431e29563db5'
PRIOR_HEAD = '9fb011c4af1f9f54353207f9ad9fbc54ab6235e3'
PRIOR_TREE = '5f4f1730e0f5218e4db9706e6daf2c25cde5c182'
TREE = '3f62762d719765b920cb7c7f1c1621440f98818e'
BUNDLE = TASK / 'pq-reintegration-m15.bundle'
BUNDLE_SHA256 = '45868c4a9c9be8b61190c250eca66ab4bf516b22e227acf441317e70c9ff0f3d'
PUBLICATION_BUNDLE = TASK / 'pq-migration-recovery-publication.bundle'
PUBLICATION_BUNDLE_SHA256 = 'fe5a44a6e85beb75de270881574b880a35d1e6240b4ed8e91902f5bc64c3a84f'
ENVIRONMENT_SHA256 = '5c9c21a7045e09aca9eab347a222c886dc56e5e10b7935f51b7dfe9f5a4a937a'
HELPER = TASK / 'native-validation-v1.py'
HELPER_SHA256 = 'fdd330aacfa3ccd65aa5740c433c76a284df8241e14ab80f31e9396fed4ed1b9'
TARGET = TASK / 'target-fixed'
OUT = TASK / 'records/native-reintegrated-r2'
ORIGIN = 'https://github.com/TrillionniumFoundation/Trillionnium-Chain.git'
EXPECTED = {'m06-migration': {'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::all_monetary_namespaces_and_zero_obligations_are_counted_without_netting',
                   'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::empty_ledger_inventory_never_certifies_external_obligations_or_retirement',
                   'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::inventory_counts_every_opaque_row_but_bounds_diagnostic_key_examples',
                   'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::inventory_rejects_wrong_pins_changed_state_and_inconsistent_issued_supply',
                   'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::malformed_account_is_not_relabelled_as_an_empty_ledger',
                   'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::unknown_debt_revocation_execution_and_active_model_rows_block_empty_inference',
                   'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::zero_accounts_and_nonce_floors_are_preserved_as_identity_obligations'},
 'node-migration': {'store::pq_migration_inventory::handoff_tests::admitted_restricted_source_handoff_preserves_nonce_liability_and_claim_on_cold_open',
                    'store::pq_migration_inventory::handoff_tests::admitted_source_handoff_refuses_wrong_registry_pins_and_unsupported_source_rows',
                    'store::pq_migration_inventory::tests::fixed_admitted_checkpoint_keeps_inventory_across_forks_reorg_and_cold_open',
                    'store::pq_migration_inventory::tests::inventory_does_not_substitute_growth_working_partition_for_complete_state',
                    'store::pq_migration_inventory::tests::inventory_rechecks_actual_state_packet_and_storage_context_after_a_prior_success',
                    'store::pq_migration_inventory::tests::inventory_refuses_durable_pending_reorg_then_uses_recovered_snapshot',
                    'store::pq_migration_inventory::tests::inventory_requires_independent_source_pins_and_actual_admission'},
 'root-separation': {'release_owner::root_separation_tests::all_three_service_keys_are_excluded_from_offline_root_and_every_online_role',
                     'release_owner::root_separation_tests::canonical_role_keys_replay_at_every_tagged_proof_boundary',
                     'release_owner::root_separation_tests::expired_old_root_keeps_dual_quorum_recovery_and_cold_proof_replay',
                     'release_owner::root_separation_tests::expired_root_recovery_requires_both_real_quorums_and_a_fresh_successor',
                     'release_owner::root_separation_tests::role_decoding_preserves_complete_root_and_canonical_record_requirements',
                     'release_owner::root_separation_tests::root_role_keys_refuse_aliases_unknown_codes_and_duplicates_in_tagged_proofs',
                     'release_owner::root_separation_tests::valid_dual_quorum_successor_cannot_reuse_an_independent_service_key'},
 'sealed': {'release_owner::sealed_tests::denied_mutations_preserve_sealed_bytes_without_claiming_unchanged_metadata',
            'release_owner::sealed_tests::inherited_fifo_without_writer_is_refused_before_any_blocking_open',
            'release_owner::sealed_tests::metadata_only_changes_refuse_read_copy_descriptor_and_exec_handoff',
            'release_owner::sealed_tests::native_elf_profile_rejects_interpreter_dependencies_search_paths_and_wrong_machine',
            'release_owner::sealed_tests::sealed_copy_survives_in_place_source_rewrite_and_path_replacement',
            'release_owner::sealed_tests::source_rewrite_or_path_exchange_during_sealing_refuses_authentication',
            'release_owner::sealed_tests::unsealed_regular_input_and_a_different_sealed_descriptor_are_rejected'}}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def emit(value):
    print(json.dumps(value, sort_keys=True), flush=True)


def identity(source):
    def git(*args):
        return subprocess.check_output(
            ['/usr/bin/git', '--no-optional-locks', '-C', str(source), *args],
            text=True).strip()
    return {'head': git('rev-parse', 'HEAD'),
            'tree': git('rev-parse', 'HEAD^{tree}'),
            'status_porcelain': git('status', '--porcelain=v1', '--untracked-files=all')}


def load_helper():
    if digest(HELPER) != HELPER_SHA256:
        raise RuntimeError('original native helper digest changed')
    spec = importlib.util.spec_from_file_location('reintegrated_native_helpers', HELPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.PREP = OUT / 'source-preparation'
    return helper


def binary_rows(helper, build_log):
    rows = helper.executables(build_log, TARGET)
    for row in rows:
        path = Path(row['path'])
        if path.is_symlink():
            raise RuntimeError('test executable is a symlink')
        with path.open('rb') as stream:
            header = stream.read(64)
        if header[:4] != b'\x7fELF':
            raise RuntimeError('test executable is not native ELF')
        if not Path(row['target']['src_path']).resolve().is_relative_to(SOURCE.resolve()):
            raise RuntimeError('test executable artifact is not from reintegrated source')
        row['format'] = 'ELF'
        row['elf_header_sha256'] = hashlib.sha256(header).hexdigest()
    return rows


INTEGRATION_CASES = [
    ('integration-claim-cold-open', 'npq6_anchored_claim_preserves_obligations_rotates_and_cold_reopens'),
    ('integration-signatures-domain', 'npq6_migration_requires_both_claim_signatures_and_the_selected_domain'),
    ('integration-unsupported-source', 'admitted_legacy_checkpoint_cannot_drop_unhandled_work_state_for_migration'),
]


def retain_prior_binaries(helper):
    previous = TASK / 'records/native-reintegrated/prior-9fb-elf-retention.json'
    expected = 'b24eb77a0b6b2d520e71e71df68654af53e87f134c82136a1982589ed265b938'
    if digest(previous) != expected:
        raise RuntimeError('first-attempt 9fb ELF retention record changed')
    entries = json.loads(previous.read_text())
    if len(entries) != 11 or len({row['retained'] for row in entries}) != 11:
        raise RuntimeError('prior 9fb retained ELF set differs from the recorded eleven')
    for row in entries:
        original, retained = Path(row['original']), Path(row['retained'])
        if (row['tested_source'] != PRIOR_HEAD or row['tested_tree'] != PRIOR_TREE
                or not original.resolve().is_relative_to(TARGET.resolve())
                or not retained.resolve().is_relative_to((TASK / 'retained-native-before-reintegration-9fb011c').resolve())
                or os.path.samefile(original, retained)):
            raise RuntimeError('prior 9fb ELF retention identity/path mismatch')
        if digest(row['source_record']) != row['source_record_sha256']:
            raise RuntimeError('prior 9fb original identity receipt changed')
        for path in [original, retained]:
            if path.is_symlink() or path.stat().st_size != row['size'] or digest(path) != row['sha256']:
                raise RuntimeError('prior 9fb original or retained ELF changed')
        if retained.stat().st_mode & 0o777 != 0o555:
            raise RuntimeError('prior 9fb retained ELF mode changed')
    helper.save(OUT / 'prior-9fb-elf-retention-reference.json', {
        'source_record': str(previous), 'source_record_sha256': expected,
        'rechecked_existing_copies': True, 'new_elf_copies': 0, 'entries': entries})
    emit({'event': 'prior_9fb_retained_elf_bodies_rechecked', 'count': 11, 'new_elf_copies': 0})
    return entries


def registered_tests(helper, record, args, selector, label, expected):
    log = record(label + '-registration', [*args, selector, '--', '--list', '--test-threads=1'])
    text = log.read_text()
    names = re.findall(r'^([A-Za-z0-9_:]+): test$', text, re.M)
    summaries = re.findall(r'^[0-9]+ tests?, [0-9]+ benchmarks?$', text, re.M)
    if (len(names) != 7 or set(names) != expected or summaries != ['7 tests, 0 benchmarks']):
        raise RuntimeError('required exact native registration roster differs: ' + label)
    helper.save(OUT / (label + '-registration-observation.json'), {
        'registered': names, 'summaries': summaries, 'expected_exact_names': sorted(expected)})


def main(helper):
    if identity(SOURCE) != {'head': PRIOR_HEAD, 'tree': PRIOR_TREE, 'status_porcelain': ''}:
        raise RuntimeError('stopped first-attempt checkout is not the clean expected prior source')
    if digest(BUNDLE) != BUNDLE_SHA256:
        raise RuntimeError('reintegrated bundle digest mismatch')
    if digest(TASK / 'environment.json') != ENVIRONMENT_SHA256:
        raise RuntimeError('fixed environment file changed')
    original_before = identity(ORIGINAL)
    if original_before['head'] != ORIGINAL_HEAD or original_before['status_porcelain']:
        raise RuntimeError('retained probe source is not the clean expected original')
    prior_before = identity(PRIOR_SOURCE)
    if prior_before != {'head': PRIOR_HEAD, 'tree': PRIOR_TREE, 'status_porcelain': ''}:
        raise RuntimeError('prior 9fb source is not the exact clean qualified source')
    helper.save(OUT / 'original-source-before.json', original_before)
    helper.save(OUT / 'prior-9fb-source-before.json', prior_before)
    helper.preparation('prior-9fb-preflight', ['/bin/bash', 'scripts/project-preflight.sh'], PRIOR_SOURCE)
    if digest(TASK / 'records/native-integrated-evidence-9fb011c.tar.gz') != '278b6ac2f1266f8c881d8cf114e1effa52bde7a6a530e4a72e718d480e273ff5':
        raise RuntimeError('prior sealed 9fb evidence archive changed')
    retained = retain_prior_binaries(helper)
    checkpoint_input = TASK / 'records/native-fixed/checkpoint-tests-observation.json'
    checkpoint_roster = json.loads(checkpoint_input.read_text())
    if (len(checkpoint_roster['passed']) != 56 or len(set(checkpoint_roster['passed'])) != 56
            or checkpoint_roster['failed'] or checkpoint_roster['ignored']):
        raise RuntimeError('prior checkpoint roster is not the original 56 passed tests')
    helper.save(OUT / 'prior-checkpoint-roster.json', {
        'path': str(checkpoint_input), 'sha256': digest(checkpoint_input), 'observation': checkpoint_roster})
    # A normal clone from this shallow source did not transfer unadvertised
    # objects. Preserve that failure and fetch only the two real prerequisites
    # from the existing local Git pool using ordinary Git transport.
    if helper.preparation('canonical-origin', ['/usr/bin/git', 'remote', 'get-url', 'origin'], SOURCE).strip() != ORIGIN:
        raise RuntimeError('stopped new checkout origin differs from canonical repository')
    helper.preparation('stopped-checkout-preflight', ['/bin/bash', 'scripts/project-preflight.sh'], SOURCE)
    clone_source = helper.preparation('clone-source-identity', ['/usr/bin/git', 'show', '-s',
                          '--format=%H %T', 'HEAD'], CLONE_SOURCE).strip()
    if clone_source != PRIOR_HEAD + ' ' + PRIOR_TREE:
        raise RuntimeError('publication object source is not the selected prior HEAD/tree')
    before_fetch = identity(SOURCE)
    prerequisites = []
    for index, prerequisite in enumerate([
            'b0dadfdc0d906d35f19a1ba79df2ddbb8bbfba25',
            '1c14fab4cca9c2ad1a48c502f51eb89edeb7df50']):
        if index == 0:
            if digest(PUBLICATION_BUNDLE) != PUBLICATION_BUNDLE_SHA256:
                raise RuntimeError('existing publication bundle digest changed')
            helper.preparation('publication-bundle-verify', ['/usr/bin/git', 'bundle', 'verify',
                               str(PUBLICATION_BUNDLE)], SOURCE)
            helper.preparation('prerequisite-fetch-' + str(index), ['/usr/bin/git', 'fetch', '--no-tags',
                               str(PUBLICATION_BUNDLE), 'HEAD'], SOURCE)
            transport = 'verified-existing-publication-bundle'
            pool_fields = None
        else:
            pool_fields = helper.preparation('pool-prerequisite-' + str(index), ['/usr/bin/git', 'show', '-s',
                        '--format=%H %T', prerequisite], CLONE_SOURCE).strip().split()
            if len(pool_fields) != 2 or pool_fields[0] != prerequisite:
                raise RuntimeError('existing local pool does not have the exact prerequisite')
            helper.preparation('prerequisite-fetch-' + str(index), ['/usr/bin/git', 'fetch', '--no-tags',
                               str(CLONE_SOURCE), prerequisite], SOURCE)
            transport = 'ordinary-local-git-fetch'
        fetched = helper.preparation('prerequisite-fetch-head-' + str(index), ['/usr/bin/git', 'rev-parse',
                                     'FETCH_HEAD^{commit}'], SOURCE).strip()
        fields = helper.preparation('prerequisite-' + str(index), ['/usr/bin/git', 'show', '-s',
                    '--format=%H %T', prerequisite], SOURCE).strip().split()
        if (fetched != prerequisite or len(fields) != 2 or fields[0] != prerequisite
                or not re.fullmatch('[0-9a-f]{40}', fields[1])):
            raise RuntimeError('new checkout lacks the real exact fetched prerequisite')
        if pool_fields is not None and fields != pool_fields:
            raise RuntimeError('ordinary local fetch obtained a different prerequisite')
        prerequisites.append({'commit': fields[0], 'tree': fields[1], 'transport': transport})
    after_fetch = identity(SOURCE)
    if before_fetch != after_fetch:
        raise RuntimeError('ordinary prerequisite fetch changed the checked-out source')
    helper.save(OUT / 'prerequisite-observation.json', {
        'source_pool': str(CLONE_SOURCE), 'clone_source': clone_source,
        'ordinary_local_git_fetch': True, 'manual_shallow_edit': False, 'prerequisites': prerequisites,
        'before_source': before_fetch, 'after_source': after_fetch,
        'publication_bundle_sha256': PUBLICATION_BUNDLE_SHA256})
    helper.preparation('reintegrated-bundle-verify', ['/usr/bin/git', 'bundle', 'verify', str(BUNDLE)], SOURCE)
    helper.preparation('reintegrated-bundle-import', ['/usr/bin/git', 'fetch', '--no-tags', str(BUNDLE), HEAD], SOURCE)
    helper.preparation('reintegrated-fast-forward', ['/usr/bin/git', 'merge', '--ff-only', HEAD], SOURCE)
    source_before = identity(SOURCE)
    if source_before != {'head': HEAD, 'tree': TREE, 'status_porcelain': ''}:
        raise RuntimeError('reintegrated source identity mismatch')
    helper.save(OUT / 'reintegrated-source-before.json', source_before)
    environment = helper.load_environment('target-fixed')
    if (environment['CARGO_BUILD_JOBS'] != '2' or environment['CARGO_INCREMENTAL'] != '0'
            or environment['RUST_TEST_THREADS'] != '1' or environment['RUSTUP_TOOLCHAIN'] != '1.95.0'):
        raise RuntimeError('original native concurrency/toolchain selection changed')
    if digest(environment['TRNM_PQ_OPENSSL']) != environment['TRNM_PQ_OPENSSL_SHA256']:
        raise RuntimeError('pinned original native provider digest changed')
    cargo = str(Path(environment['RUSTC']).with_name('cargo'))
    flags = ['--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml']
    def record(label, command):
        return helper.record(SOURCE, HEAD, OUT, environment, label, command)
    def preflight(label):
        return record(label, ['/bin/bash', 'scripts/project-preflight.sh'])
    preflight('preflight')
    record('rustc', [environment['RUSTC'], '-Vv'])
    record('cargo', [cargo, '-V'])
    all_binaries = []
    observations = {}
    scopes = [
        ('checkpoint', 'trnm-checkpoint-store', ['--all-targets'], [], 56, set(checkpoint_roster['passed'])),
        ('node-migration', 'trnm-pon-node', ['--lib', '--all-features'], ['pq_migration_inventory'], 7, EXPECTED['node-migration']),
        ('m06-migration', 'trnm-mvcc-fee', ['--lib'], ['migration_inventory_v1'], 7, EXPECTED['m06-migration']),
    ]
    for name, package, target_args, selectors, expected_count, expected_names in scopes:
        args = [cargo, 'test', *flags, '-p', package, *target_args]
        preflight(name + '-build-preflight')
        build = record(name + '-build', [*args, '--no-run', '--message-format=json'])
        binaries = binary_rows(helper, build)
        helper.save(OUT / (name + '-binaries-before.json'), binaries)
        all_binaries.extend(binaries)
        preflight(name + '-run-preflight')
        if name == 'node-migration':
            node_binaries = binaries
            node_args = args
            registered_tests(helper, record, args, selectors[0], name, expected_names)
        log = OUT / (name + '-tests.log')
        try:
            record(name + '-tests', [*args, '--no-fail-fast', *selectors, '--', '--test-threads=1'])
        finally:
            helper.recheck_binaries(binaries)
            helper.save(OUT / (name + '-binaries-after.json'), binaries)
            if log.exists():
                tests = helper.actual_tests(log)
                helper.save(OUT / (name + '-tests-observation.json'), tests)
        if (tests['failed'] or tests['ignored'] or len(tests['passed']) != expected_count
                or set(tests['passed']) != expected_names or not tests['summaries']):
            raise RuntimeError('required exact native test roster was not passed: ' + name)
        if selectors and (len(tests['summaries']) != 1 or not re.fullmatch(
                r'test result: ok\. 7 passed; 0 failed; 0 ignored; 0 measured; [0-9]+ filtered out; finished in [0-9]+(?:\.[0-9]+)?s', tests['summaries'][0])):
            raise RuntimeError('required migration summary was not passed: ' + name)
        observations[name] = tests
    for name, selector in [('root-separation', 'release_owner::root_separation_tests::'),
                           ('sealed', 'release_owner::sealed_tests::')]:
        helper.recheck_binaries(node_binaries)
        helper.save(OUT / (name + '-binaries-before.json'), node_binaries)
        preflight(name + '-run-preflight')
        registered_tests(helper, record, node_args, selector, name, EXPECTED[name])
        log = OUT / (name + '-tests.log')
        try:
            record(name + '-tests', [*node_args, '--no-fail-fast', selector, '--',
                                     '--show-output', '--test-threads=1'])
        finally:
            helper.recheck_binaries(node_binaries)
            helper.save(OUT / (name + '-binaries-after.json'), node_binaries)
            if log.exists():
                tests = helper.actual_tests(log)
                helper.save(OUT / (name + '-tests-observation.json'), tests)
        if (tests['failed'] or tests['ignored'] or len(tests['passed']) != 7
                or set(tests['passed']) != EXPECTED[name] or len(tests['summaries']) != 1
                or not re.fullmatch(r'test result: ok\. 7 passed; 0 failed; 0 ignored; 0 measured; [0-9]+ filtered out; finished in [0-9]+(?:\.[0-9]+)?s', tests['summaries'][0])):
            raise RuntimeError('required exact seven-test module roster was not passed: ' + name)
        observations[name] = tests
    args = [cargo, 'test', *flags, '-p', 'trnm-pon-node', '--test', 'pq_application_migration_v6']
    preflight('integration-build-preflight')
    build = record('integration-build', [*args, '--no-run', '--message-format=json'])
    integration_binaries = binary_rows(helper, build)
    helper.save(OUT / 'integration-binaries-before.json', integration_binaries)
    all_binaries.extend(integration_binaries)
    for label, selector in INTEGRATION_CASES:
        preflight(label + '-preflight')
        log = OUT / (label + '.log')
        try:
            record(label, [*args, selector, '--', '--exact', '--show-output', '--test-threads=1'])
        finally:
            helper.recheck_binaries(integration_binaries)
            helper.save(OUT / (label + '-binaries-after.json'), integration_binaries)
            if log.exists():
                tests = helper.actual_tests(log)
                helper.save(OUT / (label + '-observation.json'), tests)
        record(label + '-execution', ['/usr/bin/python3', 'scripts/ci/check_required_native_test.py',
                                     str(log), '--test', selector])
        if tests['failed'] or tests['ignored'] or tests['passed'] != [selector]:
            raise RuntimeError('required exact integration test was not passed: ' + selector)
        observations[label] = tests
    preflight('workspace-clippy-preflight')
    record('workspace-clippy', [cargo, 'clippy', *flags, '--workspace', '--all-targets',
                               '--all-features', '--', '-D', 'warnings'])
    helper.recheck_binaries(all_binaries)
    helper.save(OUT / 'binaries-after-all-gates.json', all_binaries)
    for row in retained:
        if Path(row['retained']).stat().st_size != row['size'] or digest(row['retained']) != row['sha256']:
            raise RuntimeError('prior retained ELF changed during integration validation')
    source_after = identity(SOURCE)
    original_after = identity(ORIGINAL)
    helper.save(OUT / 'reintegrated-source-after.json', source_after)
    prior_after = identity(PRIOR_SOURCE)
    helper.save(OUT / 'prior-9fb-source-after.json', prior_after)
    helper.save(OUT / 'original-source-after.json', original_after)
    if source_before != source_after or original_before != original_after or prior_before != prior_after:
        raise RuntimeError('source identity changed during reintegrated validation')
    if digest(TASK / 'environment.json') != ENVIRONMENT_SHA256 or digest(HELPER) != HELPER_SHA256:
        raise RuntimeError('original environment/helper changed during validation')
    result = {'schema': 'trnm-reintegrated-pq-native-validation-v1', 'status': 'completed',
              'tested_source': HEAD, 'tested_tree': TREE,
              'retained_probe_source': ORIGINAL_HEAD, 'retained_probe_source_unchanged': True,
              'prior_integrated_source': PRIOR_HEAD, 'prior_integrated_source_unchanged': True,
              'prior_integrated_elf_retained': True, 'prior_integrated_elf_count': 11,
              'environment_sha256': ENVIRONMENT_SHA256, 'helper_sha256': HELPER_SHA256,
              'bundle_sha256': BUNDLE_SHA256, 'commands': helper.COMMANDS,
              'tests': observations, 'native_elf_identity_unchanged': True,
              'automatic_retry': False, 'source_finality_or_retirement_qualified': False,
              'whole_chain_quantum_security_qualified': False, 'production_activation': False}
    helper.save(OUT / 'complete.json', result)
    emit({'event': 'reintegrated_native_complete', 'source': HEAD, 'checkpoint_passed': 56,
          'node_all_features_passed': 7, 'm06_passed': 7, 'integration_default_features_passed': 3,
          'root_separation_passed': 7, 'sealed_passed': 7,
          'strict_workspace_clippy': 'passed', 'automatic_retry': False})


if __name__ == '__main__':
    helper = None
    try:
        helper = load_helper()
        OUT.mkdir(mode=0o700)
        helper.PREP.mkdir(mode=0o700)
        main(helper)
    except Exception as error:
        if helper is not None and OUT.is_dir():
            failure = {'status': 'failed', 'error': str(error), 'commands': helper.COMMANDS,
                       'tested_source': HEAD, 'automatic_retry': False}
            for label, source in [('reintegrated', SOURCE), ('prior_integrated', PRIOR_SOURCE), ('original', ORIGINAL)]:
                if (source / '.git').is_dir():
                    try:
                        failure[label + '_source_after_failure'] = identity(source)
                    except Exception as identity_error:
                        failure[label + '_source_identity_error'] = str(identity_error)
            path = OUT / 'failure.json'
            if not path.exists():
                helper.save(path, failure)
        emit({'event': 'reintegrated_native_failed', 'error': str(error), 'automatic_retry': False})
        sys.exit(1)
