
        let (observation_only, existing_owner_only) = match selection {
            SelectedOpen::InitializeOrRecover { observation_only } => (observation_only, false),
            SelectedOpen::ExistingPqOwner => (false, true),
        };
        ensure(
            !existing_owner_only
                || matches!(
                    state_backend,
                    StateBackend::PqNetworkV2 | StateBackend::PqWitnessV4
                ),
            "PQ_EXISTING_OWNER_BACKEND",
        )?;
        ensure(
            !authenticated_migration_pending(path)?,
            "NATIVE_STATE_MIGRATION_PENDING",
        )?;
        ensure(
            settings.is_permanent_account_growth_v2()
                == (state_backend == StateBackend::PermanentAccountGrowthV2),
            "GROWTH_PROFILE_BACKEND",
        )?;
        if observation_only {
            ensure(
                matches!(
                    state_backend,
                    StateBackend::Legacy
                        | StateBackend::AuthenticatedV1
                        | StateBackend::PermanentAccountGrowthV2
                ) && path.join("native.sqlite").is_file(),
                "GROWTH_PACKET_STATUS_EXISTING_STORE_REQUIRED",
            )?;
        }
        let NativeOwners {
            policy: owner_policy,
            mining: mining_owner,
            continuous: continuous_owner,
            pq_network,
            pq_witness,
        } = owners;
        if growth_profile_v2::enabled(&settings.app) {
            ensure(
                state_backend == StateBackend::Legacy,
                "GROWTH_REFERENCE_BACKEND",
            )?;
            ensure(
                owner_policy.is_none() && mining_owner.is_none() && continuous_owner.is_none(),
                "GROWTH_REFERENCE_OWNER",
            )?;
        }

        let pq_selected = matches!(
            state_backend,
            StateBackend::PqNetworkV2 | StateBackend::PqContinuousV3 | StateBackend::PqWitnessV4
        );

        ensure(pq_selected == pq_network.is_some(), "PQ_NETWORK_BACKEND")?;
        ensure(
            (state_backend == StateBackend::PqWitnessV4) == pq_witness.is_some(),
            "PQ_WITNESS_BACKEND",
        )?;
        if let Some(client) = pq_witness.as_ref() {
            ensure(
                pq_network
                    .as_deref()
                    .is_some_and(|policy| client.binding().matches_policy(policy)),
                "PQ_WITNESS_POLICY",
            )?;
        }
        ensure(
            !settings.app.is_pq_account_profile() || pq_selected,
            "PQ_ACCOUNT_REQUIRES_PQ_NETWORK_OWNER",
        )?;
        ensure(
            !pq_selected
                || (owner_policy.is_none()
                    && mining_owner.is_none()
                    && match state_backend {
                        StateBackend::PqNetworkV2 | StateBackend::PqWitnessV4 => {
                            continuous_owner.is_none()
                        }
                        StateBackend::PqContinuousV3 => {
                            continuous_owner
                                .as_ref()
                                .is_some_and(|owner| owner.is_pq_startup_owner())
                                && settings.is_native_pq_application_v6()
                        }
                        _ => false,
                    }),
            "PQ_NETWORK_OWNER_COMBINATION",
        )?;

        ensure(
            usize::from(owner_policy.is_some())
                + usize::from(mining_owner.is_some())
                + usize::from(continuous_owner.is_some())
                <= 1,
            "OWNER_MODE_AMBIGUOUS",
        )?;
        let required_owner_marker = owner_policy
            .as_ref()
            .map(|p| p.required_marker.as_slice())
            .or_else(|| mining_owner.as_ref().map(|p| p.marker.as_slice()))
            .or_else(|| continuous_owner.as_ref().map(|p| p.marker.as_slice()));
        ensure([1, 2, 4, 8].contains(&workers), "WORKERS")?;
        settings.replay_checkpoint_tile_material()?;
        if !path.exists() {
            ensure(!existing_owner_only, "PQ_EXISTING_OWNER_REQUIRED")?;
            fs::create_dir_all(path)?;
            fs::set_permissions(path, fs::Permissions::from_mode(0o700))?;
        }
        let metadata = fs::symlink_metadata(path)?;
        ensure(
            metadata.is_dir() && !metadata.file_type().is_symlink(),
            "NAMESPACE",
        )?;
        let directory = path.canonicalize()?;
        let dbpath = directory.join("native.sqlite");
        let marker = directory.join("initializing.json");
        ensure(
            !observation_only || !marker.exists(),
            "GROWTH_OBSERVATION_RECOVERY_REQUIRED",
        )?;
        let lock = directory.join("owner.lock");
        for p in [
            &dbpath,
            &marker,
            &lock,
            &directory.join("native.sqlite-wal"),
            &directory.join("native.sqlite-shm"),
        ] {
            plain(p)?;
        }
        let owner = OpenOptions::new()
            .create(!existing_owner_only)
            .truncate(false)
            .read(true)
            .write(true)
            .mode(0o600)
            .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
            .open(&lock)?;
        owner
            .try_lock_exclusive()
            .map_err(|_| Error::from("WRITER_BUSY"))?;
        if existing_owner_only {
            existing_owner_boundary(&directory, (metadata.dev(), metadata.ino()), &owner)?;
            let current = fs::symlink_metadata(&dbpath)?;
            ensure(
                current.is_file() && !current.file_type().is_symlink() && current.nlink() == 1,
                "PQ_EXISTING_OWNER_REQUIRED",
            )?;
        }
        let ddl = state_backend.ddl();
        let schema_id = state_backend.selected_schema_id(&settings);
        let expected = canonical(
            &serde_json::json!({"schema":hex::encode(schema_id),"parameters":hex::encode(settings.parameters()),"genesis":hex::encode(settings.genesis())}),
        )?;
        if !existing_owner_only && !dbpath.exists() && !marker.exists() {
            for entry in fs::read_dir(&directory)? {
                let name = entry?.file_name();
                ensure(
                    name == "owner.lock"
                        || (required_owner_marker.is_some()
                            && name == "owner-task-policy.required"),
                    "NAMESPACE_NOT_EMPTY",
                )?;
            }
            let mut intent = OpenOptions::new()
                .write(true)
                .create_new(true)
                .mode(0o600)
                .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
                .open(&marker)?;
            intent.write_all(&expected)?;
            intent.sync_all()?;
            sync_dir(&directory)?;
            cut(&mut hook, "init-intent")?;
        }
        let intent = marker.exists();
        ensure(
            !existing_owner_only || !intent,
            "PQ_EXISTING_OWNER_INITIALIZATION",
        )?;
        if intent {
            ensure(
                read_initialization_marker(&marker, expected.len())? == expected,
                "INITIALIZATION_CONTEXT",
            )?;
        }
        let expected_db = Connection::open_in_memory()?;
        expected_db.execute_batch(&ddl)?;
        let expected_schema = schema(&expected_db)?;
        let mut initialized = false;
        let mut prior_inode = None;
        let mut retained_existing = None;
        if dbpath.exists() {
            let m = fs::metadata(&dbpath)?;
            prior_inode = Some((m.dev(), m.ino()));
            if existing_owner_only {
                cut(&mut hook, "existing-owner-before-open")?;
                existing_owner_boundary(&directory, (metadata.dev(), metadata.ino()), &owner)?;
                plain(&dbpath)?;
            }
            // Existing-only validates this very RW connection and retains it;
            // it never probes one connection and later reopens with CREATE.
            let probe = Connection::open_with_flags(
                &dbpath,
                (if existing_owner_only {
                    OpenFlags::SQLITE_OPEN_READ_WRITE
                } else {
                    OpenFlags::SQLITE_OPEN_READ_ONLY
                }) | OpenFlags::SQLITE_OPEN_NO_MUTEX,
            )?;
            let current = schema(&probe)?;
            if current.is_empty() {
                ensure(!existing_owner_only, "PQ_EXISTING_OWNER_INITIALIZED")?;
                ensure(intent, "INITIALIZATION_INTENT_REQUIRED")?;
            } else {
                ensure(current == expected_schema, "SCHEMA")?;
                if state_backend == StateBackend::PqWitnessV4 {
                    ensure(
                        witness_metadata_matches(
                            &probe,
                            "operator_task_policy",
                            required_owner_marker,
                        )?,
                        "OWNER_TASK_POLICY_REQUIRED",
                    )?;
                    ensure(
                        witness_metadata_matches(
                            &probe,
                            "pq_network_owner_v2",
                            pq_network.as_deref(),
                        )?,
                        "PQ_NETWORK_POLICY_REQUIRED",
                    )?;
                } else {
                    let required: Option<Vec<u8>> = probe
                        .query_row(
                            "SELECT value FROM metadata WHERE key='operator_task_policy'",
                            [],
                            |r| r.get(0),
                        )
                        .optional()?;
                    ensure(
                        required.as_deref() == required_owner_marker,
                        "OWNER_TASK_POLICY_REQUIRED",
                    )?;
                    let recorded_pq: Option<Vec<u8>> = probe
                        .query_row(
                            "SELECT value FROM metadata WHERE key='pq_network_owner_v2'",
                            [],
                            |row| row.get(0),
                        )
                        .optional()?;
                    ensure(recorded_pq == pq_network, "PQ_NETWORK_POLICY_REQUIRED")?;
                }
                ensure(
                    witness_metadata_matches(
                        &probe,
                        pq_rollback_witness::KEY,
                        pq_witness
                            .as_ref()
                            .map(|client| client.binding().canonical()),
                    )?,
                    "PQ_WITNESS_BINDING_REQUIRED",
                )?;
                for (key, value) in [
                    ("schema", schema_id),
                    ("parameters", settings.parameters()),
                    ("genesis", settings.genesis()),
                ] {
                    if state_backend == StateBackend::PqWitnessV4 {
                        ensure(
                            witness_metadata_matches(&probe, key, Some(value.as_slice()))?,
                            "STORAGE_CONTEXT",
                        )?;
                    } else {
                        let recorded: Option<Vec<u8>> = probe
                            .query_row("SELECT value FROM metadata WHERE key=?", [key], |r| {
                                r.get(0)
                            })
                            .optional()?;
                        ensure(
                            recorded.as_deref() == Some(value.as_slice()),
                            "STORAGE_CONTEXT",
                        )?;
                    }
                }
                initialized = true;
            }
            if existing_owner_only {
                retained_existing = Some(probe);
                cut(&mut hook, "existing-owner-validated")?;
            }
        }
        if existing_owner_only {
            ensure(
                initialized && retained_existing.is_some(),
                "PQ_EXISTING_OWNER_INITIALIZED",
            )?;
            existing_owner_boundary(&directory, (metadata.dev(), metadata.ino()), &owner)?;
        }
        for p in [
            &dbpath,
            &directory.join("native.sqlite-wal"),
            &directory.join("native.sqlite-shm"),
        ] {
            plain(p)?;
        }
        ensure(
            !observation_only || initialized,
            "GROWTH_PACKET_STATUS_EXISTING_STORE_REQUIRED",
        )?;
        let mut db = if let Some(db) = retained_existing {
            db
        } else if observation_only {
            Connection::open_with_flags(
                &dbpath,
                OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX,
            )?
        } else {
            Connection::open(&dbpath)?
        };
        let dm = fs::metadata(&dbpath)?;
        if let Some(previous) = prior_inode {
            ensure(previous == (dm.dev(), dm.ino()), "NAMESPACE_CHANGED")?;
        }
        db.busy_timeout(Duration::from_secs(5))?;
        if observation_only {
            db.execute_batch(
                "PRAGMA trusted_schema=OFF; PRAGMA foreign_keys=ON; PRAGMA query_only=ON;",
            )?;
        } else {
            db.execute_batch(
                "PRAGMA trusted_schema=OFF; PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;",
            )?;
        }
        if !initialized {
            ensure(intent, "INITIALIZATION_INTENT_REQUIRED")?;
            let tx = db.transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)?;
            tx.execute_batch(&ddl)?;
            cut(&mut hook, "init-schema")?;
            for (key, value) in [
                ("schema", schema_id),
                ("parameters", settings.parameters()),
                ("genesis", settings.genesis()),
            ] {
                tx.execute(
                    "INSERT INTO metadata VALUES(?,?)",
                    params![key, value.as_slice()],
                )?;
            }
            if let Some(policy) = pq_network.as_deref() {
                tx.execute(
                    "INSERT INTO metadata VALUES('pq_network_owner_v2',?)",
                    [policy],
                )?;
                pq_network::seed(&tx, policy)?;
            }
            if let Some(client) = pq_witness.as_ref() {
                pq_rollback_witness::seed(&tx, client.binding())?;
            }
            if let Some(marker) = required_owner_marker {
                tx.execute(
                    "INSERT INTO metadata VALUES('operator_task_policy',?)",
                    [marker],
                )?;
            }
            tx.execute(
                "INSERT INTO blocks VALUES(?,NULL,0,?,NULL,?)",
                params![
                    settings.genesis.as_slice(),
                    [0u8; 64].as_slice(),
                    if state_backend == StateBackend::PermanentAccountGrowthV2 {
                        growth::initial_root(&settings)?
                    } else {
                        settings.state_root(&settings.initial)?
                    }
                    .as_slice()
                ],
            )?;
            tx.execute(
                "INSERT INTO active VALUES(1,?,0,0)",
                [settings.genesis.as_slice()],
            )?;
            if state_backend != StateBackend::PermanentAccountGrowthV2 {
                for (key, value) in &settings.initial {
                    tx.execute(
                        "INSERT INTO kv VALUES(0,?,?)",
                        params![key, canonical(value)?],
                    )?;
                }
                tx.execute(
                    "INSERT INTO snapshots VALUES(?,?)",
                    params![settings.genesis.as_slice(), canonical(&settings.initial)?],
                )?;
            } else {
                growth::seed(&tx, &settings)?;
            }
            if state_backend == StateBackend::AuthenticatedV1 {
                native_authenticated::seed(&tx, &settings)?;
            }
            cut(&mut hook, "init-before-commit")?;
            tx.commit()?;
            cut(&mut hook, "init-committed")?;
        }
        if intent {
            fs::remove_file(marker)?;
            sync_dir(&directory)?;
        }
        let legacy_admission_schema = (state_backend == StateBackend::Legacy
            && !pq_accounts_v2::enabled(&settings.app)
            && !growth_profile_v2::enabled(&settings.app))
        .then(|| expected_schema.clone());
        let mut node = Self {
            db,
            owner,
            growth_observer_snapshot: None,
            directory,
            directory_id: (metadata.dev(), metadata.ino()),
            database_id: (dm.dev(), dm.ino()),
            settings,
            workers,
            state_backend,
            growth_epoch: None,
            #[cfg(test)]
            expected_schema: expected_schema.clone(),
            post_write_schema: (state_backend == StateBackend::AuthenticatedV1)
                .then_some(expected_schema),
            legacy_admission_schema,
            #[cfg(test)]
            public_history_test_sql_limit: None,
            #[cfg(test)]
            public_history_test_snapshot: false,
            commitment_cache: RefCell::new(None),
            historical_commitment_cache: RefCell::default(),
            commitment_root_arithmetic: pon_commitment::FullRootArithmetic::default(),
            root_rejection_cache: RefCell::new(None),
            authenticated_arithmetic: native_authenticated::ArithmeticCache::default(),
            commitment_observation: RefCell::new(None),
            history_read_counters: Cell::new(HistoryReadCounters::default()),
            history_page_read_counters: Cell::new(HistoryPageReadCounters::default()),
            native_owner_observer: RefCell::new(None),
            owner_policy,
            mining_owner,
            continuous_owner,
            public_service_cpu: None,
            public_service_epoch_listeners: 0,
            public_service_epoch_unknown: false,
            detached_execution: std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false)),
            #[cfg(test)]
            cancel_next_activation_intent: false,
            pq_network_epoch: std::sync::Arc::new(std::sync::atomic::AtomicU64::new(1)),
            pq_witness: pq_witness.map(RefCell::new),
        };
        node.check_pq_witness_open()?;
        if node.state_backend == StateBackend::PermanentAccountGrowthV2 {
            // Complete-State reference budget records cannot be silently ignored
            // by this backend. Validate/refuse them before any growth recovery.
            node.validate_native_budget_records_v1()?;
            node.growth_cold_open(!observation_only)?;
            node.validate_native_task_operation_pins_v1()?;
            node.validate_native_demand_evidence_v1()?;
            // Settings retain the immutable genesis input for exact reopen. Hot
            // execution never clones this bootstrap State or the full account set.
            return Ok(node);
        }
        if observation_only {
            // Cold reconciliation must not finish an owner's unpublished reorg.
            node.ready()?;
        }
        node.read_active()?;
        if node.state_backend == StateBackend::AuthenticatedV1 {
            native_authenticated::verify_history_with_cache(
                &node.db,
                &node.settings,
                node.active()?.0,
                &mut || Ok(()),
                Some(&node.authenticated_arithmetic),
            )?;
        }
        node.validate_authenticated_replay()?;
        node.validate_authenticated_outbox()?;
        node.validate_native_budget_records_v1()?;
        node.validate_native_task_operation_pins_v1()?;
        node.validate_native_demand_evidence_v1()?;
        if observation_only {
            node.check_packet_observation_recovery()?;
        } else {
            node.recover()?;
        }
        node.read_active()?;
        crate::ancestry_index::validate_tip(&node.db, node.ancestry_context()?, node.active()?.0)?;
        Ok(node)
    