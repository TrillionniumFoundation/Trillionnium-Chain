#!/usr/bin/env python3
"""Exact F5 native compile gates; no native executable or test execution."""
from pathlib import Path
import hashlib, json, os, signal, stat, subprocess, sys, time, traceback
ROOT=Path("/data/chain-six-d9fb-20261108/publish-source")
OUT=Path("/data/chain-six-d9fb-20261108/evidence/final-integration/consensus-f5-native-compile")
HEAD="ab610cf95a6ec39b38e20e64e6367f5b529b3633"
TREE="abd4442d789b29889960f9b0acc712b9fefed498"
EXPECTED={"head":HEAD,"tree":TREE,"status":""}
TARGET=Path("/data/chain-six-d9fb-20261108/targets/root")
TMP=Path("/data/chain-six-d9fb-20261108/tmp-consensus-f5")
CARGO="/home/qian-qi/.cargo/bin/cargo"
PREFIX=Path("/home/qian-qi/workspace/pon-demand-acceptance-20261107-root525798dad3c2/build-runtime/trnm-pq-provider-3.5.9.DYf2qEaX/install")
OPENSSL=PREFIX/"bin/openssl"
PROVIDER_SHA="8ff7dd91270fd4a8fc377031f0fd2f2cee1cd17a32ce30e4fd773a25730a120f"
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE="1",PYTHONUNBUFFERED="1",GIT_NO_REPLACE_OBJECTS="1",GIT_NO_LAZY_FETCH="1",GIT_OPTIONAL_LOCKS="0",CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS="2",TMPDIR=str(TMP),OPENSSL_DIR=str(PREFIX),OPENSSL_STATIC="1",OPENSSL_CONF="/dev/null",OPENSSL_MODULES=str(PREFIX/"lib/ossl-modules"),TRNM_PQ_OPENSSL=str(OPENSSL))
def require(ok,message):
 if not ok: raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def file_hash(path):
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  before=os.fstat(fd);require(stat.S_ISREG(before.st_mode),"regular file required: "+str(path))
  digest=hashlib.sha256();size=0
  while True:
   block=os.read(fd,1024*1024)
   if not block:break
   digest.update(block);size+=len(block)
  after=os.fstat(fd)
  require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns) and size==after.st_size,"file changed during read: "+str(path))
  return {"bytes":size,"sha256":digest.hexdigest()}
 finally:os.close(fd)
def identity():
 return {k:subprocess.check_output(["git","--no-replace-objects",*a],cwd=ROOT,env=ENV,text=True).strip() for k,a in [("head",["rev-parse","HEAD"]),("tree",["rev-parse","HEAD^{tree}"]),("status",["status","--porcelain","--untracked-files=all"])]}
require(identity()==EXPECTED,"clean exact F5 required")
require(not OUT.exists() and not OUT.is_relative_to(ROOT),"new external output required")
OUT.mkdir(parents=True,exist_ok=False);TMP.mkdir(parents=True,exist_ok=True)
require(TARGET.is_dir() and not TARGET.is_relative_to(ROOT),"existing external exclusive target required")
report={"schema":"chain-six-f5-native-compile-validation-v1","source":EXPECTED,"root":str(ROOT),"output":str(OUT),"commands":[],"complete":False,"all_passed":False,"qualification":"HOLD_NO_GO","native_executable_or_test_execution":False,"original_native_observations_reinterpreted":False,"started_unix_ns":time.time_ns(),"per_command_timeout_seconds":1200,"resource_contract":{"cpu_quota_percent":200,"memory_max_bytes":8589934592,"nice":10,"cargo_jobs":2,"exclusive_cargo_target_dir":str(TARGET)}}
def save():
 (OUT/"validation.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
def execute(label,argv,timeout=1200):
 require(identity()==EXPECTED,"source before "+label)
 so=OUT/(label+".stdout");se=OUT/(label+".stderr")
 row={"label":label,"argv":argv,"cwd":str(ROOT),"timeout_seconds":timeout,"started_unix_ns":time.time_ns(),"state":"running"}
 report["commands"].append(row);save()
 print(json.dumps({"stage":label,"state":"running","argv":argv}),flush=True)
 start=time.monotonic()
 with so.open("xb") as stdout,se.open("xb") as stderr:
  process=None
  try:
   process=subprocess.Popen(argv,cwd=ROOT,env=ENV,stdout=stdout,stderr=stderr,start_new_session=True)
   try:row["exit_code"]=process.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    row.update(timed_out=True,exit_code=124)
    os.killpg(process.pid,signal.SIGTERM)
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:
     os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=10)
    row["terminated_process_returncode"]=process.returncode
  except OSError as error:
   stderr.write((repr(error)+"\n").encode());row.update(exit_code=127,launch_error=repr(error))
 row.update(elapsed_seconds=time.monotonic()-start,stdout=file_hash(so),stderr=file_hash(se),source_after=identity(),state="completed")
 row["passed"]=row.get("exit_code")==0 and row["source_after"]==EXPECTED
 save();print(json.dumps({"stage":label,"state":"completed","exit_code":row.get("exit_code"),"passed":row["passed"],"elapsed_seconds":row["elapsed_seconds"]}),flush=True)
 return row,so,se
before=None
try:
 row,_,_=execute("source-before",["/usr/bin/python3","-B","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",HEAD,"--output",str(OUT/"source-before.json")])
 require(row["passed"],"full source-before failed")
 before=json.loads((OUT/"source-before.json").read_bytes())
 row,_,_=execute("project-preflight",["bash","scripts/project-preflight.sh"])
 require(row["passed"],"project preflight failed")
 provider=file_hash(OPENSSL);require(provider["sha256"]==PROVIDER_SHA,"original 3.5.9 provider bytes changed")
 observations=[]
 for name,argv in [("provider-version",[str(OPENSSL),"version","-a"]),("cargo-version",[CARGO,"+1.95.0","--version"]),("rustc-version",["/home/qian-qi/.cargo/bin/rustc","+1.95.0","--version"])]:
  start=time.monotonic();p=subprocess.run(argv,cwd=ROOT,env=ENV,capture_output=True,timeout=30)
  (OUT/(name+".stdout")).write_bytes(p.stdout);(OUT/(name+".stderr")).write_bytes(p.stderr)
  observations.append({"label":name,"argv":argv,"exit_code":p.returncode,"elapsed_seconds":time.monotonic()-start,"stdout":{"bytes":len(p.stdout),"sha256":sha(p.stdout)},"stderr":{"bytes":len(p.stderr),"sha256":sha(p.stderr)}})
  require(p.returncode==0,"environment identity command failed: "+name)
  if name=="provider-version":require(p.stdout.startswith(b"OpenSSL 3.5.9 "),"provider version changed")
  if name=="cargo-version":require(p.stdout.startswith(b"cargo 1.95.0 "),"Cargo version changed")
  if name=="rustc-version":require(p.stdout.startswith(b"rustc 1.95.0 "),"rustc version changed")
 environment={"provider":provider,"provider_prefix":str(PREFIX),"observations":observations,"selected_env":{k:ENV[k]for k in ["CARGO_TARGET_DIR","CARGO_BUILD_JOBS","TMPDIR","OPENSSL_DIR","OPENSSL_STATIC","OPENSSL_CONF","OPENSSL_MODULES","TRNM_PQ_OPENSSL","GIT_NO_LAZY_FETCH","GIT_NO_REPLACE_OBJECTS","GIT_OPTIONAL_LOCKS","PYTHONDONTWRITEBYTECODE"]},"python_version":sys.version,"python_executable":str(Path(sys.executable).resolve()),"driver":file_hash(Path(__file__))}
 (OUT/"environment.json").write_text(json.dumps(environment,sort_keys=True,indent=2)+"\n");report["environment"]=environment;save()
 specs=[
 ("strict-clippy",[CARGO,"+1.95.0","clippy","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","-p","trnm-pon-node","--all-targets","--all-features","-j","2","--","-D","warnings"]),
 ("format-check",[CARGO,"+1.95.0","fmt","--manifest-path","trillionnium/Cargo.toml","--all","--","--check"]),
 ("metadata-default",[CARGO,"+1.95.0","metadata","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","--format-version","1"]),
 ("metadata-all-features",[CARGO,"+1.95.0","metadata","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","--all-features","--format-version","1"]),
 ("metadata-fuzz",[CARGO,"+1.95.0","metadata","--locked","--offline","--manifest-path","tests/fuzz/Cargo.toml","--format-version","1"])]
 for label,argv in specs:
  row,so,se=execute(label,argv)
  if label.startswith("metadata") and row["passed"]:
   try:
    value=json.loads(so.read_bytes());require(value["version"]==1 and isinstance(value["packages"],list) and bool(value["packages"]) and value.get("resolve")is not None,"full locked graph required")
    expected_workspace=ROOT/("tests/fuzz"if label=="metadata-fuzz"else"trillionnium")
    require(Path(value["workspace_root"])==expected_workspace,"metadata workspace mismatch")
    require(Path(value["target_directory"])==TARGET,"metadata target mismatch")
    members=set(value["workspace_members"]);require(len(members)==len(value["workspace_members"]) and bool(members),"workspace roster missing/duplicate")
    declared={p["id"]:p for p in value["packages"]};require(members<=set(declared),"workspace package absent")
    local=[p for p in value["packages"]if p["source"]is None]
    require(all(Path(p["manifest_path"]).is_relative_to(ROOT)for p in local),"external local package path")
    row["graph"]={"packages":len(value["packages"]),"workspace_members":len(members),"local_packages":[{"name":p["name"],"version":p["version"],"manifest_path":p["manifest_path"]}for p in local],"workspace_root":value["workspace_root"],"target_directory":value["target_directory"],"resolve_nodes":len(value["resolve"]["nodes"]),"full_metadata_sha256":row["stdout"]["sha256"]}
   except Exception as error:row.update(passed=False,reader_error={"type":type(error).__name__,"message":str(error)})
   save()
 report["complete"]=True
except BaseException as error:
 report["driver_error"]={"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}
finally:
 if before is not None:
  try:
   row,_,_=execute("source-after",["/usr/bin/python3","-B","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",HEAD,"--output",str(OUT/"source-after.json")])
   report["full_source_unchanged"]=row["passed"] and json.loads((OUT/"source-after.json").read_bytes())==before
  except Exception as error:report["source_after_error"]={"type":type(error).__name__,"message":str(error)}
 report["source_after"]=identity();report["finished_unix_ns"]=time.time_ns()
 expected_labels=["source-before","project-preflight","strict-clippy","format-check","metadata-default","metadata-all-features","metadata-fuzz","source-after"]
 report["all_passed"]=report["complete"] and [x["label"]for x in report["commands"]]==expected_labels and all(x.get("passed")is True for x in report["commands"]) and report.get("full_source_unchanged")is True and report["source_after"]==EXPECTED
 save();print(json.dumps({"complete":report["complete"],"all_passed":report["all_passed"],"source_unchanged":report.get("full_source_unchanged"),"failed_stages":[x["label"]for x in report["commands"]if not x.get("passed")],"driver_error":report.get("driver_error"),"qualification":"HOLD_NO_GO"}),flush=True)
sys.exit(0 if report["all_passed"]else 1)
