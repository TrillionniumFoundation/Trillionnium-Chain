#!/usr/bin/env python3
"""Run current49 only after a successful exact-source Node test build.

Invoke through run_current_exact.py to inherit the pinned runtime/provider:
  python3 run_current_exact.py required-controls python3 run_current_required_controls.py node-build
Old archived selectors establish roster continuity, never current execution.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import time

BASE = Path('/workspace/scratch/9d99fced0bf1')
ROOT = BASE / 'chain-current'
OUT = BASE / 'current-validation'
COMMIT = '59f75acd1d4261972b8aaa45e0c36259fcafd45c'
TREE = 'c0dc8282e5b2618ffb35061f108bb2fa96e9b348'
ROSTER = 'config/pon/pq-system-required-tests-v1.json'
BUILD_ARGV = ['cargo', 'test', '--locked', '--offline', '--manifest-path',
              'trillionnium/Cargo.toml', '-p', 'trnm-pon-node', '--all-features',
              '--lib', '--no-run', '--message-format=json']


def require(value, message):
    if not value:
        raise ValueError(message)


def sha256(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def source_now():
    result = subprocess.run([sys.executable, 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                             '--expected-head', COMMIT], cwd=ROOT, capture_output=True,
                            text=True, check=True)
    source = json.loads(result.stdout)
    require(source['tested_commit'] == COMMIT and source['tested_tree'] == TREE
            and source['tracked_worktree_verified'] is True, 'wrong or unverified current source')
    return source


def checked_receipt(label, source):
    receipt = json.loads((OUT / (label + '.json')).read_text())
    code = receipt.get('exit_code')
    require(receipt.get('schema') == 'trnm-pq-native-command-v1'
            and receipt.get('status') in ('command_succeeded', 'command_failed')
            and type(code) is int and ((code == 0) == (receipt['status'] == 'command_succeeded')),
            'incomplete or inconsistent command receipt: ' + label)
    require(receipt.get('before') == receipt.get('after') == source
            and receipt.get('cwd') == str(ROOT)
            and receipt.get('whole_chain_quantum_security_qualified') is False,
            'receipt does not belong to exact current source: ' + label)
    log = OUT / (label + '.log')
    require(receipt.get('log_file') == log.name and receipt.get('log_bytes') == log.stat().st_size
            and receipt.get('log_sha256') == sha256(log), 'log mismatch: ' + label)
    return receipt, log


def selected_controls():
    raw = (ROOT / ROSTER).read_bytes()
    committed = subprocess.check_output(['git', '--no-replace-objects', 'show', COMMIT + ':' + ROSTER], cwd=ROOT)
    require(raw == committed, 'current roster differs from fixed commit')
    manifest = json.loads(raw)
    tests = manifest['tests']
    require(len(tests) == len(set(tests)) == manifest['expected_meaningful_controls'] == 49,
            'requires all 49 unique current controls')
    require(all(re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*', x) for x in tests),
            'invalid exact selector')
    require(not set(tests) & set(manifest['child_process_harnesses_not_counted'])
            and manifest['whole_chain_quantum_security_qualified'] is False
            and manifest['original_business_budgets_changed'] is False, 'roster scope mismatch')
    with tarfile.open(ROOT / 'evidence/crypto-profile-20261104/raw-observations.tar.gz', 'r:gz') as archive:
        old = json.load(archive.extractfile('source-contracts/' + ROSTER))['tests']
    require(len(old) == len(set(old)) == 45 and [name for name in tests if name in set(old)] == old,
            'original 45 selectors or their relative order changed')
    return tests, hashlib.sha256(raw).hexdigest()


def binary_identity(path):
    require(path.is_file() and not path.is_symlink() and path.stat().st_size > 0
            and bool(path.stat().st_mode & 0o111), 'Node executable is unavailable')
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha256(path)}


def run(label):
    source = source_now()
    tests, roster_hash = selected_controls()
    receipt, log = checked_receipt(label, source)
    require(receipt['exit_code'] == 0 and receipt['argv'] == BUILD_ARGV,
            'Node build must succeed with the original complete command')
    require(not receipt['environment'].get('RUSTFLAGS')
            and not receipt['environment'].get('CARGO_ENCODED_RUSTFLAGS'), 'compiler overrides are outside this run')
    rows = []
    for line in log.read_text().splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if isinstance(row, dict):
            rows.append(row)
    require([r.get('success') for r in rows if r.get('reason') == 'build-finished'] == [True],
            'missing successful Cargo completion')
    artifacts = [r for r in rows if r.get('reason') == 'compiler-artifact'
                 and r.get('target', {}).get('name') == 'trnm_pon_node'
                 and r.get('profile', {}).get('test') is True and r.get('executable')]
    require(len(artifacts) == 1, 'expected exactly one Node lib-test executable')
    artifact = artifacts[0]
    require(Path(artifact['target']['src_path']).resolve() == ROOT / 'trillionnium/crates/trnm-pon-node/src/lib.rs'
            and set(artifact.get('features', [])) == {'default', 'pq-native-openssl'}, 'wrong Node source or feature set')
    binary = Path(artifact['executable']).resolve(strict=True)
    target = Path(receipt['environment']['CARGO_TARGET_DIR']).resolve(strict=True)
    require(binary.parent == target / 'debug/deps' and binary.name.startswith('trnm_pon_node-'),
            'executable is outside the reported original test target')
    identity = binary_identity(binary)
    outputs = ['node-test-binary.json', 'required-selector-results.json', 'required-control-batch.json']
    outputs += [f'required-{i:02d}{suffix}' for i in range(49)
                for suffix in ('.json', '.log', '-recorder.txt', '-execution.txt')]
    require(all(not (OUT / name).exists() for name in outputs), 'preserve the existing control attempt')
    details = {**identity, 'source': source, 'build_receipt_label': label,
               'build_receipt_sha256': sha256(OUT / (label + '.json')), 'artifact': artifact,
               'roster_sha256': roster_hash, 'runner_sha256': sha256(__file__),
               'binary_observation_scope': 'hash observed before and after this batch; Cargo receipt itself has no executable hash'}
    (OUT / 'node-test-binary.json').write_text(json.dumps(details, indent=2) + '\n')
    results = []
    (OUT / 'required-selector-results.json').write_text('[]\n')
    for index, selector in enumerate(tests):
        name = f'required-{index:02d}'
        argv = [str(binary), selector, '--exact', '--show-output', '--test-threads=1']
        started, utc = time.monotonic_ns(), datetime.now(timezone.utc).isoformat()
        recorder = [sys.executable, 'scripts/ci/record_pq_native_command.py', '--kind', 'head',
                    '--candidate', COMMIT, '--tested', COMMIT, '--label', name,
                    '--output', str(OUT), '--', *argv]
        with (OUT / (name + '-recorder.txt')).open('x') as stream:
            recorded = subprocess.run(recorder, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        observed, raw_log = checked_receipt(name, source)
        code = observed['exit_code']
        require(observed['argv'] == argv and recorded.returncode == (code if code >= 0 else 128 - code),
                'recorder and native outcome disagree')
        with (OUT / (name + '-execution.txt')).open('x') as stream:
            checked = subprocess.run([sys.executable, 'scripts/ci/check_required_native_test.py',
                                      str(raw_log), '--test', selector], cwd=ROOT,
                                     stdout=stream, stderr=subprocess.STDOUT)
        if checked.returncode == 0:
            require(json.loads((OUT / (name + '-execution.txt')).read_text()) == {
                'result': 'PASS', 'test': selector, 'executed_tests': 1,
                'scope': 'named-libtest-execution-only'}, 'unexpected named execution result')
        result = {'selector': selector, 'label': name, 'argv': argv, 'binary_sha256': identity['sha256'],
                  'build_receipt_label': label, 'started_utc': utc, 'elapsed_ns': time.monotonic_ns() - started,
                  'exit_code': code, 'recorder_exit_code': recorded.returncode,
                  'execution_check_exit_code': checked.returncode, 'log_sha256': observed['log_sha256']}
        results.append(result)
        (OUT / 'required-selector-results.json').write_text(json.dumps(results, indent=2) + '\n')
        print(json.dumps(result), flush=True)
    final_binary, final_source = binary_identity(binary), source_now()
    require(final_binary == identity and final_source == source, 'binary or source changed during batch')
    require(sha256(__file__) == details['runner_sha256'], 'runner changed during batch')
    passed = all(r['exit_code'] == r['recorder_exit_code'] == r['execution_check_exit_code'] == 0 for r in results)
    (OUT / 'required-control-batch.json').write_text(json.dumps({
        'schema': 'trnm-current49-batch-v1', 'complete': True, 'all_passed': passed,
        'executed': len(results), 'binary_before': identity, 'binary_after': final_binary,
        'source_before': source, 'source_after': final_source,
        'runner_sha256': details['runner_sha256']}, indent=2) + '\n')
    return 0 if passed else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('build_label', nargs='?', default='node-build')
    args = parser.parse_args()
    try:
        require(re.fullmatch(r'[A-Za-z0-9_-]{1,160}', args.build_label), 'invalid build receipt label')
        raise SystemExit(run(args.build_label))
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        print('REFUSED: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
