"""Run the real reporter with a selected subset or an actual failed assertion."""
from pathlib import Path
import sys
import unittest

root = Path('/workspace/scratch/a638c5cc4765/peer-lease-next/Trillionnium-Chain')
sys.path.insert(0, str(root))
from hia.tests.test_peer_lease import PeerLeaseValues

name = 'test_all_public_values_methods_clone_drop_and_isolation'
mode = sys.argv[1]
assert mode in ('partial', 'failure')
if mode == 'failure':
    original = getattr(PeerLeaseValues, name)
    def deliberately_failed(case):
        original(case)
        case.fail('deliberate complete-report refusal control')
    setattr(PeerLeaseValues, name, deliberately_failed)
suite = unittest.TestSuite([PeerLeaseValues(name)])
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
