## Purpose

This Draft continues #812 at `7e044b65454f4c9ea505591727332acffb33e7e5` and composes the fixed #799, #800, #801, #803, #798 and #806 heads as real Git merge ancestors. Independent branch results need a common source identity before their combined behavior can be assessed.

**Whole-chain PQ, PQ128, production activation and FinalUse remain HOLD / unqualified.** This is an implementation and evidence candidate.

## Changes

- Bind cached materialization to an independently pinned complete TCM2/CCH1 manifest. The same actual payload buffers feed the staged output and SHA-512 observer. Cumulative manifest/payload budgets precede cache/output operations, retain EOF and failed reservations, and use the original absolute deadline. Sixteen new controls retain the nonempty payload namespace and no-replace publication.
- Add explicit full-frame/padded-block-equivalent accounting to the actual P3 pruned mixed-height MMCS audit example, with an independent Python reader. Repeated calls, cached prefixes, full-message witness rechecks and artificial oracle overrides remain distinct; no measured permutation count or adversary lifetime bound is invented.
- Retain classical-owner rejection before durable effects, authenticated loader-byte controls, M12 recovery fencing, fixed-seal RISC Zero algebra replay, the curated authority/effect register, and the bounded dual-family root policy model from the fixed inputs.
- Rebind reviewed source records to actual Git blobs while retaining all prior paths, trace spans, unknown budget terms and false qualification flags. Repair the composed CI sequence expectations and add omission/order/refusal controls.

The sole plan and detailed scope are in `docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md` and `docs/security/PQ_COMPOSITION_20261108.md`. Concurrent root V2 work and #807 are outside this candidate.

## Validation status at Draft creation

All completed candidate campaigns below use `5633c55219c01c689f670c2ca35d122e39f3f791` / tree `3baafa8923d1a1e7bfb6f24cff9965a4e82fba4c`.

| Scope | Observed result |
| --- | --- |
| Source/model/refusal checks | 26 commands passed, including 603 unittest cases; matching raw source before/after |
| P3 MMCS native example | 18 tests passed; strict Clippy, format and dependency-source checks passed; independent reader reconciled 76 records |
| Owner guards | 4 green controls passed; removing each of the two guards produced the intended directory-snapshot assertion failure; source fully restored |
| Separate corrected-loader SQLite component | 13 library tests, 2 explicitly executed finite parents and 14 internal cases passed; actual layout cfg/v3 fence and raw source before/after checked |
| DA full default library | **412 passed, 3 failed, 0 ignored**; all 16 new cached-materialization controls passed; strict all-target/all-feature Clippy passed |
| Node default full library | **Aborted at the fixed 8 GiB free-disk threshold** (exit -15, not a timeout); its 1,298-test roster did not finish. M15 clock-expiry and M12 transaction-head failures were observed before the abort; no complete-suite pass count is asserted |
| Remaining full-native stages | Node Clippy, recovery/settlement/release, provider-pinned PQ Node build and workspace Clippy were blocked before build by the same free-disk gate. Locked default/all-feature/fuzz metadata and provider/source readbacks completed |

The full parent campaign has now ended with `FAILED_OR_BLOCKED`, six unsuccessful/blocked gates and matching raw source-before/source-after receipts. The free-disk threshold was not relaxed. Two original-ELF Node cases will be diagnosed separately; their results cannot replace the interrupted full run.

The P3 ledger contains 52 native cached-prefix records and 24 artificial-oracle records. Its 492 full-message recomputation equivalents are not measured Keccak permutations. The original historical unchanged-runtime gate still refuses this integrated runtime; its original scope was not weakened or relabeled as passed.

The original DA failures were each reproduced once using the original ELF. A separate, unmerged test-only child `f0e8dc919f10a5f1e7debca544aed9d14e75d96d` moves transient-client database setup before occupying bounded server workers and adds diagnostics to two other tests. Its three exact cases subsequently passed once. This does not replace the 412/3 full-suite result, establish the other two root causes, or represent a full 415-test execution of that child.

The separate SQLite run does not retroactively qualify the earlier owner/full-native binaries, whose build output retained an unqualified loader/layout warning.

## Evidence and remaining gates

`evidence/pon-pq-composition-20261108/` already retains source-preparation refusals, the first failed source attempt and the CI repair. The completed raw native packets, interrupted-run receipts and separate diagnostic outcomes will be added in an evidence-only follow-up after their manifests are reconciled. Failed, ignored, incomplete, expected-red and successful controls remain separate.

Open obligations include actual quantum commitment extraction/state restoration/shared-oracle/Fiat-Shamir and recursion mapping; full-lifetime adversary budgets; real root/recovery signature verification and custody/currentness; complete authority-to-effect and actual-loaded-byte closure; and the joint quantum work/consensus/network model. No whole-chain failure bound or security-bit claim is made.
