#!/usr/bin/env python3
"""Read retained campaign/F0 ZIP bytes; does not run or alter any workload."""
import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path


def checkpoint_cost(phase):
    imports = [h['client_import'] for h in phase.get('history', [])
               if isinstance(h.get('client_import'), dict)]
    result = dict(phase=phase.get('mode'), client_import_rows=len(imports),
                  succeeded_import_rows=sum(i.get('succeeded') is True for i in imports),
                  failed_import_rows=sum(i.get('succeeded') is False for i in imports),
                  caller_thread_cpu_ns_known_sum=0, caller_cpu_unknown_rows=0,
                  host_checkpoint_calls_started=0,
                  host_checkpoint_thread_cpu_ns_known_sum=0,
                  host_checkpoint_cpu_unknown_rows=0,
                  all_host_thread_cpu_ns_known_sum=0)
    for item in imports:
        cpu = item.get('thread_cpu_ns')
        if isinstance(cpu, int) and item.get('thread_cpu_observation_available', True):
            result['caller_thread_cpu_ns_known_sum'] += cpu
        else:
            result['caller_cpu_unknown_rows'] += 1
        checks = (item.get('native_import_observation') or {}).get('host_checks') or []
        checkpoint = [c for c in checks if c.get('phase') == 'checkpoint']
        if not checkpoint:
            result['host_checkpoint_cpu_unknown_rows'] += 1
        for check in checks:
            if isinstance(check.get('thread_cpu_ns'), int):
                result['all_host_thread_cpu_ns_known_sum'] += check['thread_cpu_ns']
        for check in checkpoint:
            result['host_checkpoint_calls_started'] += check.get('calls_started', 0)
            cpu = check.get('thread_cpu_ns')
            if isinstance(cpu, int) and check.get('cpu_clock_unknown_calls', 0) == 0:
                result['host_checkpoint_thread_cpu_ns_known_sum'] += cpu
            else:
                result['host_checkpoint_cpu_unknown_rows'] += 1
    numerator = result['host_checkpoint_thread_cpu_ns_known_sum']
    denominator = result['caller_thread_cpu_ns_known_sum']
    known = not result['caller_cpu_unknown_rows'] and not result['host_checkpoint_cpu_unknown_rows']
    result['host_checkpoint_fraction_of_caller_cpu'] = numerator / denominator if known and denominator else None
    return result


def summarize(path, provenance):
    archive_bytes = path.read_bytes()
    result = dict(schema='trnm-original-business-artifact-readback-v1',
                  provenance={**provenance, 'artifact_zip': str(path),
                              'artifact_zip_sha256': hashlib.sha256(archive_bytes).hexdigest()},
                  interpretation=dict(nested_intervals_not_additive=True,
                                      unknown_cpu_is_not_zero=True,
                                      source_is_original_artifact_no_rerun=True,
                                      production_tps_qualified=False),
                  reports=[], source_records=[], results=[])
    with zipfile.ZipFile(path) as archive:
        for name in archive.namelist():
            if re.fullmatch(r'run-[123]-raw/report\.json', name) or name == 'execution/raw/report.json':
                data = json.loads(archive.read(name))
                entry = dict(zip_entry=name,
                             report_sha256=hashlib.sha256(archive.read(name)).hexdigest(),
                             schema=data.get('schema'),
                             finite_experiment_criteria_met=data.get('finite_experiment_criteria_met'),
                             scope=data.get('scope'), phases=[])
                for phase in data.get('phases', []):
                    phase_entry = dict(mode=phase.get('mode'),
                        finite_phase_criteria_met=phase.get('finite_phase_criteria_met'),
                        all_signed_rounds_confirmed_in_window=phase.get('all_signed_rounds_confirmed_in_window'),
                        observer_complete=phase.get('observer_complete'),
                        actor_reports_successful_without_cap_or_kill=phase.get('actor_reports_successful_without_cap_or_kill'),
                        duration_seconds=phase.get('duration_seconds'),
                        confirmations=phase.get('confirmations'),
                        service_outcome=phase.get('service_outcome'),
                        host_checkpoint_cost=checkpoint_cost(phase))
                    entry['phases'].append(phase_entry)
                result['reports'].append(entry)
            elif name in ['execution/results.json', 'finalization/result.json'] or re.fullmatch(r'run-[123]-result\.json', name):
                data = json.loads(archive.read(name))
                result['results'].append(dict(zip_entry=name, data={k:v for k,v in data.items() if k not in ['files', 'step']}))
            elif name in ['source-before.json', 'source-after.json', 'source-before-campaigns.json',
                          'execution/source-before.json', 'execution/source-after.json'] or re.fullmatch(r'run-[123]-source-after\.json', name):
                result['source_records'].append(dict(zip_entry=name, data=json.loads(archive.read(name))))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('zip', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--run-id', type=int, required=True)
    parser.add_argument('--job-id', type=int, required=True)
    parser.add_argument('--artifact-id', type=int, required=True)
    parser.add_argument('--head', required=True)
    args = parser.parse_args()
    record = summarize(args.zip, dict(run_id=args.run_id, job_id=args.job_id,
                                     artifact_id=args.artifact_id, source_head=args.head))
    args.output.write_text(json.dumps(record, ensure_ascii=False, indent=2) + chr(10))
    print(json.dumps(dict(output=str(args.output), reports=len(record['reports']),
                          results=len(record['results']), sha256=hashlib.sha256(args.output.read_bytes()).hexdigest())))
