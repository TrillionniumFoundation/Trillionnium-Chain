#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/opensslv.h>
#include <stdio.h>
#include <string.h>
#if OPENSSL_VERSION_MAJOR != 3 || OPENSSL_VERSION_MINOR != 5 || OPENSSL_VERSION_PATCH != 9
#error Wrong OpenSSL headers
#endif
int main(void) {
    if (strcmp(OpenSSL_version(OPENSSL_VERSION), OPENSSL_VERSION_TEXT) != 0) return 1;
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_from_name(NULL, "ML-DSA-65", "provider=default");
    if (ctx == NULL) return 2;
    EVP_PKEY_CTX_free(ctx);
    printf("header=%s\nruntime=%s\nML-DSA-65=available\n", OPENSSL_VERSION_TEXT, OpenSSL_version(OPENSSL_VERSION));
    return 0;
}
