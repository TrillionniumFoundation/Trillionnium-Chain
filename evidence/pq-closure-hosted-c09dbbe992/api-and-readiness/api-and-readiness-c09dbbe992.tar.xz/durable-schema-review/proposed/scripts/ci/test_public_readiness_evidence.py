#!/usr/bin/env python3
"""Negative source, artifact, packet, observation and cost tests; no fabricated qualification."""
from __future__ import annotations
import copy
import hashlib
import json
import os
import re
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import check_public_readiness_evidence as check

# Frozen pre-lifecycle V2 bytes from fc23fa6de10380dd9ce9cae6cddd1db4d87551ce:
# store blob 97cb5b57e5dd4ad6572f9a619c4df125e7d8d024, ancestry blob
# ba54ff267db24e7dc1dbbaddf3561ca4b40f58ac. These are independent of the reader.
# The sole 629-byte extension was introduced by 8a35529679c3d176fd7586ab1ecf4e004f25af79;
# its distinct current schema identity must never accept the preserved old ID.
PRE_LIFECYCLE_BASE_DDL = "CREATE TABLE metadata(key TEXT PRIMARY KEY,value BLOB NOT NULL);\nCREATE TABLE blocks(id BLOB PRIMARY KEY,parent BLOB,height INTEGER NOT NULL,chainwork BLOB NOT NULL,packet BLOB,state_root BLOB NOT NULL);\nCREATE INDEX work_order ON blocks(chainwork DESC,height,id);\nCREATE TABLE deltas(block BLOB NOT NULL,key TEXT NOT NULL,before BLOB,after BLOB,PRIMARY KEY(block,key));\nCREATE TABLE active(singleton INTEGER PRIMARY KEY CHECK(singleton=1),tip BLOB NOT NULL,generation INTEGER NOT NULL,state_slot INTEGER NOT NULL);\nCREATE TABLE kv(slot INTEGER NOT NULL,key TEXT NOT NULL,value BLOB NOT NULL,PRIMARY KEY(slot,key));\nCREATE TABLE reorg(singleton INTEGER PRIMARY KEY CHECK(singleton=1),old_tip BLOB NOT NULL,new_tip BLOB NOT NULL,generation INTEGER NOT NULL,cursor INTEGER NOT NULL,done INTEGER NOT NULL);\nCREATE TABLE steps(ordinal INTEGER PRIMARY KEY,kind INTEGER NOT NULL,block BLOB NOT NULL);\nCREATE TABLE events(generation INTEGER NOT NULL,ordinal INTEGER NOT NULL,kind INTEGER NOT NULL,block BLOB NOT NULL,PRIMARY KEY(generation,ordinal));\nCREATE TABLE snapshots(block BLOB PRIMARY KEY,state BLOB NOT NULL);\nCREATE TABLE local_pool_metadata(singleton INTEGER PRIMARY KEY CHECK(singleton=1),context BLOB NOT NULL CHECK(length(context)=32),limits BLOB NOT NULL,gc_groups BLOB NOT NULL DEFAULT X'0000000000000000' CHECK(length(gc_groups)=8),gc_records BLOB NOT NULL DEFAULT X'0000000000000000' CHECK(length(gc_records)=8),gc_bytes BLOB NOT NULL DEFAULT X'0000000000000000' CHECK(length(gc_bytes)=8),gc_head BLOB NOT NULL DEFAULT X'0000000000000000000000000000000000000000000000000000000000000000' CHECK(length(gc_head)=32),checked_parent BLOB,checked_generation INTEGER,CHECK((checked_parent IS NULL AND checked_generation IS NULL) OR (length(checked_parent)=32 AND checked_generation>=0)));\nCREATE TABLE local_pool_groups(ordinal INTEGER PRIMARY KEY AUTOINCREMENT,id BLOB UNIQUE NOT NULL CHECK(length(id)=32),status INTEGER NOT NULL CHECK(status IN (0,1,2,3)),reason TEXT NOT NULL);\nCREATE TABLE local_pool_rows(group_id BLOB NOT NULL,position INTEGER NOT NULL CHECK(position>=0 AND position<16),digest BLOB UNIQUE NOT NULL CHECK(length(digest)=32),sender BLOB NOT NULL CHECK(length(sender)=32),nonce BLOB NOT NULL CHECK(length(nonce)=8),expiry BLOB NOT NULL CHECK(length(expiry)=8),fee_limit BLOB NOT NULL CHECK(length(fee_limit)=8),raw BLOB NOT NULL CHECK(length(raw)>0 AND length(raw)<=2048),PRIMARY KEY(group_id,position),FOREIGN KEY(group_id) REFERENCES local_pool_groups(id) ON DELETE CASCADE);\nCREATE TABLE local_pool_removals(ordinal INTEGER PRIMARY KEY AUTOINCREMENT,id BLOB UNIQUE NOT NULL CHECK(length(id)=32),group_id BLOB NOT NULL CHECK(length(group_id)=32),reason TEXT NOT NULL);\nCREATE TABLE peer_replay(session_id BLOB PRIMARY KEY,chain_id BLOB NOT NULL,protocol_digest BLOB NOT NULL,peer_id BLOB NOT NULL,profile_digest BLOB NOT NULL,generation INTEGER NOT NULL CHECK(generation>0),highest_ack INTEGER NOT NULL CHECK(highest_ack>=0),pending_nonce INTEGER,pending_digest BLOB,pending_bytes INTEGER, CHECK((pending_nonce IS NULL AND pending_digest IS NULL AND pending_bytes IS NULL) OR (pending_nonce IS NOT NULL AND pending_nonce>0 AND pending_digest IS NOT NULL AND pending_bytes>0)));\nCREATE TABLE peer_request_audit(session_id BLOB NOT NULL,nonce INTEGER NOT NULL CHECK(nonce>0),payload_digest BLOB NOT NULL,payload BLOB,response_digest BLOB,response BLOB,status INTEGER NOT NULL CHECK(status IN (0,1,2)),PRIMARY KEY(session_id,nonce),FOREIGN KEY(session_id) REFERENCES peer_replay(session_id));\nCREATE TABLE peer_outbox(session_id BLOB PRIMARY KEY,chain_id BLOB NOT NULL,protocol_digest BLOB NOT NULL,peer_id BLOB NOT NULL,profile_digest BLOB NOT NULL,generation INTEGER NOT NULL CHECK(generation>0),highest_ack INTEGER NOT NULL CHECK(highest_ack>=0),pending_nonce INTEGER,pending_digest BLOB,pending_bytes INTEGER,pending_payload BLOB,pending_wire BLOB,pending_wire_digest BLOB,CHECK((pending_nonce IS NULL AND pending_digest IS NULL AND pending_bytes IS NULL AND pending_payload IS NULL AND pending_wire IS NULL AND pending_wire_digest IS NULL) OR (pending_nonce IS NOT NULL AND pending_nonce>0 AND pending_digest IS NOT NULL AND pending_bytes>0 AND pending_payload IS NOT NULL AND pending_wire IS NOT NULL AND pending_wire_digest IS NOT NULL)));"
PRE_LIFECYCLE_INDEX_DDL = 'CREATE TABLE ancestry_jump(block BLOB NOT NULL CHECK(length(block)=32),level INTEGER NOT NULL CHECK(level>=0 AND level<63),ancestor BLOB NOT NULL CHECK(length(ancestor)=32),ancestor_height INTEGER NOT NULL CHECK(ancestor_height>=0),left_seal BLOB NOT NULL CHECK(length(left_seal)=32),right_seal BLOB NOT NULL CHECK(length(right_seal)=32),seal BLOB NOT NULL CHECK(length(seal)=32),PRIMARY KEY(block,level),FOREIGN KEY(block) REFERENCES blocks(id),FOREIGN KEY(ancestor) REFERENCES blocks(id)) WITHOUT ROWID;'
REORG_LIFECYCLE_DDL = "CREATE TABLE reorg_lifecycle_v1(operation INTEGER PRIMARY KEY AUTOINCREMENT,old_tip BLOB NOT NULL CHECK(length(old_tip)=32),new_tip BLOB NOT NULL CHECK(length(new_tip)=32),generation INTEGER NOT NULL CHECK(generation>0),old_slot INTEGER NOT NULL CHECK(old_slot>=0),old_root BLOB NOT NULL CHECK(length(old_root)=32),owner_context BLOB NOT NULL CHECK(length(owner_context)=32),outcome INTEGER NOT NULL CHECK(outcome IN (0,1,2)),cancelled_cursor INTEGER,reason TEXT NOT NULL CHECK(length(reason)<=96),CHECK((outcome IN (0,1) AND cancelled_cursor IS NULL AND reason='') OR (outcome=2 AND cancelled_cursor>=0 AND length(reason)>0)));\n"

# Source-contract excerpts copied from the same fc23 store blob, not derived
# by deleting PQ arms from current source. open_selected retains its exact
# schema-selection pair; the full original source is also checked in evidence.
PRE_PQ_BACKEND = '''
enum StateBackend {
    Legacy,
    AuthenticatedV1,
    PermanentAccountGrowthV2,
}
impl StateBackend {
    fn ddl(self) -> String {
        match self {
            Self::Legacy => ddl(),
            Self::AuthenticatedV1 => format!("{}{}", ddl(), native_authenticated::DDL),
            Self::PermanentAccountGrowthV2 => format!("{}{}", ddl(), growth::DDL),
        }
    }
    fn selected_schema_id(self, settings: &Settings) -> Hash {
        if growth_profile_v2::enabled(&settings.app) {
            hash(
                b"native-growth-reference-branch-schema-v2",
                &[self.ddl().as_bytes()],
            )
        } else {
            self.schema_id()
        }
    }
    fn schema_id(self) -> Hash {
        let domain: &[u8] = match self {
            Self::Legacy => b"native-branch-schema-v2",
            Self::AuthenticatedV1 => b"native-authenticated-branch-schema-v1",
            Self::PermanentAccountGrowthV2 => b"native-permanent-account-growth-schema-v2",
        };
        hash(domain, &[self.ddl().as_bytes()])
    }
}
'''
PRE_PQ_OPENERS = '''
impl Node {
fn open(path: &Path, settings: Settings, workers: usize) -> Result<Self> {
        Self::open_with_fault(path, settings, workers, None)
    }
fn open_with_fault(
        path: &Path,
        settings: Settings,
        workers: usize,
        hook: Option<&mut Hook<'_>>,
    ) -> Result<Self> {
        // The legacy opener is never a fallback for a required-policy namespace.
        ensure(!owner_marker_present(path)?, "OWNER_TASK_POLICY_REQUIRED")?;
        Self::open_inner(path, settings, workers, hook, None, None, None)
    }
fn open_inner(
        path: &Path,
        settings: Settings,
        workers: usize,
        hook: Option<&mut Hook<'_>>,
        owner_policy: Option<OwnerPolicy>,
        mining_owner: Option<operator_mining_owner::MiningOwner>,
        continuous_owner: Option<operator_continuous_owner::ContinuousOwner>,
    ) -> Result<Self> {
        Self::open_selected(
            path,
            settings,
            workers,
            hook,
            NativeOwners {
                policy: owner_policy,
                mining: mining_owner,
                continuous: continuous_owner,
            },
            StateBackend::Legacy,
            false,
        )
    }
fn open_with_authenticated_state(
        path: &Path,
        settings: Settings,
        workers: usize,
    ) -> Result<Self> {
        Self::open_with_authenticated_state_and_fault(path, settings, workers, None)
    }
fn open_with_authenticated_state_and_fault(
        path: &Path,
        settings: Settings,
        workers: usize,
        hook: Option<&mut Hook<'_>>,
    ) -> Result<Self> {
        ensure(!owner_marker_present(path)?, "OWNER_TASK_POLICY_REQUIRED")?;
        Self::open_selected(
            path,
            settings,
            workers,
            hook,
            NativeOwners {
                policy: None,
                mining: None,
                continuous: None,
            },
            StateBackend::AuthenticatedV1,
            false,
        )
    }
fn open_selected() {
        let ddl = state_backend.ddl();
        let schema_id = state_backend.selected_schema_id(&settings);
    }
}
'''

# An explicit closed-contract fixture for the retained feature-gated V1 reader.
# It is independent of the current V2/V3 source and of the reader's templates;
# these schema/parser controls do not certify a historical native execution.
PQ_V1_BACKEND = '''
enum StateBackend {
    Legacy,
    AuthenticatedV1,
    PermanentAccountGrowthV2,
    #[cfg(feature = "pq-native-openssl")]
    PqNetworkV1,
}
impl StateBackend {
    fn ddl(self) -> String {
        match self {
            Self::Legacy => ddl(),
            Self::AuthenticatedV1 => format!("{}{}", ddl(), native_authenticated::DDL),
            Self::PermanentAccountGrowthV2 => format!("{}{}", ddl(), growth::DDL),
            #[cfg(feature = "pq-native-openssl")]
            Self::PqNetworkV1 => format!("{}{}", ddl(), pq_network::DDL),
        }
    }
    fn selected_schema_id(self, settings: &Settings) -> Hash {
        if growth_profile_v2::enabled(&settings.app) {
            hash(b"native-growth-reference-branch-schema-v2", &[self.ddl().as_bytes()],)
        } else {
            self.schema_id()
        }
    }
    fn schema_id(self) -> Hash {
        let domain: &[u8] = match self {
            Self::Legacy => b"native-branch-schema-v2",
            Self::AuthenticatedV1 => b"native-authenticated-branch-schema-v1",
            Self::PermanentAccountGrowthV2 => b"native-permanent-account-growth-schema-v2",
            #[cfg(feature = "pq-native-openssl")]
            Self::PqNetworkV1 => b"native-pq-network-owner-schema-v1",
        };
        hash(domain, &[self.ddl().as_bytes()])
    }
}
'''


# Preserved V2/V3 mapping from the real 64cb26b53ed82be14049000387040ba119f00e1e
# store source (Git blob 83f998b), independent of deleting V4 from current source.
PQ_V2_V3_BACKEND = '''
enum StateBackend {
    Legacy,
    AuthenticatedV1,
    PermanentAccountGrowthV2,
    PqNetworkV2,
    PqContinuousV3,
}
impl StateBackend {
    fn ddl(self) -> String {
        match self {
            Self::Legacy => ddl(),
            Self::AuthenticatedV1 => format!("{}{}", ddl(), native_authenticated::DDL),
            Self::PermanentAccountGrowthV2 => format!("{}{}", ddl(), growth::DDL),
            Self::PqNetworkV2 | Self::PqContinuousV3 => format!("{}{}", ddl(), pq_network::DDL),
        }
    }
    fn selected_schema_id(self, settings: &Settings) -> Hash {
        if growth_profile_v2::enabled(&settings.app) {
            hash(b"native-growth-reference-branch-schema-v2", &[self.ddl().as_bytes()],)
        } else {
            self.schema_id()
        }
    }
    fn schema_id(self) -> Hash {
        let domain: &[u8] = match self {
            Self::Legacy => b"native-branch-schema-v2",
            Self::AuthenticatedV1 => b"native-authenticated-branch-schema-v1",
            Self::PermanentAccountGrowthV2 => b"native-permanent-account-growth-schema-v2",
            Self::PqNetworkV2 => b"native-pq-network-owner-schema-v2",
            Self::PqContinuousV3 => b"native-pq-continuous-owner-schema-v3",
        };
        hash(domain, &[self.ddl().as_bytes()])
    }
}
'''


class SourceAndArtifactTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)/'repo'; self.root.mkdir()
        self.git('init','-q'); self.git('config','user.email','fixture@example.invalid'); self.git('config','user.name','Fixture')
        for name in ['scripts/run.py','trillionnium/Cargo.toml','config/pon/task.json','.github/workflows/check.yml','docs/readme.md']:
            path = self.root/name; path.parent.mkdir(parents=True,exist_ok=True); path.write_text(name+'\n')
        self.git('add','.'); self.git('commit','-qm','real source fixture')
        self.commit = self.git('rev-parse','HEAD'); self.tree = self.git('rev-parse','HEAD^{tree}')
        self.report = {'source_commit':self.commit,'source_tree':self.tree,'source_files_sha256':check.source_inventory(self.root,self.commit)}
        self.manifest = {'implementation_commit':self.commit,'implementation_tree':self.tree}

    def tearDown(self): self.temporary.cleanup()
    def git(self,*args): return subprocess.check_output(['git',*args],cwd=self.root,text=True).strip()

    def test_real_git_source_control_is_valid_and_false_tree_or_hash_rejects(self):
        self.assertEqual(check.validate_source(self.root,self.report,self.manifest),self.commit)
        for field, value in [('source_tree','0'*40),('source_commit','0'*40)]:
            mutated = copy.deepcopy(self.report); mutated[field] = value
            with self.assertRaises((ValueError,subprocess.CalledProcessError)): check.validate_source(self.root,mutated,self.manifest)
        changed = copy.deepcopy(self.report); changed['source_files_sha256']['scripts/run.py'] = '0'*64
        with self.assertRaises(ValueError): check.validate_source(self.root,changed,self.manifest)

    def test_source_inventory_cannot_omit_script_config_or_workflow(self):
        for name in ['scripts/run.py','config/pon/task.json','.github/workflows/check.yml']:
            mutated = copy.deepcopy(self.report); del mutated['source_files_sha256'][name]
            with self.assertRaises(ValueError): check.validate_source(self.root,mutated,self.manifest)

    def test_current_bytes_new_untracked_runtime_and_symlink_reject(self):
        path = self.root/'scripts/run.py'; original = path.read_bytes()
        path.write_bytes(original+b'changed')
        with self.assertRaises(ValueError): check.validate_source(self.root,self.report,self.manifest)
        path.write_bytes(original)
        added = self.root/'scripts/new.py'; added.write_text('new')
        with self.assertRaises(ValueError): check.validate_source(self.root,self.report,self.manifest)
        added.unlink(); path.unlink(); path.symlink_to(self.root/'docs/readme.md')
        with self.assertRaises(ValueError): check.validate_source(self.root,self.report,self.manifest)

    def test_historical_source_check_does_not_silently_qualify_changed_current(self):
        (self.root/'scripts/run.py').write_text('changed current')
        self.assertEqual(check.validate_source(self.root,self.report,self.manifest,current=False),self.commit)
        with self.assertRaises(ValueError): check.validate_source(self.root,self.report,self.manifest,current=True)

    def test_preparation_uses_exact_measured_git_snapshot_after_root_publication(self):
        from prepare_evidence_sources import declarations
        for package in ['pon-v3','pon-v4','pon-evaluation-bundle-v1']:
            path=self.root/'evidence'/package/'manifest.json';path.parent.mkdir(parents=True)
            path.write_text(json.dumps(dict(implementation_commit=self.commit,implementation_tree=self.tree)))
        self.git('add','evidence');self.git('commit','-qm','measured declaration snapshot')
        measured=self.git('rev-parse','HEAD');tree=self.git('rev-parse','HEAD^{tree}')
        expected=declarations(self.root,source=measured)
        record=dict(verified_object_trees=expected,fetched=[],branch_refs_changed=False,acceptance_granted=False)
        path=self.root/'evidence/pon-public-readiness-v1/manifest.json';path.parent.mkdir(parents=True)
        path.write_text(json.dumps(dict(implementation_commit=measured,implementation_tree=tree)))
        self.git('add','evidence');self.git('commit','-qm','later evidence publication')
        self.assertNotEqual(declarations(self.root),expected)
        self.assertEqual(check.validate_source_preparation(self.root,json.dumps(record),measured),expected)
        changed=copy.deepcopy(record);changed['verified_object_trees']=declarations(self.root)
        with self.assertRaisesRegex(ValueError,'source-preparation scope'):
            check.validate_source_preparation(self.root,json.dumps(changed),measured)
        changed=copy.deepcopy(record);del changed['verified_object_trees'][self.commit]
        with self.assertRaisesRegex(ValueError,'source-preparation scope'):
            check.validate_source_preparation(self.root,json.dumps(changed),measured)
        for field in ['branch_refs_changed','acceptance_granted']:
            changed=copy.deepcopy(record);changed[field]=True
            with self.subTest(field=field),self.assertRaisesRegex(ValueError,'source-preparation scope'):
                check.validate_source_preparation(self.root,json.dumps(changed),measured)

    def test_source_pinned_environment_rejects_old_crypto_and_inconsistent_records(self):
        requirements=self.root/'formal/pon-nakamoto-v1/requirements.txt';requirements.parent.mkdir(parents=True)
        requirements.write_text('numpy==1.26.4\ncryptography==50.0.2\n')
        report={'environment':dict(python='3.12.14',numpy='1.26.4',cryptography='50.0.2',
                                  cryptography_openssl='OpenSSL 4.0.3',cffi='2.1.1')}
        baseline={'environment':dict(python='3.12.14',numpy='1.26.4',cryptography='50.0.2')}
        child=dict(executable='/isolated/venv/bin/python3',python='3.12.14',numpy='1.26.4',cryptography='50.0.2')
        report['environment']['child_python3']=copy.deepcopy(child)
        baseline['environment']['child_python3']=copy.deepcopy(child)
        check.validate_environment(self.root,report,baseline)
        for field,value in [('executable','python3'),('numpy','1.26.3'),('cryptography','41.0.7'),('python','3.12.13')]:
            changed=copy.deepcopy(report);changed['environment']['child_python3'][field]=value
            with self.subTest(child_field=field),self.assertRaisesRegex(ValueError,'child Python'):
                check.validate_environment(self.root,changed,baseline)
        changed=copy.deepcopy(report);changed['environment'].pop('child_python3')
        with self.assertRaisesRegex(ValueError,'missing child Python'):
            check.validate_environment(self.root,changed,baseline)
        for field,value in [('cryptography','41.0.7'),('numpy','1.26.3'),('python','3.12.13'),
                            ('python','3.12'),('cryptography_openssl',''),('cryptography_openssl',None),
                            ('cffi',' '),('cffi',False)]:
            changed=copy.deepcopy(report);changed['environment'][field]=value
            with self.subTest(field=field,value=value),self.assertRaises(ValueError):
                check.validate_environment(self.root,changed,baseline)
        old_report=copy.deepcopy(report);old_baseline=copy.deepcopy(baseline)
        old_report['environment']['cryptography']=old_baseline['environment']['cryptography']='41.0.7'
        with self.assertRaisesRegex(ValueError,'environment dependency pin cryptography'):
            check.validate_environment(self.root,old_report,old_baseline)
        requirements.write_text('numpy==1.26.4\ncryptography>=50\n')
        with self.assertRaisesRegex(ValueError,'missing or ambiguous environment pin cryptography'):
            check.validate_environment(self.root,report,baseline)

    def test_qualification_subprocess_ignores_a_poisoned_python_search_path(self):
        sys.path.insert(0,str(check.ROOT/'scripts'))
        from qualification_runtime import bind_python_runtime
        fake=self.root/'fake-bin';fake.mkdir()
        program=fake/'python3';program.write_text('#!/bin/sh\nexit 79\n');program.chmod(0o755)
        poisoned=dict(os.environ,PATH=str(fake)+os.pathsep+os.environ.get('PATH',''))
        self.assertEqual(subprocess.run(['python3','-c','pass'],env=poisoned).returncode,79)
        bound,observed=bind_python_runtime(poisoned)
        output=json.loads(subprocess.check_output(['python3','-c',
            'import sys,platform,json,numpy,cryptography; print(json.dumps(dict('
            'executable=sys.executable,python=platform.python_version(),numpy=numpy.__version__,'
            'cryptography=cryptography.__version__)))'],env=bound,text=True))
        self.assertEqual(output,observed)
        self.assertEqual(output['python'],sys.version.split()[0])

    def artifacts(self):
        folder = self.root/'evidence/test'; folder.mkdir(parents=True)
        (folder/'qualification.json').write_text('{}\n'); (folder/'result.bin').write_bytes(b'actual bytes')
        manifest = {'files':{name:check.sha((folder/name).read_bytes()) for name in ['qualification.json','result.bin']}}
        (folder/'manifest.json').write_text(json.dumps(manifest)); self.git('add','evidence')
        return folder,manifest

    def test_artifacts_must_exist_match_exact_inventory_and_be_tracked(self):
        folder,manifest = self.artifacts(); check.validate_artifacts(self.root,folder,manifest)
        (folder/'extra.log').write_text('unmanifested')
        with self.assertRaises(ValueError): check.validate_artifacts(self.root,folder,manifest)
        (folder/'extra.log').unlink(); (folder/'result.bin').write_bytes(b'mutated')
        with self.assertRaises(ValueError): check.validate_artifacts(self.root,folder,manifest)
        manifest['files']['result.bin'] = check.sha(b'mutated'); self.git('rm','--cached','-q','-f','evidence/test/result.bin')
        with self.assertRaises(ValueError): check.validate_artifacts(self.root,folder,manifest)

    def test_symlink_path_aliases_and_duplicate_json_are_refused(self):
        folder,manifest = self.artifacts()
        for name in ['../result.bin','./result.bin','result.bin/../qualification.json','/tmp/file','result\\bin']:
            with self.assertRaises(ValueError): check.safe(folder,name)
        (folder/'alias').symlink_to(folder/'result.bin')
        with self.assertRaises(ValueError): check.safe(folder,'alias')
        with self.assertRaises(ValueError): check.validate_artifacts(self.root,folder,manifest)
        with self.assertRaises(ValueError): json.loads('{"pass":false,"pass":true}',object_pairs_hook=check.unique)
        (folder/'invalid.json').write_text('{"elapsed":NaN}')
        with self.assertRaises(ValueError): check.load(folder/'invalid.json')
        linked = self.root/'linked'; linked.symlink_to(folder,target_is_directory=True)
        with self.assertRaises(ValueError): check.safe(linked/'nested','artifact.json')
        with self.assertRaises(ValueError): check.scope_flags({'nested':[{'public_network_ready':True}]})
        with self.assertRaises(ValueError): check.scope_flags({'production_activation':0})
        check.scope_flags({'nested':[{'public_network_ready':False}]})


class PacketAndObservationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        vectors = check.ROOT/'formal/pon-nakamoto-v1/vectors/accepted-block'
        tx = (vectors/'transaction.bin').read_bytes()
        cls.raw = (vectors/'header.bin').read_bytes()+b'\x01\x00'+len(tx).to_bytes(2,'little')+tx+(vectors/'work.bin').read_bytes()

    def test_actual_packet_frame_control_and_truncations_trailing_bytes_reject(self):
        header,txs,proof = check.decode_packet(self.raw)
        self.assertEqual((len(header),len(txs),len(proof)),(318,1,49188))
        for raw in [self.raw[:-1],self.raw+b'\x00',self.raw[:319],b'XXXX'+self.raw[4:],self.raw[:318]+b'\xff\xff'+self.raw[320:]]:
            with self.assertRaises(ValueError): check.decode_packet(raw)

    def test_hash_repair_does_not_replace_actual_transcript_verification(self):
        sys.path.insert(0,str(check.ROOT/'formal/pon-nakamoto-v1'))
        from contract_wire import H,header_decode
        from work_oracle import verify
        header,_,proof = check.decode_packet(self.raw); decoded = header_decode(header)
        verify(H('challenge',header),decoded['work_task'],decoded['target'],proof)
        altered = bytearray(proof); altered[100] ^= 1
        # A mutable manifest hash can be repaired, while the owner verifier still refuses.
        self.assertNotEqual(check.sha(proof),check.sha(altered))
        with self.assertRaises(ValueError): verify(H('challenge',header),decoded['work_task'],decoded['target'],bytes(altered))

    def test_twenty_block_tails_are_recomputed_and_p99_is_unavailable(self):
        summary = {'requested_blocks':20,'records':[{'intake_to_inclusion_ns':i+1,'intake_to_confirmation_ns':100+i} for i in range(20)]}
        summary['inclusion_latency_block_samples'] = check.quantiles(list(range(1,21)))
        summary['confirmation_latency_block_samples'] = check.quantiles(list(range(100,120)))
        check.validate_tails(summary)
        self.assertIsNone(summary['inclusion_latency_block_samples']['p99_ns'])
        for field in ['p95_ns','p99_ns','count']:
            changed = copy.deepcopy(summary); changed['inclusion_latency_block_samples'][field] = 999
            with self.assertRaises(ValueError): check.validate_tails(changed)
        changed = copy.deepcopy(summary); changed['requested_blocks'] = 19
        with self.assertRaises(ValueError): check.validate_tails(changed)

    def test_true_confirmations_bind_transaction_context_tip_depth_and_work(self):
        target = 2**255-1
        headers = [{'id':hashlib.sha256(str(i).encode()).hexdigest(),'timestamp':100+i,'target':target} for i in range(7)]
        summary = {k:'1'*64 for k in ('network','parameters','genesis')}
        row = {'block':headers[0]['id'],'height':1}; transaction = '2'*64
        fact = dict(summary,transaction=transaction,included_block=row['block'],included_height=1,observed_height=7,
                    observed_tip=headers[-1]['id'],depth=6,active_generation=7,reorged=False,finalized=False,execution_authority=False,
                    policy='installed-depth-and-required-work',work_delta=(12).to_bytes(64,'big').hex(),
                    required_work_delta=(12).to_bytes(64,'big').hex(),confirmed=True,observed_now=200)
        batch = {'observations':[fact]}; cumulative = list(range(0,16,2))
        check.validate_observations(batch,row,[transaction],summary,headers,cumulative,confirmed=True)
        for field,value in [('transaction','3'*64),('parameters','4'*64),('observed_tip',headers[5]['id']),('depth',5),
                            ('work_delta','00'*64),('confirmed',False),('finalized',True),('execution_authority',True)]:
            changed = copy.deepcopy(batch); changed['observations'][0][field] = value
            with self.assertRaises(ValueError): check.validate_observations(changed,row,[transaction],summary,headers,cumulative,confirmed=True)
        with self.assertRaises(ValueError): check.validate_observations({'observations':[]},row,[transaction],summary,headers,cumulative,confirmed=True)


class SocketAccountingTests(unittest.TestCase):
    def rows(self):
        rows = []
        for phase in ['baseline','unpaid_false_transcript','paid_false_transcript','slow_hello_occupancy']:
            paid = int(phase == 'paid_false_transcript'); cheap = int(phase == 'unpaid_false_transcript'); slow = int(phase == 'slow_hello_occupancy')
            streams = 0 if phase == 'baseline' else (3 if slow else 2)
            rows.append(dict(schema='transport-admission-sustained-cost-v2',phase=phase,bits=16,ttl_ms=2000,
                requested_attack_duration_ns=10_000_000_000,observed_wall_ns=10_001_000_000,attacker_streams=streams,
                attacker_observed_ns=[10_000_000_000]*streams,attack_connections=paid+cheap+2*slow,paid_full_work_rejections=paid,
                slow_preface_connections=2*slow,slow_partial_hello_connections=slow,slow_body_hello_connections=slow,
                request_template_bytes=100,attacker_body_bytes_successfully_written=100*(paid+cheap),
                attacker_body_write_success_count=paid+cheap,attacker_body_write_outcome_unknown_count=0,
                attacker_body_not_started_count=0,attack_transport_error_count=0,attack_transport_errors=[],
                cheap_rejections=cheap,busy_rejections=0,forged_ticket_hash_trials=paid+cheap,admission_hash_trials=paid,
                attacker_admission_solve_ns=100*paid,honest_submit_attempts=1,honest_valid_blocks=1,honest_submit_ns=[100],
                honest_submit_errors=[],honest_head_attempts=1,honest_head_ns=[50],honest_head_errors=[],
                metrics={'work_verifications':paid+1,'admission_rejected_before_work':cheap,'admission_accepted':paid+1}))
        return rows

    def log(self,rows):
        return 'test sustained_protected_socket_cost_campaign ... '+json.dumps(rows[0])+'\n'+ '\n'.join(json.dumps(r) for r in rows[1:])+'\nok\ntest result: ok. 1 passed; 0 failed; 0 ignored;\n'

    def test_actual_paid_unpaid_denominators_and_harness_control(self):
        rows = self.rows(); self.assertEqual(check.validate_socket_log(self.log(rows)),rows)
        for phase,field,value in [(1,'paid_full_work_rejections',1),(2,'admission_hash_trials',0),(2,'attack_connections',2),
                                  (1,'honest_submit_attempts',2),(2,'attacker_streams',1)]:
            changed = copy.deepcopy(rows); changed[phase][field] = value
            with self.assertRaises(ValueError): check.validate_socket_log(self.log(changed))
        with self.assertRaises(ValueError): check.validate_socket_log(self.log(rows).replace('1 passed','0 passed'))
        with self.assertRaises(ValueError): check.validate_socket_log(self.log(rows[:2]))

    def test_honest_failures_are_retained_in_denominator_without_fairness_claim(self):
        rows = self.rows(); row = rows[2]
        row['honest_submit_attempts'] = 2
        row['honest_submit_errors'] = [{'elapsed_ns':20,'error':'BUSY:work-capacity'}]
        check.validate_socket_log(self.log(rows))
        row['honest_submit_errors'] = []
        with self.assertRaises(ValueError): check.validate_socket_log(self.log(rows))
        rows = self.rows(); row = rows[2]
        row['attack_connections'] += 1; row['attack_transport_error_count'] = 1
        row['attack_transport_errors'] = ['ADMISSION_RESERVED_READ_ONLY']
        row['attacker_body_write_outcome_unknown_count'] = 1
        check.validate_socket_log(self.log(rows))
        row['attack_transport_errors'] = []
        with self.assertRaises(ValueError): check.validate_socket_log(self.log(rows))

    def test_baseline_template_bytes_and_honest_busy_outcomes_are_not_attack_cost(self):
        rows=self.rows();row=rows[0]
        self.assertGreater(row['request_template_bytes'],0)
        row['honest_submit_attempts']=2
        row['honest_submit_errors']=[{'elapsed_ns':20,'error':'BUSY:work-capacity'}]
        row['metrics']['admission_reserved_read_only_refusals']=502
        self.assertEqual(check.validate_socket_log(self.log(rows)),rows)
        row['honest_submit_errors']=[]
        with self.assertRaisesRegex(ValueError,'honest outcome denominator'):
            check.validate_socket_log(self.log(rows))
        rows=self.rows();rows[0]['request_template_bytes']=0
        with self.assertRaises(ValueError):check.validate_socket_log(self.log(rows))
        rows=self.rows();rows[1]['request_template_bytes']+=1
        with self.assertRaisesRegex(ValueError,'socket request template size'):
            check.validate_socket_log(self.log(rows))
        rows=self.rows();rows[0]['submitted_wire_bytes']=rows[0]['request_template_bytes']
        with self.assertRaisesRegex(ValueError,'socket request template size'):
            check.validate_socket_log(self.log(rows))

    def test_baseline_real_attack_counters_remain_strictly_zero(self):
        for field in ['attack_connections','paid_full_work_rejections','cheap_rejections','busy_rejections',
                      'slow_preface_connections','slow_partial_hello_connections','slow_body_hello_connections',
                      'attack_transport_error_count','forged_ticket_hash_trials','admission_hash_trials',
                      'attacker_admission_solve_ns','attacker_body_bytes_successfully_written',
                      'attacker_body_write_success_count','attacker_body_write_outcome_unknown_count',
                      'attacker_body_not_started_count']:
            with self.subTest(field=field):
                rows=self.rows();rows[0][field]=1
                with self.assertRaises(ValueError):check.validate_socket_log(self.log(rows))
        # Repair the aggregate denominator too: genuine unsolicited attack work
        # still cannot be presented as an otherwise consistent no-attacker phase.
        rows=self.rows();row=rows[0]
        row['attack_connections']=row['paid_full_work_rejections']=1
        row['admission_hash_trials']=row['attacker_admission_solve_ns']=1
        row['metrics']['work_verifications']+=1;row['metrics']['admission_accepted']+=1
        with self.assertRaisesRegex(ValueError,'baseline attack contamination'):
            check.validate_socket_log(self.log(rows))

    def test_attacker_body_bytes_keep_complete_writes_and_unknown_outcomes_separate(self):
        rows=self.rows();row=rows[2]
        # One completed body is followed by a failed challenge read; two other
        # requests fail in the opaque helper or before invoking that helper.
        row['attack_connections']+=3;row['attack_transport_error_count']=3
        row['attack_transport_errors']=['CHALLENGE_READ','HELPER_ERROR_UNKNOWN_BODY','CONNECT_ERROR']
        row['attacker_body_write_success_count']+=1
        row['attacker_body_bytes_successfully_written']+=row['request_template_bytes']
        row['attacker_body_write_outcome_unknown_count']=1;row['attacker_body_not_started_count']=1
        self.assertEqual(check.validate_socket_log(self.log(rows)),rows)
        for field in ['attacker_body_bytes_successfully_written','attacker_body_write_success_count',
                      'attacker_body_write_outcome_unknown_count','attacker_body_not_started_count']:
            with self.subTest(field=field):
                changed=copy.deepcopy(rows);changed[2][field]+=1
                with self.assertRaises(ValueError):check.validate_socket_log(self.log(changed))
        # Repair both sums, but falsely mark a server rejection as a request
        # whose body never finished writing: this still contradicts the outcome.
        changed=self.rows();row=changed[2]
        row['attacker_body_write_success_count']=row['attacker_body_bytes_successfully_written']=0
        row['attacker_body_write_outcome_unknown_count']=1
        with self.assertRaisesRegex(ValueError,'attacker body outcome accounting'):
            check.validate_socket_log(self.log(changed))
        changed=self.rows();changed[3]['attacker_body_not_started_count']=1
        with self.assertRaisesRegex(ValueError,'unexpected attacker body write'):
            check.validate_socket_log(self.log(changed))


class DurableStoreTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.folder = Path(self.temporary.name)
        sys.path.insert(0,str(check.ROOT/'formal/pon-nakamoto-v1'))
        from contract_wire import H,canonical
        self.H,self.canonical = H,canonical
        ddl, self.schema_domain = check.native_durable_schema(check.ROOT)
        self.state = {'test:exact':1}; self.roots = [bytes([i])*32 for i in range(1,5)]
        self.packets = []; self.cumulative = [0,2,4,6]
        self.summary = {'genesis':'3'*64,'parameters':'4'*64,'network':'6'*64,'records':[]}
        from contract_wire import header_encode
        parent = bytes.fromhex(self.summary['genesis'])
        # Actual current SQLite schema and exact native header/index formulas.
        # These opaque work bytes exercise only the durable-store stage; PoN
        # validity is separately checked by packet tests and full native replay.
        self.blocks = []
        for height in range(1,4):
            header = header_encode(dict(network=bytes.fromhex(self.summary['network']),
                parameters=bytes.fromhex(self.summary['parameters']),parent=parent,height=height,
                timestamp=height*10,target=bytes([255])*32,miner=bytes(32),transactions=bytes(32),
                state=self.roots[height],receipts=bytes(32),work_task=bytes(32),nonce=height))
            proof = bytes(49156)+H('owned-store-fixture-trace',height.to_bytes(8,'little'))
            packet = header+b'\x00\x00'+proof; block = H('block',header,proof[-32:])
            self.packets.append(packet); self.blocks.append((block,parent,height))
            self.summary['records'].append({'block':block.hex()}); parent = block
        self.summary['producer_final_state'] = {'tip':parent.hex()}
        for owner in ('producer','validator'):
            directory = self.folder/owner; directory.mkdir()
            with sqlite3.connect(directory/'native.sqlite') as database:
                database.executescript(ddl)
                database.executemany('INSERT INTO metadata VALUES(?,?)',[
                    ('schema',H(self.schema_domain,ddl.encode())),
                    ('parameters',bytes.fromhex(self.summary['parameters'])),('genesis',bytes.fromhex(self.summary['genesis']))])
                database.execute('INSERT INTO active VALUES(1,?,3,0)',(parent,))
                database.execute('INSERT INTO kv VALUES(0,?,?)',('test:exact',canonical(1)))
                database.execute('INSERT INTO blocks VALUES(?,NULL,0,?,NULL,?)',
                    (bytes.fromhex('3'*64),bytes(64),self.roots[0]))
                for block,previous,height in self.blocks:
                    database.execute('INSERT INTO blocks VALUES(?,?,?,?,?,?)',
                        (block,previous,height,self.cumulative[height].to_bytes(64,'big'),
                         self.packets[height-1],self.roots[height]))
                if self.schema_domain == 'native-branch-schema-v2':
                    index = {}; zero = bytes(32)
                    for block,previous,height in self.blocks:
                        for level in range(height.bit_length()):
                            if level == 0: ancestor,ancestor_height,left,right = previous,height-1,zero,zero
                            else:
                                half = index[(block,level-1)]; other = index[(half[0],level-1)]
                                ancestor,ancestor_height,left,right = other[0],other[1],half[4],other[4]
                            seal = H('native-derived-ancestry-row-v1',bytes.fromhex(self.summary['network']),
                                bytes.fromhex(self.summary['parameters']),bytes.fromhex(self.summary['genesis']),
                                block,previous,height.to_bytes(8,'little'),bytes([level]),ancestor,
                                ancestor_height.to_bytes(8,'little'),left,right)
                            row = (ancestor,ancestor_height,left,right,seal);index[(block,level)] = row
                            database.execute('INSERT INTO ancestry_jump VALUES(?,?,?,?,?,?,?)',(block,level,*row))
        self.summary['ledger_disk_bytes'] = sum(path.stat().st_size for path in self.folder.rglob('*') if path.is_file())

    def tearDown(self): self.temporary.cleanup()
    def verify(self):
        check.validate_durable_store(check.ROOT,self.folder,self.summary,self.packets,self.roots,self.cumulative,self.state,self.canonical,self.H)

    def test_owned_sqlite_control_and_changed_packet_or_work_reject(self):
        self.verify()
        self.summary['ledger_disk_bytes'] += 1
        with self.assertRaises(ValueError): self.verify()
        self.summary['ledger_disk_bytes'] -= 1
        with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
            database.execute('UPDATE blocks SET packet=? WHERE height=1',(b'forged bytes',))
        with self.assertRaises(ValueError): self.verify()
        with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
            database.execute('UPDATE blocks SET packet=?,chainwork=? WHERE height=1',(self.packets[0],bytes(64)))
        with self.assertRaises(ValueError): self.verify()

    def test_changed_published_state_and_injected_schema_reject(self):
        with sqlite3.connect(self.folder/'producer/native.sqlite') as database:
            database.execute('UPDATE kv SET value=?',(self.canonical(2),))
        with self.assertRaises(ValueError): self.verify()
        with sqlite3.connect(self.folder/'producer/native.sqlite') as database:
            database.execute('UPDATE kv SET value=?',(self.canonical(1),))
            database.execute('CREATE TRIGGER injected AFTER INSERT ON metadata BEGIN SELECT 1; END')
        with self.assertRaises(ValueError): self.verify()

    def assert_user_schema_object_rejected(self, kind, name, sql):
        # Real catalog objects, not source-text assertions. The complete fixture
        # still has valid metadata, state, packets and ancestry, and disk bytes
        # are remeasured so the schema boundary is the intended refusal.
        for owner in ('producer', 'validator'):
            path = self.folder/owner/'native.sqlite'
            with self.subTest(owner=owner,kind=kind,name=name):
                with sqlite3.connect(path) as database:
                    database.execute(sql)
                    actual = database.execute(
                        'SELECT type,name,sql FROM sqlite_master WHERE name=?', (name,)).fetchone()
                    self.assertEqual(actual[:2], (kind,name))
                    self.assertIsInstance(actual[2], str)
                    self.assertEqual(database.execute('PRAGMA integrity_check').fetchall(), [('ok',)])
                self.summary['ledger_disk_bytes'] = sum(path.stat().st_size for path in self.folder.rglob('*') if path.is_file())
                try:
                    with self.assertRaisesRegex(ValueError,'durable schema additions/omissions/changes'):
                        self.verify()
                finally:
                    with sqlite3.connect(path) as database:
                        database.execute('DROP '+kind.upper()+' "'+name+'"')
                    self.summary['ledger_disk_bytes'] = sum(path.stat().st_size for path in self.folder.rglob('*') if path.is_file())
                    self.verify()

    def test_sqlite_like_prefix_user_table_is_not_internal(self):
        self.assert_user_schema_object_rejected('table','sqliteXshadow',
            'CREATE TABLE sqliteXshadow(value BLOB NOT NULL)')

    def test_sqlite_like_prefix_user_index_is_not_internal(self):
        self.assert_user_schema_object_rejected('index','SqliteXshadow',
            'CREATE INDEX SqliteXshadow ON kv(key)')

    def test_sqlite_like_prefix_user_trigger_is_not_internal(self):
        self.assert_user_schema_object_rejected('trigger','SQLITEXshadow',
            'CREATE TRIGGER SQLITEXshadow AFTER INSERT ON metadata BEGIN SELECT 1; END')

    def test_sqlite_like_prefix_user_view_is_not_internal(self):
        self.assert_user_schema_object_rejected('view','sqlite7shadow',
            'CREATE VIEW sqlite7shadow AS SELECT key FROM metadata')

    def test_real_sqlite_internal_autoindexes_and_statistics_remain_supported(self):
        for owner in ('producer', 'validator'):
            with sqlite3.connect(self.folder/owner/'native.sqlite') as database:
                autoindexes = database.execute(
                    'SELECT name,sql FROM sqlite_master WHERE type="index"').fetchall()
                self.assertTrue(any(name.startswith('sqlite_autoindex_') and sql is None
                                    for name,sql in autoindexes))
                # ANALYZE creates the genuine reserved statistics table; callers
                # cannot create an ordinary table with this reserved spelling.
                database.execute('ANALYZE')
                self.assertEqual(database.execute(
                    'SELECT type,name FROM sqlite_master WHERE name="sqlite_stat1"').fetchone(),
                    ('table','sqlite_stat1'))
        self.summary['ledger_disk_bytes'] = sum(path.stat().st_size for path in self.folder.rglob('*') if path.is_file())
        self.verify()

    def test_current_v2_schema_and_complete_index_positive_control(self):
        self.assertEqual(self.schema_domain,'native-branch-schema-v2')
        self.verify()
        with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
            self.assertEqual(database.execute('SELECT count(*) FROM ancestry_jump').fetchone()[0],5)

    def test_v2_schema_metadata_cannot_use_legacy_hash_domain(self):
        ddl,_ = check.native_durable_schema(check.ROOT)
        with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
            database.execute("UPDATE metadata SET value=? WHERE key='schema'",
                             (self.H('native-branch-schema-v1',ddl.encode()),))
        with self.assertRaisesRegex(ValueError,'durable metadata/context'): self.verify()

    def test_current_lifecycle_store_cannot_use_preserved_pre_lifecycle_identity(self):
        old = bytes.fromhex('8c2627fa0b06e51742e7e6d40662c61d4b4727e810abc02b24634a8a817dc0e0')
        current = bytes.fromhex('9cfc36489e0ae98abd0110a9974d5c4f388cab91ebd701f93fba401830fb6658')
        self.verify()
        for owner in ('producer','validator'):
            with self.subTest(owner=owner):
                with sqlite3.connect(self.folder/owner/'native.sqlite') as database:
                    self.assertEqual(database.execute("SELECT value FROM metadata WHERE key='schema'").fetchone()[0],current)
                    database.execute("UPDATE metadata SET value=? WHERE key='schema'",(old,))
                with self.assertRaisesRegex(ValueError,'durable metadata/context'): self.verify()
                with sqlite3.connect(self.folder/owner/'native.sqlite') as database:
                    database.execute("UPDATE metadata SET value=? WHERE key='schema'",(current,))
                self.verify()

    def test_authenticated_domain_cannot_relabel_legacy_tables(self):
        ddl,_ = check.native_durable_schema(check.ROOT)
        with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
            database.execute("UPDATE metadata SET value=? WHERE key='schema'",
                             (self.H('native-authenticated-branch-schema-v1',ddl.encode()),))
        with self.assertRaisesRegex(ValueError,'durable metadata/context'): self.verify()

    def test_authenticated_tables_are_out_of_scope_even_with_resealed_metadata(self):
        ddl,domain = check.native_durable_schema(check.ROOT)
        extension = ('CREATE TABLE archive_nodes(id BLOB PRIMARY KEY,data BLOB NOT NULL);\n'
                     'CREATE TABLE native_state_commitments(block BLOB PRIMARY KEY,data BLOB NOT NULL);\n')
        original = self.H(domain,ddl.encode())
        for schema in (original,self.H(domain,(ddl+extension).encode()),
                       self.H('native-authenticated-branch-schema-v1',(ddl+extension).encode())):
            with self.subTest(schema=schema.hex()):
                with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
                    database.executescript(extension)
                    database.execute('INSERT INTO archive_nodes VALUES(?,?)',(bytes(32),b'unverified node'))
                    database.execute('INSERT INTO native_state_commitments VALUES(?,?)',(bytes(32),b'unverified commitment'))
                    database.execute("UPDATE metadata SET value=? WHERE key='schema'",(schema,))
                self.summary['ledger_disk_bytes'] = sum(path.stat().st_size for path in self.folder.rglob('*') if path.is_file())
                with self.assertRaisesRegex(ValueError,'durable schema additions/omissions/changes'): self.verify()
                with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
                    database.execute('DROP TABLE archive_nodes')
                    database.execute('DROP TABLE native_state_commitments')
                    database.execute("UPDATE metadata SET value=? WHERE key='schema'",(original,))
                self.summary['ledger_disk_bytes'] = sum(path.stat().st_size for path in self.folder.rglob('*') if path.is_file())
                self.verify()

    def test_growth_domains_cannot_relabel_legacy_tables(self):
        ddl,domain = check.native_durable_schema(check.ROOT)
        for foreign in ('native-growth-reference-branch-schema-v2',
                        'native-permanent-account-growth-schema-v2'):
            with self.subTest(domain=foreign):
                with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
                    database.execute("UPDATE metadata SET value=? WHERE key='schema'",
                                     (self.H(foreign,ddl.encode()),))
                with self.assertRaisesRegex(ValueError,'durable metadata/context'): self.verify()
        with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
            database.execute("UPDATE metadata SET value=? WHERE key='schema'",
                             (self.H(domain,ddl.encode()),))
        self.verify()

    def test_permanent_growth_tables_remain_out_of_scope_after_metadata_resealing(self):
        ddl,domain = check.native_durable_schema(check.ROOT)
        extension = ('CREATE TABLE archive_nodes(id BLOB PRIMARY KEY,data BLOB NOT NULL);\n'
                     'CREATE TABLE growth_states(block BLOB PRIMARY KEY,data BLOB NOT NULL);\n')
        original = self.H(domain,ddl.encode())
        for schema in (original,self.H(domain,(ddl+extension).encode()),
                       self.H('native-permanent-account-growth-schema-v2',(ddl+extension).encode())):
            with self.subTest(schema=schema.hex()):
                with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
                    database.executescript(extension)
                    database.execute('INSERT INTO archive_nodes VALUES(?,?)',(bytes(32),b'unverified node'))
                    database.execute('INSERT INTO growth_states VALUES(?,?)',(bytes(32),b'unverified growth state'))
                    database.execute("UPDATE metadata SET value=? WHERE key='schema'",(schema,))
                self.summary['ledger_disk_bytes'] = sum(path.stat().st_size for path in self.folder.rglob('*') if path.is_file())
                with self.assertRaisesRegex(ValueError,'durable schema additions/omissions/changes'): self.verify()
                with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
                    database.execute('DROP TABLE archive_nodes')
                    database.execute('DROP TABLE growth_states')
                    database.execute("UPDATE metadata SET value=? WHERE key='schema'",(original,))
                self.summary['ledger_disk_bytes'] = sum(path.stat().st_size for path in self.folder.rglob('*') if path.is_file())
                self.verify()

    def test_witness_namespace_and_checkpoint_do_not_qualify_legacy_evidence(self):
        ddl,domain = check.native_durable_schema(check.ROOT)
        extension = ('CREATE TABLE pq_witness_checkpoint_v1(singleton INTEGER PRIMARY KEY CHECK(singleton=1),'
                     'sequence INTEGER NOT NULL CHECK(sequence>0),root BLOB NOT NULL CHECK(length(root)=64));')
        original = self.H(domain,ddl.encode())
        foreign = 'native-pq-network-witness-schema-v4'
        # Relabelling the ordinary database with the new domain cannot upgrade
        # the dump to external-witness or whole-owner evidence.
        with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
            database.execute("UPDATE metadata SET value=? WHERE key='schema'",
                             (self.H(foreign,ddl.encode()),))
        with self.assertRaisesRegex(ValueError,'durable metadata/context'): self.verify()
        for schema in (original,self.H(domain,(ddl+extension).encode()),
                       self.H(foreign,(ddl+extension).encode())):
            with self.subTest(schema=schema.hex()):
                with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
                    database.executescript(extension)
                    database.execute('INSERT INTO pq_witness_checkpoint_v1 VALUES(1,1,?)',(bytes(64),))
                    database.execute("UPDATE metadata SET value=? WHERE key='schema'",(schema,))
                self.summary['ledger_disk_bytes'] = sum(path.stat().st_size for path in self.folder.rglob('*') if path.is_file())
                with self.assertRaisesRegex(ValueError,'durable schema additions/omissions/changes'): self.verify()
                with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
                    database.execute('DROP TABLE pq_witness_checkpoint_v1')
                    database.execute("UPDATE metadata SET value=? WHERE key='schema'",(original,))
                self.summary['ledger_disk_bytes'] = sum(path.stat().st_size for path in self.folder.rglob('*') if path.is_file())
                self.verify()

    def test_resealed_wrong_half_link_is_not_accepted_as_derived_structure(self):
        block,previous,height = self.blocks[1]
        with sqlite3.connect(self.folder/'validator/native.sqlite') as database:
            ancestor,ancestor_height,_,right,_ = database.execute(
                'SELECT ancestor,ancestor_height,left_seal,right_seal,seal FROM ancestry_jump WHERE block=? AND level=1',(block,)).fetchone()
            left = bytes([9])*32
            seal = self.H('native-derived-ancestry-row-v1',bytes.fromhex(self.summary['network']),
                bytes.fromhex(self.summary['parameters']),bytes.fromhex(self.summary['genesis']),
                block,previous,height.to_bytes(8,'little'),bytes([1]),ancestor,
                ancestor_height.to_bytes(8,'little'),left,right)
            database.execute('UPDATE ancestry_jump SET left_seal=?,seal=? WHERE block=? AND level=1',(left,seal,block))
        with self.assertRaisesRegex(ValueError,'ancestry derived row/half-link/seal'): self.verify()

    def test_missing_extra_or_changed_derived_rows_are_refused(self):
        for mode in ('missing','extra','seal','ancestor'):
            with self.subTest(mode=mode):
                database = sqlite3.connect(self.folder/'validator/native.sqlite')
                try:
                    row = database.execute('SELECT * FROM ancestry_jump WHERE level=1 LIMIT 1').fetchone()
                    if mode == 'missing':
                        database.execute('DELETE FROM ancestry_jump WHERE block=? AND level=?',row[:2])
                    elif mode == 'extra':
                        database.execute('INSERT INTO ancestry_jump VALUES(?,?,?,?,?,?,?)',(row[0],2,*row[2:]))
                    elif mode == 'seal':
                        database.execute('UPDATE ancestry_jump SET seal=? WHERE block=? AND level=?',(bytes(32),*row[:2]))
                    else:
                        database.execute('UPDATE ancestry_jump SET ancestor=? WHERE block=? AND level=?',(bytes([8])*32,*row[:2]))
                    database.commit()
                    with self.assertRaisesRegex(ValueError,'ancestry derived row'): self.verify()
                finally:
                    database.execute('DELETE FROM ancestry_jump WHERE block=? AND level=2',(row[0],))
                    database.execute('DELETE FROM ancestry_jump WHERE block=? AND level=?',row[:2])
                    database.execute('INSERT INTO ancestry_jump VALUES(?,?,?,?,?,?,?)',row)
                    database.commit(); database.close()
        self.verify()

class NativeDurableSchemaTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.store = self.root/'trillionnium/crates/trnm-pon-node/src/store.rs'
        self.store.parent.mkdir(parents=True)
        self.index = self.store.with_name('ancestry_index.rs')
        self.current = (check.ROOT/'trillionnium/crates/trnm-pon-node/src/store.rs').read_text()
        self.current_index = (check.ROOT/'trillionnium/crates/trnm-pon-node/src/ancestry_index.rs').read_text()

    def tearDown(self): self.temporary.cleanup()

    def extract(self, source, index=None):
        self.store.write_text(source)
        self.index.write_text(self.current_index if index is None else index)
        return check.native_durable_schema(self.root)

    def replace_once(self, source, before, after):
        self.assertEqual(source.count(before),1,'source control must target exactly one occurrence: '+before)
        return source.replace(before,after,1)

    def historical_backend(self):
        return ('const BASE_DDL: &str = "'+PRE_LIFECYCLE_BASE_DDL+'";\n'
                'fn ddl() -> String { format!("{}{}", BASE_DDL, crate::ancestry_index::DDL) }\n'+
                PRE_PQ_BACKEND+PRE_PQ_OPENERS)

    def historical_pq_backend(self):
        source = self.historical_backend().replace(PRE_PQ_BACKEND,PQ_V1_BACKEND)
        for owner in ('continuous_owner','None'):
            source = self.replace_once(source,'continuous: '+owner+',',
                                       'continuous: '+owner+', pq_network: None,')
        return source

    def historical_canonical_backend(self):
        source = self.historical_backend().replace(PRE_PQ_BACKEND,PQ_V2_V3_BACKEND)
        for owner in ('continuous_owner','None'):
            source = self.replace_once(source,'continuous: '+owner+',',
                                       'continuous: '+owner+', pq_network: None,')
        return source

    def test_historical_three_variant_backend_keeps_exact_contract_and_bytes(self):
        sys.path.insert(0,str(check.ROOT/'formal/pon-nakamoto-v1'))
        from contract_wire import H
        source = self.historical_backend()
        index = 'const DDL: &str = "'+PRE_LIFECYCLE_INDEX_DDL+'";'
        ddl,domain = self.extract(source,index)
        self.assertEqual(ddl,PRE_LIFECYCLE_BASE_DDL+PRE_LIFECYCLE_INDEX_DDL)
        self.assertEqual(len(ddl.encode()),4775)
        self.assertEqual(H(domain,ddl.encode()).hex(),
                         '8c2627fa0b06e51742e7e6d40662c61d4b4727e810abc02b24634a8a817dc0e0')
        for noncode in ('\n// PqNetworkV1 pq_network\n',
                        '\nconst NOTE: &str = "PqNetworkV1 pq_network";\n',
                        '\nconst NOTE: &str = r##"PqNetworkV1 pq_network"##;\n'):
            with self.subTest(noncode=noncode):
                self.assertEqual(self.extract(source+noncode,index),(ddl,domain))
        for before,after in [
            ('b"native-branch-schema-v2"','b"native-authenticated-branch-schema-v1"'),
            ('Self::Legacy => ddl(),','Self::Legacy => format!("{}{}", ddl(), growth::DDL),'),
            ('StateBackend::Legacy,','StateBackend::AuthenticatedV1,'),
            ('let ddl = state_backend.ddl();','let ddl = ddl();'),
        ]:
            with self.subTest(mutation=before),self.assertRaisesRegex(ValueError,'durable backend'):
                self.extract(self.replace_once(source,before,after),index)

    def test_backend_generations_cannot_mix_or_downgrade(self):
        source = self.historical_backend()
        index = 'const DDL: &str = "'+PRE_LIFECYCLE_INDEX_DDL+'";'
        guard = '#[cfg(feature = "pq-native-openssl")]'
        variant = guard+'\n    PqNetworkV1,'
        ddl = guard+'\n            Self::PqNetworkV1 => format!("{}{}", ddl(), pq_network::DDL),'
        domain = guard+'\n            Self::PqNetworkV1 => b"native-pq-network-owner-schema-v1",'
        # A remaining implementation, owner field or module keeps selection on
        # the complete PQ contract; malformed PQ cannot retry the old template.
        old = self.historical_pq_backend()
        self.assertEqual(self.extract(old,index),self.extract(source,index))
        for removed in [(variant,), (ddl,), (domain,), (variant,ddl,domain)]:
            changed = old
            for arm in removed:
                changed = self.replace_once(changed,arm,'')
            with self.subTest(removed=removed),self.assertRaisesRegex(ValueError,'durable backend'):
                self.extract(changed,index)
        for added in ('\nmod pq_network {}\n', '\nfn retain(_: PqNetworkV1) {}\n',
                      '\nfn retain(_: PqNetworkV2) {}\n',
                      '\nstruct Owners { pq_network: Option<Vec<u8>> }\n'):
            with self.subTest(added=added),self.assertRaisesRegex(ValueError,'durable backend variants'):
                self.extract(source+added,index)
        for before,after in [
            ('PermanentAccountGrowthV2,\n}', 'PermanentAccountGrowthV2,\n'+variant+'\n}'),
            ('PermanentAccountGrowthV2,\n}', 'PermanentAccountGrowthV2,\n    PqNetworkV2,\n    PqContinuousV3,\n}'),
            ('Self::Legacy => ddl(),','Self::Legacy => ddl(),\n'+ddl),
            ('continuous: continuous_owner,','continuous: continuous_owner, pq_network: None,'),
        ]:
            with self.subTest(mixed=before),self.assertRaisesRegex(ValueError,'durable backend'):
                self.extract(self.replace_once(source,before,after),index)
        canonical = ('PqNetworkV2,','PqContinuousV3,',
                     'Self::PqNetworkV2 | Self::PqContinuousV3 => format!("{}{}", ddl(), pq_network::DDL),',
                     'Self::PqNetworkV2 => b"native-pq-network-owner-schema-v2",',
                     'Self::PqContinuousV3 => b"native-pq-continuous-owner-schema-v3",')
        for removed in [(arm,) for arm in canonical]+[canonical]:
            changed = self.current
            for arm in removed:
                changed = self.replace_once(changed,arm,'')
            with self.subTest(canonical_removed=removed),self.assertRaisesRegex(ValueError,'durable backend'):
                self.extract(changed)
        for added in ('\nfn retain(_: PqNetworkV2) {}\n','\nfn retain(_: PqContinuousV3) {}\n'):
            with self.subTest(added=added),self.assertRaisesRegex(ValueError,'durable backend'):
                self.extract(old+added,index)
        with self.assertRaisesRegex(ValueError,'durable backend mixed PQ generations'):
            self.extract(self.current+'\nfn retain(_: PqNetworkV1) {}\n')

    def test_historical_literal_v1_and_inline_composed_v2_stay_supported(self):
        ddl = 'CREATE TABLE exact(key BLOB);'
        v1 = 'const DDL : &str = "'+ddl+'";fn open(){let id=hash(b"native-branch-schema-v1", &[ DDL.as_bytes() ]);}'
        index_ddl = 'CREATE TABLE jumps(key BLOB);'
        index = 'const DDL: &str = "'+index_ddl+'";'
        v2 = ('const BASE_DDL: &str = "'+ddl+'";'
              'fn ddl() -> String { format!("{}{}", BASE_DDL, crate::ancestry_index::DDL) }'
              'fn open(){ let ddl = ddl(); let id = hash(b"native-branch-schema-v2", &[ddl.as_bytes()]); }')
        self.assertEqual(self.extract(v1),(ddl,'native-branch-schema-v1'))
        self.assertEqual(self.extract(v2,index),(ddl+index_ddl,'native-branch-schema-v2'))
        # Mentioning the new type in non-code must not select its parser branch.
        noncode = '\n// StateBackend\nconst NOTE: &str = r#"StateBackend"#;\n'
        self.assertEqual(self.extract(v2+noncode,index),(ddl+index_ddl,'native-branch-schema-v2'))
        for label,source in [('v1-wrong-domain',v1.replace('native-branch-schema-v1','native-branch-schema-v2')),
                             ('v1-auth-domain',v1.replace('native-branch-schema-v1','native-authenticated-branch-schema-v1')),
                             ('v1-duplicate',v1+v1),('v1-missing-literal',v1.replace('const DDL','const OTHER')),
                             ('v2-wrong-domain',v2.replace('native-branch-schema-v2','native-branch-schema-v1')),
                             ('v2-auth-domain',v2.replace('native-branch-schema-v2','native-authenticated-branch-schema-v1')),
                             ('v2-unknown-domain',v2.replace('native-branch-schema-v2','native-branch-schema-unknown')),
                             ('v2-incomplete',v2.replace('format!("{}{}", BASE_DDL, crate::ancestry_index::DDL)','format!("{}", BASE_DDL)')),
                             ('v2-reversed',v2.replace('BASE_DDL, crate::ancestry_index::DDL','crate::ancestry_index::DDL, BASE_DDL'))]:
            with self.subTest(label=label),self.assertRaises(ValueError): self.extract(source,index)
        for source,domain in [(v1,'native-branch-schema-v1'),(v2,'native-branch-schema-v2')]:
            broken = source.replace(domain,'native-branch-schema-unknown')
            for decoy in ['\n// '+source+'\n','\nconst NOTE: &str = '+json.dumps(source)+';\n',
                          '\nconst NOTE: &str = r##"'+source+'"##;\n']:
                with self.subTest(domain=domain,decoy=decoy),self.assertRaises(ValueError):
                    self.extract(broken+decoy,index)

    def test_current_backend_returns_the_exact_preserved_legacy_bytes(self):
        sys.path.insert(0,str(check.ROOT/'formal/pon-nakamoto-v1'))
        from contract_wire import H
        ddl,domain = self.extract(self.current)
        self.assertEqual(domain,'native-branch-schema-v2')
        # Preserve the independent 4775-byte pre-lifecycle vector exactly.
        # Current native storage added one explicit lifecycle table; its old
        # identity remains historical and cannot authorize the current store.
        historical_source = ('const BASE_DDL: &str = "'+PRE_LIFECYCLE_BASE_DDL+'";'
            'fn ddl() -> String { format!("{}{}", BASE_DDL, crate::ancestry_index::DDL) }'
            'fn open(){ let ddl = ddl(); hash(b"native-branch-schema-v2", &[ddl.as_bytes()]); }')
        historical_index = 'const DDL: &str = "'+PRE_LIFECYCLE_INDEX_DDL+'";'
        preserved,preserved_domain = self.extract(historical_source,historical_index)
        self.assertEqual(preserved_domain,'native-branch-schema-v2')
        self.assertEqual(preserved,PRE_LIFECYCLE_BASE_DDL+PRE_LIFECYCLE_INDEX_DDL)
        self.assertEqual(len(preserved.encode()),4775)
        self.assertEqual(H(preserved_domain,preserved.encode()).hex(),
                         '8c2627fa0b06e51742e7e6d40662c61d4b4727e810abc02b24634a8a817dc0e0')
        expected = self.replace_once(preserved,'CREATE TABLE steps(',REORG_LIFECYCLE_DDL+'CREATE TABLE steps(')
        self.assertEqual(len(REORG_LIFECYCLE_DDL.encode()),629)
        self.assertEqual(ddl,expected)
        self.assertEqual(len(ddl.encode()),5404)
        self.assertEqual(H(domain,ddl.encode()).hex(),
                         '9cfc36489e0ae98abd0110a9974d5c4f388cab91ebd701f93fba401830fb6658')
        self.assertNotRegex(ddl,r'archive_nodes|native_state_commitments')
        changed = self.replace_once(self.current,'format!("{}{}", BASE_DDL, crate::ancestry_index::DDL)',
                                    'format!("{}", BASE_DDL)')
        with self.assertRaisesRegex(ValueError,'durable V2 schema composition'): self.extract(changed)

    def test_backend_domains_and_composition_fail_closed(self):
        legacy = 'b"native-branch-schema-v2"'
        authenticated = 'b"native-authenticated-branch-schema-v1"'
        auth_arm = 'Self::AuthenticatedV1 => format!("{}{}", ddl(), native_authenticated::DDL),'
        mutations = [
            ('legacy-v1',legacy,'b"native-branch-schema-v1"'),
            ('legacy-auth',legacy,authenticated),('auth-legacy',authenticated,legacy),
            ('legacy-unknown',legacy,'b"native-branch-schema-unknown"'),
            ('auth-unknown',authenticated,'b"native-authenticated-branch-schema-unknown"'),
            ('literal-space',legacy,'b"native-branch- schema-v2"'),
            ('legacy-extension','Self::Legacy => ddl(),','Self::Legacy => format!("{}{}", ddl(), native_authenticated::DDL),'),
            ('auth-omitted',auth_arm,'Self::AuthenticatedV1 => ddl(),'),
            ('auth-reversed',auth_arm,'Self::AuthenticatedV1 => format!("{}{}", native_authenticated::DDL, ddl()),'),
            ('auth-format',auth_arm,'Self::AuthenticatedV1 => format!("{}", ddl(), native_authenticated::DDL),'),
            ('unselected-hash','hash(domain, &[self.ddl().as_bytes()])','hash(domain, &[ddl().as_bytes()])'),
            ('extra-hash-input','hash(domain, &[self.ddl().as_bytes()])','hash(domain, &[self.ddl().as_bytes(), b"extra"])'),
            ('shadowed-domain','hash(domain, &[self.ddl().as_bytes()])','let domain = b"other"; hash(domain, &[self.ddl().as_bytes()])'),
            ('extra-variant','enum StateBackend {\n    Legacy,\n    AuthenticatedV1,','enum StateBackend {\n    Legacy,\n    AuthenticatedV1,\n    Other,'),
            ('wildcard',auth_arm,'_ => format!("{}{}", ddl(), native_authenticated::DDL),'),
            ('wrong-impl-owner','impl StateBackend {','impl StateBackend for Other {'),
        ]
        for label,before,after in mutations:
            with self.subTest(label=label),self.assertRaises(ValueError):
                self.extract(self.replace_once(self.current,before,after))
        backend = self.current[self.current.index('impl StateBackend {'):self.current.index('\nstruct NativeOwners {')]
        with self.assertRaisesRegex(ValueError,'durable source body StateBackend'):
            self.extract(self.current+'\n'+backend)

    def test_permanent_growth_mapping_is_exact_without_qualifying_its_storage(self):
        ddl,domain = self.extract(self.current)
        self.assertEqual(domain,'native-branch-schema-v2')
        self.assertNotRegex(ddl,r'archive_nodes|native_state_commitments|growth_states')
        growth = 'b"native-permanent-account-growth-schema-v2"'
        arm = 'Self::PermanentAccountGrowthV2 => format!("{}{}", ddl(), growth::DDL),'
        mutations = [
            ('domain-legacy',growth,'b"native-branch-schema-v2"'),
            ('domain-authenticated',growth,'b"native-authenticated-branch-schema-v1"'),
            ('domain-gsc2',growth,'b"native-growth-reference-branch-schema-v2"'),
            ('domain-unknown',growth,'b"native-permanent-account-growth-schema-unknown"'),
            ('domain-literal-space',growth,'b"native-permanent-account-growth- schema-v2"'),
            ('growth-omitted',arm,'Self::PermanentAccountGrowthV2 => ddl(),'),
            ('growth-authenticated',arm,'Self::PermanentAccountGrowthV2 => format!("{}{}", ddl(), native_authenticated::DDL),'),
            ('growth-reversed',arm,'Self::PermanentAccountGrowthV2 => format!("{}{}", growth::DDL, ddl()),'),
            ('growth-format',arm,'Self::PermanentAccountGrowthV2 => format!("{} {}", ddl(), growth::DDL),'),
            ('growth-format-arity',arm,'Self::PermanentAccountGrowthV2 => format!("{}", ddl(), growth::DDL),'),
            ('growth-wildcard',arm,'_ => format!("{}{}", ddl(), growth::DDL),'),
            ('legacy-growth','Self::Legacy => ddl(),','Self::Legacy => format!("{}{}", ddl(), growth::DDL),'),
        ]
        for label,before,after in mutations:
            with self.subTest(label=label),self.assertRaisesRegex(ValueError,'durable backend'):
                self.extract(self.replace_once(self.current,before,after))

    def test_pq_mapping_is_exact_without_qualifying_its_storage(self):
        ddl,domain = self.extract(self.current)
        self.assertEqual(domain,'native-branch-schema-v2')
        self.assertEqual(len(ddl.encode()),5404)
        self.assertNotRegex(ddl,r'pq_network_peer_v1|pq_network_request_v1')
        pq = 'b"native-pq-network-owner-schema-v2"'
        prefix = 'Self::PqNetworkV2 | Self::PqContinuousV3'
        arm = prefix+' => format!("{}{}", ddl(), pq_network::DDL),'
        mutations = [
            ('domain-legacy',pq,'b"native-branch-schema-v2"'),
            ('domain-authenticated',pq,'b"native-authenticated-branch-schema-v1"'),
            ('domain-growth',pq,'b"native-permanent-account-growth-schema-v2"'),
            ('domain-unknown',pq,'b"native-pq-network-owner-schema-unknown"'),
            ('domain-literal-space',pq,'b"native-pq-network-owner- schema-v2"'),
            ('domain-v1',pq,'b"native-pq-network-owner-schema-v1"'),
            ('domain-v3',pq,'b"native-pq-continuous-owner-schema-v3"'),
            ('pq-omitted',arm,prefix+' => ddl(),'),
            ('pq-authenticated',arm,prefix+' => format!("{}{}", ddl(), native_authenticated::DDL),'),
            ('pq-reversed',arm,prefix+' => format!("{}{}", pq_network::DDL, ddl()),'),
            ('pq-format',arm,prefix+' => format!("{} {}", ddl(), pq_network::DDL),'),
            ('pq-format-arity',arm,prefix+' => format!("{}", ddl(), pq_network::DDL),'),
            ('pq-only-v2',arm,'Self::PqNetworkV2 => format!("{}{}", ddl(), pq_network::DDL),'),
            ('pq-v1',arm,'Self::PqNetworkV1 => format!("{}{}", ddl(), pq_network::DDL),'),
            ('pq-wildcard',arm,'_ => format!("{}{}", ddl(), pq_network::DDL),'),
            ('legacy-pq','Self::Legacy => ddl(),','Self::Legacy => format!("{}{}", ddl(), pq_network::DDL),'),
        ]
        for label,before,after in mutations:
            with self.subTest(label=label),self.assertRaisesRegex(ValueError,'durable backend'):
                self.extract(self.replace_once(self.current,before,after))

    def test_preserved_canonical_backend_and_noncode_witness_mentions_remain_exact(self):
        source = self.historical_canonical_backend()
        expected = self.extract(self.historical_backend())
        self.assertEqual(self.extract(source),expected)
        for noncode in ('\n// PqWitnessV4 pq_witness pq_rollback_witness\n',
                        '\nconst NOTE: &str = "PqWitnessV4 pq_witness pq_rollback_witness";\n',
                        '\nconst NOTE: &str = r##"PqWitnessV4 pq_witness pq_rollback_witness"##;\n'):
            with self.subTest(noncode=noncode):
                self.assertEqual(self.extract(source+noncode),expected)
        # Code-level witnesses must select the complete V4 contract; a partial
        # removal cannot quietly fall back to the preserved V2/V3 mapping.
        for added in ('\nfn retain(_: PqWitnessV4) {}\n', '\nmod pq_rollback_witness {}\n',
                      '\nstruct Owners { pq_witness: Option<WitnessClient> }\n'):
            with self.subTest(added=added),self.assertRaisesRegex(ValueError,'durable backend variants'):
                self.extract(source+added)
        with self.assertRaisesRegex(ValueError,'durable backend mixed PQ generations'):
            self.extract(self.historical_pq_backend()+'\nfn retain(_: PqWitnessV4) {}\n')

    def test_witness_v4_mapping_is_exact_and_only_legacy_schema_is_exported(self):
        ddl,domain = self.extract(self.current)
        self.assertEqual(domain,'native-branch-schema-v2')
        self.assertEqual(len(ddl.encode()),5404)
        self.assertNotRegex(ddl,r'pq_network_|pq_witness_|archive_nodes|native_state_commitments|growth_states')
        witness = 'b"native-pq-network-witness-schema-v4"'
        composition = 'format!("{}{}{}", ddl(), pq_network::DDL, pq_rollback_witness::DDL)'
        for replacement in ('native-pq-network-owner-schema-v2','native-pq-continuous-owner-schema-v3',
                            'native-branch-schema-v2','native-pq-network-witness-schema-v3',
                            'native-pq-network-witness- schema-v4'):
            with self.subTest(domain=replacement),self.assertRaisesRegex(ValueError,'durable backend domain PqWitnessV4'):
                self.extract(self.replace_once(self.current,witness,'b"'+replacement+'"'))
        for replacement in ('format!("{}{}", ddl(), pq_network::DDL)',
                            'format!("{}{}{}", ddl(), pq_rollback_witness::DDL, pq_network::DDL)',
                            'format!("{}{}{}", ddl(), pq_network::DDL, growth::DDL)',
                            'format!("{}{}", ddl(), pq_network::DDL, pq_rollback_witness::DDL)',
                            'format!("{} {}{}", ddl(), pq_network::DDL, pq_rollback_witness::DDL)',
                            'ddl()'):
            with self.subTest(composition=replacement),self.assertRaisesRegex(ValueError,'durable backend composition'):
                self.extract(self.replace_once(self.current,composition,replacement))
        for arm in ('    PqWitnessV4,',
                    'Self::PqWitnessV4 => {\n                '+composition+'\n            }',
                    'Self::PqWitnessV4 => '+witness+','):
            for replacement in ('', '#[cfg(feature = "pq-native-openssl")]\n'+arm, '#[cfg(test)]\n'+arm):
                with self.subTest(arm=arm,replacement=replacement),self.assertRaisesRegex(ValueError,'durable backend'):
                    self.extract(self.replace_once(self.current,arm,replacement))

    def test_witness_owner_cannot_enter_ordinary_openers(self):
        for name,end_marker in [('open_inner','    fn open_selected('),
                                 ('open_with_authenticated_state_and_fault','    /// Explicit local operator policy')]:
            start = self.current.index('fn '+name+'(')
            end = self.current.index(end_marker,start)
            opener = self.current[start:end]
            for replacement in ('', 'pq_witness: other_owner,', 'pq_witness: Some(client),'):
                with self.subTest(opener=name,replacement=replacement),self.assertRaisesRegex(ValueError,'durable backend opener'):
                    changed = self.replace_once(opener,'pq_witness: None,',replacement)
                    self.extract(self.replace_once(self.current,opener,changed))

    def test_canonical_continuous_namespace_and_always_compiled_mapping_are_exact(self):
        domain = 'b"native-pq-continuous-owner-schema-v3"'
        for replacement in ('native-pq-network-owner-schema-v2','native-pq-network-owner-schema-v1',
                            'native-branch-schema-v2','native-authenticated-branch-schema-v1',
                            'native-permanent-account-growth-schema-v2',
                            'native-pq-continuous-owner-schema-unknown','native-pq-continuous-owner- schema-v3'):
            with self.subTest(domain=replacement),self.assertRaisesRegex(ValueError,'durable backend domain'):
                self.extract(self.replace_once(self.current,domain,'b"'+replacement+'"'))
        for arm in ('    PqNetworkV2,','    PqContinuousV3,',
                    'Self::PqNetworkV2 | Self::PqContinuousV3 => format!("{}{}", ddl(), pq_network::DDL),',
                    'Self::PqNetworkV2 => b"native-pq-network-owner-schema-v2",',
                    'Self::PqContinuousV3 => b"native-pq-continuous-owner-schema-v3",'):
            for guard in ('#[cfg(feature = "pq-native-openssl")]',
                          '#[cfg(feature = "unknown-feature")]','#[cfg(test)]'):
                with self.subTest(arm=arm,guard=guard),self.assertRaisesRegex(ValueError,'durable backend'):
                    self.extract(self.replace_once(self.current,arm,guard+'\n'+arm))

    def test_pq_feature_guards_and_ordinary_owner_inputs_are_exact(self):
        old = self.historical_pq_backend()
        guard = '#[cfg(feature = "pq-native-openssl")]'
        arms = [
            ('variant',guard+'\n    PqNetworkV1,'),
            ('ddl',guard+'\n            Self::PqNetworkV1 => format!("{}{}", ddl(), pq_network::DDL),'),
            ('domain',guard+'\n            Self::PqNetworkV1 => b"native-pq-network-owner-schema-v1",'),
        ]
        for label,arm in arms:
            for mutation,replacement in [
                ('wrong-feature',arm.replace('pq-native-openssl','unapproved-native-feature')),
                ('missing-guard',arm.replace(guard,'')),
                ('inverted-guard',arm.replace(guard,'#[cfg(not(feature = "pq-native-openssl"))]')),
                ('broadened-guard',arm.replace(guard,'#[cfg(any(feature = "pq-native-openssl", test))]')),
            ]:
                with self.subTest(arm=label,mutation=mutation),self.assertRaisesRegex(ValueError,'durable backend'):
                    self.extract(self.replace_once(old,arm,replacement))
        for name,end_marker in [('open_inner','    fn open_selected('),
                                 ('open_with_authenticated_state_and_fault','    /// Explicit local operator policy')]:
            start = self.current.index('fn '+name+'(')
            end = self.current.index(end_marker,start)
            opener = self.current[start:end]
            for replacement in ('pq_network: Some(Vec::new()),','pq_network: other_owner,',''):
                with self.subTest(opener=name,replacement=replacement),self.assertRaisesRegex(ValueError,'durable backend opener'):
                    changed = self.replace_once(opener,'pq_network: None,',replacement)
                    self.extract(self.replace_once(self.current,opener,changed))

    def test_pq_tables_cannot_be_inserted_into_legacy_literals(self):
        for name in ('pq_network_peer_v1','pq_network_request_v1','Pq_NeTwOrK_PeEr_V1','Pq_NeTwOrK_ReQuEsT_V1',
                     'pq_network_resource_v2','pq_network_peer_v2','pq_network_request_v2',
                     'Pq_NeTwOrK_ReSoUrCe_V2','Pq_NeTwOrK_ReQuEsT_V2',
                     'pq_network_future_owner_v99','pq_network_unreviewed_extension',
                     'pq_witness_checkpoint_v1','Pq_WiTnEsS_ChEcKpOiNt_V1','pq_witness_future_v99'):
            extension = 'CREATE TABLE '+name+'(id BLOB PRIMARY KEY,data BLOB NOT NULL);'
            literal = 'const DDL: &str = "'+extension+'";'
            v1 = literal+'fn open() { hash(b"native-branch-schema-v1", &[DDL.as_bytes()]); }'
            sources = [
                (v1,None),
                (self.replace_once(self.current,'CREATE TABLE metadata',extension+'CREATE TABLE metadata'),None),
                (self.current,self.replace_once(self.current_index,'CREATE TABLE ancestry_jump',extension+'CREATE TABLE ancestry_jump')),
            ]
            for source,index in sources:
                with self.subTest(name=name,index=index is not None),self.assertRaisesRegex(ValueError,'authenticated tables in legacy durable schema'):
                    self.extract(source,index)

    def test_permanent_growth_table_cannot_be_inserted_into_legacy_literals(self):
        for name in ('growth_states','GrOwTh_StAtEs'):
            extension = 'CREATE TABLE '+name+'(block BLOB PRIMARY KEY,data BLOB NOT NULL);'
            literal = 'const DDL: &str = "'+extension+'";'
            v1 = literal+'fn open() { hash(b"native-branch-schema-v1", &[DDL.as_bytes()]); }'
            sources = [
                (v1,None),
                (self.replace_once(self.current,'CREATE TABLE metadata',extension+'CREATE TABLE metadata'),None),
                (self.current,self.replace_once(self.current_index,'CREATE TABLE ancestry_jump',extension+'CREATE TABLE ancestry_jump')),
            ]
            for source,index in sources:
                with self.subTest(name=name,index=index is not None),self.assertRaisesRegex(ValueError,'tables in legacy durable schema'):
                    self.extract(source,index)

    def test_actual_opener_and_selected_schema_bindings_cannot_be_replaced(self):
        pair = 'let ddl = state_backend.ddl();\n        let schema_id = state_backend.selected_schema_id(&settings);'
        mutations = [
            ('default-open','Self::open_with_fault(path, settings, workers, None)',
             'Self::open_with_authenticated_state_and_fault(path, settings, workers, None)'),
            ('fault-open','Self::open_inner(path, settings, workers, hook, None, None, None)',
             'Self::open_with_authenticated_state_and_fault(path, settings, workers, hook)'),
            ('legacy-selected','StateBackend::Legacy,\n            false,\n        )\n    }\n    fn open_selected',
             'StateBackend::AuthenticatedV1,\n            false,\n        )\n    }\n    fn open_selected'),
            ('auth-selected','StateBackend::AuthenticatedV1,\n            false,\n        )\n    }\n    /// Explicit local operator policy',
             'StateBackend::Legacy,\n            false,\n        )\n    }\n    /// Explicit local operator policy'),
            ('legacy-observation','StateBackend::Legacy,\n            false,\n        )\n    }\n    fn open_selected',
             'StateBackend::Legacy,\n            true,\n        )\n    }\n    fn open_selected'),
            ('auth-observation','StateBackend::AuthenticatedV1,\n            false,\n        )\n    }\n    /// Explicit local operator policy',
             'StateBackend::AuthenticatedV1,\n            true,\n        )\n    }\n    /// Explicit local operator policy'),
            ('ddl-unselected','let ddl = state_backend.ddl();','let ddl = ddl();'),
            ('schema-unselected','let schema_id = state_backend.selected_schema_id(&settings);','let schema_id = StateBackend::Legacy.schema_id();'),
            ('nested-pair',pair,'if false { '+pair+' }'),
        ]
        for label,before,after in mutations:
            with self.subTest(label=label),self.assertRaisesRegex(ValueError,'durable backend (?:opener|selected schema)'):
                self.extract(self.replace_once(self.current,before,after))
        rebound = [
            'let state_backend = StateBackend::AuthenticatedV1;',
            'let settings = settings;',
            'let (settings, _) = (settings, ());',
            'let ddl = StateBackend::AuthenticatedV1.ddl();',
            'let mut ddl = StateBackend::AuthenticatedV1.ddl();',
            'let ddl: String = StateBackend::AuthenticatedV1.ddl();',
            'let schema_id: Hash = StateBackend::AuthenticatedV1.schema_id();',
            'let (ddl, schema_id) = (StateBackend::AuthenticatedV1.ddl(), StateBackend::AuthenticatedV1.schema_id());',
            'let (state_backend, _) = (StateBackend::AuthenticatedV1, ());',
            'state_backend = StateBackend::AuthenticatedV1;',
            'ddl = StateBackend::AuthenticatedV1.ddl();',
            'schema_id = StateBackend::AuthenticatedV1.schema_id();',
            'schema_id[0] = 0;',
        ]
        for statement in rebound:
            with self.subTest(statement=statement),self.assertRaisesRegex(ValueError,'durable backend selected schema rebound'):
                self.extract(self.replace_once(self.current,pair,pair+'\n        '+statement))

    def test_legacy_and_authenticated_openers_cannot_enable_growth_observation_mode(self):
        for backend, after in (('Legacy', 'fn open_selected'),
                               ('AuthenticatedV1', '/// Explicit local operator policy')):
            tail = '\n        )\n    }\n    '+after
            current = 'StateBackend::'+backend+',\n            false,'+tail
            for replacement in ('true', 'observation_only', 'false || true',
                                '{ false }', 'false, true'):
                changed = 'StateBackend::'+backend+',\n            '+replacement+','+tail
                with self.subTest(backend=backend, replacement=replacement), \
                        self.assertRaisesRegex(ValueError, 'durable backend opener'):
                    self.extract(self.replace_once(self.current,current,changed))

    def test_existing_owner_split_cannot_change_ordinary_selection_or_schema_scope(self):
        mode = 'SelectedOpen::InitializeOrRecover { observation_only },'
        for replacement in ('SelectedOpen::ExistingPqOwner,',
                            mode.replace('observation_only }', 'observation_only: true }'),
                            mode.replace('observation_only }', 'observation_only: false }')):
            with self.subTest(mode=replacement), self.assertRaisesRegex(ValueError,'durable backend selected delegation'):
                self.extract(self.replace_once(self.current,mode,replacement))
        call = ('Self::open_selected_mode(\n            path,\n            settings,\n'
                '            workers,\n            hook,\n            owners,\n'
                '            state_backend,')
        for before,after in [('            settings,','            settings.clone(),'),
                             ('            owners,','            other_owners,'),
                             ('            state_backend,','            StateBackend::PqWitnessV4,')]:
            with self.subTest(argument=before), self.assertRaisesRegex(ValueError,'durable backend selected delegation'):
                self.extract(self.replace_once(self.current,call,call.replace(before,after)))
        for replacement in ('(true, false)', '(false, false)', '(existing_owner_only, true)'):
            before = 'SelectedOpen::ExistingPqOwner => (false, true),'
            with self.subTest(flags=replacement), self.assertRaisesRegex(ValueError,'durable backend selected mode binding'):
                self.extract(self.replace_once(self.current,before,'SelectedOpen::ExistingPqOwner => '+replacement+','))

    def test_partial_split_and_rebound_mode_cannot_fall_back_to_legacy_opener(self):
        for before,after in [
            ('    ExistingPqOwner,',''),
            ('    ExistingPqOwner,','    ExistingPqOwner, OtherMode,'),
            ('fn open_selected_mode(', 'fn unrecognized_mode('),
            ('let (observation_only, existing_owner_only) = match selection {',
             'let (observation_only, existing_owner_only) = match other_selection {'),
        ]:
            with self.subTest(mutation=before), self.assertRaisesRegex(ValueError,'durable (?:backend|source)'):
                self.extract(self.replace_once(self.current,before,after))
        pair = 'let ddl = state_backend.ddl();\n        let schema_id = state_backend.selected_schema_id(&settings);'
        for statement in ('let existing_owner_only = false;',
                          'existing_owner_only = false;',
                          'let observation_only = true;',
                          'let alias = &mut existing_owner_only;',
                          'let selection = SelectedOpen::ExistingPqOwner;'):
            with self.subTest(statement=statement), self.assertRaisesRegex(ValueError,'durable backend selected mode rebound'):
                self.extract(self.replace_once(self.current,pair,statement+'\n        '+pair))
        for marker in ('\nfn retain(_: SelectedOpen) {}\n', '\nfn open_selected_mode() {}\n'):
            with self.subTest(marker=marker), self.assertRaisesRegex(ValueError,'durable source body SelectedOpen'):
                self.extract(self.historical_backend()+marker)

    def test_existing_owner_split_requires_the_reviewed_executable_contract(self):
        boundary = '        };\n        ensure(\n            !existing_owner_only'
        redirect = ('\n        if matches!(state_backend, StateBackend::Legacy) {\n'
                    '            return Self::open_with_authenticated_state(path, settings, workers);\n'
                    '        }')
        mode = 'let (observation_only, existing_owner_only) = match selection {'
        pair = 'let ddl = state_backend.ddl();\n        let schema_id = state_backend.selected_schema_id(&settings);'
        mutations = [
            ('redirect-before-lock', boundary, boundary.replace('};', '};'+redirect, 1)),
            ('disabled-enum', 'enum SelectedOpen {', '#[cfg(any())]\nenum SelectedOpen {'),
            ('disabled-owner', 'impl Node {', '#[cfg(any())]\nimpl Node {'),
            ('disabled-wrapper', '    fn open_selected(', '    #[cfg(any())]\n    fn open_selected('),
            ('disabled-mode', '    fn open_selected_mode(', '    #[cfg(any())]\n    fn open_selected_mode('),
            ('disabled-binding', mode, '#[cfg(any())]\n        '+mode),
            ('foreign-mode-type', 'selection: SelectedOpen,', 'selection: another::SelectedOpen,'),
            ('compound-mode-assignment', pair, 'existing_owner_only |= true;\n        '+pair),
            ('tuple-mode-assignment', pair, '(existing_owner_only, _) = (true, ());\n        '+pair),
        ]
        for label,before,after in mutations:
            with self.subTest(label=label), self.assertRaisesRegex(ValueError,'durable backend selected'):
                self.extract(self.replace_once(self.current,before,after))

        # The current complete body includes the account-profile refusal before
        # namespace effects. Rolling it back to the prior reviewed body must not
        # authorize current source under a historical digest.
        guard = ('        // Every backend shares the M06 scope and account-profile decision before\n'
                 '        // creating, initializing or recovering any native namespace files.\n'
                 '        settings.app.check_account_profile()?;\n')
        for label, replacement in [
            ('rolled-back-profile-guard', ''),
            ('commented-profile-guard', guard.replace(
                '        settings.app.check_account_profile()?;',
                '        // settings.app.check_account_profile()?;')),
            ('ignored-profile-refusal', guard.replace(
                '        settings.app.check_account_profile()?;',
                '        let _ = settings.app.check_account_profile();')),
        ]:
            with self.subTest(label=label), self.assertRaisesRegex(
                    ValueError, 'durable backend selected implementation'):
                self.extract(self.replace_once(self.current, guard, replacement))
        late = self.replace_once(self.current, guard, '')
        late = self.replace_once(late, '            fs::create_dir_all(path)?;',
                                 '            fs::create_dir_all(path)?;\n'
                                 '            settings.app.check_account_profile()?;')
        with self.subTest(label='profile-refusal-after-namespace-effect'), self.assertRaisesRegex(
                ValueError, 'durable backend selected implementation'):
            self.extract(late)

    def test_selected_settings_cannot_be_mutated_through_fields_or_borrowed(self):
        header = 'fn open_selected(\n        path: &Path,\n        settings: Settings,'
        pair = 'let ddl = state_backend.ddl();\n        let schema_id = state_backend.selected_schema_id(&settings);'
        statements = [
            'settings.app.params["work_task_profile"] = serde_json::json!("legacy-task-v1");',
            'settings.app.params["work_task_profile"][0] = serde_json::json!(0);',
            'settings.app = settings.app.clone();',
            'let alias = &mut settings;',
            'let alias = &mut settings.app;',
            'let alias = &mut (settings.app);',
        ]
        for statement in statements:
            with self.subTest(statement=statement),self.assertRaisesRegex(ValueError,'durable backend selected schema rebound'):
                # A mutable parameter makes these mutations executable in Rust;
                # body-only source inspection must refuse the mutation itself.
                changed = self.replace_once(self.current,header,header.replace('settings:','mut settings:',1))
                self.extract(self.replace_once(changed,pair,statement+'\n        '+pair))

    def test_growth_selection_is_exact_without_widening_legacy_evidence(self):
        # Recognizing the current selector must not permit a changed growth
        # namespace, bypassed selector or an unapproved implementation body.
        # Every negative still targets exactly one real current-source site.
        selector = ('fn selected_schema_id(self, settings: &Settings) -> Hash {\n'
                    '        if growth_profile_v2::enabled(&settings.app) {')
        mutations = [
            ('wrong-growth-domain', 'b"native-growth-reference-branch-schema-v2"',
             'b"native-branch-schema-v2"'),
            ('growth-literal-space', 'b"native-growth-reference-branch-schema-v2"',
             'b"native-growth-reference-branch- schema-v2"'),
            ('flipped-growth-selector', selector, selector.replace('if growth_', 'if !growth_', 1)),
            ('bypassed-growth-selector', selector,
             selector.replace('if growth_profile_v2::enabled(&settings.app) {', 'if false {', 1)),
            ('default-instead-selected', 'let schema_id = state_backend.selected_schema_id(&settings);',
             'let schema_id = state_backend.schema_id();'),
            ('bypassed-backend', 'let schema_id = state_backend.selected_schema_id(&settings);',
             'let schema_id = StateBackend::Legacy.selected_schema_id(&settings);'),
            ('ignored-settings', 'let schema_id = state_backend.selected_schema_id(&settings);',
             'let schema_id = state_backend.selected_schema_id(&settings.clone());'),
            ('unapproved-method', 'impl StateBackend {',
             'impl StateBackend { fn other(self) -> Hash { self.schema_id() }'),
        ]
        for label,before,after in mutations:
            with self.subTest(label=label),self.assertRaisesRegex(ValueError,'durable (?:backend|growth schema domain)'):
                self.extract(self.replace_once(self.current,before,after))

    def test_backend_decoys_and_historical_hash_cannot_authorize_bad_active_mapping(self):
        backend = self.current[self.current.index('impl StateBackend {'):self.current.index('\nstruct NativeOwners {')]
        bad = self.replace_once(self.current,'b"native-branch-schema-v2"','b"native-branch-schema-unknown"')
        decoys = ['\n'+''.join('// '+line+'\n' for line in backend.splitlines()),
                  '\n/* outer /* nested */ '+backend+' */\n',
                  '\nconst DECOY: &str = '+json.dumps(backend)+';\n',
                  '\nconst DECOY: &str = r###"'+backend+'"###;\n',
                  '\nmod historical { '+backend+' }\n',
                  '\nignored!('+backend+');\n','\nignored!['+backend+'];\n']
        expected = self.extract(self.current)
        for decoy in decoys:
            with self.subTest(decoy=decoy):
                self.assertEqual(self.extract(self.current+decoy),expected)
                with self.assertRaisesRegex(ValueError,'durable backend domain Legacy'): self.extract(bad+decoy)
        inline = '\nfn historical(ddl: String) -> Hash { hash(b"native-branch-schema-v2", &[ddl.as_bytes()]) }\n'
        for broken in (bad,self.replace_once(self.current,'Self::Legacy => ddl(),','Self::Legacy => native_authenticated::DDL.to_string(),')):
            with self.subTest(broken=broken[-80:]),self.assertRaisesRegex(ValueError,'durable backend'):
                self.extract(broken+inline)

    def test_schema_literals_must_be_direct_items_and_cannot_include_authenticated_tables(self):
        literal = 'const DDL: &str = "CREATE TABLE exact(key BLOB);";'
        opener = 'fn open() { hash(b"native-branch-schema-v1", &[DDL.as_bytes()]); }'
        for decoy in ['mod historical { '+literal+' }','ignored!('+literal+');','ignored!['+literal+'];']:
            with self.subTest(decoy=decoy),self.assertRaisesRegex(ValueError,'durable schema literal DDL'):
                self.extract(decoy+'\nuse other::DDL;\n'+opener)
        for name in ['archive_nodes','native_state_commitments','ArChIvE_NoDeS',
                     'pq_network_resource_v2','pq_network_peer_v2','pq_network_request_v2',
                     'Pq_NeTwOrK_FuTuRe_OwNeR_V99']:
            extension = 'CREATE TABLE '+name+'(id BLOB PRIMARY KEY,data BLOB NOT NULL);'
            sources = [
                (literal.replace('CREATE TABLE exact',extension+'CREATE TABLE exact')+opener,None),
                (self.replace_once(self.current,'CREATE TABLE metadata',extension+'CREATE TABLE metadata'),None),
                (self.current,self.replace_once(self.current_index,'CREATE TABLE ancestry_jump',extension+'CREATE TABLE ancestry_jump')),
            ]
            for source,index in sources:
                with self.subTest(name=name,index=index is not None),self.assertRaisesRegex(ValueError,'authenticated tables in legacy durable schema'):
                    self.extract(source,index)


class PipelineExecutableBindingTests(unittest.TestCase):
    """Bounded local files and harmless child exits, never native qualification."""
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='trnm-pipeline-binding-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.out = self.root/'evidence'; (self.out/'logs').mkdir(parents=True)
        self.binary = self.root/'target/release/examples/continuous_pipeline'
        self.binary.parent.mkdir(parents=True)
        self.binary.write_bytes(b'independent inert artifact fixture\n')
        self.copy = self.out/'binaries/continuous_pipeline'
        self.copy.parent.mkdir(); self.copy.write_bytes(self.binary.read_bytes())
        self.artifact = dict(reason='compiler-artifact', package_id='fixture:trnm-pon-node',
            manifest_path=str(self.root/'trillionnium/crates/trnm-pon-node/Cargo.toml'),
            target=dict(name='continuous_pipeline', kind=['example'], crate_types=['bin'],
                        src_path=str(self.root/'trillionnium/crates/trnm-pon-node/examples/continuous_pipeline.rs')),
            profile=dict(opt_level='3', test=False), fresh=False,
            executable=str(self.binary), filenames=[str(self.binary)])
        self.write_build([self.artifact, dict(reason='build-finished', success=True)])
        def snapshot(path):
            info = path.stat()
            return dict(path=str(path), bytes=info.st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                        device=info.st_dev, inode=info.st_ino, mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns)
        initial, retained = snapshot(self.binary), snapshot(self.copy)
        self.binding = dict(cargo_artifact=copy.deepcopy(self.artifact), build_log='logs/pipeline-build.log',
            retained_path='binaries/continuous_pipeline', initial=initial, retained=retained,
            observation_scope='software-file-snapshots-and-launcher-exit-not-execution-attestation')
        self.observer = dict(executable='/fixture/time', sha256='1'*64, identity='time (GNU Time) fixture',
                             observation='software-file-snapshot-not-execution-attestation')
        self.report = dict(pipeline_executable=self.binding, pipeline_binary_sha256=initial['sha256'],
                           environment=dict(resource_observer=self.observer))
        self.rows = {'pipeline-build': dict(log='logs/pipeline-build.log')}
        for pattern, profile in check.CASES:
            name = 'pipeline-'+pattern+'-'+profile
            command = [str(self.binary), str(self.out/name), '20', '32', '10000', pattern, profile]
            observation = dict(source=initial, retained=retained)
            self.rows[name] = dict(command=command, returncode=0, timed_out=False,
                resource_observer=copy.deepcopy(self.observer), pipeline_execution=dict(
                    requested_argv=command, launcher_pid=123,
                    launched_argv=['/fixture/time', '-f', '%M %U %S', '-o', str(self.out/'logs'/(name+'.usage')), *command],
                    before=copy.deepcopy(observation), after=copy.deepcopy(observation),
                    observation_scope=self.binding['observation_scope']))

    def write_build(self, messages):
        (self.out/'logs/pipeline-build.log').write_text('\n'.join(json.dumps(row) for row in messages)+'\n')

    def validate(self, report=None, rows=None):
        return check.validate_pipeline_executable(self.out, report or self.report, rows or self.rows)

    def owner(self):
        sys.path.insert(0, str(check.ROOT/'scripts'))
        import run_public_readiness_qualification
        return run_public_readiness_qualification

    def actual_shell_binding(self):
        import shutil
        from unittest.mock import patch
        owner = self.owner()
        self.binary.write_bytes(Path(shutil.which('sh')).resolve().read_bytes()); self.binary.chmod(0o700)
        self.copy.unlink(); self.copy.parent.rmdir()
        with patch.object(owner, 'ROOT', self.root):
            return owner.bind_pipeline_executable(self.out/'logs/pipeline-build.log', self.binary, self.out)

    def test_complete_observations_and_relocated_archive_verify_only_file_bindings(self):
        self.assertEqual(self.validate(), self.binding)
        import shutil
        relocated = self.root/'relocated'; shutil.copytree(self.out, relocated)
        self.assertEqual(check.validate_pipeline_executable(relocated, self.report, self.rows), self.binding)

    def test_actual_retained_binary_bytes_and_size_are_required(self):
        original = self.copy.read_bytes()
        for data in (b'changed', original+b'suffix', b''):
            self.copy.write_bytes(data)
            with self.subTest(data=data), self.assertRaisesRegex(ValueError, 'retained executable bytes|bounded regular file'):
                self.validate()
        self.copy.write_bytes(original)
        changed = copy.deepcopy(self.report); changed['pipeline_binary_sha256'] = '0'*64
        with self.assertRaisesRegex(ValueError, 'retained hash/length'):
            self.validate(changed)

    def test_omitted_before_after_foreign_argv_and_failed_exit_reject(self):
        name = 'pipeline-hot-legacy'
        for field, value in [('before', None), ('after', None), ('launcher_pid', 0),
                             ('launched_argv', ['different']), ('requested_argv', ['different'])]:
            rows = copy.deepcopy(self.rows); rows[name]['pipeline_execution'][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError): self.validate(rows=rows)
        for field, value in [('returncode', 7), ('returncode', True), ('timed_out', True)]:
            rows = copy.deepcopy(self.rows); rows[name][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError): self.validate(rows=rows)
        rows = copy.deepcopy(self.rows); rows[name]['command'][0] = '/different/continuous_pipeline'
        with self.assertRaisesRegex(ValueError, 'exact executable/output argv'): self.validate(rows=rows)

    def test_case_observer_cannot_differ_or_hide_a_recorded_failure(self):
        name = 'pipeline-hot-legacy'
        rows = copy.deepcopy(self.rows); rows[name]['resource_observer']['sha256'] = '2'*64
        with self.assertRaisesRegex(ValueError, 'observer binding/failure'): self.validate(rows=rows)
        rows = copy.deepcopy(self.rows); rows[name]['resource_observer_error'] = 'retained observer failure'
        with self.assertRaisesRegex(ValueError, 'observer binding/failure'): self.validate(rows=rows)
        for field, value in [('observation', 'execution-attested'), ('sha256', 'bad'), ('identity', None)]:
            report = copy.deepcopy(self.report); report['environment']['resource_observer'][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError): self.validate(report)

    def test_cargo_artifact_cannot_be_absent_duplicated_changed_or_failed(self):
        for messages in ([], [self.artifact], [self.artifact, self.artifact, dict(reason='build-finished', success=True)],
                         [self.artifact, dict(reason='build-finished', success=False)]):
            self.write_build(messages)
            with self.subTest(messages=messages), self.assertRaisesRegex(ValueError, 'Cargo artifact'):
                self.validate()
        changed = copy.deepcopy(self.artifact); changed['profile']['opt_level'] = '1'
        self.write_build([changed, dict(reason='build-finished', success=True)])
        report = copy.deepcopy(self.report); report['pipeline_executable']['cargo_artifact'] = changed
        with self.assertRaisesRegex(ValueError, 'target/profile'): self.validate(report)

    def test_malformed_cargo_target_profile_and_file_list_fail_closed(self):
        from unittest.mock import patch
        owner = self.owner()
        for field, value in [('target', None), ('target', []), ('profile', None), ('profile', '3'),
                             ('filenames', str(self.binary)), ('filenames', None), ('filenames', [None])]:
            artifact = copy.deepcopy(self.artifact); artifact[field] = value
            self.write_build([artifact, dict(reason='build-finished', success=True)])
            report = copy.deepcopy(self.report); report['pipeline_executable']['cargo_artifact'] = artifact
            with self.subTest(field=field, value=value):
                with self.assertRaises(ValueError): self.validate(report)
                with patch.object(owner, 'ROOT', self.root), self.assertRaisesRegex(ValueError, 'PIPELINE_CARGO_ARTIFACT'):
                    owner.bind_pipeline_executable(self.out/'logs/pipeline-build.log', self.binary, self.out)

    def test_v1_cannot_acquire_current_v2_or_execution_authentication(self):
        (self.out/'manifest.json').write_text(json.dumps(dict(schema='trnm-public-readiness-evidence-v1')))
        with self.assertRaisesRegex(ValueError, 'current execution requires v2'):
            check.validate(self.root, self.out, tracked=False)
        with self.assertRaisesRegex(ValueError, 'unsupported authority'):
            check.scope_flags(dict(native_execution_authenticated=True))

    def test_actual_collector_retains_bytes_and_rejects_later_changes(self):
        from unittest.mock import patch
        owner = self.owner(); self.copy.unlink(); self.copy.parent.rmdir()
        with patch.object(owner, 'ROOT', self.root):
            binding = owner.bind_pipeline_executable(self.out/'logs/pipeline-build.log', self.binary, self.out)
        self.assertEqual(self.copy.read_bytes(), self.binary.read_bytes())
        self.assertEqual(owner.observe_pipeline_executable(binding, self.out),
                         dict(source=binding['initial'], retained=binding['retained']))
        self.copy.write_bytes(b'changed private fixture')
        with self.assertRaisesRegex(ValueError, 'RETAINED_COPY_CHANGED'):
            owner.observe_pipeline_executable(binding, self.out)

    def test_snapshot_rejects_symlink_fifo_and_oversized_regular_file(self):
        owner = self.owner()
        symlink = self.root/'alias'; symlink.symlink_to(self.binary)
        fifo = self.root/'fifo'; os.mkfifo(fifo)
        large = self.root/'oversized'
        with large.open('wb') as stream: stream.truncate(owner.PIPELINE_BINARY_LIMIT+1)
        for path in (symlink, fifo, large):
            with self.subTest(path=path), self.assertRaises(ValueError): owner.snapshot_pipeline_file(path)
            with self.subTest(path=path), self.assertRaises((OSError, ValueError)):
                owner.sha(path, limit=owner.PIPELINE_BINARY_LIMIT)
            with self.subTest(path=path), self.assertRaises((OSError, ValueError)):
                check.hash_file(path, limit=check.PIPELINE_BINARY_LIMIT)

    def test_manifest_stage_hashes_binary_as_bounded_stream_before_validation(self):
        from unittest.mock import patch
        owner = self.owner()
        (self.out/'qualification.json').write_text('{}\n')
        manifest = dict(files={path.relative_to(self.out).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
                               for path in self.out.rglob('*') if path.is_file()})
        with patch.object(Path, 'read_bytes', side_effect=AssertionError('unbounded whole-file read')):
            check.validate_artifacts(self.root, self.out, manifest, tracked=False)
            self.assertEqual(owner.sha(self.copy, limit=owner.PIPELINE_BINARY_LIMIT), self.binding['retained']['sha256'])
        with self.copy.open('wb') as stream: stream.truncate(owner.PIPELINE_BINARY_LIMIT+1)
        with patch.object(Path, 'read_bytes', side_effect=AssertionError('unbounded whole-file read')):
            with self.assertRaisesRegex(ValueError, 'bounded regular file'):
                check.validate_artifacts(self.root, self.out, manifest, tracked=False)
            with self.assertRaisesRegex(ValueError, 'BOUNDED_REGULAR_FILE'):
                owner.sha(self.copy, limit=owner.PIPELINE_BINARY_LIMIT)

    def test_actual_owner_child_failure_and_post_observation_failure_keep_exit(self):
        import contextlib
        import io
        import signal
        owner = self.owner()
        from test_qualification_runtime import QualificationRuntimeTests
        binding = self.actual_shell_binding()
        harness = QualificationRuntimeTests()
        cases = [('normal', 'exit 0', 0, False, False), ('nonzero', 'exit 7', 7, False, False),
                 ('timeout', 'sleep 10', -signal.SIGKILL, True, False), ('post-failure', 'exit 0', 0, False, True)]
        for name, script, code, timed_out, late_failure in cases:
            records = []
            execute = harness.owner_execute('run_public_readiness_qualification.py', self.out, records)
            observe = owner.observe_pipeline_executable
            if late_failure:
                snapshot = observe(binding, self.out)
                from unittest.mock import Mock
                observe = Mock(side_effect=[snapshot, ValueError('controlled post-observation failure')])
            execute.__globals__.update(observe_pipeline_executable=observe,
                                       PIPELINE_OBSERVATION_SCOPE=owner.PIPELINE_OBSERVATION_SCOPE)
            with contextlib.redirect_stdout(io.StringIO()):
                if code or late_failure:
                    with self.assertRaisesRegex(RuntimeError, 'QUALIFICATION_FAILED'):
                        execute(name, [str(self.binary), '-c', script], timeout=0.1 if timed_out else 5,
                                executable_binding=binding)
                else:
                    execute(name, [str(self.binary), '-c', 'exit 0'], executable_binding=binding)
            self.assertEqual(len(records), 1)
            self.assertEqual(records[0]['returncode'], code)
            self.assertIs(records[0]['timed_out'], timed_out)
            self.assertGreater(records[0]['pipeline_execution']['launcher_pid'], 0)
            if late_failure: self.assertIn('error', records[0]['pipeline_execution'])

    def test_actual_prelaunch_failures_retain_observations_without_inventing_exits(self):
        import contextlib
        import io
        owner = self.owner()
        from test_qualification_runtime import QualificationRuntimeTests
        binding = self.actual_shell_binding()
        harness = QualificationRuntimeTests()
        for name, stage in [('missing-observer', 'OBSERVER_BEFORE'), ('missing-cwd', 'LAUNCH'), ('changed-copy', 'BEFORE')]:
            records = []
            execute = harness.owner_execute('run_public_readiness_qualification.py', self.out, records)
            execute.__globals__.update(observe_pipeline_executable=owner.observe_pipeline_executable,
                                       PIPELINE_OBSERVATION_SCOPE=owner.PIPELINE_OBSERVATION_SCOPE)
            if name == 'missing-observer':
                execute.__globals__['resource_observer'] = dict(execute.__globals__['resource_observer'],
                                                               executable=str(self.root/'no-such-observer'))
            elif name == 'missing-cwd':
                execute.__globals__['ROOT'] = self.root/'no-such-working-directory'
            else:
                self.copy.write_bytes(b'changed private fixture')
            marker = self.root/(name+'-started')
            command = [str(self.binary), '-c', 'printf reached > "$1"', 'control', str(marker)]
            with contextlib.redirect_stdout(io.StringIO()), self.assertRaisesRegex(RuntimeError, 'PIPELINE_'+stage):
                execute(name, command, executable_binding=binding)
            self.assertEqual(len(records), 1)
            row = records[0]; execution = row['pipeline_execution']
            self.assertFalse(marker.exists())
            self.assertIsNone(row['returncode'])
            self.assertFalse(row['timed_out'])
            self.assertEqual(execution['requested_argv'], command)
            self.assertIsNone(execution['launcher_pid'])
            self.assertIsNone(execution['launched_argv'])
            self.assertIsNone(execution['after'])
            self.assertEqual(execution['failure_stage'], stage)
            self.assertTrue(execution['error'])
            if stage == 'BEFORE': self.assertIsNone(execution['before'])
            else: self.assertEqual(execution['before'], dict(source=binding['initial'], retained=binding['retained']))
            if stage == 'LAUNCH': self.assertEqual(execution['launch_attempted_argv'][-len(command):], command)

    def test_started_wait_and_cleanup_errors_retain_real_or_unknown_exit(self):
        import contextlib
        import io
        from unittest.mock import patch
        owner = self.owner()
        from test_qualification_runtime import QualificationRuntimeTests
        binding = self.actual_shell_binding()
        harness = QualificationRuntimeTests()
        real_popen = subprocess.Popen
        for name, fail_poll, unknown_exit in [('wait-error', False, False), ('cleanup-error', True, False),
                                               ('unknown-exit', False, True)]:
            records, children = [], []
            execute = harness.owner_execute('run_public_readiness_qualification.py', self.out, records)
            execute.__globals__.update(observe_pipeline_executable=owner.observe_pipeline_executable,
                                       PIPELINE_OBSERVATION_SCOPE=owner.PIPELINE_OBSERVATION_SCOPE)
            class InterruptedObservation:
                def __init__(self, process): self.process, self.pid, self.waits = process, process.pid, 0
                def wait(self, timeout=None):
                    self.waits += 1
                    if self.waits == 1:
                        # The harmless child is real and reaped. Inject only a
                        # failed delivery of this wait result to the owner.
                        self.process.wait(timeout=timeout)
                        raise OSError('controlled wait observation failure')
                    if unknown_exit: raise OSError('controlled cleanup wait failure')
                    return self.process.wait(timeout=timeout)
                def poll(self):
                    if fail_poll: raise OSError('controlled cleanup poll failure')
                    return self.process.poll()
            def launch(*args, **kwargs):
                process = real_popen(*args, **kwargs); children.append(process)
                return InterruptedObservation(process)
            try:
                with patch.object(subprocess, 'Popen', side_effect=launch), contextlib.redirect_stdout(io.StringIO()), \
                        self.assertRaisesRegex(RuntimeError, 'PIPELINE_WAIT_OR_CLEANUP'):
                    execute(name, [str(self.binary), '-c', 'exit 0'], executable_binding=binding)
            finally:
                for process in children: process.wait(timeout=5)
            self.assertEqual(len(records), 1)
            row = records[0]; execution = row['pipeline_execution']
            self.assertEqual(row['returncode'], None if unknown_exit else 0)
            self.assertFalse(row['timed_out'])
            self.assertGreater(execution['launcher_pid'], 0)
            self.assertEqual(execution['failure_stage'], 'WAIT_OR_CLEANUP')
            self.assertIn('controlled wait observation failure', execution['error'])
            self.assertEqual(bool(execution['cleanup_errors']), fail_poll or unknown_exit)
            self.assertEqual(execution['after'], dict(source=binding['initial'], retained=binding['retained']))


if __name__ == '__main__': unittest.main(verbosity=2)
