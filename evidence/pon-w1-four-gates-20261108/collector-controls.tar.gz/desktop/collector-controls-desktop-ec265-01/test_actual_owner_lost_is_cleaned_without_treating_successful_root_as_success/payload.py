import os,time,signal,json
from pathlib import Path
signal.signal(signal.SIGTERM,signal.SIG_IGN)
raw=Path('/proc/self/stat').read_text();tail=raw[raw.rfind(')')+2:].split()
Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/collector-controls-desktop-ec265-01/test_actual_owner_lost_is_cleaned_without_treating_successful_root_as_success/payload-identity.json').write_text(json.dumps({'pid':os.getpid(),'start_ticks':int(tail[19]),'boot_id':'14f92beb-43c6-4786-839e-b57307ae8048'}))
time.sleep(3)
