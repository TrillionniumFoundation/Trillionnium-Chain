#!/usr/bin/env python3
"""Cross-check nested original Host counters and exact hostile body identities."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

from read_original_campaign import (ARCHIVE_BYTES, ARCHIVE_SHA256, MODES, decode,
                                    digest, require, store, store_json)


def counters(snapshot):
    return {key: int(value) for key, value in
            (line.split() for line in snapshot["counters"]["cpu.stat"].splitlines())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    require(args.archive.stat().st_size == ARCHIVE_BYTES, "archive size mismatch")
    with args.archive.open("rb") as stream:
        require(hashlib.file_digest(stream, "sha256").hexdigest() == ARCHIVE_SHA256,
                "archive hash mismatch")
    rows, retained = [], []
    with zipfile.ZipFile(args.archive) as z:
        manifest = {r["path"]: r for r in decode(z.read("artifact-files.json"))["files"]}
        for run in range(1, 4):
            report = decode(z.read(f"run-{run}-raw/report.json"))
            for phase in report["phases"]:
                mode = phase["mode"]
                require(mode in MODES, "unknown mode")
                base = f"run-{run}-raw/{mode}-host-control/host/"
                data = {}
                for name in ("inside-before.json", "inside-after.json", "controller-result.json"):
                    path = base + name
                    require(z.getinfo(path).file_size < 1024 * 1024, "oversize Host metadata")
                    raw = z.read(path)
                    require(len(raw) == manifest[path]["bytes"] and digest(raw) == manifest[path]["sha256"],
                            "Host metadata manifest mismatch")
                    data[name] = decode(raw)
                    store(args.out_dir / "original-host-small" / path, raw)
                    retained.append(manifest[path])
                before, after = data["inside-before.json"], data["inside-after.json"]
                context = phase["phase_process_context"]
                for host in (before, after):
                    require(host["read_errors"] == {} and host["host_readiness_only"] is True
                            and host["consensus_or_model_authority"] is False, "unqualified Host observation")
                    require(host["parent_path"] == "/sys/fs/cgroup/trnmponpublic.slice"
                            and host["parent"]["canonical_path"] == host["parent_path"], "wrong Host parent")
                    require(host["parent"]["uid"] == 0 and host["parent"]["gid"] == 0
                            and host["parent"]["directory"] is True and host["parent"]["symlink"] is False,
                            "wrong parent ownership/type")
                    require(host["limits"] == {"cpu.max": "25000 100000", "cpu.max.burst": "0",
                            "memory.max": "2147483648", "memory.swap.max": "0", "pids.max": "256"},
                            "wrong actual fixed Host limits")
                    require(host["thread_cgroup"] == "0::" + context["phase_cgroup"], "Host thread membership differs")
                require(before["boot_id"] == after["boot_id"]
                        and before["parent"] == after["parent"]
                        and before["installed_unit_sha256"] == after["installed_unit_sha256"],
                        "Host identity changed across phase")
                b, a = counters(before), counters(after)
                require(b["usage_usec"] <= context["host_before"]["cpu_usage_usec"]
                        <= context["host_after"]["cpu_usage_usec"] <= a["usage_usec"],
                        "inner phase CPU interval not contained in outer launcher interval")
                controller = data["controller-result.json"]
                require(controller["passed"] is True and controller["failure"] is None
                        and controller["final_host_errors"] == [] and controller["systemd_run_exit"] == 0,
                        "Host launcher readiness failed")
                require(controller["host_readiness_only"] is True
                        and controller["service_or_depletion_criteria_met"] is False
                        and controller["consensus_or_model_authority"] is False,
                        "Host readiness misrepresented as service success")
                for name in ("controller_before", "controller_after"):
                    expected = {"actual_thread_cgroup": "0::" + context["controller_cgroup"],
                                "limits": {"cpu.max": "400000 100000", "memory.max": "17179869184"}}
                    require(controller[name] == expected, "actual controller placement/limits differ")
                hostile_digests = set()
                for child in phase["children"]:
                    result = child["report"]["result"]
                    identity = result["acquisition"]["public_request_body_digest"]
                    require(all(call["public_request_body_digest"] == identity for call in result["calls"]),
                            "hostile call body differs from original acquired body")
                    hostile_digests.add(identity)
                require(len(hostile_digests) == (0 if mode == "baseline" else 24), "wrong distinct hostile identities")
                matched = [r for r in phase["receiver_observation"]["records"]
                           if r.get("body_digest") is not None and bytes(r["body_digest"]).hex() in hostile_digests]
                rejected = sum(r["full_work_accepted"] is False for r in matched)
                accepted = sum(r["full_work_accepted"] is True for r in matched)
                require(rejected == phase["full_work_failed"] and accepted == 0,
                        "full-work outcomes are not exactly attributable to original hostile bodies")
                rows.append({"run": run, "mode": mode,
                             "actual_public_cpu_max": before["limits"]["cpu.max"],
                             "actual_public_memory_max": before["limits"]["memory.max"],
                             "actual_controller_limits": controller["controller_before"]["limits"],
                             "resource_limits_are_ceilings_not_reservations": True,
                             "host_readiness_passed": True, "service_or_depletion_criteria_met": False,
                             "outer_host_launcher_cpu_delta_usec": a["usage_usec"] - b["usage_usec"],
                             "inner_phase_host_cpu_delta_usec": context["host_after"]["cpu_usage_usec"] - context["host_before"]["cpu_usage_usec"],
                             "inner_phase_interval_is_contained_in_outer_launcher_interval": True,
                             "nested_host_counters_must_not_be_added": True,
                             "distinct_hostile_body_digests": len(hostile_digests),
                             "receiver_full_work_rejections_matched_to_exact_hostile_bodies": rejected,
                             "receiver_full_work_accepts_matched_to_exact_hostile_bodies": accepted})
    result = {"schema": "original-service-host-scope-crosscheck-v1", "verdict": "PASS",
              "archive_sha256": ARCHIVE_SHA256, "phases": rows,
              "all_hostile_full_work_rejections_matched_to_exact_original_bodies": sum(
                  r["receiver_full_work_rejections_matched_to_exact_hostile_bodies"] for r in rows),
              "host_readiness_passes": sum(r["host_readiness_passed"] for r in rows),
              "host_readiness_does_not_establish_service_success": True,
              "campaign_reexecuted": False}
    store_json(args.out_dir / "host-scope-crosscheck.json", result)
    store_json(args.out_dir / "host-scope-original-pins.json", retained)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
