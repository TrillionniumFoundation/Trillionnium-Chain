import ast,difflib,hashlib,importlib.util,json,os,pathlib,re,shutil,subprocess,sys,time,traceback
ROOT=pathlib.Path("/data/chain-six-d9fb-20261108/delivery-source")
OUT=pathlib.Path("/data/chain-six-d9fb-20261108/evidence/final-integration/ci-literal-repair-review-v2")
HEAD="e9b7a60b9519e39b792199dc8756fb9d1245bab8"
OUT.mkdir(parents=True,exist_ok=False)
(OUT/"review-driver.py").write_text(p["driver"])
TREE=OUT/"isolated-fixture"
def digest(b):return hashlib.sha256(b).hexdigest()
def write(n,obj):(OUT/n).write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n")
def git(*args):return subprocess.check_output(["git","--no-replace-objects",*args],cwd=ROOT)
assert git("rev-parse","HEAD").decode().strip()==HEAD
assert not git("status","--porcelain","--untracked-files=all")
rel="scripts/ci/check_ci_contract.py"
old=(ROOT/rel).read_text()
workflow=(ROOT/".github/workflows/pon-w1-transparent-profile.yml").read_text()
assert (ROOT/rel).read_bytes()==git("show",HEAD+":"+rel)
assert digest(workflow.encode())=="490c367b08f76487c4d2969a5b9858bd6852e7976dde8089b860969f3983e9d7"
nodes=[n for n in ast.walk(ast.parse(old)) if isinstance(n,ast.Constant) and isinstance(n.value,str) and "        id: v2_gate_tests\n" in n.value]
assert len(nodes)==1,len(nodes)
oldblock=nodes[0].value
blocks=[b for b in re.findall(r"(?ms)^      - name: .*?(?=^      - name: |\Z)",workflow) if "        id: v2_gate_tests\n" in b]
assert len(blocks)==1,len(blocks)
newblock=blocks[0]
assert old.count(oldblock)==1
assert newblock.startswith(oldblock.rstrip()+"\n")
addition=newblock[len(oldblock.rstrip()):]
command="          python3 -m unittest discover -s scripts/ci -p test_w1_v2_current_stage_gate.py -v 2>&1 | tee \"$W1_PROFILE_OUT/v3-gate-tests.log\""
assert command in addition,repr(addition[:400])
assert "test_w1_v2_controls_gate.py" not in addition
assert "test_w1_v2_current_stage_gate.py" in addition
new=old.replace(oldblock,newblock,1)
patch="".join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile="a/"+rel,tofile="b/"+rel))
(OUT/"ci-v2-current-literal.patch").write_text(patch)
(OUT/"checker-before.py").write_text(old)
(OUT/"checker-after.py").write_text(new)
(OUT/"required-v2-step-before.txt").write_text(oldblock)
(OUT/"required-v2-step-after.txt").write_text(newblock)
baseline=ROOT.parent/"evidence/final-integration/proof-pq-f4-validation/ci-contract-164.stderr.log"
assert digest(baseline.read_bytes())=="6ecff0a571b3e60d9317671102dd74282ca4f8a0c5f88de605b446117529e496"
shutil.copyfile(baseline,OUT/"f4-original-164-errors3.stderr.log")
write("patch-review.json",{"source_commit":HEAD,"source_checker_sha256":digest(old.encode()),"patched_checker_sha256":digest(new.encode()),"workflow_sha256":digest(workflow.encode()),"patch_sha256":digest(patch.encode()),"only_path_changed":rel,"old_literal_preserved_as_prefix":True,"new_literal_matches_whole_actual_step":True,"added_bytes":len(new.encode())-len(old.encode()),"original_f4_errors":3,"qualification_upgraded":False})
print(json.dumps({"patch":str(OUT/"ci-v2-current-literal.patch"),"sha256":digest(patch.encode()),"added_bytes":len(new.encode())-len(old.encode()),"phase":"copying-isolated-fixture"}),flush=True)
shutil.copytree(ROOT,TREE,symlinks=True,ignore=shutil.ignore_patterns(".git"))
(TREE/rel).write_text(new)
env=dict(os.environ);env.update(PYTHONDONTWRITEBYTECODE="1",PYTHONUNBUFFERED="1")
argv=["/usr/bin/python3","-B","scripts/ci/test_ci_contract.py","-v"]
t=time.monotonic()
print(json.dumps({"phase":"full-164","argv":argv,"cwd":str(TREE)}),flush=True)
with (OUT/"repaired-164.stdout.log").open("xb") as so,(OUT/"repaired-164.stderr.log").open("xb") as se:
 rc=subprocess.run(argv,cwd=TREE,env=env,stdout=so,stderr=se,timeout=1200).returncode
stderr=(OUT/"repaired-164.stderr.log").read_text()
ids=re.findall(r"(?m)^test_[A-Za-z0-9_]+ \(([^)\n]+)\)",stderr)
statuses=re.findall(r"(?m)\.\.\. (ok|ERROR|FAIL|skipped[^\n]*)$",stderr)
passed=rc==0 and re.findall(r"(?m)^Ran (\d+) tests in [0-9.]+s$",stderr)==["164"] and stderr.endswith("\nOK\n") and len(ids)==len(set(ids))==164 and statuses==["ok"]*164
write("repaired-164-result.json",{"argv":argv,"cwd":str(TREE),"exit_code":rc,"wall_seconds":time.monotonic()-t,"passed":passed,"ids":ids,"named_count":len(ids),"distinct_count":len(set(ids)),"stdout_sha256":digest((OUT/"repaired-164.stdout.log").read_bytes()),"stderr_sha256":digest(stderr.encode())})
print(json.dumps({"phase":"full-164-complete","exit_code":rc,"passed":passed}),flush=True)
sys.path.insert(0,str(TREE/"scripts/ci"))
spec=importlib.util.spec_from_file_location("reviewed_ci_literal",TREE/rel)
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
module.check_w1_postwin_workflow(workflow)
controls=[]
assert workflow.count(command)==1
mutants={"remove_current_ten_command":workflow.replace(command+"\n","",1),"rename_current_ten_command":workflow.replace(command,command.replace("test_w1_v2_current_stage_gate.py","test_w1_v2_current_stage_gate_missing.py"),1)}
for name,text in mutants.items():
 (OUT/(name+".yml")).write_text(text)
 try:module.check_w1_postwin_workflow(text)
 except ValueError as error:
  reason=str(error);ok=reason=="CI contract: W1 post-win v2_gate_tests retains its exact executable source/build/control block"
 else:reason=None;ok=False
 controls.append({"name":name,"rejected":ok,"reason":reason,"input_sha256":digest(text.encode())})
write("current-ten-command-negative-controls.json",{"positive_actual_workflow_passed":True,"controls":controls,"all_rejected":all(x["rejected"] for x in controls),"qualification_upgraded":False})
assert (ROOT/rel).read_text()==old and (ROOT/".github/workflows/pon-w1-transparent-profile.yml").read_text()==workflow
assert git("rev-parse","HEAD").decode().strip()==HEAD and not git("status","--porcelain","--untracked-files=all")
complete=passed and all(x["rejected"] for x in controls)
write("summary.json",{"schema":"trnm-f4-ci-exact-literal-repair-review-v1","source_commit":HEAD,"original_f4_complete_164_passed":False,"original_f4_errors":3,"repaired_fixture_complete_164_passed":passed,"targeted_negative_controls":controls,"source_worktree_unchanged":True,"only_proposed_path":rel,"proposal_complete":complete,"qualification_upgraded":False,"new_native_executions":0,"patch_sha256":digest(patch.encode())})
index=[{"path":x.name,"bytes":x.stat().st_size,"sha256":digest(x.read_bytes())} for x in sorted(OUT.iterdir()) if x.is_file()]
write("SHA256SUMS.json",index)
print(json.dumps({"terminal":"succeeded" if complete else "failed","summary":str(OUT/"summary.json"),"summary_sha256":digest((OUT/"summary.json").read_bytes()),"patch_sha256":digest(patch.encode()),"negative_controls":controls}),flush=True)
sys.exit(0 if complete else 1)
