import re, sys
from pathlib import Path
lines = Path(sys.argv[1]).read_text().splitlines()
names = [m[1] for line in lines if (m := re.fullmatch(r'test (store::native_authenticated::[A-Za-z0-9_:]+) \.\.\. ok', line))]
summaries = [line for line in lines if line.startswith('test result:')]
post_write = [name for name in names if name.startswith('store::native_authenticated::post_write_readback::tests::')]
if (len(names) != 83 or len(set(names)) != 83 or len(post_write) != 23
        or len(summaries) != 1 or not summaries[0].startswith('test result: ok. 83 passed; 0 failed; 0 ignored;')):
    raise SystemExit('current authenticated module requires 60 retained and 23 post-write executions in one log')
