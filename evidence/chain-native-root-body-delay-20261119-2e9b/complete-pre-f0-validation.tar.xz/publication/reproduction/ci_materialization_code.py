import pathlib,subprocess,json,hashlib,os,time
s=pathlib.Path('/home/qq/chain-host-stat-20261118-2e9b-source');original=pathlib.Path('/home/qq/work/chain-prepaid-d952-original-control-20261119-2e9b/source-2');out=pathlib.Path('/home/qq/chain-native-root-body-delay-20261118-2e9b-validation/write-complete-v4/ci-materialization-1');assert not out.exists();out.mkdir();pre=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=s,capture_output=True,text=True);(out/'preflight.stdout').write_text(pre.stdout);(out/'preflight.stderr').write_text(pre.stderr);assert pre.returncode==0
raw=subprocess.check_output(['git','ls-tree','-r','-z','d95239eda6a666458aa264ddeaf993d6d9fbf37d','--','formal'],cwd=s);copied=[]
for row in raw.split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t');mode,kind,blob=meta.split();relative=os.fsdecode(name);dst=s/relative
 if dst.exists() or dst.is_symlink():continue
 src=original/relative
 if not src.is_file() or src.is_symlink():continue
 assert kind==b'blob' and mode in [b'100644',b'100755'];data=src.read_bytes();h=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert h==blob.decode()
 original_head=subprocess.check_output(['git','rev-parse','HEAD:'+relative],cwd=s,text=True).strip();assert original_head==h,'own old source object differs'
 dst.parent.mkdir(parents=True,exist_ok=True)
 with dst.open('xb') as f:f.write(data)
 dst.chmod(0o755 if mode==b'100755' else 0o644)
 copied.append({'path':relative,'bytes':len(data),'git_blob':h,'sha256':hashlib.sha256(data).hexdigest()})
receipt={'materialized_original_missing_files':copied,'source_objects_unchanged':True,'existing_files_overwritten':False,'from_source':'d95239eda6a666458aa264ddeaf993d6d9fbf37d','native_reexecution':False};(out/'MATERIALIZATION.json').write_text(json.dumps(receipt,indent=2)+'\n');start=time.monotonic()
with (out/'ci-contract.stdout').open('xb') as so,(out/'ci-contract.stderr').open('xb') as se:p=subprocess.Popen(['python3','-B','scripts/ci/check_ci_contract.py'],cwd=s,stdout=so,stderr=se);rc=p.wait(timeout=1800)
result={'materialized_count':len(copied),'ci_contract_returncode':rc,'wall_seconds':time.monotonic()-start,'f0_qualified':False};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))