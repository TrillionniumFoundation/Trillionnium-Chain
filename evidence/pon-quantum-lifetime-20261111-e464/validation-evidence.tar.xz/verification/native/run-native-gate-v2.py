#!/usr/bin/env python3
"""Local command observations; this is not a release or security acceptance gate."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/e4648d82092d')
ROOT = BASE / 'chain'
OUTPUT = BASE / 'verification/native'
SETUP = OUTPUT / 'setup-20261112T000232Z/environment.json'
SOURCE_BEFORE = BASE / 'verification/committed-b/source-before.json'
COMMIT = '523a4f431b65f8a52128962f5880c4030e3e05db'
TREE = '51b57df779e46bb16518c5c6c7aef90e48faa06d'


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def source_snapshot():
    def git(*args):
        return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT, text=True).strip()
    snapshot = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                'git_status': git('status', '--porcelain', '--untracked-files=all')}
    if snapshot != {'head': COMMIT, 'tree': TREE, 'git_status': ''}:
        raise RuntimeError('frozen source identity changed')
    snapshot['lock_sha256'] = {name: digest(ROOT / name) for name in
                              ('trillionnium/Cargo.lock', 'tests/fuzz/Cargo.lock')}
    return snapshot


def resources():
    memory = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        name, value = line.split(':', 1)
        if name in ('MemAvailable', 'MemTotal'):
            memory[name + '_bytes'] = int(value.strip().split()[0]) * 1024
    volumes = {}
    for path in ('/workspace', '/tmp'):
        info = os.statvfs(path)
        volumes[path] = {'available_bytes': info.f_bavail * info.f_frsize,
                         'total_bytes': info.f_blocks * info.f_frsize}
    return {'observed_utc': datetime.now(timezone.utc).isoformat(), 'memory': memory, 'volumes': volumes}


def borrowed_identities_match(setup):
    for item in setup['toolchain_identities'] + setup['provider_sdk_identities']:
        if digest(item['path']) != item['sha256']:
            raise RuntimeError('borrowed toolchain/provider identity changed: ' + item['path'])


def main():
    label = sys.argv[1]
    setup = json.loads(SETUP.read_text())
    cargo = str(Path(setup['toolchain_prefix']) / 'bin/cargo')
    commands = {
        'preflight': ['bash', 'scripts/project-preflight.sh'],
        'metadata-default': [cargo, 'metadata', '--offline', '--locked', '--format-version', '1', '--manifest-path', 'trillionnium/Cargo.toml'],
        'metadata-all-features': [cargo, 'metadata', '--offline', '--locked', '--format-version', '1', '--manifest-path', 'trillionnium/Cargo.toml', '--all-features'],
        'metadata-fuzz-all-features': [cargo, 'metadata', '--offline', '--locked', '--format-version', '1', '--manifest-path', 'tests/fuzz/Cargo.toml', '--all-features'],
        'fmt': [cargo, 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check'],
        'clippy': [cargo, 'clippy', '--offline', '--locked', '--manifest-path', 'trillionnium/Cargo.toml', '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings'],
        'workspace-tests': [cargo, 'test', '--offline', '--locked', '--manifest-path', 'trillionnium/Cargo.toml', '--workspace', '--all-targets', '--all-features'],
        'doc-tests': [cargo, 'test', '--offline', '--locked', '--manifest-path', 'trillionnium/Cargo.toml', '--workspace', '--doc', '--all-features'],
    }
    argv = commands[label]
    output = OUTPUT / (label + '-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    output.mkdir()
    source = json.loads(SOURCE_BEFORE.read_text())
    if not (source['tracked_worktree_verified'] is True and source['tested_commit'] == COMMIT and source['tested_tree'] == TREE):
        raise RuntimeError('full physical source-before observation missing')
    relocation_path = OUTPUT / 'cache-relocation-20261112T001328Z/receipt.json'
    relocation = json.loads(relocation_path.read_text())
    if relocation['status'] != 'MOVED_VERIFIED_OWN_CACHE' or relocation['locked_archive_count'] != 159:
        raise RuntimeError('complete independent cache relocation not verified')
    overrides = setup['environment_overrides'] | {'CARGO_BUILD_JOBS': '1', 'CARGO_HOME': relocation['destination']}
    if label == 'workspace-tests':
        receipt = output / 'test-artifacts'
        receipt.mkdir()
        paths = {
            'TRNM_MODEL_COMPOSITION_VECTORS': 'model-composition',
            'TRNM_AUTHENTICATED_STATE_VECTORS': 'authenticated-state/native.json',
            'TRNM_NATIVE_AUTHENTICATED_STATE_EXPORT_DIR': 'native-authenticated-state',
            'TRNM_AUTHENTICATED_MIGRATION_EXPORT': 'authenticated-migration',
            'TRNM_ACCOUNT_MULTIPROOF_VECTORS': 'account-multiproof/native.json',
            'TRNM_OBLIGATION_RANGE_VECTORS': 'obligation-range/native.json',
            'TRNM_ZERO_PAIRED_PREFIX_OUTPUT': 'zero-paired-prefix',
            'TRNM_DAA_EVIDENCE_DIR': 'daa-bounds',
            'TRNM_JOINT_DAA_EVIDENCE_DIR': 'joint-daa',
            'TRNM_WORK_SCHEDULE_RESEARCH_DIR': 'branch-work-schedule',
        }
        for key, value in paths.items():
            overrides[key] = str(receipt / value)
        for directory in ('model-composition', 'authenticated-state', 'account-multiproof', 'obligation-range'):
            (receipt / directory).mkdir()
        import secrets
        overrides['TRNM_MODEL_COMPOSITION_RUN_ID'] = secrets.token_hex(32)
    environment = os.environ.copy()
    environment.update(overrides)
    environment['PATH'] = setup['path_prefix'] + os.pathsep + environment['PATH']
    report = {
        'schema': 'trnm-local-native-command-observation-v1', 'label': label,
        'status': 'RUNNING', 'argv': argv, 'cwd': str(ROOT),
        'started_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': None,
        'environment_overrides': overrides, 'path_prefix': setup['path_prefix'],
        'setup': {'path': str(SETUP), 'sha256': digest(SETUP)},
        'cache_relocation': {'path': str(relocation_path), 'sha256': digest(relocation_path)},
        'orchestrator': {'path': str(Path(__file__).resolve()), 'sha256': digest(Path(__file__))},
        'full_physical_source_before': {'path': str(SOURCE_BEFORE), 'sha256': digest(SOURCE_BEFORE), 'observation': source},
        'full_physical_source_after': 'separate campaign observation required',
        'whole_chain_quantum_security_qualified': False,
        'rust_baseline_whole_job_pass_claim': False,
        'resource_refusal': None, 'resource_monitor_interval_seconds': 2,
    }
    report_path = output / 'receipt.json'
    with report_path.open('x') as stream:
        json.dump(report, stream)
    started = time.monotonic()
    try:
        report['source_before'] = source_snapshot()
        borrowed_identities_match(setup)
        report['borrowed_identity_before_matches'] = True
        with (output / 'resource-observations.jsonl').open('x') as resource_log, (output / 'stdout.log').open('xb') as stdout, (output / 'stderr.log').open('xb') as stderr:
            initial = resources()
            resource_log.write(json.dumps(initial) + '\n')
            resource_log.flush()
            is_build = label in ('clippy', 'workspace-tests', 'doc-tests')
            def insufficient(sample):
                return (sample['memory']['MemAvailable_bytes'] < 256 * 1024**2 or
                        sample['volumes']['/tmp']['available_bytes'] < 256 * 1024**2 or
                        sample['volumes']['/workspace']['available_bytes'] < 128 * 1024**2)
            if is_build and insufficient(initial):
                report['resource_refusal'] = 'insufficient resources before starting own build'
            else:
                process = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr, env=environment, start_new_session=True)
                consecutive_low = 0
                while process.poll() is None:
                    time.sleep(2)
                    sample = resources()
                    resource_log.write(json.dumps(sample) + '\n')
                    resource_log.flush()
                    consecutive_low = consecutive_low + 1 if insufficient(sample) else 0
                    if is_build and consecutive_low >= 3:
                        report['resource_refusal'] = 'own build terminated after three low-resource observations'
                        os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid, signal.SIGKILL)
                            process.wait()
                        break
                report['exit_code'] = process.wait()
        report['source_after'] = source_snapshot()
        borrowed_identities_match(setup)
        report['borrowed_identity_after_matches'] = True
        report['status'] = ('RESOURCE_BLOCKED' if report['resource_refusal'] else
                            'COMMAND_SUCCEEDED' if report['exit_code'] == 0 else 'COMMAND_FAILED')
        if label.startswith('metadata') and report['exit_code'] == 0:
            metadata = json.loads((output / 'stdout.log').read_text())
            report['graph_summary'] = {'packages': len(metadata['packages']),
                                      'workspace_members': len(metadata['workspace_members']),
                                      'resolve_nodes': len(metadata['resolve']['nodes'])}
        if label in ('workspace-tests', 'doc-tests'):
            matches = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', (output / 'stdout.log').read_text(errors='replace'))
            report['completed_harness_results'] = [dict(zip(('result', 'passed', 'failed', 'ignored', 'measured', 'filtered'), (row[0], *map(int, row[1:])))) for row in matches]
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        report.update(status='OBSERVATION_FAILED', error=str(error))
    finally:
        report['finished_utc'] = datetime.now(timezone.utc).isoformat()
        report['elapsed_seconds'] = round(time.monotonic() - started, 3)
        report['logs'] = [{'file': item.name, 'bytes': item.stat().st_size, 'sha256': digest(item)} for item in output.iterdir() if item.suffix in ('.log', '.jsonl')]
        report_path.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'label': label, 'status': report['status'], 'exit_code': report['exit_code'], 'elapsed_seconds': report['elapsed_seconds'], 'receipt': str(report_path)}), flush=True)
    return 0 if report['status'] == 'COMMAND_SUCCEEDED' else 1


if __name__ == '__main__':
    raise SystemExit(main())
