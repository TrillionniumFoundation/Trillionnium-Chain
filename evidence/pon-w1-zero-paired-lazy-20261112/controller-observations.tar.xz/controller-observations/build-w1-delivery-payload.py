#!/usr/bin/env python3
"""Assemble reviewed documentation/data payload; never edits the checkout."""
from pathlib import Path
import ast
import base64
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE / 'chain-w1'
HEAD = '165d286b687e0a73d7fe68148d2179274fc0c0b8'
TREE = '2eb4f5e888a7a02f573d72a2fdf4d5a7cfc352e0'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def record(data):
    return {'bytes': len(data), 'sha256': sha(data), 'base64': base64.b64encode(data).decode()}


def main():
    archive = json.loads((HERE / 'formal-archive-receipt.json').read_text())
    supplement = json.loads((HERE / 'formal-supplement-v2-summary.json').read_text())
    restoration = json.loads((HERE / 'formal-index-restoration-summary.json').read_text())
    assert archive['result'] == 'COMPLETE_BYTE_VERIFIED_ARCHIVE'
    assert supplement['result'] == 'SUPPLEMENTAL_WORKSPACE_CLIPPY_PASSED'
    assert supplement['exit_code'] == 0 and not supplement['timed_out']
    assert restoration['source_guard_passed'] is True
    readme = (HERE / 'w1-evidence-README.draft.md').read_text()
    readme = readme.replace('work-security qualification and production activation remain HOLD',
                            'work-security qualification remains HOLD; production_activation=false')
    readme = readme.replace('## User-requested strategy set: coverage and remaining obligations',
        'Observed attempts per search differ across horizons: T0 has 1.5 at H1 and 1.875 at H8; '
        'T1 has 40.5 at H1 and 32.5 at H8. Cross-horizon cost differences therefore cannot be '
        'attributed only to preparation amortization. Comparisons remain within each fixed cost cell.\n\n'
        '## User-requested strategy set: coverage and remaining obligations')
    readme = re.sub(r'^\| Final evidence commit \|.*$',
        '| Evidence publication identity | A direct evidence/docs/corpus child of the native source. Its actual commit is recorded after commit in the external publication receipt and the PR execution ledger; native results remain bound to `165d`. |',
        readme, flags=re.M)
    provider_text = ('**PASS in the separate second supplement:** identical workspace/all-targets/all-features '
        'strict Clippy command, exit 0, no timeout; the original 3,600-second cap remains. '
        'Current OpenSSL 3.5.9 executable, two headers and two static libraries matched all five historical pins '
        'before and after; the original seven-key environment was selected explicitly. '
        'The first supplement exited 1 at the source guard before Clippy started because historical evidence '
        'paths had Git skip-worktree flags. Its original refusal remains in the archive. '
        'A separately recorded restoration checked every existing file against HEAD, restored only missing '
        'tracked bytes from local Git objects, cleared the hiding flags and passed the unchanged full source guard. '
        'The origin of the flags is not established. No source blob, checker, feature or timeout was changed.')
    readme = re.sub(r'\*\*PENDING_PROVIDER_SUPPLEMENT:.*?\*\* The original failure must remain visible\.',
                    provider_text + ' The original exit-101 compiler failure remains visible.', readme)
    archive_text = (f"Complete byte-verified archive: {archive['archive_bytes']:,} bytes, "
        f"SHA256 `{archive['archive_sha256']}`, {archive['member_count']} members. "
        'The full XZ/tar stream and every retained member were read back; archive integrity does not make '
        'the original failed checks phase pass.')
    readme = readme.replace('**PENDING_ARCHIVE_RECEIPT**', archive_text)
    readme = readme.replace('## Retained artifacts and publication placeholders', '## Retained artifacts')
    readme = readme.replace('Intended directory: `evidence/pon-w1-zero-paired-lazy-20261112`. Fill pending artifacts from receipts; never guess hashes or outcomes.',
        'This directory retains the original native observation and failures. The evidence commit changes documentation, evidence storage and the corresponding corpus pins; it does not rerun or relabel the native campaign.')
    readme = readme.replace('| File | Role / draft state |', '| File | Role |')
    readme = readme.replace('Derived report and final recorded statuses; root to finalize from retained observations',
        'Derived numerical report plus the recorded native, original-checks, restoration and supplemental outcomes')
    readme = re.sub(r'\*\*PENDING_ARTIFACT_HASH_TABLE:\*\* fill sizes/SHA256 only after verification\.',
        'The [delivery manifest](evidence-artifact-manifest.json) records each delivered file\'s size, SHA256 and Git blob. '
        'It excludes itself to avoid a hash cycle. The [ordered parts manifest](native-evidence.parts.json) '
        'binds all raw archive parts and their exact reassembly; each part is at most the unchanged 4 MiB reader cap.', readme)
    # Avoid assigning archive properties to the separate local-development file.
    readme = re.sub(r'^\| \[local-development\.tar\.xz\].*$',
        '| [local-development.tar.xz](local-development.tar.xz) | Earlier sparse-checkout development observations and failures, 17,036 bytes / SHA256 `13622446e72134ec3dbe49b4a57ab9cc5fb1ca6906d6072ee78e2ff660d6bcef`; never substituted for the complete-source native campaign |',
        readme, flags=re.M)
    assert 'PENDING_' not in readme and '@@PENDING' not in readme
    results = json.loads((HERE / 'formal-cost-results-small.json').read_text())
    results['execution_ledger'] = {
        'native_campaign': 'COMPLETE_COMPONENT_OBSERVATION',
        'original_checks_phase': {'success': False, 'workspace_clippy_exit_code': 101,
            'diagnostic': 'E0599 private_key_from_seed API unavailable under the original provider selection'},
        'first_provider_supplement': {'result': 'HOLD', 'exit_code': 1,
            'clippy_executed': False, 'reason': 'index hides tracked worktree entries'},
        'index_restoration': restoration, 'second_provider_supplement': supplement,
        'archive': archive, 'parent_pr': 908,
        'parent_c5_native': {'passed': 62, 'total': 64, 'failed_controls': ['pnq2-42', 'cleanup-01'], 'status': 'FAIL'},
        'final_evidence_child_validation': 'Separate external receipt and PR exact-head ledger; not assigned by this precommit file',
        'security_qualified': False, 'production_activation': False}
    new_files = {
        'README.md': readme.encode(), 'cost-results.md': (HERE / 'cost-results.md').read_bytes(),
        'results.json': (json.dumps(results, indent=2, sort_keys=True, allow_nan=False) + '\n').encode(),
        'excerpt.json': (HERE / 'formal-cost-excerpt.json').read_bytes(),
        'analyze-excerpt.mjs': (HERE / 'analyze-zero-paired-lazy-excerpt.mjs').read_bytes(),
        'publication-helper.py': (HERE / 'remote-publish-w1-evidence.py').read_bytes(),
        'final-validation-helper.py': (HERE / 'final-evidence-validator.py').read_bytes(),
        'local-development.tar.xz': (HERE / 'local-development.tar.xz').read_bytes(),
        'controller-observations.tar.xz': (HERE / 'controller-observations.tar.xz').read_bytes(),
    }
    docs = {}
    research = 'docs/research/PON_W1_ZERO_PAIRED_LAZY_V1.md'
    addition = ('\n## Recorded native observation\n\n'
        'The [frozen-source results and complete strategy-coverage ledger](../../evidence/pon-w1-zero-paired-lazy-20261112/README.md) '
        'retain all six registered shards on source `165d286b687e0a73d7fe68148d2179274fc0c0b8`. '
        'The four cost cells observed the same fixed `full-limb-sparse-lazy` arm below the new '
        '`zero-paired-lazy` arm in aggregate CPU and wall cost per accepted winner. '
        'The new composition is a measured legal alternative, not the fastest measured arm or an attacker lower bound. '
        'The original OpenSSL compile failure, source-index refusal and separate successful pinned-provider supplement remain distinct. '
        'The evidence child keeps the measurement source unchanged; production and work-security qualification remain HOLD.\n')
    before = (ROOT / research).read_bytes(); data = before + addition.encode()
    docs[research] = {'before_sha256': sha(before), **record(data)}
    comparison = 'docs/protocol/pon-nakamoto-v1/details/W1_IMPLEMENTATION_COMPARISON.md'
    before = (ROOT / comparison).read_bytes()
    insertion = ('\nThe [zero-paired plus winner-only experiment](../../../research/PON_W1_ZERO_PAIRED_LAZY_V1.md) '
        'now composes two legal choices previously tested separately. Its '
        '[source-bound native results and attacker-strategy ledger](../../../../evidence/pon-w1-zero-paired-lazy-20261112/README.md) '
        'retain the slower observations: on the recorded x64 zero-material grid, the same fixed FullLimb sparse lazy arm '
        'has lower aggregate CPU and wall cost per accepted winner than zero-paired lazy in all four cost cells. '
        'Scalar-product counts do not select the fastest implementation or prove a security floor.\n')
    header = b'# W1 implementation equivalence and cost comparison\n'
    assert before.startswith(header)
    data = header + insertion.encode() + before[len(header):]
    docs[comparison] = {'before_sha256': sha(before), **record(data)}
    plan = 'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
    before = (ROOT / plan).read_bytes()
    addition = ('**W1 measured legal-strategy baseline, 2026-11-11 America/New_York — HOLD:**\n\n'
        'The [source-bound observation](../../evidence/pon-w1-zero-paired-lazy-20261112/README.md) '
        'completed all six registered zero-paired/lazy shards on frozen source `165d286b687e0a73d7fe68148d2179274fc0c0b8`: '
        '240 preparations, 800 searches, 12,840 attempts, 12,080 misses, 760 hits and 3,280 full verifier calls. '
        'The same fixed FullLimb sparse lazy strategy has the lowest observed aggregate CPU/wall cost in all four cost cells. '
        'The new zero-paired lazy composition did not lower that measured baseline. Preserve the negative comparison and '
        'all five arms; do not turn the 152,832 operation count into a timing or hardness claim.\n\n'
        'The ledger maps every requested strategy class to existing code and open obligations. Only zero material, '
        'actual H1/H8 preparation reuse and winner-only proof construction were measured here. '
        'Hardware, cross-miner/epoch reuse, actual padded input provenance, false-search/receiver costs, self-traffic/rewards '
        'and maintenance costs remain separate. Keep the original workspace Clippy failure, the later source-index refusal '
        'and exact-file restoration, and the separately successful strict command with the pinned provider. '
        'The evidence/docs/corpus child requires its own source-bound checks; the native campaign remains labeled `165d`. '
        'Parent #908 C5 remains FAIL at 62/64 named controls. Ticket independence, cheapest-strategy optimality, '
        'resource ownership, joint DAA/chainwork and production qualification remain unresolved.\n\n')
    docs[plan] = {'before_sha256': sha(before), **record(addition.encode() + before)}
    payload = {'source_commit': HEAD, 'source_tree': TREE,
               'new_evidence_files': {name: record(data) for name, data in new_files.items()},
               'documents': docs}
    destination = HERE / 'w1-evidence-delivery-payload.json'
    data = (json.dumps(payload, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    assert len(data) <= 1024 * 1024
    destination.open('xb').write(data)
    (HERE / 'w1-evidence-README.final.md').open('xb').write(readme.encode())
    print(json.dumps({'path': str(destination), 'bytes': len(data), 'sha256': sha(data),
                      'new_files': sorted(new_files), 'changed_documents': sorted(docs)}))


if __name__ == '__main__':
    main()
