#!/usr/bin/env python3
from pathlib import Path
import json,shutil,struct,subprocess,tempfile,unittest
from independent_check import ROOT,verify_export,w,H
from verify_research_sources import verify as verify_sources

BIN=ROOT/'target/release/pon-research'

class IndependentW1Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='p0-check-',dir=ROOT/'evidence')
        self.root=Path(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def export(self,case='maintenance'):
        out=self.root/'winner'
        r=subprocess.run([str(BIN),'export',str(out),case,'1','64'],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stderr)
        return out
    def test_actual_maintenance_material_and_complete_prefix_replay(self):
        out=self.export()
        result=verify_export(out)
        self.assertEqual(result['full_prefix_values_checked'],32768)
        proof=(out/'pnw1.bin').read_bytes()
        words=struct.unpack('<'+'I'*(3*w.CELLS),proof[4:-32])
        self.assertEqual(list(words[:w.CELLS]),[(13*i+17)%257 for i in range(w.CELLS)])
        self.assertEqual(list(words[w.CELLS:2*w.CELLS]),[(29*i+31)%263 for i in range(w.CELLS)])
        frozen=(ROOT/'upstream/trillionnium/crates/trnm-mvcc-fee/src/continuity_v1.rs').read_text()
        self.assertIn('((13 * i + 17) % 257)',frozen)
        self.assertIn('((29 * i + 31) % 263)',frozen)
    def test_single_wrong_prefix_noise_and_statement_are_rejected(self):
        out=self.export('rank2')
        verify_export(out)
        for filename,offset in [('transcript.bin',131071),('noise.bin',7),('noised-a.bin',16383),('noised-b.bin',0),('pnw1.bin',4+2*w.CELLS*4),('header.bin',70)]:
            p=out/filename;original=p.read_bytes();bad=bytearray(original);bad[offset]^=1;p.write_bytes(bad)
            with self.assertRaises(ValueError,msg=filename):verify_export(out)
            p.write_bytes(original)
    def test_zero_grinding_and_no_fabricated_qualification(self):
        out=self.export('zero');p=out/'statement.json';original=p.read_text();base=json.loads(original)
        for key in ['fri_commit_grinding_bits','fri_query_grinding_bits','proof_grinding_bits']:
            for value in [1,True,-1,'0']:
                altered=dict(base);altered[key]=value;p.write_text(json.dumps(altered))
                with self.assertRaisesRegex(ValueError,'GRINDING_NOT_ZERO'):verify_export(out)
        for key in ['transparent_backend_executed','succinct_proof_generated','computational_hardness_qualified','post_quantum_qualified','parent_state_or_chain_validity_checked','independent_work_puzzle','node_task_eligibility_checked']:
            altered=dict(base);altered[key]=True;p.write_text(json.dumps(altered))
            with self.assertRaisesRegex(ValueError,'UNSUPPORTED_ACCEPTANCE_CLAIM'):verify_export(out)
        p.write_text(original);verify_export(out)
    def test_new_solvers_match_independent_python_for_high_field_inputs(self):
        for rank in [0,1,2,8]:
            left=[(w.Q-1-(i*31)%1031)for i in range(w.N*rank)]
            right=[(w.Q-1-(i*47)%1019)for i in range(rank*w.N)]
            a=w.mm(left,right,w.N,rank,w.N)
            b=w.mm(right,left,w.N,rank,w.N)if rank else [0]*w.CELLS
            # b is another legal matrix; no declared rank is trusted by Rust.
            task=w.task_id(a,b);header=bytearray(318);header[:6]=b'PNH1\1\0';header[118:150]=b'\xff'*32;header[278:310]=task;header[310:318]=(3).to_bytes(8,'little')
            hp=self.root/f'header-{rank}';hp.write_bytes(header)
            mp=self.root/f'material-{rank}';mp.write_bytes(w.field_bytes(a)+w.field_bytes(b))
            expected=w.prove(H('challenge',bytes(header)),a,b)
            for method in ['low-rank-prefix-scalar','low-rank-prefix-paired']:
                op=self.root/f'{rank}-{method}.bin'
                r=subprocess.run([str(BIN),'solve',method,str(hp),str(mp),str(op)],capture_output=True,text=True)
                self.assertEqual(r.returncode,0,r.stderr)
                self.assertEqual(op.read_bytes(),expected)
                w.verify(H('challenge',bytes(header)),task,b'\xff'*32,op.read_bytes())
    def test_dense_task_is_explicitly_unsupported_and_never_falls_back(self):
        a=[int(i//w.N==i%w.N)for i in range(w.CELLS)]
        hp=self.root/'header';hp.write_bytes(b'PNH1\1\0'+b'\0'*312)
        mp=self.root/'material';mp.write_bytes(w.field_bytes(a)*2);op=self.root/'proof'
        r=subprocess.run([str(BIN),'solve','low-rank-prefix-paired',str(hp),str(mp),str(op)],capture_output=True,text=True)
        self.assertNotEqual(r.returncode,0);self.assertIn('unsupported',r.stderr);self.assertFalse(op.exists())
    def test_winner_search_exhaustion_keeps_failed_attempt_cost(self):
        out=self.root/'exhausted'
        r=subprocess.run([str(BIN),'export',str(out),'zero','20','1'],capture_output=True,text=True)
        self.assertNotEqual(r.returncode,0)
        search=json.loads((out/'search.json').read_text())
        self.assertFalse(search['winner_found']);self.assertEqual(len(search['attempts']),1)
        self.assertGreater(search['attempts'][0]['process_cpu_ns'],0)
        self.assertFalse((out/'statement.json').exists())

    def test_pinned_sources_refuse_changed_upstream_and_compiled_bytes(self):
        clean=verify_sources(); snapshot=self.root/'source-snapshot'
        for rel in clean['checks'] + ['source-manifest.json','parallel-source-manifest.json','vendor/hex/SOURCE.json']:
            target=snapshot/rel;target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(ROOT/rel,target)
        verify_sources(snapshot)
        for rel in ['src/pon_work.rs','upstream/formal/pon-nakamoto-v1/work_oracle.py','upstream-parallel/trillionnium/crates/trnm-crypto-primitives/src/pon_work/full_relation.rs']:
            path=snapshot/rel;original=path.read_bytes();path.write_bytes(original+b'\n')
            with self.assertRaisesRegex(ValueError,'SOURCE_MISMATCH'):verify_sources(snapshot)
            path.write_bytes(original)

if __name__=='__main__':unittest.main(verbosity=2)
