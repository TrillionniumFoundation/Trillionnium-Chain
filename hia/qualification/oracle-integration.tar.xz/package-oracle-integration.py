from pathlib import Path
import hashlib, json
from owner_evidence_lib import Package, BASE, ROOT, encoded

package = Package('oracle-integration')
included = {'controls': package.directory('controls', BASE / 'oracle-integration-controls'),
            'documentation-correction': package.directory('documentation-correction', BASE / 'oracle-documentation-correction')}
sources = json.loads((BASE / 'oracle-integration-controls/integration-sources.json').read_bytes())
package.snapshot('integration-source-snapshots', sources, ROOT)
for name in ('check_oracle_static.py', 'run_oracle_controls.py', 'preserve_oracle_prior_runs.py',
             'oracle-controls.stdout.raw', 'oracle-controls.stderr.raw',
             'oracle-static.stdout.raw', 'oracle-static.stderr.raw',
             'oracle-package.stdout.raw', 'oracle-package.stderr.raw',
             'oracle-prior-preservation.stdout.raw', 'oracle-prior-preservation.stderr.raw',
             'oracle-archive-readback.json', 'oracle-volumes-readback.json',
             'oracle-mac-github-route-verification.json'):
    package.file('root/' + name, BASE / name)
for path in sorted((BASE / 'oracle-work/retained-prior-runs').glob('*.json')):
    package.file('preservation/' + path.name, path)
package.file('package-oracle-integration.py', Path(__file__).resolve())
package.file('package-support.py', BASE / 'owner_evidence_lib.py')
package.finish({'schema': 'trnm.hia.oracle-integration-package.v1',
    'audited_parent': 'd49083115e977f9c1947f92b9c10d93870e1b752',
    'included_directories': included, 'finite_controls_passed': 33,
    'bootstrap_test_groups': 4, 'actual_bootstrap_invocations': 168,
    'component_discovery': {'total': 476, 'general': 469, 'state_root': 7, 'runtime_executed': False},
    'workflow_jobs': 54, 'bootstrap_gates': 42, 'timeout_minutes': 20,
    'metadata_only_cargo_packages': 26, 'original_workspace_tests_and_clippy_executed': False,
    'peer_direction_fix_is_documentation_only': True,
    'old_runtime_source_snapshots_rewritten': False,
    'runtime_reexecuted_by_packager': False, 'whole_chain_native': False,
    'old_stack_can_be_removed': False, 'production_activation': False},
    archive_filename='oracle-integration.tar.xz')
archive = json.loads((BASE / 'oracle-integration-archive-readback.json').read_bytes())
record = {'schema': 'trnm.hia.oracle-integration.v1', 'status': 'PASS_FINITE_INTEGRATION_CONTROLS',
    'audited_parent': 'd49083115e977f9c1947f92b9c10d93870e1b752',
    'archive': archive, 'integration_source_inputs': sources,
    'static_controls': json.loads((BASE / 'oracle-integration-controls/static-checks.json').read_bytes()),
    'cargo_graph': json.loads((BASE / 'oracle-integration-controls/cargo-metadata-readback.json').read_bytes()),
    'finite_tests': 33, 'bootstrap_test_groups': 4, 'bootstrap_actual_invocations': 168,
    'component_discovery_is_not_execution': True,
    'documentation_correction': json.loads((BASE / 'oracle-documentation-correction/correction.json').read_bytes()),
    'prior_success_archives': [json.loads(p.read_bytes()) for p in sorted((BASE / 'oracle-work/retained-prior-runs').glob('*.json'))],
    'hosted_execution': 'NOT_RUN_FOR_THIS_UNCOMMITTED_INCREMENT',
    'original_four_second_service_budget_unchanged': True,
    'whole_chain_native': False, 'old_stack_can_be_removed': False, 'production_activation': False}
target = ROOT / 'hia/qualification/oracle-integration.json'
assert not target.exists(); target.write_bytes(encoded(record))
print(json.dumps({'record': str(target), 'source_inputs': len(sources), 'archive': archive}))
