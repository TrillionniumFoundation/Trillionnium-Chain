"""Independent scalar-state and deadline review; no physical security claim."""
from pathlib import Path
from fractions import Fraction
import hashlib
import json
import sys

root = Path(__file__).resolve().parent.parent / "chain-quantum-next"
formal = root / "formal/pon-nakamoto-v1"
sys.path[:0] = [str(formal), str(formal / "experiments")]
import w1_marked_domain_campaign as campaign
from w1_marked_domain import MAX_PROCESSORS, enumerate_domain
from w1_bounded_search import simulate_bounded_measurements
from quantum_adversarial_search import TrialCosts

paths = ("w1_bounded_search.py", "test_w1_bounded_search.py",
         "quantum_adversarial_search.py", "w1_marked_domain.py")
before = {name: hashlib.sha256((formal / name).read_bytes()).hexdigest() for name in paths}
base = campaign.retained.reduced_template()
domains = [enumerate_domain(campaign.with_parameters(base, 3, target=target))
           for target in ((1 << 254) - 1, (1 << 255) - 1, 3 * (1 << 254) - 1, (1 << 256) - 1)]
cost = TrialCosts(2, 3, 5, 7, 11, 13, "upward")
rows = []
for domain in domains:
    for predicate in ("full", "prefix-restricted"):
        marked = {row["nonce"] for row in domain["outcomes"] if row["winner"]
                  and (predicate == "full" or row["prefix_all_accepted"])}
        legal = {row["nonce"] for row in domain["outcomes"] if row["winner"]}
        for iterations in (0, 1, 2, 3, 10):
            amplitudes = [Fraction(1)] * domain["domain_size"]
            for _ in range(iterations):
                phased = [-a if i in marked else a for i, a in enumerate(amplitudes)]
                mean = sum(phased) / domain["domain_size"]
                amplitudes = [2 * mean - a for a in phased]
            single = sum(amplitudes[i] ** 2 for i in legal) / domain["domain_size"]
            for processors in (1, 3, MAX_PROCESSORS):
                report = simulate_bounded_measurements(
                    (domain,), ((0, iterations),), processors, 901, (cost,), "100000",
                    predicate=predicate, propagation_seconds=(17,))
                trial = report["trials"][0]
                expected = float(1 - (1 - single) ** processors)
                actual = trial["conditional_batch_valid_candidate_probability"]
                assert abs(expected - actual) < 2e-13, (predicate, iterations, processors, expected, actual)
                assert all(m["candidate_check_completed"] and m["winner"] == (m["nonce"] in legal)
                           for m in trial["measurements"])
                assert report["success"] == any(m["nonce"] in legal for m in trial["measurements"])
                assert report["native_blocks_admitted"] == 0 and not report["consensus_security_theorem"]
                rows.append({"template": domain["template_sha256"], "size": domain["domain_size"],
                             "legal": len(legal), "marked": len(marked), "predicate": predicate,
                             "iterations": iterations, "processors": processors,
                             "expected_probability": expected, "observed_probability": actual,
                             "delivered": report["success"]})


def fraction(value):
    return Fraction(value["numerator"], value["denominator"])


full = enumerate_domain(campaign.with_parameters(base, 1))
limits = []
for half in range(137):
    limit = Fraction(half, 2)
    report = simulate_bounded_measurements((full,), ((0, 2), (0, 2)), 2, 9, (cost,),
                                          str(half / 2), propagation_seconds=(17,))
    assert fraction(report["elapsed_seconds_exact"]) == limit
    assert sum(fraction(value) for value in report["phase_paid_seconds_exact"].values()) == limit
    assert report["success"] == (limit == 68)
    assert all(0 <= fraction(phase["paid_seconds_exact"]) <= fraction(phase["planned_seconds_exact"])
               for trial in report["trials"] for phase in trial["phases"])
    limits.append({"horizon": str(half / 2), "success": report["success"],
                   "termination": report["termination"]})
after = {name: hashlib.sha256((formal / name).read_bytes()).hexdigest() for name in paths}
assert before == after, "SOURCE_CHANGED_DURING_REVIEW"
record = {
    "schema": "bounded-search-independent-review-v1", "source_sha256": before,
    "source_unchanged": True, "full_state_oracle_reflection_probability_controls": rows,
    "exact_horizon_ledger_sweep": limits, "controls_total": len(rows) + len(limits),
    "actual_quantum_or_native_attack": False,
    "review_limits": "Reduced literal domains and exact rational reference vectors; arbitrary amplitudes still use declared binary64 approximation, proof clocks are assumptions, no safety theorem.",
}
out = Path(__file__).with_suffix(".json")
out.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"path": str(out), "controls_total": record["controls_total"],
                  "probability_controls": len(rows), "horizon_controls": len(limits),
                  "domains": [(d["domain_size"], d["marked_count"], d["prefix_restricted_marked_count"])
                              for d in domains], "source_unchanged": True}))
