#!/usr/bin/env python3
"""Read existing competition evidence; does not run a node, certify security or write files."""
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path

HEAD = 'a56889a54aac5f14141bb45fb602141dd6a37645'
INPUTS = ('native-fixture.json', 'native-competition-plan.json', 'native-competition-fixture.json',
          'competition-certificates.json', 'competition-samples.json')
TEST = 'quantum_native_bridge_tests::competition::replay_source_bound_native_competition_samples'

def require(condition, message):
    if not condition: raise ValueError(message)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

def unique(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, 'DUPLICATE_JSON_KEY')
        value[key] = item
    return value

def strict(raw):
    def invalid(value): raise ValueError('NONFINITE_JSON:' + value)
    return json.loads(raw, object_pairs_hook=unique, parse_constant=invalid)

def exact(value):
    require(type(value) is dict and set(value) == {'numerator', 'denominator'}, 'RATIONAL_SHAPE')
    require(type(value['numerator']) is int and type(value['denominator']) is int and value['denominator'] > 0,
            'RATIONAL_TYPE')
    return str(Fraction(value['numerator'], value['denominator']))

def main(directory, expected_source, execution_receipt):
    snapshots = {}
    def load(name):
        require('/' not in name and '\\' not in name and name not in ('', '.', '..'), 'TOP_LEVEL_EVIDENCE_PATH')
        raw = (directory / name).read_bytes()
        snapshots[name] = raw
        return strict(raw)
    native = load('native-competition-replay.json')
    require(native.get('schema') == 'trnm-w1-native-competition-replay-v1', 'NATIVE_REPLAY_SCHEMA')
    require(native['native_source']['git_head'] == expected_source, 'FROZEN_SOURCE_MISMATCH')
    data = {name: load(name) for name in INPUTS}
    hashes = {name: hashlib.sha256(snapshots[name]).hexdigest() for name in INPUTS}
    require(native['verified_inputs'] == hashes == native['independent_python_verifier']['verified_inputs'], 'RAW_INPUT_RECEIPTS')
    require(native['independent_python_verifier']['status'] == 'VERIFIED', 'PYTHON_RECEIPT_NOT_VERIFIED')
    sample = data['competition-samples.json']
    sample_runs = {row['name']: row for row in sample['runs']}
    require(len(sample_runs) == len(sample['runs']) == len(native['runs']), 'RUN_INVENTORY')
    require({row['name'] for row in native['runs']} == set(sample_runs), 'RUN_NAMES')
    named_test_checked = False
    if execution_receipt is not None:
        receipt = strict(execution_receipt.read_bytes())
        require(receipt.get('result') == 'PASS' and receipt.get('test') == TEST
                and type(receipt.get('executed_tests')) is int and receipt['executed_tests'] == 1, 'NAMED_TEST_RECEIPT')
        named_test_checked = True
    results = []
    for run in native['runs']:
        modeled = sample_runs[run['name']]
        require(run['ever_private_replacement'] is modeled['expected_ever_private_replacement']
                and run['private_active_at_horizon'] is modeled['expected_private_active_at_horizon'], 'NATIVE_EXPECTED_EVENT_MATCH')
        admissions = run['receiver_admissions']
        require(len(admissions) == len(modeled['receiver_events']) and bool(admissions), 'RECEIVER_EVENT_COUNT')
        events = []
        for actual, expected in zip(admissions, modeled['receiver_events']):
            require(canonical(actual['expected_event']) == canonical(expected), 'RECEIVER_EVENT_IDENTITY')
            require(actual['native_library_admitted'] is True and actual['selected_tip'] == expected['selected_tip']
                    and actual['selected_chainwork_hex'] == expected['selected_chainwork_hex'], 'NATIVE_SELECTED_TIP_WORK')
            events.append({**{key: expected[key] for key in ('owner', 'block_id', 'parent_id', 'height',
                'selected_tip_before', 'selection_changed', 'private_replacement')},
                'declared_arrival_seconds_exact': exact(expected['at_seconds']),
                'logical_native_observed_now': actual['logical_observed_now'],
                'block_chainwork': int(expected['block_chainwork_hex'], 16),
                'selected_tip': actual['selected_tip'], 'selected_chainwork': int(actual['selected_chainwork_hex'], 16)})
        honest = []
        for production in run['honest_production']:
            ledger_name = production['ledger_file']
            ledger_raw = (directory / ledger_name).read_bytes() if ('/' not in ledger_name and '\\' not in ledger_name and ledger_name not in ('', '.', '..')) else None
            require(ledger_raw is not None and len(ledger_raw) == production['ledger_bytes']
                    and hashlib.sha256(ledger_raw).hexdigest() == production['ledger_sha256'], 'HONEST_LEDGER_BINDING')
            snapshots[ledger_name] = ledger_raw
            attempts = production['attempts']
            honest.append({key: production[key] for key in ('height', 'parent_id', 'selected_block_id',
                'prepare_elapsed_ns', 'admit_activate_elapsed_ns', 'complete_pipeline_elapsed_ns',
                'ledger_file', 'ledger_sha256')})
            honest[-1].update(attempts=len(attempts), misses=sum(row['native_winner'] is False for row in attempts),
                nonces=[row['nonce'] for row in attempts],
                proof_cpu_wall_ns=sum(row['proof_elapsed_ns'] for row in attempts),
                verification_cpu_wall_ns=sum(row['verification_elapsed_ns'] for row in attempts))
        trajectory = modeled['raw_observation']['trajectory']
        observations = [step['edge']['observation'] for step in trajectory]
        phases = [{'trajectory_index': i, 'phase': phase['phase'], 'planned_exact': exact(phase['planned']),
                   'paid_exact': exact(phase['paid']), 'complete': phase['complete']}
                  for i, observation in enumerate(observations) for phase in observation.get('phases', [])]
        results.append({key: run[key] for key in ('name', 'scenario_id', 'execution_kind', 'observation_kind',
            'ever_private_replacement', 'private_active_at_horizon', 'authenticated_reopen_equal',
            'completed_candidate_checks_replayed', 'private_proofs_held', 'private_proofs_not_published',
            'receiver_history_replay_elapsed_ns', 'private_history_replay_elapsed_ns', 'honest_history_replay_elapsed_ns')})
        results[-1].update(seed=modeled['raw_observation'].get('seed'),
            publication_complete=modeled['publication_complete'],
            private_terminal_result=observations[-1]['result'],
            modeled_private_elapsed_exact=exact(modeled['logical_elapsed_seconds_exact']),
            declared_receiver_horizon_exact=exact(modeled['receiver_observed_until_seconds']),
            observed_private_nonces=[x['nonce'] for x in observations if x.get('nonce') is not None],
            private_candidate_misses=sum(row['native_winner'] is False for row in run['candidate_probes']),
            private_cpu_probe_components=[{key: row[key] for key in ('nonce', 'candidate_block_id',
                'native_winner', 'actual_prepare_elapsed_ns', 'actual_proof_elapsed_ns',
                'actual_candidate_verification_elapsed_ns', 'actual_private_admission_elapsed_ns')}
                for row in run['candidate_probes']], modeled_paid_phases=phases,
            honest_production=honest, receiver_events=events,
            final_selected_tip=admissions[-1]['selected_tip'],
            final_selected_chainwork=int(admissions[-1]['selected_chainwork_hex'], 16))
    certificates = []
    for key, record in data['competition-certificates.json']['certificates'].items():
        complete = record.get('status') == 'COMPLETE' and record.get('finite_model_certificate_complete') is True
        certificates.append({'key': key, 'status': record['status'], 'state_count': record['state_count'],
            'risk_upper_exact': exact(record['risk_upper']) if complete else None,
            'fixed_policy_risks_exact': {q: exact(value) for q, value in record['fixed_policy_risks'].items()} if complete else None,
            'conditional_private_machine_bounds': record['conditional_machine_risk_bounds'] if complete else None})
    require(all((directory / name).read_bytes() == raw for name, raw in snapshots.items()), 'INPUT_CHANGED_DURING_READBACK')
    print(json.dumps({'schema': 'trnm-native-competition-field-readback-v1', 'status': 'READBACK_ONLY',
        'scope': 'consistency and field extraction only; not native execution attestation, a Bellman checker, hardware calibration or a network theorem',
        'source_head': expected_source, 'named_execution_receipt_checked': named_test_checked,
        'source_file_sha256': native['native_source']['source_sha256'], 'raw_input_sha256': hashes,
        'native_replay_sha256': hashlib.sha256(snapshots['native-competition-replay.json']).hexdigest(),
        'claims_as_reported': native['claims'], 'observer_controls': sample['observer_controls'],
        'declared_seeded_runs': sample['declared_seeded_run_count'],
        'actual_seeded_runs': sum(row['observation_kind'] == 'fixed-seed-conditional-competition-sample' for row in results),
        'certificates': certificates, 'runs': results}, indent=2, sort_keys=True, allow_nan=False))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--expected-source', default=HEAD)
    parser.add_argument('--native-test-receipt', type=Path)
    args = parser.parse_args()
    main(args.directory, args.expected_source, args.native_test_receipt)
