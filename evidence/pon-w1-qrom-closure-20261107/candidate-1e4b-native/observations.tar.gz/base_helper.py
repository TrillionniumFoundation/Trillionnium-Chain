#!/usr/bin/env python3
"""Task-local native observations on frozen 7150; never edits its source tree."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import signal
import stat
import subprocess
import time
import tomllib

REPO = Path('/home/qian-qi/work/chain-qrom-local-20261107-7150')
OUT = Path('/home/qian-qi/work/chain-qrom-closure-20261107-evidence/native-7150')
HEAD = '7150d96a2112875b4afcf3023361a5cef4a0e4b1'
TARGET = OUT / 'cargo-target'
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', CARGO_BUILD_JOBS='2',
           CARGO_TARGET_DIR=str(TARGET), CARGO_TERM_COLOR='never')
RECORDS = []
FIXTURE = 'evidence/pon-w1-full-v2-20261105/'
FIXED = [FIXTURE + name for name in ['succinct.bin','header.bin','expected-artifacts.bin','input.bin','guest.bin']]
FIXED += ['evidence/pon-w1-complete-succinct-20261028/full-proof/' + name for name in ['succinct.bin','input.bin']]
V2 = 'formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.toml'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def frozen():
    actual = git('rev-parse','HEAD').decode().strip()
    if actual != HEAD:
        raise RuntimeError('frozen HEAD changed: ' + actual)


def observe(name, command, timeout=600, expected=0):
    frozen()
    stdout_path, stderr_path = OUT/(name+'.stdout.log'), OUT/(name+'.stderr.log')
    started, begin = datetime.now(timezone.utc).isoformat(), time.monotonic()
    print(json.dumps({'stage_started':name,'command':command}), flush=True)
    timed_out, launch_error = False, None
    exit_code = None
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        try:
            process = subprocess.Popen(command, cwd=REPO, env=ENV, stdout=stdout, stderr=stderr,
                                       start_new_session=True)
            try:
                process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            exit_code = process.returncode
        except OSError as error:
            launch_error = str(error)
            stderr.write((launch_error+'\n').encode())
    record = {'name':name,'command':command,'cwd':str(REPO),'source_commit':HEAD,
              'started_utc':started,'elapsed_seconds':time.monotonic()-begin,
              'exit_code':exit_code,'timeout_seconds':timeout,'timed_out':timed_out,
              'launch_error':launch_error,'expected_exit':expected,
              'expectation_met':not timed_out and launch_error is None and
              ((exit_code is not None and exit_code>0) if expected=='nonzero' else exit_code==expected),
              'post_quantum_soundness_qualified':False,'consensus_admission':False}
    for stream,path in [('stdout',stdout_path),('stderr',stderr_path)]:
        data=path.read_bytes()
        record[stream+'_bytes']=len(data)
        record[stream+'_sha256']=sha(data)
    write_json(OUT/(name+'.json'),record)
    RECORDS.append(record)
    write_json(OUT/'stage-status.json',{'head':HEAD,'records':RECORDS,'full_tracked_identity_claimed':False})
    print(json.dumps(record,sort_keys=True),flush=True)
    return record['expectation_met']


def tree():
    result={}
    for record in git('ls-tree','-r','-z',HEAD).split(b'\0'):
        if not record: continue
        header,path=record.split(b'\t',1)
        mode,kind,oid=header.decode().split()
        if kind!='blob': raise RuntimeError('non-blob tracked entry')
        result[path.decode()]={'mode':mode,'git_blob':oid}
    return result


def include_inventory(entries):
    """Resolve literal and manifest-relative include! forms; retain all others."""
    resolved, unresolved = [], []
    prefixes=('trillionnium/', 'formal/pon-nakamoto-v1/w1_v2_verifier/',
              'formal/pon-nakamoto-v1/w1_hardened_verifier/', 'formal/pon-nakamoto-v1/w1_zkvm/relation/')
    for relative in entries:
        if not relative.endswith('.rs') or not relative.startswith(prefixes):
            continue
        path=REPO/relative
        source=path.read_text()
        for match in re.finditer(r'include_(?:str|bytes)\s*!\s*\(',source):
            index,start,depth,quoted,escaped=match.end(),match.end(),1,False,False
            while index<len(source) and depth:
                char=source[index]
                if quoted:
                    if escaped: escaped=False
                    elif char=='\\': escaped=True
                    elif char=='"': quoted=False
                elif char=='"': quoted=True
                elif char=='(': depth+=1
                elif char==')': depth-=1
                index+=1
            expr=source[start:index-1].strip()
            plain=re.fullmatch(r'"([^"\\]*)"\s*,?',expr,re.S)
            concat=re.fullmatch(r'concat!\s*\(\s*env!\s*\(\s*"CARGO_MANIFEST_DIR"\s*\)\s*,\s*"([^"\\]*)"\s*,?\s*\)\s*,?',expr,re.S)
            target=None
            if plain:
                target=(path.parent/plain.group(1)).resolve()
            elif concat:
                manifest=next((parent for parent in path.parents if (parent/'Cargo.toml').is_file()),None)
                if manifest is not None:
                    target=Path(str(manifest)+concat.group(1)).resolve()
            row={'source':relative,'line':source[:match.start()].count('\n')+1,'expression':expr}
            if target is None or not target.is_relative_to(REPO):
                unresolved.append(row)
            else:
                row['target']=str(target.relative_to(REPO))
                resolved.append(row)
    return {'resolved':resolved,'unresolved':unresolved,
            'scope':'Lexical selected-source include inventory; not a complete Rust macro/build-script dependency proof.'}


def selected_snapshot(name, entries, includes):
    frozen()
    selected={path for path in entries if not path.startswith('evidence/')}
    selected.update(FIXED)
    selected.update(item['target'] for item in includes['resolved'])
    rows=[]
    for relative in sorted(selected):
        expected=entries.get(relative)
        path=REPO/relative
        row={'path':relative,'expected':expected,'scope':'non_evidence_source_or_resolved_include_or_fixed_verification_input'}
        try:
            info=path.lstat()
            if not stat.S_ISREG(info.st_mode): raise ValueError('not a regular file')
            data=path.read_bytes()
            oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            row.update(bytes=len(data),sha256=sha(data),actual_git_blob=oid,
                       matches_head=expected is not None and oid==expected['git_blob'])
        except (OSError,ValueError) as error:
            row.update(matches_head=False,error=str(error))
        rows.append(row)
    result={'schema':'TRNM-W1-NATIVE-SELECTED-SOURCE1','head':HEAD,'selected_count':len(rows),
            'non_evidence_tracked_count':sum(not p.startswith('evidence/') for p in entries),
            'selected_bytes_match_head':all(row['matches_head'] for row in rows),
            'full_tracked_identity_claimed':False,'files':rows,'include_inventory':includes}
    write_json(OUT/(name+'.json'),result)
    print(json.dumps({'selected_snapshot':name,'count':len(rows),'matches':result['selected_bytes_match_head'],
                      'mismatches':[row['path'] for row in rows if not row['matches_head']]}),flush=True)
    return result


def v2_feature_check():
    data=json.loads((OUT/'cargo-metadata-v2.stdout.log').read_text())
    packages={p['id']:p for p in data['packages']}
    nodes={p['id']:p for p in data['resolve']['nodes']}
    package=next(p for p in packages.values() if p['name']=='risc0-zkvm')
    features=nodes[package['id']]['features']
    manifests={}
    for relative in [V2,'formal/pon-nakamoto-v1/w1_hardened_verifier/Cargo.toml']:
        dep=tomllib.loads((REPO/relative).read_text())['dependencies']['risc0-zkvm']
        manifests[relative]=dep
        assert dep['default-features'] is False and dep['version']=='=3.0.6'
        assert set(dep['features'])=={'std','disable-dev-mode'}
    assert package['version']=='3.0.6'
    assert 'disable-dev-mode' in features and 'std' in features
    assert not {'default','prove','client','bonsai'}&set(features)
    result={'package_id':package['id'],'features':features,'direct_dependency_declarations':manifests,
            'default_prover_client_features_absent':True,'disable_dev_mode_active':True,
            'proof_environment_variable_names_present':[key for key in ['RISC0_DEV_MODE','RISC0_PROVER','BONSAI_API_URL','BONSAI_API_KEY'] if key in ENV],
            'environment_values_disclosed':False,'post_quantum_soundness_qualified':False}
    write_json(OUT/'v2-feature-check.json',result)
    print(json.dumps({'feature_check':'PASS','features':features}),flush=True)


def official_image_probe():
    libraries=list((TARGET/'release/deps').glob('librisc0_zkvm-*.rlib'))
    if len(libraries)!=1:
        write_json(OUT/'official-image-probe-unavailable.json',{'reason':'need one unambiguous newly built zkvm rlib','count':len(libraries)})
        return
    source=OUT/'official_image.rs'
    source.write_text('fn main() {\n let arg = std::env::args().nth(1).expect("guest path");\n let bytes = std::fs::read(arg).expect("guest bytes");\n let id = risc0_zkvm::compute_image_id(&bytes).expect("official compute_image_id");\n println!("{}", id);\n println!("{:?}", id.as_words());\n}\n')
    binary=OUT/'official-image'
    command=['rustc','--edition=2021','-C','opt-level=2',str(source),'--extern','risc0_zkvm='+str(libraries[0]),'-L','dependency='+str(TARGET/'release/deps'),'-o',str(binary)]
    if observe('official-image-build',command,timeout=120):
        if observe('official-image', [str(binary),str(REPO/FIXTURE/'guest.bin')],timeout=120):
            lines=(OUT/'official-image.stdout.log').read_text().splitlines()
            words=json.loads(lines[1])
            expected=[1958252411,3287394615,1805488136,1516578702,78549041,790278610,301018785,4279049364]
            result={'official_words':words,'expected_fixed_words':expected,'matches':words==expected,
                    'guest_sha256':sha((REPO/FIXTURE/'guest.bin').read_bytes()),
                    'probe_source_sha256':sha(source.read_bytes()),'probe_binary_sha256':sha(binary.read_bytes()),
                    'upstream_rlib_sha256':sha(libraries[0].read_bytes()),'source_commit':HEAD,
                    'upstream_function':'risc0_zkvm::compute_image_id','whole_qrom_proof':False}
            write_json(OUT/'official-image-comparison.json',result)
            if not result['matches']: raise RuntimeError('official guest image mismatch')


def main():
    frozen()
    write_json(OUT/'runner-identity.json',{'script_sha256':sha(Path(__file__).read_bytes()),'head':HEAD,
        'target_dir':str(TARGET),'CARGO_BUILD_JOBS':'2','source_tree_mutation_authorized':False})
    source_args=['python3','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',HEAD]
    before=None
    try:
        if not observe('preflight-audit',['bash','scripts/project-preflight.sh','--audit']): return
        observe('full-source-before',source_args+['--output',str(OUT/'full-source-before-result.json')])
        entries=tree()
        includes=include_inventory(entries)
        before=selected_snapshot('selected-source-before',entries,includes)
        if not before['selected_bytes_match_head']:
            raise RuntimeError('selected compilation/fixture input identity mismatch; no build attempted')
        observe('cargo-fmt',['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'])
        chain=observe('cargo-metadata-chain',['cargo','metadata','--manifest-path','trillionnium/Cargo.toml','--locked','--format-version','1'],timeout=900)
        v2=observe('cargo-metadata-v2',['cargo','metadata','--manifest-path',V2,'--locked','--format-version','1'],timeout=900)
        if v2:
            v2_feature_check()
            observe('cargo-features-v2',['cargo','tree','--manifest-path',V2,'--locked','-e','features'])
            observe('v2-native-tests',['cargo','test','--manifest-path',V2,'--locked'],timeout=1800)
            built=observe('v2-release-build',['cargo','build','--release','--manifest-path',V2,'--locked'],timeout=1800)
            if built:
                binary=TARGET/'release/w1-verify-v2'
                receipt,header,artifacts=[str(REPO/FIXTURE/name) for name in ['succinct.bin','header.bin','expected-artifacts.bin']]
                observe('v2-fixed-receipt',[str(binary),receipt,header,artifacts])
                observe('v2-complete-native',[str(binary),'--native',str(REPO/FIXTURE/'input.bin'),artifacts],timeout=600)
                bad_receipt=OUT/'mutated-receipt.bin'
                data=bytearray(Path(receipt).read_bytes()); data[76]^=1; bad_receipt.write_bytes(data)
                observe('v2-mutated-receipt',[str(binary),str(bad_receipt),header,artifacts],expected='nonzero')
                bad_artifacts=OUT/'mutated-artifacts.bin'
                data=bytearray(Path(artifacts).read_bytes()); data[0]^=1; bad_artifacts.write_bytes(data)
                observe('v2-mutated-artifacts',[str(binary),receipt,header,str(bad_artifacts)],expected='nonzero')
                observe('v2-native-mutated-artifacts',[str(binary),'--native',str(REPO/FIXTURE/'input.bin'),str(bad_artifacts)],expected='nonzero')
                write_json(OUT/'v2-binary-identity.json',{'path':str(binary),'sha256':sha(binary.read_bytes()),'bytes':binary.stat().st_size,'source_commit':HEAD})
                official_image_probe()
        if chain:
            observe('chain-workspace-tests',['cargo','test','--manifest-path','trillionnium/Cargo.toml','--workspace','--locked','--','--test-threads=2'],timeout=2700)
            observe('chain-strict-clippy',['cargo','clippy','--manifest-path','trillionnium/Cargo.toml','--workspace','--all-targets','--locked','--','-D','warnings'],timeout=2700)
    except Exception as error:
        write_json(OUT/'runner-error.json',{'type':type(error).__name__,'error':str(error),'source_commit':HEAD})
        print(json.dumps({'runner_error':str(error)}),flush=True)
    finally:
        try:
            after=selected_snapshot('selected-source-after',tree(),include_inventory(tree()))
            if before is not None:
                write_json(OUT/'selected-source-comparison.json',{'before_sha256':sha((OUT/'selected-source-before.json').read_bytes()),
                  'after_sha256':sha((OUT/'selected-source-after.json').read_bytes()),
                  'same_selected_files_and_bytes':before['files']==after['files'],
                  'selected_bytes_match_head':after['selected_bytes_match_head'],'full_tracked_identity_claimed':False})
            observe('full-source-after',source_args+['--output',str(OUT/'full-source-after-result.json')])
        except Exception as error:
            write_json(OUT/'after-error.json',{'error':str(error)})
        write_json(OUT/'native-index.json',{'head':HEAD,'records':RECORDS,
          'all_recorded_expectations_met':all(r['expectation_met'] for r in RECORDS),
          'full_tracked_identity_claimed':False,'post_quantum_soundness_qualified':False,
          'consensus_admission':False,'release_authorized':False,
          'warning':'Full tracked identity failures are retained independently; selected source identity is a narrower observation.'})
        print(json.dumps({'runner_complete':True,'out':str(OUT)}),flush=True)


if __name__=='__main__':
    main()
    raise SystemExit(0 if RECORDS and all(row['expectation_met'] for row in RECORDS) else 2)
