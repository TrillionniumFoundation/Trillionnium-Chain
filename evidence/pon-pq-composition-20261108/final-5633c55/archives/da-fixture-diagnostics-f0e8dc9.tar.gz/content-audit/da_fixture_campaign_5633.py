#!/usr/bin/env python3
"""Prepare one isolated test-only child of 5633, then build/list once and run three tests once.

Preparation and execution are separate explicit modes so the new commit and exact
argv can be reviewed before any native build. No original repository, target,
failure evidence or branch is modified. Diagnostic outcomes never replace 412/3.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

BASE = Path("/home/qian-qi/work/chain-pq-composition-663507-20261108")
HELPER = BASE / "da_diagnostics_5633.py"
HELPER_SHA = "a2403eb189313b50f8292ccb97bd0fb9bfbfd3d518592be0c7702ed14d9c397e"
PATCH = BASE / "da_fixture_diagnostic_5633.patch"
PATCH_SHA = "fa029f0542db3024ee4cfdfc6bacbf554af5aa572e8b629c3567e8f316b2a647"
ROOT = BASE / "da-fixture-diagnostics-5633"
SOURCE, OUTPUT, TARGET = ROOT / "source", ROOT / "output", ROOT / "target"
ALLOWED = {
    "trillionnium/crates/trnm-data-availability/src/cell/network/serving/tests.rs",
    "trillionnium/crates/trnm-data-availability/src/cell/discovery/equivocation_history_tests.rs",
    "trillionnium/crates/trnm-data-availability/src/cell/release/transport_tests/rarest.rs",
}
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != HELPER_SHA:
    raise RuntimeError("reviewed helper bytes changed")
spec = importlib.util.spec_from_file_location("da_reviewed_helpers", HELPER)
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)
require, identity, save = h.require, h.identity, h.save


def capture_list(argv: list[str]) -> int:
    """Cargo supplies the true runtime environment; this mode may only list tests."""
    require(identity(Path(__file__).resolve())["sha256"] == os.environ["TRNM_DIAG_RUNNER_SHA"],
            "list wrapper differs from reviewed runner")
    require(len(argv) == 5 and argv[1:] ==
            ["--list", "--format=pretty", "--color=never", "--test-threads=1"], "unexpected listing argv")
    elf = Path(argv[0]).resolve(strict=True)
    require(elf.is_relative_to(TARGET), "listing ELF escaped fresh target")
    record = {"argv": argv, "cwd": str(Path.cwd()), "environment": dict(os.environ),
              "elf_before": identity(elf), "attempts": 1, "tests_executed": False}
    save(OUTPUT / "list-harness.started.json", record)
    with (OUTPUT / "list-harness.stdout.log").open("xb") as stdout, \
            (OUTPUT / "list-harness.stderr.log").open("xb") as stderr:
        process = subprocess.run(argv, stdout=stdout, stderr=stderr, check=False)
    record.update(exit_code=process.returncode, elf_after=identity(elf))
    record["logs"] = [identity(OUTPUT / ("list-harness." + stream + ".log"))
                      for stream in ("stdout", "stderr")]
    save(OUTPUT / "list-harness.receipt.json", record)
    require(record["elf_before"] == record["elf_after"], "ELF changed while listing")
    return process.returncode


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", required=True, choices=("prepare", "execute"))
    parser.add_argument("--expected-runner-sha256", required=True)
    parser.add_argument("--expected-head")
    args = parser.parse_args()
    runner = Path(__file__).resolve(strict=True)
    runner_before, helper_before, patch_before = identity(runner), identity(HELPER), identity(PATCH)
    require(runner_before["sha256"] == args.expected_runner_sha256, "runner pin differs")
    require(helper_before["sha256"] == HELPER_SHA and patch_before["sha256"] == PATCH_SHA,
            "reviewed helper or patch changed")
    require(not runner.is_relative_to(SOURCE), "runner must stay outside checked source")
    if args.mode == "prepare":
        require(not ROOT.exists() and args.expected_head is None, "preparation must be fresh")
        ROOT.mkdir(mode=0o700)
        OUTPUT.mkdir(mode=0o700)
    else:
        require(re.fullmatch(r"[0-9a-f]{40}", args.expected_head or "") is not None,
                "execution requires the reviewed new commit")
        require((OUTPUT / "prepared-source.json").is_file() and not TARGET.exists(),
                "execution requires prepared source and a fresh target")
        save(OUTPUT / "execution-intent.json", {"head": args.expected_head, "runner": runner_before,
                                               "patch": patch_before, "attempts": 1})
        TARGET.mkdir(mode=0o700)
    env = h.expected_base_environment()
    env.update(CARGO_TARGET_DIR=str(TARGET), RUST_BACKTRACE="full",
               TRNM_DIAG_RUNNER_SHA=args.expected_runner_sha256)
    records, results, errors = [], [], []
    source_before = source_after = None
    elf_before = elf_after = None
    tool_before = {}
    new_head = args.expected_head

    def command(label: str, argv: list, *, cwd: Path = SOURCE, timeout: int = 180,
                command_env: dict | None = None, expected_program: dict | None = None) -> dict:
        require(not any(row["label"] == label for row in records), "command retry forbidden")
        argv = list(map(str, argv))
        row = {"label": label, "argv": argv, "cwd": str(cwd), "attempts": 1,
               "started_unix_seconds": time.time(), "exit_code": None,
               "timed_out": False, "timeout_seconds": timeout}
        save(OUTPUT / (label + ".started.json"), row)
        process = None
        started = time.monotonic()
        try:
            program = Path(argv[0]).resolve(strict=True)
            row["program_before"] = identity(program)
            if expected_program is not None:
                require(row["program_before"] == expected_program, "emitted/pinned executable differs")
            with (OUTPUT / (label + ".stdout.log")).open("xb") as stdout, \
                    (OUTPUT / (label + ".stderr.log")).open("xb") as stderr:
                process = subprocess.Popen(argv, cwd=cwd, env=command_env or env,
                                           stdout=stdout, stderr=stderr, start_new_session=True)
                try:
                    row["exit_code"] = process.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    row["timed_out"] = True
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    row["exit_code"] = process.wait()
            row["program_after"] = identity(program)
            require(row["program_after"] == row["program_before"], "executable changed during command")
        except (Exception, KeyboardInterrupt) as error:
            row["error"] = type(error).__name__ + ": " + str(error)
        finally:
            if process is not None and process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                row["exit_code"] = process.wait()
            row["elapsed_seconds"] = time.monotonic() - started
            row["logs"] = [identity(path) for suffix in ("stdout", "stderr")
                           if (path := OUTPUT / (label + "." + suffix + ".log")).exists()]
            records.append(row)
            save(OUTPUT / (label + ".receipt.json"), row)
            print(json.dumps({"label": label, "exit_code": row["exit_code"],
                              "timed_out": row["timed_out"], "error": row.get("error")}), flush=True)
        return row

    def checked(label: str, argv: list, **kwargs) -> str:
        row = command(label, argv, **kwargs)
        require(not row.get("error") and not row["timed_out"] and row["exit_code"] == 0,
                label + " failed; retain original logs")
        return (OUTPUT / (label + ".stdout.log")).read_text().strip()

    def source(label: str, root: Path, head: str) -> dict:
        destination = OUTPUT / (label + ".source.json")
        checked(label, [h.PYTHON, "-B", root / "scripts/ci/verify_ci_source.py", "--kind", "head",
                        "--expected-head", head, "--output", destination], cwd=root)
        value = json.loads(destination.read_text())
        require(value["tested_commit"] == head and value["tracked_worktree_verified"] is True,
                "source identity not established")
        return value

    try:
        original_campaign = json.loads((h.ORIGINAL / "campaign-start.json").read_text())
        tool_before = {item["path"]: identity(Path(item["path"])) for item in original_campaign["tool_binaries"]}
        require(all(tool_before[item["path"]] == item for item in original_campaign["tool_binaries"]),
                "original toolchain identity drift")
        save(OUTPUT / (args.mode + "-inputs.json"), {
            "mode": args.mode, "parent": h.HEAD, "runner": runner_before, "helper": helper_before,
            "patch": patch_before, "environment": env, "tool_binaries": tool_before,
            "original_suite": {"passed": 412, "failed": 3, "ignored": 0},
            "original_result_replaced": False, "complete_suite_qualified": False,
        })
        if args.mode == "prepare":
            checked("parent-preflight", ["/bin/bash", "scripts/project-preflight.sh", "--audit"], cwd=h.REPO)
            source("parent-source-before", h.REPO, h.HEAD)
            origin = checked("parent-origin", ["/usr/bin/git", "remote", "get-url", "origin"], cwd=h.REPO)
            require(origin in {"https://github.com/TrillionniumFoundation/Trillionnium-Chain",
                               "https://github.com/TrillionniumFoundation/Trillionnium-Chain.git",
                               "git@github.com:TrillionniumFoundation/Trillionnium-Chain.git"}, "unexpected original origin")
            checked("clone-local-objects", ["/usr/bin/git", "clone", "--shared", "--no-checkout", "--",
                                            h.REPO, SOURCE], cwd=BASE, timeout=600)
            checked("set-isolated-origin", ["/usr/bin/git", "remote", "set-url", "origin", origin])
            checked("checkout-parent", ["/usr/bin/git", "checkout", "-b",
                                         "test/chain-da-fixture-diagnostics-5633", h.HEAD], timeout=600)
            checked("preflight-before-edit", ["/bin/bash", "scripts/project-preflight.sh"])
            source_before = source("isolated-parent-source", SOURCE, h.HEAD)
            checked("patch-check", ["/usr/bin/git", "apply", "--check", "--index", "--whitespace=error", PATCH])
            checked("apply-test-patch", ["/usr/bin/git", "apply", "--index", "--whitespace=error", PATCH])
            names = checked("staged-paths", ["/usr/bin/git", "diff", "--cached", "--name-only"]).splitlines()
            require(len(names) == 3 and set(names) == ALLOWED, "patch changed an unapproved source path")
            checked("preflight-before-commit", ["/bin/bash", "scripts/project-preflight.sh", "--staged"])
            checked("commit-isolated-diagnostic", ["/usr/bin/git", "-c", "user.name=DA fixture diagnostic",
                    "-c", "user.email=diagnostic@localhost", "commit", "-m",
                    "Diagnose DA fixture timing while retaining transport limits\n\nParent: " + h.HEAD + "\nPatch-SHA256: " + PATCH_SHA])
            new_head = checked("new-head", ["/usr/bin/git", "rev-parse", "HEAD"])
            require(checked("new-parent", ["/usr/bin/git", "rev-parse", "HEAD^"]) == h.HEAD,
                    "diagnostic commit has the wrong parent")
            require(set(checked("committed-paths", ["/usr/bin/git", "diff-tree", "--no-commit-id",
                                                    "--name-only", "-r", "HEAD"]).splitlines()) == ALLOWED,
                    "committed source scope changed")
            source_after = source("prepared-source-check", SOURCE, new_head)
            source("parent-source-after", h.REPO, h.HEAD)
            save(OUTPUT / "prepared-source.json", {"parent": h.HEAD, "head": new_head,
                 "tree": source_after["tested_tree"], "source": str(SOURCE), "output": str(OUTPUT),
                 "target": str(TARGET), "patch": patch_before, "runner": runner_before,
                 "changed_paths": sorted(ALLOWED), "production_source_bytes_changed": False,
                 "source_before": source_before, "source_after": source_after, "native_commands_executed": []})
        else:
            prepared = json.loads((OUTPUT / "prepared-source.json").read_text())
            require(prepared["head"] == new_head and prepared["parent"] == h.HEAD
                    and prepared["patch"] == patch_before and prepared["runner"] == runner_before,
                    "prepared source/patch/runner differs")
            checked("preflight-before-build", ["/bin/bash", "scripts/project-preflight.sh"])
            source_before = source("build-source-before", SOURCE, new_head)
            configuration = "target.x86_64-unknown-linux-gnu.runner=" + json.dumps(
                [str(h.PYTHON), "-B", str(runner), "__capture_list__"])
            checked("build-and-list-once", [h.TOOLCHAIN / "bin/cargo", "test", "--locked", "--offline",
                    "--manifest-path", "trillionnium/Cargo.toml", "--target", "x86_64-unknown-linux-gnu",
                    "--message-format=json", "--config", configuration, "-p", "trnm-data-availability",
                    "--lib", "--", "--list", "--format=pretty", "--color=never", "--test-threads=1"], timeout=1200)
            artifacts = []
            for line in (OUTPUT / "build-and-list-once.stdout.log").read_text().splitlines():
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if (item.get("reason") == "compiler-artifact" and item.get("executable")
                        and item.get("target", {}).get("name") == "trnm_data_availability"
                        and item.get("target", {}).get("kind") == ["lib"]
                        and item.get("profile", {}).get("test") is True):
                    artifacts.append(item)
            require(len(artifacts) == 1, "build did not emit exactly one DA lib test executable")
            listing = json.loads((OUTPUT / "list-harness.receipt.json").read_text())
            elf = Path(artifacts[0]["executable"]).resolve(strict=True)
            elf_before = identity(elf)
            require(elf.is_relative_to(TARGET) and listing["exit_code"] == 0
                    and listing["elf_before"] == listing["elf_after"] == elf_before,
                    "compiled/listed executable identity differs")
            names = re.findall(r"^([A-Za-z0-9_:]+): test$", (OUTPUT / "list-harness.stdout.log").read_text(), re.M)
            original_names = [line.removeprefix("test ") for line in
                (h.ORIGINAL / "data-availability-default-lib-discovery-harnesses" /
                 (h.HARNESS_STEM + ".libtest.log")).read_text().splitlines()]
            require(len(names) == len(set(names)) == len(original_names) == 415
                    and set(names) == set(original_names) and set(h.TESTS).issubset(names),
                    "the complete original 415-test roster changed")
            require(listing["cwd"] == str(SOURCE / "trillionnium/crates/trnm-data-availability"),
                    "Cargo selected an unexpected test cwd")
            runtime_env = listing["environment"]
            require(all(runtime_env.get(key) == value for key, value in env.items()),
                    "Cargo listing changed an explicitly fixed environment value")
            save(OUTPUT / "compiled-harness.json", {"artifact": artifacts[0], "elf": elf_before,
                 "listing": listing, "names": sorted(names), "parent": h.HEAD, "new_head": new_head})
            for index, name in enumerate(h.TESTS, 1):
                label = f"fixture-native-{index:02d}"
                logfile = OUTPUT / (label + ".libtest.log")
                row = command(label, [elf, name, "--exact", "--format=pretty", "--color=never",
                              "--test-threads=1", "--logfile", logfile], cwd=Path(listing["cwd"]),
                              timeout=120, command_env=runtime_env, expected_program=elf_before)
                outcome = "INCOMPLETE"
                if not row["timed_out"] and not row.get("error") and logfile.exists():
                    text = logfile.read_text()
                    if row["exit_code"] == 0 and text == "ok " + name + "\n":
                        outcome = "PASS_ON_TEST_ONLY_CHILD"
                    elif row["exit_code"] == 101 and text == "failed " + name + "\n":
                        outcome = "FAIL_ON_TEST_ONLY_CHILD"
                results.append({"name": name, "outcome": outcome, "attempts": 1,
                                "record": str(OUTPUT / (label + ".receipt.json"))})
                require(not row.get("error") and identity(elf) == elf_before, "native executable/launch changed")
            elf_after = identity(elf)
    except (Exception, KeyboardInterrupt) as error:
        errors.append(type(error).__name__ + ": " + str(error))
    finally:
        if args.mode == "execute":
            try:
                source_after = source("build-source-after", SOURCE, new_head)
                require(source_before is not None and source_after == source_before, "source pre/post mismatch")
            except (Exception, KeyboardInterrupt) as error:
                errors.append("source-after: " + str(error))
        try:
            require(identity(runner) == runner_before and identity(HELPER) == helper_before
                    and identity(PATCH) == patch_before, "runner/helper/patch changed")
            require(bool(tool_before) and {path: identity(Path(path)) for path in tool_before} == tool_before,
                    "toolchain identity changed or was never established")
        except (Exception, KeyboardInterrupt) as error:
            errors.append("identity-after: " + str(error))
        complete = not errors and (args.mode == "prepare" or
                   len(results) == 3 and all(row["outcome"] != "INCOMPLETE" for row in results))
        summary = {"mode": args.mode, "status": "COMPLETE" if complete else "INCOMPLETE_OR_BLOCKED",
                   "parent": h.HEAD, "new_head": new_head, "patch": patch_before,
                   "runner": runner_before, "helper": helper_before, "source_before": source_before,
                   "source_after": source_after, "elf_before": elf_before, "elf_after": elf_after,
                   "commands": records, "results": results, "errors": errors,
                   "original_suite": {"passed": 412, "failed": 3, "ignored": 0},
                   "original_result_replaced": False, "whole_chain_pq_qualified": False,
                   "complete_suite_qualified": False, "root_cause_resolved": False}
        save(OUTPUT / (args.mode + "-summary.json"), summary)
        print(json.dumps({"mode": args.mode, "status": summary["status"], "new_head": new_head,
                          "summary": str(OUTPUT / (args.mode + "-summary.json")), "errors": errors}), flush=True)
    return 0 if complete else 1


if __name__ == "__main__":
    if sys.argv[1:2] == ["__capture_list__"]:
        raise SystemExit(capture_list(sys.argv[2:]))
    raise SystemExit(main())
