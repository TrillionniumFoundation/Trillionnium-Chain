import pathlib,subprocess,json,os,hashlib,time,re,shlex
root=pathlib.Path("/home/qian-qi/chain-final-consolidation-20261114-root");src=root/"source"
ev=root/"native-final-rust-composition-dba-v1";ev.mkdir(exist_ok=False)
env=os.environ.copy();env["PATH"]="/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin";env["TMPDIR"]=str(root/"tmp");env["PYTHONDONTWRITEBYTECODE"]="1";env["CARGO_TARGET_DIR"]=str(root/"target");env["CARGO_BUILD_JOBS"]="4"
allowed={"OPENSSL_DIR","OPENSSL_STATIC","TRNM_PQ_OPENSSL","TRNM_PQ_OPENSSL_SHA256","TRNM_PQ_OPENSSL_VERSION","OPENSSL_CONF","OPENSSL_MODULES"}
for line in (root/"pq-provider.env").read_text().splitlines():
 line=line.strip()
 if not line or line.startswith("#"):continue
 if line.startswith("export "):line=line[7:]
 parts=shlex.split(line)
 assert len(parts)==1 and "=" in parts[0]
 k,v=parts[0].split("=",1);assert k in allowed,k;env[k]=v
assert "TRNM_PQ_OPENSSL" in env
provider=pathlib.Path(env["TRNM_PQ_OPENSSL"]);provider_sha="f956c01f912fc3211836ed5086d16755dc605a5458b29ee2ae8bf9c7a353142d"
assert hashlib.sha256(provider.read_bytes()).hexdigest()==provider_sha
steps=[]
def run(label,args,timeout=1800,wd=src):
 start=time.monotonic()
 try:q=subprocess.run(args,cwd=wd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
 except subprocess.TimeoutExpired as error:
  q=subprocess.CompletedProcess(args,124,(error.stdout or b"")+b"\nDRIVER_TIMEOUT_PRESERVED\n")
 path=ev/(label+".log");path.write_bytes(q.stdout)
 text=q.stdout.decode(errors="replace")
 row={"label":label,"argv":args,"exit":q.returncode,"seconds":round(time.monotonic()-start,3),"sha256":hashlib.sha256(q.stdout).hexdigest(),"log":str(path),"tests":[{"result":m[0],"passed":int(m[1]),"failed":int(m[2]),"ignored":int(m[3])} for m in re.findall(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;",text)]}
 steps.append(row);(ev/"steps.json").write_text(json.dumps(steps,indent=2)+"\n");print(json.dumps(row),flush=True);assert q.returncode==0,(label,text[-4000:]);return text
def git(*a):return subprocess.check_output(["git",*a],cwd=src,env=env)
base="e82419698aa3fd527c6f828da11cc8749dcb007b";head="dba81d56be6598cec9df2774446ca3ab7fccca98";tree="031d74a1060c0c0cb0f10a1651fab829784d0ca8"
assert git("rev-parse","HEAD").decode().strip()==base and git("status","--porcelain")==b""
run("pre-update-preflight",["bash","scripts/project-preflight.sh"])
bundle=root/"root-e824-to-dba.bundle"
raw=b"".join((root/("root-e824-to-dba.bundle.part"+str(i).zfill(3))).read_bytes() for i in range(2))
assert len(raw)==103646 and hashlib.sha256(raw).hexdigest()=="b0926c651836586ab69161c6319cd98fffc82f7af755dd0474056356cad2f022"
with bundle.open("xb") as f:f.write(raw)
run("bundle-verify",["git","bundle","verify",str(bundle)])
run("bundle-fetch",["git","fetch",str(bundle),"HEAD"])
assert git("rev-parse","FETCH_HEAD").decode().strip()==head
run("fast-forward",["git","merge","--ff-only","FETCH_HEAD"])
assert git("rev-parse","HEAD").decode().strip()==head and git("rev-parse","HEAD^{tree}").decode().strip()==tree and git("status","--porcelain")==b""
prior=json.loads((root/"native-statement-parallel-clippy-e824-v2/actual-source-manifest.json").read_text())
paths=set(prior["files_sha256"])
paths.update(git("diff","--name-only","--diff-filter=ACMR",base,head).decode().splitlines())
paths.update(p for p in git("ls-files").decode().splitlines() if p.startswith("trillionnium/crates/") and (p.endswith(".rs") or p.endswith("/Cargo.toml")))
entries={}
tracked={}
for item in git("ls-tree","-rz",head).split(b"\0"):
 if not item:continue
 m,path=item.split(b"\t",1);mode,typ,oid=m.decode().split();tracked[path.decode()]=(mode,typ,oid)
for path in sorted(paths):
 if path not in tracked:continue
 mode,typ,oid=tracked[path];assert typ=="blob" and mode in {"100644","100755"},(path,mode,typ)
 raw=(src/path).read_bytes();assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==oid,path
 entries[path]=hashlib.sha256(raw).hexdigest()
manifest={"identity":{"head":head,"tree":tree,"files":len(entries),"provider_sha256":provider_sha},"files_sha256":entries}
mraw=(json.dumps(manifest,indent=2,sort_keys=True)+"\n").encode();(ev/"actual-source-manifest.json").write_bytes(mraw)
print(json.dumps({"source_verified":len(entries),"manifest_sha256":hashlib.sha256(mraw).hexdigest()}),flush=True)
run("preflight",["bash","scripts/project-preflight.sh"])
ws=["--manifest-path","trillionnium/Cargo.toml"]
out=run("public-v3-complete",["cargo","+1.95.0","test","--locked",*ws,"-p","trnm-pon-node","--all-features","--lib","ingress::public_v3::","--","--nocapture","--test-threads=1"],timeout=3600)
assert "275 passed; 0 failed; 2 ignored" in out
for name in ["authenticated_caller_requires_explicit_v4_and_single_binding","authenticated_caller_observation_requires_real_signature_on_tcp","default_observer_preserves_complete_v4_serialization"]:
 assert name+" ... ok" in out,name
for label,selector,count in [("cell-release","cell::release_tests::",19),("cell-availability","cell::network::availability::tests::",13),("cell-budget","cell::network::budget_tests::",8),("cell-cancellation","cell::network::cancellation_tests::",4)]:
 out=run(label,["cargo","+1.95.0","test","--locked",*ws,"-p","trnm-data-availability","--all-features","--lib",selector,"--","--nocapture","--test-threads=1"],timeout=1800)
 assert str(count)+" passed; 0 failed; 0 ignored" in out,(label,count)
out=run("mining-timestamp-liveness",["cargo","+1.95.0","test","--locked",*ws,"-p","trnm-pon-node","--all-features","--test","mining_timestamp_liveness","--","--nocapture","--test-threads=1"],timeout=1800)
assert "2 passed; 0 failed; 0 ignored" in out
run("strict-clippy",["cargo","+1.95.0","clippy","--locked",*ws,"-p","trnm-data-availability","-p","trnm-pon-node","--all-targets","--all-features","--","-D","warnings"],timeout=3600)
run("fmt",["cargo","+1.95.0","fmt",*ws,"--all","--","--check"],timeout=120)
for path,sha in entries.items():assert hashlib.sha256((src/path).read_bytes()).hexdigest()==sha,path
assert hashlib.sha256(provider.read_bytes()).hexdigest()==provider_sha and git("status","--porcelain")==b"" and git("rev-parse","HEAD").decode().strip()==head
summary={"head":head,"tree":tree,"steps":steps,"source_manifest_sha256":hashlib.sha256(mraw).hexdigest(),"sources_unchanged_before_and_after":True,"provider_sha256":provider_sha,"public_v3_tests_passed":275,"public_v3_preexisting_ignored":2,"cell_tests_passed":44,"original_mining_time_tests_passed":2,"strict_all_target_all_feature_clippy":True,"four_second_hosted_campaign_started":False,"host_provisioning_started":False,"qualification_granted":False}
(ev/"summary.json").write_text(json.dumps(summary,indent=2)+"\n");print(json.dumps({"completed":True,"summary":str(ev/"summary.json")}),flush=True)
