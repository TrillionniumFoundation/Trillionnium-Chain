# Cost and composition claim-boundary review

Review status: **data/identity boundaries verified; final MVCC and strict-Clippy recovery outcomes pending**.

This is a local read-only review of fixed Git objects, original cost records and command receipts. It adds no native execution, benchmark sample or hosted-CI observation. The review file is outside the source repository.

Review recorded UTC: 2026-11-10T10:51:20.583239+00:00

## Execution identities that must remain distinct

| Evidence | Exact attribution |
| --- | --- |
| Original cost generation and native verification, 96 constructions / 576 stages | `39336622c63df1ae746d83a76bb53202cd01ba17`, tree `42fbd7d5a7f00b75000cb4aa242e578a8f941d59` |
| Original 20 actual-stream controls | The same `39336622` source |
| Earlier binding-only checks | `be24e0be2ddf7dfef7e902f6b879cad1f2005ebc`, tree `23dadad580311dba14c6407123d998876a9d5acb` |
| Incoming candidate work | `df927b6ffaecff293b9e9428e3ba516f47cd101a` |
| Actual combined-source checks | `f5e836c2b88f7fe0f7cb3f1992601c6943df733e`, tree `6866639dce1132a1e716505ab4156c43b3ca01b3` |
| Combined-source 20 reader controls | Reader source `f5e836c2`, replaying the retained native stream measured at `39336622` |
| Subsequent evidence-only delivery / PR | Delivery identity only; execution identities above remain attached to their own observations |

The retained cost stream SHA-256 is `953ef816f391839d1bae8b7c3cb2c6653b2bfad2eb611968288167afcf2d3f7d`. It matches the original execution receipt and the before/after hashes in `validation-f5e836c2/from-zero-retained-log-input-binding.json`. That receipt explicitly retains `native_execution_repeated=false` and `native_execution_identity_transferred=false` for this cost replay. This does not deny the separate, actually rerun journal and PublicV3 tests below.

## Six cost cells, independently recomputed from original raw rows

Each cell has eight from-zero samples. CPU values are microseconds per submitted candidate. Construction includes per-sample setup and every losing/winning search attempt. The ratio is `(sum precheck CPU + sum raw-first CPU) / sum construction CPU`, not an average of per-trial ratios.

| Material | Conditional uniform-ticket p | Fake trials | Construction CPU (us) | Precheck CPU (us) | Raw-first CPU (us) | Ratio |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| zero | 1/2 | 19 | 50.429 | 29.984 | 698.485 | 14.445546x |
| zero | 1/16 | 163 | 71.454 | 31.446 | 708.120 | 10.350190x |
| zero | 1/256 | 1882 | 151.091 | 31.734 | 723.023 | 4.995391x |
| full-rank-field | 1/2 | 10 | 78.425 | 47.951 | 820.208 | 11.069866x |
| full-rank-field | 1/16 | 132 | 50.373 | 42.794 | 749.588 | 15.730326x |
| full-rank-field | 1/256 | 1608 | 136.004 | 44.364 | 760.756 | 5.919810x |

The six values and their range, 4.995391x to 15.730326x, match the original report. The false arm retains 3,814 trials / 3,766 misses / 48 hits. All 48 pass the preliminary statement filter and then receive native full-verifier `Transcript` rejection. No false `VerifiedWork` is accepted. The independent legal comparator retains 7,528 trials / 7,480 misses / 48 hits.

These are finite component CPU observations on the recorded machine and fixed samples. Public fixture/task setup is separate from the per-sample ratio. Precheck and raw verification are separate calls, verification progress callbacks are timed, and path order is fixed. The arithmetic cache is an opt-in component. Neither the ratio nor a hot-cache result measures admitted public service, proves a worst-case bound, establishes independent lotteries, or proves minimum legal work cost. All targets, sample counts, hardware and timing limitations from the original report still apply.

## Incoming work and combined-source observations

The fixed incoming delta tightens lifecycle material recipes, the full producer-support matrix and every completed trial's proof digest. The lifecycle reader still does not replay W1's challenge-dependent relation. Its 1,888-search complete-roster obligation is distinct from the new 96-construction diagnostic. The work-security workflow keeps exact legal/factorial method identities and the updated counts; the nine Python gate controls check those parsers and are not themselves execution of all listed native shards.

Incoming evaluation changes validate retained quorum closures during hydration/adoption, including retained historical exclusions. Existing missing conflict-insertion heights still limit reconstruction of an older nonempty subset after additional conflicts. Incoming PublicV3 changes order cancellation observations in a test; they do not relax service budgets. Neither change supplies independent evaluator governance or full public-service qualification.

The combined source preserves all 138 QROM local inputs, all 16 selected project inputs and the 1,573-path native inventory. The contract SHA remains `272275f202b896b74b7f7499695fa3f50b28a36465806c60b8c369e2e76db5b9`; the profile descriptor remains `b86f7f122f8295418abb20ebd71132d1719a37770499b01293fa1d018f47a06e`. The declared crate-root/literal-data inventory still does not recursively follow cross-root Rust `#[path]` imports.

Seventeen static/cost command receipts were individually checked against their original log sizes/hashes. They all exit zero, and each before/after observation verifies `f5e836c2` / tree `6866639d`, 27,867 tracked entries and 2,552,906,464 bytes. Their control denominators remain QROM 14, profile 26, lifecycle 15, factorial gate 9, material reader 32, retained-cost-log reader 20, corpus 59, source integrity 43 and CI contract 177; no skipped cohort was promoted.

| Additional combined-source native observation | Status at this review |
| --- | --- |
| Owner-journal / risk-ledger integration suites | 11 + 12 = 23 passed; four ignored owned helper entrypoints invoked by parent tests, not double counted |
| Targeted PublicV3 unit cohort | 59 passed, zero ignored; **1,263 filtered out**. This is a targeted cohort, not all node tests |
| Initial MVCC test command | Failed, exit 101: linker `ld` signal 7 / Bus error; no completed full-suite pass |
| Initial strict workspace Clippy | Failed, exit 101: `No space left on device` / os error 28 |
| Same-source recovery reruns | **PENDING at review**; replace this field only with separately retained terminal receipts |

The original failed logs are valid retained observations. A linker failure is not by itself proof of a source defect or of a particular physical cause; the following ENOSPC is an explicit storage failure. Cache recovery is preparation, not a pass. Earlier Clippy success at `39336622` cannot fill the combined-source Clippy gate.

## Final PR/report corrections and remaining scope

The inspected `publication/pr-body.md` is still the pre-composition draft. Before submission:

- Replace the active base `da1374a2` with the fresh candidate base `df927b6f`, while retaining `da1374a2` only as the common historical base.
- Add exact combined source `f5e836c2` / tree `6866639d` and the actual subsequent evidence delivery identity. `bf010229` is the earlier evidence delivery / first parent, not the final composed-source identity.
- Restrict the statement that no `trillionnium` file changed after `39336622` to the earlier binding follow-up `be24e0be`; it is false as a blanket description of the combined source.
- Keep cost measurement at `39336622`, reader replay at `f5e836c2`, and fresh `f5e836c2` native cohorts separate. Do not present 17 successful static/cost commands as a complete workspace/native pass.
- Insert terminal MVCC/Clippy recovery results only after their actual completion, retaining initial failures. Publication/readback is separate from hosted CI; do not infer a hosted pass from local results.

**HOLD / NO-GO remains.** Authorized funded demand, independently verified delivery, model net benefit and minimum consensus work cost are separate open propositions. Public-service liveness, cross-receiver/restart resource responsibility, all legal optimizations and amortization, joint DAA/timestamp/chainwork/confirmation bounds, evaluator independence, external-effect recovery and whole-chain classical/quantum qualification remain open. All production/qualification refusals remain in force.
