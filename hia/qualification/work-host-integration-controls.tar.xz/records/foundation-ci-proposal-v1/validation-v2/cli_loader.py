from pathlib import Path
import sys,importlib.util
root=Path('/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo')
candidate=Path('/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/foundation-ci-proposal-v1/candidate')
sys.path.insert(0,str(root))
import hia.tools
spec=importlib.util.spec_from_file_location('hia.tools.qualify_foundation_ci',candidate/'hia/tools/qualify_foundation_ci.py')
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);setattr(hia.tools,'qualify_foundation_ci',m);m.ROOT=root
raise SystemExit(m.main())
