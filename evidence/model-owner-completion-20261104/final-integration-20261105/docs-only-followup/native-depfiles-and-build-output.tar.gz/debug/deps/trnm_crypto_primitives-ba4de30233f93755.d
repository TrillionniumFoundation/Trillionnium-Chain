/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/trnm_crypto_primitives-ba4de30233f93755.d: crates/trnm-crypto-primitives/src/lib.rs crates/trnm-crypto-primitives/src/owned_ed25519.rs crates/trnm-crypto-primitives/src/pon_work.rs crates/trnm-crypto-primitives/src/pon_work/arithmetic_facts.rs crates/trnm-crypto-primitives/src/pon_work/artifacts.rs crates/trnm-crypto-primitives/src/pon_work/blocked_one_zero.rs crates/trnm-crypto-primitives/src/pon_work/blocked_zero.rs crates/trnm-crypto-primitives/src/pon_work/blocked_zero_paired.rs crates/trnm-crypto-primitives/src/pon_work/facts.rs crates/trnm-crypto-primitives/src/pon_work/integer_paired.rs crates/trnm-crypto-primitives/src/pon_work/legal_attempt.rs crates/trnm-crypto-primitives/src/pon_work/maintenance_limb.rs crates/trnm-crypto-primitives/src/pon_work/maintenance_periodic.rs crates/trnm-crypto-primitives/src/pon_work/maintenance_prefix.rs crates/trnm-crypto-primitives/src/pon_work/paired_product.rs crates/trnm-crypto-primitives/src/pon_work/rejection_cache.rs crates/trnm-crypto-primitives/src/pon_work/structured.rs crates/trnm-crypto-primitives/src/qualified_work_task.rs crates/trnm-crypto-primitives/src/qualified_work_task/lifecycle_v2.rs crates/trnm-crypto-primitives/src/qualified_work_task/pq_lifecycle_v4.rs crates/trnm-crypto-primitives/src/qualified_work_task/pq_lifecycle_v5.rs crates/trnm-crypto-primitives/src/pq_auth.rs Cargo.toml

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libtrnm_crypto_primitives-ba4de30233f93755.rmeta: crates/trnm-crypto-primitives/src/lib.rs crates/trnm-crypto-primitives/src/owned_ed25519.rs crates/trnm-crypto-primitives/src/pon_work.rs crates/trnm-crypto-primitives/src/pon_work/arithmetic_facts.rs crates/trnm-crypto-primitives/src/pon_work/artifacts.rs crates/trnm-crypto-primitives/src/pon_work/blocked_one_zero.rs crates/trnm-crypto-primitives/src/pon_work/blocked_zero.rs crates/trnm-crypto-primitives/src/pon_work/blocked_zero_paired.rs crates/trnm-crypto-primitives/src/pon_work/facts.rs crates/trnm-crypto-primitives/src/pon_work/integer_paired.rs crates/trnm-crypto-primitives/src/pon_work/legal_attempt.rs crates/trnm-crypto-primitives/src/pon_work/maintenance_limb.rs crates/trnm-crypto-primitives/src/pon_work/maintenance_periodic.rs crates/trnm-crypto-primitives/src/pon_work/maintenance_prefix.rs crates/trnm-crypto-primitives/src/pon_work/paired_product.rs crates/trnm-crypto-primitives/src/pon_work/rejection_cache.rs crates/trnm-crypto-primitives/src/pon_work/structured.rs crates/trnm-crypto-primitives/src/qualified_work_task.rs crates/trnm-crypto-primitives/src/qualified_work_task/lifecycle_v2.rs crates/trnm-crypto-primitives/src/qualified_work_task/pq_lifecycle_v4.rs crates/trnm-crypto-primitives/src/qualified_work_task/pq_lifecycle_v5.rs crates/trnm-crypto-primitives/src/pq_auth.rs Cargo.toml

crates/trnm-crypto-primitives/src/lib.rs:
crates/trnm-crypto-primitives/src/owned_ed25519.rs:
crates/trnm-crypto-primitives/src/pon_work.rs:
crates/trnm-crypto-primitives/src/pon_work/arithmetic_facts.rs:
crates/trnm-crypto-primitives/src/pon_work/artifacts.rs:
crates/trnm-crypto-primitives/src/pon_work/blocked_one_zero.rs:
crates/trnm-crypto-primitives/src/pon_work/blocked_zero.rs:
crates/trnm-crypto-primitives/src/pon_work/blocked_zero_paired.rs:
crates/trnm-crypto-primitives/src/pon_work/facts.rs:
crates/trnm-crypto-primitives/src/pon_work/integer_paired.rs:
crates/trnm-crypto-primitives/src/pon_work/legal_attempt.rs:
crates/trnm-crypto-primitives/src/pon_work/maintenance_limb.rs:
crates/trnm-crypto-primitives/src/pon_work/maintenance_periodic.rs:
crates/trnm-crypto-primitives/src/pon_work/maintenance_prefix.rs:
crates/trnm-crypto-primitives/src/pon_work/paired_product.rs:
crates/trnm-crypto-primitives/src/pon_work/rejection_cache.rs:
crates/trnm-crypto-primitives/src/pon_work/structured.rs:
crates/trnm-crypto-primitives/src/qualified_work_task.rs:
crates/trnm-crypto-primitives/src/qualified_work_task/lifecycle_v2.rs:
crates/trnm-crypto-primitives/src/qualified_work_task/pq_lifecycle_v4.rs:
crates/trnm-crypto-primitives/src/qualified_work_task/pq_lifecycle_v5.rs:
crates/trnm-crypto-primitives/src/pq_auth.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
