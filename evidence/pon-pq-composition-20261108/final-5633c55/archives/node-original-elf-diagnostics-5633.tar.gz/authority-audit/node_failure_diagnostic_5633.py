#!/usr/bin/env python3
"""One additional diagnostic per original Node failure, on the retained original ELF.
This does not retry/replace the broad campaign, rebuild, or perform a full source scan.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time
import traceback

HEAD = "5633c55219c01c689f670c2ca35d122e39f3f791"
TREE = "3baafa8923d1a1e7bfb6f24cff9965a4e82fba4c"
ROOT = Path("/home/qian-qi/work/chain-pq-composition-663507-20261108")
REPO = ROOT / "repo"
ORIGINAL = ROOT / "final-native-5633c55"
OUT = ROOT / "node-failure-diagnostic-5633c55-once"
STEM = "trnm_pon_node-cf56cc7c22eb0fc0-28961ac7046b22c0bcd0"
ELF = ORIGINAL / "native-target-default/x86_64-unknown-linux-gnu/debug/deps/trnm_pon_node-cf56cc7c22eb0fc0"
ELF_PIN = {"bytes": 506457320, "sha256": "b8beb2cddc818af3ddc59ce44b7d184ad21c27d5170318fdf6be7b388797b466"}
CWD = REPO / "trillionnium/crates/trnm-pon-node"
CASES = (
    ("m15-clock", "release_owner::service_tests::clock_reply_then_real_elapsed_expiry_refuses_without_cas"),
    ("m12-transaction-head", "store::async_w1_generation_v2::tests::recovery_v3::transaction_head_change_after_witness_read_is_not_promoted_to_a_signed_successor"),
)
BINDING_PINS = {
    "campaign-start.json": {
        "bytes": 4389,
        "sha256": "37aabdb0de18b67c24b434a5f52af06123a668b11a81357825c24500093dba55"
    },
    "node-default-lib-list.receipt.json": {
        "bytes": 2098,
        "sha256": "10e2392e321bfddd5f2b8b929d0b4b41ef8c71f3b8f85d213640ff6840e130c8"
    },
    "node-default-lib-run.started.json": {
        "bytes": 1310,
        "sha256": "3171533c04675299c6dbfa13ab16e199606729413d6f5a5d3df0b7eb74d0d1c1"
    },
    "node-default-lib-discovery-harnesses/trnm_pon_node-cf56cc7c22eb0fc0-28961ac7046b22c0bcd0.finish.json": {
        "bytes": 2686,
        "sha256": "50bff97caad5ae337f6b6a2061853e65dfd6dd00a5ef680788efee33bf2ebc70"
    },
    "node-default-lib-execution-harnesses/trnm_pon_node-cf56cc7c22eb0fc0-28961ac7046b22c0bcd0.start.json": {
        "bytes": 1998,
        "sha256": "60328a4b14c868f7b9a97a89b21d15b4d82db5abf54b192c16f12b716e6659a5"
    },
    "source-before.source.json": {
        "bytes": 423,
        "sha256": "0c0c76846a4cace0b3a378b631f16fb23a88841d22a5edcce4ce1ddf7cb8d1b1"
    },
    "node-default-lib.roster.json": {
        "bytes": 152059,
        "sha256": "d2ae981e86abfa1b03e51cc5140c6f571af2ab2e4912d3d368c1269f506bbe71"
    },
    "node-default-lib-list.stdout.log": {
        "bytes": 270020,
        "sha256": "93a48a1133ce97f4b5992c05cc2247bf3d89c6bfe4140b6d16cdc116ab9c2f62"
    },
    "node-default-lib-list.stderr.log": {
        "bytes": 3087,
        "sha256": "d3650568927e281a48ae4119192317bf7edc85cdc51adf7591a4aa8d51cfc2b0"
    },
    "node-default-lib-discovery-harnesses/trnm_pon_node-cf56cc7c22eb0fc0-28961ac7046b22c0bcd0.libtest.log": {
        "bytes": 145250,
        "sha256": "5713fe071264781ae1db527cc0e7fd653e1c7a6ad0943a92c156b55f80936dcb"
    }
}
SOURCE_PINS = {
    "trillionnium/crates/trnm-pon-node/src/pq_rollback_witness.rs": {
        "bytes": 38146,
        "sha256": "090c13700baf9ed945a4aa86519f1d4df85105ef1064addd73de2acb025d9a45"
    },
    "trillionnium/crates/trnm-pon-node/src/release_owner/frontier_service.rs": {
        "bytes": 5931,
        "sha256": "ebce1d727a1e8c89327b53b345d7e4da9b3329dbeb955b1a7356214b541c3273"
    },
    "trillionnium/crates/trnm-pon-node/src/release_owner/service_clock.rs": {
        "bytes": 3396,
        "sha256": "702f582374706400530529bce619acd86228222152eb1e5d34bb453b1e169e60"
    },
    "trillionnium/crates/trnm-pon-node/src/release_owner/service_configuration.rs": {
        "bytes": 5896,
        "sha256": "ce08c9a464ccc27bcb52838bfb73416e4b0e5ed5df29622f3f7439c7e5787a90"
    },
    "trillionnium/crates/trnm-pon-node/src/release_owner/service_faults.rs": {
        "bytes": 1900,
        "sha256": "670031a3618c69a54d9be080ce6f0eb9510763c94dd9696a59b72176fb8df294"
    },
    "trillionnium/crates/trnm-pon-node/src/release_owner/service_store.rs": {
        "bytes": 8222,
        "sha256": "b4a3a5c375db867241d3df56a78f0347af4853d785be285c77f92d0adfde89d8"
    },
    "trillionnium/crates/trnm-pon-node/src/release_owner/service_test_fixture.rs": {
        "bytes": 12410,
        "sha256": "9d11574e909c3c8fc6dc74e8ed580d64a81ed4f83f16cc26284b04f3562284c4"
    },
    "trillionnium/crates/trnm-pon-node/src/release_owner/service_tests.rs": {
        "bytes": 13717,
        "sha256": "4a830b1945af7455103f523d33f9fbfb41b3a262ce21ff36bc8311d6d685f513"
    },
    "trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2/recovery_v3.rs": {
        "bytes": 9882,
        "sha256": "ef3b54afdc5ff3b3c3c52939eed897674fac8c930299bdea2fda0ad08cfc630a"
    },
    "trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2/tests/recovery_v3.rs": {
        "bytes": 21783,
        "sha256": "4a291e66bff207306897a07691f26bbade865a259aeba229359debab1154bbda"
    },
    "trillionnium/crates/trnm-service-settlement/src/native_generation_budget_v2.rs": {
        "bytes": 43345,
        "sha256": "a8d026bf5f31fbf692b69a888d9251545143657a28278c90c4104970ea562d34"
    },
    "trillionnium/crates/trnm-service-settlement/src/native_generation_budget_v2/recovery_checkpoint_v3.rs": {
        "bytes": 3651,
        "sha256": "af4d32879a2509f2cd9877b19b69b233ca3fe609949eed04dba7942a00340618"
    }
}

def require(ok, message):
    if not ok:
        raise ValueError(message)

def save(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")

def identity(path):
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode), "not a regular file: " + str(path))
    require(path.resolve(strict=True) == path, "path alias: " + str(path))
    return dict(device=info.st_dev, inode=info.st_ino, size=info.st_size,
                mtime_ns=info.st_mtime_ns, ctime_ns=info.st_ctime_ns, mode=info.st_mode)

def record(path):
    before = identity(path)
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    require(before == identity(path), "file changed while hashing: " + str(path))
    return {"path": str(path), "bytes": before["size"], "sha256": digest.hexdigest()}

def pinned(path, expected):
    result = record(path)
    require(all(result[key] == value for key, value in expected.items()),
            "pin mismatch: " + str(path))
    return result

def git_read(label, args, env):
    argv = ["/usr/bin/git", "-c", "core.fsmonitor=false", "-c", "core.untrackedCache=false",
            "-c", "core.ignoreStat=false", "-C", str(REPO), *args]
    receipt = {"argv": argv, "cwd": str(REPO), "attempts": 1, "timeout_seconds": 30,
               "started_unix_seconds": time.time(), "timed_out": False}
    stdout = OUT / (label + ".stdout.log")
    stderr = OUT / (label + ".stderr.log")
    started = time.monotonic()
    child = None
    try:
        with stdout.open("xb") as out, stderr.open("xb") as err:
            child = subprocess.Popen(argv, cwd=REPO, env=env, stdin=subprocess.DEVNULL,
                                     stdout=out, stderr=err, start_new_session=True)
            try:
                receipt["exit_code"] = child.wait(timeout=30)
            except subprocess.TimeoutExpired:
                receipt["timed_out"] = True
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                receipt["exit_code"] = child.wait()
    finally:
        receipt["elapsed_seconds"] = time.monotonic() - started
        receipt["logs"] = [record(p) for p in (stdout, stderr) if p.exists()]
        save(OUT / (label + ".receipt.json"), receipt)
    require(not receipt["timed_out"] and receipt.get("exit_code") == 0,
            "read-only Git check failed: " + label)
    return stdout.read_bytes()

def source_check(phase, env):
    result = {"full_tracked_raw_scan_performed_here": False,
              "scope": "HEAD/tree, Git clean status, and twelve explicit raw source pins"}
    result["head"] = git_read(phase + "-head", ["rev-parse", "--verify", "HEAD"], env).decode().strip()
    result["tree"] = git_read(phase + "-tree", ["rev-parse", "--verify", "HEAD^{tree}"], env).decode().strip()
    status_bytes = git_read(phase + "-clean", ["status", "--porcelain=v1", "--untracked-files=all"], env)
    result["git_status_bytes"] = len(status_bytes)
    require(result["head"] == HEAD and result["tree"] == TREE and not status_bytes,
            "source HEAD/tree or clean status differs")
    result["critical_sources"] = {name: pinned(REPO / name, pin) for name, pin in SOURCE_PINS.items()}
    save(OUT / (phase + ".json"), result)
    return result

def original_live_snapshot():
    path = ORIGINAL / "node-default-lib-execution-harnesses" / (STEM + ".libtest.log")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and 0 < before.st_size <= 2 * 1024 * 1024,
                "unexpected original live logfile size/type")
        data = b""
        while len(data) < before.st_size:
            part = os.read(fd, before.st_size - len(data))
            require(part, "short live logfile read")
            data += part
        after = os.fstat(fd)
        require((before.st_dev, before.st_ino) == (after.st_dev, after.st_ino)
                and after.st_size >= before.st_size, "live logfile replaced or truncated")
        os.lseek(fd, 0, os.SEEK_SET)
        verify = b""
        while len(verify) < len(data):
            part = os.read(fd, len(data) - len(verify))
            require(part, "short live prefix verification")
            verify += part
        require(verify == data, "original live prefix changed")
    finally:
        os.close(fd)
    lines = data.decode("utf-8").splitlines()
    matches = {name: [line for line in lines if line == "failed " + name] for _, name in CASES}
    require(all(len(rows) == 1 for rows in matches.values()), "both original failures are not present once")
    path_out = OUT / "original-live-libtest-prefix.log"
    with path_out.open("xb") as stream:
        stream.write(data)
    result = {"source_path": str(path), "copied_prefix_bytes": len(data),
              "observed_source_size_after_first_read": after.st_size,
              "snapshot": record(path_out), "failed_lines": matches,
              "full_suite_completion_receipt_present": (ORIGINAL / "node-default-lib-run.receipt.json").exists(),
              "full_harness_finish_present": (ORIGINAL / "node-default-lib-execution-harnesses" / (STEM + ".finish.json")).exists(),
              "interpretation": "A bounded live prefix, not the original full-suite final result."}
    save(OUT / "original-live-failures.json", result)
    return result

def bind_original():
    binding_dir = OUT / "original-bindings"
    binding_dir.mkdir()
    records = {}
    data = {}
    for name, pin in BINDING_PINS.items():
        records[name] = pinned(ORIGINAL / name, pin)
        raw = (ORIGINAL / name).read_bytes()
        require(len(raw) == pin["bytes"] and hashlib.sha256(raw).hexdigest() == pin["sha256"],
                "binding changed before retained copy: " + name)
        destination = binding_dir / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as stream:
            stream.write(raw)
        if name.endswith(".json"):
            data[name] = json.loads(raw)
    campaign = data["campaign-start.json"]
    source = data["source-before.source.json"]
    listing = data["node-default-lib-list.receipt.json"]
    discovery = data["node-default-lib-discovery-harnesses/" + STEM + ".finish.json"]
    execution = data["node-default-lib-execution-harnesses/" + STEM + ".start.json"]
    roster = data["node-default-lib.roster.json"]
    require(campaign["expected_head"] == HEAD and source["tested_commit"] == HEAD
            and source["tested_tree"] == TREE and source["tracked_worktree_verified"] is True,
            "original source binding differs")
    require(listing["passed"] is True and listing["exit_code"] == 0
            and listing["attempts"] == 1 and not listing["timed_out"], "discovery did not pass once")
    require(list(roster) == [str(ELF)], "original default roster is not one exact ELF")
    item = roster[str(ELF)]
    expected_binary = dict(path=str(ELF), **ELF_PIN)
    require(discovery["executable_before"] == expected_binary == discovery["executable_after"]
            == execution["executable_before"] == item["binary"], "ELF provenance mismatch")
    require(discovery["exit_code"] == 0 and discovery["mode"] == "list"
            and execution["mode"] == "run" and execution["attempts"] == 1,
            "wrong original phases")
    require(discovery["cwd"] == execution["cwd"] == str(CWD), "original test cwd differs")
    require(discovery["runtime_environment"] == execution["runtime_environment"],
            "recorded original runtime environments differ")
    require(item["artifact"]["manifest_path"] == str(CWD / "Cargo.toml")
            and item["artifact"]["target"]["kind"] == ["lib"]
            and "pq-native-openssl" not in item["artifact"]["features"], "wrong Node artifact")
    names = item["names"]
    log_lines = (binding_dir / "node-default-lib-discovery-harnesses" / (STEM + ".libtest.log")).read_text().splitlines()
    require(all(re.fullmatch(r"test \S+", line) for line in log_lines), "invalid discovery logfile")
    require(len(names) == len(set(names)) == 1298
            and sorted(line[5:] for line in log_lines) == names, "actual discovered roster differs")
    require(all(names.count(name) == 1 for _, name in CASES), "diagnostic test missing or ambiguous")
    environment = dict(campaign["environment"])
    environment.update(execution["runtime_environment"])
    environment["RUST_BACKTRACE"] = "full"
    require(environment["RUST_TEST_THREADS"] == "1", "original recorded test-thread count differs")
    note = {"source": "retained campaign environment overlaid with retained harness runtime_environment",
            "explicit_changes": {"RUST_BACKTRACE": {"recorded": campaign["environment"].get("RUST_BACKTRACE"),
                                                   "diagnostic": "full"}},
            "environment": environment,
            "unrecorded_original_cargo_injected_environment": "UNKNOWN; not reconstructed or claimed equal",
            "ambient_environment_inherited": False,
            "wrapper_only_TRNM_NATIVE_variables": "not set for direct ELF execution",
            "complete_environment_reproduction_claimed": False,
            "same_recorded_cwd": str(CWD),
            "distinct_process_cgroup_and_concurrent_workload": True}
    save(OUT / "environment.json", note)
    return records, environment

def run_case(label, name, env, elf_identity):
    require(identity(ELF) == elf_identity, "ELF identity changed before diagnostic")
    logfile = OUT / (label + ".libtest.log")
    argv = [str(ELF), name, "--exact", "--format=pretty", "--color=never",
            "--test-threads=1", "--nocapture", "--logfile", str(logfile)]
    row = {"label": label, "test_name": name, "argv": argv, "cwd": str(CWD),
           "attempts": 1, "retry": False, "timeout_seconds": 120, "timed_out": False,
           "started_unix_seconds": time.time(), "exit_code": None, "elf_identity_before": elf_identity}
    save(OUT / (label + ".started.json"), row)
    stdout = OUT / (label + ".stdout.log")
    stderr = OUT / (label + ".stderr.log")
    started = time.monotonic()
    try:
        with stdout.open("xb") as out, stderr.open("xb") as err:
            process = subprocess.Popen(argv, cwd=CWD, env=env, stdin=subprocess.DEVNULL,
                                       stdout=out, stderr=err, start_new_session=True)
            row["pid"] = process.pid
            try:
                row["exit_code"] = process.wait(timeout=120)
            except subprocess.TimeoutExpired:
                row["timed_out"] = True
                # Only this new diagnostic process group; never the original campaign.
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                row["exit_code"] = process.wait()
        row["elf_identity_after"] = identity(ELF)
        require(row["elf_identity_after"] == elf_identity, "ELF identity changed during diagnostic")
        records = logfile.read_text().splitlines() if logfile.exists() else []
        known = [line for line in records if line in ("ok " + name, "failed " + name)]
        row["outer_records"] = records
        row["exactly_one_nonignored_outer_result"] = len(records) == len(known) == 1
        row["native_outcome"] = ("passed" if known == ["ok " + name] else
                                 "failed" if known == ["failed " + name] else "missing_or_unexpected")
        row["result_consistent"] = bool(not row["timed_out"] and row["exactly_one_nonignored_outer_result"]
                                        and ((row["native_outcome"] == "passed" and row["exit_code"] == 0)
                                             or (row["native_outcome"] == "failed" and row["exit_code"] == 101)))
    except Exception as error:
        row["recording_error"] = f"{type(error).__name__}: {error}"
    finally:
        row["elapsed_seconds"] = time.monotonic() - started
        row["logs"] = [record(path) for path in (stdout, stderr, logfile) if path.exists()]
        save(OUT / (label + ".receipt.json"), row)
        print(json.dumps({"diagnostic": label, "exit_code": row["exit_code"],
                          "timed_out": row["timed_out"], "native_outcome": row.get("native_outcome")}), flush=True)
    return row

def main():
    require(not sys.argv[1:], "fixed diagnostic runner accepts no arguments")
    require(REPO.resolve(strict=True) == REPO and ORIGINAL.resolve(strict=True) == ORIGINAL,
            "source/campaign path alias")
    require(not OUT.is_relative_to(REPO), "diagnostic output must be external")
    OUT.mkdir(mode=0o700)  # Exclusive reservation; never resume or rerun an existing directory.
    result = {"schema": "trnm-original-node-failure-diagnostic-v1", "expected_head": HEAD,
              "expected_tree": TREE, "original_campaign": str(ORIGINAL),
              "original_parent_job_id": "1a1bc526042-138b0-1aa",
              "output": str(OUT), "runner": record(Path(__file__).resolve(strict=True)),
              "started_unix_seconds": time.time(), "original_full_suite_replaced": False,
              "original_failures_reclassified": False, "tests_rebuilt": False,
              "source_modified": False, "original_deadlines_or_budgets_changed": False,
              "whole_chain_pq_qualified": False, "production_activation": False,
              "sqlite_bounded_io_qualification_claimed": False,
              "full_raw_source_scan_performed_here": False,
              "full_raw_source_prepost_responsibility": "original parent campaign",
              "diagnostic_cases": [], "errors": []}
    env = None
    try:
        result["original_bindings"], env = bind_original()
        result["source_before"] = source_check("source-before", env)
        result["elf_before"] = pinned(ELF, ELF_PIN)
        elf_identity = identity(ELF)
        result["original_live_failures"] = original_live_snapshot()
        save(OUT / "diagnostic-start.json", result)
        for label, name in CASES:
            result["diagnostic_cases"].append(run_case(label, name, env, elf_identity))
    except Exception as error:
        result["errors"].append(f"{type(error).__name__}: {error}")
        result["exception_traceback"] = traceback.format_exc()
    finally:
        if env is not None:
            for key, action in (
                ("source_after", lambda: source_check("source-after", env)),
                ("elf_after", lambda: pinned(ELF, ELF_PIN)),
                ("original_bindings_after", lambda: {name: pinned(ORIGINAL / name, pin)
                                                     for name, pin in BINDING_PINS.items()}),
            ):
                try:
                    result[key] = action()
                except Exception as error:
                    result["errors"].append(f"{key}: {type(error).__name__}: {error}")
        result["finished_unix_seconds"] = time.time()
        cases = result["diagnostic_cases"]
        result["attempted_cases"] = len(cases)
        result["executed_cases"] = sum("pid" in row for row in cases)
        result["passed_cases"] = sum(row.get("native_outcome") == "passed" and row.get("result_consistent", False) for row in cases)
        result["failed_cases"] = sum(row.get("native_outcome") == "failed" and row.get("result_consistent", False) for row in cases)
        result["timed_out_cases"] = sum(row["timed_out"] for row in cases)
        result["diagnostic_capture_complete"] = (not result["errors"] and len(cases) == 2
                                                 and all(row.get("result_consistent") for row in cases))
        result["result"] = ("DIAGNOSTIC_CAPTURED_BOTH_PASS" if result["passed_cases"] == 2 else
                            "DIAGNOSTIC_CAPTURED_WITH_TEST_FAILURE") if result["diagnostic_capture_complete"] else "DIAGNOSTIC_INCOMPLETE_OR_TIMEOUT"
        save(OUT / "summary.json", result)
        print(json.dumps({"result": result["result"], "summary": str(OUT / "summary.json"),
                          "passed": result["passed_cases"], "failed": result["failed_cases"],
                          "timed_out": result["timed_out_cases"]}), flush=True)
    return 0 if result["diagnostic_capture_complete"] and result["failed_cases"] == 0 else 1

if __name__ == "__main__":
    raise SystemExit(main())

