import pathlib,subprocess,json,hashlib,tarfile,traceback
root=pathlib.Path('/data/chain-six-d9fb-20261108/publish-source')
original=pathlib.Path('/data/chain-six-d9fb-20261108/delivery-source')
out=pathlib.Path('/data/chain-six-d9fb-20261108/evidence/final-integration/f5-preparation')
out.mkdir(exist_ok=False)
parent=out.parent
f4='e9b7a60b9519e39b792199dc8756fb9d1245bab8'
def sha(b):return hashlib.sha256(b).hexdigest()
def run(name,args):
 p=subprocess.run(args,cwd=root,capture_output=True,timeout=600)
 (out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr)
 if p.returncode:raise RuntimeError((name,p.returncode,p.stderr.decode('utf-8','replace')[-1000:]))
 return p.stdout
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root).decode().strip()
assert git('rev-parse','HEAD')==f4 and git('status','--porcelain')==''
run('preflight',['bash','scripts/project-preflight.sh'])
package=parent/'github-prepublish/mldsa-readback-proposal-d9fb.tar.gz'
assert package.stat().st_size==33845 and sha(package.read_bytes())=='926632e8f9a6fa2619d29c0fcf35cbb17d4866dd20d31ce6d5c2a13cd7f1c958'
inputs=parent/'mldsa-readback-proposal'
inputs.mkdir(exist_ok=False)
members=[]
with tarfile.open(package,'r:gz') as archive:
 items=archive.getmembers()
 assert len(items)==123 and len({m.name for m in items})==123
 for m in items:
  rel=pathlib.PurePosixPath(m.name)
  assert m.isfile() and not rel.is_absolute() and '..' not in rel.parts
  dest=inputs/rel;dest.parent.mkdir(parents=True,exist_ok=True)
  raw=archive.extractfile(m).read();assert len(raw)==m.size
  with dest.open('xb') as f:f.write(raw)
  members.append({'path':m.name,'bytes':m.size,'sha256':sha(raw)})
assert sum(x['bytes'] for x in members)==264020
(out/'mldsa-input-extraction.json').write_text(json.dumps(members,indent=2)+'\n')
patches=[
 ('mldsa',inputs/'proposal.patch','91f5d68b891d1ca5246142d3d98be401cdbcdc00a1776752d7d5ffdf8dade9c8'),
 ('ci-literal',parent/'ci-literal-repair-review-v2/ci-v2-current-literal.patch','0d7aca756dcc2b2db2b386f1e44b5097e633d113e8342300e988fbf15c2ea415'),
 ('raw-storage',parent/'repository-json-repair-review-v1/proposal/proposal.patch','069ffe9abda5acb24a6c6e20ca4103a854ee6d2773bf7c951014b573759f176f')]
for label,path,digest in patches:
 assert sha(path.read_bytes())==digest
 run(label+'-patch-check',['git','apply','--check',str(path)])
 run(label+'-patch-apply',['git','apply',str(path)])
assert sha((root/'.github/workflows/pon-pq-system-continuation.yml').read_bytes())=='07c93ac69d837c91c917c4bd65f077bf04a90545b09d2fc2f58066c3d0057775'
assert sha((root/'scripts/ci/check_ci_contract.py').read_bytes())=='4a231ae15037b7d918c93fd3f90fd362aa54c4923ed4f2610734775f45d3e14f'
assert sha((root/'evidence/hepta-real-native-learning-20261108/verify_originals.py').read_bytes())=='1dc97b04d1c38c72a7f4d99a494998fdf8d615584b0e074e212ff6b053fe18de'
assert sha((root/'evidence/hepta-real-native-learning-20261108/export-manifest.json').read_bytes())=='28523b53429d8094760ff67206e95139ae4b868dee1ed9ae80b923882027f351'
run('refresh-original-inventory',['/usr/bin/python3','-B','scripts/refresh_distributed_source_inventory.py'])
inventory='trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs'
assert sha((root/inventory).read_bytes())=='55a5ef0c45f683022ad4f6d784946933d9bb1abf8c3ccdfc5f5ef8c5028a3b93'
plan_path='docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
plan=(root/plan_path).read_text()
marker='## 0. One authority and explicit retirement\n\n'
assert plan.count(marker)==1
plan=plan.replace(marker,marker+"**Final integration repair boundaries, 2026-11-08 UTC:**\nThe F4 scoped run at e9b7a60b9519e39b792199dc8756fb9d1245bab8 executed all\n431 named controls and retained four errors: three exact CI-step wiring errors\nand one repository JSON error. Its source-before/after bytes remained identical.\nThe final repair makes the CI contract require both the historical 23 and current\n10 controls, matches the exact current rustdoc line 359, and stores the single\noriginal empty failed-command stdout through a closed raw-byte path mapping.\nThe 517 original identities and original export-manifest bytes are unchanged.\n\nThe original source-inventory generator adds exactly the new current QROM\nobservation configuration, increasing its path roster from 1484 to 1485. This\nchanges the generated example/test Rust inventory; the native algorithm and\nmain-entry source files remain unchanged. Formal source and dependency lockfiles\nalso remain unchanged. The current composition pin is refreshed, while every\nhistorical work-cost pin and its current-source refusal remain intact.\nLater scoped validation and strict compilation identify their exact committed\nsource. No result is transferred to a new binary by source comparison alone.\n\nOriginal hosted business failures remain open. The ML-DSA workflow's original\nAPI rejection tests succeeded on all four lanes, but its old readback line\nprevented independent-C execution; the offline repair does not claim that\nunexecuted stage. CodeQL exported no API analyses or checks in 39 polls and\ncorrectly retained its original deadline refusal. Its explicit local-SARIF lane\nhas a different branch/upload scope; empty results, trigger policy, permissions\nand the original wait limit are not weakened. The overall disposition remains\nHOLD / NO-GO.\n\n",1)
old='Existing\nnative runtime, formal and fuzz subtrees remain F3-identical; source equality does'
new='At the F4 observation,\nnative, formal and fuzz subtrees are F3-identical; source equality does'
assert plan.count(old)==1
plan=plan.replace(old,new,1)
(root/plan_path).write_text(plan)
observed_path=root/'evidence/chain-six-full-20261108/OBSERVED_RESULTS.md'
observed=observed_path.read_text()
old='Native Rust, formal research implementation and locked dependency subtrees remain identical to F3; later static validation records their own commit.'
new='Native Rust implementation source remains identical to F3 except the regenerated example/test inventory, which adds one configuration input. Formal research code and dependency lockfiles are unchanged; later validation records their own commit.'
assert observed.count(old)==1
observed=observed.replace(old,new,1)
observed=observed.replace('Final delivery validation also identifies the exact later source and the unchanged native subtrees.','Final delivery validation also identifies the exact later source relationship, including the generated inventory exception.')
observed+="\n## Final integration findings and bounded repairs\n\nThe full F4 scoped run at e9b7a60b9519e39b792199dc8756fb9d1245bab8 executed all 24 commands and all 431 named Python controls: 427 passed and four reported errors. Three errors came from the CI contract's old exact step literal, and one came from a real failed command's empty stdout stored with a JSON extension. The CI and repository CLIs refused consistently, and the source-inventory check also required refresh. F4 remains FAIL; its source-before/after records are identical.\n\nThe reviewed repairs require the complete historical 23 plus current 10 control blocks, preserve the one empty original as a raw-byte file with a closed exact mapping and unchanged export manifest, and run the original inventory generator. The generated Rust inventory adds only config/pon/w1-qrom-current-source-observation-v1.json, moving from 1484 to 1485 source paths. This generated example/test file is an explicit exception to native-source byte equality; native algorithms and main entry source remain unchanged. Historical work-cost source pins are unchanged.\n\nFour original hosted ML-DSA artifacts establish that the intended compile-fail API test succeeded at line 359, with the required E0308/current-view type rejection. Its reader still required line 353. The one-byte correction is checked against all four original logs and nineteen labelled invalid variants. The original hosted failures remain, and the downstream independent-C stage was not executed in those jobs.\n\nThe original CodeQL exporter made 39 polls with no API analyses or CodeQL checks for the exact PR head/merge and refused at its original deadline. The explicit local-SARIF producer has a different branch filter and upload: never; those records cannot satisfy the API export. The original source identity, 16 exporter controls and trigger attribution are retained. No empty-result acceptance, timeout extension or privilege change is introduced.\n"
observed_path.write_text(observed)
cp=root/'config/pon/pq-cross-branch-corpus-v1.json'
before=json.loads(cp.read_bytes());after=json.loads(cp.read_bytes())
repin=['.github/workflows/pon-pq-system-continuation.yml','scripts/ci/check_ci_contract.py',inventory,plan_path]
pin_changes=[]
for path in repin:
 oldpin=before['pinned_blobs'][path]
 newpin=subprocess.check_output(['git','hash-object','--stdin'],cwd=root,input=(root/path).read_bytes()).decode().strip()
 after['pinned_blobs'][path]=newpin
 pin_changes.append({'path':path,'old':oldpin,'new':newpin})
check=json.loads(json.dumps(after))
for row in pin_changes:check['pinned_blobs'][row['path']]=row['old']
assert check==before and len(after['pinned_blobs'])==899 and len(after['required_paths'])==807
cp.write_text(json.dumps(after,indent=2)+'\n')
native_changed=git('diff','--name-only',f4,'--','trillionnium').splitlines()
assert native_changed==[inventory],native_changed
assert git('diff','--name-only',f4,'--','formal','tests/fuzz')==''
for path in ['trillionnium/Cargo.lock','tests/fuzz/Cargo.lock']:
 assert (root/path).read_bytes()==subprocess.check_output(['git','show',f4+':'+path],cwd=root)
run('diff-check',['git','diff','--check'])
changed=git('status','--porcelain')
(out/'prepared-status.txt').write_text(changed+'\n')
run('stage',['git','add','--','.github/workflows/pon-pq-system-continuation.yml','scripts/ci/check_ci_contract.py',inventory,plan_path,'config/pon/pq-cross-branch-corpus-v1.json','evidence/chain-six-full-20261108/OBSERVED_RESULTS.md','evidence/hepta-real-native-learning-20261108'])
run('staged-diff-check',['git','diff','--cached','--check'])
run('preflight-before-commit',['bash','scripts/project-preflight.sh'])
run('commit',['git','commit','-m','Close exact-source integration gates while preserving original failures'])
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
assert git('status','--porcelain')==''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=original).decode().strip()==f4
assert subprocess.check_output(['git','status','--porcelain'],cwd=original).decode().strip()==''
result={'schema':'chain-six-f5-clean-source-freeze-v1','head':head,'tree':tree,'parent':f4,'root':str(root),'native_original_source':'1a446a79700cc093a2b1a7f10367ef4a5ddbd680','native_rust_changes_from_f4':[inventory],'native_algorithm_and_main_sources_unchanged':True,'formal_fuzz_and_lockfiles_unchanged':True,'current_corpus_pin_changes':pin_changes,'historical_work_cost_profiles_modified':False,'source_paths':1485,'clean':True,'tests_on_this_commit':'pending','qualification':'HOLD_NO_GO'}
(out/'freeze.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
