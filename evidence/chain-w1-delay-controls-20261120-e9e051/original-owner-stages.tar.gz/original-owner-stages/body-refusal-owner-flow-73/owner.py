from pathlib import Path
import json,sys,time,resource,hashlib
root=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');src=root/'source';out=root/'body-refusal-owner-flow-73';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);t=time.monotonic();b=resource.getrusage(resource.RUSAGE_SELF);hits=[]
for path in (src/'trillionnium/crates/trnm-pon-node/src').rglob('*.rs'):
 text=path.read_text();lines=text.splitlines()
 if 'body_refusal' not in text and 'retry_at' not in text:continue
 matched=[i for i,line in enumerate(lines) if 'body_refusal' in line or 'retry_at' in line];selected=set()
 for i in matched:selected.update(range(max(0,i-20),min(len(lines),i+45)))
 snippets=[str(i+1)+':'+lines[i] for i in sorted(selected)];hits.append({'path':str(path.relative_to(src)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'snippets':snippets})
data=(json.dumps({'matches':hits},indent=2)+'\n').encode();(out/'READOUT.json').write_bytes(data);a=resource.getrusage(resource.RUSAGE_SELF);result={'wall_seconds':time.monotonic()-t,'self_user_cpu_seconds':a.ru_utime-b.ru_utime,'self_system_cpu_seconds':a.ru_stime-b.ru_stime,'readout_bytes':len(data),'readout_sha256':hashlib.sha256(data).hexdigest()};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'result':result,'matches':hits}),flush=True)
