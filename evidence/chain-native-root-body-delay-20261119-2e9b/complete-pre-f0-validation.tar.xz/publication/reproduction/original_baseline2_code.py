import pathlib,subprocess,json,time,os,hashlib,resource,fcntl,traceback
s=pathlib.Path('/home/qq/chain-host-stat-20261118-2e9b-source');base=pathlib.Path('/home/qq/work/chain-prepaid-d952-original-control-20261119-2e9b');out=base/'evidence-2';assert not out.exists();out.mkdir();src=base/'source-2';target=base/'target-2';result={'schema':'chain-original-prepaid-control.v2','source':'d95239eda6a666458aa264ddeaf993d6d9fbf37d','test':'ingress::public_v3::scalar_cpu::metered_fact_tests::continuously_distinct_bad_products_exhaust_one_original_prepaid_domain','automatic_retry':False,'prior_clone_native_tests':0,'fixture_changed':False,'iteration_limit':512,'initial_prepaid_credit_ns':400000000,'unchanged_start_reserve_ns':100000000,'full_burst_ns':2000000000,'f0_qualified':False,'started_ns':str(time.time_ns()),'stages':[]}
def save(): (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
def run(name,args,cwd,env=None,limit=3600):
 start=time.monotonic();usage=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args,'cwd':str(cwd)};result['stages'].append(row);save()
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:
  p=subprocess.Popen(args,cwd=cwd,stdout=so,stderr=se,env=env);row['pid']=p.pid;save();rc=p.wait(timeout=limit)
 after=resource.getrusage(resource.RUSAGE_CHILDREN);row.update(returncode=rc,elapsed_seconds=time.monotonic()-start,child_user_cpu_seconds=after.ru_utime-usage.ru_utime,child_system_cpu_seconds=after.ru_stime-usage.ru_stime);save();return rc
try:
 assert run('source-preflight',['bash','scripts/project-preflight.sh'],s)==0
 assert run('new-detached-worktree',['git','worktree','add','--detach','--no-checkout',str(src),result['source']],s)==0
 assert run('sparse-original-source',['git','sparse-checkout','set','--no-cone','/*','!/evidence/','!/docs/evidence/'],src)==0
 assert run('checkout',['git','checkout','--detach',result['source']],src)==0
 assert run('preflight',['bash','scripts/project-preflight.sh','--audit'],src)==0
 with pathlib.Path('/home/qq/chain-host-stat-20261118-2e9b-target/release/.cargo-lock').open('a+b') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert run('copy-owned-terminated-cache',['cp','-a','--reflink=auto','/home/qq/chain-host-stat-20261118-2e9b-target',str(target)],base)==0
 result['head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip();result['tree']=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=src,text=True).strip();result['status_before']=subprocess.check_output(['git','status','--porcelain=v1'],cwd=src,text=True);assert not result['status_before']
 rel='trillionnium/crates/trnm-pon-node/src/ingress/public_v3/scalar_cpu_metered_fact_tests.rs';data=(src/rel).read_bytes();assert data==(s/rel).read_bytes();result['unchanged_test_sha256']=hashlib.sha256(data).hexdigest();result['fresh_source_original_test_identical_to_candidate']=True;result['unmaterialized_historical_binary_evidence_not_tested']=True;save();print(json.dumps({'prepared':True,'path':str(base),'source':result['head']}),flush=True)
 env=os.environ.copy();env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];env['CARGO_TARGET_DIR']=str(target);env['CARGO_BUILD_JOBS']='2';env['CARGO_INCREMENTAL']='0';env['CARGO_NET_OFFLINE']='true'
 rc=run('original-prepaid-native',['/home/qq/.cargo/bin/cargo','+1.95.0','test','--offline','--locked','--release','--jobs','2','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib',result['test'],'--','--exact','--nocapture','--test-threads=1'],src,env)
 result['status_after']=subprocess.check_output(['git','status','--porcelain=v1'],cwd=src,text=True);result['original_case_passed']=rc==0;result['source_unchanged']=not result['status_after'] and (src/rel).read_bytes()==data
except BaseException as e:
 result['error']=repr(e);(out/'driver-error.log').write_text(traceback.format_exc())
finally:
 result['finished_ns']=str(time.time_ns());result['original_files']={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in out.iterdir() if p.name!='RESULT.json' and p.is_file()};save();print(json.dumps(result,indent=2),flush=True)