import ast,base64,hashlib,json,os,pathlib,subprocess,time
r=pathlib.Path('/home/qian-qi/work/chain-qrom-closure-publish-20261107')
o=pathlib.Path('/home/qian-qi/work/chain-qrom-closure-20261107-evidence/publication-A-fixtures-v1');o.mkdir()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
head='1e4bffc371bcdc53aabc621b6b6cb2485ab36f53'
def require(x,m):
 if not x:raise ValueError(m)
def digest(x):return hashlib.sha256(x).hexdigest()
def blob(x):return hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x,usedforsecurity=False).hexdigest()
require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==head,'A HEAD')
tree={}
for row in subprocess.check_output(['git','ls-tree','-r','-z',head],cwd=r,env=env).split(b'\0'):
 if row:
  meta,name=row.split(b'\t',1);mode,kind,oid=meta.decode().split();tree[name.decode()]={'mode':mode,'kind':kind,'git_blob':oid}
pins=json.loads((r/'config/pon/pq-cross-branch-corpus-v1.json').read_text())['pinned_blobs']
restored=[]
for name,oid in pins.items():
 if (r/name).exists():continue
 require(name.startswith('evidence/') and tree[name]['git_blob']==oid and tree[name]['mode'] in ('100644','100755'),'missing pin not exact regular tracked evidence')
 got=subprocess.run(['git','cat-file','blob',oid],cwd=r,env=env,capture_output=True);provider='local-Git-object'
 if got.returncode==0:data=got.stdout
 else:
  got=subprocess.run(['gh','api','repos/TrillionniumFoundation/Trillionnium-Chain/git/blobs/'+oid],cwd=r,env=env,capture_output=True)
  (o/('api-'+oid+'.stdout')).write_bytes(got.stdout);(o/('api-'+oid+'.stderr')).write_bytes(got.stderr);require(got.returncode==0,'exact GitHub blob read')
  item=json.loads(got.stdout);require(item['sha']==oid and item['encoding']=='base64' and type(item['size']) is int and 0<=item['size']<=1048576,'API identity/size')
  data=base64.b64decode(item['content'].replace('\n',''),validate=True);require(len(data)==item['size'],'API size');provider='authenticated-GitHub-exact-blob'
 require(blob(data)==oid,'exact pin blob bytes')
 parent=r
 for part in pathlib.Path(name).parts[:-1]:
  parent=parent/part;require(not parent.is_symlink(),'source ancestor symlink');parent.mkdir(exist_ok=True)
 fd=os.open(r/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o755 if tree[name]['mode']=='100755' else 0o644)
 with os.fdopen(fd,'wb') as f:f.write(data)
 restored.append({'path':name,'git_blob':oid,'bytes':len(data),'sha256':digest(data),'provider':provider})
(o/'restored-source-pins.json').write_text(json.dumps(restored,indent=2,sort_keys=True)+'\n')
p=subprocess.run(['python3','scripts/ci/check_pq_research_integration.py'],cwd=r,env=env,capture_output=True,timeout=300)
(o/'source-pin-check.stdout').write_bytes(p.stdout);(o/'source-pin-check.stderr').write_bytes(p.stderr)
print(json.dumps({'restored_pins':restored,'source_pin_check_exit':p.returncode,'source_pin_stdout':p.stdout.decode(),'source_pin_stderr':p.stderr.decode()}),flush=True)
testfiles=sorted((r/'scripts/ci').glob('test_w1_*.py'))+[r/'scripts/ci/test_ci_contract.py',r/'scripts/ci/test_ci_source_integrity.py',r/'scripts/ci/test_pq_research_integration.py']
files=set(testfiles)
for path in list(testfiles):
 t=ast.parse(path.read_text())
 for n in ast.walk(t):
  if isinstance(n,ast.ImportFrom) and n.module:
   for parent in [r/'scripts/ci',r/'scripts']:
    q=parent/(n.module.replace('.','/')+'.py')
    if q.is_file():files.add(q)
  if isinstance(n,ast.Import):
   for a in n.names:
    for parent in [r/'scripts/ci',r/'scripts']:
     q=parent/(a.name.replace('.','/')+'.py')
     if q.is_file():files.add(q)
# Include W1 audit helpers and their pinned contracts, all read-only source.
files.update((r/'scripts').glob('w1_*.py'))
files.update((r/'config/pon').glob('w1-*.json'))
prefixes=set();unresolved=[]
def add(value):
 if not isinstance(value,str):return
 if value.startswith('evidence/') and '\n' not in value and '\0' not in value:
  name=value.rstrip('/')
  if name.count('/')>=1 and any(x==name or x.startswith(name+'/') for x in tree):prefixes.add(name)
def divparts(n):
 if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Div):return divparts(n.left)+divparts(n.right)
 return [n.value if isinstance(n,ast.Constant) and isinstance(n.value,str) else None]
for path in sorted(files):
 if path.suffix=='.py':
  t=ast.parse(path.read_text())
  for n in ast.walk(t):
   if isinstance(n,ast.Constant):add(n.value)
   if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Div):
    parts=divparts(n);start=next((i for i,x in enumerate(parts) if x=='evidence' or isinstance(x,str) and x.startswith('evidence/')),None)
    if start is not None:
     sub=parts[start:]
     if all(isinstance(x,str) for x in sub):add('/'.join(sub))
     elif len(sub)>1:unresolved.append({'source':str(path.relative_to(r)),'line':getattr(n,'lineno',None)})
 elif path.suffix=='.json':
  def scan(v):
   if isinstance(v,str):add(v)
   elif isinstance(v,list):
    for x in v:scan(x)
   elif isinstance(v,dict):
    for k,x in v.items():add(k);scan(x)
  scan(json.loads(path.read_text()))
selected={x for x in tree if any(x==p or x.startswith(p+'/') for p in prefixes)}
missing=sorted(x for x in selected if not (r/x).exists())
probe=subprocess.run(['git','cat-file','--batch-check=%(objectname) %(objecttype) %(objectsize)'],cwd=r,env=env,input=(''.join(tree[x]['git_blob']+'\n' for x in missing)).encode(),capture_output=True)
require(probe.returncode==0,'object size lookup')
sizes=probe.stdout.decode().splitlines();require(len(sizes)==len(missing),'object size count')
rows=[]
for name,line in zip(missing,sizes):
 fields=line.split();row={'path':name,**tree[name],'local_blob_available':len(fields)==3 and fields[1]=='blob','bytes':int(fields[2]) if len(fields)==3 and fields[1]=='blob' else None};rows.append(row)
report={'schema':'TRNM-W1-A-STATIC-FIXTURE-COVERAGE1','candidate':head,'test_files':[str(x.relative_to(r)) for x in testfiles],'source_files_scanned':[str(x.relative_to(r)) for x in sorted(files)],'resolved_fixture_prefixes':sorted(prefixes),'unresolved_dynamic_path_expressions':unresolved,'selected_tracked_fixture_files':len(selected),'missing':rows,'scope':'Static selected implementation coverage, not proof of exhaustive runtime dependency discovery. Prefixes refer to actual tracked A paths. No test results inferred.'}
(o/'fixture-inventory.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'test_files':len(testfiles),'source_files_scanned':len(files),'selected_fixture_files':len(selected),'missing_count':len(rows),'known_missing_bytes':sum(x['bytes'] or 0 for x in rows),'unknown_blob_sizes':sum(x['bytes'] is None for x in rows),'missing':rows,'resolved_prefixes':sorted(prefixes)}),flush=True)
