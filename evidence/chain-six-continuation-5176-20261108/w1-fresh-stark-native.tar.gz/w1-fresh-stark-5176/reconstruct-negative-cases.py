#!/usr/bin/env python3
"""Rebuild omitted ordinary-control inputs and compare every original digest."""
import hashlib,importlib.util,json,pathlib,sys
sys.dont_write_bytecode=True
bundle=pathlib.Path(__file__).resolve().parent
manifest=json.loads((bundle/'manifest.json').read_text())
root=pathlib.Path(sys.argv[1]).resolve(strict=True);out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=False)
helper=root/'helpers/run_carry_controls.py'
if hashlib.sha256(helper.read_bytes()).hexdigest()!='ba715fc86c2af79092ead558e9e5fd6ee610df05e9e9531268af0a6d74dceb43':raise ValueError('helper pin')
spec=importlib.util.spec_from_file_location('pinned_control_helpers',helper);control=importlib.util.module_from_spec(spec);spec.loader.exec_module(control)
generation=root/'experiment/generation-01';fixture=root/'retained-native-fixture'
retained={'statement.bin':generation/'prepared/statement.bin','sha.proof.bin':generation/'proof/sha.proof.bin','arith.proof.bin':generation/'proof/arith.proof.bin'}
raw={name:path.read_bytes() for name,path in retained.items()}
for name,replacements,prefix,phases in control.ordinary_controls(raw['statement.bin'],raw['sha.proof.bin'],raw['arith.proof.bin'],(fixture/'expected_header.bin').read_bytes(),(fixture/'expected_artifacts.bin').read_bytes()):
    control.populate(out/name,retained,replacements)
actual={}
for path in out.rglob('*'):
    if path.is_file():
        relative='experiment/generation-01/cases/'+str(path.relative_to(out))
        data=path.read_bytes();actual[relative]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
expected={r:{k:v[k] for k in ('bytes','sha256')} for r,v in manifest['omitted_reconstructible_case_files'].items()}
if actual!=expected:raise ValueError('negative-case reconstruction differs from original bytes')
print(json.dumps({'reconstructed_case_files':len(actual),'all_original_digests_match':True,'verification_executed':False}))
