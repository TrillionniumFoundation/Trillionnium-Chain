import ast,hashlib,json,os,sys,tarfile,tempfile,time
from pathlib import Path
OUT=Path(tempfile.mkdtemp(prefix="trnm-continuity-original-failures-20261116-"))
ROOTS={"v3":Path("/tmp/trnm-continuity-original-20261116-jvd8w4er"),"v5":Path("/tmp/trnm-continuity-original-v5-20261116-4s0txlam")}
EXPECTED_BINARY={"v3":{"bytes":610956064,"sha256":"5ed7ad7063e46fc29d37c46ddfb53b6e993c0e2dff6021cb49cc9b804217ef67"},"v5":{"bytes":610955888,"sha256":"7c884eb67afbcc79e2a3e2163e3a581d093fccd936b1fab71abc8d92e9d37d4c"}}
STORE="trillionnium/crates/trnm-pon-node/src/store.rs"
HOOK="trillionnium/crates/trnm-pon-node/src/hia_continuity_staging_oracle.rs"
DECLARATION=b'\n#[cfg(test)]\n#[path = "hia_continuity_staging_oracle.rs"]\nmod hia_continuity_staging_oracle;\n'
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def identity(path):
 need(path.is_file() and not path.is_symlink(),"Regular file required: "+str(path))
 size=0;digest=hashlib.sha256()
 with path.open("rb") as stream:
  while block:=stream.read(1<<20):size+=len(block);digest.update(block)
 return {"bytes":size,"sha256":digest.hexdigest()}
def write_json(path,document):
 with path.open("x") as stream:stream.write(json.dumps(document,sort_keys=True,indent=2)+"\n")
with (OUT/"archive_driver.py").open("x") as stream:stream.write(sys.orig_argv[sys.orig_argv.index("-c")+1])
files={};attempts={}
def add(name,path):
 need(name not in files and not path.is_symlink() and path.is_file(),"Duplicate or unsafe evidence: "+name)
 files[name]={"source_path":str(path),**identity(path)}
for version,root in ROOTS.items():
 output=root/("original-rust-run-v1" if version=="v3" else "original-rust-run-v5")
 wrapper=json.loads((root/"execution-wrapper.json").read_bytes());report=json.loads((output/"report.json").read_bytes())
 need(wrapper["status"]==report["status"]=="FAIL" and wrapper["oracle_exit_code"]==1 and wrapper["cleanup_errors"]==[],"Failed attempt identity")
 binary=root/"original-test-binary";need(identity(binary)==EXPECTED_BINARY[version],"Actual preserved original binary")
 need(wrapper["independent_original_binary"]["path"]==str(binary),"Wrapper preserved another executable")
 need((output/"isolated-source"/STORE).read_bytes()==(root/"repo"/STORE).read_bytes()+DECLARATION,"Original function bytes changed")
 need((output/"isolated-source"/HOOK).read_bytes()==(root/"repo/hia/platform/continuity_store/rust_reference.rs").read_bytes(),"Compiled child differs")
 actual_stdout=output/"actual-apply-slot-root-corpus/stdout.raw"
 actual_stderr=output/"actual-apply-slot-root-corpus/stderr.raw"
 lines=actual_stdout.read_text().splitlines() if actual_stdout.exists() else []
 contexts=[json.loads(line.split("HIA_CONTINUITY_CONTEXT:",1)[1]) for line in lines if "HIA_CONTINUITY_CONTEXT:" in line]
 cases=[json.loads(line.split("HIA_CONTINUITY_STAGE_ORACLE:",1)[1]) for line in lines if "HIA_CONTINUITY_STAGE_ORACLE:" in line]
 need(len(cases)==0,"Unexpected already-executed semantic corpus")
 retained=[row for row in report["stages"] if any("store::" in part and "hia_continuity" not in part for part in row["argv"]) and "--exact" in row["argv"]]
 need(len(retained)==(0 if version=="v3" else 4) and all(row["exit_code"]==0 for row in retained),"Actual retained-test outcome differs")
 build=json.loads((root/"unpacked/bundle/build.json").read_bytes())
 sourceinputs=build["source_inputs"];originals=build["original_sources"]
 need(len(sourceinputs)==61 and len(originals)==4361,"Bound source set cardinality")
 sourcehash=sha(json.dumps(sourceinputs,sort_keys=True,separators=(",",":")).encode())
 need(sourcehash==build["source_set_sha256"],"Source set digest")
 attempts[version]={"status":"ACTUAL_ORIGINAL_FAIL","root":str(root),"wrapper":identity(root/"execution-wrapper.json"),"oracle_report":identity(output/"report.json"),
 "actual_semantic_cases":0,"planned_semantic_cases":572,"retained_tests_executed":len(retained),"retained_test_stages":retained,"actual_constructor_snapshots_printed":contexts,"constructor_snapshot_count":len(contexts),
 "constructor_success_cannot_be_inferred_from_print":True,"original_failure":report["error"],"actual_stderr":actual_stderr.read_text() if actual_stderr.exists() else None,
 "source_count":61,"original_source_count":4361,"source_set_sha256":sourcehash,"original_source_set_sha256":sha(json.dumps(originals,sort_keys=True,separators=(",",":")).encode()),
 "exact_corpus":build.get("corpus"),"independent_binary":{"path":str(binary),**EXPECTED_BINARY[version]},
 "original_store_bytes_preserved":True,"compiled_child_matches_bound_source":True,"source_after_cleanup_errors":wrapper["cleanup_errors"],"wrapper_elapsed_seconds":wrapper["elapsed_seconds"],
 "oracle_started_utc":wrapper.get("oracle_started_utc"),"oracle_finished_utc":wrapper.get("oracle_finished_utc"),"wrapper_finished_utc":wrapper["finished_utc"],
 "native_or_rust_success_relabelled":False}
 for path in sorted(root.iterdir()):
  if path.is_file() and not path.is_symlink() and path.name!="original-test-binary":
   need(path.stat().st_size<64<<20,"Unexpected large top-level evidence")
   add(version+"/"+path.name,path)
 for name in ("preparation","chunks","chunks-before-name-correction"):
  directory=root/name
  if directory.is_dir():
   for path in sorted(directory.rglob("*")):
    need(not path.is_symlink(),"Evidence directory symlink")
    if path.is_file() and not path.name.endswith(".bin"):add(version+"/"+path.relative_to(root).as_posix(),path)
 for directory,dirs,names in os.walk(output,followlinks=False):
  dirs[:]=[name for name in dirs if name not in ("isolated-source","cargo-target")]
  for name in sorted(names):
   path=Path(directory)/name;add(version+"/"+path.relative_to(root).as_posix(),path)
 for relative in (STORE,HOOK,"trillionnium/Cargo.lock"):
  path=output/"isolated-source"/relative
  add(version+"/compiled-source/"+relative,path)
 add(version+"/bound-native-build.json",root/"unpacked/bundle/build.json")
 need(identity(binary)==EXPECTED_BINARY[version],"Preserved executable changed during capture")
summary={"schema":"trnm.hia.continuity-original-failed-attempts.v1","status":"TWO_ACTUAL_ORIGINAL_FAILURES_PRESERVED","planned_public_corpus_cases":572,
"completed_original_semantic_cases":0,"original_rust_qualified":False,"native_qualification_separate":True,
"failure_attribution":{"v3":"Adapter omitted store:: in retained continuity test name; linked-test discovery refused before retained tests/corpus.",
"v5":"All four retained tests passed; variant 2 hook chose PermanentAccountGrowthV2 opener for a growth-reference Config, panicking GROWTH_PROFILE before corpus."},
"attempts":attempts,"scope":"Original failures are immutable observations, not rewritten PASS; V6 requires its own new source-bound qualification.",
"independent_binaries_stored_separately":True,"omitted_reconstructible_copies":["private Git repo","isolated complete original source except exact appended store/hook/Cargo.lock","native unpacked package copies","transport binary chunk duplicates"],
"complete_raw_process_stages_retained":True,"created_unix_ns":time.time_ns()}
write_json(OUT/"summary.json",summary)
add("summary.json",OUT/"summary.json");add("archive_driver.py",OUT/"archive_driver.py")
write_json(OUT/"file-manifest.json",{"schema":"trnm.hia.exact-evidence-files.v1","files":files,"file_count":len(files),"uncompressed_bytes":sum(row["bytes"] for row in files.values())})
add("file-manifest.json",OUT/"file-manifest.json")
archive_path=OUT/"continuity-original-v3-v5-failures.tar.xz"
with tarfile.open(archive_path,"w:xz",preset=3) as archive:
 for name,row in sorted(files.items()):
  path=Path(row["source_path"]);need(identity(path)=={k:row[k] for k in ("bytes","sha256")},"Source changed before archive")
  archive.add(path,arcname=name,recursive=False)
verified={}
with tarfile.open(archive_path,"r:xz") as archive:
 members=archive.getmembers();need(len(members)==len(files) and len({m.name for m in members})==len(files),"Complete unique archive member set")
 for member in members:
  need(member.isfile() and member.name in files,"Unexpected archive entry")
  size=0;digest=hashlib.sha256()
  with archive.extractfile(member) as stream:
   while block:=stream.read(1<<20):size+=len(block);digest.update(block)
  observed={"bytes":size,"sha256":digest.hexdigest()}
  need(observed=={k:files[member.name][k] for k in ("bytes","sha256")},"Archived bytes differ")
  verified[member.name]=observed
for name,row in files.items():need(identity(Path(row["source_path"]))=={k:row[k] for k in ("bytes","sha256")},"Evidence changed during archive")
final={"archive":{"path":str(archive_path),**identity(archive_path)},"members":len(files),"all_member_bytes_reverified":True,
"summary":{"path":str(OUT/"summary.json"),**identity(OUT/"summary.json")},"manifest":{"path":str(OUT/"file-manifest.json"),**identity(OUT/"file-manifest.json")},
"binary_identities":{key:value["independent_binary"] for key,value in attempts.items()},"actual_semantic_cases":0,"v5_actual_retained_tests":4}
write_json(OUT/"archive-identity.json",final);print(json.dumps(final),flush=True)
