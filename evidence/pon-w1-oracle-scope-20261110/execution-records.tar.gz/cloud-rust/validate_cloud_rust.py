#!/usr/bin/env python3
"""Pinned, isolated Rust setup plus exact-source locked metadata and format gates."""
from __future__ import annotations
import concurrent.futures
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tarfile
import tomllib

sys.dont_write_bytecode = True
ROOT = Path('/workspace/scratch/0776da4af99b')
REPO = ROOT / 'repo'
OUT = ROOT / 'cloud-rust-validation-6e39f273'
FEASIBILITY = ROOT / 'cloud-rust-feasibility-6e39f273'
SOURCE = '6e39f27357ce7c030f5662ada3d524fecb58d63e'
MANIFEST_SHA256 = '821ff14e4c4a1cbe1e8915f35aff0a3fbbdf8d293ad48ab8f31e3b0440c581f9'
SPEC = importlib.util.spec_from_file_location('desktop_recorder', ROOT / 'validate_on_desktop.py')
SUPPORT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SUPPORT)


def resources():
    mem = {line.split(':')[0]: line.split(':')[1].strip()
           for line in Path('/proc/meminfo').read_text().splitlines()
           if line.split(':')[0] in ['MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree']}
    return {'memory': mem, 'disk': shutil.disk_usage(ROOT)._asdict()}


def main():
    OUT.mkdir()
    downloads = OUT / 'downloads'
    extracted = OUT / 'extracted'
    prefix = OUT / 'toolchain'
    cargo_home = OUT / 'cargo-home'
    target = OUT / 'target'
    records = OUT / 'records'
    for directory in [downloads, extracted, prefix, cargo_home, target, records]:
        directory.mkdir()
    env = dict(os.environ)
    env.update(PATH=str(prefix / 'bin') + ':' + env.get('PATH', '/usr/bin:/bin'),
               CARGO_HOME=str(cargo_home), CARGO_TARGET_DIR=str(target),
               RUSTUP_HOME=str(OUT / 'unused-rustup-home'),
               RUSTC=str(prefix / 'bin/rustc'), RUSTDOC=str(prefix / 'bin/rustdoc'),
               CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_TERM_COLOR='never',
               PYTHONDONTWRITEBYTECODE='1', RUSTFLAGS='', RUSTDOCFLAGS='')
    for key in ['CARGO_ENCODED_RUSTFLAGS', 'CARGO_ENCODED_RUSTDOCFLAGS',
                'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'CARGO_BUILD_TARGET']:
        env.pop(key, None)
    recorder = SUPPORT.Recorder(records, env)
    summary = {'schema': 'trnm-cloud-rust-validation-v1', 'started_utc': SUPPORT.now(),
               'source_commit': SOURCE, 'runner': SUPPORT.hash_regular(Path(__file__)),
               'recorder_source': SUPPORT.hash_regular(ROOT / 'validate_on_desktop.py'),
               'resources_before': resources(), 'toolchain_prefix': str(prefix),
               'cargo_home': str(cargo_home), 'cargo_target_dir': str(target),
               'jobs': 1, 'incremental': 0, 'source_unchanged': None,
               'toolchain_installed': False, 'provider_built': False,
               'metadata': {}, 'format': 'NOT_EXECUTED', 'strict_clippy': 'NOT_EXECUTED',
               'published': False, 'new_native_node_processes': 0,
               'production_activation': False, 'errors': [], 'skipped': []}
    before = None
    guard = ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py',
             '--kind', 'head', '--expected-head', SOURCE]

    def must(name, argv, cwd=REPO, timeout=600):
        row = recorder.command(name, argv, cwd=cwd, timeout=timeout)
        SUPPORT.require(row['passed'], 'required step failed: ' + name)
        return row

    try:
        must('preflight', ['/bin/bash', 'scripts/project-preflight.sh', '--dev'])
        must('source-before', guard + ['--output', str(OUT / 'source-before.json')], timeout=900)
        before = json.loads((OUT / 'source-before.json').read_text())
        SUPPORT.require(before['tested_commit'] == SOURCE and before['tracked_worktree_verified'],
                        'exact source guard did not establish source')
        summary['source_before'] = before
        raw = (FEASIBILITY / 'rust-manifest.response').read_bytes()
        SUPPORT.require(hashlib.sha256(raw).hexdigest() == MANIFEST_SHA256, 'Rust manifest digest mismatch')
        manifest = tomllib.loads(raw.decode())
        SUPPORT.require(manifest['date'] == '2026-04-16'
                        and manifest['pkg']['rust']['version'].startswith('1.95.0 '), 'Rust manifest version mismatch')
        SUPPORT.require(shutil.disk_usage(ROOT).free >= 6 * 1024**3, 'insufficient disk for isolated minimal toolchain')
        packages = []
        for name in ['rustc', 'rust-std', 'cargo', 'rustfmt-preview', 'clippy-preview']:
            item = manifest['pkg'][name]['target']['x86_64-unknown-linux-gnu']
            SUPPORT.require(item['available'] is True, 'required Rust component unavailable')
            url, digest = item['xz_url'], item['xz_hash']
            SUPPORT.require(url.startswith('https://static.rust-lang.org/dist/2026-04-16/'),
                            'unexpected component origin')
            archive = downloads / url.rsplit('/', 1)[1]
            packages.append({'name': name, 'url': url, 'sha256': digest, 'archive': str(archive)})
        summary['rust_manifest_sha256'] = MANIFEST_SHA256
        summary['components'] = packages
        SUPPORT.write_json(OUT / 'input-pins.json', packages)

        def download(item):
            return recorder.command('download-' + item['name'],
                ['/usr/bin/curl', '--fail-with-body', '--location', '--proto', '=https', '--tlsv1.2',
                 '--connect-timeout', '20', '--max-time', '300', '--max-redirs', '4',
                 '--max-filesize', str(200 * 1024**2), '--output', item['archive'], item['url']],
                cwd=OUT, timeout=320)

        # Download only. Component installations share a prefix and stay sequential.
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            downloaded = list(pool.map(download, packages))
        SUPPORT.require(all(row['passed'] for row in downloaded), 'component download failed; no automatic retry')
        for item in packages:
            archive = Path(item['archive'])
            actual = SUPPORT.hash_regular(archive)
            SUPPORT.require(actual['sha256'] == item['sha256'], 'component SHA mismatch: ' + item['name'])
            item['observed_archive'] = actual
            with tarfile.open(archive, 'r:xz') as content:
                members = content.getmembers()
                root_names = {member.name.split('/')[0] for member in members}
                SUPPORT.require(len(root_names) == 1, 'component archive has multiple roots')
                for member in members:
                    parts = Path(member.name).parts
                    SUPPORT.require(not Path(member.name).is_absolute() and '..' not in parts,
                                    'component archive has escaping path')
            directory = extracted / next(iter(root_names))
            must('extract-' + item['name'], ['/usr/bin/tar', '--extract', '--xz', '--file', str(archive),
                                           '--directory', str(extracted)], cwd=OUT, timeout=180)
            item['installer'] = SUPPORT.hash_regular(directory / 'install.sh')
            must('install-' + item['name'], ['/bin/sh', str(directory / 'install.sh'),
                                           '--prefix=' + str(prefix), '--disable-ldconfig'], cwd=OUT, timeout=180)
            # This disposable extraction was created here; the pinned archive remains.
            shutil.rmtree(directory)
        must('rustc-version', [str(prefix / 'bin/rustc'), '--version', '--verbose'], timeout=30)
        must('cargo-version', [str(prefix / 'bin/cargo'), '--version'], timeout=30)
        must('rustfmt-version', [str(prefix / 'bin/rustfmt'), '--version'], timeout=30)
        must('clippy-version', [str(prefix / 'bin/cargo-clippy'), '--version'], timeout=30)
        SUPPORT.require(recorder.stdout('rustc-version').startswith('rustc 1.95.0 ')
                        and recorder.stdout('cargo-version').startswith('cargo 1.95.0 '), 'installed toolchain version mismatch')
        summary['toolchain_installed'] = True
        summary['installed_binary_inputs'] = {
            name: SUPPORT.hash_regular(prefix / 'bin' / name)
            for name in ['rustc', 'cargo', 'rustfmt', 'cargo-fmt', 'cargo-clippy', 'clippy-driver']}
        summary['lockfiles_before'] = {name: SUPPORT.hash_regular(REPO / name)
                                      for name in ['trillionnium/Cargo.lock', 'tests/fuzz/Cargo.lock']}
        cargo = str(prefix / 'bin/cargo')
        for label, path, features in [('default', 'trillionnium/Cargo.toml', []),
                                      ('all-features', 'trillionnium/Cargo.toml', ['--all-features']),
                                      ('fuzz', 'tests/fuzz/Cargo.toml', [])]:
            base = [cargo, 'metadata', '--locked', '--format-version', '1', '--manifest-path', path, *features]
            initial = recorder.command('metadata-' + label + '-offline-initial', base + ['--offline'], cwd=REPO)
            selected = initial
            attempts = [initial['name']]
            if not initial['passed']:
                # Dependency versions stay bound by the committed lockfile. Keep
                # inherited managed network settings, and never relax --locked.
                online = recorder.command('metadata-' + label + '-locked-fetch', base, cwd=REPO, timeout=900)
                attempts.append(online['name'])
                selected = online
                if online['passed']:
                    selected = recorder.command('metadata-' + label + '-offline-final', base + ['--offline'], cwd=REPO)
                    attempts.append(selected['name'])
            summary['metadata'][label] = {'status': 'PASS' if selected['passed'] else 'FAIL',
                                           'attempts': attempts, 'final_step': selected['name']}
        formatted = recorder.command('format', [cargo, 'fmt', '--manifest-path', 'trillionnium/Cargo.toml',
                                                '--all', '--', '--check'], cwd=REPO, timeout=600)
        summary['format'] = 'PASS' if formatted['passed'] else 'FAIL'
        summary['resources_after_light_gates'] = resources()
        summary['strict_clippy_argv'] = [cargo, 'clippy', '--locked', '--offline', '--manifest-path',
                                         'trillionnium/Cargo.toml', '--workspace', '--all-targets',
                                         '--all-features', '--', '-D', 'warnings']
        summary['skipped'].append({'step': 'strict-clippy',
                                  'reason': 'Await explicit resource assessment after light gates; no provider or Clippy build started by this script'})
    except Exception as error:
        summary['errors'].append({'type': type(error).__name__, 'message': str(error)})
    finally:
        if before is not None:
            after = recorder.command('source-after', guard + ['--output', str(OUT / 'source-after.json')],
                                     cwd=REPO, timeout=900)
            if after['passed']:
                summary['source_after'] = json.loads((OUT / 'source-after.json').read_text())
                summary['source_unchanged'] = summary['source_after'] == before
            else:
                summary['source_unchanged'] = False
        summary['resources_final'] = resources()
        summary['finished_utc'] = SUPPORT.now()
        summary['steps'] = [{k: row[k] for k in ['name', 'exit_code', 'passed', 'timed_out', 'elapsed_seconds']}
                            for row in recorder.steps]
        summary['status'] = ('LIGHT_GATES_PASSED_STRICT_CLIPPY_NOT_EXECUTED'
            if not summary['errors'] and summary['source_unchanged'] is True
            and summary['format'] == 'PASS' and len(summary['metadata']) == 3
            and all(item['status'] == 'PASS' for item in summary['metadata'].values())
            else 'INCOMPLETE_OR_FAILED')
        SUPPORT.write_json(OUT / 'summary.json', summary)
        print(json.dumps({'summary_path': str(OUT / 'summary.json'),
                          'status': summary['status'], 'errors': summary['errors'],
                          'metadata': summary['metadata'], 'format': summary['format'],
                          'strict_clippy': summary['strict_clippy'],
                          'resources': summary['resources_final']}, sort_keys=True), flush=True)
    return 0 if summary['status'].startswith('LIGHT_GATES_PASSED') else 1


if __name__ == '__main__':
    sys.exit(main())
