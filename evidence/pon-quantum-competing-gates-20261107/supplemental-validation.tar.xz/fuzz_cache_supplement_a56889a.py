#!/usr/bin/env python3
"""Isolated supplemental locked fuzz metadata; never writes the main cache/repo."""
from datetime import datetime, timezone
import hashlib, importlib.util, json, os
from pathlib import Path
import shutil, signal, subprocess, sys, time, tomllib, traceback

ROOT=Path('/home/qian-qi/work/trnm-quantum-four-gates-20261107-c9b4')
REPO=ROOT/'repo'
HEAD='a56889a54aac5f14141bb45fb602141dd6a37645'
EXPECTED={'head':HEAD,'tree':'b4e64c82d2646b9f32124feb510edc3349a375d0','tracked_files':11030,'inventory_sha256':'a1f7fa55fccc079391b874a86b2bdd5ae667615777aa305ad355d55b66c99424'}
DRIVER=ROOT/'run_competing_gates_validation.py'
DRIVER_SHA='48a259891b7da79f845cf578f71c035679c73844d6c3ddc3610352f22e2f9f39'
ENVFILE=ROOT/'build-environment-normal-loader-fresh-target.json'
ENV_SHA='e997245b8004f49da3cf8f1805934a0ddcdb910a205034f9382a2c4e3adeb4a4'
OUT=ROOT/'fuzz-validation-a56889a-20261107'
CACHE=ROOT/'fuzz-cache-a56889a-20261107'
ORIGINAL=ROOT/'validation-competing-a56889a/commands/23-fuzz-offline-full-metadata'
LOCK=REPO/'tests/fuzz/Cargo.lock'
LOCK_SHA='6bb73c6a273d5a61637ba673a15f435e82596eb07ecceac64c79e87fea7a9f35'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc(): return datetime.now(timezone.utc).isoformat()
def canonical(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def write(p,v):
    tmp=p.with_name(p.name+'.pending')
    with tmp.open('w') as f:
        json.dump(v,f,sort_keys=True,indent=2)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    tmp.replace(p)
def configs(home):
    rows=[]
    for name in ('config','config.toml'):
        p=home/name; row={'path':str(p),'exists':os.path.lexists(p)}
        if row['exists']:
            row.update(sha256=sha(p),resolved_path=str(p.resolve()),symlink=p.is_symlink(),mode=oct(p.lstat().st_mode))
        rows.append(row)
    return rows

def main():
    assert sha(DRIVER)==DRIVER_SHA
    assert sha(ENVFILE)==ENV_SHA
    spec=importlib.util.spec_from_file_location('retained_source_verifier',DRIVER)
    verifier=importlib.util.module_from_spec(spec); spec.loader.exec_module(verifier)
    declared=json.loads(ENVFILE.read_bytes())
    oldhome=Path(declared['CARGO_HOME']); oldconfigs=configs(oldhome)
    env=dict(declared,CARGO_HOME=str(CACHE),CARGO_TARGET_DIR=str(OUT/'target'),CARGO_BUILD_JOBS='1',
        CARGO_NET_OFFLINE='false',CARGO_REGISTRIES_CRATES_IO_PROTOCOL='sparse',CARGO_HTTP_TIMEOUT='15',
        CARGO_NET_RETRY='1',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C',LANG='C')
    cargo=str(Path(declared['RUSTC']).parent/'cargo')
    os.environ.clear(); os.environ.update(env)
    initial=verifier.source(REPO,HEAD)
    assert initial==EXPECTED
    assert not subprocess.check_output(['git','ls-files','--others','-z'],cwd=REPO)
    OUT.mkdir(exist_ok=False); CACHE.mkdir(exist_ok=False)
    (OUT/'sources').mkdir(); (OUT/'original').mkdir()
    isolated_configs=configs(CACHE)
    commands=[]
    result={'status':'STARTED','head':HEAD,'created_utc':utc(),'commands':commands,
        'independent_cargo_home':str(CACHE),'output_directory':str(OUT),
        'original_run_failure_preserved':True,'native_main_job_modified':False,
        'fuzz_binary_executed':False,'native_build_performed':False,
        'quantum_hardware_executed':False,'physical_hardware_calibrated':False,
        'prelaunch_diagnostics':[
            {'kind':'tool_argument_rejection','detail':'h_process_start requires absolute executable; initial python3 request did not launch'},
            {'kind':'local_staging_failure','detail':'local scratch file write failed ENOSPC before remote script upload; direct tool byte upload used'}]}
    def guard(name):
        row={'checked_utc':utc()}
        try:
            assert sha(DRIVER)==DRIVER_SHA,'SOURCE_HELPER_CHANGED'
            assert sha(ENVFILE)==ENV_SHA,'ORIGINAL_ENV_CHANGED'
            assert configs(oldhome)==oldconfigs,'ORIGINAL_CONFIG_CHANGED'
            assert configs(CACHE)==isolated_configs,'ISOLATED_CONFIG_CHANGED'
            assert not subprocess.check_output(['git','ls-files','--others','-z'],cwd=REPO),'EXTRA_SOURCE'
            observed=verifier.source(REPO,HEAD)
            assert observed==EXPECTED,'SOURCE_CHANGED'
            assert not subprocess.check_output(['git','ls-files','--others','-z'],cwd=REPO),'EXTRA_SOURCE'
            assert sha(LOCK)==LOCK_SHA,'LOCK_CHANGED'
            row.update(status='VERIFIED',source=observed,original_cargo_configs=oldconfigs)
            return observed
        except BaseException as e:
            row.update(status='FAILED',error=repr(e)); raise
        finally: write(OUT/'sources'/(name+'.json'),row)
    def run(name,offline):
        cmd=[cargo,'metadata','--locked','--manifest-path','tests/fuzz/Cargo.toml','--all-features','--format-version','1']
        if offline: cmd.insert(2,'--offline')
        row={'name':name,'argv':cmd,'cwd':str(REPO),'started_utc':utc(),'timeout_seconds':240,
            'offline':offline,'exit_code':None,'timed_out':False,'stdout':name+'.json',
            'stderr':name+'.stderr','source_before':guard(name+'-before')}
        commands.append(row); write(OUT/'commands.json',commands)
        start=time.monotonic()
        with (OUT/row['stdout']).open('xb') as stdout,(OUT/row['stderr']).open('xb') as stderr:
            try:
                proc=subprocess.Popen(cmd,cwd=REPO,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
                try: row['exit_code']=proc.wait(timeout=240)
                except subprocess.TimeoutExpired:
                    row['timed_out']=True; os.killpg(proc.pid,signal.SIGKILL); row['exit_code']=proc.wait()
            finally:
                stdout.flush(); stderr.flush(); os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
                row['elapsed_seconds']=time.monotonic()-start
                row['source_after']=guard(name+'-after')
                row['stdout_sha256']=sha(OUT/row['stdout']); row['stderr_sha256']=sha(OUT/row['stderr'])
                row['ended_utc']=utc(); write(OUT/'commands.json',commands)
        print(json.dumps({k:row[k] for k in ('name','exit_code','timed_out','elapsed_seconds')}),flush=True)
        assert row['exit_code']==0 and not row['timed_out'],'METADATA_FAILED:'+name
        graph=json.loads((OUT/row['stdout']).read_bytes())
        assert isinstance(graph.get('resolve'),dict) and graph['resolve']['nodes'],'MISSING_GRAPH'
        assert len(graph['packages'])>1 and graph.get('workspace_members'),'SHALLOW_METADATA'
        locked={(p['name'],p['version'],p.get('source')):p for p in packages}
        registry=[p for p in graph['packages'] if p.get('source')]
        assert all((p['name'],p['version'],p['source']) in locked for p in registry),'UNLOCKED_PACKAGE'
        row.update(canonical_full_metadata_sha256=hashlib.sha256(canonical(graph)).hexdigest(),
            packages=len(graph['packages']),registry_packages=len(registry),resolve_nodes=len(graph['resolve']['nodes']))
        write(OUT/'commands.json',commands)
        return graph
    try:
        write(OUT/'declaration.json',result|{'source':initial,'driver_sha256':sha(__file__),
            'source_verifier_path':str(DRIVER),'source_verifier_sha256':DRIVER_SHA,
            'original_environment_sha256':ENV_SHA,'original_cargo_home':str(oldhome),
            'original_cargo_configs':oldconfigs,'isolated_cargo_configs':isolated_configs,
            'environment_overrides':{k:env[k] for k in ('CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS',
                'CARGO_NET_OFFLINE','CARGO_REGISTRIES_CRATES_IO_PROTOCOL','CARGO_HTTP_TIMEOUT','CARGO_NET_RETRY','PYTHONDONTWRITEBYTECODE','LC_ALL','LANG')},
            'cargo':verifier.identity(cargo),'rustc':verifier.identity(env['RUSTC']),
            'fuzz_manifest_sha256':sha(REPO/'tests/fuzz/Cargo.toml'),'fuzz_lock_sha256':sha(LOCK)})
        guard('initial')
        for suffix in ('.log','.json'):
            p=Path(str(ORIGINAL)+suffix); dest=OUT/'original'/p.name
            shutil.copyfile(p,dest); assert sha(p)==sha(dest)
        assert sha(OUT/'original/23-fuzz-offline-full-metadata.log')=='8f068dfb9df45b7318970cfae8580f44128915c37a260b2d8e37d62c40267f80'
        packages=tomllib.loads(LOCK.read_text())['package']
        registry=[p for p in packages if p.get('source','').startswith('registry+')]
        copied=[]; missing=[]; indexes=[]
        guard('cache-seed-before')
        for p in registry:
            name=p['name']; filename=name+'-'+p['version']+'.crate'
            hits=list(oldhome.glob('registry/cache/*/'+filename))
            if not hits: missing.append({'name':name,'version':p['version'],'checksum':p['checksum']})
            for src in hits:
                assert sha(src)==p['checksum'],'ORIGINAL_ARCHIVE_CHECKSUM:'+filename
                dest=CACHE/src.relative_to(oldhome); dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(src,dest); assert sha(dest)==p['checksum'],'COPIED_ARCHIVE_CHECKSUM:'+filename
                copied.append({'path':str(dest.relative_to(CACHE)),'sha256':sha(dest),'bytes':dest.stat().st_size})
            name=name.lower()
            if len(name)<3: rel=str(len(name))+'/'+name
            elif len(name)==3: rel='3/'+name[0]+'/'+name
            else: rel=name[:2]+'/'+name[2:4]+'/'+name
            for src in oldhome.glob('registry/index/*/.cache/'+rel):
                dest=CACHE/src.relative_to(oldhome); dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(src,dest); assert sha(src)==sha(dest)
                indexes.append({'path':str(dest.relative_to(CACHE)),'sha256':sha(dest)})
        for src in oldhome.glob('registry/index/*/config.json'):
            dest=CACHE/src.relative_to(oldhome); dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src,dest); assert sha(src)==sha(dest)
            indexes.append({'path':str(dest.relative_to(CACHE)),'sha256':sha(dest)})
        guard('cache-seed-after')
        write(OUT/'cache-seed.json',{'locked_registry_packages':len(registry),'copied_archives':copied,
            'copied_sparse_index_files':indexes,'missing_archives_before_network':missing,
            'original_cache_write_operations':0,'shared_symlinks_created':False})
        print(json.dumps({'stage':'cache-seeded','copied_archives':len(copied),'missing':missing}),flush=True)
        online=run('online-locked-full-metadata',False)
        offline=run('offline-locked-full-metadata',True)
        assert canonical(online)==canonical(offline),'ONLINE_OFFLINE_GRAPH_DIFFERENCE'
        bykey={(p['name'],p['version'],p.get('source')):p for p in packages}
        archives=[]
        for p in offline['packages']:
            if not p.get('source'): continue
            lockrow=bykey[p['name'],p['version'],p['source']]
            hits=list(CACHE.glob('registry/cache/*/'+p['name']+'-'+p['version']+'.crate'))
            assert hits,'RESOLVED_ARCHIVE_MISSING'
            for path in hits:
                assert sha(path)==lockrow['checksum'],'RESOLVED_ARCHIVE_CHECKSUM'
                archives.append({'name':p['name'],'version':p['version'],'path':str(path.relative_to(CACHE)),'sha256':sha(path)})
        write(OUT/'resolved-registry-archive-inventory.json',archives)
        result.update(status='PASS',graph_canonical_sha256=hashlib.sha256(canonical(offline)).hexdigest(),
            packages=len(offline['packages']),registry_packages=len(archives),resolve_nodes=len(offline['resolve']['nodes']),
            online_offline_full_metadata_equal=True,source_final=guard('final'),
            all_resolved_archives_match_lockfile_checksums=True,original_main_result_rewritten=False)
    except BaseException as e:
        result.update(status='FAIL',error=repr(e),traceback=traceback.format_exc())
        try: result['source_after_failure']=guard('failure-final')
        except BaseException as ge: result['source_after_failure_error']=repr(ge)
    finally:
        result['completed_utc']=utc(); write(OUT/'result.json',result)
        inventory=[{'path':str(p.relative_to(OUT)),'sha256':sha(p),'bytes':p.stat().st_size}
            for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='artifact-inventory.json']
        write(OUT/'artifact-inventory.json',inventory)
        print(json.dumps({k:result.get(k) for k in ('status','error','graph_canonical_sha256','packages','registry_packages','resolve_nodes','output_directory')}),flush=True)
    return 0 if result['status']=='PASS' else 1
if __name__=='__main__': raise SystemExit(main())
