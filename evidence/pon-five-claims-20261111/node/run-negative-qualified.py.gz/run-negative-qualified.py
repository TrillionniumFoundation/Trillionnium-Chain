import hashlib, json, os, stat, subprocess, sys, time, traceback
from pathlib import Path
repo=Path('/home/qian-qi/work/chain-pon-submit-probe-20261111-d6cb')
artifacts=Path('/home/qian-qi/work/pon-five-claims-w1-artifacts-d6cb')
base='11e242dbaaae14a9d16282fe8deaf36827e98395'
branch='fix/chain-pon-five-claims-before-20261111-d6cb'
manifest=json.loads((artifacts/'draft-manifest.json').read_text())
assert manifest['base']==base and manifest['native_tests_executed'] is False
for item in manifest['files']:
    raw=Path(item['path']).read_bytes()
    assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'], item['path']
assert hashlib.sha256((artifacts/'negative-probe.rs').read_bytes()).hexdigest()=='b6ab023c4ad823674257f7c0e66ba55b99f5234b31e0951457e72c0a383b6d62'
out=artifacts/'before-native-qualified'
out.mkdir(exist_ok=False)
env=os.environ.copy()
toolbin='/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin'
env['PATH']=toolbin+':'+env.get('PATH','')
env['RUSTUP_TOOLCHAIN']='1.95.0'
env['RUSTC']=toolbin+'/rustc'
env['CARGO_TARGET_DIR']='/home/qian-qi/work/chain-pon-submit-target-d6cb'
env['CARGO_BUILD_JOBS']='2'
env['RUST_TEST_THREADS']='1'
env['CARGO_TERM_COLOR']='never'
records=[]
def capture(args):
    return subprocess.run(args,cwd=repo,env=env,check=True,capture_output=True,text=True).stdout.strip()
def run(label,args,check=True,timeout=1800):
    started=time.time()
    with (out/(label+'.stdout.log')).open('wb') as stdout, (out/(label+'.stderr.log')).open('wb') as stderr:
        process=subprocess.run(args,cwd=repo,env=env,stdout=stdout,stderr=stderr,timeout=timeout)
    record={'label':label,'argv':args,'started_unix':started,'finished_unix':time.time(),'exit_code':process.returncode}
    for name in ['stdout','stderr']:
        raw=(out/(label+'.'+name+'.log')).read_bytes()
        record[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    records.append(record)
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if check and process.returncode: raise RuntimeError(label+' failed '+str(process.returncode))
    return process.returncode
def full_source(label):
    head=capture(['git','rev-parse','HEAD'])
    tree=capture(['git','rev-parse','HEAD^{tree}'])
    entries=subprocess.run(['git','ls-tree','-r','--full-tree','-z','HEAD'],cwd=repo,check=True,capture_output=True).stdout.split(b'\0')
    count=total=0
    for entry in entries:
        if not entry: continue
        info,path=entry.split(b'\t',1)
        mode,kind,expected=info.split()
        assert kind==b'blob', 'unexpected nonblob source '+repr(path)
        item=repo/os.fsdecode(path)
        if mode==b'120000':
            raw=os.fsencode(os.readlink(item))
            actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
            size=len(raw)
        else:
            before=item.stat()
            size=before.st_size
            digest=hashlib.sha1(b'blob '+str(size).encode()+b'\0')
            with item.open('rb') as stream:
                while True:
                    chunk=stream.read(1048576)
                    if not chunk: break
                    digest.update(chunk)
            after=item.stat()
            assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns), 'source changed during read '+str(item)
            actual=digest.hexdigest()
        assert actual==expected.decode(), 'tracked source mismatch '+str(item)
        count+=1;total+=size
    assert capture(['git','status','--porcelain'])=='', 'dirty subject'
    result={'head':head,'tree':tree,'tracked_entries_verified':count,'tracked_bytes_verified':total,'full_git_blob_equality':True}
    (out/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    return result
try:
    assert capture(['git','rev-parse','HEAD'])=='e63427560885b65c57db6bdc478df023111b4733'
    assert capture(['git','status','--porcelain'])==''
    run('preflight-before-build',['bash','scripts/project-preflight.sh'])
    before=full_source('source-before')
    run('rustc-version',[toolbin+'/rustc','--version'])
    run('cargo-version',[toolbin+'/cargo','--version'])
    run('metadata',[toolbin+'/cargo','metadata','--manifest-path','trillionnium/Cargo.toml','--locked','--offline','--format-version','1'])
    run('build',[toolbin+'/cargo','test','--manifest-path','trillionnium/Cargo.toml','--release','--locked','--offline','-p','trnm-pon-node','--lib','--no-run','--message-format=json'],timeout=2400)
    candidates=[]
    sqlite_witness=[]
    for line in (out/'build.stdout.log').read_text().splitlines():
        try: item=json.loads(line)
        except json.JSONDecodeError: continue
        if item.get('reason')=='build-script-executed' and 'trnm-sqlite-io-boundary' in item.get('package_id',''):
            sqlite_witness.append(item)
        if item.get('reason')=='compiler-artifact' and item.get('target',{}).get('name')=='trnm_pon_node' and item.get('profile',{}).get('test') and item.get('executable'):
            candidates.append(item['executable'])
    assert len(sqlite_witness)==1 and 'trnm_sqlite_layout_witness' in sqlite_witness[0].get('cfgs',[]), sqlite_witness
    (out/'sqlite-build-script.json').write_text(json.dumps(sqlite_witness[0],indent=2)+'\n')
    assert len(set(candidates))==1, candidates
    binary=Path(candidates[-1])
    binary_before=hashlib.sha256(binary.read_bytes()).hexdigest()
    selector='ingress::submit_activation_history_tests::submit_future_ancestor_is_checked_after_full_work_before_m06'
    code=run('native-probe',[str(binary),'--exact',selector,'--nocapture','--test-threads=1'],check=False,timeout=300)
    stdout=(out/'native-probe.stdout.log').read_text()
    stderr=(out/'native-probe.stderr.log').read_text()
    after=full_source('source-after')
    binary_after=hashlib.sha256(binary.read_bytes()).hexdigest()
    assert before==after and binary_before==binary_after
    expected=code==101 and selector in stdout and 'candidate_durable=true' in stderr and 'left: 1' in stderr and 'right: 0' in stderr
    summary={'schema':'trnm-submit-ancestry-before-qualified-observation-v1','absolute_rustc':env['RUSTC'],'sqlite_layout_witness_cfg_observed':True,'base':base,'source':before,'binary':{'path':str(binary),'sha256_before':binary_before,'sha256_after':binary_after},'selector':selector,'native_exit_code':code,'expected_original_failure_observed':expected,'native_tests_passed':False,'first_case_only_before_assertion':True,'production_qualification':False,'source_after':after,'build_scope':'release default-feature trnm-pon-node library tests','artifacts_directory':str(out)}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)
    print(stdout[-5000:],flush=True)
    print(stderr[-5000:],flush=True)
    if not expected: raise RuntimeError('expected original runtime failure not established')
except BaseException:
    (out/'failure.txt').write_text(traceback.format_exc())
    raise

