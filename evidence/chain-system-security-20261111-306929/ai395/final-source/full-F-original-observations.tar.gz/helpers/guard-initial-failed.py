#!/usr/bin/env python3
"""Validate only the exact external gate driver's new corpus-delta rejection block."""
import ast, copy, hashlib, json, pathlib, types

DRIVER = pathlib.Path("/home/qq/chain-system-security-final-source-gates-v2-20261112-306929.py")
EXPECTED = "6c539b2f83037642a86d9ad9e3348397e99a22e66984f9e6eae01d5ca19de074"
OUTPUT = pathlib.Path("/home/qq/chain-system-security-final-gate-v2-guard-controls-20261112-306929")
raw = DRIVER.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
OUTPUT.mkdir(exist_ok=False)
module = ast.parse(raw, filename=str(DRIVER))
branch = [node for node in ast.walk(module)
          if isinstance(node, ast.If) and ast.unparse(node.test) == 'args.mode == "evidence-child"']
assert len(branch) == 1
nodes = branch[0].body
def assigns(node, name):
    return isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets)
start = next(i for i,n in enumerate(nodes) if assigns(n, "old_corpus"))
end = next(i for i,n in enumerate(nodes) if assigns(n, "corpus_review"))
block = ast.Module(body=copy.deepcopy(nodes[start:end + 1]), type_ignores=[])
ast.fix_missing_locations(block)
compiled = compile(block, str(DRIVER) + ":corpus-delta", "exec")
PARENT, CHILD = "f" * 40, "e" * 40
CORPUS = "config/pon/pq-cross-branch-corpus-v1.json"
README = "evidence/chain-system-security-20261111-306929/README.md"
ADDED = "evidence/chain-system-security-20261111-306929/final-source/summary.json"
UNRELATED = "evidence/historical-unrelated/README.md"
UNLISTED = "evidence/historical-unrelated/other.json"
old = {"version": 1, "reader_limit": 4194304, "policy": {"activation": False},
       "pinned_blobs": {README: "1" * 40, UNRELATED: "2" * 40},
       "required_paths": [README, UNRELATED]}
new = copy.deepcopy(old)
new["pinned_blobs"].update({README: "3" * 40, ADDED: "4" * 40})
new["required_paths"].append(ADDED)
changes = [{"status": "M", "path": README}, {"status": "A", "path": ADDED}]
blobs = {README: "3" * 40, ADDED: "4" * 40}
def require(condition, message):
    if not condition:
        raise ValueError(message)
def run_case(name, mutate, expected):
    prior, current, actual, actual_blobs = copy.deepcopy(old), copy.deepcopy(new), copy.deepcopy(changes), dict(blobs)
    types_by_oid = {oid: "blob" for oid in actual_blobs.values()}
    mutate(prior, current, actual, actual_blobs, types_by_oid)
    calls = []
    def git(*argv):
        calls.append(list(argv))
        if argv == ("show", PARENT + ":" + CORPUS):
            return json.dumps(prior).encode()
        if argv == ("show", CHILD + ":" + CORPUS):
            return json.dumps(current).encode()
        if argv[0] == "rev-parse":
            prefix = CHILD + ":"
            assert argv[1].startswith(prefix)
            return (actual_blobs[argv[1][len(prefix):]] + "\n").encode()
        if argv[0] == "cat-file" and argv[1] == "-t":
            return (types_by_oid[argv[2]] + "\n").encode()
        raise AssertionError("unexpected isolated Git call: " + repr(argv))
    scope = {"args": types.SimpleNamespace(parent=PARENT, head=CHILD),
             "CORPUS": CORPUS, "json": json, "git": git, "changes": actual, "require": require}
    try:
        exec(compiled, scope)
    except ValueError as error:
        assert expected is not None and expected in str(error), (name, expected, str(error))
        return {"name": name, "expected": "rejection", "actual": "rejected",
                "error": str(error), "passed": True, "mock_git_calls": calls}
    assert expected is None, (name, "unexpected acceptance")
    review = scope["corpus_review"]
    assert review["non_pin_and_required_fields_equal"]
    assert review["existing_pins_preserved"] and review["existing_required_paths_preserved"]
    assert len(review["reviewed_actual_file_pins"]) == 2
    assert review["added_required_paths"] == [ADDED]
    return {"name": name, "expected": "acceptance", "actual": "accepted",
            "passed": True, "review": review, "mock_git_calls": calls}
cases = [
 ("reviewed_addition_and_existing_evidence_update", lambda p,n,c,b,t: None, None),
 ("unrelated_existing_pin_changed", lambda p,n,c,b,t: n["pinned_blobs"].__setitem__(UNRELATED, "9"*40), "pins outside actual"),
 ("prior_pin_removed", lambda p,n,c,b,t: n["pinned_blobs"].pop(UNRELATED), "removed existing corpus pins"),
 ("prior_required_path_removed", lambda p,n,c,b,t: n["required_paths"].remove(UNRELATED), "removed required paths"),
 ("reader_cap_changed", lambda p,n,c,b,t: n.__setitem__("reader_limit", 8388608), "policy or reader fields"),
 ("activation_policy_changed", lambda p,n,c,b,t: n["policy"].__setitem__("activation", True), "policy or reader fields"),
 ("pin_added_without_file_change", lambda p,n,c,b,t: n["pinned_blobs"].__setitem__(UNLISTED, "9"*40), "pins outside actual"),
 ("required_path_added_without_file_change", lambda p,n,c,b,t: n["required_paths"].append(UNLISTED), "required paths outside actual"),
 ("new_file_missing_pin", lambda p,n,c,b,t: n["pinned_blobs"].pop(ADDED), "lacks an actual changed file/pin"),
 ("new_file_missing_required_path", lambda p,n,c,b,t: n["required_paths"].remove(ADDED), "new evidence file is not registered"),
 ("changed_pin_wrong_actual_blob", lambda p,n,c,b,t: n["pinned_blobs"].__setitem__(README, "8"*40), "differs from actual child Git blob"),
 ("pin_targets_non_blob_object", lambda p,n,c,b,t: t.__setitem__("4"*40, "tree"), "pin is not a file blob"),
 ("duplicate_required_path", lambda p,n,c,b,t: n["required_paths"].append(README), "invalid corpus required path set"),
 ("pin_container_type_changed", lambda p,n,c,b,t: n.__setitem__("pinned_blobs", []), "containers changed type"),
]
observations = [run_case(*case) for case in cases]
report = {"schema": "trnm-external-source-gate-corpus-delta-controls-v1",
          "driver": str(DRIVER), "driver_sha256": EXPECTED, "driver_bytes": len(raw),
          "tested_block": "unchanged AST statements old_corpus through corpus_review inclusive",
          "source_ast_lines": [nodes[start].lineno, nodes[end].end_lineno],
          "cases": observations, "all_passed": all(r["passed"] for r in observations),
          "positive_cases": 1, "negative_cases": len(observations) - 1,
          "shared_repository_read": False, "shared_repository_changed": False,
          "git_calls_mocked": True, "repository_108_controls_executed": False,
          "native_commands_executed": False}
with (OUTPUT / "controls.json").open("x") as stream:
    json.dump(report, stream, indent=2); stream.write("\n")
print(json.dumps({key: value for key, value in report.items() if key != "cases"}))
