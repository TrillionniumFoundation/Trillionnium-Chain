from pathlib import Path
import os,sys,json,time,resource,subprocess,hashlib,re,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'new-w1-delay-validation-78';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);env=os.environ.copy();env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];env['CARGO_TARGET_DIR']=str(src.parent/'target');env['RUST_TEST_THREADS']='1';env['TRNM_CI_RECEIPT_DIR']=str(out/'receipts');env['TRNM_PUBLIC_V3_CAMPAIGN_DIR']=str(out/'mixed-service-campaign');res={'schema':'chain-new-native-w1-delay-original-controls-v1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'source_diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src)).hexdigest(),'complete':False,'commands':[],'original_limits_unchanged':True}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args,required=False):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=src,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);r={'name':name,'argv':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};log=(out/(name+'.stdout')).read_text(errors='replace');r['libtest_summaries']=re.findall(r'test result: .*',log);res['commands'].append(r);save();print(json.dumps(r),flush=True)
 if rc!=0:print((out/(name+'.stderr')).read_text(errors='replace')[-5000:],flush=True)
 assert rc==0,r
 if required:assert re.search(r'test result: ok\. [1-9][0-9]* passed;',log),r
try:
 assert res['source_diff_sha256']=='f268c67c8c005505c8461700d06da23df8f840dc7f0e9cefac730a57e18d0e56';save();run('preflight',['bash','scripts/project-preflight.sh']);base=['cargo','test','--release','--locked','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node']
 for name,selector in [('w1-rejection','ingress::public_v3::work_rejection::tests::'),('body-refusal','ingress::public_v3::body_refusal::tests::'),('native-root-delay','ingress::public_v3::native_root_delay_tests::')]:
  run(name,base+['--lib',selector,'--','--test-threads=1','--nocapture'],True)
 run('original-mixed-130',base+['--test','public_v3_service_campaign','public_v3_mixed_calls_reopen_with_complete_failure_denominators','--','--exact','--test-threads=1','--nocapture'],True)
 p=out/'mixed-service-campaign/report.json';raw=p.read_bytes();report=json.loads(raw);res['mixed_report']={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'attempts':len(report['attempts']),'finite_target_met':report['finite_target_met'],'gap_ns':report['honest_probe_max_gap_including_restart_ns'],'phases':[{k:v for k,v in x.items() if k not in ('false_transcript_fixture','owner','producer','server_metrics')} for x in report['phases']]};res['complete']=True;save();print(json.dumps(res['mixed_report']),flush=True)
except BaseException as e:
 res['error']=repr(e);res['complete']=True;save();(out/'owner.error').write_text(traceback.format_exc());raise
