# C1 hosted CI readback and durable-schema gate diagnosis

This directory retains one initial GitHub run/jobs readback, followed by targeted completed-job logs and the failed CodeQL export artifact. No rerun or remote mutation was triggered. All proposed changes are outside the frozen candidate checkout.

## Source identities

- C1 PR head: `c09dbbe9921da12db8bf7240a8a95a0e9a789e50`.
- PR base: `31543fb6dde565b62b47436e0b1d399b6d0bd772`.
- Prospective merge: `61589dddd13e7495369aaecad9212668049417c1`, with ordered parents `[base, head]`.
- Both head and prospective merge have tree `f15a7ee4a0f5455eaf965db01dcd49e02a5f22b6`. Their source kinds and commit identities remain distinct.

The QROM head/merge logs and CodeQL Actions head/merge logs each contain matching before/after source records, 27,912 tracked entries and 2,554,106,689 tracked bytes. The external-evidence-contract failure and CodeQL export likewise retain successful C1 source checks before and after execution. See [readback-summary.json](readback-summary.json) for extracted records and log locations.

## Acceptance state in this readback

| Run | Observed state | Scope |
| --- | --- | --- |
| [QROM implementation 42955582962](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42955582962) | Success | Head job 130309764072 and prospective-merge job 130309764460 both completed. Each log contains the exact 103 successful named IDs: original 81, historical 8, current 14. The retained log IDs were independently matched to the C1 fixed rosters. |
| [Local CodeQL SARIF 42955582992](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42955582992) | In progress | Actions and Python succeeded for both source kinds. Rust head and prospective merge were still generating SARIF. No completed six-cell result or zero-alert conclusion is claimed. |
| [CodeQL API export 42955582970](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42955582970) | Failure | Export reached its deadline. The original artifact contains 39 API polls; all analysis lists and filtered `CodeQL` check lists for both source kinds are empty. There are 38 waiting messages and a final 39th poll. Source checks and failure-artifact upload succeeded. |
| [Required baseline 42955583052](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42955583052) | Incomplete, with observed failures | Run metadata still says `queued`, while its latest job list includes completed, failed, active and queued jobs. Preserve both observations; do not collapse this to a successful or wholly unstarted run. |

The CodeQL API check query uses `check_name=CodeQL&filter=latest`; empty filtered responses do not imply that other Actions checks are absent. Local SARIF retention and API-export acceptance are separate observations. The conditional failure-diagnostics upload step being skipped in successful local SARIF jobs is not a skipped analysis step.

The failed export ZIP is [c1-codeql-export-42955582970.zip](c1-codeql-export-42955582970.zip), artifact ID `13828664132`, 208,483 bytes, SHA256 `3c6df0231bc96cd417bf3c482b714e5178f5350eaca4f446f60bc7ff28756fbc`. The GitHub artifact digest matches the downloaded bytes; all 203 top-level manifest entries and 199 nested analysis-manifest entries were checked. Original result/source metadata is also copied byte-for-byte into `export-selected/`. No current default-setup configuration was inferred from this artifact.

## Newly localized source contract failure

The C1 head `external-evidence-contract` job **130309764822** failed in `python3 scripts/ci/test_public_readiness_evidence.py`: 71 outer tests, 46 failing subcases and 22 errors. The earliest shared error is `ValueError: durable backend selected implementation` from `native_durable_schema()`.

The checker and its test file are byte-identical to parent 315. At `scripts/ci/check_public_readiness_evidence.py` lines 497–502, `reviewed_bodies['observation_only']` still binds the parent's complete `open_selected_mode` body. C1 `store.rs` added the account-profile refusal before native namespace effects. The only body difference is two explanatory comment lines and `settings.app.check_account_profile()?;`.

| Exact complete body | Bytes | SHA256 |
| --- | ---: | --- |
| Parent 315 | 20,288 | `088b58a4072271bb60772bfacab6cf06ec4052700cef46f92708453d8b9a07be` |
| C1 with the new refusal | 20,493 | `e89baea593c5a31e16760c3ad42854d9112775b2e51a8994262f06eee379f1d3` |

This rejects the real C1 positive control early and masks later negative controls. The original reader accepts the current-source fixture with those three new lines removed, because that recreates the previously pinned body. The proposed reader binds only the reviewed C1 body for this current contract; it does not add an old-body fallback.

The [two-file proposed patch](durable-schema-review/durable-schema-c1-proposed.patch) updates that exact digest and extends the existing executable-contract test with four source mutations: guard rollback, comment-only guard, ignored refusal and refusal moved after `create_dir_all`. No Rust source, schema/domain, historical dispatcher or qualification flag changes are proposed. The historical CLI continues to execute the checker from the measured historical checkout.

The repo-external [proposal validation](durable-schema-review/proposal-validation.json) records five before/after cases and three successful existing named tests. They verify the exact preserved DDL, executable-contract negative controls and real SQLite complete-index positive control. The accepted current result remains 5,404 DDL bytes in `native-branch-schema-v2`. [targeted-tests.log](durable-schema-review/targeted-tests.log) retains the actual output. This is not a full 71-test or hosted rerun result.

Both changed Python paths are pinned in `config/pon/pq-cross-branch-corpus-v1.json`. A later implementation commit must update their two blob pins and pass the 71-test suite and the integration checks. Because that corpus JSON is embedded through `distributed_source_inventory.rs`, this is no longer an evidence-only change: retain C1 native results as C1 results and revalidate the affected Node library tests and Clippy for the new commit. No such future result is inferred here.

## Other retained failures and limits

Cross-architecture native-from-zero jobs **130309764639 (arm64)** and **130309764652 (x64)** failed their original service controls after successful build preparation. Their complete decoded logs are under `logs/`; classification was delegated to the agent handling the original campaign. Their failures are not reclassified as build failures or repaired by this proposed reader change.

GitHub job/artifact wrapper responses are latest-attempt, first-page observations. Status reads are not atomic. The JSON files retain those responses; `transport/` preserves the connector's exact decoded log string, and `logs/` contains the same UTF-8 strings for inspection. These are not claims about original server-side compressed log bytes. Original artifact bytes, by contrast, are retained as the ZIP and checked against the API digest.

Whole-chain post-quantum qualification, production activation and complete required-baseline acceptance are not established by these observations.
