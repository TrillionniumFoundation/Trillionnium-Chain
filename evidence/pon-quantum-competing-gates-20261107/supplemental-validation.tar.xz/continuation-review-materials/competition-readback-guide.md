# 原生 continuing-competition 证据读取表

此表对应实现提交 `a56889a54aac5f14141bb45fb602141dd6a37645`，tree `b4e64c82d2646b9f32124feb510edc3349a375d0`。这是字段/语义审阅结果，不是尚未完成的原生运行结果。

## 先确认运行和输入身份

1. 显式 test ELF 的正常退出，以及 `check_required_native_test.py` 对 `quantum_native_bridge_tests::competition::replay_source_bound_native_competition_samples` 输出 `result: PASS, executed_tests: 1`。该检查器只证明日志中的指定 libtest 执行，不独立认证日志或替代原生断言。
2. `native-competition-replay.json.schema == trnm-w1-native-competition-replay-v1`；`native_source.git_head` 必须是上面的冻结提交。保留整个 `native_source.source_sha256`、构建 executable 哈希和实际进程记录。
3. `native-competition-replay.json.verified_inputs` 与 `independent_python_verifier.verified_inputs` 应一致，恰好绑定以下五个原始文件的 SHA256：`native-fixture.json`、`native-competition-plan.json`、`native-competition-fixture.json`、`competition-certificates.json`、`competition-samples.json`。
4. `native-competition-pre-replay-python.stdout` 是原生 replay 调用独立 Python checker 的原始回执；其 stdout/stderr 哈希保存在原生最终 JSON。回执还保留 `verified_payloads`，绑定所消费的 packet 和 honest fixture ledger。
5. `native-competition-replay.json` 只在全部 run、重开检查、输入与源码最终复查之后以新文件形式写出。文件缺失、test 失败或不完整 JSON 必须保留为失败/未完成，不从仅存在的 fixture 或 Python samples 推断 native 成功。

## 最重要的结果字段

| 问题 | 权威读取位置 | 含义与报告边界 |
| --- | --- | --- |
| 是否曾短暂替换公共分支 | `native-competition-replay.json.runs[].ever_private_replacement` | 原生逐次 admission/activation 累计得到；与私有分支最后是否仍占优不同。 |
| 截止 4 秒私有分支是否仍 active | `runs[].private_active_at_horizon` | 所有声明 honest arrivals 都完成后检查；不能用短暂替换替代该指标。 |
| 最后选中的实际 tip/work | `runs[].receiver_admissions[-1].selected_tip`、`.selected_chainwork_hex`，并与 `runs[].after.chainwork_hex` 对照 | work 是 64 字节大端十六进制，可用 `int(hex,16)` 精确转换。保留完整 block ID。 |
| 逐次诚实/私有到达的顺序 | `runs[].receiver_admissions[].expected_event` | 包含 `owner, at_seconds, block_id, parent_id, height, block_chainwork_hex, selected_tip_before, selected_tip, selected_chainwork_hex, selection_changed, private_replacement`。实际 selected/work 也在 admission 回执外层独立保留。 |
| 是否真实通过 Node 接受 | 每条 admission 的 `native_library_admitted` | 原生代码实际执行完整 proof verifier、`Node::admit`、`activate_observed`，逐步比较 tip/work。Python 的 `native_blocks_admitted_by_python_reader` 必须仍为 0。 |
| 重开是否一致 | `runs[].authenticated_reopen_equal`；顶层 `claims.authenticated_reopens_equal` | 比较 active state、stats，以及每个已经提交的 packet 字节摘要。 |
| 是否包含持续到达 | `runs[].honest_production` 长度；`receiver_admissions` 中 owner=honest 的条目 | 本轮每 run 有两个诚实后继块，即使私有 miner 已停止或发布；诚实 producer 的视图在 horizon 前与私有广播隔离。 |

`at_seconds` 是精确有理数；原生 `logical_observed_now` 是 `CLOCK_ORIGIN + floor(at_seconds)`，供整数时间戳的原生 admission 使用。两者不能混写成实际网络墙钟测量。相同逻辑时刻诚实块先入站，分支内父先子后；累计工作相等时保持当前 active tip。观察具体边界时应展示同一 run 的完整逐次事件，而不只展示最终布尔值。

## 随机样本与观察者选路必须分开

从 `competition-samples.json.runs[]` 与 native `runs[]` 按完整 `name` 一一关联，同时读取 `scenario_id, execution_kind, observation_kind`。

- `fixed-seed-conditional-competition-sample`：固定 seed=9 的声明策略样本；`raw_observation.seed`、`.iterations` 和 trajectory 中已观察 nonce 应保留。共有六个声明的 seeded runs；实际总 run 数还包括存在的 observer controls。
- `observer-selected-classical-path-control-not-random-sample`：观察者从 census 中选出的路径控制。可说明“存在且原生接受的声明路径”，不能说明随机命中率或一次真实采样成功。
- `competition-samples.json.observer_controls` 区分 `RETAINED` 与 `NO_PROOF_COMPLETE_SELECTED_PATH`。不要把控制不存在解释为原生系统安全证明。
- `competition-samples.json.runs[].publication_complete` 与 `packets_to_submit` 决定原生是否允许发布。私有 producer 的候选 proof 存在或通过检查，本身不授权 receiver admission。

## 已支付、未完成与诚实生产成本

| 账本 | 字段 | 正确用法 |
| --- | --- | --- |
| 私有建模动作 | `competition-samples.json.runs[].raw_observation.trajectory[].edge.observation.phases[]` | 每项 `phase, planned, paid, complete`；保留截止时部分支付的初始化等阶段。计划耗时与实际支付分别显示，不替换预算或忽略 censor。 |
| 私有已完成候选检查 | native `runs[].candidate_probes[]` | 包含 `native_winner, native_verifier_error, nonce, context_id, candidate_block_id, proof_sha256, packet_sha256`；Target miss 仍重做完整 native proof。只有 modeled candidate check 完成后才有该 probe。 |
| 私有 CPU 重演时间 | probe 的 `actual_prepare_elapsed_ns, actual_proof_elapsed_ns, actual_candidate_verification_elapsed_ns, actual_private_admission_elapsed_ns` | 是离线 CPU 实测，不可替换模型的量子搜索/初始化时钟；相关 calibration 字段保持 false。 |
| 未发布合法私有 proof | `private_proofs_held, private_proofs_not_published` | 独立于是否 receiver 接受、是否形成替换。 |
| 新鲜诚实生产 | native `runs[].honest_production[]` | 每个高度的 `attempts` 保留全部 misses 与首个 winner；逐项 `proof_elapsed_ns, verification_elapsed_ns`，另有 prepare、admit/activate。 |
| 诚实完整 pipeline | `honest_production[].complete_pipeline_elapsed_ns` | 包含 prepare 至 admission 和 ledger append/fsync；组件时间是子集，不要与 pipeline 再相加。明确排除之后的 readback/digest、元数据序列化和前置历史加载。 |
| 诚实失败防丢账 | `ledger_file, ledger_bytes, ledger_sha256` 和对应 `honest-production-run-*-h17/h18.jsonl` | 原生逐尝试 append + fsync；全部文件应保留。4096 次上限耗尽会保留 `exhausted` 事件并失败，不能补写成功。 |
| 三节点前置历史 | `receiver_history_replay_elapsed_ns, private_history_replay_elapsed_ns, honest_history_replay_elapsed_ns` | 单独保留外部预存公共历史的加载成本，不伪装成四秒私有计费的一部分。 |
| export 的诚实成本 | `native-competition-fixture.json.honest_production[]` | 是生成 fixture 的独立观察；与每 run 新鲜重演成本分开，不能累计后称单次在线竞争费用。 |

量子默认示例若仍止于初始化，应报告 trajectory 的未完成阶段、已支付时间和零完整候选检查；同时明确 receiver 的诚实 CPU 分支仍按条件日程执行。不得将诚实节点 CPU 生产成功表述为量子矿工完成。

## 概率和共识边界

读取 `competition-certificates.json.certificates`，键为 `{scenario_id}/{execution_kind}/{risk_event}`，两个风险事件严格区分：`ever-private-replacement`、`private-active-at-horizon`。

- 先看每张证书的 `status == COMPLETE` 与 `finite_model_certificate_complete == true`。若 INCOMPLETE，则 `risk_upper, fixed_policy_risks, conditional_machine_risk_bounds` 必须为 null，不能报告界。
- `risk_upper` 是声明有限动作集合上的 census 与完整未来诚实日程已知的最优条件包络；不能当作不知道未来的可实现矿工策略的实测命中率。
- `fixed_policy_risks` 是各 q 固定策略的精确理想概率。它与 seed=9 的单一路径输出分开。
- `conditional_machine_risk_bounds.failure_union_upper`、`.census_advised_action_envelope`、`.fixed_q_policies` 仅给出私有机器故障的条件扰动界。必须一并保留 `external_honest_and_receiver_trajectory_is_exact_condition: true` 和 `honest_production_receiver_or_network_failures_bounded: false`。
- `competition-samples.json.risk_summaries` 是上述字段的便捷取读视图，不能替代完整证书及其独立 checker。
- 顶层原生 claims 应继续保留 `real_time_search_budget_verified:false, conditional_receiver_schedule_only:true, public_ingress_executed:false, stochastic_continuing_honest_mining_covered:false, quantum_hardware_executed:false, quantum_mining_qualified:false, production_activation:false`。

因此可报告的是：在冻结源码、指定完整候选、声明诚实日程与成本前提下，原生 Node 对所有逐步入站事件给出了可核对的接受、选链与重开结果。任意量子算法、诚实网络随机过程、任意时间戳策略、长期 DAA 和结算安全仍不由该实验覆盖。
