import concurrent.futures
import hashlib
import json
import re
import shlex
import subprocess
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/1790ff0f3cc3/chain')
OUT = Path('/workspace/scratch/1790ff0f3cc3/work/final-composition/ci')
WORK = OUT.parent
EXPECTED = 'cb8ed84404977320fdb09d75284f99149654107d'
TREE = 'f436619ccda70416e6f60ece3316eeab57aa4d48'
OWN = '413084b29b30ebbf1e7a1e97643b743ec5a751c8'
REMOTE = '657bf2a462ff13a6101ebcb4fbe0fb91c515c972'
BASE = 'dda4cc47362065819e9591f11f713933e7a853bf'
MANIFEST = 'config/pon/pq-cross-branch-corpus-v1.json'
INVENTORY = 'trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs'


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT, text=True).strip()


def identity():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status_porcelain': git('status', '--porcelain=v1', '--untracked-files=all')}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def blobs(commit):
    data = subprocess.check_output(['git', '--no-replace-objects', 'ls-tree', '-rz', commit], cwd=ROOT)
    return {path.decode(): info.split()[2].decode() for entry in data.split(b'\0') if entry
            for info, path in [entry.split(b'\t', 1)]}


initial = identity()
assert initial == {'head': EXPECTED, 'tree': TREE, 'status_porcelain': ''}, initial
parents = git('show', '-s', '--format=%P', EXPECTED).split()
assert parents == [REMOTE, OWN], parents
pins_before = json.loads((WORK / 'pins-before-repair.json').read_text())
old_raw = subprocess.check_output(['git', '--no-replace-objects', 'show', OWN + ':' + MANIFEST], cwd=ROOT)
new_raw = (ROOT / MANIFEST).read_bytes()
old = json.loads(old_raw)
new = json.loads(new_raw)
current_blobs = blobs(EXPECTED)
remote_blobs = blobs(REMOTE)
remote_changed = git('diff', '--name-only', BASE, REMOTE).splitlines()
assert len(remote_changed) == 16
assert len(pins_before) == 9
replaced = old_raw
mapping = []
for item in pins_before:
    path = item['path']
    assert path in remote_changed
    assert old['pinned_blobs'][path] == item['old']
    assert new['pinned_blobs'][path] == item['actual'] == current_blobs[path]
    assert item['remote_blob'] == remote_blobs[path]
    assert replaced.count(item['old'].encode()) == 1
    replaced = replaced.replace(item['old'].encode(), item['actual'].encode())
    if path == INVENTORY:
        assert item['actual'] != item['remote_blob']
        correspondence = 'Combined regenerated inventory; differs from both parents; independently checked by --check'
    else:
        assert item['actual'] == item['remote_blob']
        correspondence = 'Exact blob from remote 657 change relative to explicit base dda4'
    mapping.append({**item, 'correspondence': correspondence})
assert replaced == new_raw, 'Registry must contain exactly nine original value replacements'
all_mismatches = [{'path': path, 'pinned': blob, 'actual': current_blobs.get(path)}
                  for path, blob in new['pinned_blobs'].items() if current_blobs.get(path) != blob]
assert all_mismatches == [], all_mismatches
assert len(new['pinned_blobs']) == len(old['pinned_blobs']) == 490
assert new['pinned_blobs']['scripts/ci/ci_job.sh'] == old['pinned_blobs']['scripts/ci/ci_job.sh'] == current_blobs['scripts/ci/ci_job.sh']
original = json.loads((WORK / 'pq-before.json').read_text())
assert original['exit_code'] == 1
original_files = [{'path': str(WORK / name), 'sha256': digest(WORK / name)}
                  for name in ('pins-before-repair.json', 'pq-before.json', 'pq-before.stderr', 'pq-before.stdout')]
pin_audit = {'source_commit': EXPECTED, 'source_tree': TREE, 'parents': parents,
             'explicit_composition_base': BASE, 'pinned_blobs_checked': 490,
             'remaining_pin_mismatches': all_mismatches, 'pin_updates': mapping,
             'exact_remote_changed_blobs': 8, 'combined_inventory_updates': 1,
             'unchanged_ci_job_pin': new['pinned_blobs']['scripts/ci/ci_job.sh'],
             'only_nine_original_pin_value_byte_replacements': True,
             'other_manifest_fields_unchanged': True,
             'remote_changed_paths': remote_changed, 'original_failure_files': original_files,
             'original_failure_uncommitted_tree': original['uncommitted_combination_tree']}
(OUT / 'pin-audit.json').write_text(json.dumps(pin_audit, indent=2) + '\n')
(OUT / 'registry-nine-field.diff').write_text(subprocess.check_output(
    ['git', '--no-replace-objects', 'diff', '--no-ext-diff', '--unified=3', OWN, EXPECTED, '--', MANIFEST], cwd=ROOT, text=True))


def run(label, command):
    before = identity()
    assert before == initial, before
    path = OUT / (label + '.log')
    assert not path.exists(), path
    start = time.monotonic()
    with path.open('x') as stream:
        try:
            result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=600)
            exit_code = result.returncode
            timed_out = False
        except subprocess.TimeoutExpired:
            exit_code = None
            timed_out = True
    elapsed = time.monotonic() - start
    after = identity()
    counts = re.findall(r'Ran (\d+) tests? in ', path.read_text())
    record = {'label': label, 'command': command, 'command_text': shlex.join(command),
              'cwd': str(ROOT), 'exit_code': exit_code, 'timed_out': timed_out, 'wall_seconds': elapsed,
              'source_before': before, 'source_after': after, 'source_unchanged': before == after,
              'reported_unittest_count': int(counts[-1]) if counts else None,
              'log_path': str(path), 'log_sha256': digest(path), 'log_bytes': path.stat().st_size,
              'passed': exit_code == 0 and not timed_out and before == after}
    (OUT / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: record[key] for key in ('label', 'exit_code', 'reported_unittest_count', 'source_unchanged', 'wall_seconds', 'passed')}), flush=True)
    print('\n'.join(path.read_text().splitlines()[-4:]), flush=True)
    return record


records = [run('source-before', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', EXPECTED, '--output', str(OUT / 'source-before-identity.json')])]
records.append(run('preflight', ['bash', 'scripts/project-preflight.sh', '--audit']))
assert all(item['passed'] for item in records), 'Refuse controls without exact source/preflight'
control_commands = [
    ('phase-reader', ['python3', '-B', 'scripts/ci/test_pon_public_v3_phase_read.py', '-v']),
    ('ci-contract', ['python3', '-B', 'scripts/ci/test_ci_contract.py', '-v']),
    ('pq-integration-tests', ['python3', '-B', 'scripts/ci/test_pq_research_integration.py', '-v']),
    ('pq-integration', ['python3', '-B', 'scripts/ci/check_pq_research_integration.py']),
    ('inventory', ['python3', '-B', 'scripts/refresh_distributed_source_inventory.py', '--check']),
]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    futures = [pool.submit(run, label, command) for label, command in control_commands]
    records.extend(future.result() for future in futures)
records.append(run('source-after', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', EXPECTED, '--output', str(OUT / 'source-after-identity.json')]))
final = identity()
source_before = json.loads((OUT / 'source-before-identity.json').read_text())
source_after = json.loads((OUT / 'source-after-identity.json').read_text())
summary = {
    'schema': 'trnm-final-composition-ci-controls-v1',
    'source_commit': EXPECTED, 'source_tree': TREE, 'parents': parents,
    'all_checks_passed': all(item['passed'] for item in records) and final == initial and source_before == source_after,
    'source_before': source_before, 'source_after': source_after,
    'initial_git_identity': initial, 'final_git_identity': final,
    'commands': records,
    'reported_unit_counts': {item['label']: item['reported_unittest_count'] for item in records if item['reported_unittest_count'] is not None},
    'pin_audit_path': str(OUT / 'pin-audit.json'), 'pin_audit_sha256': digest(OUT / 'pin-audit.json'),
    'exact_pin_updates': mapping, 'all_pinned_blobs_match': True,
    'diff_path': str(OUT / 'registry-nine-field.diff'), 'diff_sha256': digest(OUT / 'registry-nine-field.diff'),
    'original_failure_reference': original_files,
    'scope': 'Frozen cb8 source identity, phase reader/CI contract/PQ research registration Python controls and generated inventory only; no native or business acceptance.',
    'native_tests_run': False, 'business_acceptance_claimed': False, 'activation_claimed': False,
    'closure_scope': 'HOLD', 'tracked_files_modified_by_controls': False,
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'summary': str(OUT / 'summary.json'), 'all_checks_passed': summary['all_checks_passed'], 'reported_unit_counts': summary['reported_unit_counts'], 'source_commit': EXPECTED, 'source_tree': TREE}), flush=True)
raise SystemExit(0 if summary['all_checks_passed'] else 1)
