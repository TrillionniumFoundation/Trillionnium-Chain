import pathlib,json,hashlib,subprocess,os,sys,re,collections,zipfile,datetime
D=pathlib.Path("/private/tmp/chain-audit-20261114-branch-graph/final-object-delta-review-v1")
OUT=D/"delivery-v2";OUT.mkdir(exist_ok=False)
G="/private/tmp/chain-audit-recovery-records-20261113/full-history-independent-v1/complete.git"
env={**os.environ,"GIT_NO_LAZY_FETCH":"1","GIT_OPTIONAL_LOCKS":"0","GIT_TERMINAL_PROMPT":"0"}
def sha(b):return hashlib.sha256(b).hexdigest()
def readjson(p):return json.loads(p.read_text())
def write(p,value):
 with p.open("x") as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write("\n")
def git(*args):
 p=subprocess.run(["/usr/bin/git","--git-dir="+G,*args],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 p.check_returncode();return p.stdout
assert (D/"stable-recheck-driver.py").read_text()==sys.argv[1]
(D/"custody_driver_v2.py").write_text(sys.argv[3])
assert readjson(D/"pty-terminal-receipts.json")==json.loads(sys.argv[2])
write(D/"packaging-attempt-v1-terminal.json",json.loads(sys.argv[4]))
first=readjson(D/"run-v1/summary.json");stable=readjson(D/"stable-recheck-v1/summary.json")
assert first["new_objects"]["new_blob_count"]==411 and stable["exit_code"]==0 and stable["refs_unchanged"]
log=(D/"stable-recheck-v1/git-fsck.log").read_text().splitlines()
assert all(re.fullmatch(r"dangling (?:tree|blob|commit) [a-f0-9]{40}",line) for line in log)
triage=readjson(D/"stable-recheck-v1/missing-oid-triage.json")
root="96643a2dd8a90cded0059216cae15e2cd620c77b"
root_tree=git("rev-parse",root+"^{tree}").decode().strip()
wanted={r["oid"] for r in triage["rows"]}
hits={}
raw=git("ls-tree","-r","-t","--full-tree","--format=%(objectname) %(objecttype) %(path)",root)
for line in raw.decode().splitlines():
 oid,typ,path=line.split(" ",2)
 if oid in wanted:hits.setdefault(oid,[]).append({"path":path,"type":typ})
hits.setdefault(root_tree,[{"path":".","type":"tree"}])
assert set(hits)==wanted,{"unmapped":sorted(wanted-set(hits)),"extra":sorted(set(hits)-wanted)}
write(D/"stable-recheck-v1/missing-objects-current-merge-membership.json",{"commit":root,"tree":root_tree,"all_ten_missing_objects_reachable_from_exact_merge_tree":True,"memberships":hits,"read_only":True})
patterns=readjson(D/"run-v1/patterns-and-scope.json")
compiled={p["id"]:re.compile(p["bytes_regex_ascii"].encode()) for p in patterns["patterns"]}
extra=[]
for row in triage["rows"]:
 if row["reported_missing_type"]!="blob":continue
 oid=row["oid"];data=git("cat-file","blob",oid)
 assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==oid
 counts={name:sum(1 for _ in pat.finditer(data)) for name,pat in compiled.items()}
 extra.append({"oid":oid,"bytes":len(data),"sha256":sha(data),"paths_at_merge":hits[oid],"content_address_verified":True,"raw_bytes_scanned":len(data),"match_counts":counts,"credential_values_disclosed":False})
assert len(extra)==2
write(D/"stable-recheck-v1/post-enumeration-merge-two-blob-scan.json",{"schema":"explicit-two-post-enumeration-merge-blob-scan-v1","commit":root,"tree":root_tree,"reason":"These two immutable merge blobs were reported missing during the non-atomic first fsck and created after the frozen initial scan enumeration. They are now separately named and scanned, not silently added to initial 411-blob scope.","pattern_definitions_sha256":sha((D/"run-v1/patterns-and-scope.json").read_bytes()),"blobs":extra,"all_secret_types_excluded":False,"recursive_archive_decompression":False,"scan_includes_later_report_or_archive_objects":False})
baseline_dir=pathlib.Path("/private/tmp/chain-consolidation-20261114-root/all-object-secret-inventory-v1")
copies=D/"original-baseline-receipts";copies.mkdir()
expect={
"object-inventory.txt":"ec74ecf3a402fdc790d4649a2829e7f4995b724ad157b849e73d4ff94aab0648",
"summary.json":"5a98080e9e29d74e300b6e4ba77cf923605df1a51d46405faa9a19c339d6e365",
"private-marker-triage-v1.json":"c0f6f15654a9fd150e8d104e975f65c9de3113e53f2876f0a9b34d2f3f8243d3",
"git-fsck-summary.json":"a8becd37aabe33bd7099f42ba0738169aca06c77003e8187dae50b6f116a508c"}
for name,expected in expect.items():
 b=(baseline_dir/name).read_bytes();assert sha(b)==expected
 (copies/name).write_bytes(b)
summary={
"schema":"final-object-delta-review-delivery-v1",
"status":"complete_read_only_evidence",
"source_binding_commit":first["expected_code_commit"],"source_binding_tree":first["expected_code_tree"],
"explicit_following_merge_commit":root,"explicit_following_merge_tree":root_tree,
"initial_baseline":{"objects":186433,"blobs":74256,"raw_blob_bytes":7939757665,"inventory_sha256":expect["object-inventory.txt"],"original_regex_available":False,"original_category_results":"Four token categories zero; three private-key-header markers, separately triaged as Python marker-only strings."},
"frozen_delta":{"enumerated_objects":187538,"new_objects":1105,"new_blob_count":411,"raw_new_blob_bytes":130927248,"new_tree_count":631,"new_commit_count":63,"all_previous_oids_present_and_metadata_unchanged":True,"all_new_blob_content_addresses_verified":True,"all_new_blob_bytes_scanned":True,"pattern_match_counts":first["match_counts"],"summary_sha256":sha((D/"run-v1/summary.json").read_bytes()),"inventory_sha256":first["current_inventory"]["sha256"]},
"explicit_after_enumeration_merge_appendix":{"blob_count":len(extra),"raw_blob_bytes":sum(x["bytes"] for x in extra),"all_content_addresses_verified":True,"match_counts":{k:sum(x["match_counts"][k] for x in extra) for k in compiled},"receipt_sha256":sha((D/"stable-recheck-v1/post-enumeration-merge-two-blob-scan.json").read_bytes()),"initial_delta_not_rewritten":True},
"fsck":{"first_exit":2,"first_log_sha256":first["fsck"]["sha256"],"first_refs_changed":True,"reported_missing_count":10,"all_missing_oids_absent_frozen_enumeration":True,"all_missing_oids_now_readable":True,"all_missing_oids_reachable_from_exact_following_merge":True,"stable_exit":0,"stable_seconds":stable["elapsed_seconds"],"stable_refs_unchanged":True,"stable_log_sha256":stable["fsck_log_sha256"],"stable_dangling_counts":dict(collections.Counter(x.split()[1] for x in log)),"stable_summary_sha256":sha((D/"stable-recheck-v1/summary.json").read_bytes()),"original_failure_retained":True,"repair_fetch_prune_performed":False,"interpretation":"First fsck overlapped coordinator Git writes and read a non-atomic object/ref view. Ten reported missing objects were created after the initial enumeration and are present in the following exact merge. A read-only recheck while coordinator writes were paused passed with unchanged refs; no repair was performed."},
"patterns":{"explicit_new_regex":True,"definition_sha256":sha((D/"run-v1/patterns-and-scope.json").read_bytes()),"same_as_original_scanner_claimed":False,"raw_match_values_disclosed":False,"recursive_archive_decompression":False,"all_secret_types_excluded":False},
"scope_limits":["Only the frozen 411 new blobs plus the separately enumerated two immutable merge blobs received these new regex scans.","Earlier 74256 blobs are covered by the preserved earlier result, whose exact regex driver is unavailable; they were not rescanned here.","Future report/evidence/docs/archive objects and any objects outside these explicitly enumerated sets are excluded and require separate execution receipts.","Full fsck success does not imply all credentials absent or all repository behavior correct."],
"read_only_git":True,"remote_write":False,"checkout_or_refs_modified":False}
write(OUT/"summary.json",summary)
readme="# Incremental Git-object review\n\nThe initial frozen delta contains 1,105 new objects: 411 blobs, 631 trees and 63 commits. All 411 new blobs (130,927,248 raw bytes) were scanned and their Git content addresses recomputed. Every declared new pattern returned zero matches. The exact new regex definitions are in run-v1/patterns-and-scope.json; the unavailable earlier scanner is not claimed equivalent.\n\nThe first fsck returned 2 while coordinator Git writes were concurrent. All ten reported missing objects were absent from the frozen enumeration, later readable, and present in merge 96643a2dd8a90cded0059216cae15e2cd620c77b. A stable read-only full fsck returned 0 with unchanged refs. Both original logs and authoritative terminal receipts are retained. Dangling objects were not deleted.\n\nTwo merge blobs created after the original enumeration were separately and explicitly scanned (1,006,072 bytes, all patterns zero). This supplemental receipt does not rewrite the initial 411-blob result. Later report, evidence, documentation and archive objects are excluded.\n\nThe original baseline inventory, summary and three marker-only triage results are copied unchanged. ZIP payloads were not recursively decompressed. No result claims exclusion of every possible secret.\n\nAll archive members are bound by receipt-index.json. Its own hash and the ZIP hash are in the external delivery.json, avoiding a self-reference.\n"
(OUT/"README.md").write_text(readme)
files=[]
for prefix in ["run-v1","stable-recheck-v1","original-baseline-receipts"]:
 files += sorted((D/prefix).glob("*"))
files += [D/"scan_driver.py",D/"stable-recheck-driver.py",D/"custody_driver.py",D/"custody_driver_v2.py",D/"packaging-attempt-v1-terminal.json",D/"pty-terminal-receipts.json",OUT/"summary.json",OUT/"README.md"]
assert all(p.is_file() and not p.is_symlink() for p in files)
members=[]
for p in files:
 name=p.relative_to(D).as_posix();b=p.read_bytes()
 members.append({"path":name,"bytes":len(b),"sha256":sha(b)})
assert len({r["path"] for r in members})==len(members)
idx={"schema":"final-object-delta-original-receipts-index-v1","members":members,"payload_member_count":len(members),"payload_total_bytes":sum(x["bytes"] for x in members),"index_itself_excluded_from_self_hash":True}
write(OUT/"receipt-index.json",idx)
zp=OUT/"final-object-delta-original-receipts-v1.zip"
with zipfile.ZipFile(zp,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files+[OUT/"receipt-index.json"]:
  name=p.relative_to(D).as_posix()
  zi=zipfile.ZipInfo(name,date_time=(2026,11,14,5,30,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=0o600<<16
  z.writestr(zi,p.read_bytes())
with zipfile.ZipFile(zp) as z:
 assert z.testzip() is None
 assert set(z.namelist())=={r["path"] for r in members}|{"delivery-v2/receipt-index.json"}
 for row in members:
  b=z.read(row["path"]);assert len(b)==row["bytes"] and sha(b)==row["sha256"]
delivery={"status":"verified","summary":{"path":str(OUT/"summary.json"),"bytes":(OUT/"summary.json").stat().st_size,"sha256":sha((OUT/"summary.json").read_bytes())},"index":{"path":str(OUT/"receipt-index.json"),"bytes":(OUT/"receipt-index.json").stat().st_size,"sha256":sha((OUT/"receipt-index.json").read_bytes())},"zip":{"path":str(zp),"bytes":zp.stat().st_size,"sha256":sha(zp.read_bytes()),"members":len(members)+1},"all_zip_members_individually_verified":True,"additional_merge_blobs":[{"oid":x["oid"],"paths":x["paths_at_merge"],"bytes":x["bytes"],"match_counts":x["match_counts"]} for x in extra]}
write(OUT/"delivery.json",delivery)
print(json.dumps(delivery,ensure_ascii=False),flush=True)
