#!/usr/bin/env python3
"""Evaluate the proposed reader against frozen C1; do not edit the checkout."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

BASE = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/d4d2da8133e2/chain-pq-closure')
sys.path.insert(0, str(ROOT / 'scripts/ci'))
PATHS = ['scripts/ci/check_public_readiness_evidence.py', 'scripts/ci/test_public_readiness_evidence.py',
         'trillionnium/crates/trnm-pon-node/src/store.rs', 'trillionnium/crates/trnm-pon-node/src/ancestry_index.rs']
before = {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in PATHS}


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


original = module('original_public_readiness', ROOT / PATHS[0])
fixed = module('check_public_readiness_evidence', BASE / 'proposed' / PATHS[0])
fixed.ROOT = ROOT
assert original.FLAGS == fixed.FLAGS
current = (ROOT / PATHS[2]).read_text()
guard = ('        // Every backend shares the M06 scope and account-profile decision before\n'
         '        // creating, initializing or recovering any native namespace files.\n'
         '        settings.app.check_account_profile()?;\n')
assert current.count(guard) == 1
rolled_back = current.replace(guard, '', 1)
late = rolled_back.replace('            fs::create_dir_all(path)?;',
                           '            fs::create_dir_all(path)?;\n'
                           '            settings.app.check_account_profile()?;', 1)
sources = {
    'actual_c1': current,
    'rollback_to_parent_selected_body': rolled_back,
    'guard_only_in_comment': current.replace(guard, guard.replace('        settings.app.', '        // settings.app.'), 1),
    'guard_refusal_ignored': current.replace(guard, guard.replace('settings.app.check_account_profile()?;', 'let _ = settings.app.check_account_profile();'), 1),
    'guard_after_namespace_effect': late,
}
comparison = []
with tempfile.TemporaryDirectory(prefix='durable-schema-proof-') as folder:
    temp_root = Path(folder)
    store = temp_root / PATHS[2]
    store.parent.mkdir(parents=True)
    (temp_root / PATHS[3]).write_bytes((ROOT / PATHS[3]).read_bytes())
    for name, source in sources.items():
        store.write_text(source)
        row = {'case': name, 'store_sha256': hashlib.sha256(source.encode()).hexdigest()}
        for label, reader in [('c1_original_reader', original), ('proposed_reader', fixed)]:
            try:
                ddl, domain = reader.native_durable_schema(temp_root)
                outcome = {'accepted': True, 'ddl_bytes': len(ddl.encode()), 'domain': domain,
                           'ddl_sha256': hashlib.sha256(ddl.encode()).hexdigest()}
            except ValueError as error:
                outcome = {'accepted': False, 'error': str(error)}
            row[label] = outcome
        comparison.append(row)
assert comparison[0]['c1_original_reader']['accepted'] is False
assert comparison[0]['proposed_reader']['accepted'] is True
assert comparison[1]['c1_original_reader']['accepted'] is True
assert comparison[1]['proposed_reader']['accepted'] is False
assert all(not row['proposed_reader']['accepted'] for row in comparison[1:])
assert comparison[0]['proposed_reader']['ddl_bytes'] == 5404
assert comparison[0]['proposed_reader']['domain'] == 'native-branch-schema-v2'
tests = module('staged_public_readiness', BASE / 'proposed' / PATHS[1])
names = [
    'NativeDurableSchemaTests.test_current_backend_returns_the_exact_preserved_legacy_bytes',
    'NativeDurableSchemaTests.test_existing_owner_split_requires_the_reviewed_executable_contract',
    'DurableStoreTests.test_current_v2_schema_and_complete_index_positive_control',
]
expected = ['staged_public_readiness.' + name for name in names]


class Result(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.started_ids = []
        self.success_ids = []

    def startTest(self, test):
        self.started_ids.append(test.id())
        super().startTest(test)

    def addSuccess(self, test):
        self.success_ids.append(test.id())
        super().addSuccess(test)


suite = unittest.TestLoader().loadTestsFromNames(names, tests)
stream = io.StringIO()
result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=Result).run(suite)
log = stream.getvalue()
(BASE / 'targeted-tests.log').write_text(log)
assert result.testsRun == 3 and result.started_ids == expected and result.success_ids == expected
assert not any([result.failures, result.errors, result.skipped, result.expectedFailures, result.unexpectedSuccesses])
after = {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in PATHS}
assert before == after
record = {
    'scope': 'repo-external proposed Python reader and test bytes against frozen C1 source; no candidate edits',
    'source_commit': 'c09dbbe9921da12db8bf7240a8a95a0e9a789e50',
    'source_tree': 'f15a7ee4a0f5455eaf965db01dcd49e02a5f22b6',
    'candidate_target_files_before': before, 'candidate_target_files_after': after,
    'proposed_files': {path: hashlib.sha256((BASE / 'proposed' / path).read_bytes()).hexdigest() for path in PATHS[:2]},
    'comparison': comparison, 'targeted_tests_run': result.testsRun, 'expected_ids': expected,
    'started_ids': result.started_ids, 'success_ids': result.success_ids,
    'skipped': [], 'failures': [], 'errors': [], 'qualification_flags_unchanged': True,
    'whole_71_test_suite_rerun': False, 'hosted_rerun_triggered': False,
}
(BASE / 'proposal-validation.json').write_text(json.dumps(record, indent=2) + '\n')
print(log, end='')
print(json.dumps({'comparison_cases': len(comparison), 'targeted_tests_passed': 3,
                  'candidate_target_files_unchanged': before == after, 'whole_71_suite_rerun': False}, sort_keys=True))
