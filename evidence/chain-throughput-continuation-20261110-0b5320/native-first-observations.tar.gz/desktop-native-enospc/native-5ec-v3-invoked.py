import json,os,pathlib,subprocess,shutil,sys,hashlib,time,signal,re
sha='5ec9b4490fbfd22df4527e3b75ec74d6986572cf'
root=pathlib.Path('/tmp/chain-throughput-0b5320')
out=pathlib.Path('/dev/shm/chain-throughput-0b5320/native-5ec9-v3')
out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='/dev/shm/chain-throughput-0b5320/target',CARGO_TERM_COLOR='never',PYTHONDONTWRITEBYTECODE='1')
summary={'source':sha,'scope':'retained native component, node library and pool integration tests; no original campaign, TPS or release qualification','steps':[],'tests':[],'success':False}
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save():(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
def run(name,argv,seconds):
 so=out/(name+'.stdout.log');se=out/(name+'.stderr.log');start=time.monotonic();timed=False
 print(json.dumps({'stage':name,'state':'starting'}),flush=True)
 with so.open('wb') as o,se.open('wb') as e:
  p=subprocess.Popen(argv,cwd=root,env=env,stdout=o,stderr=e,start_new_session=True)
  try:rc=p.wait(timeout=seconds)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGTERM)
   try:rc=p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
 row={'stage':name,'argv':argv,'exit':rc,'timed_out':timed,'elapsed_seconds':time.monotonic()-start,'stdout':so.name,'stderr':se.name,'stdout_sha256':digest(so),'stderr_sha256':digest(se)}
 summary['steps'].append(row);save();print(json.dumps(row),flush=True)
 return row,so,se
def req(name,argv,seconds):
 row,so,se=run(name,argv,seconds)
 if row['exit'] or row['timed_out']:raise RuntimeError(name+': '+se.read_text(errors='replace')[-1600:])
 return so
def source(name):return req(name,['/usr/bin/python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',sha,'--output',str(out/(name+'.json'))],180)
def artifacts(log,name):
 result=[]
 for line in log.read_text().splitlines():
  try:r=json.loads(line)
  except ValueError:continue
  if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('target',{}).get('name')==name:result.append(r)
 if len(result)!=1:raise RuntimeError('EXACT_BINARY_REQUIRED '+name)
 return result[0]
def retain(artifact,label,test):
 profile=artifact['profile'];expect={'debug_assertions':False,'debuginfo':0,'opt_level':'3','overflow_checks':False,'test':test}
 if any(profile.get(k)!=v for k,v in expect.items()):raise RuntimeError('RELEASE_PROFILE_MISMATCH '+label)
 p=pathlib.Path(artifact['executable']);kept=out/(label+'.bin');shutil.copy2(p,kept)
 record={'path':str(p),'retained':str(kept),'profile':profile,'sha256':digest(p),'bytes':p.stat().st_size}
 summary[label]=record;save();return str(p)
cargo=['/home/qian-qi/.cargo/bin/cargo','+1.95.0']
try:
 if subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=root,text=True).strip()!=sha:raise RuntimeError('SOURCE_MISMATCH')
 branch=req('branch',['/usr/bin/git','branch','--show-current'],30).read_text().strip()
 if branch!='fix/chain-throughput-test-20261110-0b5320':raise RuntimeError('BRANCH_MISMATCH')
 req('preflight',['/usr/bin/bash','scripts/project-preflight.sh'],90)
 source('source-before')
 req('rustc',['/home/qian-qi/.cargo/bin/rustc','+1.95.0','--version','--verbose'],30)
 req('cargo',cargo+['--version'],30)
 flags={k:v for k,v in env.items() if k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS') or k.startswith('CARGO_PROFILE_')}
 summary['build_context']={'cargo_target_dir':env['CARGO_TARGET_DIR'],'jobs':2,'incremental':0,'profile_overrides':flags,'lock_sha256':digest(root/'trillionnium/Cargo.lock'),'manifest_sha256':digest(root/'trillionnium/Cargo.toml'),'free_bytes':shutil.disk_usage('/tmp').free};save()
 if any(flags.values()):raise RuntimeError('UNEXPECTED_PROFILE_FLAGS')
 summary['build_context']['target_filesystem']={'path':'/dev/shm','free_bytes':shutil.disk_usage('/dev/shm').free,'exec_probe_receipt':'/tmp/chain-throughput-0b5320-evidence/disk-recovery-v2.json','exec_probe_exit':0}
 summary['build_context']['previous_attempt']={'evidence':'/tmp/chain-throughput-0b5320-evidence/native-5ec9-v2','outcome':'compiler LLVM ENOSPC; no tests executed','raw_stderr_sha256':'e0022276452e5cf5e216237a0e4f59bb3cc76272941140add238fd1ecb1a2519'};save()
 if shutil.disk_usage('/dev/shm').free<16*1024**3:raise RuntimeError('LESS_THAN_16_GIB_TARGET_FREE')
 req('metadata',cargo+['metadata','--locked','--format-version','1','--manifest-path','trillionnium/Cargo.toml'],300)
 log=req('build-lib',cargo+['test','--locked','--release','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib','--no-run','--message-format=json'],1800)
 binary=retain(artifacts(log,'trnm_pon_node'),'node_lib',True)
 listed=req('test-list',[binary,'--list'],60).read_text()
 names=[
 'ingress::history_import::tests::detached_budget_controls::shared_detached_history_continues_from_real_deficit_without_new_credit',
 'ingress::history_import::tests::detached_budget_controls::shared_detached_history_refill_keeps_original_resource_cancellation',
 'ingress::history_import::tests::detached_budget_controls::shared_detached_history_refill_cannot_renew_original_deadline',
 'ingress::public_v3::scalar_cpu::history_handoff_tests::history_writer_handoff_waits_for_original_free_credit_and_preserves_other_reserve',
 'ingress::public_v3::scalar_cpu::history_handoff_tests::history_writer_handoff_preserves_original_resource_and_deadline',
 'ingress::public_v3::scalar_cpu::history_handoff_tests::history_writer_handoff_denies_wait_to_unqualified_and_replayed_work',
 'ingress::public_v3::scalar_cpu::history_handoff_tests::history_writer_handoff_never_revives_refused_or_unknown_operation',
 'ingress::public_v3::scalar_cpu::history_handoff_tests::history_writer_handoff_keeps_funded_unqualified_path_without_wait',
 'mining::pool_reconcile_control_tests::pool_run_stop_interrupts_reconciliation_pool_rows',
 'mining::pool_reconcile_control_tests::pool_run_deadline_interrupts_reconciliation_pool_rows']
 names.extend(["mining::prepare_control_tests::registered_prepare_pre_cancel_keeps_error_before_material_or_parent_io","mining::prepare_control_tests::registered_prepare_cancels_inside_active_row_scan_before_execution","mining::prepare_control_tests::registered_prepare_cancels_during_inactive_ancestry_read_and_retries","mining::prepare_control_tests::registered_prepare_control_preserves_packets_errors_and_cold_commit","mining::pool_run_control_tests::pool_run_stop_interrupts_batch_parent_scan","mining::pool_run_control_tests::pool_run_stop_interrupts_registered_and_legacy_prepare","mining::pool_run_control_tests::pool_run_stop_interrupts_post_search_revalidation","mining::pool_run_control_tests::pool_run_original_deadline_interrupts_parent_scan","mining::pool_run_control_tests::pool_run_cancelled_preview_keeps_queue_without_completed_m06","mining::pool_run_control_tests::pool_run_native_and_sql_failures_survive_concurrent_stop","mining::pool_run_control_tests::pool_run_completed_packet_and_reconcile_failure_remain_durable"])
 for name in names:
  if listed.splitlines().count(name+': test')!=1:raise RuntimeError('MISSING_OR_DUPLICATE_TEST '+name)
 for i,name in enumerate(names):
  row,so,se=run('test-'+str(i+1).zfill(2),[binary,name,'--exact','--nocapture','--test-threads=1'],120)
  passed=row['exit']==0 and not row['timed_out'] and re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored;',so.read_text(errors='replace')) is not None
  summary['tests'].append({'name':name,'passed':passed,'step':row});save()
 source('source-after-targeted')
 print(json.dumps({'targeted_complete':True,'passed':sum(t['passed'] for t in summary['tests']),'planned':len(names),'source':sha}),flush=True)
 # Continue the original retained suites regardless of a targeted assertion failure.
 row,so,se=run('node-library',[binary,'--nocapture','--test-threads=1'],3600)
 summary['library_pass']=row['exit']==0 and not row['timed_out'];save()
 source('source-after-library')
 log=req('build-pool',cargo+['test','--locked','--release','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--test','pool_mining','--no-run','--message-format=json'],1200)
 pool=retain(artifacts(log,'pool_mining'),'pool_integration',True)
 cli=artifacts(log,'trnm-pon-node')
 retain(cli,'node_cli',False)
 req('pool-list',[pool,'--list'],60)
 row,so,se=run('pool-integration',[pool,'--nocapture','--test-threads=1'],1200)
 summary['pool_pass']=row['exit']==0 and not row['timed_out'];save()
 summary['success']=all(t['passed'] for t in summary['tests']) and len(summary['tests'])==21 and summary['library_pass'] and summary['pool_pass']
except Exception as e:
 summary['failure']=str(e);print(json.dumps({'failure':str(e)}),flush=True)
finally:
 try:source('source-after')
 except Exception as e:summary['source_after_failure']=str(e);summary['success']=False
 summary['free_bytes_after']=shutil.disk_usage('/tmp').free;summary['tmpfs_free_bytes_after']=shutil.disk_usage('/dev/shm').free;save()
 print(json.dumps({'final':True,'success':summary['success'],'failure':summary.get('failure'),'targeted_passed':sum(t['passed'] for t in summary['tests']),'library_pass':summary.get('library_pass'),'pool_pass':summary.get('pool_pass'),'evidence':str(out),'source':sha,'free_bytes_after':summary['free_bytes_after']}),flush=True)
sys.exit(0 if summary['success'] else 1)
