"""Fresh V6 source admission and actual native build; no inherited V3 suite claim."""
from __future__ import annotations
import hashlib,json,pathlib,resource,subprocess,sys,time,traceback
BASE=pathlib.Path(__file__).resolve().parent
ROOT=BASE/"candidate-v6-snapshot"
OUT=BASE/"verification-v6-1"
def identity(path):
    raw=path.read_bytes()
    return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def write_json(path,value):
    path.write_text(json.dumps(value,sort_keys=True,indent=2)+"\n")
def need(condition,message):
    if not condition: raise ValueError(message)
def main():
    OUT.mkdir(mode=0o700)
    started=time.monotonic_ns()
    report={"schema":"trnm.continuity-v6-admission-native-build.v1","status":"RUNNING",
        "repository":str(ROOT),"full_native_659":"NOT_RUN_V6","full_capacity_7":"NOT_RUN_V6",
        "actual_original_rust":"NOT_RUN_V6","source_transition":"correct four original Legacy owner selections and matching README after full adapter audit",
        "prior_v3_v4_v5_results_are_not_v6_qualification":True,"all_git_tracked_files_verified":False}
    write_json(OUT/"running.json",report)
    try:
        transition=json.loads((BASE/"continuity-v5-to-v6-transition.json").read_bytes())
        need(transition["changed_paths"]==["hia/platform/continuity_store/README.md",
             "hia/platform/continuity_store/rust_reference.rs"],"Unexpected V5 to V6 source change")
        sys.path.insert(0,str(ROOT))
        from hia.platform.continuity_store.rust_oracle import complete_source_manifest,canonical_json_hash
        from hia.platform.typed_store.build import original_manifest
        inputs=complete_source_manifest(ROOT)
        original=original_manifest(ROOT)
        need(inputs==transition["source_inputs"],"V6 source changed before verification")
        need(canonical_json_hash(inputs)==transition["v6_source_set_sha256"],
             "Unexpected V6 source set")
        need(len(inputs)==61 and len(original)==4361,"Unexpected source extent")
        preflight=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=ROOT,capture_output=True,timeout=30)
        (OUT/"preflight.stdout").write_bytes(preflight.stdout)
        (OUT/"preflight.stderr").write_bytes(preflight.stderr)
        need(preflight.returncode==0,"V6 preflight failed")
        integrity=BASE/"integrity-v6-1"
        process=subprocess.run([sys.executable,"-B","-m","hia.platform.continuity_store.test_integrity",
            "--output",str(integrity)],cwd=ROOT,capture_output=True,timeout=180)
        (OUT/"integrity.stdout").write_bytes(process.stdout)
        (OUT/"integrity.stderr").write_bytes(process.stderr)
        need(process.returncode==0,"V6 source/corpus admission failed")
        admission=json.loads((integrity/"report.json").read_bytes())
        need(admission["status"]=="PASS" and admission["control_count"]==102
             and admission["production_source_inputs"]==inputs,"V6 admission identity/count differs")
        report["integrity"]={"status":"PASS","controls":102,"native_executions":0,"rust_executions":0,
            "report":str(integrity/"report.json"),**identity(integrity/"report.json")}
        write_json(OUT/"running.json",report)
        from hia.platform.continuity_store.build import Build
        build_started=time.monotonic_ns()
        builder=Build(BASE/"build-v6-1",ROOT)
        executable,receipt=builder.build()
        need(receipt["source_inputs"]==inputs and receipt["original_sources"]==original,
             "Actual build did not bind the admitted source")
        need(len(executable)==1398300 and hashlib.sha256(executable).hexdigest()
             =="43c2011cbece7f183268aac6d58cf59194587892c28459ac3c9434a6b50266c4",
             "V6 actual runtime differs from V5")
        prior=json.loads((BASE/"native-v5-1/report.json").read_bytes())["build"]
        need(prior["executable"]==receipt["executable"] and prior["images"]==receipt["images"]
             and prior["emitter"]==receipt["emitter"] and prior["elf_prefix"]==receipt["elf_prefix"],
             "V6 runtime component identities differ")
        need(complete_source_manifest(ROOT)==inputs and original_manifest(ROOT)==original,
             "Source changed during verification")
        report.update(status="ADMISSION_PASS_BUILD_PASS_SAME_RUNTIME",
            source_set_sha256=canonical_json_hash(inputs),source_inputs=inputs,
            original_sources_count=len(original),original_sources_sha256=canonical_json_hash(original),
            build_report={"path":str(BASE/"build-v6-1/build.json"),**identity(BASE/"build-v6-1/build.json")},
            build_elapsed_seconds=(time.monotonic_ns()-build_started)/1e9,
            executable=receipt["executable"],runtime_components_equal_v5=True,
            actual_compiler_sha256=receipt["compiler_sha256"],
            elapsed_seconds=(time.monotonic_ns()-started)/1e9,
            controller_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            full_integrated_head_ci_required=["659 native controls","7 full capacity controls","572 actual original Rust cases and 4 retained original tests"])
        write_json(OUT/"report.json",report)
        print(json.dumps({k:report[k] for k in ("status","source_set_sha256","executable",
            "build_elapsed_seconds","elapsed_seconds","controller_peak_rss_kib")}))
    except BaseException as error:
        report.update(status="FAIL",error=repr(error),traceback=traceback.format_exc(),
            elapsed_seconds=(time.monotonic_ns()-started)/1e9)
        write_json(OUT/"report.json",report)
        raise
if __name__=="__main__":main()
