//! Complete W1 statement and execution-witness export for a future transparent
//! proof backend. This module DOES NOT generate a succinct proof. Witness
//! validation below explicitly performs full recomputation.
use crate::pon_work::{self, hash, Hash, WorkError, CELLS, N, PROOF_BYTES, Q, R};
use sha2::{Digest, Sha256};

pub const HEADER_BYTES: usize = 318;
pub const TRACE_BYTES: usize = (N / R) * (N / R) * (N / R) * R * R * 4;
pub const STATEMENT_SCHEMA: &str = "trnm-w1-complete-statement-research-v1";
pub const SOURCE_COMMIT: &str = "4b6b8a91b6dfe41fbd7f40f40b359d535c2c4251";

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StatementError {
    HeaderLength,
    HeaderVersion,
    Work(WorkError),
    WitnessLength,
    WitnessMismatch,
}
impl From<WorkError> for StatementError {
    fn from(e: WorkError) -> Self {
        Self::Work(e)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CompleteStatement {
    pub header: [u8; HEADER_BYTES],
    pub challenge: Hash,
    pub task: Hash,
    pub target: Hash,
    pub trace: Hash,
    pub ticket: Hash,
    pub block_id: Hash,
    pub proof_digest: Hash,
    pub statement_id: Hash,
}

impl CompleteStatement {
    /// Only W1 acceptance is checked. Parent state, height, lease, DAA, and
    /// chain validity remain the existing Node's duties and are NOT asserted.
    pub fn from_winner(header: &[u8], proof: &[u8]) -> Result<Self, StatementError> {
        if header.len() != HEADER_BYTES {
            return Err(StatementError::HeaderLength);
        }
        if &header[..6] != b"PNH1\x01\0" {
            return Err(StatementError::HeaderVersion);
        }
        let header: [u8; HEADER_BYTES] = header.try_into().unwrap();
        let challenge = hash(b"challenge", &[&header]);
        let target: Hash = header[118..150].try_into().unwrap();
        let task: Hash = header[278..310].try_into().unwrap();
        let accepted = pon_work::verify(challenge, task, target, proof)?;
        let trace: Hash = proof[PROOF_BYTES - 32..].try_into().unwrap();
        let ticket = accepted.ticket();
        let block_id = hash(b"block", &[&header, &trace]);
        let proof_digest: Hash = Sha256::digest(proof).into();
        // This is an evidence identifier, never a chainwork or validity token.
        let statement_id = hash(
            b"w1-complete-statement-research-v1",
            &[pon_work::PROFILE.as_bytes(), &header, &proof_digest],
        );
        Ok(Self {
            header,
            challenge,
            task,
            target,
            trace,
            ticket,
            block_id,
            proof_digest,
            statement_id,
        })
    }
}

pub struct ExecutionWitness {
    pub noise: Vec<u32>,
    pub noised_a: Vec<u32>,
    pub noised_b: Vec<u32>,
    pub transcript: Vec<u8>,
    pub noise_hashes: [u32; 4],
}

fn field_bytes(values: &[u32]) -> Vec<u8> {
    values.iter().flat_map(|v| v.to_le_bytes()).collect()
}
fn matrix_mul(a: &[u32], b: &[u32], rows: usize, inner: usize, cols: usize) -> Vec<u32> {
    (0..rows)
        .flat_map(|i| {
            (0..cols).map(move |j| {
                ((0..inner)
                    .map(|k| u128::from(a[i * inner + k]) * u128::from(b[k * cols + j]))
                    .sum::<u128>()
                    % Q) as u32
            })
        })
        .collect()
}
fn noise(challenge: Hash, label: u8) -> Result<(Vec<u32>, u32), WorkError> {
    let mut out = Vec::with_capacity(N * R);
    for counter in 0_u32..128 {
        for chunk in hash(b"noise", &[&challenge, &[label], &counter.to_le_bytes()]).chunks_exact(4)
        {
            let value = u32::from_le_bytes(chunk.try_into().unwrap());
            if u128::from(value) < Q {
                out.push(value);
                if out.len() == N * R {
                    return Ok((out, counter + 1));
                }
            }
        }
    }
    Err(WorkError::NoiseBudget)
}

/// Export only after the original complete verifier accepts a winning ticket.
pub fn export_witness(
    statement: &CompleteStatement,
    proof: &[u8],
) -> Result<ExecutionWitness, StatementError> {
    let checked = CompleteStatement::from_winner(&statement.header, proof)?;
    if checked != *statement {
        return Err(StatementError::WitnessMismatch);
    }
    let words: Vec<u32> = proof[4..4 + 3 * CELLS * 4]
        .chunks_exact(4)
        .map(|b| u32::from_le_bytes(b.try_into().unwrap()))
        .collect();
    let (a, rest) = words.split_at(CELLS);
    let b = &rest[..CELLS];
    let mut all_noise = Vec::with_capacity(4 * N * R);
    let mut noise_hashes = [0_u32; 4];
    for (label, count) in noise_hashes.iter_mut().enumerate() {
        let (values, hashes) = noise(statement.challenge, label as u8)?;
        all_noise.extend_from_slice(&values);
        *count = hashes;
    }
    let factors: Vec<_> = all_noise.chunks_exact(N * R).collect();
    let e = matrix_mul(factors[0], factors[1], N, R, N);
    let f = matrix_mul(factors[2], factors[3], N, R, N);
    let ap: Vec<_> = a
        .iter()
        .zip(e)
        .map(|(x, y)| ((u128::from(*x) + u128::from(y)) % Q) as u32)
        .collect();
    let bp: Vec<_> = b
        .iter()
        .zip(f)
        .map(|(x, y)| ((u128::from(*x) + u128::from(y)) % Q) as u32)
        .collect();
    let mut cp = vec![0_u32; CELLS];
    let mut transcript = Vec::with_capacity(TRACE_BYTES);
    for bi in 0..N / R {
        for bj in 0..N / R {
            for bk in 0..N / R {
                for i in bi * R..(bi + 1) * R {
                    for j in bj * R..(bj + 1) * R {
                        let value = u128::from(cp[i * N + j])
                            + (bk * R..(bk + 1) * R)
                                .map(|k| u128::from(ap[i * N + k]) * u128::from(bp[k * N + j]))
                                .sum::<u128>();
                        cp[i * N + j] = (value % Q) as u32;
                        transcript.extend_from_slice(&cp[i * N + j].to_le_bytes());
                    }
                }
            }
        }
    }
    let mut h = Sha256::new();
    h.update(b"TRNM-PON-TRACE1\0");
    h.update(statement.challenge);
    h.update(&transcript);
    let trace: Hash = h.finalize().into();
    if trace != statement.trace {
        return Err(StatementError::WitnessMismatch);
    }
    Ok(ExecutionWitness {
        noise: all_noise,
        noised_a: ap,
        noised_b: bp,
        transcript,
        noise_hashes,
    })
}

pub fn validate_witness_full_replay(
    statement: &CompleteStatement,
    proof: &[u8],
    candidate: &ExecutionWitness,
) -> Result<(), StatementError> {
    if candidate.noise.len() != 4 * N * R
        || candidate.noised_a.len() != CELLS
        || candidate.noised_b.len() != CELLS
        || candidate.transcript.len() != TRACE_BYTES
    {
        return Err(StatementError::WitnessLength);
    }
    let actual = export_witness(statement, proof)?;
    if actual.noise != candidate.noise
        || actual.noised_a != candidate.noised_a
        || actual.noised_b != candidate.noised_b
        || actual.transcript != candidate.transcript
        || actual.noise_hashes != candidate.noise_hashes
    {
        return Err(StatementError::WitnessMismatch);
    }
    Ok(())
}

impl ExecutionWitness {
    pub fn noise_bytes(&self) -> Vec<u8> {
        field_bytes(&self.noise)
    }
    pub fn noised_a_bytes(&self) -> Vec<u8> {
        field_bytes(&self.noised_a)
    }
    pub fn noised_b_bytes(&self) -> Vec<u8> {
        field_bytes(&self.noised_b)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn fixture() -> (Vec<u8>, Vec<u8>) {
        let a = vec![0; CELLS];
        let b = vec![0; CELLS];
        let mut header = vec![0; HEADER_BYTES];
        header[..6].copy_from_slice(b"PNH1\x01\0");
        header[118..150].fill(255);
        header[278..310].copy_from_slice(&pon_work::task_id(&a, &b).unwrap());
        let proof = pon_work::prove(hash(b"challenge", &[&header]), &a, &b).unwrap();
        (header, proof)
    }
    #[test]
    fn complete_export_matches_original_and_detects_every_witness_surface() {
        let (header, proof) = fixture();
        let statement = CompleteStatement::from_winner(&header, &proof).unwrap();
        let mut w = export_witness(&statement, &proof).unwrap();
        validate_witness_full_replay(&statement, &proof, &w).unwrap();
        w.transcript[TRACE_BYTES - 1] ^= 1;
        assert_eq!(
            validate_witness_full_replay(&statement, &proof, &w),
            Err(StatementError::WitnessMismatch)
        );
        w.transcript[TRACE_BYTES - 1] ^= 1;
        w.noise[0] ^= 1;
        assert_eq!(
            validate_witness_full_replay(&statement, &proof, &w),
            Err(StatementError::WitnessMismatch)
        );
        w.noise[0] ^= 1;
        w.noised_a[CELLS - 1] ^= 1;
        assert_eq!(
            validate_witness_full_replay(&statement, &proof, &w),
            Err(StatementError::WitnessMismatch)
        );
        w.noised_a[CELLS - 1] ^= 1;
        w.noised_b[0] ^= 1;
        assert_eq!(
            validate_witness_full_replay(&statement, &proof, &w),
            Err(StatementError::WitnessMismatch)
        );
        w.noised_b[0] ^= 1;
        w.noise_hashes[0] += 1;
        assert_eq!(
            validate_witness_full_replay(&statement, &proof, &w),
            Err(StatementError::WitnessMismatch)
        );
    }
    #[test]
    fn full_header_and_original_work_are_bound() {
        let (header, proof) = fixture();
        for offset in [6, 38, 70, 102, 110, 150, 182, 214, 246, 310] {
            let mut other = header.clone();
            other[offset] ^= 1;
            assert!(
                CompleteStatement::from_winner(&other, &proof).is_err(),
                "unbound header byte {offset}"
            );
        }
        let mut bad = proof.clone();
        bad[PROOF_BYTES - 1] ^= 1;
        assert!(matches!(
            CompleteStatement::from_winner(&header, &bad),
            Err(StatementError::Work(WorkError::Transcript))
        ));
        let mut bad = proof.clone();
        bad[4 + 2 * CELLS * 4] ^= 1;
        assert!(matches!(
            CompleteStatement::from_winner(&header, &bad),
            Err(StatementError::Work(WorkError::Product))
        ));
        let mut bad = header.clone();
        bad[118..150].fill(0);
        assert!(matches!(
            CompleteStatement::from_winner(&bad, &proof),
            Err(StatementError::Work(WorkError::Target))
        ));
        let mut bad = header.clone();
        bad[278] ^= 1;
        assert!(matches!(
            CompleteStatement::from_winner(&bad, &proof),
            Err(StatementError::Work(WorkError::Task))
        ));
    }

    #[test]
    fn supplied_derived_statement_fields_cannot_override_original_verification() {
        let (header, proof) = fixture();
        let original = CompleteStatement::from_winner(&header, &proof).unwrap();
        for field in 0..9 {
            let mut changed = original.clone();
            let bytes = match field {
                0 => &mut changed.challenge,
                1 => &mut changed.task,
                2 => &mut changed.target,
                3 => &mut changed.trace,
                4 => &mut changed.ticket,
                5 => &mut changed.block_id,
                6 => &mut changed.proof_digest,
                7 => &mut changed.statement_id,
                _ => {
                    changed.header[70] ^= 1;
                    assert!(export_witness(&changed, &proof).is_err());
                    continue;
                }
            };
            bytes[0] ^= 1;
            assert!(matches!(
                export_witness(&changed, &proof),
                Err(StatementError::WitnessMismatch)
            ));
        }
    }
}
