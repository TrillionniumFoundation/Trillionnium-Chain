#!/usr/bin/env python3
"""Readback only: parse the unchanged original stdout, never run native gates."""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RELATIVE = Path("evidence/cell-storage-convergence-f2568-20261109/tools/run_storage_convergence_exact_gates.py")

def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

def load(stage):
    spec = importlib.util.spec_from_file_location("parser18_" + stage, ROOT / stage / RELATIVE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

raw_path = ROOT / "complete-da-native.original.stdout.log"
config_path = ROOT / "native-config-097.json"
raw = raw_path.read_bytes()
assert len(raw) == 85158
assert hashlib.sha256(raw).hexdigest() == "1ce59bde5c6802777295b4404ebb0e8ec3af3e403e264aa0c9ae31dbcd06acb2"
assert identity(config_path)["sha256"] == "013be8af54eead8a48d645acf5217eeb109fc7f04db543454e77ca6649fca3a4"
config = json.loads(config_path.read_bytes())
assert config["sha"] == "097f59f505f8ec42f72e3b8255e6cb7822a70646"
assert config["tree"] == "4b1eb80fa88b0b8f98d216247f7b8bce2df73f20"
old, new = load("before"), load("after")
expected = new.validate_native_expectations(config["native_expectations"])["complete-da-native"]
try:
    old.exact_native_execution(raw.decode(), expected, "complete-da-native")
except old.GateError as error:
    old_error = str(error)
else:
    raise AssertionError("original parser unexpectedly accepted the unchanged original stdout")
assert old_error == "retained process-death observation differs from its exact three-line form"
actual = new.exact_native_execution(raw.decode(), expected, "complete-da-native")
assert actual["total_passed"] == 764
assert [row["passed"] for row in actual["harnesses"]] == [714, 0, 0, 1, 5, 5, 5, 5, 2, 2, 7, 2, 16]
assert sum(row["passed"] for row in actual["harnesses"][:-1]) == 748
assert actual["harnesses"][-1]["passed"] == 16
assert all(row["filtered_out"] == 0 for row in actual["harnesses"])
assert sum(len(row["names"]) for row in actual["new_test_execution"].values()) == 70
assert len(actual["nested_child_observations"]) == 1
nested = actual["nested_child_observations"][0]
assert nested["start_line"] == 543
assert tuple(nested["observed_lines"]) == new.PROCESS_DEATH_CHILD_PREFIX_LINES
assert nested["parent_results_counted"] == 1 and nested["child_independent_results_counted"] == 0
names = [name for row in actual["harnesses"] for name in row["test_names"]]
assert names.count(new.PROCESS_DEATH_PARENT) == names.count(new.PROCESS_DEATH_CHILD) == 1
assert raw.decode().splitlines().count(new.PROCESS_DEATH_CHILD_PREFIX_LINES[2]) == 2
assert old.REQUIRED_NEW_TESTS == new.REQUIRED_NEW_TESTS
assert old.SEALED_PYTHON_REQUIRED_NAMES == new.SEALED_PYTHON_REQUIRED_NAMES
assert len(new.SEALED_PYTHON_REQUIRED_NAMES) == 24
assert old.gate_commands(Path("/synthetic/readback"), config["sha"]) == new.gate_commands(Path("/synthetic/readback"), config["sha"])
assert len(new.gate_commands(Path("/synthetic/readback"), config["sha"])) == 25
print(json.dumps({
    "schema": "cell-storage-process-death-parser-readback-v1",
    "state": "parser_correction_validated_against_unchanged_original_stdout",
    "native_or_model_commands_executed": 0,
    "original_receipt_rewritten": False,
    "original_acceptance_attempt_state": "failed",
    "original_acceptance_gates_passed": 24,
    "original_acceptance_gates_total": 25,
    "new_acceptance_run_performed": False,
    "raw_stdout": identity(raw_path),
    "frozen_configuration": identity(config_path),
    "original_parser": identity(ROOT / "before" / RELATIVE),
    "corrected_parser": identity(ROOT / "after" / RELATIVE),
    "original_parser_rejection": old_error,
    "actual_native_passes_in_original_stdout": 748,
    "actual_doc_passes_in_original_stdout": 16,
    "actual_parsed_execution": actual,
    "original_child_prefix_occurrences": 2,
    "ordinary_child_results_counted": 1,
    "nested_child_results_counted": 0,
    "all_25_gate_argv_and_order_unchanged": True,
    "full_native_expectations_unchanged": True,
    "all_24_python_case_names_unchanged": True,
}, sort_keys=True, indent=2))
