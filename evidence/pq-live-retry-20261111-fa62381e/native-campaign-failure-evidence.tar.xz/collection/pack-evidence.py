#!/usr/bin/env python3
"""Package retained S2 evidence; never execute any retained command or binary."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import tarfile
import zipfile

BASE = Path(__file__).resolve().parent
ZIP = BASE / 'original-artifact.zip'
ZIP_BYTES = 75865526
ZIP_SHA = '7250117547e038c408cb9400d76759777f578c67979f0d0e3353dd7ee5051945'
SOURCE = '3c98e08e92094bb79ac811b682192d7252a7c325'
ARTIFACT_ID = 13858366171
ARCHIVE = BASE / 'native-campaign-failure-evidence.tar.xz'
MANIFEST = BASE / 'native-campaign-failure-evidence.manifest.json'
VERIFY = BASE / 'native-campaign-failure-evidence.verification.json'
FILELIST = BASE / 'native-campaign-failure-evidence.filelist.tsv'


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()


def stream_digest(handle):
    digest = hashlib.sha256()
    count = 0
    while chunk := handle.read(1024 * 1024):
        count += len(chunk)
        digest.update(chunk)
    return count, digest.hexdigest()


def digest_file(path):
    with path.open('rb') as handle:
        return stream_digest(handle)


def safe_name(name):
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and str(path) == name, name


def create_only(path, data):
    if path.exists():
        assert path.read_bytes() == data, 'Refusing different existing output: ' + str(path)
    else:
        with path.open('xb') as handle:
            handle.write(data)


assert digest_file(ZIP) == (ZIP_BYTES, ZIP_SHA), 'Original ZIP identity mismatch'
rows = []
zip_names = []
local_names = {
    'FINDINGS.md': 'FINDINGS.md',
    'collection/pack-evidence.py': 'pack-evidence.py',
    'collection/retrieval.json': 'retrieval.json',
    'collection/artifact-metadata.json': 'artifact-metadata.json',
    'collection/job-log.txt': 'job-log.txt',
    'collection/range-attempt-observation.json': 'range-attempt-observation.json',
    'collection/range-attempt-final.json': 'range-attempt-final.json',
    'collection/range-partial-retrieval.json': 'range-partial-retrieval.json',
    'analysis/causal-summary.json': 'causal-summary.json',
    'analysis/history-attribution-summary.json': 'history-attribution-summary.json',
    'analysis/original-predicate-and-resource-summary.json': 'original-predicate-and-resource-summary.json',
    'analysis/client-native-stage-deltas-run1.json': 'client-native-stage-deltas-run1.json',
    'analysis/source-references.json': 'source-references.json',
}
with zipfile.ZipFile(ZIP) as original:
    original_manifest = json.loads(original.read('artifact-files.json'))
    original_rows = {entry['path']: entry for entry in original_manifest['files']}
    assert len(original_rows) == len(original_manifest['files']), 'Duplicate original manifest paths'
    infos = original.infolist()
    assert len({entry.filename for entry in infos}) == len(infos), 'Duplicate ZIP member paths'
    # Retain every top-level text/JSON/log observation, excluding the actual ELF.
    zip_names.extend(entry.filename for entry in infos
                     if not entry.is_dir() and '/' not in entry.filename
                     and entry.filename != 'public_v3_multiprocess.bin')
    for run in range(1, 4):
        prefix = f'run-{run}-raw/'
        zip_names.extend(prefix + name for name in ['report.json', 'economics.json', 'honest-preparation.json'])
        for phase in ['baseline', 'from-zero', 'late-product']:
            control = prefix + phase + '-host-control/'
            zip_names.extend(control + name for name in [
                'phase-job.json', 'host/child-result.json', 'host/controller-result.json'])
    assert len(zip_names) == len(set(zip_names)), 'Duplicate selection'
    for name in sorted(zip_names):
        safe_name(name)
        info = original.getinfo(name)
        assert not info.is_dir() and info.file_size <= 64 * 1024 * 1024
        with original.open(info) as handle:
            count, sha = stream_digest(handle)
        assert count == info.file_size
        expected = original_rows.get(name)
        if name != 'artifact-files.json':
            assert expected and expected['bytes'] == count and expected['sha256'] == sha, name
        else:
            assert expected is None, 'Unexpected manifest self-reference'
        rows.append({
            'path': 'artifact/' + name, 'bytes': count, 'sha256': sha,
            'provenance': {
                'kind': 'original-github-actions-artifact-member',
                'artifact_id': ARTIFACT_ID, 'zip_member': name,
                'compressed_bytes': info.compress_size,
                'original_manifest_match': True if expected else None,
                'binding': 'original artifact-files.json and pinned ZIP' if expected else 'pinned original ZIP (manifest cannot self-hash)',
            },
        })

    for archive_name, filename in sorted(local_names.items()):
        safe_name(archive_name)
        source = BASE / filename
        assert source.is_file() and not source.is_symlink()
        count, sha = digest_file(source)
        provenance = {'kind': 'derived-read-only-analysis-or-collection-record', 'local_file': filename}
        if filename == 'job-log.txt':
            provenance = {
                'kind': 'github-workflow-job-log-decoded-utf8', 'job_id': 130540971588,
                'source_url': 'https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43026071397/job/130540971588',
            }
        elif filename == 'artifact-metadata.json':
            provenance = {'kind': 'github-workflow-run-artifact-metadata', 'run_id': 43026071397, 'artifact_id': ARTIFACT_ID}
        rows.append({'path': archive_name, 'bytes': count, 'sha256': sha, 'provenance': provenance})

    rows.sort(key=lambda row: row['path'])
    assert len({row['path'] for row in rows}) == len(rows)
    manifest = {
        'schema': 'trnm-retained-native-campaign-failure-evidence-v1',
        'source': SOURCE,
        'tree': '34f4288927ec5e08430f7b2516db909859fab075',
        'original_run_id': 43026071397, 'original_job_id': 130540971588,
        'original_artifact': {
            'id': ARTIFACT_ID, 'bytes': ZIP_BYTES, 'sha256': ZIP_SHA,
            'original_zip_members': len(infos), 'retained_original_members': len(zip_names),
            'original_zip_included': False,
        },
        'collection_integrity_passed': True,
        'original_native_campaign_status': 'FAIL',
        'original_native_exit_codes': [101, 101, 101],
        'all_three_original_criteria_met': False,
        'whole_chain_quantum_security_qualified': False,
        'actual_native_tests_executed_by_this_collection': False,
        'native_builds_executed_by_this_collection': False,
        'source_or_business_criteria_changed_by_this_collection': False,
        'scope': 'Read-only retention and attribution of the original S2 finite campaign failure. Collection integrity does not qualify native behavior.',
        'excluded': ['original ZIP container', 'compiled ELF', 'SQLite databases', 'build products'],
        'tar_normalization': {'format': 'ustar', 'mtime': 0, 'uid': 0, 'gid': 0, 'uname': '', 'gname': '', 'mode': '0644'},
        'manifest_self_hash': 'See adjacent verification JSON; this manifest does not recursively include itself.',
        'files': rows,
    }
    manifest_data = encode(manifest)
    create_only(MANIFEST, manifest_data)
    manifest_row = {
        'path': 'extraction-manifest.json', 'bytes': len(manifest_data),
        'sha256': hashlib.sha256(manifest_data).hexdigest(),
        'provenance': {'kind': 'collection-manifest'},
    }
    all_rows = sorted([*rows, manifest_row], key=lambda row: row['path'])
    if not ARCHIVE.exists():
        partial = ARCHIVE.with_suffix(ARCHIVE.suffix + '.partial')
        assert not partial.exists(), 'Refusing ambiguous existing partial archive'
        with tarfile.open(partial, mode='w:xz', preset=6, format=tarfile.USTAR_FORMAT) as tar:
            for row in all_rows:
                info = tarfile.TarInfo(row['path'])
                info.size = row['bytes']
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mode = 0o644
                if row['path'] == 'extraction-manifest.json':
                    with io.BytesIO(manifest_data) as handle:
                        tar.addfile(info, handle)
                elif row['path'].startswith('artifact/'):
                    with original.open(row['provenance']['zip_member']) as handle:
                        tar.addfile(info, handle)
                else:
                    with (BASE / local_names[row['path']]).open('rb') as handle:
                        tar.addfile(info, handle)
        partial.rename(ARCHIVE)

# Reopen the final compressed archive and hash every complete member.
expected_rows = {row['path']: row for row in all_rows}
verified_rows = []
with tarfile.open(ARCHIVE, mode='r:xz') as tar:
    members = tar.getmembers()
    assert [member.name for member in members] == sorted(expected_rows)
    for member in members:
        assert member.isfile() and member.uid == member.gid == member.mtime == 0
        assert member.mode == 0o644 and member.uname == member.gname == ''
        with tar.extractfile(member) as handle:
            count, sha = stream_digest(handle)
        row = expected_rows[member.name]
        assert (count, sha) == (row['bytes'], row['sha256']), member.name
        verified_rows.append({'path': member.name, 'bytes': count, 'sha256': sha})
archive_bytes, archive_sha = digest_file(ARCHIVE)
verification = {
    'schema': 'trnm-retained-native-campaign-archive-verification-v1',
    'archive': ARCHIVE.name, 'bytes': archive_bytes, 'sha256': archive_sha,
    'manifest': MANIFEST.name, 'manifest_sha256': hashlib.sha256(manifest_data).hexdigest(),
    'verified_members': len(verified_rows), 'all_members_reopened_and_hashed': True,
    'collection_integrity_passed': True,
    'original_native_campaign_status': 'FAIL',
    'original_native_exit_codes': [101, 101, 101],
    'actual_native_tests_executed_by_this_collection': False,
    'native_builds_executed_by_this_collection': False,
    'files': verified_rows,
}
create_only(VERIFY, encode(verification))
filelist = 'path\tbytes\tsha256\tprovenance\n' + ''.join(
    f"{row['path']}\t{row['bytes']}\t{row['sha256']}\t{row['provenance']['kind']}\n"
    for row in all_rows)
create_only(FILELIST, filelist.encode())
create_only(ARCHIVE.with_suffix(ARCHIVE.suffix + '.sha256'), f'{archive_sha}  {ARCHIVE.name}\n'.encode())
print(json.dumps({
    'archive': str(ARCHIVE), 'bytes': archive_bytes, 'sha256': archive_sha,
    'manifest': str(MANIFEST), 'filelist': str(FILELIST), 'verification': str(VERIFY),
    'original_members': len(zip_names), 'verified_members': len(verified_rows),
    'original_native_campaign_status': 'FAIL', 'collection_integrity_passed': True,
    'actual_native_tests_executed': False, 'native_builds_executed': False,
}, indent=2))
