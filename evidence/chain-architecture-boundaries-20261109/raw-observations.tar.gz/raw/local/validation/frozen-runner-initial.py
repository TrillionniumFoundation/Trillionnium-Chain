#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json, os, re, signal, subprocess, time
ROOT=Path('/workspace/scratch/736a3d6dec1b/chain-architecture')
BASE=ROOT.parent
TOOLCHAIN=Path('/workspace/scratch/5faaca703596/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu')
p=argparse.ArgumentParser(); p.add_argument('group',choices=['static','native']); p.add_argument('--expected-head',required=True); a=p.parse_args()
OUT=BASE/'validation'/('frozen-'+a.group); OUT.mkdir(exist_ok=False)
env=os.environ.copy(); env.update(PATH=str(TOOLCHAIN/'bin')+':'+env['PATH'],RUSTC=str(TOOLCHAIN/'bin/rustc'),RUSTDOC=str(TOOLCHAIN/'bin/rustdoc'),LD_LIBRARY_PATH=str(TOOLCHAIN/'lib'),CARGO_HOME=str(BASE/'cargo-home'),CARGO_TARGET_DIR=str(BASE/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_TEST_DEBUG='0',RUST_TEST_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
for line in (BASE/'validation/provider.env').read_text().splitlines():
 k,v=line.split('=',1); env[k]=v
records=[]
report={'schema':'chain-architecture-source-bound-execution-v1','group':a.group,'expected_head':a.expected_head,'records':records,'production_activation':False,'whole_chain_pq_qualified':False,'original_public_campaign_qualified':False,'native_runtime_scope':'local mechanism diagnostic: node opt1, debug0, jobs1; no original runtime limit changes','environment':{k:env[k] for k in ['RUSTC','RUSTDOC','LD_LIBRARY_PATH','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_TEST_DEBUG','RUST_TEST_THREADS','OPENSSL_DIR','OPENSSL_STATIC','TRNM_PQ_OPENSSL','TRNM_PQ_OPENSSL_SHA256','OPENSSL_CONF','OPENSSL_MODULES']}}
def save():
 (OUT/'summary.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
def run(name,command,required=()):
 start=time.time(); log=OUT/(name+'.log'); row={'name':name,'command':command,'started_unix':start,'log':log.name}
 try:
  with log.open('wb') as stream:
   process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
   try: row['exit_code']=process.wait(timeout=1800)
   except subprocess.TimeoutExpired:
    os.killpg(process.pid,signal.SIGKILL); process.wait(); raise
 except subprocess.TimeoutExpired:
  row['exit_code']=None; row['failure']='timeout after 1800 seconds'
 data=log.read_bytes(); text=data.decode('utf-8',errors='replace')
 row.update(elapsed_seconds=time.time()-start,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 row['required_tests']={n:bool(re.search(r'^test .*'+re.escape(n)+r' \.\.\. ok$',text,re.M)) for n in required}
 row['successful']=row['exit_code']==0 and all(row['required_tests'].values())
 records.append(row); save(); print(json.dumps({'name':name,'exit_code':row['exit_code'],'successful':row['successful'],'elapsed_seconds':row['elapsed_seconds']}),flush=True)
 return row['successful']
source=['python3','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',a.expected_head]
if not run('source-before',source): raise SystemExit(1)
if not run('preflight',['bash','scripts/project-preflight.sh']): raise SystemExit(1)
if a.group=='static':
 commands=[('ci-contract',['python3','scripts/ci/check_ci_contract.py']),('ci-contract-tests',['python3','scripts/ci/test_ci_contract.py','-v']),('pq-source-contract',['python3','scripts/ci/check_pq_research_integration.py']),('pq-source-controls',['python3','scripts/ci/test_pq_research_integration.py','-v']),('readiness-controls',['python3','scripts/ci/test_public_readiness_evidence.py','-v']),('source-negative-controls',['python3','scripts/ci/test_ci_source_integrity.py','-v']),('goodput-controls',['python3','scripts/ci/test_read_validated_business_goodput.py','-v']),('repository-links-contract',['python3','scripts/ci/check_repository.py']),('repository-controls',['python3','scripts/ci/test_repository.py','-v']),('source-inventory',['python3','scripts/refresh_distributed_source_inventory.py','--check'])]
 commands.append(('retained-pr327-goodput-readback',['python3','scripts/read_validated_business_goodput.py','--bundle','evidence/pon-upgrade-implementation-20261018/native-rounds/chain-pr327-original-campaign-39694587963','--expected-manifest-sha256','12406cc156e57c130fa14af2b50b386031ec3640ce7f0234ed5bc9f0a700aac3','--expected-head','9e705ccf75b7318dcc4bda4815956f58beb10e72','--expected-tree','521ae87a28060d545979069b189eebbc74a71fd8','--retained-subset']))
 for name,command in commands: run(name,command)
else:
 run('rustc-version',[env['RUSTC'],'-Vv']); run('cargo-version',['cargo','-Vv'])
 for name,manifest,features in [('graph-default','trillionnium/Cargo.toml',[]),('graph-all-features','trillionnium/Cargo.toml',['--all-features']),('graph-fuzz-all-features','tests/fuzz/Cargo.toml',['--all-features'])]:
  run(name,['cargo','metadata','--locked','--offline','--format-version','1','--manifest-path',manifest]+features)
 run('rustfmt',['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'])
 run('strict-clippy',['cargo','clippy','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','--workspace','--all-targets','--all-features','--','-D','warnings'])
 test=['cargo','test','--locked','--offline','--config','profile.test.package.trnm-pon-node.opt-level=1','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--features','pq-native-openssl']
 suites=[('native-parent',test+['--lib','store::detached_admission::tests::','--','--test-threads=1'],['parent_qualification_requires_committed_state_after_w1_and_m06','parent_qualification_survives_cancelled_write_and_restart']),('native-pq-authentication',test+['--lib','ingress::public_v3::pq_identity::tests::','--','--test-threads=1'],['pq_authentication_unknown_survives_original_listener_close_and_cold_reopen','pq_authentication_unknown_survives_shared_classical_listener_close','pq_authentication_known_refusal_preserves_clean_listener_close','pq_authentication_unknown_survives_last_history_epoch_close']),('native-scalar',test+['--lib','ingress::public_v3::scalar_cpu::','--','--test-threads=1'],[]),('native-ordinary-owner',test+['--lib','store::operator_continuous_owner::tests::','--','--test-threads=1'],['ordinary_public_v3_clean_sole_or_last_listener_removes_original_sqlite_marker']),('native-pq-cli',test+['--test','pq_application_local_cli','--','--test-threads=1'],['ordinary_npq6_configuration_rejects_missing_null_extra_and_mixed_bindings'])]
 for name,command,required in suites: run(name,command,required)
run('source-after',source)
report['all_selected_commands_passed']=all(row['successful'] for row in records); save()
raise SystemExit(0 if report['all_selected_commands_passed'] else 1)
