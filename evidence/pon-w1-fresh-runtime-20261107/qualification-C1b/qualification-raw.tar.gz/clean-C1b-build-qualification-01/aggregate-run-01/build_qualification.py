#!/usr/bin/env python3
"""Aggregate exact C1b development evidence without replaying builds or proofs."""
import collections
import hashlib
import re
import json
import os
from pathlib import Path
import stat
import subprocess
import time

ROOT = Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
REPO = ROOT / "integration-repo"
BASE = ROOT / "clean-C1b-build-qualification-01"
OUT = Path(__file__).resolve().parent
HEAD = "0f18f93f2d35b62c6ca6d63faf4f336d55cbf4bf"
TREE = "94334bb6b52cfd13040059a5e71f47d8cc9603f2"
SOURCE_SHA = "ff53757db8a8ae10931e26993b1a4234777dce62672e46fd4e2d618ad463c8be"
GUEST_SHA = "25718312ec3c6f5219d832e3516adfb5f82983156f669c5e7daa15bd22d1798f"
R0_SHA = "2acdf550f9aca4d05b74072463e4ed307c3824309c754a5cb5f93aa84f3390e6"
IMAGE = [1958252411, 3287394615, 1805488136, 1516578702, 78549041, 790278610, 301018785, 4279049364]
MANIFESTS = {
    "backend": ("backend-validation/exact-source-0f18f93f2d35-01/manifest.json", "96c49a54374ccd491b3bbd751f506d54d1201b444cf08da7f19b326fde6c6440"),
    "native": ("clean-exact-native-verifier-0f18f93f2d35-01/manifest.json", "e5fcf8619c4b5ef9ac68cf0311a52c855e6c7fa3aeba10c863cdf21724bcfd81"),
    "owner": ("clean-C1b-build-qualification-01/owner-node-m12-01/manifest.json", "bebcfc3dd629f98abb196c5521b3ef07000628a83a841a3d17b34e2a06f02070"),
    "ci": ("integration-validation/exact-c1b-0f18f93f-01/aggregate.json", "51c2f4dfed2c828e856caa488489a00494a7f2c6a5b4e5af4c74973cbf424585"),
}
JOBS = {
    "backend": "1a1b7fb0f14-12894-ce9", "native": "1a1b7fb5200-12894-cea",
    "owner": "1a1b7faf7c7-12894-ce7", "ci": "1a1b7fa83f2-12894-ce4",
}
PREVIOUS = {
    "path": str(ROOT / "clean-C1-build-qualification-01/qualification.json"),
    "bytes": 133183, "sha256": "5b1243d0b2b623041c1a1eba1f6043c59d20e15c2b686ada2f24d179da8e84dc",
}
CACHE_PINS = {
    "backend": {"path": str(ROOT / "exact-source-cache-setups/backend-0f18f93f2d35-01/manifest.json"), "bytes": 8455,
                "sha256": "756ebe2a66791548e549ee27970b1ae08d78e7251e88c16f8e4c1ecd2a7fc47c"},
    "native": {"path": str(ROOT / "exact-source-cache-setups/native-0f18f93f2d35-01/manifest.json"), "bytes": 9104,
               "sha256": "794d36228fa91050c03d289f5e5ef67f2877eea9d055ab8f2fd572af28aa3145"},
    "owner": {"path": str(BASE / "owner-node-m12-01-cache-setup/manifest.json"), "bytes": 4403,
              "sha256": "d3d9d11f49aee36d0c4c0e5917fd2d9064193eebdd9355300523839c7f82c454"},
}



def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path, elf=False):
    p = Path(path)
    before = p.lstat()
    require(stat.S_ISREG(before.st_mode), "ordinary file required: " + str(p))
    digest = hashlib.sha256()
    with p.open("rb") as f:
        if elf:
            header = f.read(64)
            require(header[:6] == b"\x7fELF\x02\x01" and int.from_bytes(header[18:20], "little") == 62
                    and before.st_mode & 0o111, "actual executable x86_64 ELF required")
            f.seek(0)
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    after = p.lstat()
    fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    require(all(getattr(before, k) == getattr(after, k) for k in fields), "file changed while hashing")
    return {"path": str(p), "bytes": before.st_size, "sha256": digest.hexdigest()}


def check(record, elf=False):
    p = pin(record["path"], elf)
    require(p["sha256"] == record["sha256"]
            and ("bytes" not in record or p["bytes"] == record["bytes"]), "retained file pin mismatch")
    return p


def save(path, value):
    path = Path(path)
    with path.open("x") as f:
        json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
        f.write("\n"); f.flush(); os.fsync(f.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return pin(path)


def guard(row):
    path = row.get("report_path", row.get("path"))
    p = check({"path": path, "sha256": row["sha256"]})
    data = json.loads(Path(path).read_bytes())
    require(p["sha256"] == SOURCE_SHA and data["schema"] == "trnm-ci-source-v1"
            and data["kind"] == "head" and data["tested_commit"] == HEAD
            and data["candidate"] == HEAD and data["tested_tree"] == TREE
            and data["tracked_worktree_verified"] is True
            and data["tests_executed_by_identity_check"] is False, "full raw C1b source identity required")
    if "report" in row:
        require(data == row["report"], "embedded source report differs from raw report")
    return {"report_path": path, "sha256": p["sha256"], "bytes": p["bytes"],
            "tested_commit": HEAD, "tested_tree": TREE}


def normalize(name, row, manifest_pin):
    exit_code = row["exit_code"] if "exit_code" in row else row["exit"]
    require(type(exit_code) is int and exit_code == 0 and not row.get("timed_out", False)
            and row.get("error") is None and row.get("accepted", True) is True,
            "all actual constituent commands must succeed")
    require(isinstance(row["argv"], list) and row["argv"] and all(type(x) is str for x in row["argv"]),
            "raw command argv required")
    logs = {}
    for key in ("stdout", "stderr"):
        if key + ".log" in row:
            selected = row[key + ".log"]
        elif key in row and isinstance(row[key], dict):
            selected = row[key]
        else:
            selected = {"path": row[key + "_path"], "sha256": row[key + "_sha256"]}
        logs[key] = check(selected)
    return {"component": name, "label": name + "/" + row["label"], "original_label": row["label"],
            "argv": row["argv"], "cwd": row.get("cwd", str(REPO)), "exit": 0,
            "stdout_path": logs["stdout"]["path"], "stdout_sha256": logs["stdout"]["sha256"],
            "stderr_path": logs["stderr"]["path"], "stderr_sha256": logs["stderr"]["sha256"],
            "raw_component_manifest": manifest_pin}


def main():
    os.sched_setaffinity(0, {10, 11})
    attempt = {"schema": "TRNM-W1-C1B-AGGREGATE-ATTEMPT1", "source_commit": HEAD, "source_tree": TREE,
               "completed": False, "commands": [], "errors": [], "wrapper": pin(__file__),
               "fresh_proof_generations": 0, "test_bodies_executed": False}
    env = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C", "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        def run(label, argv, timeout=180):
            stdout, stderr = OUT / (label + ".stdout"), OUT / (label + ".stderr")
            with stdout.open("xb") as so, stderr.open("xb") as se:
                r = subprocess.run(argv, cwd=REPO, env=env, stdout=so, stderr=se,
                                   stdin=subprocess.DEVNULL, timeout=timeout, check=False)
                so.flush(); os.fsync(so.fileno()); se.flush(); os.fsync(se.fileno())
            row = {"label": "aggregate/" + label, "argv": argv, "cwd": str(REPO), "exit": r.returncode,
                   "stdout_path": str(stdout), "stdout_sha256": pin(stdout)["sha256"],
                   "stderr_path": str(stderr), "stderr_sha256": pin(stderr)["sha256"]}
            attempt["commands"].append(row)
            require(r.returncode == 0, label + " failed")
            return stdout, stderr

        run("preflight", ["/usr/bin/bash", "scripts/project-preflight.sh", "--dev"])
        run("source-before", ["/usr/bin/python3", "scripts/ci/verify_ci_source.py", "--kind", "head",
                             "--expected-head", HEAD, "--output", str(OUT / "source-before.json")])
        source_before = guard(pin(OUT / "source-before.json"))
        statuses = {}
        for name, job_id in JOBS.items():
            raw = OUT / ("terminal-" + name + ".json")
            value = json.loads(raw.read_bytes())
            require(value["job_id"] == job_id and value["output_complete"] is True
                    and value["output_durable"] is True and value["timed_out"] is False
                    and value["cancelled"] is False, "actual complete durable terminal required")
            require((value["state"], value["exit_code"]) == ("succeeded", 0)
                    and value["terminal_publication_confirmed"] is True
                    and value["log_errors"] == {"stdout": None, "stderr": None}
                    and value["log_synced"] == {"stdout": True, "stderr": True}
                    and value["log_truncated"] == {"stdout": False, "stderr": False},
                    "actual successful untruncated durable terminal required")
            statuses[name] = {"raw": pin(raw), "status": value}
        status_pin = save(OUT / "gate-job-statuses.json", statuses)
        manifests, manifest_pins = {}, {}
        for name, (relative, digest) in MANIFESTS.items():
            p = check({"path": str(ROOT / relative), "sha256": digest})
            value = json.loads(Path(p["path"]).read_bytes())
            if name == "ci":
                require(value["expected_head"] == HEAD and value["expected_tree"] == TREE,
                        "CI expected source identity")
            else:
                require(value["source_commit"] == HEAD and value["source_tree"] == TREE,
                        "component exact source identity")
            manifests[name], manifest_pins[name] = value, p
        b, n, o, ci = [manifests[k] for k in ("backend", "native", "owner", "ci")]
        previous_pin = check(PREVIOUS)
        previous = json.loads(Path(previous_pin["path"]).read_bytes())
        require(previous["schema"] == "TRNM-W1-CLEAN-BUILD-QUALIFICATION1"
                and previous["qualification_complete"] is True
                and previous["source_commit"] == "cb557c5e59b00ba7c6b1d40f78fbe51031a26f11"
                and previous["source_tree"] == "7971aca2ff432ec8907bb69545a2c58d70b4a215"
                and set(previous["binaries"]) == {"native_winner", "verifier", "owner_test", "runner", "r0vm"},
                "original exact C1 qualification remains immutable")
        previous_before = {role: check(row, elf=True) for role, row in previous["binaries"].items()}
        caches = {}
        for role, expected_pin in CACHE_PINS.items():
            retained = check(expected_pin)
            value = json.loads(Path(retained["path"]).read_bytes())
            require(value["cache_setup_complete"] is True and value["errors"] == []
                    and value["source_commit"] == HEAD and value["source_tree"] == TREE
                    and value["copied_cache_from_C1"] is True and value["fresh_cargo_target"] is False
                    and value["independent_reproducible_build_established"] is False
                    and value["shared_original_regular_inodes"] == 0
                    and value["original_cache_snapshot_unchanged"] is True,
                    "actual isolated copied C1 cache; no independent rebuild claim")
            if role != "owner":
                require(manifests[role]["copied_cache_setup"]["path"] == retained["path"]
                        and manifests[role]["copied_cache_setup"]["sha256"] == retained["sha256"]
                        and manifests[role]["original_C1_binaries_unchanged_after"] is True,
                        "gate bound the isolated copy and original ELF readback")
            caches[role] = {"manifest": retained, "observation": value}

        require(b["qualification_complete"] is True and b["errors"] == []
                and b["test_result"]["passed"] == 22 and b["test_result"]["failed"] == 0
                and b["test_result"]["ignored"] == 0, "backend exact gates")
        require(o["qualification_complete"] is True and o["errors"] == [] and o["fresh_cargo_target"] is False
                and o["test_counts"] == {"node_passed": 15, "node_explicit_ignored": 3, "m12_passed": 10, "m12_ignored": 0},
                "owner exact gates")
        require(ci["all_passed"] is True and ci["executed_checks"] == ci["planned_checks_including_source_after"] == 19
                and ci["source_identity_equal_before_after"] is True and ci["frozen_candidate_bytes_unchanged"] is True
                and ci["selected_test_methods_planned"] == 471 and ci["mandatory_test_methods_planned"] == 104,
                "CI exact nineteen checks and method counts")
        require(n["passed"] is True and n["source_clean_after"] is True and n["locks_unchanged"] is True
                and n["fresh_cargo_target"] is False and b["fresh_cargo_target"] is False
                and set(n["binaries"]) == {"native_winner", "verifier"}
                and n["test_counts"]["10-native-tests"] == {"groups": 26, "passed": 243, "failed": 0, "ignored": 0}
                and n["test_counts"]["12-verifier-tests"] == {"groups": 1, "passed": 2, "failed": 0, "ignored": 0},
                "current exact native/verifier gate must succeed normally")
        roster = n["strict_native_roster"]
        require(roster["count"] == 243 and roster["exact_actual_names_equal"] is True
                and roster["actual_groups"] == 26 and roster["actual_receiver_controls"] == 7,
                "strict current 243 roster and real seven receiver controls")
        roster_pin = check(roster["expected_roster"])
        roster_data = json.loads(Path(roster_pin["path"]).read_bytes())
        expected_names = collections.Counter({row["name"]: row["count"] for row in roster_data["tests"]})
        require(sum(expected_names.values()) == 243, "fixed exact native roster length")
        native_log = Path(manifest_pins["native"]["path"]).parent / "10-native-tests.stdout"
        native_text = native_log.read_text()
        actual_names = collections.Counter(line[5:-7] for line in native_text.splitlines()
                                           if line.startswith("test ") and line.endswith(" ... ok"))
        groups = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;", native_text)
        require(actual_names == expected_names and len(groups) == 26
                and all(tuple(map(int, row))[1:] == (0, 0, 0, 0) for row in groups),
                "current actual native log must equal the predeclared roster with no skipped tests")
        receiver_log = Path(manifest_pins["native"]["path"]).parent / "15-real-receiver-controls.stderr"
        receiver_text = receiver_log.read_text()
        require(re.findall(r"^Ran ([0-9]+) tests in .+$", receiver_text, re.M) == ["7"]
                and "OK" in receiver_text.splitlines(), "seven actual receiver controls")
        require(n["receiver_control_uses_historical_receipt"] is True and n["proof_launched"] is False,
                "receiver controls do not establish a fresh full proof")
        normalized = []
        source_guards = {}
        for name, expected_count in (("backend", 13), ("native", 21), ("owner", 14), ("ci", 19)):
            value = manifests[name]
            require(len(value["commands"]) == expected_count, "complete retained command set required")
            normalized.extend(normalize(name, row, manifest_pins[name]) for row in value["commands"])
            source_guards[name] = {phase: guard(value[phase]) for phase in ("source_before", "source_after")}
        for raw in ci["raw_files"]:
            check(raw)
        require(len(normalized) == 67, "exact current component command count")
        binaries = {}
        for role, row in (("native_winner", n["binaries"]["native_winner"]),
                          ("verifier", n["binaries"]["verifier"]), ("owner_test", o["binaries"]["owner_test"]),
                          ("runner", b["runner"])):
            p = check(row, elf=True)
            expected_target = Path(caches[{"native_winner": "native", "verifier": "native", "owner_test": "owner", "runner": "backend"}[role]]["observation"]["destination_target"])
            require(Path(p["path"]).is_relative_to(expected_target)
                    and p["path"] != previous_before[role]["path"], "role must use its distinct actual C1b Cargo target")
            require((Path(p["path"]).stat().st_dev, Path(p["path"]).stat().st_ino)
                    != (Path(previous_before[role]["path"]).stat().st_dev, Path(previous_before[role]["path"]).stat().st_ino),
                    "new qualified role must not share original C1 executable inode")
            binaries[role] = {**p, "kind": "repository_build", "source_commit": HEAD, "source_tree": TREE,
                              "raw_role_record": row}
        r0 = pin(ROOT / "fixed-backend-01/r0vm", elf=True)
        require(r0["sha256"] == R0_SHA and r0["bytes"] == 108764424, "fixed original upstream r0vm")
        version_out, _ = run("r0vm-version", [r0["path"], "--version"], 60)
        require(version_out.read_text().strip() == "risc0-r0vm 3.0.3", "actual fixed r0vm version")
        binaries["r0vm"] = {**r0, "kind": "fixed_upstream_release", "upstream_version": "3.0.3",
                            "version_stdout": pin(version_out), "newly_built_for_C1b": False}
        lock_paths = [
            "trillionnium/Cargo.lock", "formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock",
            "formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock",
            "formal/pon-nakamoto-v1/w1_zkvm/methods/guest/Cargo.lock",
            "formal/pon-nakamoto-v1/w1_zkvm/methods/guest-v2/Cargo.lock",
        ]
        locks = {relative: pin(REPO / relative) for relative in lock_paths}
        nb = json.loads((Path(manifest_pins["native"]["path"]).parent / "locks-before.json").read_bytes())
        na = json.loads((Path(manifest_pins["native"]["path"]).parent / "locks-after.json").read_bytes())
        require(nb == na and all(locks[k]["sha256"] == v for k, v in nb.items()), "native locks changed")
        require(o["locks_before"] == o["locks_after"]
                and locks["trillionnium/Cargo.lock"]["sha256"] == o["locks_before"]["trillionnium/Cargo.lock"]["sha256"],
                "owner lock closure")
        for relative in lock_paths:
            if relative in b["owned_source_before"]:
                require(b["owned_source_before"][relative]["sha256"] == b["owned_source_after"][relative]["sha256"]
                        == locks[relative]["sha256"], "backend lock closure")
        guest = pin(REPO / "evidence/pon-w1-full-v2-20261105/guest.bin")
        require(guest["sha256"] == GUEST_SHA and guest["bytes"] == 375928, "original retained guest bytes")
        require(b["guest_build_provenance"], "actual current build provenance required")
        for row in b["guest_build_provenance"]:
            check(row["original"]); check(row["raw_copy"]); check(row["retained_guest"]); check(row["generated_methods"])
            value = json.loads(Path(row["raw_copy"]["path"]).read_bytes())
            require(value == row["value"] and value["mode"] == "retained-v2-guest"
                    and value["sha256"] == GUEST_SHA and value["image_id"] == IMAGE
                    and value["sdk_image_checked"] is True and value["guest_compilation_performed"] is False,
                    "retained guest SDK qualification")
        guest.update(image_id=IMAGE, guest_compilation_performed=False,
                     build_provenance=b["guest_build_provenance"])
        run("source-after", ["/usr/bin/python3", "scripts/ci/verify_ci_source.py", "--kind", "head",
                            "--expected-head", HEAD, "--output", str(OUT / "source-after.json")])
        source_after = guard(pin(OUT / "source-after.json"))
        require(source_before["sha256"] == source_after["sha256"], "aggregate source changed")
        for name, p in manifest_pins.items():
            check(p)
        for row in binaries.values():
            check(row, elf=True)
        previous_after = {role: check(row, elf=True) for role, row in previous["binaries"].items()}
        require(previous_before == previous_after, "all five actual original C1 qualified ELF pins changed")
        check(previous_pin)
        for expected_pin in CACHE_PINS.values():
            check(expected_pin)
        qualification = {
            "schema": "TRNM-W1-CLEAN-BUILD-QUALIFICATION1", "source_commit": HEAD, "source_tree": TREE,
            "repo_path": str(REPO), "qualification_complete": True,
            "source_clean_before": True, "source_clean_after": True,
            "source_before": source_before, "source_after": source_after,
            "commands": normalized + attempt["commands"], "component_successful_command_count": 67,
            "aggregate_observation_command_count": len(attempt["commands"]),
            "binaries": binaries, "locks": locks, "guest": guest,
            "gate_manifests": manifest_pins, "gate_jobs": status_pin, "component_source_guards": source_guards,
            "native_current_roster": {"count": 243, "roster": roster_pin,
                                      "actual_native_run": pin(native_log), "actual_groups": 26,
                                      "actual_real_receiver_log": pin(receiver_log), "actual_real_receiver_controls": 7,
                                      "native_wrapper_passed": True, "native_wrapper_terminal": statuses["native"],
                                      "historical_receipt_used_only_for_receiver_controls": True},
            "historical_C1_qualification": {"qualification": previous_pin,
                "original_native_failed_terminal_retained": True,
                "independent_243_reassessment": previous["native_count_reassessment"],
                "scope": "Historical predecessor evidence only; this C1b native wrapper and all current commands succeeded with the fixed 243 roster."},
            "original_C1_binaries_preservation": {"observed_after_all_four_exact_gates": True,
                "before_aggregation": previous_before, "after_aggregation": previous_after,
                "all_five_pins_unchanged": True, "raw_original_qualification": previous_pin},
            "test_methods_reported": {"backend": 22, "native": 243, "verifier": 2, "real_receiver_controls": 7,
                                      "node": 15, "m12": 10, "ci": 471, "sum": 770,
                                      "owner_heavy_entries_explicitly_ignored": 3},
            "fresh_cargo_target": False,
            "fresh_cargo_target_basis": "All three build targets were independent inode copies of qualified C1 caches; actual Cargo artifact fresh/rebuilt fields remain in each component manifest. This is not an independent rebuild.",
            "target_observations": {
                "native": {"path": n["target_dir"], "fresh_cargo_target": False,
                           "copied_cache_setup": caches["native"], "actual_binaries": n["binaries"]},
                "owner": {"path": o["target"], "fresh_cargo_target": False,
                          "copied_cache_setup": caches["owner"], "actual_binaries": o["binaries"]},
                "backend": {"path": b["target_dir"], "fresh_cargo_target": False,
                            "copied_cache_setup": caches["backend"],
                            "owned_release_fingerprint_observation_before": b["cargo_fingerprints_before"],
                            "cargo_artifact_fresh_rebuilt_readback": b["cargo_json_artifacts"]}
            },
            "fresh_proof_generations": 0, "guest_compilation_performed": False,
            "independent_reproducible_build_established": False, "original_business_budget_qualified": False,
            "security_qualified": False, "production_qualified": False, "payment_qualified": False,
            "complete_process_tree_resource_accounting_qualified": False,
            "scope": "Exact C1b source/build identities and retained development gates only. No new full proof, deployment, original business-budget, full resource-accounting, payment or cryptographic-security qualification.",
            "aggregate_wrapper": pin(__file__), "observed_monotonic_ns": time.monotonic_ns(),
        }
        require(set(binaries) == {"owner_test", "native_winner", "runner", "verifier", "r0vm"}, "exact five roles")
        qpin = save(BASE / "qualification.json", qualification)
        attempt.update(completed=True, qualification=qpin)
    except BaseException as exc:
        attempt["errors"].append({"type": type(exc).__name__, "message": str(exc)})
    attempt["completed_monotonic_ns"] = time.monotonic_ns()
    record = save(OUT / "result.json", attempt)
    print(json.dumps({"completed": attempt["completed"], "result": record,
                      "qualification": attempt.get("qualification"), "errors": attempt["errors"]}), flush=True)
    return 0 if attempt["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

