# Physical resource cost audit

## Implemented correction

`physical_estimate()` is a callable direct estimator. Its former validation checked dictionary keys and nonnegative bounded integer types but omitted the Circuit count/depth and gate-subtotal invariants. The original control accepted all five malformed cases. In particular, 100 non-T gates with gate_depth=0 returned CONDITIONAL_ESTIMATE, allocated_code_cycles_per_instance=0 and quantum_wall_seconds_serial_magic_delivery_schedule="0".

The fix factors the existing arithmetic shape checks into `_validate_count_shape()` and uses it in both Circuit.validate() and physical_estimate(). It rejects nonzero-count/zero-depth pairs, depths above their counts, Toffoli+direct-T counts above the total gate count, and component depths above total depth. Stages retain the uint64 bound; aggregate workloads retain MAX_DERIVED. Zero-gate empty stages remain supported. No new circuit compilation or physical-layout assumptions were added.

The defect affected callers of the direct Python estimator. The complete Request/account and JSON entry paths already validated Circuit input and are not claimed to have accepted the malformed stage inputs.

## Evidence

- before_physical_counts.log: untouched original control, five malformed inputs accepted; nonempty-zero-depth returned zero cycles/time; process exit 1.
- after_physical_counts.log: identical control after fix, every malformed input rejected; process exit 0.
- control_physical_counts.py: repeatable standalone negative control with source SHA256.
- unittest.log: 54 tests passed in 2.179 s (`test_quantum_oracle_resources`, `test_quantum_resource_clock`, `test_quantum_candidate_check_clock`). Includes three new tests with ten malformed direct-input subcases, a valid serial aggregate > uint64, and a valid empty stage.
- diff-check.log: git diff --check passed, empty output.

## Added width/depth consistency correction

Cross-review by quantum_paper_review and root identified a second reproducible invalid schedule through the normal Request/account entry path: 100 gates on one logical wire with depth one was accepted, as was a Toffoli on two wires. The pre-fix `before_width_depth.log` preserves five accepted impossible schedules; `after_width_depth.log` rejects all five through the same control.

The shared validator now also enforces necessary bounds for the declared X/CNOT/Toffoli/T schedule:

- gate_count + 2*toffoli_count <= logical_qubits*gate_depth, because each gate occupies at least one wire and each Toffoli three;
- toffoli_count <= floor(logical_qubits/3)*toffoli_depth;
- direct_t_count <= logical_qubits*direct_t_depth.

This preserves conservative depth upper bounds: increasing a valid schedule's depth does not violate a width bound. Gate counts and depth refer to the same declared schedule, as the existing subtotal and nonzero count/depth checks already required. Independently loose ceilings cannot be substituted for a consistent schedule budget. The constructor uses actual wrapped gate counts with conservative depth upper bounds and continues to pass the tested path. CNOT's extra wire occupancy cannot be derived from this schema and is deliberately not invented, so these are necessary, permissive consistency bounds rather than sufficient circuit verification.

The old exact magic-budget headroom witness used 10^60+1 T gates, depth 1, and one wire. It now uses a valid serial one-wire schedule with matching aggregate depth; exact positive headroom still remains below the report precision and the test passes. Additional controls accept serial single-wire gates, parallel disjoint Toffolis, parallel T gates and mixed Toffoli/T gates.

Final targeted suite: 55 tests passed (`unittest-final-source.log`); final controls passed and final diff check passed. The earlier 54-test log is preserved as the first-fix checkpoint, not overwritten.

## Other reviewed boundaries

Existing distance selection compares exact Fraction expressions, including total-failure equality, an above-budget Pell-number control lost at Decimal precision 100, and positive magic-budget headroom smaller than the report precision. The existing tests all passed. Standalone resource output remains explicitly an estimate rounded to 30 significant digits; it is not used to select code distance. The resource-clock certificate rounds its printable failure upper estimates with ROUND_CEILING, and exact quantum clocks to binary float upward.

The campaign binding charges prepare/reset per trial, forward and inverse winner computation per iteration, all independent processors and their factories, and a whole-campaign conservative start/iteration envelope. It explicitly replaces the caller's narrower workload. Candidate checks are charged for every completed measured candidate, including failed and zero-iteration trials, while no check is charged before completed readout; the tests exercised cancellation, censoring, and exact binary phase boundaries.

Failure coverage remains conditional: coherent data-stage cycles plus stipulated per-T residual faults. Initialization/reset/readout and classical controller failures remain idealized or out of scope; this does not establish an end-to-end machine failure bound. Data access and persistent register costs are caller/construction premises; shared task preprocessing in the standalone ledger is replaced by repeated per-trial preprocessing in the event binding. No real hardware, complete W1 unrestricted oracle, calibrated same-budget quantum superiority, or executable production fork attack is established.

## Files modified

- formal/pon-nakamoto-v1/quantum_oracle_resources.py
- formal/pon-nakamoto-v1/test_quantum_oracle_resources.py

No other repository files edited by this agent. No commit or push performed. Native, CUDA and long campaigns were not run.
