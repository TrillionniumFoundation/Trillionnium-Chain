#!/usr/bin/env python3
"""Build the exact new Hepta native targets; this is never a test pass."""
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

import run_new_pair as run


def main():
    base = Path(__file__).resolve().parent
    root, target, out = base / "source", base / "target", base / "build-01"
    out.mkdir(mode=0o700, exist_ok=False)
    record = {"expected_hepta_sha": run.HEPTA_SHA, "native_tests_executed": False,
              "build_only": True, "historical_results_reused": False, "started_ns": time.time_ns(),
              "exit_code": 99}
    before = None
    try:
        record["resources_before"] = run.resources()
        run.check_envelope(record["resources_before"])
        before = run.source(root, out / "source-before.manifest.json.gz")
        record["source_before"] = before
        record["profile"] = run.digest(root / "codex-rs/.config/nextest.toml")
        run.require(record["profile"]["sha256"] == run.PROFILE_SHA, "original nextest profile differs")
        names = json.loads((base / "learning39.json").read_text())
        run.require(run.digest(base / "learning39.json")["sha256"] == run.ROSTERS[0][2], "roster differs")
        command = [str(run.TOOLS / "just"), "test", "--no-run", "--locked",
                   "-p", "codex-hepta-learning-artifacts", "-p", "codex-hepta-agentd", "--lib",
                   "-E", " | ".join("test(=" + name + ")" for name in names)]
        env = os.environ.copy()
        env.update(CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS="2", CARGO_INCREMENTAL="0",
                   CARGO_PROFILE_DEV_DEBUG="0", CARGO_PROFILE_TEST_DEBUG="0", LIBCLANG_PATH="/usr/lib/llvm-21/lib",
                   NEXTEST_PROFILE="local", NEXTEST_TEST_THREADS="2", RUSTUP_TOOLCHAIN="1.96.0",
                   RUST_MIN_STACK="8388608", PYTHONDONTWRITEBYTECODE="1",
                   PATH=f"{run.RUST}:{run.TOOLS}:/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin")
        record.update(command=command, runner=run.digest(__file__), shared_wrapper=run.digest(run.__file__),
                      source_collector=run.digest(run.identity.__file__), binary_before=run.binaries(target))
        run.write_new(out / "start.json", record)
        print(json.dumps({"event": "build_started", "source": before["source"],
                          "tracked_entries": before["observation"]["tracked_entries"],
                          "tracked_bytes": before["observation"]["tracked_bytes"]}), flush=True)
        started = time.monotonic()
        with (out / "build.stdout").open("x") as stream:
            process = subprocess.run(command, cwd=root / "codex-rs", env=env,
                                     stdout=stream, stderr=subprocess.STDOUT)
        record.update(exit_code=process.returncode, wall_seconds=time.monotonic() - started,
                      log=run.digest(out / "build.stdout"), binary_after=run.binaries(target))
    except Exception as exc:
        record["error"] = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
    finally:
        try:
            record["resources_after"] = run.resources()
            after = run.source(root, out / "source-after.manifest.json.gz")
            record["source_after"] = after
            record["source_unchanged"] = before is not None and run.stable_source(before) == run.stable_source(after)
            if not record["source_unchanged"]:
                record["exit_code"] = record["exit_code"] or 99
        except Exception as exc:
            record["final_observation_error"] = str(exc)
            record["exit_code"] = record["exit_code"] or 99
        record["finished_ns"] = time.time_ns()
        run.write_new(out / "result.json", record)
        print(json.dumps({"event": "build_finished", "exit_code": record["exit_code"],
                          "error": record.get("error"), "source_unchanged": record.get("source_unchanged")}), flush=True)
    return record["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
