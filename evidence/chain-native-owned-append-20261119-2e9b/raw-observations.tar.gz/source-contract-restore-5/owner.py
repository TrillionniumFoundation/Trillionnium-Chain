from pathlib import Path
import subprocess,json,time,resource,hashlib,sys,traceback
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=s.parent/'source-contract-restore-5';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);head='f0a8364118df01113c14d6a81fbb6fdb6210e4ff';prefix='evidence/pon-w1-qrom-semantics-20261107';res={'schema':'chain-original-git-input-restoration-v1','source_head':head,'prefix':prefix,'restored':[],'existing_verified':[],'complete':False};t=time.monotonic();c=resource.getrusage(resource.RUSAGE_CHILDREN)
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
try:
 with (out/'preflight.log').open('xb') as f:rc=subprocess.call(['bash','scripts/project-preflight.sh'],cwd=s,stdout=f,stderr=subprocess.STDOUT)
 assert rc==0 and subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==head
 listing=subprocess.check_output(['git','ls-tree','-r',head,'--',prefix],cwd=s,text=True);(out/'tree.txt').write_text(listing)
 for line in listing.splitlines():
  metadata,rel=line.split('\t',1);mode,kind,oid=metadata.split();assert kind=='blob' and mode in ('100644','100755')
  raw=subprocess.check_output(['git','cat-file','blob',oid],cwd=s);assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid
  p=s/rel;row={'path':rel,'git_blob':oid,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  if p.exists():
   assert p.read_bytes()==raw,rel;res['existing_verified'].append(row)
  else:
   p.parent.mkdir(parents=True,exist_ok=True)
   with p.open('xb') as f:f.write(raw)
   if mode=='100755':p.chmod(0o755)
   res['restored'].append(row)
  save()
 a=resource.getrusage(resource.RUSAGE_CHILDREN);res.update(complete=True,wall_seconds=time.monotonic()-t,child_user_cpu_seconds=a.ru_utime-c.ru_utime,child_system_cpu_seconds=a.ru_stime-c.ru_stime);save();print(json.dumps(res,indent=2))
except BaseException as e:res['error']=repr(e);save();traceback.print_exc();raise
