# M15 native regression repair

This note accompanies uncommitted source changes in four release_owner files.
It does not claim native Rust execution. Parent integration owns exact-source
native test, formatting, Clippy and complete regression receipts.

## Root cold proof replay

The retained original failure was `invalid type: string "1", expected u8`
inside State::replay. Root.roles is BTreeMap<u8, Keys>, while Publication and
Record use internally tagged Serde enums. serde_json normally parses numeric
object keys using its MapKeyDeserializer. Tagged-enum content buffering retains
those keys as strings, and Serde's ContentDeserializer does not perform that
JSON-specific conversion. Both layers have to retain the same canonical bytes.

The repair adds a field-level deserializer for exact role names "1" through "4".
It consumes MapAccess directly and rejects duplicates before insertion, so no
serde_json::Value conversion can discard a duplicate. Noncanonical aliases and
unknown names are refused. The original integer BTreeMap serializer, root
kernel validation, v1 record hash domains and stored schemas remain unchanged.
The existing real dual-quorum cold-replay test is retained. New tests check bare
Root, Publication and Record round trips with byte/digest identity, and direct
nested rejection of duplicates, numeric aliases and unknown roles.

Primary source documenting the same Serde mechanism:
https://github.com/serde-rs/json/issues/560
https://github.com/serde-rs/serde/blob/master/serde/src/private/de.rs

## Sealed memfd identity failure

The retained original failure occurs at the final identity/seal check after a
write was correctly refused. An independent local syscall probe on kernel
6.18.57 reproduces the exact causal distinction: pwrite on a sealed O_RDWR memfd
returns EPERM and changes mtime/ctime, while inode, mode, size, seals and SHA256
remain unchanged. Shrink, grow and executable-mode changes also fail; the write
operation caused the timestamp change in this run. The Python fcntl module does
not export the seal constants in this environment; the retained probe uses the
exact Linux UAPI constants from the installed headers.

The repair retains every existing timestamp/identity check. After validating
seals and SHA256, it opens an O_PATH reference to the held descriptor, checks a
regular file, reopens that held object O_RDONLY | O_NONBLOCK | O_CLOEXEC, and
checks full identity. A safe rustix dup3 atomically replaces the still-owned fd
with the read-only description under CLOEXEC. This preserves DataBuilder's
already-reserved numeric descriptor in LaunchAttempt and avoids a close/open
allocation window. Both descriptors remain owned until replacement finishes.
Failure drops owned descriptors and returns an error; there is no writable or
pathname-execution fallback.

Recheck now also requires read-only access. It continues requiring device,
inode, size, uid, mode, mtime, ctime and all five required seals. Source-file
identity handling is untouched. Existing mutation-rejection tests remain, with
checks after each denied operation. New controls verify reserved descriptor
identity, O_RDONLY, CLOEXEC until explicit exec handoff, inherited readback,
and refusal after an allowed non-executable permission mutation. Timestamps
are never reset or ignored to make a failed observation pass.

The independent Python read-only probe performs the same descriptor downgrade
semantics and sees writes/shrink/grow/executable chmod all refused, with complete
stored identity unchanged. This is Linux syscall evidence, not native Node
execution. It is retained separately from the prior ROG failures.

## Native validation commands for parent

Run the repository preflight and the declared existing Rust/OpenSSL environment.

```sh
cargo test --locked --offline --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib --all-features release_owner::root_separation_tests:: -- --nocapture --test-threads=1
cargo test --locked --offline --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib --all-features release_owner::sealed_tests:: -- --nocapture --test-threads=1
```

Expected inventory: six root-separation tests and seven sealed-object tests.
Successful target tests alone do not establish a green complete Node regression.
