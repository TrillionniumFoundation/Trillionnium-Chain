#!/usr/bin/python3
"""Exact-byte candidate parser regression; zero proof/funding operations."""
import ast
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import unittest

ROOT = Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
REPO = ROOT / "integration-repo"
OUT = ROOT / "owner-capacity-repair-01/candidate-tests-01"
COMMIT = "cb557c5e59b00ba7c6b1d40f78fbe51031a26f11"
TREE = "7971aca2ff432ec8907bb69545a2c58d70b4a215"
BASELINE = [{"rel":"scripts/w1_generation_target_v2.py","bytes":25002,"sha256":"fa67f19f6a5d2cf1a13f339aa14fb8cf2fcbb6eab70ce9749bb027e4399aba29"},{"rel":"scripts/w1_owned_generation_runtime_v2.py","bytes":38913,"sha256":"500f2712942ff2e5f46e82cb2fb1a5d514be55a9ca6e851b7cede79374c15119"},{"rel":"scripts/w1_owner_cancellation_v1.py","bytes":19812,"sha256":"b3ba7bfe226e66cc18419e89eec87ef8e383cab434970d4e1ca4b50003ffcf2b"},{"rel":"scripts/test_w1_generation_target_v2.py","bytes":11180,"sha256":"d654e737aaec99cfa8928bb8fa1fe04706c43894f53bad9be52ebc94038de5d9"},{"rel":"scripts/test_w1_owned_generation_runtime_v2.py","bytes":5979,"sha256":"e17cbe7edc2bfa86599e90c6405a852eb023a6eb65642bd9fdffc65558528701"},{"rel":"scripts/test_w1_owner_cancellation_v1.py","bytes":6394,"sha256":"523d0cbcf5f8de5e7c28ce3308c5480004b695c85ff44a04fa1ea01a0b6521ff"}]
CANDIDATE = [{"rel":"scripts/test_w1_generation_target_v2.py","bytes":21466,"sha256":"ececf1fbe647358c4ef0efc531e85df02d3820fb2827d4d4762d45d831ec2138"},{"rel":"scripts/test_w1_owned_generation_runtime_v2.py","bytes":8831,"sha256":"fc14dca6a2e950b8d404b2fea6a6b72754a97972778e69a5f4422d181248f442"},{"rel":"scripts/test_w1_owner_cancellation_v1.py","bytes":12184,"sha256":"8bb29370073d9681a9a6393b0b8ce8f08dc9ee554ecfa01c612228a8badf4d80"},{"rel":"scripts/w1_generation_target_v2.py","bytes":26876,"sha256":"b82961b18d5ea15b05a8763008456e818766d24304442cb7a93ba3be527335ee"},{"rel":"scripts/w1_owned_generation_runtime_v2.py","bytes":38944,"sha256":"f2bc49081a0bc08d88e7c1337c2c8bc512f9b968f0334cd6c5d68f9e2e052297"},{"rel":"scripts/w1_owner_cancellation_v1.py","bytes":20764,"sha256":"94f0a3f6de92ee6fa1abba41097da7bae4b44b3328487f7a7a8f43943f448207"}]
EXPECTED = {"test_w1_generation_target_v2.py": 13, "test_w1_owned_generation_runtime_v2.py": 7,
            "test_w1_owner_cancellation_v1.py": 7}
MANIFEST = {"schema": "TRNM-W1-CAPACITY-REPAIR-CANDIDATE1", "base_commit": COMMIT,
            "base_tree": TREE, "candidate_is_committed": False, "commands": [],
            "fresh_proofs": 0, "funding_operations": 0, "original_operation_redispatched": False}

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save_bytes(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}

def save(path, value):
    return save_bytes(path, (json.dumps(value, sort_keys=True, indent=2) + "\n").encode())

def run(label, argv, timeout=90):
    result = subprocess.run(argv, cwd=REPO, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    row = {"label": label, "argv": argv, "exit": result.returncode,
           "stdout": save_bytes(OUT / label / "stdout.log", result.stdout),
           "stderr": save_bytes(OUT / label / "stderr.log", result.stderr)}
    MANIFEST["commands"].append(row)
    require(result.returncode == 0, label + " failed")
    return result

def current():
    result = {}
    for expected in CANDIDATE:
        raw = (REPO / expected["rel"]).read_bytes()
        require((len(raw), sha(raw)) == (expected["bytes"], expected["sha256"]),
                "candidate source changed: " + expected["rel"])
        result[expected["rel"]] = {"bytes": len(raw), "sha256": sha(raw)}
    return result

def functions(raw):
    text = raw.decode()
    return {node.name: ast.get_source_segment(text, node) for node in ast.parse(text).body
            if isinstance(node, ast.FunctionDef)}

def constants(raw):
    return {node.targets[0].id: ast.literal_eval(node.value) for node in ast.parse(raw).body
            if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id in {"NAMESPACE", "APPLICATION_ID", "META_SQL", "OPS_SQL", "MAX_RESULT"}}

def names(suite):
    result = []
    for case in suite:
        result.extend(names(case) if isinstance(case, unittest.TestSuite) else [case.id()])
    return result

def execute():
    require(sorted(os.sched_getaffinity(0)) == [20, 21], "actual test affinity changed")
    membership = Path("/proc/self/cgroup").read_text().strip()
    require(membership.startswith("0::/") and "\n" not in membership, "actual test cgroup unknown")
    group = Path("/sys/fs/cgroup") / membership[3:].lstrip("/")
    resource = {"affinity": sorted(os.sched_getaffinity(0)), "membership": membership,
                "cpu_max": (group / "cpu.max").read_text().strip(),
                "memory_max": (group / "memory.max").read_text().strip()}
    quota, period = resource["cpu_max"].split()
    require(quota != "max" and int(quota) == 2 * int(period)
            and resource["memory_max"] == "8589934592", "actual test resource limits changed")
    MANIFEST["resources"] = save(OUT / "resources.json", resource)
    require(run("head", ["/usr/bin/git", "rev-parse", "HEAD"]).stdout.decode().strip() == COMMIT, "base commit changed")
    require(run("tree", ["/usr/bin/git", "rev-parse", "HEAD^{tree}"]).stdout.decode().strip() == TREE, "base tree changed")
    run("preflight", ["/bin/bash", "scripts/project-preflight.sh", "--dev"])
    MANIFEST["source_before"] = current()
    for expected in BASELINE:
        raw = run("baseline-" + Path(expected["rel"]).name,
                  ["/usr/bin/git", "show", COMMIT + ":" + expected["rel"]]).stdout
        require((len(raw), sha(raw)) == (expected["bytes"], expected["sha256"]), "baseline exact bytes changed")
        save_bytes(OUT / "baseline" / expected["rel"], raw)
        save_bytes(OUT / "candidate" / expected["rel"], (REPO / expected["rel"]).read_bytes())
    old_target = (OUT / "baseline/scripts/w1_generation_target_v2.py").read_bytes()
    new_target = (REPO / "scripts/w1_generation_target_v2.py").read_bytes()
    require(constants(old_target) == constants(new_target), "V2 namespace/SQL/result policy changed")
    before_fn, after_fn = functions(old_target), functions(new_target)
    for name in ("canonical", "sha", "clock_domain", "open_db", "read_operation"):
        require(before_fn[name] == after_fn[name], "retained V2 encoding/readback changed: " + name)
    MANIFEST["unchanged_v2_functions"] = ["canonical", "sha", "clock_domain", "open_db", "read_operation"]
    MANIFEST["unchanged_v2_constants"] = constants(old_target)
    sys.path.insert(0, str(REPO / "scripts"))
    import w1_generation_target_v2 as target
    require(target.MAX_REQUEST == 131072, "explicit inbound raw cap")
    enumerated = {}
    for pattern, count in EXPECTED.items():
        suite = unittest.defaultTestLoader.discover(str(REPO / "scripts"), pattern=pattern)
        entries = names(suite)
        require(len(entries) == count and len(set(entries)) == count, "test enumeration/count changed")
        enumerated[pattern] = entries
    MANIFEST["test_enumeration"] = save(OUT / "test-enumeration.json", enumerated)
    for pattern, count in EXPECTED.items():
        result = run("test-" + pattern, ["/usr/bin/python3", "-B", "-m", "unittest", "discover",
                                       "-s", "scripts", "-p", pattern, "-v"])
        stderr = result.stderr.decode()
        require(re.search(r"\bRan " + str(count) + r" tests in ", stderr) and stderr.rstrip().endswith("OK")
                and "skipped" not in stderr.lower(), "actual test count/skip guard")
    original = ROOT / "owner-cancel-run-01/target-request.json"
    with original.open("rb") as stream:
        historical_raw = stream.read(target.MAX_REQUEST + 1)
    require(len(historical_raw) == 68909
            and sha(historical_raw) == "eff76555c5166818cbf7b833e12c43d315f6fd6bb684d8031f09e70982910071",
            "original failed request changed")
    historical = json.loads(historical_raw.decode("utf-8"))
    compact = target.canonical(historical)
    require(len(compact) == 66550
            and sha(compact) == "aa45f127e085302cd25ee9dc11518919a97242fabe9f0bbd69cc74dc39058dca",
            "original compact bytes/digest changed")
    try:
        target.load_request(original, historical["target_instance"], check_clock=False)
    except ValueError as exc:
        require(str(exc) == "target backend source pin", "wrong original request rejection: " + str(exc))
        rejection = str(exc)
    else:
        raise ValueError("old source-pinned request incorrectly accepted as new executable input")
    require(not (ROOT / "owner-cancel-local-target-01").exists()
            and not (ROOT / "owner-cancel-run-01/proof").exists(), "original failure boundary changed")
    MANIFEST["original_failed_request_regression"] = save(OUT / "original-failure-readback.json", {
        "path": str(original), "raw_bytes": len(historical_raw), "raw_sha256": sha(historical_raw),
        "canonical_bytes": len(compact), "canonical_sha256": sha(compact), "file_pin_count": len(historical["file_pins"]),
        "current_source_binding_rejected": rejection, "accepted_for_execution": False,
        "original_target_root_absent": True, "original_proof_directory_absent": True,
        "original_request_not_modified": sha(original.read_bytes()) == sha(historical_raw),
        "new_proofs": 0, "original_operation_restarted": False})
    save_bytes(OUT / "original-failed-request-exact-copy.json", historical_raw)
    diff = run("diff", ["/usr/bin/git", "diff", "--binary", COMMIT, "--",
                       *[x["rel"] for x in CANDIDATE]]).stdout
    MANIFEST["patch"] = save_bytes(OUT / "candidate.patch", diff)
    MANIFEST["counts"] = EXPECTED
    MANIFEST["passed"] = True

OUT.mkdir(parents=True, exist_ok=False)
try:
    execute()
except BaseException as exc:
    MANIFEST["passed"] = False
    MANIFEST["error"] = f"{type(exc).__name__}: {exc}"
finally:
    try:
        MANIFEST["source_after"] = current()
        require(MANIFEST.get("source_before") == MANIFEST["source_after"], "source changed during tests")
    except BaseException as exc:
        MANIFEST["passed"] = False
        MANIFEST["source_after_error"] = f"{type(exc).__name__}: {exc}"
    record = save(OUT / "manifest.json", MANIFEST)
    print(json.dumps({"passed": MANIFEST["passed"], "manifest": record,
                      "counts": MANIFEST.get("counts"), "new_proofs": 0}), flush=True)
raise SystemExit(0 if MANIFEST["passed"] else 1)
