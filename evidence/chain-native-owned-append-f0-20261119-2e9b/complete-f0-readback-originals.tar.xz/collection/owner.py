from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import json,subprocess,time,resource,hashlib,sys,traceback,zipfile,stat
root=Path('/home/qian-qi/work/chain-native-owned-append-f0-20261119-2e9b');out=root/'collection';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);repo='TrillionniumFoundation/Trillionnium-Chain';head='e8b0ec93ab6a6a1ff5e36cfcf9d1179e030a5975';rid=44465153982
res={'schema':'chain-sole-owned-append-f0-collection-v1','head':head,'run_id':rid,'run_attempt':1,'complete_download':False,'business_reexecuted':False,'requests':[],'money':None};start=time.monotonic();self0=resource.getrusage(resource.RUSAGE_SELF)
def sha(data):return hashlib.sha256(data).hexdigest()
def save():(out/'COLLECTION.json').write_text(json.dumps(res,indent=2)+'\n')
def api(name,endpoint,binary=False):
 path=out/(name+('.zip' if binary else '.stdout'));err=out/(name+'.stderr');t=time.monotonic();c=resource.getrusage(resource.RUSAGE_CHILDREN);utc=datetime.now(timezone.utc).isoformat()
 with path.open('xb') as a,err.open('xb') as b:rc=subprocess.call(['/usr/bin/gh','api',endpoint],stdout=a,stderr=b)
 d=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'endpoint':endpoint,'started_utc':utc,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':d.ru_utime-c.ru_utime,'child_system_cpu_seconds':d.ru_stime-c.ru_stime,'stdout_bytes':path.stat().st_size,'stdout_sha256':sha(path.read_bytes()),'stderr_bytes':err.stat().st_size,'stderr_sha256':sha(err.read_bytes())};res['requests'].append(row);save()
 if rc:raise RuntimeError('read-only API failed '+name+'; no business rerun')
 return path
def pages(name,endpoint,key):
 items=[]
 for p in range(1,30):
  f=api(name+'-page-'+str(p),endpoint+('&' if '?' in endpoint else '?')+'per_page=100&page='+str(p));data=json.loads(f.read_text());items+=data[key]
  if len(items)>=data['total_count']:
   assert len(items)==data['total_count'];return items
 raise RuntimeError('read pagination limit')
try:
 for n in range(360):
  run=json.loads(api('run-'+str(n),'repos/'+repo+'/actions/runs/'+str(rid)).read_text())
  assert run['head_sha']==head and run['run_attempt']==1 and run['id']==rid
  res['run']={k:run.get(k) for k in ('id','head_sha','head_branch','run_attempt','event','path','status','conclusion','created_at','updated_at','html_url')};save()
  jobs=pages('jobs-'+str(n),'repos/'+repo+'/actions/runs/'+str(rid)+'/jobs?filter=all','jobs') if n%3==0 or run['status']=='completed' else []
  print(json.dumps({'f0_poll':n,'run_id':rid,'status':run['status'],'conclusion':run['conclusion'],'jobs':[{'id':j['id'],'status':j['status'],'conclusion':j['conclusion'],'active_steps':[x['name'] for x in j.get('steps',[]) if x['status']=='in_progress']} for j in jobs],'observed_utc':datetime.now(timezone.utc).isoformat()}),flush=True)
  if run['status']=='completed':break
  time.sleep(20)
 else:raise RuntimeError('observation bound reached; original run was not repeated')
 res['jobs']=jobs
 res['artifacts']=pages('artifacts','repos/'+repo+'/actions/runs/'+str(rid)+'/artifacts','artifacts')
 res['timing']=json.loads(api('timing','repos/'+repo+'/actions/runs/'+str(rid)+'/timing').read_text())
 for job in jobs:api('job-'+str(job['id'])+'-log','repos/'+repo+'/actions/jobs/'+str(job['id'])+'/logs')
 selected=[x for x in res['artifacts'] if head in x['name'] and x['name'].startswith('pon-fixed-host-root-f0-')]
 assert len(selected)==1 and not selected[0]['expired'];artifact=selected[0]
 zpath=api('artifact-'+str(artifact['id']),'repos/'+repo+'/actions/artifacts/'+str(artifact['id'])+'/zip',binary=True)
 ziphash=sha(zpath.read_bytes());expected=artifact.get('digest')
 assert expected is None or expected=='sha256:'+ziphash,(expected,ziphash)
 dest=out/('artifact-'+str(artifact['id']));dest.mkdir(exist_ok=False);members=[]
 with zipfile.ZipFile(zpath) as z:
  entries=z.infolist();assert len(entries)<=10000 and sum(i.file_size for i in entries)<=2*1024**3
  seen=set()
  for entry in entries:
   p=PurePosixPath(entry.filename);assert not p.is_absolute() and '..' not in p.parts and '\x00' not in entry.filename and entry.filename not in seen;seen.add(entry.filename)
   mode=entry.external_attr>>16;assert stat.S_IFMT(mode) in (0,stat.S_IFREG,stat.S_IFDIR)
   target=dest.joinpath(*p.parts)
   if entry.is_dir():target.mkdir(parents=True,exist_ok=True);continue
   target.parent.mkdir(parents=True,exist_ok=True);raw=z.read(entry)
   with target.open('xb') as f:f.write(raw)
   members.append({'path':entry.filename,'bytes':len(raw),'sha256':sha(raw)})
 manifest=json.loads((dest/'artifact-files.json').read_text());assert manifest['errors']==[] and manifest['all_files_retained'] is True
 observed={x['path']:x for x in members}
 for item in manifest['files']:
  assert item['path'] in observed and observed[item['path']]['bytes']==item['bytes'] and observed[item['path']]['sha256']==item['sha256'],item['path']
 assert set(observed)=={x['path'] for x in manifest['files']}|{'artifact-files.json'}
 res.update(artifact_id=artifact['id'],artifact_zip=str(zpath),artifact_zip_bytes=zpath.stat().st_size,artifact_zip_sha256=ziphash,provider_digest_verified=expected is not None,artifact_root=str(dest),zip_members=len(members),manifest_members=len(manifest['files']),every_manifest_member_verified=True,complete_download=True,wall_seconds=time.monotonic()-start)
 self1=resource.getrusage(resource.RUSAGE_SELF);res['collector_self_user_cpu_seconds']=self1.ru_utime-self0.ru_utime;res['collector_self_system_cpu_seconds']=self1.ru_stime-self0.ru_stime;save();print(json.dumps({'collection_complete':True,'run_id':rid,'conclusion':run['conclusion'],'artifact_id':artifact['id'],'zip_bytes':res['artifact_zip_bytes'],'zip_sha256':ziphash,'manifest_members':len(manifest['files'])}),flush=True)
except BaseException as e:res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
