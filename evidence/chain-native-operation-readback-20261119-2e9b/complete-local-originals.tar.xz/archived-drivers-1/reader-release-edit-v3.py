from pathlib import Path
import json,subprocess,hashlib
base=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b');src=base/'source';out=base/'completed-graph-edit-3';out.mkdir(exist_ok=False)
previous=json.loads((base/'native-validation-2/RESULT.json').read_text())
assert previous['source_unchanged'] and previous['native_authenticated_passed'] is False
assert previous['stages'][-1]['exit_code']==101
assert "error[E0505]" in (base/'native-validation-2/native-authenticated.stderr').read_text()
assert hashlib.sha256(subprocess.check_output(['git','diff','--binary'],cwd=src)).hexdigest()==previous['source_patch_sha256']
with (out/'preflight.stdout').open('xb') as so,(out/'preflight.stderr').open('xb') as se:r=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=src,stdout=so,stderr=se)
assert r.returncode==0
p=src/'trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_scoped_readback.rs';s=p.read_text();old='    Ok(VerifiedGraph {\n';assert s.count(old)==1
s=s.replace(old,'    // Release the actual SQL cursor before moving the original owner marker.\n    // The same reader was always dropped before the caller\'s final callback.\n    drop(reader);\n'+old)
p.write_text(s)
with (out/'fmt.stdout').open('xb') as so,(out/'fmt.stderr').open('xb') as se:r=subprocess.run(['/home/qq/.cargo/bin/cargo','+1.95.0','fmt','--manifest-path','trillionnium/Cargo.toml','--all'],cwd=src,stdout=so,stderr=se)
assert r.returncode==0
res={}
for kind,extra in [('candidate',[]),('production',['--','trillionnium/crates/trnm-pon-node/src/store/native_authenticated.rs','trillionnium/crates/trnm-pon-node/src/store/native_authenticated/post_write_readback.rs','trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_scoped_readback.rs'])]:
 raw=subprocess.check_output(['git','diff','--binary']+extra,cwd=src);(out/(kind+'.patch')).write_bytes(raw);res[kind]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
res['compiler_failure_preserved']='native-validation-2/RESULT.json'
(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res),flush=True)
