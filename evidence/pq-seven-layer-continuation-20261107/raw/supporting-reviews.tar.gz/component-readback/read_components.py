#!/usr/bin/env python3
"""Read frozen build/static-check records; never run native/product commands."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tomllib

HEAD = "e36cfb88956a0e35e53d74c5ab71c94c628439d9"
TREE = "b2586f06e82de55484a2e5752563e8b669c3ea17"
COMMON = ["--offline", "--locked", "--manifest-path", "trillionnium/Cargo.toml"]
PLAN = ["compiler", "provider-version", "node-build", "node-registry", "node-full",
        "tls-cli-and-witness-registry", "tls-cli-and-witness",
        "migration-v6-and-feature-off-registry", "migration-v6-and-feature-off",
        "checkpoint-release-registry", "checkpoint-release", "sqlite-build-requalification", "strict-clippy"]

def need(value, reason):
    if not value:
        raise ValueError(reason)

def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result

def decode(raw):
    return json.loads(raw, object_pairs_hook=unique)

def raw(path):
    need(path.is_file() and not path.is_symlink(), "missing/nonregular evidence: " + str(path))
    return path.read_bytes()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def info(path):
    data = raw(path)
    return {"path": str(path), "sha256": sha(data), "bytes": len(data)}

def load(path):
    return decode(raw(path))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--validation", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root, validation = args.root.resolve(strict=True), args.validation.resolve(strict=True)
    output = args.output.absolute()
    need(not output.exists() and not output.resolve().is_relative_to(root), "use a new output outside source")
    report = {"schema": "task-sqlite-clippy-graph-readback-v1", "head": HEAD, "tree": TREE,
              "generated_utc": datetime.now(timezone.utc).isoformat(), "reader": info(Path(__file__).resolve()),
              "components": {}, "claim_guard": "HOLD", "whole_chain_pq_qualified": False,
              "production_activation": False, "full_storage_qualified": False, "release_system_pq_qualified": False,
              "dependency_provenance_qualified": False, "sqlite_operations_executed_by_requalification": False,
              "native_or_product_commands_executed_by_this_reader": False, "source_or_record_files_modified": False}

    def blob(path):
        return subprocess.check_output(["git", "--no-replace-objects", "show", HEAD + ":" + path], cwd=root)

    def receipt(directory, label, command=None):
        path = directory / (label + ".json")
        value = load(path)
        need(value.get("schema") == "trnm-pq-native-command-v1", label + ": recorder schema")
        need(value.get("status") in ("command_succeeded", "command_failed"), label + ": incomplete command")
        need(type(value.get("exit_code")) is int and (value["exit_code"] == 0) == (value["status"] == "command_succeeded"), label + ": exit/status")
        need(value.get("whole_chain_quantum_security_qualified") is False, label + ": qualification promoted")
        before = value.get("before")
        need(isinstance(before, dict) and before == value.get("after"), label + ": source changed")
        need(before.get("kind") == "head" and before.get("candidate") == HEAD and before.get("tested_commit") == HEAD
             and before.get("tested_tree") == TREE and before.get("tracked_worktree_verified") is True
             and before.get("tests_executed_by_identity_check") is False, label + ": not frozen exact source")
        need(value.get("cwd") == str(root) and value.get("log_file") == label + ".log", label + ": cwd/log path")
        data = raw(directory / value["log_file"])
        need(value.get("log_sha256") == sha(data) and value.get("log_bytes") == len(data), label + ": raw log hash/size")
        need(value["argv"][:2] == ["timeout", "1500"], label + ": outer timeout")
        if command is not None:
            need(value["argv"][2:] == command, label + ": exact command")
        evidence = {"receipt": info(path), "log": info(directory / value["log_file"]), "argv": value["argv"],
                    "exit_code": value["exit_code"], "status": value["status"], "source_verified_before_and_after": True}
        return value, data, evidence

    try:
        native = validation / "native"
        terminal = load(native / "result.json")
        need(terminal.get("phase") == "native" and terminal.get("head") == HEAD and terminal.get("tree") == TREE, "native final source")
        need(terminal.get("planned_commands") == PLAN and terminal.get("not_executed") == [], "native plan incomplete/changed")
        records = terminal["commands"]
        need(len(records) == 13 and [v["label"] for v in records] == PLAN, "native 13-command coverage/order")
        need(load(native / "progress.json") == records, "native final/progress differ")
        failed = []
        for entry in records:
            value, _, evidence = receipt(native, entry["label"])
            need(entry["receipt_sha256"] == evidence["receipt"]["sha256"] and entry["command"] == value["argv"][2:]
                 and entry["command_exit"] == value["exit_code"] and entry["status"] == value["status"]
                 and entry["cap_seconds"] == 1500, "final command/receipt mismatch: " + entry["label"])
            if entry["status"] != "command_succeeded" or entry["recorder_exit"] != 0:
                failed.append(entry["label"])
        need(terminal.get("all_commands_succeeded") is (not failed), "native all-succeeded contradiction")
        need(all(terminal.get(k) is False for k in ("whole_chain_pq_qualified", "public_wan_qualified", "production_activation")), "native elevated flags")
        report["native_phase"] = {"status": "FAIL" if failed else "PASS", "terminal_commands": 13, "not_executed": [],
                                  "all_commands_succeeded": not failed, "failed_commands": failed,
                                  "final_manifest": info(native / "result.json"), "parent_native_suite_accounting_is_separate": True}

        lock_bytes = blob("trillionnium/Cargo.lock")
        lock = tomllib.loads(lock_bytes.decode())
        key = lambda p: (p["name"], p["version"], p.get("source"))
        locked = {key(p): p for p in lock["package"]}
        need(len(locked) == len(lock["package"]) == 181, "frozen lock package count")
        graphs = {}
        selections = [
            ("default", validation / "source", "locked-graph", ["cargo", "metadata", *COMMON, "--format-version=1"], 176),
            ("all_features", validation / "all-features-graph", "locked-all-features-graph",
             ["cargo", "metadata", "--offline", "--locked", "--all-features", "--manifest-path", "trillionnium/Cargo.toml", "--format-version=1"], 181),
        ]
        for label, directory, recorded_label, command, expected in selections:
            value, data, evidence = receipt(directory, recorded_label, command)
            need(value["exit_code"] == 0, label + ": metadata command failed")
            graph = decode(data)
            packages, nodes = graph["packages"], graph["resolve"]["nodes"]
            ids = {p["id"] for p in packages}
            need(len(packages) == len(ids) == len(nodes) == expected and {n["id"] for n in nodes} == ids, label + ": graph coverage")
            need(len(graph["workspace_members"]) == len(set(graph["workspace_members"])) == 26
                 and set(graph["workspace_members"]) <= ids, label + ": workspace members")
            need(graph["workspace_root"] == str(root / "trillionnium"), label + ": workspace root")
            need(all(key(p) in locked for p in packages), label + ": unlocked package/version/source")
            need(all(d["pkg"] in ids for n in nodes for d in n["deps"]), label + ": missing dependency node")
            features = {n["id"]: n["features"] for n in nodes}
            inventory = [{"name": p["name"], "version": p["version"], "source": p.get("source"),
                          "lock_checksum": locked[key(p)].get("checksum"), "selected_features": features[p["id"]],
                          "workspace_member": p["id"] in graph["workspace_members"]}
                         for p in sorted(packages, key=lambda p: (p["name"], p["version"]))]
            graphs[label] = graph
            report["components"]["locked_graph_" + label] = {"status": "PASS", "evidence": evidence, "packages": len(packages),
                "resolve_nodes": len(nodes), "workspace_members": 26, "workspace_default_members": len(graph["workspace_default_members"]),
                "all_packages_match_frozen_lock": True, "package_inventory": inventory,
                "additional_recorded_command_outside_original_source_plan": label == "all_features"}
        all_keys = {key(p) for p in graphs["all_features"]["packages"]}
        default_keys = {key(p) for p in graphs["default"]["packages"]}
        need(all_keys == set(locked), "actual all-features graph differs from lock inventory")
        extra = sorted(all_keys - default_keys, key=str)
        need({p[0] for p in extra} == {"openssl", "openssl-sys", "openssl-macros", "foreign-types", "foreign-types-shared"}, "extra package set")
        report["lock_comparison"] = {"lock_format": lock["version"], "lock_packages": 181, "lock_sha256": sha(lock_bytes),
            "default_selected_packages": 176, "fresh_all_features_selected_packages": 181, "all_features_equals_lock_inventory": True,
            "all_features_only": [{"name": n, "version": v, "source": s} for n, v, s in extra],
            "note": "Original source phase stays default-feature 176; all-features 181 is a separate fresh recorded command."}

        value, helper_log, evidence = receipt(native, "sqlite-build-requalification")
        command = value["argv"][2:]
        sqlite, target = native / "sqlite-requalification", native / "sqlite-target"
        need(len(command) == 10 and command[:6] == ["python3", "scripts/ci/check_sqlite_build_requalification.py", "--output", str(sqlite), "--target", str(target)]
             and command[6] == "--rustc" and command[8] == "--cargo", "SQLite helper argv")
        rustc, cargo = Path(command[7]), Path(command[9])
        need(rustc.is_absolute() and cargo == rustc.with_name("cargo") and value["exit_code"] == 0, "SQLite helper status/toolchain")
        before, after = load(sqlite / "source-before.json"), load(sqlite / "source-after.json")
        need(before == after and before["head"] == HEAD and before["status"] == "", "SQLite source changed/dirty")
        need(all(sha(blob(p)) == digest for p, digest in before["files"].items()), "SQLite source hash not frozen")
        summary = load(sqlite / "summary.json")
        need(summary["schema"] == "trnm-sqlite-build-requalification-v1" and summary["passed"] is True and summary["source_unchanged"] is True, "SQLite summary")
        need(all(summary[k] is False for k in ("target_cleaned_between_phases", "sqlite_operations_executed", "public_service_qualified", "dependency_provenance_qualified")), "SQLite scope flags")
        labels = ["refuse-1", "qualify-1", "refuse-2", "qualify-2"]
        need([v["label"] for v in summary["commands"]] == labels, "SQLite phase coverage/order")
        outputs, phases = [], []
        for label, qualifies in zip(labels, [False, True, False, True]):
            record = load(sqlite / (label + ".json"))
            need(record == summary["commands"][len(phases)] and record["passed"] is True, label + ": record/summary differ")
            need(record["argv"] == [str(cargo), "check", *COMMON, "-p", "trnm-sqlite-io-boundary"] and record["exit_code"] == 0, label + ": genuine Cargo command/exit")
            need(record["rustc"] == (str(rustc) if qualifies else "rustc") and record["loader_path_seed"] == str(rustc.parent.parent / "lib"), label + ": compiler/loader spelling")
            log = raw(sqlite / (label + ".log"))
            need(sha(log) == record["log_sha256"] and len(log) == record["log_bytes"], label + ": Cargo raw log hash/size")
            finished = re.findall(r"^\s+Finished \x60dev\x60 profile \[unoptimized \+ debuginfo\] target\(s\) in (.+)$", log.decode(), re.M)
            need(len(finished) == 1 and "Compiling trnm-sqlite-io-boundary v0.1.0" in log.decode(), label + ": actual rebuild/finish missing")
            need(len(record["build_outputs"]) == 1, label + ": multiple/absent build outputs")
            entry = record["build_outputs"][0]
            original = Path(entry["path"])
            retained = sqlite / entry["retained"]
            need(original.is_relative_to(target / "debug/build") and original.name == "output"
                 and retained.parent == sqlite and retained.name.startswith(label + "-"), label + ": build-output path")
            output_raw = raw(retained)
            need(sha(output_raw) == entry["sha256"], label + ": retained output hash")
            lines = output_raw.decode().splitlines()
            cfg = "cargo:rustc-cfg=trnm_sqlite_layout_witness" in lines
            watch = "cargo:rerun-if-env-changed=RUSTC" in lines
            unqualified = [line for line in lines if "UNQUALIFIED:" in line]
            need(watch and entry["watches_rustc"] is True and cfg is qualifies and entry["qualified"] is qualifies, label + ": watch/cfg mismatch")
            if qualifies:
                need(not unqualified and entry["unqualified_reason"] is None, label + ": unexpected refusal")
                need("cargo:rustc-env=TRNM_SQLITE3_BUILD_FENCE=sqlite-3.51.3-normal-native-linux-layout-v3" in lines
                     and "cargo:rustc-env=TRNM_SQLITE3_AMALGAMATION_SHA256=9512509b1bccb7461f79bea8aad6280ae4699e925fa4804381b71f59e7efb0c5" in lines
                     and "cargo:rustc-link-lib=static=trnm_sqlite_layout_witness" in lines, label + ": missing exact qualified fence")
            else:
                reason = "cargo:warning=trnm SQLite I/O boundary UNQUALIFIED: RUSTC must be absolute"
                need(unqualified == [reason] and entry["unqualified_reason"] == reason
                     and "cargo:rustc-env=TRNM_SQLITE3_UNQUALIFIED_REASON=RUSTC must be absolute" in lines
                     and "cargo:rustc-link-lib=static=trnm_sqlite_layout_witness" not in lines, label + ": refusal semantics")
            outputs.append(entry)
            phases.append({"label": label, "cargo_exit_code": record["exit_code"], "qualified_cfg_present": cfg,
                           "watches_rustc": watch, "unqualified_lines": unqualified, "rustc_spelling": record["rustc"],
                           "loader_path_seed": record["loader_path_seed"], "cargo_finished": finished[0],
                           "record": info(sqlite / (label + ".json")), "cargo_log": info(sqlite / (label + ".log")),
                           "retained_build_output": info(retained), "cargo_build_output_path": str(original),
                           "build_output_mtime_ns": entry["mtime_ns"]})
        need(len({v["path"] for v in outputs}) == 1, "SQLite phases changed target/build unit")
        need(all(b["mtime_ns"] > a["mtime_ns"] for a, b in zip(outputs, outputs[1:])), "SQLite outputs did not refresh every phase")
        need(outputs[0]["sha256"] == outputs[2]["sha256"] and outputs[1]["sha256"] == outputs[3]["sha256"]
             and outputs[0]["sha256"] != outputs[1]["sha256"], "SQLite refuse/qualify output sequence")
        need([decode(line) for line in helper_log.decode().splitlines() if line.startswith("{")]
             == [{"phase": label, "passed": True, "exit": 0} for label in labels], "SQLite outer raw phase transcript")
        report["components"]["sqlite_build_requalification"] = {"status": "PASS", "evidence": evidence, "phases": phases,
            "source_before_equals_after": True, "source_files_match_frozen_blobs": before["files"],
            "same_target": str(target), "same_build_output_path": outputs[0]["path"], "each_phase_mtime_advanced": True,
            "target_cleaned_between_phases": False,
            "no_clean_basis": "Frozen helper creates one fresh target and sets CARGO_TARGET_DIR once; four recorded cargo check commands retain the same output path, changed mtimes and alternating raw cfg outputs. No clean/source edit is in its loop.",
            "refusal_semantics": "All four Cargo exits are zero. Refuse phases withhold the optional layout-witness cfg and emit RUSTC must be absolute; they are not failed Cargo commands.",
            "sqlite_operations_executed": False, "dependency_provenance_qualified": False, "public_service_qualified": False,
            "summary": info(sqlite / "summary.json"), "source_before": info(sqlite / "source-before.json"), "source_after": info(sqlite / "source-after.json")}

        value, data, evidence = receipt(native, "strict-clippy", ["cargo", "clippy", *COMMON, "--workspace", "--all-targets", "--all-features", "--", "-D", "warnings"])
        need(value["exit_code"] == 0, "strict Clippy command failed")
        text = data.decode()
        finished = re.findall(r"^\s+Finished \x60dev\x60 profile \[unoptimized \+ debuginfo\] target\(s\) in (.+)$", text, re.M)
        need(len(finished) == 1, "Clippy actual terminal summary missing")
        rows = re.findall(r"^\s+(?:Checking|Compiling) ([A-Za-z0-9_-]+) v([^\s]+)(?: .*)?$", text, re.M)
        need(rows and all(any(n == k[0] and v == k[1] for k in locked) for n, v in rows), "Clippy package/version absent from lock")
        graph = graphs["all_features"]
        members = {p["name"] for p in graph["packages"] if p["id"] in graph["workspace_members"]}
        observed = {n for n, _ in rows if n in members}
        need(observed == members, "Clippy raw transcript omits workspace member")
        warnings = [line for line in text.splitlines() if line.startswith("warning:")]
        errors = [line for line in text.splitlines() if re.match(r"error(?:\[|:)", line)]
        need(not errors, "Clippy raw error despite successful exit")
        report["components"]["strict_workspace_clippy"] = {"status": "PASS", "evidence": evidence, "finished_dev_profile": finished[0],
            "workspace_members_observed": sorted(observed), "workspace_member_count": len(observed),
            "observed_package_versions": [{"name": n, "version": v} for n, v in rows],
            "cargo_warning_lines": warnings, "error_lines": errors, "native_test_execution": False,
            "scope": "Workspace/all-targets/all-features static checking with -D warnings; no native execution or storage/release/PQ qualification."}
        report["component_readback_status"] = "PASS"
    except Exception as error:
        report["component_readback_status"] = "FAIL"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"component_readback_status": report["component_readback_status"],
                      "native_phase_status": report.get("native_phase", {}).get("status"),
                      "output": str(output), "whole_chain_pq_qualified": False,
                      "production_activation": False, "error": report.get("error")}, sort_keys=True))
    return 0 if report["component_readback_status"] == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
