set -euo pipefail
python3 scripts/ci/finalize_fixed_root_f0.py controller-intent --out "$OUT" \
  --expected-head "$EXPECTED_HEAD" --expected-tree "$EXPECTED_TREE" \
  > "$OUT/controller-arm.stdout.log" 2> "$OUT/controller-arm.stderr.log"
python3 - <<'PY'
import json, os
from pathlib import Path
value = json.loads((Path(os.environ['OUT'])/'controller-intent.json').read_text())
with open(os.environ['GITHUB_ENV'], 'a') as stream:
    for key, field in [('F0_UNIT','service'), ('F0_DESCRIPTION','description'), ('PREPARED_SHA','job_sha256')]:
        if '\n' in value[field] or '\r' in value[field]:
            raise ValueError('single-line controller identity required')
        stream.write(key+'='+value[field]+'\n')
PY
