#!/usr/bin/env python3
"""Preserve terminal command observations without transferring their source scope."""
import argparse
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/workspace/scratch/3042e909dc8c')
REPO = ROOT / 'chain'
OUT = ROOT / 'prepared-late-evidence'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=REPO)

def preserve(path, payload):
    if path.exists():
        assert path.read_bytes() == payload, f'Refusing to overwrite a different prepared batch: {path}'
    else:
        path.write_bytes(payload)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--code', required=True)
    ap.add_argument('--label', action='append', required=True)
    args = ap.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}', args.code)
    assert len(args.label) == len(set(args.label)), 'Duplicate command labels'
    assert {'late-authority-storage', 'integrated-structure'} <= set(args.label)
    tree = git('rev-parse', args.code + '^{tree}').decode().strip()
    prior = git('show', args.code + ':evidence/pq-current-root-integration-20261104/verification-records.tar.gz')
    assert sha(prior) == '07bad156351ad39895ad0a05e027104976148c03bf7effc3fd977077fe68c039'
    retained, commands = {}, []
    for label in args.label:
        assert re.fullmatch(r'[a-z0-9-]+', label)
        path = ROOT / 'final-receipts' / (label + '.json')
        raw_receipt = path.read_bytes()
        receipt = json.loads(raw_receipt)
        assert receipt['status'] in ('command_succeeded', 'command_failed'), label
        assert (receipt['status'] == 'command_succeeded') == (receipt['exit_code'] == 0), label
        assert receipt['before'] == receipt['after'], label
        assert receipt['before']['tracked_worktree_verified'], label
        tested_tree = git('rev-parse', receipt['before']['tested_commit'] + '^{tree}').decode().strip()
        assert receipt['before']['tested_tree'] == tested_tree, label
        assert receipt['whole_chain_quantum_security_qualified'] is False, label
        log = (path.parent / receipt['log_file']).read_bytes()
        assert len(log) == receipt['log_bytes'] and sha(log) == receipt['log_sha256'], label
        text = log.decode(errors='replace')
        rust = [{'status': v[0], 'passed': int(v[1]), 'failed': int(v[2]),
                 'ignored': int(v[3]), 'filtered': int(v[4])}
                for v in re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; '
                                    r'(\d+) ignored; \d+ measured; (\d+) filtered out', text)]
        counts = [int(v) for v in re.findall(r'(?m)^Ran (\d+) tests? in ', text)]
        record = {
            'label': label, 'status': receipt['status'], 'exit_code': receipt['exit_code'],
            'argv': receipt['argv'], 'source': receipt['before'],
            'executed_on_final_code': receipt['before']['tested_commit'] == args.code and tested_tree == tree,
            'rust_summaries': rust, 'python_test_counts': counts,
            'count_scope': 'Observed per-command run/pass/failure counts; repeated commands and partial failures are not aggregated into an overall pass.',
            'rust_names': [{'name': n, 'outcome': o} for n, o in
                           re.findall(r'(?m)^test ([^ \n]+) \.\.\. (ok|FAILED|ignored)', text)],
            'receipt_member': 'commands/' + path.name,
            'receipt_sha256': sha(raw_receipt), 'log_member': 'commands/' + receipt['log_file'],
            'log_sha256': sha(log), 'elapsed_ns': receipt['elapsed_ns'],
        }
        commands.append(record)
        retained[record['receipt_member']] = raw_receipt
        retained[record['log_member']] = log
    for name in (
        'late-source.json', 'late-source-preparation.json',
        'late-cell-callsite-review.md', 'late-cli-cache-failure-analysis.json',
        'ec2-F-candidate-tree.json', 'fc86-F-candidate-tree.json',
        'incoming-552-object-restoration.json', 'incoming-ec2-object-restoration.json',
        'incoming-fc86-object-restoration.json', 'final-integration-source.json',
        'final-native-cache-cleanup.json', 'late-concurrent-review.md',
        'final-composition-audit.json', 'integrated-disk-exhaustion-stop.json',
        'checkpoint-cache-cleanup.json', 'integrated-post-test-cache-cleanup.json',
        'integrated-example-cache-cleanup.json', 'integrated-completed-test-cache-cleanup.json',
        'integrated-provider-and-graph.json',
        'incoming-160-object-restoration.json', 'integrated-final-cache-space-recovery.json',
        'integrated-space-observation.json',
    ):
        p = ROOT / 'receipts' / name
        if p.exists():
            retained['source-and-review/' + name] = p.read_bytes()
    retained['assembly/build-late-integration-evidence.py'] = Path(__file__).read_bytes()
    packed_tar = io.BytesIO()
    with tarfile.open(fileobj=packed_tar, mode='w') as archive:
        for name, payload in sorted(retained.items()):
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode, entry.mtime = len(payload), 0o644, 0
            archive.addfile(entry, io.BytesIO(payload))
    archive_bytes = gzip.compress(packed_tar.getvalue(), compresslevel=9, mtime=0)
    OUT.mkdir(exist_ok=True)
    preserve(OUT / 'late-verification-records.tar.gz', archive_bytes)
    lock = git('show', args.code + ':trillionnium/Cargo.lock')
    corpus = json.loads(git('show', args.code + ':config/pon/pq-cross-branch-corpus-v1.json'))
    record = {
        'schema': 'trnm-pq-late-integration-observations-v1', 'status': 'HOLD_NO_GO',
        'code_commit': args.code, 'code_tree': tree,
        'cargo_lock_sha256': sha(lock),
        'source_scope': 'Each command retains its own pre/post verified source; earlier executions are not inherited.',
        'commands': commands,
        'archive': {'path': 'late-verification-records.tar.gz', 'bytes': len(archive_bytes),
                    'sha256': sha(archive_bytes),
                    'members': [{'path': n, 'bytes': len(b), 'sha256': sha(b)}
                                for n, b in sorted(retained.items())]},
        'prior_archive_unchanged': {'path': 'verification-records.tar.gz',
             'sha256': '07bad156351ad39895ad0a05e027104976148c03bf7effc3fd977077fe68c039'},
        'failure_scope': [
            'The F authority/storage command failed after 322 passes with five CLI spawn ENOENT failures; M15/M12 were not reached.',
            'A retained CLI ELF embedded a removed target-authority path. Its executable and dependency metadata disagreed. The failure remains; a fresh package rebuild is a separate observation.',
            'Earlier e05 canonical Node compilation ended in SIGKILL. Its separate debug-disabled diagnostic is not a canonical acceptance gate.',
            'AF_UNIX positive checkpoint daemon cases remain unavailable in the observed environment.',
            'The first integrated structure command omitted cargo fmt --all and exited before formatting targets were inspected; the corrected command is retained separately.',
        ],
        'unclosed': [
            'Atomic current-root authorization at every real account, governance, release, recovery, CURRENT, FinalUse and provider effect owner.',
            'Full native W1 and added proof-backend security games, composition and cheapest legal classical/quantum attacks.',
            'Unified quantum mining, DAA, timestamp, cumulative-work, reorganization and propagation model.',
            'Migration preserving historical rights, nonce floors, liabilities and externally entered effects across independent rollback faults.',
            'Actual PQ wire complete-service CPU/Host, network, memory, queue, tail and recovery acceptance.',
            'Original four-second/at-least-sixteen-hostile-W1, depth-six and 4105-block History obligations.',
            'Fixed complete Chain/runtime pair, independent organizations/operators, separate fault domains, reproducible deployment and governed activation.',
        ],
        'internal_parallel_review_is_independent_organization_acceptance': False,
        'prospective_protected_main_merge_executed': False,
        'whole_chain_quantum_security_qualified': False,
        'whole_native_authorization_migrated': False,
        'production_activation': False,
    }
    preserve(OUT / 'late-integration.json', (json.dumps(record, indent=2, ensure_ascii=False, sort_keys=True) + '\n').encode())
    by_label = {c['label']: c for c in commands}
    for name, passed, ignored in [('integrated-native-components', 671, 8),
                                  ('integrated-crypto-recovery', 39, 0)]:
        c = by_label[name]
        assert c['status'] == 'command_succeeded' and c['executed_on_final_code']
        assert sum(x['passed'] for x in c['rust_summaries']) == passed
        assert sum(x['ignored'] for x in c['rust_summaries']) == ignored
        assert sum(x['failed'] for x in c['rust_summaries']) == 0
    for name, count in [('integrated-python-controls', 370), ('integrated-claim-ci-controls', 135)]:
        c = by_label[name]
        assert c['status'] == 'command_succeeded' and c['executed_on_final_code']
        assert sum(c['python_test_counts']) == count
    node = by_label['integrated-node-canonical']
    assert node['executed_on_final_code']
    if node['status'] == 'command_succeeded':
        assert [x['passed'] for x in node['rust_summaries']] == [3, 1, 1, 4]
        assert all(x['failed'] == x['ignored'] == 0 for x in node['rust_summaries'])
        node_result = '9 pass: 3 PNQ2 completion, 2 exact startup deadline and intake domain controls, 4 request lifecycle controls; original canonical profile retained.'
    else:
        node_result = (f"Command failed with exit {node['exit_code']}; "
                       f"{sum(x['passed'] for x in node['rust_summaries'])} selected tests observed passing. "
                       'The canonical gate remains incomplete; exact failure output is retained.')
    md = f'''# Late integration and actual verification

**Status: HOLD / NO-GO for whole-chain qualification and activation.**
This follow-up belongs to existing Draft PR #688. It records actual executions
on commit `{args.code}`, tree `{tree}`. It does not move an earlier execution
to a later commit or provide independent organizational acceptance.

## Source and preserved concurrent work

The fixed code merge has parents `fc86ed8e927a8eb4e048b160437126a6c0b96c0d`
and `8f8462803f190e6c60e3e8d87f6673c3480504b7`. It preserves the current-root,
checkpoint and original PNQ2 deadline fixes together with concurrent Cell,
Growth, public-service startup/request observation and shared-material changes.
The final merge combines only the plan, generated inventory and source corpus
where both sides changed them; exact incoming production blobs are retained.

Later commit `160b6f91e39708454d1edd200ab9ef2b4192192e` changes exactly four
shared-material evidence paths. Its complete tree was reconstructed and the
non-evidence diff from this fixed code is empty. This source-delta observation
does not relabel any command as an execution on 160b6f91.

Every completed command on this code verified all **9,771 tracked entries /
960,078,192 bytes** before and after execution. These are head-checkout runs;
a prospective merge with protected main and a complete Chain/runtime deployment
were not executed. Each earlier F command retains its own source identity.
The composition audit checks **487 source pins**, **405 required paths** and a
**52-control roster**. A roster is not an execution count. All explicitly checked
qualification/activation fields remain false.

## Actual results on the fixed code

| Scope | Observed result |
| --- | --- |
| M06, M09, M12, M15 default-feature native command | **671 pass, 0 fail, 8 ignored**, including 14 compile-fail documentation checks. M06: 241 runtime + 2 documentation; M09: 352 runtime/CLI + 10 documentation; M12: 46 runtime + 2 documentation; M15: 18 runtime. |
| Shared-material native example | **6 pass**. This does not establish work savings, proof-backend soundness or hostile-service capacity. |
| Selected M03 recovery targets | **33 pass**: 15 cold recovery, 15 binary-module and 3 CLI-refusal controls. Three positive AF_UNIX cross-process cases remain outside the selector. |
| Node canonical selectors | {node_result} |
| Source/model/public-observation/shared-operator Python controls | **370 pass**, including the unchanged actual-source and conditional-DAA controls and added image-binding/complete-operator checks. |
| Recorder, claim, authority-inventory and CI-contract controls | **135 pass**: 4 + 22 + 11 + 98. Repeated/imported coverage is not claimed as independent additional assurance. |
| Strict Clippy | **7 packages**, all targets/features, warnings denied: Node, mvcc-fee, service-settlement, checkpoint-store, release-bundle, data-availability and crypto-primitives. |
| Workspace and repository | Corrected full-workspace formatting, source inventory, exact corpus, diff checks and **2,967 local links** pass. |
| Locked offline graph | 26 workspace members, 175 default resolved packages, 180 lockfile package entries. |

The eight ignored cases are existing explicit component timing/RSS experiments.
They were not executed or counted as passing. The four-package command uses
default features; the all-feature Clippy result is compilation/static analysis,
not an all-feature runtime test claim. Source guards and arithmetic/report tests
do not prove the cryptographic goals in the six-domain acceptance contract.

## Failures and resource observations remain visible

On F (`8f846280...`), six-package strict Clippy passed, but the authority/storage
command failed after **322 passes and five CLI spawn failures**. M15/M12 were not
reached by that failed command. The failing `cell_closure_cli` ELF embedded the
removed `target-authority/debug/trnm-cell` path while its `.d` metadata claimed
the current `target-integrated` path. The evidence establishes an artifact-path
inconsistency; it does not identify the historical operation that caused it.
The M09 package cache was removed and rebuilt. On the fixed final code all five
closure CLI cases pass within the successful four-package command. No symlink,
test relaxation or production-code workaround was used for the cache failure.

The first final structure command omitted `cargo fmt --all` and failed with
`Failed to find targets` before checking formatting. Its raw failed receipt and
the successful corrected command are both retained.

The shared filesystem reported zero generally available space during this work;
a later statvfs observation still reported 2,603,180,032 free bytes to the root
process. Availability alone is not treated as a command failure. Only this
session's reproducible build caches were removed, including already-completed
test executables and non-test examples; their identities and cleanup scopes are
recorded. Sources, raw logs and records were retained. The attempted stop review
sent no signal to a Cargo process, and the recorded component, Clippy and
crypto/recovery commands completed successfully. These executions are not
isolated-host timing or memory qualification samples.

The original e05 canonical Node compiler SIGKILL, its separate debug-disabled
diagnostic, the earlier AF_UNIX EPERM and the cancelled source-control receipt
remain unchanged in the original archive. Later success does not rewrite those
attempts. Historical shared-material reports likewise retain their own executed
source; this integration does not relabel them as fresh production measurements.

## Authorization and activation boundaries

The `trnm-release-bundle::pq_release` authority kernel still has no production
caller in the inspected Chain tree. Cell release requires the supplied complete
current expectation, but the consuming owner must supply a fresh view and bind
it atomically to the actual effect. New typed storage/provider paths do not by
themselves supply that current publisher/root authority. A CLI acquisition policy,
an observer clock, a claimed Hello identity and a local completion receipt are
not authorization for CURRENT, FinalUse, a payment or an external effect.

Stricter manifest replay can refuse histories previously accepted under the
older rule. Historical rights, nonce/debt floors and already-entered external
effects still require an explicit migration/reconciliation procedure and
independent recovery evidence. Live journal validation remains O(journal records);
the fixed-buffer implementation does not establish a production recovery budget.

The [six-domain remaining evidence](README.md#six-domains-remaining-closure-evidence)
and [implementation boundaries](../../docs/security/PQ_RECOVERY_RELEASE_TRANSPORT_BOUNDARIES_V1.md)
remain open. In particular, preserve the original four-second / at-least-sixteen
hostile W1 requirement, CPU/Host budgets, depth-six/required-work confirmation and
4,105-block History. Full W1/backend security, cheapest legal quantum attack cost,
DAA/timestamp/fork/propagation closure, actual PQ-wire whole-service capacity and
independent fixed-source deployment/activation are not established by these tests.

## Reproduction and original records

[late-integration.json](late-integration.json) contains exact commands, statuses,
source identities, per-target outcomes and archive member hashes. The raw
[late verification archive](late-verification-records.tar.gz) is
**{len(archive_bytes):,} bytes**, SHA256 `{sha(archive_bytes)}`.
It contains {len(retained)} members, including the two failed command records,
source preservation reviews and cache-failure evidence.

The prior [verification archive](verification-records.tar.gz) is unchanged:
SHA256 `07bad156351ad39895ad0a05e027104976148c03bf7effc3fd977077fe68c039`.
Its source scopes remain as described by [reproduction.json](reproduction.json).

Use a clean checkout of the fixed code, an allowed `fix/chain-*` branch,
`bash scripts/project-preflight.sh`, Rust 1.95.0, one Cargo job, no incremental
compilation and one Rust test thread. Preserve the exact lockfile and command
profiles. The observed native provider binary is OpenSSL 3.5.9 with SHA256
`35f28c82e7e4fdcd06b0a42062efd224a5fd5d32d5cc9894252f8206219d496e`;
its identity and locked graph are recorded separately from runtime-test claims.
No protected-main merge, production activation or independent approval is
represented by this evidence update.
'''
    preserve(OUT / 'LATE_INTEGRATION.md', md.encode())
    print(json.dumps({'code': args.code, 'tree': tree, 'commands': len(commands),
                      'archive_bytes': len(archive_bytes), 'archive_sha256': sha(archive_bytes),
                      'members': len(retained),
                      'results': [{'label': c['label'], 'status': c['status'],
                                   'rust': c['rust_summaries'], 'python': c['python_test_counts']}
                                  for c in commands]}, ensure_ascii=False))

if __name__ == '__main__':
    main()
