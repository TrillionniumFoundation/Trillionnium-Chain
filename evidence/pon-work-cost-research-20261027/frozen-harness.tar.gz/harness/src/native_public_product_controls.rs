//! Standalone supplementary driver for the actual 5e native public-product API.
//! Linked only to already locked Cargo-built libraries. Never a Node admission test.
use std::{error::Error, fs::File, io::Read};
use trnm_crypto_primitives::pon_work::{self, public_product::PublicProduct, CELLS};
use trnm_protocol::pon_wire::Header;

fn main() -> Result<(), Box<dyn Error>> {
    let paths: Vec<_> = std::env::args_os().skip(1).collect();
    if paths.is_empty() || paths.len() > 64 {
        return Err("expected 1..64 exact retained controls".into());
    }
    for path in &paths {
        let mut bytes = Vec::new();
        File::open(path)?
            .take((318 + pon_work::PROOF_BYTES + 1) as u64)
            .read_to_end(&mut bytes)?;
        if bytes.len() != 318 + pon_work::PROOF_BYTES {
            return Err("control length".into());
        }
        let header = Header::decode(&bytes[..318]).map_err(|error| format!("header: {error:?}"))?;
        let proof = &bytes[318..];
        let operands: Vec<_> = proof[4..4 + 8 * CELLS]
            .chunks_exact(4)
            .map(|word| u32::from_le_bytes(word.try_into().unwrap()))
            .collect();
        let fact = PublicProduct::new(&operands[..CELLS], &operands[CELLS..])
            .map_err(|error| format!("public product setup: {error:?}"))?;
        assert_eq!(
            fact.precheck(header.challenge(), header.work_task, header.target, proof),
            Ok(true)
        );
        let mut tiles = 0;
        let result = pon_work::verify_with_progress(
            header.challenge(),
            header.work_task,
            header.target,
            proof,
            &mut |point| {
                if matches!(point, pon_work::VerificationProgress::TranscriptTile { .. }) {
                    tiles += 1;
                }
                Ok::<_, ()>(())
            },
        );
        assert!(matches!(
            result,
            Err(pon_work::VerificationError::Relation(
                pon_work::WorkError::Transcript
            ))
        ));
        assert_eq!(tiles, 512);
    }
    println!(
        "{{\"actual_native_public_product_passes\":{},\"full_transcript_rejections\":{},\"tiles_per_rejection\":512,\"node_entry_executed\":false,\"succinct_proof\":false}}",
        paths.len(), paths.len()
    );
    Ok(())
}
