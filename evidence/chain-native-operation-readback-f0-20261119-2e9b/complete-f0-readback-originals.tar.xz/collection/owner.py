from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,time,resource,hashlib,zipfile,stat,shutil,traceback,sys
root=Path('/home/qian-qi/work/chain-native-operation-readback-f0-20261119-2e9b');out=root/'collection';out.mkdir(exist_ok=False);polls=out/'polls';polls.mkdir()
(out/'owner.py').write_text(sys.argv[1])
repo='TrillionniumFoundation/Trillionnium-Chain';head='3db79eb2682ba3bcbbf33557c5eee3b67731028f';runid=44451798839
res={'schema':'chain-original-f0-collection-v1','run_id':runid,'expected_head':head,'complete_download':False,'business_qualified':False,'full_physical_cost_closed':False,'requests':[]}
def save():(out/'COLLECTION.json').write_text(json.dumps(res,indent=2)+'\n')
def api(name,endpoint,target=None):
 dest=out/(name+'.stdout') if target is None else target
 err=out/(name.replace('/','-')+'.stderr');start=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'endpoint':endpoint,'started_utc':datetime.now(timezone.utc).isoformat()};res['requests'].append(row);save()
 with dest.open('xb') as so,err.open('xb') as se:
  p=subprocess.Popen(['/usr/bin/gh','api',endpoint],stdout=so,stderr=se);row['pid']=p.pid;save();rc=p.wait()
 a=resource.getrusage(resource.RUSAGE_CHILDREN);row.update(exit_code=rc,wall_seconds=time.monotonic()-start,child_user_cpu_seconds=a.ru_utime-b.ru_utime,child_system_cpu_seconds=a.ru_stime-b.ru_stime,bytes=dest.stat().st_size,sha256=hashlib.sha256(dest.read_bytes()).hexdigest());save();return rc,dest
try:
 for attempt in range(200):
  rc,p=api('poll-'+str(attempt),'repos/'+repo+'/actions/runs/'+str(runid),polls/(str(attempt)+'.run.json'))
  if rc==0:
   run=json.loads(p.read_text());assert run['id']==runid and run['head_sha']==head and run['run_attempt']==1
   print(json.dumps({'poll':attempt,'run_id':runid,'status':run['status'],'conclusion':run['conclusion'],'observed_utc':datetime.now(timezone.utc).isoformat()}),flush=True)
   if run['status']=='completed':
    shutil.copyfile(p,out/'run.stdout');break
  time.sleep(30)
 else:raise RuntimeError('workflow still not completed; existing run retained and not repeated')
 rc,p=api('jobs','repos/'+repo+'/actions/runs/'+str(runid)+'/jobs?filter=all&per_page=100');assert rc==0
 jobs=json.loads(p.read_text());assert jobs['total_count']==len(jobs['jobs']) and jobs['total_count']==1
 for job in jobs['jobs']:
  api('job-'+str(job['id'])+'-log','repos/'+repo+'/actions/jobs/'+str(job['id'])+'/logs')
 api('timing','repos/'+repo+'/actions/runs/'+str(runid)+'/timing')
 rc,p=api('artifacts','repos/'+repo+'/actions/runs/'+str(runid)+'/artifacts?per_page=100');assert rc==0
 artifacts=json.loads(p.read_text());assert artifacts['total_count']==len(artifacts['artifacts'])==1
 res['artifacts']=[]
 for item in artifacts['artifacts']:
  assert item['expired'] is False
  path=out/('artifact-'+str(item['id'])+'.zip')
  rc,_=api('artifact-'+str(item['id'])+'-download','repos/'+repo+'/actions/artifacts/'+str(item['id'])+'/zip',path);assert rc==0
  raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest();assert item['digest']=='sha256:'+digest
  extracted=out/('artifact-'+str(item['id']));extracted.mkdir(exist_ok=False)
  with zipfile.ZipFile(path) as archive:
   rows=archive.infolist();assert len(rows)==len({r.filename for r in rows}) and sum(r.file_size for r in rows)<512*1024*1024
   for row in rows:
    name=Path(row.filename);target=extracted/name
    assert not name.is_absolute() and target.resolve().is_relative_to(extracted.resolve()) and not stat.S_ISLNK(row.external_attr>>16)
    assert not row.is_dir()
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(archive.read(row.filename))
  res['artifacts'].append({'id':item['id'],'zip':path.name,'bytes':len(raw),'sha256':digest,'provider_digest_verified':True,'extracted':extracted.name,'members':len(rows)})
 res['provider_run_conclusion']=run['conclusion'];res['complete_download']=True;save();print(json.dumps({'collection_complete':True,'run_id':runid,'conclusion':run['conclusion'],'artifacts':res['artifacts']}),flush=True)
except BaseException as exc:
 res['error']=repr(exc);save();(out/'error.log').write_text(traceback.format_exc());raise
