# F0 native proof integration supplement, 5176

This supplement records new native-adapter execution at frozen source
4505a598d6ec2644a175e47398d4a5f3f054bc5e (F0). It does not relabel or replace the
earlier generation experiment at 6f2c5ce28bf39fd4548f6312d2eebe363c77da4b.

The earlier archive remains separately preserved with SHA256
5c42a370d3c39c0d144047f0c2308c5b113a1e752e51fb90061643aa699f68f8.
This supplement invokes no prover and generates zero new complete proofs. It
reuses the SHA and arithmetic proof components actually generated in that
earlier experiment for the same fixed native statement.

The exact correspondence compares all 1,526 recorded adapter source inputs.
Three files differ: pq_application_local_cli.rs, native_budget/task_operation_v2.rs,
and native_budget/task_operation_v2/tests.rs. Thus the M12 implementation change
is in the adapter's source closure and requires a new adapter build. All 15
recorded standalone STARK source, manifest and lock inputs are identical to F0;
their precise records are retained in input-correspondence.json.

F0 is built using cargo +1.95.0, release, --locked --offline, jobs=2 and
RUSTFLAGS=-C target-cpu=native. The newly compiled F0 executable is copied to an
immutable evidence path before it is used. The executed adapter regenerates the
native fixture and checks that the statement still matches the earlier proof.
The same pinned independent-process harness then runs five admission/cancellation
cases and four cold reopens, with a nine-slot shared proof-start owner and
exhaustion status. Raw process records, stdout, stderr, native state and final
observations are bundled.

The selected source bytes, F0 HEAD and copied executable are checked after
execution. Source files, current binary and reused proof inputs are included.
Third-party dependency sources and toolchains are not bundled; no complete
hermetic build or authenticated provenance is claimed.

The resource record is the research configuration: CPU affinity 0..7,
RAYON_NUM_THREADS=8, cgroup quota 800000/100000, memory.max=8589934592 and
memory.swap.max=max. SQLite's external-RUSTFLAGS UNQUALIFIED warning is retained.
The original public resource profile, same-resource net benefit, NI/PQ soundness,
whole-chain lifecycle qualification and production activation remain unestablished.

Files are stored once under objects/ with exact logical paths, lengths, modes and
SHA256 in manifest.json. Run:

    python3 restore.py /new/path/restored

The restore operation checks every object before writing each logical file.
experiment/ contains the actual F0 run; source/ contains the corresponding F0
selected inputs; prior-source-differences/ retains the three original source
versions for review; reused-proof-inputs/ identifies the earlier generated proof
without assigning it a new generation identity. All contents are independent of
the source worktree used during execution once this bundle has been created.

Qualification remains HOLD_NO_GO. Native subprocess reopen observations do not
establish complete daemon OS-restart qualification.
