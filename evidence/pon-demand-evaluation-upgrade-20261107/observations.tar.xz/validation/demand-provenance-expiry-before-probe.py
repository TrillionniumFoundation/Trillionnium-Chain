"""Read-only temporal-origin probe, with identical pre/post-repair expectations."""
import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--source-dir', type=Path, required=True)
parser.add_argument('--dependency-dir', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.dependency_dir))
sys.path.insert(0, str(args.source_dir))
from test_demand_evidence import DemandTests


def identity():
    return {name: hashlib.sha256((args.source_dir / name).read_bytes()).hexdigest()
            for name in ('demand_evidence.py', 'test_demand_evidence.py')}


def pending(*, provenance):
    fixture = DemandTests()
    fixture.setUp()
    bundle = fixture.bundle()
    for key in ('delivery', 'acceptance', 'evaluation', 'availability', 'adoption'):
        bundle[key] = None
    bundle['payments'] = []
    sources = copy.deepcopy(bundle['funding']['body']['payload']['sources'])
    for source in sources.values():
        source['state'] = 'locked'
    fixture.resign(bundle, 'funding', observed_at=20, valid_until=40, sources=sources)
    if provenance:
        fixture.resign(bundle, 'provenance', valid_until=20)
    else:
        bundle['provenance'] = None
    observation = fixture.observe(bundle, height=20)
    return fixture, observation


before = identity()
cases = []
for attached, height, expected in (
    (True, 20, 'funded-external-attested'),
    (True, 21, 'existing-native-maintenance'),
    (True, 30, 'existing-native-maintenance'),
    (False, 30, 'funded-unknown'),
):
    fixture, observed = pending(provenance=attached)
    snapshot = fixture.book.snapshot()
    result = fixture.book.queue_observation(height=height, expected_anchor=fixture.anchor)
    cases.append(dict(provenance_attached=attached, provenance_valid_until=20 if attached else None,
                      observed_height=20, query_height=height, expected_mode=expected,
                      observed_mode=result['mode'], passes=result['mode'] == expected,
                      observation_schema=observed['schema'],
                      dispatch_authorized=result['dispatch_authorized'],
                      query_preserved_snapshot=fixture.book.snapshot() == snapshot))
after = identity()
result = dict(schema='demand-provenance-expiry-adversarial-v1', source_before=before,
              source_after=after, source_unchanged=before == after,
              native_executions=0, cases=cases, passed=all(c['passes'] for c in cases))
text = json.dumps(result, indent=2, sort_keys=True) + '\n'
args.output.write_text(text)
print(text, end='')
raise SystemExit(0 if result['passed'] else 1)
