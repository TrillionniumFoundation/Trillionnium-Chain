import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import tarfile
import time
import traceback
from pathlib import Path

BASE=Path("/home/qian-qi/work/cell-complete-93ddee66e1b3-20261107")
ROOT=BASE/"chain-final"
OUT=BASE/"concurrent-ci-acc2ec24-20261107-v1"
COMMIT="acc2ec24fac7e6fbebb49384fc7efc7c9f8b2030"
TREE="e59270db7fe6ea77e01362b591dd98e4e93d62fe"
PREVIOUS="644a6c044"
CONTEXT=("publication-public-final-644a6c","concurrent-integration-acc2")
commands=[]
env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
counts={}
error=None

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def write(name,raw):
    path=OUT/name
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())

def save(name,value):
    write(name,(json.dumps(value,sort_keys=True,indent=2)+"\n").encode())

def command(name,argv,required=False):
    before=time.time_ns()
    with (OUT/(name+".stdout")).open("xb") as stdout, (OUT/(name+".stderr")).open("xb") as stderr:
        result=subprocess.run(argv,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
        stdout.flush();stderr.flush()
        os.fsync(stdout.fileno());os.fsync(stderr.fileno())
    record={"name":name,"argv":argv,"cwd":str(ROOT),"started_unix_ns":before,
            "finished_unix_ns":time.time_ns(),"exit_code":result.returncode,
            "env_overrides":{"PYTHONDONTWRITEBYTECODE":"1","TMPDIR":env["TMPDIR"]}}
    for stream in ("stdout","stderr"):
        raw=(OUT/(name+"."+stream)).read_bytes()
        record[stream]={"path":name+"."+stream,"bytes":len(raw),"sha256":digest(raw)}
    commands.append(record)
    save(name+".command.json",record)
    print(json.dumps({"command":name,"exit_code":result.returncode}),flush=True)
    if required and result.returncode:
        raise RuntimeError("required command failed: "+name)
    return result.returncode

def source_snapshot(label):
    command("tree-"+label,["git","ls-tree","-r","-z","HEAD"],True)
    command("index-"+label,["git","ls-files","-t","-z"],True)
    tree_raw=(OUT/("tree-"+label+".stdout")).read_bytes()
    index_raw=(OUT/("index-"+label+".stdout")).read_bytes()
    skipped={entry[2:] for entry in index_raw.split(b"\0") if entry.startswith(b"S ")}
    records=[]
    absent=[]
    for entry in tree_raw.split(b"\0"):
        if not entry: continue
        meta,raw_name=entry.split(b"\t",1)
        mode,kind,oid=meta.decode().split()
        name=os.fsdecode(raw_name)
        relative=Path(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise RuntimeError("unsafe tracked path")
        path=ROOT/relative
        if not os.path.lexists(path):
            if raw_name not in skipped:
                raise RuntimeError("non-sparse tracked path missing: "+name)
            absent.append({"path":name,"git_mode":mode,"git_blob_oid":oid})
            continue
        info=path.lstat()
        if kind!="blob":
            raise RuntimeError("unsupported materialized tracked kind: "+name)
        if mode=="120000":
            if not stat.S_ISLNK(info.st_mode):
                raise RuntimeError("tracked symlink replaced: "+name)
            raw=os.fsencode(os.readlink(path))
            size=len(raw)
            actual=hashlib.sha1(b"blob "+str(size).encode()+b"\0"+raw).hexdigest()
            sha=digest(raw)
        else:
            if mode not in ("100644","100755") or not stat.S_ISREG(info.st_mode):
                raise RuntimeError("tracked file type differs: "+name)
            if bool(info.st_mode&0o111)!=(mode=="100755"):
                raise RuntimeError("tracked executable bit differs: "+name)
            size=info.st_size
            hasher=hashlib.sha256()
            blob=hashlib.sha1(b"blob "+str(size).encode()+b"\0")
            with path.open("rb") as stream:
                while True:
                    chunk=stream.read(1024*1024)
                    if not chunk: break
                    hasher.update(chunk);blob.update(chunk)
            actual=blob.hexdigest();sha=hasher.hexdigest()
        if actual!=oid:
            raise RuntimeError("tracked raw bytes differ from exact commit: "+name)
        records.append({"path":name,"git_mode":mode,"git_blob_oid":oid,
                        "bytes":size,"sha256":sha,"posix_mode":stat.S_IMODE(info.st_mode)})
    result={"schema":"materialized-sparse-source-snapshot-v1","commit":COMMIT,"tree":TREE,
            "materialized_files":records,"sparse_absent_files":absent,
            "materialized_count":len(records),"sparse_absent_count":len(absent),
            "all_materialized_git_blobs_verified":True,"whole_tree_materialized":not absent}
    save("source-"+label+".json",result)
    return result

def context_copy():
    entries=[]
    for directory in CONTEXT:
        source=BASE/directory
        if not source.is_dir() or source.is_symlink():
            raise RuntimeError("context directory missing or symlinked: "+directory)
        for path in sorted(source.rglob("*")):
            if path.is_symlink():
                raise RuntimeError("context symlink refused")
            if path.is_dir(): continue
            info=path.stat()
            if not stat.S_ISREG(info.st_mode):
                raise RuntimeError("non-regular context file")
            relative=path.relative_to(source)
            target=Path("integration-context")/directory/relative
            raw=path.read_bytes()
            write(target,raw)
            entries.append({"source":str(path),"archive_path":str(target),
                            "bytes":len(raw),"sha256":digest(raw)})
    save("integration-context.json",{"files":entries,
         "scope":"original finished public-only source-switch and rejected-push records; not CI test failures"})
    return entries

if OUT.exists():
    raise RuntimeError("create-only result directory exists")
OUT.mkdir(mode=0o700)
(OUT/"tmp").mkdir(mode=0o700)
env["TMPDIR"]=str(OUT/"tmp")
write("runner.py",globals().get("_runner_raw",Path(__file__).read_bytes()))
save("scope.json",{"commit":COMMIT,"tree":TREE,"sparse_checkout":True,
     "source_edits_allowed":False,"native_parallel_check":True,
     "v3_computation_rerun":False,
     "source_integrity_43_rerun":False,
     "source_integrity_43_reason":"verify_ci_source.py and its 43-test suite are unchanged; added push consumer and changed workflow contract receive their own 13 real-Git controls plus the 103 existing controls",
     "integration_context_directories":list(CONTEXT)})
try:
    context_entries=context_copy()
    command("identity-before",["git","show","-s","--format=%H%n%T%n%P%n%D","HEAD"],True)
    identity=(OUT/"identity-before.stdout").read_text().splitlines()
    if identity[:2]!=[COMMIT,TREE]:
        raise RuntimeError("exact concurrent commit or tree mismatch")
    command("status-before",["git","status","--short"],True)
    if (OUT/"status-before.stdout").read_bytes():
        raise RuntimeError("sparse checkout is dirty before tests")
    command("sparse-paths",["git","sparse-checkout","list"],True)
    command("preflight",["bash","scripts/project-preflight.sh"],True)
    before=source_snapshot("before")
    command("unchanged-source-integrity-dependencies",
            ["git","diff","--exit-code",PREVIOUS,COMMIT,"--",
             "scripts/ci/verify_ci_source.py","scripts/ci/test_ci_source_integrity.py"],True)
    command("affected-ci-diff",
            ["git","diff","--stat",PREVIOUS,COMMIT,"--","scripts/ci",".github/workflows"],True)
    check_exit=command("check-ci-contract",["python3","scripts/ci/check_ci_contract.py"])
    test_exit=command("test-ci-contract",["python3","scripts/ci/test_ci_contract.py","-v"])
    push_exit=command("test-integration-push-source",["python3","scripts/ci/test_integration_push_source.py","-v"])
    for name,count in (("test-ci-contract",103),("test-integration-push-source",13)):
        stderr=(OUT/(name+".stderr")).read_text(errors="replace")
        values=re.findall(r"^Ran (\d+) tests? in ([0-9.]+)s$",stderr,re.MULTILINE)
        counts[name]={"expected":count,"observed":values}
        if len(values)!=1 or int(values[0][0])!=count:
            raise RuntimeError("exact test count missing: "+name)
    if any((check_exit,test_exit,push_exit)):
        raise RuntimeError("one or more CI controls failed")
except BaseException:
    error=traceback.format_exc()
    write("failure.txt",error.encode())
finally:
    try:
        after=source_snapshot("after")
        if "before" in globals() and before!=after:
            raise RuntimeError("materialized tracked source changed during tests")
        command("identity-after",["git","show","-s","--format=%H%n%T%n%P%n%D","HEAD"],True)
        if (OUT/"identity-after.stdout").read_text().splitlines()[:2]!=[COMMIT,TREE]:
            raise RuntimeError("concurrent commit or tree changed")
        command("status-after",["git","status","--short"],True)
        if (OUT/"status-after.stdout").read_bytes():
            raise RuntimeError("sparse checkout dirty after tests")
    except BaseException:
        if error is None:
            error=traceback.format_exc()
            write("final-fence-failure.txt",error.encode())
    save("commands.json",commands)
    save("summary.json",{"schema":"concurrent-cell-ci-acc2ec24-v1",
         "result":"PASS" if error is None else "FAIL","commit":COMMIT,"tree":TREE,
         "tests":counts,"commands":[{"name":c["name"],"exit_code":c["exit_code"]} for c in commands],
         "materialized_source_files":globals().get("after",{}).get("materialized_count"),
         "sparse_absent_files":globals().get("after",{}).get("sparse_absent_count"),
         "source_before_after_identical":globals().get("before")==globals().get("after"),
         "whole_tree_materialized":False,
         "scope":"exact commit/tree; raw-byte verification of all materialized tracked entries; sparse absent paths explicitly retained",
         "source_edits":0,"v3_computation_rerun":False,"native_retested_by_this_runner":False,
         "source_integrity_43_rerun":False,"integration_guard_refusal_is_test_failure":False,
         "integration_context_files":len(globals().get("context_entries",[])),
         "failure":error,"production_or_consensus_activation":False})
    files=sorted(p for p in OUT.rglob("*") if p.is_file() and p.relative_to(OUT).parts[0] != "tmp")
    manifest=[{"path":str(p.relative_to(OUT)),"bytes":p.stat().st_size,
               "sha256":digest(p.read_bytes())} for p in files]
    save("FILES.json",{"schema":"concurrent-ci-files-v1","files":manifest})
    archive=OUT.with_suffix(".tar.gz")
    with archive.open("xb") as output:
        with tarfile.open(fileobj=output,mode="w:gz") as tar:
            for p in sorted(OUT.rglob("*")):
                if p.is_file() and p.relative_to(OUT).parts[0] != "tmp":
                    tar.add(p,arcname=str(p.relative_to(OUT)))
    raw=archive.read_bytes()
    info={"path":str(archive),"bytes":len(raw),"sha256":digest(raw),
          "result":"PASS" if error is None else "FAIL","result_directory":str(OUT)}
    with OUT.with_suffix(".archive.json").open("x") as output:
        json.dump(info,output,indent=2,sort_keys=True);output.write("\n")
    print(json.dumps(info,sort_keys=True),flush=True)
sys.exit(0 if error is None else 1)
