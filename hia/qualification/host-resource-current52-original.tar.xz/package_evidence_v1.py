import hashlib,json,os,stat,sys,tarfile,time,traceback
from pathlib import Path
ROOT=Path("/tmp/trnm-resource-current52-original-20261116-c0mq1616")
REPO=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo")
OUT=ROOT/"qualification"
def ident(p):
 h=hashlib.sha256();n=0
 with p.open("rb") as f:
  while raw:=f.read(1048576):h.update(raw);n+=len(raw)
 return {"bytes":n,"sha256":h.hexdigest()}
def check(ok,msg):
 if not ok:raise ValueError(msg)
(ROOT/"package_evidence_v1.py").write_text(sys.orig_argv[sys.orig_argv.index("-c")+1])
r=json.loads((ROOT/"reconciled-evidence-v1.json").read_bytes())
check(r["status"]=="PASS","Reconciliation not complete")
proof=json.loads((ROOT/"durable-process-observations.json").read_bytes())
for name,code in (("first_wrapper",1),("reconciliation",0)):
 terminal=proof[name]["terminal"]
 check(terminal["exit_code"]==code and terminal["output_complete"] and terminal["output_durable"] and terminal["terminal_publication_confirmed"],"Durable terminal not complete")
check(proof["reconciliation"]["idempotent_recovery_start"]["reused"] is True,"Unknown launch retried as new")
files={}
def add(path,arcname=None):
 check(path.is_file() and not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode),"Not owned regular evidence "+str(path))
 name=arcname or path.relative_to(ROOT).as_posix()
 check(name not in files,"Duplicate archive member "+name)
 files[name]={"path":str(path),**ident(path)}
for p in sorted(ROOT.iterdir()):
 if p.is_file() and not p.is_symlink() and p.name!="original-test-binary":add(p)
for p in sorted((OUT/"original").iterdir()):
 if p.is_file():add(p)
 elif p.name!="isolated-source" and p.is_dir() and not p.is_symlink():
  for f in sorted(p.iterdir()):
   if f.is_file() and not f.is_symlink():add(f)
for p in sorted((OUT/"native").iterdir()):
 if p.is_file():add(p)
physical=OUT/"native/physical"
for p in sorted(physical.iterdir()):
 if p.is_file() and not p.is_symlink():add(p)
 if p.name=="build":
  for f in sorted(p.rglob("*")):
   if f.is_file() and not f.is_symlink():add(f)
 elif p.is_dir() and not p.is_symlink():
  # Cases contain deliberate unreadable/symlink fixtures. Only direct receipt
  # files are collected; fixture trees and external targets are never walked.
  for child in sorted(p.iterdir()):
   if child.is_file() and not child.is_symlink():add(child)
   elif child.is_dir() and not child.is_symlink():
    for f in sorted(child.iterdir()):
     if f.is_file() and not f.is_symlink():add(f)
for relative,expected in r["source_inputs"].items():
 p=REPO/relative;check(ident(p)==expected,"Frozen52 source changed")
 add(p,"source-inputs/"+relative)
summary={k:r[k] for k in ("schema","status","prior_wrapper_job","prior_wrapper_terminal_exit","prior_wrapper_failure","original_execution_rerun","actual_qualifier_process","actual_original_process_stages","native_controls","native_semantic","native_physical","native_trace","actual_original_cases","actual_original_operations","retained_original_summary","actual_rustc","independent_binary","native_report","native_comparison","original_report","original_comparison","exact_corpus","prior_wrapper_record","source_set_sha256","original_source_set_sha256","source_inputs","production_fixed_parent_positive_qualified","full_node_or_paid_account")}
summary.update(schema="trnm.hia.resource-current52-development-evidence.v1",repository=str(REPO),base_head="34ecf1bd11264bb78df19836e0eb4b6665ed2cec",base_tree="6e21f6fe51fad0a7e89fbbe6042c175bb5cba246",root=str(ROOT),original_source_count=len(r["original_sources"]),source_count=len(r["source_inputs"]),wrapper_metadata_status_was_stale_running_after_exception=True,full_report=ident(ROOT/"reconciled-evidence-v1.json"),durable_process_observations=ident(ROOT/"durable-process-observations.json"),actual_wrapper_terminal=proof["first_wrapper"]["terminal"],actual_reconciliation_terminal=proof["reconciliation"]["terminal"],actual_reconciliation_output=proof["reconciliation"]["complete_output"],independent_binary_not_embedded_in_compressed_archive=True)
small=ROOT/"development-evidence-summary.json";small.write_text(json.dumps(summary,sort_keys=True,indent=2)+"\n");add(small)
manifest=ROOT/"evidence-file-manifest.json";manifest.write_text(json.dumps({"schema":"trnm.hia.source-bound-evidence-archive.v1","files":files,"binary_separate":r["independent_binary"],"excluded":["qualification/original/isolated-source","shared Cargo cache","deliberately unsafe fixture subtrees"],"qualification_status_not_modified":True},sort_keys=True,indent=2)+"\n")
archive=ROOT/"resource-current52-original-evidence.tar.xz"
with tarfile.open(archive,"x:xz",preset=1) as t:
 for name,row in sorted(files.items()):
  p=Path(row["path"]);check(ident(p)=={"bytes":row["bytes"],"sha256":row["sha256"]},"Evidence changed before archive "+name)
  t.add(p,arcname=name,recursive=False)
 t.add(manifest,arcname=manifest.name,recursive=False)
identity={"schema":"trnm.hia.resource-current52-archive-identity.v1","status":"PASS","archive":{"path":str(archive),**ident(archive)},"manifest":{"path":str(manifest),**ident(manifest)},"summary":{"path":str(small),**ident(small)},"full_report":{"path":str(ROOT/"reconciled-evidence-v1.json"),**ident(ROOT/"reconciled-evidence-v1.json")},"entries":len(files)+1,"binary_separate":r["independent_binary"]}
p=ROOT/"archive-identity.json";p.write_text(json.dumps(identity,sort_keys=True,indent=2)+"\n")
print(json.dumps(identity),flush=True)
