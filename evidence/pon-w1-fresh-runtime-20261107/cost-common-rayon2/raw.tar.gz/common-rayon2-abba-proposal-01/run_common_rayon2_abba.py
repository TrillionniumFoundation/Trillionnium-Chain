#!/usr/bin/env python3
"""One unfunded common-Rayon-2 ABBA cost study using frozen A's comparator.

No proof is generated here. A binding file made from the two actual completed
generation jobs is mandatory; the accompanying template cannot be executed.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
REPO = ROOT / "repo"
A = "d3037ca5dfb6f301757c159b7888dca9b0317be0"
TREE = "d4a8f84cdc896b9454ce0d03a164f8916e6afdf9"
SCHEMA = "TRNM-W1-COMMON-RAYON2-ABBA-STUDY1"
BINDING_SCHEMA = "TRNM-W1-COMMON-RAYON2-ABBA-BINDING1"
SOURCE_SHA = "e2e1d88b8bb08d6da57361287d3f76df9f78299fb5a44b45d3bdb0ea61c08556"
QUALIFICATION_SHA = "cc52956605ae4d4abc75084c04ba312c7baab316b4ac3d0ad18097ed3ab71b57"
VERIFY_PATH = ROOT / "target-native/release/w1-verify-v2"
VERIFY_SHA = "582b53d8607cca6ec228c18de8047e1d6564f0fd9cd3cdeafa06c66f460ad3d5"
COMPARE_REL = "scripts/run_w1_deployment_comparison.py"
COMPARE_SHA = "20298a5836fb7322a713304be407e7f09238d24d758fdcd9bf2ec49fe8d7eae0"
STAGE_REL = "formal/pon-nakamoto-v1/experiments/w1_stage_measure.py"
STAGE_SHA = "a3c80e25ec202749225ddd1a4fc45f3f22ab753f5e9e6941e694a3aa4a547df9"
RUNTIME_REL = "scripts/w1_owned_generation_runtime_v2.py"
RUNTIME_SHA = "500f2712942ff2e5f46e82cb2fb1a5d514be55a9ca6e851b7cede79374c15119"
EXPECTED_SHA = "802adcdd951cfb4cd7271df22c3bca6af66fee9f40454c74f8b5ff2c98a1b683"
HEADER_SHA = "7b96038f228a1eedccf7b29ffc54802aba691be7259e33937846c6bf6126d78f"
ARM_IDS = ["generation-arm-1", "generation-arm-2"]
ORDER = ["native", "proof", "proof", "native"] * 10
WALL_NS = 600_000_000_000


def need(value, message):
    if not value:
        raise ValueError(message)


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def read_json(path, limit=16 * 1024 * 1024):
    with Path(path).open("rb") as stream:
        raw = stream.read(limit + 1)
    need(len(raw) <= limit, "bounded JSON")
    value = json.loads(raw, object_pairs_hook=strict_object,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))
    need(type(value) is dict, "JSON object")
    return value


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def record(path):
    path = Path(path)
    return {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(Path(path).parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def shape_pin(value):
    need(type(value) is dict and set(value) == {"path", "sha256", "bytes"}, "complete external pin")
    need(type(value["path"]) is str and Path(value["path"]).is_absolute(), "absolute external path")
    need(type(value["bytes"]) is int and value["bytes"] > 0, "positive pinned byte length")
    need(type(value["sha256"]) is str and len(value["sha256"]) == 64
         and all(c in "0123456789abcdef" for c in value["sha256"]), "external SHA256")


def pinned(value):
    shape_pin(value)
    path = Path(value["path"])
    need(path.is_file() and not path.is_symlink(), "regular pinned original")
    need(record(path) == value, "externally bound original bytes changed")
    return path


def declaration(observer_path, observer_sha):
    return {"schema": SCHEMA, "execution_status": "NOT_RUN", "binding_status": "WAITING_FOR_ACTUAL_GENERATION_TERMINALS",
        "source_commit": A, "source_tree": TREE, "observer": {"path": str(Path(observer_path).resolve()), "sha256": observer_sha},
        "output": str(ROOT / "common-rayon2-abba-A-01"),
        "arm_order": ARM_IDS, "planned_order_per_arm": ORDER, "planned_total_rows": 80,
        "abbreviations": {"ABBA_A": "native full replay", "ABBA_B": "fixed receipt full verification",
                          "generation_arm": "one externally bound complete receipt, not an ABBA letter"},
        "common_conditions": {"cpu_quota_percent": 200, "memory_max_bytes": 8 * 1024**3,
                              "cpu_affinity": [8, 9], "rayon_threads": 2, "abba_repeats_per_arm": 10},
        "local_cost_deadline_ns": WALL_NS, "deadline_scope": "one new local cost-only clock for both arms",
        "main_generation_deadline_extended": False, "main_7200s_task_mutated": False,
        "stop_rule": "stop new arm dispatch after any failed arm, cancellation, unknown closure, or local cost deadline; retain all 80 planned rows",
        "prior_internal_rayon_threads": [4, 8],
        "prior_internal_comparisons": "preserve original raw observations under their own 4/8-thread conditions; do not pool with common2",
        "outer_term_grace_seconds": 12, "inner_term_grace_seconds": 5,
        "emergency_owned_cgroup_cleanup_seconds": 5, "cleanup_extends_cost_eligibility": False,
        "fresh_proof_generations": 0, "same_host_load_fully_controlled": False,
        "resource_accounting_complete": False, "population_tail_established": False,
        "funded_owner_or_admission_qualified": False,
        "statistics": "reuse frozen A comparator; ratio of finite inner medians, nearest-rank finite p95/p99; no ratio-of-paired-samples claim"}


def validate_declaration(value, observer_path):
    need(type(value.get("observer")) is dict, "observer identity")
    digest = value["observer"].get("sha256")
    need(type(digest) is str and len(digest) == 64 and all(c in "0123456789abcdef" for c in digest), "observer SHA")
    need(value == declaration(observer_path, digest), "fixed study declaration changed")


def binding_shape(value):
    need(value.get("schema") == BINDING_SCHEMA and value.get("state") == "BOUND_ACTUAL_TERMINALS", "binding is still unobserved")
    need(value.get("source_commit") == A and value.get("source_tree") == TREE, "generation source must be A")
    context = value.get("statement")
    need(type(context) is dict and set(context) == {"input", "header", "expected_artifacts"}, "one common external statement")
    for pin in context.values():
        shape_pin(pin)
    need(context["input"]["bytes"] == 49506 and context["header"]["bytes"] == 318
         and context["header"]["sha256"] == HEADER_SHA
         and context["expected_artifacts"]["bytes"] == 64
         and context["expected_artifacts"]["sha256"] == EXPECTED_SHA, "fixed independent statement identity")
    arms = value.get("arms")
    need(type(arms) is list and len(arms) == 2 and [a.get("id") for a in arms] == ARM_IDS, "both predeclared generation arms")
    for index, arm in enumerate(arms):
        need(arm.get("source_commit") == A and arm.get("prior_requested_rayon_threads") == [4, 8][index],
             "generation/prior-comparison identity changed")
        for key in ("receipt", "generation_terminal"):
            shape_pin(arm.get(key))
        previous = arm.get("prior_internal_comparison")
        need(previous is None or type(previous) is dict, "prior observation must be raw pin or UNOBSERVED null")
        if previous is not None:
            shape_pin(previous)


def load_binding(path, expected_sha):
    need(sha(path) == expected_sha, "independent binding digest mismatch")
    value = read_json(path)
    binding_shape(value)
    for pin in value["statement"].values():
        pinned(pin)
    need(Path(value["statement"]["input"]["path"]).read_bytes()[:318]
         == Path(value["statement"]["header"]["path"]).read_bytes(), "input/header disagreement")
    terminals = []
    for arm in value["arms"]:
        pinned(arm["receipt"])
        terminal = read_json(pinned(arm["generation_terminal"]))
        need(terminal.get("state") in {"succeeded", "failed", "cancelled", "timed_out"}
             and type(terminal.get("exit_code")) is int
             and terminal.get("output_complete") is True and terminal.get("output_durable") is True
             and type(terminal.get("job_id")) is str and terminal["job_id"], "actual full generation job is not durably terminal")
        # Nonzero terminal remains nonzero evidence. The new actual verifier may
        # reject the receipt. No generation success is manufactured by binding.
        terminals.append(terminal)
        if arm.get("prior_internal_comparison") is not None:
            pinned(arm["prior_internal_comparison"])
    need(terminals[0]["job_id"] != terminals[1]["job_id"], "two arm origins cannot silently reuse one job")
    return value, terminals


def resource_guard(value, affinity):
    parts = value["cpu_max"].split()
    need(len(parts) == 2 and all(x.isdecimal() for x in parts), "finite actual CPU control")
    q, p = map(int, parts)
    need(p > 0 and q == 2 * p, "actual CPUQuota must be 200 percent")
    need(value["memory_max"] == str(8 * 1024**3) and affinity == [8, 9], "actual memory/affinity changed")


def comparison_argv(binding, arm, out, deadline_ns, boot):
    s = binding["statement"]
    return ["/usr/bin/python3", str(REPO / COMPARE_REL),
            "--verifier", str(VERIFY_PATH), "--verifier-sha256", VERIFY_SHA,
            "--receipt", arm["receipt"]["path"], "--input", s["input"]["path"],
            "--header", s["header"]["path"], "--expected-artifacts", s["expected_artifacts"]["path"],
            "--out", str(out), "--repeats", "10", "--wall-seconds", "600",
            "--deadline-monotonic", repr(deadline_ns / 1e9), "--deadline-boot-id", boot]


def planned_ledger():
    return [{"arm": arm, "index": i, "kind": kind, "dispatched": False, "accepted": False,
             "observation": None, "state": "NOT_DISPATCHED"}
            for arm in ARM_IDS for i, kind in enumerate(ORDER)]


def validate_rows(report, arm, binding):
    need(report.get("schema") == "TRNM-W1-DEPLOYMENT-COMPARISON2"
         and report.get("planned_order") == ORDER, "comparison planned denominator/order changed")
    rows = report.get("rows")
    need(type(rows) is list and len(rows) <= 40, "bounded real rows")
    statement = binding["statement"]
    ids = report.get("identities", {})
    for key in ("input", "header", "expected_artifacts"):
        need(ids.get(key + "_sha256") == statement[key]["sha256"], "common statement changed")
    need(ids.get("receipt_sha256") == arm["receipt"]["sha256"] and ids.get("verifier_sha256") == VERIFY_SHA,
         "fixed receipt/verifier identity changed")
    for index, row in enumerate(rows):
        need(type(row.get("index")) is int and row["index"] == index
             and row.get("kind") == ORDER[index] and row.get("dispatched") is True, "noncanonical actual row")
        stage = row.get("stage")
        if stage is not None:
            need(stage.get("environment", {}).get("RAYON_NUM_THREADS") == "2", "mixed Rayon condition in actual row")
        if row.get("accepted") is True:
            need(stage is not None and stage.get("stage_process_complete") is True
                 and stage.get("returncode") == 0 and stage.get("canceled_signal") is None
                 and stage.get("termination_reasons") == [], "accepted row has failed process")
    return rows


def complete_report(report, process, cancellation_sidecar):
    return (process.get("stage_process_complete") is True and process.get("returncode") == 0
            and report.get("operation_complete") is True and report.get("error") is None
            and report.get("cancellation_event") is None and not cancellation_sidecar
            and len(report.get("rows", [])) == 40
            and all(row.get("accepted") is True for row in report["rows"])
            and report.get("cost_comparison") is not None and report.get("fresh_proof_generations") == 0)


def import_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def audit_command(argv, directory, label, measure, deadline_ns=None):
    stage_out = directory / (label + "-process")
    result = measure.measure(list(map(str, argv)), stage_out, 120.,
                             deadline=deadline_ns / 1e9 if deadline_ns is not None else None,
                             environment_overrides={"PYTHONDONTWRITEBYTECODE": "1"})
    row = {"argv": list(map(str, argv)), "exit": result["returncode"], "label": label,
           "stage_result": record(stage_out / "result.json"),
           "stdout": record(stage_out / "stdout.log"), "stderr": record(stage_out / "stderr.log")}
    write_new(directory / (label + "-command.json"), row)
    need(result.get("stage_process_complete") is True and result["returncode"] == 0, "required audit command failed")
    return row


def source_check(out, label, measure, deadline_ns=None):
    target = out / (label + ".json")
    row = audit_command(["/usr/bin/python3", str(REPO / "scripts/ci/verify_ci_source.py"),
                         "--kind", "head", "--expected-head", A, "--output", str(target)],
                        out, label, measure, deadline_ns)
    need(sha(target) == SOURCE_SHA, "exact A source report changed")
    return {"command": row, "report": record(target)}


def source_pins():
    return [(REPO / COMPARE_REL, COMPARE_SHA), (REPO / STAGE_REL, STAGE_SHA),
            (REPO / RUNTIME_REL, RUNTIME_SHA), (VERIFY_PATH, VERIFY_SHA),
            (ROOT / "clean-A-build-qualification-01/qualification.json", QUALIFICATION_SHA)]


def run(args, measure):
    need(sha(args.declaration) == args.declaration_sha256, "external study declaration changed")
    declared = read_json(args.declaration)
    validate_declaration(declared, __file__)
    need(sha(__file__) == declared["observer"]["sha256"], "observer source changed")
    binding, terminals = load_binding(args.binding, args.binding_sha256)  # Fails before any benchmark if unbound.
    out = Path(declared["output"])
    need(out == ROOT / "common-rayon2-abba-A-01", "exclusive new output")
    out.mkdir(exist_ok=False)
    write_new(out / "declaration-copy.json", declared)
    write_new(out / "binding-copy.json", binding)
    audit = out / "audit"
    audit.mkdir()
    ledger = planned_ledger()
    arm_records, setup, reports = [], [], []
    scope = before = after = None
    source_before = source_after = None
    started = deadline_ns = None
    failure = None
    complete = False
    boot = measure.local_boot_id()
    setup_started = time.monotonic_ns()
    try:
        os.chdir(REPO)
        os.sched_setaffinity(0, {8, 9})
        setup.append(audit_command(["/usr/bin/bash", "scripts/project-preflight.sh", "--dev"], audit, "preflight", measure))
        source_before = source_check(audit, "source-before", measure)
        for path, digest in source_pins():
            need(sha(path) == digest, "pinned program/source changed")
        sys.path.insert(0, str(REPO / "scripts"))
        runtime = import_module("common2_owned_runtime", REPO / RUNTIME_REL)
        scope = runtime.Scope({})
        before = scope.snapshot()
        resource_guard(before, sorted(os.sched_getaffinity(0)))
        need(not scope.remaining(), "foreign new work already in job scope")
        setup_finished = time.monotonic_ns()
        write_new(out / "setup.json", {"commands": setup, "started_monotonic_ns": setup_started,
                   "finished_monotonic_ns": setup_finished, "source": source_before,
                   "existing_qualification": record(ROOT / "clean-A-build-qualification-01/qualification.json")})
        started = time.monotonic_ns()
        deadline_ns = started + WALL_NS
        write_new(out / "cost-origin.json", {"schema": SCHEMA, "started_monotonic_ns": started,
                   "local_cost_deadline_monotonic_ns": deadline_ns, "clock_boot_id": boot,
                   "main_generation_deadline_extended": False, "planned_rows": ledger})
        for arm_index, arm in enumerate(binding["arms"]):
            need(time.monotonic_ns() < deadline_ns and measure.local_boot_id() == boot, "original cost deadline exhausted")
            load_binding(args.binding, args.binding_sha256)
            resource_guard(scope.snapshot(), sorted(os.sched_getaffinity(0)))
            arm_out = out / arm["id"]
            stage_out = out / ("observe-" + arm["id"])
            observation = {"arm": arm["id"], "dispatch_attempted": True,
                           "comparison_output_directory": str(arm_out), "observer_directory": str(stage_out),
                           "process": None, "comparison": None, "error": None}
            for item in ledger[arm_index * 40:(arm_index + 1) * 40]:
                item.update(dispatched=None, accepted=None, state="DISPATCH_UNOBSERVED_WITHIN_ATTEMPTED_ARM")
            arm_records.append(observation)
            try:
                process = measure.measure(comparison_argv(binding, arm, arm_out, deadline_ns, boot),
                          stage_out, 600., deadline=deadline_ns / 1e9,
                          environment_overrides={"RAYON_NUM_THREADS": "2", "PYTHONDONTWRITEBYTECODE": "1"},
                          termination_grace_seconds=12)
                observation["process"] = record(stage_out / "result.json")
            except BaseException as caught:
                snapshot = getattr(caught, "observed_snapshot", None)
                if snapshot and snapshot.get("kind") == "stage":
                    observation["process"] = {key: snapshot[key] for key in ("path", "sha256")}
                observation["error"] = {"type": type(caught).__name__, "message": str(caught)}
                raise
            finally:
                # A raw prefix is a fact; neither a later signal nor a retention
                # I/O error may erase the actual primary cancellation.
                primary = sys.exc_info()[1]
                prior_cancel = primary if isinstance(primary, (measure.Canceled, KeyboardInterrupt)) else None
                with measure.DeferredCancellation(prior_cancel, phase="common2-arm-prefix",
                         live_deadline=(deadline_ns / 1e9, boot)) as prefix_handoff:
                    if (arm_out / "result.json").is_file():
                        observation["comparison"] = record(arm_out / "result.json")
                        try:
                            value = read_json(arm_out / "result.json")
                            actual_rows = validate_rows(value, arm, binding)
                            for pending in ledger[arm_index * 40 + len(actual_rows):(arm_index + 1) * 40]:
                                pending.update(dispatched=False, accepted=False, state="NOT_DISPATCHED_BY_COMPARATOR")
                            for row in actual_rows:
                                target = ledger[arm_index * 40 + row["index"]]
                                target.update(dispatched=True, accepted=row.get("accepted") is True,
                                              state="ACCEPTED" if row.get("accepted") is True else "REJECTED",
                                              observation={"comparison_result": str(arm_out / "result.json"), "row_index": row["index"]})
                        except Exception as read_error:
                            observation["readback_error"] = {"type": type(read_error).__name__, "message": str(read_error)}
                    prefix_path = out / (arm["id"] + "-observation.json")
                    write_new(prefix_path, observation)
                    prefix_handoff.published_snapshot("common2-arm-prefix", prefix_path)
            need(observation.get("readback_error") is None and observation["comparison"] is not None, "raw comparison unavailable")
            report = read_json(arm_out / "result.json")
            validate_rows(report, arm, binding)
            need(complete_report(report, process, (arm_out / "operation-cancellation.json").exists()),
                 "comparison did not finish all forty actual rows")
            reports.append(report)
            need(time.monotonic_ns() < deadline_ns, "cost deadline exhausted after arm handoff")
        work_ids = [{row["verifier_report"]["work_id"] for row in report["rows"]} for report in reports]
        need(len(work_ids[0]) == 1 and work_ids[0] == work_ids[1], "arms verified different complete work claims")
        need(reports[0]["identities"]["journal_sha256"] == reports[1]["identities"]["journal_sha256"],
             "arms verified different full public journals")
        need(scope.wait_empty(deadline_ns), "owned processes did not close before cost deadline")
        complete = time.monotonic_ns() < deadline_ns
    except BaseException as caught:
        failure = caught

    prior = failure if isinstance(failure, (measure.Canceled, KeyboardInterrupt)) else None
    cleanup_known = False
    audit_errors = []
    try:
        live = (deadline_ns / 1e9, boot) if deadline_ns is not None else None
        with measure.DeferredCancellation(prior, phase="common2-study-publication", live_deadline=live) as handoff:
            if scope is not None:
                try:
                    cleanup_known = not scope.remaining() or scope.cleanup()
                    after = scope.snapshot()
                    resource_guard(after, sorted(os.sched_getaffinity(0)))
                except BaseException as caught:
                    audit_errors.append({"scope": "owned-cleanup", "type": type(caught).__name__, "message": str(caught)})
            try:
                load_binding(args.binding, args.binding_sha256)
                need(sha(args.declaration) == args.declaration_sha256 and sha(__file__) == declared["observer"]["sha256"],
                     "original study changed")
                for path, digest in source_pins():
                    need(sha(path) == digest, "pinned source/program changed")
                source_after = source_check(audit, "source-after", measure, deadline_ns)
            except BaseException as caught:
                audit_errors.append({"scope": "source-audit", "type": type(caught).__name__, "message": str(caught)})
            final_complete = (complete and failure is None and handoff.canceled_signal is None and cleanup_known
                              and not audit_errors and deadline_ns is not None and time.monotonic_ns() < deadline_ns)
            cost = None
            if final_complete:
                cost = {"per_arm": [r["cost_comparison"] for r in reports],
                        "arm2_over_arm1_proof_inner_median": reports[1]["cost_comparison"]["proof"]["verifier_inner_ns"]["median"]
                                                               / reports[0]["cost_comparison"]["proof"]["verifier_inner_ns"]["median"],
                        "scope": "ratio of two finite proof-verification medians under common requested conditions; not a paired ratio, new proof generation, or population tail"}
            report = {"schema": SCHEMA, "declaration": record(args.declaration), "binding": record(args.binding),
                "source_commit": A, "source_tree": TREE, "operation_complete": final_complete,
                "error": None if failure is None else {"type": type(failure).__name__, "message": str(failure)},
                "canceled_signal": handoff.canceled_signal, "cancellation_event": handoff.pending_event(),
                "audit_errors": audit_errors, "planned_rows": ledger, "arm_observations": arm_records,
                "generation_terminals_preserved": terminals, "source_before": source_before, "source_after": source_after,
                "local_cost_started_monotonic_ns": started, "local_cost_deadline_monotonic_ns": deadline_ns,
                "clock_boot_id": boot, "deadline_exhausted_at_snapshot": deadline_ns is not None and time.monotonic_ns() >= deadline_ns,
                "scope_before": before, "scope_after": after, "owned_scope_closed_observed": cleanup_known,
                "single_cgroup_cpu_delta_including_cleanup_and_setup_overlap_ns":
                    after["cpu_usage_ns"] - before["cpu_usage_ns"] if before and after else None,
                "resource_note": "do not sum this scope with nested stage wait4 CPU; memory peak includes setup",
                "cost_comparison": cost, "fresh_proof_generations": 0,
                "distinct_receipt_byte_identities": len({a["receipt"]["sha256"] for a in binding["arms"]}),
                "main_generation_deadline_extended": False, "funded_owner_or_admission_qualified": False,
                "population_tail_established": False, "result_is_pre_handoff_snapshot": True,
                "real_exit_zero_and_no_operation_cancellation_sidecar_required": True}
            write_new(out / "result.json", report)
            handoff.published_snapshot("common2-study", out / "result.json")
    except (measure.Canceled, KeyboardInterrupt) as caught:
        measure.publish_cancellation(out / "operation-cancellation.json", caught, "common-rayon2-abba")
    print(json.dumps({"schema": SCHEMA, "operation_complete": report["operation_complete"],
                      "result": str(out / "result.json"), "fresh_proof_generations": 0}))
    if deadline_ns is not None and time.monotonic_ns() >= deadline_ns:
        return 124
    return 0 if report["operation_complete"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", required=True)
    parser.add_argument("--declaration", type=Path, required=True)
    parser.add_argument("--declaration-sha256", required=True)
    parser.add_argument("--binding", type=Path, required=True)
    parser.add_argument("--binding-sha256", required=True)
    args = parser.parse_args()
    need(sha(REPO / STAGE_REL) == STAGE_SHA, "A measurement source changed")
    measure = import_module("common2_stage", REPO / STAGE_REL)
    def execute():
        with measure.cancel_on_signals():
            return run(args, measure)
    return measure.run_cli(execute)


if __name__ == "__main__":
    raise SystemExit(main())
