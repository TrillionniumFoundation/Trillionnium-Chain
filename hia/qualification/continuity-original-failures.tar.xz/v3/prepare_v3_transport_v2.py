import hashlib,json,lzma,sys,tarfile,time
from pathlib import Path,PurePosixPath
ROOT=Path("/tmp/trnm-continuity-original-20261116-jvd8w4er")
SOURCE=Path("/tmp/trnm-continuity-recovery-20261116-1b30xc0r/continuity-native-v3-original-bundle.tar.xz")
SHA="e369ca94f46f70956e32774ce5e4246ac31000836e80011e5ffebd06f93dd4b6"
def sha(raw):return hashlib.sha256(raw).hexdigest()
def ident(raw):return {"bytes":len(raw),"sha256":sha(raw)}
def require(ok,msg):
 if not ok:raise ValueError(msg)
(ROOT/"prepare_v3_transport_v2.py").write_text(sys.orig_argv[sys.orig_argv.index("-c")+1])
raw=SOURCE.read_bytes();require(len(raw)==2655516 and sha(raw)==SHA,"Whole immutable package identity")
with tarfile.open(SOURCE,"r:xz") as t:
 members=t.getmembers();names=[m.name for m in members];require(len(names)==72 and len(set(names))==72,"Unique72 members")
 for m in members:
  p=PurePosixPath(m.name);require(m.isfile() and not p.is_absolute() and str(p)==m.name and all(x not in ("",".","..") for x in p.parts),"Unsafe package member")
 blobs={m.name:t.extractfile(m).read() for m in members}
 require(all(len(blobs[m.name])==m.size for m in members),"Short archived member")
comparison=json.loads(blobs["bundle/native-comparison.json"]);report=json.loads(blobs["bundle/native-report.json"])
sources=comparison["build"]["source_inputs"]
require(len(sources)==61 and sum(p.startswith("hia/platform/continuity_store/") for p in sources)==18 and sum(p.startswith("hia/platform/typed_store/") for p in sources)==13,"Complete61 with18own13typed")
require(comparison["build"]["status"]=="PASS" and comparison["build"]["source_set_sha256"]=="5dad817d1bb956313e8a96f6c4fb57b56d0358237cebf530f8f2bcb0fc7137c8","Frozen V3 source set")
for p,v in sources.items():require(ident(blobs[p])==v,"Exact captured source "+p)
require(sha(json.dumps(sources,sort_keys=True,separators=(",",":")).encode())==comparison["build"]["source_set_sha256"],"Recomputed source digest")
require(report["control_journal"]["records"]==659 and report["comparison_journal"]["records"]==572,"Actual journal counts")
archives={}
decoded={}
for name,entry in report["archives"].items():
 compressed=blobs["bundle/"+name+".xz"];require(ident(compressed)==entry["archive"],"Compressed journal identity "+name)
 decoder=lzma.LZMADecompressor(format=lzma.FORMAT_XZ,memlimit=64<<20)
 decoded_raw=decoder.decompress(compressed,max_length=(512<<20)+1)
 require(decoder.eof and not decoder.unused_data and len(decoded_raw)<=512<<20 and ident(decoded_raw)==entry["raw"],"Complete raw journal identity "+name)
 decoded[name]=decoded_raw;archives[name]={"raw":ident(decoded_raw),"archive":ident(compressed),"lines":len(decoded_raw.splitlines())}
require(archives["control-records.jsonl"]["lines"]==659 and archives["comparison-records.jsonl"]["lines"]==572 and archives["corpus.jsonl"]["lines"]==572,"Actual complete record lines")
controls=[json.loads(line) for line in decoded["control-records.jsonl"].splitlines()]
matches=[json.loads(line) for line in decoded["comparison-records.jsonl"].splitlines()]
require(all(row.get("status")=="PASS" for row in controls),"Actual journal contains incomplete native controls")
history=lzma.decompress(blobs["history/continuity-536-corpus.jsonl.xz"])
require(len(history)==1939076 and sha(history)=="1fc35f3b3e81e697a6086c044e5372165957a50ff37e03f8d115ced8d282d34f","Frozen original536 history")
require(decoded["corpus.jsonl"].splitlines()[:536]==history.splitlines(),"Original536 actual input order preserved")
chunks=ROOT/"chunks"
if chunks.exists():require(chunks.is_dir() and not chunks.is_symlink() and not list(chunks.iterdir()),"Existing chunk directory must be empty")
else:chunks.mkdir(mode=0o700)
rows=[]
for i,start in enumerate(range(0,len(raw),60000)):
 part=raw[start:start+60000];name=f"chunk-{i:04d}.bin"
 with (chunks/name).open("xb") as f:f.write(part)
 rows.append({"name":name,"offset":start,**ident(part)})
transfer={"package_sha256":SHA,"package_bytes":len(raw),"head":"453326b335af9375f2f6796d4e906cb4cdf2ce4d","tree":"fc5a31e67b207078ee1b01ad98e918df11ad8b8f","chunks":rows}
(chunks/"transfer.json").write_text(json.dumps(transfer,sort_keys=True,indent=2)+"\n")
require(ident(SOURCE.read_bytes())==ident(raw),"Owner package changed during capture")
summary={"schema":"trnm.hia.continuity-v3-local-transport-admission.v1","status":"TRANSPORT_AND_JOURNAL_IDENTITIES_PASS_ORIGINAL_NOT_RUN","package":{"path":str(SOURCE),**ident(raw)},"comparison":ident(blobs["bundle/native-comparison.json"]),"native_report":ident(blobs["bundle/native-report.json"]),"report_keys":list(report),"report_status":report["status"],"control_keys":list(controls[0]),"first_compact_control":report["controls"][0],"comparison_keys":list(comparison),"comparison_record_keys":list(matches[0]),"archives":archives,"source_count":len(sources),"source_set_sha256":comparison["build"]["source_set_sha256"],"journal_all_status_pass":True,"original536_unchanged":True,"transfer":transfer,"context_keys":list(comparison["contexts"]),"finished_unix_ns":time.time_ns()}
p=ROOT/"v3-transport-admission.json";p.write_text(json.dumps(summary,sort_keys=True,indent=2)+"\n")
print(json.dumps({k:v for k,v in summary.items() if k!="transfer"}),flush=True)
