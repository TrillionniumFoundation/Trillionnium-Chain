"""Retain actual observations and verify every byte of the resulting archives."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import lzma
import tarfile

BASE = Path('/workspace/scratch/a638c5cc4765')
ROOT = BASE / 'Trillionnium-Chain'
FINAL = BASE / 'owner-extension-final-v2'
FAILED = BASE / 'owner-extension-final'

def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()

def safe(name):
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and str(path) == name and '\\' not in name

class Package:
    def __init__(self, label):
        self.label = label
        self.entries = {}
    def file(self, name, path):
        safe(name)
        assert name not in self.entries and path.is_file() and not path.is_symlink(), (name, path)
        data = path.read_bytes()
        self.entries[name] = {'path': path, 'mode': 0o755 if path.stat().st_mode & 0o111 else 0o644, **identity(data)}
    def data(self, name, data):
        safe(name)
        assert name not in self.entries
        self.entries[name] = {'data': data, 'mode': 0o644, **identity(data)}
    def directory(self, prefix, directory, excluded=()):
        assert directory.is_dir() and not directory.is_symlink()
        count = size = 0
        for path in sorted(directory.rglob('*')):
            relative = path.relative_to(directory)
            if any(part in excluded for part in relative.parts):
                continue
            assert not path.is_symlink(), path
            if path.is_file():
                self.file(prefix + '/' + relative.as_posix(), path)
                count += 1
                size += path.stat().st_size
            else:
                assert path.is_dir(), path
        return {'files': count, 'bytes': size}
    def snapshot(self, prefix, source_map, root, overrides=None):
        overrides = overrides or {}
        for name, info in source_map.items():
            path = overrides.get(name, root / name)
            data = path.read_bytes()
            assert identity(data) == info, (prefix, name)
            self.data(prefix + '/' + name, data)
    def finish(self, metadata):
        self.data('PACKAGE.json', encoded(metadata))
        manifest = {'schema': 'trnm.hia.evidence-member-manifest.v1',
            'manifest_not_self_hashed': True,
            'payload_member_count': len(self.entries),
            'payload_total_bytes': sum(row['bytes'] for row in self.entries.values()),
            'members': [{'path': name, 'size': row['bytes'], 'sha256': row['sha256'], 'mode': row['mode']}
                for name, row in sorted(self.entries.items())]}
        manifest_raw = encoded(manifest)
        archive_path = ROOT / 'hia/qualification' / (self.label + '-development.tar.xz')
        assert not archive_path.exists()
        with archive_path.open('xb') as output:
            with tarfile.open(fileobj=output, mode='w:xz', format=tarfile.USTAR_FORMAT, preset=6) as archive:
                for name, row in sorted(self.entries.items()):
                    data = row.get('data') if 'data' in row else row['path'].read_bytes()
                    assert identity(data) == {'bytes': row['bytes'], 'sha256': row['sha256']}, name
                    info = tarfile.TarInfo(name)
                    info.size = len(data); info.mode = row['mode']; info.mtime = 0
                    archive.addfile(info, io.BytesIO(data))
                info = tarfile.TarInfo('MANIFEST.json')
                info.size = len(manifest_raw); info.mode = 0o644; info.mtime = 0
                archive.addfile(info, io.BytesIO(manifest_raw))
        compressed = archive_path.read_bytes()
        decoder = lzma.LZMADecompressor()
        plain = decoder.decompress(compressed)
        assert decoder.eof and not decoder.unused_data
        seen = set(); last_end = 0
        with tarfile.open(fileobj=io.BytesIO(plain), mode='r:') as archive:
            for member in archive:
                safe(member.name)
                assert member.isfile() and member.name not in seen
                seen.add(member.name)
                data = archive.extractfile(member).read()
                assert len(data) == member.size
                if member.name == 'MANIFEST.json':
                    assert data == manifest_raw
                else:
                    row = self.entries[member.name]
                    assert identity(data) == {'bytes': row['bytes'], 'sha256': row['sha256']}, member.name
                    assert member.mode == row['mode']
                last_end = member.offset_data + ((member.size + 511) // 512) * 512
        assert seen == set(self.entries) | {'MANIFEST.json'}
        assert len(plain) - last_end >= 1024 and not any(plain[last_end:])
        for name, row in self.entries.items():
            if 'path' in row:
                assert identity(row['path'].read_bytes()) == {'bytes': row['bytes'], 'sha256': row['sha256']}, name
        result = {'schema': 'trnm.hia.owner-extension-archive-readback.v1', 'result': 'PASS',
            'path': str(archive_path.relative_to(ROOT)), **identity(compressed),
            'regular_members': len(seen), 'logical_bytes': manifest['payload_total_bytes'] + len(manifest_raw),
            'manifest': identity(manifest_raw), 'single_xz_stream': True, 'complete_zero_tar_tail': True,
            'every_regular_member_rehashed': True, 'original_observations_unchanged': True,
            'runtime_reexecuted_by_packager': False}
        (BASE / (self.label + '-archive-readback.json')).write_bytes(encoded(result))
        print(json.dumps(result), flush=True)

def common(package, label, readback):
    included = {'final': package.directory('final', FINAL / label)}
    for suffix in ('.stdout.raw', '.stderr.raw', '.execution.json'):
        package.file('execution' + suffix, FINAL / (label + suffix))
    for name in ('source-before.json', 'source-after.json'):
        package.file('integration-' + name, FINAL / name)
    package.file('independent-readback.json', BASE / readback)
    included['initial-enospc-failure'] = package.directory('historical/enospc', FAILED / label, excluded=('original-target',))
    for suffix in ('.stdout.raw', '.stderr.raw', '.execution.json'):
        package.file('historical/enospc-execution' + suffix, FAILED / (label + suffix))
    return included

gov = Package('governance')
gov_report = json.loads((FINAL / 'governance/report.json').read_bytes())
included = common(gov, 'governance', 'governance-final-readback.json')
gov.snapshot('source-snapshots/final', gov_report['source_inputs'], ROOT)
work = BASE / 'governance-work'
for label in ('build-01', 'qualification-v1', 'qualification-partial-control', 'qualification-failure-control'):
    included[label] = gov.directory('historical/' + label, work / label)
    for suffix in ('.stdout.raw', '.stderr.raw'):
        path = work / (label + suffix)
        if path.is_file():
            gov.file('historical/' + label + suffix, path)
old = json.loads((work / 'qualification-partial-control/report.json').read_bytes())
gov.snapshot('source-snapshots/reporter-controls', old['source_inputs'], BASE / 'governance-next/Trillionnium-Chain',
    {'hia/tests/test_governance.py': work / 'historical-v3-source/test_governance.py'})
gov.file('historical/report-negative-control.py', work / 'report-negative-control.py')
gov.file('independent-reader.py', BASE / 'read_governance.py')
gov.finish({'schema': 'trnm.hia.governance.final-evidence-package.v1',
    'final_qualification': 'final/report.json', 'final_status': gov_report['status'],
    'tests': 10, 'comparisons': 94, 'public_operations': 6185, 'fixed_fixture_operations': 193,
    'original_retained_tests': {'governance': 45, 'audit': 3}, 'included_directories': included,
    'historical_limits': ['Initial compiler and index-assertion failures retain their actual available observations; they do not inherit the final source snapshot.',
        'The older partial/failure reporter controls have their exact captured source snapshot; the final harness additionally executes real timeout, spawn, setup and native-worker failure controls.',
        'ENOSPC prevented completion of the first merged run; its actual FAIL observations are preserved without repair.'],
    'excluded_redundant_prior_success_runs': ['qualification-v2', 'qualification-v3', 'qualification-v4', 'qualification-v4-final'],
    'whole_chain_native': False, 'old_stack_can_be_removed': False})

guard = Package('control-guard')
guard_report = json.loads((FINAL / 'control-guard/observations.json').read_bytes())
included = common(guard, 'control-guard', 'control-guard-final-readback.json')
source_map = {row['source_path']: {'bytes': row['size'], 'sha256': row['sha256']} for row in guard_report['source_inputs']}
guard.snapshot('source-snapshots/final', source_map, ROOT)
work = BASE / 'control-guard-work'
for label in ('first-native', 'first-original'):
    included[label] = guard.directory('historical/' + label, work / label)
guard.file('historical/first-authoring-failure.log', work / 'first-authoring-failure.log')
guard.file('independent-reader.py', BASE / 'read_control_guard.py')
guard.finish({'schema': 'trnm.hia.control-guard.final-evidence-package.v1',
    'final_qualification': 'final/observations.json', 'final_status': guard_report['result'],
    'tests': 14, 'actual_original_comparisons': 1361, 'actual_native_calls': 1367,
    'evaluations_in_successful_sessions': 462, 'original_retained_tests': 5, 'included_directories': included,
    'profile': guard_report['profile'], 'new_profile_not_an_original_production_provider': True,
    'native_worker_outputs': 'Complete parsed actual NativeModule observations; Rust and allocator process streams are retained as actual raw bytes.',
    'historical_limits': ['Historical first-build observations retain their own available artifacts and hashes, not the final source snapshot.',
        'The initial merged ENOSPC setup failure has no finalized successful observation report.'],
    'excluded_redundant_prior_success_runs': ['run1'],
    'whole_chain_native': False, 'old_stack_can_be_removed': False})
