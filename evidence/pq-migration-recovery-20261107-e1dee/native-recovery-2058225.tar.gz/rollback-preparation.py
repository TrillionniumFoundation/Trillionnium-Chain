import pathlib,os,json,hashlib,shutil,importlib.util,stat,time,sys
task=pathlib.Path("/home/qian-qi/work/chain-pq-migration-recovery-e1dee-20261106")
assert task.resolve()==task
spec=importlib.util.spec_from_file_location("native_runner",task/"native-validation-v1.py")
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
out=task/"records/rollback-preparation";out.mkdir(mode=0o700)
env=runner.load_environment("target-fixed");head=runner.FIXED
binary=task/"retained-checkpoint-fault-domain-probe"
assert runner.digest(binary)=="8151dfced4ed72986279e6bb4404dd9ac96ff0b1ef3ddbe40e62aff249395b70"
runner.record(task/"source",head,out,env,"preflight",["/bin/bash","scripts/project-preflight.sh"])
exercise=task/"exercise";node=exercise/"node";old=exercise/"old-node";preserved=exercise/"retained-current-node"
expected_names={"checkpoint.log",".checkpoint.log.head-v2",".checkpoint.log.lock-v2","local-pin.bin"}
def inventory(root):
 assert root.is_dir() and not root.is_symlink()
 assert {p.name for p in root.iterdir()}==expected_names
 result={}
 for p in sorted(root.iterdir()):
  info=p.lstat()
  assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
  result[p.name]={"sha256":runner.digest(p),"size":info.st_size,"mode":stat.S_IMODE(info.st_mode)}
 return result
before=inventory(node);old_before=inventory(old)
assert not preserved.exists()
assert not (exercise/"returned-from-x230.bin").exists()
os.rename(node,preserved)
shutil.copytree(old,node,symlinks=True)
for p in node.iterdir():
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW);os.fsync(fd);os.close(fd)
for p in [node,exercise]:
 fd=os.open(p,os.O_DIRECTORY|os.O_NOFOLLOW);os.fsync(fd);os.close(fd)
assert inventory(node)==old_before
assert inventory(preserved)==before
export=exercise/"fresh-export.bin"
assert runner.digest(export)=="6b1cbc4afafca25b15c40e849f827a387c3a1354be338494f1d2d7fe600e54d3"
os.rename(export,out/"preserved-pre-restore-export.bin")
restored=inventory(node)
runner.record(task/"source",head,out,env,"restored-missing-external-pin",
 [str(binary),"verify",str(node/"checkpoint.log"),str(exercise/"returned-from-x230.bin")],1)
assert inventory(node)==restored
runner.record(task/"source",head,out,env,"coherent-old-world-local-pin-counterexample",
 [str(binary),"verify",str(node/"checkpoint.log"),str(node/"local-pin.bin")],0)
assert inventory(node)==restored
result={"schema":"trnm-isolated-node-rollback-preparation-v1","created_unix_ns":time.time_ns(),"source":head,
 "probe_sha256":runner.digest(binary),"retained_new_world":str(preserved),"restored_namespace":str(node),
 "custody_host":"x230","custody_fsync_job":"1a1b34e0fc9-fc05-81e8",
 "custody_pin_sha256":"6b1cbc4afafca25b15c40e849f827a387c3a1354be338494f1d2d7fe600e54d3",
 "before":before,"old_snapshot":old_before,"after_restore":restored,
 "missing_external_pin_refused":True,"coherent_old_local_pin_accepted_counterexample":True,
 "fresh_pin_returned_after_restore":False,"production_custody_qualified":False,
 "whole_node_runtime_effects_qualified":False,"commands":runner.COMMANDS}
runner.save(out/"result.json",result)
print(json.dumps({"status":"restored-awaiting-fresh-independent-read","source":head,
 "missing_pin_refused":True,"coherent_old_world_accepted_counterexample":True,
 "restored_namespace":str(node),"fresh_external_pin_not_present":True}),flush=True)

