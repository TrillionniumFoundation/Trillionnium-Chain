#!/usr/bin/env python3
"""Execute the existing authenticated release command and its actual CI guards."""
import argparse
import hashlib
import importlib.util
from pathlib import Path
import sys

RUNNER_SHA = 'da7dc56e80384b2d5b44ae84d11024a36fa28e94a6ba7c0cf7684937cc322fb2'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--head', required=True)
    args = parser.parse_args()
    args.repo = args.repo.resolve(strict=True)
    args.out = args.out.resolve(strict=True)
    runner = Path(__file__).with_name('run_native_qualification.py')
    if hashlib.sha256(runner.read_bytes()).hexdigest() != RUNNER_SHA:
        raise ValueError('pinned original 118 runner required')
    spec = importlib.util.spec_from_file_location('pinned_native_runner', runner)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    env = helper.environment(args.repo)
    path = args.out / 'release-authenticated-stage.json'
    report = dict(schema='trnm-original-release-authenticated-v1', status='running',
        head=args.head, expected_tests=118, production_qualified=False,
        scope='original release authenticated prefix, including its existing ignored test',
        environment={key: env.get(key) for key in tuple(helper.ENVIRONMENT) + ('TMPDIR',)},
        commands=[])
    helper.write_json(path, report, exclusive=True)
    passed = False
    try:
        preflight = helper.run_recorded(args, 'release-authenticated-preflight',
            ['bash', 'scripts/project-preflight.sh', '--audit'], env)
        report['preflight'] = preflight
        helper.require(preflight['passed'], 'source-bound project preflight required')
        command = ['cargo', '+1.95.0', 'test', '--release', '--locked', '--manifest-path',
                   'trillionnium/Cargo.toml', '-p', 'trnm-pon-node', '--lib',
                   'store::native_authenticated::', '--', '--include-ignored',
                   '--show-output', '--test-threads=1']
        result = helper.run_recorded(args, 'release-authenticated', command, env)
        report['commands'].append(result)
        helper.write_json(path, report)
        # Use the current source's existing workflow reader. Importing this
        # module does not run its fixture tests or create native evidence.
        sys.path.insert(0, str(args.repo / 'scripts/ci'))
        import test_authenticated_suite_count as current_guard
        pattern, code = current_guard.workflow_guards()
        helper.require('118 passed' in pattern, 'original 118-test summary guard required')
        guard = args.out / 'original-release-authenticated-guard.py'
        with guard.open('x') as stream:
            stream.write(code)
        log = args.out / 'release-authenticated.log'
        for label, argv in (
            ('release-authenticated-summary-check', ['grep', '-E', pattern, str(log)]),
            ('release-authenticated-roster-check', [sys.executable, '-B', str(guard), str(log)]),
        ):
            report['commands'].append(helper.run_recorded(args, label, argv, env))
            helper.write_json(path, report)
        report['original_workflow_guard'] = helper.file_facts(guard)
        passed = all(row['passed'] for row in report['commands'])
    except (OSError, ValueError, KeyError, TypeError, ImportError) as error:
        report['error'] = str(error)
    report['status'] = 'passed' if passed else 'failed'
    report['finished_utc'] = helper.utc()
    helper.write_json(path, report)
    print(report['status'], flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
