import hashlib,json,pathlib,subprocess,os,re,stat,tarfile,traceback,sys
ROOT=pathlib.Path("/data/chain-six-d9fb-20261108/publish-source")
OUT=pathlib.Path("/data/chain-six-d9fb-20261108/evidence/final-integration/f5-independent-review")
RAW=OUT/"scoped-raw";RAW.mkdir()
F4="e9b7a60b9519e39b792199dc8756fb9d1245bab8";F5="ab610cf95a6ec39b38e20e64e6367f5b529b3633";TREE="abd4442d789b29889960f9b0acc712b9fefed498"
CORPUS="config/pon/pq-cross-branch-corpus-v1.json"
INV="trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs"
WORKFLOW=".github/workflows/pon-pq-system-continuation.yml"
CI="scripts/ci/check_ci_contract.py"
PLAN="docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md"
BASE="evidence/hepta-real-native-learning-20261108/"
EXPECTED={WORKFLOW,CORPUS,CI,PLAN,INV,"evidence/chain-six-full-20261108/OBSERVED_RESULTS.md",BASE+"README.md",BASE+"verify_originals.py",BASE+"original-storage-map-v1.json",BASE+"v3/archive-list.stdout.json",BASE+"v3/archive-list.stdout.json.raw"}
def sha(b):return hashlib.sha256(b).hexdigest()
def write(path,obj):
 with path.open("x") as stream:json.dump(obj,stream,sort_keys=True,indent=2);stream.write("\n")
def raw(path,b):
 with path.open("xb") as f:f.write(b)
def unique(pairs):
 out={}
 for k,v in pairs:
  if k in out:raise ValueError("duplicate JSON field "+k)
  out[k]=v
 return out
def parse(b):return json.loads(b,object_pairs_hook=unique)
commands=[]
def git(label,*args):
 cmd=["git","--no-replace-objects",*args]
 r=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
 raw(RAW/(label+".stdout.raw"),r.stdout);raw(RAW/(label+".stderr.raw"),r.stderr)
 commands.append({"label":label,"argv":cmd,"exit_code":r.returncode,"stdout_bytes":len(r.stdout),"stdout_sha256":sha(r.stdout),"stderr_sha256":sha(r.stderr)})
 if r.returncode:raise RuntimeError(label+": "+r.stderr.decode(errors="replace"))
 return r.stdout
write(OUT/"original-cancelled-probe.json",p["cancelled"])
raw(OUT/"scoped-review-driver.py",p["driver"].encode())
checks={};details={}
try:
 assert git("head-before","rev-parse","HEAD").decode().strip()==F5
 assert git("tree-before","rev-parse","HEAD^{tree}").decode().strip()==TREE
 assert git("parents-before","show","-s","--format=%P","HEAD").decode().split()==[F4]
 assert not git("status-before-scoped","status","--porcelain","--untracked-files=all")
 flags=git("index-flags","ls-files","-v","-z").split(b"\0")
 assert not any(x and (x[:1].islower() or x[:1]==b"S") for x in flags)
 checks["exact_head_tree_parent_and_clean_visible_index"]=True
 def tree_map(ref,label):
  out={}
  for entry in git(label,"ls-tree","-r","-l","-z","--full-tree",ref).split(b"\0"):
   if not entry:continue
   meta,path=entry.split(b"\t",1);mode,kind,oid,size=meta.split()
   assert kind==b"blob"
   out[path.decode()]={"mode":mode.decode(),"git_blob":oid.decode(),"bytes":int(size)}
  return out
 before=tree_map(F4,"f4-tree");after=tree_map(F5,"f5-tree")
 changes={name for name in before.keys()|after.keys() if before.get(name)!=after.get(name)}
 assert changes==EXPECTED,(sorted(changes-EXPECTED),sorted(EXPECTED-changes))
 checks["only_allowed_eleven_paths_in_git_diff"]=True
 def actual(path):
  fp=ROOT/path;assert stat.S_ISREG(fp.lstat().st_mode),path
  data=fp.read_bytes()
  blob=hashlib.sha1(("blob "+str(len(data))+"\0").encode()+data).hexdigest()
  assert after[path]["git_blob"]==blob and after[path]["bytes"]==len(data),path
  return data
 def prior(path):
  return git("before-"+str(len(commands)),"show",F4+":"+path)
 changed=[]
 for path in sorted(changes):
  item={"path":path,"before":before.get(path),"after":after.get(path)}
  if path in after:item["actual_sha256"]=sha(actual(path))
  changed.append(item)
 write(OUT/"changed-path-identities.json",changed)
 wf0=prior(WORKFLOW);wf1=actual(WORKFLOW)
 assert wf0.count(b"line 353")==1 and wf1==wf0.replace(b"line 353",b"line 359",1)
 assert len(wf0)==len(wf1) and sum(x!=y for x,y in zip(wf0,wf1))==1
 checks["mldsa_reader_exact_single_byte_353_to_359"]=True
 ci0=prior(CI);ci1=actual(CI)
 assert sha(ci0)=="db10588173039cb46d5ec9282e5576234d7b75ed0d547f3c1250c1075c9ae83a"
 assert sha(ci1)=="4a231ae15037b7d918c93fd3f90fd362aa54c4923ed4f2610734775f45d3e14f"
 checks["ci_literal_exact_reviewed_plus_1672_bytes"]=len(ci1)-len(ci0)==1672
 c0=prior(CORPUS);c1=actual(CORPUS);a=parse(c0);b=parse(c1)
 keys=[k for k,v in a.items() if isinstance(v,dict) and CI in v and WORKFLOW in v]
 assert len(keys)==1;key=keys[0];pins0=a[key];pins1=b[key]
 assert len(pins0)==len(pins1)==899 and pins0.keys()==pins1.keys()
 changed_pins={x for x in pins0 if pins0[x]!=pins1[x]}
 assert changed_pins=={WORKFLOW,CI,INV,PLAN}
 expected=c0
 pinrows=[]
 for path in sorted(changed_pins):
  old,new=pins0[path],pins1[path]
  assert old==before[path]["git_blob"] and new==after[path]["git_blob"]
  needle=('"'+path+'": "'+old+'"').encode();replacement=('"'+path+'": "'+new+'"').encode()
  assert expected.count(needle)==1;expected=expected.replace(needle,replacement)
  pinrows.append({"path":path,"before":old,"after":new})
 assert expected==c1
 a.pop(key);b.pop(key);assert a==b
 listkeys={k:len(v) for k,v in a.items() if isinstance(v,list)}
 assert 807 in listkeys.values(),listkeys
 for path,pin in pins1.items():
  assert after[path]["git_blob"]==pin and before[path]["git_blob"]==pins0[path]
  actual(path)
 checks["corpus_exact_four_pin_substitutions_no_metadata_change_899_807"]=True
 write(OUT/"corpus-review.json",{"pin_field":key,"pin_count":899,"list_counts":listkeys,"metadata_unchanged":True,"exact_byte_substitution_only":True,"changed_pins":pinrows,"all_899_current_pins_match_actual_git_blobs":True})
 qpath="config/pon/w1-qrom-current-source-observation-v1.json"
 qraw=actual(qpath);assert before[qpath]==after[qpath] and sha(qraw)=="7eac13d310d91177dfbdbfd1adc70af4ccfe5eddb64821558e3fa4a109b43353"
 q=parse(qraw);selected={**q["current_files"],**q["original_owner_files"]};assert len(selected)==39
 qrows=[]
 for path,record in sorted(selected.items()):
  data=actual(path);assert before[path]==after[path] and len(data)==record["bytes"] and sha(data)==record["sha256"]
  qrows.append({"path":path,"git_blob":after[path]["git_blob"],"bytes":len(data),"sha256":sha(data)})
 assert all(v is False or v is None for v in q["qualification"].values())
 checks["qrom_all_39_selected_input_blobs_unchanged_and_profile_false_null_retained"]=True
 write(OUT/"qrom-selected-review.json",{"profile_sha256":sha(qraw),"selected_count":39,"qualification":q["qualification"],"rows":qrows,"tests_or_original_guards_executed":False})
 inv0=prior(INV);inv1=actual(INV)
 invrows=lambda d:re.findall(rb'^        "([^"]+)",$',d,re.M)
 oldrows,newrows=invrows(inv0),invrows(inv1)
 added=b'''    (
        "config/pon/w1-qrom-current-source-observation-v1.json",
        include_bytes!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../../config/pon/w1-qrom-current-source-observation-v1.json"
        )),
    ),
'''
 anchor=b'    (\n        "config/pon/w1-qrom-implementation-v1.json"'
 assert inv0.count(anchor)==1 and inv1==inv0.replace(anchor,added+anchor,1)
 assert len(oldrows)==1484 and len(newrows)==1485 and len(inv1.splitlines())-len(inv0.splitlines())==7
 assert set(newrows)-set(oldrows)=={qpath.encode()} and set(oldrows)-set(newrows)==set()
 checks["inventory_only_exact_seven_line_config_addition_1484_to_1485"]=True
 hpath="formal/pon-nakamoto-v1/contracts/work-cost-contract-v1.json"
 hraw=actual(hpath);assert before[hpath]==after[hpath]
 assert sha(hraw)=="3c21ea1823c6193ad41039034693799bc7673777305a103f425df65fe8891c34"
 h=parse(hraw);entries=h["source_entries"];rows=[r for r in entries if r["path"]==INV]
 assert len(rows)==1 and rows[0]["git_blob"]=="dc662dc57a272f0e3fc8fbc30f9604a68e948cd6" and rows[0]["bytes"]==356189 and rows[0]["sha256"]=="bde0849b437647f3cb8d7fd7933b690c0d7e2e37b3ef40ad968eb87bcd969c90"
 assert rows[0]["git_blob"]!=after[INV]["git_blob"]
 checks["historical_work_cost_contract_bytes_and_frozen_dc662_pin_unchanged"]=True
 write(OUT/"inventory-and-historical-pin-review.json",{"inventory_before":before[INV],"inventory_after":after[INV],"paths_before":1484,"paths_after":1485,"added_path":qpath,"historical_contract":hpath,"historical_contract_sha256":sha(hraw),"historical_pin_unchanged":rows[0],"current_pin_differs_from_historical":True,"original_guard_executed":False})
 manifestpath=BASE+"export-manifest.json";mraw=actual(manifestpath)
 assert before[manifestpath]==after[manifestpath] and sha(mraw)=="28523b53429d8094760ff67206e95139ae4b868dee1ed9ae80b923882027f351"
 manifest=parse(mraw);originals=manifest["files"];assert len(originals)==len({x["path"] for x in originals})==517
 mapping=parse(actual(BASE+"original-storage-map-v1.json"))
 expected_map={"schema":"hepta-native-original-raw-storage-v1","export_manifest_sha256":sha(mraw),"mappings":[{"manifest_path":"v3/archive-list.stdout.json","stored_path":"v3/archive-list.stdout.json.raw","bytes":0,"sha256":sha(b"")}]}
 assert mapping==expected_map and type(mapping["mappings"][0]["bytes"]) is int
 oldempty=BASE+"v3/archive-list.stdout.json";newempty=oldempty+".raw"
 assert oldempty not in after and newempty not in before and before[oldempty]==after[newempty]
 assert not (ROOT/oldempty).exists() and not (ROOT/oldempty).is_symlink() and actual(newempty)==b""
 original_rows=[]
 for row in originals:
  rel=row["path"];logical=BASE+rel;stored=newempty if logical==oldempty else logical
  data=actual(stored)
  assert before[logical]==after[stored] and len(data)==row["bytes"] and sha(data)==row["sha256"]
  original_rows.append({"logical_path":rel,"stored_path":stored[len(BASE):],"git_blob":after[stored]["git_blob"],"bytes":len(data),"sha256":sha(data)})
 checks["original_517_manifest_and_all_identities_preserved_with_one_zero_byte_raw_storage_map"]=True
 write(OUT/"original-517-review.json",{"manifest_sha256":sha(mraw),"original_count":517,"unchanged_original_storage_paths":516,"mapping":mapping,"all_original_blobs_and_actual_bytes_preserved":True,"rows":original_rows,"original_verifier_executed":False})
 nativechanged=sorted(x for x in changes if x.startswith(("trillionnium/","formal/","tests/fuzz/")))
 assert nativechanged==[INV]
 protected=[x for x in before if x.startswith(("trillionnium/","formal/","tests/fuzz/")) and x!=INV]
 assert all(before[x]==after.get(x) for x in protected)
 locks=[x for x in before if x.endswith(("Cargo.lock","package-lock.json","pnpm-lock.yaml","yarn.lock","poetry.lock","uv.lock"))]
 assert all(before[x]==after.get(x) for x in locks)
 checks["all_other_native_formal_fuzz_and_lock_git_entries_identical"]=True
 details["unchanged_native_formal_fuzz_entries"]=len(protected);details["unchanged_lockfiles"]=len(locks)
 assert git("head-after","rev-parse","HEAD").decode().strip()==F5
 assert not git("status-after-scoped","status","--porcelain","--untracked-files=all")
 checks["source_stayed_clean_at_f5"]=True
 result={"schema":"trnm-f5-independent-readonly-diff-review-v1","source_commit":F5,"source_tree":TREE,"parent":F4,"read_only_review_completed":all(checks.values()),"checks":checks,"details":details,"changed_paths":sorted(changes),"test_commands_executed":0,"native_commands_executed":0,"qualification_upgraded":False,"security_disposition":"HOLD_NO_GO","original_cancelled_probe_retained":True,"scope":"Git commit identities, selected actual file bytes and static code/diff review; no rerun of tests or original validators"}
 write(OUT/"review.json",result)
 text="# F5 independent read-only review\n\nSource: "+F5+"\nTree: "+TREE+"\nParent: "+F4+"\n\nThe reviewed diff is confined to the eleven allowed paths. The ML-DSA reader changes one byte (353 to 359). The CI checker matches the previously reviewed full 23+10 literal patch. The current corpus changes exactly four blob values; all other bytes, 899 entries and 807 required paths are unchanged. All 899 current pins match the committed and actual files.\n\nAll 39 QROM selected inputs retain the same Git blobs and locked lengths/hashes. Qualification fields remain false/null. The sole native-source exception is the generated inventory's seven-line addition of the current QROM configuration, from 1484 to 1485 paths. Other native, formal, fuzz and dependency-lock Git entries are unchanged.\n\nThe historical work-cost contract and dc662 inventory pin remain unchanged and differ from the current 4220 inventory blob. No old source refusal is relabelled as successful. The original 517-entry export manifest retains its 28523b SHA-256. All 517 original file identities and actual bytes match; exactly one empty logical JSON output is stored through the fixed raw path mapping. The new verifier retains the original manifest/hash checks, rejects duplicate or changed mappings and a coexisting logical file, and restricts the single mapped raw path. This is a consistency review, not independent custody or rollback protection.\n\nThe plan and observed-results corrections retain F4 FAIL, unexecuted independent-C scope, original CodeQL deadline refusal and HOLD / NO-GO, and name the generated-inventory exception. No test, verifier, native execution or compilation was run in this review. The earlier read-only probe's unexpected cancelled/exit-15 terminal is retained separately; this scoped review is a distinct operation.\n"
 raw(OUT/"REVIEW.md",text.encode())
 write(OUT/"scoped-git-commands.json",commands)
except BaseException:
 raw(OUT/"scoped-review-exception.log",traceback.format_exc().encode())
 write(OUT/"partial-checks.json",checks)
 raise
files=[x for x in sorted(OUT.rglob("*")) if x.is_file()]
assert all(not x.is_symlink() for x in files)
index=[{"path":x.relative_to(OUT).as_posix(),"bytes":x.stat().st_size,"sha256":sha(x.read_bytes())} for x in files]
write(OUT/"SHA256SUMS.json",index)
archive=OUT.with_suffix(".tar.xz")
with tarfile.open(archive,"x:xz") as tar:
 for x in sorted(OUT.rglob("*")):
  if x.is_file():tar.add(x,arcname=x.relative_to(OUT),recursive=False)
expected={r["path"]:(r["bytes"],r["sha256"]) for r in index}
expected["SHA256SUMS.json"]=((OUT/"SHA256SUMS.json").stat().st_size,sha((OUT/"SHA256SUMS.json").read_bytes()))
with tarfile.open(archive,"r:xz") as tar:
 members=tar.getmembers();assert len(members)==len(expected)
 for m in members:
  assert m.isfile() and m.name in expected
  data=tar.extractfile(m).read();assert (len(data),sha(data))==expected.pop(m.name)
 assert not expected
print(json.dumps({"result":"READ_ONLY_REVIEW_COMPLETE_HOLD","review":str(OUT/"review.json"),"review_sha256":sha((OUT/"review.json").read_bytes()),"manifest_sha256":sha((OUT/"SHA256SUMS.json").read_bytes()),"archive":str(archive),"archive_bytes":archive.stat().st_size,"archive_sha256":sha(archive.read_bytes()),"members":len(members),"checks":checks,"details":details}))
