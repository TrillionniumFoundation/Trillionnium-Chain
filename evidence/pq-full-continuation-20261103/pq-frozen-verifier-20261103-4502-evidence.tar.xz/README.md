# Frozen W1 verifier profile — local native evidence, 2026-11-03

This packet records the two-file research-verifier change based on Chain
1c7e8ab7cd6a321cad4e6c7f7e8a197d7b3be14c. The tested working tree was modified;
the four exact consumed crate source/manifest/lock identities are retained in
source.json, every native command record, final-source.json and sources/.
This is an isolated verification-only crate result, not an all-repository
artifact qualification, an independently administered deployment or a CI result.

Actual Rust 1.95.0 results: 4 unit tests passed with zero ignored; locked release
build, strict all-targets Clippy and formatting passed. The saved full receipt
passed cryptographic verification. The original 24 complete-receipt controls
were preserved, and the two recognized-but-disallowed suite controls passed:
26 total (one ACCEPT, 25 REJECT), no PANIC. The saved real lift passed the
separate recursion diagnostic with complete_w1_claim=false and the explicit
Poseidon2/verifier-parameter identities. No new proof was generated.

The initial run was stopped only while its Cargo invocation waited for a
package-cache lock held by another process. The authoritative runtime state
was cancelled with exit code -15. Its original incomplete command record and
52-byte lock-wait log remain under initial-cache-lock-wait; they are not called
a passed or completed test. The isolated-cache offline metadata probe failed
because required public dependencies were absent; its original failure remains.
The following locked online metadata fetch succeeded and all native commands
then ran offline. Existing shared package-cache owners were not interrupted.
Only public lockfile-selected .crate archives and sparse-index entries were
copied; archive checksums were checked before reuse. No credentials were copied.

The original local runner recorded four source files before and after each
read-only command. The formatting mutation stage intentionally has null source
snapshots. runner.py is the exact executed Python command, and environment.json
records its explicit compiler/cache/build overrides. Logs and command receipts
are complete; every payload file is identified in archive-manifest.json.

The accepted control root is unchanged. Execution segment exponent 18 is not
a verifier restriction to 18; the pinned SDK root still admits its original
maximum exponent 22. Signature qualification, PoN work hardness, quantum
Fiat–Shamir soundness, PQ-128 and production activation remain unqualified.
No elapsed value in these functional controls is a production performance claim.
