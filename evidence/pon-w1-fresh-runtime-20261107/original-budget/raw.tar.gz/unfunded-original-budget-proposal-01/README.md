# Original-budget, unfunded A probe — proposal 01

Execution status: **NOT RUN**. The declaration, observer and controls are for parent review. No NativeTask is funded and no proof program is dispatched by the validation command.

## Fixed trial

Source A is commit d3037ca5dfb6f301757c159b7888dca9b0317be0, tree d4a8f84cdc896b9454ce0d03a164f8916e6afdf9. Existing exact-build qualification is pinned by its independent SHA256. This is not integration C0 and does not repair A's separate funded-owner failure/cancellation path.

The one declared trial reuses the independent material, 318-byte header template with first nonce 0, and 64-byte expected artifacts under experiment-inputs-01. Native maximum attempts stays 10000, as in the full experiment; there are no replacement seeds, retries, resume checkpoints or extra trials.

An actual native attempt is performed by the qualified A Rust example. Immediately before the first dispatch preparation, the parent records Linux CLOCK_MONOTONIC and fixes deadline = origin + 4,000,000,000 ns. Origin persistence, native spawn, search, native replay, winner files, postwin Python startup, fresh full execution, segment proofs, recursive compression and independent receipt verification consume that same budget. The native and postwin programs receive/use the same absolute deadline and boot. No stage may rebase it.

Hepta launch requests CPUQuota=25%, MemoryMax=2 GiB. The observer sets affinity 8..11 and requires actual cgroup controls and affinity to match. Affinity to four CPUs does not mean a four-CPU allocation. Segment workers=1, sequential compression with one worker, Rayon=1 and comparison-repeats=0.

## Actual A boundaries

A's postwin comparison flag disables its additional ABBA run. It does **not** disable the coordinator's existing post-ACK serialization, transfer and fixed-receipt/native diagnostics. Therefore the observer keeps two observations:

* The raw, bound controller/receiver early ACK on the same Linux boot, with its original-clock native-to-ACK and dispatch-origin-to-ACK durations, when present.
* The complete postwin process handoff and the outer operation outcome, including late diagnostics, cancellation or missing cleanup.

An earlier verified ACK is a saved fact. It never overrides a failed/canceled/late outer operation. Missing raw facts remain UNOBSERVED. The reader does not perform a new mathematical W1/zkVM verification; the actual pinned A verifier does that in the real process path.

## Setup, cleanup and audit

Existing source/build qualification, exact binary and input hashing, imports and resource checks are setup before native origin. No Cargo rebuild is proposed in this experiment. The existing qualification distinguishes a cached locked build from an independent reproducible build.

Outer TERM grace is 30 seconds, versus A postwin's 12 and the inner stage's 5. This grace permits report handoff and cleanup; it does not extend proof eligibility. A's existing Scope observes the one isolated Hepta job recursively, excludes only the recorded original ancestors, and can kill only newly observed PID+birth identities. Its final bounded 5-second emergency cleanup is separate from the 30-second outer TERM grace. Unreadable or nonempty scope remains UNKNOWN. The probe never signals another job, task1 or either full-generation run.

Full source/hash readback and report publication after the timed endpoint are explicitly postrun audit. They may veto the observation if identities changed; they cannot move its original endpoint or deadline. A cancellation during final publication makes the actual exit nonzero and emits an immutable cancellation sidecar, even if an earlier report/ACK was already saved. Consumers must require the real exit and absence of cancellation sidecars for any successful operation interpretation.

The resource delta is from one owned cgroup, around the timed work and cleanup. Do not add nested wait4 CPU to it or sum nested RSS. Its memory peak includes setup and is a cumulative upper bound. Complete process-tree/resource accounting, production admission, WAN propagation, population tails and the funded M12/NativeTask path remain unqualified.

## Files and review gate

* run_unfunded_original_budget.py: explicit run --execute entry only; importing does not dispatch.
* declaration.json: immutable one-trial plan; an external SHA is mandatory.
* test_unfunded_original_budget.py: ten pure contract/negative-decision controls, no native/prover/receiver subprocess and no successful proof stub.
* proposed-hepta-launch.json: reviewable exact future request, **NOT SUBMITTED**.
* validation.json: syntax/control results and raw log identities.

The scope is one unfunded proof-path observation. It is not the 16-hostile/6-confirmation business matrix, funded cancellation recovery, a fresh proof distribution, or a deployment benefit proof. A postwin attempt can legitimately expire before proof dispatch; both planned rows and all actual error prefixes are retained.
