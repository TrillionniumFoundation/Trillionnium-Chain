//! Isolated research harness, not a consensus profile or a succinct proof backend.
//! The exact upstream W1 relation remains the acceptance oracle.

pub mod pon_work;

pub mod low_rank_prefix;
pub mod statement;
