## Why

The pure-PoN work packages need a reviewable implementation candidate and source-bound evidence, including failures. The existing candidate did not establish a complete inexpensive W1 proof, all-honest service under exhausted budgets, end-to-end PQ authorization, a qualified Hepta upgrade, or independent WAN acceptance.

This draft is stacked on the existing integration PR #323. It retains the native #498 and PQ #495 histories. It does not merge into main or activate a protocol, model, account migration, or production authorization path.

## Changes

- Freeze the exact original W1 work relation, sole work identity, existing cumulative-work credit, attacker freedoms, preprocessing/hardware/quantum assumptions and unresolved hardness claims. Pure PoN remains the consensus; no stake, BFT, TEE or hash-only fallback is introduced.
- Add a full-relation RISC Zero guest, explicit expected-image/journal/receipt gates, native equivalence controls and real local proof-cost instrumentation. Reject recursive Composite receipt tags before deserialization. The proof prototype remains outside native admission.
- Move shared History decode/full W1 outside the Node mutex while preserving the original CPU domain, deadline and durable accounting. Retain actual kill cuts and original service matrices.
- Add conditional quantum/DAA and fixed-probability/variable-work models, pinned ASERT integer vectors and an explicitly unsynthesized SHA component worksheet.
- Add versioned TPQ1 framing and a real in-process ML-DSA-65 adapter/provider with native tests and a production-owner inventory. This is not complete owner/account/network migration.
- Exercise actual SmolLM generations and complete Cell transfer after publisher shutdown. Repair a transient pre-header capacity reset with one bounded retry using the same original budgets.
- Add independent-WAN preregistration/denominator checks, without claiming a WAN deployment occurred.

## Actual results and open exits

| Work package | Observed result |
| --- | --- |
| Full succinct W1 | **0/1 receipts** at the original 3,600 s timeout. Prover observed CPU >=7,182.52 s; process HWM 2,478,088,192 B. Proof size/verifier cost/tail are unavailable. The same input completed 1,000 native verifications: median 0.694 ms, observed p99 1.560 ms. No proving benefit was established. |
| History/service | The finite 130-attempt local campaign passed 32 honest probes and 16 mutations without exhausting budget. On original published source 0c804e9f, the actual hosted A03 campaign executed 3 runs / 9 phases: 63/189 planned blocks were submitted successfully, 576/576 History responses arrived, all 576 imports were refused, and 0/27 confirmation targets completed (9 observed, 18 never reached). CPU refusal/depletion remained zero. A03's 4-CPU/16-GiB process contract conflicts with the fixed public importer's <=25%-CPU/<=2-GiB context; the from-zero wrapper does not solve that architecture issue. |
| Isolated M06 | **Not integrated in implementation or ancestry.** Exact signed-client recovery after an actual 10 s deadline passed; withholding that frame left a different honest mutation 0/1 with `REORG_IN_PROGRESS`. An admitted 8,625,548-byte custom parent exhausted original CPU before M06. Separate affected scope: 373 pass / 1 fail / 3 ignored, 377 planned. Failure evidence is copied into the report only. |
| Quantum/DAA | 11 conditional models / 109,190 retained rows. Some extended schedules catch up in the assumed model; bounded failures do not establish safety. No QPU attack or verified complete physical oracle estimate. |
| PQ | Real ML-DSA adapter controls pass, but native production owners do not consume it. TPQ1 signed frame is 3,487 B versus the old 2,048 B whole-transaction limit. **Whole-chain PQ remains false.** |
| Cell/model | 11 Cells / 269 chunks / 272,190,131 payload B; publisher stopped, fresh consumer fetched from replica, actual model loaded. Parent 16/32 vs candidate 16/32: **NO_UPDATE**. Original Hepta owner CI is a separate stacked candidate. |
| WAN | **NOT RUN**. No independently administered three-operator, >=72-hour campaign. |

## Validation

The earlier integrated native source passed locked 25-package workspace/all-target/all-feature strict Clippy (`-D warnings`), formatting, 91 CI-contract tests and 34 negative source-integrity tests. Both actual CPU-domain regression controls passed, including the two-listener socket test. Prior source-specific crypto/protocol results are retained, not recounted as final-source runs. Full inherited native acceptance and hosted final-source head/merge checks remain open.

Start at `evidence/pon-pure-workpackages-20261027/README.md`. All original failed observations and missing denominators remain. `evidence/pon-source-publication-20261027/` preserves raw measured commit identities and the finite same-tree API publication mapping: connector-authored commit metadata changes commit IDs, never measured source IDs. Publication reachability parents retain integrated side histories and explicitly exclude the blocked M06 branch.

**Draft / HOLD / NO_GO.** Passing component tests do not grant release, self-upgrade, independent acceptance or production authority.

## Reviewed CI corrections and current source

The original source's failed CI observations remain intact. Subsequent narrow commits:

- Rebind exactly two reviewed recent-batch literal source guards; no guard is removed.
- Put only the original from-zero subprocess under the existing root-owned fixed Host parent, retaining 25% CPU, 2 GiB, zero swap, 256 tasks, original native selectors and 60/900/90-second limits. The same provisioned parent/service identity is read before and after execution; cancellation cannot become success.
- Reproduce the three original failures in the 86-test Python reader suite, then correct their fixed four-versus-five expectations. The complete original 86 and 12 Host controls pass locally; the runner and refusal predicates are unchanged.
- Regenerate the existing distributed source inventory with the unchanged generator: 1,020 to 1,028 entries, eight additions and zero removals. Original failed freshness check, corrected check and formatting outcome are retained.

Current API head: `ac469237422d43805845e8b9a6839ad14e1028e7`; exact tree `aa000d8883cbffdf0ac4fbfb57b63394693c99c6`. Original same-tree local source: `516d077effb27351dca227bbfbd3d55f8fe3c333`. Base #323 remains `57c1ed545d067937cbd7aaa7570d5f22123265e6`. Actual GitHub prospective merge `47727c4f8335427710b4f3608768b4e9cc7c2a64` was fetched and checked against ordered parents and the canonical native merge tree.

The final committed-source reader checked 5,496 entries / 706,257,682 bytes; inventory, formatting and CI-contract validation pass. These do not recast earlier native executions as new-head runs. At the 2026-10-27 11:29:56 UTC list snapshot, 12 new-source workflows were queued/pending and all 35 registered checks were queued; uninstantiated checks and queued jobs receive no passing credit.

Original CodeQL check 122144152932 remains failed with 9 annotations. Source/flow review found public transaction sequences/mining counters and development-only public account diagnostics at those nine sites; eight selected sinks already existed in the base. No alert was dismissed or rule suppressed. The remaining 307 exposed Rust findings were not cleared by that review. Full source-specific security acceptance remains open.

Paired Hepta draft: https://github.com/TrillionniumFoundation/hepta-private-ci/pull/4080 . The blocked M06 implementation remains excluded from this branch and its ancestry. **Draft / HOLD / NO_GO.**
