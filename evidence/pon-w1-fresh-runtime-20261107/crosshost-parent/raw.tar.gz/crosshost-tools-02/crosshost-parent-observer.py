#!/usr/bin/env python3
"""Capture operator-mediated ROG verification using only the original parent clock.

This external evidence collector neither generates proofs nor admits/pays tasks.
Remote CLOCK_MONOTONIC values remain opaque. A late result is retained as late.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
REPO = ROOT / 'repo'
OUT = ROOT / 'crosshost-observation-01'
COMMIT = 'd3037ca5dfb6f301757c159b7888dca9b0317be0'
TREE = 'd4a8f84cdc896b9454ce0d03a164f8916e6afdf9'
BOOT = '14f92beb-43c6-4786-839e-b57307ae8048'
EXPECTED = '802adcdd951cfb4cd7271df22c3bca6af66fee9f40454c74f8b5ff2c98a1b683'
ROG_LAUNCH_SHA = 'c435ec8357861952eea6f6a1cdda6ae822baf198d8baef47cb608191d6522c20'
ARMS = {
    'funded-balanced': {
        'run': ROOT / 'funded-balanced-run-01', 'proof_name': 'proof',
        'job_id': '1a1b75f99d3-12894-a75',
        'operation': 'e92c0bfb3f87c738f20719ab73e6933a5fad706e69bf754e2e20f7ecb090f308',
        'operation_kind': 'original funded provider operation',
        'deadline': 1162725467096441, 'winner_ns': 1155534490086143,
    },
    'sequential-unfunded': {
        'run': ROOT / 'sequential-unfunded-run-01', 'proof_name': 'postwin',
        'job_id': '1a1b75fd351-12894-a76',
        'operation': '8891181165039b63703e0ff44857f1a6aa9a732f842a53ee5446dff4fac0ef28',
        'operation_kind': 'original Hepta launch request digest; UNFUNDED, not a NativeTask/provider operation',
        'deadline': 1162741070990231, 'winner_ns': 1155549063640127,
    },
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def decode(raw):
    value = json.loads(raw, object_pairs_hook=unique,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
    require(type(value) is dict, 'JSON object required')
    return value


def pin(path, maximum=16 * 1024**2):
    path = Path(path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= maximum,
            'bounded, ordinary, singly linked file required')
    with path.open('rb') as stream:
        raw = stream.read(maximum + 1)
    after = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    require(all(getattr(before, f) == getattr(after, f) for f in fields) and len(raw) == before.st_size,
            'file changed during read')
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}, raw


def write_bytes(path, raw):
    with Path(path).open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(Path(path).parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_json(path, value):
    write_bytes(path, (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode())
    return pin(path)[0]


def source():
    def git(*args):
        return subprocess.check_output(['/usr/bin/git', '-C', str(REPO), *args], text=True).strip()
    result = {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
              'status': git('status', '--porcelain=v1', '--untracked-files=normal')}
    require(result == {'commit': COMMIT, 'tree': TREE, 'status': ''}, 'source A changed')
    return result


def terminal(status, job_id, require_success=False):
    require(status.get('job_id') == job_id and status.get('state') in ('succeeded', 'failed', 'cancelled', 'timed_out'),
            'actual original job terminal status required')
    require(status.get('output_complete') is True and status.get('output_durable') is True,
            'complete durable original job output required')
    if require_success:
        require(status.get('state') == 'succeeded' and type(status.get('exit_code')) is int
                and status['exit_code'] == 0 and status.get('cancelled') is False
                and status.get('timed_out') is False, 'remote receiver actual terminal success required')


def prepare(arm, status_raw):
    spec = ARMS[arm]
    status = decode(status_raw)
    terminal(status, spec['job_id'])
    before = source()
    native = spec['run'] / 'native-winner'
    proof = spec['run'] / spec['proof_name']
    paths = {'header.bin': native / 'header.bin', 'winner-result.json': native / 'result.json',
             'winner-intent.json': native / 'intent.json', 'succinct.bin': proof / 'checkpoint/succinct.bin'}
    files, original = {}, {}
    for name, path in paths.items():
        record, raw = pin(path, 65536 if name.startswith('winner-') else 16 * 1024**2)
        files[name] = {'bytes': record['bytes'], 'sha256': record['sha256']}
        original[name] = {'pin': record, 'raw': raw}
    winner = decode(original['winner-result.json']['raw'])
    intent = decode(original['winner-intent.json']['raw'])
    for value in (winner, intent):
        require(value.get('schema') == 'TRNM-W1-NATIVE-WINNER2'
                and value.get('original_deadline_boot_id') == BOOT
                and type(value.get('original_deadline_monotonic_ns')) is int
                and value['original_deadline_monotonic_ns'] == spec['deadline']
                and value.get('expected_artifacts_sha256') == EXPECTED,
                'original native deadline/statement changed')
    require(winner.get('native_winner_monotonic_ns') == spec['winner_ns']
            and winner.get('header_sha256') == files['header.bin']['sha256']
            and files['header.bin']['bytes'] == 318, 'original native winner/header changed')
    request = {'schema': 'TRNM-W1-ROG-RECEIVE-REQUEST1',
               'request_id': 'trnm-w1-7d418660-' + arm + '-rog-01',
               'source_commit': COMMIT, 'source_tree': TREE,
               'expected_artifacts_sha256': EXPECTED,
               'parent': {'operation': spec['operation'], 'original_boot_id': BOOT,
                          'original_deadline_ns': spec['deadline']}, 'files': files}
    dest = OUT / arm
    dest.mkdir(parents=True, exist_ok=False)
    outgoing = dest / 'outgoing'
    outgoing.mkdir()
    for name, value in original.items():
        write_bytes(outgoing / name, value['raw'])
    request_pin = write_json(outgoing / 'request.json', request)
    write_bytes(dest / 'original-job-terminal.json', status_raw)
    additional = {}
    for name, path in {'postwin': proof / 'result.json', 'controller': proof / 'controller/result.json',
                       'checkpoint_manifest': proof / 'checkpoint/manifest.json',
                       'generation_stages': proof / 'checkpoint/stages.jsonl'}.items():
        additional[name] = pin(path)[0] if path.exists() else {'state': 'UNOBSERVED', 'path': str(path)}
    for value in original.values():
        require(pin(value['pin']['path'])[0] == value['pin'], 'original data changed after copy')
    observed = time.monotonic_ns()
    manifest = {'schema': 'TRNM-W1-CROSSHOST-TRANSFER-PREPARED1', 'arm': arm,
                'request': request_pin, 'original_files': {k: v['pin'] for k, v in original.items()},
                'original_job_status': status, 'source_before': before, 'source_after': source(),
                'parent_operation_kind': spec['operation_kind'], 'additional_raw_facts': additional,
                'prepared_parent_monotonic_ns': observed, 'current_parent_boot_id':
                Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                'fresh_generation_established_by_this_collector': False,
                'transport': 'operator-mediated Hepta binary transfer; deployed WAN protocol not established',
                'admission_authorized': False, 'payment_authorized': False}
    record = write_json(dest / 'prepared.json', manifest)
    print(json.dumps({'prepared': record, 'request': request_pin, 'files': files}))


def accept(arm, bundle_raw, arrived_ns):
    spec = ARMS[arm]
    dest = OUT / arm
    bundle = decode(bundle_raw)
    request_pin, request_raw = pin(dest / 'outgoing/request.json', 65536)
    request = decode(request_raw)
    prepared = decode(pin(dest / 'prepared.json')[1])
    require(request_pin == prepared['request'], 'original prepared request changed')
    incoming = dest / 'incoming'
    incoming.mkdir(exist_ok=False)
    write_bytes(incoming / 'received-bundle.json', bundle_raw)
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    errors = []
    ack = None
    try:
        status = bundle['remote_job_status']
        terminal(status, bundle['remote_job_id'], True)
        remote_base = '/home/qian-qi/work/chain-w1-funded-owner-20261107-r01'
        expected_args = [remote_base + '/crosshost-tools-02/rog-receiver-launch.py', arm,
                         '--request-sha256', request_pin['sha256']]
        launch = bundle['remote_job_launch']['job']
        require(launch.get('id') == bundle['remote_job_id'] and launch.get('host') == 'rog'
                and launch.get('executable') == '/usr/bin/python3.14'
                and launch.get('args') == expected_args and launch.get('launch_state') == 'launched'
                and launch.get('cwd') == remote_base + '/repo', 'remote terminal is not the original receive launch')
        require(type(bundle['remote_ack_raw']) is str and type(bundle['remote_readback_raw']) is str,
                'raw remote ACK/readback required')
        ack_raw = bundle['remote_ack_raw'].encode()
        ack = decode(ack_raw)
        readback_raw = bundle['remote_readback_raw'].encode()
        readback = decode(readback_raw)
        require(hashlib.sha256(ack_raw).hexdigest() == bundle['remote_ack_sha256'] == readback['ack']['sha256']
                and len(ack_raw) == readback['ack']['bytes'], 'remote ACK bytes changed')
        require(hashlib.sha256(readback_raw).hexdigest() == bundle['remote_readback_sha256'], 'remote readback bytes changed')
        terminal(bundle['remote_readback_job_status'], bundle['remote_readback_job_id'], True)
        readback_launch = bundle['remote_readback_job_launch']['job']
        require(readback_launch.get('id') == bundle['remote_readback_job_id']
                and readback_launch.get('host') == 'rog' and readback_launch.get('launch_state') == 'launched'
                and readback_launch.get('executable') == '/usr/bin/python3.14'
                and readback_launch.get('args') == [remote_base + '/crosshost-tools-02/rog-terminal-readback.py',
                    arm, '--receiver-job-id', bundle['remote_job_id']], 'readback terminal is not the original readback launch')
        require(readback['schema'] == 'TRNM-W1-ROG-TERMINAL-READBACK2'
                and readback['all_checked'] is True and readback['cancellation_sidecars'] == []
                and readback['receiver_job_id'] == bundle['remote_job_id'], 'remote terminal readback not complete')
        launch_fact = readback['actual_launch_record']
        require(launch_fact['arm'] == arm and launch_fact['request_sha256'] == request_pin['sha256']
                and launch_fact['cgroup'].endswith('/hepta-runtime-job-' + bundle['remote_job_id'] + '.service')
                and launch_fact['launch_source_sha256'] == ROG_LAUNCH_SHA
                and launch_fact['rayon_num_threads'] == '2', 'actual remote process/allocation identity changed')
        require(ack['schema'] == 'TRNM-W1-ROG-INDEPENDENT-ACK1'
                and ack.get('verified') is True and ack.get('receiver_operation_complete') is True
                and ack.get('local_deadline_exhausted_at_snapshot') is False
                and ack.get('error') is None and ack.get('cancellation_event') is None
                and ack.get('source_commit') == COMMIT and ack.get('source_tree') == TREE
                and ack.get('admission_authorized') is False and ack.get('payment_authorized') is False,
                'remote ACK does not establish eligible local completion')
        require(ack['request']['sha256'] == request_pin['sha256']
                and ack['request_id'] == request['request_id'], 'remote request identity changed')
        for key, value in request['parent'].items():
            require(ack['parent'][key] == value, 'remote parent identity changed')
        require(ack['parent']['reported_native_winner_monotonic_ns'] == spec['winner_ns'], 'remote winner changed')
        for name, selected in request['files'].items():
            require(all(ack['files'][name][key] == selected[key] for key in ('bytes', 'sha256')),
                    'remote file identity changed')
            original = prepared['original_files'][name]
            require(pin(original['path'])[0] == original, 'original parent file changed')
        require(ack['expected_artifacts']['sha256'] == EXPECTED, 'independent expected artifacts changed')
        source()
    except (KeyError, ValueError, TypeError, OSError, subprocess.CalledProcessError) as error:
        errors.append({'type': type(error).__name__, 'message': str(error)})
    same_clock = boot == BOOT
    complete = not errors
    timely = complete and same_clock and spec['winner_ns'] <= arrived_ns < spec['deadline']
    result = {'schema': 'TRNM-W1-PARENT-REMOTE-ACK-OBSERVATION2', 'arm': arm,
              'request': request_pin, 'parent_operation': spec['operation'],
              'remote_job_id': bundle.get('remote_job_id'), 'remote_readback_job_id': bundle.get('remote_readback_job_id'),
              'parent_operation_kind': spec['operation_kind'], 'original_boot_id': BOOT,
              'observed_boot_id': boot, 'original_deadline_ns': spec['deadline'],
              'native_winner_ns': spec['winner_ns'], 'full_remote_bundle_observed_ns': arrived_ns,
              'same_original_parent_clock': same_clock,
              'remote_complete_with_terminal_readback': complete, 'observed_within_original_deadline': timely,
              'winner_to_observed_remote_ack_ns': arrived_ns - spec['winner_ns'] if same_clock else None,
              'remaining_original_budget_ns': spec['deadline'] - arrived_ns if same_clock else None,
              'errors': errors,
              'timing_scope': 'parent CLOCK_MONOTONIC after the complete remote ACK, actual terminal status and terminal readback bytes reached this collector; includes operator/tool scheduling and transfer',
              'cross_host_clock_subtraction_performed': False, 'deadline_renewed': False,
              'pure_network_latency_established': False, 'deployed_wan_qualified': False,
              'node_admission_established': False, 'payment_authorized': False,
              'production_qualified': False, 'complete_resource_accounting_established': False}
    record = write_json(dest / 'parent-observation.json', result)
    print(json.dumps({'observation': record, 'remote_complete': complete, 'within_original_deadline': timely,
                      'winner_to_observed_remote_ack_ns': result['winner_to_observed_remote_ack_ns'], 'errors': errors}))
    return 0 if complete else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'accept'))
    parser.add_argument('arm', choices=tuple(ARMS))
    args = parser.parse_args()
    raw = sys.stdin.buffer.read(1024**2 + 1)
    arrived = time.monotonic_ns()
    require(len(raw) <= 1024**2, 'bounded stdin bundle')
    if args.action == 'prepare':
        prepare(args.arm, raw)
        return 0
    return accept(args.arm, raw, arrived)


if __name__ == '__main__':
    raise SystemExit(main())
