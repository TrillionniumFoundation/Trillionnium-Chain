# Native History attribution review

## Exact source and purpose

Reviewed commit `0c589e2212f7feeaac4ec12d076d27ab139bc52f`, tree `831caac4edbae18921b3269a85faef456d78bbbe`, in the clean `fixed` checkout. The change adds optional measurements at the existing History domain lookup, durable epoch begin, and CPU reservation wait. It does not change the native work relation, reservation/refill arithmetic, cold-start policy, original deadlines, Host observations, error precedence, or admission decisions.

`native_attribution` is an optional **top-level** extension of the existing History import snapshot. It contains a page observation and at most 16 indexed packet observations bound to the original packet IDs. Each recorder has two fixed epoch-substep slots and two fixed CPU-wait slots; the latter accommodates page decode and empty-page activation. Successful packet paths normally use one CPU-wait slot. Collection uses bounded slots and nonblocking diagnostic locks, without new budget-state queries.

The extension distinguishes domain lookup from durable epoch begin and retains the page owner's exclusive/shared mode. Each entered CPU wait reports actual reserve attempts/returned outcomes, grants/budget refusals/other refusals, actual sleep-call counts, requested and measured sleep duration, and remaining original deadline at entry, exit and the most recent reserve/sleep. Sleep wall time includes scheduler overshoot; it is not a measured CPU-refill cause or an explanation of all wall delay. Calling-thread CPU and nested intervals must not be added to their enclosing phase totals.

## Missing and partial observations

An unentered extension is omitted. An entered wait with no sleeps has zero observed sleep calls and **null duration totals**, rather than invented zero-time samples. Expired deadline remaining can legitimately be a known zero. Unknown clock readings and checked duration conversion/sum overflow stay null; a later known sample does not fill a previously unknown sleep total. Recorder-capacity exhaustion, duplicate epoch capture or lock contention increments the existing measurement-failure count and does not alter native work. An unwound action retains `completed=false`, `accepted=null` and its unfinished attempt counts. A live snapshot can be partial and is not evidence of completion.

## Tests and evidence boundary

Eight new controls exercise absent capture, original error identity, unwind/capture contention, actual immediate reservation, actual zero-credit cold refill, deadline/Host refusal before reservation, bounded partial capture, and unavailable clock totals. The actual reservation controls check the original account's in-flight state and balance identity; they do not synthesize a new CPU grant. Existing real W1 success/cancellation tests additionally check packet identity, both original epoch substeps, and the distinction between successful reservation and later W1 cancellation. The expired native History test requires the extension to remain absent.

At this review, default-profile compilation of the monolithic node library test ended with **rustc SIGKILL**, before service tests executed. The fixed-source recovery build with node test debug information disabled is a separate pending observation. Its eventual result must retain the changed build configuration and cannot replace the failed original build or become a throughput measurement. The two journal integration suites separately passed 27 tests with four ignored under their original profile; that result does not establish that the new service tests ran. Record subsequent service counts only from their own completed receipts.

The retained 19 phase entries, four Host row shapes, and exact legacy packet keys (`packet_index`, `packet_id`, `phases`) are unchanged. The existing Python phase/campaign readers tolerate the top-level extension but **do not validate its new fields**. Legacy-reader acceptance establishes compatibility only. Any downstream acceptance rule based on the new measurements needs an explicit validator for this extension. Existing native serialization assertions verify the old packet shape without relaxing those readers.

Instrumentation itself adds optional clock, counter, lock and serialization overhead. No speedup, original-campaign improvement, cost-amplification factor or public-service qualification has been measured on this candidate. No Host substep timing was added in this slice.

## Separate original campaign readback

The independently checked original artifact belongs to source `aaa3c53965bf0cf472e52451e205e9a020e834ab`, tree `fe3ce4c61bc2e3d477ea328b7742d0b2598282b3`, run **42781760995**, artifact **13761459229**. Its ZIP SHA-256 is `715587a56f595588c4eca4b36ba6e0a326b78e69078a4240cc878959e1f02cfe`. It was read, not executed again. See `../original-service-readback/summary.md`, `summary.json`, and `host-scope-crosscheck.json` for the original hash-bound counts and resource scopes.

The original complete criteria remain **0/3 campaigns and 0/9 phases accepted**. Separately, **6/27 planned individual rounds confirmed inside the window**: all six occurred in the three baselines, two per baseline; all attack phases had zero. There were 15 actual confirmation records and 12 unreached rounds. These distinct denominators must not be collapsed into either “zero confirmations” or “six accepted phases.”

The readback distinguishes **90 honest submission attempts**, **87 client success responses**, and **89 receiver full-work accepts**. Two late client errors corresponded to accepted receiver observations. All **13,781** hostile full-work rejections were matched to their original hostile bodies, with zero such accepted receiver work. All 144 attacker processes were launched and reaped. No original paid-credit depletion was observed, and its required attack-phase condition also failed. These facts establish neither general service liveness nor a whole-service amplification ratio.

The public Host's quarter-core and 2 GiB limits are ceilings, not reservations. Host cgroup totals, process-phase CPU, setup, and paid mutation CPU have nested scopes; whole-phase observations include setup and cleanup outside the 30-second business window. The new attribution does not retroactively supply missing measurements in this original campaign. Original service, independent-operator/WAN, general work-cost, joint consensus, and production gates remain open.
