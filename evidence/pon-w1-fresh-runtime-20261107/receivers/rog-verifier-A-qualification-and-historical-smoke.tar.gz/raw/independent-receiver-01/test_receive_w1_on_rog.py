#!/usr/bin/env python3
"""Synthetic metadata controls only; no receipt verification or proof executed."""
import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest import mock

import receive_w1_on_rog as receiver


def metadata_fixture():
    header = bytearray(318)
    header[:4] = b"PNH1"
    header[118:150] = b"\xff" * 32
    header[278:310] = b"\x02" * 32
    header = bytes(header)
    boot = "11111111-1111-4111-8111-111111111111"
    request = {"schema":receiver.REQUEST_SCHEMA, "source_commit":receiver.COMMIT,
               "source_tree":receiver.TREE, "request_id":"synthetic-metadata-only",
               "expected_artifacts_sha256":receiver.EXPECTED_SHA,
               "parent":{"operation":"a" * 64, "original_boot_id":boot, "original_deadline_ns":11000}}
    intent = {"schema":"TRNM-W1-NATIVE-WINNER2", "original_deadline_monotonic_ns":11000,
              "original_deadline_boot_id":boot, "entered_monotonic_ns":1000,
              "expected_artifacts_sha256":receiver.EXPECTED_SHA, "material_sha256":receiver.MATERIAL_SHA,
              "header_template_sha256":receiver.HEADER_TEMPLATE_SHA, "first_nonce":0, "maximum_attempts":10000}
    winner = {"schema":intent["schema"], "winner_observed":True, "native_replay_verified":True,
              "native_ticket_before_deadline":True, "winner_saved_before_deadline":True,
              "node_admission":False, "production_qualified":False,
              "original_deadline_monotonic_ns":11000, "original_deadline_boot_id":boot,
              "search_started_monotonic_ns":2000, "native_winner_monotonic_ns":3000,
              "winner_saved_monotonic_ns":4000, "expected_artifacts_sha256":receiver.EXPECTED_SHA,
              "header_sha256":hashlib.sha256(header).hexdigest(), "nonce":0, "attempts":1,
              "challenge":receiver.domain(b"challenge",[header]).hex(), "task_id":header[278:310].hex(),
              "ticket":"0" * 64, "input_sha256":"b" * 64, "input_bytes":49506}
    return request, winner, intent, header


class ReceiverMetadataControls(unittest.TestCase):
    def test_parent_clock_is_opaque_to_remote_local_clock(self):
        request, winner, intent, header = metadata_fixture()
        with mock.patch.object(receiver.time, "monotonic_ns", side_effect=AssertionError("cross-host clock read")):
            result = receiver.validate_parent_binding(request,winner,intent,header)
        self.assertEqual(result["original_deadline_ns"],11000)
        self.assertIs(result["parent_timeliness_evaluated"],False)
        self.assertIs(result["native_input_bytes_independently_verified"],False)

    def test_original_parent_identity_and_fixed_expected64_cannot_change(self):
        original = metadata_fixture()
        for destination,key,value in (("winner","original_deadline_monotonic_ns",12000),
                ("intent","original_deadline_boot_id","22222222-2222-4222-8222-222222222222"),
                ("winner","winner_saved_monotonic_ns",11000), ("winner","native_winner_monotonic_ns",True),
                ("winner","expected_artifacts_sha256","0" * 64), ("intent","first_nonce",1),
                ("request","source_commit","f" * 40)):
            request,winner,intent,header = copy.deepcopy(original)
            {"request":request,"winner":winner,"intent":intent}[destination][key] = value
            with self.assertRaises(ValueError):
                receiver.validate_parent_binding(request,winner,intent,header)

    def test_original_request_hash_binds_parent_operation_before_verification(self):
        request,winner,intent,header = metadata_fixture()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            content = {"header.bin":header, "winner-result.json":json.dumps(winner).encode(),
                       "winner-intent.json":json.dumps(intent).encode(), "succinct.bin":b"SYNTHETIC-NOT-A-RECEIPT"}
            request["files"] = {}
            for name,raw in content.items():
                (root/name).write_bytes(raw)
                request["files"][name] = {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
            raw = json.dumps(request).encode(); path = root/"request.json"; path.write_bytes(raw)
            args = SimpleNamespace(request=str(path),request_sha256=hashlib.sha256(raw).hexdigest())
            metadata = receiver.receive_inputs(args)
            self.assertIs(metadata["fresh_generation_independently_established"],False)
            request["parent"]["operation"] = "c" * 64
            path.write_text(json.dumps(request))
            with self.assertRaises(ValueError):
                receiver.receive_inputs(args)

    def test_unknown_cleanup_cancel_or_late_stage_cannot_complete(self):
        valid = {"schema":"TRNM-W1-STAGE-MEASUREMENT3", "stage_process_complete":True,
                 "returncode":0, "completion_observed_before_deadline":True,
                 "owned_session_observation_complete":True, "timed_out":False,
                 "deadline_exhausted_at_snapshot":False, "final_owned_session_members":[],
                 "process_group_remaining_after_child_exit":False, "final_known_group_probes":[{"state":"ABSENT"}],
                 "error":None, "canceled_signal":None, "cancellation_event":None,
                 "termination_reasons":[], "cleanup_errors":[], "proc_scan_errors":[], "group_probe_errors":[]}
        receiver.strict_stage(valid)
        for key,value in (("timed_out",True),("deadline_exhausted_at_snapshot",True),
                ("final_owned_session_members",[123]),("process_group_remaining_after_child_exit",True),
                ("final_known_group_probes",[{"state":"UNKNOWN"}]),("canceled_signal",15),
                ("returncode",False),("owned_session_observation_complete",False)):
            wrong = dict(valid); wrong[key] = value
            with self.assertRaises(ValueError):
                receiver.strict_stage(wrong)

    def test_float_deadline_is_never_rounded_past_original_integer(self):
        for ns in (1,11000,1152537491873545,2**63 - 1):
            a,b = receiver.deadline_seconds(ns).as_integer_ratio()
            self.assertLessEqual(a * 1_000_000_000, ns * b)


if __name__ == "__main__":
    unittest.main()
