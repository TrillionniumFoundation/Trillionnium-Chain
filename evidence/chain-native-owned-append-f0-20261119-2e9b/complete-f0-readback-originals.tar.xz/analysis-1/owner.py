from pathlib import Path
import json,hashlib,sys,time,resource
root=Path('/home/qian-qi/work/chain-native-owned-append-f0-20261119-2e9b');out=root/'analysis-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);t=time.monotonic();c0=resource.getrusage(resource.RUSAGE_SELF)
sources=[root.parent/'chain-native-operation-readback-f0-20261119-2e9b/current-cost-profile.json',root/'current-cost-profile.json'];runs=[]
for path in sources:
 raw=path.read_bytes();obj=json.loads(raw)['run'];row={k:v for k,v in obj.items() if k!='phases'};row['source']={'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};row['phases']=[]
 for phase in obj['phases']:
  p={k:v for k,v in phase.items() if k not in ('history_attempts','actual_graph_frequency','original_controller_cgroup_resources')}
  p['imports']=[{k:v for k,v in h.items() if k not in ('actual_packets','checkpoint_observation','host_checkpoint_buckets')} for h in phase['history_attempts']]
  p['graph_frequency']=[{k:v for k,v in f.items() if k!='actual_blocks'} for f in phase['actual_graph_frequency']]
  row['phases'].append(p)
 runs.append(row)
report=json.loads((root/'collection/artifact-14501973522/execution/raw/report.json').read_text())
observation=[]
for p in report['phases']:
 o=p['receiver_observation'];observation.append({'phase':p['mode'],'observer_complete':p['observer_complete'],'observer_keys':list(o),'record_count':len(o['records']),'tail_records':o['records'][-2:]})
res={'schema':'chain-original-f0-append-complete-bottleneck-comparison-v1','qualification':'Different runner allocations and completed work counts; nested observations overlap; no causal speed or full cost claim','runs':runs,'receiver_tail_diagnostic':observation}
raw=(json.dumps(res,indent=2,sort_keys=True)+'\n').encode();(out/'current-bottleneck.json').write_bytes(raw)
c=resource.getrusage(resource.RUSAGE_SELF);measure={'file':str(out/'current-bottleneck.json'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'wall_seconds':time.monotonic()-t,'self_user_cpu_seconds':c.ru_utime-c0.ru_utime,'self_system_cpu_seconds':c.ru_stime-c0.ru_stime}
(out/'RESULT.json').write_text(json.dumps(measure,indent=2)+'\n');print(json.dumps(measure))
for r in runs:
 print(json.dumps({'run_id':r['run_id'],'phases':[{k:v for k,v in p.items() if k not in ('imports','original_public_process_rss_diagnostic','retained_database_files')} for p in r['phases']]}))
