from pathlib import Path
from urllib.parse import unquote,urlsplit
import json,subprocess,re,sys,time,resource,hashlib,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'original-tail-input-restore-68';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);head='e8b0ec93ab6a6a1ff5e36cfcf9d1179e030a5975';res={'schema':'chain-original-git-tail-fixture-restore-v1','head':head,'restored':[],'fetches':[],'waves':[],'complete':False};t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN);bs=resource.getrusage(resource.RUSAGE_SELF)
def sha(x):return hashlib.sha256(x).hexdigest()
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def command(name,args,stdin=None):
 w=time.monotonic();c=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:p=subprocess.run(args,input=stdin,cwd=src,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);r={'name':name,'argv':args,'exit_code':p.returncode,'wall_seconds':time.monotonic()-w,'child_user_cpu_seconds':a.ru_utime-c.ru_utime,'child_system_cpu_seconds':a.ru_stime-c.ru_stime};res.setdefault('commands',[]).append(r);save();assert p.returncode==0,r
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()==head;diff=subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src);res['unchanged_diff_sha256']=sha(diff);(out/'source-before.patch').write_bytes(diff);command('preflight',['bash','scripts/project-preflight.sh'])
 tracked={}
 for entry in subprocess.check_output(['git','ls-tree','-rz',head],cwd=src).split(b'\0'):
  if entry:
   meta,path=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();tracked[path.decode()]={'mode':mode,'kind':kind,'oid':oid}
 raw=(src/'scripts/ci/ci_job.sh').read_text();a=raw.index('    python3 scripts/test_cell_learning_business_join.py');z=raw.index('    ;;',a);tail=raw[a:z];files={p for p in re.findall(r'(?:scripts|formal)/[a-zA-Z0-9_./-]+\\.py',tail) if (src/p).is_file()};texts=[tail]+[(src/p).read_text() for p in sorted(files)];prefixes={'evidence/pon-joint-consensus-daa-20261108/native-retained-final','evidence/pon-upgrade-implementation-20261018/native-rounds/chain-p0-native-54','evidence/pon-upgrade-implementation-20261018/native-rounds/chain-pr327-original-campaign-39694587963'}
 for text in texts:
  for p in re.findall(r'evidence/[a-zA-Z0-9_./-]+',text):
   p=p.rstrip('.')
   if p in tracked or any(x.startswith(p+'/') for x in tracked):prefixes.add(p)
 requested={p for p in tracked if any(p==root or p.startswith(root+'/') for root in prefixes) and not (src/p).exists()};res['original_fixture_prefixes']=sorted(prefixes);res['examined_original_scripts']=sorted(files);res['original_missing_count']=len(requested);print(json.dumps({'fixture_prefixes':sorted(prefixes),'missing_inputs':len(requested),'literal_original_scripts':len(files)}),flush=True)
 for wave in range(40):
  requested={p for p in requested if not (src/p).exists()};res['waves'].append({'wave':wave,'requested':sorted(requested)});save()
  if not requested:break
  needed=sorted({tracked[p]['oid'] for p in requested})
  for at in range(0,len(needed),256):
   wanted=needed[at:at+256];tag='wave-'+str(wave)+'-fetch-'+str(at//256);(out/(tag+'.input')).write_text('\n'.join(wanted)+'\n');command(tag,['git','-c','fetch.negotiationAlgorithm=noop','-c','maintenance.auto=false','-c','fetch.writeCommitGraph=false','fetch','--no-tags','--no-write-fetch-head','--recurse-submodules=no','--filter=blob:none','origin','--stdin'],('\n'.join(wanted)+'\n').encode());res['fetches'].append({'wave':wave,'objects':len(wanted)});save();print(json.dumps({'wave':wave,'fetched_objects':min(at+256,len(needed)),'total':len(needed)}),flush=True)
  for name in sorted(requested):
   e=tracked[name];assert e['mode'] in ('100644','100755') and e['kind']=='blob';p=src/name;assert not p.exists()
   assert all(not parent.is_symlink() for parent in p.parents if parent.is_relative_to(src));raw=subprocess.check_output(['git','show',head+':'+name],cwd=src);assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==e['oid'];p.parent.mkdir(parents=True,exist_ok=True)
   with p.open('xb') as f:f.write(raw)
   p.chmod(0o755 if e['mode']=='100755' else 0o644);res['restored'].append({'path':name,'bytes':len(raw),'sha256':sha(raw),'git_blob':e['oid']})
  save();print(json.dumps({'wave':wave,'original_files_restored':len(res['restored'])}),flush=True)
  missing=set()
  for path in src.rglob('*.md'):
   if any(x in {'.git','target','__pycache__','.pytest_cache','node_modules'} for x in path.relative_to(src).parts):continue
   assert not path.is_symlink();text=re.sub(r'^'+chr(96)*3+r'[^\n]*\n.*?^'+chr(96)*3+r'[^\n]*$', '',path.read_text(),flags=re.M|re.S)
   for target in re.findall(r'\[[^\]]*\]\(([^\s)]+)\)',text):
    parsed=urlsplit(target.strip('<>'))
    if parsed.scheme or parsed.netloc or not parsed.path:continue
    dest=(path.parent/unquote(parsed.path)).resolve();assert dest.is_relative_to(src)
    if not dest.exists():missing.add(str(dest.relative_to(src)))
  requested=set()
  for name in missing:
   if name in tracked:requested.add(name)
   else:
    children=[p for p in tracked if p.startswith(name+'/')];assert children,'missing frozen Git '+name;preferred=[p for p in children if Path(p).name=='README.md'];requested.add(sorted(preferred or children)[0])
 else:raise RuntimeError('link dependency wave bound reached')
 assert subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src)==diff

 a=resource.getrusage(resource.RUSAGE_CHILDREN);aself=resource.getrusage(resource.RUSAGE_SELF);res.update(complete=True,wall_seconds=time.monotonic()-t,child_user_cpu_seconds=a.ru_utime-b.ru_utime,child_system_cpu_seconds=a.ru_stime-b.ru_stime,self_user_cpu_seconds=aself.ru_utime-bs.ru_utime,self_system_cpu_seconds=aself.ru_stime-bs.ru_stime);save();print(json.dumps({'complete':True,'restored':len(res['restored']),'bytes':sum(x['bytes'] for x in res['restored']),'wall_seconds':res['wall_seconds'],'commands':res['commands']}),flush=True)
except BaseException as e:
 a=resource.getrusage(resource.RUSAGE_CHILDREN);aself=resource.getrusage(resource.RUSAGE_SELF);res.update(error=repr(e),wall_seconds=time.monotonic()-t,child_user_cpu_seconds=a.ru_utime-b.ru_utime,child_system_cpu_seconds=a.ru_stime-b.ru_stime,self_user_cpu_seconds=aself.ru_utime-bs.ru_utime,self_system_cpu_seconds=aself.ru_stime-bs.ru_stime);save();(out/'error.log').write_text(traceback.format_exc());raise
