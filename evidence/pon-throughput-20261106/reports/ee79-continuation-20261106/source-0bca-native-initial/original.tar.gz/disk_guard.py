#!/usr/bin/env python3
"""External task-only 8 GiB disk stop; never changes Cargo/Rust arguments."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

FLOOR = 8 * 1024**3


def available(root):
    value = os.statvfs(root)
    return value.f_bavail * value.f_frsize


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--label', required=True)
    parser.add_argument('--head', required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if args.command[:1] == ['--']:
        args.command = args.command[1:]
    if not args.command or not re.fullmatch('[a-z0-9-]+', args.label):
        parser.error('command and canonical label required')
    root = args.root.resolve(strict=True)
    raw = root / 'raw'
    receipt = raw / ('guard-' + args.label + '.json')
    log = raw / ('guard-' + args.label + '.log')
    record = dict(schema='trnm-external-disk-guard-v1', status='running',
        argv=args.command, cwd=str(root / 'repo'), expected_head=args.head,
        floor_available_bytes=FLOOR, poll_seconds=0.25,
        enforcement='sampled external stop, not a filesystem reservation or hard quota',
        guard_sha256=digest(Path(__file__).resolve()), runner_success=False,
        disk_guard_triggered=False, child_exit_code=None, started_unix_ns=time.time_ns())
    with receipt.open('x') as stream:
        json.dump(record, stream, sort_keys=True)
    signal_seen = []

    def interrupted(number, _):
        signal_seen.append(number)

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)

    def save():
        temporary = receipt.with_suffix('.updating')
        temporary.write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
        os.replace(temporary, receipt)

    process = None
    stop_reason = None
    try:
        record['initial_available_bytes'] = available(root)
        record['minimum_available_bytes'] = record['initial_available_bytes']
        if record['initial_available_bytes'] < FLOOR:
            record['disk_guard_triggered'] = True
            stop_reason = 'disk_below_floor_before_start'
        else:
            with log.open('xb') as stream:
                process = subprocess.Popen(args.command, cwd=root / 'repo',
                    stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
                    start_new_session=True)
                record['child_pid_and_process_group'] = process.pid
                save()
                next_save = time.monotonic() + 5
                while process.poll() is None:
                    current = available(root)
                    record['last_available_bytes'] = current
                    record['minimum_available_bytes'] = min(record['minimum_available_bytes'], current)
                    if current < FLOOR:
                        record['disk_guard_triggered'] = True
                        stop_reason = 'disk_below_floor_during_command'
                        break
                    if signal_seen:
                        stop_reason = 'external_stop_signal'
                        record['stop_signals'] = signal_seen.copy()
                        break
                    if time.monotonic() >= next_save:
                        save()
                        next_save = time.monotonic() + 5
                    time.sleep(0.25)
                if stop_reason:
                    record['stop_reason'] = stop_reason
                    save()
                    # Only the new session/process group created above. Keep
                    # its leader unreaped until escalation so its PID cannot be
                    # reused for an unrelated group during this five-second gap.
                    try:
                        os.killpg(process.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    time.sleep(5)
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                record['child_exit_code'] = process.wait()
    except (OSError, ValueError) as error:
        record['error'] = str(error)
        stop_reason = 'guard_error'
        if process is not None and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
                time.sleep(5)
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            record['child_exit_code'] = process.wait()
    if stop_reason:
        record['stop_reason'] = stop_reason
        # Interrupted original receipts remain incomplete, not successful.
        # A separate after-source observation preserves the retained checkout
        # identity without pretending the interrupted native command completed.
        after = raw / ('guard-' + args.label + '-source-after.json')
        after_log = raw / ('guard-' + args.label + '-source-after.log')
        command = [sys.executable, str(root / 'repo/scripts/ci/verify_ci_source.py'),
                   '--kind', 'head', '--expected-head', args.head, '--output', str(after)]
        with after_log.open('xb') as stream:
            result = subprocess.run(command, cwd=root / 'repo', stdout=stream,
                                    stderr=subprocess.STDOUT, check=False)
        record['after_stop_source_check'] = dict(argv=command, exit_code=result.returncode,
                                                log=str(after_log), log_sha256=digest(after_log))
    record['runner_success'] = stop_reason is None and record['child_exit_code'] == 0
    record['status'] = 'passed' if record['runner_success'] else 'failed'
    record['finished_unix_ns'] = time.time_ns()
    record['final_available_bytes'] = available(root)
    if log.exists():
        record['log_sha256'] = digest(log)
        record['log_bytes'] = log.stat().st_size
    save()
    print(json.dumps(record, sort_keys=True))
    return 0 if record['runner_success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
