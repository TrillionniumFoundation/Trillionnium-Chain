#!/usr/bin/env python3
"""Join actual local observations without turning metadata into execution."""
from __future__ import annotations
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

BASE=Path('/workspace/scratch/bb9b841c1d43')
ROOT=BASE/'pq-task-renewal-v5'
LOCAL=BASE/'pq-v5-evidence'
META=BASE/'pq-v5-typecheck'
DEST=ROOT/'evidence/pon-pq-task-renewal-v5-20261028'
PARENT='a1815707d29d424a8ec89d3701a7cf914572a416'
REMOTE='1d4778507e1e99ab54cca72b7c26b6ec2ff33344'
TREE='a7ac9da2199e8a9024c0daca800f0bd5ffef5c05'

def sha(data):return hashlib.sha256(data).hexdigest()
def digest(path):return sha(path.read_bytes())
def write(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def inventory():
    return {str(p.relative_to(ROOT)):digest(p)
        for prefix in ('scripts','trillionnium','config','formal/pon-nakamoto-v1','.github')
        for p in sorted((ROOT/prefix).rglob('*'))
        if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}

assert git('rev-parse','HEAD').decode().strip()==PARENT
assert git('rev-parse','HEAD^{tree}').decode().strip()==TREE
current=inventory()
write(DEST/'source-inputs.json',{'schema':'npq5-local-input-inventory-v1',
    'base_local_commit':PARENT,'base_remote_commit':REMOTE,'base_tree':TREE,
    'scope':'present explicitly inventoried source inputs; not a complete tracked-worktree source qualification',
    'file_count':len(current),'sha256_by_path':current})

checks={}
for stem,count in [('legacy-reader-frozen',76),('new-gate-readers-frozen',12),
        ('retained-gate-readers-frozen',10),('source-negatives-final',34),
        ('evidence-sources-final',38),('ci-contract-frozen',None),
        ('locked-graph-final',None),('fmt-frozen',None),('inventory-final',None),
        ('preflight-final',None)]:
    report=json.loads((LOCAL/(stem+'.json')).read_text())
    assert report['passed'] and report['exit_code']==0 and not report['timed_out']
    assert report['source_sha256_before']==report['source_sha256_after']
    changed={p:{'at_observation':h,'final':current.get(p)}
        for p,h in report['source_sha256_after'].items() if current.get(p)!=h}
    permitted={'trillionnium/crates/trnm-mvcc-fee/tests/pq5_task_renewal.rs',
        '.github/workflows/pon-recent-batch-acceptance.yml'}
    if stem.endswith('frozen'):assert not changed
    else:assert set(changed)<=permitted
    text=(LOCAL/(stem+'.stderr.log')).read_text()
    if count is not None:
        assert re.search(r'Ran '+str(count)+r' tests? in ',text)
        assert re.search(r'\nOK\s*$',text)
    for suffix in ('stdout.log','stderr.log'):
        assert digest(LOCAL/report[suffix]['path'])==report[suffix]['sha256']
    checks[stem]={'observation':'checks/'+stem+'.json','sha256':digest(LOCAL/(stem+'.json')),
        'actual_exit_code':0,'actual_test_count':count,'timeout_seconds':report['timeout_seconds'],
        'elapsed_ns':report['elapsed_ns'],'source_unchanged_during_observation':True,
        'final_inventory_differences':changed,
        'scope_join':('exact final inventoried source' if not changed else
            'only later integration-test strengthening and reviewed workflow literals; relevant checker/graph/inventory inputs are unchanged')}

selected=[('trnm_protocol-lib-clippy02',set()),('trnm_crypto_primitives-lib-clippy02',set()),
    ('trnm_mvcc_fee-lib-clippy02',set()),('trnm_pon_node-lib-clippy02',set()),
    ('trnm_protocol-lib-clippytests02',set()),('trnm_mvcc_fee-lib-clippytests02',set()),
    ('trnm_mvcc_fee-pq5_task_renewal-clippytests04',{'trillionnium/crates/trnm-mvcc-fee/tests/pq5_task_renewal.rs'}),
    ('trnm_pon_node-native_pq_v5-clippytests03',{'trillionnium/crates/trnm-pon-node/tests/native_pq_v5.rs'})]
integration_paths={'trillionnium/crates/trnm-mvcc-fee/tests/pq5_task_renewal.rs',
    'trillionnium/crates/trnm-pon-node/tests/native_pq_v5.rs'}
metadata=[];seen_externs={}
for label,actual_test in selected:
    result=json.loads((META/(label+'.json')).read_text())
    inputs=json.loads((META/(label+'-inputs.json')).read_text())
    assert result['returncode']==0 and not result['timeout']
    assert '--emit=metadata' in result['argv'] and result['argv'][-2:]==['-D','warnings']
    assert digest(META/(label+'.log'))==result['log_sha256']
    changed={p:{'at_observation':h,'final':current.get(p)} for p,h in inputs['source'].items() if current.get(p)!=h}
    assert set(changed)<=integration_paths-actual_test
    for item in inputs['selected_externs'].values():
        path=Path(item['path'])
        if str(path) not in seen_externs:seen_externs[str(path)]=digest(path)
        assert seen_externs[str(path)]==item['sha256']
    metadata.append({'label':label,'result':'metadata/'+label+'.json',
        'result_sha256':digest(META/(label+'.json')),'inputs_sha256':digest(META/(label+'-inputs.json')),
        'exit_code':0,'wall_seconds':result['wall_seconds'],
        'noninput_integration_files_changed':changed,
        'scope':'metadata-only strict Clippy; runtime/target input bytes exact; no native execution or full Cargo/all-features qualification'})

before={};after={}
contract='scripts/ci/native_pq_tasks_v4_unit_contract.py'
exec(git('show','HEAD:'+contract),before)
exec((ROOT/contract).read_text(),after)
old=before['EXPECTED_OUTCOMES'];new=after['EXPECTED_OUTCOMES']
assert all(new[k][n]==v for k,rows in old.items() for n,v in rows.items())
extra={k:{n:v for n,v in new[k].items() if n not in old[k]} for k in old}
assert sum(len(rows) for rows in extra.values())==1
retained={}
for p in ['trillionnium/Cargo.lock','trillionnium/Cargo.toml',
    'scripts/ci/run_native_pq_tasks_v4.py','scripts/ci/test_native_pq_tasks_v4_research.py',
    'trillionnium/crates/trnm-mvcc-fee/tests/pq4_task_authority.rs',
    'trillionnium/crates/trnm-pon-node/tests/native_pq_v4.rs']:
    b=(ROOT/p).read_bytes();assert b==git('show','HEAD:'+p)
    retained[p]={'bytes':len(b),'sha256':sha(b)}
roster={'schema':'npq5-retained-native-roster-v1',
    'original_passes_required':180,'original_integration_cases_required':44,
    'original_library_ignores_required':8,'original_library_entries_unchanged':True,
    'additional_library_cases':extra,'new_m06_integration_cases':16,'new_node_integration_cases':7,
    'total_passes_required':204,'new_integration_ignores_allowed':0,
    'v4_actual_w1_phases_required':26,'v5_actual_w1_phases_required':37,
    'v5_material_phases_required':10,'native_executed_on_current_source':False,
    'old_exact_files':retained}
write(DEST/'retained-roster.json',roster)

refusal=json.loads((LOCAL/'full-source-fence-sparse.json').read_text())
refusal_text=(LOCAL/'full-source-fence-sparse.stderr.log').read_text()
assert refusal['exit_code']==1 and not refusal['passed'] and 'index hides tracked worktree entries' in refusal_text
graph=json.loads((LOCAL/'locked-graph-final.stdout.log').read_text())
assert (len(graph['packages']),len(graph['workspace_members']),len(graph['resolve']['nodes']))==(173,26,173)
links=json.loads((LOCAL/'markdown-links-final.json').read_text())
assert links['result']=='PASS' and links['count']==11
assert all(digest(ROOT/path)==expected for path,expected in links['source_sha256'].items())
assert all((ROOT/item['resolved']).is_file() for item in links['links'])

summary={'schema':'npq5-local-validation-summary-v1','base_local_commit':PARENT,
    'base_remote_commit':REMOTE,'base_tree':TREE,'checks':checks,'metadata_clippy_targets':metadata,
    'metadata_targets_passed':8,'cargo_locked_metadata':{'packages':173,'workspace_members':26,'nodes':173},
    'new_markdown_links':{'result':'PASS','count':11,'observation':'checks/markdown-links-final.json','sha256':digest(LOCAL/'markdown-links-final.json')},
    'full_source_guard':'REFUSE: index hides tracked worktree entries',
    'full_source_guard_was_not_relaxed':True,
    'native_tests_executed':0,'native_status':'NOT_RUN_RESOURCE_STOP',
    'native_scope':'complete V5 Cargo build, tests, real W1 and all-targets/all-features Clippy require hosted execution',
    'failed_observations_retained':['metadata/trnm_mvcc_fee-lib-tests01.json',
        'metadata/trnm_protocol-lib-clippy01.json','metadata/trnm_pon_node-native_pq_v5-clippytests02.json',
        'checks/ci-contract-final.json','checks/full-source-fence-sparse.json']}
write(DEST/'validation-summary.json',summary)
qualification={'schema':'npq5-task-renewal-candidate-qualification-v1',
    'base_local_commit':PARENT,'base_remote_commit':REMOTE,'base_tree':TREE,
    'status':'SOURCE_CANDIDATE_NATIVE_NOT_RUN','fresh_profile':'NPQ5/PQP5',
    'candidate_commands':[18,19,20,21,22],
    'renewal_19_22_qualified':False,'full_cargo_graph_qualified':False,
    'metadata_only_clippy_targets_passed':8,'legacy_reader_tests_passed':76,
    'required_native_passes':204,'native_passes_observed':0,'retained_library_ignores':8,
    'required_v5_w1_phases':37,'required_v4_w1_phases':26,
    'capacity_status':'source-derived codec expectations and native executable assertions; not observed native qualification',
    'unchanged_limits':{'packet_bytes':1048576,'state_value_bytes':4096,'transaction_sum_bytes':524288,
        'transaction_bytes':9432,'w1_proof_bytes':49188,'task_slots':32,'local_revocations':1024,
        'native_controller_seconds':2400,'hosted_job_minutes':60},
    'expected_capacity':{'atomic_payload_bytes':1032,'atomic_transaction_bytes':8274,
        'registration_transaction_bytes':7894,'full_32_renewals_bytes':264768,
        'full_32_renewals_packet_bytes':314348,'witness_leaves_per_slot':5,
        'command_signature_checks_for_32_renewals':64},
    'migration_supported':False,'model_commands_supported':False,
    'retired_key_model_governance_qualified':False,'whole_chain_post_quantum':False,
    'p1_complete':False,'production_activation':False,'real_demand_proved':False,
    'useful_model_work_qualified':False,'source_chain_retirement_proved':False,
    'sqlite_physical_io_qualified':False,
    'independent_review_scope':'two shared-runtime source pin diffs only; full V5 runtime review remains open',
    'local_revocation_scope':'actual activation/transaction-root-bound stable-lineage local production refusal; branch-relative remote validity unchanged; no external full-storage rollback anchor',
    'open_blockers':['Exact published source hosted 204-test native gate and 37+26 real W1 phase readback',
        'Fresh Cargo all-targets/all-features strict Clippy on published source',
        'Independent full V5 runtime review',
        'Explicit task migration and external trust/source-retirement ownership',
        'Remaining model/evaluation and historical retired-key authority paths']}
write(DEST/'qualification.json',qualification)

files=[]
for path in sorted(LOCAL.iterdir()):
    if path.is_file() and path.suffix in ('.json','.log','.py'):
        files.append(('checks/'+path.name,path))
for path in sorted(META.iterdir()):
    if path.is_file() and path.suffix in ('.json','.log'):
        files.append(('metadata/'+path.name,path))
members=[]
archive=DEST/'observations.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
    for name,path in files:
        b=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0
        tar.addfile(info,io.BytesIO(b));members.append({'path':name,'bytes':len(b),'sha256':sha(b)})
assert archive.stat().st_size<=4*1024*1024
with tarfile.open(archive,'r:xz') as tar:
    actual=tar.getmembers();assert [m.name for m in actual]==[m['path'] for m in members]
    for member,expected in zip(actual,members):
        assert member.isfile();b=tar.extractfile(member).read()
        assert len(b)==expected['bytes'] and sha(b)==expected['sha256']
write(DEST/'observation-archive.json',{'schema':'npq5-local-observation-archive-v1',
    'archive':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive),
    'all_members_read_back':True,'member_count':len(members),'uncompressed_bytes':sum(m['bytes'] for m in members),
    'members':members,'scope':'actual metadata and Python observations; no native executable or native result is included'})
print(json.dumps({'metadata_targets':len(metadata),'checks':len(checks),'archive_members':len(members),
    'archive_bytes':archive.stat().st_size,'archive_sha256':digest(archive),'native_status':'NOT_RUN_RESOURCE_STOP'},indent=2))
