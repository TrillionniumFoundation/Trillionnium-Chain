import hashlib,json,os,sys,time
from pathlib import Path
ROOT=Path("/tmp/trnm-continuity-original-20261116-jvd8w4er")
def require(ok,msg):
 if not ok:raise ValueError(msg)
def ident(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
(ROOT/"repair_private_chunk_names_and_launch_v3.py").write_text(sys.orig_argv[sys.orig_argv.index("-c")+1])
prior=ROOT/"execution-wrapper.json";value=json.loads(prior.read_bytes())
require(value["status"]=="FAIL" and value["error"]=="ValueError('Noncontiguous or reordered chunks')" and value.get("oracle_exit_code") is None,"Unexpected original run state")
saved=ROOT/"execution-wrapper-transport-name-failure.json"
require(not saved.exists(),"Original transport failure already preserved")
prior.rename(saved)
chunks=ROOT/"chunks";old=ROOT/"chunks-before-name-correction"
require(not old.exists(),"Private transport repair already exists")
metadata=json.loads((chunks/"transfer.json").read_bytes());chunks.rename(old);chunks.mkdir(mode=0o700)
rows=[]
for i,part in enumerate(metadata["chunks"]):
 raw=(old/part["name"]).read_bytes();require(ident(raw)=={"bytes":part["bytes"],"sha256":part["sha256"]},"Frozen transport bytes changed")
 name=f"part-{i:03d}.bin"
 with (chunks/name).open("xb") as f:f.write(raw)
 rows.append(dict(part,name=name))
metadata["chunks"]=rows
(chunks/"transfer.json").write_text(json.dumps(metadata,sort_keys=True,indent=2)+"\n")
admission=json.loads((ROOT/"complete-journal-admission.json").read_bytes())
require(admission["status"]=="PASS_ORIGINAL_ABOUT_TO_RUN" and admission["actual_control_records"]==659 and admission["actual_semantic_records"]==572,"Native journal gate missing")
repair={"schema":"trnm.hia.private-chunk-name-adapter-repair.v1","status":"PASS","prior_failure":ident(saved.read_bytes()),"changed":"Private chunk filenames only: chunk-0000.bin to required part-000.bin; immutable bytes/offsets/hash/package unchanged","source_or_oracle_changed":False,"original_was_not_run_before_repair":True,"transfer":metadata,"finished_unix_ns":time.time_ns()}
(ROOT/"private-chunk-name-repair.json").write_text(json.dumps(repair,sort_keys=True,indent=2)+"\n")
print(json.dumps({"status":"PRIVATE_TRANSPORT_REPAIRED_ORIGINAL_LAUNCHING","package_sha256":metadata["package_sha256"],"chunks":len(rows)}),flush=True)
driver=ROOT/"desktop_run_continuity_v1.py"
require(ident(driver.read_bytes())["sha256"]=="dacb15e8ca501d31a072c861c1850c967dd3f12a183a22f32c61ed5791a9ad6b","Private execution driver changed")
os.execv("/usr/bin/python3",["/usr/bin/python3","-B",str(driver),"--package-sha256","e369ca94f46f70956e32774ce5e4246ac31000836e80011e5ffebd06f93dd4b6","--package-bytes","2655516","--comparison-sha256","d9fa9bbe83eb4676a6cba0f02af0276f2128dae29179b46f570f9c15724bb5c4","--source-count","61","--owned-count","18","--typed-count","13","--case-count","572"])
