#!/usr/bin/env python3
"""Restore only absent skipped evidence from the already-readable pinned HEAD blobs.

No source edits, HEAD moves, network fetches, replacement refs, attribute filters,
or source-verifier changes are made. Existing paths are never overwritten.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/baeed38792e5/chain')
OUT = Path('/workspace/scratch/baeed38792e5/liveness-work')
HEAD = '6ee529046d295e3175f09112492abee373f1f54c'
FLOOR = 1024 * 1024 * 1024


def git(*args: str, data: bytes | None = None) -> bytes:
    return subprocess.check_output(
        ['git', '--no-replace-objects', *args], cwd=ROOT, input=data)


def save(name: str, value: dict) -> None:
    path = OUT / name
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    os.replace(temporary, path)


def ensure_parent(path: Path) -> None:
    current = ROOT
    for part in path.relative_to(ROOT).parts[:-1]:
        if part in ('', '.', '..'):
            raise RuntimeError('noncanonical destination')
        current /= part
        if not current.exists():
            current.mkdir()
        if not stat.S_ISDIR(current.lstat().st_mode):
            raise RuntimeError('destination traverses non-directory')


def main() -> None:
    if git('rev-parse', 'HEAD').decode().strip() != HEAD:
        raise RuntimeError('pinned HEAD changed')
    index_before = git('ls-files', '--stage', '-z')
    if git('diff', '--cached', '--name-only', 'HEAD', '--'):
        raise RuntimeError('staged source differs from HEAD')
    flagged = git('ls-files', '-v', '-z').split(b'\0')
    if any(item[:1].islower() for item in flagged if item):
        raise RuntimeError('unexpected assume-unchanged flag')
    paths = [item[2:] for item in flagged if item.startswith(b'S ')]
    if len(paths) != 213 or len(set(paths)) != len(paths):
        raise RuntimeError('unexpected skipped path set')
    entries = {}
    for entry in git('ls-tree', '-r', '-l', '-z', 'HEAD').split(b'\0'):
        if entry:
            metadata, path = entry.split(b'\t', 1)
            mode, kind, blob, size = metadata.split()
            entries[path] = (mode.decode(), kind.decode(), blob.decode(), int(size))
    items = []
    for raw_path in paths:
        name = raw_path.decode('utf-8')
        path = ROOT / name
        mode, kind, blob, size = entries[raw_path]
        if not name.startswith('evidence/') or kind != 'blob' or mode not in ('100644', '100755'):
            raise RuntimeError('unexpected restore entry')
        if os.path.lexists(path):
            raise RuntimeError('target already exists: ' + name)
        items.append({'path': name, 'mode': mode, 'git_blob_sha1': blob, 'size': size})
    required = sum(item['size'] for item in items)
    free = shutil.disk_usage(ROOT).free
    if free < required + FLOOR:
        raise RuntimeError('insufficient disk reserve')
    report = {
        'schema': 'pinned-head-missing-evidence-restoration-v1',
        'head': HEAD,
        'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
        'root': str(ROOT),
        'source': 'existing local Git object database; exact HEAD blob IDs',
        'object_directory': git('rev-parse', '--path-format=absolute', '--git-path', 'objects').decode().strip(),
        'network_fetches': 0,
        'started_utc': datetime.now(timezone.utc).isoformat(),
        'minimum_free_bytes': FLOOR,
        'initial_free_bytes': free,
        'planned_count': len(items),
        'planned_bytes': required,
        'index_stage_sha256_before': hashlib.sha256(index_before).hexdigest(),
        'items': items,
        'completed': False,
    }
    save('missing-evidence-before.json', report)
    try:
        for item in items:
            if git('rev-parse', 'HEAD').decode().strip() != HEAD:
                raise RuntimeError('HEAD changed during restoration')
            if shutil.disk_usage(ROOT).free < item['size'] + FLOOR:
                raise RuntimeError('disk reserve reached')
            path = ROOT / item['path']
            ensure_parent(path)
            fd, temporary_name = tempfile.mkstemp(prefix='.restore-head-', dir=path.parent)
            temporary = Path(temporary_name)
            try:
                digest = hashlib.sha1(b'blob ' + str(item['size']).encode() + b'\0', usedforsecurity=False)
                content_digest = hashlib.sha256()
                count = 0
                process = subprocess.Popen(
                    ['git', '--no-replace-objects', 'cat-file', 'blob', item['git_blob_sha1']],
                    cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                with os.fdopen(fd, 'wb') as stream:
                    while chunk := process.stdout.read(1024 * 1024):
                        stream.write(chunk)
                        digest.update(chunk)
                        content_digest.update(chunk)
                        count += len(chunk)
                    process.stdout.close()
                    error = process.stderr.read()
                    process.stderr.close()
                    if process.wait() or error:
                        raise RuntimeError('Git object extraction failed: ' + item['path'])
                    stream.flush()
                    os.fsync(stream.fileno())
                if count != item['size'] or digest.hexdigest() != item['git_blob_sha1']:
                    raise RuntimeError('blob validation failed: ' + item['path'])
                os.chmod(temporary, 0o755 if item['mode'] == '100755' else 0o644)
                # A concurrent path creation fails instead of being overwritten.
                os.link(temporary, path)
                temporary.unlink()
                item.update(restored=True, sha256=content_digest.hexdigest(), source='local-head-blob')
            finally:
                if temporary.exists():
                    temporary.unlink()
        if git('ls-files', '--stage', '-z') != index_before:
            raise RuntimeError('staged entries changed during restoration')
        git('update-index', '--no-skip-worktree', '-z', '--stdin', data=b'\0'.join(paths) + b'\0')
        if git('ls-files', '--stage', '-z') != index_before:
            raise RuntimeError('staged entries changed when removing flags')
        report.update(
            completed=True,
            restored_count=sum(item.get('restored', False) for item in items),
            restored_bytes=sum(item['size'] for item in items if item.get('restored')),
            skip_flags_cleared=len(paths),
            final_free_bytes=shutil.disk_usage(ROOT).free,
            final_head=git('rev-parse', 'HEAD').decode().strip(),
            index_stage_sha256_after=hashlib.sha256(git('ls-files', '--stage', '-z')).hexdigest(),
            status_after=git('status', '--porcelain=v1', '--untracked-files=all').decode(),
        )
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        report['finished_utc'] = datetime.now(timezone.utc).isoformat()
        save('missing-evidence-restoration.json', report)
    print(json.dumps({key: value for key, value in report.items() if key != 'items'}, sort_keys=True))


if __name__ == '__main__':
    main()
