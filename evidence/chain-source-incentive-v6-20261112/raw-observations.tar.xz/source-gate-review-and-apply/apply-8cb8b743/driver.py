from __future__ import annotations
import hashlib, json, os, pathlib, re, subprocess, sys, tempfile, time, traceback

ROOT = pathlib.Path("/home/qq/chain-source-settlement-20261112-eb070ca2")
STAGE = pathlib.Path("/home/qq/chain-source-incentive-gate-staging-eb070ca2/review-8cb8b743")
OUT = pathlib.Path(__file__).parent
EXPECTED_HEAD = "8cb8b743bccd93a5fac49a072990d18e0d4b4a21"
EXPECTED_PREPARATION = "c721889a0f5392d6e861849b7760ae64dd4f61b3acce918cb9f8412f0e70d885"
EXPECTED_PATCH = "f6958f7b16cc054f0b2ad12494310803f1313b03b15c71bbf88f37dce4bba6c3"
CORPUS = "config/pon/pq-cross-branch-corpus-v1.json"
events = []
changed_by_driver = False

def sha(data):
    return hashlib.sha256(data).hexdigest()

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def run(label, argv, timeout=120):
    started = time.time()
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=timeout)
    (OUT / (label + ".stdout")).write_bytes(result.stdout)
    (OUT / (label + ".stderr")).write_bytes(result.stderr)
    row = {"label":label,"argv":argv,"exit_code":result.returncode,
           "duration_seconds":round(time.time()-started,6),
           "stdout_sha256":sha(result.stdout),"stderr_sha256":sha(result.stderr)}
    events.append(row)
    with (OUT / "commands.jsonl").open("a") as stream:
        stream.write(json.dumps(row,sort_keys=True)+"\n")
    print(json.dumps({"event":"command_completed",**row}),flush=True)
    return result

def git(*args):
    return subprocess.check_output(["git",*args],cwd=ROOT)

def clean():
    need(git("rev-parse","HEAD").decode().strip()==EXPECTED_HEAD,"HEAD must be exact first checkpoint")
    need(git("status","--porcelain=v1","--untracked-files=all")==b"","checkout must be clean before mutation")

def blob_id(data):
    return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()

try:
    clean()
    preflight=run("preflight",["bash","scripts/project-preflight.sh"])
    need(preflight.returncode==0,"preflight failed")
    clean()
    prep_raw=(STAGE/"preparation.json").read_bytes()
    patch=(STAGE/"source-gate-continuation.patch").read_bytes()
    need(sha(prep_raw)==EXPECTED_PREPARATION,"reviewed preparation changed")
    need(sha(patch)==EXPECTED_PATCH,"reviewed patch changed")
    prep=json.loads(prep_raw)
    need(prep["source_checkpoint"]==EXPECTED_HEAD,"staged checkpoint differs")
    rows=prep["staged_files"]
    need(len(rows)==5 and len({row["path"] for row in rows})==5,"exactly five reviewed files required")
    originals={}
    staged={}
    for row in rows:
        path=row["path"]
        actual=(ROOT/path).read_bytes()
        future=(STAGE/"files"/path).read_bytes()
        need(sha(actual)==row["old_sha256"],"old reviewed file drift: "+path)
        need(sha(future)==row["sha256"] and len(future)==row["bytes"],
             "new reviewed file drift: "+path)
        need(blob_id(future)==row["git_blob_sha1"],"staged Git blob differs: "+path)
        originals[path]=actual
        staged[path]=future
    corpus_before=(ROOT/CORPUS).read_bytes()
    corpus_text=corpus_before.decode()
    corpus=json.loads(corpus_text)
    old_pins=dict(corpus["pinned_blobs"])
    updates=prep["corpus_pin_updates"]
    need(set(updates)==set(originals),"exact five existing pin updates required")
    for path in updates:
        need(path in old_pins and path in corpus["required_paths"],"pin must already be required: "+path)
        need(old_pins[path]==blob_id(originals[path]),"existing corpus pin differs from current blob: "+path)

    match=re.search(r'"pinned_blobs"\s*:\s*',corpus_text)
    need(match is not None,"pinned_blobs object not found")
    begin=match.end()
    parsed,end=json.JSONDecoder().raw_decode(corpus_text,begin)
    need(parsed==old_pins,"pin object selection mismatch")
    section=corpus_text[begin:end]
    for path,new_pin in updates.items():
        pattern="("+re.escape(json.dumps(path))+r'\s*:\s*")'+re.escape(old_pins[path])+'(")'
        section,count=re.subn(pattern,lambda m:m.group(1)+new_pin+m.group(2),section)
        need(count==1,"pin replacement must be unique: "+path)
    corpus_after=(corpus_text[:begin]+section+corpus_text[end:]).encode()
    proposed=json.loads(corpus_after)
    expected=json.loads(corpus_before)
    expected["pinned_blobs"].update(updates)
    need(proposed==expected,"unrelated corpus semantics changed")
    need({p for p in old_pins if proposed["pinned_blobs"][p]!=old_pins[p]}==set(updates),
         "unrelated existing pin changed")
    originals[CORPUS]=corpus_before
    for path,data in originals.items():
        backup=OUT/"before"/path
        backup.parent.mkdir(parents=True,exist_ok=True)
        backup.write_bytes(data)

    check=run("patch-check",["git","apply","--check",str(STAGE/"source-gate-continuation.patch")])
    need(check.returncode==0,"reviewed patch cannot apply")
    clean()
    applied=run("apply-reviewed-patch",["git","apply",str(STAGE/"source-gate-continuation.patch")])
    need(applied.returncode==0,"patch apply failed")
    changed_by_driver=True
    # This replacement changes only the five reviewed existing pin values.
    target=ROOT/CORPUS
    need(target.read_bytes()==corpus_before,"corpus changed before atomic replacement")
    with tempfile.NamedTemporaryFile("wb",dir=target.parent,prefix=".source-gate-corpus-",delete=False) as stream:
        stream.write(corpus_after);stream.flush();os.fsync(stream.fileno());pending=pathlib.Path(stream.name)
    pending.chmod(target.stat().st_mode & 0o777)
    os.replace(pending,target)
    for path,data in staged.items():
        need((ROOT/path).read_bytes()==data,"applied bytes differ: "+path)
    need((ROOT/CORPUS).read_bytes()==corpus_after,"applied corpus differs")
    need(git("rev-parse","HEAD").decode().strip()==EXPECTED_HEAD,"HEAD changed during application")
    changed=set(git("diff","--name-only").decode().splitlines())
    need(changed==set(originals),"unrelated tracked file changed: "+repr(sorted(changed)))
    need(git("diff","--cached","--name-only")==b"","index unexpectedly staged")
    diffcheck=run("diff-whitespace",["git","diff","--check"])
    need(diffcheck.returncode==0,"diff whitespace failure")

    checks=[
      ("source-inventory",[sys.executable,"scripts/refresh_distributed_source_inventory.py","--check"]),
      ("authority-test",[sys.executable,"scripts/ci/test_pq_authority_effect_register.py"]),
      ("authority-reader",[sys.executable,"scripts/ci/pq_authority_effect_register.py"]),
    ]
    results=[]
    for label,argv in checks:
        result=run(label,argv)
        results.append((label,result.returncode))
    (OUT/"actual.patch").write_bytes(git("diff","--",*sorted(originals)))
    (OUT/"diff-stat.txt").write_bytes(git("diff","--stat"))
    (OUT/"post-status.txt").write_bytes(git("status","--porcelain=v1","--untracked-files=all"))
    need(git("rev-parse","HEAD").decode().strip()==EXPECTED_HEAD,"HEAD changed during checks")
    need(set(git("diff","--name-only").decode().splitlines())==set(originals),"post-check source set changed")
    files=[{"path":p,"bytes":len((ROOT/p).read_bytes()),"sha256":sha((ROOT/p).read_bytes()),
            "git_blob_sha1":blob_id((ROOT/p).read_bytes())} for p in sorted(originals)]
    summary={"status":"PASS" if all(code==0 for _,code in results) else "FAILED_PREINTEGRATION",
             "scope":"reviewed-source-gate-update-only-no-native-reexecution",
             "head":EXPECTED_HEAD,"committed":False,"changed_files":files,"checks":results,
             "corpus_only_changed_existing_pins":updates,"commands":events}
    (OUT/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    print(json.dumps(summary,sort_keys=True),flush=True)
    sys.exit(0 if summary["status"]=="PASS" else 1)
except Exception as error:
    summary={"status":"FAILED","error":str(error),"repository_mutation_started":changed_by_driver,
             "commands":events,"committed":False}
    (OUT/"failure.json").write_text(json.dumps(summary,indent=2)+"\n")
    (OUT/"failure.traceback").write_text(traceback.format_exc())
    try:
        (OUT/"failure-post-status.txt").write_bytes(git("status","--porcelain=v1","--untracked-files=all"))
        (OUT/"failure-actual.patch").write_bytes(git("diff"))
    except Exception:
        pass
    print(json.dumps(summary,sort_keys=True),flush=True)
    raise
