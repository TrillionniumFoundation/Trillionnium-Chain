import hashlib,json,lzma,os,sys,tarfile,time
from pathlib import Path,PurePosixPath
ROOT=Path("/tmp/trnm-continuity-original-v5-20261116-4s0txlam")
SOURCE=Path("/tmp/trnm-continuity-recovery-20261116-1b30xc0r/continuity-native-v5-original-bundle.tar.xz")
PACKAGE_SHA="caab1b9c1dddb72215bcd9e21dc483c9e77397c65a3e8a02a9c80d79505ab402"
PACKAGE_BYTES=2656892
SOURCE_SET="12dd16f62547fae1235416fc4421739f6f1a5905d75ff08bc3316e835aebd625"
def sha(raw):return hashlib.sha256(raw).hexdigest()
def ident(raw):return {"bytes":len(raw),"sha256":sha(raw)}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def write_json(path,value):
 with path.open("x") as stream:stream.write(json.dumps(value,sort_keys=True,indent=2)+"\n")
with (ROOT/"admit_and_launch_v5.py").open("x") as stream:stream.write(sys.orig_argv[sys.orig_argv.index("-c")+1])
raw=SOURCE.read_bytes();need(ident(raw)=={"bytes":PACKAGE_BYTES,"sha256":PACKAGE_SHA},"Whole immutable V5 package identity")
with tarfile.open(SOURCE,"r:xz") as archive:
 members=archive.getmembers();names=[m.name for m in members]
 need(len(names)==len(set(names))==75,"Unique 75 regular package members")
 need(sum(m.size for m in members)<=1<<30,"Aggregate archive extent")
 for m in members:
  p=PurePosixPath(m.name)
  need(m.isfile() and 0<=m.size<=512<<20 and not p.is_absolute() and str(p)==m.name and "\\" not in m.name and "\0" not in m.name and all(part not in ("",".","..") for part in p.parts),"Unsafe package member")
 blobs={m.name:archive.extractfile(m).read() for m in members}
 need(all(len(blobs[m.name])==m.size for m in members),"Short archive read")
comparison_raw=blobs["bundle/native-comparison.json"];comparison=json.loads(comparison_raw)
report=json.loads(blobs["bundle/native-report.json"]);build=json.loads(blobs["bundle/build.json"])
context_report=json.loads(blobs["bundle/context-report.json"])
need(build==comparison["build"]==report["build"],"Exact build receipts differ")
sources=build["source_inputs"]
need(len(sources)==61 and sum(p.startswith("hia/platform/continuity_store/") for p in sources)==18 and sum(p.startswith("hia/platform/typed_store/") for p in sources)==13,"Complete 61/18/13 source closure")
need(comparison["status"]==build["status"]=="PASS" and build["source_set_sha256"]==SOURCE_SET,"Frozen V5 source set")
need(set(sources)<=set(blobs) and all(p in sources or p.startswith(("bundle/","history/")) for p in blobs),"Unexpected/omitted package namespace")
for p,v in sources.items():need(ident(blobs[p])==v,"Captured source identity: "+p)
need(sha(json.dumps(sources,sort_keys=True,separators=(",",":")).encode())==SOURCE_SET,"Recomputed source digest")
need(report["status"]=="NATIVE_PASS_ORIGINAL_NOT_RUN" and report["control_count"]==659 and report["semantic_cases"]==572 and report["source_inputs_stable"] is True,"Complete actual native status")
need(report["control_journal"]["records"]==659 and report["comparison_journal"]["records"]==572,"Complete journal counts")
need(report["contexts"]==comparison["contexts"] and len(comparison["contexts"])==4,"Four actual native constructor snapshots")
need(set(report["archives"])=={"corpus.jsonl","control-records.jsonl","comparison-records.jsonl"},"Complete journal artifact identities")
decoded={};archives={}
for name,entry in report["archives"].items():
 compressed=blobs["bundle/"+name+".xz"];need(ident(compressed)==entry["archive"],"Compressed journal identity: "+name)
 decoder=lzma.LZMADecompressor(format=lzma.FORMAT_XZ,memlimit=64<<20)
 data=decoder.decompress(compressed,max_length=(512<<20)+1)
 need(decoder.eof and not decoder.unused_data and len(data)<=512<<20 and ident(data)==entry["raw"],"Complete decoded journal: "+name)
 decoded[name]=data;archives[name]={"raw":ident(data),"archive":ident(compressed),"lines":len(data.splitlines())}
need(archives["control-records.jsonl"]["lines"]==659 and archives["comparison-records.jsonl"]["lines"]==572 and archives["corpus.jsonl"]["lines"]==572,"Complete journal record cardinality")
need(ident(decoded["corpus.jsonl"])=={"bytes":90044661,"sha256":"ee34bbb31806534bd7e22cada7e88be7f10efcd0f780be51852377f29093a676"},"Unchanged exact V3/V5 corpus")
lines=decoded["control-records.jsonl"].splitlines(keepends=True)
need(len(lines)==len(report["controls"])==659,"Complete native control index")
offset=0
for index,(line,row) in enumerate(zip(lines,report["controls"],strict=True)):
 actual=json.loads(line);ref=row["complete_record"]
 need(ref["record"]==index and ref["offset"]==offset and ref["bytes"]==len(line) and ref["sha256"]==sha(line),"Actual control journal pointer/hash")
 need(actual["name"]==row["name"] and actual["status"]==row["status"]=="PASS","Actual control/journal values")
 offset+=len(line)
matches=[json.loads(line) for line in decoded["comparison-records.jsonl"].splitlines()]
need(matches==comparison["cases"] and len(matches)==572,"Complete actual native result journal differs")
history=lzma.decompress(blobs["history/continuity-536-corpus.jsonl.xz"],memlimit=64<<20)
need(ident(history)=={"bytes":1939076,"sha256":"1fc35f3b3e81e697a6086c044e5372165957a50ff37e03f8d115ced8d282d34f"},"Preserved original 536 corpus")
need(decoded["corpus.jsonl"].splitlines()[:536]==history.splitlines(),"Original 536 inputs changed or reordered")
chunks=ROOT/"chunks"
if chunks.exists():need(chunks.is_dir() and not chunks.is_symlink() and not list(chunks.iterdir()),"Existing chunk directory must be empty")
else:chunks.mkdir(mode=0o700)
parts=[]
for i,start in enumerate(range(0,len(raw),60000)):
 part=raw[start:start+60000];name=f"part-{i:03d}.bin"
 with (chunks/name).open("xb") as stream:stream.write(part)
 parts.append({"name":name,"offset":start,**ident(part)})
transfer={"package_sha256":PACKAGE_SHA,"package_bytes":PACKAGE_BYTES,"head":"453326b335af9375f2f6796d4e906cb4cdf2ce4d","tree":"fc5a31e67b207078ee1b01ad98e918df11ad8b8f","chunks":parts}
write_json(chunks/"transfer.json",transfer)
need(ident(SOURCE.read_bytes())==ident(raw),"Owner archive changed during admission")
admission={"schema":"trnm.hia.continuity-v5-complete-native-journal-admission.v1","status":"PASS_ORIGINAL_ABOUT_TO_RUN","package":{"path":str(SOURCE),**ident(raw)},"member_count":75,"source_set_sha256":SOURCE_SET,"source_inputs":sources,"comparison":ident(comparison_raw),"native_report":ident(blobs["bundle/native-report.json"]),"actual_control_records":659,"actual_semantic_records":572,"complete_control_index_recomputed":True,"complete_comparison_journal_equals_bundle":True,"actual_contexts":comparison["contexts"],"build_matches_report_and_comparison":True,"context_report_keys":list(context_report),"archives":archives,"original536_unchanged":True,"complete_member_identities":{p:ident(v) for p,v in blobs.items()},"checked_unix_ns":time.time_ns()}
write_json(ROOT/"complete-journal-admission.json",admission)
print(json.dumps({"status":admission["status"],"native_controls":659,"semantic_cases":572,"original_prefix":536,"source_set_sha256":SOURCE_SET,"comparison_sha256":sha(comparison_raw),"package_sha256":PACKAGE_SHA}),flush=True)
driver=ROOT/"desktop_run_continuity_v5.py"
need(sha(driver.read_bytes())=="08e6417605bafbe7286f58a79474a34c74102e83d33c19fbccafc2ef4d1b7e0e","Private execution driver changed")
os.execv("/usr/bin/python3",["/usr/bin/python3","-B",str(driver),"--package-sha256",PACKAGE_SHA,"--package-bytes",str(PACKAGE_BYTES),"--comparison-sha256",sha(comparison_raw),"--source-count","61","--owned-count","18","--typed-count","13","--case-count","572"])
