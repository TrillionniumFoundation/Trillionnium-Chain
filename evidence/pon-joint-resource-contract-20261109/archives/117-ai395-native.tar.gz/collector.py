#!/usr/bin/env python3
"""Collect completed native evidence without mutating original run directories."""
import hashlib,json,os,re,shutil,stat,tarfile,time
from pathlib import Path
BASE=Path("/home/qq/work")
PREP=BASE/"chain-pon-joint-58fd59-preparation"
STAGE=BASE/"chain-pon-joint-58fd59-native-evidence-11791e2d-01"
ARCHIVE=BASE/(STAGE.name+".tar.gz")
HEAD="11791e2da79b69322271be2cffe03725165151d1"
TREE="162552848110fda532504b78865a16930bc6d9bb"
RUNS={
"initial-no-run":BASE/"chain-pon-joint-58fd59-native-11791e2d-01",
"serial-02":BASE/"chain-pon-joint-58fd59-native-11791e2d-serial-02",
"remaining-03":BASE/"chain-pon-joint-58fd59-native-11791e2d-remaining-03",
}
JOBS={
"bundle-upload":"1a1be334762-138b0-921",
"final-import":"1a1be39380b-3902-1a",
"transfer-hash-refusal":"1a1be3c1646-3902-2a",
"initial-no-run-orchestration":"1a1be3d1f93-3902-32",
"serial-handoff-stop":"1a1be3fdfca-3902-47",
"serial-02":"1a1be42dc82-514c-10",
"remaining-03":"1a1be467bf5-5e21-6",
}
JOBROOT=Path("/home/qq/.local/state/hepta-runtime-mac-worker/jobs")
def sha(p):
    with p.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def write(p,v):
    with p.open("x") as f:json.dump(v,f,indent=2,sort_keys=True);f.write("\n")
def copy_file(src,dst):
    before=src.lstat()
    assert stat.S_ISREG(before.st_mode) and not src.is_symlink(),str(src)
    dst.parent.mkdir(parents=True,exist_ok=True)
    with src.open("rb") as si,dst.open("xb") as so:shutil.copyfileobj(si,so)
    after=src.lstat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    assert sha(src)==sha(dst),str(src)
def copy_tree(src,dst):
    assert src.is_dir() and not src.is_symlink()
    dst.mkdir(parents=True,exist_ok=False)
    for p in sorted(src.rglob("*")):
        assert not p.is_symlink(),str(p)
        if p.is_file():copy_file(p,dst/p.relative_to(src))
STAGE.mkdir(exist_ok=False)
copy_file(Path(__file__),STAGE/"collector.py")
processes=[]
for label,job in JOBS.items():
    src=JOBROOT/job
    exitdata=json.loads((src/"exit.json").read_text())
    assert exitdata["output_complete"] and exitdata["output_durable"]
    assert not any(exitdata["log_truncated"].values()) and not any(exitdata["log_errors"].values())
    for stream in ("stdout","stderr"):
        count=exitdata["log_bytes"][stream]
        assert count["seen"]==count["stored"]==(src/(stream+".log")).stat().st_size
    dst=STAGE/"processes"/label
    dst.mkdir(parents=True)
    for p in sorted(src.iterdir()):
        if p.suffix==".json" or p.name in ("stdout.log","stderr.log","stdin.bin"):
            copy_file(p,dst/p.name)
    processes.append({"label":label,"job_id":job,"exit_code":exitdata["exit_code"],"output_complete":exitdata["output_complete"],
        "output_durable":exitdata["output_durable"],"log_bytes":exitdata["log_bytes"],"role":"original process metadata and byte-for-byte streams"})
for label,path in RUNS.items():copy_tree(path,STAGE/"runs"/label)
for name in ("fc5c44ca-import","11791e2d-import"):
    copy_tree(PREP/name,STAGE/"preparation"/name)
for name in ("native117-serial-handoff-stop.json","native117-serial-handoff-complete.json","store-growth-roster-correction.json"):
    copy_file(PREP/name,STAGE/"preparation"/name)
# Independent collector verifies existing receipts; it never changes statuses.
receipts=[]
for group,root in RUNS.items():
    for p in sorted(root.glob("*.json")):
        obj=json.loads(p.read_text())
        if not isinstance(obj,dict) or obj.get("schema")!="trnm-pq-native-command-v1":continue
        log=root/obj["log_file"]
        valid=(obj.get("before")==obj.get("after") and obj.get("before",{}).get("tested_commit")==HEAD
            and obj.get("before",{}).get("tested_tree")==TREE and obj.get("before",{}).get("tracked_worktree_verified") is True
            and obj.get("log_sha256")==sha(log) and obj.get("log_bytes")==log.stat().st_size)
        assert valid,str(p)
        receipts.append({"run":group,"receipt":p.name,"status":obj["status"],"exit_code":obj["exit_code"],"source_and_log_integrity":valid,
            "before":obj["before"],"after":obj["after"],"test_threads":obj["environment"].get("RUST_TEST_THREADS")})
# Select actual successful component receipts from the preserved two serial runs.
components=[]
for group,label,total,ignored in [("serial-02","history-deadline",10,0),("serial-02","public-growth",7,0),
    ("remaining-03","store-growth",79,2),("remaining-03","consensus",10,0),("remaining-03","daa-joint-consensus",2,0)]:
    root=RUNS[group];r=json.loads((root/(label+".json")).read_text());o=json.loads((root/(label+".observation.json")).read_text())
    log=(root/(label+".log")).read_text()
    summaries=re.findall(r"^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;",log,re.M)
    parent=summaries[-1] if summaries else None
    success=(r["status"]=="command_succeeded" and r["exit_code"]==0 and r["environment"]["RUST_TEST_THREADS"]=="1"
        and o["source_and_command_pass"] and o["roster"]["pass"] and parent is not None and parent[0]=="ok"
        and int(parent[1])==total-ignored and int(parent[2])==0 and int(parent[3])==ignored and int(parent[4])==0)
    components.append({"run":group,"label":label,"passed":success,"test_total":total,"passed_tests":int(parent[1]) if parent else None,
        "failed_tests":int(parent[2]) if parent else None,"ignored_tests":int(parent[3]) if parent else None,
        "native_executables":o["native_executables"],"receipt_sha256":sha(root/(label+".json")),
        "log_sha256":sha(root/(label+".log")),"log_bytes":(root/(label+".log")).stat().st_size})
# Match the native emitted JSON to its retained JSON and every original packet.
daa=RUNS["remaining-03"]/"joint-daa-originals"
native_log=(RUNS["remaining-03"]/"daa-joint-consensus.log").read_text()
emitted={}
for line in native_log.splitlines():
    if "pon_native_joint_daa_v1 " in line:
        value=json.loads(line.split("pon_native_joint_daa_v1 ",1)[1]);emitted[value["backend"]]=value
packet_reports=[]
for backend in ("pnh1-authenticated","pgh2-growth"):
    directory=daa/backend
    path=directory/"joint-daa.json";data=json.loads(path.read_text())
    assert data["schema"]=="pon-native-joint-daa-v1" and data==emitted[backend]
    packetfiles=[]
    for row in data["records"]:
        packet=directory/row["packet_file"]
        assert packet.parent==directory/"packets" and packet.suffix==".pnk"
        assert packet.stat().st_size==row["packet_bytes"] and sha(packet)==row["packet_sha256"]
        packetfiles.append(row["packet_file"])
    assert len(set(packetfiles))==len(packetfiles)==114
    assert set(packetfiles)=={str(p.relative_to(directory)) for p in (directory/"packets").iterdir()}
    packet_reports.append({"backend":backend,"report_sha256":sha(path),"native_log_json_equal":True,
        "original_packets_verified":len(packetfiles),"retargets":data["retargets"],
        "shorter_higher_work_branch_selected":data["shorter_higher_work_branch_selected"],
        "after_cold_reopen":data["after_cold_reopen"],"public_network_qualification":data["public_network_qualification"],
        "wall_clock_cadence_measured":data["wall_clock_cadence_measured"],
        "attacker_work_fraction_measured":data["attacker_work_fraction_measured"],
        "quantum_attack_profitability_measured":data["quantum_attack_profitability_measured"]})
bad=JOBROOT/JOBS["transfer-hash-refusal"]/"stdin.bin"
actual=RUNS["initial-no-run"]/"runner.py"
raw=bad.read_bytes()
transfer={"failed_input_size":len(raw),"failed_input_sha256":sha(bad),"canonical_file_size":actual.stat().st_size,
    "canonical_file_sha256":sha(actual),"failed_input_plus_one_newline_matches_canonical":raw+b"\n"==actual.read_bytes(),
    "failure_before_source_build_or_test":True}
sqlites={group:json.loads((RUNS[group]/"sqlite-build-observation.json").read_text()) for group in ("serial-02","remaining-03")}
assert all(v["qualified"] and all(item["layout_cfg"] and not item["unqualified"]
    and item["build_fence"]==["sqlite-3.51.3-normal-native-linux-layout-v3"] for item in v["outputs"]) for v in sqlites.values())
summary={"schema":"pon-joint-ai395-native-evidence-v1","head":HEAD,"tree":TREE,
    "original_source_check_tracked_entries":26124,"original_source_check_tracked_bytes":2485379627,
    "components":components,"all_requested_native_components_pass":all(c["passed"] for c in components),
    "processes":processes,"receipts":receipts,"sqlite_build_outputs":sqlites,"joint_daa_integrity":packet_reports,
    "transfer_refusal_diagnostic":transfer,"failures_preserved":["initial transfer hash refusal","planned predecessor orchestration SIGTERM after completed no-run recorder","serial-02 external narrow-roster mismatch"],
    "public_resource_contract_executed":False,"whole_system_qualified":False,"production_activation":False,
    "archive_does_not_contain_target_or_full_source":True,"collector_time_ns":time.time_ns()}
write(STAGE/"collection-summary.json",summary)
manifest=[{"path":str(p.relative_to(STAGE)),"size":p.stat().st_size,"sha256":sha(p)}
    for p in sorted(STAGE.rglob("*")) if p.is_file()]
write(STAGE/"manifest.json",{"schema":"sha256-file-manifest-v1","manifest_excludes_itself":True,"files":manifest})
with tarfile.open(ARCHIVE,"x:gz",compresslevel=9) as tf:
    for p in sorted(STAGE.rglob("*")):
        if p.is_file():tf.add(p,arcname=str(p.relative_to(STAGE)),recursive=False)
archive={"path":str(ARCHIVE),"size":ARCHIVE.stat().st_size,"sha256":sha(ARCHIVE),
    "file_count":len(manifest)+1,"content_bytes_excluding_manifest":sum(r["size"] for r in manifest),
    "manifest_sha256":sha(STAGE/"manifest.json"),"all_requested_native_components_pass":summary["all_requested_native_components_pass"],
    "public_resource_contract_executed":False,"whole_system_qualified":False}
write(BASE/(ARCHIVE.name+".json"),archive)
print(json.dumps(archive,sort_keys=True),flush=True)

