#!/usr/bin/env python3
"""Sequential native validation of one frozen committed candidate.

No repository writes, timeout extensions, dependency resolution changes, or
substitution of historical test results. Cargo child costs include its build
and reaped descendants; peak RSS is not aggregate process-tree memory.
"""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/62902f6722b7/chain-work')
OUT = Path(__file__).resolve().parent
HEAD = '361825dd1f924770562705d7a68c78170f0375c3'
TREE = '92f8fbdc5b722498ede9dd85040d4716aa6a182e'
BASE = ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml']
COMMANDS = [
    ('01-m09-all-targets-all-features', BASE + ['-p', 'trnm-data-availability', '--all-targets', '--all-features', '--', '--test-threads=1'], 387),
    ('02-m09-doc-all-features', BASE + ['-p', 'trnm-data-availability', '--doc', '--all-features', '--', '--test-threads=1'], 10),
    ('03-node-storage-all-features', BASE + ['-p', 'trnm-pon-node', '--all-features', '--lib', 'storage_service::tests', '--', '--test-threads=1'], 22),
    ('04-settlement-native-budget-all-features', BASE + ['-p', 'trnm-service-settlement', '--all-features', '--lib', 'native_budget', '--', '--test-threads=1'], 35),
    ('05-v4-sampler-release', ['cargo', 'test', '--locked', '--offline', '--release', '--manifest-path', 'trillionnium/Cargo.toml', '-p', 'trnm-pon-node', '--example', 'pon_w1_preparation_strategy_v4', '--', '--test-threads=1'], 9),
]


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            value.update(block)
    return value.hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def verify_source(label):
    command = ['python3', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', HEAD]
    started = time.monotonic_ns()
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    receipt = {'command': command, 'exit_code': result.returncode, 'wall_ns': time.monotonic_ns() - started,
               'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
               'stderr_sha256': hashlib.sha256(result.stderr).hexdigest(), 'tests_executed': False}
    if result.returncode == 0:
        identity = json.loads(result.stdout)
        if identity['tested_commit'] != HEAD or identity['tested_tree'] != TREE:
            raise RuntimeError('Unexpected frozen source identity')
        receipt['identity'] = identity
    save(OUT / (label + '.json'), receipt)
    return receipt


def test_results(text):
    pattern = (r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; '
               r'(\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s$')
    blocks = []
    for match in re.finditer(pattern, text, re.MULTILINE):
        status, passed, failed, ignored, measured, filtered, seconds = match.groups()
        blocks.append({'status': status, 'passed': int(passed), 'failed': int(failed),
                       'ignored': int(ignored), 'measured': int(measured),
                       'filtered_out': int(filtered), 'execution_seconds': float(seconds)})
    totals = {name: sum(block[name] for block in blocks)
              for name in ('passed', 'failed', 'ignored', 'measured', 'filtered_out')}
    return {'blocks': blocks, 'totals': totals,
            'scope': 'Exact libtest/rustdoc summaries printed by this invocation; filtered and ignored tests are not credited.'}


def run_one(label, command, expected_passed):
    source_before = verify_source(label + '-source-before')
    if source_before['exit_code'] != 0:
        raise RuntimeError('Source identity failed before ' + label)
    log = OUT / (label + '.log')
    record = {'schema': 'trnm-composed-native-command-v1', 'label': label, 'command': command,
              'cwd': str(ROOT), 'source_before': label + '-source-before.json',
              'expected_passed_controls': expected_passed, 'started_utc': now(),
              'started_unix_ns': time.time_ns(), 'status': 'RUNNING',
              'budget_changes': False, 'historical_results_reused': False}
    save(OUT / (label + '-started.json'), record)
    print(json.dumps({'event': 'COMMAND_STARTED', 'label': label, 'command': command,
                      'log': str(log), 'started_utc': record['started_utc']}), flush=True)
    started = time.monotonic_ns()
    with log.open('xb') as stream:
        process = subprocess.Popen(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
        while True:
            try:
                _, status, usage = os.wait4(process.pid, 0)
                break
            except InterruptedError:
                continue
        process.returncode = os.waitstatus_to_exitcode(status)
    record.update(ended_utc=now(), ended_unix_ns=time.time_ns(),
                  wall_ns=time.monotonic_ns() - started, exit_code=process.returncode,
                  status='COMMAND_FINISHED', pid=process.pid)
    record['cost'] = {'user_cpu_seconds': usage.ru_utime, 'system_cpu_seconds': usage.ru_stime,
                      'total_cpu_seconds': usage.ru_utime + usage.ru_stime,
                      'max_single_process_rss_bytes': usage.ru_maxrss * (1024 if sys.platform == 'linux' else 1),
                      'minor_faults': usage.ru_minflt, 'major_faults': usage.ru_majflt,
                      'block_inputs': usage.ru_inblock, 'block_outputs': usage.ru_oublock,
                      'voluntary_context_switches': usage.ru_nvcsw,
                      'involuntary_context_switches': usage.ru_nivcsw,
                      'scope': 'wait4 for this exact Cargo child, including build and descendants it reaped. Not aggregate host/process-tree peak memory, service latency, energy, or a dedicated test-body CPU measurement.'}
    text = log.read_text(errors='replace')
    record['log'] = {'path': str(log), 'bytes': log.stat().st_size, 'sha256': digest(log)}
    record['test_results'] = test_results(text)
    record['observed_executables_after_command'] = []
    for name in sorted(set(re.findall(r'^\s*Running .+ \((/[^\n()]+)\)\s*$', text, re.MULTILINE))):
        executable = Path(name)
        item = {'path': name, 'exists': executable.is_file()}
        if executable.is_file():
            item.update(bytes=executable.stat().st_size, sha256=digest(executable))
        record['observed_executables_after_command'].append(item)
    record['executable_hash_scope'] = 'Post-command observation of test executable paths printed by Cargo; not a loader or reproducible-build attestation. Rustdoc temporary test binaries are not retained by the unchanged command.'
    # Preserve the executed command before the post-source check, including a
    # source-check failure or interrupted finalization.
    save(OUT / (label + '-receipt.json'), record)
    source_after = verify_source(label + '-source-after')
    record['source_after'] = label + '-source-after.json'
    record['source_identity_verified_before_and_after'] = source_after['exit_code'] == 0 and source_before.get('identity') == source_after.get('identity')
    totals = record['test_results']['totals']
    record['expected_control_count_observed'] = totals['passed'] == expected_passed
    record['validation_passed'] = (record['exit_code'] == 0 and
        record['source_identity_verified_before_and_after'] and
        record['expected_control_count_observed'] and totals['failed'] == 0 and
        bool(record['test_results']['blocks']))
    save(OUT / (label + '-receipt.json'), record)
    print(json.dumps({'event': 'COMMAND_FINISHED', 'label': label, 'exit_code': record['exit_code'],
                      'test_totals': totals, 'wall_ns': record['wall_ns'],
                      'source_identity_verified_before_and_after': record['source_identity_verified_before_and_after'],
                      'validation_passed': record['validation_passed']}), flush=True)
    return record


def main():
    declaration = OUT / 'declaration.json'
    if declaration.exists():
        raise RuntimeError('Refusing to overwrite an existing validation declaration')
    save(declaration, {'schema': 'trnm-composed-native-validation-declaration-v1',
        'head': HEAD, 'tree': TREE, 'declared_utc': now(), 'command_count': len(COMMANDS),
        'commands': [{'label': label, 'command': command, 'expected_passed_controls': expected}
                     for label, command, expected in COMMANDS],
        'environment': {key: os.environ.get(key) for key in ('RUSTC', 'RUSTDOC', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'PYTHONDONTWRITEBYTECODE', 'OPENSSL_DIR', 'OPENSSL_LIB_DIR', 'OPENSSL_INCLUDE_DIR')},
        'runner_sha256': digest(Path(__file__)), 'repository_mutation_authorized': False,
        'new_campaign_or_benchmark': False, 'timeouts_or_budgets_enlarged': False})
    toolchain = {}
    for name in ('cargo', 'rustc', 'rustdoc'):
        value = Path(shutil.which(name)).resolve()
        toolchain[name] = {'path': str(value), 'bytes': value.stat().st_size, 'sha256': digest(value)}
    save(OUT / 'toolchain.json', toolchain)
    with (OUT / 'preflight.log').open('xb') as output:
        preflight = subprocess.run(['bash', 'scripts/project-preflight.sh'], cwd=ROOT,
                                   stdout=output, stderr=subprocess.STDOUT, check=False)
    if preflight.returncode != 0:
        raise RuntimeError('Project preflight failed')
    state = {'schema': 'trnm-composed-native-validation-summary-v1', 'head': HEAD, 'tree': TREE,
             'declared_commands': len(COMMANDS), 'completed_commands': [], 'pending_commands': [x[0] for x in COMMANDS],
             'status': 'RUNNING', 'source_and_native_scope': 'Five actual sequential native commands on the frozen composed commit; no hosted CI, public-service, proof-generation or model-adoption result is implied.'}
    save(OUT / 'summary.json', state)
    for label, command, expected in COMMANDS:
        record = run_one(label, command, expected)
        state['completed_commands'].append({'label': label, 'receipt': label + '-receipt.json',
            'exit_code': record['exit_code'], 'test_totals': record['test_results']['totals'],
            'validation_passed': record['validation_passed']})
        state['pending_commands'].remove(label)
        save(OUT / 'summary.json', state)
    state['status'] = 'PASS' if all(item['validation_passed'] for item in state['completed_commands']) else 'FAIL'
    state['completed_utc'] = now()
    state['actual_passed_controls_total'] = sum(x['test_totals']['passed'] for x in state['completed_commands'])
    state['actual_failed_controls_total'] = sum(x['test_totals']['failed'] for x in state['completed_commands'])
    state['actual_ignored_controls_total'] = sum(x['test_totals']['ignored'] for x in state['completed_commands'])
    state['complete_denominator_scope'] = 'Pass/fail/ignored totals across these five command scopes. The same test/code can be exercised in more than one scope; this is not an independent-trial or service-confirmation count.'
    save(OUT / 'summary.json', state)
    print(json.dumps(state), flush=True)
    return 0 if state['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
