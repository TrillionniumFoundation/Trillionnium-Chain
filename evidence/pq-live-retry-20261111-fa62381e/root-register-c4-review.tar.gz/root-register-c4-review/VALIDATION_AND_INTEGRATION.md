# C4 root dependency register maintenance review

## Reviewed source and exact delta

The patch is based on S3 commit `454ae116159867ff6cddd91b964523df7f7e16f0`,
tree `3117250c4db0f2ae681d51ed6ee5e6a2fa7555a9`. The shared desktop
checkout has not been edited by this preparation.

All 41 declared source files were fetched from the immutable official S3 URL,
saved under `s3-selected/`, and hashed. Thirty-eight still match the preceding
frozen map. The only three changes are the workspace Cargo.lock and the
crypto-primitives and pon-node Cargo manifests. The old map's bytes match
published #901 commit `6c35f94d9387fac41c1547f05742d70150320b2e`.
The complete three-file delta is in `reviewed-rustix-source-delta.diff`: Rustix
1.1.4 becomes 1.1.6; the checksum changes; existing feature selections remain.

The four-file patch changes the register checkpoint and three source digests,
the reader's two frozen constants, a documented successor review, and three
existing corpus blob pins. It changes no source roster, test, role, budget,
algorithm, root policy, custody claim or qualification flag. It adds no
runtime code.

The source-map digest becomes
`0a6cb7dc497a9365e0538b0ab7de510c28068ef0f0b211d0f0971b460a7302d4`.
The reader is still a declared-file inventory inspector. It deliberately
returns `source_revision_bound = false`; a successful inspector is not a
Git commit attestation, native execution or lifetime security proof.

## Preserved originals

The exact S3 register, reader, tests, document and corpus are in `reference/`.
The prior frozen map digest is
`76cf5db4ce841bc3763d6010d79f835a6a0018c8d12f40a4047f0455b8bde6a1`
and prior checkpoint is `be5f047771e4d714726fec41abfa68231a06260b`.
The documentation preserves the older ac0cb... historical follow-up digest.

The complete original S3 repository-truth failure is retained in
`original-failure/job-130613468571.log.gz`, from
https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229392/job/130613468571 .
It ran 43 unchanged controls and exited 1 with 4 failures plus 1 error.
The first error is `source hash mismatch: trillionnium/Cargo.lock`.
The decoded original log SHA256 is
`e6f4318600a8e10f9f23cf1cf7a49ab8e41755052950d98afcf35a02b496fb6a`.

The actual W1 fresh-service failed observation is retained separately in
`original-failure/job-130596765045.log.gz`; it is not attributed to this
register mismatch. Its visible outer controller failed with systemd exit 1
after a successful native build; the visible log does not establish the
inner failed control or a resource-exhaustion root cause.

No historical report has been overwritten, renamed to S3, or relabelled PASS.

## Application and validation sequence for the integration owner

1. End the S3 source freeze only after the original source-bound Clippy receipt
   is terminal. Run the repository's original preflight before editing:
   `bash scripts/project-preflight.sh --audit`.
2. Verify the three actual source digests in `patch-review.json` and the exact
   original blobs before application. Use `git apply --check`, then apply the
   reviewed patch. If another C4 integration has already changed corpus pins,
   apply the three implementation/document files and merge only the exact
   three entries from `corpus-pin-delta.json`; do not overwrite the corpus.
3. Run the original unchanged suite:
   `python3 scripts/ci/test_pq_root_dependency_register.py -v`.
   Expect all 43 actual controls, including changed-source refusal,
   rewritten-map refusal, missing/oversized/nonregular/symlink source refusal,
   canonical source checkpoint refusal, exact roles, and all false/unknown
   qualification controls. Preserve the complete stdout/stderr and exit code.
4. Generate a new current report with the real CLI. It has no `--output`
   argument; stdout is the report:
   `python3 scripts/ci/pq_root_dependency_register.py --root .`.
   Capture stdout to a new external evidence file first. If retaining it in
   the repository, use a fresh path such as
   `evidence/pq-live-retry-20261111-fa62381e/root-dependency-register-current-report.json`.
   Preserve stderr and the actual exit code independently. Expected valid
   result is status HOLD, inventory_contract_satisfied true,
   source_files_checked true, source_file_count 41,
   source_binding_scope declared-root-component-files-only,
   source_revision_bound false, all eight domain_failure_bounds null,
   actual_lifetime_failure_bound null, and all qualification/activation flags
   false. A zero process exit is not a qualification PASS.
5. The existing inventory generator changes only its path list. This patch
   adds no source/config paths, so its existing inventory should be identical.
   After all C4 additions are known, the authoritative commands are:
   `python3 scripts/refresh_distributed_source_inventory.py`, followed by
   `python3 scripts/refresh_distributed_source_inventory.py --check`.
   Do not hand-edit the include list.
6. Finalize only reviewed corpus deltas after all integrated edits. For this
   patch alone the exact three old/new blob pairs are in
   `corpus-pin-delta.json`. There is no legitimate blanket accept-current
   refresh command. Preserve all historical pins and required paths. Any
   additional report/README archival registration is the integration owner's
   explicit C4 delta.
7. Run the actual repository source/corpus/claim gates:
   `python3 scripts/ci/check_pq_research_integration.py`,
   `python3 scripts/ci/pq_chain_claim_guard.py`,
   `python3 scripts/ci/check_ci_contract.py`,
   `python3 scripts/ci/check_repository.py`.
   Re-run applicable original regression suites and the full prescribed
   repository-truth lane if the integration gate requires them; this note
   does not replace or reduce that lane.
8. After C4 is committed and physically clean, bind the final 43 controls and
   report reproduction to its real commit using the existing
   `scripts/ci/record_pq_native_command.py`. Use an absolute receipt output
   outside source; supply kind=head and the same actual C4 SHA for candidate
   and tested. This recorder verifies every tracked raw byte before/after.
   It cannot truthfully attest a dirty precommit checkout. Preserve both
   preliminary candidate results and final committed-source receipts.

The local preparation performed only an exact expected-map/delta check;
`local-expected-graph.json` records this limited observation. The original
43 controls and new report have not been run by this child agent.

## Proposed sole-plan entry for the parent to integrate

The S3 repository-truth lane exposed a second stale current source map:
the V3 root dependency register still pinned pre-remediation Rustix inputs.
The actual S3 run executed all 43 controls, then failed with four assertions
and one error; the first error was the workspace lockfile hash. The successor
maintenance reviews all 41 declared files against published S3, updates only
the three changed Rustix source pins plus the current checkpoint and frozen
digest, and preserves the original failure and all historical source maps.
The original suite and a fresh HOLD report must be observed on the applied
candidate before completion is claimed. This is source-register maintenance;
the eight domain bounds and lifetime bound remain unknown, and whole-chain
PQ, PQ-128, independent custody, common-restore exclusion and production
activation remain unqualified.

