from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,time,resource,sys,traceback
root=Path('/home/qian-qi/work/chain-native-operation-readback-f0-20261119-2e9b');root.mkdir(exist_ok=False)
out=root/'dispatch-1';out.mkdir()
(out/'owner.py').write_text(sys.argv[1])
repo='TrillionniumFoundation/Trillionnium-Chain';head='3db79eb2682ba3bcbbf33557c5eee3b67731028f';tree='4877dd4e945841e734a57234e89fb1eb0440805e';branch='fix/chain-native-operation-readback-20261119-2e9b';workflow='pon-fixed-host-root-f0.yml'
res={'schema':'chain-operation-original-f0-dispatch-v1','head':head,'tree':tree,'branch':branch,'workflow':workflow,'planned_invocations':1,'stages':[],'business_qualified':False,'full_physical_cost_closed':False}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def call(name,args):
 start=time.monotonic();r0=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args,'started_utc':datetime.now(timezone.utc).isoformat()};res['stages'].append(row);save()
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:
  p=subprocess.Popen(args,stdout=so,stderr=se);row['pid']=p.pid;save();rc=p.wait()
 r1=resource.getrusage(resource.RUSAGE_CHILDREN);row.update(exit_code=rc,wall_seconds=time.monotonic()-start,child_user_cpu_seconds=r1.ru_utime-r0.ru_utime,child_system_cpu_seconds=r1.ru_stime-r0.ru_stime);save();print(json.dumps(row),flush=True)
 raw=(out/(name+'.stdout')).read_text()
 return rc,raw
try:
 rc,raw=call('account',['/usr/bin/gh','api','user','--jq','.login']);assert rc==0 and raw.strip()=='ProfHepta'
 rc,raw=call('frozen-head',['/usr/bin/gh','api','repos/'+repo+'/git/ref/heads/'+branch]);assert rc==0 and json.loads(raw)['object']['sha']==head
 rc,raw=call('frozen-tree',['/usr/bin/gh','api','repos/'+repo+'/git/commits/'+head]);c=json.loads(raw);assert rc==0 and c['tree']['sha']==tree and c['parents'][0]['sha']=='f088f1d4f8a50aff0c5ecd465480b2aeee6e5e94'
 endpoint='repos/'+repo+'/actions/workflows/'+workflow+'/runs?head_sha='+head+'&event=workflow_dispatch&per_page=100'
 rc,raw=call('before-dispatch',['/usr/bin/gh','api',endpoint]);assert rc==0;found=json.loads(raw)['workflow_runs'];found=[r for r in found if r['head_sha']==head]
 assert len(found)<=1,'multiple preexisting matching F0 runs; no dispatch allowed'
 if found:
  res['dispatch_post_attempts']=0;res['observed_existing_matching_run']=True
 else:
  payload=out/'dispatch-request.json';payload.write_text(json.dumps({'ref':branch})+'\n')
  res['dispatch_post_attempts']=1;res['dispatch_intent_utc']=datetime.now(timezone.utc).isoformat();save()
  rc,_=call('dispatch-once',['/usr/bin/gh','api','--method','POST','repos/'+repo+'/actions/workflows/'+workflow+'/dispatches','--input',str(payload)])
  res['dispatch_native_exit_code']=rc;save()
  # Never repeat an ambiguous POST. Reconcile only by read-only exact-head queries.
  for index in range(30):
   rc,raw=call('observe-'+str(index),['/usr/bin/gh','api',endpoint])
   if rc==0:
    found=[r for r in json.loads(raw)['workflow_runs'] if r['head_sha']==head]
    if found:break
   time.sleep(10)
 assert len(found)==1,'exactly one original F0 run must be observed'
 run=found[0];res['run']={k:run.get(k) for k in ['id','run_attempt','status','conclusion','head_sha','head_branch','html_url','created_at','updated_at','event','path']}
 assert res['run']['head_sha']==head and res['run']['run_attempt']==1
 save();print(json.dumps({'result':res,'root':str(root)}),flush=True)
except BaseException as error:
 res['error']=repr(error);save();(out/'error.log').write_text(traceback.format_exc());raise
