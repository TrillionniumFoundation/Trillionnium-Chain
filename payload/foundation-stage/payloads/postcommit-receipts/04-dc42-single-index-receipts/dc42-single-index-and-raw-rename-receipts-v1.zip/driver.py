import os,sys,pathlib,subprocess,json,hashlib,re,copy,datetime
D=pathlib.Path("/private/tmp/chain-audit-20261114-branch-graph/final-doc-blob-delta-review-v1/increment-dc42-v1");D.mkdir(exist_ok=False)
(D/"driver.py").write_text(sys.argv[1])
G=["/usr/bin/git","--git-dir=/private/tmp/chain-audit-recovery-records-20261113/full-history-independent-v1/complete.git"]
ENV={**os.environ,"GIT_NO_LAZY_FETCH":"1","GIT_OPTIONAL_LOCKS":"0","GIT_TERMINAL_PROMPT":"0"}
B="318527b4b2a07b5037d755547acd92e46ae3aded";H="dc42ce4df5cff79cc61c5addbaf01074b56b06ca";T="9fda17fed2542b2baccaa34585bb00afd699e12b"
P=pathlib.Path("/private/tmp/chain-audit-20261114-branch-graph/final-doc-blob-delta-review-v1")
R=P/("run-"+B);OLDINDEX=P/"delivery-318527b4-v1/receipt-index.json"
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,v):
 with (D/name).open("x") as f:json.dump(v,f,indent=2,ensure_ascii=True);f.write("\n")
def g(*a):
 p=subprocess.run(G+list(a),env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE);p.check_returncode();return p.stdout
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
oldidxbytes=OLDINDEX.read_bytes();assert sha(oldidxbytes)=="cb723e6bca7c3f993a005f39236e18dc07271469950fd6fce7ca5116b7eec4c6"
oldreceipt=json.loads(oldidxbytes)
coveragebytes=(R/"blob-coverage.jsonl").read_bytes()
entry=next(r for r in oldreceipt["members"] if r["path"]=="run-"+B+"/blob-coverage.jsonl")
assert sha(coveragebytes)==entry["sha256"] and len(coveragebytes)==entry["bytes"]
oldcoverage={r["oid"]:r for r in map(json.loads,coveragebytes.decode().splitlines())}
assert len(oldcoverage)==335
oldsummary=(R/"summary.json").read_bytes();assert sha(oldsummary)=="832b88158ccae777073c4281b7e9dcce5a7a9ad3b32562fced9f4dbd4f2fd630"
identity=g("show","-s","--format=%H%n%T%n%P",H).decode().splitlines();assert identity==[H,T,B]
patterns=(R/"patterns-and-scope.json").read_bytes();assert sha(patterns)=="33cdf0d872006fd692c72388443f0e8a47e804cfe679b28c6e612074ef5cf479"
compiled={x["id"]:re.compile(x["bytes_regex_ascii"].encode()) for x in json.loads(patterns)["patterns"]}
(D/"patterns-and-scope.json").write_bytes(patterns)
raw=g("diff-tree","-r","--no-commit-id","--raw","--no-renames","--no-ext-diff","--abbrev=40","-z",B,H)
(D/"raw-diff.bin").write_bytes(raw)
parts=raw.split(b"\0");assert parts.pop()==b"" and len(parts)==6
rows=[]
for i in range(0,len(parts),2):
 f=parts[i].decode().split();path=os.fsdecode(parts[i+1])
 assert len(f)==5 and f[0].startswith(":")
 rows.append({"path":path,"old_mode":f[0][1:],"new_mode":f[1],"old_oid":f[2],"new_oid":f[3],"status":f[4]})
indexpath="evidence/branch-consolidation-20261114/ARTIFACT_INDEX.json"
oldpath="evidence/branch-consolidation-20261114/remote/remote-open-pr-graphql-0210-v1/page-4.json"
newpath=oldpath+".raw"
expected={indexpath:"M",oldpath:"D",newpath:"A"}
assert {r["path"]:r["status"] for r in rows}==expected
by={r["path"]:r for r in rows}
empty="e69de29bb2d1d6434b8b29ae775ad8c2e48c5391"
assert by[oldpath]["old_oid"]==by[newpath]["new_oid"]==empty
assert by[oldpath]["old_mode"]==by[newpath]["new_mode"]=="100644"
assert empty in oldcoverage and oldcoverage[empty]["bytes"]==0 and oldcoverage[empty]["sha256"]==hashlib.sha256(b"").hexdigest()
assert g("cat-file","blob",empty)==b""
newblob=by[indexpath]["new_oid"];oldblob=by[indexpath]["old_oid"]
assert newblob not in oldcoverage and oldblob in oldcoverage
oldbytes=g("cat-file","blob",oldblob);data=g("cat-file","blob",newblob)
assert sha(oldbytes)==oldcoverage[oldblob]["sha256"]
assert sha(data)=="c7554324094f652d33616ae5f6701ce584313951bbe73638fa35690497a3d9df"
assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==newblob
a=json.loads(oldbytes);b=json.loads(data);expected_index=copy.deepcopy(a)
relative=oldpath.removeprefix("evidence/branch-consolidation-20261114/")
assert expected_index["entries"][145]["path"]==relative
expected_index["entries"][145]["path"]=relative+".raw"
assert b==expected_index
needle=('"path": "'+relative+'"').encode()
replacement=('"path": "'+relative+'.raw"').encode()
assert oldbytes.count(needle)==1 and data==oldbytes.replace(needle,replacement,1)
assert len(a["entries"])==len(b["entries"])==527
assert sum(r["bytes"] for r in a["entries"])==sum(r["bytes"] for r in b["entries"])==49605430
matches={name:{"count":len(hits),"offsets":hits} for name,pat in compiled.items() if (hits:=[m.start() for m in pat.finditer(data)])}
counts={name:matches.get(name,{}).get("count",0) for name in compiled}
write("path-diff.json",rows)
write("rename-and-index-equality.json",{"base":B,"head":H,"tree":T,"raw_diff_paths":3,"other_tree_paths_or_blob_OIDs_changed":False,"old_path":oldpath,"new_path":newpath,"preserved_empty_blob":empty,"preserved_empty_sha256":sha(b""),"old_index_blob":oldblob,"new_index_blob":newblob,"old_index_bytes":len(oldbytes),"new_index_bytes":len(data),"artifact_entries_preserved":527,"artifact_payload_bytes_preserved":49605430,"index_only_json_pointer_changed":"/entries/145/path","index_entire_byte_difference_is_single_dot_raw_suffix_in_target_path":True,"original_source_path_and_all_other_entry_fields_equal":True,"old_empty_blob_scan_reused":True,"old_335_blob_payloads_not_rescanned":True})
write("new-index-blob-scan.json",{"oid":newblob,"path":indexpath,"bytes":len(data),"sha256":sha(data),"content_address_verified":True,"all_raw_bytes_scanned":True,"match_counts":counts,"redacted_matches":matches,"raw_match_values_disclosed":False,"classification":"NO_MATCHES" if not matches else "REVIEW_REQUIRED","patterns_sha256":sha(patterns)})
summary={"schema":"one-index-blob-post-document-rename-review-v1","started_at":started,"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"base":B,"head":H,"tree":T,"parent_exact_base":True,"changed_raw_paths":3,"only_rename_and_single_index_path_replacement":True,"new_unique_blobs_scanned":1,"new_raw_blob_bytes_scanned":len(data),"new_blob_oid":newblob,"new_blob_sha256":sha(data),"all_new_content_addresses_verified":True,"match_counts":counts,"hit_blob_count":int(bool(matches)),"unclassified_hit_count":int(bool(matches)),"empty_blob_reused_from_335_prior_coverage":empty,"prior_receipt_index_sha256":sha(oldidxbytes),"prior_summary_sha256":sha(oldsummary),"prior_coverage_sha256":sha(coveragebytes),"prior_335_payloads_rescanned":False,"all_other_blob_OIDs_unchanged":True,"artifact_payload_count":527,"artifact_payload_bytes_unchanged":49605430,"raw_diff_sha256":sha(raw),"fsck_rerun":False,"git_writes":False,"recursive_archive_decompression":False,"all_secret_types_excluded":False,"external_receipts_are_outside_audited_commit":True,"additional_toml_markdown_probe_executed":False,"additional_probe_note":"Coordinator's full original repository check passed after rename; requested extra probe was cancelled before any remote execution."}
write("summary.json",summary);write("terminal.json",{"exit":0,"summary_sha256":sha((D/"summary.json").read_bytes()),"credential_review_complete":not matches})
print(json.dumps({"summary":str(D/"summary.json"),"summary_bytes":(D/"summary.json").stat().st_size,"summary_sha256":sha((D/"summary.json").read_bytes()),"new_blob":newblob,"bytes_scanned":len(data),"match_counts":counts,"all_other_blobs_unchanged":True,"index_payload_527_bytes_unchanged":49605430}),flush=True)
