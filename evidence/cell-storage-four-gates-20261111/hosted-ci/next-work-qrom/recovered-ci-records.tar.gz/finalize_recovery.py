#!/usr/bin/env python3
"""Recover only retained CI bytes; read Git objects and four small existing QROM artifacts. No tests."""
from pathlib import Path, PurePosixPath
import argparse, subprocess, json, hashlib, zipfile, io, stat, tarfile, gzip

ROOT = Path(__file__).resolve().parent
C3 = "030de92be05bfd4f73e199098c12dfeaedf29b17"
BASE = "30ce6e99c5d0d86e6563a49786e8b1e41b44c6c6"
C3_TREE = "21e970bfdb11ab64403d2af5f3c56536a2961f80"
def sha(data): return hashlib.sha256(data).hexdigest()
def raw_write(path, data):
    path = ROOT / path
    assert path.resolve().is_relative_to(ROOT)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.is_file() and not path.is_symlink() and path.read_bytes() == data, str(path)
        return
    with path.open("xb") as stream: stream.write(data)
def record(path, value): raw_write(path, (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode())
def reject_constant(value): raise ValueError("invalid JSON constant: " + value)
def strict_parse(data): return json.loads(data, parse_constant=reject_constant)
def preserved_path(path, data):
    failure = None
    saved = path
    if path.endswith(".json"):
        try: strict_parse(data)
        except (ValueError, UnicodeError) as error:
            saved = path + ".raw"
            failure = str(error)
    raw_write(saved, data)
    return saved, failure

parser = argparse.ArgumentParser()
parser.add_argument("--repo", type=Path, required=True)
parser.add_argument("--fetch-qrom", action="store_true")
args = parser.parse_args()
repo = args.repo.resolve()
assert repo.is_dir() and not ROOT.is_relative_to(repo), "Evidence root must be outside checkout"
def git(*argv): return subprocess.check_output(["git", "-C", str(repo), *argv])
assert git("rev-parse", C3 + "^{tree}").decode().strip() == C3_TREE
recovered = []
for index in range(8):
    package = strict_parse((ROOT / "transfer" / ("payload-%02d.json" % index)).read_bytes())
    assert package["schema"] == "cell-ci-memory-recovery-package-v1"
    for entry in package["entries"]:
        data = entry["content"].encode("utf-8")
        assert len(data) == entry["expected_bytes"], entry["path"]
        if entry["expected_sha256"] is not None:
            assert sha(data) == entry["expected_sha256"], entry["path"]
        saved, invalid = preserved_path(entry["path"], data)
        recovered.append({"original_path": entry["path"], "saved_path": saved,
            "bytes": len(data), "sha256": sha(data), "prior_sha_verified": entry["expected_sha256"] is not None,
            "origin": entry["origin"], "invalid_json_reason": invalid})
assert len(recovered) == 69 and sum(x["prior_sha_verified"] for x in recovered) == 65
record("RECOVERED_PAYLOADS.json", {"schema": "cell-ci-memory-recovered-payloads-v1", "files": recovered,
    "full_job_logs": 10, "prior_sha_verified_files": 65, "complete_command_output_captures": 4,
    "all_18_fresh_artifact_members_recovered": False,
    "note": "Only retained V8 bytes are restored. Capture stdout/result files are exact local retrieval records, not substitutes for all original artifact members."})

qrom_paths = [
 "formal/pon-nakamoto-v1/w1_v2_verifier/src/main.rs",
 "config/pon/w1-qrom-implementation-v1.json",
 "scripts/w1_qrom_implementation_audit.py", "scripts/w1_qrom_semantics_audit.py",
 "evidence/pon-w1-qrom-semantics-20261107/report.json",
 ".github/workflows/pon-w1-qrom-closure.yml", ".github/workflows/pon-w1-qrom-implementation.yml",
 "formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock"]
next_paths = [
 ".github/workflows/pon-next-architecture-security.yml",
 "scripts/ci/test_cell_storage_convergence_ci.py", "scripts/ci/test_cell_discovery_v3_ci.py",
 ".github/workflows/pon-w1-work-security.yml", "scripts/ci/run_w1_fresh_service_v1.py",
 "scripts/ci/run_from_zero_host.py", "scripts/ci/run_from_zero_native.py",
 "trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero.rs",
 "trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero/fresh_challenge.rs"]
source_results = {}
for group, paths in [("qrom", qrom_paths), ("next-work", next_paths)]:
    rows = []
    for path in paths:
        base_blob = git("rev-parse", BASE + ":" + path).decode().strip()
        candidate_blob = git("rev-parse", C3 + ":" + path).decode().strip()
        assert base_blob == candidate_blob, path
        data = git("cat-file", "blob", candidate_blob)
        assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == candidate_blob
        saved, invalid = preserved_path(group + "/source/c3/" + path, data)
        rows.append({"path": path, "base_blob": base_blob, "c3_blob": candidate_blob,
            "same_blob": True, "bytes": len(data), "sha256": sha(data), "saved_path": saved,
            "invalid_json_reason": invalid})
    changed = git("diff", "--name-only", BASE, C3).decode().splitlines()
    assert not set(paths).intersection(changed)
    result = {"base": BASE, "candidate": C3, "candidate_tree": C3_TREE,
        "files": rows, "changed_paths": changed, "reviewed_paths_intersect_change_set": False,
        "method": "Read-only exact Git objects on desktop; no runtime experiment or source mutation."}
    source_results[group] = result
    record(group + "/source-comparison.json", result)

artifact_recovery = []
for run in [43131213029, 43131212890]:
    listing = strict_parse((ROOT / "qrom" / ("run-%s" % run) / "artifacts.connector.json").read_bytes())["structuredContent"]["artifacts"]
    for meta in listing:
        aid = meta["id"]
        assert meta["size_in_bytes"] <= 65536, "Only the four known small QROM artifacts may be fetched"
        path = ROOT / "qrom" / "artifacts" / (str(aid) + ".zip")
        if path.exists():
            data = path.read_bytes()
        else:
            assert args.fetch_qrom, "QROM original ZIP missing; use explicit --fetch-qrom"
            process = subprocess.run(["/usr/bin/gh", "api",
                "repos/TrillionniumFoundation/Trillionnium-Chain/actions/artifacts/%s/zip" % aid],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
            if process.returncode:
                raw_write("qrom/artifacts/%s-fetch-error-%s.stderr" % (aid, sha(process.stderr)[:16]), process.stderr)
                raise RuntimeError("Read-only QROM artifact fetch failed: %s exit %s" % (aid, process.returncode))
            data = process.stdout
        assert len(data) == meta["size_in_bytes"] and sha(data) == meta["digest"].removeprefix("sha256:"), aid
        raw_write("qrom/artifacts/%s.zip" % aid, data)
        members = []
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            infos = archive.infolist()
            assert len(infos) <= 200 and sum(x.file_size for x in infos) <= 32 * 1024 * 1024
            for info in infos:
                if info.is_dir(): continue
                rel = PurePosixPath(info.filename)
                assert not rel.is_absolute() and ".." not in rel.parts and "\\" not in info.filename
                assert stat.S_IFMT(info.external_attr >> 16) != stat.S_IFLNK
                content = archive.read(info)
                saved, invalid = preserved_path("qrom/artifacts/%s/%s" % (aid, info.filename), content)
                members.append({"original_path": info.filename, "saved_path": saved, "bytes": len(content),
                    "sha256": sha(content), "zip_crc_verified": True, "invalid_json_reason": invalid})
        artifact_recovery.append({"run_id": run, "artifact_id": aid, "metadata": meta,
            "zip_bytes": len(data), "zip_sha256": sha(data), "github_digest_verified": True, "members": members})
assert len(artifact_recovery) == 4 and sum(len(x["members"]) for x in artifact_recovery) == 84
record("qrom/ARTIFACT_RECOVERY.json", {"artifacts": artifact_recovery,
    "all_four_original_zip_sha256_verified": True, "members_verified": 84,
    "transport": "Read-only desktop gh GET of stable existing artifact IDs. No workflow rerun."})

def differences(a, b, path="$"):
    if type(a) != type(b): return [{"path": path, "frozen": a, "generated": b}]
    if isinstance(a, dict):
        out = []
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b: out.append({"path": path + "." + key, "frozen": a.get(key), "generated": b.get(key)})
            else: out += differences(a[key], b[key], path + "." + key)
        return out
    if isinstance(a, list):
        if len(a) != len(b): return [{"path": path, "frozen_count": len(a), "generated_count": len(b)}]
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in differences(x, y, path + "[%s]" % i)]
    return [] if a == b else [{"path": path, "frozen": a, "generated": b}]
frozen_raw = (ROOT / "qrom/source/c3/evidence/pon-w1-qrom-semantics-20261107/report.json").read_bytes()
frozen = strict_parse(frozen_raw)
closure = []
for aid in [13907306916, 13906966410]:
    raw = (ROOT / ("qrom/artifacts/%s/semantics.json" % aid)).read_bytes()
    diff = differences(frozen, strict_parse(raw))
    first = next(i for i, (a, b) in enumerate(zip(frozen_raw, raw)) if a != b)
    assert len(diff) == 1 and diff[0]["path"] == "$.provenance.lock_checks[2].sha256"
    assert first + 1 == 73514 and frozen_raw[:first].count(b"\n") + 1 == 1696
    closure.append({"artifact_id": aid, "frozen_report_sha256": sha(frozen_raw), "generated_report_sha256": sha(raw),
        "first_different_byte_1_based": first + 1, "first_different_line_1_based": 1696, "structural_differences": diff})
contract = strict_parse((ROOT / "qrom/source/c3/config/pon/w1-qrom-implementation-v1.json").read_bytes())
pin = next(x for x in contract["project_files"] if x["path"] == qrom_paths[0])
actual = next(x for x in source_results["qrom"]["files"] if x["path"] == qrom_paths[0])
assert pin["bytes"] == 9233 and actual["bytes"] == 11172
qrom_observations = []
for aid in [13907017899, 13907685196, 13907306916, 13906966410]:
    directory = ROOT / ("qrom/artifacts/%s" % aid)
    before = strict_parse((directory / "source-before.json").read_bytes())
    after = strict_parse((directory / "source-after.json").read_bytes())
    assert before == after and before["tested_tree"] == C3_TREE
    status = strict_parse((directory / "ci-status.json").read_bytes())
    qrom_observations.append({"artifact_id": aid, "source": before, "source_before_after_equal": True, "ci_status": status})
record("qrom/REVIEW.json", {"candidate": C3, "base": BASE,
    "method": "Restored exact original full logs with prior SHA verification; restored four original small QROM ZIPs verified against recorded GitHub SHA; static source/JSON comparison only.",
    "implementation": {"actual_failure": "input exceeds bound: formal/pon-nakamoto-v1/w1_v2_verifier/src/main.rs",
        "pinned_record": pin, "actual_source": actual, "reader_limit": 9233, "reader_reads_at_most": 9234,
        "cli_exit_code": 2, "predicate": "bounded_file rejects limit+1 bytes before later pinned input drift checking",
        "named_control_boundary": "19 implementation audit methods: 15 successes, 2 assertion failures, 2 errors; WorkflowGateTests.setUpClass fails with the same AuditError and its 14 methods do not execute. Required 81-method roster incomplete."},
    "closure": {"actual_failure": "cmp differs at byte 73514, line 1696", "named_controls_passed_per_job": 105,
        "differences": closure, "later_compares_not_certified": True},
    "observations": qrom_observations, "classification": "Specific frozen-input inconsistencies already present in #879, not introduced by the 21-path Cell change set.",
    "qualification": "Both workflows and all four jobs remain failed. No limit was widened, frozen report refreshed, or security qualification inferred."})

next_jobs = strict_parse((ROOT / "next-work/run-43131212900/jobs.projection.json").read_bytes())["jobs"]
work_jobs = strict_parse((ROOT / "next-work/run-43131212866/jobs.projection.json").read_bytes())["jobs"]
source_receipts = []
failure_excerpts = []
for run, jobs in [(43131212900, next_jobs), (43131212866, work_jobs)]:
    for job in jobs:
        if job["conclusion"] != "failure": continue
        relative = "next-work/run-%s/job-%s/full.log" % (run, job["id"])
        lines = (ROOT / relative).read_text().splitlines()
        failures = [{"line_1_based": i + 1, "raw_line": s} for i, s in enumerate(lines) if "##[error]" in s]
        failure_excerpts.append({"run_id": run, "job_id": job["id"], "name": job["name"],
            "full_log": relative, "failed_steps": [s for s in job["steps"] if s["conclusion"] == "failure"], "errors": failures})
        clean = [s.split("Z ", 1)[1] if s[:4].isdigit() and "Z " in s else s for s in lines]
        observations = []
        for i, line in enumerate(clean):
            if line != "{": continue
            fragment = []
            for s in clean[i:i + 60]:
                fragment.append(s)
                if s == "}":
                    try:
                        value = strict_parse("\n".join(fragment))
                        if value.get("schema") == "trnm-ci-source-v1": observations.append(value)
                    except (ValueError, AttributeError): pass
                    break
        assert len(observations) == 2 and observations[0] == observations[1]
        assert observations[0]["tested_tree"] == C3_TREE
        source_receipts.append({"run_id": run, "job_id": job["id"], "source": observations[0],
            "source_before_after_equal": True, "parsed_from_original_full_log": True})
record("next-work/failure-excerpts.json", {"jobs": failure_excerpts})
record("next-work/source-receipts.json", {"jobs": source_receipts})
captures = []
for kind, aid, job in [("head", 13906069822, 130895529871), ("merge", 13908311753, 130895530271)]:
    relative = "next-work/recovery-captures/%s-selected-read-command.stdout" % kind
    text = (ROOT / relative).read_text()
    lines = text.splitlines()
    selection = strict_parse(lines[0]); diagnosis = strict_parse(lines[1])
    assert selection["artifact_id"] == diagnosis["artifact_id"] == aid
    assert selection["files"] == 9 and diagnosis["execution_finished"] is True
    assert "fresh challenges failed the original four-second/six-depth business target; retain report.json, no post-window success credit" in text
    assert "CONFIRMATION_TARGET" in text and "FRESH_NATIVE_PROCESS_REQUIRED" in text
    captures.append({"kind": kind, "artifact_id": aid, "job_id": job, "retained_stdout": relative,
        "prior_selection_report": selection, "retained_diagnosis": diagnosis,
        "all_original_members_restored": False, "original_native_log_text_in_capture": True})
assert len(next_jobs) == 4 and all(j["conclusion"] == "failure" for j in next_jobs)
assert all([s["name"] for s in j["steps"] if s["conclusion"] == "failure"] == ["Retain logs and failed or partial observations"] for j in next_jobs)
assert len(work_jobs) == 23
record("next-work/REVIEW.json", {"candidate": C3, "base": BASE,
    "method": "Restored full failed-job logs and complete original connector metadata with prior SHA verification. Static exact-source review. No new native tests or workflow reruns.",
    "next_architecture": {"run_id": 43131212900, "failed_jobs": 4,
        "all_prior_native_python_lint_format_source_and_outcome_steps_succeeded": True,
        "only_failed_stage": "Retain logs and failed or partial observations",
        "actual_failure": "upload-artifact rejected a generated filename containing Colon :",
        "invalid_filename": "native-storage-component-cell::host_handoff::tests::research_fds::research_fd_sender_refuses_changed_pins_budget_task_parent_or_expiry_before_any_byte.exit",
        "artifact_metadata_list_empty": True,
        "classification": "Inherited workflow output-filename defect; no failing executed native predicate in this run. Overall workflow remains failed."},
    "work_security": {"run_id": 43131212866, "jobs": 23, "success": sum(j["conclusion"] == "success" for j in work_jobs),
        "failure": sum(j["conclusion"] == "failure" for j in work_jobs), "skipped": sum(j["conclusion"] == "skipped" for j in work_jobs),
        "original": "Native exit 0 but finite_target_met=false; original report reader rejects CONFIRMATION_TARGET.",
        "fresh": "Native exit 101 at fresh_challenge.rs:244: original four-second/six-depth business target assertion fails; runner records FRESH_NATIVE_PROCESS_REQUIRED.",
        "actual_resources": {"window_ns": 4000000000, "attack_workers": 16, "cpu_max": "25000 100000", "memory_max": "2147483648", "swap_max": "0", "pids_max": "256"},
        "business_predicate_failure_not_outer_timeout": True, "fresh_last_history_replay": "PUBLIC_REQUEST_DEADLINE",
        "captures": captures,
        "causality_limit": "Relevant workflow, Host owner, readers and native test blobs are identical to #879. No direct Cell edit to these predicates/resources was found. No paired #879/C3 runtime comparison was performed, so indirect timing effects and causal performance regression are not ruled out."},
    "recovery_limits": ["All six original failed-job full logs and metadata restored with prior SHA verification.",
        "The previous local selection read 18 small original artifact members, 46,409 bytes, using 406,744 HTTP range bytes including ZIP directories.",
        "Those 18 original member files were not all retained in V8 and are not represented as recovered here. Exact extraction stdout/result captures survive, including four native log texts and diagnostics.",
        "No fresh-service complete ZIP, large report.json, binary or SQLite was re-downloaded for this recovery; no complete fresh ZIP digest independently verified.",
        "Passing work-security jobs are reported from jobs metadata; their full logs were not re-read."]})
record("next-work/FIX_RECOMMENDATION.json", {"scope": "Recommendation for reviewed C3; no source mutation by recovery script.",
    "workflow": ".github/workflows/pon-next-architecture-security.yml",
    "affected_loops_at_c3": [[220, 223], [248, 251]],
    "change": "Set stem=\u0024{selector//:/-} in both loops; use stem only in output label and paired reader log path. Preserve cargo selector and --test selector unchanged.",
    "controls": {"path": "scripts/ci/test_cell_storage_convergence_ci.py",
        "bindings": ["NODE_RUN_BODY lines 54-55", "COMPONENT_RUN_BODY lines 105-106", "candidate matcher near 352", "wrong-log negative controls near 381 and 478"],
        "other_workflow_reader": "scripts/ci/test_cell_discovery_v3_ci.py",
        "inventory": "config/pon/pq-cross-branch-corpus-v1.json"},
    "unchanged_requirements": ["Rust selectors", "--exact", "native gates", "business assertions", "deadlines", "resource budgets", "failure exits"]})

readme = """# Recovered C3 hosted CI evidence

Candidate: 030de92be05bfd4f73e199098c12dfeaedf29b17; base #879: 30ce6e99c5d0d86e6563a49786e8b1e41b44c6c6.

This recovery restores 65 original connector/decoded payload files against their pre-outage SHA-256, including ten complete failed-job logs, plus four complete retrieval stdout/result captures. It reads exact historical Git objects and four small existing QROM artifacts. It does not run tests, rerun workflows, or alter source, frozen reports, assertions or budgets.

## Actual failures

- QROM implementation run 43131213029: the pinned verifier contract permits 9,233 bytes; unchanged actual main.rs is 11,172 bytes. The reader rejects limit+1 before the later hash check. The required named roster is incomplete.
- QROM closure run 43131212890: 105 named controls pass in each job, then generated semantics differs from the frozen report at byte 73514 / line 1696. The sole JSON difference is the unchanged w1_zkvm/Cargo.lock provenance hash. Both workflow failures remain failures.
- Next architecture run 43131212900: four matrix jobs pass preceding execution and source checks; artifact upload fails because generated .exit/.log filenames contain Rust :: separators. No artifact was published by this run. The proposed filename-only correction preserves actual selectors and all native standards.
- Work security run 43131212866: metadata reports 20 successful jobs, two failed fresh-service jobs and one conditional skip. Original native service exits zero but finite_target_met is false, so the reader rejects CONFIRMATION_TARGET. Fresh native service exits 101 on its original four-second/six-depth business assertion. Its failure is not an artifact transport problem or outer timeout.

Read qrom/REVIEW.json, next-work/REVIEW.json and their exact-source comparisons. The unchanged direct source inputs establish the scope of inherited predicates; for timing-sensitive service failure, no paired baseline/candidate runtime comparison was performed.

## Recovery boundary

The former local environment became unavailable. All ten original full job logs and their original metadata survive in this recovery. Four original QROM ZIPs are fetched by stable artifact IDs and verified against their previously recorded GitHub size and SHA-256; all 84 members are retained.

The former local selection of 18 fresh-service artifact members (46,409 bytes) is NOT claimed to have survived in full. Exact untruncated extraction stdout/result records remain, containing native log text and diagnostics. No complete fresh-service ZIP, multi-megabyte report.json, native binary or SQLite is re-downloaded here; complete fresh ZIP SHA-256 is not independently verified.

Invalid original JSON, if any, is retained unchanged with .raw appended and explicitly mapped. Temporary signed download URLs are excluded. Connector JSON files are complete serialized connector results, not original HTTP response bytes. Source identity never establishes security qualification or business-target success.
"""
raw_write("README.md", readme.encode())
files = []
for path in sorted(ROOT.rglob("*")):
    if not path.is_file(): continue
    rel = path.relative_to(ROOT)
    if rel.parts[0] == "transfer" or str(rel) in ["MANIFEST.json", "FINAL_RECEIPT.json", "recovered-ci-records.tar.gz"]: continue
    data = path.read_bytes()
    files.append({"path": str(rel), "bytes": len(data), "sha256": sha(data)})
record("MANIFEST.json", {"schema": "cell-ci-recovered-evidence-manifest-v1", "candidate": C3, "base": BASE,
    "files_excluding_manifest_and_archive_receipt": len(files), "bytes": sum(x["bytes"] for x in files),
    "recovered_original_payloads_with_prior_sha": 65, "full_job_logs": 10,
    "qrom_original_zips_verified": 4, "qrom_members_verified": 84,
    "fresh_original_selected_members_restored_in_full": False, "files": files})
archive_path = ROOT / "recovered-ci-records.tar.gz"
included = sorted([x["path"] for x in files] + ["MANIFEST.json"])
if not archive_path.exists():
    with archive_path.open("xb") as stream:
        with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0, compresslevel=9) as zipped:
            with tarfile.open(mode="w", fileobj=zipped, format=tarfile.PAX_FORMAT) as archive:
                for relative in included:
                    data = (ROOT / relative).read_bytes()
                    info = tarfile.TarInfo(relative); info.size = len(data); info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    archive.addfile(info, io.BytesIO(data))
with tarfile.open(archive_path, "r:gz") as archive:
    assert archive.getnames() == included
    for member in archive.getmembers():
        assert archive.extractfile(member).read() == (ROOT / member.name).read_bytes()
final = {"schema": "cell-ci-recovered-final-receipt-v1", "root": str(ROOT),
    "archive": str(archive_path), "archive_bytes": archive_path.stat().st_size,
    "archive_sha256": sha(archive_path.read_bytes()), "archive_members": len(included),
    "manifest_sha256": sha((ROOT / "MANIFEST.json").read_bytes()),
    "original_payloads_prior_sha_verified": 65, "full_job_logs": 10, "qrom_zips_verified": 4, "qrom_members_verified": 84,
    "fresh_18_original_members_restored": False, "fresh_complete_extraction_stdout_results_retained": 4,
    "native_or_workflow_reruns": False, "source_mutations": False}
record("FINAL_RECEIPT.json", final)
print(json.dumps(final, sort_keys=True))
