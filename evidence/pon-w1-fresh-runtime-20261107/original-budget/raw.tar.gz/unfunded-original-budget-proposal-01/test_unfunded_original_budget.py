#!/usr/bin/env python3
"""Pure contract/negative decisions; no subprocess, native search or proof."""
import copy
import importlib.util
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("probe", HERE / "run_unfunded_original_budget.py")
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


class OriginalBudgetContractTests(unittest.TestCase):
    def setUp(self):
        self.script = HERE / "run_unfunded_original_budget.py"
        self.contract = probe.fixed_contract(self.script, "a" * 64)
        self.rows = [{"label": name, "dispatched": True, "actual_stage_complete": True, "error": None}
                     for name in probe.LABELS]

    def test_fixed_contract_rejects_booleans_disguised_as_integer_limits(self):
        self.contract["resources"]["segment_workers"] = True
        with self.assertRaises(ValueError):
            probe.validate_contract(self.contract, self.script)

    def test_source_and_independent_artifact_pin_mutations_are_rejected(self):
        for mutate in ("source", "expected"):
            value = copy.deepcopy(self.contract)
            if mutate == "source":
                value["source"]["commit"] = "b" * 40
            else:
                value["inputs"] = copy.deepcopy(probe.PINNED_INPUTS)
                value["inputs"]["expected_artifacts"]["sha256"] = "b" * 64
            with self.assertRaises(ValueError):
                probe.validate_contract(value, self.script)

    def test_single_origin_sets_native_absolute_deadline_and_fixed_nonce_roster(self):
        deadline, commands = probe.planned_commands(self.contract, Path("/unused"), 123456, "fixed-boot")
        self.assertEqual(deadline, 4000123456)
        native = commands["native-winner"]
        self.assertEqual(native[-3:], [str(deadline), "fixed-boot", "10000"])
        self.assertEqual(native[1:4], [probe.PINNED_INPUTS[k]["path"]
                                      for k in ("material", "expected_artifacts", "header_template")])
        postwin = commands["postwin-proof"]
        self.assertEqual(postwin[-10:], ["--segment-workers", "1", "--compression-mode", "sequential",
                                        "--compression-workers", "1", "--rayon-threads", "1",
                                        "--comparison-repeats", "0"])
        self.assertNotIn("--total-wall-seconds", postwin)

    def test_planned_rows_cannot_be_removed_or_duplicated(self):
        for rows in (self.rows[:1], self.rows + self.rows[:1]):
            with self.assertRaises(ValueError):
                probe.decide(rows, 1, 10, None, True, True, None)

    def test_exact_deadline_and_late_endpoint_never_promote_claimed_success(self):
        for endpoint in (10, 11, None):
            self.assertEqual(probe.decide(self.rows, endpoint, 10, None, True, True, None),
                             "DEADLINE_EXHAUSTED")

    def test_unlaunched_row_with_claimed_completion_cannot_pass(self):
        self.rows[1]["dispatched"] = False
        self.assertEqual(probe.decide(self.rows, 1, 10, None, True, True, None), "INCOMPLETE")

    def test_actual_cancel_veto_and_deadline_priority_preserve_separate_input(self):
        self.assertEqual(probe.decide(self.rows, 1, 10, 15, True, True, None), "CANCELED")
        self.assertEqual(probe.decide(self.rows, 10, 10, 15, True, True, None), "DEADLINE_EXHAUSTED")
        with self.assertRaises(ValueError):
            probe.decide(self.rows, 1, 10, True, True, True, None)

    def test_resource_unknown_error_and_failed_audit_cannot_pass(self):
        self.assertEqual(probe.decide(self.rows, 1, 10, None, False, True, None), "UNKNOWN_RESOURCE_CLOSURE")
        self.assertEqual(probe.decide(self.rows, 1, 10, None, True, False, None), "FAILED")
        self.assertEqual(probe.decide(self.rows, 1, 10, None, True, True, OSError("fixture")), "FAILED")

    def test_actual_quota_memory_and_affinity_must_match_not_merely_thread_count(self):
        observed = {"cpu_max": "25000 100000", "memory_max": str(2 * 1024**3)}
        probe.enforce_resources(observed, [8, 9, 10, 11])
        for changed in ({**observed, "cpu_max": "250000 100000"},
                        {**observed, "cpu_max": "max 100000"},
                        {**observed, "memory_max": str(4 * 1024**3)}):
            with self.assertRaises(ValueError):
                probe.enforce_resources(changed, [8, 9, 10, 11])
        with self.assertRaises(ValueError):
            probe.enforce_resources(observed, [0, 1, 2, 3])

    def test_declared_cleanup_cannot_extend_four_seconds(self):
        changed = copy.deepcopy(self.contract)
        changed["budget"]["wall_ns"] += 30_000_000_000
        with self.assertRaises(ValueError):
            probe.validate_contract(changed, self.script)
        self.assertEqual(self.contract["cleanup"]["outer_term_grace_seconds"], 30)
        self.assertEqual(self.contract["cleanup"]["postwin_controller_term_grace_seconds"], 12)
        self.assertEqual(self.contract["cleanup"]["inner_stage_term_grace_seconds"], 5)
        self.assertFalse(self.contract["cleanup"]["eligibility_extended"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
