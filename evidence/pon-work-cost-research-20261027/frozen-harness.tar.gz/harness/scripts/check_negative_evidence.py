#!/usr/bin/env python3
"""Replay correct-C false traces independently; no Node availability verdict."""
from pathlib import Path
import argparse, hashlib, json
from check_cost_evidence import CASES, RECORD_BYTES, SOURCE, TARGET, material, require, read_bounded
from independent_check import H,w,header_decode

def check(directory):
    raw=read_bounded(directory/'raw.json',1024*1024);data=json.loads(raw)
    require(data['schema']=='trnm-w1-correct-product-false-trace-cost-v1','SCHEMA')
    require(data['source_commit']==SOURCE and data['target_bits']==4,'CONTEXT')
    require(data['independent_security_puzzle']is False and data['succinct_proof']is False,'NO_EXTRA_PUZZLE')
    require(data['global_minimum_attack_cost_proved']is False,'NO_HARDNESS_CLAIM')
    products={};setup={};seen=set()
    for case in data['cases']:
        require(case in CASES,'CASE');a,b=material(case)
        products[case]=(w.task_id(a,b),w.field_bytes(a)+w.field_bytes(b)+w.field_bytes(w.mm(a,b,w.N,w.N,w.N)))
    for row in data['rows']:
        case,sample=row['case'],row['sample'];key=(case,sample)
        require(case in products and type(sample)is int and 0<=sample<data['samples'] and key not in seen,'ROW_ID');seen.add(key)
        require(row['node_entry_executed']is False and row['full_verifier_result']=='Transcript','SCOPE')
        require(row['path']==f'correct-product-{case}-{sample}.bin','PATH')
        blob=read_bounded(directory/row['path'],RECORD_BYTES)
        require(len(blob)==row['bytes']==RECORD_BYTES and hashlib.sha256(blob).hexdigest()==row['sha256'],'BYTES')
        header,proof=blob[:318],blob[318:];h=header_decode(header);challenge=H('challenge',header)
        task,matrices=products[case]
        require(h['work_task']==task and h['target']==TARGET and h['nonce']==sample+1,'HEADER')
        require(proof[4:-32]==matrices,'ACTUAL_CORRECT_PRODUCT')
        w.precheck(challenge,task,TARGET,proof)
        try:w.verify(challenge,task,TARGET,proof)
        except ValueError as error:require(str(error)=='TRANSCRIPT','WRONG_REFUSAL')
        else:raise ValueError('FALSE_TRACE_ACCEPTED')
        require(type(row['hash_trials'])is int and 0<row['hash_trials']<=65536,'TRIAL_BOUND')
        for index in range(row['hash_trials']):
            trace=H('p0-false-trace-correct-product-v1',sample.to_bytes(8,'little'),index.to_bytes(8,'little'))
            hit=H('ticket',challenge,trace)<=TARGET
            require(hit==(index==row['hash_trials']-1),'OMITTED_FALSE_TRACE_TRIAL')
        require(trace==proof[-32:],'FORGERY_TRACE')
        for field in ['public_product_setup_wall_ns','public_product_setup_cpu_ns','forge_wall_ns','forge_cpu_ns','precheck_wall_ns','precheck_cpu_ns','full_reject_wall_ns','full_reject_cpu_ns']:
            require(type(row[field])is int and row[field]>0,'COST_FIELD')
        values=(row['public_product_setup_wall_ns'],row['public_product_setup_cpu_ns'])
        if case in setup:require(setup[case]==values,'SETUP_CHANGED')
        else:setup[case]=values
    require(len(seen)==len(data['cases'])*data['samples'],'MISSING_ROWS')
    return dict(result='PASS',schema='trnm-correct-product-false-trace-readback-v1',raw_sha256=hashlib.sha256(raw).hexdigest(),
                independent_correct_products=len(products),independent_full_transcript_rejections=len(seen),
                all_hash_trials_reconstructed=True,node_entry_executed=False,network_DoS_qualified=False,succinct_proof=False)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('directory',type=Path);args=p.parse_args()
    print(json.dumps(check(args.directory),indent=2))
