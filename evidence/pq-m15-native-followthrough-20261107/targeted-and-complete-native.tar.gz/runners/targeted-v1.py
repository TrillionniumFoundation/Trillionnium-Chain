#!/usr/bin/env python3
"""Create-only fixed-source M15 regression phases; never retry or edit old inputs."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import gzip
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys

COMMIT = "1c14fab4cca9c2ad1a48c502f51eb89edeb7df50"
TREE = "cd446a4dc02d94f446134e9fd441bab04a672a2c"
OLD = "840522d0b65b4989f1a2a1d09c0ad51af1a1956d"
OLD_TREE = "70377cc0a9c8d029907f6c49bbb8dee1435a6cd1"
WORK = Path("/home/alex/work")
ORIGINAL = WORK / "chain-parent-m15-final-native-df896925-20261106"
SOURCE = WORK / "chain-m15-regression-1c14fab4-13c7"
TARGET = WORK / "chain-native-tls-df896925-20261105-target"
OUTPUT = WORK / "chain-m15-regression-1c14fab4-13c7-evidence"
BUNDLE = WORK / "chain-m15-1c14fab4-from840-13c7.bundle"
BUNDLE_SHA = "b31cc54b7aab549baddcee59ffef037c70c009a306aa66d93b1d982388ffda96"
PROVIDER = WORK / "chain-zeroize191-df896925-20261105-evidence/dependency-preparation"
PROVIDER_SHA = "a17992ff9c4874b101c4cd99e0e62f24ae3055dd9c810db1ce450f36240d5543"
PROVIDER_ENV_SHA = "5861a85eeb05a0d0beb23b96485e0b4aaf4df2d5211f3cd577c8779517fe3760"
OLD_EVIDENCE = Path(str(ORIGINAL) + "-evidence")
BATCH = OLD_EVIDENCE / "21-original-final240-gates-v2"
READER = WORK / "chain-f85-final-gate-df896925-20261106-evidence/01-final-gates-preparation-v1/chain_native_complete_readback.py"
READER_SHA = "618a943e1f940049c9e4bf7c40f756c7aeac83fea2c3bd7d769adf3b29e19092"
FRESH = OLD_EVIDENCE / "native-840522-final-registry-v1-registry-only/fresh-final-registry-binding.json"
FRESH_SHA = "053e0d8a18d935f000320219970fcc3a8b24b57ebe4b51a702fc98e9a35c11cc"
ROOT_CASES = [
    "canonical_role_keys_replay_at_every_tagged_proof_boundary",
    "root_role_keys_refuse_aliases_unknown_codes_and_duplicates_in_tagged_proofs",
    "role_decoding_preserves_complete_root_and_canonical_record_requirements",
    "all_three_service_keys_are_excluded_from_offline_root_and_every_online_role",
    "valid_dual_quorum_successor_cannot_reuse_an_independent_service_key",
    "expired_old_root_keeps_dual_quorum_recovery_and_cold_proof_replay",
    "expired_root_recovery_requires_both_real_quorums_and_a_fresh_successor",
]
SEALED_CASES = [
    "sealed_copy_survives_in_place_source_rewrite_and_path_replacement",
    "denied_mutations_preserve_sealed_bytes_without_claiming_unchanged_metadata",
    "metadata_only_changes_refuse_read_copy_descriptor_and_exec_handoff",
    "source_rewrite_or_path_exchange_during_sealing_refuses_authentication",
    "inherited_fifo_without_writer_is_refused_before_any_blocking_open",
    "unsealed_regular_input_and_a_different_sealed_descriptor_are_rejected",
    "native_elf_profile_rejects_interpreter_dependencies_search_paths_and_wrong_machine",
]
CASES = ["release_owner::root_separation_tests::" + n for n in ROOT_CASES]
CASES += ["release_owner::sealed_tests::" + n for n in SEALED_CASES]
NEW_CASES = set(CASES[:3] + ["release_owner::sealed_tests::" + n for n in SEALED_CASES[1:3]])
CARGO = ["cargo", "+1.95.0"]
BASE = ["--locked", "--manifest-path", "trillionnium/Cargo.toml"]
NODE = CARGO + ["test"] + BASE + ["-p", "trnm-pon-node", "--lib", "--all-features"]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def file_identity(path):
    path = Path(path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), "not a regular file: " + str(path))
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC), "rb") as stream:
        opened = os.fstat(stream.fileno())
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
        after_fd = os.fstat(stream.fileno())
    fields = lambda v: (v.st_dev, v.st_ino, v.st_mode, v.st_nlink, v.st_size, v.st_mtime_ns, v.st_ctime_ns)
    require(fields(before) == fields(opened) == fields(after_fd) == fields(path.lstat()), "file changed: " + str(path))
    return dict(path=str(path), bytes=before.st_size, sha256=digest, device=before.st_dev,
                inode=before.st_ino, nlink=before.st_nlink, mode=oct(stat.S_IMODE(before.st_mode)),
                mtime_ns=before.st_mtime_ns, ctime_ns=before.st_ctime_ns)


def write_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def git(root, *argv):
    return subprocess.check_output(["git", "--no-replace-objects", *argv], cwd=root, text=True).strip()


def check_old_inputs():
    checks = [(BUNDLE, BUNDLE_SHA), (READER, READER_SHA), (FRESH, FRESH_SHA),
              (BATCH / "original-native-batch2/result.json", "bea10f7899779d1d4cb2278050fb96f80d1ddf1d4cc40998c54d009dc045cefb"),
              (BATCH / "union-complete/node-complete.log", "66d40f5ffb12eae2530df53a8065020dd0ddab3927e8595bd73b8d5438eef85f"),
              (WORK / "chain-npq6-provider-bound-13c7/node-npq6", "4816721ef2ea829f904b6622443e14937fbd679df3ea777b99065f37c492b86f"),
              (WORK / "chain-npq6-provider-bound-13c7/node-feature-off", "1e2a7b806318470cc37d389d6eb8ec41311aab43cdee2f17535aeaed6704aa68")]
    batch = json.loads((BATCH / "original-native-batch2/result.json").read_text())
    require(batch["exit_code"] == 1 and batch["elfs_unchanged"] is True, "old failure/binding missing")
    checks += [(Path(row["retained_path"]), row["sha256"]) for row in batch["retained_after"]]
    identities = []
    for path, expected in checks:
        identity = file_identity(path)
        require(identity["sha256"] == expected, "old input changed: " + str(path))
        identities.append(identity)
    return identities


def prepared_environment():
    env = os.environ.copy()
    for key, value in env.items():
        forbidden = key in ("RUSTC", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "RUSTFLAGS",
                            "CARGO_ENCODED_RUSTFLAGS", "RUSTDOCFLAGS", "CARGO_ENCODED_RUSTDOCFLAGS")
        forbidden |= key.startswith("CARGO_PROFILE_") or (key.startswith("CARGO_TARGET_") and key.endswith("_RUSTFLAGS"))
        require(not (forbidden and value), "unexpected compiler override: " + key)
    require(sha(PROVIDER / "pq-provider/provider.json") == PROVIDER_SHA, "provider receipt changed")
    require(sha(PROVIDER / "provider-env") == PROVIDER_ENV_SHA, "provider env changed")
    provider = json.loads((PROVIDER / "pq-provider/provider.json").read_text())
    require(provider["result"] == "PREPARED_AND_SMOKE_VERIFIED" and provider["version"] == "3.5.9", "provider refused")
    require(sha(SOURCE / "scripts/ci/prepare_pq_provider.sh") == provider["preparation_script_sha256"], "provider script differs")
    allowed = {"OPENSSL_DIR", "OPENSSL_STATIC", "TRNM_PQ_OPENSSL", "TRNM_PQ_OPENSSL_SHA256",
               "TRNM_PQ_OPENSSL_VERSION", "OPENSSL_CONF", "OPENSSL_MODULES"}
    values = {}
    for line in (PROVIDER / "provider-env").read_text().splitlines():
        key, value = line.split("=", 1)
        require(key in allowed and key not in values, "unexpected/duplicate provider environment")
        values[key] = value
    require(set(values) == allowed, "incomplete provider environment")
    inputs = []
    for item in provider["native_backend_inputs"]:
        actual = file_identity(item["path"])
        require(actual["sha256"] == item["sha256"] and actual["bytes"] == item["bytes"], "native backend changed")
        inputs.append(actual)
    env.update(values)
    env.update(PATH="/home/alex/.cargo/bin:" + env.get("PATH", ""), CARGO_TARGET_DIR=str(TARGET),
               CARGO_BUILD_JOBS="2", CARGO_INCREMENTAL="0", RUST_TEST_THREADS="1",
               PYTHONDONTWRITEBYTECODE="1", GIT_TERMINAL_PROMPT="0")
    return env, inputs


def clone_source():
    require(not SOURCE.exists(), "create-only source already exists")
    require(git(ORIGINAL, "rev-parse", "HEAD") == OLD and git(ORIGINAL, "rev-parse", "HEAD^{tree}") == OLD_TREE, "old source differs")
    subprocess.run(["git", "bundle", "verify", str(BUNDLE)], cwd=ORIGINAL, check=True)
    subprocess.run(["git", "clone", "--no-hardlinks", "--no-checkout", str(ORIGINAL), str(SOURCE)], check=True)
    subprocess.run(["git", "fetch", str(BUNDLE), "HEAD"], cwd=SOURCE, check=True)
    subprocess.run(["git", "checkout", "-b", "fix/chain-m15-regression-20261107-13c7", COMMIT], cwd=SOURCE, check=True)
    subprocess.run(["git", "remote", "set-url", "origin", "https://github.com/TrillionniumFoundation/Trillionnium-Chain.git"], cwd=SOURCE, check=True)
    require(not (SOURCE / ".git/objects/info/alternates").exists(), "clone retains shared object dependency")
    require(git(SOURCE, "rev-parse", "HEAD^{tree}") == TREE, "new source tree differs")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("targeted", "complete"), required=True)
    args = parser.parse_args()
    phase = OUTPUT / args.phase
    if args.phase == "targeted":
        OUTPUT.mkdir(mode=0o700, exist_ok=False)
    phase.mkdir(mode=0o700, exist_ok=False)
    manifest = dict(schema="chain-m15-regression-native-v1", phase=args.phase, commit=COMMIT, tree=TREE,
                    started_utc=datetime.now(timezone.utc).isoformat(), result="RUNNING", commands=[],
                    runner_sha256=sha(__file__), original_outer_timeout_seconds=14400,
                    phase_outer_timeout_seconds=14400 if args.phase == "targeted" else 1500,
                    full_phase_1500_limit_is_new_stricter_constraint=args.phase == "complete",
                    per_command_timeout_added=False, automatic_retry_added=False,
                    whole_chain_quantum_security_qualified=False, production_activation=False)
    def save():
        (phase / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    save()
    verifier = env = None
    code = 1
    try:
        require(subprocess.run(["pgrep", "-x", "cargo|cargo-clippy|cargo-nextest|rustc|clippy-driver"], stdout=subprocess.DEVNULL).returncode == 1, "another Rust job is active")
        manifest["old_inputs_before"] = check_old_inputs()
        if args.phase == "targeted":
            compressed = OUTPUT / "original-node-complete.log.gz"
            with (BATCH / "union-complete/node-complete.log").open("rb") as src, compressed.open("xb") as dst:
                with gzip.GzipFile(filename="", fileobj=dst, mode="wb", mtime=0) as archive:
                    shutil.copyfileobj(src, archive, 1024 * 1024)
            with gzip.open(compressed, "rb") as stream:
                require(hashlib.file_digest(stream, "sha256").hexdigest() == "66d40f5ffb12eae2530df53a8065020dd0ddab3927e8595bd73b8d5438eef85f", "compressed original failure differs")
            manifest["original_failure_gzip"] = file_identity(compressed)
            clone_source()
        spec = importlib.util.spec_from_file_location("verify_ci_source", SOURCE / "scripts/ci/verify_ci_source.py")
        verifier = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(verifier)
        manifest["source_before"] = verifier.verify("head", COMMIT, root=SOURCE)
        manifest["original_source_before"] = verifier.verify("head", OLD, root=ORIGINAL)
        require(manifest["source_before"]["tested_tree"] == TREE, "wrong checkout tree")
        env, manifest["provider_inputs_before"] = prepared_environment()
        manifest["environment"] = {k: env.get(k) for k in ("PATH", "CARGO_HOME", "CARGO_TARGET_DIR", "CARGO_BUILD_JOBS", "CARGO_INCREMENTAL", "RUST_TEST_THREADS", "OPENSSL_DIR", "OPENSSL_STATIC", "TRNM_PQ_OPENSSL", "TRNM_PQ_OPENSSL_SHA256", "TRNM_PQ_OPENSSL_VERSION", "OPENSSL_CONF", "OPENSSL_MODULES")}
        save()
        def run(label, command):
            argv = ["python3", "scripts/ci/record_pq_native_command.py", "--kind", "head", "--candidate", COMMIT,
                    "--tested", COMMIT, "--label", label, "--output", str(phase), "--"] + command
            print(json.dumps(dict(event="start", label=label, argv=command)), flush=True)
            status = subprocess.run(argv, cwd=SOURCE, env=env, check=False).returncode
            manifest["commands"].append(dict(label=label, exit_code=status))
            save()
            require(status == 0, "command failed: " + label + " exit " + str(status))
            return (phase / (label + ".log")).read_text()
        run("preflight", ["bash", "scripts/project-preflight.sh"])
        if args.phase == "targeted":
            version = run("rustc", ["rustc", "+1.95.0", "-Vv"])
            require(version.startswith("rustc 1.95.0 "), "unexpected Rust compiler version")
            run("cargo", CARGO + ["-Vv"])
            run("strict-clippy", CARGO + ["clippy"] + BASE + ["-p", "trnm-pon-node", "--lib", "--tests", "--all-features", "--", "-D", "warnings"])
            build = run("node-build", NODE + ["--no-run", "--message-format=json"])
            artifacts = []
            for line in build.splitlines():
                if not line.startswith("{"):
                    continue
                row = json.loads(line)
                if row.get("reason") == "compiler-artifact" and row.get("executable") and row["target"]["name"] == "trnm_pon_node":
                    artifacts.append(row)
            require(len(artifacts) == 1, "expected one actual Node libtest artifact")
            artifact = artifacts[0]
            require(artifact["target"]["kind"] == ["lib"] and artifact["target"]["src_path"] == str(SOURCE / "trillionnium/crates/trnm-pon-node/src/lib.rs"), "not the Node library harness")
            require(artifact["profile"]["test"] is True and artifact["profile"]["opt_level"] == "3", "unexpected test compilation profile")
            require(set(artifact["features"]) == {"default", "pq-native-openssl"}, "unexpected features")
            original = Path(artifact["executable"])
            before = file_identity(original)
            retained = phase / "node-libtest"
            with original.open("rb") as src, retained.open("xb") as dst:
                shutil.copyfileobj(src, dst, 1024 * 1024)
                dst.flush()
                os.fsync(dst.fileno())
            retained.chmod(0o555)
            after = file_identity(original)
            copy = file_identity(retained)
            require(before == after and before["sha256"] == copy["sha256"] and copy["nlink"] == 1 and before["inode"] != copy["inode"], "retained harness identity differs")
            binding = dict(artifact=artifact, original=before, retained=copy)
            write_json(phase / "node-artifact-binding.json", binding)
        else:
            previous = json.loads((OUTPUT / "targeted/manifest.json").read_text())
            require(previous["result"] == "PASS" and previous["commit"] == COMMIT and previous["tree"] == TREE, "targeted phase did not pass")
            binding = json.loads((OUTPUT / "targeted/node-artifact-binding.json").read_text())
        manifest["artifact_binding"] = binding
        require(file_identity(binding["original"]["path"]) == binding["original"], "compiled harness changed")
        require(file_identity(binding["retained"]["path"]) == binding["retained"], "retained harness changed")
        registry = run("node-registry", NODE + ["--", "--list"])
        names = re.findall(r"^([A-Za-z_][A-Za-z0-9_:]*): test$", registry, re.M)
        require(len(names) == len(set(names)) and names, "ambiguous native registry")
        original_registry = json.loads(FRESH.read_text())
        require(set(names) == set(original_registry["node_names"]) | NEW_CASES, "actual registry differs from original plus five reviewed controls")
        require(re.findall(r"^(\d+) tests?, (\d+) benchmarks?$", registry, re.M) == [(str(len(names)), "0")], "registry aggregate differs")
        selected = {n for n in names if n.startswith(("release_owner::root_separation_tests::", "release_owner::sealed_tests::"))}
        require(selected == set(CASES) and len(selected) == 14, "M15 registry differs from the exact fourteen controls")
        write_json(phase / "registry-binding.json", dict(actual_names=names, actual_count=len(names), selected=sorted(selected), original_registry_sha256=FRESH_SHA, reviewed_added_names=sorted(NEW_CASES)))
        if args.phase == "targeted":
            for index, name in enumerate(CASES):
                label = "m15-" + format(index, "02d")
                run(label, [binding["retained"]["path"], name, "--exact", "--show-output", "--test-threads=1"])
                run(label + "-execution", ["python3", "scripts/ci/check_required_native_test.py", str(phase / (label + ".log")), "--test", name])
        else:
            run("node-complete", NODE + ["--", "--show-output", "--test-threads=1"])
            run("node-complete-readback", ["python3", str(READER), "--directory", str(phase), "--commit", COMMIT, "--tree", TREE, "--expected-count", str(len(names))])
        require(file_identity(binding["original"]["path"]) == binding["original"], "compiled harness changed during native execution")
        require(file_identity(binding["retained"]["path"]) == binding["retained"], "retained harness changed during native execution")
        manifest["actual_registry_count"] = len(names)
        manifest["exact_required_tests"] = CASES
        code = 0
    except Exception as error:
        manifest["error"] = str(error)
        print(json.dumps(dict(event="failed", error=str(error))), flush=True)
    finally:
        try:
            manifest["old_inputs_after"] = check_old_inputs()
            require(manifest["old_inputs_before"] == manifest["old_inputs_after"], "old inputs changed")
            if verifier is not None:
                manifest["source_after"] = verifier.verify("head", COMMIT, root=SOURCE)
                manifest["original_source_after"] = verifier.verify("head", OLD, root=ORIGINAL)
                require(manifest["source_before"] == manifest["source_after"] and manifest["original_source_before"] == manifest["original_source_after"], "source identity changed")
            if env is not None:
                _, manifest["provider_inputs_after"] = prepared_environment()
                require(manifest["provider_inputs_before"] == manifest["provider_inputs_after"], "provider input changed")
        except Exception as error:
            code = 1
            manifest["final_identity_error"] = str(error)
        manifest.update(result="PASS" if code == 0 else "FAIL", exit_code=code, finished_utc=datetime.now(timezone.utc).isoformat())
        save()
    print(json.dumps(dict(result=manifest["result"], phase=args.phase, output=str(phase))), flush=True)
    return code


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    raise SystemExit(main())
