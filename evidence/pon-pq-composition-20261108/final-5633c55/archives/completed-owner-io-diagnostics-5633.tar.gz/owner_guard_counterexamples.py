#!/usr/bin/env python3
"""Exact-source, default-feature native counterexamples for the two #799 guards.

This is an additional focused experiment, not a replacement for the inherited
32/45-command campaign. It never edits the supplied repository, never pushes,
never retries a test, and never promotes whole-chain or release qualification.
It checks out the named local Git object into one new isolated worktree, proves all
four controls green, then removes exactly one first-statement guard at a time.
Each red result must be the corresponding directory-snapshot assertion failure,
not a build error, absent test, changed error string, panic elsewhere, or timeout.
The removed source bytes are restored even if a command fails. All logs remain.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time


SCHEMA = "trnm-pq-owner-guard-counterexamples-v1"
PREFIX = "store::pq_owner_rejection_tests::"
TASK = "pq_account_rejects_classical_task_owner_before_any_durable_effect"
MINING = "pq_account_rejects_classical_mining_owner_before_any_durable_effect"
TESTS = (
    TASK,
    MINING,
    "classical_task_owner_with_signed_catalog_still_opens",
    "classical_mining_owner_with_signed_catalog_still_opens",
)
TEST_SOURCE = "trillionnium/crates/trnm-pon-node/src/store/pq_owner_rejection_tests.rs"
GUARD = (
    '        ensure(\n'
    '            !settings.app.is_pq_account_profile(),\n'
    '            "PQ_ACCOUNT_REQUIRES_PQ_NETWORK_OWNER",\n'
    '        )?;\n'
)
MUTATIONS = (
    ("task", TASK, "trillionnium/crates/trnm-pon-node/src/store.rs", (
        "    pub fn open_with_operator_task_policy(\n"
        "        path: &Path,\n"
        "        settings: Settings,\n"
        "        workers: usize,\n"
        "        inputs: crate::operator_task_policy::RestrictedNodeInputs,\n"
        "    ) -> Result<Self> {\n"
    )),
    ("mining", MINING, "trillionnium/crates/trnm-pon-node/src/store/operator_mining_owner.rs", (
        "    pub fn open_with_operator_mining_task_view(\n"
        "        path: &Path,\n"
        "        settings: Settings,\n"
        "        workers: usize,\n"
        "        inputs: policy::Inputs,\n"
        "        cpu: &ServiceMutationCpuDomain,\n"
        "    ) -> Result<Self> {\n"
    )),
)
CANONICAL_ORIGINS = {
    "https://github.com/TrillionniumFoundation/Trillionnium-Chain",
    "https://github.com/TrillionniumFoundation/Trillionnium-Chain.git",
    "git@github.com:TrillionniumFoundation/Trillionnium-Chain.git",
}
NAMES = re.compile(r"^test (\S+) \.\.\. (ok|FAILED|ignored.*)$", re.M)
SUMMARY = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
    r"(\d+) ignored; (\d+) measured; (\d+) filtered out; finished in .+$", re.M
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def save(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def file_record(path: Path) -> dict:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def snapshot_assertion_line(source: str, name: str) -> int:
    function = re.search(r"(?m)^fn " + re.escape(name) + r"\(\) \{", source)
    require(function is not None, "missing exact control function: " + name)
    following = re.search(r"(?m)^fn ", source[function.end():])
    end = function.end() + following.start() if following else len(source)
    assertion = "assert_eq!(snapshot(fixture.root.path()), before);"
    body = source[function.start():end]
    require(body.count(assertion) == 1, "not one exact directory assertion in " + name)
    offset = function.start() + body.index(assertion)
    return source.count("\n", 0, offset) + 1


def readback(stdout: str, stderr: str, rc: int, name: str,
             assertion_line: int | None = None) -> dict:
    expected = PREFIX + name
    red = assertion_line is not None
    outcome = "FAILED" if red else "ok"
    require(re.findall(r"^running (\d+) tests?$", stdout, re.M) == ["1"],
            "test did not execute exactly once")
    require(NAMES.findall(stdout) == [(expected, outcome)],
            "wrong test name, outcome, duplicate, or ignored test")
    summaries = SUMMARY.findall(stdout)
    require(len(summaries) == 1, "missing or multiple libtest summaries")
    require(summaries[0][:5] == (outcome, "0" if red else "1",
                                "1" if red else "0", "0", "0"),
            "unexpected pass/fail/ignore/measure counts")
    require(rc == (101 if red else 0), "unexpected native command exit code")
    if red:
        combined = stdout + "\n" + stderr
        location = (r"panicked at [^\n]*src/store/pq_owner_rejection_tests\.rs:"
                    + str(assertion_line) + r":\d+:")
        require(re.search(location, combined) is not None,
                "red result was not the exact directory-snapshot assertion")
        require("assertion `left == right` failed" in combined,
                "red result was not equality mismatch")
        require("owner-task-policy.required" in combined,
                "red snapshot did not record the required-owner marker")
        if name == MINING:
            require("claim-" in combined, "red mining snapshot did not record a reservation")
    return {"test": expected, "executed_tests": 1, "outcome": outcome,
            "snapshot_assertion_line": assertion_line,
            "scope": "named-native-owner-guard-control-only"}


class Campaign:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.repo = args.repo.resolve(strict=True)
        self.out = args.out.resolve()
        require(not self.out.exists(), "output already exists; preserve it and choose a new path")
        require(not self.out.is_relative_to(self.repo), "output must be outside the source repository")
        self.out.mkdir(mode=0o700)
        self.work = self.out / "isolated-source"
        self.target = self.out / "native-target"
        self.cargo = args.cargo.resolve(strict=True)
        self.rustc = args.rustc.resolve(strict=True)
        self.cargo_home = args.cargo_home.resolve(strict=True)
        require(self.cargo_home.is_dir(), "Cargo cache is not a directory")
        self.git = Path(shutil.which("git") or "").resolve(strict=True)
        self.python = Path(sys.executable).resolve(strict=True)
        # No inherited wrappers, injected Rust flags, Cargo features, credentials,
        # Git replacement/configuration, or network dependency resolution.
        self.env = {key: os.environ[key] for key in ("HOME", "USER", "LOGNAME", "TMPDIR")
                    if key in os.environ}
        self.env.update({
            "PATH": str(self.cargo.parent) + ":/usr/bin:/bin",
            "LANG": "C", "LC_ALL": "C", "TZ": "UTC",
            "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_SYSTEM": os.devnull,
            "GIT_CONFIG_GLOBAL": os.devnull, "GIT_ATTR_NOSYSTEM": "1",
            "GIT_NO_REPLACE_OBJECTS": "1", "GIT_TERMINAL_PROMPT": "0",
            "GIT_OPTIONAL_LOCKS": "0",
            "PYTHONDONTWRITEBYTECODE": "1", "CARGO_TERM_COLOR": "never",
            "CARGO_HOME": str(self.cargo_home), "CARGO_TARGET_DIR": str(self.target),
            "CARGO_NET_OFFLINE": "true", "CARGO_BUILD_JOBS": str(args.jobs),
            "RUSTC": str(self.rustc), "RUSTDOC": str(self.rustc.with_name("rustdoc")),
            "RUST_BACKTRACE": "0", "RUST_TEST_THREADS": "1",
        })
        self.records: list[dict] = []
        self.manifest = {
            "schema": SCHEMA, "source_repository": str(self.repo),
            "runner": file_record(Path(__file__).resolve()),
            "expected_head": args.expected_head, "scope": "focused-additional-experiment",
            "inherited_campaign_replaced": False, "features": "default (empty)",
            "original_repository_modified": False, "native_tests_retried": False,
            "whole_chain_pq_qualified": False, "production_activation": False,
            "tool_binaries": [file_record(path) for path in
                              (self.python, self.git, self.cargo, self.rustc)],
            "cargo_home": str(self.cargo_home), "target": str(self.target),
            "cargo_home_configuration": [file_record(path) for path in
                                         (self.cargo_home / "config", self.cargo_home / "config.toml")
                                         if path.is_file()],
            "commands": self.records,
        }

    def git_read(self, root: Path, *args: str) -> str:
        return subprocess.check_output([str(self.git), "--no-replace-objects", "-C", str(root),
                                        *args], env=self.env, text=True,
                                       stderr=subprocess.PIPE).strip()

    def command(self, label: str, argv: list[str], cwd: Path,
                allowed: tuple[int, ...] = (0,)) -> tuple[dict, str, str]:
        started = time.monotonic()
        receipt = {"label": label, "argv": argv, "cwd": str(cwd),
                   "started_unix_seconds": time.time(), "attempts": 1,
                   "timed_out": False, "exit_code": None}
        print(json.dumps({"starting": label, "argv": argv}), flush=True)
        stdout = self.out / (label + ".stdout.log")
        stderr = self.out / (label + ".stderr.log")
        with stdout.open("xb") as out, stderr.open("xb") as err:
            child = subprocess.Popen(argv, cwd=cwd, env=self.env, stdout=out, stderr=err,
                                     start_new_session=True)
            limit = started + self.args.timeout_seconds
            while True:
                try:
                    child.wait(timeout=max(0.01, min(30, limit - time.monotonic())))
                    break
                except subprocess.TimeoutExpired:
                    if time.monotonic() < limit:
                        print(json.dumps({"running": label,
                                          "elapsed_seconds": time.monotonic() - started}),
                              flush=True)
                        continue
                    receipt["timed_out"] = True
                    os.killpg(child.pid, signal.SIGTERM)
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait(timeout=5)
                    break
            receipt["exit_code"] = child.returncode
        receipt["elapsed_seconds"] = time.monotonic() - started
        receipt["logs"] = [file_record(stdout), file_record(stderr)]
        self.records.append(receipt)
        save(self.out / (label + ".receipt.json"), receipt)
        print(json.dumps({"finished": label, "exit_code": child.returncode,
                          "timed_out": receipt["timed_out"]}), flush=True)
        require(not receipt["timed_out"], label + " timed out; no retry")
        require(child.returncode in allowed, label + " failed; no retry")
        return receipt, stdout.read_text(errors="replace"), stderr.read_text(errors="replace")

    def preflight(self, root: Path, label: str) -> None:
        self.command(label, ["/bin/bash", "scripts/project-preflight.sh"], root)

    def source_guard(self, root: Path, label: str) -> None:
        self.command(label, [str(self.python), "-B", "scripts/ci/verify_ci_source.py",
                            "--kind", "head", "--expected-head", self.args.expected_head,
                            "--output", str(self.out / (label + ".source.json"))], root)

    def native(self, label: str, name: str, line: int | None = None) -> None:
        command = [str(self.cargo), "test", "--locked", "--offline", "--manifest-path",
                   "trillionnium/Cargo.toml", "-p", "trnm-pon-node", "--lib", PREFIX + name,
                   "--", "--exact", "--show-output", "--test-threads=1"]
        receipt, stdout, stderr = self.command(label, command, self.work, (0, 101))
        result = readback(stdout, stderr, receipt["exit_code"], name, line)
        harnesses = re.findall(r"Running unittests [^\n]+ \(([^\n]+)\)", stderr)
        require(len(harnesses) == 1, "missing unique executed native harness")
        harness = Path(harnesses[0]).resolve(strict=True)
        require(harness.is_relative_to(self.target)
                and harness.name.startswith("trnm_pon_node-"), "unexpected native harness")
        result["harness"] = file_record(harness)
        save(self.out / (label + ".readback.json"), result)

    def run(self) -> None:
        require(sys.platform.startswith("linux"), "the owner tests require Linux")
        require(self.git_read(self.repo, "rev-parse", "HEAD") == self.args.expected_head,
                "source HEAD differs from the explicit expected commit")
        origin = self.git_read(self.repo, "remote", "get-url", "origin")
        require(origin in CANONICAL_ORIGINS, "source repository origin is not the canonical Chain")
        self.preflight(self.repo, "source-preflight")
        self.source_guard(self.repo, "source-before")
        self.manifest["source_tree"] = self.git_read(self.repo, "rev-parse", "HEAD^{tree}")
        _, cargo, _ = self.command("cargo-version", [str(self.cargo), "-V"], self.repo)
        _, rustc, _ = self.command("rustc-version", [str(self.rustc), "-Vv"], self.repo)
        require(cargo.startswith("cargo 1.95.0 ") and rustc.startswith("rustc 1.95.0 "),
                "this focused campaign requires the reviewed Rust 1.95.0 toolchain")
        # Fresh .git metadata only; the supplied repository is read-only.
        self.command("isolated-init", [str(self.git), "init", "--quiet", "--object-format=sha1",
                                      "--template=", str(self.work)], self.out)
        # Share immutable Git objects through a fresh local .git without changing
        # the source .git or duplicating its historical packs. Checkout writes
        # independent ordinary files, never hardlinks to the baseline source.
        # Copy an actual shallow boundary verbatim; do not invent missing history.
        objects = self.git_read(self.repo, "rev-parse", "--path-format=absolute",
                                "--git-path", "objects")
        object_path = Path(objects)
        require(object_path.is_absolute() and object_path.is_dir()
                and "\n" not in objects and "\r" not in objects,
                "invalid local source object directory")
        alternate = self.work / ".git/objects/info/alternates"
        with alternate.open("x") as stream:
            stream.write(objects + "\n")
        shared = {"object_directory": objects, "source_objects_modified": False,
                  "baseline_files_hardlinked": False,
                  "alternate": file_record(alternate)}
        shallow = Path(self.git_read(self.repo, "rev-parse", "--path-format=absolute",
                                     "--git-path", "shallow"))
        if shallow.exists():
            boundary = shallow.read_bytes()
            require(all(re.fullmatch(rb"[0-9a-f]{40}", line) is not None
                        for line in boundary.splitlines()), "invalid existing shallow boundary")
            with (self.work / ".git/shallow").open("xb") as stream:
                stream.write(boundary)
            shared["copied_actual_shallow_boundary"] = file_record(shallow)
        self.manifest["shared_objects"] = shared
        save(self.out / "isolated-shared-objects.json", shared)
        self.command("isolated-origin", [str(self.git), "-C", str(self.work), "remote", "add",
                                        "origin", origin], self.out)
        branch = "test/chain-pq-owner-counterexamples-" + self.args.expected_head[:12]
        self.command("isolated-checkout", [str(self.git), "-C", str(self.work), "checkout",
                                          "--quiet", "-b", branch, self.args.expected_head], self.out)
        self.preflight(self.work, "isolated-preflight")
        self.source_guard(self.work, "isolated-before")
        test_source = (self.work / TEST_SOURCE).read_text()
        self.manifest["critical_source_files"] = [file_record(self.work / path) for path in
                                                 (TEST_SOURCE, *(x[2] for x in MUTATIONS))]
        for name in TESTS:
            self.native("green-" + name, name)
        self.source_guard(self.work, "isolated-after-green")
        mutations = []
        self.manifest["mutations"] = mutations
        for kind, name, relative, header in MUTATIONS:
            self.preflight(self.work, "before-" + kind + "-mutation")
            path = self.work / relative
            original = path.read_bytes()
            source = original.decode("utf-8")
            require(source.count(header + GUARD) == 1,
                    "exact first-statement guard is missing or ambiguous: " + relative)
            changed = source.replace(header + GUARD, header, 1).encode()
            line = snapshot_assertion_line(test_source, name)
            patch = "".join(difflib.unified_diff(source.splitlines(keepends=True),
                                                changed.decode().splitlines(keepends=True),
                                                fromfile="a/" + relative, tofile="b/" + relative))
            (self.out / (kind + "-only-guard-removal.patch")).write_text(patch)
            mutations.append({"kind": kind, "file": relative,
                              "before_sha256": hashlib.sha256(original).hexdigest(),
                              "after_sha256": hashlib.sha256(changed).hexdigest(),
                              "deleted_guard_lines": 4, "snapshot_assertion_line": line,
                              "native_test": PREFIX + name})
            try:
                path.write_bytes(changed)
                require(self.git_read(self.work, "diff", "--name-only") == relative,
                        "mutation changed an unexpected tracked path")
                require(self.git_read(self.work, "diff", "--numstat") == "0\t4\t" + relative,
                        "mutation differs from exactly four deleted guard lines")
                require(path.read_bytes() == changed, "mutation bytes changed before execution")
                self.native("red-" + kind + "-guard-removed", name, line)
                require(path.read_bytes() == changed, "mutation bytes changed during execution")
                require(self.git_read(self.work, "diff", "--name-only") == relative,
                        "native command changed another tracked file")
            finally:
                path.write_bytes(original)
            self.source_guard(self.work, "isolated-after-" + kind + "-restore")
        self.manifest["result"] = "PASS_SCOPED_COUNTEREXAMPLES"
        self.manifest["green_controls"] = 4
        self.manifest["expected_red_controls"] = 2
        self.manifest["original_repository_head_after"] = self.git_read(self.repo, "rev-parse", "HEAD")
        self.manifest["isolated_source_restored"] = True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--cargo", type=Path, required=True)
    parser.add_argument("--rustc", type=Path, required=True)
    parser.add_argument("--cargo-home", type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--timeout-seconds", type=int, default=1800)
    args = parser.parse_args()
    require(re.fullmatch(r"[0-9a-f]{40}", args.expected_head) is not None, "noncanonical head SHA")
    require(1 <= args.jobs <= 8 and 30 <= args.timeout_seconds <= 3600, "invalid resource limit")
    campaign = Campaign(args)
    result = 0
    try:
        campaign.run()
    except Exception as error:
        campaign.manifest["result"] = "FAILED_OR_BLOCKED"
        campaign.manifest["error"] = f"{type(error).__name__}: {error}"
        result = 1
    finally:
        campaign.manifest["finished_unix_seconds"] = time.time()
        save(campaign.out / "summary.json", campaign.manifest)
    print(json.dumps({"result": campaign.manifest["result"],
                      "summary": str(campaign.out / "summary.json"),
                      "whole_chain_pq_qualified": False}), flush=True)
    return result


if __name__ == "__main__":
    raise SystemExit(main())
