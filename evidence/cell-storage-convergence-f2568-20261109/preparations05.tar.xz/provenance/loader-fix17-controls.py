import hashlib,json,os,pathlib,shutil,subprocess,sys,tarfile,time
c=json.load(sys.stdin);r=pathlib.Path('/home/qq/work/chain-cell-storage-convergence-f2568-20261109');o=r.parent/'chain-cell-storage-convergence-loader-fix17-preparation';o.mkdir(exist_ok=False)
z={'schema':'cell-sealed-corrective-python-preparation-v1','passed':False,'commands':[],'model_executed':False,'native_cargo_executed':False,'python_version':sys.version,'started_unix':time.time()}
def H(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def command(label,args,cwd,env=None,timeout=90):
 started=time.time();rec={'label':label,'argv':args,'cwd':str(cwd),'started_unix':started,'timeout_seconds':timeout,'timed_out':False}
 try:
  p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,timeout=timeout);out,err=p.stdout,p.stderr;rec['exit_code']=p.returncode
 except subprocess.TimeoutExpired as exc:
  out,err=exc.stdout or b'',exc.stderr or b'';rec.update(exit_code=None,timed_out=True)
 for name,raw in [('stdout',out),('stderr',err)]:
  path=o/(label+'.'+name);path.write_bytes(raw);rec[name]={'path':str(path),'bytes':len(raw),'sha256':H(path)}
 rec['ended_unix']=time.time();z['commands'].append(rec);return rec,out,err
def git(label,args):
 rec,out,err=command(label,['git',*args],r);assert rec['exit_code']==0 and not rec['timed_out'];return out.decode().strip()
def snapshots():
 return {str(p.relative_to(o)):{'bytes':p.stat().st_size,'sha256':H(p)} for p in sorted((o/'scripts').glob('*.py'))}
try:
 rec,_,_=command('preflight',['bash','scripts/project-preflight.sh'],r);assert rec['exit_code']==0
 assert git('head-before',['rev-parse','HEAD'])=='46ab510c21088d8b4bccee34fe142d327294dc28'
 z['tree']=git('tree-before',['rev-parse','HEAD^{tree}']);assert not git('status-before',['status','--porcelain','--untracked-files=all'])
 archive=r.parent/'chain-cell-storage-convergence-loader-fix17.tar.gz';assert H(archive)==c['archive_sha256']
 with tarfile.open(archive,'r:gz') as tf:
  rows=tf.getmembers();assert len(rows)==len(c['members']) and {x.name for x in rows}==set(c['members'])
  for m in rows:
   p=pathlib.PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts
   raw=tf.extractfile(m).read();wanted=c['members'][m.name];assert len(raw)==wanted['bytes'] and hashlib.sha256(raw).hexdigest()==wanted['sha256']
   dest=o/m.name;dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();dest.write_bytes(raw)
 before=snapshots();z['source_before']=before
 project_files=['scripts/llm_runtime_pilot.py','scripts/llm_python_runtime_contract.py','scripts/llm_runtime_rss_diagnostics.py','scripts/llm_runtime_exit_observation.py']
 z['original_project_source_before']={p:H(r/p) for p in project_files}
 env=os.environ.copy();env['CELL_SEALED_TEST_PROJECT_ROOT']=str(r);env['PYTHONDONTWRITEBYTECODE']='1'
 args=[sys.executable,'-B','-m','unittest','discover','-s',str(o/'scripts'),'-p','test_llm_cell_sealed_worker_v1.py','-v']
 fixed,out,err=command('fixed24',args,o,env)
 z['fixed24_passed']=fixed['exit_code']==0 and not fixed['timed_out'] and b'Ran 24 tests' in err and err.rstrip().endswith(b'OK')
 if z['fixed24_passed']:
  check=o/'actual-runtime-origin-check.py';check.write_text(c['runtime_check_script'])
  args=['/usr/bin/env','-i','PATH=/usr/bin:/bin','LANG=C.UTF-8','LC_ALL=C.UTF-8','/home/qq/hepta-smollm2-weight-research-20261103/python/cpython-3.12.16-linux-x86_64-gnu/bin/python3.12','-I','-S','-B','-X','pycache_prefix='+str(o/'unused-bytecode'),str(check)]
  real,out,err=command('actual-pinned-runtime-origin',args,o,timeout=90)
  z['actual_runtime_check']=json.loads(out) if real['exit_code']==0 else None
  z['actual_runtime_passed']=real['exit_code']==0 and not real['timed_out'] and z['actual_runtime_check']['passed'] is True
 z['source_after']=snapshots();z['source_unchanged']=z['source_before']==z['source_after']
 z['original_project_source_after']={p:H(r/p) for p in project_files};z['original_project_source_unchanged']=z['original_project_source_before']==z['original_project_source_after']
 assert git('head-after',['rev-parse','HEAD'])=='46ab510c21088d8b4bccee34fe142d327294dc28';assert not git('status-after',['status','--porcelain','--untracked-files=all'])
 z['passed']=z['fixed24_passed'] and z.get('actual_runtime_passed') is True and z['source_unchanged'] and z['original_project_source_unchanged']
finally:
 z['ended_unix']=time.time();(o/'receipt.json').write_text(json.dumps(z,indent=2,sort_keys=True)+'\n');print(json.dumps({'passed':z['passed'],'fixed24_passed':z.get('fixed24_passed'),'actual_runtime_passed':z.get('actual_runtime_passed'),'receipt':str(o/'receipt.json')}))
sys.exit(0 if z['passed'] else 1)
