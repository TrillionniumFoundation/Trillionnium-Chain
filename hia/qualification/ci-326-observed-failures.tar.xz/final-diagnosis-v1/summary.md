# Exact 326 CI failure diagnosis

Source: 326837e4c5a8a6b3b99390063c08a47dc4f9d6a0. This records observed failures; it is not a service qualification or a rerun.

## Whole-service pressure

All four native pressure phases failed CONFIRMATION_TARGET at the preserved 4-second / 16-attacker setting. Their separate attack-free baselines each confirmed one transaction. All business submissions started before the pressure window ended.

| Lane | Baseline confirmation latency (ns) | Pressure confirmed / unconfirmed / unknown | Job |
| --- | ---: | --- | --- |
| x64 head | 2793951231 | 0 / 1 / 0 | [133551950504](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43939229406/job/133551950504) |
| arm64 head | 1879010917 | 0 / 1 / 0 | [133551950562](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43939229406/job/133551950562) |
| arm64 prospective merge | 1806120511 | 0 / 1 / 0 | [133551950307](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43939229406/job/133551950307) |
| x64 prospective merge | 3214757923 | 0 / 1 / 0 | [133551950326](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43939229406/job/133551950326) |

The artifact manifests preserve five native tests, formatting, service and sustained observations. Those earlier successes do not change the pressure acceptance failure. Complete confirmation traces, request-terminal errors and source bindings remain in the original ZIPs.

## Long history

Both x64 lanes explicitly report their actual local server leaving its loop because the configured 1,800-second lifetime expired, without an earlier requested stop and without a server error. Their later history RPC reports Connection refused (os error 111). The evidence supports this proximate failure sequence; it does not isolate every cost that kept synchronization unfinished.

| Lane | Server loop elapsed (ns) | Sync observation elapsed (ns) | Completed import calls | Raw log lines |
| --- | ---: | ---: | ---: | --- |
| x64 prospective merge | 1800000865168 | 2739003186376 | 3973 | 27, 28, 29 |
| x64 head | 1800000225611 | 3143993253435 | 3297 | 26, 27, 28 |

Completed import calls are successful call returns, not durable committed block counts. The original binaries, unchanged source before/after, complete raw logs and manifests are indexed per artifact.

## Historical budget controls

All three historical subjects stop at IDENTICAL_GROUP_TESTS_LOCK_AND_PROFILE_REQUIRED before Cargo/native execution, leaving zero executed controls. The first differing common input is trillionnium/Cargo.lock: historical 759c42c62d7b9a72d93c533039b5bf47f3508efabf1f1ee63f5eee59b9b9e55f versus current 86aa87b12d7299990b368a0c07b1236bce99b1f43c5f58482c2adf0266f9a25e. Node package dependencies also differ.

The budget group has an additional semantic test change: the old pre-completion refill expectation and schema-v2 observations differ from the current NativeCommitted two-packet positive / sticky pre-completion refusal and schema-v3 observations. Pool and pool-scan selected tests are byte-identical, but their locked dependency/package graph differs. Editing a checksum cannot restore the required controlled comparison.

Repair must select a genuinely matched driver/subject pair with identical group, tests, lock and profile, and then execute it, while retaining current-head fixed qualification separately. A new counterexample against current semantics is another route, but would require its own actual native result. No such repair or execution is claimed here.

## Missing old artifact and cancelled jobs

Current retained-pressure job fails because exact artifact 11531476198 from run 37730166589 is unavailable. The checked repository absence archive has 52 fully verified members, but contains retrieval/404 evidence, not those missing historical bytes. Exact recovery remains OPEN; no other successful run substitutes for it.

Owned cleanup has six Linux successes and two macOS cancelled jobs with empty steps and no assigned runner ID in the captured API. The cancellation cause is UNKNOWN and no native execution is evidenced for those two jobs.

## Evidence inventory

Nine complete original artifact ZIPs retain 9478 indexed members. Ten full plugin-decoded UTF-8 job logs retain 8,607,013 bytes. Every retained file is SHA-256 indexed by complete-input-index.json, including provider API snapshots and original ZIP/member indexes.

The small accompanying archive carries summaries, indexes, raw job logs and extracted key observations. Complete original ZIPs remain at their indexed absolute paths and are not duplicated in this small archive. The original 0.25 CPU / 2 GiB / zero swap / 256 PID / 4 seconds / 16 attackers / 1,800 seconds requirements remain unchanged.
