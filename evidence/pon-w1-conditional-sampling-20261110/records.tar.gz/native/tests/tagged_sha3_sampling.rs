//! Native adapter boundary tests; these establish no cryptographic distribution.
use std::collections::VecDeque;
use std::sync::Arc;
use std::sync::atomic::{AtomicUsize, Ordering};

use p3_challenger::{CanObserve, CanSample, CanSampleBits, HashChallenger, SerializingChallenger64};
use p3_field::extension::BinomialExtensionField;
use p3_field::{BasedVectorSpace, PrimeCharacteristicRing};
use p3_goldilocks::Goldilocks;
use p3_symmetric::CryptographicHasher;

const P: u64 = 18_446_744_069_414_584_321;

#[derive(Clone, Debug)]
struct ScriptedBytes {
    bytes: VecDeque<u8>,
    consumed: Arc<AtomicUsize>,
}

impl CanSample<u8> for ScriptedBytes {
    fn sample(&mut self) -> u8 {
        self.consumed.fetch_add(1, Ordering::Relaxed);
        self.bytes.pop_front().expect("scripted bytes exhausted")
    }
}

impl CanObserve<u8> for ScriptedBytes {
    fn observe(&mut self, _: u8) {
        panic!("no observation is allowed in a raw sampler fixture");
    }
}

fn scripted(words: &[u64]) -> (SerializingChallenger64<Goldilocks, ScriptedBytes>, Arc<AtomicUsize>) {
    let consumed = Arc::new(AtomicUsize::new(0));
    let bytes = words.iter().flat_map(|value| value.to_le_bytes()).collect();
    let inner = ScriptedBytes { bytes, consumed: consumed.clone() };
    (SerializingChallenger64::new(inner), consumed)
}

#[test]
fn canonical_field_sampling_rejects_the_modulus_and_all_larger_candidates() {
    let (mut challenger, consumed) = scripted(&[P, P + 1, u64::MAX, P - 1]);
    let value: Goldilocks = challenger.sample();
    assert_eq!(value, Goldilocks::from_u64(P - 1));
    assert_eq!(consumed.load(Ordering::Relaxed), 32);
}

#[test]
fn extension_sampling_rejects_and_samples_each_basis_coefficient() {
    type Extension = BinomialExtensionField<Goldilocks, 2>;
    let (mut challenger, consumed) = scripted(&[P, P - 1, u64::MAX, 7]);
    let value: Extension = challenger.sample();
    let coefficients = [Goldilocks::from_u64(P - 1), Goldilocks::from_u64(7)];
    let expected = Extension::from_basis_coefficients_fn(|index| coefficients[index]);
    assert_eq!(value, expected);
    assert_eq!(consumed.load(Ordering::Relaxed), 32);
}

#[test]
fn query_indices_mask_raw_words_without_field_rejection_or_modular_reduction() {
    for bits in [15, 16] {
        let (mut challenger, consumed) = scripted(&[P, u64::MAX]);
        assert_eq!(challenger.sample_bits(bits), 1);
        assert_eq!(challenger.sample_bits(bits), (1 << bits) - 1);
        assert_eq!(consumed.load(Ordering::Relaxed), 16);
    }
}

#[test]
fn query_indices_use_the_low_bits_of_the_little_endian_candidate() {
    let word = 0x1234_5678_9abc_def0;
    for bits in [15, 16] {
        let (mut challenger, consumed) = scripted(&[word]);
        assert_eq!(challenger.sample_bits(bits), (word & ((1 << bits) - 1)) as usize);
        assert_eq!(consumed.load(Ordering::Relaxed), 8);
    }
}

#[test]
fn sixty_four_query_draws_can_repeat_an_index() {
    for bits in [15, 16] {
        let (mut challenger, consumed) = scripted(&[17; 64]);
        let indices: Vec<_> = (0..64).map(|_| challenger.sample_bits(bits)).collect();
        assert_eq!(indices, vec![17; 64]);
        assert_eq!(consumed.load(Ordering::Relaxed), 512);
    }
}

#[test]
fn hash_challenger_pops_a_real_tagged_sha3_digest_in_reverse_byte_order() {
    use w1_full_public_stark_research::tagged_sha3::{Component, TranscriptHasher};
    let hasher = TranscriptHasher::new(Component::Sha, [0x42; 64]);
    let digest: [u8; 64] = hasher.hash_iter([1, 2, 3]);
    let mut challenger = HashChallenger::new(vec![1, 2, 3], hasher);
    let actual: [u8; 64] = challenger.sample_array();
    let expected: [u8; 64] = core::array::from_fn(|index| digest[63 - index]);
    assert_eq!(actual, expected);
}
