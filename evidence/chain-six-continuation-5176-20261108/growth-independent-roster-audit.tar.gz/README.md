# Growth roster reconciliation

The retained F3 run selected the complete store::growth:: library module and reported **77 passed, 2 ignored**. Filtering only native_growth_v2_ selects **51 passed plus those same 2 ignored**. The missing **26 are library tests in the same Growth module**, not integration tests.

This audit only read the current source, Git objects, and retained original archive. It ran no Cargo build or test and changed no source file. The exact F3 and e798 Growth paths are unchanged at F0 4505a598d6ec2644a175e47398d4a5f3f054bc5e; that source comparison does not turn prior results into fresh F0 execution.

Original command:

    cargo +1.95.0 test --locked --offline --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib 'store::growth::' -- --test-threads=1

Current supplement, matching the feature graph reported by the parent:

    cargo +1.95.0 test --locked --offline --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --features pq-native-openssl --lib 'store::growth::' -- --skip native_growth_v2_ --test-threads=1

The supplement should select 26 tests and zero ignored tests. Only an actual successful current supplement can be combined with the current 51 passes. Keep the existing target directory and resource limits. Do not run ignored experiments, and do not add --exact to a module filter.

Files:

- original-growth79-selected.txt: complete distinct original selection.
- original-growth77-passed.txt: complete original pass roster.
- original-growth2-ignored.txt: original ignored experiments.
- supplement26-nonprefix.txt: exact missing 26 names.
- prefix51-passed.txt: the other 51 passed names.
- original-f3-native-growth.log: unchanged original raw log.
- original-f3-native-growth-record.json: original per-check metadata.
- audit.json: pins, archive hashes, exact command, group counts, source comparisons, and execution boundaries.

The legacy checks.json passed-name parser lists 76 names because the process-cut test's ok is on a later line after child output. The unchanged raw log contains all 79 distinct test starts and the final 77/2 successful summary. This audit restores the complete roster and leaves the original metadata unchanged.

The two CLI integration tests in tests/native_growth_cli.rs are outside this original library roster and are not included in the 77 or missing 26.
