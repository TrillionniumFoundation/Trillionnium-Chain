#!/usr/bin/env python3
"""Read-only checksum audit of Cargo's resolved source packages; no credentials."""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import sys
import tomllib
import tarfile

ROOT=Path('/home/qian-qi/work/chain-qrom-local-20261107-7150')
OUT=Path('/home/qian-qi/work/chain-qrom-closure-20261107-evidence/native-7150')
EXPECTED='7150d96a2112875b4afcf3023361a5cef4a0e4b1'
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()
def main():
    phase=sys.argv[1]
    assert phase in ('before','after')
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==EXPECTED
    dest=OUT/('resolved-dependencies-'+phase+'.json')
    assert not dest.exists()
    graphs=[('chain','trillionnium/Cargo.lock'),('v2','formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock')]
    packages={}
    graph_records=[]
    for name,lock_path in graphs:
        metadata=OUT/('cargo-metadata-'+name+'.stdout.log')
        data=json.loads(metadata.read_text())
        lock=tomllib.loads((ROOT/lock_path).read_text())
        locked={(p['name'],p['version'],p.get('source')):p for p in lock['package']}
        graph_records.append({'name':name,'lock':lock_path,'lock_sha256':sha(ROOT/lock_path),
                              'metadata_sha256':sha(metadata),'package_count':len(data['packages'])})
        for package in data['packages']:
            key=(package['name'],package['version'],package.get('source'))
            row=packages.setdefault(package['id'],{'name':package['name'],'version':package['version'],
                'source':package.get('source'),'manifest_path':package['manifest_path'],'graphs':[],
                'lock_checksums':[]})
            row['graphs'].append(name)
            match=locked.get(key)
            assert match is not None,('resolved package not in lock',key)
            row['lock_checksums'].append(match.get('checksum'))
    failures=[]
    for identity,row in sorted(packages.items()):
        root=Path(row['manifest_path']).parent
        if row['source'] is None:
            row['scope']='path_dependency_covered_by_selected_HEAD_source_snapshot'
            row['inside_frozen_repo']=root.is_relative_to(ROOT)
            row['verified']=row['inside_frozen_repo']
        elif row['source'].startswith('registry+'):
            row['scope']='resolved_registry_package_source_files_and_cached_archive_if_present'
            expected=set(row['lock_checksums'])
            archive=root.parents[2]/'cache'/root.parent.name/(root.name+'.crate')
            row['cached_archive_present']=archive.is_file()
            row['cached_archive_sha256']=sha(archive) if archive.is_file() else None
            row['cached_archive_matches_lock']=row['cached_archive_sha256'] in expected
            row['scope']='resolved_registry_archive_against_lock_and_each_archived_source_file_against_extracted_bytes'
            checked=[]
            bad=[]
            names=set()
            if not row['cached_archive_matches_lock']:
                bad.append({'path':str(archive),'reason':'cached archive missing or checksum mismatch'})
            else:
                with tarfile.open(archive,'r:gz') as contents:
                    for member in contents:
                        if member.isdir(): continue
                        prefix=root.name+'/'
                        if not member.isfile() or not member.name.startswith(prefix):
                            bad.append({'path':member.name,'reason':'unsupported archive member'})
                            continue
                        relative=member.name[len(prefix):]
                        path=root/relative
                        if relative in names or not path.resolve().is_relative_to(root.resolve()):
                            bad.append({'path':relative,'reason':'duplicate or escaping archive member'})
                            continue
                        names.add(relative)
                        try:
                            if not stat.S_ISREG(path.lstat().st_mode):
                                raise ValueError('nonregular extracted source')
                            archived=contents.extractfile(member)
                            expected_digest=hashlib.sha256()
                            for chunk in iter(lambda:archived.read(1024*1024),b''):
                                expected_digest.update(chunk)
                            got=sha(path)
                            if got!=expected_digest.hexdigest():
                                bad.append({'path':relative,'expected':expected_digest.hexdigest(),'actual':got})
                            checked.append({'path':relative,'sha256':got,'bytes':path.stat().st_size})
                        except (OSError,ValueError) as error:
                            bad.append({'path':relative,'reason':str(error)})
            row['source_files_verified']=len(checked)
            row['source_bytes_verified']=sum(p['bytes'] for p in checked)
            row['canonical_file_identity_sha256']=hashlib.sha256(json.dumps(sorted(checked,key=lambda p:p['path']),sort_keys=True,separators=(',',':')).encode()).hexdigest()
            row['mismatches']=bad
            row['verified']=not bad and row['cached_archive_matches_lock']
        else:
            row['scope']='unsupported_nonregistry_source'
            row['verified']=False
        if not row['verified']: failures.append(identity)
    flags=['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTC','CARGO_HOME']
    env_id={key:{'present':key in os.environ,'value_sha256':hashlib.sha256(os.environ[key].encode()).hexdigest() if key in os.environ else None} for key in flags}
    result={'schema':'TRNM-W1-NATIVE-RESOLVED-DEPENDENCIES1','phase':phase,'head':EXPECTED,
        'graphs':graph_records,'package_count':len(packages),'all_supported_source_checks_pass':not failures,
        'failures':failures,'packages':packages,'selected_environment_identities_only':env_id,
        'environment_values_and_credentials_disclosed':False,
        'compiler_generated_files_are_not_independent_source_proofs':True,
        'post_quantum_soundness_qualified':False}
    dest.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'path':str(dest),'packages':len(packages),'all_supported_source_checks_pass':not failures,
        'failures':failures,'sha256':sha(dest),'source_files':sum(p.get('source_files_verified',0) for p in packages.values())}))
    if phase=='after':
        prior=json.loads((OUT/'resolved-dependencies-before.json').read_text())
        comparison={'packages_and_source_files_unchanged':prior['packages']==packages,
                    'graphs_unchanged':prior['graphs']==graph_records,
                    'before_sha256':sha(OUT/'resolved-dependencies-before.json'),'after_sha256':sha(dest)}
        (OUT/'resolved-dependencies-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
        print(json.dumps(comparison))
    return 0 if not failures else 2

if __name__=='__main__':
    raise SystemExit(main())
