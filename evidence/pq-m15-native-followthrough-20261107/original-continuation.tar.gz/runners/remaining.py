#!/usr/bin/env python3
"""Continue the original cost/CPQ1/interop commands after the fixed full Node gate."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

SUPPORT = Path("/home/alex/work/chain-m15-regression-1c14fab4-13c7-runner-v2.py")
SUPPORT_SHA = "750a23f7665477885627a80399b26bb7e887d2f4cf814e7230314123daa18def"
ORIGINAL_RUNNER_SHA = "0cf1f5593f5a7dd1b8d3a0f6e5b05fce20055aec54343a9a89b425c61b1ca609"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    if hashlib.sha256(SUPPORT.read_bytes()).hexdigest() != SUPPORT_SHA:
        raise ValueError("fixed native support changed")
    m = load_module("m15_fixed_support", SUPPORT)
    source, output = m.SOURCE, m.OUTPUT / "continuation"
    output.mkdir(mode=0o700, exist_ok=False)
    m.require(m.sha(m.WORK / "chain-final-union-original-native-runner-bound-v1.py") == ORIGINAL_RUNNER_SHA,
              "reviewed original remaining command source changed")
    full = json.loads((m.OUTPUT / "complete/manifest.json").read_text())
    m.require(full["result"] == "PASS" and full["commit"] == m.COMMIT and full["tree"] == m.TREE,
              "complete fixed-source Node phase has not passed")
    source_verifier = load_module("verify_ci_source", source / "scripts/ci/verify_ci_source.py")
    env, provider_before = m.prepared_environment()
    aggregate = dict(schema="chain-original-remaining-native-v1", commit=m.COMMIT, tree=m.TREE,
                     source=str(source), target=str(m.TARGET), started_utc=datetime.now(timezone.utc).isoformat(),
                     original_runner_sha256=ORIGINAL_RUNNER_SHA, runner_sha256=m.sha(__file__),
                     original_outer_timeout_seconds=14400, outer_timeout_seconds=14400,
                     per_command_timeout_added=False, automatic_retry_added=False,
                     phases=[], result="RUNNING", full_manifest_sha256=m.sha(m.OUTPUT / "complete/manifest.json"),
                     whole_chain_quantum_security_qualified=False, production_activation=False,
                     shared_host=True, hardware_or_wan_qualified=False)
    def save():
        (output / "manifest.json").write_text(json.dumps(aggregate, indent=2, sort_keys=True) + "\n")
    save()
    code = 1
    try:
        aggregate["source_before"] = source_verifier.verify("head", m.COMMIT, root=source)
        aggregate["original_source_before"] = source_verifier.verify("head", m.OLD, root=m.ORIGINAL)
        aggregate["old_inputs_before"] = m.check_old_inputs()
        aggregate["provider_inputs_before"] = provider_before
        cargo, base, node = m.CARGO, m.BASE, m.NODE
        for name in ["cost", "cpq1", "interop-c", "interop-sdk"]:
            phase = output / name
            phase.mkdir(mode=0o700, exist_ok=False)
            record = dict(phase=name, started_utc=datetime.now(timezone.utc).isoformat(), commands=[], result="RUNNING")
            aggregate["phases"].append(record)
            save()
            def run(label, command):
                argv = ["python3", "scripts/ci/record_pq_native_command.py", "--kind", "head", "--candidate", m.COMMIT,
                        "--tested", m.COMMIT, "--label", label, "--output", str(phase), "--"] + command
                print(json.dumps(dict(event="start", phase=name, label=label, argv=command)), flush=True)
                status = subprocess.run(argv, cwd=source, env=env, check=False).returncode
                record["commands"].append(dict(label=label, exit_code=status))
                save()
                m.require(status == 0, name + "/" + label + " failed: " + str(status))
            def bind_binary(path):
                value = m.file_identity(path)
                m.write_json(phase / "binary.json", value)
                return value
            run("preflight", ["bash", "scripts/project-preflight.sh", "--audit"])
            if name == "cost":
                env["TRNM_PQ_AUTH_COST_DIRECTORY"] = str(phase / "pq-authentication-cost")
                env["TRNM_NATIVE_ROOT_DIGEST_COST_OUTPUT"] = str(phase / "native-root-digest-cost.jsonl")
                costs = [
                    (node, "store::history_page::tests::inline_record_tests::history_inline_record_complete_call_cost"),
                    (node, "ingress::public_v3::pq_identity::verifier_cache::tests::pq_caller_authentication_complete_cost"),
                    (node, "account_archive_prototype::native_root_digest::tests::native_root_digest_paired_complete_root_cost_observation"),
                    (cargo + ["test"] + base + ["-p", "trnm-mvcc-fee", "--lib"], "pon_commitment::unchanged_snapshot_tests::unchanged_snapshot_full_binding_cost"),
                ]
                for index, (command, selector) in enumerate(costs):
                    label = "cost-" + format(index, "02d")
                    run(label, command + [selector, "--", "--exact", "--ignored", "--show-output", "--test-threads=1"])
                    run(label + "-execution", ["python3", "scripts/ci/check_required_native_test.py", str(phase / (label + ".log")), "--test", selector])
                del env["TRNM_PQ_AUTH_COST_DIRECTORY"]
                del env["TRNM_NATIVE_ROOT_DIGEST_COST_OUTPUT"]
            elif name == "cpq1":
                run("compiler", ["rustc", "+1.95.0", "-Vv"])
                run("cargo-version", cargo + ["-V"])
                run("locked-graph", cargo + ["metadata"] + base + ["--format-version", "1"])
                run("reader-negatives", ["python3", "-m", "unittest", "discover", "-s", "scripts/ci", "-p", "test_cpq1_parameter_observation.py", "-v"])
                host_code = ('import json,os,pathlib,platform; root=pathlib.Path("/sys/fs/cgroup"); '
                             'names=("cpu.max","memory.max","memory.current","memory.events"); '
                             'print(json.dumps({"schema":"trnm-cpq1-host-context-v1","platform":platform.platform(),'
                             '"machine":platform.machine(),"cpu_count":os.cpu_count(),'
                             '"cpu_affinity":sorted(os.sched_getaffinity(0)),"load_average":os.getloadavg(),'
                             '"cpu_model":next((line.split(":",1)[1].strip() for line in pathlib.Path("/proc/cpuinfo").read_text().splitlines() if line.startswith("model name")),None),'
                             '"meminfo":pathlib.Path("/proc/meminfo").read_text(),'
                             '"cgroup":{name:(root/name).read_text().strip() if (root/name).is_file() else None for name in names},'
                             '"shared_host":True,"original_hardware_or_wan_qualification":False},sort_keys=True))')
                run("build", cargo + ["build", "--release"] + base + ["-p", "trnm-crypto-primitives", "--example", "pq_profile_bench"])
                binary = bind_binary(m.TARGET / "release/examples/pq_profile_bench")
                run("host-before", ["python3", "-c", host_code])
                run("cpq1", [binary["path"], "--samples", "64"])
                run("host-after", ["python3", "-c", host_code])
                m.require(m.file_identity(binary["path"]) == binary, "CPQ1 binary changed")
                run("independent-readback", ["python3", "scripts/ci/check_cpq1_parameter_observation.py", str(phase / "cpq1.log")])
            elif name == "interop-c":
                upstream = m.WORK / "chain-zeroize191-df896925-20261105-inputs/mldsa-native"
                run("independent-source-guard", ["python3", "trillionnium/crates/trnm-crypto-primitives/tests/independent_backend/test_mldsa_native_source.py", "--source", str(upstream)])
                run("oracle-build", cargo + ["build"] + base + ["-p", "trnm-crypto-primitives", "--example", "pq_message_oracle"])
                run("tap21-metadata", cargo + ["test"] + base + ["-p", "trnm-crypto-primitives", "--test", "tuf_tap21"])
                binary = bind_binary(m.TARGET / "debug/examples/pq_message_oracle")
                run("independent-c", ["python3", "trillionnium/crates/trnm-crypto-primitives/tests/independent_backend/mldsa_native_differential.py", "--source", str(upstream), "--chain-oracle", binary["path"], "--wycheproof", "trillionnium/crates/trnm-crypto-primitives/tests/fixtures/wycheproof/mldsa_65_verify_test.json", "--build-dir", str(phase / "c-build"), "--report", str(phase / "differential.json")])
                m.require(m.file_identity(binary["path"]) == binary, "independent C oracle changed")
            else:
                upstream = m.WORK / "chain-zeroize191-df896925-20261105-inputs/securesystemslib"
                python = m.WORK / "chain-zeroize191-df896925-20261105-inputs/sdk-env/bin/python"
                run("sdk-dependencies", [str(python), "-m", "pip", "install", "--disable-pip-version-check", "--only-binary=:all:", "--report", str(phase / "dependencies.json"), "cryptography==50.0.2", "cffi==2.1.1", "pycparser==3.12"])
                run("sdk-source-guard", ["python3", "trillionnium/crates/trnm-crypto-primitives/tests/independent_backend/test_tuf_sdk_source.py", "--source", str(upstream)])
                run("sdk-oracle-build", cargo + ["build"] + base + ["-p", "trnm-crypto-primitives", "--example", "pq_message_oracle"])
                binary = bind_binary(m.TARGET / "debug/examples/pq_message_oracle")
                run("sdk-interop", [str(python), "trillionnium/crates/trnm-crypto-primitives/tests/independent_backend/tuf_sdk_differential.py", "--source", str(upstream), "--chain-oracle", binary["path"], "--report", str(phase / "differential.json")])
                m.require(m.file_identity(binary["path"]) == binary, "SDK oracle changed")
            record.update(result="PASS", finished_utc=datetime.now(timezone.utc).isoformat())
            save()
        code = 0
    except Exception as error:
        aggregate["error"] = str(error)
        if aggregate["phases"]:
            aggregate["phases"][-1]["result"] = "FAIL"
        print(json.dumps(dict(event="failed", error=str(error))), flush=True)
    finally:
        try:
            aggregate["source_after"] = source_verifier.verify("head", m.COMMIT, root=source)
            aggregate["original_source_after"] = source_verifier.verify("head", m.OLD, root=m.ORIGINAL)
            aggregate["old_inputs_after"] = m.check_old_inputs()
            _, aggregate["provider_inputs_after"] = m.prepared_environment()
            for key in ["source", "original_source", "old_inputs", "provider_inputs"]:
                m.require(aggregate[key + "_before"] == aggregate[key + "_after"], key + " changed")
        except Exception as error:
            code = 1
            aggregate["final_identity_error"] = str(error)
        aggregate.update(result="PASS" if code == 0 else "FAIL", exit_code=code, finished_utc=datetime.now(timezone.utc).isoformat())
        save()
    print(json.dumps(dict(result=aggregate["result"], output=str(output))), flush=True)
    return code


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    raise SystemExit(main())
