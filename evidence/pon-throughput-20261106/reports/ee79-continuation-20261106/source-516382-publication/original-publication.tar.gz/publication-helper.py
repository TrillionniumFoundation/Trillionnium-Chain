#!/usr/bin/env python3
"""One guarded fast-forward publication from the existing isolated checkout."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

BASE = Path('/home/qian-qi/work/chain-throughput-20261106-ee79')
REPO = BASE / 'repo'
BUNDLE = BASE / 'pq-parallel-118.bundle'
BUNDLE_SHA = 'd71ac3e47718b490e89d5c1ce4ed0f1e4b4c002406906fa9cda0b2052236231d'
LOCAL_BEFORE = '0bca28ebf59058b6aba9db5eb956c4479556e9ee'
REMOTE_BEFORE = '0bca28ebf59058b6aba9db5eb956c4479556e9ee'
HEAD = '516382d87bbfdba85fbf34b6aa7b62edbc5759bb'
TREE = '473434f61c82d9b8daa76dff98ab3bdedbba13ca'
BRANCH = 'fix/chain-throughput-publish-20261106-1eed'
REF = 'refs/heads/' + BRANCH
KEY = 'chain-ee79-existing-repo-0bca-to-516382-cas-publish-v1'
OUT = BASE / 'raw/516382-existing-repo-publish-v1'


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    require(sys.version_info >= (3, 11), 'Python >=3.11 required by original hook')
    require(REPO.resolve(strict=True) == REPO and not REPO.is_symlink(), 'existing repo path mismatch')
    require(BUNDLE.resolve(strict=True) == BUNDLE and BUNDLE.is_file() and not BUNDLE.is_symlink(),
            'bundle is absent or not the exact regular path')
    OUT.mkdir(exist_ok=False)
    with (OUT / 'publication-ledger.jsonl').open('x') as ledger:
        def record(phase, **values):
            value = {'schema': 'trnm-existing-repo-publication-v1', 'phase': phase,
                     'utc': datetime.now(timezone.utc).isoformat(), 'key': KEY, **values}
            ledger.write(json.dumps(value, sort_keys=True) + '\n')
            ledger.flush()
            os.fsync(ledger.fileno())
            print(json.dumps({'phase': phase, **values}, sort_keys=True), flush=True)

        def run(label, argv, *, check=True):
            log = OUT / (label + '.log')
            with log.open('xb') as output:
                result = subprocess.run(argv, cwd=REPO, stdout=output, stderr=subprocess.STDOUT,
                                        env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
                                                 GIT_TERMINAL_PROMPT='0'), timeout=300)
                output.flush()
                os.fsync(output.fileno())
            value = {'argv': argv, 'exit_code': result.returncode, 'log': str(log),
                     'log_bytes': log.stat().st_size, 'log_sha256': sha(log)}
            with (OUT / (label + '.json')).open('x') as output:
                json.dump(value, output, sort_keys=True, indent=2)
                output.write('\n')
            record('command', label=label, **value)
            if check:
                require(result.returncode == 0, label + ' failed; no retry')
            return result.returncode, log.read_text()

        def git(label, *arguments):
            return run(label, ['git', *arguments])[1].strip()

        def remote_head(label):
            value = git(label, 'ls-remote', '--exit-code', 'origin', REF)
            require(re.fullmatch(r'[0-9a-f]{40}\s+' + re.escape(REF), value) is not None,
                    'remote branch readback not exact')
            return value.split()[0]

        record('started', repo=str(REPO), initial_head=LOCAL_BEFORE, target_head=HEAD,
               target_tree=TREE, branch=BRANCH, bundle_sha256=BUNDLE_SHA,
               script_sha256=os.environ.get('TRNM_PUBLISH_SCRIPT_SHA256'),
               prior_publication_job_terminal='1a1b199aa4c-fc05-79c7 succeeded exit 0',
               force_push=False, hook_bypass=False, remote_policy_mutated=False)
        try:
            require(git('initial-branch', 'symbolic-ref', '--quiet', 'HEAD') == REF,
                    'existing checkout branch differs')
            require(git('initial-head', 'rev-parse', 'HEAD') == LOCAL_BEFORE,
                    'existing checkout is not exact 0bca')
            require(not git('initial-status', 'status', '--porcelain=v1', '--untracked-files=all'),
                    'existing checkout has changes')
            run('initial-preflight', ['bash', 'scripts/project-preflight.sh'])
            run('initial-source', ['python3', '-B', 'scripts/ci/verify_ci_source.py',
                '--kind', 'head', '--expected-head', LOCAL_BEFORE,
                '--output', str(OUT / 'source-before-0bca.json')])
            observed_remote = remote_head('remote-before-local-update')
            require(observed_remote in {REMOTE_BEFORE, HEAD}, 'unexpected remote head; do not cover concurrent work')
            require(sha(BUNDLE) == BUNDLE_SHA, 'bundle SHA256 differs')
            run('bundle-verify', ['git', 'bundle', 'verify', str(BUNDLE)])
            require(git('bundle-heads', 'bundle', 'list-heads', str(BUNDLE)) == HEAD + ' HEAD',
                    'bundle does not have the exact expected HEAD')
            run('bundle-fetch', ['git', 'fetch', '--no-tags', '--no-recurse-submodules', str(BUNDLE), 'HEAD'])
            require(sha(BUNDLE) == BUNDLE_SHA, 'bundle changed during fetch')
            require(git('fetched-head', 'rev-parse', 'FETCH_HEAD') == HEAD, 'fetched object differs')
            require(git('before-ff-head', 'rev-parse', 'HEAD') == LOCAL_BEFORE
                    and git('before-ff-branch', 'symbolic-ref', '--quiet', 'HEAD') == REF
                    and not git('before-ff-status', 'status', '--porcelain=v1', '--untracked-files=all'),
                    'checkout changed before fast-forward')
            run('fast-forward', ['git', 'merge', '--ff-only', HEAD])
            require(git('checked-head', 'rev-parse', 'HEAD') == HEAD
                    and git('checked-tree', 'rev-parse', 'HEAD^{tree}') == TREE
                    and git('checked-branch', 'symbolic-ref', '--quiet', 'HEAD') == REF
                    and not git('checked-status', 'status', '--porcelain=v1', '--untracked-files=all'),
                    'fast-forward source mismatch')
            run('final-preflight', ['bash', 'scripts/project-preflight.sh'])
            run('final-source', ['python3', '-B', 'scripts/ci/verify_ci_source.py',
                '--kind', 'head', '--expected-head', HEAD, '--output', str(OUT / 'source-516382.json')])
            before_push = remote_head('remote-immediately-before-push')
            require(before_push in {REMOTE_BEFORE, HEAD}, 'remote changed; no push is allowed')
            push_code = None
            if before_push == REMOTE_BEFORE:
                push_code, _ = run('nonforce-push', ['git', '-c', 'core.hooksPath=.githooks',
                    'push', 'origin', 'HEAD:' + REF], check=False)
            else:
                record('already-up-to-date', remote_head=before_push, push_executed=False)
            after_push = remote_head('remote-after-push')
            require(push_code in {None, 0}, 'push returned nonzero; failure retained despite readback')
            require(after_push == HEAD, 'remote readback differs from expected publication')
            require(git('final-head', 'rev-parse', 'HEAD') == HEAD
                    and git('final-tree', 'rev-parse', 'HEAD^{tree}') == TREE
                    and git('final-branch', 'symbolic-ref', '--quiet', 'HEAD') == REF
                    and not git('final-status', 'status', '--porcelain=v1', '--untracked-files=all'),
                    'source changed during publication')
            summary = {'status': 'published' if push_code == 0 else 'already-published-verified',
                       'repo': str(REPO), 'branch': BRANCH, 'head': HEAD, 'tree': TREE,
                       'remote_before_local_update': observed_remote, 'remote_before_push': before_push,
                       'remote_after_push': after_push, 'push_exit_code': push_code,
                       'force_push': False, 'original_pre_push_hook_preserved': True,
                       'remote_policy_mutated': False, 'output': str(OUT),
                       'source_receipt_sha256': sha(OUT / 'source-516382.json')}
            with (OUT / 'publication-result.json').open('x') as output:
                json.dump(summary, output, sort_keys=True, indent=2)
                output.write('\n')
                output.flush()
                os.fsync(output.fileno())
            record('complete', **summary)
        except BaseException as error:
            record('failed', error_type=type(error).__name__, error=str(error),
                   no_retry=True, unknown_prior_clone_replayed=False)
            raise


if __name__ == '__main__':
    main()
