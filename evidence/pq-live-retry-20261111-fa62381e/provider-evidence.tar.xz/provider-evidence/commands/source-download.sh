python3 - <<'PY_OFFICIAL_RELEASE_ARCHIVE_FA62381E'
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/tmp/chain-pq-fa62381e-s1-check')
os.chdir(root)
subprocess.run(['bash','scripts/project-preflight.sh','--audit'],check=True)
out=Path('/tmp/chain-pq-fa62381e-provider/source-via-gh')
out.mkdir()
started=time.monotonic_ns()
metadata=subprocess.run(['gh','api','repos/openssl/openssl/releases/tags/openssl-3.5.9'],
                        stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False,timeout=60)
(out/'release-metadata.json').write_bytes(metadata.stdout)
(out/'release-metadata.stderr').write_bytes(metadata.stderr)
if metadata.returncode:
 raise SystemExit(metadata.returncode)
release=json.loads(metadata.stdout)
assets=[x for x in release.get('assets',[]) if x.get('name')=='openssl-3.5.9.tar.gz']
if release.get('tag_name')!='openssl-3.5.9' or len(assets)!=1:
 raise SystemExit('unexpected official release/asset')
asset=assets[0]
url='https://github.com/openssl/openssl/releases/download/openssl-3.5.9/openssl-3.5.9.tar.gz'
if asset.get('browser_download_url')!=url:
 raise SystemExit('official archive URL mismatch')
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'scripts/ci'))
from ci_observation import run
observation=run(['gh','release','download','openssl-3.5.9','--repo','openssl/openssl',
                 '--pattern','openssl-3.5.9.tar.gz','--dir',str(out)],
                out/'download.log',cwd=root,timeout=900)
archive=out/'openssl-3.5.9.tar.gz'
actual=None
if archive.is_file():
 with archive.open('rb') as stream:
  actual=hashlib.file_digest(stream,'sha256').hexdigest()
expected='603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a'
success=observation['exit_code']==0 and not observation['timed_out'] and actual==expected
record={'official_repository':'openssl/openssl','release_tag':release['tag_name'],
        'asset_id':asset['id'],'archive':str(archive),'expected_sha256':expected,
        'actual_sha256':actual,'source_digest_verified':success,
        'expected_bytes':asset['size'],'actual_bytes':archive.stat().st_size if archive.exists() else None,
        'release_metadata_sha256':hashlib.sha256(metadata.stdout).hexdigest(),
        'observation':observation,'elapsed_ns':time.monotonic_ns()-started}
(out/'archive-download.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,sort_keys=True))
raise SystemExit(0 if success else (observation['exit_code'] or 1))
PY_OFFICIAL_RELEASE_ARCHIVE_FA62381E