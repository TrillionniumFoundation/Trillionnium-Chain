#!/usr/bin/env python3
"""Collect exact B native command/source evidence; this is not PQ acceptance."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
from datetime import datetime, timezone

REPO = Path('/home/qq/chain-hash-transitive-976f-20261111')
OUT = Path('/home/qq/chain-hash-transitive-976f-20261111-native-b')
B = '9fd6ee29a7a663cef547040d9d42cc36a371a17e'
TREE = '7351f83fa9ac5c0e7540fa64bce06ea6f328602f'
LABELS = ['b-m06-history-all-features', 'b-node-history-default', 'b-node-history-all-features',
          'b-five-packages-lib-default', 'b-five-packages-lib-all-features',
          'b-five-packages-doc', 'b-six-packages-strict-clippy']
PROVIDER = Path('/home/qq/trnm-v4-e12ecc-recovery/tmp/trnm-pq-provider-3.5.9.EuFYF5vc/install')
PROVIDER_PINS = {
    'bin/openssl': (8985944, 'd4c13f27791f214bc9ea80acb1ed51fa1fbc7c17db72b9a7c54e24bf0accc171'),
    'lib/libcrypto.a': (12442056, '0c7c92a17a5d607ce38340e80de6ae9050d0c8631dd19e88d892b1844963c13c'),
    'lib/libssl.a': (2149026, 'd7cddef12614789118f792fb4b07748c9a413d241895c1501fe12e3998658d90'),
    'include/openssl/opensslv.h': (3449, '9647fc99758cf83e3bcf11ae310894fd4911ad62bff22d8213a614df89cfedda'),
}
DRIVER_PINS = {
    '/tmp/chain-hash-976f-setup-b.py': (7900, '9624225df36db46733fb96b949b86a23db8b1d694ff0b2824fc1d26cb71b9b3c'),
    '/tmp/chain-hash-976f-setup-b-connected.py': (6799, '86926f88edb136e2d520603354a7dae330d02d0219d1b29d2a435b86e1d601c0'),
    '/tmp/chain-hash-976f-setup-b-complete.py': (9730, '9ba448ff301a954e91760ec1414b34d116a44fcc197903650fd6c9832468b70b'),
    '/tmp/chain-hash-976f-setup-b-objects.py': (9608, '439ad11e13348d679760596aeb7a7b642d547f47f7594dec0aee424b410f9913'),
    '/tmp/chain-hash-976f-native-b-driver.py': (6447, 'cb8dbd80517a5bb4df860f8f4ce63f6d12e285b657be4467b4600b18583d6b5c'),
}


def identity(path):
    meta = path.lstat()
    assert stat.S_ISREG(meta.st_mode), 'regular files only'
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': meta.st_size, 'sha256': digest}


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def main():
    evidence = OUT / 'evidence'
    evidence.mkdir()
    terminals_file = OUT / 'terminal-observations.json'
    terminals = json.loads(terminals_file.read_text())
    assert terminals['candidate'] == B and terminals['tree'] == TREE
    environment = json.loads((OUT / 'environment.json').read_text())
    child_env = dict(os.environ, **environment)
    for key in list(child_env):
        if key in {'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'} or key.startswith('CARGO_PROFILE_'):
            child_env.pop(key)

    source_log = evidence / 'source-after.log'
    with source_log.open('xb') as stream:
        code = subprocess.run([sys.executable, '-B', 'scripts/ci/verify_ci_source.py',
                               '--kind', 'head', '--expected-head', B,
                               '--output', str(evidence / 'source-after.json')],
                              cwd=REPO, env=child_env, stdout=stream, stderr=subprocess.STDOUT).returncode
    assert code == 0, 'final full raw source guard failed'
    source = json.loads((evidence / 'source-after.json').read_text())
    assert source['tested_commit'] == B and source['tested_tree'] == TREE
    assert source['tracked_worktree_verified'] is True
    assert source == json.loads((OUT / 'source-before.json').read_text())

    provider_after = []
    before = {entry['path']: entry for entry in json.loads((OUT / 'provider-identities.json').read_text())}
    for relative, (size, digest) in PROVIDER_PINS.items():
        path = PROVIDER / relative
        actual = identity(path)
        assert actual['bytes'] == size and actual['sha256'] == digest
        assert actual == before[str(path)]
        provider_after.append(actual)
    write_new(evidence / 'provider-after.json', provider_after)

    driver_after = []
    for name, (size, digest) in DRIVER_PINS.items():
        actual = identity(Path(name))
        assert actual['bytes'] == size and actual['sha256'] == digest
        driver_after.append(actual)
    write_new(evidence / 'drivers-after.json', driver_after)

    records = []
    executables = set()
    harness_pattern = re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s$', re.M)
    for label in LABELS:
        receipt_path = OUT / 'records' / (label + '.json')
        log_path = OUT / 'records' / (label + '.log')
        receipt = json.loads(receipt_path.read_text())
        assert receipt['schema'] == 'trnm-pq-native-command-v1'
        assert receipt['before'] == receipt['after'] == source
        actual = identity(log_path)
        assert actual['bytes'] == receipt['log_bytes'] and actual['sha256'] == receipt['log_sha256']
        text = log_path.read_text()
        harnesses = []
        active_package = None
        current_marker = None
        for line in text.splitlines():
            marker = re.match(r'^\s*Running unittests .* \((/[^)\n]+)\)\s*$', line)
            doc = re.match(r'^\s*Doc-tests ([A-Za-z0-9_-]+)\s*$', line)
            if marker:
                running = Path(marker[1])
                assert running.resolve().is_relative_to((OUT / 'target').resolve())
                active_package = running.name.rsplit('-', 1)[0].replace('_', '-')
                current_marker = line.strip()
            elif doc:
                active_package = doc[1].replace('_', '-')
                current_marker = line.strip()
            match = harness_pattern.fullmatch(line.strip())
            if match:
                assert active_package is not None, 'unattributed test summary'
                row = match.groups()
                harnesses.append({'package': active_package, 'marker': current_marker,
                                  'summary_line': line.strip(), 'status': row[0],
                                  'passed': int(row[1]), 'failed': int(row[2]),
                                  'ignored': int(row[3]), 'measured': int(row[4]),
                                  'filtered': int(row[5]), 'seconds': float(row[6])})
        roster = [receipt['argv'][index + 1] for index, argument in enumerate(receipt['argv']) if argument == '-p']
        package_totals = []
        for package in roster:
            observed = [entry for entry in harnesses if entry['package'] == package]
            total = {'package': package, 'harness_count': len(observed),
                     'harness_observed': bool(observed)}
            for key in ['passed', 'failed', 'ignored', 'measured', 'filtered']:
                total[key] = sum(entry[key] for entry in observed) if observed else None
            package_totals.append(total)
        for name in re.findall(r'Running unittests .* \((/[^)\n]+)\)', text):
            path = Path(name)
            assert path.resolve().is_relative_to((OUT / 'target').resolve())
            executables.add(path)
        records.append({'label': label, 'argv': receipt['argv'], 'status': receipt['status'],
                        'exit_code': receipt['exit_code'], 'receipt': identity(receipt_path),
                        'log': actual, 'harnesses': harnesses, 'package_totals': package_totals})
    artifact_after = []
    for path in sorted(executables):
        with path.open('rb') as stream:
            assert stream.read(4) == b'\x7fELF'
        actual = identity(path)
        actual.update(identity_kind='post_run_file_observation', live_execution_pin=False)
        artifact_after.append(actual)
    write_new(evidence / 'native-artifacts-after.json', artifact_after)

    versions = {}
    for label, argv in [('rustc', ['rustc', '--version', '--verbose']),
                        ('cargo', ['cargo', '--version']),
                        ('openssl', [str(PROVIDER / 'bin/openssl'), 'version', '-a'])]:
        versions[label] = subprocess.check_output(argv, cwd=REPO, env=child_env, text=True)
    assert versions['rustc'].startswith('rustc 1.95.0 ') and versions['cargo'].startswith('cargo 1.95.0 ')
    assert versions['openssl'].startswith('OpenSSL 3.5.9 ')
    write_new(evidence / 'versions-after.json', versions)

    setup_records = []
    for name in ['setup-summary.json', 'setup-connected-summary.json', 'setup-complete-summary.json', 'setup-objects-summary.json']:
        value = json.loads((OUT / name).read_text())
        assert value['candidate'] == B
        setup_records.append({'file': name, 'status': value['status'], 'commands': value['commands']})
    success = all(record['status'] == 'command_succeeded' and record['exit_code'] == 0 for record in records)
    summary = {'candidate': B, 'tree': TREE, 'host': 'ai395',
               'status': 'native_commands_passed' if success else 'native_commands_failed',
               'whole_chain_quantum_security_qualified': False,
               'source': source, 'native_command_count': len(records), 'records': records,
               'test_summary_accounting': 'Observed harness executions per package and command; never a unique-case union across configurations or phases.',
               'post_run_native_artifacts': artifact_after,
               'provider_identity_count': len(provider_after), 'driver_identity_count': len(driver_after),
               'terminal_observation_count': len(terminals['terminals']),
               'setup_records': setup_records,
               'sqlite_optional_hard_io_qualified': False,
               'sqlite_optional_hard_io_note': 'Observed UNQUALIFIED: RUSTC must be absolute. Ordinary Node/CMH2 tests do not confer this separate qualification.',
               'finished_utc': datetime.now(timezone.utc).isoformat()}
    write_new(evidence / 'native-summary.json', summary)

    files = []
    def add(path, name, origin):
        actual = identity(path)
        assert actual['bytes'] <= 32 * 1024 * 1024, 'bounded evidence member'
        files.append((path, name, origin, actual))
    for name in ['source-before.json', 'provider-identities.json', 'environment.json',
                 'setup-summary.json', 'setup-connected-summary.json', 'setup-complete-summary.json',
                 'setup-objects-summary.json', 'native-focused-summary.json', 'native-full-summary.json',
                 'native-clippy-summary.json', 'terminal-observations.json']:
        add(OUT / name, 'native/' + name, 'ai395')
    for directory in ['setup', 'setup-connected', 'setup-complete', 'setup-objects', 'records']:
        for path in sorted((OUT / directory).iterdir()):
            add(path, 'native/' + directory + '/' + path.name, 'ai395')
    for path in sorted(evidence.iterdir()):
        add(path, 'native/final/' + path.name, 'ai395')
    for name in DRIVER_PINS:
        add(Path(name), 'drivers/' + Path(name).name, 'ai395-controller-script')
    add(Path(__file__), 'drivers/' + Path(__file__).name, 'ai395-controller-script')
    terminal_root = Path('/home/qq/.local/state/hepta-runtime-mac-worker/terminals')
    for item in terminals['terminals']:
        session = item['session_id']
        role = item['role']
        assert re.fullmatch(r'dpty-[0-9a-f]{64}', session)
        assert re.fullmatch(r'[A-Za-z0-9_-]+', role)
        add(terminal_root / session / 'output.log', 'terminals/' + role + '-' + session + '.log', 'ai395')
    cloud = Path('/tmp/chain-hash-976f-cloud-b-observations.tar.gz')
    cloud_identity = identity(cloud)
    assert cloud_identity['bytes'] == 378819 and cloud_identity['sha256'] == 'bbc1785b2325a4bc6de2f92a6b84ed9a981b9cde61c1f08dc6d51ecd67e5e07d'
    add(cloud, 'cloud/chain-hash-976f-cloud-b-observations.tar.gz', 'cloud-separate-provenance')
    manifest = {'schema': 'chain-hash-b-validation-evidence-v1', 'candidate': B, 'tree': TREE,
                'members': [{'name': name, 'origin': origin, 'bytes': actual['bytes'], 'sha256': actual['sha256']}
                            for _, name, origin, actual in files],
                'manifest_excludes_its_own_hash': True,
                'whole_chain_quantum_security_qualified': False}
    manifest_path = evidence / 'MANIFEST.json'
    write_new(manifest_path, manifest)
    archive_path = OUT / 'native-b-observations.tar.gz'
    with tarfile.open(archive_path, 'x:gz') as archive:
        for path, name, _, actual in files:
            data = path.read_bytes()
            assert len(data) == actual['bytes'] and hashlib.sha256(data).hexdigest() == actual['sha256']
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o600
            archive.addfile(info, io.BytesIO(data))
        data = manifest_path.read_bytes()
        info = tarfile.TarInfo('MANIFEST.json')
        info.size = len(data)
        info.mode = 0o600
        archive.addfile(info, io.BytesIO(data))
    print(json.dumps({'archive': identity(archive_path), 'archive_members': len(files) + 1,
                      'native_command_count': len(records), 'status': summary['status'],
                      'summary': str(evidence / 'native-summary.json')}, sort_keys=True), flush=True)
    return 0 if success else 1


if __name__ == '__main__':
    raise SystemExit(main())
