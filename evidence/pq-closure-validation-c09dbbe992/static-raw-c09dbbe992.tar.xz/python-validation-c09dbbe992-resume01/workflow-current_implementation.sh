set -euo pipefail
python3 scripts/ci/w1_qrom_supplemental_controls.py --suite current \
  --repo-root "$GITHUB_WORKSPACE" --output-dir "$W1_QROM_OUT" \
  2>&1 | tee "$W1_QROM_OUT/current-controls.log"
python3 scripts/w1_qrom_current_implementation_audit.py --repo-root "$GITHUB_WORKSPACE" \
  --output "$W1_QROM_OUT/implementation-current.json" 2>&1 | tee "$W1_QROM_OUT/implementation-current.log"
