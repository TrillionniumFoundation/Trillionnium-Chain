import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
import traceback

PUB=Path('/home/qian-qi/work/chain-qrom-closure-publish-20261107')
PARENT=Path('/home/qian-qi/work/chain-qrom-closure-20261107-evidence')
OUT=PARENT/'publication-prepare-A-1e4bffc-v1'
BUNDLE=PARENT/'W1_QROM_native_fixes_1e4bffc371bc.bundle'
OLD='1a14f7d4826363daefac9ec10131c66d7e70ece7'
HEAD='1e4bffc371bcdc53aabc621b6b6cb2485ab36f53'
TREE='23c95cb4acfcfd2b1355d9d6e33c4c18b3f332a0'
BRANCH='fix/chain-w1-qrom-implementation-map-20261107'
REF='refs/heads/w1-qrom-native-A-1e4bffc371bc'
REPO='TrillionniumFoundation/Trillionnium-Chain'
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_TERMINAL_PROMPT='0',GIT_NO_LAZY_FETCH='1')
report={'schema':'TRNM-W1-PUBLICATION-PREPARE-A1','candidate':HEAD,'tree':TREE,'previous_publication_head':OLD,'commands':[],'exact_blob_downloads':[],'GitHub_push_performed':False,'native_clone_accessed':False,'complete_source_worktree_verified':False}
def require(value,message):
    if not value: raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data,usedforsecurity=False).hexdigest()
def save():
    (OUT/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
def run(label,args,check=True,timeout=180):
    started=time.monotonic()
    result=subprocess.run(args,cwd=PUB,env=ENV,capture_output=True,timeout=timeout)
    for suffix,data in [('stdout',result.stdout),('stderr',result.stderr)]:
        with (OUT/(label+'.'+suffix)).open('xb') as stream:stream.write(data)
    report['commands'].append({'label':label,'args':args,'exit_code':result.returncode,'seconds':time.monotonic()-started,'stdout_bytes':len(result.stdout),'stdout_sha256':sha(result.stdout),'stderr_bytes':len(result.stderr),'stderr_sha256':sha(result.stderr)})
    save();print(json.dumps({'stage':label,'exit_code':result.returncode}),flush=True)
    if check:require(result.returncode==0,label+' failed; exact logs retained')
    return result
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=PUB,env=ENV).decode().strip()
def contents(path,mode):
    if mode=='120000':
        require(path.is_symlink(),'expected symlink '+str(path));return os.fsencode(os.readlink(path))
    require(path.is_file() and not path.is_symlink(),'expected regular source '+str(path));return path.read_bytes()
def canonical_name(name):
    parts=Path(name).parts
    require(type(name) is str and name and not Path(name).is_absolute() and all(p not in ('','..','.','.git') for p in parts),'noncanonical source path')
def materialize(name,mode,oid):
    path=PUB/name
    try:data=contents(path,mode)
    except (FileNotFoundError,ValueError):data=None
    provider='existing-matching-publication-file'
    if data is None or blob(data)!=oid:
        p=subprocess.run(['git','--no-replace-objects','cat-file','blob',oid],cwd=PUB,env=ENV,capture_output=True)
        if p.returncode==0:data=p.stdout;provider='candidate-Git-object'
        else:
            require(len(report['exact_blob_downloads'])<32,'exact blob download count bound reached')
            r=run('github-blob-'+oid,['gh','api','repos/'+REPO+'/git/blobs/'+oid],timeout=120)
            v=json.loads(r.stdout)
            require(v.get('sha')==oid and v.get('encoding')=='base64' and type(v.get('size')) is int and 0<=v['size']<=16*1024*1024,'GitHub blob identity/size')
            data=base64.b64decode(v['content'].replace('\n',''),validate=True)
            require(len(data)==v['size'] and blob(data)==oid,'GitHub blob bytes')
            require(sum(x['bytes'] for x in report['exact_blob_downloads'])+len(data)<=32*1024*1024,'exact blob total bound reached')
            install=subprocess.run(['git','hash-object','-w','--stdin'],cwd=PUB,env=ENV,input=data,capture_output=True)
            require(install.returncode==0 and install.stdout.decode().strip()==oid,'install exact blob')
            report['exact_blob_downloads'].append({'path':name,'git_blob':oid,'bytes':len(data),'sha256':sha(data)})
            provider='authenticated-GitHub-exact-blob'
        require(blob(data)==oid,'candidate blob mismatch')
        current=PUB
        for part in Path(name).parts[:-1]:
            current=current/part;require(not current.is_symlink(),'source ancestor symlink');current.mkdir(exist_ok=True)
        if mode=='120000':
            if path.exists() or path.is_symlink():
                require(not path.is_dir(),'refuse directory replacement');path.unlink()
            os.symlink(os.fsdecode(data),path)
        else:
            require(not path.is_symlink(),'regular destination symlink')
            fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_NOFOLLOW,0o755 if mode=='100755' else 0o644)
            with os.fdopen(fd,'wb') as f:f.write(data)
            path.chmod(0o755 if mode=='100755' else 0o644)
    require(blob(contents(path,mode))==oid,'materialized source readback')
    if mode!='120000':require(bool(path.stat().st_mode&0o111)==(mode=='100755'),'source executable mode')
    return {'path':name,'mode':mode,'git_blob':oid,'bytes':len(data),'sha256':sha(data),'provider':provider}
try:
    payload=json.load(sys.stdin)
    require(PUB.resolve(strict=True)==PUB and str(PUB)!='/home/qian-qi/work/chain-qrom-local-20261107-7150','publication path identity')
    require(git('rev-parse','HEAD')==OLD and git('branch','--show-current')==BRANCH,'publication initial HEAD/branch')
    require(git('remote','get-url','origin') in {'https://github.com/'+REPO,'https://github.com/'+REPO+'.git','git@github.com:'+REPO+'.git'},'canonical origin')
    OUT.mkdir(mode=0o700)
    with (OUT/'executed-prepare-A.py').open('x') as f:f.write(payload['driver_source'])
    report['driver_sha256']=sha(payload['driver_source'].encode())
    initial=run('initial-status',['git','status','--porcelain=v1','-z','--untracked-files=all']).stdout
    for entry in initial.split(b'\0'):
        if entry:require(entry[:3]==b' D ' and entry[3:].startswith(b'evidence/'),'unexpected existing publication change')
    run('initial-preflight',['bash','scripts/project-preflight.sh','--dev'])
    raw=BUNDLE.read_bytes()
    require(len(raw)==2348492 and sha(raw)=='65835d8b22e2a506ace76a4adcae377499580ed72a0ad91ee7362f836a2a5084','A bundle identity')
    run('bundle-verify',['git','bundle','verify',str(BUNDLE)])
    require(run('bundle-heads',['git','bundle','list-heads',str(BUNDLE)]).stdout.decode().strip()==HEAD+' HEAD','bundle advertised HEAD')
    run('fetch-A',['git','fetch','--no-tags',str(BUNDLE),'HEAD:'+REF])
    require(git('rev-parse',REF)==HEAD and git('rev-parse',REF+'^{tree}')==TREE,'fetched A identity')
    run('old-is-ancestor',['git','merge-base','--is-ancestor',OLD,HEAD])
    run('normal-fast-forward-A',['git','-c','core.hooksPath=.githooks','merge','--ff-only',REF],timeout=240)
    require(git('rev-parse','HEAD')==HEAD and git('rev-parse','HEAD^{tree}')==TREE and git('branch','--show-current')==BRANCH,'fast-forward source identity')
    entries={}
    for raw_entry in subprocess.check_output(['git','ls-tree','-r','-z',HEAD],cwd=PUB,env=ENV).split(b'\0'):
        if not raw_entry:continue
        metadata,path=raw_entry.split(b'\t',1);mode,kind,oid=metadata.decode().split();name=path.decode()
        canonical_name(name);require(kind=='blob' and mode in ('100644','100755','120000'),'unsupported source type');entries[name]=(mode,oid)
    changed_raw=run('changed-paths-from-published',['git','diff','--name-only','--no-renames','-z',OLD,HEAD]).stdout
    changed={x.decode() for x in changed_raw.split(b'\0') if x}
    required={'evidence/pon-w1-qrom-implementation-20261107/upstream-sources.json.gz','evidence/pon-w1-full-v2-20261105/guest.bin'}
    selected={name for name in entries if not name.startswith('evidence/')}|(changed&set(entries))|required
    require(selected<=set(entries),'selected source absent from A tree')
    selected_rows=[materialize(name,*entries[name]) for name in sorted(selected)]
    (OUT/'selected-source-manifest.json').write_text(json.dumps(selected_rows,indent=2,sort_keys=True)+'\n')
    report['selected_source']={'files':len(selected_rows),'bytes':sum(x['bytes'] for x in selected_rows),'changed_present_paths':len(changed&set(entries)),'whole_source_claimed':False}
    status=run('actual-status-A',['git','status','--porcelain=v1','-z','--untracked-files=all']).stdout
    missing=[]
    for entry in status.split(b'\0'):
        if not entry:continue
        name=entry[3:].decode()
        require(entry[:3]==b' D ' and name.startswith('evidence/') and name not in selected,'unexpected source change after A preparation')
        missing.append(name)
    (OUT/'missing-historical-evidence.json').write_text(json.dumps(missing,indent=2)+'\n');report['missing_historical_evidence_count']=len(missing)
    results={}
    for label,args in [
      ('preflight-dev',['bash','scripts/project-preflight.sh','--dev']),
      ('preflight-audit',['bash','scripts/project-preflight.sh','--audit']),
      ('source-pin-check',['python3','scripts/ci/check_pq_research_integration.py']),
      ('generated-inventory-check',['python3','scripts/refresh_distributed_source_inventory.py','--check'])]:
        results[label]=run(label,args,check=False,timeout=300).returncode
    report['gate_exit_codes']=results
    complete=run('complete-source-check',['python3','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',HEAD,'--output',str(OUT/'complete-source.json')],check=False,timeout=300)
    report['complete_source_worktree_verified']=complete.returncode==0
    if complete.returncode:
        require(missing and b'source is not clean' in complete.stderr,'complete source failed beyond retained historical omissions')
    else:require(not missing,'successful complete source conflicts with omissions')
    require(git('rev-parse','HEAD')==HEAD and git('rev-parse','HEAD^{tree}')==TREE,'A source moved')
    report['prepared_for_independent_followup']=all(code==0 for code in results.values())
    report['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
    print(json.dumps({k:v for k,v in report.items() if k not in ('commands','exact_blob_downloads')}),flush=True)
    require(report['prepared_for_independent_followup'],'one or more A preparation gates failed; raw results retained')
except BaseException as error:
    report['error']=type(error).__name__+': '+str(error)
    if OUT.is_dir():
        save();(OUT/'failure-traceback.log').write_text(traceback.format_exc())
    raise
