#!/usr/bin/env python3
"""Keep compact, source-bound observations of already completed PQ CI matrices."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
report = json.loads((HERE / 'pq-system-original-artifact-summary.json').read_text())
poll = json.loads(sorted(HERE.glob('poll-[0-9]*.json'))[-1].read_text())
status = next(row for row in poll['summary'] if row['key'] == 'pq')
jobs = {row['job_id']: row for row in status['terminal']}
rows = []
for artifact in report['artifacts']:
    if artifact['is_pre_full_regression_snapshot']:
        continue
    name = artifact['artifact_name']
    arm = 'ubuntu-24.04-arm-' in name
    merge = artifact['source']['kind'] == 'prospective-merge'
    job_id = {
        (False, False): 127783767948,
        (False, True): 127783767681,
        (True, False): 127783768211,
        (True, True): 127783767813,
    }[(arm, merge)]
    assert job_id in jobs, 'A full artifact does not itself prove terminal job status'
    node = artifact['special_suites']['node-lib']
    final = node['libtest_results'][-1]
    assert final['filtered_out'] == 0
    row = {key: artifact[key] for key in [
        'artifact_id', 'artifact_url', 'artifact_name', 'archive_sha256',
        'archive_bytes', 'source', 'command_count', 'nonzero_commands',
    ]}
    row.update({
        'job_id': job_id,
        'job_url': f"https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42185197027/job/{job_id}",
        'job_conclusion': jobs[job_id]['conclusion'],
        'final_node_library_result': final,
        'node_command': node['argv'],
        'node_exit_code': node['exit_code'],
        'node_log_sha256': node['log_sha256'],
        'node_log_bytes': node['log_bytes'],
        'node_log_digest_verified': node['log_digest_verified'],
        'node_source_before_after_equal': node['source_before_after_equal'],
        'failed_selectors': node.get('native_failed_tests', []),
        'failure_excerpts': node.get('native_failure_excerpts', []),
        'clippy_exit': artifact['special_suites']['clippy']['exit_code'],
        'public_submit_recovery': artifact['special_suites']['public-submit-recovery']['libtest_results'][-1],
    })
    for label, key in [('native', 'required_native_controls'), ('tls', 'required_tls_controls'), ('scope', 'required_scope_controls')]:
        controls = artifact[key]
        row[label + '_required'] = len(controls)
        row[label + '_actually_passed'] = sum(
            item['execution']['executed_tests'] == 1 and
            item['execution']['result'] == 'PASS' and
            item['exit_code'] == 0 and
            (item.get('native_log_exactly_one_pass') is True if label != 'scope' else
             len(item['native_results']) == 1 and item['native_results'][0]['passed'] == 1 and
             item['native_results'][0]['failed'] == 0 and item['native_results'][0]['ignored'] == 0)
            for item in controls
        )
    rows.append(row)

result = {
    'schema': 'original-pq-available-terminal-counts-v1',
    'source_head': report['head'],
    'source_tree': report['tree'],
    'run_id': report['run_id'],
    'full_matrix_log_count': len(rows),
    'workflow_status': status['run_status'],
    'workflow_terminal_conclusion': status['run_conclusion'],
    'terminal_observed_utc': poll['observed_at_utc'],
    'matrices': rows,
    'interpretation': {
        'final_harness_summary_is_last_not_sum_of_child_harnesses': True,
        'controls_and_full_suite_overlap_do_not_add_as_unique_tests': True,
        'pending_matrices_have_no_acceptance_verdict': True,
        'old_9e50_failures_retained_separately': True,
        'production_tps_qualified': False,
    },
}
suffix = '-pending' if len(rows) == 4 and status['run_status'] != 'completed' else ''
out = HERE / f'pq-terminal-counts-{len(rows)}-matrices{suffix}.json'
raw = (json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode()
if out.exists():
    old = json.loads(out.read_text())
    assert old['matrices'] == rows and old['workflow_terminal_conclusion'] == status['run_conclusion'], 'Existing immutable snapshot differs'
    raw = out.read_bytes()
else:
    out.write_bytes(raw)
print(json.dumps({'path': str(out), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'matrices': len(rows)}))
