import hashlib,json,pathlib,subprocess,time,os,sys
c=json.load(sys.stdin)
assert sys.flags.optimize == 0
r=pathlib.Path('/home/qq/work/chain-cell-storage-convergence-f2568-20261109-native02');w=r.parent;prep=w/'chain-cell-storage-convergence-f2568-20261109-sealed-prep-01';o=prep/'model-execution-observation-03';o.mkdir(exist_ok=False)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'schema':'cell-sealed-research-native-attempt-observation-v1','scope':'real-model research execution on exact clean committed source; no ordinary Hepta FinalUse/M12/service qualification','started_unix':time.time(),'model_exit_code':None,'completed':False}
def save():
 p=o/'observation.json.pending';p.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');p.replace(o/'observation.json')
def run(name,args):
 p=subprocess.run(args,cwd=r,capture_output=True);(o/(name+'.stdout')).write_bytes(p.stdout);(o/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(name,p.stderr.decode());return p.stdout.decode().strip()
run('preflight',['bash','scripts/project-preflight.sh']);report['base_head']=run('head',['git','rev-parse','HEAD']);report['base_tree']=run('tree',['git','rev-parse','HEAD^{tree}']);report['status_before']=run('status-before',['git','status','--porcelain','--untracked-files=all']);assert report['base_head']==c['head'] and report['base_tree']==c['tree'] and not report['status_before']
build=pathlib.Path(c['build_summary']);assert H(build)==c['build_summary_sha256'];b=json.loads(build.read_text());assert b['passed'] and b['source_unchanged'] and b['provider_unchanged'] and not b['model_executed'];assert b['base_head']==b['final_head']==c['head'] and b['base_tree']==b['final_tree']==c['tree'] and not b['status_before'] and not b['status_after']
binary=pathlib.Path(b['binary']['path']);assert H(binary)==b['binary']['sha256']==c['binary_sha256'];report['binary_before']=b['binary']
manifest=prep/'source-inputs.attempt-03.v1.json';pin=c['manifest_sha256'];assert H(manifest)==pin;inputs=json.loads(manifest.read_text());assert not pathlib.Path(inputs['output']).exists();assert inputs['seconds']==300 and inputs['runtime_rss_bytes']==8589934592 and inputs['max_snapshot_bytes']==536870912 and inputs['threads']==4;assert inputs['operation']=='44e5dcf5e9ce62bdfeb12de88a8ec27e089db4a552cd5320d1a6f7ba3aa28cee';assert inputs['context']['runtime']=='e93bfc47f8055786f2088fc65f61c1f0d2482a0b8b4e5b8b9e30e8707fbb8c1b'
report['input']={'path':str(manifest),'sha256':pin,'operation':inputs['operation'],'output':inputs['output'],'seconds':inputs['seconds'],'runtime_rss_bytes':inputs['runtime_rss_bytes'],'max_snapshot_bytes':inputs['max_snapshot_bytes'],'threads':inputs['threads']};report['argv']=[str(binary),str(manifest),pin]
for name in ['OPENSSL_DIR','OPENSSL_STATIC','TRNM_PQ_OPENSSL','TRNM_PQ_OPENSSL_SHA256','TRNM_PQ_OPENSSL_VERSION','OPENSSL_CONF','OPENSSL_MODULES']:assert os.environ.get(name)==b['provider_before']['exports'][name],name
openssl=pathlib.Path(os.environ['TRNM_PQ_OPENSSL']);assert H(openssl)==os.environ['TRNM_PQ_OPENSSL_SHA256']
def source_snapshot():
 rows=[]
 for directory in ('trillionnium','scripts','config','.github'):
  for p in sorted((r/directory).rglob('*')):
   if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':rows.append({'path':str(p.relative_to(r)),'sha256':H(p),'bytes':p.stat().st_size})
 return rows
before=source_snapshot();expected=json.loads((build.parent/'source-after.json').read_text());assert before==expected;(o/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');(o/'source-inputs.json').write_bytes(manifest.read_bytes());save()
with (o/'native.stdout').open('xb') as out,(o/'native.stderr').open('xb') as err:
 report['model_started_unix']=time.time();save();p=subprocess.run(report['argv'],cwd=prep,stdout=out,stderr=err)
report['model_exit_code']=p.returncode;report['model_ended_unix']=time.time();report['model_elapsed_seconds']=report['model_ended_unix']-report['model_started_unix']
for channel in ('stdout','stderr'):
 p=o/('native.'+channel);report[channel]={'path':str(p),'bytes':p.stat().st_size,'sha256':H(p)}
after=source_snapshot();(o/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');report['source_unchanged']=before==after;report['binary_unchanged']=H(binary)==b['binary']['sha256'];report['manifest_unchanged']=H(manifest)==pin;report['provider_binary_unchanged']=H(openssl)==os.environ['TRNM_PQ_OPENSSL_SHA256'];report['status_after']=run('status-after',['git','status','--porcelain','--untracked-files=all']);report['final_head']=run('head-after',['git','rev-parse','HEAD']);report['final_tree']=run('tree-after',['git','rev-parse','HEAD^{tree}']);report['committed_source_unchanged']=report['final_head']==c['head'] and report['final_tree']==c['tree'] and not report['status_after'];report['status_unchanged']=report['status_before']==report['status_after'];report['completed']=True;report['execution_succeeded']=report['model_exit_code']==0 and all(report[x] for x in ('source_unchanged','binary_unchanged','manifest_unchanged','provider_binary_unchanged','status_unchanged','committed_source_unchanged'));save();print(json.dumps({k:report[k] for k in ('model_exit_code','model_elapsed_seconds','execution_succeeded','source_unchanged','binary_unchanged','manifest_unchanged')}),flush=True);raise SystemExit(0 if report['execution_succeeded'] else 1)
