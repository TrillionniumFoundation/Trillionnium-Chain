#!/usr/bin/env python3
"""Preserve original fixture evidence and commit only the reviewed test repair."""
import ast,hashlib,importlib.util,io,json,os,re,sys,zipfile
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
BASE=Path('/home/qian-qi/work/sp27-02-e815');REPO=BASE/'chain'
FROZEN=BASE/'publish_chain_a6.py'
assert hashlib.sha256(FROZEN.read_bytes()).hexdigest()=='6eecdcbdf9ee91db3fe740e0f4b00873645d7c8d8a97e8ec68fd0b265ad0f9b8'
spec=importlib.util.spec_from_file_location('D',FROZEN);D=importlib.util.module_from_spec(spec);spec.loader.exec_module(D)
OUT=BASE/'chain-format-fixture-commit-v1';OUT.mkdir(mode=0o700)
env=os.environ.copy()
for k in ['GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']:env.pop(k,None)
env.update({'GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0','PYTHONDONTWRITEBYTECODE':'1','GH_HOST':'github.com'})
log=D.Ledger(OUT,env);status,error='FAILED',None
TARGET='scripts/ci/test_run_from_zero_native.py'
REL='research/sp2027/02_receiver_liveness/validation/format-fixture-20261112'
EXPECTED_BEFORE='d94052e5777392461da80c3470d08222cc72f14a0e82f9b477b9fcf0da3f870b'
EXPECTED_AFTER='bd208eb66ae8c301de55a67df19691f5b4c69eea2bbc84092ce6a25e35050f99'
CI_SHA='9d0b319d0857a93e64d495e13ca1b708e5d16fe0a7ffb6ae681e0245a4b29a59'
README="# Native formatting fixture repair: preserved validation records\n\nThis directory records a test-fixture defect and its local repair. It is not a new\nnative experiment, performance measurement, or scientific sample. The four\nSP27-02 CI batches and their original outcomes remain unchanged.\n\nThe [original failed CI job](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43131136331/job/130895274019)\nran from source ff35430d27eea56dd803e05aa6d48573e37ed4c9. Its complete log is retained\nverbatim, including errors beyond the fixture error identified here. No claim is\nmade that this is the only failure in the job or the complete CI set.\n\nThe production formatting-copy driver requires four explicit out-of-line test\nmodules. The older positive fixture created only fresh_challenge.rs. The retained\nlocal reproduction at evidence commit a6e79dfbfc30d829a8527d0546091d005ecdce06\ntherefore failed with FileNotFoundError for sp27_receiver_controls.rs.\n\n| Observation | Actual result |\n|---|---|\n| Original CI job log | Preserved without rewriting its historical test results |\n| Local targeted positive fixture before repair | 1 test; 1 error; exit 1 |\n| Local complete driver suite after repair | 149 tests; OK; exit 0 |\n\nThe only edited test method now creates four explicit, different byte fixtures and\ntheir corresponding #[path] declarations. It checks every staged module against\nits original bytes and verifies that all original files remain unchanged. The\nflattening negative control, missing-module negative control, and real-source\nmodule-coverage test remain unchanged. The production driver, native mechanism,\nHost contract, permission gates, four-second window, resources, and cancellation\ngates are unchanged. No ignored native selector was executed for this repair.\n\n[MANIFEST.json](MANIFEST.json) binds [records.zip](records.zip), every raw member,\nthe original CI source/run/job, the fixture source before and after the edit, and\nthe actual fail-before/pass-after receipts. The ZIP is a new preservation package;\nits member contents are the original captured bytes. It does not replace any\nolder archive, reader, result, or scientific batch.\n\nRun the byte-integrity check from this directory:\n\n~~~sh\npython3 verify_records.py\n~~~\n\nRun the complete current driver suite from the repository root:\n\n~~~sh\npython3 scripts/ci/test_run_from_zero_native.py\n~~~\n\nTo reproduce the old fixture failure, use an isolated checkout of\na6e79dfbfc30d829a8527d0546091d005ecdce06 and run:\n\n~~~sh\npython3 scripts/ci/test_run_from_zero_native.py BinarySelectionTests.test_format_copy_retains_out_of_line_module_and_original_bytes\n~~~\n\nThat historical command is expected to exit nonzero. The unit controls simulate\ncompiler and service processes where declared; their synthetic observations are\nnot promoted to native measurements. The mechanism conclusion remains UNKNOWN,\nand these local results do not claim that a later CI workflow is green.\n"
VERIFY="#!/usr/bin/env python3\n\"\"\"Verify preserved validation bytes; this does not rerun native experiments.\"\"\"\nimport hashlib,json,zipfile\nfrom pathlib import Path\nroot=Path(__file__).resolve().parent\nmanifest=json.loads((root/'MANIFEST.json').read_bytes())\narchive=root/manifest['archive']['path']\nraw=archive.read_bytes()\nassert len(raw)==manifest['archive']['bytes']\nassert hashlib.sha256(raw).hexdigest()==manifest['archive']['sha256']\nwith zipfile.ZipFile(archive) as z:\n    assert z.testzip() is None\n    assert sorted(z.namelist())==sorted(manifest['members'])\n    for name,expected in manifest['members'].items():\n        payload=z.read(name)\n        assert len(payload)==expected['bytes'],name\n        assert hashlib.sha256(payload).hexdigest()==expected['sha256'],name\nprint(json.dumps({'verified_archive':str(archive),'members':len(manifest['members']),\n                  'sha256':manifest['archive']['sha256'],'native_experiments':0}))\n"
child,child_tree=None,None
try:
    log.phase='RECONCILE_REVIEWED_FIXTURE'
    D.github_actor(log,'github-identity')
    for label,argv,expected in [
        ('head',['git','rev-parse','HEAD'],D.HEAD),
        ('tree',['git','rev-parse','HEAD^{tree}'],D.TREE),
        ('branch',['git','branch','--show-current'],D.BRANCH)]:
        raw,_=log.run('initial-'+label,argv)
        log.require(raw.decode().strip()==expected,'initial-'+label+'-matches')
    D.remote_head(log,D.HEAD,'remote-a6')
    D.read_pr(log,D.HEAD,'draft-pr-a6')
    diff,_=log.run('initial-diff',['git','diff','--name-only'])
    log.require(diff.decode().splitlines()==[TARGET],'only-reviewed-fixture-dirty')
    staged,_=log.run('initial-staged',['git','diff','--cached','--name-only'])
    log.require(staged==b'','initial-index-unmodified')
    untracked,_=log.run('initial-untracked',['git','ls-files','--others','--exclude-standard'])
    log.require(untracked==b'','no-unrelated-untracked-files')
    log.run('preflight-before-validation-package',['bash','scripts/project-preflight.sh'])
    old,_=log.run('parent-fixture-bytes',['git','show',D.HEAD+':'+TARGET])
    log.require(D.sha(old)==EXPECTED_BEFORE and D.sha((REPO/TARGET).read_bytes())==EXPECTED_AFTER,
                'reviewed-before-and-after-source-byte-pins')
    repair=BASE/'chain-format-fixture-repair-v1'
    result_raw=(repair/'RESULT.json').read_bytes()
    log.require(D.sha(result_raw)=='b78803ea7a062424527e87a6f0f2b810d46712fc02ffc8e925baba597f95a25d',
                'actual-fixture-repair-result-pin')
    result=json.loads(result_raw);log.require(result['status']=='SUCCESS','actual-local-repair-passed')
    manifest_raw=(repair/'FILES_MANIFEST.json').read_bytes()
    log.require(D.sha(manifest_raw)==result['files_manifest']['sha256'],'actual-repair-file-manifest-pin')
    repair_manifest=json.loads(manifest_raw)
    receipt_raw=(repair/'REPAIR_RECEIPT.json').read_bytes()
    log.require(D.sha(receipt_raw)=='a7ea7c6968d8ddac375e11d3fd654cb09ba033362edf488d30e0c7ac76a74fbf',
                'actual-local-fail-before-pass-after-pin')
    receipt=json.loads(receipt_raw)
    log.require(receipt['whole_suite_tests']==149 and receipt['whole_suite_after_passed'] is True
        and receipt['production_driver_changed'] is False and receipt['native_experiments_rerun']==0,
        'real-suite-scope')
    members={}
    for name,identity in repair_manifest['files'].items():
        p=PurePosixPath(name)
        log.require(not p.is_absolute() and '..' not in p.parts,'safe-original-record-name',name)
        path=repair/name
        log.require(not path.is_symlink() and D.file_identity(path)==identity,'original-local-record-byte-pin',name)
        members['local-repair/'+name]=path.read_bytes()
    members['local-repair/FILES_MANIFEST.json']=manifest_raw
    members['local-repair/RESULT.json']=result_raw
    ci_path=BASE/'root-extra-ci-ff354-20261112/130895274019-logs.stdout'
    ci=ci_path.read_bytes()
    log.require(len(ci)==211728 and D.sha(ci)==CI_SHA,'original-ci-job-log-byte-pin')
    log.require(b'FileNotFoundError' in ci and b'sp27_receiver_controls.rs' in ci
        and b'test_format_copy_retains_out_of_line_module_and_original_bytes' in ci,
        'original-ci-log-contains-related-fixture-failure')
    members['ci-original/job-130895274019.log']=ci
    job_raw,_=log.run('official-ci-job',['gh','api','repos/TrillionniumFoundation/Trillionnium-Chain/actions/jobs/130895274019'])
    run_raw,_=log.run('official-ci-run',['gh','api','repos/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43131136331'])
    job,run=json.loads(job_raw),json.loads(run_raw)
    log.require(job['id']==130895274019 and job['run_id']==43131136331
        and run['id']==43131136331 and run['head_sha']==D.BASE,
        'official-ci-source-run-job-binding')
    members['ci-original/job-130895274019.api.json']=job_raw
    members['ci-original/run-43131136331.api.json']=run_raw
    members['tools/repair_format_fixture_v1.py']=(BASE/'repair_format_fixture_v1.py').read_bytes()
    members['tools/package_format_fixture_commit_v1.py']=Path(__file__).read_bytes()
    package=OUT/'records.zip'
    with zipfile.ZipFile(package,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,raw in sorted(members.items()):
            info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(0o100444<<16)
            z.writestr(info,raw)
    package.chmod(0o444)
    with zipfile.ZipFile(package) as z:
        log.require(z.testzip() is None and sorted(z.namelist())==sorted(members),'complete-preservation-archive')
        for name,raw in members.items():log.require(z.read(name)==raw,'archive-member-byte-identical',name)
    package_manifest={
      'schema':'sp27-format-fixture-validation-records-v1',
      'archive':{'path':'records.zip',**D.file_identity(package)},
      'members':{name:{'bytes':len(raw),'sha256':D.sha(raw)} for name,raw in sorted(members.items())},
      'evidence_package_parent':D.HEAD,'executed_scientific_source':D.BASE,
      'original_ci':{'run_id':43131136331,'job_id':130895274019,'source_commit':D.BASE,
        'log_sha256':CI_SHA,'url':'https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43131136331/job/130895274019'},
      'fixture_before_sha256':EXPECTED_BEFORE,'fixture_after_sha256':EXPECTED_AFTER,
      'observations':{'local_targeted_before':{'tests':1,'errors':1,'exit_code':1},
                      'local_entire_suite_after':{'tests':149,'exit_code':0,'result':'OK'}},
      'original_results_rewritten':False,'raw_member_bytes_modified':False,
      'native_experiments':0,'scientific_samples':0,'production_driver_changed':False,
      'mechanism_conclusion':'UNCHANGED_UNKNOWN',
      'source_scope':'Only the existing positive format-copy test fixture changed; historical source/raw batches remain intact.'}
    directory=REPO/REL
    log.require(not directory.exists(),'new-private-validation-directory')
    log.run('preflight-before-private-validation-write',['bash','scripts/project-preflight.sh'])
    directory.mkdir(parents=True)
    D.write_new(directory/'records.zip',package.read_bytes())
    D.json_new(directory/'MANIFEST.json',package_manifest)
    D.write_new(directory/'README.md',README.encode())
    D.write_new(directory/'verify_records.py',VERIFY.encode())
    log.run('actual-archive-verification',['python3',REL+'/verify_records.py'])
    log.run('diff-check-before-stage',['git','diff','--check'])
    allowed=[TARGET]+[REL+'/'+n for n in ['MANIFEST.json','README.md','records.zip','verify_records.py']]
    log.run('preflight-before-stage',['bash','scripts/project-preflight.sh'])
    log.run('stage-only-reviewed-source-and-original-records',['git','add','--',*allowed])
    staged,_=log.run('exact-staged-paths',['git','diff','--cached','--name-only'])
    log.require(sorted(staged.decode().splitlines())==sorted(allowed),'no-other-staged-path')
    identities={}
    for path in allowed:
        raw,_=log.run('staged-byte-'+str(len(identities)),['git','show',':'+path])
        actual=(REPO/path).read_bytes()
        log.require(raw==actual,'index-byte-identical-to-reviewed-working-file',path)
        identities[path]={'bytes':len(raw),'sha256':D.sha(raw)}
    log.run('staged-diff-check',['git','diff','--cached','--check'])
    log.run('preflight-staged',['bash','scripts/project-preflight.sh','--staged'])
    message=OUT/'COMMIT_MESSAGE.txt'
    D.write_new(message,b'test(ci): preserve all native format-copy fixtures\\n\\nRetain the failed original CI and local before/after controls.\\nThe complete patched Python driver suite passes 149 tests; no native experiment is rerun.\\n'.replace(b'\\n',b'\n'))
    log.phase='CREATE_REVIEWED_CHILD_COMMIT'
    log.run('commit-reviewed-fixture-and-records',['git','commit','--file',str(message)],timeout=300)
    raw,_=log.run('actual-child-head',['git','rev-parse','HEAD']);child=raw.decode().strip()
    raw,_=log.run('actual-child-tree',['git','rev-parse','HEAD^{tree}']);child_tree=raw.decode().strip()
    raw,_=log.run('actual-child-parents',['git','show','-s','--format=%P',child])
    log.require(raw.decode().strip()==D.HEAD,'exact-single-parent-is-a6')
    names,_=log.run('actual-child-paths',['git','diff-tree','--no-commit-id','--name-only','-r',child])
    log.require(sorted(names.decode().splitlines())==sorted(allowed),'child-changes-only-approved-paths')
    D.clean_state(log,child,child_tree,'final')
    D.remote_head(log,D.HEAD,'remote-still-a6-not-pushed')
    D.json_new(OUT/'COMMIT_RECEIPT.json',{
      'schema':'sp27-format-fixture-child-commit-v1','parent':D.HEAD,'head':child,'tree':child_tree,
      'actor':'ProfHepta','paths':identities,'native_experiments_rerun':0,'pushed':False,
      'original_ci_log_sha256':CI_SHA,'local_repair_result_sha256':D.sha(result_raw),
      'records_archive':D.file_identity(directory/'records.zip'),
      'records_manifest':D.file_identity(directory/'MANIFEST.json')})
    status='SUCCESS'
except BaseException as exc:
    error=type(exc).__name__+': '+str(exc);log.event({'kind':'stopped','error':error,'no_automatic_retry':True})
finally:
    log.event({'kind':'final-result','status':status,'error':error});log.handle.close()
    files={str(p.relative_to(OUT)):D.file_identity(p) for p in sorted(OUT.rglob('*')) if p.is_file()}
    D.json_new(OUT/'FILES_MANIFEST.json',{'files':files})
    D.json_new(OUT/'RESULT.json',{'schema':'sp27-format-fixture-commit-result-v1','status':status,'error':error,
      'phase':log.phase,'parent':D.HEAD,'head':child,'tree':child_tree,'files_manifest':D.file_identity(OUT/'FILES_MANIFEST.json'),
      'native_experiments_rerun':0,'external_writes':0,'pushed':False})
    print(json.dumps({'status':status,'error':error,'head':child,'tree':child_tree,
      'result':str(OUT/'RESULT.json'),'result_sha256':D.file_identity(OUT/'RESULT.json')['sha256']}),flush=True)
sys.exit(0 if status=='SUCCESS' else 1)

