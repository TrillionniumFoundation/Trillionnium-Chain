from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/9fe375f34217/chain-convergence')
OUT = Path('/workspace/scratch/9fe375f34217/local-validation-03')
HEAD = '75dc7ec3973ce3661c27c895418efd5c6cc8b4a8'
OUT.mkdir(exist_ok=False)
temporary = Path('/dev/shm/chain-seven-tests-9fe375f34217')
temporary.mkdir(exist_ok=True)
env = dict(os.environ, TMPDIR=str(temporary), PYTHONDONTWRITEBYTECODE='1')
source = ['scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', HEAD]
names = ['test_record_pq_native_command', 'test_chain_hepta_command_binding',
         'test_chain_hepta_qualification', 'test_w1_qrom_current_implementation_audit',
         'test_ci_contract', 'test_ci_source_integrity', 'check_ci_contract',
         'check_pq_research_integration', 'check_repository']
commands = [('source_before', source)]
commands += [(name, ['scripts/ci/' + name + '.py']) for name in names]
commands += [('current_mapping', ['scripts/w1_qrom_current_implementation_audit.py']),
             ('source_after', source)]
results = []
for name, args in commands:
    print('START', name, flush=True)
    start = time.monotonic()
    log = OUT / (name + '.log')
    argv = [sys.executable] + args
    with log.open('xb') as stream:
        try:
            code = subprocess.run(argv, cwd=ROOT, env=env, stdout=stream,
                                  stderr=subprocess.STDOUT, timeout=600).returncode
        except subprocess.TimeoutExpired:
            code = None
    results.append({'name': name, 'argv': argv, 'exit_code': code,
                    'elapsed_seconds': time.monotonic() - start,
                    'log': log.name, 'bytes': log.stat().st_size,
                    'sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
    report = {'source_commit': HEAD, 'source_tree': 'a58d215f954c1dee99ab7a031ff496e089499ba0',
              'all_commands_complete': len(results) == len(commands),
              'commands': results, 'native_tests_run': False,
              'status': 'HOLD_NO_GO',
              'repository_control_suite': 'separate desktop run; requires full disk copy'}
    (OUT / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
    print('DONE', name, 'exit', code, flush=True)
    if name == 'source_before' and code != 0:
        break
