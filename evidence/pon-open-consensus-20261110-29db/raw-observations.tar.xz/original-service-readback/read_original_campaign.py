#!/usr/bin/env python3
"""Read retained original CI evidence only; never execute a campaign or binary.

ZIP entries are streamed for CRC, SHA-256 and byte-count verification. Only an
explicit list of small, original metadata files is retained. Raw report objects
are parsed to derive counts and accounting identities; they are not replayed as
native consensus verification or treated as evidence for a different source.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile

ARCHIVE_BYTES = 83_560_661
ARCHIVE_SHA256 = "715587a56f595588c4eca4b36ba6e0a326b78e69078a4240cc878959e1f02cfe"
HEAD = "aaa3c53965bf0cf472e52451e205e9a020e834ab"
TREE = "fe3ce4c61bc2e3d477ea328b7742d0b2598282b3"
ARTIFACT_ID = 13761459229
RUN_ID = 42781760995
RUN_URL = f"https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/{RUN_ID}"
ARTIFACT_URL = f"https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/actions/artifacts/{ARTIFACT_ID}/zip"
SOURCE_PREFIX = f"https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/{HEAD}/"
MODES = ("baseline", "from-zero", "late-product")
REPORT_HASHES = (
    "b96c4e005020a21b6b517f4c23e8904d6309d33b6ba71dd725bf6dcb67a4db0e",
    "fb174b9ff583604cf71d2d134c67b8afac2712ed1e56a1ed30248e06f469dd51",
    "0cbb68b43030aa8fe138642037fd727d7e5fc2cba93617029494339b26eea175",
)
LIMITS = {"entries": 2_000, "entry_uncompressed_bytes": 64 * 1024 * 1024,
          "total_uncompressed_bytes": 1024 * 1024 * 1024,
          "small_retained_entry_bytes": 1024 * 1024}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique_object(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, f"duplicate JSON key: {key}")
        out[key] = value
    return out


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def store(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        require(path.read_bytes() == raw, f"refusing to replace differing retained evidence: {path}")
    else:
        with path.open("xb") as stream:
            stream.write(raw)


def store_json(path, value):
    store(path, (json.dumps(value, indent=2, sort_keys=True) + "\n").encode())


def cpu_delta(before, after):
    for name in ("user_cpu_ns", "system_cpu_ns"):
        require(after[name] >= before[name], "nonmonotonic reaped child CPU")
    return {name: after[name] - before[name] for name in ("user_cpu_ns", "system_cpu_ns")}


def source_receipt(value):
    require(value["tested_commit"] == HEAD and value["candidate"] == HEAD, "wrong source commit")
    require(value["tested_tree"] == TREE, "wrong source tree")
    require(value["kind"] == "head" and value["base"] is None
            and value["prospective_merge"] is None, "wrong source lane")
    require(value["tracked_worktree_verified"] is True, "unverified worktree receipt")


def phase_readback(run, phase, report, z, inventory):
    mode = phase["mode"]
    phase_path = f"run-{run}-raw/{mode}.json"
    require(decode(z.read(phase_path)) == phase, "standalone phase differs from report")
    require(phase["duration_seconds"] == 30, "phase deadline changed")
    require(phase["state_backend"] == "authenticated-v1", "wrong phase backend")
    requested = 0 if mode == "baseline" else 24
    require(phase["attacker_processes_requested"] == requested, "wrong attack count")
    require(phase["attacker_processes_ready"] == requested, "actors not ready")
    require(phase["observer_complete"] is True, "incomplete request observer")
    receiver = phase["receiver_observation"]
    require(receiver["records_not_retained"] == 0 and receiver["measurement_failures"] == 0
            and receiver["counter_overflow"] is False, "incomplete receiver observation")
    flags = ("cpu_intervals_are_nested_not_additive", "cpu_wait_is_outside_dispatch",
             "dispatch_cpu_includes_paid_body_decode", "dispatch_cpu_includes_response_signing",
             "phase_parent_links_are_inclusive", "submit_phase_cpu_excludes_scoped_workers")
    require(all(receiver[name] is True for name in flags), "changed nested CPU observation scope")
    records = receiver["records"]
    accepted = sum(row["full_work_accepted"] is True for row in records)
    failed = sum(row["full_work_accepted"] is False for row in records)
    require(accepted == phase["full_work_accepted"] and failed == phase["full_work_failed"],
            "receiver full-work counts differ")
    settled = 0
    for row in records:
        settlement = row.get("cpu_settlement")
        if settlement and settlement["budget_settled"]:
            require(settlement["interval_is_additive_to_dispatch_cpu"] is False,
                    "settlement unexpectedly additive")
            require(settlement["owner_cpu_known"] is True
                    and settlement["scoped_worker_cpu_known"] is True, "unknown settled CPU")
            require(settlement["owner_cpu_ns"] + settlement["scoped_worker_cpu_ns"]
                    == settlement["total_cpu_ns"], "settlement CPU identity mismatch")
            settled += 1

    children = phase["children"]
    require(len(children) == requested, "child report count mismatch")
    child_calls = []
    actor_successes = 0
    for child in children:
        actor = child["report"]
        result = actor["result"]
        successful = (child["exit_success"] is True and child["parent_forced_kill"] is False
                      and actor["error"] is None and result["attempt_cap_reached"] is False)
        actor_successes += successful
        child_calls.extend(result["calls"])
    require((actor_successes == requested) == phase["actor_reports_successful_without_cap_or_kill"],
            "actor success differs")

    confirms = phase["confirmations"]
    require([c["round"] for c in confirms] == list(range(len(confirms))), "round sequence mismatch")
    require(len(confirms) <= 3, "unexpected extra confirmation rounds")
    confirmation_rows = []
    for confirmation in confirms:
        observation = confirmation["observation"]
        inside = confirmation["confirmed_inside_pressure_window"] is True
        if inside:
            require(observation is not None and observation["confirmed"] is True,
                    "successful confirmation has no confirmed native observation")
            require(confirmation["ended_ns"] <= 30_000_000_000, "late confirmation marked inside")
            require(observation["depth"] >= 6
                    and int(observation["work_delta"], 16) >= int(observation["required_work_delta"], 16),
                    "confirmation lacks installed depth/work threshold")
            require(observation["included_block"] == confirmation["included_block"]
                    and observation["transaction"] == confirmation["transaction"], "confirmation identity mismatch")
            require(observation["execution_authority"] is False and observation["finalized"] is False,
                    "unexpected execution/finality authority")
        confirmation_rows.append({key: confirmation[key] for key in (
            "round", "started_ns", "ended_ns", "confirmed_inside_pressure_window",
            "paid_credit_depletion_observed_during_round", "receiver_hostile_work_rejected_during_round")}
            | {"native_observation_present": observation is not None,
               "native_observed_confirmed": observation is not None and observation["confirmed"] is True,
               "depth": observation["depth"] if observation else None,
               "work_delta": int(observation["work_delta"], 16) if observation else None,
               "required_work_delta": int(observation["required_work_delta"], 16) if observation else None})
    all_confirmed = len(confirms) == 3 and all(c["confirmed_inside_pressure_window"] is True for c in confirms)
    require(all_confirmed == phase["all_signed_rounds_confirmed_in_window"], "all-round confirmation mismatch")
    overlaps = [sum(call["started_ns"] < c["ended_ns"] and call["ended_ns"] > c["started_ns"]
                    for call in child_calls if call.get("started_ns") is not None and call.get("ended_ns") is not None)
                for c in confirms]
    require(overlaps == phase["attack_calls_overlapping_each_signed_round"], "actor-round overlap mismatch")

    service = phase["service_outcome"].get("Ok")
    require(service is not None, "missing service outcome")
    require(service["work_finished"] == accepted + failed
            and service["work_failed"] == failed, "service vs receiver full-work counters differ")
    require(service["mutation_cpu_charged_ns"] == service["mutation_dispatch_excluding_work_cpu_ns"]
            + service["mutation_full_work_cpu_ns"], "paid CPU partition mismatch")
    flow = phase["final_actual_flow"]
    require(flow["balance_identity_verified"] is True, "flow balance not verified")
    require(flow["initial_credit_ns"] + flow["credited_refill_ns"] - flow["paid_cpu_debit_ns"]
            == flow["remaining_paid_credit_ns"], "independent paid-credit balance mismatch")
    require(flow["paid_cpu_debit_ns"] == service["mutation_cpu_charged_ns"]
            == flow["settled_full_cpu_ns"], "settled/charged CPU mismatch")
    require(flow["live_owners"] == 0 and flow["booked_reservation_ns"] == 0
            and flow["unsettled_known_live_cpu_ns"] == 0, "unsettled final owners")
    samples = phase["budget_samples"]
    measured = [row["meter"]["Ok"] for row in samples if "Ok" in row.get("meter", {})]
    depletion_samples = sum(row["depleted"] is True for row in measured)
    require(len(measured) == len(samples), "missing paid-credit sample")
    depleted = phase["depletion_at_ns"] is not None
    require(depleted == phase["genuine_budget_depletion_observed"], "depletion flag mismatch")
    require(depleted == (depletion_samples > 0), "depletion flag vs samples mismatch")

    # The original exact-source predicate is retained in source-public_v3_multiprocess.rs.
    # Its root_mode is false for all original baseline/from-zero/late-product phases.
    common = (all_confirmed and phase["receiver_client_state_equal"]
              and phase["observer_complete"] and service["mutation_cpu_clock_failures"] == 0
              and phase["final_meter"]["in_flight"] == 0
              and phase["final_meter"]["accounting_unavailable"] is False
              and not phase["verifier_errors"])
    attack_criteria = (depleted and phase["attacker_processes_ready"] == 24
                       and actor_successes == requested and len(overlaps) == 3
                       and all(overlap > 0 for overlap in overlaps) and failed > 0
                       and accepted >= 21
                       and any(c["paid_credit_depletion_observed_during_round"] is True for c in confirms)
                       and all(c["receiver_hostile_work_rejected_during_round"] is True for c in confirms)
                       and all(call["status"] != "ok" for call in child_calls))
    criteria = bool(common and (mode == "baseline" or attack_criteria))
    require(criteria == phase["finite_phase_criteria_met"], "independent phase predicate mismatch")

    context = phase["phase_process_context"]
    controller = phase["external_controller_observation"]
    require(context["schema"] == "fixed-public-phase-external-actors-v1", "wrong phase placement")
    require(context["same_original_receiver_and_verifier_owners"] is True
            and context["attackers_launched_by_external_controller"] is True, "owner placement differs")
    require(context["independent_administration"] is False and context["wan_qualified"] is False,
            "unsupported administration or WAN qualification")
    require(context["runtime_business_deadline_changed"] is False
            and context["scalar_policy_changed"] is False, "changed original phase inputs")
    require(context["phase_cgroup"].startswith("/trnmponpublic.slice/")
            and context["controller_cgroup"].startswith("/system.slice/")
            and context["phase_cgroup"] != context["controller_cgroup"], "incorrect Host/controller separation")
    require(controller["launched"] == controller["reaped"] == requested
            and controller["host_launcher_process_exit"] == 0, "external launch/reap mismatch")
    contexts = controller["actual_attack_process_contexts"]
    require(len(contexts) == requested, "missing attacker cgroup contexts")
    require([c["ordinal"] for c in contexts] == list(range(requested)), "actor ordinal mismatch")
    require(all(c["actual_cgroup"] == "0::" + context["controller_cgroup"] for c in contexts),
            "attacker outside original controller cgroup")
    require({c["pid"] for c in contexts} == {c["pid"] for c in children}, "actor PID mismatch")
    host_before, host_after = context["host_before"], context["host_after"]
    counter_names = ("cpu_usage_usec", "cpu_nr_periods", "cpu_nr_throttled", "cpu_throttled_usec")
    host_deltas = {name: host_after[name] - host_before[name] for name in counter_names}
    require(all(v >= 0 for v in host_deltas.values()), "nonmonotonic Host counters")
    cpu = {
        "host_counter_scope": "/sys/fs/cgroup/trnmponpublic.slice aggregate, sampled before and after phase()",
        "host_deltas": host_deltas,
        "host_cpu_delta_ns": host_deltas["cpu_usage_usec"] * 1000,
        "whole_parent_phase_cpu_ns": phase["whole_parent_phase_cpu_ns"],
        "whole_parent_phase_wall_ns": phase["whole_parent_phase_wall_ns"],
        "receiver_and_verifier_setup_cpu_ns": phase["receiver_and_verifier_setup_cpu_ns"],
        "receiver_and_verifier_setup_wall_ns": phase["receiver_and_verifier_setup_wall_ns"],
        "paid_mutation_cpu_charged_ns": service["mutation_cpu_charged_ns"],
        "paid_mutation_dispatch_excluding_work_cpu_ns": service["mutation_dispatch_excluding_work_cpu_ns"],
        "paid_mutation_full_work_cpu_ns": service["mutation_full_work_cpu_ns"],
        "paid_body_decode_cpu_ns_nested_in_dispatch": service["mutation_body_decode_cpu_ns"],
        "paid_response_cpu_ns_nested_in_dispatch": service["mutation_response_cpu_ns"],
        "controller_reaped_children_delta": cpu_delta(phase["children_os_usage_before"], phase["children_os_usage_after"]),
        "controller_reaped_children_scope": controller["children_os_usage_scope"],
        "public_phase_reaped_children_delta": cpu_delta(phase["public_phase_children_os_usage_before"],
                                                         phase["public_phase_children_os_usage_after"]),
        "intervals_are_nested_not_additive": True,
        "host_throttled_time_is_not_additive_CPU_usage": True,
        "whole_phase_includes_setup_and_post_window_cleanup": True,
        "no_cost_amplification_ratio_derived": True,
    }

    submissions = phase["submissions"]
    require(len(submissions) <= report["preparation"]["business_blocks"], "too many business submissions")
    require([s["packet_index"] for s in submissions] == list(range(len(submissions))), "submission sequence mismatch")
    returned_ok = [s for s in submissions if s["status"] == "ok" and isinstance(s.get("response"), dict)
                   and s["response"].get("ok") is True]
    good_body_digests = {bytes(row["body_digest"]).hex() for row in records
                         if row["full_work_accepted"] is True and row.get("body_digest") is not None}
    server_accepts_after_client_error = sum(s["status"] != "ok" and s["public_request_body_digest"] in good_body_digests
                                           for s in submissions)
    return {
        "run": run, "mode": mode, "raw_phase_path": phase_path,
        "raw_phase_sha256": inventory[phase_path]["sha256"],
        "raw_phase_matches_report": True,
        "finite_phase_criteria_met": criteria,
        "independently_recomputed_phase_predicate_matches": True,
        "planned_signed_rounds": 3, "planned_business_blocks": 21,
        "confirmation_records": len(confirms),
        "successful_individual_confirmations_inside_window": sum(c["confirmed_inside_pressure_window"] is True for c in confirms),
        "unstarted_confirmation_rounds": 3 - len(confirms),
        "confirmations": confirmation_rows,
        "honest_submission_attempts": len(submissions),
        "client_success_responses": len(returned_ok),
        "client_errors": sum(s["status"] != "ok" for s in submissions),
        "submissions_returned_after_window": sum(s["returned_after_window"] is True for s in submissions),
        "receiver_full_work_accepted": accepted, "receiver_full_work_failed": failed,
        "receiver_accepts_matched_to_client_errors": server_accepts_after_client_error,
        "receiver_request_records": len(records), "settled_request_cpu_identities_checked": settled,
        "history_calls": len(phase["history"]),
        "receiver_client_state_equal": phase["receiver_client_state_equal"],
        "attacker_processes_requested_ready_launched_reaped": requested,
        "actor_reports_successful_without_cap_or_kill": actor_successes == requested,
        "hostile_calls": len(child_calls), "hostile_client_success_responses": sum(c["status"] == "ok" for c in child_calls),
        "hostile_calls_overlapping_each_recorded_round": overlaps,
        "verifier_errors": phase["verifier_errors"],
        "genuine_budget_depletion_observed": depleted,
        "budget_samples_checked": len(samples), "depleted_budget_samples": depletion_samples,
        "terminal_mutation_cpu_refusals": service["mutation_cpu_refusals"],
        "final_actual_flow": flow, "cpu": cpu,
        "completion_observation": phase["completion_work_observation"],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    require(args.archive.stat().st_size == ARCHIVE_BYTES, "archive length mismatch")
    with args.archive.open("rb") as stream:
        actual_archive_hash = hashlib.file_digest(stream, "sha256").hexdigest()
    require(actual_archive_hash == ARCHIVE_SHA256, "archive SHA-256 mismatch")
    api = decode((args.out_dir / "github-artifact-metadata.json").read_bytes())
    artifact = next(a for a in api["artifacts"] if a["id"] == ARTIFACT_ID)
    require(artifact["digest"] == "sha256:" + ARCHIVE_SHA256
            and artifact["size_in_bytes"] == ARCHIVE_BYTES, "GitHub artifact metadata mismatch")
    require(artifact["workflow_run"]["id"] == RUN_ID
            and artifact["workflow_run"]["head_sha"] == HEAD, "GitHub run/head mismatch")
    with zipfile.ZipFile(args.archive) as z:
        infos = z.infolist()
        require(len(infos) <= LIMITS["entries"], "too many archive entries")
        require(len({i.filename for i in infos}) == len(infos), "duplicate ZIP entry")
        require(sum(i.file_size for i in infos) <= LIMITS["total_uncompressed_bytes"], "archive uncompressed limit")
        for info in infos:
            name = info.filename
            parts = PurePosixPath(name).parts
            require(name and not name.startswith("/") and ".." not in parts and "." not in parts
                    and str(PurePosixPath(name)) == name and re.fullmatch(r"[A-Za-z0-9._/-]+", name),
                    "unsafe or noncanonical archive path")
            require(not info.is_dir() and stat.S_IFMT(info.external_attr >> 16) in (0, stat.S_IFREG),
                    "nonregular archive member")
            require(not (info.flag_bits & 1), "encrypted ZIP entry")
            require(info.compress_type in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED), "unexpected ZIP compression")
            require(0 <= info.file_size <= LIMITS["entry_uncompressed_bytes"], "oversize archive member")
        manifest_bytes = z.read("artifact-files.json")
        manifest = decode(manifest_bytes)
        inventory = {}
        for row in manifest["files"]:
            require(set(row) == {"path", "bytes", "sha256"}, "unexpected manifest row schema")
            require(row["path"] not in inventory, "duplicate manifest path")
            require(type(row["bytes"]) is int and row["bytes"] >= 0
                    and re.fullmatch(r"[0-9a-f]{64}", row["sha256"]), "invalid manifest size/hash")
            inventory[row["path"]] = row
        require(set(inventory) == {i.filename for i in infos} - {"artifact-files.json"}, "manifest does not cover exact archive")
        observed = {}
        for info in infos:
            h = hashlib.sha256()
            size = 0
            with z.open(info) as stream:
                while block := stream.read(1024 * 1024):
                    size += len(block)
                    require(size <= LIMITS["entry_uncompressed_bytes"], "stream exceeded per-entry bound")
                    h.update(block)
            require(size == info.file_size, "ZIP decompressed byte count mismatch")
            observed[info.filename] = {"path": info.filename, "bytes": size, "sha256": h.hexdigest()}
            if info.filename in inventory:
                require(observed[info.filename] == inventory[info.filename], "manifest SHA/length mismatch: " + info.filename)
        print(f"PASS: ZIP/CRC and exact manifest checked for {len(infos)} entries / {sum(i.file_size for i in infos)} uncompressed bytes", flush=True)

        results = decode(z.read("results.json"))
        require(results["expected_head"] == HEAD and results["expected_tree"] == TREE
                and results["source_kind"] == "head", "wrong run source")
        require(results["toolchain"] == "1.95.0" and results["profile"] == "release"
                and results["state_backend"] == "authenticated-v1", "wrong run configuration")
        require(results["planned_complete_runs"] == 3 and len(results["attempts"]) == 3, "campaign count differs")
        require(results["original_inputs"] == {"attacker_processes": [0, 24, 24], "business_blocks": 21,
                "modes": list(MODES), "phase_seconds": 30, "seed_blocks": 4, "seed_transfers": 1024}, "original inputs differ")
        require(results["build"]["complete_success"] is True and results["build"]["returncode"] == 0, "build failed")
        require(results["finalization_failures"] == [], "finalization failures")
        source_names = sorted(n for n in inventory if re.fullmatch(r"(?:source-[a-z-]+|run-[1-3]-source-after)\.json", n))
        for name in source_names:
            source_receipt(decode(z.read(name)))
        source_receipt(results["source_after"])
        binary = results["binary"]
        require(observed[binary["retained"]]["sha256"] == binary["sha256_before"] == binary["sha256_after"]
                and observed[binary["retained"]]["bytes"] == binary["bytes"], "binary hash/length mismatch")
        require(observed["run-native-campaign.py"]["sha256"] == results["runner_sha256"], "runner hash mismatch")
        rows, campaigns = [], []
        for number, attempt in enumerate(results["attempts"], 1):
            require(attempt["number"] == number and attempt == decode(z.read(f"run-{number}-result.json")),
                    "individual result differs from top-level attempt")
            report_path = f"run-{number}-raw/report.json"
            require(observed[report_path]["sha256"] == attempt["report_sha256"] == REPORT_HASHES[number - 1],
                    "report hash mismatch")
            require(attempt["report_validation_failure"] is None and attempt["phase_startup_errors"] == [],
                    "report validation/startup failure")
            require(attempt["step"]["error"] is None and attempt["step"]["returncode"] == 101,
                    "not the retained finite-criteria failure")
            report = decode(z.read(report_path))
            require(report["schema"] == "native-public-v3-separate-process-campaign-v2", "report schema differs")
            require([p["mode"] for p in report["phases"]] == list(MODES), "report phase sequence differs")
            require(report["preparation"]["actual_signed_seed_transfers"] == 1024
                    and report["preparation"]["business_blocks"] == 21
                    and report["preparation"]["seed_blocks"] == 4, "preparation differs")
            for flag in ("production_candidate", "release_ready", "independent_operators", "wan_qualified",
                         "work_profile_qualified", "cryptographic_hardness_qualified"):
                require(report[flag] is False, "unsupported report qualification")
            phase_rows = [phase_readback(number, p, report, z, observed) for p in report["phases"]]
            criteria = report["economics_complete"] and all(p["finite_phase_criteria_met"] for p in phase_rows)
            require(criteria == report["finite_experiment_criteria_met"] == attempt["original_criteria_met"],
                    "campaign predicate mismatch")
            rows.extend(phase_rows)
            campaigns.append({"run": number, "report": observed[report_path], "criteria_met": criteria,
                              "returncode": attempt["step"]["returncode"],
                              "elapsed_ns": attempt["step"]["elapsed_ns"],
                              "economics_complete": report["economics_complete"]})
            print(f"PASS: run {number} report SHA, embedded/raw phase equality, counts and nested accounting checked", flush=True)

        summed = ("honest_submission_attempts", "client_success_responses", "client_errors",
                  "submissions_returned_after_window", "receiver_full_work_accepted", "receiver_full_work_failed",
                  "receiver_accepts_matched_to_client_errors", "receiver_request_records",
                  "settled_request_cpu_identities_checked", "history_calls", "confirmation_records",
                  "successful_individual_confirmations_inside_window", "unstarted_confirmation_rounds",
                  "hostile_calls", "hostile_client_success_responses", "budget_samples_checked", "depleted_budget_samples")
        totals = {key: sum(row[key] for row in rows) for key in summed}
        totals.update({"campaigns": len(campaigns), "campaign_criteria_met": sum(c["criteria_met"] for c in campaigns),
                       "phases": len(rows), "phase_criteria_met": sum(p["finite_phase_criteria_met"] for p in rows),
                       "planned_signed_rounds": sum(p["planned_signed_rounds"] for p in rows),
                       "planned_business_blocks": sum(p["planned_business_blocks"] for p in rows),
                       "genuine_budget_depletion_phases": sum(p["genuine_budget_depletion_observed"] for p in rows),
                       "native_verifier_deadline_error_phases": sum("PUBLIC_REQUEST_DEADLINE" in p["verifier_errors"] for p in rows),
                       "state_equal_phases": sum(p["receiver_client_state_equal"] for p in rows),
                       "attacker_processes_launched_reaped": sum(p["attacker_processes_requested_ready_launched_reaped"] for p in rows)})
        require(totals["campaign_criteria_met"] == 0 and totals["phase_criteria_met"] == 0, "0/3 or 0/9 claim differs")
        require(results["complete_success"] is False and results["failure"] == "ORIGINAL_THREE_RUN_CAMPAIGN_FAILED",
                "top-level campaign outcome differs")

        retained = ["artifact-files.json", "SCOPE.txt", "results.json", "hardware.json", "binary-before.json",
                    "resource-before-build.json", "resource-after-native.json", "run-native-campaign.py",
                    "rustc-version.txt", "cargo-version.txt"] + source_names
        for number in range(1, 4):
            retained.extend([f"run-{number}-result.json", f"run-{number}-raw/campaign-failure.json",
                             f"run-{number}.step.json", f"run-{number}.stdout.log", f"run-{number}.stderr.log",
                             f"run-{number}-resource-before.json", f"run-{number}-resource-after.json"])
        for name in retained:
            require(observed[name]["bytes"] <= LIMITS["small_retained_entry_bytes"], "retained metadata too large")
            store(args.out_dir / "original-small" / name, z.read(name))
        original_pins = {"artifact_url": ARTIFACT_URL, "run_url": RUN_URL, "source_head": HEAD, "source_tree": TREE,
                         "archive_bytes": ARCHIVE_BYTES, "archive_sha256": ARCHIVE_SHA256,
                         "manifest": observed["artifact-files.json"],
                         "reports": [observed[f"run-{i}-raw/report.json"] for i in range(1, 4)],
                         "retained_small_originals": [observed[n] for n in sorted(set(retained))],
                         "report_bytes_retained_in_git": False}
        store_json(args.out_dir / "original-pins.json", original_pins)
        summary = {
            "schema": "independent-original-service-artifact-readback-v1", "verdict": "PASS_READBACK_OF_FAILED_EXPERIMENT",
            "source_head": HEAD, "source_tree": TREE, "source_is_new_candidate": False,
            "run_url": RUN_URL, "artifact_url": ARTIFACT_URL,
            "archive": {"bytes": ARCHIVE_BYTES, "sha256": ARCHIVE_SHA256,
                        "entries": len(infos), "manifest_members": len(inventory),
                        "uncompressed_bytes": sum(i.file_size for i in infos),
                        "compressed_member_bytes": sum(i.compress_size for i in infos),
                        "largest_entry_bytes": max(i.file_size for i in infos), "applied_limits": LIMITS,
                        "names_unique_canonical_regular_unencrypted": True,
                        "all_CRCs_SHA256_lengths_checked": True, "manifest_exact_coverage": True},
            "source_receipts_checked": source_names, "binary": binary,
            "original_inputs": results["original_inputs"], "resources": results["expected_resources"],
            "public_phase_placement": results["public_phase_placement"],
            "hardware": {key: decode(z.read("hardware.json"))[key] for key in
                         ("cpu_models", "logical_cpu_count", "machine", "physical_resources_are_observations_not_reservations")},
            "campaigns": campaigns, "totals": totals, "phases": rows,
            "interpretation": [
                "0/3 campaign and 0/9 phase criteria are verified; they are not zero individual confirmations.",
                "6 individual confirmations succeeded in baseline phases. Attack phases did not produce an in-window confirmation.",
                "15 confirmation records exist for 27 scheduled rounds; 12 rounds were never reached. Do not report 6/15 as the scheduled-round success rate.",
                "Client responses, receiver full-work accepts, signed confirmation and complete phase criteria are distinct counters.",
                "No budget depletion was observed; the attack-phase original depletion condition also failed.",
                "The fixed public Host has a 25000/100000 CPU ceiling and 2 GiB ceiling; controller/attackers use the original 400000/100000 and 16 GiB ceilings. These are not reservations.",
                "Host CPU delta is the fixed parent cgroup aggregate, containing its descendants. Whole phase process CPU, setup and paid mutation CPU are nested scopes, never an additive total.",
                "Controller RUSAGE_CHILDREN covers reaped attacker processes and the Host launcher; it excludes the systemd-owned public phase process. Max child RSS is not simultaneous summed memory.",
                "Whole phase wall/CPU includes setup and cleanup outside the 30-second business window. Throttled microseconds are not CPU consumed.",
                "This is a readback of retained same-host x86_64 release-profile observations at the original head. It does not rerun native verification, establish causality for all delays, qualify the new candidate, or prove WAN/independent-operator service, hardness, finality or production activation.",
            ],
            "campaign_reexecuted": False, "retained_binary_executed": False,
        }
        store_json(args.out_dir / "summary.json", summary)
        table = ["| Run | Mode | Honest attempts | Client OK | Receiver work accepted | Work rejected | In-window confirmations / 3 planned | Phase criteria | Host CPU s | Parent phase CPU s |",
                 "|---:|---|---:|---:|---:|---:|---:|---|---:|---:|"]
        for row in rows:
            table.append(f"| {row['run']} | {row['mode']} | {row['honest_submission_attempts']} | {row['client_success_responses']} | {row['receiver_full_work_accepted']} | {row['receiver_full_work_failed']} | {row['successful_individual_confirmations_inside_window']}/3 | {str(row['finite_phase_criteria_met']).lower()} | {row['cpu']['host_cpu_delta_ns']/1e9:.6f} | {row['cpu']['whole_parent_phase_cpu_ns']/1e9:.6f} |")
        md = "# Independent readback of original service campaign\n\n"
        md += f"Original run: {RUN_URL}\n\nOriginal source: `{HEAD}`; tree `{TREE}`. This is not the new candidate.\n\n"
        md += f"Archive `{ARTIFACT_ID}`: {ARCHIVE_BYTES:,} bytes; SHA-256 `{ARCHIVE_SHA256}`.\n\n"
        md += f"Verified {len(infos):,} ZIP entries, {len(inventory):,} exact manifest members and {sum(i.file_size for i in infos):,} uncompressed bytes, including every CRC/SHA/length. Names, regular-file types and size ceilings were checked without unrestricted extraction.\n\n"
        md += "**Original criteria: 0/3 campaigns and 0/9 phases. Individual confirmations: 6/27 planned rounds, with 15 actual confirmation records and 12 unreached rounds.** All six successful confirmations were in baseline phases; every attack phase had zero.\n\n"
        md += "\n".join(table) + "\n\n"
        md += f"Honest submissions: {totals['honest_submission_attempts']} attempts, {totals['client_success_responses']} client success responses, {totals['receiver_full_work_accepted']} receiver full-work accepts. The three baseline final requests returned late client errors; two nevertheless matched accepted receiver observations. Hostile requests yielded {totals['receiver_full_work_failed']} receiver full-work rejections and zero hostile client success responses. All {totals['attacker_processes_launched_reaped']} attacker processes were launched and reaped; no actor hit its cap or required forced kill.\n\n"
        md += "## Scope and accounting\n\n" + "\n\n".join(summary["interpretation"][4:]) + "\n\n"
        md += "## Original report SHA-256\n\n" + "\n".join(f"- `run-{i}-raw/report.json`: `{h}`" for i, h in enumerate(REPORT_HASHES, 1)) + "\n\n"
        md += "The original manifest and small original metadata are in `original-small/`; `original-pins.json` records their exact hashes. The 166.7 MB of original reports remain in the pinned archive and were not copied into git. `summary.json` contains integer counters, confirmation outcomes and separate nested CPU scopes for every phase. No campaign or retained binary was executed.\n"
        store(args.out_dir / "summary.md", md.encode())
        print(json.dumps({"verdict": summary["verdict"], "totals": totals, "summary": str(args.out_dir / "summary.json")}, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
