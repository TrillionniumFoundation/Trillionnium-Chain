from pathlib import Path
import json,subprocess,time,resource,hashlib,traceback
base=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b');src=base/'source';out=base/'source-gates-2';out.mkdir(exist_ok=False)
commands=[
('preflight',['bash','scripts/project-preflight.sh']),
('applicability',['python3','-B','scripts/ci/check_applicability.py']),
('applicability-negatives',['python3','-B','scripts/ci/test_applicability.py']),
('w1-current-map-negatives',['python3','-B','-m','unittest','discover','-s','scripts/ci','-p','test_w1_lifetime_current_observation.py','-v']),
('pq-exact-source',['python3','-B','scripts/ci/check_pq_research_integration.py']),
('ci-contract',['python3','-B','scripts/ci/check_ci_contract.py']),
('whitespace',['git','diff','--check'])]
res={'schema':'chain-operation-source-gates-v2','stages':[],'production_changed_by_checks':False,'f0_qualified':False,'full_physical_cost_closed':False}
def snapshot():
 patch=subprocess.check_output(['git','diff','--binary'],cwd=src)
 paths=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=src).split(b'\0')
 added={p.decode():hashlib.sha256((src/p.decode()).read_bytes()).hexdigest() for p in paths if p}
 return {'tracked_patch_sha256':hashlib.sha256(patch).hexdigest(),'untracked_files':added}
before=snapshot();res['before']=before
for name,args in commands:
 t=time.monotonic();r0=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:
  p=subprocess.Popen(args,cwd=src,stdout=so,stderr=se);res['current']={'name':name,'pid':p.pid};(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');rc=p.wait()
 r1=resource.getrusage(resource.RUSAGE_CHILDREN)
 row={'name':name,'command':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':r1.ru_utime-r0.ru_utime,'child_system_cpu_seconds':r1.ru_stime-r0.ru_stime}
 res['stages'].append(row);(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(row),flush=True)
res.pop('current',None);res['after']=snapshot();res['source_unchanged']=res['before']==res['after'];res['all_passed']=all(r['exit_code']==0 for r in res['stages']) and res['source_unchanged']
(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res),flush=True)
