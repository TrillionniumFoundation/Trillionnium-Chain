#!/usr/bin/env python3
"""Create and validate an isolated C2 publish checkout; never push or alter C1."""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time
import traceback

SOURCE = Path('/home/qian-qi/work/chain-pq-closure-20261111-d4d2')
DEST = Path('/data/chain-pq-closure-20261111-d4d2-publish')
OUT = Path('/data/pq-closure-c2-publish-validation-0e554f36ff-d4d2')
BUNDLE = Path('/data/pq-closure-readiness-correction-0e554f36ff-d4d2.bundle')
BUNDLE_SHA = '5cf89adcb148ba338825626359fb8731104c1468931e474f72ae9da7667c884d'
C1 = 'c09dbbe9921da12db8bf7240a8a95a0e9a789e50'
C1_TREE = 'f15a7ee4a0f5455eaf965db01dcd49e02a5f22b6'
C2 = '0e554f36ffdde3053a5eb1756eb5e526b1935032'
C2_TREE = '753cdbad6714f00d8ccb9ddbb47f0fd71280ee62'
BRANCH = 'fix/chain-pq-closure-20261111-d4d2'
PROVIDER = Path('/home/qian-qi/chain-stark-route-validation-7e8b/provider-clippy-eeeaafbc742d-retry01/trnm-pq-provider-3.5.9.wUXuiklK/install')
CHANGED = ['config/pon/pq-cross-branch-corpus-v1.json',
           'scripts/ci/check_public_readiness_evidence.py',
           'scripts/ci/test_public_readiness_evidence.py']
GIT = ['/usr/bin/git', '--no-replace-objects', '--no-optional-locks', '-c', 'core.hooksPath=/dev/null']
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1',
           GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_SYSTEM='/dev/null', GIT_CONFIG_GLOBAL='/dev/null',
           GIT_TERMINAL_PROMPT='0', GIT_NO_LAZY_FETCH='1')
ENV['PATH'] = '/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin'
RECEIPTS = []


def now():
    return datetime.now(timezone.utc).isoformat()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def write(name, value):
    with (OUT / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def file_identity(path):
    path = Path(path)
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode), 'not a regular file: ' + str(path))
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    after = path.lstat()
    require((info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
            'file changed while hashing: ' + str(path))
    return {'path': str(path), 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode),
            'sha256': digest.hexdigest()}


def git(root, *args):
    return subprocess.check_output(GIT + ['-C', str(root), *args], env=ENV, timeout=120).decode().strip()


def identity(root, expected, expected_tree):
    require(root.is_dir() and not root.is_symlink() and root.resolve() == root, 'noncanonical repository')
    head = git(root, 'rev-parse', 'HEAD')
    tree = git(root, 'rev-parse', 'HEAD^{tree}')
    status = git(root, 'status', '--porcelain=v1', '--untracked-files=all')
    branch = git(root, 'branch', '--show-current')
    require(head == expected and tree == expected_tree and branch == BRANCH and not status,
            'repository source identity mismatch: ' + str(root))
    gd = Path(git(root, 'rev-parse', '--absolute-git-dir'))
    return {'path': str(root), 'commit': head, 'tree': tree, 'branch': branch, 'status': status,
            'HEAD_file': file_identity(gd / 'HEAD'), 'index_file': file_identity(gd / 'index')}


def source_equal(before, after):
    return before == after


def run(name, argv, cwd, *, timeout=900, required=True):
    record = {'name': name, 'argv': argv, 'cwd': str(cwd), 'started_utc': now(), 'timeout_seconds': timeout}
    write(name + '.started.json', record)
    print(json.dumps({'started': name, 'at': record['started_utc']}), flush=True)
    started = time.monotonic()
    with (OUT / (name + '.stdout.log')).open('xb') as stdout, (OUT / (name + '.stderr.log')).open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=cwd, env=ENV, stdout=stdout, stderr=stderr, start_new_session=True)
        timed_out = False
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                code = process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait()
    record.update({'finished_utc': now(), 'elapsed_seconds': time.monotonic() - started,
                   'exit_code': code, 'timed_out': timed_out,
                   'stdout': file_identity(OUT / (name + '.stdout.log')),
                   'stderr': file_identity(OUT / (name + '.stderr.log'))})
    record['passed'] = code == 0 and not timed_out
    if name == 'public-readiness-tests':
        log = (OUT / (name + '.stderr.log')).read_text()
        terminal = re.search(r'\n-{70}\nRan (\d+) tests in [0-9.]+s\n\nOK\n\Z', log)
        ids = re.findall(r'^test_\w+ \(__main__\.([^)]*)\) \.\.\. ok$', log, re.M)
        record['outer_tests'] = int(terminal[1]) if terminal else None
        record['success_ids'] = ids
        record['complete_71_without_skip'] = (terminal is not None and int(terminal[1]) == 71
                                               and len(ids) == len(set(ids)) == 71)
        record['passed'] = record['passed'] and record['complete_71_without_skip']
    write(name + '.receipt.json', record)
    RECEIPTS.append(record)
    print(json.dumps({'completed': name, 'exit_code': code, 'passed': record['passed']}), flush=True)
    if required:
        require(record['passed'], 'required command failed: ' + name)
    return record


def main():
    require(not os.path.lexists(DEST), 'publish checkout already exists; inspect instead of reusing')
    require(not os.path.lexists(OUT), 'validation output already exists; do not overwrite')
    original = identity(SOURCE, C1, C1_TREE)
    require(original['HEAD_file']['sha256'] == '9643173d0c4d672ec4e4c1d56426ad62363da89aa7e41fc1de5c8d33d9c9d14c'
            and original['index_file']['sha256'] == '4c4d7147a22fa098bc924995524a1c28f9d9a40e88150cfd3b082d02a2e0f12a',
            'original HEAD/index changed since initial read-only inspection')
    require(file_identity(BUNDLE)['sha256'] == BUNDLE_SHA and BUNDLE.stat().st_size == 25432, 'bundle identity mismatch')
    OUT.mkdir(mode=0o700)
    write('original-c1-before.json', original)
    write('input-bundle.json', file_identity(BUNDLE))
    write('runner-identity.json', file_identity(Path(__file__).resolve()))
    write('environment.json', {'created_utc': now(), 'uid': os.getuid(), 'gid': os.getgid(),
                              'python': sys.version, 'python_executable': sys.executable,
                              'uname': list(os.uname()),
                              'selected_environment': {k: ENV.get(k) for k in ['PATH','PYTHONDONTWRITEBYTECODE','GIT_OPTIONAL_LOCKS','GIT_NO_REPLACE_OBJECTS','GIT_CONFIG_NOSYSTEM','GIT_CONFIG_SYSTEM','GIT_CONFIG_GLOBAL','GIT_TERMINAL_PROMPT','GIT_NO_LAZY_FETCH','OPENSSL_CONF','OPENSSL_MODULES','OPENSSL_DIR','OPENSSL_STATIC','LD_LIBRARY_PATH','PYTHONPATH']}})
    try:
        run('source-preflight', ['/bin/bash', 'scripts/project-preflight.sh'], SOURCE)
        require(source_equal(original, identity(SOURCE, C1, C1_TREE)), 'source preflight changed original repo')
        origin = git(SOURCE, 'remote', 'get-url', 'origin')
        require(origin in {'https://github.com/TrillionniumFoundation/Trillionnium-Chain',
                           'https://github.com/TrillionniumFoundation/Trillionnium-Chain.git',
                           'git@github.com:TrillionniumFoundation/Trillionnium-Chain.git'}, 'noncanonical origin')
        run('clone-shared-full', GIT + ['clone', '--shared', '--no-checkout', '--branch', BRANCH,
                                      str(SOURCE), str(DEST)], Path('/data'))
        run('set-canonical-origin', GIT + ['-C', str(DEST), 'remote', 'set-url', 'origin', origin], DEST)
        run('materialize-c1', GIT + ['-C', str(DEST), 'checkout', BRANCH], DEST)
        run('new-checkout-preflight', ['/bin/bash', 'scripts/project-preflight.sh'], DEST)
        run('bundle-verify', GIT + ['-C', str(DEST), 'bundle', 'verify', str(BUNDLE)], DEST)
        run('bundle-import-c2', GIT + ['-C', str(DEST), 'fetch', '--no-tags', str(BUNDLE), C2], DEST)
        run('fast-forward-c2', GIT + ['-C', str(DEST), 'merge', '--ff-only', '--no-edit', C2], DEST)
        actual_changes = git(DEST, 'diff', '--name-only', C1, C2).splitlines()
        require(actual_changes == CHANGED, 'unexpected C2 changed paths')
        require(git(DEST, 'show', '-s', '--format=%P', C2) == C1, 'unexpected C2 parent')
        write('publish-c2-before.json', identity(DEST, C2, C2_TREE))
        write('object-sharing.json', {'alternates': (DEST / '.git/objects/info/alternates').read_text(),
                                      'original_c1_not_modified': True, 'changed_paths': actual_changes,
                                      'origin': origin, 'full_checkout_required': True})
        run('c2-preflight', ['/bin/bash', 'scripts/project-preflight.sh'], DEST)
        run('gnu-time-version', ['/usr/bin/time', '--version'], DEST)
        require('GNU' in (OUT / 'gnu-time-version.stdout.log').read_text(), 'actual GNU time missing')
        provider_files = ['bin/openssl','include/openssl/opensslv.h','include/openssl/configuration.h','lib/libcrypto.a','lib/libssl.a']
        write('provider-identity.json', {'prefix': str(PROVIDER), 'files': [file_identity(PROVIDER / p) for p in provider_files],
                                         'gnu_time': file_identity(Path('/usr/bin/time')),
                                         'python': file_identity(Path(sys.executable).resolve()),
                                         'scope': 'host dependency identity retained; this job runs Python/source gates, not Rust native workloads'})
        run('openssl-version', [str(PROVIDER / 'bin/openssl'), 'version', '-a'], DEST)
        source_args = ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', C2]
        run('source-before', source_args + ['--output', str(OUT / 'source-before.json')], DEST)
        for name, argv in [
            ('repository-truth', ['/usr/bin/python3', '-B', 'scripts/ci/check_repository.py']),
            ('distributed-inventory', ['/usr/bin/python3', '-B', 'scripts/ci/refresh_distributed_source_inventory.py', '--check']),
            ('corpus-integration', ['/usr/bin/python3', '-B', 'scripts/ci/check_pq_research_integration.py']),
            ('public-readiness-tests', ['/usr/bin/python3', '-B', 'scripts/ci/test_public_readiness_evidence.py']),
            ('patch-whitespace', GIT + ['-C', str(DEST), 'diff', '--check', C1, C2]),
        ]:
            run(name, argv, DEST, required=False)
        run('source-after', source_args + ['--output', str(OUT / 'source-after.json')], DEST)
        require((OUT / 'source-before.json').read_bytes() == (OUT / 'source-after.json').read_bytes(), 'C2 source snapshots differ')
        write('publish-c2-after.json', identity(DEST, C2, C2_TREE))
        write('original-c1-after.json', identity(SOURCE, C1, C1_TREE))
        require(source_equal(original, json.loads((OUT / 'original-c1-after.json').read_bytes())), 'original C1 changed')
        all_passed = all(row['passed'] for row in RECEIPTS)
        write('summary.json', {'schema': 'TRNM-C2-INDEPENDENT-PUBLISH-PREPARATION1', 'source': {'commit':C2,'tree':C2_TREE},
                                'source_checkout': str(SOURCE), 'publish_checkout': str(DEST),
                                'all_commands_passed': all_passed, 'original_c1_identity_unchanged': True,
                                'full_c2_source_before_after_equal': True, 'commands': RECEIPTS,
                                'push_performed': False, 'pr_edit_performed': False,
                                'native_c1_results_upgraded_to_c2': False, 'whole_chain_pq_qualified': False,
                                'production_activation': False, 'finished_utc': now()})
        require(all_passed, 'one or more validation commands failed; retain original results')
        print(json.dumps({'publish_ready': True, 'checkout':str(DEST),'output':str(OUT),'commit':C2,'tree':C2_TREE,'tests':71,'original_c1_unchanged':True}), flush=True)
    except BaseException as error:
        write('failure.json', {'error_type': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc(),
                               'finished_utc': now(), 'commands': RECEIPTS, 'push_performed':False})
        try:
            write('original-c1-after-failure.json', identity(SOURCE, C1, C1_TREE))
        except BaseException as source_error:
            write('original-c1-after-failure-error.json', {'error':str(source_error)})
        raise


if __name__ == '__main__':
    main()
