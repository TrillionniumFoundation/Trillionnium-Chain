#!/usr/bin/env python3
"""Run existing repository gates; retain every original command and return."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

base = Path('/workspace/scratch/2e04527a60e8/validation')
label = sys.argv[1]
if not label or '/' in label:
    raise SystemExit('one new output label required')
out = base / label
out.mkdir()
commands = [
    ('preflight', ['bash', 'scripts/project-preflight.sh']),
    ('corpus', ['python3', '-B', 'scripts/ci/check_pq_research_integration.py']),
    ('corpus-negative', ['python3', '-B', 'scripts/ci/test_pq_research_integration.py']),
    ('repository', ['python3', '-B', 'scripts/ci/check_repository.py']),
    ('repository-negative', ['python3', '-B', 'scripts/ci/test_repository.py']),
    ('boundary-negative', ['python3', '-B', 'scripts/ci/test_project_boundary.py']),
    ('source-integrity-negative', ['python3', '-B', 'scripts/ci/test_ci_source_integrity.py']),
    ('claim-guard', ['python3', '-B', 'scripts/ci/pq_chain_claim_guard.py']),
    ('claim-guard-negative', ['python3', '-B', 'scripts/ci/test_pq_chain_claim_guard.py']),
    ('ci-contract-negative', ['python3', '-B', 'scripts/ci/test_ci_contract.py']),
    ('inventory', ['python3', '-B', 'scripts/refresh_distributed_source_inventory.py', '--check']),
    ('format', ['cargo', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check']),
    ('cargo-metadata', ['cargo', 'metadata', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml', '--format-version', '1']),
]
rows = []
for name, argv in commands:
    path = out / (name + '.log')
    started = time.time()
    clock = time.monotonic()
    with path.open('xb') as stream:
        result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT)
    row = {
        'name': name,
        'argv': argv,
        'exit_code': result.returncode,
        'started_unix_seconds': started,
        'elapsed_seconds': time.monotonic() - clock,
        'log': path.name,
        'log_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    }
    rows.append(row)
    (out / (name + '.json')).write_text(json.dumps(row, indent=2) + '\n')
    print(json.dumps(row), flush=True)
(out / 'commands.json').write_text(json.dumps(rows, indent=2) + '\n')
raise SystemExit(1 if any(row['exit_code'] != 0 for row in rows) else 0)
