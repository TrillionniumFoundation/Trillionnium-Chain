use super::*;
use std::{
    sync::{atomic::AtomicUsize, Mutex},
    time::Instant,
};
use trnm_crypto_primitives::{sign_hex, signing_key_from_hex};
use trnm_protocol::pon_wire::Envelope;

fn open(path: &Path, settings: &Settings, authenticated: bool) -> Node {
    if authenticated {
        Node::open_with_authenticated_state(path, settings.clone(), 2).unwrap()
    } else {
        Node::open(path, settings.clone(), 2).unwrap()
    }
}
fn transfer(settings: &Settings, nonce: u64) -> Vec<u8> {
    let key =
        signing_key_from_hex(&hex::encode(hash(b"DEV-ONLY-KEY", &[&0_u64.to_le_bytes()]))).unwrap();
    let mut payload = development_public(nonce + 10).unwrap().to_vec();
    payload.extend(1_u64.to_le_bytes());
    let mut envelope = Envelope {
        network: settings.network(),
        sender: development_public(0).unwrap(),
        nonce,
        expiry: 10_000,
        fee_limit: 1_000_000,
        tag: 1,
        payload,
        signature: [0; 64],
    };
    envelope.signature = hex::decode(sign_hex(&key, &envelope.signing_digest().unwrap()))
        .unwrap()
        .try_into()
        .unwrap();
    envelope.encode().unwrap()
}
fn packet(node: &Node, parent: Hash, first: u64, count: u64, timestamp: u64, miner: u64) -> Packet {
    node.make(
        parent,
        (first..first + count)
            .map(|n| transfer(node.settings(), n))
            .collect(),
        development_public(miner).unwrap(),
        timestamp,
        4096,
    )
    .unwrap()
}
fn prepared(node: &Node, packet: &Packet) -> Box<PreparedExecution> {
    let lease = node.reserve_detached_execution().unwrap();
    let checked = WorkCheckedPacket::verify(packet.clone()).unwrap();
    match node
        .prepare_shared_admission(
            checked,
            lease,
            1000,
            &ExecutionControl::new(&|_| Ok(()), &()),
        )
        .unwrap()
    {
        PreparedSharedAdmission::Execute(value) => value,
        PreparedSharedAdmission::Existing(_) => panic!("new candidate must execute"),
        PreparedSharedAdmission::HeldForSnapshotCapacity { .. } => {
            panic!("small fixture must detach")
        }
    }
}
fn executed(node: &Node, packet: &Packet) -> ExecutedSharedAdmission {
    prepared(node, packet)
        .execute(&ExecutionControl::new(&|_| Ok(()), &()))
        .unwrap()
}
fn wrong_root(mut packet: Packet) -> Packet {
    packet.header.state[0] ^= 1;
    let (a, b) = maintenance();
    let prover = pon_work::PreparedTask::new(&a, &b).unwrap();
    for nonce in 0..4096 {
        packet.header.nonce = nonce;
        packet.proof = prover.prove(packet.header.challenge()).unwrap();
        if WorkCheckedPacket::verify(packet.clone()).is_ok() {
            return packet;
        }
    }
    panic!("real bounded W1 search exhausted");
}
fn bindings(node: &Node) -> u64 {
    let observed = node.native_history_arithmetic_observation();
    [
        "execution_parent_checked_apply",
        "execution_parent_rebuilt_tree",
        "execution_parent_full_root",
    ]
    .iter()
    .map(|key| observed["counters"][key].as_u64().unwrap())
    .sum()
}

fn assert_parent_not_extendable(node: &mut Node, child: &Packet) {
    let unknown = |result: Result<()>| {
        let error = result.unwrap_err();
        assert!(error.is(crate::ErrorCode::UnknownParent), "{error}");
        assert!(!error.requires_owner_stop());
    };
    let parent = child.header.parent;
    unknown(node.parent_height(parent).map(|_| ()));
    unknown(node.state_at(parent).map(|_| ()));
    unknown(
        node.make(
            parent,
            child.transactions.clone(),
            child.header.miner,
            child.header.timestamp,
            4096,
        )
        .map(|_| ()),
    );
    unknown(node.check_admission_context(child, 1000).map(|_| ()));
    // The actual child's complete W1 is valid. This refusal must therefore be
    // missing local parent authority, rather than a malformed child/proof.
    unknown(
        node.admit_work_checked(WorkCheckedPacket::verify(child.clone()).unwrap(), 1000)
            .map(|_| ()),
    );
    unknown(node.activate_observed(parent, 1000).map(|_| ()));
}

#[test]
fn parent_qualification_requires_committed_state_after_w1_and_m06() {
    for authenticated in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let producer_directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut producer = open(producer_directory.path(), &settings, authenticated);
        let parent = packet(&producer, settings.genesis(), 1, 1, 1001, 0);
        let parent_id = producer.admit(&parent, 1000).unwrap();
        let child = packet(&producer, parent_id, 2, 1, 1002, 0);
        let child_id = producer.admit(&child, 1000).unwrap();
        producer.activate_observed(child_id, 1000).unwrap();
        let reference = producer.read_active().unwrap();

        let mut node = open(directory.path(), &settings, authenticated);
        let original = node.stats().unwrap();
        let checked = WorkCheckedPacket::verify(parent.clone()).unwrap();
        assert_parent_not_extendable(&mut node, &child);
        assert_eq!(node.stats().unwrap(), original);

        let lease = node.reserve_detached_execution().unwrap();
        let preparation = match node
            .prepare_shared_admission(
                checked,
                lease,
                1000,
                &ExecutionControl::new(&|_| Ok(()), &()),
            )
            .unwrap()
        {
            PreparedSharedAdmission::Execute(value) => value,
            _ => panic!("new small parent must use the original detached execution"),
        };
        assert_parent_not_extendable(&mut node, &child);
        assert_eq!(node.stats().unwrap(), original);

        let mandatory = AtomicUsize::new(0);
        let outcome = preparation
            .execute(&ExecutionControl::new(
                &|point| {
                    if point == ExecutionProgress::AfterMandatory {
                        mandatory.fetch_add(1, Ordering::Relaxed);
                    }
                    Ok(())
                },
                &(),
            ))
            .unwrap();
        assert!(mandatory.load(Ordering::Relaxed) > 0);
        assert_parent_not_extendable(&mut node, &child);
        assert_eq!(node.stats().unwrap(), original);

        assert_eq!(
            node.commit_shared_admission(
                outcome,
                1000,
                &ExecutionControl::new(&|_| Ok(()), &()),
                None,
            )
            .unwrap(),
            parent_id
        );
        // A fully admitted fork parent is eligible even before activation. The
        // boundary is complete durable validation, not a requirement to mine
        // only the active branch or to promote a completed execution artifact.
        assert_eq!(node.active().unwrap().0, settings.genesis());
        assert_eq!(node.parent_height(parent_id).unwrap(), 1);
        assert!(node
            .check_admission_context(&child, 1000)
            .unwrap()
            .is_none());
        let built = packet(&node, parent_id, 2, 1, 1002, 0);
        assert_eq!(built.encode().unwrap(), child.encode().unwrap());
        assert_eq!(node.admit(&child, 1000).unwrap(), child_id);
        node.activate_observed(child_id, 1000).unwrap();
        assert_eq!(node.read_active().unwrap(), reference);
        let final_stats = node.stats().unwrap();
        drop(node);
        let reopened = open(directory.path(), &settings, authenticated);
        assert_eq!(reopened.read_active().unwrap(), reference);
        assert_eq!(reopened.stats().unwrap(), final_stats);
    }
}

#[test]
fn parent_qualification_survives_cancelled_write_and_restart() {
    for authenticated in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let producer_directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut producer = open(producer_directory.path(), &settings, authenticated);
        let parent = packet(&producer, settings.genesis(), 1, 1, 1001, 0);
        let parent_id = producer.admit(&parent, 1000).unwrap();
        let child = packet(&producer, parent_id, 2, 1, 1002, 0);
        let child_id = producer.admit(&child, 1000).unwrap();
        producer.activate_observed(child_id, 1000).unwrap();
        let reference = producer.read_active().unwrap();

        let mut node = open(directory.path(), &settings, authenticated);
        let original = node.stats().unwrap();
        let outcome = executed(&node, &parent);
        let outside = Mutex::new(
            Connection::open_with_flags(
                directory.path().join("native.sqlite"),
                rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY,
            )
            .unwrap(),
        );
        let delta_boundaries = AtomicUsize::new(0);
        let commit_boundaries = AtomicUsize::new(0);
        let control = |point| {
            if matches!(point, ExecutionProgress::PersistenceDelta { .. }) {
                delta_boundaries.fetch_add(1, Ordering::Relaxed);
            }
            if point == ExecutionProgress::BeforeDurableCommit {
                // These original checkpoints follow the real block INSERT and
                // delta traversal. A separate reader must still see no parent
                // row while this transaction can be rolled back.
                assert!(delta_boundaries.load(Ordering::Relaxed) > 0);
                let visible: u64 = outside
                    .lock()
                    .unwrap()
                    .query_row(
                        "SELECT COUNT(*) FROM blocks WHERE id IN (?,?)",
                        params![parent_id.as_slice(), child_id.as_slice()],
                        |row| row.get(0),
                    )
                    .unwrap();
                assert_eq!(visible, 0);
                commit_boundaries.fetch_add(1, Ordering::Relaxed);
                return Err(Error::new(crate::ErrorCode::PublicRequestCancelled));
            }
            Ok(())
        };
        let error = node
            .commit_shared_admission(outcome, 1000, &ExecutionControl::new(&control, &()), None)
            .unwrap_err();
        assert!(error.is(crate::ErrorCode::PublicRequestCancelled));
        assert!(!error.requires_owner_stop());
        assert_eq!(commit_boundaries.load(Ordering::Relaxed), 1);
        assert_parent_not_extendable(&mut node, &child);
        assert_eq!(node.stats().unwrap(), original);
        drop(outside);
        drop(node);

        let mut reopened = open(directory.path(), &settings, authenticated);
        assert_parent_not_extendable(&mut reopened, &child);
        assert_eq!(reopened.stats().unwrap(), original);
        // The cancelled candidate did not acquire a lasting parent capability,
        // poison the genuine child, or prevent a later full validation.
        assert_eq!(reopened.admit(&parent, 1000).unwrap(), parent_id);
        assert_eq!(reopened.admit(&child, 1000).unwrap(), child_id);
        reopened.activate_observed(child_id, 1000).unwrap();
        assert_eq!(reopened.read_active().unwrap(), reference);
    }
}

#[test]
fn native_m06_runs_without_writer_and_matches_held_owner_on_both_backends() {
    for authenticated in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let reference_directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let node = open(directory.path(), &settings, authenticated);
        let candidate = packet(&node, settings.genesis(), 1, 4, 1001, 0);
        let owner = Mutex::new(node);
        let before_bindings = bindings(&owner.lock().unwrap());
        let preparation = prepared(&owner.lock().unwrap(), &candidate);
        assert!(preparation.snapshot_payload_bytes > 0);
        assert!(preparation.snapshot_payload_bytes <= MAX_SNAPSHOT_PAYLOAD);
        let checked = AtomicUsize::new(0);
        let observer = Mutex::new(());
        let control = |point| {
            if matches!(
                point,
                ExecutionProgress::BeforeStateClone
                    | ExecutionProgress::BeforePrepare { .. }
                    | ExecutionProgress::BeforeCommitment
            ) {
                // Executor workers can call this concurrently. Serialize only
                // these observer probes so one observer is not mistaken for a
                // retained native writer by another observer's try_lock.
                let _probe = observer.lock().unwrap();
                owner
                    .try_lock()
                    .expect("M06 retained Node writer")
                    .public_head_metadata()
                    .unwrap();
                checked.fetch_add(1, Ordering::Relaxed);
            }
            Ok(())
        };
        let outcome = preparation
            .execute(&ExecutionControl::new(&control, &()))
            .unwrap();
        assert!(checked.load(Ordering::Relaxed) >= 6);
        let mut node = owner.lock().unwrap();
        if authenticated {
            assert_eq!(bindings(&node), before_bindings + 1);
        }
        let id = node
            .commit_shared_admission(
                outcome,
                1000,
                &ExecutionControl::new(&|_| Ok(()), &()),
                None,
            )
            .unwrap();
        node.activate_observed(id, 1000).unwrap();
        let mut reference = open(reference_directory.path(), &settings, authenticated);
        reference.admit(&candidate, 1000).unwrap();
        reference.activate_observed(id, 1000).unwrap();
        assert_eq!(
            node.read_active().unwrap(),
            reference.read_active().unwrap()
        );
        assert_eq!(
            node.packet(id).unwrap().encode().unwrap(),
            candidate.encode().unwrap()
        );
        assert_eq!(
            node.record(id).unwrap().work.bytes(),
            reference.record(id).unwrap().work.bytes()
        );
        drop(node);
        drop(owner);
        assert_eq!(
            open(directory.path(), &settings, authenticated)
                .read_active()
                .unwrap(),
            reference.read_active().unwrap()
        );
    }
}

#[test]
fn one_original_snapshot_lease_is_bounded_and_cannot_move_to_another_node() {
    let a = tempfile::tempdir().unwrap();
    let b = tempfile::tempdir().unwrap();
    let settings = Settings::development(Some(1)).unwrap();
    let node = open(a.path(), &settings, false);
    let other = open(b.path(), &settings, false);
    let lease = node.reserve_detached_execution().unwrap();
    assert!(node
        .reserve_detached_execution()
        .err()
        .unwrap()
        .is(crate::ErrorCode::PublicQueueBusy));
    let candidate = packet(&node, settings.genesis(), 1, 1, 1001, 0);
    let error = other
        .prepare_shared_admission(
            WorkCheckedPacket::verify(candidate).unwrap(),
            lease,
            1000,
            &ExecutionControl::new(&|_| Ok(()), &()),
        )
        .err()
        .unwrap();
    assert!(error.is(crate::ErrorCode::OwnerDetachedExecutionContext));
    drop(node.reserve_detached_execution().unwrap());
}

#[test]
fn completed_artifact_refuses_wrong_owner_reopen_and_late_owner_stop() {
    let a = tempfile::tempdir().unwrap();
    let b = tempfile::tempdir().unwrap();
    let settings = Settings::development(Some(1)).unwrap();
    let mut node = open(a.path(), &settings, true);
    let mut other = open(b.path(), &settings, true);
    let candidate = packet(&node, settings.genesis(), 1, 1, 1001, 0);
    let outcome = executed(&node, &candidate);
    assert!(other
        .commit_shared_admission(
            outcome,
            1000,
            &ExecutionControl::new(&|_| Ok(()), &()),
            None
        )
        .unwrap_err()
        .is(crate::ErrorCode::OwnerDetachedExecutionContext));
    let outcome = executed(&node, &candidate);
    drop(node);
    node = open(a.path(), &settings, true);
    assert!(node
        .commit_shared_admission(
            outcome,
            1000,
            &ExecutionControl::new(&|_| Ok(()), &()),
            None
        )
        .unwrap_err()
        .is(crate::ErrorCode::OwnerDetachedExecutionContext));
    let outcome = executed(&node, &candidate);
    node.mark_ordinary_public_service_epoch_unknown();
    assert!(node
        .commit_shared_admission(
            outcome,
            1000,
            &ExecutionControl::new(&|_| Ok(()), &()),
            None
        )
        .unwrap_err()
        .is(crate::ErrorCode::OwnerPublicServiceUncleanEpoch));
    assert!(node.packet(candidate.id().unwrap()).is_err());
    assert!(other.packet(candidate.id().unwrap()).is_err());
}

#[test]
fn current_clock_target_and_unsupported_owner_are_rechecked_after_m06() {
    let directory = tempfile::tempdir().unwrap();
    let settings = Settings::development(Some(1)).unwrap();
    let mut node = open(directory.path(), &settings, false);
    let candidate = packet(&node, settings.genesis(), 1, 1, 1001, 0);
    let outcome = executed(&node, &candidate);
    assert_eq!(
        node.commit_shared_admission(outcome, 0, &ExecutionControl::new(&|_| Ok(()), &()), None)
            .unwrap_err()
            .to_string(),
        "TIME_DEFERRED"
    );
    // Deliberate internal corruption control; callers have no such field access.
    let mut outcome = executed(&node, &candidate);
    outcome.admission.packet.header.target[0] ^= 1;
    assert_eq!(
        node.commit_shared_admission(
            outcome,
            1000,
            &ExecutionControl::new(&|_| Ok(()), &()),
            None
        )
        .unwrap_err()
        .to_string(),
        "TARGET"
    );
    let outcome = executed(&node, &candidate);
    node.enable_local_root_rejection_cache().unwrap();
    assert!(node
        .commit_shared_admission(
            outcome,
            1000,
            &ExecutionControl::new(&|_| Ok(()), &()),
            None
        )
        .unwrap_err()
        .is(crate::ErrorCode::OwnerDetachedExecutionUnsupported));
    assert!(node
        .reserve_detached_execution()
        .err()
        .unwrap()
        .is(crate::ErrorCode::OwnerDetachedExecutionUnsupported));
    assert!(node.packet(candidate.id().unwrap()).is_err());
}

#[test]
fn foreign_write_and_restore_cannot_reuse_original_database_epoch() {
    for authenticated in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = open(directory.path(), &settings, authenticated);
        let candidate = packet(&node, settings.genesis(), 1, 1, 1001, 0);
        let outcome = executed(&node, &candidate);
        let foreign = Connection::open(directory.path().join("native.sqlite")).unwrap();
        foreign
            .execute("INSERT INTO metadata VALUES('detached-fault',X'00')", [])
            .unwrap();
        foreign
            .execute("DELETE FROM metadata WHERE key='detached-fault'", [])
            .unwrap();
        let error = node
            .commit_shared_admission(
                outcome,
                1000,
                &ExecutionControl::new(&|_| Ok(()), &()),
                None,
            )
            .unwrap_err();
        assert!(error.is(crate::ErrorCode::StorageContext) && error.requires_owner_stop());
        assert!(node.packet(candidate.id().unwrap()).is_err());
        assert_eq!(node.read_active().unwrap().0, settings.genesis());
    }
}

#[test]
fn final_sqlite_writer_fence_rejects_write_and_restore_after_last_context_check() {
    for authenticated in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = open(directory.path(), &settings, authenticated);
        let candidate = packet(&node, settings.genesis(), 1, 1, 1001, 0);
        let outcome = executed(&node, &candidate);
        let foreign = Mutex::new(Connection::open(directory.path().join("native.sqlite")).unwrap());
        let seen = AtomicUsize::new(0);
        let control = |point| {
            if point == ExecutionProgress::BeforePersistence
                && seen.fetch_add(1, Ordering::Relaxed) == 1
            {
                // This is the final original control boundary immediately
                // before BEGIN IMMEDIATE, after fresh context checks finished.
                let foreign = foreign.lock().unwrap();
                foreign
                    .execute("INSERT INTO metadata VALUES('last-window',X'00')", [])
                    .unwrap();
                foreign
                    .execute("DELETE FROM metadata WHERE key='last-window'", [])
                    .unwrap();
            }
            Ok(())
        };
        let error = node
            .commit_shared_admission(outcome, 1000, &ExecutionControl::new(&control, &()), None)
            .unwrap_err();
        assert_eq!(seen.load(Ordering::Relaxed), 2);
        assert!(error.is(crate::ErrorCode::StorageContext) && error.requires_owner_stop());
        assert!(node.packet(candidate.id().unwrap()).is_err());
        assert_eq!(node.read_active().unwrap().0, settings.genesis());
    }
}

#[test]
fn legal_concurrent_append_revalidates_parent_and_preserves_competing_branch() {
    for authenticated in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = open(directory.path(), &settings, authenticated);
        let candidate = packet(&node, settings.genesis(), 1, 1, 1001, 0);
        let competing = packet(&node, settings.genesis(), 1, 1, 1002, 1);
        let outcome = executed(&node, &candidate);
        let competing_id = node.admit(&competing, 1000).unwrap();
        node.activate_observed(competing_id, 1000).unwrap();
        let id = node
            .commit_shared_admission(
                outcome,
                1000,
                &ExecutionControl::new(&|_| Ok(()), &()),
                None,
            )
            .unwrap();
        assert_eq!(id, candidate.id().unwrap());
        assert_eq!(node.read_active().unwrap().0, competing_id);
        assert_eq!(
            node.packet(id).unwrap().encode().unwrap(),
            candidate.encode().unwrap()
        );
    }
}

#[test]
fn detached_result_cannot_bypass_real_pending_reorganization() {
    for authenticated in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = open(directory.path(), &settings, authenticated);
        let candidate = packet(&node, settings.genesis(), 1, 1, 1001, 0);
        let competing = packet(&node, settings.genesis(), 1, 1, 1002, 1);
        let outcome = executed(&node, &candidate);
        let competing_id = node.admit(&competing, 1000).unwrap();
        let mut cut = |point: &str| {
            if point == "intent" {
                // A non-control fault retains a real unfinished intent. Typed
                // cancellation is now terminalized by its original owner and
                // is covered by the separate same-owner cancellation matrix.
                Err(Error::new(crate::ErrorCode::StoragePacket))
            } else {
                Ok(())
            }
        };
        assert!(node
            .activate_with_fault(competing_id, Some(&mut cut))
            .unwrap_err()
            .is(crate::ErrorCode::StoragePacket));
        let error = node
            .commit_shared_admission(
                outcome,
                1000,
                &ExecutionControl::new(&|_| Ok(()), &()),
                None,
            )
            .unwrap_err();
        assert_eq!(error.to_string(), "REORG_IN_PROGRESS");
        assert!(node.packet(candidate.id().unwrap()).is_err());
        // The original recovery, not this artifact, resolves that durable intent.
        node.activate_observed(competing_id, 1000).unwrap();
        assert_eq!(node.read_active().unwrap().0, competing_id);
    }
}

#[test]
fn real_w1_wrong_root_and_original_m06_cancellation_create_no_commit() {
    let directory = tempfile::tempdir().unwrap();
    let settings = Settings::development(Some(1)).unwrap();
    let node = open(directory.path(), &settings, true);
    let valid = packet(&node, settings.genesis(), 1, 4, 1001, 0);
    let invalid = wrong_root(valid.clone());
    let before_bindings = bindings(&node);
    assert_eq!(
        prepared(&node, &invalid)
            .execute(&ExecutionControl::new(&|_| Ok(()), &()))
            .err()
            .unwrap()
            .to_string(),
        "ROOT"
    );
    assert_eq!(bindings(&node), before_bindings + 1);
    let seen = AtomicUsize::new(0);
    let cancelled = prepared(&node, &valid).execute(&ExecutionControl::new(
        &|point| {
            if matches!(point, ExecutionProgress::BeforeApply { .. }) {
                seen.fetch_add(1, Ordering::Relaxed);
                Err(Error::new(crate::ErrorCode::PublicRequestDeadline))
            } else {
                Ok(())
            }
        },
        &(),
    ));
    assert!(cancelled
        .err()
        .unwrap()
        .is(crate::ErrorCode::PublicRequestDeadline));
    assert!(seen.load(Ordering::Relaxed) > 0);
    assert!(node.packet(valid.id().unwrap()).is_err());
    assert!(node.packet(invalid.id().unwrap()).is_err());
    assert_eq!(node.read_active().unwrap().0, settings.genesis());
    drop(node.reserve_detached_execution().unwrap());
}

#[test]
fn original_transaction_readback_rejects_trigger_corruption_and_rolls_back() {
    for authenticated in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = open(directory.path(), &settings, authenticated);
        let candidate = packet(&node, settings.genesis(), 1, 1, 1001, 0);
        let outcome = executed(&node, &candidate);
        node.db.execute_batch("CREATE TRIGGER detached_skip BEFORE INSERT ON deltas BEGIN SELECT RAISE(IGNORE); END;").unwrap();
        let error = node
            .commit_shared_admission(
                outcome,
                1000,
                &ExecutionControl::new(&|_| Ok(()), &()),
                None,
            )
            .unwrap_err();
        assert!(error.requires_owner_stop());
        assert!(node.packet(candidate.id().unwrap()).is_err());
        assert_eq!(node.read_active().unwrap().0, settings.genesis());
    }
}

#[test]
fn snapshot_payload_capacity_is_a_private_schedule_hint_and_preserves_control_errors() {
    let control = ExecutionControl::new(&|_| Ok(()), &());
    let mut state = State::new();
    for index in 0..2048 {
        state.insert(format!("bounded-{index:05}"), json_value("x".repeat(4094)));
    }
    assert!(
        matches!(payload_bytes(&state, &control).unwrap(), SnapshotPayload::HeldRequired { observed_bytes } if observed_bytes > MAX_SNAPSHOT_PAYLOAD)
    );
    // An identical-looking caller resource error is NOT authority to continue
    // in another schedule. Only the private counter result selects held M06.
    let error = payload_bytes(
        &state,
        &ExecutionControl::new(
            &|_| {
                Err(Error::new(
                    crate::ErrorCode::PublicExecutionSnapshotCapacity,
                ))
            },
            &(),
        ),
    )
    .unwrap_err();
    assert!(error.is(crate::ErrorCode::PublicExecutionSnapshotCapacity));
    assert_eq!(error.kind(), crate::ErrorKind::Capacity);
    assert!(!error.requires_owner_stop());
}

// The original buffered scan is an independent length/count reference. It is
// test-only and cannot select a second production scheduling policy.
fn buffered_payload_bytes(
    state: &State,
    control: &ExecutionControl<'_, Error>,
) -> Result<SnapshotPayload> {
    let mut total = 0usize;
    for (index, (key, value)) in state.iter().enumerate() {
        if index.is_multiple_of(256) {
            (control.progress)(ExecutionProgress::BeforeParentBinding)?;
        }
        let cell = canonical(value)?;
        total = total
            .checked_add(key.len())
            .and_then(|sum| sum.checked_add(cell.len()))
            .ok_or("PUBLIC_EXECUTION_SNAPSHOT_CAPACITY")?;
        if total > MAX_SNAPSHOT_PAYLOAD {
            return Ok(SnapshotPayload::HeldRequired {
                observed_bytes: total,
            });
        }
    }
    Ok(SnapshotPayload::Fits(total))
}

#[test]
fn snapshot_payload_count_keeps_exact_json_bytes_and_serialization_errors() {
    use serde::ser::SerializeSeq;
    use std::io::Write;

    let escaped: String = (0..=127).map(char::from).collect();
    let values = [
        serde_json::Value::Null,
        serde_json::json!(true),
        serde_json::json!(false),
        serde_json::json!(u64::MAX),
        serde_json::json!(i64::MIN),
        serde_json::json!(-0.0),
        serde_json::json!(1.25e-100),
        serde_json::json!(f64::MAX),
        serde_json::json!(escaped),
        serde_json::json!("a\"\\\n\t\r\u{0000}日本語é🦀"),
        serde_json::json!({"z": [], "a": {"β": [false, null, 3], "x": {}}}),
        serde_json::json!("x".repeat(4094)),
    ];
    for value in &values {
        assert_eq!(
            canonical_payload_length(value).unwrap(),
            canonical(value).unwrap().len()
        );
    }
    let nested = serde_json::json!({"outer": values, "keys": {"\n": "\"", "🦀": 17}});
    assert_eq!(
        canonical_payload_length(&nested).unwrap(),
        canonical(&nested).unwrap().len()
    );

    struct FailsAfterPrefix;
    impl Serialize for FailsAfterPrefix {
        fn serialize<S: serde::Serializer>(
            &self,
            serializer: S,
        ) -> std::result::Result<S::Ok, S::Error> {
            let mut seq = serializer.serialize_seq(None)?;
            seq.serialize_element("written before the original error")?;
            Err(serde::ser::Error::custom("snapshot serialization failure"))
        }
    }
    let original = canonical(&FailsAfterPrefix).unwrap_err();
    let counted = canonical_payload_length(&FailsAfterPrefix).unwrap_err();
    assert_eq!(counted.to_string(), original.to_string());
    assert_eq!(counted.kind(), original.kind());

    // Overflow cannot wrap into a small detached snapshot, and it does not
    // short-circuit a later serialization failure into a capacity verdict.
    let mut length = CanonicalPayloadLength(Some(usize::MAX - 1));
    length.write_all(&[0]).unwrap();
    assert_eq!(length.0, Some(usize::MAX));
    length.write_all(&[0]).unwrap();
    assert_eq!(length.0, None);
    length.write_all(&[]).unwrap();
    assert_eq!(length.0, None);
    let error = Error::from(serde_json::to_writer(&mut length, &FailsAfterPrefix).unwrap_err());
    assert_eq!(error.to_string(), original.to_string());
}

#[test]
fn snapshot_payload_count_preserves_exact_capacity_and_cancellation_boundaries() {
    let mut state = State::new();
    let mut remaining = MAX_SNAPSHOT_PAYLOAD - 1;
    while remaining > 0 {
        let key = format!("cell-{:05}", state.len());
        let bytes = remaining.min(key.len() + 4096);
        assert!(bytes >= key.len() + 2);
        state.insert(
            key.clone(),
            serde_json::json!("x".repeat(bytes - key.len() - 2)),
        );
        remaining -= bytes;
    }
    let control = ExecutionControl::new(&|_| Ok(()), &());
    for expected_bytes in MAX_SNAPSHOT_PAYLOAD - 1..=MAX_SNAPSHOT_PAYLOAD + 1 {
        let expected = buffered_payload_bytes(&state, &control).unwrap();
        assert_eq!(payload_bytes(&state, &control).unwrap(), expected);
        assert_eq!(
            expected,
            if expected_bytes <= MAX_SNAPSHOT_PAYLOAD {
                SnapshotPayload::Fits(expected_bytes)
            } else {
                SnapshotPayload::HeldRequired {
                    observed_bytes: expected_bytes,
                }
            }
        );
        let value = state.values_mut().next_back().unwrap();
        *value = serde_json::json!(format!("{}x", value.as_str().unwrap()));
    }
    for cancel_at in [0, 1, 3, 7, 8] {
        let observe =
            |scan: fn(&State, &ExecutionControl<'_, Error>) -> Result<SnapshotPayload>| {
                let calls = AtomicUsize::new(0);
                let progress = |point| {
                    assert_eq!(point, ExecutionProgress::BeforeParentBinding);
                    if calls.fetch_add(1, Ordering::Relaxed) == cancel_at {
                        Err(Error::new(crate::ErrorCode::PublicRequestCancelled))
                    } else {
                        Ok(())
                    }
                };
                let result = scan(&state, &ExecutionControl::new(&progress, &()));
                (
                    result.map_err(|error| {
                        (error.to_string(), error.kind(), error.requires_owner_stop())
                    }),
                    calls.load(Ordering::Relaxed),
                )
            };
        assert_eq!(observe(payload_bytes), observe(buffered_payload_bytes));
    }
    assert_eq!(
        payload_bytes(&State::new(), &control).unwrap(),
        SnapshotPayload::Fits(0)
    );
}

#[test]
fn admitted_custom_genesis_over_eight_mib_keeps_original_held_schedule_and_cpu_owner() {
    for authenticated in [false, true] {
        assert_custom_genesis_held_schedule_and_cpu_owner(authenticated);
    }
}

#[test]
fn authenticated_large_parent_original_schedule_supplementary_denominator() {
    assert_custom_genesis_held_schedule_and_cpu_owner(true);
}

#[test]
fn large_parent_root_arithmetic_keeps_current_sql_and_original_read_checkpoints() {
    for authenticated in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let mut settings = Settings::development(Some(1)).unwrap();
        for index in 0..2100 {
            settings.initial.insert(
                format!("fixture-large-parent:{index:04}"),
                json_value("x".repeat(4080)),
            );
        }
        let initial_root = settings.state_root(&settings.initial).unwrap();
        settings.genesis = hash(
            b"genesis",
            &[
                &settings.network(),
                &settings.parameters(),
                &initial_root,
                &settings.genesis_time().to_le_bytes(),
            ],
        );
        let node = open(directory.path(), &settings, authenticated);
        let original = node.read_active().unwrap();
        assert!(
            node.derived_commitment_status()
                .last
                .unwrap()
                .actual_payload_bytes
                > MAX_SNAPSHOT_PAYLOAD
        );
        assert_eq!(node.read_active().unwrap(), original);
        // Exercise the actual pre-COMMIT SQL readback on both current backends.
        node.check_active_before_commit().unwrap();
        node.check_active_before_commit().unwrap();
        let slot = node.slot().unwrap();

        // A current same-length canonical cell must still change the calculated
        // root after the full-root arithmetic entry has been warmed.
        node.db
            .execute_batch("SAVEPOINT changed_actual_state")
            .unwrap();
        node.db
            .execute(
                "UPDATE kv SET value=? WHERE slot=? AND key='fixture-large-parent:2099'",
                params![canonical(&json_value("y".repeat(4080))).unwrap(), slot],
            )
            .unwrap();
        let error = node.read_active().unwrap_err();
        assert_eq!(error.to_string(), "ROOT");
        assert!(error.requires_owner_stop());
        let error = node.check_active_before_commit().unwrap_err();
        assert_eq!(error.to_string(), "ROOT");
        assert!(error.requires_owner_stop());
        node.db
            .execute_batch("ROLLBACK TO changed_actual_state; RELEASE changed_actual_state")
            .unwrap();
        assert_eq!(node.read_active().unwrap(), original);

        // Current SQL type/canonical-byte checks still run before any root
        // arithmetic; an exact repair can use mathematical material again.
        node.db
            .execute_batch("SAVEPOINT malformed_actual_cell")
            .unwrap();
        node.db
            .execute(
                "UPDATE kv SET value='null' WHERE slot=? AND key='fixture-large-parent:2099'",
                [slot],
            )
            .unwrap();
        assert!(node.read_active().unwrap_err().requires_owner_stop());
        assert!(node
            .check_active_before_commit()
            .unwrap_err()
            .requires_owner_stop());
        node.db
            .execute_batch("ROLLBACK TO malformed_actual_cell; RELEASE malformed_actual_cell")
            .unwrap();
        assert_eq!(node.read_active().unwrap(), original);
        node.check_active_before_commit().unwrap();

        let mut checkpoints = 0usize;
        assert_eq!(
            node.read_active_with_progress(&mut || {
                checkpoints += 1;
                Ok(())
            })
            .unwrap(),
            original
        );
        // Include a row-scan checkpoint and the final boundary, not just the
        // entry callback. The callback identity must survive unchanged.
        assert!(checkpoints > 10);
        for stop in [1, 4, checkpoints] {
            let mut calls = 0usize;
            let error = node
                .read_active_with_progress(&mut || {
                    calls += 1;
                    ensure(calls != stop, "original-large-state-read-cancel")
                })
                .unwrap_err();
            assert_eq!(error.to_string(), "original-large-state-read-cancel");
            assert_eq!(calls, stop);
            assert_eq!(node.read_active().unwrap(), original);
        }
        drop(node);
        assert_eq!(
            open(directory.path(), &settings, authenticated)
                .read_active()
                .unwrap(),
            original
        );
    }
}

fn assert_custom_genesis_held_schedule_and_cpu_owner(authenticated: bool) {
    // Explicit independent test genesis, NOT a claimed history grown from the
    // installed default genesis. All original limits and assertions are shared.
    let directory = tempfile::tempdir().unwrap();
    let reference_directory = tempfile::tempdir().unwrap();
    let mut settings = Settings::development(Some(1)).unwrap();
    for index in 0..2100 {
        settings.initial.insert(
            format!("fixture-large-parent:{index:04}"),
            json_value("x".repeat(4080)),
        );
    }
    let initial_root = settings.state_root(&settings.initial).unwrap();
    settings.genesis = hash(
        b"genesis",
        &[
            &settings.network(),
            &settings.parameters(),
            &initial_root,
            &settings.genesis_time().to_le_bytes(),
        ],
    );
    let mut node = open(directory.path(), &settings, authenticated);
    let mut reference = open(reference_directory.path(), &settings, authenticated);
    let seed = packet(&node, settings.genesis(), 1, 1, 1001, 0);
    let parent = node.admit(&seed, 1000).unwrap();
    node.activate_observed(parent, 1000).unwrap();
    assert_eq!(reference.admit(&seed, 1000).unwrap(), parent);
    reference.activate_observed(parent, 1000).unwrap();
    let candidate = packet(&node, parent, 2, 4, 1002, 0);
    let before = node.read_active().unwrap();
    let actual_payload: usize = before
        .2
        .iter()
        .map(|(key, value)| key.len() + canonical(value).unwrap().len())
        .sum();
    assert!(actual_payload > MAX_SNAPSHOT_PAYLOAD);
    let lease = node.reserve_detached_execution().unwrap();
    let held = node
        .prepare_shared_admission(
            WorkCheckedPacket::verify(candidate.clone()).unwrap(),
            lease,
            1000,
            &ExecutionControl::new(&|_| Ok(()), &()),
        )
        .unwrap();
    let PreparedSharedAdmission::HeldForSnapshotCapacity {
        checked,
        observed_payload_bytes,
    } = held
    else {
        panic!("large native parent must select original held M06")
    };
    assert!(
        observed_payload_bytes > MAX_SNAPSHOT_PAYLOAD && observed_payload_bytes <= actual_payload
    );
    drop(checked);
    drop(node.reserve_detached_execution().unwrap());
    assert_eq!(node.read_active().unwrap(), before);
    let original = crate::ingress::public_v3::ServiceMutationCpuDomain::standalone();
    node.bind_public_service_cpu_domain(&original).unwrap();
    let arithmetic_before = node.authenticated_arithmetic.observation();
    let owner = Mutex::new(node);
    let end = Instant::now() + std::time::Duration::from_secs(10);
    // Inspect the exact shared scalar-CPU epoch without mutating credit.
    // Observations are optional diagnostics: a missing/unknown meter remains
    // unknown, and the original dispatch/unwrap still decides acceptance.
    let cpu_budget_before = original.observe().ok();
    let cpu_flow_before = original.observe_actual_flow().ok().flatten();
    let dispatch_start = Instant::now();
    let attempt = crate::ingress::dispatch_shared_with_metered_w1(
        &owner,
        crate::ingress::Request::Submit {
            packet: hex::encode(candidate.encode().unwrap()),
        },
        &original,
        &|| ensure(Instant::now() < end, "PUBLIC_REQUEST_DEADLINE"),
    );
    // Preserve the original acceptance assertion below, including its failure.
    // Previously the unwrap above panicked before the original arithmetic
    // evidence could be printed for >8 MiB parent state. Capture actual
    // post-dispatch accounting without retrying, increasing CPU credit, or
    // using an unmetered execution path.
    let elapsed_ns = dispatch_start.elapsed().as_nanos();
    let cpu_budget_after = original.observe().ok();
    let cpu_flow_after = original.observe_actual_flow().ok().flatten();
    let arithmetic_after = owner.lock().unwrap().authenticated_arithmetic.observation();
    let native_refused = attempt
        .as_ref()
        .is_ok_and(|outcome| outcome.native.is_err());
    let (unchanged_on_refusal, refusal_readback_error) = if attempt.is_err() || native_refused {
        // A null equality in the old observation concealed whether the
        // reason was a poisoned owner lock or a real native readback error.
        // The outer result can be Ok while its settled native outcome is Err.
        // Observe both refusal forms after the original operation and its CPU
        // settlement, without changing either result or retrying admission.
        // Keep the original failure and any actual readback error; unavailable
        // readback is unknown, never evidence that active state is unchanged.
        match owner.lock() {
            Ok(node) => match node.read_active() {
                Ok(actual) => (Some(actual == before), None),
                Err(error) => (None, Some(error.to_string())),
            },
            Err(_) => (None, Some("OWNER_LOCK_POISONED".to_owned())),
        }
    } else {
        (None, None)
    };
    println!(
        "{}",
        serde_json::json!({
            "schema": "native-large-parent-original-dispatch-diagnostic-v1",
            "authenticated_backend": authenticated,
            "complete_key_utf8_and_canonical_value_bytes": actual_payload,
            "observed_held_capacity_lower_bound_bytes": observed_payload_bytes,
            "dispatch_elapsed_ns": elapsed_ns.to_string(),
            "original_dispatch_result": attempt.as_ref().map(|_| "ok").map_err(ToString::to_string),
            "original_native_result": attempt.as_ref().ok().map(|outcome| outcome.native.as_ref().map(|_| "ok").map_err(ToString::to_string)),
            "active_state_unchanged_on_refusal": unchanged_on_refusal,
            "refusal_readback_error": refusal_readback_error,
            "refusal_readback_scope": "read-only observation after original native outcome and CPU settlement; neither result is changed",
            "cpu_budget_before": cpu_budget_before,
            "cpu_budget_after": cpu_budget_after,
            "actual_cpu_flow_before": cpu_flow_before,
            "actual_cpu_flow_after": cpu_flow_after,
            "arithmetic_before": &arithmetic_before,
            "arithmetic_after": &arithmetic_after,
            "measurement_scope": "actual original metered dispatch; observation after outcome, no alternative execution, refill or altered acceptance"
        })
    );
    // Stage comparisons are evidence on both success AND refusal. The former
    // placement after the strict unwrap suppressed the expensive-stage record
    // precisely on the original production-blocking CPU-budget failure.
    println!(
        "{}",
        serde_json::json!({"schema":"native-large-parent-arithmetic-stages-v1", "authenticated_backend":authenticated, "before":arithmetic_before, "after":arithmetic_after, "measurement_scope":"existing stage counters sampled outside the original paid CPU operation; no budget or schedule changes"})
    );
    // This remains the original strict business gate: a budget refusal is
    // still an actual failing native test, not a qualified success.
    let result = attempt.unwrap();
    println!(
        "{}",
        serde_json::json!({"schema":"native-large-parent-schedule-parity-v1", "authenticated_backend":authenticated, "genesis_fixture":"2100 explicitly seeded 4080-byte string cells; original native validator and one signed admitted seed block; not default-genesis historical growth", "genesis":hex::encode(settings.genesis()), "genesis_state_root":hex::encode(initial_root), "admitted_parent":hex::encode(parent), "complete_key_utf8_and_canonical_value_bytes":actual_payload, "early_capacity_observed_lower_bound_bytes":observed_payload_bytes, "original_cpu_receipt":result.cpu, "native_result":result.native.as_ref().map(|_|"ok").map_err(ToString::to_string), "host_qualified":false, "budget_depletion_demonstrated":false, "all_honest_service_qualified":false})
    );
    assert!(!result.cpu.accounting_unavailable);
    assert_eq!(result.cpu.started_workers, result.cpu.finished_workers);
    assert_eq!(result.cpu.started_workers, result.cpu.known_workers);
    assert!(result.cpu.total_cpu_ns.unwrap() > 0);
    let reply = result.native.unwrap();
    let id = candidate.id().unwrap();
    assert_eq!(reply["block"], hex::encode(id));
    assert_eq!(reference.admit(&candidate, 1000).unwrap(), id);
    reference.activate_observed(id, 1000).unwrap();
    let node = owner.lock().unwrap();
    assert!(node
        .public_service_cpu_domain()
        .unwrap()
        .shares_domain_with(&original));
    assert_eq!(original.observe().unwrap().in_flight, 0);
    assert_eq!(
        node.read_active().unwrap(),
        reference.read_active().unwrap()
    );
    assert_eq!(
        node.packet(id).unwrap().encode().unwrap(),
        candidate.encode().unwrap()
    );
    drop(node);
    drop(owner);
    assert_eq!(
        open(directory.path(), &settings, authenticated)
            .read_active()
            .unwrap(),
        reference.read_active().unwrap()
    );
}

fn process_cpu_ns() -> u64 {
    let stamp = rustix::time::clock_gettime(rustix::time::ClockId::ProcessCPUTime);
    u64::try_from(stamp.tv_sec)
        .unwrap()
        .checked_mul(1_000_000_000)
        .unwrap()
        .checked_add(u64::try_from(stamp.tv_nsec).unwrap())
        .unwrap()
}
fn rss_kib() -> u64 {
    let raw = fs::read_to_string("/proc/self/status").unwrap();
    raw.lines()
        .find(|line| line.starts_with("VmRSS:"))
        .unwrap()
        .split_whitespace()
        .nth(1)
        .unwrap()
        .parse()
        .unwrap()
}

#[test]
#[ignore = "explicit actual 1024-signed-transfer full-State snapshot/execution/commit cost; not a saturation campaign"]
fn detached_full_state_cost_uses_real_signed_history_and_reports_scope() {
    let directory = tempfile::tempdir().unwrap();
    let settings = Settings::development(Some(1)).unwrap();
    let mut node = open(directory.path(), &settings, true);
    let mut parent = settings.genesis();
    for block in 0..4 {
        let seed = packet(&node, parent, block * 256 + 1, 256, 1001 + block, 0);
        parent = node.admit(&seed, 1000).unwrap();
        node.activate_observed(parent, 1000).unwrap();
    }
    let candidate = packet(&node, parent, 1025, 1, 1010, 0);
    let checked = WorkCheckedPacket::verify(candidate.clone()).unwrap();
    let before_rss = rss_kib();
    let started = Instant::now();
    let cpu = process_cpu_ns();
    let lease = node.reserve_detached_execution().unwrap();
    let PreparedSharedAdmission::Execute(preparation) = node
        .prepare_shared_admission(
            checked,
            lease,
            1000,
            &ExecutionControl::new(&|_| Ok(()), &()),
        )
        .unwrap()
    else {
        panic!("new packet");
    };
    let prepare_cpu = process_cpu_ns() - cpu;
    let prepare_wall = started.elapsed().as_nanos();
    let keys = preparation.prior.len();
    let payload = preparation.snapshot_payload_bytes;
    let prepared_rss = rss_kib();
    let started = Instant::now();
    let cpu = process_cpu_ns();
    let outcome = preparation
        .execute(&ExecutionControl::new(&|_| Ok(()), &()))
        .unwrap();
    let execution_cpu = process_cpu_ns() - cpu;
    let execution_wall = started.elapsed().as_nanos();
    let executed_rss = rss_kib();
    let started = Instant::now();
    let cpu = process_cpu_ns();
    let id = node
        .commit_shared_admission(
            outcome,
            1000,
            &ExecutionControl::new(&|_| Ok(()), &()),
            None,
        )
        .unwrap();
    let commit_cpu = process_cpu_ns() - cpu;
    let commit_wall = started.elapsed().as_nanos();
    assert_eq!(id, candidate.id().unwrap());
    assert!(keys >= 1024 && payload > 0);
    // A separate real deep-copy observation AFTER the measured pipeline, so
    // this extra allocation does not warm the pipeline's earlier State clone.
    let clone_source = node.state_at(parent).unwrap();
    let clone_started = Instant::now();
    let clone_cpu = process_cpu_ns();
    let cloned = clone_source.clone();
    let clone_cpu = process_cpu_ns() - clone_cpu;
    let clone_wall = clone_started.elapsed().as_nanos();
    assert_eq!(cloned, clone_source);
    println!(
        "{}",
        serde_json::json!({"schema":"native-detached-full-state-cost-v1","actual_seed_transfers":1024,
        "actual_seed_blocks":4,"state_keys":keys,"canonical_key_value_bytes":payload,
        "one_snapshot_slot":true,"snapshot_payload_cap_bytes":MAX_SNAPSHOT_PAYLOAD,
        "prepare_process_cpu_ns":prepare_cpu,"prepare_wall_ns":prepare_wall,
        "execution_process_cpu_ns":execution_cpu,"execution_wall_ns":execution_wall,
        "commit_process_cpu_ns":commit_cpu,"commit_wall_ns":commit_wall,
        "separate_actual_state_clone_process_cpu_ns":clone_cpu,"separate_actual_state_clone_wall_ns":clone_wall,
        "rss_kib_before":before_rss,"rss_kib_prepared":prepared_rss,"rss_kib_executed":executed_rss,
        "scope":"one actual authenticated native Node; full signed history; per-stage whole-process CPU includes joined M06 workers; RSS snapshots include allocator retention and are not allocation attribution; snapshot/SQL still hold writer; no A03 or WAN throughput claim",
        "budget_depletion_demonstrated":false,"resource_fairness_qualified":false,"production_activation":false})
    );
}

fn held_parent_fixture(node: &Node, candidate: &Packet) -> HeldPreparedAdmission {
    HeldPreparedAdmission {
        checked: WorkCheckedPacket::verify(candidate.clone()).unwrap(),
        parent: node
            .check_admission_parent(candidate, &mut || Ok(()))
            .unwrap(),
        owner: Arc::clone(&node.detached_execution),
    }
}

#[test]
fn held_parent_continuation_checks_original_owner_epoch_and_current_clock() {
    for authenticated in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let other_directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = open(directory.path(), &settings, authenticated);
        let mut other = open(other_directory.path(), &settings, authenticated);
        let candidate = packet(&node, settings.genesis(), 1, 1, 1001, 0);
        let control = ExecutionControl::new(&|_| Ok(()), &());
        let prepared = held_parent_fixture(&node, &candidate);
        assert!(other
            .admit_held_prepared(prepared, 1000, &control, None)
            .unwrap_err()
            .is(crate::ErrorCode::OwnerDetachedExecutionContext));
        let prepared = held_parent_fixture(&node, &candidate);
        assert_eq!(
            node.admit_held_prepared(prepared, 0, &control, None)
                .unwrap_err()
                .to_string(),
            "TIME_DEFERRED"
        );
        let prepared = held_parent_fixture(&node, &candidate);
        let reads_before = node.native_history_arithmetic_observation();
        let foreign = Connection::open(directory.path().join("native.sqlite")).unwrap();
        foreign
            .execute(
                "INSERT INTO metadata VALUES('held-epoch-control',X'00')",
                [],
            )
            .unwrap();
        foreign
            .execute("DELETE FROM metadata WHERE key='held-epoch-control'", [])
            .unwrap();
        assert!(prepared.parent.epoch != Some(node.admission_state_epoch().unwrap()));
        let id = node
            .admit_held_prepared(prepared, 1000, &control, None)
            .unwrap();
        assert_eq!(id, candidate.id().unwrap());
        if authenticated {
            let after = node.native_history_arithmetic_observation();
            let reads = |value: &serde_json::Value| {
                value["stages"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .find(|row| row["stage"] == "state_at")
                    .unwrap()["totals"]["calls"]
                    .as_u64()
                    .unwrap()
            };
            assert!(
                reads(&after) > reads(&reads_before),
                "changed epoch must reconstruct the full current parent"
            );
        }
        assert!(other.packet(id).is_err());
        node.activate_observed(id, 1000).unwrap();
        assert_eq!(node.read_active().unwrap().0, id);
    }
}

#[cfg(target_os = "linux")]
#[path = "prepared_held_native_completion_tests.rs"]
mod native_completion_controls;

mod executed_deltas {
    use super::*;

    fn facts(node: &Node) -> BTreeMap<String, Vec<Vec<String>>> {
        let tables = node
            .db
            .prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
            .unwrap()
            .query_map([], |row| row.get::<_, String>(0))
            .unwrap()
            .collect::<rusqlite::Result<Vec<_>>>()
            .unwrap();
        tables
            .into_iter()
            .map(|table| {
                assert!(table
                    .bytes()
                    .all(|byte| byte.is_ascii_alphanumeric() || byte == b'_'));
                let mut statement = node.db.prepare(&format!("SELECT * FROM {table}")).unwrap();
                let columns = statement.column_count();
                let mut rows = statement
                    .query_map([], |row| {
                        (0..columns)
                            .map(|column| {
                                row.get::<_, rusqlite::types::Value>(column)
                                    .map(|value| format!("{value:?}"))
                            })
                            .collect::<rusqlite::Result<Vec<_>>>()
                    })
                    .unwrap()
                    .collect::<rusqlite::Result<Vec<_>>>()
                    .unwrap();
                rows.sort();
                (table, rows)
            })
            .collect()
    }

    fn original_rows(before: &State, after: &State) -> Vec<Delta> {
        // Literal complete canonical union is an independent write oracle.
        let keys: std::collections::BTreeSet<_> = before.keys().chain(after.keys()).collect();
        keys.into_iter()
            .filter_map(|key| {
                let a = before.get(key).map(canonical).transpose().unwrap();
                let b = after.get(key).map(canonical).transpose().unwrap();
                (a != b).then(|| (key.clone(), a, b))
            })
            .collect()
    }

    fn enlarged_settings() -> Settings {
        let mut settings = Settings::development(Some(1)).unwrap();
        // Explicit unchanged fixture cells, not a user-growth/service claim.
        for index in 0..512 {
            settings.initial.insert(
                format!("execution-delta-fixture:{index:04}"),
                serde_json::json!({"unchanged": index}),
            );
        }
        let root = settings.state_root(&settings.initial).unwrap();
        settings.genesis = hash(
            b"genesis",
            &[
                &settings.network(),
                &settings.parameters(),
                &root,
                &settings.genesis_time().to_le_bytes(),
            ],
        );
        settings
    }

    #[test]
    fn native_changed_rows_match_full_union_all_sql_held_owner_and_cold_reopen() {
        for authenticated in [false, true] {
            let directory = tempfile::tempdir().unwrap();
            let settings = enlarged_settings();
            let fast_path = directory.path().join("fast");
            let reference_path = directory.path().join("reference");
            let held_path = directory.path().join("held");
            let mut fast = open(&fast_path, &settings, authenticated);
            let mut reference = open(&reference_path, &settings, authenticated);
            let mut held = open(&held_path, &settings, authenticated);
            let candidate = packet(&fast, settings.genesis(), 1, 1, 1001, 0);
            let outcome = executed(&fast, &candidate);
            let expected = original_rows(&outcome.admission.prior, &outcome.admission.output.state);
            let union =
                state_merge::entries(&outcome.admission.prior, &outcome.admission.output.state)
                    .count();
            assert!(union > 512 && expected.len() < 10);
            assert_eq!(outcome.admission.execution_deltas.is_some(), authenticated);
            if let Some(changes) = &outcome.admission.execution_deltas {
                let actual: Vec<_> = changes
                    .iter()
                    .map(|change| {
                        (
                            String::from_utf8(change.key.clone()).unwrap(),
                            change.before.clone(),
                            change.after.clone(),
                        )
                    })
                    .collect();
                assert_eq!(actual, expected);
            }
            let mut original = executed(&reference, &candidate);
            original.admission.execution_deltas = None;
            let fast_steps = AtomicUsize::new(0);
            let reference_steps = AtomicUsize::new(0);
            let held_steps = AtomicUsize::new(0);
            let count = |counter: &AtomicUsize, point| {
                if matches!(point, ExecutionProgress::PersistenceDelta { .. }) {
                    counter.fetch_add(1, Ordering::Relaxed);
                }
                Ok(())
            };
            let id = fast
                .commit_shared_admission(
                    outcome,
                    1000,
                    &ExecutionControl::new(&|point| count(&fast_steps, point), &()),
                    None,
                )
                .unwrap();
            assert_eq!(
                reference
                    .commit_shared_admission(
                        original,
                        1000,
                        &ExecutionControl::new(&|point| count(&reference_steps, point), &()),
                        None
                    )
                    .unwrap(),
                id
            );
            assert_eq!(
                held.admit_work_checked_with_progress(
                    WorkCheckedPacket::verify(candidate).unwrap(),
                    1000,
                    &|point| count(&held_steps, point)
                )
                .unwrap(),
                id
            );
            assert_eq!(reference_steps.load(Ordering::Relaxed), union);
            let native_steps = if authenticated { expected.len() } else { union };
            assert_eq!(fast_steps.load(Ordering::Relaxed), native_steps);
            assert_eq!(held_steps.load(Ordering::Relaxed), native_steps);
            assert_eq!(fast.delta_rows(id).unwrap(), expected);
            assert_eq!(facts(&fast), facts(&reference));
            assert_eq!(facts(&fast), facts(&held));
            for node in [&mut fast, &mut reference, &mut held] {
                node.activate_observed(id, 1000).unwrap();
            }
            let final_state = fast.read_active().unwrap();
            let final_facts = facts(&fast);
            assert_eq!(final_facts, facts(&reference));
            assert_eq!(final_facts, facts(&held));
            drop((fast, reference, held));
            for path in [&fast_path, &reference_path, &held_path] {
                let reopened = open(path, &settings, authenticated);
                assert_eq!(reopened.read_active().unwrap(), final_state);
                assert_eq!(facts(&reopened), final_facts);
            }
        }
    }

    #[test]
    fn native_write_material_cannot_conceal_missing_extra_wrong_or_reordered_deltas() {
        for fault in ["missing", "extra", "before", "after", "order", "non_utf8"] {
            let directory = tempfile::tempdir().unwrap();
            let settings = Settings::development(Some(1)).unwrap();
            let mut node = open(directory.path(), &settings, true);
            let candidate = packet(&node, settings.genesis(), 1, 1, 1001, 0);
            let before = facts(&node);
            let active = node.read_active().unwrap();
            let mut outcome = executed(&node, &candidate);
            let changes = outcome.admission.execution_deltas.as_mut().unwrap();
            assert!(changes.len() > 1);
            match fault {
                "missing" => {
                    changes.remove(0);
                }
                "extra" => changes.push(trnm_protocol::pon_state::Change {
                    key: b"unexpected-extra-cell".to_vec(),
                    before: None,
                    after: Some(b"null".to_vec()),
                }),
                "before" => changes[0].before = Some(b"null".to_vec()),
                "after" => changes[0].after = Some(b"null".to_vec()),
                "order" => changes.reverse(),
                "non_utf8" => changes[0].key = vec![255],
                _ => unreachable!(),
            }
            // This is an internal fault probe. Public callers have no constructor
            // for the opaque execution artifact or its optional write material.
            let error = node
                .commit_shared_admission(
                    outcome,
                    1000,
                    &ExecutionControl::new(&|_| Ok(()), &()),
                    None,
                )
                .unwrap_err();
            assert!(error.requires_owner_stop(), "{fault}: {error}");
            assert!(
                matches!(
                    error.to_string().as_str(),
                    "NATIVE_STATE_DELTA" | "STORAGE_WRITE"
                ),
                "{fault}: {error}"
            );
            assert_eq!(facts(&node), before, "{fault}");
            assert_eq!(node.read_active().unwrap(), active);
            drop(node);
            let mut reopened = open(directory.path(), &settings, true);
            assert_eq!(facts(&reopened), before);
            assert_eq!(reopened.read_active().unwrap(), active);
            // The negative did not become a durable block, nor poison recovery.
            assert_eq!(
                reopened.admit(&candidate, 1000).unwrap(),
                candidate.id().unwrap()
            );
        }
    }

    #[test]
    fn every_real_delta_boundary_keeps_cancellation_and_complete_rollback() {
        let settings = Settings::development(Some(1)).unwrap();
        let template = tempfile::tempdir().unwrap();
        let producer = open(template.path(), &settings, true);
        let candidate = packet(&producer, settings.genesis(), 1, 1, 1001, 0);
        let count = executed(&producer, &candidate)
            .admission
            .execution_deltas
            .unwrap()
            .len();
        assert!(count > 0);
        let stops = (0..count)
            .map(|index| ExecutionProgress::PersistenceDelta { index })
            .chain([ExecutionProgress::BeforeDurableCommit]);
        for stop in stops {
            let directory = tempfile::tempdir().unwrap();
            let mut node = open(directory.path(), &settings, true);
            let before = facts(&node);
            let outcome = executed(&node, &candidate);
            let reached = AtomicUsize::new(0);
            let error = node
                .commit_shared_admission(
                    outcome,
                    1000,
                    &ExecutionControl::new(
                        &|point| {
                            if point == stop {
                                reached.fetch_add(1, Ordering::Relaxed);
                                Err(Error::new(crate::ErrorCode::PublicRequestCancelled))
                            } else {
                                Ok(())
                            }
                        },
                        &(),
                    ),
                    None,
                )
                .unwrap_err();
            assert!(error.is(crate::ErrorCode::PublicRequestCancelled));
            assert!(!error.requires_owner_stop());
            assert_eq!(reached.load(Ordering::Relaxed), 1);
            assert_eq!(facts(&node), before);
            drop(node);
            let reopened = open(directory.path(), &settings, true);
            assert_eq!(facts(&reopened), before);
        }
    }
}
