import pathlib,subprocess,json,hashlib,os,time,platform,re,statistics
source=pathlib.Path('/home/qian-qi/work/chain-w1-node-r4-f16ac')
backend=pathlib.Path('/home/qian-qi/work/chain-w1-compact-backend-20261108-f16ac-r4/formal/pon-nakamoto-v1/w1_public_stark_research')
binary=pathlib.Path('/home/qian-qi/work/chain-w1-scheduled-sha-release-20261108-f16ac-r4/native-node-adapter-v3')
out=pathlib.Path('/home/qian-qi/work/chain-w1-scheduled-sha-native-reference-20261108-f16ac-r4-02');out.mkdir(exist_ok=False)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(binary)=='14f123c6e51f5b9a3a54176bf55b9d7f5a424083af701411b8b2c41311790cbb'
fixtures={case:{k:backend/'fixtures/round4-schedule'/f'{case}.{k}.bin' for k in ['input','expected-header']} for case in ['retained','dense']}
def snapshot():
 files=[source/'formal/pon-nakamoto-v1/w1_node_adapter_research/Cargo.toml',source/'formal/pon-nakamoto-v1/w1_node_adapter_research/Cargo.lock']
 files+=list((source/'formal/pon-nakamoto-v1/w1_node_adapter_research/src').rglob('*.rs'))
 for root in sorted((source/'trillionnium/crates').iterdir()):
  if root.is_dir() and (root/'Cargo.toml').is_file():
   files.append(root/'Cargo.toml');files+=list((root/'src').rglob('*.rs'))
 files+=list((source/'formal/pon-nakamoto-v1/w1_public_stark_research/src').rglob('*.rs'))
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),
  'files':{str(p.relative_to(source)):digest(p) for p in sorted(files)},
  'binary':{'path':str(binary),'sha256':digest(binary)},
  'fixtures':{case:{k:{'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size} for k,p in f.items()} for case,f in fixtures.items()}}
cpus=sorted(os.sched_getaffinity(0))[:8];assert len(cpus)==8;os.sched_setaffinity(0,cpus)
before=snapshot()
env=dict(os.environ,RAYON_NUM_THREADS='8',LC_ALL='C')
records=[]
for index,case in enumerate(['retained','dense','dense','retained','retained','dense']):
 directory=out/f'{index:02d}-{case}';directory.mkdir()
 raw=fixtures[case]['input'];header=fixtures[case]['expected-header']
 args=[str(binary),'native',str(raw),str(header),'100']
 start=time.monotonic_ns();start_utc=time.time_ns();load=pathlib.Path('/proc/loadavg').read_text()
 with (directory/'stdout.jsonl').open('wb') as so,(directory/'stderr.txt').open('wb') as se:
  p=subprocess.run(['/usr/bin/time','-v','-o',str(directory/'resource.txt'),*args],stdout=so,stderr=se,env=env,timeout=30)
 wall=(time.monotonic_ns()-start)/1e9
 lines=(directory/'stdout.jsonl').read_text().splitlines();report=json.loads(lines[-1]) if lines else None
 inner=report['result'] if report else {}
 ok=p.returncode==0 and inner.get('schema')=='trnm-w1-current-native-comparator-v1' and inner.get('calls')==100 and inner.get('default_kernel')=='FullLimb' and inner.get('raw_sha256')==digest(raw)
 if not ok:raise RuntimeError('native failure; retained '+str(directory))
 values=inner['seconds'];assert len(values)==100
 rss=re.search(r'Maximum resident set size \(kbytes\): (\d+)',(directory/'resource.txt').read_text())
 row={'index':index,'case':case,'argv':args,'returncode':p.returncode,'utc_start_ns':start_utc,'outer_seconds':wall,'report':report,'loadavg_before':load.strip(),'first_call_seconds':values[0],'median_call_seconds':statistics.median(values),'peak_rss_kib':int(rss.group(1)) if rss else None}
 records.append(row);(directory/'result.json').write_text(json.dumps(row,indent=2)+'\n')
 print(json.dumps({k:v for k,v in row.items() if k not in ['argv','report']}),flush=True)
after=snapshot()
summaries={}
for case in ['retained','dense']:
 rows=[r for r in records if r['case']==case];values=[v for r in rows for v in r['report']['result']['seconds']]
 summaries[case]={'fresh_processes':len(rows),'calls':len(values),'median_call_seconds':statistics.median(values),
 'first_call_seconds':[r['first_call_seconds'] for r in rows],
 'median_outer_seconds_for_100_calls':statistics.median(r['outer_seconds'] for r in rows),'maximum_observed_call_seconds':max(values),
 'median_peak_rss_kib':statistics.median(r['peak_rss_kib'] for r in rows)}
result={'schema':'w1-current-native-reference-separate-window-v1','qualification':'HOLD_NO_GO','result':'PASS' if before==after else 'SOURCE_CHANGED',
'comparison_scope':'Current pon_work::verify FullLimb calls, including header.challenge inside each call; independent expected-header and bounded input reads outside per-call samples, included in outer process wall; not Node admission and not interleaved with STARK ABBA',
'producer_or_proof_work_performed':False,'new_proofs_generated':0,'api_inputs':['RAW','EXPECTED_HEADER'],'public_statement_or_prefix_not_required':True,
'calls':600,'fresh_processes':6,'distinct_inputs':2,'call_samples_are_independent_proofs':False,'cache_scope':'Repeated calls within each fresh process; OS caches not flushed',
'cpu_affinity':cpus,'rayon_num_threads':8,'cpu_quota_percent':800,'memory_max_bytes':4294967296,'host_exclusive':False,'team_clearance':'root explicit CLEAR required; block02 predeclared before seeing block01 timing (block01 made zero calls)',
'build_scope':'RUSTFLAGS=-C target-cpu=native; development native SQLite I/O boundary remains unqualified; native comparator performs no database admission',
'source_before':before,'source_after':after,'source_binaries_inputs_unchanged':before==after,'cases':summaries,'runs':records}
(out/'manifest.json').write_text(json.dumps(result,indent=2)+'\n')
summary={k:v for k,v in result.items() if k not in ['source_before','source_after','runs']};(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('NATIVE_RESULT',json.dumps(summary),flush=True)
