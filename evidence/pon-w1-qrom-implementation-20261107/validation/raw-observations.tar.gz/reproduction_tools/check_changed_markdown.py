#!/usr/bin/env python3
"""Resolve all links in the changed Markdown against the complete Git inventory."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urlsplit

root = Path('/workspace/scratch/4a83c49617d8/chain_pq')
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
known = set(filter(None, tracked))
for name in tuple(known):
    known.update(str(parent) for parent in Path(name).parents)
paths = [
    'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md',
    'docs/security/W1_STARK_REVIEW_20261106.md',
    'docs/security/W1_QROM_IMPLEMENTATION_MAP_20261107.md',
    'evidence/pon-w1-qrom-implementation-20261107/README.md',
]
results = []
for name in paths:
    path = root / name
    raw = path.read_bytes()
    body = re.sub(r'^```[^\n]*\n.*?^```[^\n]*$', '', raw.decode(), flags=re.M | re.S)
    links = []
    for target in re.findall(r'\[[^\]]*\]\(([^\s)]+)\)', body):
        parsed = urlsplit(target.strip('<>'))
        if parsed.scheme or parsed.netloc or not parsed.path:
            continue
        resolved = (path.parent / unquote(parsed.path)).resolve()
        assert resolved.is_relative_to(root), (name, target, 'escapes repository')
        relative = str(resolved.relative_to(root))
        assert relative in known or resolved.exists(), (name, target, 'absent from Git and candidate')
        links.append({'target': target, 'resolved': relative})
    results.append({'path': name, 'sha256': hashlib.sha256(raw).hexdigest(), 'local_links': links})
print(json.dumps({'result': 'PASS', 'scope': 'All local path targets in four changed Markdown files. '
                  'Complete Git path inventory is used for historical files excluded by sparse checkout; '
                  'this does not validate every old file or remote URL.',
                  'files': results, 'link_count': sum(len(row['local_links']) for row in results)},
                 sort_keys=True, indent=2))
