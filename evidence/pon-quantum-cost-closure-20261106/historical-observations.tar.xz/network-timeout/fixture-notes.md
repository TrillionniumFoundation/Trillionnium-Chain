# Adaptive release deadline regression

This is a deterministic conditional-lottery control, not a native W1 execution
or a hardware measurement. No long campaign was started.

## Root cause

The first private block completes at `0.5` seconds and its timeout is `0.1`
seconds. The former implementation schedules the nearest binary64 sum, `0.6`.
At that event, `0.6 - 0.5` is `0.09999999999999998`, so `timed_out` is false.
Rearming the same rounded deadline fails the `at > now` guard. With no later
private blocks or public messages, the pending timeout disappears permanently.

`reproduce_timeout.py` uses only public scenario/run interfaces. A deterministic
one-item marked domain completes a block at `0.5`; a shock at `0.55` stops only
the next search. A high work-lead threshold requires timeout publication. The
unmodified simulation produces no publication through the one-second horizon.

## Suggested regression controls

1. Run the supplied scenario. Require one publication at the smallest binary64
   time greater than or equal to `Fraction(0.5) + Fraction(0.1)`; require
   `timed_out=True` in its release row. Preserve the partial second-search cost.
2. Stop the observation at `0.6`: no timeout publication is permitted because
   that represented time is below the exact deadline.
3. Stop at the upward-rounded deadline: exactly one publication is permitted.
4. Repeat with exactly representable `start=0.5`, `wait=0.25`, where the deadline
   remains `0.75` and does not receive an unnecessary additional ULP.
5. Exercise a future-dated private prefix whose eligibility timer is earlier
   than its timeout and verify only one pending effective timer/release.

Use one exact deadline expression for both comparison and scheduling. Do not
add a tolerance that releases a block before the represented configured wait.

## Reproduction

Run `python -B reproduce_timeout.py --repo /path/to/Trillionnium-Chain
--model-source quantum_network_sim.before.py` for the saved pre-fix source
snapshot, or omit `--model-source` to use the current tree. `--repo` defaults
to the current directory. Run `python -B independent_controls.py --repo
/path/to/Trillionnium-Chain` for the independent boundary controls.
`before-source.json` records the repository HEAD, source hash, and relevant
source excerpt. The original outcome is in `before-result.json`.

`driver-lineage.json` maps the original before/after outcomes to the historical
driver snapshots (`*.py.original.txt`). Those snapshots retain the workspace
path used at the time; the current `.py` drivers use the explicit repository
root argument and are suitable for replay in a different checkout.
