#!/usr/bin/env python3
"""Package actual local observations and every retained recovery failure."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path("/workspace/scratch/7f73fe002713")
STAGE = ROOT / "daa-reader-driver-stage"
TRANSFER = ROOT / "daa-native-archive-recovery-v1"
GIT = ROOT / "daa-native-git-recovery-v1"
RUN = ROOT / "daa-final-validation/four-profile-readers-recovery-v2"
LAUNCH = ROOT / "daa-final-validation/four-profile-reader-recovery-v2-launch"
DEST = ROOT / "daa-four-profile-reader-recovery-v2"
ARCHIVE = ROOT / "daa-four-profile-reader-recovery-v2.tar.gz"
HEAD = "d23488c5f9b4a6696c3799b12f14b8af0a1b81fc"
TREE = "72b106b4458299c37da146b0218b8f5276195b6d"


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return {"bytes": path.stat().st_size, "sha256": h.hexdigest()}


def write_new(path, value):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def copy_one(source, target):
    assert source.is_file() and not source.is_symlink(), str(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists(), str(target)
    shutil.copyfile(source, target)
    assert digest(source) == digest(target)


def copy_tree(source, target):
    for path in sorted(source.rglob("*")):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            copy_one(path, target / path.relative_to(source))


def main():
    result = json.loads((RUN / "result.json").read_text())
    launch = json.loads((LAUNCH / "execution.json").read_text())
    transfer = json.loads((TRANSFER / "transfer.json").read_text())
    recovered = json.loads((TRANSFER / "archive-verification.json").read_text())
    git = json.loads((GIT / "result.json").read_text())
    assert result["expected_commit"] == HEAD and result["expected_tree"] == TREE
    assert git["result"] == "PASS" and recovered["all_saved_rpc_chunks_match"] is True
    profiles = []
    for row in result["profiles"]:
        value = json.loads(Path(row["reader"]["stdout_path"]).read_text())
        profiles.append({
            "schedule": row["group"], "backend": row["backend"], "result": row["result"],
            "reader_schema": value["schema"], "header_profile": value["header_profile"],
            "observations": value["observations"],
            "unique_full_python_verified_proofs_within_profile": value["unique_full_python_verified_proofs"],
            "signed_spans_seconds": row["signed_spans"],
            "ordinary": {"height": value["ordinary_height"], "required_chainwork": value["ordinary_required_chainwork"]},
            "selected": {"height": value["selected_height"], "required_chainwork": value["selected_required_chainwork"]},
            "reader_exit_code": row["reader"]["returncode"], "suite_exit_code": row["suite"]["returncode"],
            "suite": row.get("suite_summary"),
            "reader_stdout": row["reader"]["stdout"], "suite_stderr": row["suite"]["stderr"],
            "full_python_transcript_and_product_recomputed": value["full_python_transcript_and_product_recomputed"],
            "public_network_qualification": value["public_network_qualification"],
            "host_and_source_provenance_checked_by_reader": value["host_and_source_provenance_checked_by_reader"],
            "reader_performed_native_admission": value["reader_performed_native_admission"],
            "reader_reopened_native_database": value["reader_reopened_native_database"],
            "reader_verified_aam1_account_proofs": value["reader_verified_aam1_account_proofs"]})
    before = json.loads((RUN / "source-before.json").read_text())
    after = json.loads((RUN / "source-after.json").read_text())
    inputs_before = json.loads((RUN / "inputs-before.json").read_text())
    inputs_after = json.loads((RUN / "inputs-after.json").read_text())
    summary = {
        "schema": "pon-four-profile-reader-recovery-validation-v2",
        "result": result["result"], "outer_driver_exit_code": launch["returncode"],
        "started_utc": result["started_utc"], "finished_utc": result["finished_utc"],
        "execution_site": "local managed /workspace runtime",
        "source_commit": HEAD, "source_tree": TREE,
        "source_before": {**digest(RUN / "source-before.json"), "tested_commit": before["tested_commit"],
                          "tested_tree": before["tested_tree"], "tracked_worktree_verified": before["tracked_worktree_verified"],
                          "tracked_entries": before["tracked_entries"], "tracked_bytes": before["tracked_bytes"]},
        "source_after": {**digest(RUN / "source-after.json"), "tested_commit": after["tested_commit"],
                         "tested_tree": after["tested_tree"], "tracked_worktree_verified": after["tracked_worktree_verified"],
                         "tracked_entries": after["tracked_entries"], "tracked_bytes": after["tracked_bytes"]},
        "source_after_verified": result.get("source_after_verified"),
        "native_archive": recovered["archive"],
        "native_archive_inputs_match": result.get("native_archive_inputs_match"),
        "native_archive_unchanged": result.get("native_archive_unchanged"),
        "input_files_before": len(inputs_before), "input_files_after": len(inputs_after),
        "input_file_bytes_and_sha256_unchanged": inputs_before == inputs_after,
        "inputs_before_manifest": digest(RUN / "inputs-before.json"),
        "inputs_after_manifest": digest(RUN / "inputs-after.json"),
        "profiles": profiles,
        "profiles_are_replays_not_independent_attack_trials": True,
        "recovery": {
            "original_remote_launch_outcome": "UNKNOWN after two MCP request timeouts",
            "remote_reader_execution_observed": False,
            "late_original_driver_blocked_by_verified_exclusive_fence": True,
            "fence_sha256": result["remote_launch_recovery"]["exclusive_fence_sha256"],
            "partial_rpc_chunks_saved_and_matched": len(transfer["chunks"]),
            "recorded_rpc_timeouts": len(transfer["transport_failures"]),
            "read_only_rpc_requests_unknown_at_controller_stop": len(transfer["pending_read_requests_at_controller_stop"]),
            "complete_archive_route": "normal Git fetch and git show, then full SHA256 and saved-chunk checks",
            "publication_commit": git["publication_commit"], "archive_git_blob": git["native_archive_git_blob"],
            "archive_git_path": git["native_archive_git_path"]},
        "local_runtime": json.loads((RUN / "local-runtime.json").read_text()),
        "scope": {
            "mathematically_independent_scalar_implementation": True,
            "independent_host_authentication": False,
            "qualification": "HOLD_NO_GO", "public_network_qualification": False,
            "production_activation": False,
            "common_prefix_failure_bound": None, "chain_growth_failure_bound": None,
            "chain_quality_failure_bound": None, "six_confirmations_failure_bound": None,
            "actual_lifetime_failure_bound": None,
            "quantum_attack_profitability_established": False,
            "real_time_honest_network_attack_demonstrated": False,
            "uncomputed_bounds_are_unknown_not_zero": True}}
    DEST.mkdir(mode=0o700, exist_ok=False)
    copy_tree(RUN, DEST / "run")
    copy_tree(LAUNCH, DEST / "outer-execution")
    for name in ("readers-driver-d23488c5-v1.py", "readers-driver-local-recovery-v2.py",
                 "extract-native-archive-recovery-v2.py", "run-local-readers-recovery-v2.py",
                 "package-local-reader-recovery-v2.py", "controller-launch-observations-v1.json",
                 "controller-response-snapshots-v1.json", "readers-launch-fence-v1.json",
                 "extract-native-archive.stdout.log", "extract-native-archive.stderr.log",
                 "extract-native-archive.execution.json"):
        copy_one(STAGE / name, DEST / "controller" / name)
    for name in ("transfer.json", "saved-chunks-at-pause.json", "archive-verification.json", "extracted-files.json"):
        copy_one(TRANSFER / name, DEST / "transfer" / name)
    for path in sorted(GIT.iterdir()):
        if path.is_file() and path.name != "native-archive.stdout":
            copy_one(path, DEST / "git-recovery" / path.name)
    copy_one(ROOT / "recover-native-via-git.py", DEST / "git-recovery/recover-native-via-git.py")
    for name in ("daa-native-git-recovery-launch-v1.json", "daa-native-git-recovery-launch-v1.stdout",
                 "daa-native-git-recovery-launch-v1.stderr"):
        copy_one(ROOT / name, DEST / "git-recovery" / name)
    copy_one(ROOT / "daa-final-validation/four-profile-readers-recovery-v2-archive.json",
             DEST / "run-only-archive-descriptor.json")
    write_new(DEST / "validation.json", summary)
    write_new(ROOT / "daa-four-profile-reader-validation-v2.json", summary)
    lines = [
        "# Four-profile independent scalar replay: local recovery v2", "",
        f"Actual result: **{result['result']}**. Execution occurred in the local managed `/workspace` runtime.", "",
        f"Frozen implementation: `{HEAD}`; tree `{TREE}`. Full source identity was checked before and after execution.", "",
        "| Schedule | Backend | Full W1 proofs within profile | Methods | Passed | Skipped | Result |",
        "| --- | --- | ---: | ---: | ---: | ---: | --- |"]
    for row in profiles:
        suite = row["suite"] or {}
        lines.append(f"| {row['schedule']} | {row['backend']} | {row['unique_full_python_verified_proofs_within_profile']} | "
                     f"{suite.get('methods_executed')} | {suite.get('passed')} | {suite.get('skipped')} | {row['result']} |")
    lines += ["", "## Input and execution record", "",
              "The separately retained native archive is `native-run-d23488c5-v1.tar.gz`, 4,657,951 bytes, "
              "SHA256 `6c33da56842862608e365acb7c69d72175538556a2a76b74254f7b0357de9c81`. "
              "Its full digest, all 36 saved RPC chunks, archive members, and 460 report/packet files were checked locally. "
              "The full archive and its duplicate `git show` stdout are intentionally not nested in this reader bundle.", "",
              "`run/` retains the exact reader JSON, suite stdout/stderr, command argv/environment/exit codes, "
              "source-before/after verification records, input-before/after hashes, actual runtime limits, and final result. "
              "`outer-execution/` retains the sole local driver launch and its outer exit/logs. "
              "The method counts include positive validation methods; these are not all negative tests. "
              "Replaying four profiles does not create four independent attack trials.", "",
              "## Transport recovery record", "",
              "Two identical remote launch requests timed out; their launch outcome remains UNKNOWN. "
              "A create-only, regular-file fence was written and its full hash rechecked at the driver's first exclusive "
              "launcher-log path, blocking any late original driver from passing that pre-execution gate. "
              "No successful remote reader or resource-scope execution is claimed. "
              "The fixed-version RPC transfer saved 36 verified chunks, retained 13 explicit timeouts, and stopped with "
              "8 read-only requests of unknown outcome. The complete archive was subsequently recovered through "
              "normal Git fetch and git show from an evidence-only commit. "
              "`controller/`, `transfer/`, and `git-recovery/` retain the successful observations and failures.", "",
              "## Scope", "",
              "The Python readers independently recompute scalar W1 transcripts and products, lineage, timestamps, "
              "retargets, clamping, and cumulative required work. They do not independently authenticate the host, "
              "derive runtime namespace identity from source, execute native M06/admission, reopen the native database, "
              "or verify AAM1 account proofs. Native behavior has its separate retained native execution record. "
              "The old negative-span reader and the new positive-span reader retain separate strict schemas.", "",
              "Qualification remains HOLD_NO_GO, production/public-network activation is false, and CP/CG/CQ, "
              "six-confirmation, and lifetime failure bounds remain unknown (`null`). "
              "This replay establishes neither quantum profitability nor a real-time honest-network attack. "
              "Local elapsed time and resource limits are execution observations, not physical-cost or security bounds.", ""]
    with (DEST / "README.md").open("x", encoding="utf-8") as handle:
        handle.write("\n".join(lines))
    manifest = {path.relative_to(DEST).as_posix(): digest(path)
                for path in sorted(DEST.rglob("*")) if path.is_file()}
    write_new(DEST / "files.json", manifest)
    with ARCHIVE.open("xb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, filename="") as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as bundle:
            for path in sorted(DEST.rglob("*")):
                if path.is_file():
                    info = bundle.gettarinfo(str(path), arcname=DEST.name + "/" + path.relative_to(DEST).as_posix())
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ""
                    info.mode = 0o600
                    with path.open("rb") as handle:
                        bundle.addfile(info, handle)
    descriptor = {"schema": "pon-four-profile-reader-recovery-bundle-v2", "path": str(ARCHIVE),
                  **digest(ARCHIVE), "result": result["result"], "source_commit": HEAD, "source_tree": TREE,
                  "summary_path": str(ROOT / "daa-four-profile-reader-validation-v2.json"),
                  "summary": digest(ROOT / "daa-four-profile-reader-validation-v2.json"),
                  "files_in_manifest": len(manifest),
                  "packaged_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
    write_new(ROOT / "daa-four-profile-reader-recovery-v2-archive.json", descriptor)
    print(json.dumps(descriptor, indent=2))


if __name__ == "__main__":
    main()
