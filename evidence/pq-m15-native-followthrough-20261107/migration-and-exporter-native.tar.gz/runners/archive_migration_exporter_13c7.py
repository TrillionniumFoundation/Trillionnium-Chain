#!/usr/bin/env python3
"""Archive native migration evidence and exporter preparation, keeping failures."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import tarfile

WORK = Path('/home/alex/work')
OUTPUT = WORK / 'chain-migration-exporter-13c7-native-evidence.tar.gz'
SUMMARY = WORK / 'chain-migration-exporter-13c7-native-summary.json'
ROOTS = {
    'migration1c14': WORK / 'chain-migration-1c14fab4-13c7-evidence',
    'exporter840': WORK / 'chain-npq6-export-13c7-evidence-v3',
    'exporter-source-refusal': WORK / 'chain-npq6-export-13c7-evidence',
    'exporter-idle-refusal': WORK / 'chain-npq6-export-13c7-evidence-v2',
    'retained-cli-loader': WORK / 'chain-npq6-retained-cli-loader-13c7',
}
migration = json.loads((ROOTS['migration1c14'] / 'manifest.json').read_text())
exporter = json.loads((ROOTS['exporter840'] / 'manifest.json').read_text())
if migration['result'] != 'PASS' or migration['actual_named_tests_passed'] != 3:
    raise ValueError('migration exact native scope is not terminal PASS')
if exporter['result'] != 'PASS' or exporter['material_generated'] is not False:
    raise ValueError('exporter build-only scope is not terminal PASS')
for name in ['exporter-source-refusal', 'exporter-idle-refusal']:
    refusal = json.loads((ROOTS[name] / 'manifest.json').read_text())
    if refusal['result'] != 'FAIL' or refusal['commands']:
        raise ValueError('expected preserved zero-native preparation refusal')

entries = [(prefix + '/' + str(path.relative_to(root)), path)
           for prefix, root in ROOTS.items() for path in sorted(root.rglob('*'))
           if path.suffix in ['.json', '.jsonl', '.log']]
for name in ['chain_migration_three_1c14fab4.py', 'chain_npq6_export_build_840.py',
             'chain_npq6_export_build_840_v2.py', 'chain_npq6_export_build_840_v3.py',
             'chain_npq6_export_fresh_840_13c7.py', 'chain_retained_cli_loader_inspect.py',
             'chain-m15-regression-1c14fab4-13c7-runner-v2.py', 'archive_migration_exporter_13c7.py']:
    entries.append(('runners/' + name, WORK / name))
provider = WORK / 'chain-zeroize191-df896925-20261105-evidence/dependency-preparation'
entries += [('provider/provider.json', provider / 'pq-provider/provider.json'),
            ('provider/provider-env', provider / 'provider-env'),
            ('retained-cli/receipt.json', WORK / 'chain-npq6-provider-bound-13c7/receipt.json')]


def identity(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_nlink,
            value.st_size, value.st_mtime_ns, value.st_ctime_ns)


payloads, seals = [], []
for name, path in entries:
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > 64 * 1024 * 1024:
        raise ValueError('nonregular or excessive evidence: ' + str(path))
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC), 'rb') as stream:
        if identity(os.fstat(stream.fileno())) != identity(before):
            raise ValueError('evidence changed before read')
        raw = stream.read(64 * 1024 * 1024 + 1)
        if identity(os.fstat(stream.fileno())) != identity(before):
            raise ValueError('evidence changed during read')
    if len(raw) != before.st_size or identity(path.lstat()) != identity(before):
        raise ValueError('evidence changed after read')
    payloads.append((name, raw))
    seals.append(dict(archive_path=name, original_path=str(path), bytes=len(raw),
                      sha256=hashlib.sha256(raw).hexdigest()))

native_cases = []
for index, name in enumerate(migration['exact_required_tests']):
    label = 'migration-' + format(index, '02d')
    raw = (ROOTS['migration1c14'] / (label + '.log')).read_text()
    matches = re.findall(r'^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; 2 filtered out; finished in ([0-9.]+)s$', raw, re.M)
    if len(matches) != 1:
        raise ValueError('actual exact migration aggregate differs')
    native_cases.append(dict(test=name, passed=1, failed=0, ignored=0, elapsed_seconds=float(matches[0])))
summary = dict(schema='chain-migration-exporter-native-evidence-summary-v1',
               migration=dict(commit=migration['commit'], tree=migration['tree'], result=migration['result'],
                              started_utc=migration['started_utc'], finished_utc=migration['finished_utc'],
                              commands=migration['commands'], native_cases=native_cases,
                              source_before=migration['source_before'], source_after=migration['source_after'],
                              artifact_binding=migration['artifact_binding'],
                              selected_features=migration['selected_features']),
               exporter_build=dict(commit=exporter['commit'], tree=exporter['tree'], result=exporter['result'],
                                   started_utc=exporter['started_utc'], finished_utc=exporter['finished_utc'],
                                   commands=exporter['commands'], registry_names=exporter['registry_names'],
                                   ignored_names=exporter['ignored_names'],
                                   source_before=exporter['source_before'], source_after=exporter['source_after'],
                                   artifact_binding=exporter['artifact_binding'],
                                   material_generated=False),
               failed_setup_scopes_preserved=['exporter-source-refusal', 'exporter-idle-refusal'],
               includes_large_executables=False, large_executable_bindings_retained=True,
               current_remote_head_not_qualified=True, original_full_node_aggregate_unchanged=True,
               paired_hepta_consumer_executed=False, live_legacy_chain_cutover_qualified=False,
               production_activation=False, whole_chain_quantum_security_qualified=False)
summary_raw = (json.dumps(summary, indent=2, sort_keys=True) + '\n').encode()
with SUMMARY.open('xb') as stream:
    stream.write(summary_raw)
payloads.append(('summary.json', summary_raw))
seals.append(dict(archive_path='summary.json', original_path=str(SUMMARY), bytes=len(summary_raw),
                  sha256=hashlib.sha256(summary_raw).hexdigest()))
archive_seals = dict(schema='chain-migration-exporter-raw-evidence-archive-v1', files=seals,
                     source_and_prior_evidence_modified=False, native_count_scopes_are_separate=True,
                     fresh_export_wrapper_uploaded_but_not_executed=True)
payloads.append(('archive-seals.json', (json.dumps(archive_seals, indent=2, sort_keys=True) + '\n').encode()))
with OUTPUT.open('xb') as destination:
    with gzip.GzipFile(filename='', mode='wb', fileobj=destination, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.USTAR_FORMAT) as tar:
            for name, raw in payloads:
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o600, 0
                tar.addfile(info, io.BytesIO(raw))
    destination.flush()
    os.fsync(destination.fileno())
with OUTPUT.open('rb') as stream:
    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
print(json.dumps(dict(path=str(OUTPUT), bytes=OUTPUT.stat().st_size, sha256=digest,
                      raw_evidence_files=len(seals), summary_path=str(SUMMARY),
                      summary_sha256=hashlib.sha256(summary_raw).hexdigest()), sort_keys=True))
