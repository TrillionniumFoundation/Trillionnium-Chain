    python3 scripts/ci/pq_lifetime_composition.py
    python3 scripts/ci/test_pq_content_chain_review.py
    python3 scripts/ci/pq_content_chain_review.py
    python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_fixed_success_query_frontier.py' -v
    python3 formal/pon-nakamoto-v1/fixed_success_query_frontier.py --check
    python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_cost_tail_transfer.py' -v
    python3 formal/pon-nakamoto-v1/cost_tail_transfer.py --check
    python3 formal/pon-nakamoto-v1/test_quantum_bernoulli_source_audit.py -v
    python3 scripts/ci/test_retained_research_ci.py
    python3 scripts/test_qualification_runtime.py
