set -euo pipefail
python3 scripts/ci/w1_qrom_supplemental_controls.py --suite historical \
  --repo-root "$GITHUB_WORKSPACE" --output-dir "$W1_QROM_OUT" \
  2>&1 | tee "$W1_QROM_OUT/historical-controls.log"
