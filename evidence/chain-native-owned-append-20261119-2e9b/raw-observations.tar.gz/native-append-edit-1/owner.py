from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'native-append-edit-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);inputs=json.loads(sys.argv[2]);res={'schema':'chain-same-writer-owned-native-appends-v1','stages':[],'files':[],'complete':False}
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(src.parent/'target');env['PATH']='/home/qq/.cargo/bin:'+env['PATH']
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=src,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['stages'].append(row);save();print(json.dumps(row),flush=True)
 if rc:print((out/(name+'.stderr')).read_text(errors='replace')[-12000:],flush=True)
 return rc
def replace(text,before,after,count=1):
 assert text.count(before)==count,(before[:150],text.count(before));return text.replace(before,after)
try:
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 paths=[
 'trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_store.rs',
 'trillionnium/crates/trnm-pon-node/src/store/native_authenticated/post_write_readback.rs',
 'trillionnium/crates/trnm-pon-node/src/store/native_authenticated.rs']
 originals={}
 for i,path in enumerate(paths):
  raw=(src/path).read_bytes();assert raw==subprocess.check_output(['git','show','HEAD:'+path],cwd=src);(out/('original-'+str(i)+'.rs')).write_bytes(raw);originals[path]=raw.decode()
 native=originals[paths[0]]
 native=replace(native,'pub(crate) mod scoped_readback;\n','pub(crate) mod scoped_readback;\n#[path = "native_append.rs"]\npub(crate) mod append;\n')
 native=replace(native,'    progress: &mut dyn FnMut() -> Result<()>,\n) -> Result<Option<Node>> {\n    progress()?;','    progress: &mut dyn FnMut() -> Result<()>,\n    inserts: &mut Option<&mut append::InsertCount>,\n) -> Result<Option<Node>> {\n    progress()?;')
 native=replace(native,'        super::save_node(db, first).map_err(storage)?;','        save_applied_node(db, first, inserts)?;')
 native=replace(native,'    super::save_node(db, &next).map_err(storage)?;','    save_applied_node(db, &next, inserts)?;')
 native=replace(native,'apply_batch(db, left, left_updates, empty, progress)?','apply_batch(db, left, left_updates, empty, progress, inserts)?')
 native=replace(native,'apply_batch(db, right, right_updates, empty, progress)?','apply_batch(db, right, right_updates, empty, progress, inserts)?')
 native=replace(native,'/// Apply actual ordered native deltas. Accounts retain both nonce and existence;','''fn save_applied_node(
    db: &Connection,
    node: &Node,
    inserts: &mut Option<&mut append::InsertCount>,
) -> Result<()> {
    // The original SQL and exact conflict readback complete before this private
    // fact is counted. No callback can supply or modify the fact.
    super::save_node(db, node).map_err(storage)?;
    if let Some(inserts) = inserts.as_deref_mut() {
        inserts.record()?;
    }
    Ok(())
}

/// Apply actual ordered native deltas. Accounts retain both nonce and existence;''')
 native=replace(native,'    apply_bounded(db, parent, deltas, progress, 65_536)','    apply_bounded(db, parent, deltas, progress, 65_536, None)')
 native=replace(native,'        trnm_mvcc_fee::pon_executor::growth::MAX_ACCOUNTS,\n    )','        trnm_mvcc_fee::pon_executor::growth::MAX_ACCOUNTS,\n        None,\n    )')
 native=replace(native,'    maximum: u64,\n) -> Result<Root> {','    maximum: u64,\n    mut inserts: Option<&mut append::InsertCount>,\n) -> Result<Root> {')
 native=replace(native,'    let root = apply_batch(db, original, &updates, &empty, progress)?;','    let root = apply_batch(db, original, &updates, &empty, progress, &mut inserts)?;')
 post=originals[paths[1]]
 post=replace(post,'    scoped_readback::{Frontier, VerifiedGraph},','    append::AppliedNodes,\n    scoped_readback::{Frontier, VerifiedGraph},')
 post=replace(post,"impl<'db> PostWriteReadback<'db> {\n",inputs['holder']+"impl<'db> PostWriteReadback<'db> {\n"+inputs['helper'])
 post=replace(post,'        mut parent_graph: Option<Self>,\n        original_owner:',"        parent_graph: impl Into<PublicationParent<'db>>,\n        original_owner:")
 post=replace(post,'    ) -> Result<Option<Self>> {\n        let eligible = match parent_graph.as_mut() {','    ) -> Result<Option<Self>> {\n        let publication = parent_graph.into();\n        let mut parent_graph = publication.graph;\n        let appends = publication.appends;\n        let eligible = match parent_graph.as_mut() {')
 post=replace(post,'                scope.current(db)?\n                    && !scope.consumed','                (match appends.as_ref() {\n                    Some(appends) => scope.current_after_appends(db, record, appends)?,\n                    None => scope.current(db)?,\n                })\n                    && !scope.consumed')
 post=replace(post,'                            && record.accounts == verified.record.accounts\n                    })\n                    && actual_deltas\n                        .iter()\n                        .all(|row| !row.0.starts_with("account:"))','''                            && (appends.as_ref().is_some_and(|appends| {
                                appends.is_for(
                                    &scope.graph_scope,
                                    verified.record.id,
                                    &verified.record.accounts,
                                    &record.accounts,
                                )
                            }) || record.accounts == verified.record.accounts
                                && actual_deltas
                                    .iter()
                                    .all(|row| !row.0.starts_with("account:")))
                    })''')
 post=replace(post,'                    == 1\n                    && previous.schema == next.schema','                    == appends.as_ref().map_or(Some(1), |fact| fact.inserts().checked_add(1)).ok_or("NATIVE_APPEND_COUNT")?\n                    && previous.schema == next.schema')
 post=replace(post,'                    next.graphs[0] = Some(CompletedGraph::complete(record.clone()));\n                    next.ids[2] = record.parent;','''                    next.ids[2] = record.parent;
                    if appends.is_some() {
                        // Only the ORIGINAL complete parent graph survived the
                        // actual passive appends. The child receives no full
                        // graph verdict; its current State and exposed graph
                        // must still pass the original verifier below.
                        let parent = previous.graphs[0].as_ref().ok_or("NATIVE_ACCOUNT_FRONTIER")?;
                        next.graphs[2] = Some(CompletedGraph::complete(parent.record.clone()));
                    } else {
                        next.graphs[0] = Some(CompletedGraph::complete(record.clone()));
                    }''')
 post=replace(post,'                        next.metadata_insert_seeded = true;','                        next.metadata_insert_seeded = appends.is_none();\n                        next.append_insert_seeded = appends.is_some();')
 post=replace(post,'    metadata_insert_seeded: bool,\n','    metadata_insert_seeded: bool,\n    #[cfg(test)]\n    append_insert_seeded: bool,\n')
 post=replace(post,'            metadata_insert_seeded: false,\n','            metadata_insert_seeded: false,\n            #[cfg(test)]\n            append_insert_seeded: false,\n')
 # Preserve the reviewed exact metadata proof unchanged. The archive proof is
 # a separate literal ordinary-table/PK check with the same fresh PRAGMA reads.
 first=post.index('    fn passive_record_insert_schema(');last=post.index('    pub(in crate::store) fn new(',first)
 passive=post[first:last].replace('passive_record_insert_schema','passive_account_insert_schema').replace('native_state_commitments','archive_nodes').replace('block BLOB','id BLOB').replace('Some("block".into())','Some("id".into())').replace('ordinary metadata table','ordinary account-node table')
 post=post[:last]+passive+post[last:]
 parent=originals[paths[2]]
 parent=replace(parent,'    let accounts = native_store::apply(db, &parent_record.accounts, &rows, progress)?;','''    let (accounts, parent_graph) = PostWriteReadback::apply_publication_accounts(
        db,
        &parent_record,
        &rows,
        progress,
        parent_graph,
    )?;''')
 parent=replace(parent,'    // Only this native helper owns the exact metadata write. When actual SQL\n    // deltas/apply leave the complete parent account Root untouched, it can\n    // prove that this one passive INSERT preserves the just-read account graph.\n    // Any extra write/schema/owner change keeps the original full child graph.','''    // Only this native helper owns the exact metadata write. Its consumed
    // parent owner may carry the sealed facts of the actual passive account
    // INSERTs. It never receives a caller-supplied count or graph verdict.
    // Any extra write/schema/owner change keeps the original full child graph.''')
 for path,text in zip(paths,[native,post,parent]):(src/path).write_text(text)
 added='trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_append.rs'
 with (src/added).open('x') as f:f.write(inputs['append'])
 assert run('format',['/home/qq/.cargo/bin/cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all'])==0
 patch=subprocess.check_output(['git','diff','--',*paths],cwd=src);(out/'production.patch').write_bytes(patch)
 for path in paths+[added]:
  raw=(src/path).read_bytes();row={'path':path,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};res['files'].append(row);(out/Path(path).name).write_bytes(raw)
 res['production_patch']={'bytes':len(patch),'sha256':hashlib.sha256(patch).hexdigest()};save()
 assert run('native-check',['/home/qq/.cargo/bin/cargo','check','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--release','--locked','--offline','--lib'])==0
 assert run('diff-check',['git','diff','--check'])==0
 res['complete']=True;save();print(json.dumps(res,indent=2),flush=True)
except BaseException as e:
 res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
