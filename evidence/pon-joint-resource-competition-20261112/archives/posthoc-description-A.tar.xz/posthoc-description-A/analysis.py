#!/usr/bin/env python3
"""Posthoc descriptive readback of the original 128 cases; never run a simulator."""
from __future__ import annotations
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import stat

SOURCE = "43e5c9d6b668276d03e1c7a76f467ec211e1d7dc"
INPUT = Path("/home/qian-qi/work/chain-daa-resource-formal-20261112-600e-43e5c9d6b668/campaign")
OUTPUT = Path("/home/qian-qi/work/chain-daa-posthoc-600e/analysis.json")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def strict_object(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError("DUPLICATE_JSON_KEY")
        out[key] = value
    return out


def invalid_constant(text):
    raise ValueError("NONFINITE_JSON_" + text)


def load(raw):
    return json.loads(raw, object_pairs_hook=strict_object, parse_constant=invalid_constant)


def read_regular(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > 8_000_000:
        raise ValueError("INPUT_FILE_BOUND")
    raw = path.read_bytes()
    after = path.lstat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
        raise ValueError("INPUT_CHANGED_WHILE_READING")
    return raw


def uint(value):
    if type(value) is not int or value < 0:
        raise ValueError("INTEGER_COUNTER")
    return value


def credit(value):
    if type(value) is not str or not re.fullmatch(r"0|[1-9][0-9]*", value):
        raise ValueError("INTEGER_CREDIT")
    return int(value)


def summarize_pairs(pairs):
    deltas = [int(pair["private_minus_honest_quantum_adopted_credit"]) for pair in pairs]
    return {"pairs": len(pairs), "private_more_credit": sum(value > 0 for value in deltas),
            "equal_credit": sum(value == 0 for value in deltas),
            "private_less_credit": sum(value < 0 for value in deltas),
            "paired_credit_delta_sum": str(sum(deltas))}


def main():
    started = datetime.now(timezone.utc).isoformat()
    manifest_raw = read_regular(INPUT / "manifest.json")
    manifest = load(manifest_raw)
    files = manifest["files_sha256"]
    if manifest["schema"] != "trnm-joint-resource-competition-campaign-v1-manifest" or len(files) != 258:
        raise ValueError("ORIGINAL_MANIFEST")
    if {path.name for path in INPUT.iterdir()} != set(files) | {"manifest.json"}:
        raise ValueError("ORIGINAL_INVENTORY")
    original_hashes, original_bytes = {}, 0
    for name, expected in files.items():
        if Path(name).name != name or not re.fullmatch(r"[0-9a-f]{64}", expected):
            raise ValueError("ORIGINAL_MEMBER")
        raw = read_regular(INPUT / name)
        if sha(raw) != expected:
            raise ValueError("ORIGINAL_HASH")
        original_hashes[name] = expected
        original_bytes += len(raw)
    report = load(read_regular(INPUT / "report.json"))
    roster = load(read_regular(INPUT / "roster.json"))
    if (report["source"]["git_head"] != SOURCE or report["source"]["all_source_files_committed_at_head"] is not True
            or len(report["observations"]) != 128 or len(roster["cases"]) != 128
            or roster["duration_seconds"] != 3600.0 or roster["seeds"] != [6101, 6102, 6103, 6104]):
        raise ValueError("ORIGINAL_COHORT")
    records = []
    for filename, parameters in zip(report["observations"], roster["cases"]):
        record = load(read_regular(INPUT / filename))
        if canonical(record["parameters"]) != canonical(parameters):
            raise ValueError("ORIGINAL_PARAMETERS")
        if (record["execution"] != "returned" or record["error"] is not None
                or record["readback_error"] is not None or record["summary"]["termination"] != "horizon"
                or record["readback"]["all_declared_capacity_checks_pass"] is not True):
            raise ValueError("INCOMPLETE_ORIGINAL_CASE")
        if filename != record["case_id"] + ".json":
            raise ValueError("CASE_IDENTITY")
        records.append(record)
    if len({record["case_id"] for record in records}) != 128:
        raise ValueError("DUPLICATE_CASE")
    pairs, details = [], {}
    excluded = {"name", "quantum_strategy", "quantum_timestamp_mode",
                "private_timestamp_step", "private_release_seconds"}
    for offset in range(0, 128, 2):
        honest, private = records[offset:offset + 2]
        hp, pp = honest["parameters"], private["parameters"]
        if hp["quantum_strategy"] != "honest-tip" or pp["quantum_strategy"] != "private-branch":
            raise ValueError("PAIR_ORDER")
        if canonical({k: v for k, v in hp.items() if k not in excluded}) != canonical(
                {k: v for k, v in pp.items() if k not in excluded}):
            raise ValueError("PAIR_RESOURCE_PREMISES")
        environment = next((env for env in ("steady", "delay", "participation", "proof_cost")
                            if hp["name"].startswith(env + "_q")), None)
        if environment is None:
            raise ValueError("ENVIRONMENT_NAME")
        delta = credit(private["readback"]["quantum_adopted_credit"]) - credit(honest["readback"]["quantum_adopted_credit"])
        pair_id = honest["case_id"] + "__vs__" + private["case_id"]
        pair = {"pair_id": pair_id, "policy": hp["policy"], "environment": environment,
                "quantum_iteration_seconds": hp["quantum_iteration_seconds"], "seed": hp["seed"],
                "honest_case": honest["case_id"], "private_case": private["case_id"],
                "private_minus_honest_quantum_adopted_credit": str(delta)}
        original = report["comparison"]["pairs"][offset // 2]
        if (original["honest"] != honest["case_id"] or original["private"] != private["case_id"]
                or original["private_minus_honest_quantum_adopted_credit"] != str(delta)
                or original["complete"] is not True):
            raise ValueError("ORIGINAL_COMPARISON_MISMATCH")
        pairs.append(pair)
        details[pair_id] = {**pair}
        for arm, record in (("honest", honest), ("private", private)):
            summary, checked = record["summary"], record["readback"]
            details[pair_id][arm] = {
                "case_id": record["case_id"], "original_file": record["case_id"] + ".json",
                "original_sha256": files[record["case_id"] + ".json"],
                "termination": summary["termination"], "observation_seconds": summary["observation_seconds"],
                "quantum_adopted_credit": checked["quantum_adopted_credit"],
                "classical_adopted_credit": checked["classical_adopted_credit"],
                "quantum_adopted_blocks": checked["quantum_adopted_blocks"],
                "classical_adopted_blocks": checked["classical_adopted_blocks"],
                "observer_added_chainwork": summary["observer_added_chainwork"],
                "blocks_created": summary["blocks_created"], "trace_rows": record["trace_rows"],
                "observer_reorgs": summary["observer_reorgs"],
                "observer_max_reorg_depth": summary["observer_max_reorg_depth"],
                "probe": summary["probe"],
                "resource_charges": checked["resource_charges"],
            }
    groups = defaultdict(list)
    cells = defaultdict(list)
    clocks = defaultdict(list)
    for pair in pairs:
        groups[(pair["policy"], pair["environment"])].append(pair)
        cells[(pair["policy"], pair["environment"], pair["quantum_iteration_seconds"])].append(pair)
        clocks[(pair["policy"], pair["quantum_iteration_seconds"])].append(pair)
    by_policy = []
    for policy in ("fixed-target", "periodic-target"):
        aggregated = summarize_pairs([pair for pair in pairs if pair["policy"] == policy])
        previous = next(item for item in report["comparison"]["by_policy"] if item["policy"] == policy)
        if (aggregated["pairs"] != previous["complete_pairs"]
                or aggregated["private_more_credit"] != previous["private_more_credit_pairs"]
                or aggregated["equal_credit"] != previous["equal_credit_pairs"]
                or aggregated["private_less_credit"] != previous["private_less_credit_pairs"]
                or aggregated["paired_credit_delta_sum"] != previous["paired_credit_delta_sum"]):
            raise ValueError("POLICY_TOTAL_MISMATCH")
        by_policy.append({"policy": policy, **aggregated})
    honest_records = [record for record in records if record["parameters"]["quantum_strategy"] == "honest-tip"]
    short = lambda record: uint(record["readback"]["integer_policy_readback"]["positive_short_epochs_accepted"])
    totals = {
        "runs": len(records), "pairs": len(pairs),
        "termination_histogram": dict(sorted(Counter(record["summary"]["termination"] for record in records).items())),
        "blocks_created": sum(uint(record["summary"]["blocks_created"]) for record in records),
        "trace_rows": sum(uint(record["trace_rows"]) for record in records),
        "observer_added_blocks": sum(uint(record["summary"]["observer_added_blocks"]) for record in records),
        "observer_reorgs": sum(uint(record["summary"]["observer_reorgs"]) for record in records),
        "maximum_observer_reorg_depth": max(uint(record["summary"]["observer_max_reorg_depth"]) for record in records),
        "observer_reorg_beyond_confirmation_depth_events": sum(uint(record["summary"]["observer_reorg_beyond_confirmation_depth"]) for record in records),
        "pairwise_prefix_samples": sum(uint(record["summary"]["pairwise_prefix_samples"]) for record in records),
        "pairwise_prefix_disagreements_below_common_height_minus_k": sum(uint(record["summary"]["pairwise_prefix_disagreements_below_common_height_minus_k"]) for record in records),
        "probe_confirmation_reversals": sum(uint(record["summary"]["probe"]["confirmation_reversals"]) for record in records),
        "runs_with_probe_confirmation_reversals": sum(record["summary"]["probe"]["confirmation_reversals"] > 0 for record in records),
    }
    probe_fields = {}
    probe_keys = set(records[0]["summary"]["probe"])
    if any(set(record["summary"]["probe"]) != probe_keys for record in records):
        raise ValueError("PROBE_FIELD_SET")
    for key in sorted(probe_keys):
        values = [record["summary"]["probe"][key] for record in records]
        present = [value for value in values if value is not None]
        item = {"runs": len(values), "null_runs": len(values) - len(present)}
        if not present:
            item["type"] = "all-null"
        elif all(type(value) is bool for value in present):
            item.update({"type": "boolean", "true_runs": sum(value is True for value in present),
                         "false_runs": sum(value is False for value in present)})
        elif all(type(value) in (int, float) for value in present):
            item.update({"type": "number", "nonnull_runs": len(present),
                         "minimum": min(present), "maximum": max(present), "sum": sum(present)})
        elif all(type(value) is str for value in present):
            item.update({"type": "string", "value_counts": dict(sorted(Counter(present).items()))})
        else:
            raise ValueError("UNSUPPORTED_PROBE_FIELD_TYPE")
        probe_fields[key] = item
    totals["probe_original_fields"] = probe_fields
    totals["probe_field_aggregation_scope"] = "original names retained; numeric sums are descriptive, not probabilities"
    short_epochs = {
        "all_runs_positive_short_epochs_accepted": sum(short(record) for record in records),
        "honest_runs": len(honest_records),
        "honest_runs_with_positive_short_epochs_accepted": sum(short(record) > 0 for record in honest_records),
        "honest_runs_positive_short_epochs_accepted": sum(short(record) for record in honest_records),
        "by_policy": [{"policy": policy,
                       "honest_runs": sum(record["parameters"]["policy"] == policy for record in honest_records),
                       "honest_runs_with_positive_short_epochs_accepted": sum(
                           record["parameters"]["policy"] == policy and short(record) > 0 for record in honest_records),
                       "honest_runs_positive_short_epochs_accepted": sum(
                           short(record) for record in honest_records if record["parameters"]["policy"] == policy)}
                      for policy in ("fixed-target", "periodic-target")],
        "scope": "generated-block checks in all-honest cases; not only the final canonical chain",
        "fixed_target_has_no_periodic_retarget_epochs": True,
    }
    ranked = sorted(pairs, key=lambda pair: (-abs(int(pair["private_minus_honest_quantum_adopted_credit"])), pair["pair_id"]))
    selected = [pair["pair_id"] for pair in ranked[:4]]
    for policy in ("fixed-target", "periodic-target"):
        candidate = next(pair["pair_id"] for pair in ranked if pair["policy"] == policy)
        if candidate not in selected:
            selected.append(candidate)
    most_negative = min(pairs, key=lambda pair: (int(pair["private_minus_honest_quantum_adopted_credit"]), pair["pair_id"]))
    if most_negative["pair_id"] not in selected:
        selected.append(most_negative["pair_id"])
    for name, expected in original_hashes.items():
        if sha(read_regular(INPUT / name)) != expected:
            raise ValueError("ORIGINAL_CHANGED_DURING_ANALYSIS")
    if sha(read_regular(INPUT / "manifest.json")) != sha(manifest_raw):
        raise ValueError("ORIGINAL_MANIFEST_CHANGED")
    result = {
        "schema": "trnm-joint-resource-posthoc-description-v1",
        "source": SOURCE, "started_utc": started, "ended_utc": datetime.now(timezone.utc).isoformat(),
        "original_campaign_directory": str(INPUT), "original_manifest_sha256": sha(manifest_raw),
        "original_manifest_members": len(files), "original_member_bytes": original_bytes,
        "original_report_sha256": files["report.json"], "original_roster_sha256": files["roster.json"],
        "input_hashes_reverified_after_analysis": True,
        "scope": "posthoc descriptive aggregation of all retained original 128 cases",
        "new_simulator_executions": 0, "new_independent_samples": 0,
        "attack_probability_estimated": False, "policy_or_seed_selection_performed": False,
        "by_policy": by_policy,
        "by_policy_environment": [{"policy": key[0], "environment": key[1], **summarize_pairs(values)}
                                  for key, values in sorted(groups.items())],
        "by_policy_quantum_clock": [{"policy": key[0], "quantum_iteration_seconds": key[1], **summarize_pairs(values)}
                                    for key, values in sorted(clocks.items())],
        "by_policy_environment_quantum_clock": [
            {"policy": key[0], "environment": key[1], "quantum_iteration_seconds": key[2], **summarize_pairs(values)}
            for key, values in sorted(cells.items())],
        "totals": totals, "honest_short_epochs": short_epochs,
        "largest_absolute_paired_delta_ids": [pair["pair_id"] for pair in ranked[:4]],
        "most_negative_paired_delta_id": most_negative["pair_id"],
        "selected_extreme_details": [details[pair_id] for pair_id in selected],
        "extreme_selection_scope": "posthoc reporting only; no seed deletion, model tuning or qualification inference",
        "all_pair_deltas": pairs,
        "limitations": [
            "Offered hypothetical clocks/processors match; physical resource fairness is unqualified.",
            "The delivery-delay model has no bandwidth/byte/validation-queue budget.",
            "Proof-cost and participation sensitivities are not task-supply experiments.",
            "Prefix/reorganization counters are finite proxies, not CP/CG/CQ failure probabilities.",
            "A private quantum miner's extra adopted credit is not a physical-resource or profitable-network attack proof.",
            "The declared strategy is compressed-only with scheduled release, not an optimal Bailey-Sattath policy.",
            "Across-policy credit totals are endogenous to target evolution and do not supply a common physical price.",
        ],
        "physical_resource_fairness_qualified": False, "network_byte_budget_qualified": False,
        "production_consensus_activation": False, "release_ready": False,
    }
    with OUTPUT.open("xb") as stream:
        stream.write((json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + "\n").encode())
    summary = {key: value for key, value in result.items() if key != "all_pair_deltas"}
    summary["all_pair_deltas_retained_in"] = str(OUTPUT)
    summary_path = OUTPUT.with_name("summary.json")
    with summary_path.open("xb") as stream:
        stream.write((json.dumps(summary, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode())
    print(json.dumps({"result": "POSTHOC_DESCRIPTION_RECORDED", "output": str(OUTPUT),
                      "analysis_bytes": OUTPUT.stat().st_size,
                      "analysis_sha256": sha(OUTPUT.read_bytes()), "new_simulator_executions": 0,
                      "by_policy": by_policy, "by_policy_quantum_clock": result["by_policy_quantum_clock"],
                      "honest_short_epochs": short_epochs, "totals": totals}, sort_keys=True))


if __name__ == "__main__":
    main()
