#!/usr/bin/env python3
"""Publish the frozen HOLD candidate through the authorized native gh channel."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

ROOT = Path('/home/qian-qi/work/chain-pq-composition-663507-20261108')
REPO = ROOT / 'repo'
OUT = ROOT / 'publish-initial-5633'
BODY = ROOT / 'pr-body-initial-terminal-5633.md'
HEAD = '5633c55219c01c689f670c2ca35d122e39f3f791'
TREE = '3baafa8923d1a1e7bfb6f24cff9965a4e82fba4c'
BRANCH = 'fix/chain-pq-composition-20261108-663507'
BASE = 'fix/chain-p0-unified-qualification-20261108-99b5'
BASE_HEAD = '7e044b65454f4c9ea505591727332acffb33e7e5'
REPOSITORY = 'TrillionniumFoundation/Trillionnium-Chain'
ACTOR = 'ProfHepta'
BODY_SHA = '7a779294355e83097013b8204d7d8bc35b2b79132c3de91a80e35a9df2bd4b58'
TITLE = 'Compose PQ authority, content-byte binding and exact-source evidence'
ANCESTORS = [
    'd0a567658ae907ad51e45538b90130402c79a3d0',
    'f63890781e21f65e3779f3a6f1ce27aaaa804b94',
    '50a1fad7156dedd7db31f08a4bb1c94cc0c9d015',
    'ebc31f07f96060fe1e9fb165aae0123de0fcbc1a',
    'a49bcd0c1f88cacf35421208977df3ae9d9df3af',
    '0788c44f4139c74772a8a9d7d475821f56e5b727',
]
PR_JQ = '{number,html_url,state,draft,title,body,user:.user.login,head:{ref:.head.ref,sha:.head.sha,repo:.head.repo.full_name},base:{ref:.base.ref,sha:.base.sha,repo:.base.repo.full_name}}'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    with (OUT / name).open('x') as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write('\n')


def run(label, argv, timeout=180, private_stdout=False):
    started = time.time()
    record = {'label': label, 'argv': argv, 'cwd': str(REPO), 'start': started}
    try:
        completed = subprocess.run(argv, cwd=REPO, capture_output=True, timeout=timeout)
        stdout, stderr = completed.stdout, completed.stderr
        record.update(returncode=completed.returncode, duration=time.time() - started,
                      stdout_sha256=digest(stdout), stderr_sha256=digest(stderr),
                      stdout_size=len(stdout), stderr_size=len(stderr))
        if private_stdout:
            record['stdout_redacted'] = True
        else:
            (OUT / (label + '.stdout')).write_bytes(stdout)
        (OUT / (label + '.stderr')).write_bytes(stderr)
        save(label + '.json', record)
        if completed.returncode:
            raise RuntimeError(f'{label}: exit {completed.returncode}; inspect retained receipt')
        return stdout.decode('utf-8')
    except subprocess.TimeoutExpired as error:
        record.update(timed_out=True, duration=time.time() - started)
        if not private_stdout:
            (OUT / (label + '.stdout')).write_bytes(error.stdout or b'')
        (OUT / (label + '.stderr')).write_bytes(error.stderr or b'')
        save(label + '.json', record)
        raise


def source_guard(label):
    value = {
        'head': run(label + '-head', ['git', 'rev-parse', 'HEAD']).strip(),
        'tree': run(label + '-tree', ['git', 'rev-parse', 'HEAD^{tree}']).strip(),
        'branch': run(label + '-branch', ['git', 'branch', '--show-current']).strip(),
        'status': run(label + '-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all']),
    }
    save(label + '.json', value)
    assert value == {'head': HEAD, 'tree': TREE, 'branch': BRANCH, 'status': ''}, value


def refs(label):
    raw = run(label, ['git', 'ls-remote', '--heads', 'origin',
                     'refs/heads/' + BASE, 'refs/heads/' + BRANCH])
    found = {}
    for line in raw.splitlines():
        sha, ref = line.split('\t')
        assert ref not in found
        found[ref] = sha
    assert found.get('refs/heads/' + BASE) == BASE_HEAD, found
    assert found.get('refs/heads/' + BRANCH) in (None, HEAD), found
    return found


def read_pr(label, number):
    return json.loads(run(label, ['gh', 'api', f'repos/{REPOSITORY}/pulls/{number}',
                                 '--jq', PR_JQ]))


def check_our_pr(pr):
    assert pr['state'] == 'open' and pr['draft'] is True, pr
    assert pr['user'] == ACTOR and pr['title'] == TITLE, pr
    assert pr['head'] == {'ref': BRANCH, 'sha': HEAD, 'repo': REPOSITORY}, pr
    assert pr['base'] == {'ref': BASE, 'sha': BASE_HEAD, 'repo': REPOSITORY}, pr
    assert pr['body'].replace('\r\n', '\n').rstrip() == BODY.read_text().rstrip()


def main():
    OUT.mkdir(exist_ok=False)
    runner_before = digest(Path(__file__).read_bytes())
    save('intent.json', {'pid': os.getpid(), 'started': time.time(), 'head': HEAD,
                         'tree': TREE, 'runner_sha256': runner_before,
                         'body_sha256': BODY_SHA, 'scope': 'ordinary push and Draft creation only'})
    result = {'status': 'INCOMPLETE', 'head': HEAD, 'tree': TREE,
              'source_unchanged': False, 'runner_sha256': runner_before}
    try:
        assert digest(BODY.read_bytes()) == BODY_SHA
        run('preflight-before', ['bash', 'scripts/project-preflight.sh'])
        source_guard('source-before')
        origin = run('origin', ['git', 'remote', 'get-url', 'origin'], private_stdout=True).strip()
        assert origin in {
            f'https://github.com/{REPOSITORY}', f'https://github.com/{REPOSITORY}.git',
            f'git@github.com:{REPOSITORY}.git', f'ssh://git@github.com/{REPOSITORY}.git',
        }, 'Unexpected origin; raw value deliberately omitted'
        for index, ancestor in enumerate(ANCESTORS):
            run(f'ancestor-{index}', ['git', 'merge-base', '--is-ancestor', ancestor, HEAD])
        actor = run('actor-before', ['gh', 'api', 'user', '--jq', '.login']).strip()
        assert actor == ACTOR, actor
        base_pr = read_pr('base-pr-before', 812)
        assert base_pr['state'] == 'open' and base_pr['draft'] is True
        assert base_pr['head'] == {'ref': BASE, 'sha': BASE_HEAD, 'repo': REPOSITORY}
        before_refs = refs('remote-refs-before')
        endpoint = f'repos/{REPOSITORY}/pulls?state=all&head=TrillionniumFoundation:{BRANCH}&base={BASE}&per_page=100'
        existing = json.loads(run('existing-prs', ['gh', 'api', endpoint, '--jq', '[.[] | ' + PR_JQ + ']']))
        assert len(existing) <= 1, 'Ambiguous existing PRs; no mutation performed'
        if existing:
            check_our_pr(existing[0])
            result['existing_pr_reused'] = True
            number = existing[0]['number']
        else:
            source_guard('source-pre-push')
            run('preflight-push', ['bash', 'scripts/project-preflight.sh'])
            if before_refs.get('refs/heads/' + BRANCH) != HEAD:
                run('push', ['git', 'push', '--porcelain', 'origin', 'HEAD:refs/heads/' + BRANCH], timeout=600)
            else:
                save('push-reused.json', {'remote_branch_already_at_head': HEAD})
            pushed = refs('remote-refs-after-push')
            assert pushed.get('refs/heads/' + BRANCH) == HEAD
            url = run('create-draft', ['gh', 'pr', 'create', '--repo', REPOSITORY,
                      '--draft', '--base', BASE, '--head', BRANCH,
                      '--title', TITLE, '--body-file', str(BODY)], timeout=300).strip()
            assert url.startswith(f'https://github.com/{REPOSITORY}/pull/')
            number = int(url.rsplit('/', 1)[1])
            result['existing_pr_reused'] = False
        actual = read_pr('pr-after', number)
        check_our_pr(actual)
        assert refs('remote-refs-final').get('refs/heads/' + BRANCH) == HEAD
        assert run('actor-after', ['gh', 'api', 'user', '--jq', '.login']).strip() == ACTOR
        source_guard('source-after')
        assert digest(BODY.read_bytes()) == BODY_SHA
        assert digest(Path(__file__).read_bytes()) == runner_before
        result.update(status='PUBLISHED_DRAFT_HOLD', pr=actual,
                      source_unchanged=True, no_activation=True)
    except BaseException as error:
        result.update(status='FAILED_OR_UNCERTAIN_REQUIRES_READBACK',
                      error_type=type(error).__name__, error=str(error),
                      traceback=traceback.format_exc())
        raise
    finally:
        result['finished'] = time.time()
        save('summary.json', result)
        print(json.dumps({key: value for key, value in result.items() if key != 'pr'}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
