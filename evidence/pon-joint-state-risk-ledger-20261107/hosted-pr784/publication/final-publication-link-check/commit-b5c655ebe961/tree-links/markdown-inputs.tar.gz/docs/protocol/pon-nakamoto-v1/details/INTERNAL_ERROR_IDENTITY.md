# Native internal error identity

The native Node retains its existing display and wire error strings while
carrying `ErrorCode`, `ErrorKind` and an optional typed underlying cause in
`trnm-pon-node/src/error.rs`. This changes no signed domain, stored schema,
profile selection, error precedence or admission rule. A code identifies an
observed failure; it does not by itself establish remote authentication,
transaction non-entry, persistence, membership or permission to retry.

## Construction and scope

Exact registered local codes are classified once when constructed. There is no
prefix-based classification. Typed `std::io`, SQLite and JSON conversions keep
the original cause for `std::error::Error::source()` and preserve the respective
`IO: `, `STORAGE: ` and `JSON: ` display prefixes. Their message text is never
parsed as a protocol code. Thus an IO cause containing `FRAME_EOF` is still an
IO error and cannot acquire the local frame-EOF retry identity.

Known codes cover the decisions migrated below and selected protocol,
capacity, cancellation, context and identity failures. Other legacy strings,
including formatted work, task and some authenticated-ingress diagnostics, remain
`Unclassified`; this is not a claim that every Node error producer has been
migrated. A new structural code must be registered explicitly rather than
inheriting a shutdown policy through its spelling.

Stored-data provenance is assigned where the Node has actually selected an existing
local record. `local_integrity` preserves the original diagnostic/code and typed cause
while marking a failed retained header, ancestry link, canonical KV/root, undo delta,
reorganization step or generation invariant as `LocalStructure`. The same code on a
new packet or unknown caller-supplied locator has no such authority. In particular,
`UNKNOWN_PARENT` from a missing ancestor of an already retained block stops the owner;
an ordinary unknown polling locator remains `StaleContext` and keeps its bounded
retry behavior. The polling lookup therefore tests both code and origin.

`local_replay_source` similarly keeps the typed replay/outbox reconstruction or
recovery cause and original `AUTH_REPLAY:`, `AUTH_RECOVERY:` and
`AUTH_OUTBOX_RECOVERY:` text. It is applied to local retained journals, not incoming
frame conflicts. No recovery/shutdown decision parses those prefixes. Progress
callbacks, visitor errors, cancellation, clock deferral and reorganization fault hooks
are deliberately outside these provenance conversions. Complete untrusted operations
must never be wrapped merely because they can also access the store.

The authenticated replay/outbox store also retains the transport boundary's typed
admission and exact-payload verification causes. `peer_admission_source` and
`peer_frame_source` preserve the original `AUTH_REPLAY:`, `AUTH_OUTBOX:`,
`AUTH_FRAME:` and `AUTH_OUTBOX_FRAME:` text; their categories come from
`PeerAdmissionErrorV0`, independently of its human description. A conflicting frame
or acknowledgement is an identity conflict, a pending frame is capacity, and a stale
nonce/token is stale context. Exact payload rejection is protocol invalid. None of
these input boundaries grants owner-stop authority or a new retry policy.

After the store has selected an acknowledged local audit row, an invalid completed
response/retirement shape is `LocalStructure` with the unchanged
`AUTH_REPLAY_AUDIT` diagnostic. A conditional replay/outbox transition affecting the
wrong number of rows is similarly local because recovery and acknowledgement have
already verified its exact pending frame. Both the completed audit update and replay
frontier update must affect exactly one row before the same transaction commits; a
failed second update rolls back the first. The inbound replay/audit reservation and
outbound reservation likewise each require an exact one-row write before reporting
`Execute` or returning the durable wire. A failed local write rolls back the whole
reservation, including an already written replay row. By contrast, a missing caller
session keeps
`AUTH_REPLAY_STATE`/`AUTH_OUTBOX_STATE` as stale context, and an actually retired reply
keeps `AUTH_REPLAY_RETIRED` as stale context. The same `AUTH_OUTBOX_STATE` text thus has
different origin at a failed caller lookup and a failed retained transition. Neither
the raw code nor a peer's structural-looking text establishes retained origin.

The explicit revision14 composition refusals are also registered individually.
Configuration/profile/current-parent mismatches are stale context; missing bundle
gain, nonpositive marginal gain and exactly cancelling component subsets are policy
refusals. Invalid count/order/range/slot/state/derivation/weight are protocol failures.
None acquires local database-corruption or owner-stop authority, and these categories
do not grant a generic retry. Earlier profile codes and their wire strings are retained.

Remote business failures are marked `RemoteRefusal` at the existing validated
reply boundary and retain no local `ErrorCode`. Submit recovery recognizes only
the exact authenticated response fields `UNKNOWN_PARENT` and
`PUBLIC_MUTATION_CPU_BUDGET`, using a private response-recovery enum after the
existing signature and request-context verification. Those two existing business
responses permit bounded parent restoration or membership observation; they do
not turn remote text into local EOF, database, owner or generic retry authority.
Prefixes, suffixes and other signed labels remain ordinary remote refusals.
The existing authenticated session constructor derives terminal/retryable
identity from the already verified terminal flag, independently of error text.
Its `REMOTE_TERMINAL:` and `REMOTE_RETRYABLE:` display strings remain unchanged.

The production held-owner public History budget and explicit cfg(test) cumulative
readonly research budget have one private local request origin. Only actual
pre-SQL resource exhaustion selects it; invalid trusted maxima and callback
errors retain their own origins. `public_history_budget` constructs only the existing
`ANCESTRY_INDEX_BUDGET` code and Capacity category. Exhausting that whole-request
SQL allowance yields no Page and keeps a healthy owner available. Parsing a
string, including that exact string, cannot select this origin; authenticated
remote-reply construction remains separate. Invalid trusted configuration and
the original unrecorded ancestry-owner budget keep their old stop policy.
`local_integrity` still overrides even the request-budget origin. This narrow
distinction grants no generic retry and downgrades no schema, packet or stored
read-fact failure. The [readonly History contract](HISTORY_STATE_RESOURCE_BOUNDS_V1.md#operation-local-readonly-public-history)
defines the cumulative cap and actual signed refusal/retry control.

## Recovery decisions

| Path | Typed condition | Recovery behavior |
| --- | --- | --- |
| Pinned polling | Local owner, namespace/database replacement, storage or validated ancestry structure failure | Preserve failure/cursor, return error, stop shared runtime |
| Pinned polling | `ANCESTRY_INDEX_BUDGET` | Stop as before; kind is capacity, not a corruption diagnosis |
| Pinned polling | Unknown parent/block, remote refusal, ordinary transport error | Preserve target/cursor and wait for next bounded cycle |
| Pinned polling | `PEER_POLL_CANCELLED` | Normal runtime/shared-stop completion |
| Submit recovery | Local `FRAME_EOF` at `challenge` or `solution-body-response` | Existing bounded membership check/retry |
| Submit recovery | Verified remote `UNKNOWN_PARENT` | Existing bounded retained-parent restoration when enabled |
| Submit recovery | Verified remote `PUBLIC_MUTATION_CPU_BUDGET` | Existing membership check and finite epoch/call/attempt budget |
| Submit recovery | Other errors, including `STATE_CAPACITY` and CPU accounting unavailable | No new recovery or retry |
| Original admission / V2 / V3 | Exact reserved-capacity, spent-ticket-replay and scalar CPU-budget codes | Original response precedence and metrics |

`ErrorKind` is diagnostic grouping, not a generic retry table. In particular,
capacity can mean a permanent candidate refusal, an exhausted whole-operation
budget or a narrowly retryable remote CPU reservation. The call site still
requires the exact code, original operation/stage and existing finite limits.
No new ingress owner, supervisor, implicit fallback or cross-profile admission
adapter is introduced.

The public V3 client's failed phase also carries `PublicClientStage`, rather than
selecting retry, uncertain-submission reporting or elapsed-time accounting by a
diagnostic string. `Construction`, `Challenge`, `SolutionSearch`,
`SolutionBodyResponse` and `Complete` serialize to exactly the prior labels;
`failed_stage: null` is unchanged. An unknown static diagnostic remains
representable as `Unknown(label)`, but its text grants no native phase authority,
including a label identical to `challenge`. The client constructs known variants
at its actual phase transitions. Existing metrics are output-only (`Serialize`),
so no old-record deserialization format is narrowed or newly accepted. This is a
Rust field-type refinement; JSON observation fields, signed replies, retry limits
and stage timing boundaries remain unchanged.

## Verification

Native error tests preserve source types and exact displays, alter diagnostic
text without altering typed decisions, reject prefix lookalikes, and prevent
remote structural names from stopping a local owner. The polling regression
executes the actual rejection/event path for local SQLite/structure errors,
remote and IO errors, missing ancestry and ancestry-budget exhaustion. The
Submit recovery stage matrix refuses remote EOF claims, IO lookalikes, public
EOF, deadlines and unavailable CPU accounting at every tested stage.

The phase matrix covers all five native stages, `None`, an unknown future phase
and unknown labels resembling the three post-construction phases. It checks exact
retry/uncertainty decisions and preserves every serialized metrics field while
charging only the actual failed phase. The retained real EOF-before-admission and
lost-ACK tests check both the typed phase and original JSON label. A normal local
signed-refusal regression confirms that EOF lookalikes, deadline and stale-context
labels complete one authenticated call and never acquire local EOF retry identity.

The retained real TCP `public_submit_recovery`, `pinned_peer_polling`,
`protected_ingress`, `public_intake_v2` and `public_pool_v3` targets remain
the behavior checks for wire compatibility, signed refusals, bounded retries,
native membership, persisted recovery and original profile separation.

The seven provenance regressions additionally mutate actual test-owned retained
header/KV/undo/journal bytes, execute the real read, recovery and polling paths, and
repair the exact rows before checking successful recovery and cold reopen. They
compare the same diagnostic on an incoming peer response, preserve cancellations
and clock deferral, and verify the concrete nested source type. These are bounded
local integrity tests; they do not declare every legacy formatted error migrated.

The replay transition regressions mutate completed audit response/retirement shape,
force a validated conditional update to affect no row with a temporary test-owned
SQLite trigger, and check rollback, exact repair and cold reopen. Real request and
outbox calls retain pending wire/frame state across conflicting payload, pending-frame
and acknowledgement refusals. Natural response retirement remains nonfatal. Source
tests preserve the concrete transport enum/wrapper, change diagnostic prose and
exercise structural lookalikes without changing the typed origin. These checks cover
the selected store boundaries; they do not add an ingress shutdown policy or certify
all legacy authenticated call sites.

Reservation tests separately suppress each fresh insertion and existing-session
UPSERT, compare the entire prior replay/outbox state and row counts after rollback,
then remove the test trigger and exercise successful reservation, acknowledgement
and cold reopen. The write invariant checks use SQLite's affected-row result and
add no query, schema, signed domain or extra persistence layer.
