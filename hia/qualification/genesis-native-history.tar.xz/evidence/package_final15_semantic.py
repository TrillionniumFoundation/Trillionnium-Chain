from pathlib import Path
import hashlib,io,json,os,sys,tarfile,time,traceback
BASE=Path("/tmp/trnm-genesis-owner-20261116-8ppak97a");ROOT=BASE/"repo";BUNDLE=BASE/"final15-semantic/bundle"
sys.path.insert(0,str(ROOT))
from hia.platform.genesis_store.rust_oracle import validate_bundle,file_identity,identity,need
receipt={"schema":"trnm.genesis-semantic-immutable-transport.v1","status":"FAIL"}
try:
    execution=json.loads((BASE/"final15-semantic-execution.json").read_bytes())
    need(execution["status"]=="PASS" and execution["exit_code"]==0,"Semantic process terminal did not pass")
    admitted=validate_bundle(ROOT,BUNDLE)
    entries={}
    for name,expected in admitted["source_inputs"].items():
        raw=(ROOT/name).read_bytes();need(identity(raw)==expected,"Source changed during packaging")
        entries[name]=raw
    for name,expected in admitted["bundle_artifacts"].items():
        raw=(BUNDLE/name).read_bytes();need(identity(raw)==expected,"Bundle changed during packaging")
        entries["bundle/"+name]=raw
    manifest={name:identity(raw) for name,raw in sorted(entries.items())}
    destination=BASE/"final15-semantic-source-bundle.tar.xz"
    with tarfile.open(destination,"x:xz",preset=6) as archive:
        for name,raw in sorted(entries.items()):
            member=tarfile.TarInfo(name);member.size=len(raw);member.mode=0o600;member.mtime=0
            archive.addfile(member,io.BytesIO(raw))
    observed={}
    with tarfile.open(destination,"r:xz") as archive:
        for member in archive:
            need(member.isfile() and member.name not in observed,"Nonregular or duplicate transport member")
            raw=archive.extractfile(member).read()
            observed[member.name]=identity(raw)
    need(observed==manifest,"Archive member identity differs")
    second=validate_bundle(ROOT,BUNDLE)
    need(second["source_inputs"]==admitted["source_inputs"] and second["original_sources"]==admitted["original_sources"]
         and second["bundle_artifacts"]==admitted["bundle_artifacts"],"Final public gate source changed")
    destination.chmod(0o400)
    receipt.update(status="PASS",path=str(destination),archive=file_identity(destination),
      members=manifest,member_count=len(manifest),source_inputs=admitted["source_inputs"],
      source_set_sha256=admitted["comparison"]["build"]["source_set_sha256"],
      original_source_files=len(admitted["original_sources"]),native_counts=admitted["native_counts"],
      corpus=admitted["comparison"]["corpus"],native_executable=admitted["comparison"]["build"]["executable"],
      semantic_execution=execution,original_rust_executed=False,
      whole_git_tracked_tree_claimed=False)
except BaseException as error:
    receipt["failure"]={"error":repr(error),"traceback":traceback.format_exc()}
finally:
    with (BASE/"final15-semantic-source-bundle.json").open("x") as stream:
        stream.write(json.dumps(receipt,sort_keys=True,indent=2)+"\n")
    print(json.dumps({key:receipt.get(key) for key in ("status","path","archive","member_count",
        "source_set_sha256","original_source_files","native_counts","failure")}),flush=True)
raise SystemExit(0 if receipt["status"]=="PASS" else 1)
