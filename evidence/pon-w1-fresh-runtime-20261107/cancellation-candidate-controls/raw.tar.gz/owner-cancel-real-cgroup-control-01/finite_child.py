import os,sys,time,subprocess,json
from pathlib import Path
out=Path(sys.argv[1])
group=Path('/sys/fs/cgroup')/Path('/proc/self/cgroup').read_text().strip()[3:].lstrip('/')
if len(sys.argv)>2:
    (group/'nested-control'/'cgroup.procs').write_text(str(os.getpid()))
    (out/'nested-ready.json').write_text(json.dumps({'pid':os.getpid(),'time':time.monotonic_ns()}))
    time.sleep(6)
else:
    (group/'nested-control').mkdir(exist_ok=False)
    with (out/'invocations').open('a') as f: f.write('one\n')
    subprocess.Popen([sys.executable,__file__,str(out),'nested'],start_new_session=True)
    limit=time.monotonic()+2
    while not (out/'nested-ready.json').exists() and time.monotonic()<limit: time.sleep(.01)
    assert (out/'nested-ready.json').exists()
