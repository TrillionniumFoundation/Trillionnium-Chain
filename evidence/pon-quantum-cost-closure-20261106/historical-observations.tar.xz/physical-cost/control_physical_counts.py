from dataclasses import replace
from pathlib import Path
import argparse
import hashlib
import json
import sys
parser = argparse.ArgumentParser(description="Reproduce the physical-resource validation control.")
parser.add_argument("--repo", type=Path, default=Path.cwd(),
                    help="Repository root (default: current working directory)")
repo = parser.parse_args().repo.expanduser().resolve()
module_dir = repo / "formal" / "pon-nakamoto-v1"
if not (module_dir / "quantum_oracle_resources.py").is_file():
    parser.error(f"Repository resource module not found under {repo}")
sys.path.insert(0, str(module_dir))
import quantum_oracle_resources as q

base = dict(gate_count=3, gate_depth=3, toffoli_count=1, toffoli_depth=1,
            direct_t_count=1, direct_t_depth=1)
model = q.example(True).physical_models[0]
cases = {
    "nonempty_zero_depth": dict(gate_count=100, gate_depth=0, toffoli_count=0,
                                toffoli_depth=0, direct_t_count=0, direct_t_depth=0),
    "gate_subtotal_exceeds_total": dict(base, gate_count=1, gate_depth=1),
    "component_dependency_exceeds_total_depth": dict(base, gate_depth=1, toffoli_depth=2, toffoli_count=2),
    "component_nonempty_zero_depth": dict(base, toffoli_depth=0),
    "depth_exceeds_gate_count": dict(base, gate_count=3, gate_depth=4),
}
print(json.dumps({"source_sha256": hashlib.sha256(Path(q.__file__).read_bytes()).hexdigest()}))
accepted = 0
for name, counts in cases.items():
    try:
        report = q.physical_estimate(counts, 3, 1, model)
    except ValueError as error:
        print(json.dumps({"case": name, "rejected": str(error)}))
        continue
    accepted += 1
    estimate = report.get("estimate")
    print(json.dumps({"case": name, "accepted": report["status"],
                      "allocated_code_cycles": estimate["allocated_code_cycles_per_instance"] if estimate else None,
                      "quantum_wall_seconds": estimate["quantum_wall_seconds_serial_magic_delivery_schedule"] if estimate else None}))
print(json.dumps({"malformed_accepted": accepted, "required": 0}))
sys.exit(bool(accepted))
