# 当前原生输入域 oracle 与回读器：最终独立复核片段

**复核结论：当前回读器已接入版本化原生输入域 oracle，已复现的空父历史、时间乘积溢出和超界时间戳输入得到拒绝；历史冻结模型及其原始证据保持可复查。** 这一结果限定于 arithmetic oracle 与当前回读器的一致性。

## 精确来源与实际复核

基线提交为 `62378d28415ead28b5f99ec6ea6033fde93e3215`；本次复核提交为 `0c589e2212f7feeaac4ec12d076d27ab139bc52f`，工作树为 `/workspace/scratch/29db5f3d3825/fixed`，复核时干净。已逐字节比对该提交的 oracle、测试、V2 向量、两个回读器及 `consensus.rs`。这些文件与较早候选 `ce4c5e7a6bc7e69805698b3e1131b425d093eceb` 相同；两候选间的差异只在 journal 的 IO 错误转换。精确长度、SHA-256、Git blob 与本次冻结输入检查结果保存在 `final-review-bindings.json`。

## 修复范围

基线复现中，历史 `reference.py` 把空 ancestry 判为 `admissible`，对原生 `u64` 时间乘积会溢出的参数仍计算出整数结果，并允许超出 `u64` 的时间戳进入抽象时间判断。原生 `consensus.rs` 已有相应的父历史与 checked arithmetic 拒绝。这些观察定位了 Python 抽象模型用于当前原生回读时的输入域差异；没有得到被原生完整验证接纳的假工作。

新增 `native_consensus_reference_v1.py` 独立使用 Python 整数计算，并显式限制原生非零 `u256` target 与 `u64` 时间域，检查 `(interval-1)*spacing` 和其四倍的原生溢出条件，保持 saturating subtraction、上中位数、最近 11 个祖先及先中位数后未来时间检查的顺序。未来时间上界保留原生 `u128` 加法语义，允许 `now+skew` 超过 `u64::MAX`，不会错误地把合法边界拒绝。Python 的 `TIMESTAMP_DOMAIN` 表示不可编码为原生 `u64` 的输入域拒绝，不应描述成一个新的线上共识错误码。

V2 向量保留全部 75 条历史结果并增加 8 条原生可表示的 retarget 拒绝向量，共 83 条。Rust 测试同时消费历史 V1 和新增 V2；`consensus.rs` 的生产部分与基线逐字节相同。本次原生规则没有依赖 Python 执行。

## 历史冻结与当前读者

历史 `reference.py`、`test_reference.py` 和原始 75 条向量仍与基线及不可变 work-cost contract 的原始长度、SHA-256、Git blob 一致。早先直接替换历史文件引发的实际 `FROZEN_REPLAY_INPUT_DRIFT:formal/pon-nakamoto-v1/reference.py` 拒绝保存在 `frozen-replay-binding-refusal.log`，没有通过改写旧 pin 消除。历史 work-cost contract 自身固定的参考提交是 `b16bae2824e6c8236ef2011fc93a74df3ac7f039`，需与本轮集成基线 `62378d…` 区分。

本次在精确 `0c589e…` 工作树实际执行了 `check_reused_inputs`，8 个复用的冻结输入均通过原始绑定检查。这是复用输入一致性结果，不是一个新的 native 成本资格结果。

`pon_daa_schedule_reader.py` 直接导入新 oracle；`pon_joint_daa_reader.py` 共享同一实例。二者继续逐份重算保留的 PNW1 transcript/乘积、header/ticket、分支 target、时间与累计 required work。返回结果仍明确区分 Python 回放与外部原生 runner 的观察：AAM1 账户证明、M06 执行、原生数据库接纳/冷重开及主机/来源 provenance 不会由报告哈希或 Python PASS 自动获得资格。

留存的同字节 Python 验证为：原生域 13/13、历史 reference 29/29、保留 schedule 10/10、PNH1 21 通过加 1 条 PGH2 专属跳过、PGH2 22/22。此次最终复核重新执行的是源绑定与冻结输入检查；没有在此复核中重新执行 Rust 或 service campaign。父任务的精确提交 native 结果应另行列出。

三个实际回读测试入口如下，工作目录为精确候选仓库根目录：

```bash
python3 -B scripts/ci/test_pon_daa_schedule_reader.py --raw-dir evidence/pon-joint-consensus-daa-20261108/native-retained-final -v
python3 -B scripts/ci/test_pon_joint_daa_reader.py --raw-dir evidence/pon-joint-consensus-daa-20261108/native-run-03/pnh1-authenticated -v
python3 -B scripts/ci/test_pon_joint_daa_reader.py --raw-dir evidence/pon-joint-consensus-daa-20261108/native-run-03/pgh2-growth -v
```

## 保留的安全命题边界

| 命题 | 本轮 oracle 修复之外仍需建立的证据 |
|---|---|
| 真实任务需求 | 独立需求、授权、资源与真实付款。 |
| 正确计算与交付 | 规定 PNW1 关系可回放；完整任务关系、实际接收和读取仍需对应证据。 |
| 模型净收益 | 冻结且独立的未来任务、净收益，以及全部失败与训练成本。 |
| 共识工作成本 | 最省合法策略在缓存、共享准备、任务选择、硬件、多目标摊销及失败/放弃下的成本界。 |

这些命题不能由同一个 arithmetic PASS 代替。原有未证明的成本界继续保持 `unproved`；本次结果也不建立公共前缀、链增长、链质量、六确认失败概率、量子攻击盈利性或开放网络服务活性。历史广义整数模型可以继续承担其原定研究角色，原生边界检查由新增版本及其对应测试承担。
