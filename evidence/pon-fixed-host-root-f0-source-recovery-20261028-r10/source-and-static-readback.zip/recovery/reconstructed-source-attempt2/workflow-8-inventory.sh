set -uo pipefail
source_status=1
if [ "$SOURCE_OUTCOME" = success ]; then
  python3 scripts/ci/verify_ci_source.py --kind head --expected-head "$EXPECTED_HEAD" --output "$OUT/source-after.json" > "$OUT/source-after.log" 2>&1
  source_status=$?
fi
export F0_SOURCE_AFTER_STATUS="$source_status"
python3 - <<'PY'
import hashlib, json, os, stat, uuid
from pathlib import Path
out = Path(os.environ['OUT'])
outcome = {key: os.environ[key] for key in (
    'SOURCE_OUTCOME','TOOLCHAIN_OUTCOME','PREPARATION_OUTCOME','ARM_OUTCOME',
    'EXECUTION_OUTCOME','FINALIZATION_OUTCOME','F0_SOURCE_AFTER_STATUS')}
with (out/'workflow-outcomes.json').open('x') as stream:
    json.dump(outcome, stream, indent=2, sort_keys=True)
    stream.write('\n')
files, paths, errors = [], [], []
for path in sorted(out.rglob('*')):
    try:
        before = path.lstat()
        if stat.S_ISDIR(before.st_mode):
            continue
        if not stat.S_ISREG(before.st_mode) or path.resolve(strict=True) != path or '\n' in str(path) or '\r' in str(path):
            raise ValueError('only exact regular artifact paths may be uploaded')
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024*1024), b''):
                digest.update(chunk)
        after = path.lstat()
        if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns) != (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):
            raise ValueError('artifact changed during inventory')
        files.append({'path': str(path.relative_to(out)), 'bytes': before.st_size, 'sha256': digest.hexdigest()})
        paths.append(str(path))
    except (OSError, ValueError) as error:
        errors.append({'path': str(path.relative_to(out)), 'failure': str(error)})
manifest = out/'artifact-files.json'
with manifest.open('x') as stream:
    json.dump({'schema':'fixed-host-root-f0-artifact-inventory-v1',
               'files':files, 'errors':errors, 'all_files_retained':not errors,
               'scope':'all regular success, failure and partial evidence; not a PASS verdict'},
              stream, indent=2, sort_keys=True)
    stream.write('\n')
paths.append(str(manifest))
boundary = 'F0_FILES_'+uuid.uuid4().hex
with open(os.environ['GITHUB_OUTPUT'], 'a') as stream:
    stream.write('paths<<'+boundary+'\n'+'\n'.join(paths)+'\n'+boundary+'\n')
raise SystemExit(1 if errors else 0)
PY
inventory_status=$?
test "$source_status" -eq 0 && test "$inventory_status" -eq 0
