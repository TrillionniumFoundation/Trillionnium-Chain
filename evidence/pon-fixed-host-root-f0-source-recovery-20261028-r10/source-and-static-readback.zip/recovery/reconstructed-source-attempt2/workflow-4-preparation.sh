set -euo pipefail
test "$(uname -m)" = x86_64
python3 scripts/run_fixed_host_root_f0.py prepare --out "$OUT/prepared" \
  --expected-head "$EXPECTED_HEAD" --expected-tree "$EXPECTED_TREE" \
  --cargo "$(command -v cargo)" --target-dir "$CARGO_TARGET_DIR" \
  > "$OUT/preparation.stdout.log" 2> "$OUT/preparation.stderr.log"
