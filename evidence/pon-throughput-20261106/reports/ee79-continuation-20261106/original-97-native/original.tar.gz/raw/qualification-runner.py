#!/usr/bin/env python3
"""Run original source-bound qualification commands in an isolated checkout.

The operator supplies the existing provider, PATH, CARGO_HOME and an external
CARGO_TARGET_DIR. Nothing here edits source, installs dependencies, changes a
profile or converts an ignored/failed/unexecuted test into a pass. Each public
stage uses the repository's original command recorder. The controls child is
inside one such recording and keeps every selected native/checker command.
Reuse one --out for different stages; never overwrite or retry an existing stage.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time
import tomllib

EXPECTED_CONTROLS = 105
MANIFEST = 'trillionnium/Cargo.toml'
CARGO = ['cargo', '+1.95.0']
BUILD = CARGO + ['test', '--locked', '--manifest-path', MANIFEST,
                 '--workspace', '--all-targets', '--all-features', '--no-run',
                 '--message-format=json']
OVERRIDES = ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC', 'RUSTC_WRAPPER',
             'RUSTC_WORKSPACE_WRAPPER', 'RUSTC_BOOTSTRAP', 'RUSTDOC',
             'RUSTDOCFLAGS', 'CARGO_ENCODED_RUSTDOCFLAGS', 'CARGO_BUILD_RUSTC',
             'CARGO_BUILD_RUSTDOC', 'CARGO_BUILD_RUSTFLAGS', 'CARGO_BUILD_TARGET',
             'CARGO_BUILD_RUSTC_WRAPPER', 'CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER')
ENVIRONMENT = ('PATH', 'CI', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
               'CARGO_INCREMENTAL', 'RUST_TEST_THREADS', 'OPENSSL_DIR',
               'OPENSSL_STATIC', 'OPENSSL_CONF', 'OPENSSL_MODULES',
               'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256',
               'TRNM_PQ_OPENSSL_VERSION', 'PYTHONOPTIMIZE') + OVERRIDES
PACKAGES = {'m06': ('trnm-mvcc-fee', 'trnm_mvcc_fee', '1'),
            'node': ('trnm-pon-node', 'trnm_pon_node', '3')}


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def utc():
    return datetime.now(timezone.utc).isoformat()


def strict_json(text):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate JSON key: ' + key)
            result[key] = value
        return result

    def constant(_):
        raise ValueError('nonfinite JSON number')

    return json.loads(text, object_pairs_hook=pairs, parse_constant=constant)


def write_json(path, value, *, exclusive=False):
    with path.open('x' if exclusive else 'w', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def file_facts(path, *, elf=False):
    """Hash a fixed regular file, detecting observed replacement or mutation."""
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'regular file required: ' + str(path))
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
    value = hashlib.sha256()
    with os.fdopen(os.open(path, flags), 'rb') as stream:
        require(fingerprint(os.fstat(stream.fileno())) == fingerprint(before),
                'file changed before hashing: ' + str(path))
        if elf:
            require(stream.read(4) == b'\x7fELF', 'native ELF required: ' + str(path))
            stream.seek(0)
        remaining = before.st_size
        while remaining:
            chunk = stream.read(min(1024 * 1024, remaining))
            require(chunk, 'file truncated while hashing: ' + str(path))
            value.update(chunk)
            remaining -= len(chunk)
        require(not stream.read(1)
                and fingerprint(os.fstat(stream.fileno())) == fingerprint(before)
                and fingerprint(path.lstat()) == fingerprint(before),
                'file changed while hashing: ' + str(path))
    return {'path': str(path), 'bytes': before.st_size,
            'sha256': value.hexdigest(), 'fingerprint': list(fingerprint(before))}


def check_fingerprint(facts):
    require(list(fingerprint(Path(facts['path']).lstat())) == facts['fingerprint'],
            'native artifact changed: ' + facts['path'])


def environment(repo):
    env = dict(os.environ)
    # Suppress Python bytecode only; preserve all actual Cargo/provider settings.
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['GIT_OPTIONAL_LOCKS'] = '0'
    require(sys.flags.optimize == 0 and env.get('PYTHONOPTIMIZE') in (None, '', '0'),
            'original selector assertions must remain enabled')
    require(not any(env.get(key) for key in OVERRIDES), 'unexpected compiler override')
    require(not any(key.startswith('CARGO_PROFILE_') for key in env),
            'unexpected Cargo profile override')
    require(not any(value for key, value in env.items()
                    if key.startswith('CARGO_TARGET_')
                    and key.endswith(('_RUSTFLAGS', '_LINKER', '_RUNNER'))),
            'unexpected Cargo target override')
    target = Path(env.get('CARGO_TARGET_DIR', ''))
    require(target.is_absolute() and not target.resolve().is_relative_to(repo),
            'absolute external CARGO_TARGET_DIR required')
    require(env.get('OPENSSL_STATIC') == '1'
            and env.get('TRNM_PQ_OPENSSL_VERSION') == '3.5.9',
            'original static OpenSSL 3.5.9 provider required')
    provider = Path(env.get('TRNM_PQ_OPENSSL', ''))
    require(provider.is_absolute(), 'absolute pinned provider executable required')
    require(file_facts(provider)['sha256'] == env.get('TRNM_PQ_OPENSSL_SHA256'),
            'provider executable SHA256 mismatch')
    manifest = tomllib.loads((repo / MANIFEST).read_text())
    for package, _, opt in PACKAGES.values():
        profile = manifest['profile']['test']['package'][package]
        require(type(profile['opt-level']) is int and profile['opt-level'] == int(opt)
                and profile['debug-assertions'] is True and profile['overflow-checks'] is True,
                'original test profile changed: ' + package)
    return env


def run_logged(argv, cwd, directory, label, env):
    """Complete command bytes plus argv/cwd/exit; an interrupted record stays running."""
    record_path, log = directory / (label + '.json'), directory / (label + '.log')
    record = {'schema': 'trnm-native-runner-child-command-v1', 'status': 'running',
              'argv': list(argv), 'cwd': str(cwd), 'started_utc': utc(),
              'exit_code': None, 'log_file': log.name}
    write_json(record_path, record, exclusive=True)
    started = time.monotonic_ns()
    try:
        with log.open('xb') as stream:
            process = subprocess.run(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                                     stdout=stream, stderr=subprocess.STDOUT, check=False)
        record['exit_code'] = process.returncode
        record['status'] = 'command_succeeded' if process.returncode == 0 else 'command_failed'
    except OSError as error:
        record.update(status='launch_failed', error=str(error))
    record['elapsed_ns'] = time.monotonic_ns() - started
    record['finished_utc'] = utc()
    if log.exists():
        record['log'] = file_facts(log)
    write_json(record_path, record)
    return record


def source_receipt(record, head):
    before, after = record.get('before'), record.get('after')
    require(type(before) is dict and before == after
            and before.get('schema') == 'trnm-ci-source-v1'
            and before.get('kind') == 'head' and before.get('candidate') == head
            and before.get('tested_commit') == head and before.get('base') is None
            and before.get('prospective_merge') is None
            and before.get('tracked_worktree_verified') is True
            and before.get('tests_executed_by_identity_check') is False,
            'complete unchanged exact-head command source receipt required')


def run_recorded(args, label, command, env):
    recorder = args.repo / 'scripts/ci/record_pq_native_command.py'
    receipt = args.out / (label + '.json')
    require(not receipt.exists() and not (args.out / (label + '.log')).exists(),
            'refusing to overwrite an existing command: ' + label)
    argv = [sys.executable, str(recorder), '--kind', 'head', '--candidate', args.head,
            '--tested', args.head, '--label', label, '--output', str(args.out), '--', *command]
    wrapper = run_logged(argv, args.repo, args.out, label + '-recorder', env)
    result = {'label': label, 'recorder': wrapper, 'passed': False,
              'receipt': str(receipt), 'command': list(command)}
    try:
        record = strict_json(receipt.read_text())
        require(record.get('schema') == 'trnm-pq-native-command-v1'
                and record.get('argv') == command and record.get('cwd') == str(args.repo),
                'wrong command recorder identity')
        result['command_status'] = record.get('status')
        result['command_exit_code'] = record.get('exit_code')
        source_receipt(record, args.head)
        result['source'] = record['before']
        log = args.out / (label + '.log')
        require(record.get('log_file') == log.name
                and record.get('log_sha256') == file_facts(log)['sha256'],
                'recorded command log mismatch')
        result['passed'] = (wrapper['exit_code'] == 0 and record.get('exit_code') == 0
                            and record.get('status') == 'command_succeeded')
    except (OSError, ValueError, KeyError, TypeError) as error:
        result['receipt_error'] = str(error)
    print(json.dumps({'label': label, 'passed': result['passed'],
                      'command_exit_code': result.get('command_exit_code')}), flush=True)
    return result


def selected_artifacts(args, env):
    receipt = strict_json((args.out / 'build.json').read_text())
    source_receipt(receipt, args.head)
    require(receipt.get('status') == 'command_succeeded' and receipt.get('exit_code') == 0
            and receipt.get('argv') == BUILD and receipt.get('cwd') == str(args.repo)
            and receipt.get('log_file') == 'build.log', 'successful original build receipt required')
    build_log = args.out / 'build.log'
    build_facts = file_facts(build_log)
    require(build_facts['sha256'] == receipt.get('log_sha256')
            and build_facts['bytes'] == receipt.get('log_bytes'), 'build log hash/size mismatch')
    target = Path(env['CARGO_TARGET_DIR']).resolve()
    require(Path(receipt['environment']['CARGO_TARGET_DIR']).resolve() == target,
            'controls and build target directories differ')
    rows, finished = {key: [] for key in PACKAGES}, []
    with build_log.open(encoding='utf-8') as stream:
        for line in stream:
            # Recorder preserves stderr too; Cargo's diagnostic text remains in
            # the original log, while structured artifact lines begin with '{'.
            if not line.lstrip().startswith('{'):
                continue
            row = strict_json(line)
            require(type(row) is dict, 'Cargo JSON message object required')
            if row.get('reason') == 'build-finished':
                finished.append(row)
            if row.get('reason') != 'compiler-artifact':
                continue
            for key, (_, name, _) in PACKAGES.items():
                if row.get('target', {}).get('name') == name and row['target'].get('kind') == ['lib']:
                    rows[key].append(row)
    require(len(finished) == 1 and finished[0].get('success') is True,
            'one successful original Cargo build-finished message required')
    selected = {}
    for key, (package, _, opt) in PACKAGES.items():
        require(rows[key], 'missing library artifacts: ' + package)
        for artifact in rows[key]:
            require(Path(artifact['target']['src_path']).resolve()
                    == args.repo / 'trillionnium/crates' / package / 'src/lib.rs',
                    'artifact source belongs to another checkout: ' + package)
            profile = artifact['profile']
            require(profile['opt_level'] == opt and profile['debug_assertions'] is True
                    and profile['overflow_checks'] is True
                    and type(profile['test']) is bool,
                    'artifact original profile mismatch: ' + package)
            require(artifact['features'] == ['default', 'pq-native-openssl'],
                    'artifact complete-workspace features mismatch: ' + package)
        tests = [row for row in rows[key] if row['profile']['test'] and row.get('executable')]
        require(len(tests) == 1, 'one library test executable required: ' + package)
        binary = Path(tests[0]['executable'])
        require(binary.is_absolute() and binary.resolve().parent == target / 'debug/deps',
                'wrong executable target/profile directory: ' + package)
        facts = file_facts(binary, elf=True)
        selected[key] = {'artifact': tests[0], 'profile_evidence': rows[key], 'binary': facts,
                         'cwd': str(args.repo / 'trillionnium/crates' / package)}
    require(selected['node']['binary']['path'] != selected['m06']['binary']['path'],
            'Node and M06 binaries must differ')
    dependencies = [row for row in rows['m06'] if row['profile']['test'] is False
                    and any(Path(name).suffix == '.rlib' for name in row['filenames'])]
    require(len(dependencies) == 1, 'one original M06 dependency rlib artifact required')
    rlibs = [Path(name) for name in dependencies[0]['filenames'] if Path(name).suffix == '.rlib']
    require(len(rlibs) == 1 and rlibs[0].is_absolute()
            and rlibs[0].resolve().parent == target / 'debug/deps', 'M06 rlib target mismatch')
    selected['m06']['dependency'] = {'artifact': dependencies[0], 'file': file_facts(rlibs[0])}
    return {'build_log': build_facts, 'source': receipt['before'], 'selected': selected}


def execute_controls(args, env):
    controls = args.out / 'semantic-controls'
    controls.mkdir(exist_ok=False)
    summary_path = controls / 'execution-summary.json'
    summary = {'schema': 'trnm-original-105-native-controls-v1', 'status': 'running',
               'expected_controls': EXPECTED_CONTROLS, 'selected_controls': None,
               'attempted_controls': 0, 'passed_controls': 0, 'tests': [],
               'complete_runtime_suite': False, 'production_qualified': False}
    write_json(summary_path, summary, exclusive=True)
    passed = False
    try:
        artifacts = selected_artifacts(args, env)
        write_json(controls / 'artifacts.json', artifacts, exclusive=True)
        selected = artifacts['selected']
        registries = {}
        for crate in ('m06', 'node'):
            binary = selected[crate]['binary']
            check_fingerprint(binary)
            registries[crate] = run_logged([binary['path'], '--list', '--format', 'terse'],
                Path(selected[crate]['cwd']), controls, crate + '-registry', env)
            check_fingerprint(binary)
        summary['registries'] = registries
        require(all(record['exit_code'] == 0 for record in registries.values()),
                'both actual libtest registry commands must succeed')

        module_path = args.repo / 'scripts/ci/test_six_workpackage_native_rosters.py'
        spec = importlib.util.spec_from_file_location('source_native_rosters', module_path)
        require(spec is not None and spec.loader is not None, 'source roster module unavailable')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        script = module.workspace_script()
        selector = controls / 'original-workspace-selector.py'
        with selector.open('x', encoding='utf-8') as stream:
            stream.write(script)
        selector_env = dict(env, TRNM_CI_RECEIPT_DIR=str(args.out))
        summary['roster_builder'] = run_logged([sys.executable, str(selector)], args.repo,
            controls, 'registry-check', selector_env)
        summary['roster_builder_source'] = file_facts(selector)
        require(summary['roster_builder']['exit_code'] == 0, 'original roster builder refused registries')
        roster_report = strict_json((controls / 'registry-check.log').read_text())
        require(roster_report['selected_count'] == EXPECTED_CONTROLS, 'original 105-control denominator changed')
        roster = []
        for line in (controls / 'selected-tests.tsv').read_text().splitlines():
            fields = line.split('\t')
            require(len(fields) == 3 and fields[0] in PACKAGES
                    and re.fullmatch(r'[A-Za-z0-9_-]+', fields[1])
                    and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*', fields[2]),
                    'invalid original native selector')
            roster.append(tuple(fields))
        require(len(roster) == EXPECTED_CONTROLS
                and len({(crate, test) for crate, _, test in roster}) == EXPECTED_CONTROLS,
                'duplicate or missing original controls')
        summary['selected_controls'] = len(roster)
        summary['tests'] = [dict(index=index, crate=crate, group=group, selector=test,
                                 status='not_started', native=None, checker=None)
                            for index, (crate, group, test) in enumerate(roster, 1)]
        write_json(summary_path, summary)
        checker = args.repo / 'scripts/ci/check_required_native_test.py'
        for row in summary['tests']:
            item = selected[row['crate']]
            label = f"test-{row['index']:03d}-{row['crate']}"
            try:
                check_fingerprint(item['binary'])
                row['native'] = run_logged([item['binary']['path'], row['selector'], '--exact',
                    '--nocapture', '--test-threads=1'], Path(item['cwd']), controls, label, env)
                # Run the original transcript checker even when native exited
                # nonzero. Neither the command exit nor a reader alone is a pass.
                row['checker'] = run_logged([sys.executable, str(checker),
                    str(controls / (label + '.log')), '--test', row['selector']],
                    args.repo, controls, label + '-check', env)
                check_fingerprint(item['binary'])
                row['status'] = ('passed' if row['native']['exit_code'] == 0
                                 and row['checker']['exit_code'] == 0 else 'failed')
            except (OSError, ValueError, KeyError, TypeError) as error:
                row.update(status='failed' if row['native'] is not None else 'not_executed',
                           error=str(error))
            summary['attempted_controls'] = sum(item['native'] is not None for item in summary['tests'])
            summary['passed_controls'] = sum(item['status'] == 'passed' for item in summary['tests'])
            write_json(summary_path, summary)
            print(json.dumps({key: row[key] for key in ('index', 'crate', 'selector', 'status')}), flush=True)

        final = {}
        for crate, item in selected.items():
            observed = file_facts(Path(item['binary']['path']), elf=True)
            require(observed == item['binary'], 'native binary changed during controls: ' + crate)
            final[crate] = observed
        observed = file_facts(Path(selected['m06']['dependency']['file']['path']))
        require(observed == selected['m06']['dependency']['file'], 'M06 dependency changed during controls')
        summary['artifacts_after'] = final
        summary['m06_dependency_after'] = observed
        passed = (summary['attempted_controls'] == EXPECTED_CONTROLS
                  and summary['passed_controls'] == EXPECTED_CONTROLS)
    except (OSError, ValueError, KeyError, TypeError, ImportError) as error:
        summary['error'] = str(error)
    summary['status'] = 'passed' if passed else 'failed'
    summary['not_executed_controls'] = EXPECTED_CONTROLS - summary['attempted_controls']
    summary['failed_or_unexecuted_controls'] = EXPECTED_CONTROLS - summary['passed_controls']
    summary['finished_utc'] = utc()
    write_json(summary_path, summary)
    print(json.dumps({key: summary[key] for key in ('status', 'expected_controls',
        'selected_controls', 'attempted_controls', 'passed_controls', 'not_executed_controls')}), flush=True)
    return 0 if passed else 1


def archive_runner(args):
    source = Path(__file__).resolve()
    facts = file_facts(source)
    archive = args.out / 'qualification-runner.py'
    if archive.exists():
        require(file_facts(archive)['sha256'] == facts['sha256'], 'mixed qualification runners in one output')
    else:
        with archive.open('xb') as stream:
            stream.write(source.read_bytes())
        require(file_facts(archive)['sha256'] == facts['sha256'], 'runner changed while archiving')
        with (args.out / 'qualification-runner.sha256').open('x') as stream:
            stream.write(facts['sha256'] + '  qualification-runner.py\n')
    identity = {'schema': 'trnm-native-qualification-input-v1', 'head': args.head,
                'repo': str(args.repo), 'runner_sha256': facts['sha256']}
    path = args.out / 'qualification-input.json'
    if path.exists():
        require(strict_json(path.read_text()) == identity, 'mixed source/runner output directory')
    else:
        write_json(path, identity, exclusive=True)
    return facts


def public_stage(args, env, runner):
    summary_path = args.out / (args.stage + '-stage.json')
    summary = {'schema': 'trnm-native-qualification-stage-v1', 'status': 'running',
               'stage': args.stage, 'head': args.head, 'repo': str(args.repo),
               'runner': runner, 'started_utc': utc(), 'commands': [],
               'production_qualified': False,
               'scope': 'only the original named command group; no whole-chain or service qualification'}
    if args.stage == 'controls':
        summary['expected_native_controls'] = EXPECTED_CONTROLS
    plans = {
        'quality': [('quality-fmt', CARGO + ['fmt', '--manifest-path', MANIFEST, '--all', '--', '--check']),
                    ('quality-clippy', CARGO + ['clippy', '--locked', '--manifest-path', MANIFEST,
                        '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings'])],
        'build': [('build', BUILD)],
        'runtime': [('runtime-tests', CARGO + ['test', '--locked', '--manifest-path', MANIFEST,
                         '--workspace', '--all-targets', '--all-features']),
                    ('runtime-docs', CARGO + ['test', '--locked', '--manifest-path', MANIFEST,
                         '--workspace', '--doc', '--all-features'])],
        'controls': [('controls', [sys.executable, str(Path(__file__).resolve()),
            '--repo', str(args.repo), '--out', str(args.out), '--head', args.head,
            '--stage', 'execute-controls', '--expected-runner-sha256', runner['sha256']])],
    }
    summary['planned_commands'] = [{'label': label, 'argv': argv} for label, argv in plans[args.stage]]
    write_json(summary_path, summary, exclusive=True)
    passed = False
    try:
        preflight = run_recorded(args, args.stage + '-preflight',
                                ['bash', 'scripts/project-preflight.sh', '--audit'], env)
        summary['preflight'] = preflight
        require(preflight['passed'], 'source-bound project preflight failed')
        env = environment(args.repo)
        summary['environment'] = {key: env.get(key) for key in ENVIRONMENT}
        for label, command in plans[args.stage]:
            result = run_recorded(args, label, command, env)
            summary['commands'].append(result)
            write_json(summary_path, summary)
            # Formatting/Clippy/build failures stop that stage. Runtime retains
            # a separate original docs attempt even if the workspace tests fail.
            if not result['passed'] and args.stage != 'runtime':
                break
        require(file_facts(Path(__file__).resolve()) == runner, 'qualification runner changed during stage')
        passed = (len(summary['commands']) == len(plans[args.stage])
                  and all(row['passed'] for row in summary['commands']))
    except (OSError, ValueError, KeyError, TypeError) as error:
        summary['error'] = str(error)
    summary['status'] = 'passed' if passed else 'failed'
    summary['attempted_commands'] = len(summary['commands'])
    summary['unattempted_commands'] = len(plans[args.stage]) - len(summary['commands'])
    summary['finished_utc'] = utc()
    write_json(summary_path, summary)
    print(json.dumps({'stage': args.stage, 'status': summary['status'],
                      'summary': str(summary_path)}), flush=True)
    return 0 if passed else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--head', required=True)
    parser.add_argument('--stage', choices=('quality', 'build', 'controls', 'runtime', 'execute-controls'),
                        required=True)
    parser.add_argument('--expected-runner-sha256', help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    try:
        require(re.fullmatch('[0-9a-f]{40}', args.head) is not None, 'canonical exact head required')
        require(args.repo.is_absolute() and args.out.is_absolute(), 'absolute repo/out paths required')
        args.repo = args.repo.resolve(strict=True)
        args.out = args.out.resolve()
        require(not args.out.is_relative_to(args.repo), 'output must be outside source')
        require((args.repo / MANIFEST).is_file(), 'original workspace manifest required')
        args.out.mkdir(parents=True, exist_ok=True)
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
        if args.stage == 'execute-controls':
            require(args.expected_runner_sha256 == file_facts(Path(__file__).resolve())['sha256'],
                    'controls child requires the outer recorder runner pin')
            return execute_controls(args, environment(args.repo))
        require(args.expected_runner_sha256 is None, 'internal runner pin on a public stage')
        runner = archive_runner(args)
        return public_stage(args, env, runner)
    except (OSError, ValueError, KeyError, TypeError) as error:
        print('qualification refused: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
