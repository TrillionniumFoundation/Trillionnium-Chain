"""Independent small-state competition review, not native or QPU execution.

The reduced fixture constructor supplies immutable inputs and a literal winner
inventory.  Expected action lists, clocks, receiver event ordering, and values
below do not use the production transition evaluator, optimizer, or checker.
"""
from collections import deque
from copy import deepcopy
from dataclasses import replace
from decimal import Decimal
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path('/workspace/scratch/c9b48df754d6/chain-quantum-next')
sys.path.insert(0, str(ROOT / 'formal/pon-nakamoto-v1'))
import contract_wire as wire
from quantum_oracle_resources import ClassicalCosts, example
from test_w1_finite_consensus import reduced_native_shaped_dag, finite_lifecycle
from test_w1_competing_consensus import reduced_competition
import w1_competing_consensus as sut
import w1_finite_consensus as finite


def rat(x):
    x = F(x)
    return {'numerator': x.numerator, 'denominator': x.denominator}


def frac(x):
    return F(x['numerator'], x['denominator'])


def freeze(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'))


def metadata(row):
    return {k: row[k] for k in ('block_id', 'parent_id', 'height', 'timestamp')} | {
        'chainwork': int(row['chainwork_hex'], 16)}


class Independent:
    def __init__(self, fixture, competition, params):
        self.f = fixture
        self.limit = F(params['horizon_seconds'])
        self.max_attempts = params['max_attempts']
        self.metric = params['risk_event']
        self.contexts = {c['context_id']: c for c in fixture['contexts']}
        self.costs = dict(zip(self.contexts, params['classical_costs']))
        self.blocks = {r['block_id']: metadata(r) for r in fixture['prefix']['parent_first_headers']}
        self.public = metadata(fixture['public_tip'])
        self.blocks[self.public['block_id']] = self.public
        self.children, self.owner, self.successor = {}, {}, {}
        for c in fixture['contexts']:
            self.children[c['context_id']] = {r['nonce']: r for r in c['winner_children']}
            for row in c['winner_children']:
                h = wire.header_decode(bytes.fromhex(row['header_hex']))
                parent = self.blocks[h['parent'].hex()]
                target = int.from_bytes(h['target'], 'big')
                self.blocks[row['block_id']] = {
                    'block_id': row['block_id'], 'parent_id': h['parent'].hex(),
                    'height': h['height'], 'timestamp': h['timestamp'],
                    'chainwork': parent['chainwork'] + (1 << 256) // (target + 1)}
                self.owner[row['block_id']] = c['context_id']
                self.successor[row['block_id']] = row['child_context_id']
        for b in competition['honest_blocks']:
            self.blocks[b['block_id']] = metadata(b)
        scenario = next(s for s in competition['scenarios'] if s['scenario_id'] == params['scenario_id'])
        self.arrivals = [(frac(row['at_seconds']), row['block_id']) for row in scenario['arrivals']]

    def initial(self):
        return {'time': rat(0), 'attempts': 0, 'private_chain': [], 'resident_context': None}

    def ctx(self, state):
        return self.successor[state['private_chain'][-1]] if state['private_chain'] else self.f['root_context_id']

    def public_at(self, time):
        arrived = [bid for at, bid in self.arrivals if at <= time]
        return arrived[-1] if arrived else self.public['block_id']

    def actions(self, state):
        result = [{'kind': 'stop'}]
        if state['private_chain']:
            result.append({'kind': 'publish'})
        if frac(state['time']) < self.limit and state['attempts'] < self.max_attempts and self.ctx(state) is not None:
            result.append({'kind': 'search', 'iterations': 0})
        if [at for at, bid in self.arrivals if at > frac(state['time'])]:
            result.append({'kind': 'wait-next-honest'})
        return result

    def receiver(self, chain, publication=None):
        # Independent chronological buckets, not the production event tuple sort.
        times = {at for at, _ in self.arrivals}
        if publication is not None:
            times.add(publication)
        tip, events, ever = self.public['block_id'], [], False
        private = set(chain) if publication is not None else set()
        for at in sorted(times):
            bucket = [('honest', bid) for when, bid in self.arrivals if when == at]
            if publication == at:
                bucket.extend(('private', bid) for bid in chain)
            for owner, bid in bucket:
                block, before = self.blocks[bid], tip
                if block['chainwork'] > self.blocks[tip]['chainwork']:
                    tip = bid
                replacement = owner == 'private' and tip == bid and before not in private
                ever |= replacement
                events.append({'owner': owner, 'at_seconds': rat(at), 'block_id': bid,
                    'parent_id': block['parent_id'], 'height': block['height'],
                    'block_chainwork_hex': f"{block['chainwork']:0128x}",
                    'selected_tip_before': before, 'selected_tip': tip,
                    'selected_chainwork_hex': f"{self.blocks[tip]['chainwork']:0128x}",
                    'selection_changed': tip != before, 'private_replacement': replacement})
        return {'receiver_events': events, 'receiver_observed_until_seconds': rat(self.limit),
                'ever_private_replacement': ever, 'private_active_at_horizon': tip in private,
                'selected_tip_at_horizon': tip,
                'selected_chainwork_at_horizon_hex': f"{self.blocks[tip]['chainwork']:0128x}"}

    def edge(self, probability, state, observation, start):
        if state is None:
            trace = self.receiver(observation['private_chain'], frac(observation['time'])
                                  if observation.get('publication_complete') else None)
            observation.update(trace)
            observation['strict_work_replacement'] = trace['ever_private_replacement']
            risk = int(trace['ever_private_replacement' if self.metric == sut.RISK_EVENTS[0]
                             else 'private_active_at_horizon'])
        else:
            risk = None
        end = frac(observation['time'])
        observation['honest_arrivals_during_action'] = [
            {'at_seconds': rat(at), 'block_id': bid} for at, bid in self.arrivals if start < at <= end]
        observation['public_tip_at_action_end'] = self.public_at(end)
        return {'probability': rat(probability), 'next_state': state, 'terminal_risk': risk,
                'observation': observation}

    def transition(self, state, action):
        start, chain = frac(state['time']), list(state['private_chain'])
        kind = action['kind']
        if kind == 'wait-next-honest':
            at, bid = next((at, bid) for at, bid in self.arrivals if at > start)
            return [{'probability': rat(1), 'next_state': dict(state, time=rat(at)), 'terminal_risk': None,
                'observation': {'result': 'honest-arrival-observed', 'time': rat(at),
                                'public_tip': self.public_at(at), 'first_arrival_at_this_time': bid}}]
        if kind == 'stop':
            return [self.edge(1, None, {'result': 'stopped', 'time': rat(start), 'private_chain': chain}, start)]
        phases, end = [], start

        def charge(name, duration):
            nonlocal end
            finish = end + duration
            paid = min(finish, self.limit) - end
            end += paid
            complete = finish <= self.limit
            phases.append({'phase': name, 'planned': rat(duration), 'paid': rat(paid), 'complete': complete})
            return complete

        if kind == 'publish':
            duration = sum((F(self.costs[self.owner[bid]]['per_winner_propagation_ns'], 10**9)
                            for bid in chain), F(0))
            done = charge('serial_bundle_propagation', duration)
            if done:
                earliest = max(F(max(0, self.blocks[bid]['timestamp'] - self.f['clock_origin_timestamp'] - 120))
                               for bid in chain)
                done = charge('future_admission_wait', max(F(0), earliest - end))
            return [self.edge(1, None, {'result': 'published' if done else 'horizon', 'time': rat(end),
                'private_chain': chain, 'phases': phases, 'publication_complete': done}, start)]
        key = self.ctx(state)
        costs = self.costs[key]
        setup = (costs['task_preprocessing_ns'] + costs['per_search_setup_ns']) if state['resident_context'] != key else 0
        measured = checked = False
        for name, ns in (('classical_task_and_template_setup', setup),
                         ('classical_nonce_generation', costs['per_trial_reset_readout_ns']),
                         ('candidate_check', costs['per_completed_trial_candidate_check_ns'])):
            done = charge(name, F(ns, 10**9))
            measured |= name == 'classical_nonce_generation' and done
            checked |= name == 'candidate_check' and done
            if not done:
                break
        base = {'context_id': key, 'parent_id': self.contexts[key]['parent_id'], 'iterations': 0,
                'phases': phases, 'nonce_available': measured, 'measurement_complete': False,
                'candidate_check_complete': checked, 'proof_complete': False}
        if not measured:
            return [self.edge(1, None, base | {'nonce': None, 'winner': None, 'result': 'horizon',
                               'time': rat(end), 'private_chain': chain}, start)]
        result, search_end, search_phases = [], end, list(phases)
        for nonce in range(16):
            end, phases = search_end, list(search_phases)
            won = nonce in self.children[key] if checked else None
            obs = base | {'phases': phases, 'nonce': nonce, 'winner': won, 'block_id': None,
                          'private_chain': chain, 'time': rat(end)}
            following = None
            if checked:
                done = charge('proof', F(costs['per_winner_proof_ns'], 10**9)) if won else True
                newchain = chain
                if won and done:
                    bid = self.children[key][nonce]['block_id']
                    newchain = chain + [bid]
                    obs.update(block_id=bid, private_chain=newchain, proof_complete=True)
                obs['result'] = 'proved-private-block' if won and done else 'checked-miss' if done else 'horizon'
                obs['time'] = rat(end)
                if done:
                    following = {'time': rat(end), 'attempts': state['attempts'] + 1,
                                 'private_chain': newchain, 'resident_context': key}
            else:
                obs['result'] = 'horizon'
            result.append(self.edge(F(1, 16), following, obs, start))
        return result


def assert_edge(expected, actual):
    for key in ('probability', 'next_state', 'terminal_risk'):
        assert expected[key] == actual[key], (key, expected[key], actual[key])
    for key, value in expected['observation'].items():
        assert value == actual['observation'].get(key), (key, value, actual['observation'].get(key))


def compare_graph(fixture, competition, params):
    ind, model = Independent(fixture, competition, params), sut.CompetingModel(fixture, competition, params)
    queue, seen, graph, actions, edges = deque([ind.initial()]), set(), {}, 0, 0
    while queue:
        state = queue.popleft()
        key = freeze(state)
        if key in seen:
            continue
        seen.add(key)
        expected_actions = ind.actions(state)
        assert expected_actions == model.actions(state)
        graph[key] = []
        for action in expected_actions:
            expected = ind.transition(state, action)
            actual = model.transition(state, action)
            assert len(expected) == len(actual)
            for a, b in zip(expected, actual):
                assert_edge(a, b)
                if a['next_state'] is not None:
                    queue.append(a['next_state'])
            graph[key].append((action, expected))
            actions += 1
            edges += len(expected)
    memo = {}
    def value(state):
        key = freeze(state)
        if key not in memo:
            memo[key] = max(sum((frac(e['probability']) * (e['terminal_risk'] if e['next_state'] is None
                     else value(e['next_state'])) for e in es), F(0)) for a, es in graph[key])
        return memo[key]
    maximum = value(ind.initial())
    return {'states': len(seen), 'actions': actions, 'edges': edges, 'independent_risk_upper': rat(maximum)}, ind, model, graph


def main():
    paths = ['formal/pon-nakamoto-v1/w1_competing_consensus.py', 'formal/pon-nakamoto-v1/w1_finite_consensus.py']
    source_before = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths}
    fixture = reduced_native_shaped_dag()
    competition = reduced_competition(fixture)
    costs = tuple(ClassicalCosts(1000, 1000, 1000, 1000, 10**9, 10**8) for _ in fixture['contexts'])
    physical = replace(example(True).physical_models[0], magic_state_error='0')
    parameters = finite._parameters(costs, physical, 1 << 100, '4', (0,), 2, 'full', 10000,
                                    None, 'classical-uniform-q0')
    parameters.update(scenario_id='late', risk_event=sut.RISK_EVENTS[0])
    cases, saved = [], {}
    for scenario in ('early', 'late'):
        for event in sut.RISK_EVENTS:
            p = parameters | {'scenario_id': scenario, 'risk_event': event}
            summary, ind, model, graph = compare_graph(fixture, competition, p)
            # Optimizer is a system under test: expected value was computed above.
            certificate = sut.analyze_competing_consensus(fixture, competition, p)
            assert certificate['risk_upper'] == summary['independent_risk_upper']
            cases.append({'scenario': scenario, 'risk_event': event, 'horizon': '4', **summary})
            if event == sut.RISK_EVENTS[0]:
                saved[scenario] = (ind, model, graph)
    # A positive survival control is necessary: two public continuations always
    # outweigh this fixture's two private blocks at the deadline. With only one
    # public continuation, an earlier private tip survives an equal-work tie.
    c = deepcopy(competition)
    c['honest_blocks'] = c['honest_blocks'][:1]
    c['scenarios'] = [{'scenario_id': 'one-honest', 'arrivals': [
        {'block_id': c['honest_blocks'][0]['block_id'], 'at_seconds': rat(4)}]}]
    positive_survival_checks = 0
    for event in sut.RISK_EVENTS:
        p = parameters | {'scenario_id': 'one-honest', 'risk_event': event}
        summary, ind, model, graph = compare_graph(fixture, c, p)
        assert frac(summary['independent_risk_upper']) == F(1, 128)
        certificate = sut.analyze_competing_consensus(fixture, c, p)
        assert certificate['risk_upper'] == summary['independent_risk_upper']
        cases.append({'scenario': 'one-honest', 'risk_event': event, 'horizon': '4', **summary})
        for key in graph:
            chain = json.loads(key)['private_chain']
            if len(chain) == 2:
                before = ind.receiver(chain, F(4) - F(1, 10**40))
                tied = ind.receiver(chain, F(4))
                assert before['private_active_at_horizon'] is True
                assert tied['private_active_at_horizon'] is False
                assert before == model.receiver_trace(chain, F(4) - F(1, 10**40))
                assert tied == model.receiver_trace(chain, F(4))
                positive_survival_checks += 2
    # Deadlines straddle setup/RNG/check/proof and full two-block publication.
    boundaries = [F(1, 10**6), F(2, 10**6), F(3, 10**6), F(4, 10**6),
                  F(1000004, 10**6), F(2000008, 10**6), F(2200008, 10**6)]
    for horizon in boundaries:
        for delta in (F(-1, 10**12), F(0), F(1, 10**12)):
            limit = horizon + delta
            c = deepcopy(competition)
            c['scenarios'] = [{'scenario_id': 'boundary', 'arrivals': [
                {'block_id': row['block_id'], 'at_seconds': rat(at)}
                for row, at in zip(c['honest_blocks'], (limit / 2, limit))]}]
            p = parameters | {'scenario_id': 'boundary',
                              'horizon_seconds': str(Decimal(limit.numerator) / Decimal(limit.denominator))}
            summary, _, _, _ = compare_graph(fixture, c, p)
            cases.append({'scenario': 'boundary', 'risk_event': p['risk_event'], 'horizon': str(limit), **summary})
    # Exact same-time honest arrivals, exact horizon, and sub-float tie offsets.
    c = deepcopy(competition)
    c['scenarios'] = [{'scenario_id': 'same-time', 'arrivals': [
        {'block_id': row['block_id'], 'at_seconds': rat(4)} for row in c['honest_blocks']]}]
    p = parameters | {'scenario_id': 'same-time'}
    summary, ind, model, graph = compare_graph(fixture, c, p)
    cases.append({'scenario': 'same-time', 'risk_event': p['risk_event'], 'horizon': '4', **summary})
    chains = {tuple(json.loads(key)['private_chain']) for key in graph}
    receiver_checks = 0
    for chain in chains:
        for publication in (None, F(0), F(4) - F(1, 10**40), F(4)):
            assert ind.receiver(chain, publication) == model.receiver_trace(chain, publication)
            receiver_checks += 1
    # Fixed policy invariance for states with the same observations but different
    # complete future schedules. State inventory is independently reachable.
    c = deepcopy(competition)
    c['scenarios'] = [{'scenario_id': 'later', 'arrivals': [
        {'block_id': row['block_id'], 'at_seconds': rat(at)}
        for row, at in zip(c['honest_blocks'], (F(3), F(4)))]}]
    summary, ind, model, graph = compare_graph(fixture, c, parameters | {'scenario_id': 'later'})
    cases.append({'scenario': 'later', 'risk_event': parameters['risk_event'], 'horizon': '4', **summary})
    first, second = saved['late'], (ind, model, graph)
    nonanticipation = 0
    for key in set(first[2]) | set(second[2]):
        state = json.loads(key)
        now = frac(state['time'])
        prefix1 = [(at, bid) for at, bid in first[0].arrivals if at <= now]
        prefix2 = [(at, bid) for at, bid in second[0].arrivals if at <= now]
        if prefix1 == prefix2:
            assert sut.fixed_action(first[1], state, 0) == sut.fixed_action(second[1], state, 0)
            nonanticipation += 1
    # Dense amplitudes use every literal item, distinct from the production
    # two-dimensional marked/unmarked recurrence.
    amplitude_checks = 0
    for context in fixture['contexts']:
        marked = tuple(row['nonce'] for row in context['winner_children'])
        amplitudes = [F(1)] * 16
        for count in range(7):
            expected = tuple(a*a/16 for a in amplitudes)
            assert finite.exact_nonce_probabilities(16, marked, count) == expected
            phased = [-a if i in marked else a for i, a in enumerate(amplitudes)]
            mean = sum(phased, F(0)) / 16
            amplitudes = [2 * mean - a for a in phased]
            amplitude_checks += 1
    life = finite_lifecycle()
    p = parameters | {'lifecycle_model': finite.asdict(life)}
    model = sut.CompetingModel(fixture, competition, p)
    bound = sut.private_machine_risk(model, F(1, 8), {'0': rat(F(1, 16))})
    count = len(fixture['contexts'])
    expected_epsilon = (2*count + 2*count*2 + 2) * F(life.host_call_failure_bound) + 2*F(life.propagation_failure_bound)
    assert frac(bound['failure_union_upper']) == expected_epsilon
    assert bound['external_honest_and_receiver_trajectory_is_exact_condition'] is True
    assert bound['honest_production_receiver_or_network_failures_bounded'] is False
    assert 'conditional on exact external' in bound['coupling_premise']
    header = sut.header(model, fixture)
    assert 'complete-future-public-schedule-aware' in header['scope']['maximum_value_policy']
    assert header['scope']['mid_action_abort_restart_or_public_branch_switch_covered'] is False
    source_after = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in paths}
    assert source_before == source_after, 'reviewed sources changed during independent checks'
    print(json.dumps({'status': 'PASS', 'reviewed_source_sha256': source_before,
        'method': 'independent classical finite-state clocks/actions/event buckets; production transitions and optimizer only systems under test',
        'input_scope': 'reduced 16-nonce fixture and supplied winner inventory; no native predicate admission claim',
        'case_count': len(cases), 'cases': cases,
        'total_case_states': sum(row['states'] for row in cases),
        'total_case_actions': sum(row['actions'] for row in cases),
        'total_case_edges': sum(row['edges'] for row in cases),
        'receiver_boundary_comparisons': receiver_checks,
        'positive_survival_boundary_comparisons': positive_survival_checks,
        'same_observed_prefix_policy_comparisons': nonanticipation, 'dense_amplitude_comparisons': amplitude_checks,
        'conditional_host_failure_union_upper': rat(expected_epsilon),
        'native_node_executed': False, 'quantum_hardware_executed': False}, indent=2))


if __name__ == '__main__':
    main()
