#!/usr/bin/env python3
"""Read a completed V4 artifact only; never execute the contained native driver."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import sys
import urllib.request
import zipfile


def main():
    arch, url, expected_size, expected_sha = sys.argv[1:]
    expected_size = int(expected_size)
    root = Path(__file__).resolve().parent / arch
    root.mkdir(exist_ok=True)
    with urllib.request.urlopen(url, timeout=60) as response:
        raw = response.read(expected_size + 1)
    assert len(raw) == expected_size
    assert hashlib.sha256(raw).hexdigest() == expected_sha
    z = zipfile.ZipFile(io.BytesIO(raw))
    entries = z.infolist()
    assert len(entries) < 5000 and len({x.filename for x in entries}) == len(entries)
    assert sum(x.file_size for x in entries) < 256 * 1024 * 1024
    records = []
    selected = []
    binary = []
    for item in entries:
        name = PurePosixPath(item.filename)
        assert not name.is_absolute() and '..' not in name.parts
        assert item.file_size < 64 * 1024 * 1024
        h = hashlib.sha256()
        count = 0
        with z.open(item) as f:
            while chunk := f.read(65536):
                h.update(chunk)
                count += len(chunk)
        assert count == item.file_size
        rec = dict(name=item.filename, bytes=count, sha256=h.hexdigest(), crc32=item.CRC)
        records.append(rec)
        if item.is_dir():
            continue
        if item.filename.startswith('pon_legal_ticket_batch_v4.'):
            with z.open(item) as f:
                header = f.read(64)
            assert header[:4] == b'\x7fELF'
            binary.append(dict(**rec, elf_class=header[4], elf_data=header[5], elf_machine=int.from_bytes(header[18:20], 'little')))
        elif not item.filename.startswith('packets/'):
            assert item.file_size < 8 * 1024 * 1024
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(z.read(item))
            selected.append(rec)
    value = dict(schema='legal-ticket-v4-independent-artifact-readback-v1', architecture=arch,
                 compressed_bytes=len(raw), compressed_sha256=expected_sha,
                 members=len(entries), uncompressed_bytes=sum(x.file_size for x in entries),
                 all_members_read_and_crc_and_sha256_checked=True,
                 archive_saved_locally=False, native_driver_executed=False,
                 member_records=records, selected_records=selected, native_binary=binary)
    (root / 'archive-member-readback.json').write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps({k:value[k] for k in ['architecture','compressed_bytes','compressed_sha256','members','uncompressed_bytes','native_binary']}))
    print(json.dumps({'selected':[x['name'] for x in selected]}))


if __name__ == '__main__':
    main()
