# One-blob documentation repair increment

Base 318527b4b2a07b5037d755547acd92e46ae3aded; head dc42ce4df5cff79cc61c5addbaf01074b56b06ca; tree 9fda17fed2542b2baccaa34585bb00afd699e12b.

The complete raw Git diff contains only the index modification and a zero-byte evidence filename change from page-4.json to page-4.json.raw. The source name remains unchanged in provenance. The original checker requires every .json file to parse, and strict diagnosis of all 164 changed JSON files isolated this one empty raw network output.

The index's entire byte difference is the single .raw suffix on /entries/145/path. All other index fields and all 527 artifact payloads (49,605,430 bytes) are unchanged. The renamed file retains Git blob e69de29bb2d1d6434b8b29ae775ad8c2e48c5391. All other blob identities are unchanged.

Only the new index blob b5083bc717e05c0368f94173f9281775a5ffced2 was rescanned: 246,290 bytes, correct Git content address, all five disclosed regex categories zero. The previous 335-blob/51,101,476-byte scan is reused by exact OID; no old payload was rescanned. No fsck, Git write or recursive archive decoding occurred. No result excludes every possible secret type. These receipts are external to the audited head.

The external delivery.json binds the ZIP and receipt index. The index does not include its own hash. All packaged original files retain their raw bytes.
