/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/examples/pon_commitment_resource_bounds-434c838371dcabdd.d: crates/trnm-mvcc-fee/examples/pon_commitment_resource_bounds.rs

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/examples/pon_commitment_resource_bounds-434c838371dcabdd: crates/trnm-mvcc-fee/examples/pon_commitment_resource_bounds.rs

crates/trnm-mvcc-fee/examples/pon_commitment_resource_bounds.rs:
