#!/usr/bin/env python3
"""Package actual four-gate observations while retaining all qualification limits."""
from pathlib import Path
from fractions import Fraction
import json
import re
import shutil
import subprocess
import package_four_gates_helpers as u

ROOT = Path('/workspace/scratch/c9b48df754d6')
REPO = ROOT / 'chain-quantum-next'
V = ROOT / 'validation-four-gates'
CORE = V / 'rog-native-ec3a939'
REMOTE = V / 'rog-remote-receipts-ec3a939'
DEST = REPO / 'evidence/pon-quantum-four-gates-20261107'
BASE = '5d7ca0f5e260b65f5a2b8ab09dfd038718129346'


def load(path):
    return json.loads(path.read_text())


def command(directory, label, expected_code):
    record = load(directory / (label + '.json'))
    assert record['exit_code'] == expected_code
    assert record['status'] == ('command_succeeded' if expected_code == 0 else 'command_failed')
    assert record['before'] == record['after']
    assert record['before']['tested_commit'] == u.HEAD and record['before']['tested_tree'] == u.TREE
    raw = (directory / record['log_file']).read_bytes()
    assert u.sha(raw) == record['log_sha256'] and len(raw) == record['log_bytes']
    return record, raw


def put(name, value):
    with (DEST / name).open('xb') as output:
        output.write(u.json_bytes(value))


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == u.HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True).strip() == u.TREE
    assert subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=REPO, text=True).strip() == ''
    subprocess.run(['bash', 'scripts/project-preflight.sh'], cwd=REPO, check=True)
    local = u.check_frozen_groups(V / 'frozen')
    native = load(V / 'native-bridge-final-observation.json')
    assert native['source_head'] == u.HEAD
    assert native['native_dag']['contexts'] == 2 and native['native_dag']['native_full_checks'] == 16
    assert native['native_dag']['native_winners'] == 2
    assert sum(r['completed_candidate_checks'] for r in native['runs']) == 4
    assert sum(r['receiver_admissions'] for r in native['runs']) == 2
    assert sum(r['reorganized'] for r in native['runs']) == 1
    assert all(r['authenticated_reopen_equal'] for r in native['runs'])
    assert native['runs'][2]['nonces'] == [7, 5] and not native['runs'][2]['reorganized']
    assert native['runs'][3]['nonces'] == [6, 1] and native['runs'][3]['reorganized']
    assert all(value is False for value in native['claims'].values())
    full, full_log = command(REMOTE / 'commands', 'node-lib-all-features-normal-loader-fresh', 101)
    result = re.search(rb'test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored;', full_log)
    assert result and tuple(map(int, result.groups())) == (1243, 2, 35)
    diagnostics = {}
    for label in ('diagnostic-expired-root-replay', 'diagnostic-sealed-copy'):
        record, log = command(REMOTE / 'commands', label, 101)
        diagnostics[label] = {'exit_code': 101, 'log_sha256': u.sha(log), 'source_unchanged': True}
    portable, _ = command(V / 'local-native-verification', 'local-native-bridge-verification', 0)
    finite_review = load(V / 'finite-native-review/review.json')
    receipt_review = load(V / 'finite-native-review/source-receipts-review.json')
    machine_review = load(V / 'machine-observation-review.json')
    assert finite_review['result'] == receipt_review['result'] == machine_review['status'] == 'PASS'
    assert machine_review['assertions_passed'] == 3813
    core_manifest = load(CORE / 'native-core-manifest.json')
    assert core_manifest['source_head'] == u.HEAD and core_manifest['pipeline_complete'] is True
    for relative, identity in core_manifest['files'].items():
        raw = (CORE / relative).read_bytes()
        assert len(raw) == identity['bytes'] and u.sha(raw) == identity['sha256']
    assert len(core_manifest['files']) == 60
    native_archive = V / 'rog-native-core-ec3a939.tar.gz'
    assert u.sha(native_archive.read_bytes()) == '1bf5f798819449369b1cd517b4635ba4853333edd749ccfd9e13f3998b58aa25'
    frontier = load(CORE / 'machine-frontier.json')
    assert frontier['planned_cells'] == frontier['observed_model_cells'] == 18
    assert all(row['status'] == 'CONSTRUCTED' for row in frontier['cells'])
    assert len(frontier['undominated_with_certified_interval_order']) == 18
    quantum = load(CORE / 'native-evidence-ec3a939/finite-certificate.json')
    classical = load(CORE / 'native-evidence-ec3a939/classical-certificate.json')
    assert quantum['risk_upper'] == {'numerator': 0, 'denominator': 1}
    assert classical['risk_upper'] == {'numerator': 1, 'denominator': 64}

    DEST.mkdir(parents=True, exist_ok=False)
    for name in ('local-validation.tar.xz', 'local-validation-index.json', 'local-validation-summary.json'):
        shutil.copyfile(ROOT / 'prepared-four-gates-evidence' / name, DEST / name)
    shutil.copyfile(native_archive, DEST / 'native-evidence.tar.gz')
    shutil.copyfile(CORE / 'native-core-manifest.json', DEST / 'native-core-manifest.json')
    for source, name in (
        (V / 'native-bridge-final-observation.json', 'native-observation.json'),
        (V / 'finite-native-review/review.json', 'finite-independent-review.json'),
        (V / 'finite-native-review/source-receipts-review.json', 'source-receipts-review.json'),
        (V / 'machine-observation-review.json', 'machine-independent-review.json'),
        (V / 'frozen/economics/summary.json', 'observed-economics-summary.json'),
    ):
        shutil.copyfile(source, DEST / name)

    # Execution records and independent reviews are separate from the core
    # manifest, which retains exactly its original sixty payload identities.
    rows = u.collect(REMOTE, 'remote-execution')
    rows.update(u.collect(V / 'finite-native-review', 'finite-native-review'))
    rows.update(u.collect(V / 'local-native-verification', 'local-native-verification'))
    for name in ('machine_observation_review.py', 'machine-observation-review.json',
                 'rog-native-final-job.json', 'rog-bridge-pipeline-job.json',
                 'rog-retained-failure-diagnostic-job.json', 'rog-native-core-download.json'):
        rows['records/' + name] = (V / name).read_bytes()
    for name in ('finish_four_gates_evidence.py', 'package_four_gates_helpers.py', 'four_gates_README.template.md'):
        rows['drivers/' + name] = (ROOT / name).read_bytes()
    execution_index = u.archive(DEST / 'execution-and-review.tar.xz', rows,
        'Exact ec3 native build/full regression including two real failures; independent failed-test diagnostics; source and runtime records; local cross-host reader replay and independent mathematical/machine reviews. No new native executions are attributed to independent reviewers.')
    put('execution-and-review-index.json', {'schema': 'trnm-w1-four-gates-archive-index-v1',
        'source_commit': u.HEAD, 'archive': execution_index})

    historical = {}
    for path in sorted(V.iterdir()):
        if not path.is_file():
            continue
        if (path.name.startswith(('native-bridge-', 'ci-registration-', 'economics-development-', 'oracle-independent-', 'rog-incomplete-', 'rog-cached-', 'rog-cargo-fetch-'))
                or path.name in ('oracle_independent_review.py', 'implementation-freeze.json',
                                 'publication-blocked-github-403.json', 'local-build-cache-reclamation.json',
                                 'rog-native-incomplete-loader-cancelled.json',
                                 'rog-native-cached-incomplete-loader-cancelled.json',
                                 'rog-source-import-01.json')):
            if path.name == 'native-bridge-final-observation.json':
                continue
            historical['development/' + path.name] = path.read_bytes()
    for name in ('finite-independent', 'fuzz-vendor-restore'):
        historical.update(u.collect(V / name, name))
    history_index = u.archive(DEST / 'development-observations.tar.xz', historical,
        'Original development-source observations and real unsuccessful attempts, including incomplete CI registration, local SIGKILL, ENOSPC recovery, cancelled unqualified-loader builds and independent mathematical controls. These are not relabelled as final-source executions. Unrelated read-only host discovery is not part of this archive.')
    put('development-observations-index.json', {'schema': 'trnm-w1-four-gates-archive-index-v1', 'archive': history_index})

    cells = [{key: row[key] for key in ('name', 'predicate', 'processors', 'iterations', 'status',
             'resources', 'code_distance', 'ideal_delivery_probability', 'conditional_delivery_probability',
             'whole_plan_failure_union_upper')} for row in frontier['cells']]
    put('machine-frontier-summary.json', {'schema': 'trnm-w1-four-gates-frontier-summary-v1',
        'source_commit': u.HEAD, 'input_sha256': u.sha((CORE / 'machine-frontier.json').read_bytes()),
        'declared_grid': frontier['declared_grid'], 'cells': cells,
        'undominated_with_certified_interval_order': frontier['undominated_with_certified_interval_order'],
        'interpretation': 'All ideal deliveries are zero under the fixed serial lifecycle, while all conditional upper bounds remain positive; no interval-certified dominance is established. These are constructions, not cheapest-cost lower bounds.',
        'claims': frontier['claims']})
    publication = {'schema': 'trnm-w1-four-gates-publication-v1', 'implementation_commit': u.HEAD,
        'implementation_tree': u.TREE, 'parent_commit': BASE, 'remote_publication_completed': False,
        'github_connector_response': {'status': 403, 'message': 'Sorry. Your account was suspended'},
        'publication_channel_available': False, 'alternate_account_or_credential_attempted': False,
        'delivery': 'An incremental Git bundle preserving the exact local implementation and later evidence commits; requires the published parent.',
        'remote_ci_result_for_this_new_source': None, 'production_activation': False}
    put('publication.json', publication)
    qualification = {'schema': 'trnm-w1-four-gates-qualification-v1', 'status': 'RESEARCH_HOLD',
        'implementation': {'commit': u.HEAD, 'tree': u.TREE, 'parent': BASE},
        'local_validation': local,
        'native_execution': {'binary_sha256': native['native_binary_sha256'], 'source_unchanged': True,
            'explicit_bridge_tests': {'executed': 2, 'passed': 2, 'failed': 0, 'ignored': 0},
            'full_node_regression': native['retained_full_regression'], 'diagnostics': diagnostics,
            'cross_host_python_replay': {'status': portable['status'], 'log_sha256': portable['log_sha256'], 'native_node_executed': False},
            'candidate_checks_replayed': 4, 'candidate_misses': 2, 'candidate_winners': 2,
            'receiver_admissions': 2, 'reorganizations': 1, 'authenticated_reopens_equal': 4,
            'reorganization_path_kind': 'observer-advice-classical-existential-witness',
            'fixed_seed_reorganization_successes': 0, 'quantum_measurements_completed': 0,
            'real_time_search_budget_verified': False, 'exclusive_host_cpu_calibration': False},
        'conditional_finite_models': {'quantum': {'states': quantum['state_count'], 'ideal_risk': quantum['risk_upper'],
            'conditional_bounds': quantum['conditional_machine_risk_bounds']},
            'classical': {'states': classical['state_count'], 'ideal_risk': classical['risk_upper'],
            'conditional_bounds': classical['conditional_machine_risk_bounds']}},
        'independent_reviews': {'finite': finite_review['result'], 'source_receipts': receipt_review['result'],
            'machine': machine_review['status'], 'machine_assertions': machine_review['assertions_passed']},
        'remaining_gates': {'calibrated_complete_machine_cost_closed': False,
            'minimum_legal_attacker_cost_proved': False, 'equal_real_total_resource_advantage_proved': False,
            'native_quantum_mining_execution_qualified': False, 'general_mixed_network_consensus_security_proved': False,
            'all_native_regression_tests_passed': False},
        'quantum_hardware_executed': False, 'quantum_mining_qualified': False,
        'production_activation': False}
    put('qualification.json', qualification)

    native_text = '''The actual all-feature test ELF has SHA256
`bfb1087323f1760046ddd7303d8fcdaa13cfa95cda7b7324c6636e8d9f817c2b`.
Two contexts contain eight nonces each; all **16 complete PNW1 candidates** were
checked. The root's only legal nonce is **6**, and its height-17 child's only
legal nonce is **1**. There are **35 unique complete packet files**, including
prefix, public tip and the three native rejection controls.

| Actual run | Completed candidate checks | Result | Receiver admissions | Reorganization |
| --- | ---: | --- | ---: | --- |
| Constructed quantum q0, seed9 | 0 | Initialization censored at the modeled deadline | 0 | No |
| Constructed quantum q1, seed9 | 0 | Initialization censored at the modeled deadline | 0 | No |
| Classical uniform q0, seed9 | 2 | Nonces 7 and 5 both miss | 0 | No |
| Observer-advice classical witness | 2 | Nonces 6 then 1 are legal | 2 | Yes |

Every completed candidate check was freshly prepared, proved and verified by the
native implementation, including both misses. Only proof-complete winners
entered the private producer, and only the completed publication entered the
separate receiver. All **four authenticated reopens** matched. The sole
replacement is the separately labelled advice witness, not a successful random
sample or quantum run. Its **2.202062 seconds** is declared model time.

The height-15 prefix has work **30**. The public height-16 and private height-16
branches both have work **37**, so the tie retains the public tip. The private
height-17 branch has work **44** and is actually selected. Native valid-work
negative controls reject wrong target, future time and unknown parent. The exact
future packet is accepted one logical second later, without requesting activation.

The full Node regression is **FAILED: 1,243 passed / 2 failed / 35 ignored**.
Both failures also reproduce in separate exact-selector diagnostics:

- `release_owner::root_separation_tests::expired_old_root_keeps_dual_quorum_recovery_and_cold_proof_replay`:
  `State::replay` returns `invalid type: string "1", expected u8`.
- `release_owner::sealed_tests::sealed_copy_survives_in_place_source_rewrite_and_path_replacement`:
  the final recheck returns `M15 sealed object identity/seals changed`.

The affected release-owner directory is unchanged from the parent. Causal
attribution and fixes remain unresolved in this quantum research continuation.
The second failure occurs after creation and mutation-refusal assertions passed;
it is not evidence that memfd is simply unsupported. The diagnostic wrapper's
successful bookkeeping exit does not turn either failed test into a pass.'''
    machine_text = '''| Declared finite implementation | States | Exact ideal replacement risk | Declared conditional fault-union bound |
| --- | ---: | ---: | ---: |
| Full serial quantum lifecycle, q0/q1 | 1 | 0 | approximately 0.00274527357349 |
| Classical uniform q0, no QPU | 7 | 1/64 | 1.6e-29 |

For the classical implementation, exactly one of the 64 pairs of uniform nonce
outcomes gives the legal path `6 -> 1`, hence `(1/8)*(1/8)=1/64`. The seed9 sample
still failed. The statement concerns this fixed initial history and two-attempt
class only.

The quantum finite certificate reserves a common distance **47**, **22,253,112
logical patches** and **98,314,690,616 physical qubits**. Under its declared
single-port serial initialization, initialization alone requires
**1045.896264 seconds**. Both q choices therefore stop at initialization within
the four-second model window: zero completed measurement, candidate, proof or
publication. The conditional bound is **[0, epsilon]**, not zero actual risk.
These are uncalibrated construction assumptions; a slow initialization design
does not bound the cheapest legal attacker.

The full/restricted predicate, P=1/2/4, q=0/1/2 grid retains **all 18 cells**, with
18 constructed and 0 refused. Every ideal delivery interval is exactly [0,0];
every conditional upper endpoint is positive. No pair has certified interval
dominance, so all 18 remain undominated. This does not identify an optimal
implementation. Initialization parallelism, factory design, physical layout and
hardware prices are still premises, not an exhaustive architecture search.'''
    files_text = '''- [qualification.json](qualification.json): source, actual test outcomes, conditional risks and unclosed gates.
- [native-observation.json](native-observation.json): explicit run-by-run native counts and retained full-regression failure.
- [finite-independent-review.json](finite-independent-review.json), [source-receipts-review.json](source-receipts-review.json), and [machine-independent-review.json](machine-independent-review.json): independent result and source checks.
- [observed-economics-summary.json](observed-economics-summary.json) and [machine-frontier-summary.json](machine-frontier-summary.json): compact comparisons with their exact source/input identities.
- [local-validation.tar.xz](local-validation.tar.xz), [index](local-validation-index.json): all local frozen command logs, complete raw-byte source checks, graphs and CPU reparse.
- [native-evidence.tar.gz](native-evidence.tar.gz), [native-core-manifest.json](native-core-manifest.json): original core package, all packets, complete certificates, modeled trajectories, actual native replay and six exact command receipts.
- [execution-and-review.tar.xz](execution-and-review.tar.xz), [index](execution-and-review-index.json): full native regression, both failed diagnostics, environment recovery, complete process records and independent review drivers.
- [development-observations.tar.xz](development-observations.tar.xz), [index](development-observations-index.json): preserved developmental and unsuccessful observations.
- [publication.json](publication.json): the publication block and exact local source identities.
- [manifest.json](manifest.json): SHA256 and length of every deliverable file; self-excluded.'''
    readme = (ROOT / 'four_gates_README.template.md').read_text()
    for key, text in {'NATIVE_RESULT': native_text, 'MACHINE_RESULT': machine_text,
        'NATIVE_TESTS': '**Full suite FAILED: 1,243 passed, 2 failed, 35 ignored**; two explicit bridge tests separately passed',
        'FILES': files_text}.items():
        readme = readme.replace('@@' + key + '@@', text)
    assert '@@' not in readme
    (DEST / 'README.md').write_text(readme)
    files = {p.name: {'bytes': p.stat().st_size, 'sha256': u.sha(p.read_bytes())}
             for p in sorted(DEST.iterdir()) if p.is_file() and p.name != 'manifest.json'}
    put('manifest.json', {'schema': 'trnm-w1-four-gates-evidence-manifest-v1',
        'implementation_commit': u.HEAD, 'implementation_tree': u.TREE,
        'self_excluded': 'manifest.json', 'files': files})
    print(json.dumps({'status': 'RESEARCH_HOLD', 'files': len(files) + 1,
        'directory': str(DEST), 'python_tests': 619,
        'full_node_regression': {'passed':1243, 'failed':2, 'ignored':35},
        'native_bridge_tests_passed':2, 'source_commit':u.HEAD,
        'core_archive_sha256':u.sha(native_archive.read_bytes())}, sort_keys=True))

if __name__ == '__main__':
    main()
