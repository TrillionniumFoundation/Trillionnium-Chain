"""Review the existing frozen campaign record; do not rerun its experiments."""
from pathlib import Path
import collections
import hashlib
import json

root = Path('/workspace/scratch/c9b48df754d6/chain-quantum-next')
path = Path('/workspace/scratch/c9b48df754d6/validation-frozen/campaign/campaign.json')
raw = path.read_bytes()
record = json.loads(raw)
assert record['source']['git_head'] == 'aa46f28505ac6d7cf4bb9830db043510a5aac3e2'
assert record['source']['all_sources_committed_at_head'] is True
assert not record['source']['uncommitted_source_files']
for name, expected in record['source']['source_sha256'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
for name in ('all_clocks_are_measurements', 'finite_horizon_is_native_acceptance_profile',
             'fixed_contexts_are_native_eligible', 'production_activation',
             'profitable_consensus_attack_demonstrated', 'quantum_hardware_executed',
             'quantum_mining_qualified'):
    assert record[name] is False, name
assert record['native_blocks_admitted'] == 0

groups, runs = [], []
for group in record['groups']:
    domains = group['domains']
    assert len(domains) == 5
    assert len({domain['domain_sha256'] for domain in domains}) == 5
    native = group['name'] == 'native'
    for domain in domains:
        assert domain['native_shape'] is native
        assert domain['domain_size'] == len(domain['outcomes'])
        assert domain['marked_count'] == sum(row['winner'] for row in domain['outcomes'])
        assert domain['prefix_restricted_marked_count'] == sum(
            row['winner'] and row['prefix_all_accepted'] for row in domain['outcomes'])
        assert domain['native_winning_proofs_verified'] == sum(
            row['complete_PNW1_scalar_verified'] for row in domain['outcomes'])
    evaluations = sum(domain['domain_size'] for domain in domains)
    proofs = sum(domain['native_winning_proofs_verified'] for domain in domains)
    assert evaluations == (20 if native else 80)
    assert proofs == (5 if native else 0)
    groups.append({'name': group['name'], 'fixed_contexts': len(domains),
                   'candidate_evaluations': evaluations,
                   'distinct_numeric_nonce_values': len({row['nonce'] for domain in domains
                                                        for row in domain['outcomes']}),
                   'scalar_native_winner_proof_checks': proofs,
                   'full_legal_winners': sum(domain['marked_count'] for domain in domains),
                   'phase_restricted_marked_winners': sum(domain['prefix_restricted_marked_count']
                                                         for domain in domains)})
    for run in group['runs']:
        result = run['result']
        observation, binding = result['observation'], result['binding']
        for item in (result, binding):
            assert item['production_activation'] is False
            assert item['quantum_mining_qualified'] is False
        for name in ('quantum_hardware_executed', 'physical_clock_calibrated',
                     'consensus_security_theorem', 'schedule_precommitment_externally_attested'):
            assert observation[name] is False
        assert observation['online_proofs_generated'] == 0
        assert observation['native_blocks_admitted'] == 0
        assert observation['grover_iterations_completed_all_processors'] == 0
        assert observation['plan']['horizon_seconds'] == '4'
        if observation['success']:
            assert observation['termination'] == 'delivered'
            assert len(observation['trials']) == 1
            assert observation['trials'][0]['planned_iterations'] == 0
        elif observation['termination'] == 'horizon':
            assert observation['trials'][0]['censored_phase'] == 'iterations'
            assert observation['trials'][0]['planned_iterations'] == 1
            assert observation['completed_measurement_batches'] == 0
            assert observation['candidate_checks_completed'] == 0
        else:
            assert observation['termination'] == 'schedule-exhausted'
            assert len(observation['trials']) == 4
            assert all(trial['evaluator_legal_winner_count'] == 0
                       for trial in observation['trials'])
        runs.append({'name': run['name'], 'termination': observation['termination'],
                     'assumed_delivery_complete': observation['success'],
                     'completed_grover_iterations_all_processors': 0,
                     'completed_measurement_batches': observation['completed_measurement_batches'],
                     'completed_candidate_checks': observation['candidate_checks_completed'],
                     'elapsed_seconds_exact': observation['elapsed_seconds_exact'],
                     'censored_phases': [trial['censored_phase'] for trial in observation['trials']]})

assert len(runs) == 16
assert len({run['name'] for run in runs}) == 16
terminations = dict(collections.Counter(run['termination'] for run in runs))
assert terminations == {'delivered': 8, 'horizon': 4, 'schedule-exhausted': 4}
summary = {
    'schema': 'frozen-bounded-campaign-summary-review-v1',
    'input_path': str(path), 'input_bytes': len(raw),
    'input_sha256': hashlib.sha256(raw).hexdigest(),
    'source_head': record['source']['git_head'],
    'source_file_hashes_checked': len(record['source']['source_sha256']),
    'scope': 'read and consistency-review existing raw campaign; no new execution or census replay',
    'groups': groups, 'run_count': len(runs), 'terminations': terminations,
    'completed_grover_iterations_all_runs': 0,
    'native_blocks_admitted': 0, 'online_proofs_generated': 0,
    'completed_measurement_batches': sum(run['completed_measurement_batches'] for run in runs),
    'completed_candidate_checks': sum(run['completed_candidate_checks'] for run in runs),
    'runs': runs,
    'interpretation_limits': [
        'Twenty native and eighty reduced figures count candidate evaluations across five contexts each, not globally distinct nonce integers or independent tasks.',
        'The five native PNW1 winner proofs were scalar-verified as offline observer work; this is not five native-admitted blocks or five online quantum proofs.',
        'All eight delivered outcomes use zero Grover iterations and assumed check/proof/propagation clocks; none demonstrates quantum acceleration.',
        'All four one-iteration controls are censored before their first Grover iteration completes; no quantum measurement occurs in those controls.',
        'The four empty-domain runs retain sixteen failed candidate checks each and exhaust their predeclared schedules.',
        'The four-second research horizon is not the native original-resource acceptance profile.',
        'Physical clock and error estimates are declared hypotheses; they do not prove minimum attacker cost, practical attack success, or quantum consensus security.',
    ],
    'overclaim_in_machine_readable_scope_flags_found': False,
}
print(json.dumps(summary,indent=2,sort_keys=True))
