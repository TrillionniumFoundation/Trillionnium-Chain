from pathlib import Path
import hashlib, sys, types
out=Path(__file__).resolve().parent
data=(out/'dependency_helper.py').read_bytes()
assert hashlib.sha256(data).hexdigest()=='301c39565411bb6eb87e5200420c2f18ab76740e9e6675983ecef9678b6463b3'
module=types.ModuleType('pinned_dependency_helper')
module.__file__=str(out/'dependency_helper.py')
exec(compile(data,module.__file__,'exec'),module.__dict__)
module.ROOT=Path('/home/qian-qi/work/chain-qrom-local-20261107-7150')
module.OUT=out
module.EXPECTED='1e4bffc371bcdc53aabc621b6b6cb2485ab36f53'
raise SystemExit(module.main())
