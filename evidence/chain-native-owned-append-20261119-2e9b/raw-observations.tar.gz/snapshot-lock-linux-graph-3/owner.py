from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=s.parent/'snapshot-lock-linux-graph-3';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);env=os.environ.copy();env['CARGO_TARGET_DIR']=str(s.parent/'target');env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];res={'schema':'chain-locked-actual-node-linux-dependency-graph-v1','complete':False,'stages':[]}
def run(name,args):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN);p=subprocess.run(args,cwd=s,env=env,capture_output=True);a=resource.getrusage(resource.RUSAGE_CHILDREN);(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);row={'name':name,'command':args,'exit_code':p.returncode,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stdout_bytes':len(p.stdout)};res['stages'].append(row);(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(row),flush=True);assert p.returncode==0
try:
 run('preflight',['bash','scripts/project-preflight.sh'])
 run('actual-node-linux-graph',['/home/qq/.cargo/bin/cargo','tree','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--locked','--offline','--target','x86_64-unknown-linux-gnu'])
 run('diff-check',['git','diff','--check'])
 res['complete']=True;(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2),flush=True)
except BaseException as e:
 res['error']=repr(e);(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');(out/'error.log').write_text(traceback.format_exc());raise
