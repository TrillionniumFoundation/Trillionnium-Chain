from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/cf19acfe6875/trillionnium-chain')
OUT = Path(__file__).resolve().parent
EXPECTED = '51683089c7ec75cca3e0bcfb2201c08aa5dab654'
EXPECTED_TREE = 'c85745e3396723b07bda7c86a36618c7863e65a5'


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def snapshot(label):
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    rows, missing, mismatch = [], [], []
    total_bytes = 0
    for record in git('ls-tree', '-r', '--full-tree', '-z', 'HEAD').split(b'\0'):
        if not record:
            continue
        header, name = record.split(b'\t', 1)
        mode, kind, expected_blob = header.decode().split()
        relative = os.fsdecode(name)
        path = ROOT / relative
        if not path.exists() and not path.is_symlink():
            missing.append(relative)
            continue
        if path.is_symlink():
            data = os.fsencode(os.readlink(path))
            actual_mode = '120000'
        elif path.is_file():
            data = path.read_bytes()
            actual_mode = '100755' if path.stat().st_mode & 0o111 else '100644'
        else:
            mismatch.append({'path': relative, 'reason': 'not-regular-file-or-link'})
            continue
        actual_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        row = {'path': relative, 'git_mode': mode, 'actual_mode': actual_mode,
               'git_blob': expected_blob, 'actual_git_blob': actual_blob,
               'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
        rows.append(row)
        total_bytes += len(data)
        if kind != 'blob' or expected_blob != actual_blob or mode != actual_mode:
            mismatch.append({'path': relative, 'reason': 'blob-or-mode-mismatch'})
    manifest = {'scope': 'materialized-tracked-files-only-with-explicit-sparse-omissions',
                'head': head, 'tree': tree, 'present': rows, 'missing_tracked_paths': missing,
                'mismatches': mismatch}
    canonical = json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode()
    digest = hashlib.sha256(canonical).hexdigest()
    manifest_path = OUT / ('source-manifest-' + digest + '.json')
    if not manifest_path.exists():
        write_json(manifest_path, manifest)
    status = git('status', '--porcelain=v1').decode()
    result = {'observed_utc': utc(), 'head': head, 'tree': tree,
              'source_manifest_sha256': digest, 'source_manifest': manifest_path.name,
              'present_file_count': len(rows), 'present_bytes': total_bytes,
              'missing_tracked_count': len(missing), 'mismatch_count': len(mismatch),
              'git_status_porcelain': status,
              'exact_head_and_tree': head == EXPECTED and tree == EXPECTED_TREE,
              'present_bytes_and_modes_match_head': not mismatch,
              'full_repository_present': not missing}
    write_json(OUT / (label + '.source.json'), result)
    return result


commands = [
    ('00-preflight', ['bash', 'scripts/project-preflight.sh']),
    ('01-new-query-frontier-tests', ['python3', '-m', 'unittest', 'discover', '-s',
        'formal/pon-nakamoto-v1', '-p', 'test_fixed_success_query_frontier.py', '-v']),
    ('02-retained-fixed-probability-tests', ['python3', '-m', 'unittest', 'discover', '-s',
        'formal/pon-nakamoto-v1', '-p', 'test_fixed_probability_contract.py', '-v']),
    ('03-new-query-frontier-check', ['python3', 'formal/pon-nakamoto-v1/fixed_success_query_frontier.py', '--check']),
    ('04-retained-cost-contract', ['python3', 'formal/pon-nakamoto-v1/fixed_probability_contract.py']),
    ('05-original-repository-check', ['python3', 'scripts/ci/check_repository.py']),
    ('06-ci-contract-static', ['python3', 'scripts/ci/check_ci_contract.py']),
    ('07-cargo-metadata-locked-offline', ['cargo', '+1.95', 'metadata', '--locked', '--offline',
        '--manifest-path', 'trillionnium/Cargo.toml', '--format-version', '1']),
    ('08-cargo-fmt', ['cargo', '+1.95', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check']),
]
environment = dict(os.environ)
environment['PATH'] = '/home/agent/.cargo/bin:' + environment.get('PATH', '')
summary = {'schema': 'query-frontier-exact-source-validation-v1', 'started_utc': utc(),
           'expected_commit': EXPECTED, 'expected_tree': EXPECTED_TREE,
           'python_version': sys.version, 'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'scope': 'focused-python-and-static-gates-on-explicitly-incomplete-sparse-checkout',
           'requested_path_prefix': '/home/agent/.cargo/bin',
           'previous_ci_166_methods': {'rerun_here': False,
              'evidence_kind': 'parent-agent-prior-terminal-observation-only',
              'reported_result': 'PASS', 'raw_output_in_this_packet': False},
           'commands': []}
for name, argv in commands:
    before = snapshot(name + '.before')
    if (not before['exact_head_and_tree'] or not before['present_bytes_and_modes_match_head']
            or before['git_status_porcelain']):
        summary['stopped_reason'] = 'SOURCE_IDENTITY_OR_DIRTY_CHECKOUT'
        break
    start, started_utc = time.monotonic(), utc()
    timeout, launch_error = False, None
    try:
        run = subprocess.run(argv, cwd=ROOT, env=environment, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, timeout=120)
        stdout, stderr, exit_code = run.stdout, run.stderr, run.returncode
    except subprocess.TimeoutExpired as error:
        stdout, stderr, exit_code, timeout = error.stdout or b'', error.stderr or b'', None, True
    except OSError as error:
        stdout, stderr, exit_code, launch_error = b'', b'', None, repr(error)
    elapsed = time.monotonic() - start
    (OUT / (name + '.stdout')).write_bytes(stdout)
    (OUT / (name + '.stderr')).write_bytes(stderr)
    after = snapshot(name + '.after')
    result = {'name': name, 'argv': argv, 'cwd': str(ROOT), 'started_utc': started_utc,
              'elapsed_seconds': elapsed, 'exit_code': exit_code, 'timed_out': timeout,
              'launch_error': launch_error,
              'stdout_path': name + '.stdout', 'stderr_path': name + '.stderr',
              'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
              'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
              'source_before_sha256': before['source_manifest_sha256'],
              'source_after_sha256': after['source_manifest_sha256'],
              'source_unchanged': before['source_manifest_sha256'] == after['source_manifest_sha256'],
              'source_head': after['head'], 'source_tree': after['tree'],
              'source_before_file': name + '.before.source.json',
              'source_after_file': name + '.after.source.json'}
    if name == '07-cargo-metadata-locked-offline' and exit_code == 0:
        metadata = json.loads(stdout)
        result['cargo_summary'] = {'packages': len(metadata['packages']),
                                   'workspace_members': len(metadata['workspace_members'])}
    write_json(OUT / (name + '.result.json'), result)
    summary['commands'].append(result)
    print(json.dumps({'name': name, 'exit_code': exit_code, 'launch_error': launch_error,
                      'seconds': round(elapsed, 3), 'source_unchanged': result['source_unchanged']}), flush=True)
    write_json(OUT / 'summary.json', summary)
    if not result['source_unchanged'] or after['git_status_porcelain']:
        summary['stopped_reason'] = 'SOURCE_CHANGED_DURING_COMMAND'
        break
summary['finished_utc'] = utc()
summary['commands_completed'] = len(summary['commands'])
summary['all_executed_commands_exit_zero'] = all(row['exit_code'] == 0 for row in summary['commands'])
summary['actual_w1_lower_bound'] = False
summary['qualification'] = 'HOLD_NO_GO'
write_json(OUT / 'summary.json', summary)
