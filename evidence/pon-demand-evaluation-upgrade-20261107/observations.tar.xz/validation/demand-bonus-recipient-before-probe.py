"""Independence probe: fixed evaluation fees must not conceal a positive-vote bonus."""
import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--source-dir', type=Path, required=True)
parser.add_argument('--dependency-dir', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.dependency_dir))
sys.path.insert(0, str(args.source_dir))
from test_demand_evidence import DemandTests
from demand_evidence import canonical, commitment


def identity():
    return {name: hashlib.sha256((args.source_dir / name).read_bytes()).hexdigest()
            for name in ('demand_evidence.py', 'test_demand_evidence.py')}


def rebind(fixture, bundle, recipient):
    beneficiary = fixture.keys[recipient]
    bundle['contract']['beneficiaries']['improvement'] = beneficiary
    contract = commitment('contract', bundle['contract'])

    def record(value):
        body = value['body']
        payload = copy.deepcopy(body['payload'])
        if body['kind'] == 'request':
            payload['terms'] = contract
        elif body['kind'] == 'funding':
            payload['sources']['improvement']['beneficiary'] = beneficiary
        elif body['kind'] == 'payment' and payload['account'] == 'improvement':
            payload['beneficiary'] = beneficiary
        elif body['kind'] == 'adoption':
            payload['evaluation'] = commitment('evaluation', bundle['evaluation'])
        signer = next(role for role, key in fixture.keys.items() if key == body['signer'])
        return fixture.sign(body['kind'], payload, contract, signer)

    for field in ('request', 'funding', 'provenance', 'delivery', 'acceptance',
                  'dispute', 'evaluation', 'availability', 'adoption'):
        if bundle[field] is not None:
            bundle[field] = record(bundle[field])
    bundle['payments'] = [record(payment) for payment in bundle['payments']]
    return contract


before = identity()
cases = []
for recipient in ('provider', 'evaluation', 'audit', 'adoption'):
    for outcome in ('no-gain', 'positive-net'):
        fixture = DemandTests()
        fixture.setUp()
        bundle = fixture.bundle(outcome=outcome, bonus=outcome == 'positive-net')
        contract = rebind(fixture, bundle, recipient)
        snapshot = fixture.book.snapshot()
        result = dict(recipient=recipient, outcome=outcome, expected_accept=recipient == 'provider')
        try:
            observed = fixture.book.observe(canonical(bundle), expected_contract=contract,
                                           expected_anchor=fixture.anchor, height=100)
            result.update(accepted=True, independence_attested=observed['independence_attested'],
                          fixed_evaluation_receipt=observed['paid']['evaluation'],
                          improvement_receipt=observed['paid']['improvement'],
                          recipient_total=(observed['paid']['evaluation'] if recipient == 'evaluation' else 0) +
                                           observed['paid']['improvement'],
                          payment_authorized=observed['payment_authorized'])
        except ValueError as error:
            result.update(accepted=False, refusal=str(error),
                          refusal_preserved_snapshot=fixture.book.snapshot() == snapshot)
        result['passes'] = result['accepted'] == result['expected_accept']
        cases.append(result)
after = identity()
result = dict(schema='demand-bonus-recipient-adversarial-v1', source_before=before,
              source_after=after, source_unchanged=before == after, native_executions=0,
              cases=cases, passed=all(c['passes'] for c in cases))
text = json.dumps(result, indent=2, sort_keys=True) + '\n'
args.output.write_text(text)
print(text, end='')
raise SystemExit(0 if result['passed'] else 1)
