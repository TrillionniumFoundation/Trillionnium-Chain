#!/usr/bin/env python3
"""Repeat only the environment-blocked exact-source strict Clippy command."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from run_frozen_validation import source

repo = Path('/workspace/scratch/c9b48df754d6/chain-quantum-next')
head = 'e31e4e1122c1f88c72025b507d5706a0dc96fbd7'
out = repo.parent / 'validation-remote/clippy-supplemental'
out.mkdir(parents=True, exist_ok=False)
before = source(repo, head)
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
command = ['cargo', 'clippy', '--offline', '--locked', '--manifest-path',
           'trillionnium/Cargo.toml', '--workspace', '--all-targets',
           '--all-features', '--', '-D', 'warnings']
started = datetime.now(timezone.utc).isoformat()
start = time.monotonic()
log = out / 'clippy.log'
with log.open('wb') as stream:
    result = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT, timeout=1800)
after = source(repo, head)
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
assert before == after
record = {'schema': 'trnm-remote-clippy-supplement-v1', 'source': before,
          'command': command, 'started_utc': started,
          'elapsed_wall_seconds': time.monotonic() - start, 'exit_code': result.returncode,
          'result': 'PASS' if result.returncode == 0 else 'FAIL',
          'log': log.name, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
          'environment': {key: os.environ.get(key) for key in
              ['OPENSSL_DIR', 'OPENSSL_STATIC', 'OPENSSL_CONF', 'OPENSSL_MODULES',
               'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256', 'TRNM_PQ_OPENSSL_VERSION',
               'CARGO_TARGET_DIR', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG',
               'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL']},
          'original_failed_log': '../rust-rerun/06.log',
          'original_failed_log_sha256': hashlib.sha256((out.parent / 'rust-rerun/06.log').read_bytes()).hexdigest(),
          'repair': 'Export all values from the existing OpenSSL 3.5.9 exports.env with set -a; no dependency or source changes.',
          'original_failure_relabelled': False,
          'runtime_tests_executed': False, 'quantum_mining_qualified': False,
          'production_activation': False}
(out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
