/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/trnm_verification_profiles-2cbbf11fb17afdda.d: crates/trnm-verification-profiles/src/lib.rs crates/trnm-verification-profiles/src/closed_round.rs crates/trnm-verification-profiles/src/exact_integer_linear_v1.rs Cargo.toml

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libtrnm_verification_profiles-2cbbf11fb17afdda.rmeta: crates/trnm-verification-profiles/src/lib.rs crates/trnm-verification-profiles/src/closed_round.rs crates/trnm-verification-profiles/src/exact_integer_linear_v1.rs Cargo.toml

crates/trnm-verification-profiles/src/lib.rs:
crates/trnm-verification-profiles/src/closed_round.rs:
crates/trnm-verification-profiles/src/exact_integer_linear_v1.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
