# Incentive observations on frozen bac6

Runtime source: bac6b7659bd7e2d633e25c2da0add60f6a10c7fb.
Tree: 371c3f55de7940e276496efe2008b537ba4d8268.

One native run executed 31 Rust tests with package default features and the
unchanged Cargo test/dev profile: M06 quorum 9, evolution 4, composition 5;
Node composition 5 and public evaluation 8. All commands exited 0.
The complete tracked source observation contains 28,327 files and
2,578,801,275 bytes. Native before/after and the later pinned-Python source
observations agree.

The same run produced exactly 13 distinct V4 observation files: one collection
of 42 arithmetic cases, nine releases and three claims. Their original bytes,
unique names and one run ID are retained. The paired Python conformance ran in
an isolated Python 3.12 environment installed from the unchanged requirements:
NumPy 1.26.4 and cryptography 50.0.2. Its five native differential and eight pure
oracle methods passed. The independent split receipt checker and six mutation
refusals also completed. The earlier system Python 3.14 / cryptography 46.0.5
observations remain separate and do not qualify that pinned dependency gate.
No native execution was repeated for the Python environment correction.

The split test preserves the counterexample: the complete bundle is identical
while the known source's actual account increase rises by 26,814 development
ledger units after all charged own-account transaction fees. Both funded
release and actual claims are observed under signed M06 execution initialized
from ordinary Node genesis. The split test does not establish ordinary Node
submission, PNW1 verification or independent History confirmation. Passing this
counterexample test is not a defense success, a source-cap bypass, unknown
controller discovery, all-real-world-cost profit or economic qualification.

Command receipts preserve actual argv, exit status, source identity and original
stdout/stderr. The three complete PTY archives have independently checked byte
ranges, SHA-256, successful terminal status and complete capture. Original
acknowledgement and observation timeouts remain in controller records. Their
later reconciliation does not relabel an earlier missing observation as a test
failure or create a second native run.

The archive includes original evidence bytes, helpers and launchers. It excludes
the installed virtual environment, Python caches and native ELF files; the
requirements, pip installation report/freeze and post-execution executable file
observations are retained. The latter are explicitly post-execution snapshots,
not before-execution binary attestations. The artifact manifest lists every
archived regular file except itself and hashes the original file bytes.

This is the scoped component campaign, not the complete protocol-contract CI
lane or qualification of a later evidence child. Production activation and
economic/whole-chain security qualification remain false.
