# Hosted PQ witness controls payloads — run 41628135456

All four downloaded early controls ZIPs match the GitHub-reported SHA-256 and byte size. Their 180 individual required-control executions (45 per lane) pass the retained exact-test transcript validator, command exit/status checks, raw log SHA-256 checks, and before/after source-identity checks. Both newly added controls passed in every lane.

This readback covers the early controls artifacts only. The four witness jobs were still in progress at the API snapshot; the complete Node suite and strict Clippy are not present in these artifacts and remain pending. Whole-chain quantum security remains unqualified.

## Source binding

- Candidate: `12fe5f2c1f19704fe7eb635dede6839ed8b1e91e`.
- Base: `2e72a989d001cf51bd0aed0e1401526e45db31f1`.
- Prospective merge: `0357031364787574cb7058b05329aa2e2730f947`; GitHub confirms its ordered parents are the base and candidate.
- Candidate and prospective merge tree: `c44112da731e3f958e55eb024e5762d6723ea2c9`.
- Every recorded command has identical before/after source identity, with 6,831 tracked entries and 782,174,381 tracked bytes verified by the CI source guard. This local readback validates those retained records and their GitHub commit/tree binding; it does not download and rehash the entire source tree.
- Required-test ordering matches the exact candidate config: the original 43 controls plus the two additions, with no child harness counted.

## Four-lane evidence

| Architecture | Source | Job | Artifact | Required results | SHA-256 |
|---|---|---:|---:|---|---|
| X64 | head | 125890591823 | 13227048372 | 45 passed, 0 failed, 0 ignored | `fbf8d7096a79e55da25f8cddaf431fe1d2a2744e22c4087d86edbfa739e6a1d2` |
| ARM64 | head | 125890592233 | 13227626471 | 45 passed, 0 failed, 0 ignored | `c6cfb229e01d317d19e98f383048c3da3d58b86ea21aa944792e778de7427386` |
| ARM64 | prospective-merge | 125890592092 | 13227695962 | 45 passed, 0 failed, 0 ignored | `48eb4ccc7178839e1deb7957cac1b39827508dbbfeb567a5e5b3950f2c1b9a26` |
| X64 | prospective-merge | 125890592046 | 13227736328 | 45 passed, 0 failed, 0 ignored | `ca84bdf3e287481ddd0d5c76ea1afe5705dd83c9e0cf213ecb3472337d7db3e9` |

## New controls and their limits

`ordinary_admission_reuses_fresh_witness_guard_without_rechecking_unchanged_state` passed in all four lanes. The unchanged source assertions require fresh admission operation sequence `[1, 2]` and pending replay `[1]`, retained state/checkpoint, the same permission epoch, and successful cold reopen.

`expired_admission_commits_retirement_then_obtains_a_new_witness_guard` passed in all four lanes. Its source assertions require the retained `[1, 2, 1, 2]` retirement/admission sequence, expiry epoch publication, retained status/highest sequence, two checkpoint advances, and cold reopen.

The raw logs report exact test execution and success; they do not print the internal operation vectors. The vector/state conclusions follow from the successful exact tests on the recorded source tree. These are in-process native component controls, not WAN, distributed writer fencing, whole-state rollback, migration, or full-system PQ qualification.

The baseline counterexample experiment on X230 is separate and had not been authorized to start at this readback. These hosted passes do not replace or erase the earlier main-host deadline/reset/assertion failures.

## Execution configuration

Each control ran `cargo +1.95.0 test --locked --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib --all-features <exact-selector> -- --exact --show-output --test-threads=1` using the existing repository test profile, without `--release`. The original 250 ms budget was not altered by this patch. Recorded environments retain two build jobs, no incremental compilation, and no RUSTFLAGS overrides.

All lanes prepared the pinned OpenSSL 3.5.9 provider and retained its source-digest verification and smoke evidence. Native command environments bind to each lane’s provider binary hash. Provider preparation itself is not a native-test result or an independent-implementation claim; the provider receipt explicitly keeps that claim false.

## Reproduce the readback

In the separately retained full package, run `python3 verify-readback.py` from its unpacked evidence directory. It reads the original ZIPs without extracting or altering them, uses the exact candidate version of `check_required_native_test.py`, verifies all native command/log pairs, and writes a detailed `readback.json` with all 180 selectors and per-file hashes. API source snapshots and a manifest of every ZIP member are retained.

The first local inspection attempt encountered a `KeyError` because the summary-only jobs wrapper omits `head_sha`; its observed error is preserved in `readback-setup-error.log`. The completed readback uses the full read-only GitHub jobs API snapshot. This was a local metadata-parser setup issue, not a native test failure.

## Payload packaging

This package contains every original file from each of the four ZIPs under `payloads/<artifact-id>/`, byte-for-byte, without repeating ZIP containers. The original full package is retained separately (725848 bytes; SHA-256 `09877c4fe92a81afafc9ce54eb56b655bd63d9300eb3145c011f2844cc639ac3`). `original-zip-verification.json` retains the independently downloaded ZIP digest/size checks. A digest of the original ZIP cannot be recomputed from extracted files because ZIP container metadata is absent.

Run `python3 verify-payloads.py` after unpacking, or `python3 verify-payloads.py /path/to/hosted-controls-payloads-41628135456.tar.xz`. This rechecks each raw payload against the original member manifest, all 180 exact tests, command/log hashes and source identities. `verify-readback-original.py` is retained for transparency and requires the separate original ZIPs. The payload readback clearly records that original ZIP digests were verified before packaging, not recomputed by the payload-only check.
