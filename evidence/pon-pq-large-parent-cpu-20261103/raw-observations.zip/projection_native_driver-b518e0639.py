#!/usr/bin/env python3
"""Execute retained, legal Node controls from one exact committed build."""
from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT = Path('/home/qian-qi/worktrees/trnm-pq-large-parent-cpu-20261103')
OUT = Path('/home/qian-qi/work/trnm-pq-large-parent-cpu-evidence-20261103')
HEAD = 'b518e0639b56175ce0fc8361d8be3d479ae113e4'
EXPECTED_ELF = 'd5b31f23b0936825ea34fbd677e3fe11d7fd102d3f1c1c523ef747c08192a99f'
subprocess.run(['bash', 'scripts/project-preflight.sh'], cwd=ROOT, check=True)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
receipt = json.loads((OUT / 'projection-node-build.json').read_text())
assert receipt['status'] == 'command_succeeded' and receipt['before'] == receipt['after']
assert receipt['before']['tested_commit'] == HEAD
artifacts = []
for line in (OUT / 'projection-node-build.log').read_text().splitlines():
    try:
        item = json.loads(line)
    except json.JSONDecodeError:
        continue
    if (item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == 'trnm_pon_node'
            and item.get('target', {}).get('kind') == ['lib'] and item.get('profile', {}).get('test')
            and item.get('executable')):
        artifacts.append(item)
assert len(artifacts) == 1
artifact = artifacts[0]
binary = Path(artifact['executable'])
package = ROOT / 'trillionnium/crates/trnm-pon-node'
assert Path(artifact['target']['src_path']).resolve() == package / 'src/lib.rs'
assert artifact['features'] == ['default'] and artifact['profile']['opt_level'] == '3'
assert artifact['profile']['debug_assertions'] and artifact['profile']['overflow_checks']
assert binary.is_file() and not binary.is_symlink()

def binary_hash():
    with binary.open('rb') as stream:
        assert stream.read(4) == b'\x7fELF'
        stream.seek(0)
        return hashlib.file_digest(stream, 'sha256').hexdigest()

assert binary_hash() == EXPECTED_ELF
registry = subprocess.check_output([str(binary), '--list', '--format', 'terse'], cwd=package, text=True)
names = [line.removesuffix(': test') for line in registry.splitlines() if line.endswith(': test')]
assert names and len(names) == len(set(names))
registered = set(names)
prefix = 'store::native_authenticated::arithmetic_cache::large_input_tests::'
large = sorted(name for name in registered if name.startswith(prefix))
assert len(large) == 2
binding = {'head': HEAD, 'build_receipt': 'projection-node-build.json', 'artifact': artifact,
           'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'binary_sha256_before': EXPECTED_ELF, 'package_cwd': str(package),
           'large_input_controls': large, 'native_commands': []}
binding_path = OUT / 'projection-node-binary-binding.json'
with binding_path.open('x') as stream:
    json.dump(binding, stream, indent=2)
with (OUT / 'projection-node-registry.log').open('x') as stream:
    stream.write(registry)
detached = 'store::detached_admission::tests::'
history = 'store::historical_commitment_tests::'
reactor = 'ingress::public_v2::tests::'
jobs = [
    ('projection-large-genesis', detached + 'admitted_custom_genesis_over_eight_mib_keeps_original_held_schedule_and_cpu_owner', True, 1),
    ('projection-auth-parent', detached + 'authenticated_large_parent_original_schedule_supplementary_denominator', True, 1),
    ('projection-large-cache', prefix, False, 2),
    ('projection-parser', 'ingress::public_v3::tests::canonical_', False, 5),
    ('projection-codec', 'store::canonical_json::tests::', False, 2),
    ('projection-live-state', 'store::bounded_active_state_tests::', False, 3),
    ('projection-byte-error', 'store::error_boundary_tests::persisted_state_bytes_and_root_are_local_but_progress_errors_keep_their_identity', True, 1),
    ('projection-current-sql-root', detached + 'large_parent_root_arithmetic_keeps_current_sql_and_original_read_checkpoints', True, 1),
    ('projection-trigger-readback', detached + 'original_transaction_readback_rejects_trigger_corruption_and_rolls_back', True, 1),
    ('projection-reorg-tail', 'store::reorg_readback_tests::', False, 6),
    ('projection-postwrite', 'store::native_authenticated::post_write_readback::tests::', False, 15),
    ('projection-history-current', history + 'legacy_prepared_history_reads_observe_current_rows_writes_and_rollback', True, 1),
    ('projection-history-schema', history + 'legacy_prepared_history_reads_reprepare_after_schema_and_authorizer_changes', True, 1),
    ('projection-history-damage', history + 'actual_foreign_snapshot_delta_and_root_damage_preserve_original_failures', True, 1),
    ('projection-reactor-internal', reactor + 'public_loop_exit_records_lifetime_before_internal_stop', True, 1),
    ('projection-reactor-external', reactor + 'public_loop_exit_records_external_stop_after_signed_read', True, 1),
]
env = os.environ.copy()
env.update(CARGO_HOME='/home/qian-qi/work/trnm-pq-admission-cargo-20261103',
           CARGO_TARGET_DIR='/home/qian-qi/work/trnm-pq-large-parent-cpu-target-20261103',
           CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
           RUSTC='/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc')
status = 0
for label, selector, exact, count in jobs:
    selected = sorted(name for name in registered if (name == selector if exact else name.startswith(selector)))
    assert len(selected) == count and binary_hash() == EXPECTED_ELF
    assert not (OUT / (label + '.json')).exists() and not (OUT / (label + '.log')).exists()
    command = ['/usr/bin/env', '--chdir=' + str(package), '/usr/bin/time', '-v', '-o',
               str(OUT / (label + '.resources.txt')), str(binary), selector]
    command += (['--exact'] if exact else []) + ['--nocapture', '--test-threads=1']
    print('START', label, flush=True)
    args = ['python3', 'scripts/ci/record_pq_native_command.py', '--kind', 'head',
            '--candidate', HEAD, '--tested', HEAD, '--label', label, '--output', str(OUT), '--', *command]
    with (OUT / (label + '-recorder.log')).open('xb') as stream:
        result = subprocess.run(args, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    reader_code = None
    if exact and (OUT / (label + '.log')).exists():
        with (OUT / (label + '.execution.json')).open('xb') as output, (OUT / (label + '.execution.stderr')).open('xb') as error:
            reader_code = subprocess.run(['python3', 'scripts/ci/check_required_native_test.py',
                str(OUT / (label + '.log')), '--test', selector], cwd=ROOT, stdout=output, stderr=error).returncode
    binding['native_commands'].append({'label': label, 'registered_controls': selected,
                                      'recorded_exit': result.returncode, 'reader_exit': reader_code})
    binding['binary_sha256_after_latest'] = binary_hash()
    assert binding['binary_sha256_after_latest'] == EXPECTED_ELF
    binding_path.write_text(json.dumps(binding, indent=2) + '\n')
    print('DONE', label, 'exit', result.returncode, 'reader', reader_code, flush=True)
    if (OUT / (label + '.log')).exists():
        print('\n'.join(line for line in (OUT / (label + '.log')).read_text().splitlines()
                        if line.startswith('test result:')), flush=True)
    status |= bool(result.returncode or reader_code)
    record = json.loads((OUT / (label + '.json')).read_text())
    assert record['status'] in ['command_succeeded', 'command_failed'], 'incomplete/source failure stops further execution'
binding['all_native_commands_terminal'] = True
binding['aggregate_exit'] = int(status)
binding_path.write_text(json.dumps(binding, indent=2) + '\n')
print('ALL_NATIVE_COMMANDS_TERMINAL', 'exit', int(status), flush=True)
raise SystemExit(int(status))
