"""Produce replayable reduced-fixture preprocessing scopes and source hashes."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    repo = parser.parse_args().repo.resolve()
    formal = repo / "formal/pon-nakamoto-v1"
    sys.path.insert(0, str(formal))
    from test_w1_preprocessing_reuse import PreprocessingReuseTests
    from w1_preprocessing_reuse import compare_preprocessing
    from w1_quantum_oracle import template_from_spec

    PreprocessingReuseTests.setUpClass()
    observations = []
    for name, left, right, nonce, expected_blocks, same_task in PreprocessingReuseTests.cases:
        # Round-trip the exact inputs that this evidence file retains.
        inputs = {"left_template": left.spec(), "right_template": right.spec(),
                  "left_nonce": 0, "right_nonce": nonce}
        result = compare_preprocessing(template_from_spec(inputs["left_template"]),
                                       template_from_spec(inputs["right_template"]), 0, nonce)
        if (result["matching_fixed_prefix_blocks"] != expected_blocks
                or result["ab_inputs_equal"] != same_task
                or result["task_commitment_input_equal"] != same_task):
            raise AssertionError(name)
        observations.append({"case": name, "inputs": inputs, "result": result})
    sources = ("w1_preprocessing_reuse.py", "test_w1_preprocessing_reuse.py",
               "w1_quantum_oracle.py", "w1_quantum_restricted_oracle.py",
               "w1_quantum_primitives.py", "reversible_components.py",
               "test_w1_quantum_oracle.py")
    print(json.dumps({"scope": "eight reduced-fixture changes; no timing or energy measurement",
                      "source_sha256": {name: hashlib.sha256((formal / name).read_bytes()).hexdigest()
                                        for name in sources},
                      "control_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                      "observations": observations}, indent=2))


if __name__ == "__main__":
    main()
