# Source reader race regression

The `pre_fix` readers are exact bytes from commit
`79075c36cb8a9d27f922920c1f4958895efc32b5`. The regression control files are
identical in the two snapshots. `source-hashes.json` records SHA-256 and Git blob
identities for every captured source file, and identifies old source versus the
uncommitted repair. The post-fix helper is included as a captured dependency.

Run `python3 replay.py --phase both` to reproduce. The script verifies all
captured source hashes before executing the same selected unittest classes,
then preserves raw stdout, stderr and a structured result. Pre-fix failures are
intentional observations; post-fix failures make the replay command fail.

Scheduling hooks perform real filesystem changes at the check/open or
check/read boundary. They do not replace stat results, returned bytes or the
underlying open/read operations. Cases include leaf replacement, leaf symlinks,
parent replacement preserving the same hardlinked leaf, parent and checkout
ancestor symlinks, equal-size ordinary and mmap writes, restored mtime, source
growth, disappearance, and a FIFO substitution with a two-second deadlock
failure. Stable files remain accepted. Failed reads must close all recorded
file descriptors.

These are local source-reader regressions. They do not establish cryptographic,
consensus, whole-state rollback, public-network or runtime qualification.
Directory traversal is verified per read, not as an immutable whole-checkout
snapshot against a privileged filesystem or changes between separate reads.
