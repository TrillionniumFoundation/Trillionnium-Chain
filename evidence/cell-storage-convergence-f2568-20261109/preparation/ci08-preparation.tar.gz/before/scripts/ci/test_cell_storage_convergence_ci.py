"""Exact workflow seams and mutation controls; not native execution evidence."""
from __future__ import annotations
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[2]
WORKFLOW = ROOT / ".github/workflows/pon-next-architecture-security.yml"
PYTHON_STEP = "Run all next-architecture Python controls and retained exact fixture"
NODE_STEP = "Run complete storage-owner module and exact new funding controls"
DA_STEP = "Run the complete default-feature P2P crate"
SOURCE_BEFORE_STEP = "Verify exact source and ordered prospective merge"
SOURCE_AFTER_STEP = "Reverify the complete measured source after all attempts"
OUTCOMES_STEP = "Retain stage outcomes and artifact digests"
UPLOAD_STEP = "Retain logs and failed or partial observations"
PYTHON_GUARD = "        if: ${{ always() && steps.source.outcome == 'success' && steps.preflight.outcome == 'success' }}"
NATIVE_GUARD = "        if: ${{ always() && steps.source.outcome == 'success' && steps.preflight.outcome == 'success' && steps.toolchain.outcome == 'success' }}"
PYTHON_RUN_BODY = """\
          set -euo pipefail
          status=0
          bash "$OUT/run-command.sh" next-python python3 -B -m unittest discover -s formal/next-architecture-security -p 'test_*.py' -v || status=1
          bash "$OUT/run-command.sh" counterexample-fixture python3 -B formal/next-architecture-security/counterexamples.py --check-fixture || status=1
          bash "$OUT/run-command.sh" complete-version-vector python3 -B scripts/cell_complete_version_vector.py --check || status=1
          bash "$OUT/run-command.sh" discovery-epoch-vector python3 -B scripts/cell_discovery_epoch_v3_vector.py --check || status=1
          bash "$OUT/run-command.sh" discovery-workflow-controls python3 -B scripts/ci/test_cell_discovery_v3_ci.py || status=1
          bash "$OUT/run-command.sh" complete-content-vector python3 -B scripts/cell_version_content_vector.py --check || status=1
          bash "$OUT/run-command.sh" version-retention-vector python3 -B scripts/cell_version_retention_v3_vector.py --check || status=1
          bash "$OUT/run-command.sh" storage-descriptor-vector python3 -B scripts/cell_storage_descriptor_reference.py --check || status=1
          bash "$OUT/run-command.sh" storage-convergence-workflow-controls python3 -B scripts/ci/test_cell_storage_convergence_ci.py || status=1
          exit "$status"
"""
NODE_RUN_BODY = """\
          set -euo pipefail
          status=0
          bash "$OUT/run-command.sh" native-storage-owner cargo +1.95.0 test --locked --release --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib store::storage_service:: -- --test-threads=1 || status=1
          required=(
            store::storage_service::tests::version::native_version_reorg_keeps_custody_but_cannot_grant_new_funding_or_foreign_retirement
            store::storage_service::tests::version::native_version_scheduler_pending_metadata_accepts_only_new_funded_copy_then_reopens_done
            store::storage_service::tests::version::native_version_pending_monetary_effect_cannot_retry_copy_with_a_new_source
            store::storage_service::tests::version::native_version_scope_alias_and_late_funding_errors_precede_every_reservation
            store::storage_service::tests::version::native_version_outer_history_cannot_invent_missing_member_intents
            store::storage_service::tests::shard::native_shard_real_funding_target_readback_and_repair_keep_original_debits
            store::storage_service::tests::shard::native_shard_pending_initial_effect_cannot_dispatch_even_with_source_present
            store::storage_service::tests::shard::native_shard_unknown_repair_never_reissues_and_foreign_owner_cannot_retire
            store::storage_service::tests::version::shard_plan::native_complete_version_to_complete_local_shard_plan_reopens_without_sources_or_new_debits
          )
          for selector in "${required[@]}"; do
            bash "$OUT/run-command.sh" "native-storage-$selector" cargo +1.95.0 test --locked --release --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib "$selector" -- --exact --test-threads=1 || status=1
            python3 -B scripts/ci/check_required_native_test.py "$OUT/native-storage-$selector.log" --test "$selector" || status=1
          done
          exit "$status"
"""
DA_RUN_BODY = """\
          set -euo pipefail
          bash "$OUT/run-command.sh" p2p-complete cargo +1.95.0 test --locked --release --manifest-path trillionnium/Cargo.toml -p trnm-data-availability -- --test-threads=1
"""
NODE_REQUIRED_NAMES = (
    'store::storage_service::tests::version::native_version_reorg_keeps_custody_but_cannot_grant_new_funding_or_foreign_retirement',
    'store::storage_service::tests::version::native_version_scheduler_pending_metadata_accepts_only_new_funded_copy_then_reopens_done',
    'store::storage_service::tests::version::native_version_pending_monetary_effect_cannot_retry_copy_with_a_new_source',
    'store::storage_service::tests::version::native_version_scope_alias_and_late_funding_errors_precede_every_reservation',
    'store::storage_service::tests::version::native_version_outer_history_cannot_invent_missing_member_intents',
    'store::storage_service::tests::shard::native_shard_real_funding_target_readback_and_repair_keep_original_debits',
    'store::storage_service::tests::shard::native_shard_pending_initial_effect_cannot_dispatch_even_with_source_present',
    'store::storage_service::tests::shard::native_shard_unknown_repair_never_reissues_and_foreign_owner_cannot_retire',
    'store::storage_service::tests::version::shard_plan::native_complete_version_to_complete_local_shard_plan_reopens_without_sources_or_new_debits',
)
TRIGGERS = (
    'docs/development/specs/pon/CELL_STORAGE_CONVERGENCE_DEV_V1.md',
    'scripts/cell_version_retention_v3_vector.py',
    'scripts/cell_storage_descriptor_reference.py',
    'scripts/ci/test_cell_storage_convergence_ci.py',
    'formal/pon-nakamoto-v1/vectors/cell-version-retention-v3.json',
    'formal/pon-nakamoto-v1/vectors/cell-storage-owner-vectors-v1.json',
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def exact_line(text: str, line: str) -> None:
    require(text.splitlines().count(line) == 1, "missing/duplicate/nonliteral workflow line: " + line.strip())


def step(text: str, name: str) -> str:
    marker = "      - name: " + name + "\n"
    require(text.count(marker) == 1, "missing/duplicate workflow step: " + name)
    return text.split(marker, 1)[1].split("\n      - name:", 1)[0].rstrip("\n") + "\n"


def run_body(block: str) -> str:
    marker = "        run: |\n"
    require(block.count(marker) == 1, "workflow run body missing/duplicate")
    return block.split(marker, 1)[1]


def validate(text: str) -> None:
    triggers = text.split("\npermissions:", 1)[0]
    for path in TRIGGERS:
        exact_line(triggers, "      - " + path)
    strategy_marker = "    strategy:\n"
    require(text.count(strategy_marker) == 1, "matrix strategy missing/duplicate")
    strategy = text.split(strategy_marker, 1)[1].split("\n    env:", 1)[0].rstrip("\n")
    require(strategy == "      fail-fast: false\n      matrix:\n"
            "        runner: [ubuntu-24.04, ubuntu-24.04-arm]\n"
            "        source: [head, prospective-merge]",
            "all four source/architecture combinations must run without matrix exclusions")
    require(text.count("  next-architecture:\n") == 1, "next-architecture job missing/duplicate")
    job_header = text.split("  next-architecture:\n", 1)[1].split("    steps:\n", 1)[0]
    require(not any(line.startswith(("    if:", "    continue-on-error:")) for line in job_header.splitlines()),
            "job-level skip/failure bypass")
    for line in (
        "        runner: [ubuntu-24.04, ubuntu-24.04-arm]",
        "        source: [head, prospective-merge]",
        "  cancel-in-progress: false",
        "    timeout-minutes: 90",
        '  CARGO_BUILD_JOBS: "2"',
        '  RUST_TEST_THREADS: "1"',
        "      EXPECTED_SOURCE: ${{ matrix.source == 'head' && github.event.pull_request.head.sha || github.sha }}",
    ):
        exact_line(text, line)
    checkout = step(text, "Checkout the immutable event source")
    exact_line(checkout, "          ref: ${{ env.EXPECTED_SOURCE }}")
    exact_line(checkout, "          fetch-depth: 0")
    exact_line(checkout, "          persist-credentials: false")
    preflight = step(text, "Retain original project preflight")
    exact_line(preflight, '        run: bash "$OUT/run-command.sh" preflight bash scripts/project-preflight.sh --audit')

    python = step(text, PYTHON_STEP)
    node = step(text, NODE_STEP)
    da = step(text, DA_STEP)
    for block, identifier, guard, body in ((python, "python", PYTHON_GUARD, PYTHON_RUN_BODY),
                                           (node, "storage_owner", NATIVE_GUARD, NODE_RUN_BODY),
                                           (da, "p2p", NATIVE_GUARD, DA_RUN_BODY)):
        exact_line(block, guard)
        exact_line(block, "        shell: bash")
        require("continue-on-error:" not in block, "native/Python gate failure cannot be ignored")
        expected_header = "        id: " + identifier + "\n" + guard + "\n        shell: bash\n"
        require(block.split("        run: |\n", 1)[0] == expected_header,
                "runtime step source/environment/profile header changed")
        require(run_body(block) == body, "required command/body/roster or failure exit changed")
    exact_line(node, "        id: storage_owner")
    # The exact body retains the full module plus nine genuine one-test runs.
    # The existing checker deliberately accepts only an actual one-test log.
    require(len(NODE_REQUIRED_NAMES) == len(set(NODE_REQUIRED_NAMES)) == 9,
            "new native funding roster changed")
    for name in NODE_REQUIRED_NAMES:
        exact_line(node, "            " + name)

    for name, label in ((SOURCE_BEFORE_STEP, "source-before"), (SOURCE_AFTER_STEP, "source-after")):
        block = step(text, name)
        exact_line(block, '          args=(--kind "$SOURCE_KIND" --expected-head "$EXPECTED_HEAD")')
        exact_line(block, '          if test "$SOURCE_KIND" = prospective-merge; then')
        exact_line(block, '            args+=(--expected-base "$EXPECTED_BASE" --expected-merge "$EXPECTED_MERGE")')
        exact_line(block, '          bash "$OUT/run-command.sh" ' + label
                   + ' python3 -B scripts/ci/verify_ci_source.py "${args[@]}" --output "$OUT/' + label + '.json"')
    after = step(text, SOURCE_AFTER_STEP)
    exact_line(after, "        if: ${{ always() && steps.source.outcome == 'success' }}")
    exact_line(after, '          cmp "$OUT/source-before.json" "$OUT/source-after.json"')
    exact_line(after, '          cmp "$OUT/source-before.json" "$OUT/source.json"')

    outcomes = step(text, OUTCOMES_STEP)
    exact_line(outcomes, "        if: ${{ always() && steps.reserve.outcome == 'success' }}")
    exact_line(outcomes, '          stage_outcomes = json.loads(os.environ["STAGE_OUTCOMES"])')
    exact_line(outcomes, '          storage_owner_passed = stage_outcomes.get("storage_owner", {}).get("outcome") == "success"')
    exact_line(outcomes, '              "steps": stage_outcomes,')
    exact_line(outcomes, '              "storage_owner_required": True,')
    exact_line(outcomes, '              "storage_owner_passed": storage_owner_passed,')
    exact_line(outcomes, '          (root / "sha256sums.txt").write_text("\\n".join(records) + "\\n")')
    exact_line(outcomes, "          if not storage_owner_passed:")
    exact_line(outcomes, '              raise SystemExit("required storage-owner native stage did not succeed")')
    require(outcomes.index('          if not storage_owner_passed:')
            > outcomes.index('          (root / "sha256sums.txt").write_text'),
            "failure must retain summaries and hashes before rejecting the gate")
    upload = step(text, UPLOAD_STEP)
    exact_line(upload, "        if: always()")
    exact_line(upload, "          if-no-files-found: error")
    exact_line(upload, "          retention-days: 30")


class CellStorageConvergenceCiControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.text = WORKFLOW.read_text()

    def rejected(self, changed: str) -> None:
        self.assertNotEqual(changed, self.text)
        with self.assertRaises(ValueError):
            validate(changed)

    def test_current_source_preserves_complete_runtime_and_failure_seams(self) -> None:
        validate(self.text)

    def test_new_commands_cannot_be_omitted_moved_duplicated_or_stubbed(self) -> None:
        blocks = (step(self.text, PYTHON_STEP), step(self.text, NODE_STEP))
        lines = [line + "\n" for block in blocks for line in block.splitlines()
                 if ("version-retention-vector" in line or "storage-descriptor-vector" in line
                     or "storage-convergence-workflow-controls" in line
                     or 'native-storage-owner cargo' in line
                     or '"native-storage-$selector" cargo' in line
                     or "check_required_native_test.py" in line)]
        self.assertEqual(len(lines), 6)
        for line in lines:
            for change in ("", line * 2, line.replace("bash ", "true # bash ", 1)
                           if "bash " in line else line.replace("python3 ", "true # python3 ", 1),
                           line.replace("|| status=1", "|| true")):
                with self.subTest(line=line, change=change):
                    self.rejected(self.text.replace(line, change, 1))
            self.rejected(self.text.replace(line, "", 1) + line)

    def test_native_compile_only_skip_ignored_filters_and_release_changes_reject(self) -> None:
        for step_name in (NODE_STEP, DA_STEP):
            original = step(self.text, step_name)
            for replacement in (" --no-run -- --test-threads=1", " -- --skip missing --test-threads=1",
                                " -- --ignored --test-threads=1", " bogus -- --test-threads=1"):
                changed = original.replace(" -- --test-threads=1", replacement, 1)
                self.rejected(self.text.replace(original.rstrip("\n"), changed.rstrip("\n"), 1))
            changed = original.replace(" --release", "", 1)
            self.rejected(self.text.replace(original.rstrip("\n"), changed.rstrip("\n"), 1))
        self.rejected(self.text.replace("--lib store::storage_service:: --", "--lib store::storage_service::tests::version:: --", 1))

    def test_all_nine_exact_names_are_mandatory_unique_and_executed(self) -> None:
        for name in NODE_REQUIRED_NAMES:
            line = "            " + name + "\n"
            for change in ("", line * 2, "            # " + name + "\n", line.replace(name, name + "_substitute")):
                with self.subTest(name=name, change=change):
                    self.rejected(self.text.replace(line, change, 1))
        self.rejected(self.text.replace('for selector in "${required[@]}";', 'for selector in "${required[0]}";', 1))
        self.rejected(self.text.replace('"$OUT/native-storage-$selector.log" --test', '"$OUT/native-storage-owner.log" --test', 1))
        self.rejected(self.text.replace('"$selector" -- --exact --test-threads=1', '"$selector" -- --test-threads=1', 1))

    def test_native_and_python_failure_exits_and_source_guards_cannot_be_skipped(self) -> None:
        for name in (PYTHON_STEP, NODE_STEP):
            original = step(self.text, name)
            for changed in (original.replace('exit "$status"', "exit 0", 1),
                            original.replace("${{ always() &&", "${{ false &&", 1),
                            original.replace("        shell: bash", "        continue-on-error: true\n        shell: bash", 1),
                            original.replace("steps.preflight.outcome == 'success'", "true", 1)):
                self.rejected(self.text.replace(original.rstrip("\n"), changed.rstrip("\n"), 1))

    def test_both_source_axes_and_both_architecture_axes_remain_required(self) -> None:
        for old, replacements in (
            ("runner: [ubuntu-24.04, ubuntu-24.04-arm]", ("runner: [ubuntu-24.04]", "runner: [ubuntu-24.04-arm]")),
            ("source: [head, prospective-merge]", ("source: [head]", "source: [prospective-merge]")),
            ("ref: ${{ env.EXPECTED_SOURCE }}", ("ref: main",)),
            ("--kind \"$SOURCE_KIND\"", ("--kind head",)),
            ("--expected-head \"$EXPECTED_HEAD\"", ("--expected-head HEAD",)),
        ):
            for new in replacements:
                self.rejected(self.text.replace(old, new, 1))
        self.rejected(self.text.replace('            args+=(--expected-base "$EXPECTED_BASE" --expected-merge "$EXPECTED_MERGE")\n', "", 1))

    def test_matrix_exclusions_job_skips_and_different_step_sources_reject(self) -> None:
        anchor = "        source: [head, prospective-merge]\n"
        for addition in ("        exclude:\n          - runner: ubuntu-24.04-arm\n            source: prospective-merge\n",
                         "        include:\n          - runner: ubuntu-24.04\n            source: head\n"):
            self.rejected(self.text.replace(anchor, anchor + addition, 1))
        self.rejected(self.text.replace("  next-architecture:\n", "  next-architecture:\n    if: false\n", 1))
        self.rejected(self.text.replace("      fail-fast: false", "      fail-fast: true", 1))
        node = step(self.text, NODE_STEP)
        for addition in ("        working-directory: another-checkout\n", "        env:\n          RUSTFLAGS: altered\n"):
            changed = node.replace("        shell: bash\n", addition + "        shell: bash\n", 1)
            self.rejected(self.text.replace(node.rstrip("\n"), changed.rstrip("\n"), 1))

    def test_new_path_triggers_and_original_resource_bounds_are_not_dropped(self) -> None:
        for path in TRIGGERS:
            self.rejected(self.text.replace("      - " + path + "\n", "", 1))
        for old, new in (("cancel-in-progress: false", "cancel-in-progress: true"),
                         ("timeout-minutes: 90", "timeout-minutes: 91"),
                         ('CARGO_BUILD_JOBS: "2"', 'CARGO_BUILD_JOBS: "4"'),
                         ('RUST_TEST_THREADS: "1"', 'RUST_TEST_THREADS: "2"')):
            self.rejected(self.text.replace(old, new, 1))

    def test_storage_outcome_participates_in_final_summary_and_exit(self) -> None:
        for old, new in (
            ('stage_outcomes.get("storage_owner", {}).get("outcome") == "success"', "True"),
            ('              "storage_owner_required": True,\n', ""),
            ('              "storage_owner_passed": storage_owner_passed,\n', ""),
            ("          if not storage_owner_passed:", "          if False:"),
            ('              raise SystemExit("required storage-owner native stage did not succeed")', "              pass"),
            ("        id: storage_owner", "        id: uncounted_storage_owner"),
        ):
            self.rejected(self.text.replace(old, new, 1))

    def test_failed_source_and_logs_still_have_unconditional_final_observation(self) -> None:
        original = step(self.text, SOURCE_AFTER_STEP)
        changed = original.replace("always()", "success()", 1)
        self.rejected(self.text.replace(original.rstrip("\n"), changed.rstrip("\n"), 1))
        self.rejected(self.text.replace('          cmp "$OUT/source-before.json" "$OUT/source-after.json"\n', "", 1))
        upload = step(self.text, UPLOAD_STEP)
        for changed in (upload.replace("if: always()", "if: success()"),
                        upload.replace("if-no-files-found: error", "if-no-files-found: ignore"),
                        upload.replace("retention-days: 30", "retention-days: 1")):
            self.rejected(self.text.replace(upload.rstrip("\n"), changed.rstrip("\n"), 1))


if __name__ == "__main__":
    unittest.main()
