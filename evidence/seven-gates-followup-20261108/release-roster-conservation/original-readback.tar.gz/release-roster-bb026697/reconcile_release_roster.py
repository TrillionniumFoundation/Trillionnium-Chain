#!/usr/bin/env python3
"""Read-only evidence reconciliation. Never invokes Cargo or edits a repository."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


FINAL = "bb026697a972521009bc133ae6ed2b653e18e931"
BASE = "7e044b65454f4c9ea505591727332acffb33e7e5"
INTRO = "155c8e3a8c188ba113accb4079e9ad344d5c63a1"
INTRO_PARENT = "12e510b211110d93d9ead07e02c07a1eecc28ae9"
LOG_SHA256 = "ae0c50c82ed0682bb5ed1fc81620283d68954839f95be03d15a5b52302aabb2a"
CRATE = "trillionnium/crates/trnm-release-bundle"
MANIFEST = "config/pon/pq-initial-root-material-required-tests-v1.json"
RUNNER = "evidence/pq-authority-preflight-20261108-9d315/authority-final-validation-runner.py"
EXTRA = sorted([
    "content_v1::tests::complete_artifact_and_all_metadata_enter_the_strong_commitment",
    "content_v1::tests::retained_file_reads_exact_bytes_and_refuses_partial_offset",
    "content_v1::tests::short_long_wrong_locator_and_old_digest_wrapper_are_refused",
])
MODULES = {
    "src/lib.rs": "tests",
    "src/content_v1/tests.rs": "content_v1::tests",
    "src/pq_release/tests.rs": "pq_release::tests",
    **{f"src/pq_release/{name}.rs": f"pq_release::tests::{name}" for name in (
        "current_tests", "validated_root_tests", "bundle_quorum_tests",
        "retained_verifier_tests", "initial_root_material_tests", "quorum_preflight_tests",
    )},
}
NAME_RE = re.compile(r"^test ([A-Za-z0-9_:]+) \.\.\. (ok|FAILED|ignored(?:,.*)?)$", re.M)
SUMMARY_RE = re.compile(
    r"^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; "
    r"(\d+) measured; (\d+) filtered out;.*$", re.M
)
TEST_RE = re.compile(
    r"(?P<attrs>(?:^[ \t]*#\[[^\n]*\][ \t]*\n)+)"
    r"^[ \t]*fn (?P<name>[A-Za-z0-9_]+)\(", re.M
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.out.resolve()
    if out == repo or repo in out.parents:
        raise ValueError("evidence output must be outside the source repository")
    out.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_NO_LAZY_FETCH="1")
    history_commands = []

    def git(*argv: str, allowed=(0,)) -> bytes:
        result = subprocess.run(["git", *argv], cwd=repo, env=env, capture_output=True, check=False)
        if result.returncode not in allowed:
            raise RuntimeError(f"git {argv!r}: {result.returncode}: {result.stderr.decode()}")
        history_commands.append({"argv": ["git", *argv], "exit_code": result.returncode,
                                 "stdout": result.stdout.decode(), "stderr": result.stderr.decode()})
        return result.stdout

    before = git("status", "--porcelain=v1").decode()
    assert before == "", "source checkout is not clean"
    assert git("rev-parse", "HEAD").decode().strip() == FINAL
    tree = git("rev-parse", "HEAD^{tree}").decode().strip()
    assert tree == "18175756871bf341586fc37be1b17a00ef1dd099"
    raw = args.log.read_bytes()
    assert sha(raw) == LOG_SHA256
    log = raw.decode()
    rows = NAME_RE.findall(log)
    summaries = [list(map(int, row)) for row in SUMMARY_RE.findall(log)]
    names = [name for name, _ in rows]
    counts = Counter(names)
    assert len(rows) == 55 and len(counts) == 55
    assert all(outcome == "ok" for _, outcome in rows)
    assert summaries == [[55, 0, 0, 0, 0]]
    assert re.findall(r"^running (\d+) tests$", log, re.M) == ["55"]

    manifest = json.loads((repo / MANIFEST).read_text())
    groups = {"original_release": 37, "initial_root_material": 6, "quorum_preflight": 9}
    assert manifest["expected_controls"] == {**groups, "complete_release": 52}
    old = manifest["complete_release_tests"]
    assert len(old) == len(set(old)) == 52
    partitions = {key: manifest[key + "_tests"] for key in groups}
    flat = [name for group in partitions.values() for name in group]
    assert all(len(partitions[key]) == count for key, count in groups.items())
    assert len(flat) == len(set(flat)) == 52 and set(flat) == set(old)
    assert set(names) - set(old) == set(EXTRA)
    assert not set(old) - set(names)
    assert not set(old) & set(EXTRA)

    crate_paths = git("ls-tree", "-r", "--name-only", FINAL, "--", CRATE).decode().splitlines()
    assert not any(path.startswith(CRATE + "/" + target + "/") for path in crate_paths
                   for target in ("tests", "benches", "examples", "src/bin"))
    source_roster = []
    per_module = []
    all_rust_test_attributes = 0
    for path in crate_paths:
        if path.endswith(".rs"):
            text = (repo / path).read_text()
            all_rust_test_attributes += len(re.findall(r"^\s*#\[test\]\s*$", text, re.M))
            assert not re.search(r"^\s*#\[ignore(?:\]|\s|=)", text, re.M)
    for relative, module in MODULES.items():
        path = CRATE + "/" + relative
        text = (repo / path).read_text()
        module_rows = []
        for match in TEST_RE.finditer(text):
            attrs = match.group("attrs")
            if "#[test]" not in attrs:
                continue
            conditions = re.findall(r"#\[cfg\(([^\n]*)\)\]", attrs)
            assert conditions in ([], ["unix"])
            attributes = re.findall(r"#\[[^\n]*\]", attrs)
            assert all(attr in ("#[test]", "#[cfg(unix)]") for attr in attributes)
            row = {"name": module + "::" + match.group("name"), "path": path,
                   "line": text.count("\n", 0, match.start("name")) + 1,
                   "attributes": attributes, "platform_condition": conditions or ["all"]}
            module_rows.append(row)
            source_roster.append(row)
        per_module.append({"path": path, "module": module, "test_count": len(module_rows)})
    assert all_rust_test_attributes == len(source_roster) == 55
    assert len({row["name"] for row in source_roster}) == 55
    assert {row["name"] for row in source_roster} == set(names)
    unix = [row["name"] for row in source_roster if row["platform_condition"] == ["unix"]]
    assert unix == ["content_v1::tests::retained_file_reads_exact_bytes_and_refuses_partial_offset"]
    registrations = []
    for relative in ("src/lib.rs", "src/content_v1.rs", "src/pq_release.rs", "src/pq_release/tests.rs"):
        path = CRATE + "/" + relative
        for number, line in enumerate((repo / path).read_text().splitlines(), 1):
            if re.match(r"\s*(pub )?mod \w+", line) or line.startswith("#[path = ") or line == "#[cfg(test)]":
                registrations.append({"path": path, "line": number, "text": line})
    pq_test_text = (repo / CRATE / "src/pq_release/tests.rs").read_text()
    for module in MODULES.values():
        if module.startswith("pq_release::tests::"):
            name = module.rsplit("::", 1)[1]
            assert f'#[path = "{name}.rs"]\nmod {name};' in pq_test_text
    assert "pub mod content_v1;" in (repo / CRATE / "src/lib.rs").read_text()
    assert "pub mod pq_release;" in (repo / CRATE / "src/lib.rs").read_text()
    for relative in ("src/content_v1.rs", "src/pq_release.rs"):
        assert "#[cfg(test)]\nmod tests;" in (repo / CRATE / relative).read_text()

    assert git("merge-base", "--is-ancestor", INTRO, BASE) == b""
    assert git("merge-base", "--is-ancestor", BASE, FINAL) == b""
    assert git("rev-parse", INTRO + "^").decode().strip() == INTRO_PARENT
    extra_path = CRATE + "/src/content_v1/tests.rs"
    assert git("ls-tree", INTRO_PARENT, "--", extra_path) == b""
    introduction = git("show", "--format=fuller", "--no-patch", INTRO).decode()
    path_history = git("log", "--format=%H %P %s", "--follow", FINAL, "--", extra_path).decode()
    assert path_history.splitlines() == [f"{INTRO} {INTRO_PARENT} feat(security): bind CPQ1 authorization to complete content"]
    changed = git("diff", "--name-status", BASE, FINAL, "--", CRATE, RUNNER, MANIFEST).decode()
    assert changed == ""
    crate_trees = {head: git("rev-parse", head + ":" + CRATE).decode().strip() for head in (BASE, FINAL)}
    assert len(set(crate_trees.values())) == 1
    files = []
    for path in sorted([*crate_paths, RUNNER, MANIFEST]):
        data = (repo / path).read_bytes()
        blobs = {head: git("rev-parse", head + ":" + path).decode().strip() for head in (BASE, FINAL)}
        assert len(set(blobs.values())) == 1
        if path == extra_path:
            intro_blob = git("rev-parse", INTRO + ":" + path).decode().strip()
            assert intro_blob == blobs[FINAL]
        record = {"path": path, "bytes": len(data), "sha256": sha(data), "git_blobs": blobs}
        files.append(record)
        destination = out / "source" / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)

    immutable_accepts = (
        len(names) == 52 and len(set(names)) == 52 and set(names) == set(old)
        and sum(row[0] for row in summaries) == 52
        and not any(any(row[1:]) for row in summaries)
    )
    assert immutable_accepts is False
    after = git("status", "--porcelain=v1").decode()
    assert after == before == ""
    report = {
        "schema": "trnm-release-roster-conservation-evidence-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Read-only reconciliation of retained stdout and exact source; not a new native run or qualification decision.",
        "source": {"head": FINAL, "tree": tree, "baseline_head": BASE, "crate_trees": crate_trees,
                   "whole_crate_runner_and_manifest_unchanged": True,
                   "checkout_status_before": before, "checkout_status_after": after},
        "native_stdout": {"original_path": str(args.log.resolve()), "retained_path": "release-bb026697.stdout.log",
                          "bytes": len(raw), "sha256": sha(raw),
                          "libtest_summary_fields": ["passed", "failed", "ignored", "measured", "filtered_out"],
                          "libtest_summaries": summaries, "parsed_result_rows": len(rows),
                          "unique_result_names": len(counts), "duplicate_names": [],
                          "all_observed_outcomes": ["ok"], "passed_names": sorted(names),
                          "process_exit_code_reported_by_parent": 0,
                          "process_exit_code_independently_proven_by_this_stdout": False,
                          "source_and_provider_identity_independently_proven_by_this_stdout": False},
        "original_contract": {"runner": RUNNER, "manifest": MANIFEST, "expected_controls": manifest["expected_controls"],
                              "original_partitions": partitions, "complete_release_tests": old,
                              "immutable_exact_52_predicate_accepts_current_stdout": immutable_accepts,
                              "preserved_rejection": "raw release libtest execution differs from exact 52 passed, zero ignored",
                              "original_32_campaign_pass": False, "original_failure_must_be_retained": True,
                              "runner_edited": False, "manifest_edited": False},
        "conservation": {"equation": "55 = 37 + 6 + 9 + 3 = original 52 + pre-existing content 3",
                         "original_52_present": 52, "extras": EXTRA, "missing_original": [], "unexpected_extras": [],
                         "original_extra_overlap": [], "native_roster_equals_unix_source_roster": True,
                         "set_conservation_pass": True},
        "extra_origin": {"introduction_commit": INTRO, "introduction_parent": INTRO_PARENT,
                         "introduction_commit_text": introduction, "path_history": path_history,
                         "path": extra_path, "path_absent_at_introduction_parent": True,
                         "introduction_is_ancestor_of_baseline": True,
                         "baseline_is_ancestor_of_final": True,
                         "already_present_at_baseline": True,
                         "extra_test_blob_unchanged_since_introduction": True,
                         "not_introduced_by_final_followup": True},
        "source_roster": {"method": "Manual module-registration review plus direct #[test] source enumeration, reconciled against raw native names; no Cargo command.",
                          "platform": "Unix", "unix_only_tests": unix, "per_module": per_module,
                          "all_rust_test_attributes_in_crate": all_rust_test_attributes,
                          "complete_unix_test_rows": sorted(source_roster, key=lambda row: row["name"]),
                          "module_registrations": registrations,
                          "static_enumeration_limit": "This is an enumeration of the reviewed direct test definitions, not a general Rust macro/cfg evaluator; the observed native roster supplies the actual command result."},
        "file_identities": files,
        "qualification": {"overall": "HOLD", "original_32_campaign_pass": False,
                          "no_cargo_rerun": True, "new_native_execution_claimed": False,
                          "whole_chain_pq_qualified": False, "payment_or_wan_qualified": False},
    }
    (out / "release-bb026697.stdout.log").write_bytes(raw)
    (out / "roster-conservation.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    (out / "git-history-readback.json").write_text(json.dumps(history_commands, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"out": str(out), "original": 52, "extra": 3, "native": 55,
                      "source": 55, "already_at_7e": True, "immutable_collector_accepts": False,
                      "original_32_campaign_pass": False}))


if __name__ == "__main__":
    main()
