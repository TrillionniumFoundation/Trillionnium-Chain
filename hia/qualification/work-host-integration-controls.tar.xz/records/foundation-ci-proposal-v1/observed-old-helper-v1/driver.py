from pathlib import Path
import sys,subprocess,hashlib,json,copy,io,tarfile,time,traceback
root=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo");out=root.parent/"foundation-ci-proposal-v1";out.mkdir(mode=0o700);review=out/"observed-old-helper-v1";review.mkdir()
(review/"driver.py").write_text(sys.argv[1]);sys.path.insert(0,str(root))
from hia.tools import qualify_foundation_ci as q
started=time.monotonic_ns();report={"schema":"trnm.foundation-ci-helper-boundary-observation.v1","status":"FAIL","scope":"SYNTHETIC_HELPER_CONTROLS_ONLY","full_public_cli_exploit_executed":False,"native_runtime_executed":False,"observations":[]}
def need(v,m):
 if not v:raise ValueError(m)
def observe(name,action):
 try:r=action();accepted=True;error=None
 except Exception as e:r=None;accepted=False;error=repr(e)
 report["observations"].append({"name":name,"accepted":accepted,"error":error,"result_repr":repr(r)})
 print(json.dumps(report["observations"][-1]),flush=True)
try:
 p=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=root,capture_output=True)
 (review/"preflight.stdout.raw").write_bytes(p.stdout);(review/"preflight.stderr.raw").write_bytes(p.stderr);need(p.returncode==0,"Preflight failed")
 need(subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()=="c3901ff19c26815205d9cdd6975fc24ecc51ae88","Head moved")
 need(subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True)=="","Canonical dirty")
 source={}
 for rel in ("hia/tools/qualify_foundation_ci.py","hia/tests/test_foundation_ci.py"):
  raw=(root/rel).read_bytes();dst=out/"baseline"/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);source[rel]={"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
 report["canonical_source_before"]=source
 expected={"git_head":"a"*40,"run_id":"123","attempt":1}
 parent={"schema":q.SCHEMA,"stage":"continuity-native","status":"PASS","lineage":expected,"native_controls":659,"semantic_cases":572,"original_rust":"NOT_RUN","whole_node_or_commit_authority":False,"physical_power_loss":False}
 (review/"baseline-parent.json").write_text(json.dumps(parent,sort_keys=True,indent=2)+"\n")
 observe("valid-integer-parent",lambda:q.check_parent(parent,expected))
 for name,path,value in (("float-native-count",("native_controls",),659.0),("float-semantic-count",("semantic_cases",),572.0),("boolean-attempt",("lineage","attempt"),True),("float-attempt",("lineage","attempt"),1.0)):
  changed=copy.deepcopy(parent)
  if len(path)==2:changed[path[0]][path[1]]=value
  else:changed[path[0]]=value
  (review/(name+".json")).write_text(json.dumps(changed,sort_keys=True,indent=2)+"\n");observe(name,lambda:q.check_parent(changed,expected))
 for index,token in enumerate(("NaN","Infinity","-Infinity","1e10000","-1e10000")):
  path=review/("nonfinite-"+str(index)+".json");path.write_text('{"value":'+token+'}\n');observe("json-"+token,lambda:q.read(path))
 raw=b"fixture bytes\n";archive=review/"size-fixture.tar.xz";member=tarfile.TarInfo("native/result.raw");member.size=len(raw)
 with tarfile.open(archive,"x:xz") as stream:stream.addfile(member,io.BytesIO(raw))
 entries={"native/result.raw":{"type":"0","bytes":float(len(raw)),"linkname":"","sha256":hashlib.sha256(raw).hexdigest()}}
 (review/"float-size-manifest.json").write_text(json.dumps(entries,sort_keys=True,indent=2)+"\n")
 observe("float-archive-member-size",lambda:q.extract_regular(archive,review/"float-size-unpacked",entries))
 committed=q.identity(root/"PROJECT_ID");committed["bytes"]=float(committed["bytes"])
 observe("float-committed-source-size",lambda:q.check_committed_sources({"PROJECT_ID":committed},root))
 need(all(x["accepted"] for x in report["observations"]),"Expected helper observation changed")
 report["canonical_source_after"]={rel:{"bytes":len((root/rel).read_bytes()),"sha256":hashlib.sha256((root/rel).read_bytes()).hexdigest()} for rel in source}
 need(report["canonical_source_after"]==source,"Canonical source changed")
 report.update(status="OBSERVED_HELPER_TYPE_GAPS",accepted_negative_controls=len(report["observations"])-1,canonical_source_unchanged=True)
except BaseException as e:report["failure"]={"error":repr(e),"traceback":traceback.format_exc()};raise
finally:
 report["elapsed_ns"]=time.monotonic_ns()-started;(review/"report.json").write_text(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+"\n");print(json.dumps({"status":report["status"],"scope":report["scope"],"observations":len(report["observations"])}),flush=True)
