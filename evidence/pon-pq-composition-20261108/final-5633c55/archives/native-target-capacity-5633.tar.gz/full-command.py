import os, stat, json, time, fnmatch
ROOT = '/home/qian-qi/work/chain-pq-composition-663507-20261108/final-native-5633c55/native-target-default'
start=time.time()
out={'schema':'native-target-compile-archive-capacity-full-manifest-v1','root':ROOT,'read_only':True,'content_read_bytes_per_suffix_candidate':4,'elf_objects_excluded':True,'deletion_authorized':False,'native_commands_executed':False}
fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
try:
 for component in ROOT.strip('/').split('/'):
  child=os.open(component,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd)
  os.close(fd);fd=child
 rs=os.fstat(fd);device=rs.st_dev
 out['root_identity']={'device':device,'inode':rs.st_ino,'mode':oct(stat.S_IMODE(rs.st_mode)),'uid':rs.st_uid}
 def free():
  s=os.fstatvfs(fd)
  return {'available_bytes':s.f_bavail*s.f_frsize,'time_unix':time.time()}
 out['free_before']=free()
 counts={'directories':0,'regular_files_observed':0,'symlink_entries_skipped':0,'special_entries_skipped':0,'suffix_candidate_paths':0,'elf_suffix_paths_excluded':0,'so_suffix_paths_excluded':0}
 eligible={};elf={};cross=[]
 for here,dirs,files,dfd in os.fwalk('.',dir_fd=fd,topdown=True,follow_symlinks=False):
  counts['directories']+=1
  kept=[]
  for name in sorted(dirs):
   s=os.stat(name,dir_fd=dfd,follow_symlinks=False)
   if stat.S_ISLNK(s.st_mode):
    counts['symlink_entries_skipped']+=1;continue
   if not stat.S_ISDIR(s.st_mode):
    raise RuntimeError('directory changed kind: '+os.path.join(here,name))
   if s.st_dev!=device:
    cross.append(os.path.join(here,name));continue
   kept.append(name)
  dirs[:]=kept
  for name in sorted(files):
   s=os.stat(name,dir_fd=dfd,follow_symlinks=False)
   if stat.S_ISLNK(s.st_mode):
    counts['symlink_entries_skipped']+=1;continue
   if not stat.S_ISREG(s.st_mode):
    counts['special_entries_skipped']+=1;continue
   counts['regular_files_observed']+=1
   suffix=next((x for x in ('.rlib','.rmeta','.o','.a') if name.endswith(x)),None)
   if suffix is None:continue
   counts['suffix_candidate_paths']+=1
   if fnmatch.fnmatchcase(name,'*.so*'):
    counts['so_suffix_paths_excluded']+=1;continue
   rel=os.path.normpath(os.path.join(here,name))
   pfd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=dfd)
   try:
    before=os.fstat(pfd)
    identity=lambda q:(q.st_dev,q.st_ino,q.st_size,q.st_mtime_ns,q.st_ctime_ns,q.st_mode,q.st_nlink,q.st_blocks)
    if identity(s)!=identity(before):raise RuntimeError('file changed before read: '+rel)
    magic=os.read(pfd,4)
    after=os.fstat(pfd)
    if identity(before)!=identity(after):raise RuntimeError('file changed during read: '+rel)
   finally:os.close(pfd)
   is_elf=magic==b'\x7fELF'
   if is_elf:counts['elf_suffix_paths_excluded']+=1
   group=elf if is_elf else eligible
   key=(s.st_dev,s.st_ino)
   if key not in group:
    group[key]={'path':ROOT+'/'+rel,'paths':[],'suffix':suffix,'allocated_bytes':s.st_blocks*512,'logical_bytes':s.st_size,'mode':oct(stat.S_IMODE(s.st_mode)),'nlink':s.st_nlink,'device':s.st_dev,'inode':s.st_ino,'first_four_bytes_hex':magic.hex()}
   group[key]['paths'].append(ROOT+'/'+rel)
 def totals(group):
  return {'unique_inodes':len(group),'paths':sum(len(r['paths']) for r in group.values()),'allocated_bytes':sum(r['allocated_bytes'] for r in group.values()),'logical_bytes':sum(r['logical_bytes'] for r in group.values()),'inodes_with_links_not_fully_counted_in_this_group':sum(r['nlink']!=len(r['paths']) for r in group.values())}
 out['counts']=counts;out['cross_device_directories_skipped']=cross
 out['eligible_non_elf_compile_archives']=totals(eligible)
 out['excluded_elf_suffix_objects']=totals(elf)
 out['eligible_by_suffix']={s:totals({k:v for k,v in eligible.items() if v['suffix']==s}) for s in ('.rlib','.rmeta','.o','.a')}
 out['top_10_eligible_by_allocated_bytes']=sorted(eligible.values(),key=lambda r:(-r['allocated_bytes'],r['path']))[:10]
 out['eligible_nlink1_compile_archive_files']=[{**r,'path':r['path'][len(ROOT)+1:]} for r in sorted(eligible.values(),key=lambda r:r['path']) if r['nlink']==1 and r['suffix'] in ('.rlib','.rmeta','.a')]
 out['allocated_is_reclaimable_space_guarantee']=False
 out['root_identity_after']={'device':os.fstat(fd).st_dev,'inode':os.fstat(fd).st_ino}
 out['free_after']=free();out['elapsed_seconds']=time.time()-start
 out['status']='READ_ONLY_OBSERVATION_COMPLETE'
except BaseException as e:
 out['status']='FAILED_INCOMPLETE';out['error']=type(e).__name__+': '+str(e);raise
finally:
 os.close(fd)
 print(json.dumps(out,sort_keys=True,indent=2),flush=True)
