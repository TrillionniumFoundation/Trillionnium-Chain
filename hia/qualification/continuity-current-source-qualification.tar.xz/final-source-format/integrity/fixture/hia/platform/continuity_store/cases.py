class Fixture:
    def __init__(self, name): self.name = name
    def corpus(self):
        return {"name":self.name,"base_hex":"544b5653545230310000000000000000",
                "delta_hex":"","detach":False,"root":False,"profile":0,
                "variant":0,"height":0,"cancel":None,"cancel_class":2,"token":0}
def cases(): return [Fixture("fixture-a"), Fixture("fixture-b")]
def capacity_cases(): return iter(())
