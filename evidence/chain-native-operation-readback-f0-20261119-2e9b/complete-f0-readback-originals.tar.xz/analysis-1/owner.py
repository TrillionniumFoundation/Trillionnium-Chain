from pathlib import Path
import json,hashlib,sys
root=Path('/home/qian-qi/work/chain-native-operation-readback-f0-20261119-2e9b');out=root/'analysis-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
current=json.loads((root/'current-cost-profile.json').read_text())['run'];readback=json.loads((root/'f0-independent-readback.json').read_text())
prior=json.loads(Path('/home/qian-qi/work/chain-native-root-delay-f0-20261119-2e9b/current-cost-profile.json').read_text())['run']
def summarize(run):
 rows=[]
 for p in run['phases']:
  rows.append({key:p[key] for key in ['phase','observed_imports','history_client_cpu','history_host_cpu_nested','history_host_calls','host_checkpoint_bucket_totals','native_stage_deltas_nested_not_additive','whole_public_phase_cpu_ns','whole_public_phase_wall_ns','final_actual_cpu_credit_flow','receiver_observer_complete','receiver_records_not_retained','receiver_measurement_failures']})
  rows[-1]['graph_frequency']=[{k:f[k] for k in ['owner','completed_business_blocks','no_account_change_blocks','potential_one_graph_node_visits','potential_is_not_measured_saved_work']} for f in p['actual_graph_frequency']]
  rows[-1]['actual_first_import']=next((h for h in p['history_attempts'] if h['import_observed']),None)
  rows[-1]['controller_resources']=p['original_controller_cgroup_resources']
 return {'run_id':run['run_id'],'head':run['head'],'original_window':run['original_window_confirmations'],'four_second':run['four_second_confirmations'],'phases':rows}
result={'schema':'chain-original-operation-readback-f0-measured-comparison-v1','same_declared_original_inputs':True,'causal_speedup_qualified':False,'distinct_provider_allocations_and_different_completed_work':True,'nested_costs_must_not_be_added':True,'full_physical_cost_closed':False,'current':summarize(current),'prior':summarize(prior),'current_rounds':readback['all_planned_rounds']}
for run in (result['current'],result['prior']):
 for p in run['phases']:
  if p['actual_first_import']:p['actual_first_import']={key:p['actual_first_import'][key] for key in ['history_index','import_error','client_cpu_ns','client_wall_ns','host_checkpoint_calls','host_checkpoint_cpu_ns','host_checkpoint_buckets','actual_packets']}
with (out/'current-bottleneck.json').open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(result,indent=2))
