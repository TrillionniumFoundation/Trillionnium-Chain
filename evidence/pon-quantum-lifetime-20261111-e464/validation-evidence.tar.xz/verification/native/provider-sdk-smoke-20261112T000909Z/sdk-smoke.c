#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/opensslv.h>
#include <stdio.h>
#include <stdlib.h>
#if OPENSSL_VERSION_MAJOR != 3 || OPENSSL_VERSION_MINOR != 5 || OPENSSL_VERSION_PATCH != 9
#error Unexpected OpenSSL SDK headers
#endif
int main(void) {
    const unsigned char message[] = "Trillionnium isolated borrowed SDK smoke v1";
    const unsigned char wrong[] = "Trillionnium isolated borrowed SDK changed message";
    EVP_PKEY_CTX *keygen = NULL;
    EVP_PKEY *key = NULL;
    EVP_MD_CTX *sign = NULL, *verify = NULL, *reject = NULL;
    unsigned char *signature = NULL;
    size_t size = 0;
    int result = 1;
    printf("header=%s\nruntime=%s\n", OPENSSL_VERSION_TEXT, OpenSSL_version(OPENSSL_VERSION));
    if (OpenSSL_version_num() != OPENSSL_VERSION_NUMBER) goto cleanup;
    keygen = EVP_PKEY_CTX_new_from_name(NULL, "ML-DSA-65", NULL);
    if (!keygen || EVP_PKEY_keygen_init(keygen) != 1 || EVP_PKEY_keygen(keygen, &key) != 1) goto cleanup;
    sign = EVP_MD_CTX_new();
    verify = EVP_MD_CTX_new();
    reject = EVP_MD_CTX_new();
    if (!sign || !verify || !reject) goto cleanup;
    if (EVP_DigestSignInit_ex(sign, NULL, NULL, NULL, NULL, key, NULL) != 1) goto cleanup;
    if (EVP_DigestSign(sign, NULL, &size, message, sizeof(message)-1) != 1) goto cleanup;
    signature = malloc(size);
    if (!signature || EVP_DigestSign(sign, signature, &size, message, sizeof(message)-1) != 1) goto cleanup;
    if (EVP_DigestVerifyInit_ex(verify, NULL, NULL, NULL, NULL, key, NULL) != 1) goto cleanup;
    if (EVP_DigestVerify(verify, signature, size, message, sizeof(message)-1) != 1) goto cleanup;
    if (EVP_DigestVerifyInit_ex(reject, NULL, NULL, NULL, NULL, key, NULL) != 1) goto cleanup;
    if (EVP_DigestVerify(reject, signature, size, wrong, sizeof(wrong)-1) != 0) goto cleanup;
    printf("ML-DSA-65 generated, signed, verified, and rejected the changed message; signature_bytes=%zu\n", size);
    result = 0;
cleanup:
    free(signature);
    EVP_MD_CTX_free(sign); EVP_MD_CTX_free(verify); EVP_MD_CTX_free(reject);
    EVP_PKEY_free(key); EVP_PKEY_CTX_free(keygen);
    return result;
}
