#!/usr/bin/env python3
"""Read back retained observations; does not run crypto or re-run source checks."""
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import itertools
import json
from pathlib import Path

OBS = Path(__file__).resolve().parent
RECORDS = OBS.parent
BASE = RECORDS.parent
COMMIT = '53a90ad66b224db9d5095ba3efdadc7319ad8423'
TREE = '6e8ed831672296129672df51f814abba05ea3355'
SOURCES = {
    'candidate_driver.rs': '8db6ed50de36323afa2dd5e5bd6048eb5c91a7ef487378ac7efa75286ce04790',
    'empty_message_evp.c': '483f873a691c346a946ce08c579292ab34f1747a8be3dedf9dfcdeda49104e03',
    'run_candidate_interop.py': 'b830b268875477dcd7eea3a2f938627be6b0fd88c413c36a03959e1947f0de4f',
}
PROVIDER_HASHES = {
    'openssl': '08e4988f44357113a30082b8b37b368c722dc6be82d07a8e3c3585b75e301955',
    'libcrypto': 'fda16ed5c2188f643f8edc1574966efa56f1685a640705eba602c2242c02ce08',
    'source_archive': '603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a',
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def check_identity(row):
    path = Path(row['path'])
    require(identity(path) == row, 'file identity mismatch: ' + str(path))
    return path


def checked_receipt(path):
    row = json.loads(path.read_text())
    require(row['schema'] == 'trnm-pq-native-command-v1'
            and row['status'] == 'command_succeeded' and row['exit_code'] == 0,
            'unsuccessful native receipt: ' + str(path))
    require(row['before'] == row['after'] and row['before']['tested_commit'] == COMMIT
            and row['before']['tested_tree'] == TREE and row['before']['tracked_worktree_verified'] is True,
            'source receipt mismatch: ' + str(path))
    log = path.parent / row['log_file']
    require(log.stat().st_size == row['log_bytes'] and digest(log) == row['log_sha256'],
            'native log integrity mismatch: ' + str(log))
    return row


def review():
    outer = checked_receipt(RECORDS / 'interop.json')
    build = checked_receipt(RECORDS / 'benchmark-build.json')
    manifest = json.loads((OBS / 'manifest.json').read_text())
    require(manifest['status'] == 'FINITE_INTEROPERABILITY_OBSERVED_HOLD'
            and manifest['source_commit'] == COMMIT, 'wrong interop completion/source')
    source = outer['before']
    require(source == build['before'] == manifest['source_before'] == manifest['source_after']
            == manifest['candidate_library_build']['source'], 'source identities differ')
    require(Path(outer['argv'][1]) == BASE / 'interop-preparation/run_candidate_interop.py',
            'wrong outer observer entrypoint')
    for flag, value in [('--commit', COMMIT), ('--library-build-receipt', str(RECORDS / 'benchmark-build.json')),
                        ('--output', str(OBS)), ('--work', str(BASE / 'interop-work'))]:
        require(outer['argv'].count(flag) == 1 and outer['argv'][outer['argv'].index(flag) + 1] == value,
                'wrong outer argument: ' + flag)
    candidate = manifest['candidate_library_build']
    require(check_identity(candidate['receipt']) == RECORDS / 'benchmark-build.json', 'wrong build receipt path')
    require(candidate['argv'] == build['argv'] and build['argv'][0] == 'cargo'
            and '--locked' in build['argv'] and '--message-format=json' in build['argv'],
            'wrong Cargo build provenance')
    for name in ('crypto_library', 'zeroize_library'):
        check_identity(candidate[name])
    for name, checksum in SOURCES.items():
        require(digest(OBS / name) == checksum == digest(BASE / 'interop-preparation' / name),
                'prepared observer source differs: ' + name)
        check_identity(manifest['observation_sources'][name])
    for row in manifest['observers'].values():
        check_identity(row)
    for name in ('rustc', 'cc'):
        check_identity({key: manifest[name][key] for key in ('path', 'bytes', 'sha256')})
    for name, checksum in PROVIDER_HASHES.items():
        check_identity(manifest['provider'][name])
        require(manifest['provider'][name]['sha256'] == checksum, 'provider pin differs: ' + name)
    provider_path = check_identity(manifest['provider']['receipt'])
    require(provider_path.read_bytes() == (OBS / 'provider-preparation-receipt.json').read_bytes(),
            'archived provider receipt differs')
    provider = json.loads(provider_path.read_text())
    require(provider['result'] == 'PREPARED_AND_SMOKE_VERIFIED' and provider['exit_code'] == 0
            and provider['source_digest_verified'] is True and provider['version'] == '3.5.9'
            and provider['cli_sha256'] == PROVIDER_HASHES['openssl'], 'provider preparation not completed')

    commands = [json.loads(line) for line in (OBS / 'commands.jsonl').read_text().splitlines()]
    by_label = {row['label']: row for row in commands}
    require(len(by_label) == len(commands) == manifest['commands_recorded'] == 121, 'command roster differs')
    for row in commands:
        require(not row['timed_out'] and row['launch_error'] is None and row['expectation_met'] is True
                and type(row['exit_code']) is int and row['exit_code'] == row['expected_exit_code'],
                'actual command outcome differs: ' + row['label'])
        data = b''
        for stream in ('stdout', 'stderr'):
            path = check_identity(row[stream])
            require(path == OBS / (row['label'] + '.' + stream + '.txt'), 'unexpected log path')
            data += path.read_bytes()
        require(row['expected_output_token'] is None or row['expected_output_token'].encode() in data,
                'required actual output token missing: ' + row['label'])
    checks = json.loads((OBS / 'completed-checks.json').read_text())
    require(checks == manifest['completed_checks'] and len(checks) == 80, 'completed-check records differ')
    kinds = ('valid', 'wrong-message', 'wrong-key', 'late-invalid-signature', 'nonempty-context')
    expected = set(itertools.product((65, 87), (0, 176, 4096, 65536),
                                    ('rust-to-openssl', 'openssl-to-rust'), kinds))
    observed = {(c['parameter'], c['case_signed_message_bytes'], c['direction'], c['kind']) for c in checks}
    require(observed == expected and len(observed) == 80, 'finite matrix differs or contains duplicates')
    for check in checks:
        suite, length, direction, kind = (check[k] for k in ('parameter', 'case_signed_message_bytes', 'direction', 'kind'))
        interface = ('openssl-evp' if length == 0 else 'openssl-cli') if direction == 'rust-to-openssl' else 'rust-candidate'
        label = f'{direction}-{kind}-{suite}-{length}'
        require(check['label'] == label and check['interface'] == interface
                and check['signature_arithmetic_observed'] is True
                and check['outcome'] == ('accepted' if kind == 'valid' else 'rejected'), 'matrix entry semantics differ')
        row = by_label[label]
        code = 0 if kind == 'valid' else (1 if interface == 'openssl-cli' else 3)
        token = ('Signature Verified Successfully' if kind == 'valid' else 'Signature Verification Failure') \
            if interface == 'openssl-cli' else ('ACCEPT' if kind == 'valid' else 'REJECT_SIGNATURE')
        require(row['exit_code'] == code and row['expected_output_token'] == token, 'mathematical outcome classification differs')
    limits = manifest['cli_empty_message_limitations']
    require(len(limits) == 4 and {(r['parameter'], r['operation']) for r in limits}
            == set(itertools.product((65, 87), ('sign', 'verify'))), 'CLI limitation set differs')
    for row in limits:
        command = by_label[row['label']]
        require(row['label'] == f"cli-empty-{row['operation']}-{row['parameter']}"
                and row['counted_as_cryptographic_rejection'] is False
                and row['outcome'] == 'frontend_refused_before_signature_operation'
                and command['exit_code'] == 1
                and command['expected_output_token'] == 'Could not allocate 0 bytes for oneshot sign/verify buffer',
                'CLI frontend limitation was misclassified')

    fixtures_path = check_identity(manifest['public_fixtures'])
    require(fixtures_path == OBS / 'public-fixtures.json', 'wrong public fixture archive')
    fixtures = json.loads(fixtures_path.read_text())
    require(len({row['name'] for row in fixtures}) == len(fixtures), 'duplicate public fixture name')
    for row in fixtures:
        path = Path(row['name'])
        require(path.name == str(path) and path.suffix in ('.bin', '.der', '.raw', '.sig'), 'unexpected fixture type')
        raw = base64.b64decode(row['base64'], validate=True)
        require(len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'], 'public fixture digest differs')
        require((BASE / 'interop-work/public-fixtures' / path).read_bytes() == raw, 'retained public fixture differs')
    for length in (0, 176, 4096, 65536):
        row = next(r for r in fixtures if r['name'] == f'message-{length}.bin')
        require(base64.b64decode(row['base64']) == bytes((i * 29 + 17) % 256 for i in range(length)), 'public message differs')
    require(manifest['private_test_keys_archived'] is False and manifest['private_test_key_directory_removed'] is True
            and not list((BASE / 'interop-work').glob('private-test-keys-*'))
            and not list((BASE / 'interop-work').rglob('*.pem')), 'temporary private key remains')
    require(all(manifest[name] is False for name in ('whole_chain_quantum_security_qualified', 'production_activation',
            'fips_conformance_certified', 'fips_validated_module_claim', 'side_channel_review_performed')), 'scope widened')
    require(manifest['valid_checks_observed'] == 16 and manifest['invalid_signature_checks_observed'] == 64,
            'summary counts differ')
    return {'source': source, 'outer_receipt': identity(RECORDS / 'interop.json'),
            'manifest': identity(OBS / 'manifest.json'), 'commands': identity(OBS / 'commands.jsonl'),
            'checks': identity(OBS / 'completed-checks.json'), 'public_fixtures': identity(fixtures_path),
            'command_count': len(commands), 'command_exit_counts': dict(Counter(str(r['exit_code']) for r in commands)),
            'valid_checks': 16, 'invalid_signature_checks': 64, 'cli_frontend_limitations': 4,
            'unexpected_outcomes': [], 'fixture_count': len(fixtures),
            'matrix_by_parameter_direction_kind': dict(Counter(f"{c['parameter']}:{c['direction']}:{c['kind']}" for c in checks)),
            'provider': manifest['provider'], 'observers': manifest['observers'],
            'crypto_library': candidate['crypto_library'], 'zeroize_library': candidate['zeroize_library'],
            'native_or_crypto_reexecution_performed': False, 'new_full_source_verifier_run': False,
            'existing_exact_source_receipts_matched': True, 'private_key_directory_absent': True}


if __name__ == '__main__':
    output = OBS / 'independent-readback.json'
    require(not output.exists(), 'preserve previous readback observation')
    result = {'schema': 'trnm-candidate-interop-readback-v1', 'reader': identity(Path(__file__).resolve()),
              'started_utc': datetime.now(timezone.utc).isoformat(), 'whole_chain_pq_qualified': False}
    try:
        result.update(review(), status='OBSERVATIONS_CONSISTENT_HOLD')
    except BaseException as error:
        result.update(status='READBACK_FAILED', failure={'type': type(error).__name__, 'message': str(error)})
        raise
    finally:
        result['finished_utc'] = datetime.now(timezone.utc).isoformat()
        with output.open('x') as stream:
            json.dump(result, stream, sort_keys=True, indent=2)
            stream.write('\n')
    print(json.dumps({key: result[key] for key in ('status', 'command_count', 'command_exit_counts',
          'valid_checks', 'invalid_signature_checks', 'cli_frontend_limitations', 'fixture_count', 'unexpected_outcomes')}, sort_keys=True))
