"""Non-dispatch queue classification probes for signed terminal disputes."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--source-dir', type=Path, required=True)
p.add_argument('--dependency-dir', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
sys.path.insert(0, str(a.dependency_dir))
sys.path.insert(0, str(a.source_dir))
from test_demand_evidence import DemandTests, ident
from demand_evidence import validate_contract

results = []
for verdict in ('refund', 'unresolved', 'pay-service'):
    f = DemandTests()
    f.setUp()
    b = f.bundle()
    for key in ('delivery', 'acceptance', 'evaluation', 'availability', 'adoption'):
        b[key] = None
    b['payments'] = []
    sources = {account: dict(source, state='locked') for account, source in
               b['funding']['body']['payload']['sources'].items()}
    f.resign(b, 'funding', observed_at=20, valid_until=40, sources=sources)
    b['dispute'] = f.sign('dispute', dict(policy=b['contract']['dispute_policy'],
        output=None, verdict=verdict, resolved_at=25, evidence=ident('case')),
        validate_contract(b['contract']), 'dispute')
    before = f.book.snapshot()
    try:
        result = f.observe(b, height=30)
        observation = dict(accepted=True, dispute=result['dispute'])
    except Exception as error:
        observation = dict(accepted=False, code=str(error),
                           snapshot_unchanged=before == f.book.snapshot())
    queue = f.book.queue_observation(height=30, expected_anchor=f.anchor)
    results.append(dict(verdict=verdict, observation=observation, queue=queue))

report = dict(source={name: hashlib.sha256((a.source_dir / name).read_bytes()).hexdigest()
                     for name in ('demand_evidence.py', 'test_demand_evidence.py')},
              results=results, native_executions=0)
a.output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps(report, indent=2, sort_keys=True))
