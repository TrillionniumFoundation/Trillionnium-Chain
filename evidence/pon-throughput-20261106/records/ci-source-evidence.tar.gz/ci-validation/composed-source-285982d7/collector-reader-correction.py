#!/usr/bin/env python3
"""Read retained unittest stderr; never reruns a command or changes raw receipts."""
from __future__ import annotations
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil

OUT=Path('/workspace/scratch/1eed767ad985/ci-validation/composed-source-285982d7')
LABELS=['ci-contract','source-integrity-negatives','pq-record-command-controls','pq-corpus-controls','pq-claim-controls','pq-authority-controls','project-boundary-controls','repository-mutants']
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    with path.open('x') as stream: json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')

original_manifest=OUT/'artifacts.sha256'
manifest_sha=sha(original_manifest)
verified=[]
for line in original_manifest.read_text().splitlines():
    expected,name=line.split('  ',1)
    p=OUT/name
    assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(OUT.resolve()),name
    assert sha(p)==expected,name
    verified.append(name)
original_path=OUT/'summary.json'
original_sha=sha(original_path)
original=json.loads(original_path.read_text())
assert original['tested_commit']=='285982d78a4f62a064841cb0f106d18c865e19c5'
assert original['tested_tree']=='ce074eb1857a92c9b47ea317b841777fcfc63c04'
corrected=copy.deepcopy(original)
corrections=[]
observed=0
for label in LABELS:
    entry=corrected['checks'][label]
    result=entry['execution']
    stderr=Path(result['stderr_path']);stdout=Path(result['stdout_path'])
    for p in [stderr,stdout]:
        assert p.resolve().is_relative_to(OUT.resolve()) and p.relative_to(OUT).as_posix() in verified
    text=stderr.read_text(errors='replace')
    matches=list(re.finditer(r'^Ran (\d+) tests? in ([0-9.]+)s$',text,re.M))
    assert len(matches)==1,(label,'non-unique summary')
    match=matches[0];terminal=text[match.end():].strip();count=int(match[1])
    assert count==entry['tests'] and count>0,(label,'changed count')
    assert result['capture_errors']=={} and result['spawn_error'] is None,label
    passed=result['native_exit']==0 and result['log_exit']==0 and terminal=='OK'
    if entry['passed']!=passed:
        corrections.append({'label':label,'original_reader_passed':entry['passed'],'corrected_passed':passed,'native_exit':result['native_exit'],'capture_exit':result['log_exit'],'actual_tests':count,'terminal_stderr_summary':terminal,'stderr_sha256':sha(stderr),'stdout_sha256':sha(stdout)})
    entry['passed']=passed
    entry['terminal_summary']=terminal
    entry['unittest_summary_stream']='stderr (original unittest framework stream); stdout contains intentionally failing negative fixtures'
    entry['tests']=count
    entry['test_elapsed_seconds']=float(match[2])
    observed+=count
assert original['unittest_cases_observed']==observed
assert {x['label'] for x in corrections}=={'source-integrity-negatives','pq-record-command-controls'},corrections
assert all(x['corrected_passed'] is True and x['original_reader_passed'] is False for x in corrections)
corrected['unittest_cases_observed']=observed
corrected['all_checks_passed']=all(x['passed'] for x in corrected['checks'].values())
corrected['result']='PASS' if (corrected['all_checks_passed'] and corrected['source_before_equals_after'] and corrected.get('lockfiles_unchanged') and corrected['prior_summaries_unchanged'] and corrected['capture_helper_unchanged'] and 'runner_error' not in corrected) else 'FAIL'
correction={
 'schema':'trnm-static-collector-reader-correction-v1',
 'reason':'The original collector parsed a combined stdout/stderr tail. Negative fixtures write expected FAIL/command_failed records on stdout, sometimes after unittest has emitted its complete terminal OK on stderr. The correction reads that original framework stream and retains all actual exit/capture/source checks.',
 'original_collector_terminal_exit':1,
 'original_summary_path':'summary.json','original_summary_sha256':original_sha,
 'original_result':original['result'],'original_artifact_manifest_sha256':manifest_sha,
 'original_artifacts_verified':len(verified),'raw_files_changed':False,
 'commands_reexecuted':False,'tests_reexecuted':False,
 'corrections':corrections,'generated_utc':datetime.now(timezone.utc).isoformat(),
}
corrected['collector_reader_correction']=correction
assert sha(original_manifest)==manifest_sha and sha(original_path)==original_sha
shutil.copyfile(__file__,OUT/'collector-reader-correction.py')
write(OUT/'collector-reader-correction.json',correction)
write(OUT/'summary-corrected.json',corrected)
paths=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name!='artifacts-corrected.sha256')
with (OUT/'artifacts-corrected.sha256').open('x') as stream:
    for p in paths: stream.write(sha(p)+'  '+p.relative_to(OUT).as_posix()+'\n')
print(json.dumps({'result':corrected['result'],'actual_cases':observed,'original_collector_result_retained':original['result'],'corrected_labels':[x['label'] for x in corrections],'source_before_equals_after':corrected['source_before_equals_after'],'artifact_files':len(paths),'summary':str(OUT/'summary-corrected.json')}))
