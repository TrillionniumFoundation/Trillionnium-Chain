#!/usr/bin/env python3
"""Package verified hosted evidence; keep original ZIPs in the full variant."""
from pathlib import Path
import hashlib
import io
import json
import lzma
import tarfile

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/"report"
FILES=sorted(p for p in ROOT.rglob("*") if p.is_file())
def digest(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()
results=[]
for variant,name in [
    ("full-with-original-zips","hosted-w1-four-lane-41628135456-evidence.tar.xz"),
    ("all-artifact-payloads","hosted-w1-four-lane-41628135456-payloads.tar.xz"),
]:
    selected=[p for p in FILES if variant=="full-with-original-zips" or p.relative_to(ROOT).parts[0]!="artifacts"]
    rows=[{"path":str(p.relative_to(ROOT)),"bytes":p.stat().st_size,"sha256":digest(p)} for p in selected]
    manifest={"schema":"trnm-hosted-w1-bundle-manifest-v1","variant":variant,
        "run_id":41628135456,"run_attempt":1,"complete_artifact_payloads":4,
        "artifact_payload_entries":328,"original_zip_containers_included":variant=="full-with-original-zips",
        "whole_chain_quantum_security_qualified":False,"files":rows}
    data=(json.dumps(manifest,indent=2)+"\n").encode()
    archive=OUT/name
    with archive.open("xb") as sink,lzma.LZMAFile(sink,"w",preset=6) as compressed,tarfile.open(fileobj=compressed,mode="w|",format=tarfile.PAX_FORMAT) as t:
        for p,row in zip(selected,rows):
            info=tarfile.TarInfo(row["path"])
            info.size=row["bytes"];info.mode=0o644;info.mtime=0
            with p.open("rb") as source:
                t.addfile(info,source)
        info=tarfile.TarInfo("archive-manifest.json")
        info.size=len(data);info.mode=0o644;info.mtime=0
        t.addfile(info,io.BytesIO(data))
    with tarfile.open(archive,"r:xz") as t:
        members=t.getmembers()
        assert len(members)==len(rows)+1
        recorded=json.load(t.extractfile("archive-manifest.json"))
        assert recorded==manifest
        for row in rows:
            b=t.extractfile(row["path"]).read()
            assert len(b)==row["bytes"] and hashlib.sha256(b).hexdigest()==row["sha256"],row["path"]
    result={"path":str(archive),"filename":name,"variant":variant,"bytes":archive.stat().st_size,
        "sha256":digest(archive),"payload_files":len(rows),"archive_entries":len(rows)+1,
        "artifact_payload_entries":328,"all_payload_hashes_readback_verified":True}
    results.append(result)
    print(json.dumps(result),flush=True)
(OUT/"hosted-w1-package-summary.json").write_text(json.dumps(results,indent=2)+"\n")
