#!/usr/bin/env python3
"""Package already retrieved CI observations; never execute repo tests or mutate it."""
import collections
import datetime
import gzip
import hashlib
import io
import json
import os
import pathlib
import re
import subprocess
import tarfile

ROOT = pathlib.Path(__file__).resolve().parent
REPO = ROOT.parent / 'chain-daa'
STAGE = ROOT.parent / 'daa-evidence-stage' / 'ci'
SOURCE = 'd23488c5f9b4a6696c3799b12f14b8af0a1b81fc'
BASE = '249f772cc2a2ace5e363fd5fbfec4241a26f4d4d'


def read(name):
    return json.loads((ROOT / name).read_text())


def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
    return subprocess.check_output(['git', '-C', str(REPO), *args], env=env)


def log(job):
    return (ROOT / f'job-{job}-logs.log').read_text().splitlines()


def matching(job, needles):
    return [{'line': n, 'text': line} for n, line in enumerate(log(job), 1)
            if any(needle in line for needle in needles)]


def example_result(job, example):
    lines = log(job)
    starts = [i for i, line in enumerate(lines)
              if f'Running unittests examples/{example}.rs' in line]
    assert len(starts) == 1, (job, example, starts)
    for i in range(starts[0] + 1, len(lines)):
        match = re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', lines[i])
        if match:
            return {'line': i + 1, 'text': lines[i], 'passed': int(match[1]),
                    'failed': int(match[2]), 'ignored': int(match[3])}
    raise AssertionError((job, example, 'missing result'))


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
additional_paths = [
    '.github/workflows/pon-w1-work-security.yml',
    '.github/workflows/codeql-analysis-export.yml',
    'scripts/export_codeql_analysis.py',
    'scripts/ci/run_w1_fresh_service_v1.py',
    'scripts/ci/test_w1_factorial_native_gate.py',
    'trillionnium/crates/trnm-pon-node/examples/pon_w1_legal_strategy_v1.rs',
    'trillionnium/crates/trnm-pon-node/examples/pon_w1_legal_strategy_v3.rs',
    'trillionnium/crates/trnm-pon-node/examples/support/w1_cost_producers.rs',
    'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero.rs',
    'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero/fresh_challenge.rs',
]
identities = []
for path in additional_paths:
    row = {'path': path}
    for name, commit in [('base', BASE), ('head', SOURCE)]:
        raw = git('show', f'{commit}:{path}')
        row[name] = {'bytes': len(raw), 'sha256': digest(raw)}
    row['base_equals_head'] = row['base'] == row['head']
    identities.append(row)
write(ROOT / 'additional-source-identity-comparison.json', {
    'scope': 'Read-only git show at explicit commits; no checkout or test execution.',
    'source_head': SOURCE, 'base_head': BASE, 'files': identities,
})

run_ids = [43126392924, 43126392928, 43126393033, 43126392872, 43126392847]
jobs_by_run = {run: read(f'run-{run}-jobs.retrieval.json')['value']['jobs'] for run in run_ids}
source_failed_jobs = [job for run in run_ids for job in jobs_by_run[run] if job['conclusion'] == 'failure']
assert len(source_failed_jobs) == 20
all_job_logs = sorted(ROOT.glob('job-*-logs.log'))
assert len(all_job_logs) == 28
details = []
for job in source_failed_jobs:
    jid = job['id']
    row = {'job_id': jid, 'run_id': job['run_id'], 'name': job['name'],
           'url': f'https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/{job["run_id"]}/job/{jid}',
           'log': f'job-{jid}-logs.log',
           'failed_steps': [step for step in job['steps'] if step['conclusion'] == 'failure']}
    if job['run_id'] == 43126392924:
        row['original_error_lines'] = matching(jid, ['LedgerError: source identity mismatch:',
            'QROM closure controls refused: required named completion differs: started_ids'])
    elif job['run_id'] == 43126392928:
        row['original_error_lines'] = matching(jid, ['AuditError: input exceeds bound:',
            'AssertionError: "pinned input drift" does not match'])
    elif job['run_id'] == 43126392847:
        row['original_error_lines'] = matching(jid, ['CodeQL analysis export failed:'])
    elif job['run_id'] == 43126392872:
        if 'factorial' in job['name']:
            row['original_error_lines'] = matching(jid, ['factorial-example-tests: exact native controls did not execute'])
            row['fixed_gate_expected_passed'] = 6
            row['actual_example_result'] = example_result(jid, 'pon_w1_legal_strategy_v3')
            assert row['actual_example_result']['passed'] == 11
        elif 'complete legal' in job['name']:
            row['original_error_lines'] = matching(jid, ['four retained legal, two versioned legal and two shared material controls did not execute'])
            row['fixed_gate_expected_passed'] = 8
            row['actual_example_result'] = example_result(jid, 'pon_w1_legal_strategy_v1')
            assert row['actual_example_result']['passed'] == 13
        else:
            for n, line in enumerate(log(jid), 1):
                if 'Z {' not in line:
                    continue
                try:
                    value = json.loads(line.split('Z ', 1)[1])
                except ValueError:
                    continue
                if isinstance(value, dict) and value.get('schema') == 'trnm-ci-original-public-host-controller-v2':
                    row['controller_result'] = {'line': n, 'systemd_run_exit': value['systemd_run_exit'],
                        'passed': value['passed'], 'failure': value['failure'],
                        'final_host_errors': value['final_host_errors'],
                        'build_exit_code': value['preparation']['process']['exit_code']}
                    break
            assert row['controller_result']['systemd_run_exit'] == 1
    details.append(row)
write(ROOT / 'source-failed-jobs-derived.json', {
    'scope': 'Failed steps from GitHub job metadata; original lines and exact example result counts from complete decoded logs. This is a derived index, not a new execution.',
    'jobs': details,
})

base_cases = [
    (42963844385, 130336378979, ['LedgerError: source identity mismatch:']),
    (42963844495, 130336379331, ['AuditError: input exceeds bound:']),
    (42963844077, 130336377800, ['factorial-example-tests: exact native controls did not execute']),
    (42963844077, 130336378155, ['four retained legal, two versioned legal and two shared material controls did not execute']),
    (42963844077, 130336378248, ['four retained legal, two versioned legal and two shared material controls did not execute']),
    (42963844246, 130336378384, ['CodeQL analysis export failed:']),
]
base_comparators = []
for run, jid, needles in base_cases:
    row = {'run_id': run, 'job_id': jid, 'log': f'job-{jid}-logs.log',
           'error_lines': matching(jid, needles)}
    assert row['error_lines']
    if jid == 130336377800:
        row['actual_example_result'] = example_result(jid, 'pon_w1_legal_strategy_v3')
    if jid in (130336378155, 130336378248):
        row['actual_example_result'] = example_result(jid, 'pon_w1_legal_strategy_v1')
    base_comparators.append(row)
write(ROOT / 'base-error-comparators-derived.json', {'base_head': BASE, 'comparators': base_comparators})

snapshot = read('source-runs-followup.retrieval.json')
counts = dict(collections.Counter(r['conclusion'] or r['status'] for r in snapshot['value']['workflow_runs']))
assert counts == {'success': 13, 'failure': 5, 'in_progress': 2, 'queued': 1}
native_execution = read('native-campaign-execution-derived.json')['jobs']
native = native_execution['130879440817']['result']
native_base = native_execution['130336378537']['result']
assert native['binary']['sha256_before'] == native_base['binary']['sha256_before']
fresh = read('source-fresh-selected/fresh-service/manifest.json')
work_jobs = jobs_by_run[43126392872]
summary = {
    'schema': 'pon-d23488-ci-readonly-diagnosis-v1',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'repo': 'TrillionniumFoundation/Trillionnium-Chain', 'pr': 920,
    'source_commit': SOURCE, 'source_tree': '72b106b4458299c37da146b0218b8f5276195b6d',
    'comparison_base_commit': BASE,
    'snapshot': {'observed_utc': snapshot['observed_end_utc'], 'counts': counts,
        'returned_runs': len(snapshot['value']['workflow_runs']),
        'scope': 'GitHub connector first page of PR-triggered workflows for this exact commit; observation at the recorded time, not an all-branch or permanent final result.',
        'retrieval': 'source-runs-followup.retrieval.json'},
    'findings': [
        {'workflow': 'PoN W1 QROM closure observations', 'run_id': 43126392924,
         'source_jobs': [130879440375, 130879440928],
         'failed_steps': [6, 7, 9],
         'original_error': 'source identity mismatch: trillionnium/crates/trnm-pon-node/src/store.rs',
         'aggregate_error': 'required named completion differs: started_ids',
         'expected_sha256': 'b712a86b9997a098df5e8257f309d22445b2c749c9aa474457e958a0f65f5153',
         'actual_sha256_at_base_and_head': '108621f304255841ea2e1a7353858c3f0f5d8cb70a235f6a4aef6d57ebe0c554',
         'base_run_id': 42963844385, 'base_head_job_id': 130336378979,
         'attribution': 'The specific fixed-source identity refusal is inherited: same error in exact-base log, and byte-identical checker, input and workflow at base/head. This does not qualify the QROM model.'},
        {'workflow': 'PoN W1 QROM implementation observations', 'run_id': 43126392928,
         'source_jobs': [130879439988, 130879439577], 'failed_steps': [6, 7, 12],
         'original_error': 'input exceeds bound: formal/pon-nakamoto-v1/w1_v2_verifier/src/main.rs',
         'pinned_bytes': 9233, 'actual_bytes_at_base_and_head': 11172,
         'base_run_id': 42963844495, 'base_head_job_id': 130336379331,
         'attribution': 'The specific pinned-input bound refusal is inherited: same error in exact-base log, and byte-identical checker, contract, input and workflow. Two negative tests also fail because this earlier refusal differs from their expected pinned-input-drift message.'},
        {'workflow': 'PoN original native campaign', 'run_id': 43126393033,
         'source_jobs': [130879440817], 'failed_step': 7, 'build_returncode': 0,
         'attempt_returncodes': [101, 101, 101], 'original_criteria_met': [False, False, False],
         'original_panic': 'finite experiment criteria failed',
         'panic_source': 'trillionnium/crates/trnm-pon-node/tests/public_v3_multiprocess.rs:1765',
         'observed_report_pattern': 'All three reports have economics_complete=true and finite_experiment_criteria_met=false. All nine phases have finite_phase_criteria_met=false and all_signed_rounds_confirmed_in_window=false. Each baseline confirms rounds 0 and 1 but not round 2 inside the window. All six attack phases record PUBLIC_REQUEST_DEADLINE and no observed genuine budget depletion.',
         'base_run_id': 42963844218, 'base_head_job_id': 130336378537,
         'base_attempt_returncodes': [101, 101, 101],
         'identical_observed_base_head_binary_sha256': native['binary']['sha256_before'],
         'attribution': 'The previous base campaign also fails. Even with identical observed binary bytes, the exact dynamic failure cause and its causal relation to this patch are not established by this read-only comparison.',
         'scope': 'Same-host finite controlled loopback; no WAN, independent-operator, profitable quantum attack, cryptographic hardness or consensus qualification.'},
        {'workflow': 'PoN W1 work security observations', 'run_id': 43126392872,
         'job_counts': dict(collections.Counter(j['conclusion'] for j in work_jobs)),
         'legal_v1_v2': {'failed_jobs': 8, 'failed_step': 6, 'gate_expected_passed': 8,
            'actual_example_passed': 13, 'original_error': 'four retained legal, two versioned legal and two shared material controls did not execute',
            'base_head_job_ids': [130336378248, 130336378155]},
         'factorial_v3': {'failed_jobs': 4, 'failed_step': 8, 'gate_expected_passed': 6,
            'actual_example_passed': 11, 'original_error': 'factorial-example-tests: exact native controls did not execute',
            'base_head_job_id': 130336377800},
         'count_gate_attribution': 'The specific count-consistency refusals are inherited: exact-base head logs show the same actual counts and refusal text; workflow, example sources and shared producer source compared here are byte-identical. No gate was changed or bypassed.',
         'fresh_service': {'failed_jobs': 2, 'failed_step': 7, 'controller_exit': 1,
            'source_head_artifact_id': 13902843454,
            'head_original_native_exit': fresh['runs'][0]['process']['process_exit_code'],
            'head_original_reader_failure': fresh['runs'][0]['failure'],
            'head_fresh_native_exit': fresh['runs'][1]['process']['process_exit_code'],
            'head_fresh_reader_failure': fresh['runs'][1]['failure'],
            'head_original_panic': 'fresh challenges failed the original four-second/six-depth business target; retain report.json, no post-window success credit',
            'head_last_history_errors': [r['failure_diagnostic']['last_history_replay']['replay_error'] for r in fresh['runs']],
            'limit': 'Detailed inner reports/logs extracted only for source head. Both head/merge controller jobs fail; no claim that merge inner observations were independently read. Exact-base head controller also fails, but detailed dynamic causal attribution remains undetermined.'}},
        {'workflow': 'CodeQL exact-source analysis export', 'run_id': 43126392847,
         'source_jobs': [130879439040], 'failed_step': 5,
         'original_error': 'CodeQL analysis export failed: CodeQL analyses/checks did not complete and stabilize before the deadline',
         'base_run_id': 42963844246, 'base_head_job_id': 130336378384,
         'attribution': 'The same exporter wait-deadline error was observed on the exact base. This is an incomplete export observation, not evidence that a particular vulnerability was reported, and does not establish the cause of unavailable or unstable analyses.'},
    ],
    'raw_evidence': {'archive': 'source-head-diagnosis.tar.gz',
        'complete_connector_decoded_job_logs': 28,
        'source_failed_job_logs': 20, 'selected_base_head_job_logs': 8,
        'log_scope': 'All retrieved decoded log contents are retained verbatim as UTF-8; not described as original HTTP/gzip response bytes. Archive MANIFEST.json binds each retained file.',
        'details': 'source-failed-jobs-derived.json', 'base_comparators': 'base-error-comparators-derived.json',
        'source_comparisons': ['source-identity-comparison.json', 'additional-source-identity-comparison.json'],
        'native_reports': 'native-source-criteria-summary.json',
        'original_native_stderr': 'source-native-selected/run-{1,2,3}.stderr.log',
        'original_fresh_manifest': 'source-fresh-selected/fresh-service/manifest.json',
        'large_downloaded_archives_excluded_from_diagnosis_archive': [
            {'local_file': str(ROOT / 'native-campaign-d23488c5-43126393033.zip'), 'artifact_id': 13903871465,
             'bytes': 79835140, 'sha256': 'be2dbc572a76a36c48b7482adae264d50a6ddf1f7a31e776b8b303a80645b0e1'},
            {'local_file': str(ROOT / 'w1-fresh-service-head-d23488c5-43126392872.zip'), 'artifact_id': 13902843454,
             'bytes': 5904062, 'sha256': '967a26a5ffd98b5c176dcf62d3e98701b29bf323ac829782ff0c637c6498c582'},
        ]},
    'actions': {'github_read_only': True, 'local_diagnostic_packaging_only': True,
        'workflow_reruns': 0, 'tests_executed': 0, 'tracked_source_edits': 0,
        'pin_or_gate_changes': 0, 'git_writes': 0, 'github_comments': 0, 'hepta_remote_calls': 0},
    'qualification': {'all_ci_green': False, 'production_or_consensus_qualification': False,
        'note': 'Observed failure attribution does not waive CI gates or create a security proof.'},
}
assert summary['findings'][3]['job_counts'] == {'failure': 14, 'success': 8, 'skipped': 1}
write(ROOT / 'ci-failure-attribution.json', summary)

included = set(ROOT.glob('*.retrieval.json')) | set(all_job_logs)
for name in ('build_diagnosis.py', 'ci-failure-attribution.json',
             'source-identity-comparison.json', 'additional-source-identity-comparison.json',
             'source-failed-jobs-derived.json', 'base-error-comparators-derived.json',
             'native-campaign-execution-derived.json', 'native-source-criteria-summary.json',
             'native-artifact-download.json', 'fresh-artifact-download.json'):
    included.add(ROOT / name)
for dirname in ('source-native-selected', 'source-fresh-selected'):
    included.update(q for q in (ROOT / dirname).rglob('*') if q.is_file())
included = sorted(included, key=lambda q: q.relative_to(ROOT).as_posix())
manifest = {'schema': 'readonly-ci-diagnosis-file-manifest-v1',
    'scope': 'All regular files retained in this diagnosis tar excluding MANIFEST.json itself. Large upstream ZIPs remain local and are referenced by verified GitHub artifact identity.',
    'files': [{'path': q.relative_to(ROOT).as_posix(), 'bytes': q.stat().st_size,
               'sha256': digest(q.read_bytes())} for q in included]}
write(ROOT / 'MANIFEST.json', manifest)
included.append(ROOT / 'MANIFEST.json')
STAGE.mkdir(exist_ok=True)
archive = STAGE / 'source-head-diagnosis.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for q in sorted(included, key=lambda x: x.relative_to(ROOT).as_posix()):
            data = q.read_bytes()
            entry = tarfile.TarInfo(q.relative_to(ROOT).as_posix())
            entry.size = len(data); entry.mode = 0o644; entry.uid = 0; entry.gid = 0
            entry.mtime = 0; entry.uname = ''; entry.gname = ''
            tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    members = {m.name: m for m in tar.getmembers()}
    assert len(members) == len(included)
    assert all(m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute()
               and '..' not in pathlib.PurePosixPath(m.name).parts for m in members.values())
    for item in manifest['files']:
        data = tar.extractfile(item['path']).read()
        assert len(data) == item['bytes'] and digest(data) == item['sha256']
archive_identity = {'path': archive.name, 'bytes': archive.stat().st_size,
                    'sha256': digest(archive.read_bytes()), 'files': len(included),
                    'manifest_sha256': digest((ROOT / 'MANIFEST.json').read_bytes())}
write(STAGE / 'source-head-diagnosis-summary.json', {**summary, 'archive_identity': archive_identity})
write(ROOT / 'archive-identity.json', archive_identity)
print(json.dumps({'archive': str(archive), **archive_identity,
                  'summary': str(STAGE / 'source-head-diagnosis-summary.json'),
                  'summary_sha256': digest((STAGE / 'source-head-diagnosis-summary.json').read_bytes()),
                  'source_current_head': git('rev-parse', 'HEAD').decode().strip(),
                  'compared_additional_paths': len(identities),
                  'all_additional_paths_unchanged': all(v['base_equals_head'] for v in identities)}))
