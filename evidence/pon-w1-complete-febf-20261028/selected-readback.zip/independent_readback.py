#!/usr/bin/env python3
"""Pure exact-artifact readback; never executes a prover or native verifier."""
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path('/workspace/scratch/bb9b841c1d43')
HERE = ROOT / 'w1-observation/febf-run-40611562747'
OUT = HERE / 'assembly-selected'
SDK = ROOT / 'w1-integration-a54/trillionnium/crates/trnm-crypto-primitives/guests/w1-risc0'
SOURCE = 'febf622c7e4e919ad2ee4e0864230ab572f5d5b4'
TREE = 'f936a01b1391242c2014b162ea2d77ef18769e67'
sys.path.insert(0, str(SDK))
import segment_frozen_v2 as source
import segment_continue_v2 as continuation
from segment_witness import claims_record
from continuation_validate import validate
from observations import read_single_result
from soundness_report import Cursor, dimensions

def read(path):
    return source.read(path, 4 * 1024 * 1024)

def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def expected(item):
    return {k: item[k] for k in ('bytes', 'sha256')}

def native_gate(directory, start, end, helper):
    name = f'bind-frozen-{start}-{end}'
    terminal = read(directory / 'steps' / (name + '.terminal.json'))
    continuation.check_stage_terminal(terminal, SOURCE, 300)
    row = read_single_result(directory / 'steps' / (name + '.stdout.log'),
                             'pon-w1-frozen-receipts-verified-v2')
    assert row['indexes'] == list(range(start, end)) and row['helper_sha256'] == helper
    assert row['real_segment_stark_verified'] is True and row['frozen_claim_bound'] is True
    assert row['dev_mode'] is False and row['additional_pow'] is False
    assert row['whole_w1_proof_verified'] is False
    return {'native': row, 'terminal': terminal}

def source_snapshot(directory):
    a, b = read(directory / 'source-before.json'), read(directory / 'source-after.json')
    assert a == b and a['tested_commit'] == a['candidate'] == SOURCE
    assert a['tested_tree'] == TREE and a['tracked_worktree_verified'] is True
    assert a['tests_executed_by_identity_check'] is False
    return a

def main():
    archive = read(HERE / 'assembly-member-readback.json')
    assert archive['whole_zip_verified'] is True and archive['member_count'] == 2766
    index = {item['path']: item for item in archive['members']}
    assert len(index) == 2766
    for path in OUT.rglob('*'):
        if path.is_file():
            assert ident(path.read_bytes()) == expected(index[str(path.relative_to(OUT))])
    snapshot = source_snapshot(OUT)
    assert read(OUT / 'source-final.json') == snapshot
    policy, manifest = source.load_policy()
    original = source.original_members(policy, manifest)
    session = source.decode(original['segmented/session/session.json'])
    for path, data in original.items():
        assert expected(index['original/' + path]) == ident(data)
    source.compare_fresh_inputs(original, OUT / 'guest.bin', OUT / 'input.bin')
    claims = claims_record(session, [original[f'segmented/session/segment-{i}'] for i in range(62)])
    assert read(OUT / 'assembly-work/frozen-claims.json') == claims
    costs = read(OUT / 'continuation-costs.json')
    assembled = costs['assembly_result']
    assert costs['complete_proof_and_audit_observed'] is True and costs['errors'] == []
    assert assembled['source_sha'] == SOURCE and assembled['run_id'] == '40611562747'
    assert assembled['run_attempt'] == '1' and assembled['segments'] == 62
    assert assembled['v2_implementation'] == source.implementation_identity()
    assert assembled['real_composite_stark_verified'] is True
    validation = validate(OUT, assembled, SOURCE)
    assert validation == costs['actual_validation']
    native = {'assembly': native_gate(OUT / 'assembly-work', 0, 62, assembled['helper_sha256'])}
    shard_records = []
    for shard in (0, 1):
        directory = OUT / 'shards' / str(shard)
        assert source_snapshot(directory) == snapshot
        attempt = read(directory / 'continuation/attempt.json')
        indexes = list(range(26, 44)) if shard == 0 else list(range(44, 62))
        assert sorted(attempt['completed_segment_indexes']) == indexes
        assert attempt['selected_segment_indexes'] == indexes and attempt['shard_complete'] is True
        assert attempt['source_sha'] == SOURCE and attempt['run_id'] == '40611562747'
        assert attempt['run_attempt'] == '1' and attempt['direct_children_missing_terminal'] == []
        assert attempt['proving_witnesses'] == 'original-frozen-artifact'
        assert attempt['fresh_witnesses_proved'] is False and attempt['real_composite_stark_verified'] is False
        assert attempt['v2_implementation'] == source.implementation_identity()
        assert attempt['budgets'] == policy['budgets']
        continuation.require_work_finished(attempt['work_finished_elapsed_seconds'])
        assert read(directory / 'continuation/frozen-claims.json') == claims
        closed = read(directory / 'continuation-evidence-index.json')
        for relative, wanted in closed['files'].items():
            assert expected(index[f'shards/{shard}/continuation/{relative}']) == wanted
        native[f'shard{shard}-old26'] = native_gate(directory / 'continuation', 0, 26, attempt['helper_sha256'])
        native[f'shard{shard}-new18'] = native_gate(directory / 'continuation', indexes[0], indexes[-1] + 1,
                                                  attempt['helper_sha256'])
        shard_records.append(attempt)
    raw = (OUT / 'receipt.bin').read_bytes()
    assert ident(raw) == {'bytes': assembled['receipt_bytes'], 'sha256': assembled['receipt_sha256']}
    assert dimensions(raw) == {18: 62}
    cursor = Cursor(raw)
    assert cursor.word() == 0 and cursor.length(62) == 62
    receipt_rows = []
    for i in range(62):
        start = cursor.position
        cursor.take(cursor.length(262144) * 4)
        assert cursor.word() == i
        assert bytes(cursor.take(cursor.length(9))) == b'poseidon2'
        cursor.take(32)
        cursor.maybe_fixed(36)
        cursor.maybe_fixed(36)
        exit_code = cursor.word()
        if exit_code in (0, 1): cursor.take(4)
        else: assert exit_code in (2, 3)
        variant = cursor.word()
        if variant == 0: assert cursor.take(1)[0] == 0
        else:
            assert variant == 1
            cursor.take(32)
        cursor.output()
        segment = raw[start:cursor.position]
        item = ident(segment)
        assert item == expected(index[f'assembly-work/receipts/segment-{i}.bin'])
        if i < 26:
            assert segment == original[f'segmented/receipts/segment-{i}.bin']
        else:
            shard = 0 if i < 44 else 1
            assert item == expected(index[f'shards/{shard}/continuation/receipts/segment-{i}.bin'])
            report = read(OUT / f'shards/{shard}/continuation/receipts/segment-{i}.json')
            source.check_receipt(i, session, segment, report)
            continuation.check_stage_terminal(read(OUT / f'shards/{shard}/continuation/steps/segment-{i}.terminal.json'),
                                              SOURCE, 300)
        receipt_rows.append({'index': i, **item})
    controls = {}
    phases = {}
    for label, directory in [('assembly', OUT), ('shard0', OUT / 'shards/0'), ('shard1', OUT / 'shards/1')]:
        control = read(directory / 'native-frozen-controls/controls.json')
        assert control['real_original_receipts_verified'] == 26 and len(control['controls']) == 11
        assert len({x['name'] for x in control['controls']}) == 11
        for row in control['controls']:
            assert row['matched'] is True
            assert row['returncode'] == (0 if row['expected_success'] else 1)
            assert type(row['wall_seconds']) in (float, int) and math.isfinite(row['wall_seconds'])
            assert row['wall_seconds'] >= 0
        controls[label] = control
        for path in directory.glob('*.process.json'):
            phase = read(path)
            source.require_closed_phase(phase, True)
            assert phase['source_sha'] == SOURCE
            for stream in ('stdout', 'stderr'):
                entry = phase['raw_logs'][stream]
                assert ident((directory / entry['path']).read_bytes()) == expected(entry)
            phases[label + '/' + path.name.removesuffix('.process.json')] = phase
    loop = read(OUT / 'loopback/loopback-cost.json')
    assert loop['outcome'] == 'complete' and loop['transport']['outcome'] == 'complete'
    assert loop['transport']['received']['sha256'] == assembled['receipt_sha256']
    assert loop['transport']['application_payload_bytes'] == len(raw)
    for which in ('before', 'after'):
        verification = loop['verification'][which]
        assert verification['result']['real_composite_stark_verified'] is True
        assert verification['process']['exit_code'] == 0
    roles = loop['transport']['roles']
    result = {'schema': 'w1-strict-febf-independent-complete-readback-v1',
        'source': snapshot, 'source_before_after_final_equal': True,
        'run_id': 40611562747, 'artifact_id': 12785720980,
        'archive_bytes': archive['archive_bytes'], 'archive_sha256': archive['archive_sha256'],
        'whole_zip_verified_in_memory': True, 'raw_zip_retained_locally': False,
        'raw_archive_durably_republished': False,
        'original315_members_hash_equal': True, 'original62_witnesses_hash_equal': True,
        'full_original_image_input_bytes_equal': True, 'frozen_claims_equal_original': True,
        'composite_segments_equal_original26_and_current_new36': True,
        'receipt': ident(raw), 'receipt_segments': receipt_rows, 'user_cycles': session['user_cycles'],
        'existing_strict_validator_recomputed_equal': True,
        'hosted_official_complete_composite_verified': True,
        'local_cryptographic_reverification_executed': False,
        'actual_native_claim_and_stark_gates': native, 'actual_native_negative_controls': controls,
        'shards': shard_records, 'native_verifier_wall_ns': validation['verified']['verify_wall_ns'],
        'native_verifier_process_cpu_ns': validation['verified']['verify_process_cpu_ns'],
        'maximum_tested_rejection': max(validation['audit']['negative_cases'], key=lambda r:r['reject_wall_ns']),
        'proof_negative_controls': validation['negative_cases'],
        'native_production_median_wall_ns': validation['native_benchmark']['kernels']['native_production']['median_wall_ns'],
        'new_continuation_and_assembly_cpu_seconds': costs['this_continuation_generation_cpu_seconds'],
        'generation_cpu_seconds_including_original_failure': costs['generation_cpu_seconds_including_original_failure'],
        'known_proof_cpu_including_old_v1_refusals': costs['known_research_proof_attempt_cpu_seconds_including_v1_failures'],
        'all_this_run_exclusive_outer_phases': phases,
        'all_this_run_exclusive_outer_phase_cpu_seconds': sum(x['user_cpu_seconds']+x['system_cpu_seconds'] for x in phases.values()),
        'all_this_run_phase_cost_scope': 'Each recorded outer phase once across the two shards and assembly job. Includes repeated downloads/builds/controls and bind stages inside continuation/assembly; excludes setup/checkout/artifact I/O outside wrappers and separately recorded loopback.',
        'loopback': {'payload_bytes': loop['transport']['application_payload_bytes'],
            'framing_bytes': loop['transport']['application_framing_bytes'],
            'transport_wall_ns': loop['transport']['observed_wall_ns'],
            'sender_receiver_child_cpu_ns': sum(x['process']['child_cpu_ns'] for x in roles.values()),
            'parent_transport_observer_cpu_ns': loop['transport']['parent_observer_cpu_ns'],
            'including_two_verifications_wall_ns': loop['observed_total_wall_ns'],
            'wan_measured': False, 'tcp_ip_bytes_measured': False,
            'transferred_material': 'complete Composite receipt only; input is separately pinned locally'},
        'additional_pow': False, 'povw_requested': False, 'consensus_authority': False,
        'from_zero_generation_cost_measured': False, 'global_worst_invalid_proven': False,
        'pq128_qualified': False, 'public_ingress_qualified': False}
    with (HERE / 'complete-readback.json').open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({k: result[k] for k in ('schema','receipt','native_verifier_wall_ns',
        'proof_negative_controls','new_continuation_and_assembly_cpu_seconds',
        'generation_cpu_seconds_including_original_failure','all_this_run_exclusive_outer_phase_cpu_seconds','loopback')}))

if __name__ == '__main__':
    main()
