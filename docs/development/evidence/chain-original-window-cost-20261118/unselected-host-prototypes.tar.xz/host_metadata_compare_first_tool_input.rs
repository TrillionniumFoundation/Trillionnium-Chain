use std::{fs, hint::black_box, os::unix::fs::MetadataExt, path::Path, time::Instant};
fn cpu() -> u64 {
    use rustix::time::{clock_gettime_dynamic, ClockId, DynamicClockId};
    let t=clock_gettime_dynamic(DynamicClockId::Known(ClockId::ThreadCPUTime)).unwrap();
    t.tv_sec as u64 * 1_000_000_000 + t.tv_nsec as u64
}
fn main() {
    let paths = [Path::new("/sys/fs/cgroup"), Path::new("/sys/fs/cgroup/cpu.max")];
    let mut rows=Vec::new();
    for path in paths {
        let file=fs::File::open(path).unwrap();
        let m=file.metadata().unwrap();
        let expected=(m.dev(),m.ino(),m.uid(),m.mode());
        for round in 0..12 {
            for by_fd in [true,false] {
                for (slot,direct) in [false,true,true,false].into_iter().enumerate() {
                    let wall=Instant::now(); let before=cpu();
                    for _ in 0..2048 {
                        let actual=if direct {
                            let s=if by_fd { rustix::fs::fstat(&file).unwrap() }
                            else { rustix::fs::statat(rustix::fs::CWD,path,rustix::fs::AtFlags::SYMLINK_NOFOLLOW | rustix::fs::AtFlags::NO_AUTOMOUNT).unwrap() };
                            (s.st_dev as u64,s.st_ino as u64,s.st_uid,s.st_mode)
                        } else {
                            let s=if by_fd {file.metadata().unwrap()} else {fs::symlink_metadata(path).unwrap()};
                            (s.dev(),s.ino(),s.uid(),s.mode())
                        };
                        assert_eq!(black_box(actual),expected);
                    }
                    rows.push(serde_json::json!({"path":path,"round":round,"slot":slot,
                        "api":if direct {"rustix_basic_stat"}else{"std_metadata"},
                        "by_fd":by_fd,"calls":2048,"thread_cpu_ns":cpu()-before,"wall_ns":wall.elapsed().as_nanos()}));
                }
            }
        }
    }
    println!("{}",serde_json::json!({"schema":"trnm-host-fresh-metadata-abba-v1","samples":rows,
        "scope":"read-only actual cgroup metadata calls; same dev/inode/uid/mode, no fixed-parent admission or service business claim",
        "production_candidate_selected":false}));
}
