# W1 完整成本、量子资源及 DAA／重组审查交接包

**结论：已有足够材料交给独立审查者逐项核查；尚不具备可接受的完整、可比系统成本账。外部接受仍为 `false`。** 本包完成源码与历史原始证据审读，未运行新的原生工作、性能实验、模型模拟或流水线。组件成本记录、服务失败及未测定模型前提分别保留。

## 1. 候选与证据身份

| 项目 | 固定身份／范围 |
| --- | --- |
| 本次源码审查 | Chain `ea909124cc460f364bd17b009073306014133f48`；tree `96712231eba3d333bdfebefa9c22c80ea1794d04` |
| 历史实际 V5 组件执行 | Chain `9f77f4334a365387d7389735d5b67c37f12a02a0`；tree `d7803f073a81e17ce4b79efca748645e12d3adff` |
| 固定验证 PR | PR #756；base `a3e9002cd12ef90d62f8b252cad570e72dab6fa3`；原 9f prospective merge `b2aaf3d7d0e89650a6921fb2485a60e99b888c3b`，ordered parents 为 `[a3, 9f]` |
| V5 工作流 | run `42324271643`，attempt 1，x64 head job `128255821457` |
| V5 原始 artifact | `13555294305`；45,038,102 bytes；SHA256 `c211b8b8bb122d6e65a00994691eadc8fbb993ddeb20fe35df7c264f0a9ad0fb` |
| V5 保留的实际 binary | 988,400 bytes；SHA256 `6ac7c382d304b70507338778409985f0212714e23006f54f497046db886e014c`；四份 before／after 摘要一致 |
| 当前审读范围 | 内部源码、原始文件及计量账本；不等于外部审查接受，不认证硬件或计时真实性 |

25 个实际本地源码文件与当前 Git blob 已逐字节核对。完整 formal tree 与 crypto crate tree 在 9f→ea909 之间不变；61 门文件中 59 个同 blob、2 个修改，另有明确登记的名册／Host 改动。原资源、攻击和时间的 15 文件映射保持原 630 失败配置来源；同 blob 不使旧执行成为 ea909 的新结果。逐文件绑定见 [61 门及预算映射](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/gate-map-ea909/mapping.json) 和 [机器可读证据表](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/independent-review-package-ea909/cost-evidence-table.json)。

Hepta public preparation 复用的独立内部审读另见 [Hepta 六文件审读](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/hepta-prepared-3bc/review.md)。实际 `just fix` 后六文件 SHA256 均与已审格式化产物相同；[只读复核记录](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/hepta-prepared-3bc/post-just-fix-readback.json) 保留该事实。跨仓最终 binary 与同组合必要门由主候选证据绑定，本包不提前认定。

## 2. 固定 9f 工作流通过与失败的完整分母

固定 PR756 的 W1 run `42324271643` 已有 22 个终态 job：**20 个策略／复用／V5 作业通过，2 个 fresh-service 作业失败**。这两项失败分别是 head `128255821686`、prospective-merge `128255821239`。这里引用完整 jobs JSON 的实际终态；本包未重新下载这两个服务作业的 raw artifact，不推测其额外细节。原始终态见 [w1-9f-fixed-final-jobs.json](sandbox:/workspace/scratch/e0c10cd6a255/candidate-evidence/w1-9f-fixed-final-jobs.json)。

| 历史门 | 完整计划分母 | 原始结果与边界 |
| --- | --- | --- |
| 固定 PR756 W1 | 22 jobs | 20 组件类成功；2 fresh-service 失败。组件成功不能覆盖服务失败。 |
| 原 9f F0 | 6 次确认／42 次业务包暴露 | 原四秒窗口内 0/6 成功；`BASELINE_MUST_PASS`；未把未观察到的确认移出分母。 |
| 原 9f native campaign | 3 次 campaign × 3 phases × 每 phase 3 次确认 = 27；189 次业务包暴露 | 原 30 秒 phase 内 3 确认、9 观察到的失败、15 未观察；0/3 完整 campaign 成功。 |
| ea909 当前必要门 | 另行绑定同一新候选 | 本包不轮询、不继承旧通过，也不宣称新源已执行。 |

F0 baseline 的实际 importer CPU 为 5.969897011 秒、wall 为 26.510093655 秒；其中 81,891 次 Host 检查全部接受，Host 嵌套 CPU 为 5.096704855 秒。Host 区间不能再加到 importer CPU。三轮 native 的全部九 phase 共 521,227 次 Host 调用、0 次拒绝；“60 个 account_graph span”也不等于“60 次完整图遍历”。这些证据支持继续检查真实导入开销，不能凭 span 名称或组件快慢确定单一根因。详见 [F0 6／42 原始分析](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/f0-9f77-42323271496/analysis.json)、[native 27／189 原始分析](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-9f77-42323271551/analysis.json)。

## 3. V5 原始成本账已核对到什么程度

已验证 ZIP 摘要、220 个归档成员、manifest 登记的 209 个文件摘要、源 before／after 和保留 binary。随后对全部 66 个 JSONL 分片重放原 checked-in reader，并独立重加每个分片的 17 个 arm，共 1,122 个 arm 的预处理、搜索、销毁、验证及外框费用，均与存档报告一致。69 个命令均成功且有 wait4；没有 partial shard、丢失计时或 native 错误。这是已发生记录的一致性复核，没有重新执行 W1。完整值见 [66 分片／1,122 arm 原始账本核对](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/independent-review-package-ea909/fixed9f-v5-raw-analysis.json)。

| 分片用途 | 分片数 | paid setups | unsupported setups | searches | physical attempts | misses | exhaustion | speculative attempts | verifier calls |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| search-cost | 44 | 5,984 | 2,464 | 15,840 | 270,951 | 254,162 | 0 | 3,028 | 69,416 |
| exhaustion-control | 11 | 1,496 | 616 | 880 | 2,640 | 2,640 | 880 | 0 | 0 |
| first-hit-control | 11 | 1,496 | 616 | 880 | 1,056 | 0 | 0 | 176 | 3,872 |
| 全部 | 66 | 8,976 | 3,696 | 17,600 | 274,647 | 256,802 | 880 | 3,204 | 73,288 |

44 个成本分片覆盖 11 类材料 × 两个 target（理想均匀 ticket 假设下为 1/2、1/32）× 两个实际 reuse horizon（1、8），每个 8 samples、17 个预先声明的策略，attempt cap 为 4096。另 22 个控制的 attempt cap 为 3。**880 次 exhaustion 全部来自三次尝试控制；44 个成本分片没有实际耗尽。** 17,845 个 physical target hits 中有 post-winner speculative hits，不能都算独立 winner；策略之间重复相同逻辑搜索、horizon 1/8 也复用相关前缀，不能把 17,600 次搜索当成独立统计样本。

### 3.1 成本口径和不能相加的区间

下表是整个实验已发生费用的盘点，混合不同材料、目标、策略、horizon 和控制，**不是一个安全比率或可执行全局策略的总成本**。

| 范围 | CPU 秒 | 计入与排除 |
| --- | ---: | --- |
| 全部 paid setup | 0.578309 | 含 unsupported constructor、失败 rank probe 和 dense fallback；不免费使用 oracle 因子。 |
| 完整搜索生产 | 77.625786 | 完整 misses、trace、ticket、proof materialization、线程 spawn/join 和 speculation。 |
| 搜索后销毁 | 0.157874 | 与 producer interval 分开；保留全部实际 materialized buffers。 |
| winner buffer cleanup | 0.111441 | 每次搜索独立记录；不是新增的生产工作。 |
| task teardown | 0.024145 | 实际准备对象生命周期结束。 |
| 上述互斥生产费用之和 | 78.497556 | 即 producer-total；不能再加一次其内部子项。 |
| 独立 observation | 6.968207 | 完整 proof identity、JSON value 等；不等于全部序列化和输出 I/O。 |
| 原生 verifier calls | 26.766535 | winner、product-last、post-winner replay，production 和 scalar 分列。 |
| inclusive cohort | 115.667274 | 包含上列生产／observation／verification，另有 3.434977 秒未细分 harness 开销。 |
| shared material setup | 0.037478 | 每 shard 一次，与 arm setup 分开；并非真实下载／权限／DA 的完整成本。 |
| shared reference setup | 0.009250 | 每 shard 一次，与 verifier call 分开。 |
| 66 个 native 命令 wait4 | 115.815835 | 外框包含上述 native 费用与输出／runtime；不可再叠加 cohort。 |
| 实际 build wait4 | 24.073196 | 构建费用另计，不藏进单 winner ratio，也不默认为每次 search 必须支付。 |
| Python observer self CPU | 129.450546 | 分列用户／系统 CPU 的同一 observer；不据此宣称整个 CI job 全进程成本。 |

66 个 native 命令 wall 区间之和 108.822410 秒；整个 runner wall 263.356042 秒。原始 native stdout 为 166,403,576 bytes；单进程 wait4 RSS 的最大值为 53,016 KiB。RSS 不是全系统同时峰值，wait4 对未回收 descendants 的完整性仍未证明。没有能耗、完整网络带宽或经济成本数据。

### 3.2 观察到的固定策略比较

以下仅列 target 指数 1（理想 1/32）和 reuse=8 的 11 个成本单元。每项为该固定策略全部 paid setup、完整搜索与销毁之和除以 64 个记录中的 winner；材料获取、独立验证、observation 和外框开销另列。这些数字是旧 9f、该 x64 运行环境的有限观察，未作统计置信或“最佳已知”外部接受。

| 材料 | dense ms/winner | rank8 ms/winner | batch4 ms/winner | scalar ms/winner | rank8 winner production verifier ms/call |
| --- | ---: | ---: | ---: | ---: | ---: |
| zero | 7.682889 | 7.772186 | 12.755429 | 13.327875 | 0.315407 |
| rank-one | 6.121640 | 6.084727 | 10.511985 | 10.518877 | 0.305118 |
| rank-two-left | 7.059402 | 7.203866 | 11.848623 | 12.099712 | 0.318920 |
| rank-four-left | 5.959096 | 5.943085 | 9.879095 | 10.265162 | 0.316694 |
| rank-eight-left | 8.165902 | 8.185245 | 13.366939 | 14.058428 | 0.317469 |
| rank-four-right | 7.289749 | 7.285159 | 12.291923 | 12.585592 | 0.311817 |
| rank-nine-left | 6.616776 | 6.581873 | 11.050920 | 11.244442 | 0.302306 |
| full-rank-field | 7.815716 | 7.751145 | 12.688132 | 13.349509 | 0.312038 |
| sparse-diagonal | 7.638667 | 7.671594 | 12.292948 | 13.026352 | 0.313605 |
| one-zero-rank-one | 7.914433 | 7.816266 | 12.862580 | 13.188989 | 0.317489 |
| continuity-maintenance-v1 | 6.181393 | 6.131450 | 10.293844 | 10.539217 | 0.313111 |

44 个单元中的事后描述性 CPU 最小值分布为：`full-limb-rank8-lazy` 23 个；`blocked-zero` 3 个；`full-limb-dense-lazy` 7 个；`full-limb-sparse-lazy` 8 个；`maintenance-limb` 3 个。batch4 没有取得这批单元的最低 producer CPU；其 wall 和并行资源必须另看，不能以 CPU 排名替代延迟结论。也不能把各单元事后最小值拼成一个没有预先声明的全局策略。高 rank／full-rank 情况下 rank8 strategy 会回到 dense；小幅测量差异不能自动归因于低秩算法收益。

### 3.3 资源与证据资格边界

实际 observer membership 为 `/system.slice/hosted-compute-agent.service`，解析到 `/sys/fs/cgroup/system.slice/hosted-compute-agent.service`；可见 leaf 与 system.slice 的 `cpu.max` 为 `max 100000`、memory/swap 为 `max`，leaf `pids.max=17436`，allowed CPUs 为 0–3。根控制器文件缺失使观测保持 `PARTIAL_OBSERVATION`；`effective_quota_established=false`、namespace 外祖先不可见、native child membership 未认证。**此组件实验明确 `original_public_service_resource_contract_used=false`，不能视为四秒／quarter-CPU／2 GiB 门。** 原 artifact 的 source execution、clock、independent W1 replay、feature provenance、cheapest strategy、work profile、public service、cross architecture、activation 九项资格均为 false，本次 raw 一致性复核没有改变它们。

## 4. 仍需审查者决定的完整成本边界

每一项都给出已见证据、计量范围、具体缺口与关闭条件。这里的 PENDING 表示尚无外部签收；不是要求所有研究性主张都达到未声明的系统范围。审查者可明确缩小到有证据的条件结论。

### C01 — 材料获取与合法 native 上下文

**已见：** V5 的 11 类 synthetic/hash-generated matrix fixtures 与 task/target/sample/search/nonce 诊断 challenge 可复现；不授予 actual task eligibility。

**成本范围：** material_setup、reference_setup 按 shard 单列；真实下载/授权/可用性/编码器 provenance 不在 producer ratio。

**具体缺口：** 没有把 11 类 fixture 的取得、选择和 factor discovery 成本，绑定到相同当前 parent/DAA/time 下实际可提交的合法 native task。

**可关闭条件：** 逐策略给真实材料来源、选择允许的信息、当前合法上下文与实际 binary；条件只覆盖矩阵组件时明确缩小接受范围。

依据：[pon_w1_rank_batch_v5.rs](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/trillionnium/crates/trnm-crypto-primitives/examples/pon_w1_rank_batch_v5.rs)；[W1_RANK_BATCH_V5.md](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/W1_RANK_BATCH_V5.md)。

### C02 — 固定合法策略搜索与 rank 上限

**已见：** 66 shards、8 samples、17 fixed strategies；11 materials×两个 target(1/2,1/32)×reuse(1,8)=44 cost shards，另22 controls。rank≤8 先 probe A 再 B，均失败才 dense。

**成本范围：** 每 sample 每 strategy 实际 constructor 付费，包括 unsupported、失败 probe、dense fallback；没有逐 sample 事后挑赢家的策略 oracle。

**具体缺口：** rank8 cutoff/left-first 次序未证明最佳；V5 没有 horizon64 cost；right-rank8 是 unit control，不能移用 right-rank4 cost；CPU grid 未覆盖 GPU/FPGA/ASIC 或全部合法结构。

**可关闭条件：** 冻结可执行策略集合、信息边界、硬件范围及截止日期，独立确认最佳已知集合；不能提升为全局最优或 hardness 下界。

依据：[low_rank.rs](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/trillionnium/crates/trnm-crypto-primitives/src/pon_work/legal_attempt/low_rank.rs)；[pon_w1_rank_batch_v5.rs](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/trillionnium/crates/trnm-crypto-primitives/examples/pon_w1_rank_batch_v5.rs)；[pon_w1_rank_batch_reader_v5.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/scripts/pon_w1_rank_batch_reader_v5.py)。

### C03 — 完整 attempts、misses 与 batch speculation

**已见：** 每次仍完成 bounded noise、ordered 512 transcript tiles、trace 和 ticket；batch最多4个scoped workers，全部join。固定9f/x64 raw的66 shards与1122 arms已逐JSONL重算：274647 physical attempts、17600 searches、880 exhaustion、3204 speculation，全部与存档reader一致。

**成本范围：** producer 包含 complete hits/misses、线程创建/join、speculation；原4096 attempt cap及最终小batch保留。process CPU包括worker，未知CPU不补零。

**具体缺口：** 本次已完成一个固定9f/x64 artifact的完整账本重算，但不是ea909执行或W1 transcript重放；有限目标中奖率的iid/uniform假设与相关reuse前缀不能作为实测独立样本。

**可关闭条件：** 从完整raw计数重建 planned/issued/completed/exhausted/failed/missing；按预声明固定策略比较总成本与有序winner。

依据：[pon_w1_rank_batch_v5.rs](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/trillionnium/crates/trnm-crypto-primitives/examples/pon_w1_rank_batch_v5.rs)；[pon_w1_rank_batch_reader_v5.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/scripts/pon_w1_rank_batch_reader_v5.py)；[run_w1_rank_batch_v5.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/scripts/ci/run_w1_rank_batch_v5.py)；[fixed9f-v5-raw-analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/independent-review-package-ea909/fixed9f-v5-raw-analysis.json)。

### C04 — 取消、panic、spawn失败及 partial shard

**已见：** 生产parallel_map在错误/panic后仍join所有已启动worker；runner保留partial stdout/stderr、exit/signal/timeout，缺失或截断不通过。

**成本范围：** 已发出的batch不能按首winner追溯减免费用；失败/未完成不能从66-shard分母删除。

**具体缺口：** 未见可确定触发真实spawn-failure的native负控；测试中的Barrier(4)遇真实spawn失败可能挂到外层timeout。此9f artifact的69命令均成功、无partial shard；880 exhaustion全为预声明3-attempt控制，不是4096 cost-search耗尽或基础设施故障样本。

**可关闭条件：** 外审逐条检查失败资源与partial ledger，不将无结果当零成本；必要时明确该故障注入覆盖未建立。

依据：[pon_w1_rank_batch_v5.rs](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/trillionnium/crates/trnm-crypto-primitives/examples/pon_w1_rank_batch_v5.rs)；[run_w1_rank_batch_v5.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/scripts/ci/run_w1_rank_batch_v5.py)。

### C05 — proof materialization、缓冲区与teardown

**已见：** lazy只在完整trace/ticket后省proof分配；保留PNW1、canonical A/B/C prefix、trace/ticket与SHA256(proof) commitment；输家/赢家buffer disposal与task teardown都有记录。

**成本范围：** setup + search.producer + disposal + search-cleanup + teardown属于producer费用；不可再叠加已包含这些区间的cohort total。

**具体缺口：** 固定9f/x64全部raw数值现已核对；但所有cohort正常结束，不提供真实panic/spawn-failure清理成本，也不能移用于ea909门或其他硬件。

**可关闭条件：** 逐sample重算producer总量，验证complete commitments与完整失败分母，保留未知clock。

依据：[pon_w1_rank_batch_v5.rs](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/trillionnium/crates/trnm-crypto-primitives/examples/pon_w1_rank_batch_v5.rs)；[pon_w1_rank_batch_reader_v5.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/scripts/pon_w1_rank_batch_reader_v5.py)；[fixed9f-v5-raw-analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/independent-review-package-ea909/fixed9f-v5-raw-analysis.json)。

### C06 — 验证成本与winner/post-winner目标

**已见：** winner在原target执行production+independent scalar verifier；每个post-winner attempt在max target双重完整replay；reader重建AB与proof哈希，但不执行W1 transcript。

**成本范围：** verification_cost独立于producer ratio；max-target replay不是原target合法winner计数。

**具体缺口：** 固定9f/x64的73288 verifier calls及各case/path费用已和raw重算一致；reader不能认证执行/时钟或重做transcript。该联合组件表仍不是同actual admission context/原public预算下合法生产与cheap-invalid受害成本。

**可关闭条件：** 保留实际binary/source绑定和两个native verifier原始记录，明确计入哪类accepted work与拒绝成本。

依据：[pon_w1_rank_batch_v5.rs](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/trillionnium/crates/trnm-crypto-primitives/examples/pon_w1_rank_batch_v5.rs)；[pon_w1_rank_batch_reader_v5.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/scripts/pon_w1_rank_batch_reader_v5.py)；[fixed9f-v5-raw-analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/independent-review-package-ea909/fixed9f-v5-raw-analysis.json)。

### C07 — 便宜无效候选的独立攻击

**已见：** 保留false-trace sampler无需获得合法proof：9旧材料类、8 samples、每prefix setup实际复用4次search、target约1/2、cap4096，所有miss保留。V5 negative只有已经诚实完成trace/ticket后的末C字mutation。

**成本范围：** false-trace setup/search包括challenge hash、trial retention和winner clone；native verifier call另计。V5 Product mutant支付了合法生产成本。

**具体缺口：** V5的新rank2/4/8/9材料、target1/32与reuse1/8，未由旧false-trace网格给出对应攻击成本；Product拒绝不能改名为cheap-invalid覆盖。

**可关闭条件：** 只在已有共同材料/target/reuse范围比较，或提供对应raw攻击成本；同时保留原from-zero/fresh service门。

依据：[pon_w1_false_trace_reuse_v1.rs](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/trillionnium/crates/trnm-pon-node/examples/pon_w1_false_trace_reuse_v1.rs)；[pon_w1_rank_batch_v5.rs](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/trillionnium/crates/trnm-crypto-primitives/examples/pon_w1_rank_batch_v5.rs)；[pon_w1_false_trace_reuse_reader_v1.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/scripts/pon_w1_false_trace_reuse_reader_v1.py)。

### C08 — 公共服务、状态/commit/history与全部失败

**已见：** 旧9f F0：原6确认/42 exposures，0/6四秒成功；原native：27计划确认、3成功/9观察失败/15未观察，0/3完整campaign。固定PR756 run42324271643终态22 jobs中20策略/复用/V5 PASS、2 fresh-service FAIL（head128255821686、merge128255821239）。

**成本范围：** F0的4秒从scheduled offset起算；native使用30秒phase，不能混算；ACK、读取成功或先前baseline不是独立客户端确认。

**具体缺口：** 本候选ea909的实际端到端门尚未由本包观测，旧source相同或组件速度提高不能关闭服务失败。

**可关闭条件：** 同固定跨仓组合、原攻击/资源/时间及全部分母下独立client真正完成确认，同时完成history同步。

依据：[analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/f0-9f77-42323271496/analysis.json)；[analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-9f77-42323271551/analysis.json)；[w1-9f-fixed-final-jobs.json](sandbox:/workspace/scratch/e0c10cd6a255/candidate-evidence/w1-9f-fixed-final-jobs.json)。

### C09 — 嵌套CPU、wall和完整命令外框

**已见：** F0 baseline importer 5,969,897,011ns thread CPU/26,510,093,655ns wall；Host 81,891次、5,096,704,855ns CPU是其中嵌套区间，全部Host接受。native九phase同样保留完整导入和Host。

**成本范围：** calling-process CPU含并发receiver/observer；importer thread与Host、state、work、admission、commit span互相包含；cohort/wait4是外框，不重复求和。throttled_usec不是额外CPU。

**具体缺口：** 若要给一个总成本，需对actor/public/controller/child scope做互斥归属；现有span不能直接拼总和。60个account_graph spans也不是60次完整图遍历。

**可关闭条件：** 总量使用对应的完整owner/process/cgroup口径；子span只解释分布，附scope与缺测项。

依据：[analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/f0-9f77-42323271496/analysis.json)；[analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-9f77-42323271551/analysis.json)。

### C10 — 输出I/O、峰值资源与host观测

**已见：** 固定9f V5的66 native命令wait4 CPU共115815835000ns、输出166403576B、各命令RSS最大53016KiB；共享material/reference、observation、verification、cohort另列。current cgroup有实际非根membership和ancestor，但为PARTIAL_OBSERVATION；ea909观测源码同blob。

**成本范围：** wait4 peak RSS不是同时存活全系统内存；failed build未reap descendants可缺CPU。当前namespace可见ancestor不等于effective quota，也不证明child placement。

**具体缺口：** 组件ratio不含独立列出的verification/output/common material等费用；网络带宽、完整资源峰值、无法观测ancestor仍不能默认为零。

**可关闭条件：** 逐scope交付原始host/CPU/RSS/I/O记录及缺测项；继续保留独立的quarter-CPU/2GiB public Host gate。

依据：[run_w1_rank_batch_v5.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/scripts/ci/run_w1_rank_batch_v5.py)；[public_host_ci_observation.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/scripts/ci/public_host_ci_observation.py)；[W1_RANK_BATCH_V5.md](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/W1_RANK_BATCH_V5.md)；[fixed9f-v5-raw-analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/independent-review-package-ea909/fixed9f-v5-raw-analysis.json)。

### C11 — 证明生成或替代验证的成本

**已见：** V5只采样matrix component，不生成zkVM proof；现有完整关系、旧proof receipt与后续deadline失败是不同证据。

**成本范围：** 任何声称降低验证成本的proof方案须把generation、输入获取、完整关系、失败、递归与release latency计入，不能只计小journal/AB certificate。

**具体缺口：** 本包没有同完整关系下新候选实际proof generation延迟与整体收益记录。

**可关闭条件：** 固定guest/image与原relation，交付真实proof及完整generation/verifier费用；不适用该主张时明确排除。

依据：[W1_RANK_BATCH_V5.md](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/W1_RANK_BATCH_V5.md)。

### C12 — 能源、硬件与经济成本

**已见：** 现有组件记录CPU/wall与部分RSS，不测量能耗、硬件采购、GPU/FPGA/ASIC效率或货币优势。

**成本范围：** 不能把CPU纳秒ratio直接称为经济安全成本或最快攻击者成本下界。

**具体缺口：** 没有对应硬件/能源/折旧数据；如不主张经济或跨硬件优势，可把外审结论严格限于已测实现。

**可关闭条件：** 依据主张选择实测成本或透明条件区间；不要求凭空构造未知经济数据。

依据：[W1_RANK_BATCH_V5.md](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/W1_RANK_BATCH_V5.md)。

## 5. 量子资源与 DAA／重组的逐行审查前提

以下保留现模型真正声明的数值和范围，区别构造、macro evaluation、reduced gate controls 与实际原生执行。没有要求凭空运行量子硬件；可接受的条件资源模型仍需独立审查其参数来源、可共同实现性、策略范围和结论方向。一个已构造策略的资源上界不能反过来证明最快攻击者至少需要这些资源。

### Q-01 — 构造的完整 predicate 与 reduced controls

**源码事实：** 原生形状是 n=64,r=8,field_bits=32,noise_counters=128；编译固定 PNH1/PGH2 nonce 输入、bounded noise、ordered prefix trace、ticket、相位标记和逆计算。原生 scalar macro run 不标为逐门执行。

**未经测定／证明的前提：** 构造和小形状 exhaustive/gate controls 不自动证明每个原生规模电路门、原生 admission 前置条件或最快 oracle。

**外部审查应给出的证据或条件：**

- 独立复核 byte framing、nonce offset、inclusive target、noise failure、field arithmetic、phase sign 与全部 ancilla uncomputation。
- 构造 receipt 必须固定 compiler/source/leaf-netlist/layout/stage counts 摘要，明确哪些检查是 gate execution、macro evaluation 或解析证明。
- 用独立 native/scalar 实现核对固定输入和 mutation controls；原生 native admission 前置条件单列实证或明示条件。

当前源码：[w1_quantum_oracle.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/w1_quantum_oracle.py)；[w1_quantum_primitives.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/w1_quantum_primitives.py)；[reversible_components.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/reversible_components.py)。

### Q-02 — 较便宜合法子集与自己的 marked count

**源码事实：** PrefixRestrictedProgram 只标记四个 label 的前 N*R 原始 noise word 全 canonical 的合法赢家；丢弃一些完整合法赢家，省去 coherent compaction。conditional_prefix_retention 是 (q/2^w)^(4*n*r) 的条件代数值。

**未经测定／证明的前提：** RAW-WORD iid-uniform 未证明；prefix validity 与 ticket hit 的独立性未证明。保留率不是该子集的中奖概率。

**外部审查应给出的证据或条件：**

- 同一 fixed header/domain 分别给 M_full 与 M_restricted，检查 subset soundness。
- 把 restricted circuit 资源只配给 restricted marked count；拒绝便宜子集成本与完整 predicate 成功率的拼接。
- 如果用保留率或随机预言机代替实测 M，精确声明假设并给相关性/选择偏差敏感性。

当前源码：[w1_quantum_restricted_oracle.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/w1_quantum_restricted_oracle.py)；[w1_marked_domain.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/w1_marked_domain.py)。

### Q-03 — marked domain 范围与 target/header 绑定

**源码事实：** literal census 的 native 上限 nonce_bits=6（最多64 nonce），reduced 上限12；最多16 domains。target 属于 challenged header，修改 target 要重算 ticket。

**未经测定／证明的前提：** 低 nonce 子空间 census 不能刻画全部 nonce64；通用模拟的 iid Bernoulli ticket prior 与实际 W1 分布并未等价证明。

**外部审查应给出的证据或条件：**

- 逐域固定完整 header、矩阵、nonce 子空间、实际 M 与所有 wins/misses，zero-marked domain 必须保留。
- 换 target、parent、witness root 或其他 header 字节时重新构造/测量，不重用旧 tickets 对新阈值比较。
- 明确由 literal census 支持的范围；对更大域使用可审查的统计设计或条件假设，不能外推成证明。

当前源码：[w1_marked_domain.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/w1_marked_domain.py)；[quantum_adversarial_search.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_adversarial_search.py)。

### Q-04 — 攻击策略信息边界与停止策略

**源码事实：** 优化器只遍历有限 iteration candidates，目标是固定 target 的 renewal throughput；MAX_EXACT_BINOMIAL_SIZE=64，MAX_DOMAIN_SIZE=4096。persistent domains 可模拟，但无 BBHT/posterior-optimal/global-profit 实现。

**未经测定／证明的前提：** finite candidate optimum 不是最佳网络攻击；成本优化不得偷看 sampled M；fresh independent domain 的实际 W1 可实现性未证明。

**外部审查应给出的证据或条件：**

- 固定策略可见信息、iteration choices、restart/measurement/domain-refresh 开销及 release rule，再运行。
- 评审未知 M、M=0、persistent/shared M、多处理器及重启/中断策略；明确纳入或排除的 BBHT/自适应策略。
- 策略不能看全局 observer tip、未来事件或 sampled M；事后挑 seed/参数必须作为探索集，另设独立验证集。

当前源码：[quantum_adversarial_search.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_adversarial_search.py)；[quantum_network_sim.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_network_sim.py)。

### Q-05 — 完整量子资源账本

**源码事实：** clock adapter 按 prepare + 2*winner_compute + phase_marker + diffusion 计费；为每个 processor 及中断 trial 收费；静态 wire/oblivious selection 不授予免费 QRAM。

**未经测定／证明的前提：** caller supplied Circuit 仍是未验证 predicate 成本；没有来源的 logical qubits/gates/depth 不能当 W1 数据。

**外部审查应给出的证据或条件：**

- 使用 construction mode 时重新编译所有 circuit counts，不能仅接收手工 budget/checksum。
- 审查输入加载、workspace/routing、inverse、diffusion、reset/readout、每个失败候选的经典重检和 winner 后完整 proof release。
- 核对所有 processor、preprocessing reuse、full/aborted trials 和峰值存活寄存器；不可把 count 与 depth 相互替代。

当前源码：[quantum_oracle_resources.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_oracle_resources.py)；[quantum_resource_clock.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_resource_clock.py)；[w1_quantum_oracle.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/w1_quantum_oracle.py)。

### Q-06 — 物理误差与容错参数

**源码事实：** 示例 physical_error=1e-4/1e-3/3e-3、threshold=0.01、prefactor=0.1、cycle_ns=1000；采用 p_L(d)=A*(p/p_th)^((d+1)/2)。T/Toffoli=7、T-depth/Toffoli=3、decomposition_depth=10，均为声明输入。

**未经测定／证明的前提：** 这些数值是 illustrative 参数，未经 W1 硬件标定。每 patch-cycle 的残余错误率未作为实际上界验证；correlated faults/leakage/decoder/control 的影响未具体约束。

**外部审查应给出的证据或条件：**

- 给每个参数的论文/硬件来源、适用噪声/decoder/布局条件或保守区间；独立审查参数组合是否可共存。
- 对完整 task horizon、processor count、physical-qubit budget 和误差目标做联合敏感性，不能分别挑最优参数。
- 条件资源模型可以经独立审查接受，无需假装实际量子机器已运行；结论必须保留条件与范围。

当前源码：[quantum_oracle_resources.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_oracle_resources.py)；[quantum_resource_clock.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_resource_clock.py)。

### Q-07 — 物理 footprint、factory 与失败预算边界

**源码事实：** 示例 data=2*d^2 每 logical qubit，2 factories，每 factory=100*d^2，T service=10*d cycles，magic_state_error=1e-15、total_failure_budget=0.01、maximum_distance=101。code distance 为整个 campaign 选择。

**未经测定／证明的前提：** factory service 包括 production/delivery/injection/feedforward 及 buffer 是前提；初始化、reset/readout 与经典 controller 被假定理想或排除，end_to_end_machine_failure_bound=false。

**外部审查应给出的证据或条件：**

- 独立核对空间布局、factory吞吐/存储/交付、数据等待期间错误以及并行路由，不把抽象 footprint 当实机布局。
- union bound 本身不要求独立性；需要审查被相加的各项错误率是否有效上界及遗漏阶段。
- 若声称端到端可靠性，将 initialization/readout/controller/idle 的错误纳入；否则明确只接受 coherent-stage 条件账本。0.01失败预算不能称为128位安全强度。

当前源码：[quantum_oracle_resources.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_oracle_resources.py)；[quantum_resource_clock.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_resource_clock.py)。

### Q-08 — 量子时钟、经典成本与最快攻击者方向

**源码事实：** adapter 使用 serialized magic delivery 的可声明 schedule，时间向上舍入；理想 overlap lower bound 不用作实现时钟。ClassicalCosts 的 preprocessing/setup/readout/check/proof/propagation 均是 caller输入；示例分别为1ms/10us/1us/20us/1s/100ms。

**未经测定／证明的前提：** 串行构造给某个攻击策略的资源上界，不能证明攻击者至少那么慢；setup 每 trial 重复计费也可能排除了更快合法摊销。

**外部审查应给出的证据或条件：**

- 把经典费用来源绑定到同一实际实现或公开、保守的假设范围，区分可重复使用的 setup 与每次必须工作。
- 比较可实现的更快并行、优化/合法子集策略，或把结论严格限制为该构造；不能把上界反向当安全下界。
- 所有 clock 的精确分数、向上舍入、物理资源约束和 campaign-wide code distance 在运行前冻结。

当前源码：[quantum_resource_clock.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_resource_clock.py)；[quantum_oracle_resources.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_oracle_resources.py)。

### D-01 — DAA算术与原生协议边界

**源码事实：** 模型复用 required work、16-block retarget、11-ancestor median 和 now+120；ASERT 为精确u256研究算术，不含BCH nBits rounding；fixed-p-work 是新假设。

**未经测定／证明的前提：** 通过 isolated target/time arithmetic 不证明完整 alternative consensus 协议、原生合法出块或重组可执行。

**外部审查应给出的证据或条件：**

- 逐分支与原生节点核对 boundary heights、anchor、舍入、timestamp、deferral、target、work overflow 和 tie规则。
- same elapsed wall/resource budget 下生成或验证实际完整 packet/parent/task/state 路径；仅虚拟chainwork比较单列。
- 不得以模型通过授权协议迁移；ASERT/fixed-p/NG/Prism/DAG 均需独立完整协议映射与应用负载对照。

当前源码：[quantum_daa_model.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_daa_model.py)；[reference.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/reference.py)。

### D-02 — 未测定的产块、网络与 proof 时钟

**源码事实：** DAA cost_ratio 使用sqrt difficulty，基线attacker_rate默认0.25；诚实链是确定性10秒期望块。network simulator另用Poisson classical arrivals，默认0.1 block/s、0.5/0.5 shares、固定0.5秒传播、0.1秒classical proof与1秒quantum proof；资源adapter会重导出量子时钟而非使用其默认0.15秒iteration。

**未经测定／证明的前提：** 所有这些默认速率/延迟不是当前W1/网络的测量；完整 ancestor bundle、无带宽/eclipse/原生W1验证成本，以及均匀marked probability 均是条件前提。

**外部审查应给出的证据或条件：**

- 每个实验明确使用direct timing还是resource-derived clocks，拒绝混合不同profile/资源/时期的费用。
- 把带宽、完整数据可得性、native validation、proof/material获取、节点状态/存储与攻击者/诚实方实际预算列入模型或限制结论范围。
- 对传播分布、份额变化、withholding、future timestamp waits和深reorg恢复做对等负载的敏感性/原生回放。

当前源码：[quantum_daa_model.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_daa_model.py)；[quantum_network_sim.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_network_sim.py)。

### D-03 — 有限搜索、右删失与审查决定

**源码事实：** network 默认1200秒horizon、20k events、4k blocks、80k trace rows、20k pending events、10秒CPU cap。资源campaign使用自己的10k events/1k blocks等包络；重放会重导出资源和trace摘要。

**未经测定／证明的前提：** 有限seed/策略网格和cpu/event/trace限额不构成任意攻击安全阈值；checksum/source-consistent replay 不是执行认证。

**外部审查应给出的证据或条件：**

- 预声明候选集、seed、终止预算与统计目标；保留horizon未到、trace截断、zero-M、exhaustion、失败和timeout。
- 独立评审者从原始源码/数据重导出资源和完整trace，不只读audit_execution的部分计数上界。
- 逐项记录 ACCEPT_CONDITIONAL / REJECT / NEED_EVIDENCE、接受的假设、反例、剩余风险与适用profile；内部自测或本次agent审阅不能冒充外部独立签收。

当前源码：[quantum_network_sim.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/quantum_network_sim.py)；[quantum_resource_clock_campaign.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/experiments/quantum_resource_clock_campaign.py)；[quantum_adversarial_campaign.py](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/ea909124cc460f364bd17b009073306014133f48/formal/pon-nakamoto-v1/experiments/quantum_adversarial_campaign.py)。

## 6. 交付与签收规则

建议审查顺序：先固定全部跨仓源、依赖、密码 profile、材料与实际 binary；再使用本包已核对的历史组件账本，将合法策略和真正 cheap-invalid 的共同材料／target／reuse 范围对齐；继而核对当前候选原预算的实际服务与 history 结果；最后对量子 predicate／marked count／物理参数和 DAA／重组映射逐条记录决定。若只接受组件或条件模型，接受范围应精确写明，不扩展为端到端或协议迁移批准。

外部评审每项应记录 `ACCEPT_CONDITIONAL`、`REJECT` 或 `NEED_EVIDENCE`，并附评审者身份、源码／artifact 固定值、接受的假设、未接受的主张及日期。当前所有外部决定均为 `PENDING_EXTERNAL_REVIEW`。既有 CI 的 source/job pass、本次内部审读和 JSONL 一致性核对均不填写该签收。

主要交付文件：

- [cost-evidence-table.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/independent-review-package-ea909/cost-evidence-table.json)：25 个源码 pin、12 成本项、15 W1／量子／DAA 评审项及历史失败／工作流完整状态。
- [fixed9f-v5-raw-analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/independent-review-package-ea909/fixed9f-v5-raw-analysis.json)：全部 66 shards、1,122 arms、逐 scope／case／path 成本与实际文件摘要。
- [fixed9f-v5-x64-13555294305.zip](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/independent-review-package-ea909/fixed9f-v5-x64-13555294305.zip)：未经改写的 GitHub 原始 artifact。
- [analyze_fixed9f_v5.py](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/independent-review-package-ea909/analyze_fixed9f_v5.py)：只读原始记录重算程序；不运行 native W1。
- [receipt-index.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/independent-review-package-ea909/receipt-index.json)：交付文件字节数与 SHA256 索引。
