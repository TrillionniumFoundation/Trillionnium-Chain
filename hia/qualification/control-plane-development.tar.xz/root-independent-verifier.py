from pathlib import Path
from collections import Counter
import hashlib
import json
import struct

ROOT = Path('/workspace/scratch/a638c5cc4765/Trillionnium-Chain')
RUN = Path('/workspace/scratch/a638c5cc4765/control-plane-work/run6')
DEST = Path('/workspace/scratch/a638c5cc4765/control-plane-final-readback.json')

def sha(data):
    return hashlib.sha256(data).hexdigest()

files = {}
for path in sorted(RUN.rglob('*')):
    assert not path.is_symlink(), path
    if path.is_file():
        raw = path.read_bytes()
        files[path.relative_to(RUN).as_posix()] = {'bytes': len(raw), 'sha256': sha(raw)}
        if path.parent.name == 'blobs':
            assert path.name == sha(raw), path

report = json.loads((RUN / 'observations.json').read_text())
start = json.loads((RUN / 'run-start.json').read_text())
assert report['schema'] == 'trnm.hia.control-plane.development.v1'
assert report['result'] == 'PASS' and report['finalized'] is True
roster = report['expected_test_methods']
assert len(roster) == len(set(roster)) == 15
assert roster == start['expected_test_methods'] == report['started_test_methods']
assert roster == [r['method'] for r in report['completed_test_methods']]
for row in report['completed_test_methods']:
    assert row['passed'] is True
    assert all(type(x) is int and x == 0 for x in row['unittest_outcomes'].values())
for field in ('whole_package_retired', 'signature_provider_implemented', 'node_integration_complete'):
    assert report[field] is False

ref_count = 0
def raw(ref):
    global ref_count
    assert set(('path', 'size', 'sha256')) <= ref.keys()
    assert type(ref['size']) is int and ref['size'] >= 0
    assert ref['path'] == 'blobs/' + ref['sha256']
    info = files[ref['path']]
    assert (info['bytes'], info['sha256']) == (ref['size'], ref['sha256'])
    ref_count += 1
    return (RUN / ref['path']).read_bytes()

def validate_refs(value):
    if isinstance(value, dict):
        if set(('path', 'size', 'sha256')) <= value.keys():
            raw(value)
        for child in value.values():
            validate_refs(child)
    elif isinstance(value, list):
        for child in value:
            validate_refs(child)

validate_refs(report)
source_map = {}
for ref in report['source_inputs']:
    data = raw(ref)
    path = ref['source_path']
    assert data == (ROOT / path).read_bytes()
    assert ref['sha256'] == ref['before_sha256'] == start['source_before'][path]
    source_map[path] = ref['sha256']
assert len(source_map) == 11

artifacts = {}
for report_file, binary in [('native-build.json', 'native.so'), ('registry-build.json', 'registry.so')]:
    build = json.loads((RUN / report_file).read_text())
    assert build['ok'] is True
    assert files[binary]['sha256'] == build['artifact_sha256']
    assert files[binary]['bytes'] == build['artifact_bytes']
    for pin in build['chain_migration']['inputs']:
        assert sha((ROOT / 'hia' / pin['path']).read_bytes()) == pin['sha256']
    artifacts[binary] = files[binary]
original_build = json.loads((RUN / 'original-build.json').read_text())
assert original_build['executable_sha256'] == files['original']['sha256']
assert all(row['returncode'] == 0 for row in original_build['commands'])
assert any('5 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in r['stdout']
           for r in original_build['commands'])
for name in ('original', 'original-tests', 'allocator-observer/alloc-observer'):
    artifacts[name] = files[name]

oracle = Counter()
for process in report['oracle_processes']:
    assert process['returncode'] == 0
    assert process['executable_sha256'] == files['original']['sha256']
    inputs = raw(process['stdin']).decode().splitlines()
    outputs = raw(process['stdout']).decode().splitlines()
    assert len(inputs) == len(outputs)
    for given, received in zip(inputs, outputs):
        status, output = received.split(' ', 1)
        oracle[(bytes.fromhex(given), int(status), b'' if output == '-' else bytes.fromhex(output))] += 1

actual = Counter()
allocator_count = 0
for observation in report['native_observations']:
    assert observation['returncode'] == 0
    if observation.get('allocation_observer'):
        allocator_count += 1
        data = raw(observation['stdout'])
        status, calls, denied, live = struct.unpack('<4Q', data[:32])
        assert live == 0 and denied == int(status == 103)
        assert len(data) == 32 + observation['output_capacity']
        assert raw(observation['observer_executable']) == (RUN / 'allocator-observer/alloc-observer').read_bytes()
        if status:
            assert data[32:] == b'\xa5' * observation['output_capacity']
        continue
    assert observation['status'] == 'returned'
    assert observation['abi_status'] == 0
    before = [raw(x) for x in observation['arguments']]
    after = [raw(x) for x in observation['observed_arguments']]
    assert before[0] == after[0]
    actual[(observation['module'], before[0], observation['value'], after[1])] += 1

matched = 0
registry_commands = 0
for case in report['cases']:
    if 'original_compared' not in case:
        continue
    assert case['original_compared'] is True
    data, expected = bytes.fromhex(case['input']), bytes.fromhex(case['output'])
    assert case['native_status'] == case['status']
    assert bytes.fromhex(case['native_output']) == expected
    key = (data, case['status'], expected)
    assert oracle[key] > 0
    oracle[key] -= 1
    capacity = 45 if case['module'] == 'core' else max(45, len(expected) + 13)
    output = expected + b'\xa5' * (capacity - len(expected)) if case['status'] == 0 else b'\xa5' * capacity
    native_key = (case['module'], data, case['status'], output)
    assert actual[native_key] > 0
    actual[native_key] -= 1
    matched += 1
    if case['module'] == 'registry' and case['status'] == 0:
        assert data[:8] == b'NCPR0001'
        registry_commands += struct.unpack('<Q', data[8:16])[0]
assert type(report['native_calls']) is int and report['native_calls'] == len(report['native_observations']) == 2577
assert type(report['original_comparisons']) is int and matched == report['original_comparisons'] == 2564
assert allocator_count == 7
assert sum(oracle.values()) == 2  # Additional reference outputs for OOM/capacity controls.
assert sum(actual.values()) == 6  # Two capacity and four registry transport controls.
assert registry_commands == 1542

result = {
    'schema': 'trnm.hia.control-plane-independent-readback.v1',
    'result': 'PASS', 'run': 'run6', 'runtime_reexecuted_by_reader': False,
    'complete_files_read': len(files), 'logical_bytes_read': sum(v['bytes'] for v in files.values()),
    'report_sha256': files['observations.json']['sha256'],
    'source_inputs_verified': source_map, 'finalized_tests': len(roster),
    'native_calls_verified': report['native_calls'], 'actual_original_pairs_verified': matched,
    'additional_original_control_outputs': 2, 'additional_native_transport_controls': 6,
    'private_registry_commands': registry_commands, 'allocator_observer_runs': allocator_count,
    'original_retained_tests': 5, 'blob_references_verified': ref_count,
    'artifacts': artifacts, 'whole_chain_native': False,
    'old_stack_can_be_removed': False, 'production_activation': False,
}
DEST.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
