from pathlib import Path
import concurrent.futures,hashlib,json,os,re,subprocess,sys,threading,time
root=Path('/private/tmp/chain-final-current-bindings-20261114')
out=Path('/private/tmp/chain-final-current-bindings-evidence-20261114/validation-v1')
out.mkdir();(out/'pid.json').write_text(json.dumps({'pid':os.getpid(),'started':time.time()})+'\n')
env={**os.environ,'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','GIT_NO_LAZY_FETCH':'1','TMPDIR':'/private/tmp/chain-final-current-bindings-evidence-20261114/final-checkpoint-v1/canonical-tmp','PYTHONDONTWRITEBYTECODE':'1'}
def sha(b):return hashlib.sha256(b).hexdigest()
lock=threading.Lock();results=[]
def check(name,args,expected=0):
    start=time.time()
    with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:
        result=subprocess.run(args,cwd=root,env=env,stdout=so,stderr=se,check=False)
    stdout=(out/(name+'.stdout')).read_bytes();stderr=(out/(name+'.stderr')).read_bytes()
    row={'name':name,'args':args,'expected_exit':expected,'exit':result.returncode,'passed':result.returncode==expected,'seconds':time.time()-start,'test_counts':[int(x) for x in re.findall(rb'Ran (\d+) tests?',stderr)],'stdout':{'bytes':len(stdout),'sha256':sha(stdout)},'stderr':{'bytes':len(stderr),'sha256':sha(stderr)}}
    with lock:
        results.append(row);(out/'steps.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
        print(json.dumps(row),flush=True)
    return row
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,env=env,text=True).strip()=='5c04c60e463462d9df8884786e0d5bb32af08a64'
assert check('00-preflight',['bash','scripts/project-preflight.sh'])['passed']
before={p:sha((root/p).read_bytes()) for p in subprocess.check_output(['git','diff','--name-only'],cwd=root,env=env,text=True).splitlines()}
(out/'selected-edited-source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
# Independent subprocesses read the same fixed candidate; test fixtures are private.
jobs=[
('01-authority-controls',[sys.executable,'scripts/ci/test_pq_authority_effect_register.py','-v']),
('02-root-dependency-controls',[sys.executable,'scripts/ci/test_pq_root_dependency_register.py','-v']),
('03-profile-controls',[sys.executable,'scripts/ci/test_pq_proof_profile_binding.py','-v']),
('04-upstream-controls',[sys.executable,'scripts/ci/test_w1_upstream_security.py','-v']),
('05-route-controls',[sys.executable,'scripts/ci/test_w1_stark_route_audit.py','-v']),
('06-workflow-gate-controls',[sys.executable,'scripts/ci/test_w1_qrom_workflow_gate.py','-v']),
]
named=out/'qrom-current-named';named.mkdir()
jobs.append(('07-current-named-controls',[sys.executable,'scripts/ci/w1_qrom_current_ci.py','named','--repo-root',str(root),'--out',str(named)]))
closure=out/'qrom-closure-current';closure.mkdir()
closure_digest=sha((root/'config/pon/w1-qrom-closure-current-required-tests-v2.json').read_bytes())
jobs.append(('08-closure-current-controls',[sys.executable,'scripts/ci/w1_qrom_closure_current_controls.py','run','--root',str(root),'--roster-sha256',closure_digest,'--output',str(closure)]))
jobs.append(('09-corpus-controls',[sys.executable,'scripts/ci/test_pq_research_integration.py','-v']))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    futures=[pool.submit(check,*job) for job in jobs]
    for f in futures:f.result()
after={p:sha((root/p).read_bytes()) for p in before}
assert before==after,'selected candidate inputs changed during controls'
(out/'selected-edited-source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
summary={'source_base':'5c04c60e463462d9df8884786e0d5bb32af08a64','steps':results,'all_expected_exits':all(x['passed'] for x in results),'edited_inputs_before_after_equal':True,'rust_tests_executed':False,'source_inputs_scope':'30 reviewed edited candidate paths; each reader separately checks its named source inputs'}
(out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({'all_expected_exits':summary['all_expected_exits'],'steps':len(results),'failed':[x['name'] for x in results if not x['passed']]}),flush=True)
sys.exit(0 if summary['all_expected_exits'] else 1)
