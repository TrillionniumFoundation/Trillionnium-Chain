# Ordinary pool run: same-input pre-fix fixture

Status: source construction, exact hook erasure, patch applicability and formatting checked. **No native build or test has been run for this candidate.** Expected failures below are source-derived until the actual pinned harness runs.

## Base and reconstruction

H0 starts from G2 `7d6567b92575d1d84766afd49d0720b6f197b0e0`. `old-production/` preserves the exact four inspected Rust files; every byte was checked against that Git commit. `tests-only.patch` changes only three files by adding `#[cfg(test)]` observation hooks and the module declaration, plus the new `pool_run_control_tests.rs`. It does not change `error.rs`, ordinary function signatures, progress callbacks, CPU budgets, SQL, admission or execution behavior. The new test body does not reference the new fixed-only `MiningRunStopped` enum or controlled APIs.

Rebuild with `python3 build_prefixtest.py`. `h0-source/` contains the resulting source files for publication onto an otherwise complete G2 checkout. Each old file is reproduced byte-for-byte by removing the exact hook insertions. An independent `git apply --check`, actual apply into a temporary copy, and byte comparison to `h0-source/` succeeded. `h0-binding.json` records the source, test and patch digests. `unchanged-g2-inputs.json` confirms that the prior seven-test inputs, Cargo graph/lock and toolchain pin are unchanged in the working candidate.

## Identical hooks and actual causes

The three runner stages are `pool-batch`, `prepare`, and `batch-revalidation`. Their test-only observer receives the existing run's actual absolute `end`; it cannot replace that value. The state hook runs immediately before the existing 256-row progress checkpoint in the actual SQLite scan. It sets the caller's original AtomicBool after 256 rows, or blocks until the actual original five-second run deadline. Fixed code must exit there. Old code has no callback connected and continues to a later 512-or-more row checkpoint. The fixture asserts that the intended stage and signal were actually reached; early expiry, failed proof search, setup errors, missing hook or a zero-test result cannot count as the expected counterexample.

The pool-execution hook sets the same stop bit immediately before the actual existing prefix executor. It counts completed outputs after that signal. Fixed code must return its Cancelled branch and preserve the queued record; old code completes both the reconciliation and batch-selection previews. This is actual M06 with a real signed transaction, not a synthetic execution result.

The SQL/native failure control uses an actual SQLite trigger and noncanonical task field bytes. A different thread sets the actual stop bit only after the native operation has returned its real error, before classification. Both H0 and fixed must retain that failure. The SQL message deliberately equals the cancellation diagnostic; quoted text must not grant local cancellation identity.

The completion control uses actual proof generation, admission, activation, exact packet bytes against the original make APIs, and cold reopen. A trigger fails final pool reconciliation after activation; both sources must retain the committed native packet/state and recover cache classification from the actual generation. It does not make post-activation work cancellable.

## Required native gate

Use the exact Rust 1.95.0 pin, identical Cargo.lock and release profile. Build the lib-test harness once for each complete source, record its source/executable hashes and profile, list the seven exact tests, and run each with `--exact --nocapture --test-threads=1`. `expected-controls.json` gives complete names and expected assertion sites. H0 requires five specified failures and two passes; fixed requires seven passes. Reject arbitrary exit 101, missing names, ignored tests, malformed output, setup panics and failures at any other assertion. Also run the retained `tests/pool_mining.rs` integration tests on fixed; its blocked-SQL diagnostic now records zero selected transactions when no complete batch exists.

## Scope

The implementation threads only the existing stop/end into pre-admission batch, prepare and repeated validation. It carries existing restricted-owner guards and supplied worker accounting through controlled helpers, while the ordinary runner uses its existing unmetered `&()` accounting. No public CPU domain or new credit is created. `stage_preemption` remains false. SQLite calls, indivisible computation and the durable admit/activate/final-reconcile sequence can exceed that cooperative deadline. These controls are not a service campaign, TPS result or proof of full confirmation liveness.

## Narrowed candidate continuation (2026-11-11)

This directory preserves the original fixture and adds a source readback for the narrowed pool candidate. The original sibling `pool-run-control-prefixtest/` has not been overwritten. The H0 base, all H0 source bytes, identical pool test body, nine test-only hooks and `tests-only.patch` are unchanged; reconstruction and actual patch application were repeated successfully.

The only production change since the prior review is in `store/mempool.rs`: the shared `pool_reconcile_parent_with_control` body is now byte-identical to G2. Group loading and group classification add no new checks to the existing public Submit control. The caller-only control reads the parent before combining the original owner permit. Ordinary pool mining supplies its same lightweight stop/end callback there and in its outer group reads; existing public wrappers supply no-op progress. Original owner-permit and caller controls remain at the original preview and persistence checkpoints. This avoids adding parent/group Host sampling to non-pool-run public operations.

The earlier `unchanged-g2-inputs.json` remains a historical snapshot. Another authorized continuation has since changed the independent History test input; it must not be represented as the current whole-tree state. The pool test itself remains byte-identical across H0, H1 and the retained same-test copy. `narrowing-readback.json` gives all six current pool-file hashes. No native execution occurred during this narrowing.

The native gate remains five specified H0 failures plus two H0 passes, then seven fixed passes. Compound negative tests demonstrate their first failing case only; do not report every backend/material/deadline permutation as an executed H0 failure. All fixed-case permutations still must execute successfully. The retained integration blocked-SQL test still uses the same raw and real 250 ms wait; an interrupted incomplete batch now records zero selected transactions.
