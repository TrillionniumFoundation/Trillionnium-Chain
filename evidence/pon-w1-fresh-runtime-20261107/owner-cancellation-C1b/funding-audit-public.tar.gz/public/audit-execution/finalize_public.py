#!/usr/bin/python3
"""Package only explicit public audit artifacts. Never reads a private DB/dump."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import sys
import tarfile

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
OUT = ROOT / 'owner-cancel-state-audit-02'
REPORT_SHA = 'fdf24c78021513e1ba544c5838009351afe2c61fdf50d02ce2a83e7ffa690d93'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open('xb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())


def encode(v):
    return (json.dumps(v, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def read(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > 1024 * 1024:
        raise ValueError('bounded regular public file only')
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), 'rb') as stream:
        raw = stream.read(1024 * 1024 + 1)
    after = path.lstat()
    if len(raw) != before.st_size or any(getattr(before, x) != getattr(after, x)
                                         for x in ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')):
        raise ValueError('public file changed')
    return raw


def main():
    os.umask(0o077)
    facts = json.load(sys.stdin)
    terminal = json.loads(facts['analysis-terminal.json'])
    if not (terminal['job_id'] == '1a1b819cf5a-12894-d46' and terminal['state'] == 'succeeded'
            and terminal['exit_code'] == 0 and terminal['output_complete'] is True
            and terminal['output_durable'] is True and terminal['cancelled'] is False
            and terminal['timed_out'] is False):
        raise ValueError('actual analysis terminal required')
    raw = read(OUT / 'public/state-readback.json')
    if sha(raw) != REPORT_SHA or json.loads(raw)['analysis_complete'] is not True:
        raise ValueError('completed actual report pin')
    for name, raw in facts.items():
        if Path(name).name != name or not isinstance(raw, str):
            raise ValueError('raw evidence filename/string')
        write(OUT / 'public/audit-execution' / name, raw.encode('utf-8'))
    write(OUT / 'public/audit-execution/finalize_public.py', Path(__file__).read_bytes())
    readme = '''# Trial02: independent closed-state audit

Source: C1b `0f18f93f2d35b62c6ca6d63faf4f336d55cbf4bf`, tree `94334bb6b52cfd13040059a5e71f47d8cc9603f2`.
Original operation: `ebe3c586d634730e7464f2e3661aea37f6ed7402c0d74f1a695224510d2e2f5e`.

The original costly generation/cancel entry and separate cold entry both reached actual succeeded/exit 0, complete and durable terminal states. This audit then copied four closed SQLite files as ordinary bytes and opened only those new private copies with `mode=ro&immutable=1` and query-only enabled. Original DB hashes and absent sidecars were checked before and after. It performed zero Node/M12/target method calls, transaction submissions, generation dispatches or proofs.

## Actual request and persistent state

The real target request contains all 339 configured executable/source pins, checked by exact reconstruction from the original config. It is 68,944 raw UTF-8 bytes (SHA256 `d1cf5f237edb4b2d24cd8136e51064a3fce1493fe186ca7d572814c989f77cf6`) and 66,585 canonical bytes (SHA256 `090361c6425009b00738aa06e14d045ab16b68498a9ce36536424f768000e0e2`). This exceeds the former 64 KiB limit and satisfies the new explicit 128 KiB raw-file policy. The persisted target BLOB equals those canonical bytes.

M12 contains exactly Prepare, Intent, BindJob and Cancel, one of each. All event sequence numbers, hash-chain roots and Borsh payload lengths/field boundaries were checked against the fixed source. Statement, operation, original job, cancellation reason, original deadline and owner assignment remain bound. There is no Verified, Failure, Settlement or Payment event. Cold begin is Pending. The original resource cap remains reserved; unknown GPU use is not replaced with zero and does not authorize credit or provider payment.

The native chain has exactly genesis -> Reserve -> Cancel. The height-2 stored packet is byte-identical to the original retained signed Cancel packet and occurs once in that canonical history. Owner nonces are 0 -> 1 -> 2. Task remaining is 1000 after Reserve and 0 after Cancel; status is cancelled. This is one canonical effect, not a newly executed duplicate-wire rejection test. The separate cold entry submitted no new native transaction.

| Native owner transition | Balance before | Balance after | Net change |
| --- | ---: | ---: | ---: |
| Reserve | 10,000,000 | 9,998,581 | -1,419 |
| Cancel | 9,998,581 | 9,999,290 | +709 |
| Combined | 10,000,000 | 9,999,290 | -710 |

Gross NativeTask principal returned is 1000. It is not the +709 net account change, a provider payout or M12 resource credit. The 419/291 balance residuals are arithmetic from those rows; this audit did not separately decode wire fee fields. Neither canonical transaction block has a provider-account delta. This does not assert the provider's complete account balance.

The original target operation is terminal/cancelled with sticky veto; cold reconciliation retained the same request, worker identity and result and permits no redispatch/payment. The primary recorded child cgroup was recursively empty, direct child reaped, and the separate post-job snapshot found the named original scopes absent. Historical all-descendants wait/reap and complete resource accounting remain unknown. One real costly proving stage started; this cancellation trial produced zero new complete proofs.

## Scope and retained failures

This is an independent byte/schema/hash-chain/canonical-row audit. It does not rerun native signature verification, decode the whole Packet transaction list, manufacture a completed segment, execute another cold entry, or prove pre/post-cold DB byte identity (this audit took no pre-cold DB snapshot). The original native entry performed its own real consensus admission and the original cold entry observed that same packet.

The separate trial02 prelaunch preparation failure is retained. It occurred before a proof deadline, NativeTask funding or target dispatch. Audit setup also retains two failed create-only writes before the new external parent directory existed and a failed private-copy row inspection that omitted genesis packet=NULL handling; the corrected inspection and final analysis used the same private copies and did not mutate or rerun the original operation.

## Publication boundary

Publish only `PUBLIC-ALLOWLIST.json` and its exact files, or the generated public-only archive. The four SQLite copies and full private dumps under `private-analysis-only/` are deliberately excluded. No original Node DB, private keys or complete private state are included. Public artifacts contain normalized task/owner account deltas, original DB hashes, exact public wire/packet bytes, source excerpts, actual raw reports and unmodified connector content.text strings. Large u64 connector fields were not parsed and reserialized in JavaScript.
'''
    write(OUT / 'public/README.md', readme.encode())
    collection = json.loads(read(OUT / 'collection.json'))
    original_map = []
    for pin in collection['original_files']:
        p = Path(pin['path'])
        if p.suffix == '.sqlite' or '.sqlite.' in p.name:
            continue
        relative = p.relative_to(ROOT)
        destination = OUT / 'public/raw' / relative
        if destination.exists():
            original_map.append({'public_path': str(destination.relative_to(OUT)), 'original_path': pin['path'],
                                 'bytes': pin['bytes'], 'sha256': pin['sha256']})
    original_map.append({'public_path':'public/raw/scope-after.json',
                         'original_path':str(ROOT/'owner-cancel-observation-02/scope-after.json'),
                         'bytes':2504,'sha256':'9287032cba5f84b9b03af34ac4937f232bfca4731339438bd30c8b3753899f6a'})
    write(OUT / 'public/original-path-map.json', encode({'schema':'TRNM-W1-PUBLIC-ORIGINAL-MAP1','files':original_map,
        'source_originals_origin': 'immutable git objects at 0f18f93f2d35b62c6ca6d63faf4f336d55cbf4bf',
        'prelaunch_failure_mapping':'public/prelaunch-failure/ relative to ROOT/owner-cancel-preparation-failure-02/',
        'private_db_contents_included':False}))
    files = []
    for path in sorted((OUT / 'public').rglob('*')):
        if path.is_dir():
            continue
        if path.suffix == '.sqlite' or '.sqlite.' in path.name or 'private-analysis-only' in path.parts:
            raise ValueError('private database in public tree')
        raw = read(path)
        files.append({'path':str(path.relative_to(OUT)),'bytes':len(raw),'sha256':sha(raw)})
    allow = {'schema':'TRNM-W1-CANCEL02-PUBLIC-ALLOWLIST1','root':str(OUT),
             'files':files,'file_count':len(files),'total_bytes':sum(v['bytes'] for v in files),
             'excluded':['private-analysis-only/**','original Node/M12/target SQLite databases','private keys'],
             'publication_complete_for_listed_files':True,'full_private_database_publication':False}
    allow_raw = encode(allow); write(OUT/'PUBLIC-ALLOWLIST.json',allow_raw)
    archive = OUT/'public-evidence.tar.gz'
    with archive.open('xb') as stream:
        with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as zipped:
            with tarfile.open(fileobj=zipped,mode='w|',format=tarfile.PAX_FORMAT) as tar:
                for row in files+[{'path':'PUBLIC-ALLOWLIST.json','bytes':len(allow_raw),'sha256':sha(allow_raw)}]:
                    raw=read(OUT/row['path'])
                    if len(raw)!=row['bytes'] or sha(raw)!=row['sha256']:
                        raise ValueError('public file changed before archive')
                    info=tarfile.TarInfo(row['path']);info.size=len(raw);info.mode=0o600;info.mtime=0
                    tar.addfile(info,io.BytesIO(raw))
        stream.flush();os.fsync(stream.fileno())
    archived=read(archive)
    receipt={'schema':'TRNM-W1-CANCEL02-PUBLIC-PACKAGE1','publication_complete':True,
             'public_files':len(files),'public_bytes':allow['total_bytes'],
             'allowlist':{'path':str(OUT/'PUBLIC-ALLOWLIST.json'),'bytes':len(allow_raw),'sha256':sha(allow_raw)},
             'archive':{'path':str(archive),'bytes':len(archived),'sha256':sha(archived)},
             'state_report_sha256':REPORT_SHA,'private_material_archived':False}
    write(OUT/'publication.json',encode(receipt))
    print(json.dumps(receipt),flush=True)


if __name__=='__main__':
    main()
