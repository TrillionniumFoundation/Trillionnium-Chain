from pathlib import Path
from datetime import datetime,timezone
import subprocess,time,resource,json,hashlib,sys,traceback
root=Path('/home/qian-qi/work/chain-native-owned-append-f0-20261119-2e9b');out=root/'automatic-ci-timepoint-recovery-2';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);snapshot=json.loads((root/'automatic-ci-at-f0-1/SNAPSHOT.json').read_text());failures=snapshot['api_failures'];assert len(failures)==1 and failures[0]['name']=='job-135360701667-log';job=135360701667;row=failures[0];res={'schema':'chain-original-ci-failed-log-read-recovery-v1','head':snapshot['head'],'job_id':job,'original_failed_read':row,'original_partial_read_retained':True,'business_or_ci_reexecuted':False,'complete':False,'retry_count':1}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
save();t=time.monotonic();cpu=resource.getrusage(resource.RUSAGE_CHILDREN)
try:
 so=out/'job-135360701667-log.stdout';se=out/'job-135360701667-log.stderr';res['started_utc']=datetime.now(timezone.utc).isoformat();save()
 with so.open('xb') as a,se.open('xb') as b:rc=subprocess.call(['/usr/bin/gh','api',row['endpoint']],stdout=a,stderr=b)
 c=resource.getrusage(resource.RUSAGE_CHILDREN);res.update(exit_code=rc,complete=rc==0,wall_seconds=time.monotonic()-t,child_user_cpu_seconds=c.ru_utime-cpu.ru_utime,child_system_cpu_seconds=c.ru_stime-cpu.ru_stime,stdout={'file':str(so),'bytes':so.stat().st_size,'sha256':sha(so.read_bytes())},stderr={'file':str(se),'bytes':se.stat().st_size,'sha256':sha(se.read_bytes())});save();print(json.dumps(res),flush=True);sys.exit(rc)
except BaseException as e:
 if not isinstance(e,SystemExit):res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc())
 raise
