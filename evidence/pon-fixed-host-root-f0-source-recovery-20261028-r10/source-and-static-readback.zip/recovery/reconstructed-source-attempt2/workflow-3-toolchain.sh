set -euo pipefail
rustup toolchain install 1.95.0 --profile minimal --component clippy --component rustfmt 2>&1 | tee "$OUT/toolchain-install.log"
rustc +1.95.0 -Vv > "$OUT/rustc-version.txt"
cargo +1.95.0 -Vv > "$OUT/cargo-version.txt"
cargo +1.95.0 fetch --locked --manifest-path trillionnium/Cargo.toml --target x86_64-unknown-linux-gnu 2>&1 | tee "$OUT/dependency-fetch.log"
