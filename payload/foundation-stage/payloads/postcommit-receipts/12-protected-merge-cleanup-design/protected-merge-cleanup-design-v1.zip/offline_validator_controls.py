"""Synthetic pure-function controls only; no Git hook or remote mutation."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

def run_controls(module_path):
    spec = importlib.util.spec_from_file_location("offline_deletion_draft", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    zero = "0" * 40
    url = "https://github.com/TrillionniumFoundation/Trillionnium-Chain.git"
    plan = {
        "schema": "TRNM_DELETE_ADVERTISEMENT_PLAN_V1",
        "remote_name": "origin", "remote_url": url,
        "protected_refs": ["refs/heads/main",
                           "refs/heads/fix/chain-bulk-state-tree-20261017"],
        "expected_deletions": [
            {"ref": "refs/heads/offline-fixture-a", "old_oid": "1" * 40},
            {"ref": "refs/heads/offline-fixture-b", "old_oid": "2" * 40},
        ],
    }
    enc = lambda value: (json.dumps(value, sort_keys=True) + "\n").encode()
    raw = enc(plan)
    digest = hashlib.sha256(raw).hexdigest()
    args = ("origin", url)
    lines = [f"(delete) {zero} {r['ref']} {r['old_oid']}\n".encode()
             for r in plan["expected_deletions"]]
    valid = b"".join(lines)
    results = []
    for name, data in (("complete_forward", valid),
                       ("complete_reordered", b"".join(reversed(lines)))):
        answer = module.validate_deletion_advertisement(raw, digest, args, data)
        assert answer["accepted"] and answer["count"] == 2
        results.append({"name": name, "expected": "accept", "observed": "accept"})
    def reject(name, data=valid, p=raw, pin=digest, argv=args):
        try:
            module.validate_deletion_advertisement(p, pin, argv, data)
        except module.Rejected as exc:
            results.append({"name": name, "expected": "reject",
                            "observed": "reject", "reason": str(exc)})
        else:
            raise AssertionError(name + " unexpectedly accepted")
    reject("empty_stdin", b"")
    reject("missing_ref", lines[0])
    reject("duplicate_ref_same_count", lines[0] + lines[0])
    reject("extra_ref", valid + lines[0])
    reject("already_absent_old_zero", valid.replace(b"1" * 40, zero.encode()))
    reject("advanced_old_oid", valid.replace(b"1" * 40, b"3" * 40))
    reject("non_deletion_new_oid", valid.replace(zero.encode(), b"4" * 40, 1))
    reject("non_deletion_local_ref", valid.replace(b"(delete)", b"refs/heads/x", 1))
    reject("wrong_transport_url", argv=("origin", "https://example.invalid/repo.git"))
    reject("missing_hook_argument", argv=("origin",))
    reject("wrong_pinned_plan_hash", pin="f" * 64)
    reject("no_final_lf", valid[:-1])
    reject("invalid_stdin_utf8", valid[:-1] + b"\xff\n")
    reject("oversized_stdin", b"x" * (2 * 1024 * 1024 + 1))
    reject("duplicate_json_key", p=raw.replace(b'{"expected_deletions"',
           b'{"schema":"wrong","expected_deletions"'), pin=hashlib.sha256(
           raw.replace(b'{"expected_deletions"',
           b'{"schema":"wrong","expected_deletions"')).hexdigest())
    for name, ref in (("literal_main_cannot_be_replanned", "refs/heads/main"),
                      ("literal_legacy_cannot_be_replanned",
                       "refs/heads/fix/chain-bulk-state-tree-20261017")):
        changed = copy.deepcopy(plan)
        changed["protected_refs"] = []
        changed["expected_deletions"][0]["ref"] = ref
        b = enc(changed)
        replacement = valid.replace(b"refs/heads/offline-fixture-a", ref.encode())
        reject(name, replacement, p=b, pin=hashlib.sha256(b).hexdigest())
    changed = copy.deepcopy(plan)
    changed["protected_refs"].append("refs/heads/offline-fixture-a")
    b = enc(changed)
    reject("fresh_additional_protection", p=b, pin=hashlib.sha256(b).hexdigest())
    return {"schema": "TRNM_OFFLINE_DELETE_VALIDATOR_CONTROLS_V1",
            "all_passed": True, "control_count": len(results),
            "git_or_remote_calls": 0, "hook_installed": False,
            "mutation_execution_authorized_by_this_result": False,
            "results": results}
