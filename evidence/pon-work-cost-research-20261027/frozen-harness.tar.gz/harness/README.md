# Pure PoN W1 research component

This directory implements a real, byte-compatible low-rank W1 producer, an
adversarial producer-cost collector, complete execution-witness export, and
independent readback. It belongs to **PN1 / M01 under the existing sole plan**.
It is an isolated research crate, not a new consensus profile or development
roadmap. No remote repository, deployed node, task registry, reward, target,
chainwork rule, or signature policy was changed by this component.

**A transparent succinct proof backend has not been implemented or executed.**
The exported hashes and full execution witness are not computation proofs.
Full native or Python replay is explicitly reported as replay. Correct W1
execution, conjectured work-cost hardness, task eligibility, and sustained
permissionless service remain different claims. This work adds no independent
Hashcash, stake, BFT, committee, or proof-randomness lottery.

## Source identity and integration

The compiled W1 module graph is copied byte for byte from Chain commit
`4b6b8a91b6dfe41fbd7f40f40b359d535c2c4251` (#498). The original Python scalar
oracle, wire codec, configs, and actual continuity material are pinned in
`source-manifest.json`. `scripts/verify_research_sources.py` checks their Git
blob identities, including the copies actually compiled under `src/pon_work`.
It also checks the exact upstream hex 0.4.3 sources used by existing unit tests.

The concurrent integration commit
`5e797326b9c7635e43b93f97c65a309e51eafb46` already defines the canonical
`pon_work::full_relation` research guest, `PWG1` input, `PWJ1` journal and
`public_product` filter. Those reviewed sources are pinned separately in
`parallel-source-manifest.json`. Its native W1 producer/verifier implementation
differs from #498 only in the module declarations; the existing arithmetic
producer files used here have identical blobs. The old `rejection_cache`
module is not present on that concurrent branch. Its old tests are retained in
this #498 snapshot, rather than represented as current-branch behavior.

The new solver is `src/low_rank_prefix.rs`. It can be added to the existing
M01 `pon_work` module with one module declaration and the existing `sha2`
dependency; it requires no consensus wire change or new dependency. Its
constructor returns explicit `None` for unsupported matrices. Do not turn that
into an undocumented generic fallback or automatic node selection. The harness
and evidence readers are research tooling; the canonical upstream complete
relation should remain the proof guest integration point.

`scripts/export_relation_input.py` bridges a fully checked export to that
existing **49,640-byte PWG1 input**. It also emits the expected journal bytes.
Those expected bytes have no authenticity: the canonical native example or a
real pinned proof backend must execute/verify them independently.

The root workspace's boundary controls and 25 Cargo manifests were copied to
run `scripts/project-preflight.sh`. This local partial research checkout has an
allowed feature branch and canonical origin; it is not presented as the
upstream Git commit. A passing preflight does not certify the original full
workspace. Native original-workspace checks, when run, have separate logs.

## The new legal producer

For arbitrary canonical task matrices A and B of rank at most 8, the constructor
discovers exact field factorizations A=U V and B=X Y by Gaussian elimination. It
reconstructs the supplied matrices to check the factorization. No caller's rank
claim is trusted. Discovery, reconstruction, the useful product AB, allocation,
and serialization are charged to preparation in the cost collector.

The challenge-dependent matrices then have exact thin factorizations:

```
A' = [U EL] [V; ER] = L R
B' = [X FL] [Y; FR] = S T
M_b = sum(k < 8*(b+1)) R[:,k] S[k,:]
prefix_b = L M_b T
```

The producer computes **every one of the 32,768 original cumulative output
words**, retains all eight 64-by-64 prefix matrices, and hashes them in the
original `bi,bj,bk,i,j` order. It returns the original 49,188-byte PNW1 encoding.
This is neither an AB-only proof nor a sampled-prefix substitute. Its roughly
128 KiB prefix storage is an implementation tradeoff, not a protocol requirement.

Both scalar and paired-product kernels are executable. The paired identity uses
33-bit sums in u128 accumulators, canonical modular corrections and an explicit
odd-inner-dimension term. The follow-up implementation transposes dot-product
inputs and uses an exact bounded reduction for q=2^32-5. For all private callers
the accumulator is below 2^72; two uses of 2^32=5 mod q leave less than 2q, so
one subtraction is sufficient. The code checks the bound in debug builds and
tests carry boundaries and 10,000 deterministic 72-bit values against u128 `%`.
Zero dimensions, high canonical words, rank 0/1/2/4/8, complete proofs, malformed
inputs and unsupported rank-64 matrices have independent controls.

The first implementation was correct but **slower** than existing prepared
producers in the first measured campaign. That observation and its exact build
inputs remain in `evidence/build-input-v1` and `evidence/cost-v1`; it must not be
replaced with a successful performance claim. Follow-up measurements use their
own binary and evidence identity. No finite comparison establishes the globally
cheapest solver or hardware fairness.

## What the cost collector actually counts

The main corpus has 13 task-material cases, 15 producer methods, horizons 1/16/64
and three scheduling-order samples. All methods within each case use the same
complete header, target and nonce path. Target bits=4 means T=2^252-1; it is a
research target, not an assertion that the chain authorizes these headers.

Each row includes fresh method preparation, every winning and losing attempt,
header/challenge generation, complete original proof production, ticket hashing
and target comparison. Winner full-verifier cost is reported separately. Setup
is never omitted from per-win cost; zero-win cohorts report null rather than a
fabricated rate. Unsupported rows remain in the denominator. Reused nonce paths
and repeated method timings are **not independent security samples**.

Cases include zero, rank 1/2/4/8, one-zero, identity, diagonal, sparse, repeated
rows, deterministic dense, actual revision-12 continuity maintenance, and a
separately labeled old periodic fixture. The real maintenance operands are:

```
A[i] = (13*i + 17) mod 257
B[i] = (29*i + 31) mod 263
```

The `(i mod 31, 7*i mod 37)` fixture is explicitly `legacy-periodic`; it is not
relabeled as current continuity work. Matching maintenance bytes still does not
establish a live parent's admission, lease, reward or target. For every case,
`node_task_eligibility_checked=false` remains explicit.

The collector retains the first **actually timed** PNH1+PNW1 bytes for each unique
nonce, including target misses. All other timed outputs must be byte-identical to
the scalar reference and match that retained stream's SHA-256. The full first
campaign retains 832 unique records, 1,755 rows and 22,356 measured producer
calls. `scripts/check_cost_evidence.py` replays every retained relation with the
frozen Python oracle, separately checks the actual target, reconstructs corpus
materials, verifies every row's trial/winner denominator and sums all costs.
It does not authenticate a machine clock or prove that no cheaper algorithm
exists.

The shared x86-64 host is not isolated, no energy was measured, and no GPU, ARM,
ASIC, network or multi-operator campaign was executed. Linux process CPU time and
wall time are both retained. Process CPU avoids charging time when the process
was descheduled; it does not remove frequency, cache, compiler or host variation.

## Stronger false-transcript control

The original cost corpus includes explicitly rejected false trace claims. For
nonzero operands its zero C is a weaker negative control: a correct public-product
filter can reject those before transcript work. It is not evidence that a new
Node entrance can be exhausted.

The `negative` command instead computes **the correct public AB once**, charges
that actual setup and serialization, then searches false trace claims that pass
the existing ticket threshold. Every retained claim contains the correct A, B
and C. The original cheap precheck succeeds; the full original verifier rejects
`Transcript`. A separate native observation confirms all 512 transcript tiles
were traversed. All attempted trace hashes, including misses, are counted.
`scripts/check_negative_evidence.py` independently computes AB, reconstructs all
trace-search trials and confirms every complete Python replay refuses.

This demonstrates why a correct cached-product predicate is not transcript
authentication. It does not claim to have entered the actual paid Node path,
passed its task eligibility rules, depleted a ledger, earned a reward or caused
an availability failure. No hash search in this attack control is introduced as
an independent security mechanism.

## Complete witness and remaining proof boundary

`export` searches actual W1 candidates up to a caller-specified bound. It records
all misses and setup; if exhausted it retains `search.json` and returns an error.
For a winning candidate the original full verifier must accept before export.
The export contains all 318 header bytes, original PNW1 bytes, all four exact
noise streams, both noised matrices and the full 131,072-byte prefix transcript.
`CompleteStatement` derives and binds task, challenge, target, trace, ticket,
original semantic block ID and proof digest. Mutating any supplied derived field
cannot override those recomputed values. It is a research evidence statement,
not a second chain statement format or a transferable validity capability.

The independent Python reader reconstructs all noise values, all prefix values,
all hashes, canonical fields and target acceptance. It rejects altered artifacts,
nonzero FRI/proof grinding, and fabricated proof/hardness/PQ/Node qualification
flags. All grinding fields are exactly integer zero, including booleans being
rejected as substitutes. These policy checks do not substitute for a proof backend.

The exact existing N64/R8 verifier has 458,752 scalar field-product terms,
including product corrections. Typical noise expansion needs 256 SHA-256 digests
(512 compression blocks). Task binding uses 513 blocks, the ordered trace 2,049,
ticket 2, and header challenge 6. Thus the core relation plus header already
requires roughly **3,082 SHA-256 compression blocks**; full witness commitments,
statement and journal hashing add more. Rejection sampling can change the noise
count and must follow the original 128-counter bound. These are workload counts,
not measured circuit constraints or proof cost.

A complete transparent backend must establish all of these simultaneously:

1. Exact canonical input/profile/header/task/target/PNW1 witness bindings and all
   existing byte lengths and rejection-sampling rules.
2. Correct noise generation, field ranges and every cumulative prefix; proving
   just AB=C, final noised output, or a few sampled tiles is insufficient.
3. The full SHA-256 transcript, original ticket threshold and original semantic
   block ID, with proof bytes/randomness excluded from the work lottery.
4. A pinned guest image, backend/version/parameter digest, allowed hash/receipt
   types and **all additional commitment/query/proof grinding set to zero**.
5. Real cryptographic verification before authenticating the journal; malformed
   or failed proofs must not fall back into an expensive public full replay path.

The canonical field q-1 has two-adicity 1. A transparent FFT/FRI implementation
using another field therefore needs exact integer/range/carry emulation or a
carefully justified alternative arithmetization. SHA-256 must remain bit-exact.
Neither source-code similarity nor a digest of this relation pins a guest image.
Proof soundness, computational work hardness and post-quantum qualifications
require separate arguments and evidence.

The available Rust 1.95 toolchain and recovered original/new vendor graphs were
inspected; no Winterfell/Plonky3/RISC0/SP1/STWO/Miden backend is integrated here.
`evidence/backend-availability.json` records the narrow observed inventory.
The unresolved work is the actual transparent backend and full-relation
arithmetization, not an unavailable Rust compiler. No proof-generation time,
proof size, succinct-verifier cost or quantum soundness is reported as measured.
At this small W1 profile a real proof system can cost more than direct replay;
winner-only proving and a low target cannot be presumed to remove that latency.

## Commands and reproducibility

The isolated crate uses the **independent** `Cargo.lock` plus explicitly pinned
local dependency paths in `local-paths.toml`; that is separate from the original
workspace `--locked` gate. Its actual release build inputs, frozen upstream source
manifest and binary digest are retained. The shared dependency cache is read-only
and was not repaired or overwritten. Set PATH to the available official Rust
1.95 toolchain and use a private target directory:

```sh
bash scripts/project-preflight.sh
python3 scripts/verify_research_sources.py
cargo test --release --offline --config local-paths.toml
cargo build --release --offline --config local-paths.toml
python3 scripts/test_independent.py

target/release/pon-research bench /new/output/cost 3 1,16,64 \
  zero,rank1,rank2,rank4,rank8,one-zero,identity,diagonal,sparse,repeated-rows,maintenance,legacy-periodic,dense
python3 scripts/check_cost_evidence.py /new/output/cost

target/release/pon-research negative /new/output/negative 3 \
  zero,rank1,rank2,rank4,rank8,one-zero,identity,diagonal,sparse,repeated-rows,maintenance,legacy-periodic,dense
python3 scripts/check_negative_evidence.py /new/output/negative

target/release/pon-research export /new/output/winner maintenance 4 256
python3 scripts/independent_check.py /new/output/winner
python3 scripts/export_relation_input.py /new/output/winner /new/output/pwg1.bin
```

All artifact writers refuse existing output paths. Initial missing-preflight,
partial-checkout, Cargo cache/layout and compilation failures remain in evidence;
later passes do not rewrite those observations. The final test and measurement
summary is generated from actual logs and raw JSON rather than from this README.
