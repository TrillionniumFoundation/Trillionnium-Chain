import pathlib,json,re,hashlib,subprocess,shutil,time
s=pathlib.Path('/home/qq/chain-host-stat-20261118-2e9b-source');v=pathlib.Path('/home/qq/chain-native-root-body-delay-20261118-2e9b-validation');out=v/'write-complete-v4';assert not out.exists();out.mkdir();p=s/'trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs';a=s/'trillionnium/crates/trnm-pon-node/src/ingress/public_v3/work_arithmetic/tests.rs';c=s/'config/pon/pq-cross-branch-corpus-v1.json';text=p.read_text();oldarith=a.read_text();contract=re.search(r'const PUBLIC_RESOURCE_CONTRACT: &\[u8\] = b"([^"]+)";',text).group(1).encode();profile=b'public-protected-development-v3'
def H(tag,parts):
 h=hashlib.sha256();h.update(b'TRNM-PON1\0');h.update(len(tag).to_bytes(2,'little'));h.update(tag)
 for q in parts:h.update(len(q).to_bytes(4,'little'));h.update(q)
 return h.digest()
rows=json.loads((v/'signed-profile-derivation.json').read_text())['rows'];derived=[]
for row in rows:
 parts=[bytes.fromhex(h) for h in row['dynamic_parts_hex']]
 r22=H(b'public-protected-profile-v3',[profile,contract]+parts).hex();r21contract=contract[contract.index(b'resource-revision-r21'):];r21=H(b'public-protected-profile-v3',[profile,r21contract]+parts).hex();r20=H(b'public-protected-profile-v3',[profile,contract[contract.index(b'resource-revision-r20'):]]+parts).hex()
 assert (r22,r21,r20)==(row['r22'],row['r21'],row['r20']);derived.append({'bits':row['bits'],'r22':r22,'r21':r21,'r20':r20})
raw=s/'trillionnium/crates/trnm-pon-node/src/ingress/public_v3/work_arithmetic.rs';arithmetic_contract=re.search(r'\n\s*b"(fresh-empty-server-local-owner/[^"]+)"',raw.read_text()).group(1).encode();ad=json.loads((v/'arithmetic-profile-derivation.json').read_text())
for rev in ['r21','r22']:
 got=H(b'public-protected-profile-v3-arithmetic-facts-v1',[bytes.fromhex(ad['raw_'+rev]),arithmetic_contract,(64).to_bytes(8,'little'),(4194304).to_bytes(8,'little')]).hex();assert got==ad['arithmetic_'+rev]
pre=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=s,capture_output=True,text=True);(out/'preflight.stdout').write_text(pre.stdout);(out/'preflight.stderr').write_text(pre.stderr);assert pre.returncode==0
for path in [p,a,c]:
 dest=out/'before'/path.relative_to(s);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
assert hashlib.sha256(p.read_bytes()).hexdigest()=='ce94f01f68e05af543d1474a083b81c7524d45bb0fdf76d3a41f9e24af7b0085'
# Keep every predecessor literal, and add the just-retired r21 value as a signed refusal input.
for row in rows:
 expected_count=3 if row['bits']==16 else 1;assert text.count(row['r21'])==expected_count,(row['bits'],text.count(row['r21']))
 text=text.replace(row['r21'],row['r22'])
 needle='                    "'+row['r20']+'",';assert text.count(needle)==1
 text=text.replace(needle,'                    "'+row['r21']+'",\n'+needle)
text=text.replace('Fixed independent r20 SHA-256/length-framing vector','Fixed independent r22 SHA-256/length-framing vector')
text=text.replace('fn resource_revision_r21_rejects_signed_old_cookies_and_preserves_control_output_reserve()', 'fn resource_revision_r22_rejects_signed_old_cookies_and_preserves_control_output_reserve()')
text=text.replace('// Preserve exact r10-r15, r18, r19 and r20 signed predecessor inputs;\n        // combined r21 rejects them under the unchanged current signature checks.','// Preserve exact r10-r15 and r18-r21 signed predecessor inputs;\n        // combined r22 rejects them under the unchanged current signature checks.')
assert oldarith.count(ad['raw_r21'])==1 and oldarith.count(ad['arithmetic_r21'])==1
arith=oldarith.replace(ad['raw_r21'],ad['raw_r22']).replace(ad['arithmetic_r21'],ad['arithmetic_r22']).replace('current r21 resource','current r22 resource')
needle='    for (owner, cookie, predecessor) in [\n';assert arith.count(needle)==1
extra=''.join('        (\n            &'+owner+',\n            &'+cookie+',\n            "'+value+'",\n        ),\n' for owner,cookie,value in [('raw','raw_cookie',ad['raw_r21']),('arithmetic','arithmetic_cookie',ad['arithmetic_r21'])])
arith=arith.replace(needle,needle+extra)
p.write_text(text);a.write_text(arith)
receipt={'schema':'chain-r22-fixed-goldens-v1','created_at_ns':str(time.time_ns()),'signed_profiles':derived,'arithmetic':ad,'production_contract_sha256':hashlib.sha256(contract).hexdigest(),'production_contract_unchanged':re.search(r'const PUBLIC_RESOURCE_CONTRACT: &\[u8\] = b"([^"]+)";',text).group(1).encode()==contract,'prepaid_control_changed':False,'fixture_limits_changed':False,'files':{str(q.relative_to(s)):{'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()} for q in [p,a]},'source_pin_refresh_pending':True,'f0_qualified':False}
(out/'GOLDEN_DERIVATION.json').write_text(json.dumps(receipt,indent=2)+'\n')
corpus=json.loads(c.read_text());print(json.dumps({'receipt':receipt,'corpus_top_keys':list(corpus),'corpus_types':{k:type(v).__name__ for k,v in corpus.items()}},indent=2))