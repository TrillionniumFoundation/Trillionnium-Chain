#!/usr/bin/env python3
"""Independent Linux syscall probe; does not execute or qualify the Rust Node."""
import fcntl
import hashlib
import json
import os
import platform
import sys

# Linux UAPI constants from linux/fcntl.h and linux/memfd.h. The current Python
# fcntl module does not export these names even though the kernel supports them.
ADD_SEALS = 1024 + 9
GET_SEALS = 1024 + 10
NOEXEC_SEAL = 0x0008
REQUIRED_SEALS = 0x0001 | 0x0002 | 0x0004 | 0x0008 | 0x0020
BODY = b"original authenticated bytes"


def inspect(fd):
    metadata = os.fstat(fd)
    return {
        "identity": {name: getattr(metadata, name) for name in (
            "st_dev", "st_ino", "st_size", "st_uid", "st_mode",
            "st_mtime_ns", "st_ctime_ns",
        )},
        "access_mode": fcntl.fcntl(fd, fcntl.F_GETFL) & os.O_ACCMODE,
        "cloexec": bool(fcntl.fcntl(fd, fcntl.F_GETFD) & fcntl.FD_CLOEXEC),
        "seals": fcntl.fcntl(fd, GET_SEALS),
        "sha256": hashlib.sha256(os.pread(fd, 100, 0)).hexdigest(),
    }


def probe(read_only):
    fd = os.memfd_create("trnm-m15-regression-probe", os.MFD_CLOEXEC | os.MFD_ALLOW_SEALING | NOEXEC_SEAL)
    try:
        os.write(fd, BODY)
        os.fchmod(fd, 0o400)
        fcntl.fcntl(fd, ADD_SEALS, REQUIRED_SEALS)
        original_fd = fd
        before_conversion = inspect(fd)
        if read_only:
            held = os.open(f"/proc/self/fd/{fd}", os.O_PATH | os.O_CLOEXEC)
            try:
                opened = os.open(f"/proc/self/fd/{held}", os.O_RDONLY | os.O_CLOEXEC | os.O_NONBLOCK)
                try:
                    assert os.fstat(held)[:2] == os.fstat(opened)[:2]
                    # Python's dup2(..., inheritable=False) uses atomic dup3
                    # on this Linux platform; the Rust patch calls rustix dup3.
                    os.dup2(opened, fd, inheritable=False)
                finally:
                    os.close(opened)
            finally:
                os.close(held)
        baseline = inspect(fd)
        rows = []
        for name, action in (
            ("pwrite", lambda: os.pwrite(fd, b"bad", 0)),
            ("shrink", lambda: os.ftruncate(fd, 1)),
            ("grow", lambda: os.ftruncate(fd, 100)),
            ("change-executable-bits", lambda: os.fchmod(fd, 0o700)),
        ):
            before = inspect(fd)
            try:
                action()
                error = None
            except OSError as exc:
                error = {"errno": exc.errno, "message": str(exc)}
            after = inspect(fd)
            rows.append({"operation": name, "error": error, "before": before, "after": after,
                         "changed_identity_fields": [key for key in before["identity"]
                                                     if before["identity"][key] != after["identity"][key]]})
        return {"read_only_conversion": read_only, "reserved_fd_preserved": fd == original_fd,
                "before_conversion": before_conversion, "baseline": baseline, "operations": rows}
    finally:
        os.close(fd)


def main():
    rows = [probe(False), probe(True)]
    for run in rows:
        assert run["reserved_fd_preserved"]
        for op in run["operations"]:
            assert op["error"] is not None
            assert op["after"]["sha256"] == hashlib.sha256(BODY).hexdigest()
            assert op["after"]["seals"] & REQUIRED_SEALS == REQUIRED_SEALS
            if run["read_only_conversion"]:
                assert op["after"]["identity"] == run["baseline"]["identity"]
                assert op["after"]["access_mode"] == os.O_RDONLY
                assert op["after"]["cloexec"]
    result = {"schema": "trnm-m15-independent-linux-fd-regression-probe-v1",
              "kernel": platform.release(), "python": platform.python_version(),
              "native_node_executed": False, "quantum_hardware_executed": False,
              "runs": rows, "result": "PASS"}
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
