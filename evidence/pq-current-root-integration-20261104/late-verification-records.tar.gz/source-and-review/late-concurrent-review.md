# 晚到并发改动的源码复核与最小验证建议

## 固定来源与已执行结果

本说明对应最终冻结提交 `dba49c2f66d8a72d6845c70958c4a24d6c4e7e89`，tree `25ae0d2035b763b916575292d04571e93a512dd1`。这是同一工作会话内的只读源码复核，不作为独立第三方审查。

已读取 `ec2a6b96… → fc86ed8e…` 的完整 compare，并将 12 个非 evidence 文件在内存中从 ec2 原 Git blob 与 diff 重建，逐一核对 canonical Git blob ID。另直接读取 ec2 的 W1／shared-operator 对象。与 dba 最终 tree 再比较的 **14 条相关源码／测试路径全部保持相同 blob**。本轮没有修改源码、index、HEAD 或远端，也没有运行 Cargo。

已核对 [integrated-python-controls.json](../final-receipts/integrated-python-controls.json) 和 [原始日志](../final-receipts/integrated-python-controls.log)：**8 套、370 tests、75.704 秒、exit 0**；before/after 均为上述 dba commit/tree，tracked 原始字节检查一致。日志 SHA-256 为 `ca6ae4e05430694cd67c13e67af4a4cc725b0e0686d0dfae6ce429a3c3a73def`。这覆盖 source integrity、PQ integration、quantum DAA、from-zero reader、W1 staged observer、shared Cell operator、from-zero Host adapter 和 fresh-service reader。Clippy 与原生测试的结果仍由各自实际回执说明，本说明不提前计为通过。

## 变更含义与边界

| 部分 | 源码复核结论 | 仍不可据此声称 |
| --- | --- | --- |
| Public startup | 原有 listener-domain permit 前移到 Node/profile/queue 工作之前；第五个 listener 无须先等待 Node 锁。第二次 owner 获取及 Growth observation 使用同一 startup deadline／stop，失败由 RAII 归还既有许可。 | 这没有使整个启动、provider／State 工作或 durable epoch 清理成为可抢占操作，也没有证明全服务墙钟上限。 |
| Request observation | socket accept、连接 owner 关闭、task owner 关闭分别记录；OnceLock 时间先于 release close flag 发布，snapshot acquire 相应 flag 后才暴露时间。task 可以晚于断连结束，也可以早于连接输出结束。 | local clock、CPU 样本、记录完整性及 dispatch accepted 都不授予状态／付款／恢复权，也不能代替独立交易确认。 |
| M06 continuity／Growth | 无取消回调的路径按完整有序 namespace 查询；`account:` 的排除边界是 `account;`，义务顺序保持 quota/release/reward/task。公开 progress API 仍遍历原完整行源，保留每 256 行及最终发布前检查、错误优先序和账户 proof callback。 | 没有新增可复用的部分验证／continuation authority；未证明全状态 touched-key 复杂度或吞吐提升。future／zero liabilities、nonce 与完整容量仍须原生验证。 |
| W1 IMAGE_ID | Python 固定的 8 个 u32 与 Rust `image.rs` 完全相同；26 项 observer 测试包含缺失、bool／越界、每字变异、历史 guest 和重复／转义键负例。 | 修复的是报告身份绑定。Rust verifier 原先已固定 guest；不能据此宣称修复了密码学伪造、获得新完整 v2 proof，或已具 PQ 安全。 |
| Shared operator | 9 项 Python 测试覆盖全部 257 坐标含 bias、五个 tile、完整路由、canonical material、typed product／请求绑定和不完整 native 输出拒绝。 | 参考乘积和 parser controls 不是新原生执行、经济收益、未来模型效用或资金结算。 |

from-zero v2 reader 保留全部失败／迟到／缺测分母；Hello body digest 明确只是对端声明。正确认定还绑定实际交易、网络上下文、六深度 tip／work、无重组状态、返回的最终观察和接受的 History replay。原 v1 readback 仍可明确选择。CPU 的 full-work 与 dispatch 是嵌套范围，不能相加成全机器总量；未知 RSS、能耗、WAN 和磁盘增长不变成零。

fc86 的 corpus 修改仅更新 `public_v3.rs`、`request_observation.rs`、`continuity_v1.rs` 三个既有 pin。shared-material evidence 声明的实际执行来源为历史 `59321c3…`／tree `8164d7e…`；其不利 CPU 比率和 `proof_started=false` 原样保留。它们不能改归 dba 的新执行。本次未取得该历史 commit 的完整本地对象来重新鉴证其运行；对这些历史结论保留原回执范围。

## 最小新增 Node selector：三个过滤条件，六个测试

保留 canonical toolchain、provider 环境、现有 feature／test profile 和原 Host 限制。无需为这些差异运行 whole-lib timing 集合。前两项各使用 `--exact`：

```text
ingress::public_v3::intake_domain_tests::public_epoch_start_keeps_original_deadline_and_stop_while_owner_is_busy
ingress::public_v3::intake_domain_tests::one_node_cannot_spawn_a_fifth_worker_queue_service_from_the_same_domain
```

第三个过滤条件是：

```text
ingress::public_v3::request_observation::tests::lifecycle_
```

它应实际执行以下四项，不能以过滤后零测试的 exit 0 替代：

- `lifecycle_retains_disconnect_until_actual_task_owner_exits`
- `lifecycle_keeps_task_and_connection_closure_order_independent`
- `lifecycle_unknown_clock_is_not_zero_and_snapshot_cannot_block_closure`
- `lifecycle_snapshot_hides_clocks_until_their_close_publication_is_observed`

若沿用 `check_required_native_test.py` 的单测试身份要求，将以上四个名称分别加上 `ingress::public_v3::request_observation::tests::` 前缀，以 `--exact --format pretty --color never` 各执行一次，并保存实际完整日志；未执行／ignored 不算通过。前两项的两秒 `recv_timeout` 是回归死锁防护，不能被称为原四秒业务门。

这六项只覆盖新增 startup／listener／lifecycle 语义。M06 continuation／capacity 的原生结果仍由其包测试及现有 `capacity_progress` 集成测试负责。Python 测试已完成，无需把本轮扩成完整模型／性能实验；`run_shared_material_security_v1.py` 是调用 native runner 的实验驱动器，不是缺省 self-test。

## 当前生产边界

**当前 PQ 根对全部生产授权入口的约束仍未闭合。** 账户、治理、发布、恢复、CURRENT、FinalUse 必须在真实效果路径逐一证明当前外部固定的根、代际撤销和跨 profile 拒绝；本次源码保留、reader hardening、启动检查及局部测试均不能替代这个闭环。CPU／timing／Hello 观测不产生授权，历史证据不授予生产资格。

原 **4 秒／16 个恶意 W1 producer／签名交易六深度独立确认**、原 Host／CPU／内存及 **4,105 块完整恢复** 条件保持原样。F 失败由其指定分析者解释；这里不改写失败、降低 profile 或把局部测试升级为全链接受。所有全链 PQ、安全激活和独立运行方资格继续保持未获证实。
