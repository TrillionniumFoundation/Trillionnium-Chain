# M07 Branch roots, schema and owner-controlled persistence

Revision: invariant-driven revision3. Selected target: `pon-nakamoto-v1`.
[Sole development plan](../development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md); [exact invariant registry](../../config/pon/invariants-v2.json).

## Scope and ownership

Distinct fresh native-development and reference revision3 SQLite namespaces; each has one writer. Neither silently upgrades or writes the other namespace.

The claims below apply to their named component and tests, not to an independently accepted full native node.

## PoN State machine

### M07.OpenNamespace

Every owned initialization crash cut can recover; foreign incomplete databases and injected schema objects reject without writable mutation. Fsync exact initialization intent, create schema plus genesis in one transaction, remove marker after commit; compare exact schema projection on reopen.

**Atomic/commit boundary:** Fsync exact initialization intent, create schema plus genesis in one transaction, remove marker after commit; compare exact schema projection on reopen.

### M07.StageBranch

BEGIN IMMEDIATE, insert immutable block, insert changed-key deltas, COMMIT. Any failure rolls back the transaction. A restart reads complete old/new state, not partially visible rows.

**Atomic/commit boundary:** blocks+deltas one transaction; active pointer separate M08 publication.

## M07.OwnedInitialization

**Invariant:** Every owned initialization crash cut can recover; foreign incomplete databases and injected schema objects reject without writable mutation.

**Scope:** Distinct fresh native-development and reference revision3 SQLite namespaces; each has one writer. Neither silently upgrades or writes the other namespace.

**Atomic boundary:** Fsync exact initialization intent, create schema plus genesis in one transaction, remove marker after commit; compare exact schema projection on reopen.

**Failure schedule:** Intent persisted; Schema staged; Before initialization commit; After commit before marker removal; Unexpected trigger and unmarked empty database.

**Expected result:** Every owned initialization crash cut can recover; foreign incomplete databases and injected schema objects reject without writable mutation.

**Resource and retention rule:** Ordinary append writes only changed keys; one physical state slot, separate logical generation.

## Concrete regression selectors

`formal/pon-nakamoto-v1/test_invariants.py::InitializationTests.test_every_initialization_cut_recovers_only_our_exact_intent`

`formal/pon-nakamoto-v1/test_invariants.py::InitializationTests.test_unmarked_empty_database_is_not_reinitialized`

`formal/pon-nakamoto-v1/test_invariants.py::InitializationTests.test_injected_trigger_rejects_before_writable_open`

`formal/pon-nakamoto-v1/test_invariants.py::RestartForkTests.test_append_retains_one_physical_state_slot`

These exact functions contain executable assertions. The registry only checks binding; actual outcomes and source/input identities belong to the separate qualification report.

## Module-specific threat and residual work

Initialization gaps, trigger/schema substitution, disk full, path replacement and unbounded full-state copies.

Full descriptor/sidecar fencing and physical power-loss qualification remain pending.
The explicit authenticated native storage namespace below adds persistent account
updates while retaining complete native State verification.

## Current source and verification

- [`trillionnium/crates/trnm-pon-node/src/store.rs`](../../trillionnium/crates/trnm-pon-node/src/store.rs).
- [`formal/pon-nakamoto-v1/ledger.py`](../../formal/pon-nakamoto-v1/ledger.py).

No test binding or local campaign grants independent acceptance, ordinary Hepta execution or production activation. Preserve the exact source, profile and environment of every outcome.

## Executed evidence and scope

[Responsibility-level evidence navigation](README.md#responsibility-and-evidence) reads
measured commits from immutable receipts. The module's entries in
[module-maturity-v1.json](../../config/pon/module-maturity-v1.json) identify actual callable
owners, controlled entrypoints, backends, persistence and exact observed test selectors.
Run `python3 scripts/ci/report_module_evidence.py --module M07` from the repository
root to see subject-byte and complete recorded-runtime matches separately, plus scenarios
not observed in each package. A byte match is not a new test run or product acceptance.
Historical v1/v3/v4 results are never repinned. The sole plan selects further work.

## Native development continuation and remaining scope

Node is now a native single-writer fresh-namespace SQLite owner for blocks/deltas, staged KV, snapshots and active generation. Existing Python storage remains a separate oracle. Descriptor/sidecar races, physical power loss, long-run growth and incremental persistent roots remain unqualified.

The current callable mappings remain in `config/pon/module-maturity-v1.json`.
Exact native entry, storage and work behavior is specified by N3 in NETWORK_CLIENT,
the native continuation in STATE_RECOVERY and the prepared-producer section in WORK_PROFILE.
No historical receipt is relabelled as executing this source.

## Actual-state cancellation and statement reuse

The [history/state resource contract](../protocol/pon-nakamoto-v1/details/HISTORY_STATE_RESOURCE_BOUNDS_V1.md) preserves the actual KV/root check and adds cancellation every256 rows, a final tip/generation/slot check and reused delta statements. The SQLite schema and atomic transaction boundary remain unchanged. Complete root construction and retained history still have their stated growth costs.

The [authenticated account/state research companion](../protocol/pon-nakamoto-v1/details/ACCOUNT_ARCHIVE_PROTOTYPE_V1.md#authenticated-complete-state-companion)
computes a separate full-parent-bound commitment and checks proof-derived prologue
and successor aggregates. It never stores that commitment as the Node state root,
publishes an archive branch or changes this module's schema or atomic boundary.
The existing branch owner and complete native State root remain authoritative.
The separately selected native backend below supplies persistent account updates
and migration/recovery rules. Complete compact non-account obligations, retained
witness-data responsibility and growth pricing remain separate requirements.

## Explicit authenticated-state archive

The [durable research archive](../protocol/pon-nakamoto-v1/details/AUTHENTICATED_STATE_ARCHIVE_V1.md)
uses its own namespace and explicit caller operation. It imports actual native genesis,
reexecutes an admitted block through complete authenticated-state inputs and checks
full state/receipts before atomically publishing checkpoint, delta and optional selection.
CAS generations do not rewind when selecting an older branch. Missing data, altered
records, stale selection, quota exhaustion and cancellation refuse without partial
publication. Reads and reopen reconstruct complete states and compare actual native
branch data. This separate reference-backed store adds no ordinary startup selection,
installed state root, public proof service, pruning or rollback of local operation facts.

## Explicit native authenticated storage and migration

[Native authenticated storage v1](../protocol/pon-nakamoto-v1/details/NATIVE_AUTHENTICATED_STORAGE_V1.md)
is selected through `Node::open_with_authenticated_state` in a fresh storage
namespace. It keeps copy-on-write account nodes and complete state commitments in
the same `native.sqlite` transaction as admitted blocks and canonical deltas.
Genesis seeds the account tree; later actual account deltas update persistent roots
and sums, which are independently compared with the complete native State.
Active reads, historical reads, reorganization and recovery require the retained
authentication material; unavailable data does not use the legacy backend.
The ordinary opener, original DDL and consensus header root bytes retain their meaning.

Explicit migration holds a consistent source transaction and preserves the original
namespace. It copies every retained ordinary table, including local monotone facts,
and validates native branch execution before publishing a fresh destination. A
pending marker prevents either opener from accepting an incomplete destination.
External owner-journal modes require their own migration authority and are refused.
Logical equality, cancellation and process-loss tests do not establish physical
power-loss behavior or a general deployed-data migration service.

Both native storage modes now check actual block/delta/snapshot writes and the
persisted selected state before COMMIT. Selection also checks its expected
generation, event rows and reorganization state after the final write. A suppressed
write or a final write that damages the intended state cannot return a successful
publication. These checks add complete-state readback cost; no overall latency
improvement is inferred from the incremental account-node representation.


## 本轮来源绑定（Round 10）

本节补充 `M07.OwnedInitialization` 的原生后端来源绑定。
[原生认证存储](../protocol/pon-nakamoto-v1/details/NATIVE_AUTHENTICATED_STORAGE_V1.md)
按路径合并本次账户更新，在同一 owner 事务内保存最终子树。成功返回时，本次新增的
`archive_nodes` payload 均属于最终 successor；旧版本和侧分支继续保留。该承诺不覆盖
SQLite 物理页／WAL 大小或累计历史上界。取消和 SQL 拒绝可能发生在事务内部分写入之后，
由 owner 回滚；原始 parent 值、nonce 单调性及禁止账户删除的约束保持不变。

[原生 ancestry 索引](../protocol/pon-nakamoto-v1/details/NATIVE_ANCESTRY_INDEX.md)
的实际行在相关提交和恢复边界检查。独立 storage reader 从完整保留图的 parent walk
重建所有期望 jump 和 seal，包含 inactive forks；迁移两边相同的损坏不能仅凭 cell
相等通过。完整 State 校验和读取成本仍见
[状态与历史资源边界](../protocol/pon-nakamoto-v1/details/HISTORY_STATE_RESOURCE_BOUNDS_V1.md)。

完整 65,536-key 原生容量测试在普通 debug suite 中明确 ignored，必须以实际
`--release --exact --ignored` 专项执行建立证据；忽略记录及此处来源登记均不是通过。
以下绑定不授予物理断电保障、全历史保留资格或独立验收，`independent_accepted=false`。

对应完整回归 selector：

- `trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_store_batch_tests.rs::batched_paths_match_serial_versions_and_keep_every_insert_reachable`.
- `trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_store_batch_tests.rs::batched_paths_cancel_and_sql_refusal_roll_back_partial_writes_and_reopen`.
- `trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_store_batch_tests.rs::batched_paths_keep_original_parent_nonce_and_no_deletion_checks`.
- `trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_store_batch_tests.rs::native_authenticated_full_capacity_refund_entry_and_pending_reorganization_recover`.
- `trillionnium/crates/trnm-pon-node/src/native_ancestry_commit_tests.rs::real_signed_packets_reject_omitted_and_late_modified_ancestry_before_commit`.
- `trillionnium/crates/trnm-pon-node/src/native_ancestry_commit_tests.rs::restart_checks_exact_active_tip_row_set_including_genesis`.
- `trillionnium/crates/trnm-pon-node/src/native_ancestry_commit_tests.rs::activation_final_events_cannot_commit_missing_or_extra_active_ancestry`.
- `formal/pon-nakamoto-v1/test_native_authenticated_storage_oracle.py::NativeAuthenticatedStorageOracle.test_all_retained_ancestry_rows_are_reconstructed_across_inactive_forks`.
- `formal/pon-nakamoto-v1/test_native_authenticated_storage_oracle.py::NativeAuthenticatedStorageOracle.test_ancestry_missing_extra_genesis_and_unknown_rows_are_refused`.
- `formal/pon-nakamoto-v1/test_native_authenticated_storage_oracle.py::NativeAuthenticatedStorageOracle.test_resealed_wrong_ancestor_height_and_component_seals_are_recomputed`.
- `formal/pon-nakamoto-v1/test_native_authenticated_storage_oracle.py::NativeAuthenticatedStorageOracle.test_ancestry_rows_require_exact_types_and_unique_keys`.
- `formal/pon-nakamoto-v1/test_native_authenticated_storage_oracle.py::MigrationPreservationOracle.test_identically_corrupt_migration_ancestry_is_not_qualified_by_cell_equality`.


## Shared primitive, unchanged durable authority

The existing account-archive `branch` now calls M00's exact
`pon_wire::account_archive_branch_hash`. Its109-byte preimage and every resulting
node, sparse path, root and stored record retain their original meaning. Both
the native Patricia owner and complete-state reference use this primitive; the
prior storage-local implementation and an independently rebuilt full sparse tree
remain test controls. No record read, complete-state comparison, history walk,
parent binding, pre-COMMIT fence, progress callback or cold-recovery check is
removed. No new cache, store, schema, owner or conditional validity fallback is
introduced. The65,536-key state boundary and cumulative traversal remain.

Native cost observations must name their build profile. The exact default-profile
public-service test retains its original workload, deadline and global CPU budget;
passing a branch microbenchmark does not qualify that network path. The full
capacity/migration/reorganization and4,105-block history campaigns, independent
long-term DA, physical power-loss evidence and independently operated WAN remain
separate acceptance requirements. Hepta pairing must name this final source and
its actual main-merge rather than borrow a parent result.

## Complete account-root arithmetic without storage records

The existing `M07.StageBranch` / `M07.OwnedInitialization` bindings also cover
the complete account-root calculation in
[`account_root_with_lifts`](../../trillionnium/crates/trnm-pon-node/src/account_archive_prototype.rs).
Its private [digest builder](../../trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_root_digest.rs)
retains only each subtree's actual path, depth and mathematical digest. It
uses paths freshly derived from actual owners by `ordered_accounts` in the same
call, checks the original collision, partition and fork relations, and lifts
both child digests before hashing the parent. Storage-record encodings and
record-ID hashes are omitted only from
this calculation; no fake storage node or supplied root replaces checked input.

The existing bounded `LiftCache` still compares the complete
`(path, digest, source_depth, target_depth)` input. Its compiled empty hashes are
immutable mathematical constants. Identity lifts retain no entry; collisions,
full buckets and borrow conflicts retain the original mathematical fallback.
No SQL row, authorization, current-generation or successful verification verdict
is introduced into this cache. The ordinary record builder and its original
`Node::lift` loop remain independent comparison paths, alongside M00's complete
sparse-root oracle. Actual stored-node reads, State comparison, progress checks,
transaction publication, nonce, liability and recovery rules remain unchanged.

Every call still hashes, orders and rebuilds all current accounts. Complete tree
arithmetic remains O(A) in the number of account nodes after the unchanged path
sort; the sort retains its existing cost. This removes unused storage-record
work and does not close the fixed-touched-set state/history requirement.

The three ordinary controls have these exact source selectors:

- `trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_root_digest_tests.rs::native_root_digest_matches_record_and_sparse_references_after_exact_input_changes`.
- `trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_root_digest_tests.rs::native_root_digest_keeps_original_traversal_cancellation_and_collision_order`.
- `trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_root_digest_tests.rs::native_root_digest_keeps_fork_shape_and_all_lift_input_relations`.

They compare complete roots, zero-balance existence and independent balance/nonce
changes, the owner-derived ordered-row entry precondition, cancellation order
and every fork depth from 0 through 255. Internal callback parity does not add cancellation checkpoints to
the public root entry, whose original callback is a no-op.

The additional cost selector is explicitly ignored in ordinary test runs:

- `trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_root_digest_tests.rs::native_root_digest_paired_complete_root_cost_observation`.

It requires a fresh `TRNM_NATIVE_ROOT_DIGEST_COST_OUTPUT` filename and an explicit
`--exact --ignored` invocation under the original declared repository profile.
It compares the original cached
record-building path and the new cached digest path in the same binary with
separate caches and alternating order. Account State parsing, complete State
root construction, actual SQL graph checks, Host/PQ checks, network and client
confirmation are outside that measured boundary. Registration is not execution
evidence or a measured speedup; the original complete-business and independent
acceptance gates remain separate and open.

## Bounded fixed-field SQL copies in ordinary readers

The existing native storage owner uses one private `FixedSqlBlob` decoder for
32-byte identities and 64-byte cumulative work in ordinary block records,
joined confirmation/header projections, history-page child/parent records,
active-tip reads and storage-context checks. It borrows SQLite's cell, preserves
its original SQL type, and copies at most width+1 bytes before the original exact
shape validation. A one-byte sentinel is never accepted as a valid field.
Empty BLOB remains present; SQL NULL remains absence only for originally nullable
fields. All SQL conversions retain their order before parent/work/root shape
checks, including when several fields are corrupt. Missing-row and owner-stop
provenance are unchanged. No mutable row or successful validation is cached.

This bounds the owned Rust payload of the named fixed fields, not SQLite's
internal allocation, cell materialization, page reads, index comparisons, process
RSS, wall time or total state/history growth. Full packet/work/state/ancestry
validation, snapshot and transaction fences, cancellation positions, migration,
reorganization, chainwork, schemas, service budgets and the 65,536-key protocol
boundary are unchanged. No claim of constant-time history or confirmed TPS follows.

Five additive native controls reside in the existing source files under
`store::fixed_blob_read_tests` and `store::history_page::bounded_record_tests`.
They exercise real SQLite values up to 4 MiB, all SQL types, NULL/empty/exact/short
widths, multiple-damage error precedence, statement-cache sizes 0/1/16, actual
mined/admitted/activated packets in both backends, rollback, complete state and
packet equality, and cold reopen. Original controls remain mandatory. This is
not remote Sybil qualification, independent model adoption, physical power loss
or long-term DA evidence. Final-source head/actual-main-merge and paired Hepta
acceptance must execute separately on both x64 and ARM64.

The explicit [native growth reference](../development/specs/pon/PERMANENT_ACCOUNT_STORAGE_BOUNDARY.md) uses its own schema/root context with the existing full-State writer and recovery engine. Its namespace does not convert old roots or claim source-preserving migration. [Local budget obligations](../development/specs/pon/REWARD_BUDGETS_V1.md) persist separately from branch undo and confer no payment or effect authority.
