#!/usr/bin/env python3
"""Fixed-source additional continuation, never a rerun of full Node suites.
Normal-native Rust 1.95, canonical toolchain/lib loader seed, fresh shared target,
read-only fmt, strict default/workspace Clippy, three complete small packages,
complete Node PQ compile/list, and exactly the reviewed TLS25 prefix once.
Original failed/blocked records remain unchanged; no cache deletion or activation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import time


SCHEMA = "trnm-native-continuation-v1"
HOST = "x86_64-unknown-linux-gnu"
ORIGINS = {
    "https://github.com/TrillionniumFoundation/Trillionnium-Chain",
    "https://github.com/TrillionniumFoundation/Trillionnium-Chain.git",
    "git@github.com:TrillionniumFoundation/Trillionnium-Chain.git",
}
PROVIDER_FILES = {
    "bin/openssl": (8933408, "8ff7dd91270fd4a8fc377031f0fd2f2cee1cd17a32ce30e4fd773a25730a120f"),
    "include/openssl/opensslv.h": (3449, "9647fc99758cf83e3bcf11ae310894fd4911ad62bff22d8213a614df89cfedda"),
    "include/openssl/configuration.h": (4729, "406c26f93511299b264062f9f3faf0760e7a0506e91a61717c491f3c92e1a996"),
    "lib/libcrypto.a": (12381776, "dabf2189afd2e29591c5b597ac2cb9b7cd7066eaf7ce674106123614da32eb0f"),
    "lib/libssl.a": (2123138, "f355167951857505b5b0305fd2e8ea8f224fa29d780211175d32767b07234727"),
}
CACHED_TESTS = tuple("cell::content_v2::cached::tests::" + name for name in (
    "cached_materialization_binds_the_exact_multichunk_output_and_eof",
    "cache_mutation_cannot_change_owned_bytes_and_a_fresh_read_refuses_corruption",
    "self_consistent_legacy_cache_cannot_replace_the_pinned_full_payload",
    "wrapping_a_legacy_digest_cannot_materialize_actual_payload_bytes",
    "wrong_complete_manifest_pin_precedes_cache_and_output_effects",
    "manifest_profile_instance_generation_and_purpose_cannot_be_substituted",
    "transport_family_aliases_and_size_must_match_before_staging",
    "missing_or_corrupt_late_chunks_never_publish_or_refund_failed_reads",
    "chunk_order_substitution_and_false_legacy_whole_digest_refuse_publication",
    "exhausted_budget_precedes_cache_reads_and_is_not_renewed",
    "payload_budget_refusal_precedes_even_opening_an_absent_output_parent",
    "expired_deadline_precedes_pin_reservation_cache_or_output_effects",
    "expiry_during_cached_payload_read_keeps_the_original_deadline_and_budget",
    "expiry_after_sync_and_before_publication_never_publishes",
    "no_replace_preserves_existing_output_bytes_and_consumes_the_attempt",
    "no_replace_preserves_existing_and_dangling_symlinks",
))
OWNER_TESTS = tuple("store::pq_owner_rejection_tests::" + name for name in (
    "pq_account_rejects_classical_task_owner_before_any_durable_effect",
    "pq_account_rejects_classical_mining_owner_before_any_durable_effect",
    "classical_task_owner_with_signed_catalog_still_opens",
    "classical_mining_owner_with_signed_catalog_still_opens",
))
NODE_PREFIX_COUNTS = {
    "store::async_w1_generation_v2::tests::recovery_v3::": 13,
    "release_owner::sealed_tests::": 12,
    "release_owner::execution_environment::tests::": 6,
    "release_owner::service_tests::": 8,
    "operator_continuous_policy::tests::loaded_material_": 2,
    "operator_mining_policy::tests::loaded_material_": 2,
}
STATIC_ROOT_IGNORED = (
    "release_owner::native_consumer_tests::"
    "isolated_fixed_root_static_node_claim_refresh_and_revocation"
)
PQ_LISTENER_TEST = (
    "ingress::pq_network::tests::"
    "pq_account_profile_rejects_classical_listeners_with_inconsistent_backend_before_effects"
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def save(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write("\n")


def file_record(path: Path) -> dict:
    before = path.stat(follow_symlinks=False)
    require(stat.S_ISREG(before.st_mode), "not a regular file: " + str(path))
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    after = path.stat(follow_symlinks=False)
    fields = lambda item: (item.st_dev, item.st_ino, item.st_size,
                           item.st_mtime_ns, item.st_ctime_ns, item.st_mode)
    require(fields(before) == fields(after), "file changed while hashing: " + str(path))
    return {"path": str(path), "bytes": after.st_size, "sha256": digest.hexdigest()}


def disk_record(path: Path) -> dict:
    usage = shutil.disk_usage(path)
    return {"path": str(path), "total_bytes": usage.total,
            "used_bytes": usage.used, "free_bytes": usage.free}


def harness_runner(argv: list[str]) -> int:
    """Called only by Cargo; keep its cwd/env and execute the real harness once."""
    receipt: dict = {"schema": SCHEMA + "/harness", "attempts": 1,
                     "started_unix_seconds": time.time(), "exit_code": None}
    finish = None
    try:
        require(bool(argv), "Cargo did not supply a test executable")
        executable = Path(argv[0]).resolve(strict=True)
        target = Path(os.environ["TRNM_NATIVE_TARGET"]).resolve(strict=True)
        directory = Path(os.environ["TRNM_NATIVE_LOG_DIR"]).resolve(strict=True)
        mode = os.environ["TRNM_NATIVE_MODE"]
        if mode == "pq-list-tls":
            return tls_list_and_prefix(argv)
        require(mode in ("list", "run"), "invalid harness mode")
        require(os.environ.get("CARGO_PKG_NAME") in SMALL_PACKAGES,
                "ordinary full test execution is restricted to the three authorized small packages")
        require(executable.is_relative_to(target / "debug"),
                "harness did not use the required normal-native debug layout")
        expected_args = ["--format=pretty", "--color=never", "--test-threads=1"]
        if mode == "list":
            expected_args.insert(0, "--list")
        require(argv[1:] == expected_args, "unexpected harness filters or arguments")
        identity = hashlib.sha256(str(executable).encode()).hexdigest()[:20]
        stem = executable.name + "-" + identity
        logfile = directory / (stem + ".libtest.log")
        finish = directory / (stem + ".finish.json")
        require(not logfile.exists() and not finish.exists(), "duplicate harness invocation")
        receipt.update({"mode": mode, "cwd": str(Path.cwd()),
                        "executable_before": file_record(executable),
                        "argv": [str(executable), *argv[1:], "--logfile", str(logfile)],
                        "runtime_environment": {key: os.environ[key] for key in (
                            "CARGO_MANIFEST_DIR", "CARGO_PKG_NAME", "LD_LIBRARY_PATH",
                            "RUST_TEST_THREADS", "OPENSSL_DIR", "OPENSSL_STATIC",
                            "TRNM_PQ_OPENSSL", "TRNM_PQ_OPENSSL_SHA256", "TRNM_PQ_OPENSSL_VERSION",
                        ) if key in os.environ}})
        save(directory / (stem + ".start.json"), receipt)
        started = time.monotonic()
        child = subprocess.run(receipt["argv"], check=False)
        receipt["elapsed_seconds"] = time.monotonic() - started
        receipt["exit_code"] = child.returncode
        receipt["executable_after"] = file_record(executable)
        require(receipt["executable_before"] == receipt["executable_after"],
                "harness bytes changed during execution")
        if logfile.exists():
            receipt["libtest_log"] = file_record(logfile)
        else:
            receipt["error"] = "libtest did not create the outer-harness logfile"
        save(finish, receipt)
        return child.returncode if child.returncode >= 0 else 128 - child.returncode
    except Exception as error:
        receipt["error"] = f"{type(error).__name__}: {error}"
        if finish is not None and not finish.exists():
            save(finish, receipt)
        print(json.dumps({"harness_runner_failure": receipt}), file=sys.stderr, flush=True)
        return 125


def read_list(path: Path) -> list[str]:
    names = []
    for line in path.read_text(encoding="utf-8").splitlines():
        match = re.fullmatch(r"test (\S+)", line)
        require(match is not None, "unexpected non-test discovery record: " + repr(line))
        names.append(match.group(1))
    require(len(names) == len(set(names)), "duplicate discovered test name")
    return sorted(names)


def read_results(path: Path, names: list[str]) -> dict[str, dict]:
    """The final token is a known name; ignored/failure messages may be multiline."""
    known = set(names)
    result = {}
    pending = ""
    for line in path.read_text(encoding="utf-8").splitlines():
        pending += line + "\n"
        token = line.rsplit(" ", 1)[-1]
        if token not in known:
            continue
        record = pending.rstrip("\n")
        prefix = record[:-(len(token) + 1)]
        if prefix == "ok":
            outcome = "passed"
        elif prefix == "failed" or prefix.startswith("failed: ") or prefix == "failed (time limit exceeded)":
            outcome = "failed"
        elif prefix == "ignored" or prefix.startswith("ignored: "):
            outcome = "ignored"
        else:
            raise ValueError("unexpected outer-harness result record: " + repr(record))
        require(token not in result, "test executed or reported more than once: " + token)
        result[token] = {"outcome": outcome, "detail": prefix}
        pending = ""
    require(not pending, "truncated or unknown outer-harness result record: " + repr(pending))
    return result



FIXED_HEAD = "5633c55219c01c689f670c2ca35d122e39f3f791"
SMALL_PACKAGES = ("trnm-checkpoint-store", "trnm-service-settlement", "trnm-release-bundle")
TLS_PREFIX = "ingress::pq_network::tls::tests::"
ROSTER_INPUTS = {
    "tls": ("tls25-source-roster-5633.json", 8252,
            "cc3bee7070d680df0d952ea102d3416646886c474638f15d634fd916bb75e7be"),
    "small": ("small-package-roster-5633.json", 52966,
              "c03fd53d5c02e75bf98f790453f827b45e574355d5670a807346103d0aaac895"),
}

def load_scope_rosters() -> dict:
    answer = {"records": {}, "data": {}}
    for label, (filename, size, digest) in ROSTER_INPUTS.items():
        path = Path(__file__).resolve(strict=True).with_name(filename)
        record = file_record(path)
        require(record["bytes"] == size and record["sha256"] == digest,
                "reviewed scope roster changed: " + filename)
        answer["records"][label] = record
        answer["data"][label] = json.loads(path.read_text())
    require(answer["data"]["tls"]["head"] == FIXED_HEAD
            and answer["data"]["tls"]["selection_prefix"] == TLS_PREFIX
            and answer["data"]["tls"]["expected_count"] == 25,
            "wrong TLS source roster")
    require(answer["data"]["small"]["expected_source_head"] == FIXED_HEAD
            and answer["data"]["small"]["total_nonignored_outer_tests"] == 179,
            "wrong small-package source roster")
    return answer

def tls_list_and_prefix(argv: list[str]) -> int:
    """One Cargo wrapper process owns full discovery and only the TLS filter.

    Both child invocations receive the exact same copied Cargo environment and
    cwd. A hash of the complete environment records equality without publishing
    unrecorded values. There is no unfiltered Node execution branch.
    """
    require(os.environ.get("CARGO_PKG_NAME") == "trnm-pon-node", "TLS wrapper received another package")
    expected_args = ["--list", "--format=pretty", "--color=never", "--test-threads=1"]
    require(argv[1:] == expected_args, "TLS wrapper accepts only the full listing Cargo entry")
    executable = Path(argv[0]).resolve(strict=True)
    target = Path(os.environ["TRNM_NATIVE_TARGET"]).resolve(strict=True)
    directory = Path(os.environ["TRNM_NATIVE_LOG_DIR"]).resolve(strict=True)
    require(executable.parent == target / "debug/deps", "Node did not use the normal-native native ELF layout")
    require(directory.is_relative_to(target.parent), "TLS output escaped this new campaign")
    environment = dict(os.environ)
    cwd = str(Path.cwd())
    fingerprint = hashlib.sha256(json.dumps(environment, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    selected_environment = {key: environment[key] for key in (
        "CARGO_MANIFEST_DIR", "CARGO_PKG_NAME", "LD_LIBRARY_PATH", "RUST_TEST_THREADS",
        "OPENSSL_DIR", "OPENSSL_STATIC", "OPENSSL_CONF", "OPENSSL_MODULES",
        "TRNM_PQ_OPENSSL", "TRNM_PQ_OPENSSL_SHA256", "TRNM_PQ_OPENSSL_VERSION",
    ) if key in environment}
    rosters = load_scope_rosters()
    expected = rosters["data"]["tls"]["expected_exact_names"]
    require(len(expected) == len(set(expected)) == 25 and expected == sorted(expected), "bad exact TLS set")
    before = file_record(executable)
    snapshot = {"schema": SCHEMA + "/tls-wrapper", "attempts": 1, "cwd": cwd,
                "binary": before, "runtime_environment_selected": selected_environment,
                "complete_runtime_environment_sha256": fingerprint,
                "all_environment_values_published": False,
                "same_environment_and_cwd_used_for_both_child_invocations": True,
                "node_full_library_execution": False, "selection_prefix": TLS_PREFIX,
                "scope_roster_inputs": rosters["records"], "started_unix_seconds": time.time()}
    save(directory / "wrapper.start.json", snapshot)

    def invoke(label: str, arguments: list[str], timeout: int) -> dict:
        stdout, stderr = directory / (label + ".stdout.log"), directory / (label + ".stderr.log")
        logfile = directory / (label + ".libtest.log")
        command = [str(executable), *arguments, "--logfile", str(logfile)]
        receipt = {"label": label, "argv": command, "cwd": cwd, "attempts": 1,
                   "exit_code": None, "timed_out": False, "timeout_seconds": timeout,
                   "complete_runtime_environment_sha256": fingerprint,
                   "binary_before": file_record(executable), "started_unix_seconds": time.time()}
        require(receipt["binary_before"] == before, "Node ELF changed before a TLS phase")
        save(directory / (label + ".started.json"), receipt)
        start = time.monotonic()
        child = None
        try:
            with stdout.open("xb") as out, stderr.open("xb") as err:
                if disk_record(target.parent)["free_bytes"] < 8 * 1024 ** 3:
                    receipt["blocked"] = "fixed 8 GiB disk threshold refused before native invocation"
                else:
                    # Inherit the Cargo command's owned group so parent aborts
                    # also reach this ELF and its OpenSSL children.
                    child = subprocess.Popen(command, cwd=cwd, env=environment,
                                             stdin=subprocess.DEVNULL, stdout=out, stderr=err)
                    receipt["pid"] = child.pid
                    until = start + timeout
                    while child.poll() is None:
                        try:
                            child.wait(timeout=max(0.01, min(10, until - time.monotonic())))
                        except subprocess.TimeoutExpired:
                            if time.monotonic() >= until:
                                receipt["timed_out"] = True
                            if disk_record(target.parent)["free_bytes"] < 8 * 1024 ** 3:
                                receipt["aborted"] = "fixed 8 GiB disk threshold reached during native invocation"
                            if receipt["timed_out"] or receipt.get("aborted"):
                                child.kill()
                                child.wait(timeout=5)
                                break
                    receipt["exit_code"] = child.returncode
        except BaseException as error:
            if child is not None and child.poll() is None:
                child.kill()
                child.wait(timeout=5)
            receipt["error"] = f"{type(error).__name__}: {error}"
        finally:
            receipt["elapsed_seconds"] = time.monotonic() - start
            receipt["binary_after"] = file_record(executable)
            receipt["logs"] = [file_record(p) for p in (stdout, stderr, logfile) if p.is_file()]
            receipt["passed"] = (receipt["exit_code"] == 0 and receipt["binary_after"] == before
                                 and not any(receipt.get(k) for k in ("error", "timed_out", "aborted", "blocked")))
            save(directory / (label + ".receipt.json"), receipt)
        return receipt

    listing = invoke("complete-node-list", expected_args, 300)
    require(listing["passed"], "complete Node PQ list did not finish")
    names = read_list(directory / "complete-node-list.libtest.log")
    require(names and len(names) == len(set(names)), "complete Node list is empty or duplicated")
    # libtest's positional filter is a substring filter; verify its complete
    # actual match set, including a possible match outside the intended prefix.
    matching = [name for name in names if TLS_PREFIX in name]
    require(matching == expected and all(name.startswith(TLS_PREFIX) for name in matching),
            "compiled Linux+PQ TLS filter is not the exact reviewed 25-name set")
    for prefix, count in NODE_PREFIX_COUNTS.items():
        require(sum(name.startswith(prefix) for name in names) == count,
                "actual Node compiled critical namespace differs: " + prefix)
    require(all(names.count(name) == 1 for name in OWNER_TESTS), "compiled owner controls missing")
    discovery = {**snapshot, "listing_receipt": listing, "names": names,
                 "complete_discovered_count": len(names), "authorized_tls_names": matching,
                 "tls_source_roster_matches_exactly": True, "full_library_executed": False,
                 "result": "PASS_COMPILE_AND_LIST_ONLY"}
    save(directory / "discovery.readback.json", discovery)
    run = invoke("tls25-prefix", [TLS_PREFIX, "--format=pretty", "--color=never", "--test-threads=1"], 1800)
    result = {**snapshot, "execution_receipt": run, "discovered_tls_names": matching,
              "result": "FAILED_OR_BLOCKED", "ignored_are_passes": False}
    try:
        outcomes = read_results(directory / "tls25-prefix.libtest.log", matching)
        result["outcomes"] = outcomes
        result["counts"] = {key: sum(v["outcome"] == key for v in outcomes.values())
                            for key in ("passed", "failed", "ignored")}
        result["missing_names"] = sorted(set(matching) - set(outcomes))
        require(not result["missing_names"] and run["passed"]
                and result["counts"] == {"passed": 25, "failed": 0, "ignored": 0},
                "TLS prefix incomplete, failed, ignored, timed out, or did not execute exactly 25")
        require(file_record(executable) == before, "Node ELF changed after TLS execution")
        result["result"] = "PASS_TLS25_ONLY"
    except Exception as error:
        result["error"] = f"{type(error).__name__}: {error}"
    save(directory / "tls25.readback.json", result)
    return 0 if result["result"] == "PASS_TLS25_ONLY" else 101


class Campaign:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.repo = args.repo.resolve(strict=True)
        self.out = args.out.resolve()
        self.script = Path(__file__).resolve(strict=True)
        self.cargo = args.cargo.resolve(strict=True)
        self.rustc = args.rustc.resolve(strict=True)
        self.python = Path(sys.executable).resolve(strict=True)
        self.git = Path(shutil.which("git") or "").resolve(strict=True)
        self.cargo_home = args.cargo_home.resolve(strict=True)
        require(sys.platform.startswith("linux"), "this exact native campaign requires Linux")
        require(self.cargo.parent == self.rustc.parent, "Cargo and rustc are not one toolchain")
        require(self.cargo_home.is_dir(), "Cargo home is not a directory")
        require(not self.out.exists(), "output already exists; keep it and choose a new path")
        require(not self.out.is_relative_to(self.repo), "output must be outside the source repository")
        require(not self.script.is_relative_to(self.repo), "runner must remain outside the source repository")
        self.out.mkdir(mode=0o700)
        self.primary_target = self.out / "native-target"
        self.pq_target = self.primary_target
        self.commands: list[dict] = []
        self.gates: list[dict] = []
        self.suites: dict[str, dict] = {}
        self.resource_blocked = False
        # No inherited Rust wrappers/flags, features, PQ provider variables,
        # credential environment, or Git replacement/config injection.
        self.env = {key: os.environ[key] for key in ("HOME", "USER", "LOGNAME") if key in os.environ}
        self.env.update({
            "PATH": str(self.cargo.parent) + ":/usr/bin:/bin", "LANG": "C", "LC_ALL": "C", "TZ": "UTC",
            "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_SYSTEM": os.devnull,
            "GIT_CONFIG_GLOBAL": os.devnull, "GIT_ATTR_NOSYSTEM": "1", "GIT_NO_REPLACE_OBJECTS": "1",
            "GIT_TERMINAL_PROMPT": "0", "GIT_OPTIONAL_LOCKS": "0", "PYTHONDONTWRITEBYTECODE": "1",
            "CARGO_HOME": str(self.cargo_home), "CARGO_TARGET_DIR": str(self.primary_target),
            "CARGO_NET_OFFLINE": "true", "CARGO_TERM_COLOR": "never",
            "CARGO_BUILD_JOBS": str(args.jobs), "CARGO_INCREMENTAL": "0",
            "RUSTC": str(self.rustc), "RUSTDOC": str(self.rustc.with_name("rustdoc")),
            "RUSTC_WRAPPER": "", "RUSTC_WORKSPACE_WRAPPER": "", "CARGO_ENCODED_RUSTFLAGS": "",
            "RUST_BACKTRACE": "0", "RUST_TEST_THREADS": "1",
            "RUSTFMT": str(self.rustc.with_name("rustfmt")),
            "LD_LIBRARY_PATH": str((self.rustc.parent.parent / "lib").resolve(strict=True)),
        })
        tools = [self.python, self.git, self.cargo, self.rustc,
                 self.rustc.with_name("rustdoc"), self.rustc.with_name("cargo-clippy"),
                 self.rustc.with_name("clippy-driver"), self.rustc.with_name("rustfmt"),
                 self.rustc.with_name("cargo-fmt")]
        configurations = set()
        for root in [self.cargo_home, self.repo, *self.repo.parents]:
            base = root if root == self.cargo_home else root / ".cargo"
            for name in ("config", "config.toml"):
                if (base / name).is_file():
                    configurations.add((base / name).resolve(strict=True))
        self.manifest = {
            "schema": SCHEMA, "expected_head": args.expected_head, "source_repository": str(self.repo),
            "runner": file_record(self.script), "started_unix_seconds": time.time(),
            "scope": "additional-fixed-continuation-and-tls25", "inherited_campaign_replaced": False,
            "prior_campaign": str(self.out.parent / "final-native-5633c55"),
            "prior_failed_or_blocked_results_replaced": False,
            "full_node_default_suite_executed": False, "full_node_pq_suite_executed": False,
            "continuity_65536_test_executed": False, "normal_native_layout_required": True,
            "target_shared_only_within_this_new_campaign": True,
            "native_scope": ["three small packages: complete emitted all-target test harnesses",
                             "Node PQ: complete build/list, then TLS prefix exactly 25 only"],
            "readonly_scope": ["cargo fmt --all -- --check", "Node default strict all-target Clippy",
                               "workspace strict all-target all-feature Clippy"],
            "owner_counterexample_campaign_replaced": False, "source_repository_modified": False,
            "whole_chain_pq_qualified": False, "production_activation": False,
            "retries": 0, "feature_variants_are_distinct_runs": True,
            "ignored_tests_are_passes": False, "ignored_capacity_or_static_root_tests_forced": False,
            "rust_profile_overrides": {"incremental": False, "optimization_debug_assertions_overflow_checks": "source-defined"},
            "tool_binaries": [file_record(path) for path in tools],
            "cargo_configuration_files": [file_record(path) for path in sorted(configurations)],
            "environment": self.env, "targets": {"primary": str(self.primary_target), "pq": str(self.pq_target)},
            "resource_limits": {"jobs": args.jobs, "command_timeout_seconds": args.timeout_seconds,
                                "minimum_free_bytes": int(args.min_free_gib * 1024 ** 3)},
            "disk_before": disk_record(self.out), "commands": self.commands,
            "gates": self.gates, "suites": self.suites, "pq_provider_requested": args.pq_provider is not None,
            "interpretation": "Only completed scoped gates can pass. Ignored tests, missing rosters, timeouts and original failures remain visible.",
        }
        self.scoped_rosters = load_scope_rosters()
        self.manifest["scope_roster_inputs"] = self.scoped_rosters["records"]
        save(self.out / "campaign-start.json", self.manifest)

    def command(self, label: str, argv: list[str], *, env: dict | None = None,
                heavy: bool = False, timeout: int | None = None) -> dict:
        require(not any(item["label"] == label for item in self.commands), "command label reused: " + label)
        receipt = {"label": label, "argv": argv, "cwd": str(self.repo), "attempts": 1,
                   "started_unix_seconds": time.time(), "exit_code": None, "timed_out": False,
                   "disk_before": disk_record(self.out)}
        self.commands.append(receipt)
        threshold = self.manifest["resource_limits"]["minimum_free_bytes"]
        stdout = self.out / (label + ".stdout.log")
        stderr = self.out / (label + ".stderr.log")
        receipt["stdout_path"], receipt["stderr_path"] = str(stdout), str(stderr)
        save(self.out / (label + ".started.json"), receipt)
        print(json.dumps({"starting": label, "argv": argv}), flush=True)
        started = time.monotonic()
        child = None
        try:
            with stdout.open("xb") as out, stderr.open("xb") as err:
                if heavy and (self.resource_blocked or receipt["disk_before"]["free_bytes"] < threshold):
                    self.resource_blocked = True
                    receipt["blocked"] = "insufficient free disk; no build was started"
                else:
                    child = subprocess.Popen(argv, cwd=self.repo, env=env or self.env,
                                             stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                             start_new_session=True)
                    receipt["pid"] = child.pid
                    receipt["owned_new_session_process_group"] = child.pid
                    limit = started + (timeout or (self.args.timeout_seconds if heavy else 300))
                    while child.poll() is None:
                        try:
                            child.wait(timeout=max(0.01, min(30, limit - time.monotonic())))
                        except subprocess.TimeoutExpired:
                            free = disk_record(self.out)["free_bytes"]
                            if time.monotonic() >= limit:
                                receipt["timed_out"] = True
                            if heavy and free < threshold:
                                self.resource_blocked = True
                                receipt["aborted"] = "free disk fell below the fixed campaign threshold"
                            if receipt["timed_out"] or receipt.get("aborted"):
                                self.stop(child)
                                break
                            print(json.dumps({"running": label, "elapsed_seconds": time.monotonic() - started,
                                              "free_bytes": free}), flush=True)
                    receipt["exit_code"] = child.returncode
                    if child.returncode != 0:
                        # A wrapper-side timeout can finish Cargo before its
                        # descendants. Reap only this newly created group.
                        self.stop(child)
                        receipt["failed_command_group_cleanup_requested"] = True
        except BaseException as error:
            if child is not None and child.poll() is None:
                self.stop(child)
            receipt["error"] = f"{type(error).__name__}: {error}"
            if not isinstance(error, Exception):
                raise
        finally:
            receipt["elapsed_seconds"] = time.monotonic() - started
            receipt["disk_after"] = disk_record(self.out)
            receipt["logs"] = [file_record(path) for path in (stdout, stderr) if path.is_file()]
            receipt["passed"] = receipt["exit_code"] == 0 and not any(
                receipt.get(key) for key in ("timed_out", "aborted", "blocked", "error"))
            save(self.out / (label + ".receipt.json"), receipt)
            print(json.dumps({"finished": label, "exit_code": receipt["exit_code"],
                              "passed": receipt["passed"], "timed_out": receipt["timed_out"]}), flush=True)
        return receipt

    @staticmethod
    def stop(child: subprocess.Popen) -> None:
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass
        finally:
            # A fast Cargo exit does not establish that its own group is empty.
            # This group was created by our start_new_session=True Popen.
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            child.wait(timeout=5)

    def gate(self, label: str, argv: list[str], **kwargs) -> dict:
        receipt = self.command(label, argv, **kwargs)
        result = {"label": label, "result": "PASS" if receipt["passed"] else "FAILED_OR_BLOCKED",
                  "command_receipt": str(self.out / (label + ".receipt.json"))}
        self.gates.append(result)
        return result

    def source_guard(self, label: str) -> dict:
        destination = self.out / (label + ".source.json")
        gate = self.gate(label, [str(self.python), "-B", "scripts/ci/verify_ci_source.py",
                                "--kind", "head", "--expected-head", self.args.expected_head,
                                "--output", str(destination)])
        if gate["result"] == "PASS":
            value = json.loads(destination.read_text())
            require(value.get("tracked_worktree_verified") is True
                    and value.get("tested_commit") == self.args.expected_head,
                    "source guard did not verify the requested raw tracked bytes")
            gate["source"] = value
            gate["source_receipt"] = file_record(destination)
        return gate

    def metadata(self, label: str, relative: str, expected_members: int,
                 env: dict, all_features: bool = False) -> bool:
        argv = [str(self.cargo), "metadata", "--locked", "--offline", "--format-version", "1",
                "--manifest-path", relative]
        if all_features:
            argv.append("--all-features")
        gate = self.gate(label, argv, env=env)
        if gate["result"] != "PASS":
            return False
        try:
            data = json.loads((self.out / (label + ".stdout.log")).read_text())
            require(Path(data["workspace_root"]).resolve() == (self.repo / relative).parent,
                    "metadata points to the wrong workspace")
            require(len(data["workspace_members"]) == expected_members, "workspace member roster changed")
            require(data.get("resolve", {}).get("nodes"), "metadata did not resolve the actual dependency graph")
            require(Path(data["target_directory"]).resolve() == Path(env["CARGO_TARGET_DIR"]),
                    "Cargo metadata target escaped the campaign output")
            for package in data["packages"]:
                if package["source"] is None:
                    require(Path(package["manifest_path"]).resolve().is_relative_to(self.repo),
                            "untracked external path dependency: " + package["name"])
                if package["name"] in ("trnm-data-availability", "trnm-pon-node"):
                    require(package["features"].get("default") == [], "default feature contract changed")
            readback = {"workspace_members": data["workspace_members"],
                        "packages": len(data["packages"]), "resolved_nodes": len(data["resolve"]["nodes"]),
                        "all_features": all_features, "workspace_root": data["workspace_root"],
                        "target_directory": data["target_directory"]}
            save(self.out / (label + ".readback.json"), readback)
            gate["readback"] = readback
        except Exception as error:
            gate.update(result="FAILED_READBACK", error=f"{type(error).__name__}: {error}")
        return gate["result"] == "PASS"

    @staticmethod
    def artifact_paths(stdout: Path, packages: tuple[str, ...]) -> dict:
        artifacts = {}
        for line in stdout.read_text(errors="replace").splitlines():
            if not line.startswith("{"):
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if item.get("reason") != "compiler-artifact" or not item.get("executable") or not item.get("profile", {}).get("test"):
                continue
            target = item["target"]
            # Package IDs are mapped through Cargo's artifact manifest path,
            # never through the number of human-readable stdout summaries.
            manifest = Path(item["manifest_path"])
            if manifest.parent.name not in packages:
                continue
            path = str(Path(item["executable"]).resolve(strict=True))
            require(path not in artifacts, "duplicate executable artifact")
            artifacts[path] = {"package_id": item["package_id"], "manifest_path": str(manifest),
                               "target": target, "features": item["features"],
                               "profile": item["profile"]}
        require(artifacts, "Cargo reported no selected native test executable")
        return artifacts

    def read_harnesses(self, directory: Path, artifacts: dict, listing: bool,
                       previous: dict | None = None) -> dict:
        found = {}
        for path in sorted(directory.glob("*.finish.json")):
            receipt = json.loads(path.read_text())
            executable = receipt.get("executable_before", {}).get("path")
            require(executable in artifacts, "harness not bound to a selected Cargo artifact")
            require(executable not in found, "duplicate native harness execution")
            require(not receipt.get("error") and receipt.get("libtest_log"), "incomplete harness receipt")
            require(receipt["executable_before"] == receipt.get("executable_after"), "harness bytes changed")
            require(receipt["mode"] == ("list" if listing else "run"), "wrong harness phase")
            log = Path(receipt["libtest_log"]["path"])
            require(log.resolve().is_relative_to(directory) and file_record(log) == receipt["libtest_log"],
                    "outer libtest logfile changed or escaped its phase")
            readback = {"receipt": str(path), "binary": receipt["executable_before"],
                        "artifact": artifacts[executable], "exit_code": receipt["exit_code"]}
            if listing:
                require(receipt["exit_code"] == 0, "harness discovery failed")
                readback["names"] = read_list(log)
            else:
                require(previous is not None and executable in previous, "harness was not discovered")
                require(receipt["executable_before"] == previous[executable]["binary"],
                        "compiled harness changed between discovery and execution")
                results = read_results(log, previous[executable]["names"])
                readback["results"] = results
                readback["missing_names"] = sorted(set(previous[executable]["names"]) - set(results))
                readback["counts"] = {key: sum(item["outcome"] == key for item in results.values())
                                      for key in ("passed", "failed", "ignored")}
            found[executable] = readback
        return found

    def suite(self, label: str, packages: tuple[str, ...], selection: list[str], env: dict,
              *, required: tuple[str, ...] = (), prefixes: dict | None = None,
              require_static_ignored: bool = False) -> None:
        require(set(packages) == set(SMALL_PACKAGES), "full suites are limited to the three small packages")
        suite = {"label": label, "packages": packages, "selection": selection,
                 "result": "NOT_RUN", "discovery_attempts": 1, "execution_attempts": 0,
                 "ignored_are_passes": False}
        self.suites[label] = suite
        gate = {"label": label, "result": "FAILED_OR_BLOCKED"}
        self.gates.append(gate)
        runner = 'target.' + HOST + '.runner=' + json.dumps(
            [str(self.python), "-B", str(self.script), "__harness_runner__"])
        common = [str(self.cargo), "test", "--locked", "--offline", "--no-fail-fast",
                  "--manifest-path", "trillionnium/Cargo.toml",
                  "--message-format=json", "--config", runner]
        for package in packages:
            common.extend(["-p", package])
        common.extend(selection)
        discovery_dir = self.out / (label + "-discovery-harnesses")
        execution_dir = self.out / (label + "-execution-harnesses")
        discovery_dir.mkdir(mode=0o700)
        execution_dir.mkdir(mode=0o700)
        run_env = dict(env, TRNM_NATIVE_TARGET=env["CARGO_TARGET_DIR"])
        try:
            run_env.update(TRNM_NATIVE_LOG_DIR=str(discovery_dir), TRNM_NATIVE_MODE="list")
            discovery = self.command(label + "-list", common + ["--", "--list", "--format=pretty",
                                                               "--color=never", "--test-threads=1"],
                                     env=run_env, heavy=True)
            require(discovery["passed"], "discovery failed; full execution blocked without retry")
            artifacts = self.artifact_paths(Path(discovery["stdout_path"]), packages)
            listed = self.read_harnesses(discovery_dir, artifacts, True)
            suite["discovered_harnesses"] = listed
            suite["fixed_source_roster"] = self.validate_small_roster(listed, artifacts)
            require(set(listed) == set(artifacts), "compiled/listed harness sets differ")
            require({Path(item["manifest_path"]).parent.name for item in artifacts.values()} == set(packages),
                    "a requested package has no compiled test harness")
            names = [name for harness in listed.values() for name in harness["names"]]
            roster_issues = []
            for name in required:
                if names.count(name) != 1:
                    roster_issues.append("required test is absent or ambiguous: " + name)
            for prefix, count in (prefixes or {}).items():
                matches = [name for name in names if name.startswith(prefix)]
                if len(matches) != count:
                    roster_issues.append(f"critical roster changed: {prefix}: {len(matches)} != {count}")
            if require_static_ignored and names.count(STATIC_ROOT_IGNORED) != 1:
                roster_issues.append("static-root ignored control missing from roster")
            # Record drift without filtering or preventing the requested full
            # suite from running. A drifted roster still fails final readback.
            suite["critical_roster_issues"] = roster_issues
            suite["discovered_tests"] = len(names)
            save(self.out / (label + ".roster.json"), listed)
            run_env.update(TRNM_NATIVE_LOG_DIR=str(execution_dir), TRNM_NATIVE_MODE="run")
            suite["execution_attempts"] = 1
            execution = self.command(label + "-run", common + ["--", "--format=pretty",
                                                              "--color=never", "--test-threads=1"],
                                     env=run_env, heavy=True)
            ran_artifacts = self.artifact_paths(Path(execution["stdout_path"]), packages)
            require(ran_artifacts == artifacts, "Cargo's actual native artifact graph changed between phases")
            ran = self.read_harnesses(execution_dir, artifacts, False, listed)
            suite["executed_harnesses"] = ran
            suite["missing_harnesses"] = sorted(set(listed) - set(ran))
            suite["counts"] = {key: sum(item["counts"][key] for item in ran.values())
                               for key in ("passed", "failed", "ignored")}
            outcomes = {name: value for harness in ran.values() for name, value in harness["results"].items()}
            suite["ignored_tests"] = {name: value["detail"] for name, value in outcomes.items()
                                      if value["outcome"] == "ignored"}
            suite["failed_tests"] = {name: value["detail"] for name, value in outcomes.items()
                                     if value["outcome"] == "failed"}
            require(not suite["missing_harnesses"] and not any(x["missing_names"] for x in ran.values()),
                    "actual run did not account for the complete discovered roster")
            require(not roster_issues, "critical roster differs from the reviewed source: " + repr(roster_issues))
            critical = set(required)
            critical.update(name for name in names if any(name.startswith(prefix) for prefix in (prefixes or {})))
            suite["critical_outcomes"] = {name: outcomes[name] for name in sorted(critical)}
            require(all(outcomes[name]["outcome"] == "passed" for name in critical),
                    "a required critical test did not pass")
            if require_static_ignored:
                require(outcomes[STATIC_ROOT_IGNORED]["outcome"] == "ignored", "static-root control's explicit ignored status changed")
            require(execution["passed"] and all(item["exit_code"] == 0 for item in ran.values())
                    and suite["counts"] == {"passed": 179, "failed": 0, "ignored": 0},
                    "three-package actual outcomes do not match all 179 nonignored source tests; no retry")
            suite["result"] = "PASS_WITH_IGNORED" if suite["counts"]["ignored"] else "PASS"
            gate["result"] = "PASS"
        except Exception as error:
            suite.update(result="FAILED_OR_BLOCKED", error=f"{type(error).__name__}: {error}")
            gate["error"] = suite["error"]
        finally:
            save(self.out / (label + ".readback.json"), suite)

    def clippy(self, label: str, selection: list[str], env: dict) -> None:
        self.gate(label, [str(self.cargo), "clippy", "--locked", "--offline", "--manifest-path",
                          "trillionnium/Cargo.toml", *selection,
                          "--all-targets", "--", "-D", "warnings"], env=env, heavy=True)

    def provider(self) -> dict | None:
        if self.args.pq_provider is None:
            self.manifest["pq_group"] = {"result": "NOT_REQUESTED", "executed": False}
            return None
        gate = {"label": "pq-provider-pins", "result": "FAILED_OR_BLOCKED"}
        self.gates.append(gate)
        try:
            provider = self.args.pq_provider.resolve(strict=True)
            records = []
            for relative, (size, digest) in PROVIDER_FILES.items():
                record = file_record(provider / relative)
                records.append(record)
                require((record["bytes"], record["sha256"]) == (size, digest),
                        "provider file does not match the reviewed exact pin: " + relative)
            env = dict(self.env, CARGO_TARGET_DIR=str(self.pq_target),
                       OPENSSL_DIR=str(provider), OPENSSL_STATIC="1", OPENSSL_NO_VENDOR="1",
                       OPENSSL_CONF=os.devnull, OPENSSL_MODULES=str(provider / "lib/ossl-modules"),
                       TRNM_PQ_OPENSSL=str(provider / "bin/openssl"), TRNM_PQ_OPENSSL_VERSION="3.5.9",
                       TRNM_PQ_OPENSSL_SHA256=PROVIDER_FILES["bin/openssl"][1])
            version = self.command("pq-provider-version", [str(provider / "bin/openssl"), "version", "-a"], env=env)
            require(version["passed"], "pinned provider version command failed")
            require(Path(version["stdout_path"]).read_text().startswith("OpenSSL 3.5.9 "),
                    "pinned provider reports a different version")
            gate.update(result="PASS", files=records)
            self.manifest["pq_group"] = {"result": "PROVIDER_VERIFIED", "full_node_library_executed": False, "provider": str(provider),
                                         "files": records, "environment": env, "executed": False}
            return env
        except Exception as error:
            gate["error"] = f"{type(error).__name__}: {error}"
            self.manifest["pq_group"] = {"result": "BLOCKED_PROVIDER_MISMATCH", "executed": False,
                                         "error": gate["error"]}
            return None


    def verify_scope_source_pins(self, label: str) -> None:
        records = []
        for kind in ("small", "tls"):
            for expected in self.scoped_rosters["data"][kind]["source_files"]:
                record = file_record(self.repo / expected["path"])
                require((record["bytes"], record["sha256"]) == (expected["bytes"], expected["sha256"]),
                        "fixed source roster input changed: " + expected["path"])
                records.append(record)
        save(self.out / (label + ".json"), {"result": "PASS", "files": records})
        self.gates.append({"label": label, "result": "PASS"})

    def validate_small_roster(self, listed: dict, artifacts: dict) -> dict:
        expected = self.scoped_rosters["data"]["small"]["harnesses"]
        key = lambda package, target: (package, tuple(target["kind"]), target["name"])
        allowed = {(h["package"], tuple(h["target_kind"]), h["target_name"]): h for h in expected}
        required = {k for k, h in allowed.items() if h["required_nonempty_harness"]}
        seen = set()
        records = []
        for executable, data in listed.items():
            artifact = artifacts[executable]
            package = Path(artifact["manifest_path"]).parent.name
            identity = key(package, artifact["target"])
            require(identity in allowed and identity not in seen, "unexpected or duplicate small-package harness")
            item = allowed[identity]
            require(artifact["target"]["src_path"] == item["target_source_at_original_metadata"],
                    "selected test target source changed")
            require(data["names"] == item["expected_names"], "compiled names differ from fixed 179-name source roster: " + repr(identity))
            seen.add(identity)
            records.append({"package": package, "target_kind": artifact["target"]["kind"],
                            "target_name": artifact["target"]["name"], "binary": data["binary"],
                            "names": data["names"], "zero_test_harness": not data["names"]})
        require(required <= seen, "one of seven required nonempty small-package harnesses is missing")
        require(sum(len(item["names"]) for item in listed.values()) == 179, "actual three-package total is not 179")
        return {"result": "EXACT_COMPILED_SOURCE_ROSTER_MATCH", "total_names": 179,
                "harnesses": records, "zero_test_harnesses_are_tests": False}

    def sqlite_fence(self, label: str) -> None:
        gate = {"label": label, "result": "FAILED_OR_BLOCKED"}
        self.gates.append(gate)
        files = sorted(self.primary_target.glob("debug/build/trnm-sqlite-io-boundary-*/output"))
        records = []
        try:
            require(files, "fresh normal-native build did not emit the SQLite build-script output")
            for path in files:
                text = path.read_text()
                qualified = ("cargo:rustc-cfg=trnm_sqlite_layout_witness\n" in text
                             and "cargo:rustc-env=TRNM_SQLITE3_BUILD_FENCE=sqlite-3.51.3-normal-native-linux-layout-v3\n" in text
                             and "UNQUALIFIED:" not in text and "TRNM_SQLITE3_UNQUALIFIED_REASON=" not in text)
                records.append({**file_record(path), "actual_cfg_and_exact_v3_fence": qualified})
            require(all(item["actual_cfg_and_exact_v3_fence"] for item in records), "fresh SQLite output is unqualified")
            gate["result"] = "PASS"
        except Exception as error:
            gate["error"] = f"{type(error).__name__}: {error}"
        gate["outputs"] = records
        gate["earlier_binaries_requalified"] = False
        save(self.out / (label + ".readback.json"), gate)

    def node_pq_build_list_tls(self, env: dict) -> None:
        directory = self.out / "node-pq-build-list-and-tls25"
        directory.mkdir(mode=0o700)
        run_env = dict(env, TRNM_NATIVE_TARGET=str(self.primary_target),
                       TRNM_NATIVE_LOG_DIR=str(directory), TRNM_NATIVE_MODE="pq-list-tls")
        runner = 'target.' + HOST + '.runner=' + json.dumps(
            [str(self.python), "-B", str(self.script), "__harness_runner__"])
        argv = [str(self.cargo), "test", "--locked", "--offline", "--no-fail-fast",
                "--manifest-path", "trillionnium/Cargo.toml", "--message-format=json", "--config", runner,
                "-p", "trnm-pon-node", "--lib", "--features", "pq-native-openssl",
                "--", "--list", "--format=pretty", "--color=never", "--test-threads=1"]
        command = self.command("node-pq-build-list-tls-cargo", argv, env=run_env, heavy=True)
        build_gate = {"label": "node-pq-build-and-complete-list", "result": "FAILED_OR_BLOCKED",
                      "full_node_library_execution": False}
        tls_gate = {"label": "tls25-prefix-native", "result": "FAILED_OR_BLOCKED",
                    "prefix": TLS_PREFIX, "expected_count": 25, "retry": False}
        self.gates.extend((build_gate, tls_gate))
        try:
            artifacts = self.artifact_paths(Path(command["stdout_path"]), ("trnm-pon-node",))
            require(len(artifacts) == 1, "Node lib did not emit exactly one test artifact")
            path, artifact = next(iter(artifacts.items()))
            require(artifact["target"]["kind"] == ["lib"] and "pq-native-openssl" in artifact["features"], "wrong Node PQ Cargo artifact")
            discovery = json.loads((directory / "discovery.readback.json").read_text())
            require(discovery["binary"] == file_record(Path(path)) and discovery["result"] == "PASS_COMPILE_AND_LIST_ONLY",
                    "Node PQ compiled/listed ELF does not match the actual Cargo artifact")
            build_gate.update(result="PASS", compiled_test_names=discovery["complete_discovered_count"],
                              tls_names=discovery["authorized_tls_names"], binary=discovery["binary"], artifact=artifact)
            save(self.out / "node-pq-complete-discovery.readback.json", discovery)
        except Exception as error:
            build_gate["error"] = f"{type(error).__name__}: {error}"
        try:
            result = json.loads((directory / "tls25.readback.json").read_text())
            tls_gate["readback"] = result
            require(build_gate["result"] == "PASS" and command["passed"] and result["result"] == "PASS_TLS25_ONLY",
                    "TLS prefix did not complete exactly 25 passing native tests")
            require(result["binary"] == build_gate["binary"], "TLS execution used another Node ELF")
            tls_gate["result"] = "PASS"
        except Exception as error:
            tls_gate["error"] = f"{type(error).__name__}: {error}"
            partial = directory / "tls25-prefix.libtest.log"
            if partial.is_file():
                try:
                    names = self.scoped_rosters["data"]["tls"]["expected_exact_names"]
                    outcomes = read_results(partial, names)
                    tls_gate["partial_outcomes"] = outcomes
                    tls_gate["partial_counts"] = {key: sum(item["outcome"] == key for item in outcomes.values())
                                                  for key in ("passed", "failed", "ignored")}
                    tls_gate["missing_names"] = sorted(set(names) - set(outcomes))
                except Exception as partial_error:
                    tls_gate["partial_readback_error"] = f"{type(partial_error).__name__}: {partial_error}"
        save(self.out / "node-pq-build-list-scope.readback.json", build_gate)
        save(self.out / "tls25-scope.readback.json", tls_gate)

    def run(self) -> None:
        git_identity = self.command("git-identity", [str(self.git), "--no-replace-objects", "rev-parse", "HEAD", "HEAD^{tree}"])
        require(git_identity["passed"], "cannot read source identity")
        identity = Path(git_identity["stdout_path"]).read_text().splitlines()
        require(len(identity) == 2 and identity[0] == self.args.expected_head, "source HEAD is not the explicit final commit")
        self.manifest["source_tree"] = identity[1]
        origin = self.command("git-origin", [str(self.git), "remote", "get-url", "origin"])
        require(origin["passed"] and Path(origin["stdout_path"]).read_text().strip() in ORIGINS,
                "source origin is not canonical Chain")
        preflight = self.gate("project-preflight", ["/bin/bash", "scripts/project-preflight.sh"])
        require(preflight["result"] == "PASS", "project preflight failed")
        require(self.source_guard("source-before")["result"] == "PASS", "initial raw source guard failed")
        for label, argv, prefix in (
            ("cargo-version", [str(self.cargo), "-V"], "cargo 1.95.0 "),
            ("rustc-version", [str(self.rustc), "-Vv"], "rustc 1.95.0 "),
            ("rustdoc-version", [str(self.rustc.with_name("rustdoc")), "-V"], "rustdoc 1.95.0 "),
            ("clippy-version", [str(self.cargo), "clippy", "-V"], "clippy 0.1.95 "),
        ):
            version = self.gate(label, argv)
            if version["result"] == "PASS" and not (self.out / (label + ".stdout.log")).read_text().startswith(prefix):
                version["result"] = "FAILED_VERSION"
            require(version["result"] == "PASS", "toolchain is not the reviewed Rust 1.95.0: " + label)
        require("host: " + HOST + "\n" in (self.out / "rustc-version.stdout.log").read_text(), "wrong native Rust host")
        fmt_version = self.gate("rustfmt-version", [str(self.rustc.with_name("rustfmt")), "--version"])
        require(fmt_version["result"] == "PASS", "fixed toolchain rustfmt is unavailable")
        self.manifest["lockfiles"] = [file_record(self.repo / relative) for relative in
                                      ("trillionnium/Cargo.lock", "tests/fuzz/Cargo.lock")]
        workspace = self.metadata("workspace-locked-metadata", "trillionnium/Cargo.toml", 26, self.env)
        self.metadata("fuzz-locked-metadata", "tests/fuzz/Cargo.toml", 1, self.env)
        require(workspace, "primary workspace graph was not resolved; native builds blocked")
        self.verify_scope_source_pins("scope-source-pins-before")
        self.gate("cargo-fmt-all-check", [str(self.cargo), "fmt", "--manifest-path", "trillionnium/Cargo.toml",
                                         "--all", "--", "--check"], env=self.env)
        self.clippy("node-strict-default-alltargets", ["-p", "trnm-pon-node"], self.env)
        self.sqlite_fence("sqlite-native-build-fence-primary")
        self.suite("recovery-settlement-release-alltargets-allfeatures", SMALL_PACKAGES,
                   ["--all-targets", "--all-features"], self.env,
                   required=tuple(self.scoped_rosters["data"]["small"]["critical_m12_exact_names"]))
        require(self.source_guard("source-after-primary")["result"] == "PASS",
                "primary continuation commands changed source; PQ group blocked")
        pq_env = self.provider()
        if pq_env is not None:
            graph = self.metadata("workspace-locked-allfeatures-metadata", "trillionnium/Cargo.toml", 26, pq_env, True)
            if graph:
                self.manifest["pq_group"]["executed"] = True
                self.clippy("workspace-strict-alltargets-allfeatures", ["--workspace", "--all-features"], pq_env)
                self.node_pq_build_list_tls(pq_env)
                self.sqlite_fence("sqlite-native-build-fence-final")
                after = [file_record(Path(self.manifest["pq_group"]["provider"]) / relative)
                         for relative in PROVIDER_FILES]
                require(after == self.manifest["pq_group"]["files"], "pinned provider changed during continuation")
                self.manifest["pq_group"]["provider_files_unchanged"] = True
            else:
                self.manifest["pq_group"]["result"] = "BLOCKED_GRAPH_FAILURE"
        self.verify_scope_source_pins("scope-source-pins-after")

    def finish(self) -> int:
        self.manifest["finished_unix_seconds"] = time.time()
        self.manifest["disk_after"] = disk_record(self.out)
        runner_after = file_record(self.script)
        self.manifest["runner_after"] = runner_after
        scope_after = load_scope_rosters()["records"]
        self.manifest["scope_roster_inputs_after"] = scope_after
        if scope_after != self.manifest["scope_roster_inputs"]:
            self.gates.append({"label": "scope-roster-input-identity", "result": "FAILED_OR_BLOCKED"})
        if runner_after != self.manifest["runner"]:
            self.gates.append({"label": "runner-identity", "result": "FAILED_OR_BLOCKED",
                               "error": "runner bytes changed during the campaign"})
        failed = [gate["label"] for gate in self.gates if gate["result"] != "PASS"]
        self.manifest["failed_or_blocked_gates"] = failed
        has_ignored = any(suite.get("counts", {}).get("ignored", 0) for suite in self.suites.values())
        success = not failed and "fatal_error" not in self.manifest
        self.manifest["result"] = ("PASS_SCOPED_WITH_IGNORED" if has_ignored else "PASS_SCOPED") if success else "FAILED_OR_BLOCKED"
        pq = self.manifest.get("pq_group")
        if pq and pq.get("executed"):
            pq_labels = {"node-pq-build-and-complete-list", "tls25-prefix-native",
                         "workspace-strict-alltargets-allfeatures", "sqlite-native-build-fence-final"}
            pq["result"] = "FAILED_OR_BLOCKED" if not success or any(name in failed for name in pq_labels) or not pq.get("provider_files_unchanged") else "PASS_SCOPED"
        save(self.out / "summary.json", self.manifest)
        print(json.dumps({"result": self.manifest["result"], "summary": str(self.out / "summary.json"),
                          "failed_or_blocked_gates": failed, "whole_chain_pq_qualified": False}), flush=True)
        return 0 if success else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--cargo", type=Path, required=True)
    parser.add_argument("--rustc", type=Path, required=True)
    parser.add_argument("--cargo-home", type=Path, required=True)
    parser.add_argument("--pq-provider", type=Path, help="Opt in to the separately pinned provider group; all five exact hashes are mandatory")
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--timeout-seconds", type=int, default=7200)
    parser.add_argument("--min-free-gib", type=float, default=8.0)
    args = parser.parse_args()
    require(re.fullmatch(r"[0-9a-f]{40}", args.expected_head) is not None, "noncanonical expected HEAD")
    require(args.expected_head == FIXED_HEAD, "continuation is fixed to the explicit 5633 source")
    require(args.jobs == 2 and args.timeout_seconds == 7200, "fixed continuation resource limit changed")
    require(args.min_free_gib == 8.0, "the fixed 8 GiB stop threshold cannot change")
    require(args.pq_provider is not None, "the exact pinned provider is required for the authorized scope")
    campaign = Campaign(args)
    try:
        campaign.run()
    except BaseException as error:
        campaign.manifest["fatal_error"] = f"{type(error).__name__}: {error}"
    finally:
        try:
            campaign.source_guard("source-after-final")
        except BaseException as error:
            campaign.gates.append({"label": "source-after-final-readback", "result": "FAILED_OR_BLOCKED",
                                   "error": f"{type(error).__name__}: {error}"})
        return campaign.finish()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "__harness_runner__":
        raise SystemExit(harness_runner(sys.argv[2:]))
    raise SystemExit(main())
