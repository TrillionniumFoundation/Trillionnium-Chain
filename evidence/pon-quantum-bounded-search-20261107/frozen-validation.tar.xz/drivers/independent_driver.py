from pathlib import Path
import sys, json, hashlib, copy
from dataclasses import replace
from fractions import Fraction
p=Path('formal/pon-nakamoto-v1')
sys.path.insert(0,str(p))
sys.path.insert(0,str(p/'experiments'))
files=['w1_bounded_search.py','w1_marked_domain.py','quantum_adversarial_search.py']
before={f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in files}
from w1_marked_domain_campaign import with_parameters
from w1_quantum_oracle_campaign import reduced_template
from w1_marked_domain import enumerate_domain
from w1_bounded_search import simulate_bounded_measurements as sim
from quantum_adversarial_search import TrialCosts
c=TrialCosts(1,2,3,5,7,11,'upward')
t=reduced_template()
a=enumerate_domain(with_parameters(t,1))
b=enumerate_domain(with_parameters(t,3))
e=enumerate_domain(with_parameters(t,1,target=1))
f=enumerate_domain(with_parameters(t,1,target=1,profile='PGH2'))
assert (a['domain_size'],a['marked_count'],a['prefix_restricted_marked_count'])==(2,2,0)
assert (b['domain_size'],b['marked_count'],b['prefix_restricted_marked_count'])==(8,8,2)
checks=[]
def q(r):return Fraction(r['numerator'],r['denominator'])
def charge(r):
 assert sum(map(q,r['phase_paid_seconds_exact'].values()),Fraction())==q(r['elapsed_seconds_exact'])
 assert q(r['elapsed_seconds_exact'])+q(r['unused_horizon_seconds_exact'])==Fraction(r['plan']['horizon_seconds'])
 assert q(r['quantum_processor_seconds_exact'])==r['plan']['processors']*sum(q(r['phase_paid_seconds_exact'][k]) for k in ('prepare','iterations','measurement'))
for d in (a,b):
 for its in (0,1,7):
  out=sim((d,),((0,its),),3,17,(c,),'1000',predicate='prefix-restricted',propagation_seconds=(13,))
  charge(out)
  assert out['success'] and out['candidate_checks_completed']==3
  row=out['trials'][0]
  assert row['conditional_batch_valid_candidate_probability']==1.0
  assert all(x['winner'] is True and x['candidate_check_completed'] for x in row['measurements'])
  if d is a: assert row['conditional_batch_phase_mark_probability']==0.0
  assert q(out['elapsed_seconds_exact'])==50+2*its
  checks.append('full acceptance N%d q%d'%(d['domain_size'],its))
for lim,expected in [('14.5',(False,0,False,False)),('15',(True,0,False,False)),('19.999',(True,0,False,False)),('20',(True,1,True,False)),('26.999',(True,1,True,False)),('27',(True,1,True,False)),('39.999',(True,1,True,False)),('40',(True,1,True,True))]:
 out=sim((a,),((0,0),),1,3,(c,),lim,predicate='prefix-restricted',propagation_seconds=(13,))
 charge(out)
 row=out['trials'][0]
 assert (row['measurement_complete'],row['candidate_checks_completed'],row['verified_winner_observed'],row['success'])==expected,(lim,row)
 assert all(x['winner'] is None for x in row['measurements'] if not x['candidate_check_completed'])
 checks.append('deadline '+lim)
out=sim((a,),((0,0),),1,0,(replace(c,proof_seconds=0),),'20',predicate='prefix-restricted')
assert out['success'] and q(out['elapsed_seconds_exact'])==20
checks.append('zero proof at exact deadline')
out=sim((a,),((0,0),),3,0,(c,),'20',predicate='prefix-restricted')
charge(out)
assert out['candidate_checks_completed']==1 and out['trials'][0]['verified_winner_observed'] and not out['success']
assert len(out['trials'][0]['measurements'])==3
assert out['trials'][0]['measurements'][1:]==[{'nonce':out['trials'][0]['measurements'][i]['nonce'],'candidate_check_completed':False,'winner':None} for i in (1,2)]
checks.append('known first winner waits for full declared check batch')
for ds,schedule,expected in [((e,),((0,0),(0,0),(0,0)),1),((e,f),((0,0),(1,0),(0,0)),3)]:
 out=sim(ds,schedule,2,19,(c,)*len(ds),'1000',predicate='prefix-restricted')
 charge(out)
 assert not out['success'] and out['termination']=='schedule-exhausted' and out['trials_started']==3
 assert out['domain_setup_charges']==expected
 assert out['candidate_checks_completed']==6
 assert all(x['winner'] is False for row in out['trials'] for x in row['measurements'])
 checks.append('M0 persists setup count '+str(expected))
out=sim((a,),((0,3),),3,3,(c,),'15',predicate='prefix-restricted')
charge(out)
assert out['grover_iterations_completed_all_processors']==3 and q(out['trials'][0]['partial_iteration_seconds_exact'])==1
assert out['completed_measurement_batches']==0 and out['trials'][0]['measurements']==[]
checks.append('partial Grover iteration no measurement')
out=sim((a,),((0,0),),1,0,(c,),'0')
charge(out)
assert not out['trials'] and out['domain_setup_charges']==0
checks.append('zero horizon no work')
for prop in [(True,),(-1,),(float('nan'),),(float('inf'),),('1',)]:
 try: sim((a,),((0,0),),1,0,(c,),'1000',propagation_seconds=prop)
 except ValueError: pass
 else: raise AssertionError(('bad propagation accepted',prop))
checks.append('propagation refusals')
mut=copy.deepcopy(a);mut['outcomes'][0]['winner']=False
try:sim((mut,),((0,0),),1,0,(c,),'1000')
except ValueError as er: assert 'CENSUS_REPLAY_MISMATCH' in str(er)
else:raise AssertionError('forged census accepted')
checks.append('forged census rejected')
after={f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in files}
print(json.dumps({'independent_controls':len(checks),'checks':checks,'source_before':before,'source_after':after,'source_stable':before==after,'scope':'read-only deterministic conditional model controls, no QPU/native admission'},sort_keys=True))
