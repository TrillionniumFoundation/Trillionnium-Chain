# F2 GitHub failure observations and the credit output repair

These are retained results from real GitHub pull-request runs, read through the authenticated **ProfHepta** connection. No workflow was re-run, no remote status was changed, and no primary checkout was edited by this diagnosis. The two QROM source guards remain failed on the original F2 input. Nothing here supplies a quantum, lifetime, economic, or production qualification.

## Exact source

All three runs are attempt 1 of PR 821, candidate commit
**0101b0ce76239832e0b2d19d0fd3f07e40fabeb4**, base
**7e044b65454f4c9ea505591727332acffb33e7e5**. Their prospective merge is
**d5ba8574297839ed06e7a016207827b7993825c6**. Both source kinds have tree
**f57618067a8106d0a96f74dd38291a25416ff68c**.

Every one of the six jobs actually completed its original full source check before and after execution, with equal receipts: **24,847 entries / 2,419,054,249 bytes**. Those source checks establish the tested bytes; they do not make failed execution stages successful. Full source tuples, named failed/skipped stages and complete log digests are in [diagnosis.json](diagnosis.json). Original run metadata, job metadata and all six complete decoded job logs are adjacent.

| Run | Head job | Prospective merge job | First real failure |
| --- | --- | --- | --- |
| [42515032701 — QROM closure](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42515032701) | 128836076731 | 128836076552 | Historical lifetime source pin rejects current store.rs; that test class executes zero tests. |
| [42515032598 — QROM implementation](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42515032598) | 128836076425 | 128836076720 | The exact historical main.rs size bound rejects the larger current file. |
| [42515032608 — finite credit](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42515032608) | 128836076247 | 128836076706 | Expected negative-fixture stdout is buffered until after the successful unittest footer; the strict terminal parser then correctly rejects that malformed combined log. |

## Credit: one-line wiring repair

[credit-unbuffered.patch](credit-unbuffered.patch) changes only the source-integrity invocation in the retained-controls step to use Python's unbuffered output option. The original parser, pipefail policy, source checks and all 43 test cases stay unchanged. The existing central CI contract does not pin this separate workflow command; its credit literals concern the ci_job.sh lane, which this patch does not change.

The [scoped validation](credit-wiring-validation/summary.json) used six exact F2 source files, independently matched to their Git blob identities, and actual temporary Git repositories and child processes:

| Invocation | Actual tests | Unittest exit | Original per-log parser exit |
| --- | ---: | ---: | ---: |
| Original buffered command | 43 | 0 | 1 |
| Proposed unbuffered command | 43 | 0 | 0 |

All 43 named starts were present exactly once in both runs, with no skipped or failed tests. The parser body is copied byte-for-byte from the original workflow, evaluated only for the source-integrity log. This is not a claim that the other three retained suites or the complete patched hosted workflow have executed. Both command logs, parser output and the test driver are retained.

## QROM closure: a historical source guard, not a quantum failure estimate

The active script scripts/w1_lifetime_ledger.py fixes SOURCE_BASE to
7150d96a2112875b4afcf3023361a5cef4a0e4b1 and fixes 20 selected source hashes.
The full current-file comparison found only one changed entry:

- store.rs: historical SHA256 b712a86b9997a098df5e8257f309d22445b2c749c9aa474457e958a0f65f5153; current SHA256 108621f304255841ea2e1a7353858c3f0f5d8cb70a235f6a4aef6d57ebe0c554, 382,866 bytes.

The historical hash was verified against the actual Git blob at the declared old commit. The other 19 selected current files still match. The 15/44-path PQ locks updated elsewhere are a separate registry; they do not override this script's original selected-source contract.

In both hosted jobs, LifetimeLedgerTests.setUpClass refused before its cases could run. The later required-started-IDs check and report-stage check then retained that failure. They must not be bypassed or reported as a completed roster.

The store changes are the composed native generation/task/funding/observation routes and the reviewed observation-field repair already described in the separate PQ source-lock review. A current source observation can refer to those bytes while leaving all lifetime and network/consensus assumptions unknown. It needs a versioned selected-source profile and an explicit test/workflow migration; merely changing the original historical hash would erase the distinction.

## QROM implementation: two project-source changes

The active config/pon/w1-qrom-implementation-v1.json binds selected inputs from
cb114b13bf848a77634e40a08b31b30c7c758e7b. Its bytes are independently pinned by CONTRACT_SHA256 in scripts/w1_qrom_implementation_audit.py.

Comparison of every selected current project file and audit helper found:

| Selected input | Historical bytes | Current bytes | Exact change |
| --- | ---: | ---: | --- |
| w1_v2_verifier/src/main.rs | 9,233 | 11,172 | Adds the explicit --native-once branch and one complete native replay with separately supplied public inputs. The existing receipt-verification branch is unchanged. The new report keeps parent eligibility and admission authorization false. |
| trnm-protocol/src/pon_wire.rs | 32,354 | 32,654 | Adds typed funded-service decoding for nonlegacy lengths of tags 2 and 5, retaining the exact legacy 80/64-byte cases. Parsing grants no authorization. |

The remaining 14 project files and all 3 audit helpers retain their original bytes. The original main.rs pin was checked against its declared historical Git blob. [pin-drift-observation.json](pin-drift-observation.json) records all 37 distinct current selected source files across the two contracts; all fetched source contents were checked against their Git blob identities.

The first size failure prevented this campaign from reaching the original retained-proof and upstream-snapshot checks. This diagnosis has not re-executed those binary checks. The retained binary, guest image and upstream snapshot must remain historical assets; none should be overwritten to manufacture a current result.

## Bounded continuation

A reviewed current mapping does not require inventing a new query bound if it remains an explicitly unqualified source observation. It still needs its own namespace, immutable source revision, strict full path/size/hash table, independent literal controls and actual original checks against the chosen inputs. A safe migration must retain the old contract and refusal, preserve every unknown/false risk field, run the full named roster, distinguish historical assets from current entrypoint bytes, and reject omitted gates, unreviewed rehashing or a changed current source.

That versioned migration is a separate continuation. This patch does not relax a size limit, remove a native source pin, amend an old snapshot, or promote HOLD to PASS. The one-line credit repair is ready to integrate independently while the native campaign proceeds.
