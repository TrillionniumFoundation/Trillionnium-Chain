import argparse,hashlib,json,os,pathlib,subprocess,sys,time
ROOT=pathlib.Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
A="d3037ca5dfb6f301757c159b7888dca9b0317be0"
def read(p):return json.loads(pathlib.Path(p).read_text())
def pin(p):
 p=pathlib.Path(p)
 return {"path":str(p),"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
def write(p,value):
 with pathlib.Path(p).open("x") as f:
  json.dump(value,f,indent=2,sort_keys=True);f.write("\n");f.flush();os.fsync(f.fileno())
 fd=os.open(str(pathlib.Path(p).parent),os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def identity():
 member=pathlib.Path("/proc/self/cgroup").read_text()
 assert member.startswith("0::/") and "hepta-runtime-job-" in member
 cg=pathlib.Path("/sys/fs/cgroup")/member.strip()[3:].lstrip("/")
 return {"pid":os.getpid(),"proc_stat":pathlib.Path("/proc/self/stat").read_text(),"boot_id":pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip(),"cgroup_membership":member,"cpu_max":(cg/"cpu.max").read_text(),"memory_max":(cg/"memory.max").read_text(),"affinity":sorted(os.sched_getaffinity(0)),"nice":os.getpriority(os.PRIO_PROCESS,0)}
os.umask(0o077)

parser=argparse.ArgumentParser()
parser.add_argument("--prepared",required=True,type=pathlib.Path)
parser.add_argument("--prepared-sha256",required=True)
args=parser.parse_args()
out=ROOT/"sequential-unfunded-launch-01";out.mkdir(exist_ok=False)
os.sched_setaffinity(0,set(range(12,20)))
before=identity();assert before["affinity"]==list(range(12,20))
clock=time.monotonic_ns();deadline=clock+7200*1_000_000_000
harness=ROOT/"sequential-unfunded-harness-01/run_sequential_unfunded.py"
assert pin(harness)["sha256"]=="21591c08cc28fcfea23967b7d1bf8db74a3eafcae07abf11dc99d54641be7c7a"
argv=["/usr/bin/python3.12","-B",str(harness),"run","--prepared",str(args.prepared),"--prepared-sha256",args.prepared_sha256,"--out",str(ROOT/"sequential-unfunded-run-01"),"--original-deadline-monotonic-ns",str(deadline),"--original-deadline-boot-id",before["boot_id"]]
declaration={"schema":"TRNM-W1-SEQUENTIAL-UNFUNDED-LAUNCH-OBSERVATION1","source_commit":A,"selected_monotonic_ns":clock,"original_deadline_monotonic_ns":deadline,"original_deadline_boot_id":before["boot_id"],"initial_identity":before,"prepared_directory":str(args.prepared),"prepared_sha256":args.prepared_sha256,"harness":pin(harness),"wrapper":pin(pathlib.Path(__file__).resolve()),"argv":argv,"funded":False,"proof_deadline_can_be_extended":False}
write(out/"declaration.json",declaration)
os.environ["PYTHONDONTWRITEBYTECODE"]="1"
os.environ["RAYON_NUM_THREADS"]="8"
os.execv(argv[0],argv)
