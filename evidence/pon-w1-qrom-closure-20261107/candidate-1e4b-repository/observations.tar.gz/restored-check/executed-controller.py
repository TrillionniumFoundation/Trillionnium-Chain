import concurrent.futures,datetime,hashlib,json,os,pathlib,re,stat,subprocess,sys,time,traceback
R=pathlib.Path('/home/qian-qi/work/chain-qrom-closure-publish-20261107')
E=pathlib.Path('/home/qian-qi/work/chain-qrom-closure-20261107-evidence')
O=E/'candidate-A-repository-check-v2'
HEAD='1e4bffc371bcdc53aabc621b6b6cb2485ab36f53'
TREE='23c95cb4acfcfd2b1355d9d6e33c4c18b3f332a0'
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='scripts/ci:scripts',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
def need(ok,message):
 if not ok:raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=R,env=ENV)
def dump(name,value):
 with (O/name).open('x') as f:json.dump(value,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
def fingerprint(st):return (st.st_dev,st.st_ino,st.st_mode,st.st_size,st.st_mtime_ns,st.st_ctime_ns)
def read_entry(root_fd,name,mode,oid):
 parts=name.encode().split(b'/');need(all(x not in (b'',b'.',b'..',b'.git') for x in parts),'noncanonical selected path')
 parent=os.dup(root_fd)
 try:
  for part in parts[:-1]:
   nxt=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent);os.close(parent);parent=nxt
  before=os.stat(parts[-1],dir_fd=parent,follow_symlinks=False)
  if mode=='120000':
   need(stat.S_ISLNK(before.st_mode),'tracked symlink type');data=os.readlink(parts[-1],dir_fd=parent)
  else:
   need(stat.S_ISREG(before.st_mode) and bool(before.st_mode&0o111)==(mode=='100755'),'tracked regular source type/mode')
   fd=os.open(parts[-1],os.O_RDONLY|os.O_NOFOLLOW,dir_fd=parent)
   with os.fdopen(fd,'rb') as f:
    need(fingerprint(os.fstat(f.fileno()))==fingerprint(before),'source changed before read')
    data=f.read(before.st_size+1)
    need(fingerprint(os.fstat(f.fileno()))==fingerprint(before) and len(data)==before.st_size,'source changed during read')
  need(fingerprint(os.stat(parts[-1],dir_fd=parent,follow_symlinks=False))==fingerprint(before),'source path changed')
  actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data,usedforsecurity=False).hexdigest()
  need(actual==oid,'selected bytes differ from A Git blob: '+name)
  return {'path':name,'mode':mode,'git_blob':oid,'bytes':len(data),'sha256':sha(data)}
 finally:os.close(parent)
def snapshot(label,selected,entries):
 need(git('rev-parse','HEAD').decode().strip()==HEAD and git('rev-parse','HEAD^{tree}').decode().strip()==TREE,'source moved from A')
 root_fd=os.open(R,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:rows=[read_entry(root_fd,name,*entries[name]) for name in sorted(selected)]
 finally:os.close(root_fd)
 status=git('status','--porcelain=v1','-z','--untracked-files=all');missing=[]
 for entry in status.split(b'\0'):
  if not entry:continue
  name=entry[3:].decode();need(entry[:3]==b' D ' and name.startswith('evidence/') and name not in selected,'unexpected source/index/worktree drift');missing.append(name)
 value={'schema':'TRNM-W1-SELECTED-A-REPOSITORY-SOURCE2','candidate':HEAD,'tree':TREE,'files':rows,'missing_historical_evidence':missing,'whole_tracked_worktree_verified':False,'scope':'Exact A Git-blob bytes for all non-evidence source and currently materialized tracked evidence, including separately restored linked historical targets. The original 499 selected set remains unchanged. Missing historical evidence remains explicit; this later snapshot is not retroactive 499 coverage or a complete worktree certificate.'}
 dump(label+'.json',value);(O/(label+'-status.bin')).write_bytes(status);return value
def execute(label,args,limit,expected_count=None):
 start=time.monotonic();timed=False
 stdout=O/(label+'.stdout.log');stderr=O/(label+'.stderr.log')
 with stdout.open('xb') as out,stderr.open('xb') as err:
  process=subprocess.Popen(args,cwd=R,env=ENV,stdout=out,stderr=err,start_new_session=True)
  try:code=process.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(process.pid,15)
   try:code=process.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(process.pid,9);code=process.wait()
 raw=stderr.read_bytes();out=stdout.read_bytes();text=raw.decode(errors='replace')
 counts=[int(x) for x in re.findall(r'(?m)^Ran ([0-9]+) tests? in [0-9.]+s$',text)]
 final_ok=bool(re.search(r'(?m)^OK$',text))
 verbose=[x for x in text.splitlines() if re.match(r'^test_\S+ \(.+\) \.\.\. ',x)]
 success_lines=[x for x in verbose if x.endswith(' ... ok')]
 unexpected=[x for x in verbose if not x.endswith(' ... ok')]
 record={'label':label,'args':args,'timeout_seconds':limit,'expected_tests':expected_count,'exit_code':code,'timed_out':timed,'seconds':time.monotonic()-start,'reported_counts':counts,'final_plain_OK':final_ok,'verbose_test_line_count':len(verbose),'successful_verbose_test_lines':len(success_lines),'non_ok_verbose_lines':unexpected,'stdout_bytes':len(out),'stdout_sha256':sha(out),'stderr_bytes':len(raw),'stderr_sha256':sha(raw)}
 if expected_count is None:record['command_passed']=code==0 and not timed
 else:record['command_passed']=code==0 and not timed and counts==[expected_count] and final_ok and len(verbose)==expected_count and not unexpected
 dump(label+'.json',record);print(json.dumps({'stage':label,'exit_code':code,'timed_out':timed,'reported_counts':counts,'verbose_lines':len(verbose),'command_passed':record['command_passed']}),flush=True);return record
payload=json.load(sys.stdin);O.mkdir(mode=0o700)
(O/'executed-controller.py').write_text(payload['driver_source'])
original=json.loads((E/'candidate-A-python-499-v1/selected-source-before.json').read_text())
need(original['candidate']==HEAD and original['tree']==TREE,'original A source')
selected={x['path'] for x in original['files']}
entries={}
for entry in git('ls-tree','-r','-z',HEAD).split(b'\0'):
 if entry:
  metadata,path=entry.split(b'\t',1);mode,kind,oid=metadata.decode().split();need(kind=='blob' and mode in ('100644','100755','120000'),'tracked type');entries[path.decode()]=(mode,oid)
restoration=json.loads((E/'candidate-A-link-materialization-v1/report.json').read_text())
need((E/'candidate-A-link-materialization-v1/complete.json').is_file(),'link restoration incomplete')
for path in entries:
 if path.startswith('evidence/') and (R/path).exists():selected.add(path)
need(selected<=set(entries),'selected path absent from A tree')
before=snapshot('selected-source-before',selected,entries)
old={x['path']:x for x in original['files']};current={x['path']:x for x in before['files']}
need(all(current.get(path)==row for path,row in old.items()),'original 499 selected source changed')
need(len(before['missing_historical_evidence'])<len(original['missing_historical_evidence']),'restoration did not reduce omissions')
result=execute('repository-check',['python3','scripts/ci/check_repository.py'],600,None)
after=snapshot('selected-source-after',selected,entries)
need(after==before,'A source/fixtures changed during repository check')
summary={'schema':'TRNM-W1-A-DESKTOP-REPOSITORY-CHECK2','candidate':HEAD,'tree':TREE,'driver_sha256':sha(payload['driver_source'].encode()),'record':result,'selected_source_before_after_identical':True,'original_499_selected_rows_unchanged':True,'original_499_report_unchanged_and_still_records_repository_pending':True,'historical_missing_count':len(before['missing_historical_evidence']),'scope':'Independent later repository check after exact-A historical link restoration; no rerun or expansion of the earlier 499 test coverage','selected_source_count':len(selected),'selected_source_bytes':sum(x['bytes'] for x in before['files']),'whole_source_qualified':False,'post_quantum_soundness_qualified':False,'production_qualified':False,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
dump('report.json',summary);print(json.dumps(summary),flush=True)
need(result['command_passed'],'repository check failed; raw output retained')
