"""One-time author of the default-genesis persistent HIA owner. No hosted runtime."""
from pathlib import Path
import ast,copy,hashlib,json,re,struct,subprocess,sys
BASE=Path("/tmp/trnm-genesis-owner-20261116-8ppak97a")
ROOT=BASE/"repo"
OUT=ROOT/"hia/platform/genesis_store"
TOOLCHAIN=Path("/tmp/trnm-threadcpu-native-20261116-qvgbgeb_/pinned-hepta-f33d")
sys.path.insert(0,str(TOOLCHAIN))
sys.path.insert(0,str(ROOT))
from tools.generate_hia_selfhost import Builder as OriginalBuilder, compact_authoring_cfg,total_scalar_functions
from hepta.hia_agent_assembly import assemble_program,render_assembly
NAMES=("PHASE LAST UID MODE DIR IN_DIR LOCK FD GW GR GDEV GINO DIRDEV DIRINO LOCKDEV LOCKINO "
 "FDEV FINO TOTAL PREFIX SCAN_MASK SCAN_EXPECT SCAN_NEXT PROBE CUT_SEQ CUT_NEXT CUT_TAG "
 "UNCERTAIN PUBLISHED MUTATED WORKERS STATE_AT STATE_LEN SETTINGS_LEN LOCKED FILESET COLD_NEXT PREFIX_CHECKED STDIO_READY ERRDEV ERRINO OUTDEV OUTINO INDEV ININO").split()
CONSTANTS={name:20000+8*i for i,name in enumerate(NAMES)}
CONSTANTS.update(REC=0,ACTUAL=32768,TEMP_NAME=60000,FINAL_NAME=60256,LOCK_NAME=60512)
for name,value in {"BOOT_MAGIC":b"NGBOOT01","RECORD_MAGIC":b"NGSTATE1","OPEN_MAGIC":b"NGOPEN01",
 "READ_MAGIC":b"NGREAD01","CMD_MAGIC":b"NGCMD001","CUT_MAGIC":b"NGCUT001",
 "CONSTRUCTOR_MAGIC":b"SDV1","SETTINGS_MAGIC":b"SDO1","STATE_MAGIC":b"SRV1",
 "NAME_PREFIX":b"ng1.","PENDING_SUFFIX":b".pending","STATE_SUFFIX":b".state",
 "LOCK_WORD0":b"ng1.owne","LOCK_WORD1":b"r.lock"}.items():
 CONSTANTS[name]=int.from_bytes(value,"little")
class Builder(OriginalBuilder):
 def expr(self,node):
  result=super().expr(node)
  if result is not None and result[1] in {"u8","u16","u32","usize"}:
   return self.cast(result,"u64")
  return result
class Constants(ast.NodeTransformer):
 def visit_Name(self,node):
  if isinstance(node.ctx,ast.Load) and node.id in CONSTANTS:
   return ast.copy_location(ast.Constant(CONSTANTS[node.id]),node)
  return node
def need(condition,message):
 if not condition:raise ValueError(message)
def phase_value(statement):
 if not isinstance(statement,ast.If):return None
 expression=statement.test
 if (isinstance(expression,ast.Compare) and isinstance(expression.left,ast.Name)
   and expression.left.id=="phase" and len(expression.ops)==1 and isinstance(expression.ops[0],ast.Eq)
   and isinstance(expression.comparators[0],ast.Constant)):
  return expression.comparators[0].value
 return None
def split_phases(nodes):
 additional=[]
 for node in nodes:
  if node.name not in {"ng_boot","ng_initialize","ng_cold","ng_requests","ng_scan","ng_stdio"}:continue
  branches=[s for s in node.body if phase_value(s) is not None]
  need(bool(branches),"Missing owner phases")
  prefix=node.body[:node.body.index(branches[0])]
  fallback=node.body[-1]
  body=copy.deepcopy(prefix)
  for start in range(0,len(branches),3):
   group=branches[start:start+3]
   sub=copy.deepcopy(node);sub.name=node.name+"_"+str(start//3)
   sub.body=copy.deepcopy(prefix+group+[fallback]);additional.append(sub)
   body.append(ast.parse("if phase<="+str(phase_value(group[-1]))+":\n    return "+sub.name+"(e,c,s)").body[0])
  body.append(copy.deepcopy(fallback));node.body=body
 return nodes+additional
def lower(source):
 nodes=split_phases(ast.parse(source).body)
 nodes=[Constants().visit(node) for node in nodes]
 ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[]))
 names={node.name:node.name for node in nodes}
 signatures={node.name:([arg.annotation.id for arg in node.args.args],node.returns.id) for node in nodes}
 functions=[]
 for node in nodes:
  b=Builder(node,names,signatures,total_scalar_functions(nodes));b.statements(node.body)
  functions.append({"name":node.name,"params":[b.param(p) for p in b.params],"returns":[b.returns],
   "effects":["read","write","trap"],"entry":"b0","blocks":b.blocks})
 doc={"schema":"hepta.hia.program.v8","module":"trnm_native_genesis_owner_v1","functions":functions}
 text=render_assembly(compact_authoring_cfg(doc))
 checked=assemble_program(text).as_dict()
 return text,{"functions":len(checked["functions"]),"ops":sum(len(b["ops"]) for f in checked["functions"] for b in f["blocks"])}

SOURCE = "\ndef f0(e:readbuf,c:mutbuf,s:mutbuf) -> u32:\n    if length(e)!=65536 or length(c)!=65536 or length(s)!=196608:\n        return 64\n    phase=ng_g(s,PHASE)\n    result=ng_r(e,0)\n    ng_p(s,LAST,result)\n    if phase!=0:\n        if ng_r(e,8)!=phase:\n            return ng_fail(c,s,64)\n        if result==18446744073709551612:\n            nr=ng_g(c,0)\n            if nr==0 or nr==1 or nr==17 or nr==18 or nr==5 or nr==74 or nr==217:\n                return 0\n            return ng_fail(c,s,70)\n    step=256\n    while step==256:\n        phase=ng_g(s,PHASE)\n        if phase<20:\n            step=ng_boot(e,c,s)\n        else:\n            if phase<60:\n                step=ng_initialize(e,c,s)\n            else:\n                if phase<80:\n                    step=ng_cold(e,c,s)\n                else:\n                    if phase<200:\n                        step=ng_requests(e,c,s)\n                    else:\n                        if phase<1000:\n                            step=ng_control(e,c,s)\n                        else:\n                            step=ng_scan(e,c,s)\n    return step\n\ndef ng_r(e:readbuf,p:u64) -> u64:\n    value=0\n    i=0\n    while i<8:\n        value=value|(byte(e,p+i)<<(8*i))\n        i=i+1\n    return value\n\ndef ng_r32(e:readbuf,p:u64) -> u64:\n    value=0\n    i=0\n    while i<4:\n        value=value|(byte(e,p+i)<<(8*i))\n        i=i+1\n    return value\n\ndef ng_g(s:mutbuf,p:u64) -> u64:\n    value=0\n    i=0\n    while i<8:\n        value=value|(byte(s,p+i)<<(8*i))\n        i=i+1\n    return value\n\ndef ng_g32(s:mutbuf,p:u64) -> u64:\n    value=0\n    i=0\n    while i<4:\n        value=value|(byte(s,p+i)<<(8*i))\n        i=i+1\n    return value\n\ndef ng_p(s:mutbuf,p:u64,value:u64) -> u64:\n    i=0\n    while i<8:\n        store(s,p+i,value&255)\n        value=value>>8\n        i=i+1\n    return 0\n\ndef ng_take(e:readbuf,s:mutbuf,p:u64,q:u64,n:u64) -> u64:\n    i=0\n    while i<n:\n        store(s,p+i,byte(e,q+i))\n        i=i+1\n    return 0\n\ndef ng_copy(a:mutbuf,b:mutbuf,p:u64,q:u64,n:u64) -> u64:\n    i=0\n    while i<n:\n        store(b,p+i,byte(a,q+i))\n        i=i+1\n    return 0\n\ndef ng_inside(s:mutbuf,p:u64,q:u64,n:u64) -> u64:\n    i=0\n    while i<n:\n        store(s,p+i,byte(s,q+i))\n        i=i+1\n    return 0\n\ndef ng_equal(e:readbuf,s:mutbuf,p:u64,q:u64,n:u64) -> u64:\n    i=0\n    while i<n:\n        if byte(e,p+i)!=byte(s,q+i):\n            return 0\n        i=i+1\n    return 1\n\ndef ng_zero(s:mutbuf,p:u64,n:u64) -> u64:\n    i=0\n    while i<n:\n        store(s,p+i,0)\n        i=i+1\n    return 0\n\ndef ng_go(s:mutbuf,phase:u64) -> u32:\n    ng_p(s,PHASE,phase)\n    return 256\n\ndef ng_issue(c:mutbuf,s:mutbuf,phase:u64,nr:u64,a:u64,b:u64,d:u64,f:u64,g:u64,mask:u64) -> u32:\n    ng_p(c,0,nr)\n    ng_p(c,8,a)\n    ng_p(c,16,b)\n    ng_p(c,24,d)\n    ng_p(c,32,f)\n    ng_p(c,40,g)\n    ng_p(c,48,0)\n    ng_p(c,56,mask)\n    ng_p(c,64,phase)\n    ng_p(s,PHASE,phase)\n    return 0\n\ndef ng_fail(c:mutbuf,s:mutbuf,code:u64) -> u32:\n    if ng_g(s,UNCERTAIN)!=0:\n        code=71\n    ng_p(c,72,code)\n    ng_p(c,80,ng_g(s,PHASE))\n    ng_p(c,88,ng_g(s,LAST))\n    ng_p(c,96,ng_g(s,UNCERTAIN))\n    ng_p(c,104,ng_g(s,PUBLISHED))\n    ng_p(c,112,ng_g(s,MUTATED))\n    ng_p(c,120,ng_g(s,CUT_TAG))\n    return code\n\ndef ng_io(e:readbuf,c:mutbuf) -> u64:\n    result=ng_r(e,0)\n    left=ng_g(c,24)\n    if result==0 or result>left:\n        return 2\n    if result==left:\n        return 1\n    ng_p(c,16,ng_g(c,16)+result)\n    ng_p(c,24,left-result)\n    if ng_g(c,0)==17 or ng_g(c,0)==18:\n        ng_p(c,32,ng_g(c,32)+result)\n    return 0\n\ndef ng_path(c:mutbuf,s:mutbuf,at:u64,name:u64,n:u64) -> u64:\n    ng_zero(c,at,256)\n    ng_copy(s,c,at,name,n)\n    return 65536+at\n\ndef ng_cut(c:mutbuf,s:mutbuf,next:u64,tag:u64) -> u32:\n    ng_p(s,CUT_TAG,tag)\n    if ng_g(s,GW)==18446744073709551615:\n        return ng_go(s,next)\n    ng_p(s,CUT_NEXT,next)\n    ng_p(s,CUT_SEQ,ng_g(s,CUT_SEQ)+1)\n    ng_p(c,128,CUT_MAGIC)\n    ng_p(c,136,ng_g(s,CUT_SEQ))\n    ng_p(c,144,tag)\n    ng_p(c,152,ng_g(s,PUBLISHED))\n    return ng_issue(c,s,900,1,ng_g(s,GW),65664,32,0,0,2)\n\ndef ng_control(e:readbuf,c:mutbuf,s:mutbuf) -> u32:\n    phase=ng_g(s,PHASE)\n    if phase<900:\n        return ng_stdio(e,c,s)\n    if phase==900:\n        status=ng_io(e,c)\n        if status==0:\n            return 0\n        if status!=1:\n            return ng_fail(c,s,70)\n        return ng_issue(c,s,901,0,ng_g(s,GR),128,1,0,0,2)\n    if phase==901:\n        if ng_r(e,0)!=1:\n            return ng_fail(c,s,70)\n        if byte(e,128)!=1:\n            return ng_fail(c,s,64)\n        return ng_go(s,ng_g(s,CUT_NEXT))\n    return ng_fail(c,s,64)\n\ndef ng_file_stat(e:readbuf,s:mutbuf,limit:u64,exact:u64) -> u64:\n    if ng_r(e,0)!=0:\n        return 0\n    if ng_r(e,144)!=1 or ng_r32(e,152)!=33152 or ng_r32(e,156)!=ng_g(s,UID):\n        return 0\n    size=ng_r(e,176)\n    if size>limit:\n        return 0\n    if exact!=0 and size!=limit:\n        return 0\n    return 1\n\ndef ng_fd_identity(e:readbuf,s:mutbuf) -> u64:\n    if ng_file_stat(e,s,ng_g(s,TOTAL),1)!=1:\n        return 0\n    if ng_r(e,128)!=ng_g(s,FDEV) or ng_r(e,136)!=ng_g(s,FINO):\n        return 0\n    return 1\n\ndef ng_record(e:readbuf,s:mutbuf,n:u64) -> u64:\n    if n<576 or n>16384 or ng_r32(e,128)!=SETTINGS_MAGIC or ng_r32(e,132)!=n:\n        return 0\n    if ng_r32(e,136)!=0 or ng_r32(e,580)!=7:\n        return 0\n    params=ng_r32(e,584)\n    model=ng_r32(e,588)\n    state=ng_r32(e,592)\n    at=576+params+model\n    if at>n or state!=n-at or state<8:\n        return 0\n    if ng_r32(e,128+at)!=STATE_MAGIC or ng_r32(e,132+at)!=7:\n        return 0\n    ng_zero(s,REC,512)\n    ng_take(e,s,REC+512,128,n)\n    ng_p(s,REC,RECORD_MAGIC)\n    ng_p(s,REC+8,512+n)\n    ng_p(s,REC+24,1)\n    ng_inside(s,REC+32,REC+512+24,32)\n    ng_inside(s,REC+64,REC+512+56,32)\n    ng_inside(s,REC+96,REC+512+152,32)\n    ng_inside(s,REC+128,REC+512+184,32)\n    ng_inside(s,REC+160,REC+512+152,32)\n    ng_p(s,REC+208,1)\n    ng_p(s,REC+344,1)\n    ng_p(s,REC+384,7)\n    ng_p(s,REC+392,state)\n    ng_p(s,REC+400,n)\n    ng_p(s,REC+416,512+at)\n    ng_p(s,REC+424,512)\n    ng_p(s,REC+432,ng_g(s,REC+512+16))\n    ng_p(s,TOTAL,512+n)\n    ng_p(s,STATE_AT,512+at)\n    ng_p(s,STATE_LEN,state)\n    ng_p(s,SETTINGS_LEN,n)\n    ng_zero(s,TEMP_NAME,256)\n    ng_zero(s,FINAL_NAME,256)\n    ng_p(s,TEMP_NAME,NAME_PREFIX)\n    ng_p(s,FINAL_NAME,NAME_PREFIX)\n    i=0\n    while i<32:\n        value=byte(s,REC+96+i)\n        high=value>>4\n        low=value&15\n        if high<10:\n            high=48+high\n        else:\n            high=87+high\n        if low<10:\n            low=48+low\n        else:\n            low=87+low\n        store(s,TEMP_NAME+4+2*i,high)\n        store(s,TEMP_NAME+5+2*i,low)\n        store(s,FINAL_NAME+4+2*i,high)\n        store(s,FINAL_NAME+5+2*i,low)\n        i=i+1\n    ng_p(s,TEMP_NAME+68,PENDING_SUFFIX)\n    ng_p(s,FINAL_NAME+68,STATE_SUFFIX)\n    ng_zero(s,LOCK_NAME,32)\n    ng_p(s,LOCK_NAME,LOCK_WORD0)\n    ng_p(s,LOCK_NAME+8,LOCK_WORD1)\n    return 1\n\ndef ng_boot(e:readbuf,c:mutbuf,s:mutbuf) -> u32:\n    phase=ng_g(s,PHASE)\n    if phase==0:\n        return ng_issue(c,s,200,5,2,128,0,0,0,2)\n    if phase==1:\n        status=ng_io(e,c)\n        if status==0:\n            return 0\n        if status!=1 or ng_r(e,128)!=BOOT_MAGIC:\n            return ng_fail(c,s,64)\n        fd=ng_r(e,136)\n        mode=ng_r(e,144)\n        option=ng_r(e,152)\n        time=ng_r(e,160)\n        workers=ng_r(e,168)\n        gw=ng_r(e,176)\n        gr=ng_r(e,184)\n        if fd<3 or fd>2147483647 or mode>2 or option>1:\n            return ng_fail(c,s,64)\n        if option==0 and time!=0:\n            return ng_fail(c,s,64)\n        if gw!=18446744073709551615 or gr!=18446744073709551615:\n            if gw<3 or gr<3 or gw>2147483647 or gr>2147483647 or gw==gr or gw==fd or gr==fd:\n                return ng_fail(c,s,64)\n        ng_p(s,IN_DIR,fd)\n        ng_p(s,MODE,mode)\n        ng_p(s,WORKERS,workers)\n        ng_p(s,GW,gw)\n        ng_p(s,GR,gr)\n        ng_p(s,FD,18446744073709551615)\n        ng_zero(c,128,16)\n        ng_p(c,128,CONSTRUCTOR_MAGIC)\n        store(c,132,option)\n        n=5\n        if option==1:\n            ng_p(c,133,time)\n            n=13\n        return ng_issue(c,s,2,4096,65664,n,0,0,0,0)\n    if phase==2:\n        n=ng_r(e,0)\n        if n>=4294967280:\n            return ng_fail(c,s,68)\n        if ng_record(e,s,n)!=1:\n            return ng_fail(c,s,64)\n        workers=ng_g(s,WORKERS)\n        if workers!=1 and workers!=2 and workers!=4 and workers!=8:\n            return ng_fail(c,s,68)\n        return ng_issue(c,s,18,95,63,0,0,0,0,0)\n    if phase==3:\n        if ng_r(e,0)>4294967295:\n            return ng_fail(c,s,70)\n        ng_p(s,UID,ng_r(e,0))\n        if ng_g(s,GW)==18446744073709551615:\n            return ng_go(s,8)\n        return ng_issue(c,s,4,5,ng_g(s,GW),128,0,0,0,2)\n    if phase==4:\n        if ng_r(e,0)!=0 or (ng_r32(e,152)&61440)!=4096:\n            return ng_fail(c,s,65)\n        if ng_stdio_alias(e,s)==1:\n            return ng_fail(c,s,65)\n        ng_p(s,GDEV,ng_r(e,128))\n        ng_p(s,GINO,ng_r(e,136))\n        return ng_issue(c,s,5,72,ng_g(s,GW),3,0,0,0,0)\n    if phase==5:\n        flags=ng_r(e,0)\n        if flags>2147483647 or (flags&3)!=1 or (flags&2097152)!=0:\n            return ng_fail(c,s,65)\n        return ng_issue(c,s,6,5,ng_g(s,GR),128,0,0,0,2)\n    if phase==6:\n        if ng_r(e,0)!=0 or (ng_r32(e,152)&61440)!=4096:\n            return ng_fail(c,s,65)\n        if ng_stdio_alias(e,s)==1:\n            return ng_fail(c,s,65)\n        if ng_r(e,128)==ng_g(s,GDEV) and ng_r(e,136)==ng_g(s,GINO):\n            return ng_fail(c,s,65)\n        return ng_issue(c,s,7,72,ng_g(s,GR),3,0,0,0,0)\n    if phase==7:\n        flags=ng_r(e,0)\n        if flags>2147483647 or (flags&3)!=0 or (flags&2097152)!=0:\n            return ng_fail(c,s,65)\n        return ng_go(s,8)\n    if phase==8:\n        ng_zero(c,128,256)\n        store(c,128,46)\n        return ng_issue(c,s,9,257,ng_g(s,IN_DIR),65664,720896,0,0,2)\n    if phase==9:\n        fd=ng_r(e,0)\n        if fd<3 or fd>2147483647:\n            return ng_fail(c,s,65)\n        ng_p(s,DIR,fd)\n        return ng_issue(c,s,10,5,fd,128,0,0,0,2)\n    if phase==10:\n        if ng_r(e,0)!=0 or ng_r32(e,152)!=16832 or ng_r32(e,156)!=ng_g(s,UID):\n            return ng_fail(c,s,65)\n        ng_p(s,DIRDEV,ng_r(e,128))\n        ng_p(s,DIRINO,ng_r(e,136))\n        return ng_issue(c,s,11,3,ng_g(s,IN_DIR),0,0,0,0,0)\n    if phase==11:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,70)\n        want=9\n        if ng_g(s,MODE)==1:\n            want=3\n        if ng_g(s,MODE)==2:\n            want=5\n        return ng_begin_scan(c,s,12,want)\n    if phase==12:\n        flags=657410\n        if ng_g(s,MODE)==0:\n            flags=657474\n        ng_path(c,s,128,LOCK_NAME,14)\n        return ng_issue(c,s,13,257,ng_g(s,DIR),65664,flags,384,0,2)\n    if phase==13:\n        fd=ng_r(e,0)\n        if fd<3 or fd>2147483647:\n            return ng_fail(c,s,65)\n        ng_p(s,LOCK,fd)\n        return ng_issue(c,s,14,5,fd,128,0,0,0,2)\n    if phase==14:\n        if ng_file_stat(e,s,0,1)!=1:\n            return ng_fail(c,s,65)\n        ng_p(s,LOCKDEV,ng_r(e,128))\n        ng_p(s,LOCKINO,ng_r(e,136))\n        return ng_issue(c,s,15,73,ng_g(s,LOCK),6,0,0,0,0)\n    if phase==15:\n        result=ng_r(e,0)\n        if result==18446744073709551605:\n            return ng_fail(c,s,67)\n        if result!=0:\n            return ng_fail(c,s,70)\n        ng_p(s,LOCKED,1)\n        want=9\n        if ng_g(s,MODE)==1:\n            want=3\n        if ng_g(s,MODE)==2:\n            want=5\n        return ng_begin_scan(c,s,16,want)\n    if phase==16:\n        return ng_cut(c,s,17,1)\n    if phase==17:\n        want=9\n        if ng_g(s,MODE)==1:\n            want=3\n        if ng_g(s,MODE)==2:\n            want=5\n        return ng_begin_scan(c,s,19,want)\n    if phase==18:\n        if ng_r(e,0)>511:\n            return ng_fail(c,s,70)\n        return ng_issue(c,s,3,107,0,0,0,0,0,0)\n    if phase==19:\n        if ng_g(s,MODE)==0:\n            return ng_go(s,30)\n        if ng_g(s,MODE)==1:\n            return ng_go(s,40)\n        return ng_go(s,35)\n    return ng_fail(c,s,64)\n\ndef ng_initialize(e:readbuf,c:mutbuf,s:mutbuf) -> u32:\n    phase=ng_g(s,PHASE)\n    if phase==30:\n        ng_p(s,PREFIX,0)\n        ng_path(c,s,128,TEMP_NAME,76)\n        return ng_issue(c,s,31,257,ng_g(s,DIR),65664,657602,384,0,2)\n    if phase==31:\n        fd=ng_r(e,0)\n        if fd<3 or fd>2147483647:\n            return ng_fail(c,s,65)\n        ng_p(s,MUTATED,1)\n        ng_p(s,FD,fd)\n        return ng_issue(c,s,32,5,fd,128,0,0,0,2)\n    if phase==32:\n        if ng_file_stat(e,s,0,1)!=1:\n            return ng_fail(c,s,65)\n        ng_p(s,FDEV,ng_r(e,128))\n        ng_p(s,FINO,ng_r(e,136))\n        ng_p(s,FILESET,1)\n        ng_p(s,PREFIX_CHECKED,1)\n        return ng_cut(c,s,59,10)\n    if phase==33:\n        prefix=ng_g(s,PREFIX)\n        total=ng_g(s,TOTAL)\n        if prefix==total:\n            return ng_go(s,38)\n        ng_copy(s,c,128,REC+prefix,total-prefix)\n        ng_p(s,MUTATED,1)\n        return ng_issue(c,s,34,18,ng_g(s,FD),65664,total-prefix,prefix,0,2)\n    if phase==34:\n        status=ng_io(e,c)\n        if status==0:\n            return 0\n        if status!=1:\n            return ng_fail(c,s,70)\n        return ng_go(s,38)\n    if phase==35:\n        ng_path(c,s,128,TEMP_NAME,76)\n        return ng_issue(c,s,36,257,ng_g(s,DIR),65664,657410,0,0,2)\n    if phase==36:\n        fd=ng_r(e,0)\n        if fd<3 or fd>2147483647:\n            return ng_fail(c,s,65)\n        ng_p(s,FD,fd)\n        return ng_issue(c,s,37,5,fd,128,0,0,0,2)\n    if phase==37:\n        if ng_file_stat(e,s,ng_g(s,TOTAL),0)!=1:\n            return ng_fail(c,s,65)\n        prefix=ng_r(e,176)\n        if ng_g(s,PREFIX_CHECKED)==1:\n            if ng_r(e,128)!=ng_g(s,FDEV) or ng_r(e,136)!=ng_g(s,FINO) or prefix!=ng_g(s,PREFIX):\n                return ng_fail(c,s,65)\n        else:\n            ng_p(s,FDEV,ng_r(e,128))\n            ng_p(s,FINO,ng_r(e,136))\n            ng_p(s,FILESET,1)\n            ng_p(s,PREFIX,prefix)\n        if prefix==0:\n            if ng_g(s,PREFIX_CHECKED)==1:\n                return ng_begin_scan(c,s,33,5)\n            ng_p(s,PREFIX_CHECKED,1)\n            return ng_cut(c,s,59,12)\n        return ng_issue(c,s,57,17,ng_g(s,FD),128,prefix,0,0,2)\n    if phase==38:\n        return ng_issue(c,s,39,74,ng_g(s,FD),0,0,0,0,0)\n    if phase==39:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,70)\n        ng_p(s,COLD_NEXT,50)\n        return ng_cut(c,s,60,11)\n    if phase==40:\n        ng_path(c,s,128,FINAL_NAME,74)\n        return ng_issue(c,s,41,257,ng_g(s,DIR),65664,657408,0,0,2)\n    if phase==41:\n        fd=ng_r(e,0)\n        if fd<3 or fd>2147483647:\n            return ng_fail(c,s,65)\n        ng_p(s,FD,fd)\n        return ng_issue(c,s,42,5,fd,128,0,0,0,2)\n    if phase==42:\n        if ng_file_stat(e,s,ng_g(s,TOTAL),1)!=1:\n            return ng_fail(c,s,65)\n        if ng_g(s,FILESET)==1:\n            if ng_r(e,128)!=ng_g(s,FDEV) or ng_r(e,136)!=ng_g(s,FINO):\n                return ng_fail(c,s,65)\n        ng_p(s,FDEV,ng_r(e,128))\n        ng_p(s,FINO,ng_r(e,136))\n        ng_p(s,FILESET,1)\n        ng_p(s,PUBLISHED,1)\n        ng_p(s,COLD_NEXT,80)\n        return ng_cut(c,s,60,20)\n    if phase==50:\n        return ng_cut(c,s,58,13)\n    if phase==51:\n        ng_path(c,s,128,TEMP_NAME,76)\n        ng_path(c,s,384,FINAL_NAME,74)\n        ng_p(s,UNCERTAIN,1)\n        return ng_issue(c,s,52,316,ng_g(s,DIR),65664,ng_g(s,DIR),65920,1,10)\n    if phase==52:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,70)\n        ng_p(s,PUBLISHED,1)\n        return ng_cut(c,s,65,14)\n    if phase==53:\n        return ng_issue(c,s,54,74,ng_g(s,DIR),0,0,0,0,0)\n    if phase==54:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,70)\n        ng_p(s,UNCERTAIN,0)\n        return ng_cut(c,s,55,15)\n    if phase==55:\n        return ng_issue(c,s,56,3,ng_g(s,FD),0,0,0,0,0)\n    if phase==56:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,70)\n        ng_p(s,FD,18446744073709551615)\n        return ng_go(s,40)\n    if phase==57:\n        status=ng_io(e,c)\n        if status==0:\n            return 0\n        if status!=1:\n            return ng_fail(c,s,70)\n        if ng_equal(e,s,128,REC,ng_g(s,PREFIX))!=1:\n            return ng_fail(c,s,66)\n        if ng_g(s,PREFIX_CHECKED)==1:\n            return ng_begin_scan(c,s,33,5)\n        ng_p(s,PREFIX_CHECKED,1)\n        return ng_cut(c,s,59,12)\n    if phase==58:\n        ng_p(s,COLD_NEXT,51)\n        return ng_go(s,60)\n    if phase==59:\n        return ng_issue(c,s,37,5,ng_g(s,FD),128,0,0,0,2)\n    return ng_fail(c,s,64)\n\ndef ng_cold(e:readbuf,c:mutbuf,s:mutbuf) -> u32:\n    phase=ng_g(s,PHASE)\n    if phase==60:\n        return ng_issue(c,s,61,5,ng_g(s,FD),128,0,0,0,2)\n    if phase==61:\n        if ng_fd_identity(e,s)!=1:\n            return ng_fail(c,s,65)\n        return ng_issue(c,s,62,17,ng_g(s,FD),128,ng_g(s,TOTAL),0,0,2)\n    if phase==62:\n        status=ng_io(e,c)\n        if status==0:\n            return 0\n        if status!=1:\n            return ng_fail(c,s,70)\n        if ng_equal(e,s,128,REC,ng_g(s,TOTAL))!=1:\n            return ng_fail(c,s,66)\n        ng_take(e,s,ACTUAL,128,ng_g(s,TOTAL))\n        source=131072+ACTUAL+ng_g(s,STATE_AT)\n        return ng_issue(c,s,63,4097,source,ng_g(s,STATE_LEN),0,0,0,0)\n    if phase==63:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,82)\n        if ng_equal(e,s,128,ACTUAL+128,32)!=1:\n            return ng_fail(c,s,83)\n        return ng_issue(c,s,64,5,ng_g(s,FD),128,0,0,0,2)\n    if phase==64:\n        if ng_fd_identity(e,s)!=1:\n            return ng_fail(c,s,65)\n        want=5\n        if ng_g(s,PUBLISHED)==1:\n            want=3\n        return ng_begin_scan(c,s,ng_g(s,COLD_NEXT),want)\n    if phase==65:\n        ng_p(s,COLD_NEXT,53)\n        return ng_go(s,60)\n    return ng_fail(c,s,64)\n\ndef ng_requests(e:readbuf,c:mutbuf,s:mutbuf) -> u32:\n    phase=ng_g(s,PHASE)\n    if phase==80:\n        ng_zero(c,128,256)\n        ng_p(c,128,OPEN_MAGIC)\n        ng_p(c,136,ng_g(s,MODE))\n        ng_p(c,144,ng_g(s,TOTAL))\n        ng_p(c,152,ng_g(s,WORKERS))\n        ng_copy(s,c,160,REC+32,128)\n        ng_copy(s,c,288,REC+160,32)\n        ng_p(c,336,7)\n        ng_p(c,344,ng_g(s,STATE_LEN))\n        ng_p(c,352,ng_g(s,REC+432))\n        return ng_issue(c,s,81,1,1,65664,256,0,0,2)\n    if phase==81:\n        status=ng_io(e,c)\n        if status==0:\n            return 0\n        if status!=1:\n            return ng_fail(c,s,70)\n        return ng_go(s,90)\n    if phase==90:\n        return ng_issue(c,s,91,0,0,128,16,0,0,2)\n    if phase==91:\n        status=ng_io(e,c)\n        if status==0:\n            return 0\n        if status!=1 or ng_r(e,128)!=CMD_MAGIC:\n            return ng_fail(c,s,64)\n        op=ng_r(e,136)\n        if op==2:\n            return ng_go(s,95)\n        if op!=1:\n            return ng_fail(c,s,64)\n        return ng_begin_scan(c,s,92,3)\n    if phase==92:\n        ng_p(s,COLD_NEXT,110)\n        return ng_cut(c,s,60,30)\n    if phase==95:\n        return ng_issue(c,s,96,3,ng_g(s,FD),0,0,0,0,0)\n    if phase==96:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,70)\n        ng_p(s,FD,18446744073709551615)\n        return ng_issue(c,s,97,3,ng_g(s,LOCK),0,0,0,0,0)\n    if phase==97:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,70)\n        ng_p(s,LOCKED,0)\n        return ng_issue(c,s,98,3,ng_g(s,DIR),0,0,0,0,0)\n    if phase==98:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,70)\n        return 1\n    if phase==110:\n        ng_zero(c,128,64)\n        ng_p(c,128,READ_MAGIC)\n        ng_p(c,136,ng_g(s,TOTAL))\n        ng_copy(s,c,144,ACTUAL+128,32)\n        ng_copy(s,c,192,ACTUAL,ng_g(s,TOTAL))\n        return ng_issue(c,s,111,1,1,65664,64+ng_g(s,TOTAL),0,0,2)\n    if phase==111:\n        status=ng_io(e,c)\n        if status==0:\n            return 0\n        if status!=1:\n            return ng_fail(c,s,70)\n        return ng_go(s,90)\n    return ng_fail(c,s,64)\n\ndef ng_name(e:readbuf,s:mutbuf,p:u64,n:u64,q:u64,m:u64) -> u64:\n    if n!=m:\n        return 0\n    return ng_equal(e,s,p,q,n)\n\ndef ng_inventory(e:readbuf,s:mutbuf,n:u64) -> u64:\n    at=0\n    mask=ng_g(s,SCAN_MASK)\n    while at<n:\n        if n-at<20:\n            return 0\n        p=128+at\n        size=byte(e,p+16)|(byte(e,p+17)<<8)\n        if size<20 or size>n-at:\n            return 0\n        length=0\n        while length<size-19 and byte(e,p+19+length)!=0:\n            length=length+1\n        if length==0 or length==size-19:\n            return 0\n        bit=0\n        if length==1 and byte(e,p+19)==46:\n            bit=8\n        if length==2 and byte(e,p+19)==46 and byte(e,p+20)==46:\n            bit=16\n        if ng_name(e,s,p+19,length,LOCK_NAME,14)==1:\n            bit=1\n        if ng_name(e,s,p+19,length,FINAL_NAME,74)==1:\n            bit=2\n        if ng_name(e,s,p+19,length,TEMP_NAME,76)==1:\n            bit=4\n        if bit==0 or (mask&bit)!=0:\n            return 0\n        mask=mask|bit\n        at=at+size\n    ng_p(s,SCAN_MASK,mask)\n    return 1\n\ndef ng_begin_scan(c:mutbuf,s:mutbuf,next:u64,want:u64) -> u32:\n    ng_p(s,SCAN_NEXT,next)\n    ng_p(s,SCAN_EXPECT,want)\n    ng_p(s,SCAN_MASK,0)\n    return ng_issue(c,s,1000,8,ng_g(s,DIR),0,0,0,0,0)\n\ndef ng_scan(e:readbuf,c:mutbuf,s:mutbuf) -> u32:\n    phase=ng_g(s,PHASE)\n    if phase==1000:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,70)\n        return ng_issue(c,s,1001,217,ng_g(s,DIR),128,8192,0,0,2)\n    if phase==1001:\n        n=ng_r(e,0)\n        if n>8192:\n            return ng_fail(c,s,70)\n        if n!=0:\n            if ng_inventory(e,s,n)!=1:\n                return ng_fail(c,s,65)\n            return ng_issue(c,s,1001,217,ng_g(s,DIR),128,8192,0,0,2)\n        mask=ng_g(s,SCAN_MASK)\n        if (mask&24)!=24:\n            return ng_fail(c,s,65)\n        found=mask&7\n        want=ng_g(s,SCAN_EXPECT)\n        if want==9:\n            if found!=0 and found!=1:\n                return ng_fail(c,s,65)\n        else:\n            if found!=want:\n                return ng_fail(c,s,65)\n        if ng_g(s,LOCKED)==0:\n            return ng_go(s,ng_g(s,SCAN_NEXT))\n        ng_path(c,s,128,LOCK_NAME,14)\n        return ng_issue(c,s,1002,257,ng_g(s,DIR),65664,657408,0,0,2)\n    if phase==1002:\n        fd=ng_r(e,0)\n        if fd<3 or fd>2147483647:\n            return ng_fail(c,s,65)\n        ng_p(s,PROBE,fd)\n        return ng_issue(c,s,1003,5,fd,128,0,0,0,2)\n    if phase==1003:\n        if ng_file_stat(e,s,0,1)!=1:\n            return ng_fail(c,s,65)\n        if ng_r(e,128)!=ng_g(s,LOCKDEV) or ng_r(e,136)!=ng_g(s,LOCKINO):\n            return ng_fail(c,s,65)\n        return ng_issue(c,s,1004,3,ng_g(s,PROBE),0,0,0,0,0)\n    if phase==1004:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,70)\n        if ng_g(s,FD)==18446744073709551615:\n            return ng_issue(c,s,1008,5,ng_g(s,DIR),128,0,0,0,2)\n        name=FINAL_NAME\n        n=74\n        if ng_g(s,SCAN_EXPECT)==5:\n            name=TEMP_NAME\n            n=76\n        ng_path(c,s,128,name,n)\n        return ng_issue(c,s,1005,257,ng_g(s,DIR),65664,657408,0,0,2)\n    if phase==1005:\n        fd=ng_r(e,0)\n        if fd<3 or fd>2147483647:\n            return ng_fail(c,s,65)\n        ng_p(s,PROBE,fd)\n        return ng_issue(c,s,1006,5,fd,128,0,0,0,2)\n    if phase==1006:\n        if ng_g(s,SCAN_NEXT)==33:\n            if ng_file_stat(e,s,ng_g(s,PREFIX),1)!=1:\n                return ng_fail(c,s,65)\n            if ng_r(e,128)!=ng_g(s,FDEV) or ng_r(e,136)!=ng_g(s,FINO):\n                return ng_fail(c,s,65)\n        else:\n            if ng_fd_identity(e,s)!=1:\n                return ng_fail(c,s,65)\n        return ng_issue(c,s,1007,3,ng_g(s,PROBE),0,0,0,0,0)\n    if phase==1007:\n        if ng_r(e,0)!=0:\n            return ng_fail(c,s,70)\n        return ng_issue(c,s,1008,5,ng_g(s,DIR),128,0,0,0,2)\n    if phase==1008:\n        if ng_r(e,0)!=0 or ng_r32(e,152)!=16832 or ng_r32(e,156)!=ng_g(s,UID):\n            return ng_fail(c,s,65)\n        if ng_r(e,128)!=ng_g(s,DIRDEV) or ng_r(e,136)!=ng_g(s,DIRINO):\n            return ng_fail(c,s,65)\n        return ng_go(s,ng_g(s,SCAN_NEXT))\n    return ng_fail(c,s,64)\n\ndef ng_stdio_alias(e:readbuf,s:mutbuf) -> u64:\n    dev=ng_r(e,128)\n    ino=ng_r(e,136)\n    if dev==ng_g(s,ERRDEV) and ino==ng_g(s,ERRINO):\n        return 1\n    if dev==ng_g(s,OUTDEV) and ino==ng_g(s,OUTINO):\n        return 1\n    if dev==ng_g(s,INDEV) and ino==ng_g(s,ININO):\n        return 1\n    return 0\n\ndef ng_stdio(e:readbuf,c:mutbuf,s:mutbuf) -> u32:\n    phase=ng_g(s,PHASE)\n    if phase==200:\n        if ng_r(e,0)!=0 or (ng_r32(e,152)&61440)!=4096:\n            return ng_fail(c,s,64)\n        ng_p(s,ERRDEV,ng_r(e,128))\n        ng_p(s,ERRINO,ng_r(e,136))\n        return ng_issue(c,s,201,72,2,3,0,0,0,0)\n    if phase==201:\n        flags=ng_r(e,0)\n        if flags>2147483647 or (flags&3)!=1 or (flags&2097152)!=0:\n            return ng_fail(c,s,64)\n        return ng_issue(c,s,202,5,1,128,0,0,0,2)\n    if phase==202:\n        if ng_r(e,0)!=0 or (ng_r32(e,152)&61440)!=4096:\n            return ng_fail(c,s,64)\n        if ng_r(e,128)==ng_g(s,ERRDEV) and ng_r(e,136)==ng_g(s,ERRINO):\n            return ng_fail(c,s,64)\n        ng_p(s,OUTDEV,ng_r(e,128))\n        ng_p(s,OUTINO,ng_r(e,136))\n        return ng_issue(c,s,203,72,1,3,0,0,0,0)\n    if phase==203:\n        flags=ng_r(e,0)\n        if flags>2147483647 or (flags&3)!=1 or (flags&2097152)!=0:\n            return ng_fail(c,s,64)\n        return ng_issue(c,s,204,5,0,128,0,0,0,2)\n    if phase==204:\n        if ng_r(e,0)!=0 or (ng_r32(e,152)&61440)!=4096:\n            return ng_fail(c,s,64)\n        if ng_r(e,128)==ng_g(s,ERRDEV) and ng_r(e,136)==ng_g(s,ERRINO):\n            return ng_fail(c,s,64)\n        if ng_r(e,128)==ng_g(s,OUTDEV) and ng_r(e,136)==ng_g(s,OUTINO):\n            return ng_fail(c,s,64)\n        ng_p(s,INDEV,ng_r(e,128))\n        ng_p(s,ININO,ng_r(e,136))\n        return ng_issue(c,s,205,72,0,3,0,0,0,0)\n    if phase==205:\n        flags=ng_r(e,0)\n        if flags>2147483647 or (flags&3)!=0 or (flags&2097152)!=0:\n            return ng_fail(c,s,64)\n        ng_p(s,STDIO_READY,1)\n        return ng_issue(c,s,1,0,0,128,64,0,0,2)\n    return ng_fail(c,s,64)\n"
BUILD = "\"\"\"Build the HIA default-genesis persistent owner without hosted runtime code.\"\"\"\nfrom __future__ import annotations\nimport argparse,hashlib,json,os,re,struct,sys\nfrom pathlib import Path\nfrom hia.platform.build import Build as PinnedBuild,inspect_executable,sha256,INPUTS as PINNED_INPUTS\nfrom hia.tools.toolchain import compose_source\nROOT=Path(__file__).resolve().parents[3]\nHERE=Path(__file__).resolve().parent\nHIA=ROOT/\"hia\"\nSKIP={\"target\",\".git\",\"__pycache__\",\".pytest_cache\"}\ndef need(condition,message):\n    if not condition:raise ValueError(message)\ndef identity(raw):\n    return {\"bytes\":len(raw),\"sha256\":sha256(raw)}\ndef file_identity(path):\n    digest=hashlib.sha256();size=0\n    need(not path.is_symlink() and path.is_file(),\"Nonregular source \"+str(path))\n    with path.open(\"rb\") as stream:\n        while block:=stream.read(1<<20):size+=len(block);digest.update(block)\n    return {\"bytes\":size,\"sha256\":digest.hexdigest()}\ndef original_manifest(repository):\n    result={}\n    for directory in (\"trillionnium\",\"config\",\"formal\"):\n        for path in sorted((repository/directory).rglob(\"*\")):\n            relative=path.relative_to(repository)\n            if any(p in SKIP for p in relative.parts):continue\n            need(not path.is_symlink(),\"Original symlink \"+str(relative))\n            if path.is_file():result[relative.as_posix()]=file_identity(path)\n    need(\"trillionnium/Cargo.lock\" in result,\"Original Cargo graph absent\")\n    return result\ndef unique_keys(pairs):\n    result={}\n    for key,value in pairs:\n        need(key not in result,\"Duplicate JSON key\")\n        result[key]=value\n    return result\ndef source_manifest(repository):\n    result={}\n    def capture(path):\n        relative=path.relative_to(repository)\n        for parent in (path,*path.parents):\n            if parent==repository.parent:break\n            need(not parent.is_symlink(),\"Source ancestor symlink \"+str(parent))\n        need(path.is_file(),\"Source absent \"+str(relative))\n        raw=path.read_bytes();entry=identity(raw)\n        need(relative.as_posix() not in result or result[relative.as_posix()]==entry,\"Source changed\")\n        result[relative.as_posix()]=entry\n        return raw\n    owned=repository/\"hia/platform/genesis_store\"\n    for path in sorted(owned.iterdir()):\n        need(not path.is_symlink(),\"Owned symlink\")\n        if path.is_file() and path.suffix in {\".py\",\".rs\",\".json\",\".hepta\",\".md\"}:capture(path)\n    for name in (\"hia/platform/build.py\",\"hia/tools/toolchain.py\",\"hia/components.json\",\n                 \"hia/tests/native_support.py\",\"hia/toolchain.lock.json\",\n                 \"hia/qualification/compiler-binding.json\"):\n        capture(repository/name)\n    for name in PINNED_INPUTS:capture(repository/\"hia\"/name)\n    configuration=json.loads((owned/\"source-inputs.json\").read_bytes(),object_pairs_hook=unique_keys)\n    need(configuration[\"schema\"]==\"trnm.hia.genesis-default-inputs.v1\",\"Configuration schema\")\n    for name in configuration[\"files\"]:\n        need(isinstance(name,str) and name.startswith(\"config/pon/\") and \"..\" not in Path(name).parts,\n             \"Configuration escapes original\")\n        capture(repository/name)\n    component=json.loads((repository/\"hia/components.json\").read_bytes(),object_pairs_hook=unique_keys)\n    need(set(component)=={\"schema\",\"includes\"} and component[\"schema\"]==\"trnm.hia.component-includes.v1\"\n        and isinstance(component[\"includes\"],dict),\"Canonical component manifest schema\")\n    def canonical(name):\n        need(isinstance(name,str) and name.startswith((\"src/\",\"platform/\",\"storage/\"))\n            and Path(name).as_posix()==name and not Path(name).is_absolute()\n            and \"..\" not in Path(name).parts and name.endswith(\".hepta\"),\"Noncanonical component path\")\n        path=repository/\"hia\"/name\n        for parent in (path,*path.parents):\n            if parent==repository:break\n            need(not parent.is_symlink(),\"Symlinked canonical dependency\")\n        need(path.is_file(),\"Missing canonical dependency\")\n        return path\n    for name in component[\"includes\"]:canonical(name)\n    available={}\n    def visit(name,ancestry):\n        need(name not in ancestry,\"Cyclic component dependency\")\n        if name in available:return available[name]\n        raw=capture(canonical(name))\n        declarations=re.findall(rb\"(?m)^fn ([A-Za-z_][A-Za-z_0-9]*)\\(\",raw)\n        bodies=re.findall(rb\"(?ms)^fn ([A-Za-z_][A-Za-z_0-9]*)\\([^\\n]*\\n.*?^end(?:\\n|$)\",raw)\n        need(len(declarations)==len(set(declarations)) and set(declarations)==set(bodies)\n            and len(bodies)==len(declarations),\"Ambiguous component functions\")\n        own={n.decode() for n in declarations};all_names=set(own)\n        rows=component[\"includes\"].get(name,[])\n        need(isinstance(rows,list),\"Malformed include list\")\n        for row in rows:\n            need(isinstance(row,dict) and set(row)=={\"source\",\"functions\"}\n                and isinstance(row[\"functions\"],list) and bool(row[\"functions\"]),\"Malformed include row\")\n            dependency=visit(row[\"source\"],(*ancestry,name))\n            for selected in row[\"functions\"]:\n                need(isinstance(selected,str) and selected in dependency and selected not in all_names,\n                    \"Missing or duplicate canonical function\")\n                all_names.add(selected)\n        available[name]=own\n        return own\n    for name in (\"src/node/settings_development.hepta\",\"src/protocol/state_root_compact.hepta\"):visit(name,())\n    return dict(sorted(result.items()))\nclass Build:\n    def __init__(self,output:Path,repository:Path=ROOT):\n        self.repository=repository.resolve(strict=True)\n        need(self.repository==ROOT.resolve(),\"Builder is from another repository\")\n        self.output=output;output.mkdir(mode=0o700)\n        self.pinned=PinnedBuild(output/\"pinned-native\")\n        self.manifest=source_manifest(self.repository)\n        self.inputs={name:(self.repository/name).read_bytes() for name in self.manifest}\n        self.original=original_manifest(self.repository)\n        sys.path.insert(0,str(self.pinned.toolchain))\n        from hepta.hia_agent_assembly import assemble_program\n        self.assemble=assemble_program\n        self.sources={\"policy\":self.inputs[\"hia/platform/genesis_store/owner_policy.hepta\"]}\n        for name,relative in ((\"settings\",\"src/node/settings_development.hepta\"),(\"root\",\"src/protocol/state_root_compact.hepta\")):\n            self.sources[name],_=compose_source(HIA/relative)\n        self.sources[\"emitter\"]=self.inputs[\"hia/platform/genesis_store/linux_emitter.hepta\"]\n        self.core={}\n        for name,raw in self.sources.items():\n            document=self.assemble(raw).as_dict()\n            self.core[name]={\"functions\":len(document[\"functions\"]),\n              \"blocks\":sum(len(f[\"blocks\"]) for f in document[\"functions\"]),\n              \"ops\":sum(len(b[\"ops\"]) for f in document[\"functions\"] for b in f[\"blocks\"])}\n            need(self.core[name][\"functions\"]<=128 and self.core[name][\"ops\"]<=8192,\"Pinned native profile exceeded\")\n        snapshot=output/\"source-snapshot\"\n        for name,raw in self.inputs.items():\n            path=snapshot/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)\n        self.check_sources()\n    def check_sources(self):\n        self.pinned.check_pin()\n        need(source_manifest(self.repository)==self.manifest,\"Complete source closure changed\")\n        for name,raw in self.inputs.items():\n            need((self.repository/name).read_bytes()==raw,\"Captured source changed: \"+name)\n        need(original_manifest(self.repository)==self.original,\"Original source changed\")\n    def build(self):\n        self.check_sources();images={}\n        for name in (\"policy\",\"settings\",\"root\"):\n            images[name]=self.pinned.stage(self.pinned.compiler,self.sources[name],\"compile-\"+name)\n            need(0<len(images[name])<=1048576,\"Native image exceeds unchanged compiler profile\")\n            (self.output/(name+\".flat\")).write_bytes(images[name])\n            (self.output/(name+\"-composed.hepta\")).write_bytes(self.sources[name])\n        writer=self.pinned.stage(self.pinned.compiler,self.sources[\"emitter\"],\"compile-emitter\")\n        inspect_executable(writer)\n        prefix=self.pinned.stage(writer,struct.pack(\"<3Q\",*(len(x) for x in images.values())),\"emit-prefix\")\n        need(176<=len(prefix)<=4096,\"Native ELF prefix has unexpected extent\")\n        executable=prefix+b\"\".join(images.values());profile=inspect_executable(executable)\n        for name,raw in ((\"emitter.elf\",writer),(\"elf-prefix.raw\",prefix),(\"genesis-owner.elf\",executable)):\n            (self.output/name).write_bytes(raw)\n        self.check_sources()\n        report={\"schema\":\"trnm.hia.default-genesis-store-build.v1\",\"status\":\"PASS\",\n          \"source_inputs\":self.manifest,\"original_sources\":self.original,\n          \"source_set_sha256\":sha256(json.dumps(self.manifest,sort_keys=True,separators=(\",\",\":\")).encode()),\n          \"core\":self.core,\"images\":{k:identity(v) for k,v in images.items()},\n          \"emitter\":identity(writer),\"elf_prefix\":identity(prefix),\"executable\":identity(executable)|profile,\n          \"compiler_sha256\":sha256(self.pinned.compiler),\"toolchain\":self.pinned.lock,\n          \"compiler_qualification_binding\":self.pinned.binding,\"stages\":self.pinned.stages,\n          \"source_inputs_stable\":True,\"runtime_host_proxy\":False,\"rust_or_interpreter_fallback\":False,\n          \"hosted_link_action\":\"concatenate the native-emitted prefix and three exact native-compiled images\",\n          \"literal_isa_is_a_separate_trusted_boundary\":True,\"complete_node\":False,\n          \"successor_block_admission\":False}\n        (self.output/\"build.json\").write_text(json.dumps(report,sort_keys=True,indent=2)+\"\\n\")\n        return executable,report\ndef main():\n    if not __debug__ or os.environ.get(\"PYTHONOPTIMIZE\"):\n        raise RuntimeError(\"Optimized Python is not admitted\")\n    parser=argparse.ArgumentParser();parser.add_argument(\"--output\",type=Path,required=True)\n    args=parser.parse_args()\n    builder=Build(args.output);_,report=builder.build()\n    print(json.dumps({\"status\":\"PASS\",\"source_set_sha256\":report[\"source_set_sha256\"],\n      \"core\":report[\"core\"],\"executable\":report[\"executable\"]}))\nif __name__==\"__main__\":main()\n"
README = "# Native default-genesis persistent owner\n\nThis component is under development and has no qualification yet.\n\nThe native HIA owner constructs Settings::development(None or Some(timestamp)),\nthe complete seven-row initial State, the genesis catalog row, active generation\nzero and slot zero. It owns the real private directory description, its process\nlock, the file being initialized and the published file. There is no external\nState, Delta, context, expected-root or successful-admission input.\n\nThis is a fresh native stored schema. It does not read or rewrite SQLite, the\ngeneric StoreOwner namespace, deployed data or any other backend. The complete\nadmitted namespace is ng1.owner.lock and exactly one internally named pending or\nstate file. That filename contains the full native-computed genesis identity.\n\nThe finite catalog has one block with absent parent and packet, height zero and\n64 zero chainwork bytes, one active row, one initial snapshot referring to the\nsame complete State, and empty deltas, events, reorganization intent and steps,\nreorganization lifecycle, ancestry jumps, local pool, replay, audit and outbox\ncollections. Other catalogs are refused even if they claim the genesis active\ntip. This unit contains no successor-admission or arbitrary COMMIT operation.\n\nInitialization synchronizes the complete pending file, rereads it and computes\nM06 over its actual stored State, then publishes by RENAME_NOREPLACE and fsyncs\nthe directory. The same owner opens and fully validates the published file\nbefore an opened receipt. Explicit recovery validates every existing byte of\nthe context-named pending prefix before writing only its missing suffix. After every diagnostic pause before a suffix write, the owner repeats the\ncomplete existing-prefix read and validates its retained inode, size, pathname,\nlock and private directory. After the prepublication pause it repeats complete\nstored-byte and root validation. After rename, validation before directory\nsynchronization remains inside publication uncertainty. An\nunbound lock-only namespace is not a recovery capability. Simultaneous pending\nand final files, unknown entries and wrong-context filenames refuse unchanged.\n\nEvery READ repeats complete physical file reading, native root computation and\ncomparison with its actual stored catalog root. It checks the retained lock and\nfile inode against freshly opened names, along with exact directory/file\nownership, modes, regular type and one-link file ownership. Standard input, output and error must be three distinct real pipes with\nread-only, write-only and write-only access respectively. They are admitted by\nnative HIA before bootstrap reading; an unadmitted stream fails silently without\nwriting a diagnostic. Both optional diagnostic FDs must also be distinct real\npipes with the correct access mode and must not alias any standard stream. They carry pause/resume observations, not service permission or commit\nauthority.\n\nThe renameat2 RENAME_NOREPLACE call is the namespace publication linearization\npoint. A successful syscall does not itself establish directory durability.\nThe finite profile assumes a private directory and cooperating owners using the\nheld flock. Pathname checks and a later rename are separate syscalls; repeated\nchecks do not establish safety against a continuously mutating same-UID process.\nControlled pause-boundary substitutions are tested separately from this limit.\nA later missing receipt does not prove that a wrong file was never transiently\npublished, and no such claim is made for the original failing candidates.\n\nThe final rename attempt starts the publication uncertainty interval. It ends\nonly after successful directory fsync. A missing opened receipt always requires\nreopening; later response I/O failure does not establish rollback. The explicit\ndiagnostic gate can pause physical boundaries or encounter actual EOF. It does\nnot introduce a cancellable checkpoint after publication or implement the\noriginal external PQ witness CAS contract.\n\nOnly native HIA code performs construction, state interpretation, expected-root\nvalidation, filesystem state transitions and result decisions. The HIA-emitted\nLinux x86-64 adapter remains a separately trusted literal-ISA boundary. Hosted\nPython only authors, builds and qualifies source.\n\nThe original initialization relation is in store.rs 2183-2254. In this exact\nclosed genesis catalog, cold recover has no pending reorganization and its\nbest-work target equals the active genesis, so original recovery makes no\nsuccessor State write. Physical schema bytes differ because this is an explicit\nnew native format; the original full logical State and catalog facts must be\ncompared with a real original Rust Node.\n\nSettings-dependent configuration, default task material, the 65,536 classic and\n1,065,536 growth limits are unchanged. Seven rows are the result of this exact\ndefault constructor, not a replacement maximum State size.\n\nStill OPEN: complete M06 execution and its private admitted-output owner,\nvalidated successor block/receipt/task output persistence, branch catalog,\nreorganization/cancellation lifecycle, generic hot State changes, alternate\nSettings and continuity/growth constructors, GSC2, authenticated and PQ backends,\nreplay/outbox mutation owners, external anti-rollback witness, physical power\nloss, hostile continuous same-UID mutation, and original service budgets.\nNeither this unit nor its future successful tests can retire the original Node.\n"
class HIAEmitter:
    def __init__(self):
        self.lines=[];self.index=0;self.constants={};self.cursor=self.constant(0,'usize')
        self.labels={};self.fixups=[];self.emitted_literals=0
    def variable(self,typ,expression):
        name='p'+str(self.index);self.index+=1
        self.lines.append(f'  {name}:{typ} = {expression}')
        return name
    def constant(self,value,typ='u64'):
        key=(typ,value)
        if key not in self.constants:
            self.constants[key]=self.variable(typ,'const() {"value":'+str(value)+'}')
        return self.constants[key]
    def word(self,value,n):
        if isinstance(value,int):value=self.constant(value)
        count=self.constant(n,'usize')
        self.cursor=self.variable('usize',f'call(o,{self.cursor},{value},{count}) {{"function":"emit_le"}}')
    def emit(self,hexadecimal):
        raw=bytes.fromhex(hexadecimal);self.emitted_literals+=len(raw)
        for i in range(0,len(raw),8):
            chunk=raw[i:i+8];self.word(int.from_bytes(chunk,'little'),len(chunk))
    def label(self,name):
        assert name not in self.labels
        self.labels[name]=self.cursor
    def jump(self,prefix,target):
        self.emit(prefix);hole=self.cursor;self.word(0,4);self.fixups.append((hole,target))
    def call(self,target):self.jump('e8',target)
    def patch(self,offset,value,n):
        if isinstance(offset,int):offset=self.constant(offset,'usize')
        if isinstance(value,int):value=self.constant(value)
        count=self.constant(n,'usize')
        self.variable('usize',f'call(o,{offset},{value},{count}) {{"function":"emit_le"}}')
    def source(self):
        four=self.constant(4,'usize')
        for hole,target in self.fixups:
            after=self.variable('usize',f'int.add.checked({hole},{four})')
            displacement=self.variable('usize',f'int.sub.wrap({self.labels[target]},{after})')
            bits=self.variable('u64',f'int.cast({displacement}) {{"mode":"wrap"}}')
            self.patch(hole,bits,4)
        final=self.variable('usize',f'int.add.checked({self.cursor},n)')
        bits=self.variable('u64',f'int.cast({final}) {{"mode":"wrap"}}')
        self.patch(96,bits,8);self.patch(104,bits,8)
        zero=self.constant(0,'usize')
        self.lines.append(f'  _ = buffer.copy_range(o,s,{self.cursor},{zero},n)')
        result=self.variable('u32',f'int.cast({final}) {{"mode":"wrap"}}')
        self.lines.append(f'  ret({result})')
        return '''hia-asm.v1 hepta.hia.program.v8 selfhost_exec
fn f0(source:readbuf,output:mutbuf,workspace:mutbuf) -> (u32) effects(read,write,trap) entry(b0)
block b0(source:readbuf,output:mutbuf,workspace:mutbuf)
  n0:usize = buffer.len(source)
  cap0:usize = buffer.len(output)
  zero0:usize = const() {"value":0}
  limit0:usize = const() {"value":524288}
  space0:usize = const() {"value":1048576}
  empty0:bool = compare.eq(n0,zero0)
  large0:bool = compare.gt(n0,limit0)
  small0:bool = compare.lt(cap0,space0)
  bad0:bool = bool.or(empty0,large0)
  bad1:bool = bool.or(bad0,small0)
  branch bad1 b1() b2(source,output,n0)
block b1()
  capacity_error:u32 = const() {"value":4294967294}
  ret(capacity_error)
block b2(s:readbuf,o:mutbuf,n:usize)
'''+'\n'.join(self.lines)+'''
end
fn emit_le(o0:mutbuf,pos0:usize,word0:u64,count0:usize) -> (usize) effects(write,trap) entry(e0)
block e0(o0:mutbuf,pos0:usize,word0:u64,count0:usize)
  index0:usize = const() {"value":0}
  jump e1(o0,pos0,word0,count0,index0)
block e1(o1:mutbuf,pos1:usize,word1:u64,count1:usize,index1:usize)
  done1:bool = compare.eq(index1,count1)
  branch done1 e3(pos1) e2(o1,pos1,word1,count1,index1)
block e2(o2:mutbuf,pos2:usize,word2:u64,count2:usize,index2:usize)
  byte2:u8 = int.cast(word2) {"mode":"wrap"}
  _ = buffer.store(o2,pos2,byte2)
  one2:usize = const() {"value":1}
  eight2:u64 = const() {"value":8}
  nextpos2:usize = int.add.checked(pos2,one2)
  nextindex2:usize = int.add.checked(index2,one2)
  nextword2:u64 = int.shr.checked(word2,eight2)
  jump e1(o2,nextpos2,nextword2,count2,nextindex2)
block e3(finalpos3:usize)
  ret(finalpos3)
end
'''



class PrefixEmitter(HIAEmitter):
 def source(self):
  four=self.constant(4,"usize")
  for hole,target in self.fixups:
   after=self.variable("usize",f"int.add.checked({hole},{four})")
   delta=self.variable("usize",f"int.sub.wrap({self.labels[target]},{after})")
   bits=self.variable("u64",f'int.cast({delta}) {{"mode":"wrap"}}')
   self.patch(hole,bits,4)
  final=self.variable("usize",f"int.add.checked({self.cursor},n)")
  bits=self.variable("u64",f'int.cast({final}) {{"mode":"wrap"}}')
  self.patch(96,bits,8);self.patch(104,bits,8)
  result=self.variable("u32",f'int.cast({self.cursor}) {{"mode":"wrap"}}')
  self.lines.append(f"  ret({result})")
  header='''hia-asm.v1 hepta.hia.program.v8 selfhost_exec
fn f0(source:readbuf,output:mutbuf,workspace:mutbuf) -> (u32) effects(read,write,trap) entry(b0)
block b0(source:readbuf,output:mutbuf,workspace:mutbuf)
  size:usize = buffer.len(source)
  expect:usize = const() {"value":24}
  capacity:usize = buffer.len(output)
  minimum:usize = const() {"value":4096}
  wrong:bool = compare.ne(size,expect)
  short:bool = compare.lt(capacity,minimum)
  bad:bool = bool.or(wrong,short)
  branch bad fail() read(source,output)
block fail()
  refusal:u32 = const() {"value":4294967294}
  ret(refusal)
block read(input:readbuf,out:mutbuf)
  zero:usize = const() {"value":0}
  eight:usize = const() {"value":8}
  sixteen:usize = const() {"value":16}
  one_image:usize = const() {"value":1048576}
  a:usize = call(input,zero) {"function":"read_le"}
  b:usize = call(input,eight) {"function":"read_le"}
  c:usize = call(input,sixteen) {"function":"read_le"}
  a0:bool = compare.eq(a,zero)
  a1:bool = compare.gt(a,one_image)
  b0:bool = compare.eq(b,zero)
  b1:bool = compare.gt(b,one_image)
  c0:bool = compare.eq(c,zero)
  c1:bool = compare.gt(c,one_image)
  aa:bool = bool.or(a0,a1)
  bb:bool = bool.or(b0,b1)
  cc:bool = bool.or(c0,c1)
  ab:bool = bool.or(aa,bb)
  invalid:bool = bool.or(ab,cc)
  branch invalid fail() body(out,a,b,c)
block body(o:mutbuf,policy_bytes:usize,settings_bytes:usize,root_bytes:usize)
  image_sum:usize = int.add.checked(policy_bytes,settings_bytes)
  n:usize = int.add.checked(image_sum,root_bytes)
'''
  helpers=(ROOT/"hia/platform/typed_store/linux_stage_emitter.hepta").read_text()
  pieces=re.findall(r"(?ms)^fn (?:emit_le|read_le)\([^\n]*\n.*?^end(?:\n|$)",helpers)
  need(len(pieces)==2,"Canonical writer helpers missing")
  return header+"\n".join(self.lines)+"\nend\n"+"".join(pieces)
def emitter():
 e=PrefixEmitter()
 header=(b"\x7fELF\x02\x01\x01"+bytes(9)
  +struct.pack("<HHIQQQIHHHHHH",2,62,1,0x4000b0,64,0,0,64,56,2,0,0,0)
  +struct.pack("<IIQQQQQQ",1,5,0,0x400000,0x400000,0,0,4096)
  +struct.pack("<IIQQQQQQ",0x6474e551,6,0,0,0,0,0,16))
 e.emit(header.hex())
 e.emit("31ff be00001500 ba03000000 41ba22000000 49c7c0ffffffff 4531c9 b809000000")
 e.call("syscall");e.emit("4885c0");e.jump("0f88","map_failed")
 e.emit("4989c4 4d89e5 4d8db42400000100 4d8dbc2400000200")
 e.emit("49c784240001000001000000 bf0d000000 498db42400010000 31d2 41ba08000000 b80d000000")
 e.call("syscall");e.emit("4885c0");e.jump("0f88","map_failed")
 e.label("loop")
 e.emit("4c89ef be00000100 4c89f2 b900000100 4d89f8 41b900000300")
 e.call("policy")
 e.emit("85c0");e.jump("0f84","issue")
 e.emit("83f801");e.jump("0f84","success")
 e.emit("89c3");e.jump("e9","failed")
 e.label("issue")
 e.emit("498b06 483d00100000");e.jump("0f84","settings_call")
 e.emit("483d01100000");e.jump("0f84","root_call")
 profile={0:"rw",1:"rw",17:"rw",18:"rw",217:"rw",5:"stat",257:"path",316:"rename",
  3:"plain",8:"plain",72:"plain",73:"plain",74:"plain",95:"plain",107:"plain"}
 for nr,kind in profile.items():
  e.emit("483d"+struct.pack("<I",nr).hex());e.jump("0f84","profile_"+kind)
 e.jump("e9","invalid")
 e.label("profile_rw")
 e.emit("49837e3802");e.jump("0f85","invalid")
 e.emit("498b4610 498b5618");e.call("range");e.jump("e9","marshal")
 e.label("profile_stat")
 e.emit("49837e3802");e.jump("0f85","invalid")
 e.emit("498b4610 ba90000000");e.call("range");e.jump("e9","marshal")
 e.label("profile_path")
 e.emit("49837e3802");e.jump("0f85","invalid")
 e.emit("498b4610 ba00010000");e.call("range");e.jump("e9","marshal")
 e.label("profile_rename")
 e.emit("49837e380a");e.jump("0f85","invalid")
 e.emit("498b4610 ba00010000");e.call("range")
 e.emit("498b4620 ba00010000");e.call("range");e.jump("e9","marshal")
 e.label("profile_plain")
 e.emit("49837e3800");e.jump("0f85","invalid")
 e.label("marshal")
 e.emit("498b06 498b7e08 498b7610 498b5618 4d8b5620 4d8b4628 4d8b4e30")
 e.emit("49f7463802000000");e.jump("0f84","no_arg2")
 e.emit("4c01e6")
 e.label("no_arg2")
 e.emit("49f7463808000000");e.jump("0f84","arguments")
 e.emit("4d01e2")
 e.label("arguments")
 e.call("syscall");e.jump("e9","reply")
 e.label("settings_call")
 e.emit("49817e0880000100");e.jump("0f85","invalid")
 e.emit("498b7610 4883fe05");e.jump("0f84","settings_args")
 e.emit("4883fe0d");e.jump("0f85","invalid")
 e.label("settings_args")
 e.emit("498dbc2480000100 498d9580000000 b900400000 4d8d842400000500 41b900001000")
 e.call("settings");e.jump("e9","reply")
 e.label("root_call")
 e.emit("498b7e08 498b7610 4881ff00800200");e.jump("0f82","invalid")
 e.emit("4881ff00c20200");e.jump("0f87","invalid")
 e.emit("b800c20200 4829f8 4839c6");e.jump("0f87","invalid")
 e.emit("4c01e7 498d9580000000 b920000000 4d8d842400000500 41b900001000")
 e.call("root")
 e.label("reply")
 e.emit("49894500 498b4e40 49894d08");e.jump("e9","loop")
 e.label("range")
 e.emit("483d80000000");e.jump("0f82","invalid")
 e.emit("483d00000100");e.jump("0f86","event_range")
 e.emit("483d80000100");e.jump("0f82","invalid")
 e.emit("483d00000200");e.jump("0f87","invalid")
 e.emit("41bb00000200");e.jump("e9","range_end")
 e.label("event_range");e.emit("41bb00000100")
 e.label("range_end");e.emit("4929c3 4c39da");e.jump("0f87","invalid");e.emit("c3")
 e.label("success");e.emit("31ff b83c000000");e.call("syscall");e.emit("0f0b")
 e.label("failed")
 e.emit("4983bf"+struct.pack("<I",CONSTANTS["STDIO_READY"]).hex()+"01");e.jump("0f85","diag_done")
 e.emit("498d7648 ba38000000 41bc08000000")
 e.label("diagnostic")
 e.emit("41ffcc");e.jump("0f88","diag_done")
 e.emit("b801000000 bf02000000");e.call("syscall")
 e.emit("4883f8fc");e.jump("0f84","diagnostic")
 e.emit("4885c0");e.jump("0f8e","diag_done")
 e.emit("4839d0");e.jump("0f87","diag_done")
 e.emit("4801c6 4829c2");e.jump("0f85","diagnostic")
 e.label("diag_done");e.emit("89df b83c000000");e.call("syscall");e.emit("0f0b")
 e.label("invalid");e.emit("bf4e000000 b83c000000");e.call("syscall");e.emit("0f0b")
 e.label("map_failed");e.emit("bf4f000000 b83c000000");e.call("syscall");e.emit("0f0b")
 e.label("syscall");e.emit("0f05c3")
 e.label("policy")
 e.labels["settings"]=e.variable("usize",f"int.add.checked({e.cursor},policy_bytes)")
 e.labels["root"]=e.variable("usize",f'int.add.checked({e.labels["settings"]},settings_bytes)')
 return e.source()

def main():
 need(__debug__,"Optimized authoring is refused")
 preflight=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=ROOT,capture_output=True,timeout=60)
 (BASE/"author-v5-preflight.stdout").write_bytes(preflight.stdout)
 (BASE/"author-v5-preflight.stderr").write_bytes(preflight.stderr)
 need(preflight.returncode==0,"Project boundary refused authoring")
 current=json.loads((BASE/"build-v4/build.json").read_text())
 before={}
 for path in sorted(OUT.iterdir()):
  need(path.is_file() and not path.is_symlink(),"Unexpected owned path")
  relative=path.relative_to(ROOT).as_posix()
  content=path.read_bytes()
  identity={"bytes":len(content),"sha256":hashlib.sha256(content).hexdigest()}
  need(identity==current["source_inputs"][relative],"V4 source drift: "+relative)
  before[path.name]=identity
 need(set(before)=={"README.md","abi.json","build.py","linux_emitter.hepta","owner_policy.hepta","source-inputs.json"},"Unexpected source set")
 need(before["owner_policy.hepta"]["sha256"]=="a742d30759d34fa0b2225e5e861737edd0ef98ffb8d7da9f2b11d350018b3a05","Wrong old policy")
 observation=BASE/"interleavings-v4/report.json"
 need(hashlib.sha256(observation.read_bytes()).hexdigest()=="c145f13fc50d3c628117985acf0622fb7cbb0e6febc4784aa9c827907ac201d3","Missing actual old failures")
 archive=BASE/"gate-and-stdio-v5-before"
 need(not archive.exists(),"Do not overwrite previous source")
 archive.mkdir(mode=0o700)
 for path in sorted(OUT.iterdir()):(archive/path.name).write_bytes(path.read_bytes())
 policy,core=lower(SOURCE)
 need(core["functions"]<=128 and core["ops"]<=8192,"Owner exceeds original compiler profile")
 emitted=emitter();assemble_program(emitted)
 abi=json.loads((OUT/"abi.json").read_text())
 abi["stdio"]={"input_fd":0,"output_fd":1,"error_fd":2,"required_types":"three distinct FIFO/pipe objects",
  "access_modes":["RDONLY","WRONLY","WRONLY"],"O_PATH":False,
  "gate_aliases_standard_stream":False,"failed_admission":"silent exit64; no diagnostic write"}
 abi["gate"]["tags"]["1"]="held lock admitted; after resume repeat complete namespace and held-lock checks"
 abi["gate"]["tags"]["10"]="pending created; after resume recheck empty prefix, inode, name and lock before write"
 abi["gate"]["tags"]["12"]="prior prefix validated; after resume reread exact same prefix and pin namespace before write"
 abi["gate"]["tags"]["13"]="pending verified; after resume repeat complete bytes/root and inode/name checks before rename"
 abi["gate"]["tags"]["14"]="rename succeeded; still uncertain, repeat complete root/name checks before directory fsync"
 abi["scope"]["controlled_pause_interleavings_only"]=True
 abi["scope"]["continuous_hostile_same_uid_safety"]=False
 (OUT/"owner_policy.hepta").write_text(policy)
 (OUT/"linux_emitter.hepta").write_text(emitted)
 (OUT/"README.md").write_text(README)
 (OUT/"abi.json").write_text(json.dumps(abi,sort_keys=True,indent=2)+"\n")
 owned={p.name:{"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.iterdir())}
 report={"schema":"trnm.genesis-owner-controlled-gate-and-stdio-fix.v1","status":"NEW_SOURCE_NOT_YET_COMPILED",
  "before":before,"after":owned,"core":core,"actual_prior_interleavings":str(observation),
  "old_executable":current["executable"],"old_source_set_sha256":current["source_set_sha256"],
  "changes":["Repeat full namespace and retained lock checks after tag1",
   "Repeat exact held inode/size/prefix and namespace checks after tag10 and tag12 before writing",
   "Repeat full actual bytes/root and name/inode checks after tag13 before rename",
   "Repeat full actual bytes/root/name checks after tag14 inside publication uncertainty before directory fsync",
   "Admit all three distinct standard pipes in HIA and suppress diagnostics until admission",
   "Reject all diagnostic pipe aliases with standard pipes"],
  "limits":["Cooperating owners and private directory; pathname check and rename remain separate syscalls",
   "No claim of physical power loss or continuously hostile same-UID safety",
   "No successor admission or arbitrary COMMIT"]}
 (BASE/"gate-and-stdio-v5-source-change.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
 print(json.dumps({"status":report["status"],"core":core,"owned":owned}))
if __name__=="__main__":main()
