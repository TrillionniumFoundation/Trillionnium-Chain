#!/usr/bin/env python3
"""Bind a future committed C3 merge to the reviewed C2 + fixed-upstream tree.

This adapter only reads the repository and writes a new external observation
directory. It never installs itself, changes source, runs CI, compiles, proves,
checks out, commits, fetches, pushes, or replaces an earlier qualification.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import time

C2_HEAD = "cc4dd8bdd89309c635831db30b508af2f89419d7"
C2_TREE = "161d3a4e8ab8c865869352339ec8c66f6609449a"
C2_FROZEN_SHA = "cc83b9a4020b9437c72bbfdd2d01eebcf397e096ff7fbcc17272bfffe8c4cbc7"
UPSTREAM_HEAD = "cb314bb4656e5da4844325cd83994ab4764fe8e9"
COMMON_ANCESTOR = "819309fd312298e099642e1253b1d4ba07113e98"
MERGE_REVIEW_SHA = "2c359f84a54ca90e5a1cae9a8e3d15d717d72df0b3ba45d7610327d60eb438db"
WRAPPER_SHA = "c6fa6f1d080c1a50424d646670280ed962e0330eef4a410c14fd93ac5c2e4c74"
PLAN = "docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md"
CORPUS = "config/pon/pq-cross-branch-corpus-v1.json"
WORKFLOW = ".github/workflows/pon-recent-batch-acceptance.yml"
STORE = "trillionnium/crates/trnm-pon-node/src/store.rs"
INVENTORY = "trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs"
ADMISSION = "trillionnium/crates/trnm-pon-node/src/store/legacy_admission_root_tests.rs"
REORG = "trillionnium/crates/trnm-pon-node/src/store/legacy_reorg_root_tests.rs"
STATE_RECOVERY = "docs/protocol/pon-nakamoto-v1/details/STATE_RECOVERY.md"
EVIDENCE = "evidence/pon-business-gates-819309-final-20261107"
NON_EVIDENCE = {WORKFLOW, CORPUS, PLAN, STATE_RECOVERY, INVENTORY, STORE, ADMISSION, REORG}

# These five reviewed compositions differ from simply taking an upstream file.
# No synthetic merge-tree conflict blob is accepted for either resolved path.
REVIEWED_COMPOSED_BLOBS = {
    WORKFLOW: "3648c5057d8cdab63975d39fa467a766631ce9a7",
    CORPUS: "5f2d34bac7140a730df6d21ab495122af437ba2b",
    PLAN: "6d7580fda53bebb2fc2f12086d182acc8549639e",
    INVENTORY: "a04c1498772583ee1d7283e86e8c482a8866515b",
    STORE: "aa4a73b4092cff5d37fdf2b8263f0a484767c25a",
}


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def git_blob(raw: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def relative_name(value: str) -> str:
    require(type(value) is str and value, "nonempty string path required")
    p = PurePosixPath(value)
    require(not p.is_absolute() and ".." not in p.parts and "." not in p.parts
            and str(p) == value and "\n" not in value and "\r" not in value,
            "unambiguous repository-relative path required")
    return value


def read_regular(path: Path) -> bytes:
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), "ordinary file required: " + str(path))
    raw = path.read_bytes()
    after = path.lstat()
    require(all(getattr(before, key) == getattr(after, key)
                for key in ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")),
            "file changed during read: " + str(path))
    return raw


def pin(path: Path) -> dict:
    raw = read_regular(path)
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}


def save_new(path: Path, value: dict) -> dict:
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, sort_keys=True, indent=2, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return pin(path)


def tree_entries(raw: bytes) -> dict:
    result = {}
    require(raw.endswith(b"\0"), "nonempty complete Git tree required")
    for item in raw[:-1].split(b"\0"):
        left, name = item.split(b"\t", 1)
        mode, kind, oid = left.decode("ascii").split(" ")
        relative = relative_name(name.decode("utf-8"))
        require(relative not in result and re.fullmatch(r"[0-9a-f]{40}", oid),
                "duplicate path or non-full Git object identity")
        result[relative] = {"mode": mode, "kind": kind, "blob": oid}
    return result


def changed_paths(left: dict, right: dict) -> list[str]:
    return sorted(name for name in set(left) | set(right) if left.get(name) != right.get(name))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--c2-frozen-record", type=Path, required=True)
    parser.add_argument("--merge-review", type=Path, required=True)
    parser.add_argument("--exact-ci-wrapper", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--exact-out", type=Path, required=True)
    args = parser.parse_args()
    for value in (args.expected_head, args.expected_tree):
        require(re.fullmatch(r"[0-9a-f]{40}", value) is not None,
                "external full commit and full tree required")
    require(args.expected_head not in (C2_HEAD, UPSTREAM_HEAD, COMMON_ANCESTOR),
            "C3 must be a distinct committed two-parent merge")
    repo = args.repo.resolve(strict=True)
    for output in (args.out, args.exact_out):
        require(output.is_absolute() and not output.exists() and not output.is_symlink()
                and not output.resolve().is_relative_to(repo),
                "new absolute external output required")
    require(args.out.resolve() != args.exact_out.resolve(), "preparation and exact outputs must differ")
    base_raw = read_regular(args.c2_frozen_record)
    require(sha(base_raw) == C2_FROZEN_SHA, "original C2 frozen-record SHA differs")
    base = json.loads(base_raw)
    require(base.get("schema") == "TRNM-W1-PUBLICATION-FROZEN-SOURCES1"
            and base.get("publication_commit") == C2_HEAD and base.get("publication_tree") == C2_TREE
            and type(base.get("paths")) is dict and len(base["paths"]) == 709,
            "original committed C2 709-path record required")
    for name in base["paths"]:
        relative_name(name)
    review_raw = read_regular(args.merge_review)
    require(sha(review_raw) == MERGE_REVIEW_SHA, "reviewed merge composition changed")
    review = json.loads(review_raw)
    require(review.get("source_head") == C2_HEAD and review.get("fixed_base") == UPSTREAM_HEAD
            and review.get("common_ancestor") == COMMON_ANCESTOR,
            "review is not bound to the fixed pair of parent sources")
    wrapper = pin(args.exact_ci_wrapper)
    require(wrapper["sha256"] == WRAPPER_SHA, "original exact CI wrapper v3 differs")
    args.out.mkdir()
    out = args.out
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "GIT_NO_LAZY_FETCH": "1"}
    attempt = {
        "schema": "TRNM-W1-C3-PUBLICATION-MERGE-MAP-PREPARATION1",
        "source_commit": args.expected_head, "source_tree": args.expected_tree,
        "expected_parents": [C2_HEAD, UPSTREAM_HEAD], "common_ancestor": COMMON_ANCESTOR,
        "previous_publication_commit": C2_HEAD, "previous_publication_tree": C2_TREE,
        "previous_frozen_record": pin(args.c2_frozen_record), "merge_review": pin(args.merge_review),
        "wrapper": pin(Path(__file__).resolve()), "exact_ci_wrapper": wrapper,
        "scope": "Exact two-parent publication merge with reviewed upstream source and evidence; no inherited experiment is requalified.",
        "commands": [], "errors": [], "preparation_complete": False,
        "exact_CI_executed": False, "fresh_proof_generations": 0, "repository_mutated": False,
    }

    def run(label: str, argv: list[str], timeout: int = 180) -> bytes:
        stdout, stderr = out / (label + ".stdout"), out / (label + ".stderr")
        begin = time.monotonic_ns()
        row = {"label": label, "argv": argv, "cwd": str(repo), "timeout_seconds": timeout}
        with stdout.open("xb") as so, stderr.open("xb") as se:
            try:
                completed = subprocess.run(argv, cwd=repo, env=env, stdin=subprocess.DEVNULL,
                                           stdout=so, stderr=se, timeout=timeout, check=False)
                row.update(exit=completed.returncode, timed_out=False)
            except subprocess.TimeoutExpired:
                row.update(exit=None, timed_out=True)
            so.flush(); os.fsync(so.fileno())
            se.flush(); os.fsync(se.fileno())
        row.update(elapsed_ns=time.monotonic_ns() - begin, stdout=pin(stdout), stderr=pin(stderr))
        attempt["commands"].append(row)
        require(row["exit"] == 0 and not row["timed_out"], "read-only command failed: " + label)
        return read_regular(stdout)

    try:
        run("00-preflight", ["/usr/bin/bash", "scripts/project-preflight.sh", "--dev"])
        head = run("01-current-head", ["git", "rev-parse", "--verify", "HEAD"]).decode().strip()
        require(head == args.expected_head, "worktree HEAD differs from external C3")
        tree = run("02-current-tree", ["git", "rev-parse", args.expected_head + "^{tree}"]).decode().strip()
        require(tree == args.expected_tree, "external C3 tree differs")
        c2_tree_id = run("03-C2-tree-identity", ["git", "rev-parse", C2_HEAD + "^{tree}"]).decode().strip()
        require(c2_tree_id == C2_TREE, "original C2 tree differs")
        parents = run("04-merge-parents", ["git", "show", "--no-patch", "--format=%P", args.expected_head]).decode().strip().split()
        require(parents == [C2_HEAD, UPSTREAM_HEAD], "C3 parents must be exactly C2 then fixed upstream")
        ancestor = run("05-common-ancestor", ["git", "merge-base", C2_HEAD, UPSTREAM_HEAD]).decode().strip()
        require(ancestor == COMMON_ANCESTOR, "parent merge base differs from reviewed merge")
        run("06-source-before", ["/usr/bin/python3", "scripts/ci/verify_ci_source.py", "--kind", "head",
            "--expected-head", args.expected_head, "--output", str(out / "source-before.json")], 300)
        source_before = json.loads(read_regular(out / "source-before.json"))
        require(source_before.get("tested_commit") == args.expected_head
                and source_before.get("tested_tree") == args.expected_tree
                and source_before.get("tracked_worktree_verified") is True
                and source_before.get("tests_executed_by_identity_check") is False,
                "actual C3 full-tree source guard failed")
        old = tree_entries(run("07-common-ancestor-tree", ["git", "ls-tree", "-r", "-z", "--full-tree", COMMON_ANCESTOR]))
        upstream = tree_entries(run("08-upstream-tree", ["git", "ls-tree", "-r", "-z", "--full-tree", UPSTREAM_HEAD]))
        c2 = tree_entries(run("09-C2-tree", ["git", "ls-tree", "-r", "-z", "--full-tree", C2_HEAD]))
        current = tree_entries(run("10-C3-tree", ["git", "ls-tree", "-r", "-z", "--full-tree", args.expected_head]))
        upstream_changes = changed_paths(old, upstream)
        added_evidence = [name for name in upstream_changes if name.startswith(EVIDENCE + "/")]
        require(set(upstream_changes) - set(added_evidence) == NON_EVIDENCE
                and len(added_evidence) == 2346 and len(upstream_changes) == 2354,
                "actual upstream change set differs from reviewed 8 sources + 2346 evidence paths")
        require(not any(name.startswith(EVIDENCE + "/") or name == EVIDENCE for name in old)
                and not any(name.startswith(EVIDENCE + "/") or name == EVIDENCE for name in c2),
                "the fixed upstream evidence directory must be new to both prior trees")
        expected = dict(c2)
        additions = []
        modifications = []
        for name in upstream_changes:
            require(name in upstream and upstream[name]["kind"] == "blob"
                    and upstream[name]["mode"] in ("100644", "100755"),
                    "upstream change is not an ordinary retained blob: " + name)
            if name in old:
                modifications.append(name)
                require(name in c2 and old[name]["mode"] == upstream[name]["mode"] == c2[name]["mode"],
                        "modified file mode or existence changed unexpectedly: " + name)
            else:
                additions.append(name)
                require(name not in c2, "upstream addition collides with C2: " + name)
            expected[name] = dict(upstream[name])
            if name in REVIEWED_COMPOSED_BLOBS:
                expected[name]["blob"] = REVIEWED_COMPOSED_BLOBS[name]
        require(set(modifications) == NON_EVIDENCE - {ADMISSION}
                and set(additions) == set(added_evidence) | {ADMISSION},
                "reviewed upstream 7 modified / 2347 added identities differ")
        require(current == expected, "C3 full tree is not the reviewed exact merge composition")
        changes = changed_paths(c2, current)
        require(changes == upstream_changes, "C2 to C3 change set differs from reviewed upstream scope")

        def current_identity(name: str) -> dict:
            relative_name(name)
            path = repo / name
            require(not any(parent.is_symlink() for parent in path.parents if parent != repo.parent),
                    "symlink parent is not a repository source")
            raw = read_regular(path)
            blob = git_blob(raw)
            require(current[name]["kind"] == "blob" and current[name]["mode"] in ("100644", "100755")
                    and blob == current[name]["blob"], "current bytes differ from committed C3: " + name)
            return {"sha256": sha(raw), "git_blob": blob, "bytes": len(raw)}

        paths = {}
        for name, previous in base["paths"].items():
            require(name in c2 and name in current and c2[name]["kind"] == "blob"
                    and previous["git_blob"] == c2[name]["blob"], "original frozen path is not bound to C2: " + name)
            identity = current_identity(name)
            if name not in changes:
                require(identity == previous and c2[name] == current[name],
                        "unchanged C2 frozen identity changed: " + name)
            paths[name] = identity
        added_frozen_paths = sorted(set(changes) - set(paths))
        for name in added_frozen_paths:
            paths[name] = current_identity(name)
        require(set(base["paths"]) & set(changes) == set(modifications),
                "old C2 map must cover exactly the seven modified merge paths")
        require(set(added_frozen_paths) == set(additions),
                "new map additions must be exactly the 2347 reviewed added paths")
        require(set(paths) == set(base["paths"]) | set(additions),
                "new map must be the exact union of the old C2 map and reviewed additions")
        require(len(paths) == 3056, "reviewed C3 frozen map must contain exactly 3056 paths")
        record = {
            "schema": "TRNM-W1-MERGE-PUBLICATION-FROZEN-SOURCES1",
            "publication_commit": args.expected_head, "publication_tree": args.expected_tree,
            "parents": parents, "common_ancestor": COMMON_ANCESTOR,
            "previous_publication_commit": C2_HEAD, "previous_publication_tree": C2_TREE,
            "previous_frozen_record": pin(args.c2_frozen_record), "merge_review": pin(args.merge_review),
            "changed_non_evidence_paths": sorted(NON_EVIDENCE), "upstream_evidence_root": EVIDENCE,
            "reviewed_composed_blobs": REVIEWED_COMPOSED_BLOBS,
            "paths": {name: paths[name] for name in sorted(paths)},
        }
        frozen = save_new(out / "frozen-sources.json", record)
        differences = save_new(out / "merge-differences.json", {
            "schema": "TRNM-W1-PUBLICATION-MERGE-DIFFERENCES1", "parents": parents,
            "source_commit": args.expected_head, "source_tree": args.expected_tree,
            "common_ancestor": COMMON_ANCESTOR,
            "changed_path_count": len(changes), "added_path_count": len(additions),
            "modified_path_count": len(modifications), "added_evidence_count": len(added_evidence),
            "paths": [{"path": name, "ancestor": old.get(name), "C2": c2.get(name),
                       "upstream": upstream.get(name), "C3": current[name]} for name in changes],
        })
        run("11-source-after", ["/usr/bin/python3", "scripts/ci/verify_ci_source.py", "--kind", "head",
            "--expected-head", args.expected_head, "--output", str(out / "source-after.json")], 300)
        source_after = json.loads(read_regular(out / "source-after.json"))
        require(source_before == source_after, "C3 source changed during map preparation")
        require(all(current_identity(name) == identity for name, identity in paths.items()),
                "C3 frozen bytes changed during preparation")
        require(sha(read_regular(args.c2_frozen_record)) == C2_FROZEN_SHA,
                "original C2 frozen record changed")
        require(sha(read_regular(args.merge_review)) == MERGE_REVIEW_SHA, "merge review changed")
        require(pin(args.exact_ci_wrapper) == wrapper, "exact CI wrapper changed")
        exact_argv = ["/usr/bin/python3", str(args.exact_ci_wrapper), "--repo", str(repo),
            "--expected-head", args.expected_head, "--expected-tree", args.expected_tree,
            "--qualification-phase", "publication-head", "--candidate-source-record", frozen["path"],
            "--candidate-source-record-sha256", frozen["sha256"], "--out", str(args.exact_out)]
        attempt.update(
            preparation_complete=True, actual_parents=parents,
            source_before=pin(out / "source-before.json"), source_after=pin(out / "source-after.json"),
            source_identity_equal_before_after=True, full_tree_matches_reviewed_composition=True,
            changed_paths=changes, added_evidence_paths=added_evidence, added_frozen_paths=added_frozen_paths,
            merge_differences=differences, frozen_source_record=frozen, frozen_path_count=len(paths),
            C2_unaffected_entries_preserved=True, inherited_experiment_qualification_reassigned=False,
            planned_exact_ci_argv=exact_argv, planned_exact_command_count=19,
            planned_selected_test_methods=471, planned_mandatory_test_methods=104,
            counts_are_actual_only_after_exact_execution=True, original_C2_CI_wrapper_reused_unchanged=True,
        )
    except Exception as error:
        attempt["errors"].append({"type": type(error).__name__, "message": str(error)})
    receipt = save_new(out / "manifest.json", attempt)
    print(json.dumps({"preparation_complete": attempt["preparation_complete"], "manifest": receipt,
                      "frozen_source_record": attempt.get("frozen_source_record"),
                      "exact_CI_executed": False, "errors": attempt["errors"]}), flush=True)
    return 0 if attempt["preparation_complete"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
