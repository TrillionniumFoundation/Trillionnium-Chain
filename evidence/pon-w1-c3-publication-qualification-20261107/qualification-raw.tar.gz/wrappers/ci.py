#!/usr/bin/env python3
"""Run the declared source/CI gates once on an externally fixed final commit.

Use the explicit code-candidate or publication-head phase. Freeze and commit all
material for that phase first. The wrapper never checks out, commits, fetches,
pushes, builds Rust or generates proof.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--qualification-phase", required=True, choices=("code-candidate", "publication-head"))
    parser.add_argument("--candidate-source-record", required=True, type=Path)
    parser.add_argument("--candidate-source-record-sha256", required=True)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if not re.fullmatch(r"[0-9a-f]{40}", args.expected_head):
        raise ValueError("expected-head must be an external full commit")
    if not re.fullmatch(r"[0-9a-f]{40}", args.expected_tree):
        raise ValueError("expected-tree must be the committed full tree")
    if not re.fullmatch(r"[0-9a-f]{64}", args.candidate_source_record_sha256):
        raise ValueError("candidate source record needs its external SHA256")
    repo = args.repo.resolve(strict=True)
    if not args.out.is_absolute() or args.out.exists() or args.out.is_symlink():
        raise ValueError("out must be a new absolute directory")
    if args.out.resolve().is_relative_to(repo):
        raise ValueError("raw output must stay outside the repository")
    if sha(args.candidate_source_record) != args.candidate_source_record_sha256:
        raise ValueError("candidate source record SHA256 differs")
    candidate = json.loads(args.candidate_source_record.read_text())
    if type(candidate.get("paths")) is not dict or not candidate["paths"]:
        raise ValueError("nonempty external frozen-source path record required")
    for relative, identity in candidate["paths"].items():
        if not relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
            raise ValueError("frozen source record must name repository-relative paths")
        path = repo / relative
        if path.is_symlink() or sha(path) != identity["sha256"]:
            raise ValueError("frozen candidate bytes differ: " + relative)
    args.out.mkdir()
    out = args.out
    commands = [
        ("preflight", ["bash", "scripts/project-preflight.sh", "--dev"], 120, None),
        ("source-before", ["python3", "scripts/ci/verify_ci_source.py",
             "--kind", "head", "--expected-head", args.expected_head,
             "--output", str(out / "source-before.json")], 300, None),
        ("ci-contract", ["python3", "scripts/ci/check_ci_contract.py"], 240, None),
        ("pq-integration", ["python3", "scripts/ci/check_pq_research_integration.py"], 240, None),
        ("distributed-inventory", ["python3", "scripts/refresh_distributed_source_inventory.py", "--check"], 120, None),
        ("current-implementation", ["python3", "scripts/ci/report_current_implementation.py", "--check"], 120, None),
        ("repository-and-markdown-links", ["python3", "scripts/ci/check_repository.py"], 360, None),
        ("ci-contract-tests", ["python3", "scripts/ci/test_ci_contract.py", "-v"], 1200, 115),
        ("pq-source-negative-tests", ["python3", "scripts/ci/test_pq_research_integration.py", "-v"], 900, 39),
        ("ci-execution-source-integrity-tests", ["python3", "scripts/ci/test_ci_execution.py"], 900, 77),
        ("project-boundary-tests", ["python3", "scripts/ci/test_project_boundary.py"], 180, 16),
        ("integration-legacy-reorg-reader-tests", ["python3", "scripts/ci/test_run_legacy_reorg_root_abba.py"], 180, 3),
        ("integration-push-source-tests", ["python3", "scripts/ci/test_integration_push_source.py"], 300, 13),
        ("w1-current-command-block", ["bash", "-euo", "pipefail", str(out / "w1-current-command-block.sh")], 600, "block"),
        ("w1-retained-staged-tests", ["python3", "-m", "unittest", "discover",
             "-s", "scripts/ci", "-p", "test_w1_staged_observer.py", "-v"], 180, 32),
        ("w1-historical-readback-tests", ["python3", "scripts/ci/test_w1_proof_latency_readback.py", "-v"], 180, 11),
        ("w1-full-v2-disposition-tests", ["python3", "scripts/ci/test_w1_full_v2_disposition.py", "-v"], 180, 11),
        ("repository-negatives", ["python3", "scripts/ci/test_repository.py", "-v"], 2700, 50),
    ]
    text = (repo / "scripts/ci/ci_job.sh").read_text()
    start_marker = "    # Real signal/deadline controls and provider contracts do not generate a proof."
    stop_marker = "    python3 scripts/ci/test_pon_w1_preparation_strategy_reader_v4.py"
    if text.count(start_marker) != 1 or text.count(stop_marker) != 1:
        raise ValueError("actual mandatory command block boundaries must be unique")
    start = text.index(start_marker)
    stop = text.index(stop_marker, start)
    block = text[start:stop]
    (out / "w1-current-command-block.sh").write_text(block)
    block_counts = {"cancellation-handoff": 22, "coordinator-contract": 20,
        "provider-contract": 11, "generation-target": 13, "owner-cancellation": 7, "source-builder": 8,
        "owned-runtime-reader": 7, "kaggle-worker-contract": 12, "winner-identity": 4}
    declaration = {
        "schema": "TRNM-W1-EXACT-COMMITTED-CI-DECLARATION1",
        "expected_head": args.expected_head, "expected_tree": args.expected_tree,
        "qualification_phase": args.qualification_phase,
        "candidate_source_record": str(args.candidate_source_record),
        "candidate_source_record_sha256": args.candidate_source_record_sha256,
        "frozen_candidate_paths": len(candidate["paths"]),
        "planned": [{"label": n, "argv": a, "timeout_seconds": t, "expected_tests": c}
                    for n, a, t, c in commands],
        "w1_command_block_sha256": sha(out / "w1-current-command-block.sh"),
        "w1_expected_counts": block_counts,
        "mandatory_test_methods_planned": sum(block_counts.values()),
        "all_selected_test_methods_planned": sum(c for _, _, _, c in commands if type(c) is int) + sum(block_counts.values()),
        "wrapper": {"path": str(Path(__file__).resolve()), "sha256": sha(Path(__file__))},
        "commit_scope": ("frozen code candidate plus candidate plan entry for the real cancellation trial"
                         if args.qualification_phase == "code-candidate"
                         else "publication head including final README and evidence"),
        "scope": "current-source, CI contracts and selected retained W1 tests; not the complete required CI matrix",
        "builds_planned": 0, "fresh_proof_generations_planned": 0,
    }
    (out / "declaration.json").write_text(json.dumps(declaration, indent=2, sort_keys=True) + "\n")
    temp = Path(tempfile.mkdtemp(prefix="trnm-w1-exact-final-ci-", dir="/dev/shm"))
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "TMPDIR": str(temp),
           "TRNM_CI_RECEIPT_DIR": str(out / "ci-receipts"), "RUST_TEST_THREADS": "1"}
    rows = []
    source_before_valid = False

    def run(label, argv, timeout, expected):
        begin = time.monotonic_ns()
        row = {"label": label, "argv": argv, "timeout_seconds": timeout, "expected_tests": expected,
               "stdout_path": str(out / (label + ".stdout.log")),
               "stderr_path": str(out / (label + ".stderr.log"))}
        with (out / (label + ".stdout.log")).open("xb") as stdout, (out / (label + ".stderr.log")).open("xb") as stderr:
            try:
                process = subprocess.run(argv, cwd=repo, env=env, stdout=stdout, stderr=stderr, timeout=timeout)
                row["returncode"] = process.returncode
            except subprocess.TimeoutExpired:
                row["returncode"] = None
                row["timed_out"] = True
        row["elapsed_ns"] = time.monotonic_ns() - begin
        row["exit"] = row["returncode"]
        row["accepted"] = row["returncode"] == 0
        if type(expected) is int:
            log = (out / (label + ".stdout.log")).read_text(errors="replace") + "\n" + (out / (label + ".stderr.log")).read_text(errors="replace")
            counts = re.findall(r"^Ran ([0-9]+) tests? in ", log, re.M)
            row["reported_tests"] = [int(n) for n in counts]
            row["accepted"] &= counts == [str(expected)] and bool(re.search(r"^OK$", log, re.M)) and "skipped=" not in log
        elif expected == "block":
            observed = {}
            for name, count in block_counts.items():
                log_path = out / "ci-receipts/w1-postwin-contracts" / (name + ".log")
                if not log_path.is_file():
                    row["accepted"] = False
                    observed[name] = None
                    continue
                log = log_path.read_text()
                counts = re.findall(r"^Ran ([0-9]+) tests? in ", log, re.M)
                observed[name] = [int(n) for n in counts]
                row["accepted"] &= counts == [str(count)] and bool(re.search(r"^OK$", log, re.M)) and "skipped=" not in log
            row["observed_block_counts"] = observed
        if label.startswith("source-") and row["returncode"] == 0:
            identity = json.loads((out / (label + ".json")).read_text())
            row["accepted"] &= (identity.get("tested_commit") == args.expected_head
                and identity.get("tested_tree") == args.expected_tree
                and identity.get("tracked_worktree_verified") is True)
        row["stdout_sha256"] = sha(out / (label + ".stdout.log"))
        row["stderr_sha256"] = sha(out / (label + ".stderr.log"))
        rows.append(row)
        (out / "progress.json").write_text(json.dumps({"checks": rows}, indent=2, sort_keys=True) + "\n")
        print(json.dumps(row, sort_keys=True), flush=True)
        return row["accepted"]

    for label, argv, timeout, expected in commands:
        accepted = run(label, argv, timeout, expected)
        if (label in ("preflight", "source-before") and not accepted) or rows[-1].get("timed_out"):
            break
        if label == "source-before":
            source_before_valid = True
    if source_before_valid:
        run("source-after", ["python3", "scripts/ci/verify_ci_source.py", "--kind", "head",
            "--expected-head", args.expected_head, "--output", str(out / "source-after.json")], 300, None)
    source_equal = False
    if (out / "source-before.json").is_file() and (out / "source-after.json").is_file():
        source_equal = json.loads((out / "source-before.json").read_text()) == json.loads((out / "source-after.json").read_text())
    frozen_after = all(not (repo / q).is_symlink() and sha(repo / q) == identity["sha256"]
                       for q, identity in candidate["paths"].items())
    remaining = [str(x.relative_to(temp)) for x in temp.iterdir()]
    if not remaining:
        temp.rmdir()
    result = {
        "schema": "TRNM-W1-EXACT-COMMITTED-CI-RESULT1",
        "qualification_phase": args.qualification_phase,
        "expected_head": args.expected_head, "expected_tree": args.expected_tree,
        "planned_checks_including_source_after": len(commands) + 1,
        "executed_checks": len(rows), "checks": rows, "commands": rows,
        "source_identity_equal_before_after": source_equal,
        "frozen_candidate_bytes_unchanged": frozen_after,
        "all_passed": len(rows) == len(commands) + 1 and all(r["accepted"] for r in rows) and source_equal and frozen_after,
        "temporary_fixture_remaining": remaining,
        "fresh_proof_generations": 0, "live_provider_proof_trials": 0,
        "all_required_ci_matrix_executed": False,
        "rust_qualification_and_real_receiver_controls": "separate owner gates, not executed here",
        "resource_completeness_established": False,
    }
    result["source_before"] = None
    result["source_after"] = None
    for phase in ("source_before", "source_after"):
        path = out / (phase.replace("_", "-") + ".json")
        if path.is_file():
            result[phase] = {"path": str(path), "sha256": sha(path),
                             "report": json.loads(path.read_text())}
    result["declaration"] = {"path": str(out / "declaration.json"),
                             "sha256": sha(out / "declaration.json")}
    result["runner"] = {"path": str(Path(__file__).resolve()), "sha256": sha(Path(__file__))}
    result["selected_test_methods_planned"] = declaration["all_selected_test_methods_planned"]
    result["mandatory_test_methods_planned"] = declaration["mandatory_test_methods_planned"]
    result["raw_files"] = [{"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}
                           for path in sorted(out.rglob("*")) if path.is_file() and not path.is_symlink()]
    (out / "aggregate.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"aggregate": str(out / "aggregate.json"), "all_passed": result["all_passed"]}), flush=True)
    return 0 if result["all_passed"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
