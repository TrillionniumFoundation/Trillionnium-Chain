import hashlib, json, os, stat, subprocess, sys, time, traceback
from pathlib import Path
repo=Path('/home/qian-qi/work/chain-pon-five-claims-20261111-d6cb')
artifacts=Path('/home/qian-qi/work/pon-five-claims-w1-artifacts-d6cb')
base='11e242dbaaae14a9d16282fe8deaf36827e98395'
expected_head=sys.argv[1]
expected_tree=sys.argv[2]
assert len(expected_head)==40 and len(expected_tree)==40
control=json.loads((artifacts/'before-native-rustup-qualified'/'summary.json').read_text())
assert control['expected_original_failure_observed'] is True and control['sqlite_layout_witness_cfg_observed'] is True
assert control['source']['head']=='e63427560885b65c57db6bdc478df023111b4733'
out=artifacts/('fixed-native-rebuilt-'+expected_head[:12])
out.mkdir(exist_ok=False)
env=os.environ.copy()
toolbin='/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin'
env['PATH']=toolbin+':'+env.get('PATH','')
env['RUSTUP_TOOLCHAIN']='1.95.0'
env['RUSTC']=toolbin+'/rustc'
env['CARGO_TARGET_DIR']='/home/qian-qi/work/chain-pon-submit-target-d6cb'
env['CARGO_BUILD_JOBS']='2'
env['RUST_TEST_THREADS']='1'
env['CARGO_TERM_COLOR']='never'
records=[]
qualification_environment={key:env.get(key) for key in ['PATH','RUSTC','RUSTUP_TOOLCHAIN','LD_LIBRARY_PATH','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RUST_TEST_THREADS','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']}
qualification_environment['release_profile_overrides']={key:value for key,value in env.items() if key.startswith('CARGO_PROFILE_RELEASE_')}
(out/'environment.json').write_text(json.dumps(qualification_environment,indent=2)+'\n')
assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS')
assert not qualification_environment['release_profile_overrides']
def capture(args):
    return subprocess.run(args,cwd=repo,env=env,check=True,capture_output=True,text=True).stdout.strip()
def run(label,args,check=True,timeout=1800):
    started=time.time()
    with (out/(label+'.stdout.log')).open('wb') as stdout, (out/(label+'.stderr.log')).open('wb') as stderr:
        process=subprocess.run(args,cwd=repo,env=env,stdout=stdout,stderr=stderr,timeout=timeout)
    record={'label':label,'argv':args,'started_unix':started,'finished_unix':time.time(),'exit_code':process.returncode}
    for name in ['stdout','stderr']:
        raw=(out/(label+'.'+name+'.log')).read_bytes()
        record[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
    records.append(record)
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if check and process.returncode: raise RuntimeError(label+' failed '+str(process.returncode))
    return process.returncode
def full_source(label):
    head=capture(['git','rev-parse','HEAD'])
    tree=capture(['git','rev-parse','HEAD^{tree}'])
    entries=subprocess.run(['git','ls-tree','-r','--full-tree','-z','HEAD'],cwd=repo,check=True,capture_output=True).stdout.split(b'\0')
    count=total=0
    for entry in entries:
        if not entry: continue
        info,path=entry.split(b'\t',1)
        mode,kind,expected=info.split()
        assert kind==b'blob', 'unexpected nonblob source '+repr(path)
        item=repo/os.fsdecode(path)
        if mode==b'120000':
            raw=os.fsencode(os.readlink(item))
            actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
            size=len(raw)
        else:
            before=item.stat()
            size=before.st_size
            digest=hashlib.sha1(b'blob '+str(size).encode()+b'\0')
            with item.open('rb') as stream:
                while True:
                    chunk=stream.read(1048576)
                    if not chunk: break
                    digest.update(chunk)
            after=item.stat()
            assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns), 'source changed during read '+str(item)
            actual=digest.hexdigest()
        assert actual==expected.decode(), 'tracked source mismatch '+str(item)
        count+=1;total+=size
    assert capture(['git','status','--porcelain'])=='', 'dirty subject'
    result={'head':head,'tree':tree,'tracked_entries_verified':count,'tracked_bytes_verified':total,'full_git_blob_equality':True}
    (out/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    return result
try:
    assert capture(['git','rev-parse','HEAD'])==expected_head
    assert capture(['git','rev-parse','HEAD^{tree}'])==expected_tree
    assert capture(['git','status','--porcelain'])==''
    run('preflight-before-build',['bash','scripts/project-preflight.sh'])
    before=full_source('source-before')
    run('rustc-version',[toolbin+'/rustc','--version'])
    run('cargo-version',[toolbin+'/cargo','--version'])
    run('metadata',[toolbin+'/cargo','metadata','--manifest-path','trillionnium/Cargo.toml','--locked','--offline','--format-version','1'])
    metadata=json.loads((out/'metadata.stdout.log').read_text())
    local_package_ids={item['id'] for item in metadata['packages'] if item['source'] is None}
    seen_local_units={}
    local_artifact_observations=[]
    def observe_local_compilation(label):
        for line in (out/(label+'.stdout.log')).read_text().splitlines():
            try: artifact=json.loads(line)
            except json.JSONDecodeError: continue
            if artifact.get('reason')!='compiler-artifact' or artifact.get('package_id') not in local_package_ids:
                continue
            source_path=Path(artifact['target']['src_path'])
            source_under_subject=source_path.is_relative_to(repo)
            unit=json.dumps({key:artifact[key] for key in ['package_id','target','profile','features','filenames']},sort_keys=True)
            previous_stage=seen_local_units.get(unit)
            observation={'stage':label,'package_id':artifact['package_id'],'source_path':str(source_path),'source_under_subject':source_under_subject,'fresh':artifact.get('fresh'),'previous_same_unit_stage':previous_stage,'features':artifact['features'],'profile':artifact['profile'],'filenames':artifact['filenames']}
            local_artifact_observations.append(observation)
            (out/'local-compilation-audit.json').write_text(json.dumps(local_artifact_observations,indent=2)+'\n')
            assert source_under_subject, observation
            assert artifact.get('fresh') is False or previous_stage is not None, observation
            seen_local_units[unit]=label
        assert local_artifact_observations, 'no local compiler artifacts observed'

    run('sqlite-qualification-build',[toolbin+'/cargo','build','--manifest-path','trillionnium/Cargo.toml','--release','--locked','--offline','-p','trnm-sqlite-io-boundary','--message-format=json'],timeout=300)
    observe_local_compilation('sqlite-qualification-build')
    sqlite_precheck=[]
    for line in (out/'sqlite-qualification-build.stdout.log').read_text().splitlines():
        try: item=json.loads(line)
        except json.JSONDecodeError: continue
        if item.get('reason')=='build-script-executed' and 'trnm-sqlite-io-boundary' in item.get('package_id',''):
            sqlite_precheck.append(item)
    (out/'sqlite-precheck-build-script.json').write_text(json.dumps(sqlite_precheck,indent=2)+'\n')
    assert len(sqlite_precheck)==1 and 'trnm_sqlite_layout_witness' in sqlite_precheck[0].get('cfgs',[]), sqlite_precheck
    run('build',[toolbin+'/cargo','test','--manifest-path','trillionnium/Cargo.toml','--release','--locked','--offline','-p','trnm-pon-node','--lib','--no-run','--message-format=json'],timeout=2400)
    observe_local_compilation('build')
    candidates=[]
    sqlite_witness=[]
    for line in (out/'build.stdout.log').read_text().splitlines():
        try: item=json.loads(line)
        except json.JSONDecodeError: continue
        if item.get('reason')=='build-script-executed' and 'trnm-sqlite-io-boundary' in item.get('package_id',''):
            sqlite_witness.append(item)
        if item.get('reason')=='compiler-artifact' and item.get('target',{}).get('name')=='trnm_pon_node' and item.get('profile',{}).get('test') and item.get('executable'):
            candidates.append(item['executable'])
    assert len(sqlite_witness)==1 and 'trnm_sqlite_layout_witness' in sqlite_witness[0].get('cfgs',[]), sqlite_witness
    (out/'sqlite-build-script.json').write_text(json.dumps(sqlite_witness[0],indent=2)+'\n')
    assert len(set(candidates))==1, candidates
    binary=Path(candidates[-1])
    binary_before=hashlib.sha256(binary.read_bytes()).hexdigest()
    selectors=["ingress::submit_activation_history_tests::submit_future_ancestor_is_checked_after_full_work_before_m06","ingress::submit_activation_history_tests::submit_bad_product_keeps_full_work_refusal_before_ancestry","ingress::submit_activation_history_tests::submit_nonmonotone_but_currently_eligible_ancestry_still_activates","ingress::submit_activation_history_tests::submit_existing_future_ancestor_keeps_exact_packet_without_replaying_work","ingress::submit_activation_history_tests::submit_detached_commit_rechecks_ancestry_under_reacquired_clock","ingress::submit_activation_history_tests::submit_ancestry_scan_keeps_original_cancellation_and_releases_slot","ingress::submit_activation_history_tests::historical_admission_without_activation_parent_keeps_its_original_contract","ingress::tests::proof_statement_precheck_rejects_before_parent_state_or_work_and_preserves_retry","ingress::tests::work_replay_does_not_hold_the_durable_owner_lock","ingress::tests::cancellation_after_actual_work_verification_has_no_commit","ingress::tests::cancellation_inside_last_work_tile_or_final_boundary_has_no_durable_packet","ingress::tests::cancellation_after_admission_preserves_fact_and_exact_retry_controls_activation","ingress::tests::context_reject_and_exact_duplicate_do_not_replay_work","ingress::tests::verified_work_cannot_bypass_destination_context_or_clock"]
    run('native-list',[str(binary),'--list'],timeout=300)
    listed=(out/'native-list.stdout.log').read_text().splitlines()
    for selector in selectors:
        assert listed.count(selector+': test')==1, 'missing or duplicated exact test: '+selector
    native_results=[]
    for index,selector in enumerate(selectors):
        label='native-'+str(index+1).zfill(2)
        code=run(label,[str(binary),'--exact',selector,'--nocapture','--test-threads=1'],check=False,timeout=300)
        stdout=(out/(label+'.stdout.log')).read_text()
        stderr=(out/(label+'.stderr.log')).read_text()
        passed=code==0 and 'running 1 test' in stdout and ('test '+selector+' ... ok') in stdout and '1 passed; 0 failed' in stdout
        native_results.append({'selector':selector,'exit_code':code,'exactly_one_named_native_test_passed':passed,'command_label':label})
        print(json.dumps(native_results[-1]),flush=True)
        if not passed:
            print(stdout[-5000:],flush=True)
            print(stderr[-5000:],flush=True)
            break
    after=full_source('source-after')
    binary_after=hashlib.sha256(binary.read_bytes()).hexdigest()
    assert before==after and binary_before==binary_after
    passed=len(native_results)==len(selectors) and all(item['exactly_one_named_native_test_passed'] for item in native_results)
    summary={'schema':'trnm-submit-ancestry-fixed-native-rebuilt-observation-v1','local_compilation_origin_verified':True,'local_unit_count':len(seen_local_units),'cache_recovery_directory':str(artifacts/'fixed-cache-recovery-297bb40798ca'),'rustup_entry':'rustup run 1.95.0 /usr/bin/python3','absolute_rustc':env['RUSTC'],'sqlite_precheck_witness_cfg_observed':True,'sqlite_layout_witness_cfg_observed':True,'base':base,'source':before,'binary':{'path':str(binary),'sha256_before':binary_before,'sha256_after':binary_after},'native_results':native_results,'requested_native_count':len(selectors),'executed_native_count':len(native_results),'native_tests_passed':passed,'source_after':after,'production_qualification':False,'build_scope':'release default-feature trnm-pon-node library tests','artifacts_directory':str(out),'before_control_source':control['source'],'before_control_native_exit_code':control['native_exit_code']}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)
    if not passed: raise RuntimeError('fixed native controls did not all pass')
except BaseException:
    (out/'failure.txt').write_text(traceback.format_exc())
    raise

