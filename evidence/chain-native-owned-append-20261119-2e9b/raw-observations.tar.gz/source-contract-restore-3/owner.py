from pathlib import Path
import subprocess,json,time,resource,hashlib,sys,traceback
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=s.parent/'source-contract-restore-3';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);res={'schema':'chain-partial-clone-input-recovery-v1','stages':[],'restored':[],'complete':False}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN);p=subprocess.run(args,cwd=s,capture_output=True);a=resource.getrusage(resource.RUSAGE_CHILDREN);(out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);row={'name':name,'command':args,'exit_code':p.returncode,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['stages'].append(row);save();print(json.dumps(row),flush=True);assert p.returncode==0;return p.stdout
try:
 run('preflight',['bash','scripts/project-preflight.sh'])
 run('configure-original-promisor',['git','config','remote.origin.promisor','true'])
 run('configure-original-filter',['git','config','remote.origin.partialclonefilter','blob:none'])
 contract=json.loads((s/'config/pon/w1-qrom-implementation-current-v2.json').read_text());paths=[]
 def visit(v):
  if isinstance(v,dict):
   if isinstance(v.get('path'),str) and v['path'].startswith('evidence/'):paths.append(v['path'])
   for x in v.values():visit(x)
  elif isinstance(v,list):
   for x in v:visit(x)
 visit(contract)
 tree={}
 for row in subprocess.check_output(['git','ls-tree','-r','--full-tree','HEAD'],cwd=s,text=True).splitlines():
  meta,path=row.split('\t',1);tree[path]=meta.split()
 for i,path in enumerate(sorted(set(paths))):
  if (s/path).exists():continue
  mode,kind,blob=tree[path];assert kind=='blob' and mode in ['100644','100755']
  data=run('blob-'+str(i),['git','cat-file','blob',blob]);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob
  target=s/path;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as f:f.write(data)
  if mode=='100755':target.chmod(0o755)
  res['restored'].append({'path':path,'blob':blob,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});save()
 res['complete']=True;save();print(json.dumps({'complete':True,'restored':res['restored']},indent=2),flush=True)
except BaseException as e:
 res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
