import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import traceback

ROOT = Path('/home/qian-qi/chain-daa-monotone-20261111-7f73')
REPO = ROOT / 'publisher'
OLD = ROOT / 'native-intermediate-publication-v1'
OUT = ROOT / 'native-intermediate-pr-rest-v1'
HEAD = '31f7740ed57eb3bca2e17f7e0a5f4f63cb320f5f'
BASE = 'fix/chain-joint-production-tail-20261110-8e76'
ENDPOINT = 'repos/TrillionniumFoundation/Trillionnium-Chain/pulls/920'
PROJECTION = '{head:.head.sha,base:.base.ref,draft:.draft,state:.state,body:.body,url:.html_url}'
OUT.mkdir(exist_ok=False)
records = []

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(label, args, required=True):
    started = now()
    print(json.dumps({'phase': label, 'state': 'started', 'at': started}), flush=True)
    process = subprocess.run(args, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout = OUT / (label + '.stdout.log')
    stderr = OUT / (label + '.stderr.log')
    stdout.write_bytes(process.stdout)
    stderr.write_bytes(process.stderr)
    records.append({'label': label, 'argv': args, 'cwd': str(REPO), 'returncode': process.returncode,
                    'started_utc': started, 'finished_utc': now(), 'stdout_path': str(stdout),
                    'stderr_path': str(stderr), 'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr)})
    (OUT / 'commands.json').write_text(json.dumps(records, sort_keys=True, indent=2) + '\n')
    if required and process.returncode:
        raise RuntimeError(label + ' failed; original streams retained')
    return process

result = {'schema': 'pon-native-intermediate-pr-rest-v1', 'evidence_commit': HEAD,
          'git_mutation_performed': False, 'native_execution_repeated': False,
          'original_gh_pr_edit_exit': 1, 'body_update_verified': False}
try:
    who = json.loads(run('github-identity', ['gh', 'api', 'user', '--jq', '{login:.login,id:.id}']).stdout)
    assert who['login'] == 'ProfHepta'
    assert run('publisher-head', ['git', 'rev-parse', 'HEAD']).stdout.decode().strip() == HEAD
    assert not run('publisher-clean', ['git', 'status', '--porcelain', '--untracked-files=all']).stdout.strip()
    run('preflight', ['bash', 'scripts/project-preflight.sh'])
    original = json.loads((OLD / 'pr-readback.stdout.log').read_text())
    body = (OLD / 'pr-body.md').read_text()
    before = json.loads(run('pr-before', ['gh', 'api', ENDPOINT, '--jq', PROJECTION]).stdout)
    assert before['head'] == HEAD and before['base'] == BASE and before['draft'] is True and before['state'] == 'open'
    assert before['body'] == original['body']
    payload = OUT / 'body-request.json'
    payload.write_text(json.dumps({'body': body}, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    update = run('pr-body-rest-patch', ['gh', 'api', '--method', 'PATCH', ENDPOINT,
                                      '--input', str(payload), '--jq', PROJECTION], required=False)
    after = json.loads(run('pr-after', ['gh', 'api', ENDPOINT, '--jq', PROJECTION]).stdout)
    assert after['head'] == HEAD and after['base'] == BASE and after['draft'] is True and after['state'] == 'open'
    assert after['body'] == body
    result.update(body_update_verified=True, patch_returncode=update.returncode, pull_request=after['url'],
                  requested_body_sha256=hashlib.sha256(body.encode()).hexdigest())
except BaseException as error:
    (OUT / 'exception.log').write_text(traceback.format_exc())
    result.update(error_type=type(error).__name__, error=str(error))
finally:
    result['finished_utc'] = now()
    (OUT / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True), flush=True)

archive_path = ROOT / 'native-intermediate-publication-recovery-v1.tar.gz'
assert not archive_path.exists()
inputs = [p for folder in (OLD, OUT) for p in sorted(folder.rglob('*')) if p.is_file()]
inputs.extend([ROOT / 'publish-native-intermediate-d23488c5.py', Path(__file__).resolve()])
assert all(not p.is_symlink() for p in inputs)
with archive_path.open('xb') as sink:
    with tarfile.open(fileobj=sink, mode='w:gz') as archive:
        for path in inputs:
            archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
descriptor = {'schema': 'pon-native-intermediate-publication-recovery-archive-v1',
              'path': str(archive_path), 'bytes': archive_path.stat().st_size,
              'sha256': sha(archive_path), 'files': len(inputs),
              'original_helper_exit': 1, 'original_push_exit': 0, 'original_pr_edit_exit': 1,
              'rest_body_update_verified': result['body_update_verified'],
              'created_utc': now()}
with (ROOT / 'native-intermediate-publication-recovery-v1-archive.json').open('x') as sink:
    sink.write(json.dumps(descriptor, sort_keys=True, indent=2) + '\n')
print(json.dumps(descriptor, sort_keys=True), flush=True)
sys.exit(0 if result['body_update_verified'] else 1)
