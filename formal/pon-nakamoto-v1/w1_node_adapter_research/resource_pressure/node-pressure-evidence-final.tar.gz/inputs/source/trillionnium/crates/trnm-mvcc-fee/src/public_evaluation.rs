//! Native branch-state commit/reveal evaluation. Signatures attest opinions,
//! not objective model quality or independent identities. No fork weight changes.
use crate::pon_executor::{Config, Result};
use serde_json::{json, Value};
use std::collections::{BTreeMap, BTreeSet};
use trnm_crypto_primitives::verify_hex_strict;
use trnm_protocol::pon_wire::{hash, Envelope, Hash};

pub mod pq_storage;
pub mod quorum_v2;
pub use quorum_v2::{
    PROFILE as QUORUM_PROFILE, RECORD_NAMESPACE as QUORUM_RECORD_NAMESPACE,
    REVISION as QUORUM_REVISION, STORAGE_REVISION as QUORUM_STORAGE_REVISION,
};

pub const RECORD_NAMESPACE: &str = "evaluation-record-v2";
pub const STORAGE_REVISION: u64 = 2;
const MAPS: [(&str, &str, usize); 4] = [
    ("c", "commits", 16),
    ("r", "reveals", 16),
    ("f", "conflicts", 32),
    ("a", "appeals", 16),
];
pub const PROFILE: &str = "native-public-evaluation-dev-v1";
pub const CANDIDATE_END: u64 = 15;
pub const COMMIT_END: u64 = 31;
pub const REVEAL_END: u64 = 47;
pub const ADOPTION_START: u64 = 56;

fn check(ok: bool, error: &'static str) -> Result<()> {
    if ok {
        Ok(())
    } else {
        Err(error)
    }
}
fn n(v: &Value, field: &str) -> Result<u64> {
    v[field].as_u64().ok_or("PUBLIC_EVAL_STATE")
}
fn bytes(v: &Value) -> Result<Vec<u8>> {
    serde_json::to_vec(v).map_err(|_| "PUBLIC_EVAL_STATE")
}
fn digest(v: &Value, field: &str) -> Result<Hash> {
    let value = v[field].as_str().ok_or("PUBLIC_EVAL_STATE")?;
    check(
        value.len() == 64
            && value
                .bytes()
                .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)),
        "PUBLIC_EVAL_STATE",
    )?;
    let mut out = [0; 32];
    hex::decode_to_slice(value, &mut out).map_err(|_| "PUBLIC_EVAL_STATE")?;
    Ok(out)
}
pub fn enabled(cfg: &Config) -> bool {
    cfg.params["evaluation_profile"] == PROFILE || quorum_enabled(cfg)
}
pub fn quorum_enabled(cfg: &Config) -> bool {
    cfg.params["evaluation_profile"] == QUORUM_PROFILE
}
pub fn is_quorum(evaluation: &Value) -> Result<bool> {
    match n(evaluation, "storage_revision")? {
        pq_storage::REVISION => {
            check(
                evaluation["plan"]["schema"] == "pon-native-frozen-evaluation-v1"
                    && evaluation["plan"]["authentication_profile"]
                        == "pon-native-pq-application-v6"
                    && evaluation["plan"]["pq_conflict_scope"] == pq_storage::CONFLICT_SCOPE,
                "PUBLIC_EVAL_PROFILE",
            )?;
            Ok(false)
        }
        pq_storage::QUORUM_REVISION => {
            quorum_v2::validate_plan(&evaluation["plan"])?;
            check(
                evaluation["plan"]["authentication_profile"] == "pon-native-pq-application-v6"
                    && evaluation["plan"]["pq_conflict_scope"] == pq_storage::CONFLICT_SCOPE
                    && evaluation["plan"]["disqualified_at_freeze"] == json!([]),
                "PUBLIC_EVAL_PROFILE",
            )?;
            Ok(true)
        }
        STORAGE_REVISION => {
            check(
                evaluation["plan"]["schema"] == "pon-native-frozen-evaluation-v1",
                "PUBLIC_EVAL_PROFILE",
            )?;
            Ok(false)
        }
        QUORUM_STORAGE_REVISION => {
            quorum_v2::validate_plan(&evaluation["plan"])?;
            Ok(true)
        }
        _ => Err("PUBLIC_EVAL_STORAGE_REVISION"),
    }
}
pub fn record_namespace(cfg: &Config) -> &'static str {
    if crate::pon_executor::pq_accounts_v2::application_v6::enabled(cfg) {
        return pq_storage::NAMESPACE;
    }
    if quorum_enabled(cfg) {
        QUORUM_RECORD_NAMESPACE
    } else {
        RECORD_NAMESPACE
    }
}
pub fn freeze(
    cfg: &Config,
    cid: Hash,
    contribution: &Value,
    height: u64,
    excluded: &BTreeSet<String>,
) -> Result<Value> {
    check(enabled(cfg), "PUBLIC_EVAL_PROFILE")?;
    // PQ conflicts have no authority outside their own frozen round. In
    // particular, classic stable-account exclusions cannot enter a PQ plan.
    let no_cross_round_exclusions = BTreeSet::new();
    let excluded = if crate::pon_executor::pq_accounts_v2::application_v6::enabled(cfg) {
        &no_cross_round_exclusions
    } else {
        excluded
    };
    let width = n(&cfg.params, "candidate_round_blocks")?;
    check(
        width > ADOPTION_START && height % width <= CANDIDATE_END,
        "PUBLIC_EVAL_CANDIDATE_PHASE",
    )?;
    let author = contribution["owner"].as_str().ok_or("PUBLIC_EVAL_STATE")?;
    let roster: BTreeSet<_> = cfg
        .evaluators
        .iter()
        .filter(|key| key.as_str() != author && (quorum_enabled(cfg) || !excluded.contains(*key)))
        .cloned()
        .collect();
    check((2..=16).contains(&roster.len()), "PUBLIC_EVAL_ROSTER")?;
    let start = height / width * width;
    let mut plan = json!({"schema":"pon-native-frozen-evaluation-v1","network":hex::encode(cfg.network),"parameters":hex::encode(cfg.parameters),"candidate":hex::encode(cid),"artifact":contribution["artifact"],"components_root":contribution["components_root"],"parent":contribution["parent"],"family":hex::encode(cfg.family),"model_and_task_contract":hex::encode(cfg.plan),"roster":roster,"start":start,"candidate_end":start+CANDIDATE_END,"commit_end":start+COMMIT_END,"reveal_end":start+REVEAL_END,"adoption_start":start+ADOPTION_START,"max_score":cfg.params["max_evidence_score"],"independent_governance_accepted":false,"objective_model_quality":false});
    let storage_revision = if quorum_enabled(cfg) {
        quorum_v2::configure_plan(&mut plan, cfg, author, excluded, height / width)?;
        QUORUM_STORAGE_REVISION
    } else {
        STORAGE_REVISION
    };
    let storage_revision = if crate::pon_executor::pq_accounts_v2::application_v6::enabled(cfg) {
        plan["authentication_profile"] = json!("pon-native-pq-application-v6");
        plan["pq_conflict_scope"] = json!(pq_storage::CONFLICT_SCOPE);
        if quorum_enabled(cfg) {
            pq_storage::QUORUM_REVISION
        } else {
            pq_storage::REVISION
        }
    } else {
        storage_revision
    };
    let mut evaluation = json!({"storage_revision":storage_revision,"plan":plan,"round":null,"record_counts":{"commits":0,"reveals":0,"conflicts":0,"appeals":0},"closed":null});
    evaluation["round"] = json!(hex::encode(expected_round(&evaluation)?));
    Ok(evaluation)
}
pub fn round(evaluation: &Value) -> Result<Hash> {
    let result = digest(evaluation, "round")?;
    if is_quorum(evaluation)? || pq_storage::enabled(evaluation) {
        check(result == expected_round(evaluation)?, "PUBLIC_EVAL_ROUND")?;
    }
    Ok(result)
}
/// Recompute the profile-specific frozen-plan commitment for native observations.
pub fn expected_round(evaluation: &Value) -> Result<Hash> {
    let domain: &[u8] = if pq_storage::enabled(evaluation) {
        if is_quorum(evaluation)? {
            b"native-public-evaluation-pq-round-v7"
        } else {
            b"native-public-evaluation-pq-round-v6"
        }
    } else if is_quorum(evaluation)? {
        b"native-public-evaluation-round-v2"
    } else {
        b"native-public-evaluation-round-v1"
    };
    Ok(hash(domain, &[&bytes(&evaluation["plan"])?]))
}
pub fn reveal_commitment(
    round: Hash,
    cid: Hash,
    evaluator: Hash,
    plan: Hash,
    evidence: Hash,
    score: u64,
    salt: Hash,
) -> Hash {
    hash(
        b"native-public-evaluation-reveal-v1",
        &[
            &round,
            &cid,
            &evaluator,
            &plan,
            &evidence,
            &score.to_le_bytes(),
            &salt,
        ],
    )
}
fn evaluator(evaluation: &Value, sender: &str, round_id: Hash) -> Result<()> {
    check(round(evaluation)? == round_id, "PUBLIC_EVAL_ROUND")?;
    let roster = evaluation["plan"]["roster"]
        .as_array()
        .ok_or("PUBLIC_EVAL_STATE")?;
    check(
        roster.iter().any(|key| key.as_str() == Some(sender)),
        "PUBLIC_EVAL_AUTHORITY",
    )
}
pub fn commit(
    evaluation: &mut Value,
    sender: &str,
    round_id: Hash,
    commitment: Hash,
    height: u64,
) -> Result<()> {
    evaluator(evaluation, sender, round_id)?;
    if is_quorum(evaluation)? {
        quorum_v2::eligible(evaluation, sender)?;
    } else if pq_storage::enabled(evaluation) {
        check(
            !pq_conflict_signers(evaluation)?.contains(sender),
            "PUBLIC_EVAL_DISQUALIFIED",
        )?;
    }
    let plan = &evaluation["plan"];
    check(
        height > n(plan, "candidate_end")?
            && height <= n(plan, "commit_end")?
            && evaluation["closed"].is_null(),
        "PUBLIC_EVAL_COMMIT_PHASE",
    )?;
    check(commitment != [0; 32], "PUBLIC_EVAL_COMMITMENT")?;
    check(evaluation["commits"].get(sender).is_none(), "DUPLICATE")?;
    evaluation["commits"][sender] = json!(hex::encode(commitment));
    Ok(())
}
pub struct Reveal {
    pub candidate: Hash,
    pub round: Hash,
    pub evaluator: Hash,
    pub plan: Hash,
    pub evidence: Hash,
    pub score: u64,
    pub salt: Hash,
}
/// Producers select a domain from the frozen record, never from a local default.
/// The historical `reveal_commitment` function remains the exact v1 operation.
pub fn reveal_commitment_for(evaluation: &Value, value: &Reveal) -> Result<Hash> {
    if is_quorum(evaluation)? {
        check(
            round(evaluation)? == value.round
                && value.candidate == digest(&evaluation["plan"], "candidate")?
                && value.plan == digest(&evaluation["plan"], "model_and_task_contract")?,
            "PUBLIC_EVAL_REVEAL_CONTEXT",
        )?;
        Ok(quorum_v2::reveal_commitment(value))
    } else {
        Ok(reveal_commitment(
            value.round,
            value.candidate,
            value.evaluator,
            value.plan,
            value.evidence,
            value.score,
            value.salt,
        ))
    }
}
pub fn reveal(evaluation: &mut Value, value: Reveal, height: u64) -> Result<()> {
    let sender = hex::encode(value.evaluator);
    evaluator(evaluation, &sender, value.round)?;
    if is_quorum(evaluation)? {
        quorum_v2::eligible(evaluation, &sender)?;
    } else if pq_storage::enabled(evaluation) {
        check(
            !pq_conflict_signers(evaluation)?.contains(&sender),
            "PUBLIC_EVAL_DISQUALIFIED",
        )?;
    }
    let plan = &evaluation["plan"];
    check(
        height > n(plan, "commit_end")?
            && height <= n(plan, "reveal_end")?
            && evaluation["closed"].is_null(),
        "PUBLIC_EVAL_REVEAL_PHASE",
    )?;
    check(
        value.plan == digest(plan, "model_and_task_contract")?
            && value.evidence != [0; 32]
            && value.score <= n(plan, "max_score")?,
        "PUBLIC_EVAL_REVEAL_CONTEXT",
    )?;
    check(evaluation["reveals"].get(&sender).is_none(), "DUPLICATE")?;
    let commitment = reveal_commitment_for(evaluation, &value)?;
    check(
        evaluation["commits"][&sender] == hex::encode(commitment),
        "PUBLIC_EVAL_COMMITMENT_BINDING",
    )?;
    evaluation["reveals"][&sender] = json!({"score":value.score,"evidence":hex::encode(value.evidence),"salt":hex::encode(value.salt)});
    Ok(())
}
/// Revalidate retained commit/reveal bindings before evidence is restored or used.
/// Live reveal admission already checks these invariants; canonical row bytes and
/// storage chunk hashes alone do not establish that a retained reveal did so.
fn validate_reveals(evaluation: &Value) -> Result<()> {
    let round_id = round(evaluation)?;
    let plan = &evaluation["plan"];
    let candidate = digest(plan, "candidate")?;
    let contract = digest(plan, "model_and_task_contract")?;
    let roster = plan["roster"].as_array().ok_or("PUBLIC_EVAL_STATE")?;
    let commits = evaluation["commits"]
        .as_object()
        .ok_or("PUBLIC_EVAL_STATE")?;
    let reveals = evaluation["reveals"]
        .as_object()
        .ok_or("PUBLIC_EVAL_STATE")?;
    check(
        commits.len() <= roster.len() && reveals.len() <= commits.len(),
        "PUBLIC_EVAL_STATE",
    )?;
    for signer in commits.keys() {
        identity("r", signer)?;
        check(
            roster.iter().any(|key| key.as_str() == Some(signer)),
            "PUBLIC_EVAL_AUTHORITY",
        )?;
        check(
            digest(&evaluation["commits"], signer)? != [0; 32],
            "PUBLIC_EVAL_COMMITMENT",
        )?;
    }
    for (signer, stored) in reveals {
        identity("r", signer)?;
        check(
            stored.as_object().is_some_and(|value| value.len() == 3)
                && commits.contains_key(signer),
            "PUBLIC_EVAL_STATE",
        )?;
        let mut evaluator = [0; 32];
        hex::decode_to_slice(signer, &mut evaluator).map_err(|_| "PUBLIC_EVAL_STATE")?;
        let value = Reveal {
            candidate,
            round: round_id,
            evaluator,
            plan: contract,
            evidence: digest(stored, "evidence")?,
            score: n(stored, "score")?,
            salt: digest(stored, "salt")?,
        };
        check(
            value.evidence != [0; 32] && value.score <= n(plan, "max_score")?,
            "PUBLIC_EVAL_REVEAL_CONTEXT",
        )?;
        check(
            digest(&evaluation["commits"], signer)? == reveal_commitment_for(evaluation, &value)?,
            "PUBLIC_EVAL_COMMITMENT_BINDING",
        )?;
    }
    Ok(())
}

/// Check the classic closure against the immutable commit/reveal records.
/// A later conflict can block adoption, but cannot rescore historical closure.
/// Classic conflict rows do not retain insertion heights: after an aborted
/// closure gains more conflicts, its exact old subset cannot be reconstructed.
/// In that case validate the summary/count bounds without inventing a subset.
fn validate_classic_closure(evaluation: &Value) -> Result<()> {
    if is_quorum(evaluation)? || evaluation["closed"].is_null() {
        return Ok(());
    }
    check(
        round(evaluation)? == expected_round(evaluation)?,
        "PUBLIC_EVAL_ROUND",
    )?;
    let closed = &evaluation["closed"];
    let roster = evaluation["plan"]["roster"]
        .as_array()
        .ok_or("PUBLIC_EVAL_STATE")?;
    let reveals = evaluation["reveals"]
        .as_object()
        .ok_or("PUBLIC_EVAL_STATE")?;
    let conflicts = evaluation["conflicts"]
        .as_object()
        .ok_or("PUBLIC_EVAL_STATE")?;
    let missing = roster
        .iter()
        .filter(|key| !reveals.contains_key(key.as_str().unwrap_or("")))
        .count();
    let before = n(closed, "conflict_count_before_close")?;
    let aborted = missing > 0 || before > 0;
    let score = if aborted {
        None
    } else {
        reveals
            .values()
            .map(|value| n(value, "score"))
            .collect::<Result<Vec<_>>>()?
            .into_iter()
            .min()
    };
    check(
        closed.as_object().is_some_and(|value| value.len() == 11)
            && closed["schema"] == "pon-native-closed-evaluation-v2"
            && closed["round"] == evaluation["round"]
            && closed["candidate"] == evaluation["plan"]["candidate"]
            && closed["missing_reveal_count"] == json!(missing)
            && before <= conflicts.len() as u64
            && n(closed, "closed_height")? > n(&evaluation["plan"], "reveal_end")?
            && closed["status"]
                == if aborted {
                    "aborted"
                } else {
                    "complete-scored"
                }
            && (aborted || score.is_some())
            && closed["score"] == json!(score)
            && closed["objective_model_quality"] == false
            && closed["independent_governance_accepted"] == false,
        "PUBLIC_EVAL_CLOSED_BINDING",
    )?;
    let retained = digest(closed, "records_digest")?;
    if before == 0 {
        // A complete classic result necessarily closed with no conflicts.
        // Retain this exact digest even when new conflicts or appeals arrive.
        check(
            retained == records_digest_with_conflicts(evaluation, &json!({}))?,
            "PUBLIC_EVAL_CLOSED_BINDING",
        )?;
    } else if before == conflicts.len() as u64 {
        check(
            retained == records_digest(evaluation)?,
            "PUBLIC_EVAL_CLOSED_BINDING",
        )?;
    }
    Ok(())
}

/// Closure is a mandatory block transition after the admitted chain height deadline.
/// Legacy missing signatures abort. The explicit v2 profile counts real matching
/// reveals against its frozen threshold, never synthetic votes or a reduced quorum.
pub fn close(evaluation: &mut Value, height: u64) -> Result<Option<u64>> {
    close_with_disqualified(evaluation, height, &BTreeSet::new())
}
pub fn close_with_disqualified(
    evaluation: &mut Value,
    height: u64,
    current_disqualified: &BTreeSet<String>,
) -> Result<Option<u64>> {
    if height <= n(&evaluation["plan"], "reveal_end")? || !evaluation["closed"].is_null() {
        return Ok(None);
    }
    if is_quorum(evaluation)? {
        return quorum_v2::close(evaluation, height, current_disqualified);
    }
    validate_reveals(evaluation)?;
    let roster = evaluation["plan"]["roster"]
        .as_array()
        .ok_or("PUBLIC_EVAL_STATE")?;
    let missing: Vec<_> = roster
        .iter()
        .filter(|key| {
            evaluation["reveals"]
                .get(key.as_str().unwrap_or(""))
                .is_none()
        })
        .cloned()
        .collect();
    let conflicts = evaluation["conflicts"]
        .as_object()
        .ok_or("PUBLIC_EVAL_STATE")?;
    let aborted = !missing.is_empty() || !conflicts.is_empty();
    let score = if aborted {
        None
    } else {
        evaluation["reveals"]
            .as_object()
            .ok_or("PUBLIC_EVAL_STATE")?
            .values()
            .map(|v| n(v, "score"))
            .collect::<Result<Vec<_>>>()?
            .into_iter()
            .min()
    };
    check(aborted || score.is_some(), "PUBLIC_EVAL_STATE")?;
    evaluation["closed"] = json!({"schema":"pon-native-closed-evaluation-v2","round":evaluation["round"],"candidate":evaluation["plan"]["candidate"],"status":if aborted{"aborted"}else{"complete-scored"},"score":score,"missing_reveal_count":missing.len(),"conflict_count_before_close":conflicts.len(),"records_digest":hex::encode(records_digest(evaluation)?),"closed_height":height,"objective_model_quality":false,"independent_governance_accepted":false});
    Ok(score)
}
pub fn adoption_allowed(evaluation: &Value, height: u64) -> Result<()> {
    adoption_allowed_with_disqualified(evaluation, height, &BTreeSet::new())
}
pub fn adoption_allowed_with_disqualified(
    evaluation: &Value,
    height: u64,
    current_disqualified: &BTreeSet<String>,
) -> Result<()> {
    if is_quorum(evaluation)? {
        return quorum_v2::adoption_allowed(evaluation, height, false, current_disqualified);
    }
    validate_reveals(evaluation)?;
    validate_classic_closure(evaluation)?;
    check(
        height >= n(&evaluation["plan"], "adoption_start")?
            && evaluation["closed"]["status"] == "complete-scored"
            && height >= n(&evaluation["closed"], "closed_height")?
            && n(&evaluation["closed"], "score")? > 0
            && evaluation["conflicts"]
                .as_object()
                .ok_or("PUBLIC_EVAL_STATE")?
                .is_empty(),
        "PUBLIC_EVAL_ADOPTION",
    )
}
/// Identify a closure, including from its compact record. This hash is not
/// validation of the retained records; hydration and adoption perform that check.
pub fn closed_digest(evaluation: &Value) -> Result<Hash> {
    check(!evaluation["closed"].is_null(), "PUBLIC_EVAL_NOT_CLOSED")?;
    let domain: &[u8] = if is_quorum(evaluation)? {
        b"native-public-evaluation-closed-v3"
    } else {
        b"native-public-evaluation-closed-v2"
    };
    Ok(hash(domain, &[&bytes(&evaluation["closed"])?]))
}
pub fn appeal(
    evaluation: &mut Value,
    author: &str,
    sender: &str,
    result: Hash,
    claim: Hash,
    evidence: Hash,
    height: u64,
) -> Result<()> {
    check(
        height > n(&evaluation["plan"], "reveal_end")?,
        "PUBLIC_EVAL_APPEAL_PHASE",
    )?;
    if sender != author {
        evaluator(evaluation, sender, round(evaluation)?)?;
    }
    check(
        result == closed_digest(evaluation)? && claim != [0; 32] && evidence != [0; 32],
        "PUBLIC_EVAL_APPEAL_RESULT",
    )?;
    let domain: &[u8] = if is_quorum(evaluation)? {
        b"native-public-evaluation-appeal-v2"
    } else {
        b"native-public-evaluation-appeal-v1"
    };
    let id = hex::encode(hash(
        domain,
        &[sender.as_bytes(), &result, &claim, &evidence],
    ));
    let appeals = evaluation["appeals"]
        .as_object()
        .ok_or("PUBLIC_EVAL_STATE")?;
    check(appeals.len() < 16, "PUBLIC_EVAL_APPEAL_LIMIT")?;
    check(!appeals.contains_key(&id), "DUPLICATE")?;
    evaluation["appeals"][id] = json!({"signer":sender,"result":hex::encode(result),"claim":hex::encode(claim),"evidence":hex::encode(evidence),"height":height,"effect":"record-only; closed score and past reward unchanged"});
    Ok(())
}
/// Independently verify two full signed transaction envelopes. Conflict evidence
/// can arrive outside the original phase, but cannot replace the frozen roster.
pub fn conflict(
    evaluation: &mut Value,
    cfg: &Config,
    candidate: Hash,
    first: &[u8],
    second: &[u8],
) -> Result<String> {
    let a = Envelope::decode(first).map_err(|_| "PUBLIC_EVAL_CONFLICT_CODEC")?;
    let b = Envelope::decode(second).map_err(|_| "PUBLIC_EVAL_CONFLICT_CODEC")?;
    check(
        a.network == cfg.network
            && b.network == cfg.network
            && a.sender == b.sender
            && a.tag == b.tag
            && matches!(a.tag, 14 | 15),
        "PUBLIC_EVAL_CONFLICT_CONTEXT",
    )?;
    for tx in [&a, &b] {
        verify_hex_strict(
            &hex::encode(tx.sender),
            &tx.signing_digest()
                .map_err(|_| "PUBLIC_EVAL_CONFLICT_CODEC")?,
            &hex::encode(tx.signature),
        )
        .map_err(|_| "PUBLIC_EVAL_CONFLICT_SIGNATURE")?;
        check(
            tx.payload[..32] == candidate && tx.payload[32..64] == round(evaluation)?,
            "PUBLIC_EVAL_CONFLICT_CONTEXT",
        )?;
        evaluator(evaluation, &hex::encode(tx.sender), round(evaluation)?)?;
        if tx.tag == 14 {
            check(tx.payload[64..96] != [0; 32], "PUBLIC_EVAL_COMMITMENT")?;
        } else {
            check(
                tx.payload[64..96] == cfg.plan
                    && tx.payload[96..128] != [0; 32]
                    && u64::from_le_bytes(
                        tx.payload[128..136]
                            .try_into()
                            .map_err(|_| "PUBLIC_EVAL_STATE")?,
                    ) <= n(&evaluation["plan"], "max_score")?,
                "PUBLIC_EVAL_REVEAL_CONTEXT",
            )?;
        }
    }
    check(a.payload != b.payload, "PUBLIC_EVAL_NOT_CONFLICT")?;
    let sender = hex::encode(a.sender);
    let key = format!("{sender}:{}", a.tag);
    check(evaluation["conflicts"].get(&key).is_none(), "DUPLICATE")?;
    let mut records = [hex::encode(first), hex::encode(second)];
    records.sort();
    let effect = if is_quorum(evaluation)? {
        "signer excluded from current and future counts; frozen quorum and historical closure unchanged"
    } else {
        "current adoption blocked; next-round identity excluded; historical closure unchanged"
    };
    evaluation["conflicts"][key] = json!({"records":records,"signer":sender,"effect":effect});
    Ok(sender)
}

pub fn excluded(state: &BTreeMap<String, Value>) -> BTreeSet<String> {
    let prefix = "evaluation-disqualified:";
    state
        .range(prefix.to_owned()..)
        .take_while(|(key, _)| key.starts_with(prefix))
        .filter_map(|(key, _)| key.strip_prefix(prefix).map(str::to_owned))
        .collect()
}

/// Exact per-candidate prefix participates in MVCC scan validation.
pub fn record_prefix(candidate: Hash) -> String {
    format!("{RECORD_NAMESPACE}:{}:", hex::encode(candidate))
}
pub fn record_prefix_for(candidate: Hash, evaluation: &Value) -> Result<String> {
    if pq_storage::enabled(evaluation) {
        is_quorum(evaluation)?;
        return Ok(format!(
            "{}:{}:",
            pq_storage::NAMESPACE,
            hex::encode(candidate)
        ));
    }
    if is_quorum(evaluation)? {
        Ok(format!(
            "{QUORUM_RECORD_NAMESPACE}:{}:",
            hex::encode(candidate)
        ))
    } else {
        Ok(record_prefix(candidate))
    }
}
fn record_schema(evaluation: &Value) -> Result<&'static str> {
    Ok(if is_quorum(evaluation)? {
        "pon-native-evaluation-record-v3"
    } else {
        "pon-native-evaluation-record-v2"
    })
}
fn identity(kind: &str, id: &str) -> Result<()> {
    let valid_hex = |s: &str| {
        s.len() == 64
            && s.bytes()
                .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    };
    check(
        if kind == "f" {
            id.split_once(':')
                .is_some_and(|(key, tag)| valid_hex(key) && matches!(tag, "14" | "15"))
        } else {
            valid_hex(id)
        },
        "PUBLIC_EVAL_RECORD_KEY",
    )
}
pub fn record_rows(candidate: Hash, evaluation: &Value) -> Result<BTreeMap<String, Value>> {
    if pq_storage::enabled(evaluation) {
        return pq_storage::rows(candidate, evaluation);
    }
    check(
        evaluation["plan"]["candidate"] == hex::encode(candidate),
        "PUBLIC_EVAL_RECORD_CONTEXT",
    )?;
    let prefix = record_prefix_for(candidate, evaluation)?;
    let schema = record_schema(evaluation)?;
    let mut rows = BTreeMap::new();
    for (kind, name, maximum) in MAPS {
        let map = evaluation[name].as_object().ok_or("PUBLIC_EVAL_STATE")?;
        check(map.len() <= maximum, "PUBLIC_EVAL_RECORD_LIMIT")?;
        for (id, value) in map {
            identity(kind, id)?;
            let key = format!("{prefix}{kind}:{id}");
            let row = json!({"schema":schema,"candidate":hex::encode(candidate),"kind":kind,"id":id,"value":value});
            check(
                key.len() <= 160 && bytes(&row)?.len() <= 4096,
                "PUBLIC_EVAL_RECORD_LIMIT",
            )?;
            rows.insert(key, row);
        }
    }
    Ok(rows)
}
pub fn compact(evaluation: &Value) -> Result<Value> {
    is_quorum(evaluation)?;
    let mut value = evaluation.clone();
    for (_, name, maximum) in MAPS {
        let map = value[name].as_object().ok_or("PUBLIC_EVAL_STATE")?;
        check(map.len() <= maximum, "PUBLIC_EVAL_RECORD_LIMIT")?;
        let count = map.len();
        value["record_counts"][name] = json!(count);
        value
            .as_object_mut()
            .ok_or("PUBLIC_EVAL_STATE")?
            .remove(name);
    }
    check(bytes(&value)?.len() <= 4096, "PUBLIC_EVAL_RECORD_LIMIT")?;
    Ok(value)
}
pub fn hydrate(compact: &Value, candidate: Hash, rows: &BTreeMap<String, Value>) -> Result<Value> {
    if pq_storage::enabled(compact) {
        let value = pq_storage::hydrate(compact, candidate, rows)?;
        validate_classic_closure(&value)?;
        return Ok(value);
    }
    is_quorum(compact)?;
    check(
        compact["plan"]["candidate"] == hex::encode(candidate),
        "PUBLIC_EVAL_STORAGE_REVISION",
    )?;
    let mut value = compact.clone();
    for (_, name, _) in MAPS {
        check(value.get(name).is_none(), "PUBLIC_EVAL_STORAGE_SHAPE")?;
        value[name] = json!({});
    }
    let prefix = record_prefix_for(candidate, compact)?;
    let schema = record_schema(compact)?;
    for (key, row) in rows {
        let suffix = key
            .strip_prefix(&prefix)
            .ok_or("PUBLIC_EVAL_RECORD_CONTEXT")?;
        let (kind, id) = suffix.split_once(':').ok_or("PUBLIC_EVAL_RECORD_KEY")?;
        identity(kind, id)?;
        let (_, name, _) = MAPS
            .iter()
            .find(|(k, _, _)| *k == kind)
            .ok_or("PUBLIC_EVAL_RECORD_KEY")?;
        check(
            row.as_object().is_some_and(|m| m.len() == 5)
                && row["schema"] == schema
                && row["candidate"] == hex::encode(candidate)
                && row["kind"] == kind
                && row["id"] == id,
            "PUBLIC_EVAL_RECORD_CONTEXT",
        )?;
        value[*name][id] = row["value"].clone();
    }
    let expected = record_rows(candidate, &value)?;
    check(expected == *rows, "PUBLIC_EVAL_RECORD_CONTEXT")?;
    for (_, name, _) in MAPS {
        check(
            n(&value["record_counts"], name)?
                == value[name].as_object().ok_or("PUBLIC_EVAL_STATE")?.len() as u64,
            "PUBLIC_EVAL_RECORD_COUNT",
        )?;
    }
    validate_reveals(&value)?;
    validate_classic_closure(&value)?;
    Ok(value)
}
pub fn read_evaluation(state: &BTreeMap<String, Value>, candidate: Hash) -> Result<Value> {
    let hex = hex::encode(candidate);
    let contribution = state
        .get(&format!("contribution:{hex}"))
        .or_else(|| state.get(&format!("evaluation-archive:{hex}")))
        .ok_or("STATE")?;
    let prefix = record_prefix_for(candidate, &contribution["public_evaluation"])?;
    let rows = state
        .range(prefix.clone()..)
        .take_while(|(key, _)| key.starts_with(&prefix))
        .map(|(k, v)| (k.clone(), v.clone()))
        .collect();
    hydrate(&contribution["public_evaluation"], candidate, &rows)
}
fn records_digest(evaluation: &Value) -> Result<Hash> {
    records_digest_with_conflicts(evaluation, &evaluation["conflicts"])
}
fn records_digest_with_conflicts(evaluation: &Value, conflicts: &Value) -> Result<Hash> {
    let snapshot = json!({"commits":evaluation["commits"],"reveals":evaluation["reveals"],"conflicts":conflicts});
    let domain: &[u8] = if is_quorum(evaluation)? {
        b"native-public-evaluation-closure-records-v3"
    } else {
        b"native-public-evaluation-closure-records-v2"
    };
    Ok(hash(domain, &[&bytes(&snapshot)?]))
}

/// The private M06 proof was produced by actual ML-DSA verification of both
/// inner statements. The original frozen-roster/conflict/appeal state remains owner.
pub(crate) fn conflict_pq(
    evaluation: &mut Value,
    cfg: &Config,
    candidate: Hash,
    first: &[u8],
    second: &[u8],
    proof: &crate::pon_executor::pq_accounts_v2::application_v6::VerifiedConflict,
) -> Result<String> {
    check(
        crate::pon_executor::pq_accounts_v2::application_v6::enabled(cfg)
            && pq_storage::enabled(evaluation)
            && proof.raw() == (first, second),
        "PQ6_CONFLICT_CONTEXT",
    )?;
    let sender = hex::encode(proof.signer());
    let tag = proof.kind();
    let generation = crate::pon_executor::pq_accounts_v2::application_v6::frozen_generation(
        evaluation,
        proof.signer(),
    )?;
    check(generation == proof.generation(), "PQ_EVAL_CONFLICT_SCOPE")?;
    for payload in [proof.payloads().0, proof.payloads().1] {
        check(
            payload[..32] == candidate && payload[32..64] == round(evaluation)?,
            "PUBLIC_EVAL_CONFLICT_CONTEXT",
        )?;
        evaluator(evaluation, &sender, round(evaluation)?)?;
        if tag == 14 {
            check(payload[64..96] != [0; 32], "PUBLIC_EVAL_COMMITMENT")?;
        } else {
            check(
                tag == 15
                    && payload[64..96] == cfg.plan
                    && payload[96..128] != [0; 32]
                    && u64::from_le_bytes(
                        payload[128..136]
                            .try_into()
                            .map_err(|_| "PUBLIC_EVAL_STATE")?,
                    ) <= n(&evaluation["plan"], "max_score")?,
                "PUBLIC_EVAL_REVEAL_CONTEXT",
            )?;
        }
    }
    check(
        proof.payloads().0 != proof.payloads().1,
        "PUBLIC_EVAL_NOT_CONFLICT",
    )?;
    let key = format!("{sender}:{tag}");
    check(evaluation["conflicts"].get(&key).is_none(), "DUPLICATE")?;
    let mut records = [hex::encode(first), hex::encode(second)];
    records.sort();
    evaluation["conflicts"][key] = json!({
        "records": records,
        "signer": sender,
        "signer_generation": generation,
        "candidate": evaluation["plan"]["candidate"],
        "round": evaluation["round"],
        "scope": pq_storage::CONFLICT_SCOPE,
        "effect": "signer excluded only in this frozen authority generation and round; historical closure unchanged; signature creation time not established"
    });
    pq_conflict_signers(evaluation)?;
    Ok(sender)
}

/// Validate the immutable scope before PQ conflicts influence any vote count.
/// No result from this function is a cross-round revocation or account ban.
pub(super) fn pq_conflict_signers(evaluation: &Value) -> Result<BTreeSet<String>> {
    check(pq_storage::enabled(evaluation), "PQ_EVAL_CONFLICT_SCOPE")?;
    let round = hex::encode(round(evaluation)?);
    let mut signers = BTreeSet::new();
    for conflict in evaluation["conflicts"]
        .as_object()
        .ok_or("PUBLIC_EVAL_STATE")?
        .values()
    {
        let signer = digest(conflict, "signer")?;
        let generation = crate::pon_executor::pq_accounts_v2::application_v6::frozen_generation(
            evaluation, signer,
        )?;
        check(
            conflict["scope"] == pq_storage::CONFLICT_SCOPE
                && conflict["candidate"] == evaluation["plan"]["candidate"]
                && conflict["round"] == round
                && n(conflict, "signer_generation")? == generation,
            "PQ_EVAL_CONFLICT_SCOPE",
        )?;
        signers.insert(hex::encode(signer));
    }
    Ok(signers)
}
