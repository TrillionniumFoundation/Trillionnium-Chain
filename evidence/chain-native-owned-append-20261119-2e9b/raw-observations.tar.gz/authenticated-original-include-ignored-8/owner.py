from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=s.parent/'authenticated-original-include-ignored-8';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);env=os.environ.copy();env['CARGO_TARGET_DIR']=str(s.parent/'target');env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];env['TRNM_RETAINED_DELTA_COST_PATH']=str(out/'retained-delta-cost.jsonl');assert not Path(env['TRNM_RETAINED_DELTA_COST_PATH']).exists();res={'schema':'chain-current-authenticated-original-complete-invocation-v1','complete':False,'stages':[],'retained_delta_cost_path':env['TRNM_RETAINED_DELTA_COST_PATH']}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.log')).open('xb') as f:rc=subprocess.call(args,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);data=(out/(name+'.log')).read_bytes();row={'name':name,'command':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime,'log_bytes':len(data),'log_sha256':hashlib.sha256(data).hexdigest(),'result_lines':[x for x in data.decode(errors='replace').splitlines() if x.startswith('test result:')]};res['stages'].append(row);save();print(json.dumps(row),flush=True);return rc
try:
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 rc=run('native-authenticated',['/home/qq/.cargo/bin/cargo','test','--release','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib','store::native_authenticated::','--','--include-ignored','--show-output','--test-threads=1'])
 res['complete']=True;res['native_exit_code']=rc;save();print(json.dumps(res,indent=2),flush=True);sys.exit(rc)
except BaseException as e:
 if isinstance(e,SystemExit):raise
 res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
