#!/usr/bin/env python3
"""One supervised provider/strict-Clippy attempt, with honest resource limits."""
from __future__ import annotations
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/workspace/scratch/0776da4af99b')
REPO = ROOT / 'repo'
LIGHT = ROOT / 'cloud-rust-validation-6e39f273'
BASE = ROOT / 'cloud-clippy-bounded-6e39f273'
OUT = BASE / 'attempt'
SOURCE = '6e39f27357ce7c030f5662ada3d524fecb58d63e'
TREE = 'f36683afd74fa9811bddf21787ab2386900ea70b'
GIB = 1024**3
POLICY = {'hard_per_process_address_bytes': 2 * GIB,
          'group_rss_watchdog_bytes': 2 * GIB,
          'available_memory_floor_bytes': GIB,
          'disk_free_floor_bytes': 2 * GIB,
          'minimum_start_available_memory_bytes': 3 * GIB,
          'minimum_start_disk_free_bytes': 4 * GIB,
          'hard_single_file_bytes': 512 * 1024**2,
          'max_group_processes': 32, 'poll_interval_seconds': 0.1,
          'hard_group_physical_memory_limit': False,
          'boundary': 'Kernel per-process virtual-address/file limits plus a best-effort owned-group RSS and shared-resource watchdog; no delegated cgroup or adversarial process jail.'}


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


SUPPORT = load_module('desktop_recording', ROOT / 'validate_on_desktop.py')
PROBE = load_module('capability_probe', ROOT / 'probe_cloud_resource_caps_v2.py')


def available():
    values = {line.split(':')[0]: int(line.split()[1]) * 1024
              for line in Path('/proc/meminfo').read_text().splitlines()
              if line.startswith(('MemAvailable:', 'SwapFree:'))}
    return {'available_memory_bytes': values['MemAvailable'],
            'swap_free_bytes': values['SwapFree'],
            'disk_free_bytes': shutil.disk_usage(ROOT).free}


def bounded(recorder, name, argv, timeout):
    logs = recorder.root
    stdout_path = logs / (name + '.stdout.log')
    stderr_path = logs / (name + '.stderr.log')
    samples_path = logs / (name + '.resource-samples.ndjson')
    initial = available()
    start = time.monotonic()
    started = SUPPORT.now()
    executed = False
    code = None
    reason = None
    exception = None
    peak = 0
    minimum_memory = initial['available_memory_bytes']
    minimum_disk = initial['disk_free_bytes']
    remaining = []
    signals = []
    process = None
    max_sample_interval = 0.0
    previous_sample = start
    prior_handlers = {}
    def interrupt(signum, frame):
        raise InterruptedError('supervisor received signal ' + str(signum))
    def limits():
        resource.setrlimit(resource.RLIMIT_AS, (POLICY['hard_per_process_address_bytes'],) * 2)
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_FSIZE, (POLICY['hard_single_file_bytes'],) * 2)
        resource.setrlimit(resource.RLIMIT_CPU, (timeout + 30, timeout + 30))
    def kill_owned():
        if process is not None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
                signals.append('owned-group-SIGKILL')
            except ProcessLookupError:
                signals.append('owned-group-already-exited')
            except OSError as error:
                signals.append('owned-group-kill-error:' + type(error).__name__)
    def live_members():
        try:
            return [item for item in PROBE.members(process.pid) if item['state'] != 'Z']
        except Exception as error:
            return [{'state': 'UNKNOWN', 'monitor_error': type(error).__name__ + ': ' + str(error)}]
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr, samples_path.open('x') as samples:
        if initial['available_memory_bytes'] < POLICY['minimum_start_available_memory_bytes']:
            reason = 'start_memory_budget_not_available'
        elif initial['disk_free_bytes'] < POLICY['minimum_start_disk_free_bytes']:
            reason = 'start_disk_budget_not_available'
        else:
            try:
                for sig in (signal.SIGINT, signal.SIGTERM):
                    prior_handlers[sig] = signal.getsignal(sig)
                    signal.signal(sig, interrupt)
                process = subprocess.Popen(argv, cwd=REPO, env=recorder.environment,
                    stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                    start_new_session=True, preexec_fn=limits)
                executed = True
                while process.poll() is None:
                    group = PROBE.members(process.pid)
                    state = available()
                    current = time.monotonic()
                    max_sample_interval = max(max_sample_interval, current - previous_sample)
                    previous_sample = current
                    rss = sum(item['rss_bytes'] for item in group)
                    peak = max(peak, rss)
                    minimum_memory = min(minimum_memory, state['available_memory_bytes'])
                    minimum_disk = min(minimum_disk, state['disk_free_bytes'])
                    observation = {'elapsed_seconds': current - start, 'group': process.pid,
                                   'members': group, 'group_rss_bytes': rss, **state}
                    samples.write(json.dumps(observation, sort_keys=True) + '\n')
                    if rss > POLICY['group_rss_watchdog_bytes']:
                        reason = 'group_rss_watchdog_limit'
                    elif state['available_memory_bytes'] < POLICY['available_memory_floor_bytes']:
                        reason = 'shared_available_memory_low_watermark'
                    elif state['disk_free_bytes'] < POLICY['disk_free_floor_bytes']:
                        reason = 'shared_disk_free_low_watermark'
                    elif len(group) > POLICY['max_group_processes']:
                        reason = 'owned_group_process_count_limit'
                    elif current - start >= timeout:
                        reason = 'wall_timeout'
                    if reason:
                        kill_owned()
                        break
                    time.sleep(POLICY['poll_interval_seconds'])
                code = process.wait(timeout=5)
            except BaseException as error:
                exception = {'type': type(error).__name__, 'message': str(error)}
                reason = reason or 'supervisor_error_or_interruption'
                kill_owned()
                if process is not None:
                    try:
                        code = process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        pass
            finally:
                if process is not None:
                    for _ in range(100):
                        remaining = live_members()
                        if not remaining:
                            break
                        time.sleep(0.01)
                    if remaining:
                        reason = reason or 'live_group_members_after_leader_exit'
                        kill_owned()
                        for _ in range(100):
                            remaining = live_members()
                            if not remaining:
                                break
                            time.sleep(0.01)
                for sig, handler in prior_handlers.items():
                    signal.signal(sig, handler)
        for stream in (stdout, stderr, samples):
            stream.flush()
            os.fsync(stream.fileno())
    receipt = {'name': name, 'argv': argv, 'cwd': str(REPO), 'started_utc': started,
               'finished_utc': SUPPORT.now(), 'elapsed_seconds': time.monotonic() - start,
               'executed': executed, 'exit_code': code,
               'passed': executed and code == 0 and reason is None and exception is None and not remaining,
               'timed_out': reason == 'wall_timeout', 'timeout_seconds': timeout,
               'stop_reason': reason, 'exception': exception, 'signals': signals,
               'remaining_live_group_members': remaining, 'policy': POLICY,
               'initial_resources': initial, 'peak_observed_group_rss_bytes': peak,
               'minimum_observed_available_memory_bytes': minimum_memory,
               'minimum_observed_disk_free_bytes': minimum_disk,
               'maximum_observed_sampling_interval_seconds': max_sample_interval,
               'stdout': SUPPORT.hash_regular(stdout_path), 'stderr': SUPPORT.hash_regular(stderr_path),
               'resource_samples': SUPPORT.hash_regular(samples_path)}
    SUPPORT.write_json(logs / (name + '.receipt.json'), receipt)
    recorder.steps.append(receipt)
    print(json.dumps({key: receipt[key] for key in
                      ['name', 'executed', 'exit_code', 'passed', 'stop_reason',
                       'elapsed_seconds', 'peak_observed_group_rss_bytes']}), flush=True)
    return receipt


def main():
    OUT.mkdir()
    for path in [OUT / 'records', OUT / 'target', OUT / 'runner-temp']:
        path.mkdir()
    (OUT / 'provider.env').touch(exist_ok=False)
    prefix = LIGHT / 'toolchain'
    env = dict(os.environ)
    env.update(PATH=str(prefix / 'bin') + ':' + env.get('PATH', '/usr/bin:/bin'),
               CARGO_HOME=str(LIGHT / 'cargo-home'), CARGO_TARGET_DIR=str(OUT / 'target'),
               RUSTC=str(prefix / 'bin/rustc'), RUSTDOC=str(prefix / 'bin/rustdoc'),
               CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_TERM_COLOR='never',
               RUSTFLAGS='', RUSTDOCFLAGS='', PYTHONDONTWRITEBYTECODE='1',
               RUNNER_TEMP=str(OUT / 'runner-temp'), GITHUB_ENV=str(OUT / 'provider.env'),
               TRNM_CI_RECEIPT_DIR=str(OUT / 'provider-observations'))
    for key in ['CARGO_ENCODED_RUSTFLAGS', 'CARGO_ENCODED_RUSTDOCFLAGS',
                'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'CARGO_BUILD_TARGET']:
        env.pop(key, None)
    recorder = SUPPORT.Recorder(OUT / 'records', env)
    cargo = str(prefix / 'bin/cargo')
    clippy = [cargo, 'clippy', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml',
              '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings']
    summary = {'schema': 'trnm-one-bounded-clippy-attempt-v1', 'started_utc': SUPPORT.now(),
               'source_commit': SOURCE, 'source_tree': TREE, 'policy': POLICY,
               'jobs': 1, 'incremental': 0, 'cargo_target_dir': str(OUT / 'target'),
               'required_clippy_argv': clippy, 'required_scope_relaxed': False,
               'runner': SUPPORT.hash_regular(Path(__file__)),
               'capability_probe': SUPPORT.hash_regular(BASE / 'capability-recheck/capabilities.json'),
               'before_anchor_reused': True, 'source_unchanged': None,
               'provider': None, 'strict_clippy': None, 'errors': [], 'skipped': [],
               'new_native_node_processes': 0, 'published': False, 'production_activation': False}
    before = None
    backend = None
    backend_before = None
    try:
        capabilities = json.loads((BASE / 'capability-recheck/capabilities.json').read_text())
        SUPPORT.require(all(capabilities[key] is True for key in
                        ['hard_per_process_virtual_address_limit_verified',
                         'owned_group_rss_monitor_and_kill_verified', 'same_budget_compiler_startup_succeeded']),
                        'resource capability probes did not establish the chosen supervision')
        light = json.loads((LIGHT / 'summary.json').read_text())
        before = json.loads((LIGHT / 'source-after.json').read_text())
        original_receipt = json.loads((LIGHT / 'records/source-after.receipt.json').read_text())
        SUPPORT.require(light['source_unchanged'] is True and original_receipt['passed'] is True
                        and before['tested_commit'] == SOURCE and before['tested_tree'] == TREE
                        and before['tracked_worktree_verified'] is True, 'before anchor is not exact source')
        summary['before_anchor'] = {'guard': before,
            'guard_file': SUPPORT.hash_regular(LIGHT / 'source-after.json'),
            'original_receipt': original_receipt,
            'scope': 'Reuse the prior completed full source-after observation as this later same-source stage before anchor; original execution time and identity retained.'}
        for name, expected in light['installed_binary_inputs'].items():
            observed = SUPPORT.hash_regular(prefix / 'bin' / name)
            SUPPORT.require(observed['sha256'] == expected['sha256'], 'toolchain binary changed: ' + name)
        preflight = recorder.command('preflight', ['/bin/bash', 'scripts/project-preflight.sh', '--dev'],
                                     cwd=REPO, timeout=120)
        SUPPORT.require(preflight['passed'], 'preflight failed')
        identity_code = ("import subprocess; "
            "assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='" + SOURCE + "'; "
            "assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()=='" + TREE + "'; "
            "assert subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],text=True)==''; "
            "print('exact source head/tree and clean status confirmed')")
        identity = recorder.command('live-source-identity', ['/usr/bin/python3', '-c', identity_code],
                                    cwd=REPO, timeout=120)
        SUPPORT.require(identity['passed'], 'live source identity differs from frozen anchor')
        summary['provider_preparation_script'] = SUPPORT.hash_regular(REPO / 'scripts/ci/prepare_pq_provider.sh')
        provider = bounded(recorder, 'provider', ['/bin/bash', 'scripts/ci/prepare_pq_provider.sh'], 900)
        summary['provider'] = provider
        if provider['passed']:
            preparation = json.loads((OUT / 'provider-observations/pq-provider/provider.json').read_text())
            SUPPORT.require(preparation['result'] == 'PREPARED_AND_SMOKE_VERIFIED'
                            and preparation['source_digest_verified'] is True
                            and preparation['source_archive_sha256_expected'] ==
                                '603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a',
                            'provider result is not bound to the fixed source/smoke')
            backend = Path(preparation['install_prefix'])
            SUPPORT.require(backend.is_relative_to(OUT / 'runner-temp'), 'provider prefix escaped task directory')
            exports = dict(line.split('=', 1) for line in (OUT / 'provider.env').read_text().splitlines())
            required = {'OPENSSL_DIR', 'OPENSSL_STATIC', 'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256',
                        'TRNM_PQ_OPENSSL_VERSION', 'OPENSSL_CONF', 'OPENSSL_MODULES'}
            SUPPORT.require(set(exports) == required and exports['OPENSSL_DIR'] == str(backend)
                            and exports['OPENSSL_STATIC'] == '1' and exports['TRNM_PQ_OPENSSL_VERSION'] == '3.5.9',
                            'provider exports differ')
            for key in list(env):
                if key.endswith(('_OPENSSL_DIR', '_OPENSSL_LIB_DIR', '_OPENSSL_INCLUDE_DIR',
                                 '_OPENSSL_STATIC', '_OPENSSL_LIBS', '_OPENSSL_NO_VENDOR')):
                    env.pop(key, None)
            env.pop('OPENSSL_LIBS', None)
            env.update(exports)
            env.update(OPENSSL_LIB_DIR=str(backend / 'lib'), OPENSSL_INCLUDE_DIR=str(backend / 'include'),
                       OPENSSL_NO_VENDOR='1', LD_LIBRARY_PATH=str(backend / 'lib') + ':' + str(prefix / 'lib'))
            backend_before = {item['path']: SUPPORT.hash_regular(Path(item['path']))
                              for item in preparation['native_backend_inputs']}
            SUPPORT.require(len(backend_before) == 5 and all(
                backend_before[item['path']]['sha256'] == item['sha256']
                for item in preparation['native_backend_inputs']), 'provider installed-byte binding differs')
            summary['provider_inputs_before'] = backend_before
            summary['provider_preparation'] = preparation
            summary['strict_clippy'] = bounded(recorder, 'strict-clippy', clippy, 1200)
        else:
            summary['skipped'].append({'step': 'strict-clippy', 'reason': 'pinned provider preparation did not pass'})
    except Exception as error:
        summary['errors'].append({'type': type(error).__name__, 'message': str(error)})
    finally:
        if backend_before is not None:
            try:
                current = {name: SUPPORT.hash_regular(Path(name)) for name in backend_before}
                summary['provider_inputs_unchanged'] = current == backend_before
                summary['provider_inputs_after'] = current
            except Exception as error:
                summary['provider_inputs_unchanged'] = False
                summary['errors'].append({'stage': 'provider-after', 'message': str(error)})
        if before is not None:
            after = recorder.command('source-after', ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py',
                                     '--kind', 'head', '--expected-head', SOURCE,
                                     '--output', str(OUT / 'source-after.json')], cwd=REPO, timeout=1200)
            if after['passed']:
                summary['source_after'] = json.loads((OUT / 'source-after.json').read_text())
                summary['source_unchanged'] = summary['source_after'] == before
            else:
                summary['source_unchanged'] = False
        success = (not summary['errors'] and not summary['skipped']
                   and summary['source_unchanged'] is True
                   and summary.get('provider_inputs_unchanged') is True
                   and summary['strict_clippy'] is not None and summary['strict_clippy']['passed'])
        summary['status'] = 'STRICT_CLIPPY_PASSED_WITH_RECORDED_RESOURCE_BUDGET' if success else 'BOUNDED_ATTEMPT_INCOMPLETE_OR_FAILED'
        summary['finished_utc'] = SUPPORT.now()
        summary['resources_final'] = available()
        SUPPORT.write_json(OUT / 'summary.json', summary)
        print(json.dumps({'summary': str(OUT / 'summary.json'), 'status': summary['status'],
                          'source_unchanged': summary['source_unchanged'], 'errors': summary['errors'],
                          'skipped': summary['skipped']}, sort_keys=True), flush=True)
    return 0 if success else 1


if __name__ == '__main__':
    sys.exit(main())
