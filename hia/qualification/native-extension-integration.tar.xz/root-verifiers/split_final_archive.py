from pathlib import Path
import hashlib, json, os, stat, sys

base = Path('/workspace/scratch/a638c5cc4765')
root = base / 'Trillionnium-Chain'
label = sys.argv[1]
source = root / 'hia/qualification' / (label + '-development.tar.xz')
readback = json.loads((base / (label + '-archive-readback.json')).read_bytes())
data = source.read_bytes()
assert len(data) == readback['bytes'] and hashlib.sha256(data).hexdigest() == readback['sha256']
directory = source.with_name(label + '-development.parts')
directory.mkdir(mode=0o755)
parts = []
for index, offset in enumerate(range(0, len(data), 6*1024*1024)):
    chunk = data[offset:offset+6*1024*1024]
    name = f'part-{index:03d}'
    with (directory / name).open('xb') as stream:
        stream.write(chunk)
    parts.append({'path':name, 'offset':offset, 'bytes':len(chunk), 'sha256':hashlib.sha256(chunk).hexdigest()})
manifest = {'schema':'trnm.hia.contiguous-archive.v1','logical_name':source.name,
            'archive':{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},'parts':parts}
(directory / 'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
seen = bytearray()
for row in manifest['parts']:
    path = directory / row['path']
    with os.fdopen(os.open(path, os.O_RDONLY|os.O_NOFOLLOW),'rb') as stream:
        before = os.fstat(stream.fileno()); actual=stream.read(row['bytes']+1); after=os.fstat(stream.fileno())
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
    assert len(actual)==row['bytes'] and hashlib.sha256(actual).hexdigest()==row['sha256'] and len(seen)==row['offset']
    seen.extend(actual)
assert seen == data
retained = base/'owner-extension-full-archives'/source.name
assert not retained.exists()
source.rename(retained)
receipt = {'schema':'trnm.hia.evidence-volumes-readback.v1','status':'PASS','manifest':str((directory/'manifest.json').relative_to(root)),
           'parts':len(parts),'complete_archive':manifest['archive'],'every_part_single_link_regular':True,
           'physically_concatenated_byte_identity':True,'retained_full_archive':str(retained)}
(base/(label+'-volumes-readback.json')).write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
print(json.dumps(receipt))
