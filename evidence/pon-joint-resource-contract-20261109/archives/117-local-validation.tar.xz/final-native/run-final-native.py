import subprocess,sys,json
from pathlib import Path
out=Path('/workspace/scratch/pon-joint-58fd59-build/final-native')
subprocess.run([sys.executable,str(out/'run-small-native.py')],check=True)
summary=json.loads((out/'small-native-summary.json').read_text())
assert all(row['returncode']==0 for row in summary),summary
subprocess.run([sys.executable,str(out/'run-actual-v4.py')],check=True)
