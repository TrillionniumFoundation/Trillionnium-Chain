from pathlib import Path
import sys,json,hashlib,tarfile,stat,os,time,traceback,subprocess
root=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo");base=root.parent/"ci-c390-readback-v1/14301115959";out=base/"independent-readback-v1";out.mkdir(mode=0o700)
(out/"driver.py").write_text(sys.argv[1]);sys.path.insert(0,str(root))
from hia.tools import qualify_mempool_ci as q
from hia.platform.mempool_typed.qualify import verify
from hia.platform.mempool_typed.contract import source_manifest,original_manifest
record={"status":"FAIL","head":"c3901ff19c26815205d9cdd6975fc24ecc51ae88","run_id":"44019939486","run_attempt":1,"artifact_id":14301115959,"runtime_reexecuted":False};start=time.monotonic_ns()
def need(v,m):
 if not v:raise ValueError(m)
try:
 p=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=root,capture_output=True,check=True)
 (out/"preflight.stdout.raw").write_bytes(p.stdout);(out/"preflight.stderr.raw").write_bytes(p.stderr)
 need(q.identity(base/"artifact.zip")=={"bytes":7260721,"sha256":"013ef7bc9d86cfacd8d6b302912d971737c6a528556a64558a3474662d39f271"},"Exact GitHub ZIP differs")
 artifact=base/"extracted";package=q.read(artifact/"package-manifest.json");binding=q.read(artifact/"binding.json")
 expected={"git_head":"c3901ff19c26815205d9cdd6975fc24ecc51ae88","run_id":"44019939486","attempt":1}
 record["actual_lineage"]=binding["lineage"]
 # The reader's public lineage schema is retained exactly; explicit expected values below are not inferred from the binding.
 need(package["packing_status"]==package["qualification_status"]=="PASS" and package["capture_errors"]==[],"Hosted package failed")
 lineage=binding["lineage"]
 need(lineage==expected and type(lineage["git_head"]) is str and type(lineage["run_id"]) is str and type(lineage["attempt"]) is int,"Wrong actual commit/run/attempt")
 need(type(package["lineage"].get("attempt")) is int,"Package attempt must be an integer")
 q.check_binding(binding,expected);q.check_bound_archive(binding,package["entries"])
 need(package["lineage"]==lineage and q.identity(artifact/"binding.json")==package["binding"],"Package/binding bytes or lineage differs")
 need(q.identity(artifact/"complete-evidence.tar.xz")==package["archive"],"Full archive differs")
 q.verify_archive(artifact/"complete-evidence.tar.xz",package["entries"],package["metadata_only"])
 need(package["metadata_only"]==[],"Unmaterialized special metadata")
 dest=out/"unpacked";dest.mkdir(mode=0o700);special=[]
 with tarfile.open(artifact/"complete-evidence.tar.xz","r:xz") as tf:
  for member in tf:
   path=Path(member.name);need(not path.is_absolute() and member.name==path.as_posix() and all(p not in ("",".","..") for p in path.parts),"Noncanonical member")
   target=dest/path
   need(target.resolve(strict=False).is_relative_to(dest.resolve()),"Extraction parent escapes private destination")
   need(not any(parent.is_symlink() for parent in target.parents if parent!=dest and dest in parent.parents),"Linked extraction ancestor")
   need(not target.exists() and not target.is_symlink(),"Repeated target")
   if member.isdir():target.mkdir(parents=True,mode=0o700);continue
   target.parent.mkdir(parents=True,exist_ok=True)
   if member.isfile():
    with tf.extractfile(member) as src,open(target,"xb") as dst:
     while block:=src.read(1<<20):dst.write(block)
    os.chmod(target,0o600)
   elif member.issym():os.symlink(member.linkname,target);special.append(member.name)
   elif member.isfifo():os.mkfifo(target,0o600);special.append(member.name)
   else:raise ValueError("Device/special archive member requires separate review")
 source=source_manifest(root);original=original_manifest(root)
 need(binding["source_inputs"]==source and binding["original_sources"]==original,"Current complete source maps differ")
 need(all(q.identity(root/n)==v for n,v in binding["ci_reader_sources"].items()),"Current CI reader sources differ")
 q.base.check_committed_sources({**source,**original,**binding["ci_reader_sources"]},root)
 pair=q.transfer.source_pair(dest/"observations",lineage);need(pair==binding["source_observations"],"Recorded source observations differ")
 need(q.identity(dest/"observations/binding.json")==q.identity(artifact/"binding.json"),"Inner/outer binding differ")
 replay=verify(dest/"complete",root)
 need(replay==binding["readback"],"Independent readback result differs")
 gates=q.gate_reports(dest/"source-controls",dest/"public-controls",dest/"complete")
 need(all(binding[k]==v for k,v in gates.items()),"Actual control gates differ")
 need(source_manifest(root)==source and original_manifest(root)==original,"Sources changed during readback")
 record.update(status="PASS",package=q.identity(artifact/"package-manifest.json"),binding=q.identity(artifact/"binding.json"),archive=q.identity(artifact/"complete-evidence.tar.xz"),readback=replay,gates=gates,source_files=len(source),original_files=len(original),source_after="MATCH",special_metadata_nodes=special,complete_original_binary=q.identity(dest/"complete/original/original-tests"),archive_members=len(package["entries"]))
except BaseException as e:record["failure"]={"error":repr(e),"traceback":traceback.format_exc()};raise
finally:
 record["elapsed_ns"]=time.monotonic_ns()-start;(out/"report.json").write_text(json.dumps(record,sort_keys=True,indent=2)+"\n");print(json.dumps(record),flush=True)
