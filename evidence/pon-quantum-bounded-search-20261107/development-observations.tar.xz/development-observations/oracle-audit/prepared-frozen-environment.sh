# Prepared only. Source with the frozen commit as argument; no builds are started here.
set -euo pipefail
trnm_frozen_commit="${1:?pass the complete frozen code commit}"
[[ "$trnm_frozen_commit" =~ ^[0-9a-f]{40}$ ]]
source /workspace/scratch/62902f6722b7/env-next.sh
set -a
source /workspace/scratch/62902f6722b7/pq-next/exports.env
set +a
export CARGO_TARGET_DIR=/workspace/scratch/c9b48df754d6/target
export RUST_TEST_THREADS=1
export TRNM_CI_TOOL_ROOT=/workspace/scratch/c9b48df754d6/validation-next/tools
export TRNM_CI_RECEIPT_DIR="/workspace/scratch/c9b48df754d6/validation-next/frozen-$trnm_frozen_commit/ci"
export RUNNER_TEMP="/workspace/scratch/c9b48df754d6/validation-next/frozen-$trnm_frozen_commit/tmp"
mkdir -p "$RUNNER_TEMP"
cd /workspace/scratch/c9b48df754d6/chain-quantum-next
