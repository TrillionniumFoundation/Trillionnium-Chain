#!/usr/bin/env python3
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/scratch/de92d82e166f/chain_latency')
OUT=Path('/workspace/scratch/de92d82e166f/latency-validation-rust')
TOOL=Path('/workspace/scratch/270e2a9ce94f/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
ENV=os.environ.copy()
ENV['PATH']=str(TOOL)+os.pathsep+ENV.get('PATH','')
ENV['CARGO_HOME']='/workspace/scratch/270e2a9ce94f/toolchain/cargo'
ENV['CARGO_TARGET_DIR']='/workspace/scratch/de92d82e166f/latency-cargo-target'
def git(*args):
 p=subprocess.run(['git',*args],cwd=ROOT,text=True,capture_output=True)
 if p.returncode: raise RuntimeError(p.stderr)
 return p.stdout

def identity():
 paths=git('ls-files','-z','--','trillionnium','rust-toolchain.toml','.cargo').split('\0')
 rows={}
 for name in paths:
  if not name: continue
  p=ROOT/name
  if p.is_file() and (p.suffix in ('.rs','.toml','.lock') or p.name in ('config','Cargo.lock')):
   data=p.read_bytes();rows[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 serial=json.dumps(rows,sort_keys=True,separators=(',',':')).encode()
 return {'head':git('rev-parse','HEAD').strip(),'tree':git('rev-parse','HEAD^{tree}').strip(),'status':git('status','--porcelain=v1'), 'rust_source_files':rows,'rust_source_identity_sha256':hashlib.sha256(serial).hexdigest()}

def main():
 label=sys.argv[1]; cwd=ROOT if sys.argv[2]=='root' else ROOT/'trillionnium';cmd=sys.argv[3:]
 before=identity();start=time.time_ns()
 summary={'label':label,'command':cmd,'cwd':str(cwd),'started_unix_ns':start,'source_before':before,'environment_overrides':{k:ENV[k] for k in ('PATH','CARGO_HOME','CARGO_TARGET_DIR')},'inherited_build_environment':{k:ENV[k] for k in ('RUSTC','RUSTDOC','RUSTUP_TOOLCHAIN','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_JOBS') if k in ENV}}
 out=OUT/(label+'.stdout.log');err=OUT/(label+'.stderr.log')
 with out.open('wb') as stdout,err.open('wb') as stderr:
  run=subprocess.run(cmd,cwd=cwd,env=ENV,stdout=stdout,stderr=stderr)
 summary.update(returncode=run.returncode,finished_unix_ns=time.time_ns(),source_after=identity())
 summary['elapsed_seconds']=(summary['finished_unix_ns']-start)/1e9
 summary['source_head_unchanged']=summary['source_before']['head']==summary['source_after']['head']
 summary['rust_bytes_unchanged']=summary['source_before']['rust_source_identity_sha256']==summary['source_after']['rust_source_identity_sha256']
 for name,path in [('stdout',out),('stderr',err)]:
  data=path.read_bytes();summary[name]={'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 (OUT/(label+'.json')).write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
 print(json.dumps({k:summary[k] for k in ('label','command','returncode','elapsed_seconds','source_head_unchanged','rust_bytes_unchanged')}))
 if run.returncode:
  print(err.read_text(errors='replace')[-6500:])
 return run.returncode
if __name__=='__main__':sys.exit(main())
