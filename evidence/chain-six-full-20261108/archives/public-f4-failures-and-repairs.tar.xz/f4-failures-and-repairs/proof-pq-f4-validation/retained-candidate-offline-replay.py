import hashlib,importlib.util,json,pathlib,sys
gate_path,mode,out,proof,binary=sys.argv[1:]
spec=importlib.util.spec_from_file_location('reviewed_gate',gate_path)
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
out=pathlib.Path(out)
identity=json.loads((out/'identity.json').read_text())
aggregate=json.loads((out/'result.json').read_text())
recorded=pathlib.Path(aggregate['controls'][0]['process']['command'][1]).parent.parent
binary_sha=hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest()
assert binary_sha==identity['verifier_sha256']
kwargs={'verifier_path':pathlib.Path(identity['verifier_path']),'verifier_sha256':binary_sha,'recorded_out':recorded}
if mode=='current':kwargs['stage_schema']=gate.CURRENT_STAGE_SCHEMA
result=gate.validate(out,pathlib.Path(proof),**kwargs)
print(json.dumps({'completed_controls':result['completed_controls'],'positive':result['positive_controls_passed'],'negative':result['negative_controls_passed'],'binary_sha256':binary_sha,'stage_schema':result['controls'][0]['process']['schema'],'recorded_output':str(recorded),'review':'retained artifact consistency only; no new verifier execution','quantum_qualification':False}))
