import datetime,hashlib,json,os,pathlib,re,subprocess,sys,time,traceback
R=pathlib.Path('/home/qq/chain-system-security-20261112-306929')
HEAD='bac6b7659bd7e2d633e25c2da0add60f6a10c7fb'
O=pathlib.Path('/home/qq/chain-system-security-native-receipts-20261112-306929/root-native-bac6b765')
P=pathlib.Path('/home/qq/chain-system-security-root-provider-20261112-306929')
TC=pathlib.Path('/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu')
O.mkdir(parents=True,exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,v):
 with (O/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],text=True).strip()
assert git('rev-parse','HEAD')==HEAD and not git('status','--porcelain=v1')
provider_raw=(P/'observations/pq-provider/provider.json').read_bytes()
assert sha(provider_raw)=='509219f0ebd60c563342a509a9751a98222b44890a28552c8003e751924a9eeb'
provider=json.loads(provider_raw)
assert provider['result']=='PREPARED_AND_SMOKE_VERIFIED' and provider['exit_code']==0
env_raw=(P/'provider.env').read_bytes()
assert sha(env_raw)=='6de317bdd1826065aefeae7335a552dfae7b87e421a8f1aa66d32aa31adab2ed'
E=dict(os.environ)
E.update(PATH=str(TC/'bin')+':'+E.get('PATH','/usr/bin:/bin'),RUSTC=str(TC/'bin/rustc'),LD_LIBRARY_PATH=str(TC/'lib'),CARGO_HOME='/home/qq/.cargo',CARGO_TARGET_DIR=str(R/'trillionnium/target'),CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1',PYTHONPATH=str(R/'scripts/ci'))
allowed={'OPENSSL_DIR','OPENSSL_STATIC','TRNM_PQ_OPENSSL','TRNM_PQ_OPENSSL_SHA256','TRNM_PQ_OPENSSL_VERSION','OPENSSL_CONF','OPENSSL_MODULES'}
entries=dict(line.split('=',1) for line in env_raw.decode().splitlines())
assert set(entries)==allowed
E.update(entries)
def provider_check():
 values=[]
 for row in provider['native_backend_inputs']:
  p=pathlib.Path(row['path']);b=p.read_bytes()
  assert len(b)==row['bytes'] and sha(b)==row['sha256']
  values.append({'path':str(p),'bytes':len(b),'sha256':sha(b)})
 assert len(values)==5
 return values
inputs=provider_check()
sys.path.insert(0,str(R/'scripts/ci'))
from verify_ci_source import verify
import run_pq_root_witness_v5 as v5
import run_pq_root_continuation_v4 as v4
assert [len(v5.WITNESS),len(v5.DURABLE),len(v5.PROVIDER_READBACK),len(v4.PROVIDER)]==[17,12,8,14]
source_before=verify('head',HEAD,root=R)
save('source-before.json',source_before)
helper_paths=['scripts/ci/record_pq_native_command.py','scripts/ci/run_pq_root_witness_v5.py','scripts/ci/run_pq_root_continuation_v4.py','scripts/ci/run_pq_root_native_v3.py']
helpers={}
for path in helper_paths:
 b=(R/path).read_bytes()
 expected=subprocess.check_output(['git','-C',str(R),'show',HEAD+':'+path])
 assert b==expected;helpers[path]=sha(b)
configuration={'schema':'trnm-root-native-bac6-launch-v1','head':HEAD,'tree':git('rev-parse','HEAD^{tree}'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_helpers_sha256':helpers,'provider_receipt_sha256':sha(provider_raw),'provider_before':inputs,'expected_names':{'fresh-witness':list(v5.WITNESS),'durable-witness':list(v5.DURABLE),'provider-readback-v5':list(v5.PROVIDER_READBACK),'provider-readback-v4':list(v4.PROVIDER)},'planned_native_methods':51,'environment':{k:E.get(k) for k in ['PATH','RUSTC','LD_LIBRARY_PATH','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RUST_TEST_THREADS','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_INCREMENTAL','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER',*sorted(allowed)]},'original_profiles_and_gate_thresholds_modified':False,'status':'HOLD','production_activation':False}
save('configuration.json',configuration)
records=[]
def record(label,command):
 argv=['python3','scripts/ci/record_pq_native_command.py','--kind','head','--candidate',HEAD,'--tested',HEAD,'--label',label,'--output',str(O/'records'),'--',*command]
 started=time.monotonic()
 with (O/(label+'.driver.log')).open('xb') as f:p=subprocess.run(argv,cwd=R,env=E,stdout=f,stderr=subprocess.STDOUT)
 receipt_path=O/'records'/(label+'.json')
 actual=json.loads(receipt_path.read_text()) if receipt_path.is_file() else None
 row={'label':label,'argv':argv,'recorder_exit_code':p.returncode,'elapsed_seconds':time.monotonic()-started,'receipt':str(receipt_path),'actual_status':actual.get('status') if actual else None,'actual_exit_code':actual.get('exit_code') if actual else None}
 records.append(row);save(label+'-execution.json',row)
 print(json.dumps(row),flush=True)
 return row,actual
try:
 _,pre=record('preflight',['bash','scripts/project-preflight.sh']);assert pre and pre.get('status')=='command_succeeded'
 _,compiler=record('toolchain-rustc',[str(TC/'bin/rustc'),'-Vv']);assert compiler and compiler.get('status')=='command_succeeded'
 assert (O/'records/toolchain-rustc.log').read_text().startswith('rustc 1.95.0 ')
 _,cargo=record('toolchain-cargo',[str(TC/'bin/cargo'),'-Vv']);assert cargo and cargo.get('status')=='command_succeeded'
 v5_record,v5_outer=record('root-witness-v5',['python3','scripts/ci/run_pq_root_witness_v5.py','--out',str(O/'v5-witness')])
 v4_argv=['cargo','test','--locked','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--features','pq-root-v3','--test','root_effect_readback_v4_native','--','--nocapture','--test-threads=1']
 v4_record,v4_outer=record('root-provider-v4',v4_argv)
 v5_path=O/'v5-witness/summary.json'
 v5_report=json.loads(v5_path.read_text()) if v5_path.is_file() else None
 v5_ok=bool(v5_report and v5_report.get('source')==HEAD and v5_report.get('component_execution_passed') and v5_outer and v5_outer.get('status')=='command_succeeded')
 observation=None;error=None
 try:
  assert v4_outer is not None
  observation=v4.checked_result((O/'records/root-provider-v4.log').read_text(),v4.PROVIDER,v4_outer['exit_code'])
  assert observation['filtered_out']==0
 except (AssertionError,ValueError,KeyError,TypeError,OSError) as e:error=str(e)
 v4_ok=bool(error is None and v4_outer and v4_outer.get('status')=='command_succeeded')
 save('native-inventory-observation.json',{'source':HEAD,'v5_complete_inventory_passed':v5_ok,'v5_report':v5_report,'v4_complete_inventory_passed':v4_ok,'v4_observation':observation,'v4_error':error,'all_51_methods_verified':v5_ok and v4_ok,'status':'HOLD','production_activation':False})
 clippy_record,clippy_outer=record('workspace-strict-clippy',['cargo','clippy','--locked','--manifest-path','trillionnium/Cargo.toml','--workspace','--all-targets','--all-features','--','-D','warnings'])
 clippy_ok=bool(clippy_outer and clippy_outer.get('status')=='command_succeeded')
 after=verify('head',HEAD,root=R);save('source-after.json',after);assert after==source_before
 provider_after=provider_check();save('provider-after.json',provider_after);assert provider_after==inputs
 binaries={}
 logs=[O/'records/root-provider-v4.log',*(O/'v5-witness').glob('*.log')] if (O/'v5-witness').is_dir() else [O/'records/root-provider-v4.log']
 for log in logs:
  if not log.is_file():continue
  for value in re.findall(r'Running [^\n]*\(([^()\n]+)\)',log.read_text(errors='replace')):
   p=pathlib.Path(value)
   if not p.is_absolute():p=R/p
   if p.is_file():
    b=p.read_bytes()
    if b[:4]==b'\x7fELF':binaries[str(p)]={'bytes':len(b),'sha256':sha(b),'recorded_after_execution_without_live_inode_pin':True}
 save('native-binaries-after.json',binaries)
 report={'schema':'trnm-root-native-and-strict-clippy-result-v1','source':HEAD,'tree':git('rev-parse','HEAD^{tree}'),'source_before_after_equal':source_before==after,'provider_before_after_equal':inputs==provider_after,'v5_complete_inventory_passed':v5_ok,'v4_complete_inventory_passed':v4_ok,'all_51_methods_verified':v5_ok and v4_ok,'workspace_all_targets_all_features_strict_clippy_passed':clippy_ok,'commands':records,'native_observation':'native-inventory-observation.json','status':'HOLD','production_activation':False,'independent_custody_verified':False,'actual_external_effects_verified':False,'native_m15_production_integration_complete':False}
 save('summary.json',report)
 print(json.dumps(report),flush=True)
 raise SystemExit(0 if v5_ok and v4_ok and clippy_ok else 1)
except BaseException as e:
 if not isinstance(e,SystemExit) or e.code:
  save('launcher-terminal-failure.json',{'error_type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),'completed_records':records,'source':HEAD,'status':'HOLD'})
 raise
