#!/usr/bin/env python3
"""Archive completed exact-source native receipts and re-read retained ELF bytes.

Run only after the coordinator observes the authoritative terminal state of the
original and follow-up jobs. This is evidence collection, never a replay or pass.
"""
import gzip
import hashlib
import io
import json
import os
import pathlib
import re
import stat
import subprocess
import tarfile
import time

TASK = pathlib.Path('/data/chain-p0-crossrepo-e0c10-v3')
SRC = TASK / 'source'
HEAD = 'ea909124cc460f364bd17b009073306014133f48'
TREE = '96712231eba3d333bdfebefa9c22c80ea1794d04'
MAX_RECEIPT_BYTES = 128 * 1024**2
CHUNK = 1024**2


def need(ok, why):
    if not ok:
        raise RuntimeError(why)


def stat_identity(value):
    return (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns,
            value.st_ctime_ns, value.st_mode, value.st_nlink)


def identity(path):
    value = path.lstat()
    need(stat.S_ISREG(value.st_mode), 'non-regular input: ' + str(path))
    return stat_identity(value)


def readback(path, max_bytes, capture=False):
    """Read magic, exact bounded bytes and hash on one nonblocking descriptor."""
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode), 'non-regular opened input: ' + str(path))
        need(before.st_size <= max_bytes, 'opened input exceeds declared read bound: ' + str(path))
        need(identity(path) == stat_identity(before), 'opened input path rebound: ' + str(path))
        digest, prefix, count, pieces = hashlib.sha256(), b'', 0, []
        while count <= before.st_size:
            piece = os.read(fd, min(CHUNK, before.st_size + 1 - count))
            if not piece:
                break
            count += len(piece)
            digest.update(piece)
            prefix = (prefix + piece[:4])[:4]
            if capture:
                pieces.append(piece)
        after = os.fstat(fd)
        need(count == before.st_size and stat_identity(before) == stat_identity(after),
             'opened input changed or EOF differs: ' + str(path))
        need(identity(path) == stat_identity(after), 'fresh input path identity differs: ' + str(path))
        observed = dict(bytes=count, sha256=digest.hexdigest(),
                        observed_mode=stat.S_IMODE(after.st_mode),
                        observed_executable_mode=bool(after.st_mode & 0o111),
                        observed_is_elf=prefix == b'\x7fELF',
                        descriptor_identity=list(stat_identity(after)))
        return observed, b''.join(pieces) if capture else None
    finally:
        os.close(fd)


def sha(path):
    return readback(path, identity(path)[2])[0]['sha256']


def read_json(path):
    observed, raw = readback(path, MAX_RECEIPT_BYTES, capture=True)
    return json.loads(raw), observed


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=SRC, text=True).strip()


def source_identity():
    need(git('rev-parse', 'HEAD') == HEAD and git('rev-parse', 'HEAD^{tree}') == TREE,
         'frozen source identity differs')
    need(not git('status', '--porcelain'), 'frozen source is dirty')


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


source_identity()
subprocess.run(['bash', 'scripts/project-preflight.sh'], cwd=SRC, check=True)
start = time.monotonic()
original, original_observed = read_json(TASK / 'records/controlled-integrated-v1/summary.json')
need(original['source'] == HEAD and original['tree'] == TREE and original['native_invocations'] == 89,
     'original source or full invocation denominator differs')
followup, followup_observed = read_json(TASK / 'records/followup-v1/summary.json')
need(followup['source'] == HEAD and followup['tree'] == TREE and len(followup['rows']) == 2,
     'follow-up must have recorded both original scheduled groups')
paths = []
for relative in ('records/controlled-integrated-v1', 'records/extra-native-v1',
                 'records/followup-v1', 'records/sqlite-requalification-v1'):
    root = TASK / relative
    need(root.is_dir() and not root.is_symlink(), 'receipt directory absent or symlink')
    for path in root.rglob('*'):
        mode = path.lstat().st_mode
        if stat.S_ISDIR(mode):
            continue
        need(stat.S_ISREG(mode), 'special or symlink receipt input: ' + str(path))
        paths.append(path)
paths.extend(TASK / name for name in ('runner-controlled-v3.py', 'extra-native-v1.py',
                                     'environment.json', 'run-v3-followup.py',
                                     'native-preparation-v3.json'))
paths = sorted(set(paths))
need(len(paths) <= 2400 and sum(identity(path)[2] for path in paths) <= MAX_RECEIPT_BYTES,
     'evidence archive bound')
need(all(path.resolve().is_relative_to(TASK.resolve()) for path in paths), 'foreign receipt path')
inventory = []
for path in paths:
    observed, _ = readback(path, MAX_RECEIPT_BYTES)
    inventory.append(dict(path=str(path.relative_to(TASK)), bytes=observed['bytes'],
                          sha256=observed['sha256']))
inventory_by_path = {row['path']: row for row in inventory}
for name, observed in (('records/controlled-integrated-v1/summary.json', original_observed),
                       ('records/followup-v1/summary.json', followup_observed)):
    need(all(inventory_by_path[name][key] == observed[key] for key in ('bytes', 'sha256')),
         'decoded summary differs from archived inventory: ' + name)
retained = {}
binding_errors = []
declared_binary_references = 0


def collect_binary(value, field, receipt, location):
    """Collect declarations without probing existence, mode or current type."""
    global declared_binary_references
    declared_binary_references += 1
    try:
        need(isinstance(value, dict), 'binary declaration must be an object')
        need(all(key in value for key in (field, 'sha256', 'bytes', 'package_id',
                                          'target', 'features', 'profile')),
             'binary declaration schema incomplete')
        need(isinstance(value[field], str), 'binary path must be a string')
        path = pathlib.Path(value[field])
        root = TASK / ('retained-binaries' if field == 'retained_path'
                       else 'target-controlled-integrated-v1')
        need(path.is_absolute() and '..' not in path.parts and path.is_relative_to(root),
             'binary declaration is outside its permitted root')
        need(isinstance(value['sha256'], str) and re.fullmatch('[0-9a-f]{64}', value['sha256']),
             'binary SHA256 malformed')
        need(type(value['bytes']) is int and value['bytes'] >= 0, 'binary byte count malformed')
        need(isinstance(value['package_id'], str) and isinstance(value['target'], dict)
             and isinstance(value['features'], list) and isinstance(value['profile'], dict),
             'compiler artifact metadata malformed')
        if field == 'retained_path':
            need(isinstance(value.get('executable'), str) and value.get('role') in ('harness', 'ordinary-cli'),
                 'retained artifact role/executable metadata absent')
        entry = retained.setdefault(path, dict(expected=set(), expected_bytes=set(),
                                               receipts=set(), declarations=[], field=field))
        need(entry['field'] == field, 'binary declaration mixes retained and live roles')
        entry['expected'].add(value['sha256'])
        entry['expected_bytes'].add(value['bytes'])
        entry['receipts'].add(receipt)
        entry['declarations'].append(dict(receipt=receipt, location=location, path_field=field,
                                          metadata=value))
    except Exception as error:
        binding_errors.append(dict(receipt=receipt, location=location,
                                   error=type(error).__name__ + ': ' + str(error)))


def collect_receipt(value, receipt):
    if receipt.endswith('-binaries.json'):
        if not isinstance(value, dict):
            binding_errors.append(dict(receipt=receipt, error='binary mapping is not an object'))
            return
        for key, item in value.items():
            if not isinstance(item, dict) or item.get('path') != key:
                binding_errors.append(dict(receipt=receipt, location=str(key),
                                           error='binary mapping key and declared path differ'))
            collect_binary(item, 'path', receipt, str(key))
    else:
        if not isinstance(value, dict) or not isinstance(value.get('artifacts'), list):
            binding_errors.append(dict(receipt=receipt, error='retained artifact binding schema absent'))
            return
        if value.get('source') != HEAD or value.get('tree') != TREE:
            binding_errors.append(dict(receipt=receipt, error='retained binding source/tree differs'))
        for index, item in enumerate(value['artifacts']):
            collect_binary(item, 'retained_path', receipt, 'artifacts/' + str(index))


for path in paths:
    if path.name.endswith(('-binding.json', '-binaries.json')):
        name = str(path.relative_to(TASK))
        try:
            value, observed = read_json(path)
            need(all(observed[key] == inventory_by_path[name][key] for key in ('bytes', 'sha256')),
                 'binding receipt differs from inventory')
            collect_receipt(value, name)
        except Exception as error:
            binding_errors.append(dict(receipt=name, error=type(error).__name__ + ': ' + str(error)))
binary_rows = []
for path, value in sorted(retained.items()):
    row = dict(path=str(path), expected_sha256=sorted(value['expected']),
               expected_bytes=sorted(value['expected_bytes']),
               binding_receipts=sorted(value['receipts']), declarations=value['declarations'],
               binding_role=('content_addressed_retained_copy' if value['field'] == 'retained_path'
                             else 'live_build_output'),
               matches_original_binding=False, current_remote_bytes_observed=False)
    try:
        root = TASK / ('retained-binaries' if value['field'] == 'retained_path'
                       else 'target-controlled-integrated-v1')
        need(path.resolve().is_relative_to(root.resolve()), 'declared binary escaped its root')
        observed, _ = readback(path, max(value['expected_bytes']))
        row.update(observed, current_remote_bytes_observed=True)
        need(observed['observed_is_elf'], 'declared binary bytes are not ELF')
        need(value['field'] == 'retained_path' or observed['observed_executable_mode'],
             'live executable lost its executable mode')
        row['matches_original_binding'] = (value['expected'] == {observed['sha256']}
                                           and value['expected_bytes'] == {observed['bytes']})
    except Exception as error:
        row['readback_error'] = type(error).__name__ + ': ' + str(error)
    binary_rows.append(row)
manifest = dict(schema='completed-v3-native-evidence-v2', source=HEAD, tree=TREE,
                original_job='1a1b3dcfc11-fc05-852d', followup_job='1a1b4068ee2-fc05-85e6',
                files=inventory, actual_binary_readback=binary_rows,
                declared_binary_reference_count=declared_binary_references,
                validated_binary_reference_count=sum(len(value['declarations']) for value in retained.values()),
                binary_declaration_errors=binding_errors,
                binary_readback_scope='Executable declarations in inventoried binding receipts only; absent declarations from earlier failed builds remain missing in the original task denominator, never synthesized or accepted.',
                actual_binary_readback_all_match=bool(binary_rows) and not binding_errors
                    and all(row['matches_original_binding'] for row in binary_rows),
                remote_binary_scope='Current descriptor observations; retained copies and mutable live build outputs are reported separately, not a guarantee of future retention.',
                all_declared_remote_binary_bytes_observed=bool(binary_rows) and not binding_errors
                    and all(row['current_remote_bytes_observed'] for row in binary_rows),
                native_invocations=original['native_invocations'],
                native_accepted=original['native_accepted'], original_accepted=original['accepted'],
                followup_accepted=followup['accepted'], whole_system_qualified=False,
                no_acceptance_promotion=True)
archive = TASK / 'v3-completed-native-evidence.tar.gz'
manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
with archive.open('xb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w|') as tar:
    for path, row in zip(paths, inventory):
        observed, raw = readback(path, row['bytes'], capture=True)
        need(observed['sha256'] == row['sha256'] and observed['bytes'] == row['bytes'],
             'receipt changed before archive')
        info = tarfile.TarInfo(row['path'])
        info.size = len(raw)
        info.mode = observed['observed_mode']
        tar.addfile(info, io.BytesIO(raw))
    info = tarfile.TarInfo('ARCHIVE_MANIFEST.json')
    info.size = len(manifest_raw)
    tar.addfile(info, io.BytesIO(manifest_raw))
archive_observed, archive_raw = readback(archive, 12 * 1024**2, capture=True)
expected_members = {row['path']: (row['bytes'], row['sha256']) for row in inventory}
expected_members['ARCHIVE_MANIFEST.json'] = (len(manifest_raw), hashlib.sha256(manifest_raw).hexdigest())
seen = set()
with tarfile.open(fileobj=io.BytesIO(archive_raw), mode='r:gz') as tar:
    for member in tar:
        need(member.isfile() and member.name in expected_members and member.name not in seen,
             'archive has duplicate, foreign or nonregular member')
        expected_size, expected_sha = expected_members[member.name]
        need(member.size == expected_size, 'archive member size differs')
        with tar.extractfile(member) as stream:
            digest, count = hashlib.sha256(), 0
            while count <= expected_size:
                piece = stream.read(min(CHUNK, expected_size + 1 - count))
                if not piece:
                    break
                digest.update(piece)
                count += len(piece)
        need(count == expected_size and digest.hexdigest() == expected_sha,
             'actual archived member bytes differ: ' + member.name)
        seen.add(member.name)
need(seen == set(expected_members), 'archive omitted an expected member')
source_identity()
need(identity(archive) == tuple(archive_observed['descriptor_identity']), 'archive path changed after verification')
save(TASK / 'v3-completed-native-evidence-manifest.json', manifest)
receipt = dict(schema='completed-v3-native-archive-receipt-v1', path=str(archive),
               bytes=archive_observed['bytes'], sha256=archive_observed['sha256'], file_count=len(paths),
               source=HEAD, tree=TREE, actual_binary_readback_count=len(binary_rows),
               actual_binary_readback_all_match=manifest['actual_binary_readback_all_match'],
               archive_members_verified=len(seen), actual_archive_payloads_match_inventory=True,
               evidence_collection_wall_seconds=time.monotonic()-start,
               evidence_collection_is_native_execution=False, whole_system_qualified=False)
save(TASK / 'v3-completed-native-archive-receipt.json', receipt)
print(json.dumps(receipt, indent=2, sort_keys=True), flush=True)
raise SystemExit(0 if manifest['actual_binary_readback_all_match'] else 1)
