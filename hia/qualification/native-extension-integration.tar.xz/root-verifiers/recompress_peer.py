from pathlib import Path
import hashlib, json, lzma, time

base = Path('/workspace/scratch/a638c5cc4765')
archive = base / 'Trillionnium-Chain/hia/qualification/peer-lease-development.tar.xz'
old_report_path = base / 'peer-lease-archive-readback.json'
report = json.loads(old_report_path.read_bytes())
assert hashlib.sha256(archive.read_bytes()).hexdigest() == report['sha256']
saved = base / 'owner-extension-full-archives/peer-lease-development.preset6.tar.xz'
assert not saved.exists()
archive.rename(saved)
old_report_path.rename(base / 'peer-lease-archive-readback-preset6.json')
start = time.monotonic_ns()
before = hashlib.sha256(); total = 0
with lzma.open(saved, 'rb') as source, lzma.open(archive, 'xb', preset=9) as target:
    while chunk := source.read(4 * 1024 * 1024):
        before.update(chunk); total += len(chunk); target.write(chunk)
after = hashlib.sha256(); replayed = 0
with lzma.open(archive, 'rb') as source:
    while chunk := source.read(4 * 1024 * 1024):
        after.update(chunk); replayed += len(chunk)
assert total == replayed and before.digest() == after.digest()
report['bytes'] = archive.stat().st_size
report['sha256'] = hashlib.sha256(archive.read_bytes()).hexdigest()
report['lossless_recompression'] = {
    'xz_preset': 9, 'tar_bytes': total, 'tar_sha256': before.hexdigest(),
    'complete_before_after_decompressed_byte_identity_verified': True,
    'prior_container': {'bytes': saved.stat().st_size, 'sha256': hashlib.sha256(saved.read_bytes()).hexdigest()},
    'wall_ns': time.monotonic_ns() - start,
}
old_report_path.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
print(json.dumps(report), flush=True)
