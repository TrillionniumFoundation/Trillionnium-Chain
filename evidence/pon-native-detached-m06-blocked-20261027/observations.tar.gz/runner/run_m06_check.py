from pathlib import Path
import importlib.util,json,os,sys
root=Path('/workspace/scratch/56818e4fba76/chain-history-m06')
spec=importlib.util.spec_from_file_location('replay',root/'scripts/ci/replay_pinned_native.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
os.chdir(root)
prefix='/workspace/scratch/56818e4fba76/toolchains/rust-1.95.0/bin'
os.environ.update(PATH=prefix+':'+os.environ['PATH'], CARGO_HOME='/workspace/scratch/56818e4fba76/toolchains/cargo', CARGO_TARGET_DIR='/workspace/scratch/56818e4fba76/target-history', CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', CARGO=prefix+'/cargo', RUSTC=prefix+'/rustc', RUSTDOC=prefix+'/rustdoc')
result=module.run_child(sys.argv[3:],Path('/workspace/scratch/56818e4fba76/history-validation/m06-precommit')/sys.argv[1],timeout=float(sys.argv[2]))
print(json.dumps(result,indent=2))
sys.exit(0 if result['exit_code']==0 and not result['timed_out'] else 1)
