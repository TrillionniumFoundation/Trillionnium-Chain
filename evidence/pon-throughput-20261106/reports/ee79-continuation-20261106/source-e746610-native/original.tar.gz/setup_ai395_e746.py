#!/usr/bin/env python3
"""Exclusive task setup and exact-source serial qualification; no gate changes."""
import base64
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

BASE = Path('/home/qq/work/chain-throughput-20261106-ee79')
ROOT = BASE / 'qualification-118-e7466106a2a6'
REPO = BASE / 'repo'
TMP = Path('/home/qq/trnm-ee79-e7466106a2a6-tmp')
CARRIER = BASE / 'e746-qualification-setup-carrier.json'
OLD_HEAD = '0bca28ebf59058b6aba9db5eb956c4479556e9ee'
HEAD = 'e7466106a2a647c8032556273101440384d88b70'
TREE = '63e03dc848eeb92d747fe2c7926c2f758b277cef'
PINS = {
    'run_native_qualification.py': 'da7dc56e80384b2d5b44ae84d11024a36fa28e94a6ba7c0cf7684937cc322fb2',
    'disk_guard.py': '9e050c1a0170b100662759b3d4161f79b490888ef2b53d88e410e417b893e322',
    'observe_authenticated_ignored.py': 'b212575359d26031fa9418ec529943c8c553239680550d4b1087d2ee7385a97f',
    'run_ai395_pipeline.py': '8fba04f38b167876e0d24e4773e796efc84a1389bc5063c14cd0e344a1ca8ce0',
    'source.bundle': '45331d85469904e07c1816eb7a2d760d7aa2a019a642283f21c8794920bfc9d2',
}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


def facts(path):
    info = path.lstat()
    return dict(path=str(path), uid=info.st_uid, gid=info.st_gid, device=info.st_dev,
                inode=info.st_ino, mode_octal=oct(stat.S_IMODE(info.st_mode)),
                is_directory=stat.S_ISDIR(info.st_mode), is_symlink=stat.S_ISLNK(info.st_mode))


def main():
    if ROOT.exists() or ROOT.is_symlink() or TMP.exists() or TMP.is_symlink():
        raise ValueError('exclusive run root or private TMPDIR already exists; no overwrite allowed')
    prior_archive = BASE / 'qualification-114-0bca28ebf590-runtime2/native-0bca-runtime2-original-failure.tar.gz'
    if digest(prior_archive) != '1ab4b2ea15284eb9cbc8b8c1e2e2ad3404634221f91caeea22397c38b9a614b7':
        raise ValueError('retained original runtime2 archive changed')
    payload = json.loads(CARRIER.read_bytes())
    if payload['head'] != HEAD or payload['tree'] != TREE or set(payload['files']) != set(PINS) | {'setup_ai395_e746.py'}:
        raise ValueError('qualification carrier identity/files mismatch')
    decoded = {}
    for name, item in payload['files'].items():
        data = base64.b64decode(item['base64'], validate=True)
        actual = hashlib.sha256(data).hexdigest()
        if actual != item['sha256'] or (name in PINS and actual != PINS[name]):
            raise ValueError('qualification helper or bundle digest mismatch: ' + name)
        decoded[name] = data
    before = [facts(directory) for directory in reversed(TMP.parents)]
    for entry in before:
        if not entry['is_directory'] or entry['is_symlink'] or entry['uid'] not in (0, os.geteuid()) or int(entry['mode_octal'], 8) & 0o022:
            raise ValueError('new TMPDIR ancestry fails original owner/mode safety contract')
    ROOT.mkdir(mode=0o700)
    raw = ROOT / 'raw'
    raw.mkdir(mode=0o700)
    (ROOT / 'repo').symlink_to(REPO, target_is_directory=True)
    for name, data in decoded.items():
        with (ROOT / name).open('xb') as stream:
            stream.write(data)
    TMP.mkdir(mode=0o700)
    after = [facts(directory) for directory in reversed((TMP, *TMP.parents))]
    if after[:-1] != before or int(after[-1]['mode_octal'], 8) != 0o700:
        raise ValueError('existing ancestry changed or new TMPDIR is not 0700')
    if len({p.stat().st_dev for p in (ROOT, BASE / 'target', BASE / 'cargo', TMP)}) != 1:
        raise ValueError('guard, target, registry and TMPDIR must use the same filesystem')
    write(raw / 'temp-ancestry-before-after.json', dict(
        schema='trnm-original-ancestor-contract-private-temp-setup-v1', head=HEAD,
        before=before, after=after, new_tmpdir=str(TMP), existing_permissions_unchanged=True,
        only_new_owned_directory_created=True, same_filesystem_as_target_and_guard=True))
    report = dict(schema='trnm-task-exclusive-source-setup-v1', head=HEAD, tree=TREE,
                  original_head=OLD_HEAD, started_ns=time.time_ns(), status='running', commands=[],
                  carrier_sha256=digest(CARRIER), files={name: digest(ROOT / name) for name in decoded},
                  original_runtime2_archive_sha256=digest(prior_archive))
    env = dict(os.environ, PATH='/home/qq/.cargo/bin:' + os.environ.get('PATH', ''),
        PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0',
        RUSTUP_AUTO_INSTALL='0', CARGO_HOME=str(BASE / 'cargo'), CARGO_TARGET_DIR=str(BASE / 'target'),
        CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', RUST_TEST_THREADS='1', TMPDIR=str(TMP), CI='true')

    def run(label, argv):
        start = time.time_ns()
        with (raw / (label + '.log')).open('xb') as stream:
            result = subprocess.run(argv, cwd=REPO, env=env, stdin=subprocess.DEVNULL,
                                    stdout=stream, stderr=subprocess.STDOUT, check=False)
        row = dict(label=label, argv=argv, cwd=str(REPO), exit_code=result.returncode,
                   started_ns=start, finished_ns=time.time_ns(), log_sha256=digest(raw / (label + '.log')))
        report['commands'].append(row)
        if result.returncode:
            raise ValueError('setup command failed: ' + label)
        return (raw / (label + '.log')).read_text()

    try:
        old = run('source-old-head-tree', ['git', 'rev-parse', 'HEAD', 'HEAD^{tree}']).splitlines()
        if old != [OLD_HEAD, '06e394f20b8f491c4ea1f91a357e2b6e8a4c0812']:
            raise ValueError('shared checkout moved from expected completed original source')
        branch = run('source-old-branch', ['git', 'symbolic-ref', '--short', 'HEAD']).strip()
        report['branch'] = branch
        if not branch or branch in ('main', 'master'):
            raise ValueError('allowed development branch required')
        if run('source-old-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all']).strip():
            raise ValueError('source checkout must be clean before exact fast-forward')
        run('source-old-preflight', ['bash', 'scripts/project-preflight.sh', '--audit'])
        run('source-old-identity', ['python3', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
            '--expected-head', OLD_HEAD, '--output', str(raw / 'source-old-identity.json')])
        run('bundle-verify', ['git', 'bundle', 'verify', str(ROOT / 'source.bundle')])
        advertised = run('bundle-heads', ['git', 'bundle', 'list-heads', str(ROOT / 'source.bundle')]).splitlines()
        if advertised != [HEAD + ' HEAD']:
            raise ValueError('source bundle must advertise only requested exact HEAD')
        run('bundle-fetch', ['git', 'fetch', str(ROOT / 'source.bundle'), 'HEAD'])
        run('source-ancestry', ['git', 'merge-base', '--is-ancestor', OLD_HEAD, HEAD])
        run('source-fast-forward', ['git', 'merge', '--ff-only', '--no-edit', HEAD])
        if run('source-new-head-tree', ['git', 'rev-parse', 'HEAD', 'HEAD^{tree}']).splitlines() != [HEAD, TREE]:
            raise ValueError('new exact head/tree mismatch')
        if run('source-new-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all']).strip():
            raise ValueError('new exact source is not clean')
        run('source-new-preflight', ['bash', 'scripts/project-preflight.sh', '--audit'])
        run('source-new-identity', ['python3', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
            '--expected-head', HEAD, '--output', str(raw / 'source-new-identity.json')])
        run('rustc-version', ['rustc', '+1.95.0', '--version'])
        run('cargo-version', ['cargo', '+1.95.0', '--version'])
        original_provider = BASE / 'qualification-114-0bca28ebf590/raw/provider-discovery.json'
        provider = json.loads(original_provider.read_bytes())
        keys = ('OPENSSL_DIR', 'OPENSSL_STATIC', 'OPENSSL_CONF', 'OPENSSL_MODULES',
                'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256', 'TRNM_PQ_OPENSSL_VERSION')
        if provider.get('reusable') is not True or set(provider['environment']) != set(keys):
            raise ValueError('original verified provider descriptor missing or changed')
        if digest(Path(provider['source_descriptor'])) != provider['descriptor_sha256']:
            raise ValueError('original provider environment file changed')
        env.update(provider['environment'])
        executable = Path(env['TRNM_PQ_OPENSSL'])
        if digest(executable) != env['TRNM_PQ_OPENSSL_SHA256'] or env['TRNM_PQ_OPENSSL_VERSION'] != '3.5.9':
            raise ValueError('exact original OpenSSL provider binary/version changed')
        version = run('provider-version', [str(executable), 'version'])
        if not version.startswith('OpenSSL 3.5.9 '):
            raise ValueError('actual provider version mismatch')
        libraries = []
        for name in ('libcrypto.a', 'libssl.a'):
            lib = Path(env['OPENSSL_DIR']) / 'lib' / name
            if not lib.is_file():
                raise ValueError('original static library missing: ' + name)
            libraries.append(dict(path=str(lib), bytes=lib.stat().st_size, sha256=digest(lib)))
        provider.update(actual_binary_sha256=digest(executable), static_libraries=libraries,
            reused_prior_descriptor_path=str(original_provider), reused_prior_descriptor_sha256=digest(original_provider),
            current_observation=True, source_head=HEAD, version=dict(returncode=0, stdout=version.strip(), stderr=''))
        write(raw / 'provider-discovery.json', provider)
        report.update(status='passed', TMPDIR=str(TMP), available_bytes=os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize,
                      environment={key: env.get(key) for key in (*keys, 'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'RUST_TEST_THREADS', 'TMPDIR')})
    except Exception as error:
        report.update(status='failed', error=str(error))
        raise
    finally:
        report['finished_ns'] = time.time_ns()
        write(raw / 'source-setup.json', report)
    print(json.dumps(dict(setup=report['status'], root=str(ROOT), source_head=HEAD, source_tree=TREE,
                         TMPDIR=str(TMP), available_bytes=report['available_bytes'])), flush=True)
    os.execve('/usr/bin/python3', ['/usr/bin/python3', str(ROOT / 'run_ai395_pipeline.py')], env)


if __name__ == '__main__':
    main()
