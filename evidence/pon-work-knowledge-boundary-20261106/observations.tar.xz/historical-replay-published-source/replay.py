"""Replay retained model/evaluation inputs without training or altering originals."""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time

PIN = '873d33aefd33828842c1f1420382b77c15396d74'
BUNDLE = '68baee758d23ac6563c8b36f6412ed5f5375c111506b122bc8c10ec2e0172937'
RELATIVE = 'evidence/pon-evaluation-bundle-v1/model'
SCOPE = ('Current Python code replays historical fixed bytes. No training, new data, '
         'new mining challenge, native Rust qualification, independent custody, '
         'prospective efficacy or production reward claim.')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
    with Path(path).open('xb') as stream:
        stream.write(raw)
    return sha(raw)


def git(repo, *arguments, **kwargs):
    return subprocess.check_output(['git', *arguments], cwd=repo, **kwargs)


def inventory(repo, paths):
    return {str(path.relative_to(repo)): {'bytes': len(raw), 'sha256': sha(raw)}
            for path in paths for raw in [path.read_bytes()]}


def pinned_sources(repo):
    listing = git(repo, 'ls-tree', '-r', '-z', PIN, '--', 'formal/pon-nakamoto-v1', 'config/pon')
    entries = []
    for item in listing.split(b'\0'):
        if not item:
            continue
        info, raw_path = item.split(b'\t', 1)
        _, kind, oid = info.split()
        path = raw_path.decode()
        if kind == b'blob' and (path.endswith('.py') or path.endswith('.json')):
            entries.append((path, oid.decode()))
    blobs = subprocess.run(['git', 'cat-file', '--batch'], cwd=repo,
        input=('\n'.join(oid for _, oid in entries) + '\n').encode(), capture_output=True, check=True).stdout
    offset = 0
    expected = {}
    for path, oid in entries:
        end = blobs.index(b'\n', offset)
        actual, kind, size = blobs[offset:end].split()
        assert actual.decode() == oid and kind == b'blob'
        offset = end + 1
        raw = blobs[offset:offset + int(size)]
        offset += int(size)
        assert blobs[offset:offset + 1] == b'\n'
        offset += 1
        expected[path] = {'bytes': len(raw), 'sha256': sha(raw)}
    assert offset == len(blobs)
    return [repo / path for path in expected], expected


def action(args):
    repo, out = args.repo.resolve(), args.out.resolve()
    sys.path.insert(0, str(repo / 'formal/pon-nakamoto-v1'))
    from contract_wire import H, canonical, unique
    from evaluation_bundle import (verify_bundle, verify_partition_set, read_bounded,
                                   MAX_BUNDLE_BYTES, MAX_TASK_BYTES)
    from experiments.settle_model import (verify_observation, ObservationInputs,
                                          _verify_model_work, WORK_BYTES, WORK_SCOPE, work)
    original = repo / RELATIVE
    if args.action == 'direct':
        observed, candidate = verify_observation(original, BUNDLE)
        print(json.dumps(dict(schema='historical-original-report-compatibility-v1',
                              result='PASS', source=PIN, bundle=BUNDLE,
                              candidate=H('artifact', canonical(candidate)).hex(), scope=SCOPE), sort_keys=True))
        return
    if args.action in ('copy', 'work'):
        bundle_raw = read_bounded(original / 'evaluation-bundle.json', MAX_BUNDLE_BYTES)
        bundle = verify_bundle(bundle_raw, BUNDLE)
        model_raw = read_bounded(original / 'model.json', 65536)
        assert H('artifact', model_raw).hex() == bundle['candidate_artifact']
        files = {'evaluation-bundle.json': bundle_raw, 'model.json': model_raw}
        partitions = {}
        for name in bundle['partitions']:
            raw = read_bounded(original / (name + '.json'), MAX_TASK_BYTES)
            files[name + '.json'] = raw
            partitions[name] = json.loads(raw, object_pairs_hook=unique)
        verify_partition_set(bundle, partitions)
        if args.action == 'copy':
            derived = out / 'derived-inputs'
            derived.mkdir()
            for name, raw in files.items():
                with (derived / name).open('xb') as stream:
                    stream.write(raw)
            result = dict(schema='historical-fixed-input-copy-v1', source=PIN, bundle=BUNDLE,
                          copied_files={name: {'sha256': sha(raw), 'bytes': len(raw)} for name, raw in files.items()},
                          original_model=RELATIVE, partitions={name: len(rows) for name, rows in partitions.items()},
                          identical_model_and_partitions=True, scope=SCOPE)
        else:
            proof = read_bounded(original / 'model-work.bin', WORK_BYTES)
            inputs = ObservationInputs(tuple(sorted(files.items())))
            a, b = _verify_model_work(inputs, proof)
            challenge = H('real-model-work', H('artifact', model_raw),
                          H('tasks', canonical(partitions['consumer']))).hex()
            original_report = json.loads(read_bounded(original / 'report.json', MAX_TASK_BYTES), object_pairs_hook=unique)
            result = dict(schema='historical-model-work-binding-replay-v1', result='PASS', source=PIN,
                          bundle=BUNDLE, candidate=bundle['candidate_artifact'], proof_sha256=sha(proof),
                          proof_bytes=len(proof), task=work.task_id(a, b).hex(), challenge=challenge,
                          matches_original_reported_task=work.task_id(a, b).hex() == original_report['useful_work']['task_commitment'],
                          matches_original_reported_challenge=challenge == original_report['useful_work']['challenge'],
                          actual_verifier='current Python scalar W1 plus signed integer bridge',
                          mapping=WORK_SCOPE, complete_committed_partition_counts={name: len(rows) for name, rows in partitions.items()},
                          fresh_consensus_work=False, new_training=False, model_efficacy_accepted=False, scope=SCOPE)
        print(json.dumps(result, sort_keys=True, indent=2))
        return
    if args.action == 'aggregate':
        derived = out / 'derived-inputs'
        bundle = verify_bundle(read_bounded(derived / 'evaluation-bundle.json', MAX_BUNDLE_BYTES), BUNDLE)
        model_raw = read_bounded(derived / 'model.json', 65536)
        results = {name: json.loads(read_bounded(derived / (name + '-result.json'), MAX_TASK_BYTES), object_pairs_hook=unique)
                   for name in ('evaluation_a', 'evaluation_b')}
        report = dict(schema='pon-historical-fixed-model-evaluation-replay-v1',
                      source=bundle['source_commit'],
                      models=dict(artifact_hash=H('artifact', model_raw).hex(), bytes=len(model_raw)),
                      evaluation_bundle=BUNDLE, results=results)
        digest = save(derived / 'report.json', report)
        whole = min(value['whole_gain']['score'] for value in results.values())
        marginal = [min(value['marginal'][index]['score'] for value in results.values()) for index in range(3)]
        print(json.dumps(dict(schema='historical-replay-report-construction-v1', source=PIN,
                              new_report_schema=report['schema'], report_sha256=digest,
                              historical_corpus_source=report['source'], bundle=BUNDLE,
                              source_model=report['models']['artifact_hash'], min_whole_score=whole,
                              min_marginal_scores=marginal,
                              training_performed=False, original_training_claims_copied=False,
                              scope=SCOPE), sort_keys=True, indent=2))
        # The requested replay is no-update. An unexpected new positive verdict
        # must be investigated rather than silently launching a mining campaign.
        if whole > 0 and any(value > 0 for value in marginal):
            raise SystemExit('unexpected positive gate: retain current observations; no mining launched')
        return
    raise ValueError('unknown action')


def driver(args):
    repo, out = args.repo.resolve(), args.out.resolve()
    assert git(repo, 'rev-parse', 'HEAD', text=True).strip() == PIN
    source_paths, expected_sources = pinned_sources(repo)
    assert inventory(repo, source_paths) == expected_sources
    original = repo / RELATIVE
    original_paths = sorted(path for path in original.iterdir() if path.is_file())
    original_paths += [original.parent / 'qualification.json', original.parent / 'manifest.json']
    initial_originals = inventory(repo, original_paths)
    qualification = json.loads((original.parent / 'qualification.json').read_bytes())
    assert qualification['evaluation_bundle'] == BUNDLE
    original_report = json.loads((original / 'report.json').read_bytes())
    original_bundle = json.loads((original / 'evaluation-bundle.json').read_bytes())
    env_overrides = {'PYTHONDONTWRITEBYTECODE': '1', 'OPENBLAS_NUM_THREADS': '1', 'OMP_NUM_THREADS': '1',
                     'TRNM_NATIVE_WORK': '', 'TRNM_NATIVE_EXECUTOR': '', 'TRNM_NATIVE_SESSION': '',
                     'TRNM_PON_EVALUATION_POLICY': 'legacy-first-two-v3'}
    environment = dict(os.environ, **env_overrides)
    plan = dict(schema='historical-model-replay-plan-v1', execution_source=PIN,
                observed_head=git(repo, 'rev-parse', 'HEAD', text=True).strip(),
                original_qualification_source=qualification['source_commit'],
                original_corpus_source=original_bundle['source_commit'], original_bundle=BUNDLE,
                original_model=original_bundle['candidate_artifact'],
                original_files=initial_originals, source_files=expected_sources,
                script_sha256=sha(Path(__file__).read_bytes()), environment_overrides=env_overrides,
                python=dict(executable=sys.executable, version=sys.version, binary_sha256=sha(Path(sys.executable).resolve().read_bytes())),
                package_versions={name: importlib.metadata.version(name) for name in ('numpy', 'cryptography')},
                scope=SCOPE)
    save(out / 'plan.json', plan)
    logs = out / 'steps'
    logs.mkdir()
    steps = []
    this = [sys.executable, str(Path(__file__).resolve()), '--repo', str(repo), '--out', str(out)]

    def run(name, command, *, expected_exit=0):
        before_source = inventory(repo, source_paths)
        before_original = inventory(repo, original_paths)
        assert before_source == expected_sources and before_original == initial_originals
        started = time.monotonic_ns()
        process = subprocess.run(command, cwd=repo, env=environment, capture_output=True, timeout=120)
        elapsed = time.monotonic_ns() - started
        after_source = inventory(repo, source_paths)
        after_original = inventory(repo, original_paths)
        label = f'{len(steps):02d}-{name}'
        (logs / (label + '.stdout')).write_bytes(process.stdout)
        (logs / (label + '.stderr')).write_bytes(process.stderr)
        record = dict(schema='historical-replay-step-v1', name=name, command=command, cwd=str(repo),
                      execution_source=PIN, observed_head_after=git(repo, 'rev-parse', 'HEAD', text=True).strip(),
                      environment_overrides=env_overrides, exit_code=process.returncode,
                      expected_exit=expected_exit, elapsed_wall_ns=elapsed,
                      source_before=before_source, source_after=after_source,
                      original_before=before_original, original_after=after_original,
                      exact_pinned_source_before_and_after=before_source == after_source == expected_sources,
                      original_inputs_unchanged=before_original == after_original == initial_originals,
                      stdout_sha256=sha(process.stdout), stderr_sha256=sha(process.stderr), scope=SCOPE)
        save(logs / (label + '.json'), record)
        steps.append(record)
        print(json.dumps(dict(step=name, exit_code=process.returncode,
                              source_unchanged=record['exact_pinned_source_before_and_after'],
                              originals_unchanged=record['original_inputs_unchanged']), sort_keys=True), flush=True)
        assert record['exact_pinned_source_before_and_after'] and record['original_inputs_unchanged']
        if expected_exit is not None and process.returncode != expected_exit:
            raise RuntimeError('unexpected step exit: ' + name)
        return process

    run('preflight', ['bash', 'scripts/project-preflight.sh'])
    direct = run('original-report-compatibility', this + ['--action', 'direct'], expected_exit=None)
    if direct.returncode == 0:
        settlement_input = original
        compatibility = 'PASS'
    else:
        compatibility = 'FAIL_RETAINED_ORIGINAL_REPORT'
        missing_claim = any('value_claim' not in original_report['results'][name]
                            for name in ('evaluation_a', 'evaluation_b'))
        assert missing_claim and b'OBSERVED_EVALUATION_MISMATCH' in direct.stderr
        run('copy-fixed-inputs', this + ['--action', 'copy'])
        derived = out / 'derived-inputs'
        for partition in ('evaluation_a', 'evaluation_b'):
            run(partition, [sys.executable, str(repo / 'formal/pon-nakamoto-v1/experiments/model_loop.py'),
                '--mode', 'evaluate', '--tasks', str(derived / (partition + '.json')),
                '--model', str(derived / 'model.json'), '--evaluation-bundle', str(derived / 'evaluation-bundle.json'),
                '--bundle-hash', BUNDLE, '--partition', partition, '--calibration', str(derived / 'calibration.json'),
                '--out', str(derived / (partition + '-result.json'))])
        run('build-current-replay-report', this + ['--action', 'aggregate'])
        settlement_input = derived
    run('current-settlement-no-update', [sys.executable, str(repo / 'formal/pon-nakamoto-v1/experiments/settle_model.py'),
        '--input', str(settlement_input), '--out', str(out / 'settlement'), '--bundle-hash', BUNDLE])
    work_result = run('original-model-work-binding', this + ['--action', 'work'])
    work_report = json.loads(work_result.stdout)
    settlement = json.loads((out / 'settlement/report.json').read_bytes())
    assert settlement['outcome'] == 'not_adopted' and settlement['model_reward'] == 0
    assert not (out / 'settlement/chain').exists()
    assert work_report['matches_original_reported_task'] and work_report['matches_original_reported_challenge']
    aggregate_report = json.loads((settlement_input / 'report.json').read_bytes())
    evaluations = {}
    for name in ('evaluation_a', 'evaluation_b'):
        current = aggregate_report['results'][name]
        previous = original_report['results'][name]
        evaluations[name] = dict(predictions_equal_original=current['predictions'] == previous['predictions'],
                                 whole_score=current['whole_gain']['score'],
                                 marginal_scores=[row['score'] for row in current['marginal']],
                                 old_whole_score=previous['whole_gain']['score'],
                                 old_marginal_scores=[row['score'] for row in previous['marginal']],
                                 candidate_value=current.get('value_claim', {}).get('candidate_value'),
                                 reference_value=current.get('value_claim', {}).get('reference_value'),
                                 empirical_gap=current.get('value_claim', {}).get('optimality_bound', {}).get('gap'))
    summary = dict(schema='historical-model-replay-summary-v1', execution_source=PIN,
                   original_qualification_source=qualification['source_commit'],
                   historical_corpus_source=original_bundle['source_commit'], bundle=BUNDLE,
                   original_model=original_bundle['candidate_artifact'],
                   original_report_sha256=sha((original / 'report.json').read_bytes()),
                   original_report_compatibility=compatibility, original_report_exit=direct.returncode,
                   original_report_failure_preserved=True,
                   replay_report_schema=aggregate_report['schema'],
                   replay_report_sha256=sha((settlement_input / 'report.json').read_bytes()),
                   evaluation_observations=evaluations, settlement=settlement,
                   chain_created=False, original_model_work=work_report,
                   exact_pinned_source_before_and_after=all(s['exact_pinned_source_before_and_after'] for s in steps),
                   original_inputs_unchanged=all(s['original_inputs_unchanged'] for s in steps),
                   step_exits={s['name']: s['exit_code'] for s in steps}, scope=SCOPE)
    save(out / 'summary.json', summary)
    output_files = sorted(path for path in out.rglob('*') if path.is_file())
    save(out / 'manifest.json', dict(schema='historical-replay-output-manifest-v1',
        files={str(path.relative_to(out)): {'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
               for path in output_files}, scope=SCOPE))
    print(json.dumps(dict(result='REPLAY_COMPLETE_ORIGINAL_COMPATIBILITY_FAILURE_RETAINED',
                          summary_sha256=sha((out / 'summary.json').read_bytes()),
                          manifest_sha256=sha((out / 'manifest.json').read_bytes()),
                          original_report_compatibility=compatibility, outcome=settlement['outcome'],
                          model_reward=settlement['model_reward'], old_work_binding=work_report['result']), sort_keys=True), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--action', choices=['driver', 'direct', 'copy', 'aggregate', 'work'], default='driver')
    args = parser.parse_args()
    driver(args) if args.action == 'driver' else action(args)
