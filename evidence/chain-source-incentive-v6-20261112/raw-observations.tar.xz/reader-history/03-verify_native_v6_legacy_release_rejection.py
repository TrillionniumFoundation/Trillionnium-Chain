#!/usr/bin/env python3
"""Reject the legacy release domain using a retained real v6 receipt.

The only input mutation is in-memory: original's actual tag8 release bytes and
its matching case.release metadata. This does not sign a transaction, submit
a transaction, execute a payment, or change the retained native log.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import pathlib
import sys


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def import_reader(path):
    spec = importlib.util.spec_from_file_location("independent_v6_reader", path)
    require(spec is not None and spec.loader is not None, "reader import unavailable")
    reader = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reader)
    return reader


def regression(args, report):
    raw = args.log.read_bytes()
    report["native_log_sha256"] = hashlib.sha256(raw).hexdigest()
    require(report["native_log_sha256"] == args.expected_log_sha256,
            "retained native log hash mismatch")
    report["reader_sha512"] = hashlib.sha512(args.reader.read_bytes()).hexdigest()
    reader = import_reader(args.reader)
    reference_path = args.repo / "scripts/experiments/source_incentive_reference_v6.py"
    reference = reader.load_reference(reference_path)
    config_path = args.repo / "config/pon/model-evidence-v3.json"
    policy_path = args.repo / "config/pon/model-composition-v6.json"
    config = reader.parse_json(config_path.read_bytes())
    policy = reader.parse_json(policy_path.read_bytes())
    native = reader.extract_native_record(raw)
    baseline = reader.audit_all(native, config, policy, reference)
    require(baseline["result"] == "PASS_FINITE_NATIVE_RECEIPT_RECOMPUTATION",
            "unchanged actual receipt did not pass")
    report["unchanged_receipt_result"] = baseline["result"]
    report["native_suite_summary"] = [
        line for line in raw.decode("utf-8").splitlines() if "test result:" in line
    ]
    changed = copy.deepcopy(native)
    case = changed["original"]
    bundle = case["bundle_contribution"]
    matches = []
    for block_index, block in enumerate(case["signed_commands"]):
        for tx_index, encoded in enumerate(block["transactions"]):
            envelope = reader.decode_envelope(bytes.fromhex(encoded))
            if envelope["tag"] == 8:
                admission = reader.decode_admission(envelope["payload"])
                if admission["bundle"] == bundle:
                    matches.append((block_index, tx_index, envelope, admission))
    require(len(matches) == 1, "expected one actual original bundle admission")
    block_index, tx_index, envelope, admission = matches[0]
    payload = envelope["payload"]
    parts = [payload[32:64], payload[64:96], payload[96:104],
             payload[104:136], payload[136:144]]
    current = reader.pon_hash("source-release-v6", parts)
    legacy = reader.pon_hash("release", parts)
    require(payload[:32] == current and current != legacy,
            "actual release must match the fresh v6 domain")
    require(case.get("release") == current.hex(),
            "actual case.release does not match the signed tag8 release")
    old_encoded = case["signed_commands"][block_index]["transactions"][tx_index]
    old_tx = bytes.fromhex(old_encoded)
    new_tx = bytearray(old_tx)
    new_tx[95:127] = legacy
    require(bytes(new_tx[:95]) == old_tx[:95]
            and bytes(new_tx[127:]) == old_tx[127:],
            "mutation changed a field other than the tag8 release")
    case["signed_commands"][block_index]["transactions"][tx_index] = new_tx.hex()
    case["release"] = legacy.hex()
    # Undo precisely the two allowed changes and require byte-for-byte JSON
    # equivalence of the complete four-variant input.
    restored = copy.deepcopy(changed)
    restored["original"]["release"] = current.hex()
    restored["original"]["signed_commands"][block_index]["transactions"][tx_index] = old_encoded
    require(restored == native, "mutation changed unrelated retained evidence")
    report.update({
        "actual_admission_height": case["signed_commands"][block_index]["height"],
        "actual_transaction_index": tx_index,
        "original_v6_release": current.hex(),
        "mutated_legacy_release": legacy.hex(),
        "original_transaction_id": envelope["tx_id"],
        "mutated_transaction_id": reader.decode_envelope(bytes(new_tx))["tx_id"],
        "case_release_matches_mutated_tag8": True,
        "all_other_retained_fields_unchanged": True,
        "original_signature_bytes_retained_but_not_verified": True,
        "fresh_domain": "source-release-v6",
        "rejected_legacy_domain": "release",
    })
    try:
        reader.audit_all(changed, config, policy, reference)
    except reader.AuditFailure as error:
        report["rejection"] = str(error)
        require(str(error) == "signed release ID mismatch",
                "mutation failed at an unexpected earlier check: " + str(error))
    else:
        raise ValueError("legacy release mutation was incorrectly accepted")
    require(args.log.read_bytes() == raw, "retained native log changed during test")
    report["retained_log_unchanged"] = True
    report["result"] = "PASS_EXACT_LEGACY_RELEASE_REJECTION"


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=pathlib.Path, required=True)
    parser.add_argument("--reader", type=pathlib.Path, required=True)
    parser.add_argument("--log", type=pathlib.Path, required=True)
    parser.add_argument("--expected-log-sha256", required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    args = parser.parse_args(argv)
    report = {
        "schema": "trnm.native-v6-legacy-release-domain-negative.v1",
        "test_script_sha512": hashlib.sha512(pathlib.Path(__file__).read_bytes()).hexdigest(),
        "result": "FAIL_LEGACY_RELEASE_REGRESSION",
        "native_payment_executed": False,
        "market_test": False,
        "signature_verification_performed": False,
        "overall_native_suite_pass_claimed": False,
        "scope": "in-memory mutation of actual retained receipt; no native execution",
    }
    code = 0
    try:
        regression(args, report)
    except (ValueError, KeyError, IndexError, TypeError, OSError) as error:
        report["error"] = str(error)
        code = 1
    encoded = json.dumps(report, sort_keys=True, indent=2, allow_nan=False) + "\n"
    with args.output.open("x", encoding="utf-8") as handle:
        handle.write(encoded)
    print(encoded, end="")
    return code


if __name__ == "__main__":
    raise SystemExit(main())
