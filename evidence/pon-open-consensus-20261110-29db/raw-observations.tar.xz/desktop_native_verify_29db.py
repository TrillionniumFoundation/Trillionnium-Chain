#!/usr/bin/env python3
"""Isolated desktop checkout and exact-source default-profile verification."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

WORKSPACE = Path('/home/qian-qi/workspace')
CACHE = WORKSPACE / 'chain-seven-gates-20261108-3a20/source-exact'
ROOT = WORKSPACE / 'pon-native-check-0c589e22-29db'
TARGET = WORKSPACE / 'pon-native-check-0c589e22-29db-target'
RECORDS = WORKSPACE / 'pon-native-check-0c589e22-29db-records'
BUNDLE = WORKSPACE / 'pon-source-0c589e22-29db.bundle'
BUNDLE_SHA256 = '595e6aac64225a07d6fac23b868eeb2734ed03e2d10b1b46f662e344f472eeba'
BASE = '62378d28415ead28b5f99ec6ea6033fde93e3215'
HEAD = '0c589e2212f7feeaac4ec12d076d27ab139bc52f'
TREE = '831caac4edbae18921b3269a85faef456d78bbbe'
BRANCH = 'fix/chain-pon-verify-20261110-29db'
BUNDLE_REF = 'refs/heads/fix/chain-pon-open-consensus-repair-20261110-29db'
ORIGIN = 'https://github.com/TrillionniumFoundation/Trillionnium-Chain.git'
ORIGINS = {ORIGIN, ORIGIN[:-4], 'git@github.com:TrillionniumFoundation/Trillionnium-Chain.git'}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def emit(kind, **facts):
    print(json.dumps({'kind': kind, **facts}, sort_keys=True), flush=True)


def environment():
    env = {key: value for key, value in os.environ.items() if not key.startswith('GIT_')}
    disallowed = [key for key, value in env.items()
                  if value and (key.startswith('CARGO_PROFILE_') or key in (
                      'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC',
                      'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'))]
    require(not disallowed, 'unexpected compiler/profile environment keys: ' + ','.join(disallowed))
    env.update(PATH='/home/qian-qi/.cargo/bin:' + env.get('PATH', '/usr/bin:/bin'),
               CARGO_HOME='/home/qian-qi/.cargo', RUSTUP_HOME='/home/qian-qi/.rustup',
               CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', RUST_TEST_THREADS='1',
               CARGO_TARGET_DIR=str(TARGET), PYTHONDONTWRITEBYTECODE='1',
               GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull,
               GIT_CONFIG_SYSTEM=os.devnull, GIT_TERMINAL_PROMPT='0',
               GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0')
    return env


ENV = environment()
GIT = shutil.which('git', path=ENV['PATH'])
require(GIT is not None, 'git executable unavailable in the existing host PATH')


def git_capture(directory, *args, timeout=90):
    return subprocess.run([GIT, '--no-replace-objects', '-C', str(directory), *args],
                          env=ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          text=True, timeout=timeout, check=False)


def step(label, command, *, cwd=WORKSPACE, timeout=1500, required=True):
    log = RECORDS / (label + '.setup.log')
    receipt = RECORDS / (label + '.setup.json')
    record = {'label': label, 'argv': list(command), 'cwd': str(cwd),
              'started_unix_ns': time.time_ns(), 'status': 'running'}
    with receipt.open('x') as stream:
        json.dump(record, stream)
    emit('step-start', label=label)
    try:
        with log.open('xb') as stream:
            result = subprocess.run(command, cwd=cwd, env=ENV, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=timeout, check=False)
        record.update(exit_code=result.returncode,
                      status='succeeded' if result.returncode == 0 else 'failed')
    except Exception as error:
        record.update(exit_code=None, status='failed', error=repr(error))
    finally:
        record['finished_unix_ns'] = time.time_ns()
        if log.exists():
            with log.open('rb') as stream:
                record['log_sha256'] = hashlib.file_digest(stream, 'sha256').hexdigest()
            record['log_bytes'] = log.stat().st_size
        receipt.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    emit('step-result', label=label, status=record['status'], exit_code=record['exit_code'])
    if required:
        require(record['status'] == 'succeeded', 'step failed: ' + label)
    return record


def raw_guard(label):
    step(label, ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py',
                 '--kind', 'head', '--expected-head', HEAD,
                 '--output', str(RECORDS / (label + '.source.json'))], cwd=ROOT)


def setup():
    require(not ROOT.exists() and not ROOT.is_symlink(), 'new verification checkout already exists')
    require(not TARGET.exists() and not TARGET.is_symlink(), 'new target directory already exists')
    require(not RECORDS.exists() and not RECORDS.is_symlink(), 'new records directory already exists')
    require(BUNDLE.is_file() and not BUNDLE.is_symlink(), 'staged bundle missing or symlinked')
    bundle_bytes = BUNDLE.read_bytes()
    require(len(bundle_bytes) == 25241 and hashlib.sha256(bundle_bytes).hexdigest() == BUNDLE_SHA256,
            'staged bundle does not match the reviewed exact delta')
    require((CACHE / '.git').is_dir(), 'selected existing cache has no Git directory')
    origin = git_capture(CACHE, 'remote', 'get-url', 'origin')
    require(origin.returncode == 0 and origin.stdout.strip() in ORIGINS,
            'selected cache origin is not the official repository')
    cache_head = git_capture(CACHE, 'rev-parse', 'HEAD')
    require(cache_head.returncode == 0 and re.fullmatch('[a-f0-9]{40}', cache_head.stdout.strip()),
            'selected cache HEAD is unavailable')
    present = git_capture(CACHE, 'cat-file', '-e', BASE + '^{commit}')
    require(present.returncode in (0, 1, 128), 'unexpected cache object inspection result')
    RECORDS.mkdir()
    identity = {'cache': str(CACHE), 'cache_head': cache_head.stdout.strip(),
                'cache_origin_is_official': True, 'base_object_present_in_cache': present.returncode == 0,
                'source': str(ROOT), 'target': str(TARGET), 'records': str(RECORDS),
                'bundle': str(BUNDLE), 'bundle_sha256': BUNDLE_SHA256,
                'expected_head': HEAD, 'expected_tree': TREE, 'profile_override': None,
                'cargo_build_jobs': 2, 'cargo_incremental': 0, 'rust_test_threads': 1,
                'git_executable': GIT,
                'selected_environment': {key: ENV.get(key) for key in (
                    'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_TARGET_DIR',
                    'RUST_TEST_THREADS', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS',
                    'RUSTC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'RUSTUP_TOOLCHAIN')},
                'cargo_profile_environment_keys': sorted(key for key in ENV if key.startswith('CARGO_PROFILE_'))}
    (RECORDS / 'setup-identity.json').write_text(json.dumps(identity, indent=2, sort_keys=True) + '\n')
    emit('cache-inspected', **identity)
    step('clone-shared-no-checkout', [GIT, 'clone', '--shared', '--no-checkout', '--template=',
                                     str(CACHE), str(ROOT)])
    step('set-new-origin', [GIT, '-C', str(ROOT), 'remote', 'set-url', 'origin', ORIGIN])
    present = git_capture(ROOT, 'cat-file', '-e', BASE + '^{commit}')
    if present.returncode != 0:
        step('fetch-required-base', [GIT, '-C', str(ROOT), 'fetch', '--no-tags',
                                    '--no-write-fetch-head', 'origin', BASE])
    step('verify-delta-bundle', [GIT, '-C', str(ROOT), 'bundle', 'verify', str(BUNDLE)])
    step('import-reviewed-delta', [GIT, '-C', str(ROOT), 'fetch', '--no-tags', str(BUNDLE),
                                  BUNDLE_REF + ':refs/heads/' + BRANCH])
    actual = git_capture(ROOT, 'rev-parse', 'refs/heads/' + BRANCH)
    require(actual.returncode == 0 and actual.stdout.strip() == HEAD, 'imported branch head differs')
    actual = git_capture(ROOT, 'rev-parse', HEAD + '^{tree}')
    require(actual.returncode == 0 and actual.stdout.strip() == TREE, 'imported tree differs')
    step('checkout-reviewed-source', [GIT, '-C', str(ROOT), 'switch', BRANCH])
    step('project-preflight', ['/bin/bash', 'scripts/project-preflight.sh'], cwd=ROOT)
    step('host-rustc-version', ['/home/qian-qi/.cargo/bin/rustc', '--version'], cwd=ROOT)
    step('host-cargo-version', ['/home/qian-qi/.cargo/bin/cargo', '--version'], cwd=ROOT)
    raw_guard('prepared-source-guard')
    (RECORDS / 'SETUP_READY.json').write_text(json.dumps(identity, indent=2, sort_keys=True) + '\n')
    emit('checkout-prepared', source=str(ROOT), head=HEAD, tree=TREE, records=str(RECORDS))


def recorded(label, command):
    require(not (RECORDS / (label + '.json')).exists(), 'command label already recorded: ' + label)
    invocation = ['/usr/bin/python3', '-B', 'scripts/ci/record_pq_native_command.py',
                  '--kind', 'head', '--candidate', HEAD, '--tested', HEAD,
                  '--label', label, '--output', str(RECORDS), '--', '/usr/bin/timeout', '1200', *command]
    emit('validation-start', label=label, argv=command)
    with (RECORDS / (label + '.driver.log')).open('xb') as stream:
        result = subprocess.run(invocation, cwd=ROOT, env=ENV, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=1500, check=False)
    receipt = json.loads((RECORDS / (label + '.json')).read_text())
    emit('validation-result', label=label, status=receipt['status'], exit_code=receipt['exit_code'])
    require(receipt['status'] in ('command_succeeded', 'command_failed'),
            'source guard or command recorder failed: ' + label)
    require(result.returncode == (receipt['exit_code'] if receipt['exit_code'] >= 0
                                  else 128 - receipt['exit_code']), 'recorder return code mismatch')
    return receipt


def offline_dependency_failure(receipt):
    if receipt['exit_code'] == 0:
        return False
    text = (RECORDS / receipt['log_file']).read_text(errors='replace').lower()
    return '--offline' in text and any(part in text for part in (
        'no matching package', 'failed to download', 'attempting to make an http request',
        'failed to get', 'failed to resolve'))


def validate():
    ready = json.loads((RECORDS / 'SETUP_READY.json').read_text())
    require(ready['expected_head'] == HEAD and ready['source'] == str(ROOT), 'setup identity differs')
    require(not (RECORDS / 'validation-summary.json').exists(), 'validation was already attempted')
    manifest = ['--offline', '--locked', '--manifest-path', 'trillionnium/Cargo.toml']
    test_base = ['cargo', 'test', *manifest, '-p', 'trnm-pon-node']
    commands = [
        ('preflight', ['/bin/bash', 'scripts/project-preflight.sh']),
        ('workspace-metadata', ['cargo', 'metadata', *manifest, '--format-version', '1', '--no-deps']),
        ('fuzz-metadata', ['cargo', 'metadata', '--offline', '--locked', '--manifest-path',
                           'tests/fuzz/Cargo.toml', '--format-version', '1', '--no-deps']),
        ('workspace-format', ['cargo', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml',
                              '--all', '--', '--check']),
        ('native-consensus-vectors', [*test_base, '--lib', 'consensus::tests::', '--', '--test-threads=1']),
        ('native-history-import', [*test_base, '--lib', 'ingress::history_import', '--', '--test-threads=1']),
        ('native-public-v3', [*test_base, '--lib', 'ingress::public_v3::tests::', '--', '--test-threads=1']),
        ('native-journal-suites', [*test_base, '--test', 'native_owner_journal', '--test',
                                   'native_risk_ledger', '--', '--test-threads=1']),
        ('strict-workspace-clippy', ['cargo', 'clippy', *manifest, '--workspace', '--all-targets',
                                     '--all-features', '--', '-D', 'warnings']),
    ]
    summary = {'schema': 'pon-desktop-exact-default-profile-v1', 'status': 'running',
               'head': HEAD, 'tree': TREE, 'profile_override': None, 'commands': [],
               'bootstrap_attempted': False}
    summary_path = RECORDS / 'validation-summary.json'
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    try:
        for label, command in commands:
            receipt = recorded(label, command)
            summary['commands'].append({'label': label, 'status': receipt['status'],
                                        'exit_code': receipt['exit_code']})
            if offline_dependency_failure(receipt):
                if not summary['bootstrap_attempted']:
                    summary['bootstrap_attempted'] = True
                    for suffix, cargo_manifest in [('workspace', 'trillionnium/Cargo.toml'),
                                                   ('fuzz', 'tests/fuzz/Cargo.toml')]:
                        fetched = recorded('bootstrap-fetch-' + suffix,
                                           ['cargo', 'fetch', '--locked', '--manifest-path', cargo_manifest])
                        summary['commands'].append({'label': 'bootstrap-fetch-' + suffix,
                                                    'status': fetched['status'], 'exit_code': fetched['exit_code']})
                receipt = recorded(label + '-retry-after-fetch', command)
                summary['commands'].append({'label': label + '-retry-after-fetch',
                                            'status': receipt['status'], 'exit_code': receipt['exit_code']})
            if label.startswith('native-') and receipt['exit_code'] == 0:
                log = (RECORDS / receipt['log_file']).read_text(errors='replace')
                counts = [int(value) for value in re.findall(r'test result: ok\. (\d+) passed;', log)]
                require(counts and all(count > 0 for count in counts),
                        'native command did not visibly execute a nonempty test suite: ' + label)
                summary['commands'][-1]['observed_passed_tests'] = counts
            summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
            if label == 'preflight':
                require(receipt['exit_code'] == 0, 'project preflight failed')
        raw_guard('completed-source-guard')
        summary['status'] = ('completed_with_failures' if any(row['exit_code'] != 0
                              for row in summary['commands']) else 'completed_successfully')
    except Exception as error:
        summary.update(status='incomplete', error=repr(error))
        raise
    finally:
        summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    emit('validation-finished', status=summary['status'], records=str(RECORDS))
    return 0 if summary['status'] == 'completed_successfully' else 1


if __name__ == '__main__':
    try:
        require(len(sys.argv) == 2 and sys.argv[1] in ('setup', 'validate'), 'expected setup or validate')
        if sys.argv[1] == 'setup':
            setup()
            code = 0
        else:
            code = validate()
    except Exception as error:
        emit('driver-failure', error=repr(error))
        raise
    raise SystemExit(code)
