
import json,os,pathlib,subprocess,shutil,sys,hashlib,time,signal,re
sha='ae657e262278ae4a058220f66a6a0495721eb9ad'
seed=pathlib.Path('/tmp/chain-throughput-0b5320')
root=pathlib.Path('/tmp/chain-throughput-before-ae-0b5320')
out=pathlib.Path('/dev/shm/chain-throughput-0b5320/before-ae-v1')
target=pathlib.Path('/dev/shm/chain-throughput-0b5320/before-target')
out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR=str(target),CARGO_TERM_COLOR='never',PYTHONDONTWRITEBYTECODE='1')
summary={'source':sha,'expected_tree':'def5ae894d06b787222b6b2b2b2d97bf8be59366','scope':'exact old pool reconciliation production source plus unchanged two native test controls; component negative control only','steps':[],'tests':[],'success':False}
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save():(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
def run(name,argv,seconds,cwd=None):
 so=out/(name+'.stdout.log');se=out/(name+'.stderr.log');start=time.monotonic();timed=False
 print(json.dumps({'stage':name,'state':'starting'}),flush=True)
 with so.open('wb') as o,se.open('wb') as e:
  p=subprocess.Popen(argv,cwd=cwd or root,env=env,stdout=o,stderr=e,start_new_session=True)
  try:rc=p.wait(timeout=seconds)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGTERM)
   try:rc=p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
 row={'stage':name,'argv':argv,'exit':rc,'timed_out':timed,'elapsed_seconds':time.monotonic()-start,'stdout':so.name,'stderr':se.name,'stdout_sha256':digest(so),'stderr_sha256':digest(se)}
 summary['steps'].append(row);save();print(json.dumps(row),flush=True)
 return row,so,se
def req(name,argv,seconds,cwd=None):
 row,so,se=run(name,argv,seconds,cwd)
 if row['exit'] or row['timed_out']:raise RuntimeError(name+': '+se.read_text(errors='replace')[-1600:])
 return so
def source(name):return req(name,['/usr/bin/python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',sha,'--output',str(out/(name+'.json'))],180)
def artifacts(log,name):
 result=[]
 for line in log.read_text().splitlines():
  try:r=json.loads(line)
  except ValueError:continue
  if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('target',{}).get('name')==name:result.append(r)
 if len(result)!=1:raise RuntimeError('EXACT_BINARY_REQUIRED '+name)
 return result[0]
cargo=['/home/qian-qi/.cargo/bin/cargo','+1.95.0']
try:
 mem=dict((l.split(':')[0],int(l.split()[1])*1024) for l in pathlib.Path('/proc/meminfo').read_text().splitlines() if len(l.split())>=3)
 summary['capacity_before']={'tmpfs_free':shutil.disk_usage('/dev/shm').free,'root_free':shutil.disk_usage('/').free,'memory_available':mem['MemAvailable']};save()
 if summary['capacity_before']['tmpfs_free']<24*1024**3 or mem['MemAvailable']<40*1024**3:raise RuntimeError('INSUFFICIENT_CONCURRENT_CAPACITY')
 req('preflight-seed',['/usr/bin/bash','scripts/project-preflight.sh'],90,seed)
 if root.exists() or target.exists():raise RuntimeError('BEFORE_PATH_EXISTS')
 req('checkout',['/usr/bin/git','worktree','add','-b','fix/chain-throughput-before-ae-20261110-0b5320',str(root),sha],180,seed)
 req('preflight',['/usr/bin/bash','scripts/project-preflight.sh'],90)
 source('source-before')
 req('rustc',['/home/qian-qi/.cargo/bin/rustc','+1.95.0','--version','--verbose'],30)
 req('cargo',cargo+['--version'],30)
 flags={k:v for k,v in env.items() if k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS') or k.startswith('CARGO_PROFILE_')}
 summary['build_context']={'cargo_target_dir':str(target),'jobs':2,'incremental':0,'profile_overrides':flags,'lock_sha256':digest(root/'trillionnium/Cargo.lock'),'manifest_sha256':digest(root/'trillionnium/Cargo.toml')};save()
 if any(flags.values()):raise RuntimeError('UNEXPECTED_PROFILE_FLAGS')
 req('metadata',cargo+['metadata','--locked','--format-version','1','--manifest-path','trillionnium/Cargo.toml'],300)
 testpath='trillionnium/crates/trnm-pon-node/src/pool_reconcile_control_tests.rs'
 blob=subprocess.check_output(['/usr/bin/git','rev-parse',sha+':'+testpath],cwd=root,text=True).strip()
 if blob!='2a41c8cf8e1cd781a604f6fcaf43ade17c42e2cc':raise RuntimeError('TEST_BLOB_MISMATCH')
 summary['test_input']={'path':testpath,'git_blob':blob,'sha256':digest(root/testpath),'fixed_test_sha256':digest(seed/testpath)}
 if summary['test_input']['sha256']!=summary['test_input']['fixed_test_sha256']:raise RuntimeError('TEST_INPUT_BYTES_DIFFER');save()
 log=req('build-lib',cargo+['test','--locked','--release','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib','--no-run','--message-format=json'],1800)
 art=artifacts(log,'trnm_pon_node');profile=art['profile']
 expect={'debug_assertions':False,'debuginfo':0,'opt_level':'3','overflow_checks':False,'test':True}
 if any(profile.get(k)!=v for k,v in expect.items()):raise RuntimeError('RELEASE_PROFILE_MISMATCH')
 binary=pathlib.Path(art['executable']);retained=out/'node_lib.bin';shutil.copy2(binary,retained)
 summary['node_lib']={'path':str(binary),'retained':str(retained),'sha256':digest(binary),'bytes':binary.stat().st_size,'profile':profile};save()
 names=['mining::pool_reconcile_control_tests::pool_run_stop_interrupts_reconciliation_pool_rows','mining::pool_reconcile_control_tests::pool_run_deadline_interrupts_reconciliation_pool_rows']
 listed=req('test-list',[str(binary),'--list'],60).read_text()
 for name in names:
  if listed.splitlines().count(name+': test')!=1:raise RuntimeError('MISSING_OR_DUPLICATE_TEST '+name)
 for i,name in enumerate(names):
  row,so,se=run('test-'+str(i+1).zfill(2),[str(binary),name,'--exact','--nocapture','--test-threads=1'],120)
  stdout=so.read_text(errors='strict');stderr=se.read_text(errors='strict')
  expected=(row['exit']==101 and not row['timed_out']
   and len(re.findall('pool_reconcile_control_tests.rs:181:',stderr))==1
   and "POOL_RUN_RECONCILIATION_ROWS_IGNORED_ORIGINAL_CONTROL: pool-batch" in stderr
   and re.search(r'left:\\s*6\\n\\s*right:\\s*2',stderr) is not None
   and 'test result: FAILED. 0 passed; 1 failed; 0 ignored;' in stdout
   and stdout.count('... FAILED')==1)
  summary['tests'].append({'name':name,'expected_designated_failure':expected,'step':row});save()
 summary['success']=len(summary['tests'])==2 and all(t['expected_designated_failure'] for t in summary['tests'])
except Exception as e:
 summary['failure']=str(e);print(json.dumps({'failure':str(e)}),flush=True)
finally:
 if root.is_dir():
  try:source('source-after')
  except Exception as e:summary['source_after_failure']=str(e);summary['success']=False
 summary['capacity_after']={'tmpfs_free':shutil.disk_usage('/dev/shm').free,'root_free':shutil.disk_usage('/').free};save()
 print(json.dumps({'final':True,'success':summary['success'],'failure':summary.get('failure'),'expected_failures':sum(t['expected_designated_failure'] for t in summary['tests']),'source':sha,'evidence':str(out)}),flush=True)
sys.exit(0 if summary['success'] else 1)
