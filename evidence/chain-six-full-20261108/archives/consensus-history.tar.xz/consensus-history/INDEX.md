# Historical consensus, frozen-work and CI evidence

This is the child campaign history preceding the final unified F2 validation.
It preserves failures, partial records, exact source identities and original
logs. It contains no final F2 runtime result and grants no production,
whole-chain, universal work-cost, quantum-soundness or hosted-CI qualification.

## Contents and outcomes

| Line | Exact source / input | Retained outcome | Primary raw records |
| --- | --- | --- | --- |
| Growth red | Original production base 7e044b65454f4c9ea505591727332acffb33e7e5 with the new red test fixture; use its recorded source hashes | The selected original test fails with GROWTH_COMPLETE_STATE_UNAVAILABLE. The outer collector succeeds because it verifies that failure. | growth/red-growth-confirmation.json and .log |
| Growth green | 0f9934f84cf22318f7bc564a0a4279c9cd0db6b8 | Eight complete native confirmation controls pass. | growth/native-growth-confirmation-01.json and .log |
| Growth retained checks | Same 0f9934f84cf22318f7bc564a0a4279c9cd0db6b8 | Growth 77 pass / 2 existing ignored; consensus 10 pass; confirmation filter 9 pass; observed-history filter 1 pass. Full source guards, locked offline graph, formatting, inventory and 43 source negatives pass. Repository/Markdown exits 2 for an old inline workflow source pin. | growth/retained-checks-01/ |
| Work contract original refusal | Current research fixture 2555316603478cd87cf91cf9a798927171a1a88b | The unchanged default runner exits 1 with SOURCE_BYTES:config/pon/pq-cross-branch-corpus-v1.json. | frozen-work-profile/red-original-receipt.json and red-original-work-time-01/ |
| Work replay setup refusal | First proposed six-file patch | git diff --check refuses trailing blank lines in four files; no commit or tests ran in this attempt. Both staged input revisions and exact Runtime output are retained. | frozen-work-profile/staged-v1-*; runtime/1a1bc5df9fd-138b0-204/ |
| Explicit historical replay | Current research 08c61d59b1b338ed5cba8a77aa2c0da07f175073 plus separate fixed baseline b16bae2824e6c8236ef2011fc93a74df3ac7f039 | Original 104 named controls and 13 real Git/filesystem boundary tests pass, with no skip/xfail. Both full catalog generation and independent replay pass under the original separate 300-second limits. Full current-source guards pass before/after. The default current-source invocation still exits 1 with the original SOURCE_BYTES refusal. | frozen-work-profile/candidate-validation-v2.json; explicit-frozen-green-01/; default-refusal-retained-01/ |
| CI first red | Tests-only cc96e739386bbaa34b212d85815fb34877c66c46 on fixed R1 e64c75253e3e876018c8a62e8b327650448b6dbf | The new untouched-lane positive test errors against the old literal checker. | ci-literal/red-original-lane-checker.log |
| CI first implementation | 16b3ef70bb22e438870ffca81f4fac2c7ac42670 | New 8 controls and complete validator pass. The original 57-method pair reports 7 failing subtests across 3 credit-prefix methods because a generic diagnostic masks the original specific diagnostic. Full source-before passes; source-after exceeds its original 600-second cap. | ci-literal/checks.json; retained-lane-controls.log; source-before.json; runtime/1a1bc7d8eba-138b0-2ca/ |
| CI dependency wait | No source change | Waiting job is explicitly cancelled after the source-after prerequisite times out; this is not test coverage. | runtime/1a1bc878850-138b0-314/ |
| CI ordering correction | 70388cd53e8c8d7a397537db51ff1d076fb33625 | Only 5 checker lines move. All 65 related methods pass (8 new + 57 retained); complete validator passes. Every require-predicate AST and all three lane literals remain identical to the preceding implementation. Exact small diff and six declared input hashes remain unchanged during this run. | ci-literal/order-correction-v3/ |

The native confirmation filters overlap: the eight new controls are already
inside the 77 Growth passes and also inside the nine confirmation-filter passes.
Do not add these rows as distinct tests. The two ignored release/scale controls
were not executed and have no successful outcome in this bundle.

The work replay checks all original 1,747 fixed-baseline entries and 27,613,671
bytes, including original modes, Git blobs, lengths and SHA-256 values. Its new
mode is explicitly a historical conditional replay by current research. It
neither refreshes the old pins nor qualifies the current native cost relation.
The fixed baseline tree is 49392edc1b49a1ad92c1956f8a37c741d835677a; its native
tree is bf84f89b235adfcffcb0d3540c22c120f4031e13. The recorded original-current
refusal remains a refusal.

The first CI checks.json is intentionally partial: the original recorder exits
when source-after times out. It was not rewritten as a completed successful
campaign. The later order-only record explicitly retains that timeout and does
not claim a successful complete source-after for the fixture. Final F2 must
receive fresh full-source validation. The CI tests constrain source structure
and refusal behavior; they do not execute the native/hosted lanes named by those
source literals.

## Provenance and reproducibility

The source-identities.json file records full commit/tree/parent identities.
source-patches/ contains six exact git-format patches, including the isolated
work-study fixture. Apply source patches only against their listed parents.
The work fixture is research preparation, not an integration merge target.
Raw Runtime stdout/stderr is stored as original bytes with authoritative
terminal status observations. A successful Runtime collector may have recorded
an expected failed inner command; read the command receipts and raw logs.

The native toolchain was Rust 1.95.0. The observed OpenSSL provider was 3.5.9,
SHA-256 8ff7dd91270fd4a8fc377031f0fd2f2cee1cd17a32ce30e4fd773a25730a120f.
Original paths and command arguments are retained in their receipts. These
historical observations do not attest a later executable at the same path.

## Material deliberately not included

This archive does not include the approximately 2.4 GB checkout, Git object
database, Cargo target/cache, compiled node/test executables, installed OpenSSL
provider, or an independent deployable service. Source patches require the
referenced repository commits and their original dependency/toolchain setup.

Temporary native SQLite stores, complete node packet histories and executable
test fixtures were not exported into these evidence directories and are not
reconstructed here. Cold-recovery and WAL observations are supported by their
actual test runs and source, not by an independently reloadable archived DB.
The Python optimization catalog and its partial-event stream are included in
full; their scope is the explicitly declared finite Python experiment.

Future final-unified runners and Runtime bookkeeping were excluded. No result
is claimed for their mere presence. This is a historical evidence package,
not a complete independent-operator, public-network, payment or hosted-CI proof.

## Inventory integrity

manifest.json lists every payload file other than manifest.json itself with
size and SHA-256, plus the original copy provenance. The outer bundle-result.json
and SHA256SUMS bind the compressed archive and this index without a self-hash
cycle. Archive readback verifies every listed payload hash.
