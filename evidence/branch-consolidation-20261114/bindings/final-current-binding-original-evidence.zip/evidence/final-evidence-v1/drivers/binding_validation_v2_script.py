from pathlib import Path
import concurrent.futures,hashlib,json,os,re,subprocess,sys,threading,time
root=Path('/private/tmp/chain-final-current-bindings-20261114')
out=Path('/private/tmp/chain-final-current-bindings-evidence-20261114/validation-v2');out.mkdir()
(out/'pid.json').write_text(json.dumps({'pid':os.getpid(),'started':time.time()})+'\n')
private_bin='/private/tmp/chain-final-current-bindings-evidence-20261114/zkr-mac-gcc15-original-v1/bin'
env={**os.environ,'PATH':private_bin+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','GIT_NO_LAZY_FETCH':'1','TMPDIR':'/private/tmp/chain-final-current-bindings-evidence-20261114/final-checkpoint-v1/canonical-tmp','PYTHONDONTWRITEBYTECODE':'1','GIT_PAGER':'cat','PAGER':'cat'}
def sha(b):return hashlib.sha256(b).hexdigest()
results=[];lock=threading.Lock()
def check(name,args,expected=0):
    start=time.time()
    with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:
        r=subprocess.run(args,cwd=root,env=env,stdout=so,stderr=se,check=False)
    so=(out/(name+'.stdout')).read_bytes();se=(out/(name+'.stderr')).read_bytes()
    row={'name':name,'args':args,'expected_exit':expected,'exit':r.returncode,'passed':r.returncode==expected,'seconds':time.time()-start,'test_counts':[int(x) for x in re.findall(rb'Ran (\d+) tests?',se)],'stdout_bytes':len(so),'stdout_sha256':sha(so),'stderr_bytes':len(se),'stderr_sha256':sha(se)}
    with lock:
        results.append(row);(out/'steps.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n');print(json.dumps(row),flush=True)
    return row
assert check('00-preflight',['bash','scripts/project-preflight.sh'])['passed']
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,env=env,text=True).splitlines()
assert len(changed)==34,changed
before={p:sha((root/p).read_bytes()) for p in changed}
(out/'candidate-edited-inputs-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
closure=out/'qrom-closure-current';closure.mkdir()
closure_digest=sha((root/'config/pon/w1-qrom-closure-current-required-tests-v2.json').read_bytes())
jobs=[
('01-current-ci-controls',[sys.executable,'scripts/ci/test_w1_qrom_current_ci.py','-v']),
('02-original-workflow-gate-controls',[sys.executable,'scripts/ci/test_w1_qrom_workflow_gate.py','-v']),
('03-complete-closure-current-controls',[sys.executable,'scripts/ci/w1_qrom_closure_current_controls.py','run','--root',str(root),'--roster-sha256',closure_digest,'--output',str(closure)]),
('04-repository-check',[sys.executable,'scripts/ci/check_repository.py']),
('05-ci-contract-check',[sys.executable,'scripts/ci/check_ci_contract.py']),
('06-corpus-check',[sys.executable,'scripts/ci/check_pq_research_integration.py']),
('07-diff-check',['git','diff','--check']),
]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    futures=[pool.submit(check,*job) for job in jobs]
    for f in futures:f.result()
if next(x for x in results if x['name']=='03-complete-closure-current-controls')['passed']:
    check('08-closure-completion-check',[sys.executable,'scripts/ci/w1_qrom_closure_current_controls.py','check','--root',str(root),'--roster-sha256',closure_digest,'--output',str(closure)])
report=out/'actual-current-semantics.json'
if check('09-actual-semantics-report',[sys.executable,'scripts/w1_qrom_semantics_audit.py','--out',str(report)])['passed']:
    check('10-current-semantics-correspondence',[sys.executable,'scripts/ci/w1_qrom_closure_current_controls.py','check-semantics','--root',str(root),'--output',str(report)])
after={p:sha((root/p).read_bytes()) for p in changed}
assert before==after,'candidate edited input changed during final controls'
(out/'candidate-edited-inputs-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
summary={'source_base':'5c04c60e463462d9df8884786e0d5bb32af08a64','all_expected_exits':all(x['passed'] for x in results),'steps':results,'edited_source_before_after_equal':True,'rust_sources_modified':False,'complete_closure_required_gate_repeated_to_resolve_retained_v1_failure':True,'already_passing_authority_root_profile_upstream_route_corpus_suites_not_repeated':True}
(out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({'all_expected_exits':summary['all_expected_exits'],'failed':[x['name'] for x in results if not x['passed']]}),flush=True)
sys.exit(0 if summary['all_expected_exits'] else 1)
