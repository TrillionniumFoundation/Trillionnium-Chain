#!/usr/bin/env python3
"""Prepare/finalize one explicit owner cancellation research trial; never dispatch.

The root caller supplies the successful clean-build qualification. This reader
checks its retained files and actual output bytes; it does not rerun a build or
claim an independent reproducible build. Finalize must run inside the intended
8-CPU/8-GiB owner unit after the caller selects the one original deadline.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import time

ROOT = Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
REPO = ROOT / "integration-repo"
MATERIALS = ROOT / "experiment-inputs-01"
MATERIAL_MANIFEST_SHA = "0f2aacaf579f37d9b21bdf5f8e1df5d018b77ff032554d0758a8b16397af3a8d"
R0VM_SHA = "2acdf550f9aca4d05b74072463e4ed307c3824309c754a5cb5f93aa84f3390e6"
R0VM_BYTES = 108764424
GUEST_SHA = "25718312ec3c6f5219d832e3516adfb5f82983156f669c5e7daa15bd22d1798f"
IMAGE = [1958252411, 3287394615, 1805488136, 1516578702, 78549041, 790278610, 301018785, 4279049364]
PROFILE = "trnm-w1-risc0-3.0.6-poseidon2-join-v2"
CPUS = [8, 9, 10, 11, 20, 21, 22, 23]
MEMORY = 8 * 1024**3
BUDGET_NS = 600 * 1_000_000_000
PLAN = {"segment_workers": 2, "compression_mode": "balanced", "compression_workers": 2, "rayon_threads": 4}
ROLES = {"owner_test", "native_winner", "runner", "verifier", "r0vm"}
REQUIRED_LOCKS = {
    "trillionnium/Cargo.lock",
    "formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock",
    "formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock",
}
REQUIRED_SOURCES = {
    "scripts/w1_generation_target_v2.py", "scripts/w1_owned_generation_runtime_v2.py",
    "scripts/w1_owner_cancellation_v1.py",
    "trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2/tests/heavy/cancellation.rs",
    "trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2/tests/heavy/cancellation/tests.rs",
    "scripts/run_w1_postwin_proof.py", "scripts/run_w1_receiver.py", "scripts/run_w1_deployment_comparison.py",
    "formal/pon-nakamoto-v1/experiments/w1_full_staged_run.py",
    "formal/pon-nakamoto-v1/experiments/w1_stage_measure.py",
    "trillionnium/crates/trnm-crypto-primitives/examples/pon_w1_native_winner_v2.rs",
    "trillionnium/crates/trnm-pon-node/src/lib.rs", "trillionnium/crates/trnm-pon-node/src/store.rs",
    "trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2.rs",
    "trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2/task_owner.rs",
    "trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2/tests.rs",
    "trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2/tests/heavy.rs",
    "trillionnium/crates/trnm-service-settlement/src/lib.rs",
    "trillionnium/crates/trnm-service-settlement/src/native_generation_budget_v2.rs",
    "trillionnium/crates/trnm-service-settlement/src/native_generation_budget_v2/tests.rs",
    "formal/pon-nakamoto-v1/w1_v2_verifier/src/main.rs",
    "formal/pon-nakamoto-v1/w1_v2_verifier/src/image.rs",
} | REQUIRED_LOCKS


def require(ok, message):
    if not ok:
        raise ValueError(message)


def hex_value(value, n=64):
    require(type(value) is str and re.fullmatch("[0-9a-f]{%d}" % n, value), "invalid lowercase hexadecimal value")
    return value


def integer(value, lo, hi, name):
    require(type(value) is int and lo <= value <= hi, "invalid integer: " + name)
    return value


def pairs(rows):
    out = {}
    for key, value in rows:
        require(key not in out, "duplicate JSON key: " + key)
        out[key] = value
    return out


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode() + b"\n"


def read_json(path, bound=8 * 1024**2):
    p = absolute(path)
    with p.open("rb") as f:
        raw = f.read(bound + 1)
    require(len(raw) <= bound, "JSON exceeds byte bound")
    value = json.loads(raw, object_pairs_hook=pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))
    require(type(value) is dict, "JSON object required")
    return value, raw


def absolute(path):
    p = Path(path)
    require(p.is_absolute() and ".." not in p.parts, "absolute path required")
    require(not p.is_symlink(), "symlink is not a fixed file")
    return p


def pin(path, *, executable=False):
    p = absolute(path)
    h = hashlib.sha256()
    with p.open("rb") as f:
        before = os.fstat(f.fileno())
        require(stat.S_ISREG(before.st_mode), "regular file required")
        if executable:
            require(before.st_mode & 0o111, "executable bit required")
            require(f.read(4) == b"\x7fELF", "actual ELF executable required")
            f.seek(0)
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
        after = os.fstat(f.fileno())
    attrs = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    require(all(getattr(before, a) == getattr(after, a) for a in attrs), "file changed during hash")
    return {"path": str(p), "bytes": after.st_size, "sha256": h.hexdigest()}


def check_pin(record, *, executable=False):
    require(type(record) is dict, "file pin object required")
    got = pin(record["path"], executable=executable)
    require(got["sha256"] == hex_value(record["sha256"]), "file SHA256 changed: " + got["path"])
    if "bytes" in record:
        require(got["bytes"] == integer(record["bytes"], 0, 2**63 - 1, "file bytes"), "file size changed")
    return got


def new_file(path, value):
    p = absolute(path)
    require(p.parent.is_dir() and p.parent.resolve() == p.parent, "existing canonical parent directory required")
    with p.open("xb") as f:
        f.write(encode(value)); f.flush(); os.fsync(f.fileno())
    fd = os.open(p.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def git(*args):
    env = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C", "GIT_OPTIONAL_LOCKS": "0",
           "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null"}
    return subprocess.run(["/usr/bin/git", "--no-optional-locks", "-C", str(REPO), *args],
                          check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env).stdout


def current_source(expected_commit):
    require(REPO.resolve() == REPO and git("rev-parse", "--show-toplevel").strip().decode() == str(REPO),
            "canonical repository required")
    commit = git("rev-parse", "HEAD").strip().decode()
    tree = git("rev-parse", "HEAD^{tree}").strip().decode()
    require(commit == hex_value(expected_commit, 40), "source commit changed")
    require(git("status", "--porcelain=v1", "--untracked-files=all") == b"", "repository must be clean")
    blobs = {}
    for entry in git("ls-tree", "-rz", "--full-tree", "HEAD").split(b"\0"):
        if entry:
            meta, name = entry.split(b"\t", 1)
            mode, kind, oid = meta.decode().split()
            blobs[name.decode()] = (mode, kind, oid)
    selected = REQUIRED_SOURCES | {name for name in blobs if name.startswith("scripts/") and name.endswith(".py")}
    require(selected <= set(blobs), "required source is not committed")
    hashes = {}
    for name in sorted(selected):
        mode, kind, oid = blobs[name]
        require(kind == "blob" and mode in {"100644", "100755"}, "ordinary source blob required")
        p = absolute(REPO / name)
        raw = p.read_bytes()
        require(hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == oid,
                "raw source differs from Git object: " + name)
        hashes[name] = hashlib.sha256(raw).hexdigest()
    return {"commit": commit, "tree": tree, "source_files": hashes}


def image_id(value):
    require(type(value) is list and len(value) == 8
            and all(type(x) is int and 0 <= x < 2**32 for x in value) and value == IMAGE,
            "fixed image_id must be the actual eight JSON u32 integers")
    return value


def qualification(path, expected_commit):
    q, raw = read_json(path)
    require(q.get("schema") == "TRNM-W1-CLEAN-BUILD-QUALIFICATION1"
            and q.get("qualification_complete") is True and q.get("repo_path") == str(REPO),
            "complete qualification for canonical repository required")
    source = current_source(expected_commit)
    require(q.get("source_commit") == source["commit"] and q.get("source_tree") == source["tree"]
            and q.get("source_clean_before") is True and q.get("source_clean_after") is True,
            "qualification does not bind this clean commit/tree")
    for name in ("source_before", "source_after"):
        row = q[name]
        require(row["tested_commit"] == source["commit"] and row["tested_tree"] == source["tree"],
                "raw-source guard identity changed")
        check_pin({"path": row["report_path"], "sha256": row["sha256"]})
    commands = q.get("commands")
    require(type(commands) is list and commands, "retained build commands required")
    for row in commands:
        require(type(row) is dict and type(row.get("exit")) is int and row["exit"] == 0
                and type(row.get("argv")) is list and row["argv"]
                and all(type(x) is str for x in row["argv"]) and type(row.get("label")) is str,
                "unsuccessful or missing build command")
        hex_value(row["stdout_sha256"]); hex_value(row["stderr_sha256"])
    require(any("--locked" in row["argv"] and "--offline" in row["argv"] for row in commands),
            "actual locked/offline Cargo invocation required")
    require(type(q.get("binaries")) is dict and set(q["binaries"]) == ROLES, "exact five binary roles required")
    binaries = {}
    for role, row in q["binaries"].items():
        require(row.get("kind") == ("fixed_upstream_release" if role == "r0vm" else "repository_build"),
                "binary role provenance mismatch")
        binaries[role] = check_pin(row, executable=True)
    require(binaries["r0vm"] == {"path":str(ROOT / "fixed-backend-01/r0vm"),
            "bytes":R0VM_BYTES,"sha256":R0VM_SHA},"original fixed upstream r0vm required")
    image_source = (REPO / "formal/pon-nakamoto-v1/w1_v2_verifier/src/image.rs").read_text()
    literal = re.search(r"pub const IMAGE_ID: \[u32; 8\] = \[(.*?)\];", image_source, re.S)
    require(literal is not None, "actual fixed verifier image declaration required")
    image_id([int(x.strip().replace("_", "")) for x in literal.group(1).split(",") if x.strip()])
    locks = q.get("locks")
    require(type(locks) is dict and locks, "lock-file qualification required")
    normalized_locks = {}
    for name, row in locks.items():
        p = Path(name) if Path(name).is_absolute() else REPO / name
        relative = str(p.relative_to(REPO))
        require(relative in source["source_files"] or git("ls-files", "--error-unmatch", relative), "untracked lock")
        normalized_locks[relative] = check_pin({"path": str(p), "sha256": row["sha256"]})
    require(REQUIRED_LOCKS <= set(normalized_locks), "native/host/verifier lock closure required")
    guest = check_pin(q["guest"])
    require(guest["sha256"] == GUEST_SHA and q["guest"].get("guest_compilation_performed") is False,
            "this experiment uses the fixed retained guest")
    image_id(q["guest"].get("image_id"))
    require(q.get("fresh_cargo_target") is False and q.get("independent_reproducible_build_established") is False,
            "cache build must retain its actual qualification limits")
    return {"path": str(absolute(path)), "sha256": hashlib.sha256(raw).hexdigest()}, source, binaries


def materials():
    record, raw = read_json(MATERIALS / "manifest.json")
    require(hashlib.sha256(raw).hexdigest() == MATERIAL_MANIFEST_SHA, "prepared-material manifest changed")
    rows = {}
    for name in ("material.bin", "header-template.bin", "header-template-search0.bin", "expected-artifacts.bin", "guest.bin"):
        rows[name] = check_pin({"path": str(MATERIALS / name), **record["files"][name]})
    data = (MATERIALS / "material.bin").read_bytes()
    old_header = (MATERIALS / "header-template.bin").read_bytes()
    header = (MATERIALS / "header-template-search0.bin").read_bytes()
    expected = (MATERIALS / "expected-artifacts.bin").read_bytes()
    require(len(data) == 32768 and len(header) == len(old_header) == 318 and len(expected) == 64, "material dimensions")
    require(header[:310] == old_header[:310] and header[310:318] == bytes(8), "declared search0 header changed")
    def domain(tag, parts):
        h = hashlib.sha256(b"TRNM-PON1\0" + len(tag).to_bytes(2, "little") + tag)
        for part in parts:
            h.update(len(part).to_bytes(4, "little")); h.update(part)
        return h.digest()
    a, b = data[:16384], data[16384:]
    require(domain(b"task", [a, b]) == header[278:310], "native work task binding")
    require(domain(b"artifact", [a]) + domain(b"qualified-task-input-v1", [b]) == expected,
            "independent expected-artifacts binding")
    require(rows["guest.bin"]["sha256"] == GUEST_SHA, "retained guest changed")
    return rows


def prepare(args):
    qpin, source, binaries = qualification(args.qualification, args.expected_commit)
    asset = materials()
    out = absolute(args.out)
    require(not out.exists() and not out.is_symlink() and out.parent.is_dir(), "fresh proof output required")
    target_root = absolute(args.target_root)
    node = absolute(args.research_node)
    require(target_root.parent.is_dir() and node.parent.is_dir(), "existing target/Node parent required")
    operation = hex_value(args.operation)
    require(type(args.target_instance) is str and re.fullmatch("[A-Za-z0-9._-]{1,128}", args.target_instance), "target identity")
    nonce = integer(args.reserve_nonce, 1, 1, "fresh development Node reserve nonce")
    require(not target_root.exists() and not node.exists(), "new isolated target and Node required")
    reason = pin(args.cancellation_reason)
    require(0 < reason["bytes"] <= 65536 and reason["sha256"] != "0" * 64, "explicit immutable owner reason required")
    python = pin(Path("/usr/bin/python3").resolve(strict=True), executable=True)
    config = {
        "schema": "TRNM-W1-FUNDED-HEAVY-CONFIG2", "repo": str(REPO),
        "expected_commit": source["commit"], "expected_tree": source["tree"],
        "out": str(out), "target_root": str(target_root), "target_instance": args.target_instance,
        "research_node_path": str(node), "reserve_nonce": nonce,
        "owner_test_binary_sha256": binaries["owner_test"]["sha256"], "provider_operation": operation,
        "profile_id": PROFILE, "image_id": IMAGE, "chain_deadline": 20, "max_attempts": 10000,
        "cpus": CPUS, "proof_plan": PLAN, "provider": {"kind": "local-owned-cgroup"},
        "resource_cap": {"cpu_ns": 8 * BUDGET_NS, "gpu_ns": 2 * BUDGET_NS,
                         "memory_peak_upper_bound_bytes": MEMORY, "receipt_bytes": 16 * 1024**2},
        "source_files": source["source_files"], "python": python,
        "target": pin(REPO / "scripts/w1_generation_target_v2.py"),
        "runtime": pin(REPO / "scripts/w1_owned_generation_runtime_v2.py"),
        "owner_cancel_runtime": pin(REPO / "scripts/w1_owner_cancellation_v1.py"),
        "owner_cancellation": {"schema": "TRNM-W1-OWNER-CANCEL-PLAN1",
            "authority": "development-owner-0", "trigger": "live-first-prove-r0vm",
            "reason_sha256": reason["sha256"], "native_task_action": "cancel-reserved"},
        "material": asset["material.bin"], "header_template": asset["header-template-search0.bin"],
        "expected_artifacts": asset["expected-artifacts.bin"], "guest": asset["guest.bin"],
        "clean_build_qualification": qpin,
        "launch_requirements": {"cpu_quota_percent": 800, "memory_max_bytes": MEMORY, "affinity": CPUS},
        "sample_kind": "fixed historical A/B material and predeclared nonce start zero; not random sampling",
        "guest_compilation_performed": False, "independent_reproducible_build_established": False,
    }
    for role in ("native_winner", "runner", "r0vm", "verifier"):
        config[role] = binaries[role]
    plan = {"schema": "TRNM-W1-OWNER-CANCEL-LAUNCH-PLAN1", "config_without_clock": config,
            "owner_test": binaries["owner_test"], "generator": pin(Path(__file__).resolve()),
            "explicit_owner_reason": reason, "experiment": "one new research-owner cancellation, no full-proof completion claim",
            "qualification": qpin, "prepared_material_manifest_sha256": MATERIAL_MANIFEST_SHA,
            "deadline_selected": False, "maximum_original_budget_ns": BUDGET_NS,
            "winner_or_proof_started": False, "created_unix_ns": time.time_ns()}
    require(len(encode(config)) + 8192 <= 131072, "heavy configuration size bound")
    require(current_source(args.expected_commit) == source, "source changed during preparation")
    new_file(args.plan, plan)
    print(json.dumps({"prepared": pin(args.plan), "source_commit": source["commit"], "source_tree": source["tree"],
                      "source_files": len(source["source_files"]), "deadline_selected": False, "dispatched": False}))


def observed_launch():
    member = Path("/proc/self/cgroup").read_text().strip()
    require(member.startswith("0::/") and "\n" not in member and "hepta-runtime-job-" in member,
            "actual owned Hepta cgroup v2 required")
    mounts = [line.split() for line in Path("/proc/self/mountinfo").read_text().splitlines() if " - cgroup2 " in line]
    require(len(mounts) == 1 and mounts[0][3:5] == ["/", "/sys/fs/cgroup"], "complete cgroup mount required")
    path = Path("/sys/fs/cgroup") / member[3:].lstrip("/")
    cpu_max = (path / "cpu.max").read_text().strip()
    parts = cpu_max.split()
    require(len(parts) == 2 and parts[0].isdigit() and parts[1].isdigit()
            and int(parts[1]) > 0 and int(parts[0]) == 8 * int(parts[1]), "actual quota must be 800 percent")
    memory_max = (path / "memory.max").read_text().strip()
    require(memory_max == str(MEMORY), "actual memory.max must be exactly 8 GiB")
    affinity = sorted(os.sched_getaffinity(0))
    require(affinity == CPUS, "actual original owner affinity must match the eight declared CPUs")
    return {"cgroup": str(path), "cpu_max": cpu_max, "memory_max_bytes": int(memory_max),
            "affinity": affinity, "observation_monotonic_ns": time.clock_gettime_ns(time.CLOCK_MONOTONIC)}


def bind_deadline(path, request):
    p = absolute(path)
    try:
        new_file(p, request)
        return request
    except FileExistsError:
        prior, _ = read_json(p)
        immutable = ("schema", "plan_sha256", "config_path", "operation", "original_deadline_ns", "original_boot_id")
        require(all(prior.get(k) == request.get(k) for k in immutable), "original deadline/operation cannot be reset")
        return prior


def finalize(args):
    plan, raw = read_json(args.plan, 131072)
    require(plan.get("schema") == "TRNM-W1-OWNER-CANCEL-LAUNCH-PLAN1" and plan.get("deadline_selected") is False,
            "immutable prepared launch plan required")
    check_pin(plan["generator"])
    require(Path(plan["generator"]["path"]) == Path(__file__).resolve(), "original generator identity")
    config_path = absolute(args.config)
    boot_id = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    require(re.fullmatch("[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}", args.boot_id)
            and args.boot_id == boot_id, "original owner boot mismatch")
    deadline = integer(args.deadline_monotonic_ns, 1, 2**64 - 1, "original deadline")
    c = plan["config_without_clock"]
    declaration = {"schema": "TRNM-W1-OWNER-CANCEL-ORIGINAL-DEADLINE1", "plan_sha256": hashlib.sha256(raw).hexdigest(),
                   "config_path": str(config_path), "operation": c["provider_operation"],
                   "original_deadline_ns": deadline, "original_boot_id": boot_id,
                   "first_observed_monotonic_ns": time.clock_gettime_ns(time.CLOCK_MONOTONIC),
                   "selected_by": "root launch caller; no automatic deadline renewal"}
    declaration = bind_deadline(str(absolute(args.plan)) + ".deadline.json", declaration)
    now = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
    require(now < deadline and deadline - now <= BUDGET_NS, "original deadline exhausted or exceeds 600-second research-cancellation bound")
    launch = observed_launch()
    qpin, source, binaries = qualification(plan["qualification"]["path"], c["expected_commit"])
    require(qpin == plan["qualification"] and source["tree"] == c["expected_tree"]
            and source["source_files"] == c["source_files"], "original qualified source/record changed")
    require(binaries["owner_test"] == plan["owner_test"], "original owner ELF changed")
    for role in ("native_winner", "runner", "r0vm", "verifier"):
        require(binaries[role] == c[role], "original executable role changed: " + role)
    materials()
    check_pin(plan["explicit_owner_reason"])
    require(c["owner_cancellation"] == {"schema": "TRNM-W1-OWNER-CANCEL-PLAN1",
        "authority": "development-owner-0", "trigger": "live-first-prove-r0vm",
        "reason_sha256": plan["explicit_owner_reason"]["sha256"], "native_task_action": "cancel-reserved"},
        "original explicit owner cancellation plan changed")
    for role in ("python", "target", "runtime", "owner_cancel_runtime", "material", "header_template", "expected_artifacts", "guest"):
        check_pin(c[role], executable=(role == "python"))
    require(not Path(c["out"]).exists() and not Path(c["out"]).is_symlink(), "fresh output directory was created before dispatch")
    now = time.clock_gettime_ns(time.CLOCK_MONOTONIC)
    require(now < deadline, "original deadline exhausted during final preflight")
    c.update(original_deadline_ns=deadline, original_boot_id=boot_id,
             launch_observation=launch, original_deadline_declaration=declaration)
    require(len(encode(c)) <= 131072, "heavy configuration size bound")
    new_file(config_path, c)
    report = {"schema": "TRNM-W1-OWNER-CANCEL-CONFIG-FINALIZED1", "config": pin(config_path),
              "plan": pin(args.plan), "original_deadline_declaration": declaration,
              "owner_test": binaries["owner_test"], "launch_observation": launch,
              "finalized_monotonic_ns": time.clock_gettime_ns(time.CLOCK_MONOTONIC),
              "winner_or_proof_started": False, "dispatched": False}
    new_file(str(config_path) + ".finalized.json", report)
    require(report["finalized_monotonic_ns"] < deadline, "config publication exceeded original deadline; do not launch")
    print(json.dumps(report, sort_keys=True))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    for name in ("qualification", "expected-commit", "plan", "out", "target-root", "target-instance", "research-node", "operation"):
        p.add_argument("--" + name, required=True)
    p.add_argument("--reserve-nonce", type=int, required=True)
    p.add_argument("--cancellation-reason", required=True)
    f = sub.add_parser("finalize")
    for name in ("plan", "config", "boot-id"):
        f.add_argument("--" + name, required=True)
    f.add_argument("--deadline-monotonic-ns", type=int, required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare(args)
    else:
        finalize(args)


if __name__ == "__main__":
    main()
