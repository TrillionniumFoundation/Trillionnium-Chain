#!/usr/bin/env python3
"""Package the retained local observations without changing older evidence."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

scratch = Path('/workspace/scratch/4a83c49617d8')
repo = scratch / 'chain_pq'
packet = repo / 'evidence/pon-w1-qrom-implementation-20261107'
validation = packet / 'validation'
validation.mkdir(exist_ok=True)
def sha(value):
    return hashlib.sha256(value).hexdigest()
def write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')

members = {}
for path in sorted((scratch / 'validation').glob('*')):
    if path.is_file():
        members['local/' + path.name] = path.read_bytes()
trials = sorted(scratch.glob('w1_qrom_workflow_local_*/observations'))
for trial in trials:
    for path in sorted(trial.rglob('*')):
        if path.is_file():
            members['workflow/' + trial.parent.name + '/' + str(path.relative_to(trial))] = path.read_bytes()
for name in ('w1-budget-deep-json-before-20261107.json',
             'w1-qrom-workflow-gate-failures-before-fix-20261107.json',
             'w1-qrom-workflow-before-gate-fixes-20261107.yml',
             'w1-qrom-roster-before-gate-fixes-20261107.json'):
    path = scratch / name
    if not path.is_file():
        raise ValueError('missing retained review observation: ' + name)
    members['review/' + name] = path.read_bytes()
for name in ('observe.py', 'check_changed_markdown.py', 'package_w1_evidence.py'):
    members['reproduction_tools/' + name] = (scratch / name).read_bytes()

raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode='w', format=tarfile.PAX_FORMAT) as archive:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
compressed = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)
archive_path = validation / 'raw-observations.tar.gz'
with archive_path.open('xb') as stream:
    stream.write(compressed)
write_json(validation / 'index.json', {
    'schema': 'TRNM-W1-QROM-LOCAL-OBSERVATION-ARCHIVE1',
    'archive_sha256': sha(compressed), 'archive_bytes': len(compressed),
    'scope': 'Retained local observations and probes, including failed and superseded trials. '
             'A pass in an earlier trial does not override a later identified gate defect.',
    'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data)}
                for name, data in sorted(members.items())],
})

def observation(name):
    value = json.loads((scratch / 'validation' / (name + '.json')).read_bytes())
    return {**value, 'retained_prefix': 'local/' + name}

final_trial = scratch / 'w1_qrom_workflow_local_20261107_hardened_vcz2idhv/observations'
trial_status = json.loads((final_trial / 'local-stage-status.json').read_bytes())
assert trial_status['all_selected_stages_passed'] is True
roster = json.loads((repo / 'config/pon/w1-qrom-required-tests-v1.json').read_bytes())
assert roster['expected_tests'] == 81
successful = [observation(name) for name in (
    'all-w1-controls-final', 'source-integrity-controls', 'ci-contract-tests',
    'cargo-fmt-chain', 'repository-check-expanded', 'changed-markdown-links')]
assert all(row['exit_code'] == 0 and row['timed_out'] is False for row in successful)
for name, count in [('all-w1-controls-final', 209), ('source-integrity-controls', 43),
                    ('ci-contract-tests', 104)]:
    text = (scratch / 'validation' / (name + '.stderr.log')).read_text()
    assert re.search(r'Ran ' + str(count) + r' tests in .*\n\nOK\s*$', text)
failed = [observation(name) for name in (
    'retained-w1-tests', 'retained-w1-tests-materialized',
    'cargo-metadata-chain', 'cargo-metadata-v2', 'cargo-test-chain',
    'cargo-clippy-chain', 'cargo-clippy-chain-correct-toolchain',
    'repository-full-check-sparse')]
source_paths = [
    '.github/workflows/pon-w1-qrom-implementation.yml',
    'config/pon/w1-qrom-implementation-v1.json',
    'config/pon/w1-qrom-required-tests-v1.json',
    'scripts/w1_control_tree_audit.py', 'scripts/w1_fri_transcript_audit.py',
    'scripts/w1_profile_source_map.py', 'scripts/w1_qrom_implementation_audit.py',
    'scripts/w1_qrom_conditional_budget.py',
    'scripts/ci/test_w1_control_tree_audit.py', 'scripts/ci/test_w1_fri_transcript_audit.py',
    'scripts/ci/test_w1_qrom_implementation_audit.py', 'scripts/ci/test_w1_qrom_conditional_budget.py',
    'scripts/ci/test_w1_qrom_workflow_gate.py',
    'scripts/ci/verify_ci_source.py', 'scripts/project-preflight.sh',
]
write_json(packet / 'validation.json', {
    'schema': 'TRNM-W1-QROM-VALIDATION1',
    'source_base_commit': 'cb114b13bf848a77634e40a08b31b30c7c758e7b',
    'source_state': 'Candidate file identities recorded; full local tracked-source verification unavailable.',
    'source_files': [{'path': path, 'bytes': (repo / path).stat().st_size,
                      'sha256': sha((repo / path).read_bytes())} for path in source_paths],
    'passing_observations': successful,
    'retained_failed_observations': failed,
    'new_named_tests': 81, 'all_w1_tests': 209,
    'separate_source_integrity_tests': 43, 'separate_existing_ci_contract_tests': 104,
    'final_local_workflow_trial': trial_status,
    'historical_trial_policy': 'The initial and scope-updated trials predate the CI completeness repairs and are retained as superseded observations.',
    'materialization': {
        'selected_audit_inputs_complete_and_pinned': True,
        'additional_small_blobs_verified': 174,
        'additional_large_text_blobs_verified': 5,
        'large_historical_binary_fragments_still_absent': 29,
        'empty_responses_substituted_for_expected_blobs': False,
        'full_local_tracked_source_verified': False,
    },
    'native_rust_gate': {
        'rust_sources_and_lockfiles_changed': False,
        'formatting_passed': True,
        'full_locked_graph_resolved': False,
        'native_tests_completed': False,
        'strict_clippy_completed': False,
        'first_missing_chain_dependency': 'nix',
        'first_missing_v2_verifier_dependency': 'bincode',
    },
    'hosted_ci': {'observed_for_published_candidate_in_this_record': False,
                  'required_lanes': ['head', 'prospective-merge'],
                  'scope': 'Publish/read back hosted jobs separately; local trials do not supply their source identity.'},
    'qualification': {
        'post_quantum_soundness_qualified': False, 'complete_w1_soundness_qualified': False,
        'quantum_work_qualified': False, 'pq_signature_qualification_inferred': False,
        'production_qualified': False, 'consensus_admission': False, 'security_bits_quantum': None,
    },
})

changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=repo).decode().splitlines()
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=repo).decode().splitlines()
paths = sorted(set(changed + untracked))
records = []
for name in paths:
    path = repo / name
    if not path.is_file() or name.endswith('/file-manifest.json'):
        continue
    data = path.read_bytes()
    records.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                    'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()})
write_json(packet / 'file-manifest.json', {
    'schema': 'TRNM-W1-QROM-DELIVERABLE-FILES1',
    'source_base_commit': 'cb114b13bf848a77634e40a08b31b30c7c758e7b',
    'scope': 'Changed candidate files, excluding this self-referential manifest. '
             'Input fixture/source identities are in the separate fixed contract.',
    'files': records,
})
print(json.dumps({'packet_files': len(records), 'archive_members': len(members),
                  'archive_bytes': len(compressed), 'new_tests': 81, 'all_w1_tests': 209}))
