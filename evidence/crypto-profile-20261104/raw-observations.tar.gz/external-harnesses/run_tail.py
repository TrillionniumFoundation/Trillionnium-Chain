#!/usr/bin/env python3
"""Finish the scoped owner check, strict build and actual parameter observations."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/9d99fced0bf1/chain')
OUT = Path('/workspace/scratch/9d99fced0bf1/final-validation')
BASE = ['python3', '/workspace/scratch/9d99fced0bf1/run_exact.py']
MANIFEST = ['--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml']
results = []

def record(label, command):
    code = subprocess.run([*BASE, label, *command], cwd=ROOT).returncode
    row = {'label': label, 'exit_code': code}
    results.append(row)
    (OUT / 'tail-checks.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    if code:
        raise SystemExit(code)

selector = ('operator_pq_startup::tests::'
            'pq_continuous_real_bootstrap_receiver_and_cold_reopen_keep_state_fees_work_and_local_revocation')
record('node-continuous-owner', ['cargo', 'test', *MANIFEST, '-p', 'trnm-pon-node',
       '--all-features', '--lib', selector, '--', '--exact', '--show-output', '--test-threads=1'])
check = subprocess.run(['python3', 'scripts/ci/check_required_native_test.py',
                        str(OUT / 'node-continuous-owner.log'), '--test', selector],
                       cwd=ROOT, capture_output=True, text=True)
(OUT / 'node-continuous-owner-execution.txt').write_text(check.stdout + check.stderr)
if check.returncode:
    raise SystemExit(check.returncode)
record('clippy', ['cargo', 'clippy', *MANIFEST, '--workspace', '--all-targets',
                 '--all-features', '--', '-D', 'warnings'])
if sys.argv[1:] == ['--owner-and-clippy-only']:
    raise SystemExit(0)
assert not sys.argv[1:], sys.argv
record('benchmark-build', ['cargo', 'build', *MANIFEST, '--release',
                          '-p', 'trnm-crypto-primitives', '--example',
                          'pq_parameter_bench', '--message-format=json'])
artifacts = []
for line in (OUT / 'benchmark-build.log').read_text().splitlines():
    try:
        row = json.loads(line)
    except ValueError:
        continue
    if (row.get('reason') == 'compiler-artifact'
            and row.get('target', {}).get('name') == 'pq_parameter_bench'
            and row.get('executable')):
        artifacts.append(row)
assert len(artifacts) == 1, artifacts
(OUT / 'benchmark-binary-artifact.json').write_text(json.dumps(artifacts[0], indent=2) + '\n')
record('benchmark-run', ['python3', '/workspace/scratch/9d99fced0bf1/run_parameter_observation.py',
                         artifacts[0]['executable']])
record('benchmark-reader', ['python3', 'evidence/crypto-profile-20261104/recompute_benchmark.py',
                            str(OUT / 'parameter-observations.jsonl')])
