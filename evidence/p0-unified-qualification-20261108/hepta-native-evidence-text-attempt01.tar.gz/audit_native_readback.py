#!/usr/bin/env python3
"""Read immutable native streams, preserve a collector failure, archive own output.

This does not execute tests and does not convert engineering controls to authority.
The original runner/result remain unchanged even where collection was defective.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import time
import xml.etree.ElementTree as ET

ROOT = Path('/home/qian-qi/work/hepta-p0-native-controls-20261108-99b5-hepta-audit')
EV = ROOT / 'evidence'
SRC = Path('/home/qian-qi/work/hepta-p0-source-f178-20261108-99b5')


def digest(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def dump(name, value):
    (EV / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def git(args):
    p = subprocess.run(['git', *args], cwd=SRC, capture_output=True, text=True)
    return {'argv': ['git', *args], 'exit_code': p.returncode,
            'stdout': p.stdout, 'stderr': p.stderr}


spec = importlib.util.spec_from_file_location('original_runner', ROOT / 'run_native_controls.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
original = json.loads((EV / 'result.json').read_text())
registry = json.loads((EV / 'native_registry_build.stdout.log').read_text())
suites = registry['rust-suites']
report = {
    'schema': 'hepta-native-independent-stream-readback-v1',
    'observed_unix_ns': time.time_ns(),
    'source_sha': runner.EXPECTED, 'chain_sha': None,
    'qualification': 'HOLD_NO_GO', 'engineering_controls_only': True,
    'production_final_use_qualified': False,
    'collector_status': 'FAIL', 'collector_exit': 1,
    'original_runner_sha256': digest(ROOT / 'run_native_controls.py'),
    'original_result_sha256': digest(EV / 'result.json'),
    'original_result_modified': False,
    'readback_script_sha256': digest(Path(__file__)),
    'registry_sha256': digest(EV / 'native_registry_build.stdout.log'),
    'registry_tests': registry['test-count'],
    'scopes': [],
    'collection_defects': [
        'Original nextest store was source/codex-rs/target/nextest, independent of CARGO_TARGET_DIR.',
        'All original runner junit fields were null; readback5 and unknown_restart3 reports were overwritten and cannot be reconstructed as original JUnit.',
        'Original per-command collector_exit=0 and aggregate successful flag do not establish successful collection; this independent report records collector FAIL.',
        'Generated ignored nextest output existed inside source despite the required external output directory; it is preserved and moved after exact ownership/inventory checks.',
        'ELF observer recorded zero OS process executable observations; binary registry and before/after hashes do not manufacture this missing observation.'
    ],
    'os_loaded_identity': {'status': 'NOT_OBSERVED', 'observed_processes': 0},
    'profile_timeout_retry_modified': False,
    'additional_test_execution': False,
}
unique_selected = set()
for label, package, names in runner.SCOPES:
    receipt_path = EV / (label + '-receipt.json')
    receipt = json.loads(receipt_path.read_text())
    stderr = EV / receipt['stderr']
    stdout = EV / receipt['stdout']
    assert digest(stderr) == receipt['stderr_sha256']
    assert digest(stdout) == receipt['stdout_sha256']
    text = stderr.read_text()
    lines = text.splitlines()
    summaries = [(i, x) for i, x in enumerate(lines) if re.match(r'^\s*Summary\s+\[', x)]
    assert len(summaries) == 1, (label, 'summary_count', len(summaries))
    summary_index, summary_line = summaries[0]
    sm = re.fullmatch(r'\s*Summary\s+\[\s*([0-9.]+)s\]\s+(\d+) tests run: (\d+) passed, (\d+) skipped', summary_line)
    assert sm, (label, 'unrecognized summary', summary_line)
    starts = [x for x in lines[:summary_index] if re.match(r'^\s*Starting\s+', x)]
    assert len(starts) == 1
    start = re.fullmatch(r'\s*Starting (\d+) tests across (\d+) binary \((\d+) tests skipped\)', starts[0])
    assert start
    status_pattern = r'^\s*(?:PASS|FAIL|TIMEOUT|ABORT|LEAK|SLOW|TRY\s+\d+|RETRY|CANCEL|SKIP)\b'
    status_lines = [x for x in lines[:summary_index] if re.match(status_pattern, x)]
    parsed = []
    for line in status_lines:
        m = re.fullmatch(r'\s*PASS\s+\[\s*([0-9.]+)s\]\s+(\S+)\s+(\S+)\s*', line)
        assert m, (label, 'unclassified attempt retained', line)
        parsed.append({'status': 'PASS', 'reported_seconds': float(m.group(1)),
                       'package': m.group(2), 'test': m.group(3), 'attempt': 1, 'raw_line': line})
    assert len(parsed) == len(names)
    assert {p['test'] for p in parsed} == set(names)
    assert all(p['package'] == package for p in parsed)
    suite = suites[package]
    cases = suite['testcases']
    assert len(cases) - len(names) == int(sm.group(4)) == int(start.group(3))
    assert int(sm.group(2)) == int(sm.group(3)) == int(start.group(1)) == len(names)
    assert int(start.group(2)) == 1
    assert all(n in cases and cases[n]['ignored'] is False for n in names)
    assert receipt['native_exit'] == 0
    for n in names:
        unique_selected.add((package, n))
    report['scopes'].append({
        'id': label, 'package': package, 'native_exit': receipt['native_exit'],
        'selected': len(names), 'passed': len(names), 'failed': 0, 'timed_out': 0,
        'retry_attempts': 0, 'unknown_execution_outcomes': 0,
        'selected_ignored': 0, 'package_registry_total': len(cases),
        'package_registry_ignored': sum(c['ignored'] is True for c in cases.values()),
        'unselected_in_scope': len(cases) - len(names),
        'duration_seconds_from_native_summary': float(sm.group(1)),
        'raw_starting': starts[0], 'raw_summary': summary_line,
        'attempts_before_summary': parsed,
        'final_output_repeats_are_not_additional_attempts': True,
        'receipt_sha256': digest(receipt_path), 'stdout_sha256': digest(stdout),
        'stderr_sha256': digest(stderr),
        'pre_scope_registry_binary_path': suite['binary-path'],
        'pinned_registry_binary_digest_before_after_consistent': receipt['binary_changed'] is False,
        'actual_executed_binary_os_binding': 'NOT_OBSERVED',
        'original_junit': 'LOST_BY_OVERWRITE' if label != 'durable_effects4' else 'RECOVERED_AFTER_RUN',
        'collector_status': 'FAIL' if label != 'durable_effects4' else 'PARTIALLY_RECOVERED_ORIGINAL_COLLECTOR_FAILED'
    })
report['selected_unique_tests'] = len(unique_selected)
report['unselected_unique_tests'] = registry['test-count'] - len(unique_selected)
report['registry_ignored_total'] = sum(c['ignored'] is True for s in suites.values() for c in s['testcases'].values())
report['native_result_from_complete_streams'] = '12_SELECTED_TESTS_PASS'
report['binaries_before'] = original['binaries_before']
report['test_binary_inventory_after_scopes'] = []
for prefix in ['codex_hepta_agentd-', 'codex_hepta_operations-']:
    for p in sorted((ROOT / 'target/debug/deps').glob(prefix + '*')):
        if not p.is_file() or p.suffix in {'.d', '.rmeta', '.rlib'}:
            continue
        with p.open('rb') as f:
            if f.read(4) != b'\x7fELF':
                continue
        row = {'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p),
               'mtime_ns': p.stat().st_mtime_ns,
               'in_initial_combined_registry': str(p) in original['binaries_before']}
        report['test_binary_inventory_after_scopes'].append(row)
        retained = EV / 'binaries' / p.name
        if not retained.exists():
            shutil.copy2(p, retained)
        assert digest(retained) == row['sha256']
report['binary_inventory_note'] = ('Combined package listing can build a different feature-unified executable than a later one-package scope. '
    'Retain every fresh test ELF and its digest; do not infer OS loaded identity from the initial registry or an unchanged old ELF.')

# The only generated source output must be the exact known nextest directory.
generated = SRC / 'codex-rs/target'
expected = {'nextest', 'nextest/local', 'nextest/local/junit.xml'}
assert generated.is_dir() and not generated.is_symlink()
found = {str(p.relative_to(generated)) for p in generated.rglob('*')}
assert found == expected, ('unexpected generated output, refuse move', sorted(found))
for p in [generated, *generated.rglob('*')]:
    assert not p.is_symlink() and p.stat().st_uid == generated.stat().st_uid
    assert p.stat().st_ctime_ns >= json.loads((EV / 'campaign-started.json').read_text())['unix_ns']
    if p.is_file():
        assert p.stat().st_nlink == 1
        tracked = git(['ls-files', '--error-unmatch', str(p.relative_to(SRC))])
        assert tracked['exit_code'] == 1, 'refuse to move tracked or unknown file'
junit = generated / 'nextest/local/junit.xml'
assert digest(junit) == 'bd9b418ae21a9109b1294c91c1af1605028329219fa12e41b2e7a786f9185948'
xml = ET.fromstring(junit.read_bytes())
assert xml.attrib['tests'] == '4' and xml.attrib['failures'] == '0' and xml.attrib['errors'] == '0'
assert {c.attrib['name'] for c in xml.findall('.//testcase')} == set(runner.SCOPES[2][2])
destination = EV / 'recovered-source-generated-nextest-attempt01'
assert not destination.exists()
report['source_before_output_move'] = {
    'tracked_diff': git(['diff', '--name-status', 'HEAD']),
    'ignored': git(['ls-files', '--others', '--ignored', '--exclude-standard']),
}
(generated / 'nextest').rename(destination)
generated.rmdir()  # Only the now-empty generated parent can be removed.
report['recovered_original_junit'] = {'path': str(destination / 'local/junit.xml'),
    'sha256': digest(destination / 'local/junit.xml'), 'tests': 4, 'failures': 0, 'errors': 0}
report['source_after_output_move'] = {
    'head': git(['rev-parse', 'HEAD']), 'tracked_diff': git(['diff', '--name-status', 'HEAD']),
    'untracked': git(['ls-files', '--others', '--exclude-standard']),
    'ignored': git(['ls-files', '--others', '--ignored', '--exclude-standard']),
}
assert report['source_after_output_move']['head']['stdout'].strip() == runner.EXPECTED
assert all(r['exit_code'] == 0 and r['stdout'] == '' for k, r in report['source_after_output_move'].items() if k != 'head')
dump('independent-native-readback.json', report)

files = []
for p in sorted(EV.rglob('*')):
    if p.is_file():
        files.append({'path': str(p.relative_to(EV)), 'bytes': p.stat().st_size,
                      'sha256': digest(p), 'included_in_text_archive': not p.is_relative_to(EV / 'binaries')})
dump('artifact-manifest.json', {'files': files, 'binary_bodies_retained_on_host': True,
     'archive_excludes_binary_bodies': True})
archive = ROOT / 'hepta-native-evidence-text-attempt01.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    for p in sorted(EV.rglob('*')):
        if p.is_file() and not p.is_relative_to(EV / 'binaries'):
            tar.add(p, arcname='evidence/' + str(p.relative_to(EV)), recursive=False)
    tar.add(ROOT / 'run_native_controls.py', arcname='run_native_controls.py')
    tar.add(Path(__file__), arcname='audit_native_readback.py')
archive_info = {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': digest(archive)}
dump('archive-info.json', archive_info)
print(json.dumps({'native_result': report['native_result_from_complete_streams'],
                  'collector_status': report['collector_status'], 'qualification': report['qualification'],
                  'source_after_output_move': report['source_after_output_move'], 'archive': archive_info}, sort_keys=True))
