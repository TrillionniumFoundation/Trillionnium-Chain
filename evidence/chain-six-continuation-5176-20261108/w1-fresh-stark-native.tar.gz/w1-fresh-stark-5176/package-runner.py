import pathlib,json,sys,os,stat,hashlib,tarfile,subprocess,time
payload=json.load(sys.stdin)
parent=pathlib.Path('/data/chain-six-5176-20261108')
base=parent/'fresh-stark';root=parent/'qrom-source'
bundle=parent/'fresh-stark-public-bundle';bundle.mkdir();objects=bundle/'objects';objects.mkdir()
build=json.loads((base/'adapter-build-02/result.json').read_text())
proofbuild=json.loads((base/'build-result.json').read_text())
assert json.loads((base/'generation-01/summary.json').read_text())['result']=='PASS'
assert json.loads((base/'native-01/summary.json').read_text())['result']=='PASS'
files={};obj_records={};omitted={}
def sha(data):return hashlib.sha256(data).hexdigest()
def snapshot(path):
 before=path.lstat()
 if not stat.S_ISREG(before.st_mode):raise ValueError('non-regular evidence file: '+str(path))
 data=path.read_bytes();after=path.lstat()
 key=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 if key(before)!=key(after) or len(data)!=before.st_size:raise ValueError('file changed during bundle snapshot')
 return data,{'bytes':len(data),'sha256':sha(data),'mode':stat.S_IMODE(before.st_mode)}
def include(path,relative,expected=None,omit=False):
 data,record=snapshot(path)
 if expected is not None:
  assert record['sha256']==expected['sha256'] and record['bytes']==expected['bytes'],relative
 if omit:omitted[relative]=record;return
 if record['sha256'] not in obj_records:
  with (objects/record['sha256']).open('xb') as stream:stream.write(data)
  obj_records[record['sha256']]={'bytes':len(data)}
 files[relative]=record
 assert sum(v['bytes'] for v in obj_records.values())<1024**3,'bundle object size above 1 GiB'
for path in sorted(base.rglob('*')):
 if path.is_dir():continue
 relative=path.relative_to(base)
 include(path,'experiment/'+str(relative),omit=relative.parts[:2]==('generation-01','cases'))
fixture=pathlib.Path(json.loads((base/'generation-01/plan.json').read_text())['retained_fixture'])
fixture_pins=json.loads((base/'generation-01/plan.json').read_text())['retained_fixture_inputs']
for name,pin in fixture_pins.items():include(fixture/name,'retained-native-fixture/'+name,pin)
for relative,pin in build['source_inputs'].items():include(root/relative,'source/'+relative,pin)
for name,record in [('scheduled_sha_backend',proofbuild['binary']),('w1-node-adapter-research',build['binary'])]:
 include(pathlib.Path(record['path']),'binaries/'+name,record)
helpers={'run_carry_controls.py':'formal/pon-nakamoto-v1/w1_public_stark_research/run_carry_controls.py','run_node_controls.py':'formal/pon-nakamoto-v1/w1_node_adapter_research/run_node_controls.py'}
for name,relative in helpers.items():include(root/relative,'helpers/'+name)
for label in ['qrom-workflow-evidence','qrom-workflow-evidence-02']:
 for path in sorted((parent/label).rglob('*')):
  if path.is_file():include(path,'workflow-validation/'+label+'/'+str(path.relative_to(parent/label)))
manifest={'schema':'trnm-fresh-stark-content-addressed-evidence-5176-v1','runtime_source_head':build['source_head'],
 'source_parent':build['source_parent'],'qualified':False,'qualification':'HOLD_NO_GO',
 'new_complete_w1_generation_executions':1,'proof_components':2,'independent_new_statements':0,
 'same_fixed_native_statement':True,'generation_proof_outputs_are_byte_identical_to_historical_deterministic_result':True,
 'original_public_resource_profile':False,'production_activation':False,'third_party_build_closure_complete':False,
 'current_executable_binaries_included':['binaries/scheduled_sha_backend','binaries/w1-node-adapter-research'],
 'files':files,'objects':obj_records,'omitted_reconstructible_case_files':omitted,
 'negative_reconstruction_helper_sha256':files['helpers/run_carry_controls.py']['sha256'],
 'omitted_scope':'Only generation-01/cases inputs; exact helper + fresh proof/public inputs reconstruct every omitted byte. All negative process outputs are included.'}
(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(bundle/'restore.py').write_text(payload['restore'])
(bundle/'reconstruct-negative-cases.py').write_text(payload['reconstruct'])
(bundle/'README.md').write_text(payload['readme'])
(bundle/'package-runner.py').write_bytes(pathlib.Path('/proc/self/cmdline').read_bytes().split(b'\0')[2])
restore_out=parent/'fresh-stark-bundle-restored-validation'
with (bundle/'restore-validation.stdout').open('xb') as out,(bundle/'restore-validation.stderr').open('xb') as err:
 subprocess.run(['/usr/bin/python3',str(bundle/'restore.py'),str(restore_out)],stdout=out,stderr=err,check=True,timeout=120)
case_out=parent/'fresh-stark-bundle-negative-validation'
with (bundle/'negative-reconstruction-validation.stdout').open('xb') as out,(bundle/'negative-reconstruction-validation.stderr').open('xb') as err:
 subprocess.run(['/usr/bin/python3','-B',str(bundle/'reconstruct-negative-cases.py'),str(restore_out),str(case_out)],stdout=out,stderr=err,check=True,timeout=120)
archive=parent/'w1-fresh-stark-native-5176-20261109.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=6) as tar:tar.add(bundle,arcname='w1-fresh-stark-5176',recursive=True)
verified=0
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():
  pure=pathlib.PurePosixPath(member.name)
  assert not pure.is_absolute() and '..' not in pure.parts
  if member.isfile() and len(pure.parts)==3 and pure.parts[1]=='objects':
   data=tar.extractfile(member).read();assert sha(data)==pure.parts[2]
   assert len(data)==obj_records[pure.parts[2]]['bytes'];verified+=1
assert verified==len(obj_records)
summary={'schema':manifest['schema'],'result':'PASS','archive_path':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),
 'manifest_path':str(bundle/'manifest.json'),'manifest_sha256':sha((bundle/'manifest.json').read_bytes()),
 'included_logical_files':len(files),'unique_objects':len(obj_records),'unique_object_bytes':sum(v['bytes'] for v in obj_records.values()),
 'omitted_reconstructible_case_files':len(omitted),'all_omitted_files_reconstructed_and_digest_checked':True,'all_archive_objects_verified':True,
 'both_current_compiled_binaries_included':True,'first_adapter_build_failure_included':True,'original_public_resource_profile':False,
 'runtime_source_head':build['source_head'],'new_complete_w1_generation_executions':1,'independent_new_statements':0,'qualification':'HOLD_NO_GO'}
(parent/'fresh-stark-bundle-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
