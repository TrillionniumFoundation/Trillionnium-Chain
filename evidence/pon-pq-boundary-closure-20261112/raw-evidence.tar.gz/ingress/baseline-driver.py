import hashlib,importlib.util,json,os,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/qian-qi/work/chain-pq-boundary-closure-20261112-4150')
OUT=Path('/home/qian-qi/work/pq-boundary-ingress-20261112-4150')
HELPER=Path('/home/qian-qi/work/w1-baseline-9082-validation-165d/supplemental-provider-clippy/helpers/supplemental-provider-clippy-165d.py')
TEST='trillionnium/crates/trnm-pon-node/src/ingress/account_scope_tests.rs'
os.chdir(ROOT)
OUT.mkdir(exist_ok=False)
(OUT/'baseline-driver.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1])
def save(name,value):
 with (OUT/name).open('x') as f:
  json.dump(value,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def run(label,argv,timeout=120,check=True,env=None):
 print(json.dumps({'start':label,'argv':argv}),flush=True)
 start=time.time(); timed=False
 with (OUT/(label+'.stdout')).open('xb') as out,(OUT/(label+'.stderr')).open('xb') as err:
  process=subprocess.Popen(argv,stdout=out,stderr=err,env=env,start_new_session=True)
  try: rc=process.wait(timeout)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(process.pid,signal.SIGTERM)
   try: rc=process.wait(5)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);rc=process.wait()
 rec={'label':label,'argv':argv,'started':start,'finished':time.time(),'exit_code':rc,'timed_out':timed,'timeout_seconds':timeout,'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}
 save(label+'.json',rec);print(json.dumps(rec),flush=True)
 if check and (rc!=0 or timed):raise RuntimeError(label+' failed')
 return rec
assert hashlib.sha256(HELPER.read_bytes()).hexdigest()=='363fa66725ddedf2a6fa1e34b785b31c2e8ddeaa767f058766b2037c0f4ea492'
spec=importlib.util.spec_from_file_location('provider',HELPER);provider=importlib.util.module_from_spec(spec);spec.loader.exec_module(provider)
identity=provider.provider_identity();save('provider-before.json',identity)
assert identity['all_five_match']
selection=provider.check_inherited_environment(dict(os.environ));save('provider-selection.json',selection)
assert selection['compatible']
env=dict(os.environ);env.update(provider.expected_environment());env['PATH']='/home/qian-qi/.cargo/bin:'+env['PATH'];env['CARGO_TARGET_DIR']='/home/qian-qi/work/w1-baseline-9082-target-165d';env['CARGO_BUILD_JOBS']='2';env['PYTHONDONTWRITEBYTECODE']='1'
save('build-environment.json',{k:env[k] for k in [*provider.expected_environment(),'CARGO_TARGET_DIR','CARGO_BUILD_JOBS']})
run('preflight-before-format',['bash','scripts/project-preflight.sh'],env=env)
run('rustfmt-tests',['rustfmt','--edition','2021',TEST],env=env)
run('diff-check',['git','diff','--check'],env=env)
changes=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
assert changes==[TEST],changes
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
run('preflight-before-checkpoint',['bash','scripts/project-preflight.sh'],env=env)
run('stage-tests',['git','add','--',TEST],env=env)
run('commit-tests',['git','commit','-s','-m','test(pq): reproduce damaged account configuration in network entry'],env=env)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
save('baseline-source.json',{'head':head,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'base':'8970e2c81abbf48e2a4d3f0802d79624ab20fadd','test_only_changes':[TEST]})
print(json.dumps({'TEST_ONLY_COMMIT':head}),flush=True)
results=[]
try:
 run('source-before',['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',head,'--output',str(OUT/'source-before-identity.json')],timeout=600,env=env)
 run('rustc-version',['rustc','-vV'],env=env)
 run('cargo-version',['cargo','--version'],env=env)
 assert '\nrelease: 1.95.0\n' in (OUT/'rustc-version.stdout').read_text()
 assert (OUT/'cargo-version.stdout').read_text().startswith('cargo 1.95.0 ')
 for lane,features in [('default',[]),('all-features',['--all-features'])]:
  run('metadata-'+lane,['cargo','metadata','--locked','--offline','--format-version','1','--manifest-path','trillionnium/Cargo.toml',*features],timeout=180,env=env)
  results.append(run('baseline-'+lane,['cargo','test','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib',*features,'ingress::account_scope_tests::','--','--test-threads=1'],timeout=1200,check=False,env=env))
finally:
 after=provider.provider_identity();save('provider-after.json',after)
 save('baseline-results.json',{'source':head,'results':results,'provider_unchanged':identity==after,'whole_chain_pq_qualified':False,'production_activation':False})
 run('source-after',['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',head,'--output',str(OUT/'source-after-identity.json')],timeout=600,env=env)
 assert identity==after
 print(json.dumps({'BASELINE_FINISHED':head,'results':results}),flush=True)
