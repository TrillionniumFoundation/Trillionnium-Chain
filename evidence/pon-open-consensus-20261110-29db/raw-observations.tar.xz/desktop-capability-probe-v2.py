import json, os, pathlib, stat, subprocess, time
root=pathlib.Path('/home/qian-qi/workspace')
def emit(kind, **facts):
    print(json.dumps({'kind':kind,**facts}),flush=True)
def marker(path):
    try:
        mode=path.lstat().st_mode
        return 'directory' if stat.S_ISDIR(mode) else 'file' if stat.S_ISREG(mode) else 'symlink' if stat.S_ISLNK(mode) else 'other'
    except FileNotFoundError: return 'absent'
    except OSError as error: return type(error).__name__
emit('probe-start',sampled_unix_ms=int(time.time()*1000),root=str(root))
try:
    with os.scandir(root) as entries:
        matches=sorted([entry.name for entry in entries if any(word in entry.name.lower() for word in ('chain','pon','trnm'))])
    emit('matching-workspace-names',names=matches[:128],complete=len(matches)<=128)
    for name in matches[:128]:
        path=root/name
        kind=marker(path)
        emit('workspace-candidate',path=str(path),path_kind=kind,git_marker=marker(path/'.git') if kind=='directory' else 'not-directory')
        if kind=='directory':
            try:
                with os.scandir(path) as entries:
                    children=sorted([entry.name for entry in entries if entry.is_dir(follow_symlinks=False) and entry.name!='.git'])
                for child in children[:128]:
                    childpath=path/child
                    gitkind=marker(childpath/'.git')
                    if gitkind!='absent':
                        emit('child-git-marker',path=str(childpath),git_marker=gitkind)
                if len(children)>128: emit('child-list-limit',path=str(path),total=len(children),checked=128)
            except OSError as error: emit('child-list-error',path=str(path),error=type(error).__name__)
except OSError as error:
    emit('workspace-list-error',error=type(error).__name__)
for binary in ('rustc','cargo'):
    path=pathlib.Path('/home/qian-qi/.cargo/bin')/binary
    emit('version-start',binary=str(path),path_kind=marker(path))
    try:
        result=subprocess.run([str(path),'--version'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=10)
        emit('version-result',binary=binary,exit_code=result.returncode,stdout=result.stdout[:500],stderr=result.stderr[:500])
    except Exception as error:
        emit('version-error',binary=binary,error=type(error).__name__)
emit('probe-end')
