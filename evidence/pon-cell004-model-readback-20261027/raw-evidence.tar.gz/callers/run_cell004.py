"""A new observed Cell batch; never creates installation or receipt authority."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / "pon-work-impl/integration/provider-observability21e"
HANDOFF = SOURCE / "evidence/cell-provider-observability-20261027/release-to-004-handoff.json"
OUT = ROOT / "real-model-run-001/cell-handoff-fixed-serving-004"
EVIDENCE = ROOT / "evidence"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(path, value):
    with path.open("x", encoding="utf-8") as file:
        file.write(json.dumps(value, indent=2, sort_keys=True) + "\n")
        file.flush()
        os.fsync(file.fileno())


def resources():
    files = ["/proc/meminfo", "/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory.current",
             "/sys/fs/cgroup/memory.events", "/sys/fs/cgroup/memory.peak", "/sys/fs/cgroup/memory.stat"]
    return dict(free_bytes=shutil.disk_usage(ROOT).free,
                observations={name: Path(name).read_text() for name in files if Path(name).is_file()})


assert not OUT.exists()
assert sha(HANDOFF) == "c148a40360a32239de4db223b7b7752aa2f02e7ccc505eb031b36ca0ff653394"
handoff = json.loads(HANDOFF.read_text())
assert handoff["source_commit"] == "57fbdfeead5cfa1436eeef0d1691ee9933246d4d"
assert handoff["transfer_seconds"] == 35 and handoff["provider_seconds"] == 45
assert handoff["provider_workers"] == handoff["consumer_parallelism"] == 2
driver, binary = Path(handoff["driver_path"]), Path(handoff["binary_path"])
assert sha(driver) == handoff["driver_sha256"]
assert sha(binary) == handoff["binary_sha256"]
assert binary.stat().st_size == handoff["binary_bytes"]
source_head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True).strip()
assert source_head == "86a3ff97b5caf7af7a2406cf9079049ae11927ef"
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=SOURCE)
for row in handoff["context_inputs"]:
    assert sha(SOURCE / row["path"]) == row["sha256"]
    assert sha(ROOT / "chain-native-c96022" / row["path"]) == row["sha256"]
prior_invocation = json.loads((EVIDENCE / "cell-approved-release-003-invocation.json").read_text())
command = list(prior_invocation["command"])
command[1] = str(driver)
for name, value in (("--chain", SOURCE), ("--output", OUT), ("--cell-bin", binary)):
    command[command.index(name) + 1] = str(value)
assert "--controlled-consumer-profile" not in command
before = resources()
assert before["free_bytes"] >= 1400 * 1024**2
prior_path = ROOT / "real-model-run-001/cell-handoff-approved-release-003/handoff.json"
prior_sha = sha(prior_path)
observation = dict(schema="controlled-cell-fixed-provider-observation-v1", new_batch=True,
    source_build_commit=handoff["source_commit"], source_evidence_head=source_head,
    handoff_manifest_sha256=sha(HANDOFF), caller_sha256=sha(__file__), command=command,
    driver_sha256=sha(driver), binary_sha256=sha(binary), before=before,
    previous_003_handoff_sha256=prior_sha, previous_003_cause="UNDETERMINED",
    transfer_seconds=35, provider_seconds=45, provider_workers=2, consumer_parallelism=2,
    cache_limits_unchanged=True, ordinary_installation_qualified=False,
    public_reward_eligible=False, independent_operators=False)
save(EVIDENCE / "cell-fixed-serving-004-invocation.json", observation)
env = dict(os.environ, HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
           PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1",
           OMP_NUM_THREADS="2", MKL_NUM_THREADS="2", OPENBLAS_NUM_THREADS="2")
started = time.monotonic_ns()
try:
    with (EVIDENCE / "cell-fixed-serving-004.log").open("xb") as log:
        process = subprocess.run(command, cwd=SOURCE, env=env, stdout=log, stderr=subprocess.STDOUT)
    observation["exit_code"] = process.returncode
finally:
    observation.update(wall_ns=time.monotonic_ns() - started, after=resources(),
                       binary_sha256_after=sha(binary), driver_sha256_after=sha(driver),
                       previous_003_handoff_sha256_after=sha(prior_path))
    save(EVIDENCE / "cell-fixed-serving-004-terminal.json", observation)
assert observation["binary_sha256_after"] == observation["binary_sha256"]
assert observation["driver_sha256_after"] == observation["driver_sha256"]
assert observation["previous_003_handoff_sha256_after"] == prior_sha
result = json.loads((OUT / "handoff.json").read_text())
print(json.dumps(dict(exit_code=observation["exit_code"], wall_ns=observation["wall_ns"],
    status=result["status"], error=result.get("error"), transfer=result.get("transfer"),
    producer_exit_code=result.get("producer_exit_code_before_consumer_load"),
    report=str(OUT / "handoff.json")), sort_keys=True), flush=True)
