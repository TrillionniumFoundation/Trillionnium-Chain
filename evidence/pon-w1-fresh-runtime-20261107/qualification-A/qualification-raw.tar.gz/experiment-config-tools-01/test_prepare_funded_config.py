#!/usr/bin/env python3
"""Short configuration controls only: no native winner, build, or proof run."""
import json
from pathlib import Path
import tempfile
import unittest

import prepare_funded_config as config


class ConfigurationControls(unittest.TestCase):
    def test_image_requires_eight_exact_json_u32_values(self):
        self.assertEqual(config.image_id(list(config.IMAGE)), config.IMAGE)
        for bad in (str(config.IMAGE), [], config.IMAGE[:-1], [True] + config.IMAGE[1:],
                    [float(config.IMAGE[0])] + config.IMAGE[1:], [2**32] + config.IMAGE[1:]):
            with self.assertRaises(ValueError):
                config.image_id(bad)

    def test_original_deadline_cannot_change_after_durable_selection(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "original-deadline.json"
            original = {"schema":"TRNM-W1-FUNDED-ORIGINAL-DEADLINE1", "plan_sha256":"1" * 64,
                        "config_path":str(Path(directory) / "config.json"), "operation":"2" * 64,
                        "original_deadline_ns":12345, "original_boot_id":"test-fixture-no-launch",
                        "first_observed_monotonic_ns":100}
            config.bind_deadline(path, original)
            retained = path.read_bytes()
            for key, value in (("original_deadline_ns",12346), ("operation","3" * 64),
                               ("original_boot_id","another-boot"), ("plan_sha256","4" * 64),
                               ("config_path",str(Path(directory) / "another.json"))):
                changed = dict(original); changed[key] = value
                with self.assertRaises(ValueError):
                    config.bind_deadline(path, changed)
                self.assertEqual(path.read_bytes(), retained)
            same = dict(original); same["first_observed_monotonic_ns"] = 200
            self.assertEqual(config.bind_deadline(path, same), original)
            self.assertEqual(path.read_bytes(), retained)

    def test_immutable_output_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.json"
            config.new_file(path, {"original":True})
            raw = path.read_bytes()
            with self.assertRaises(FileExistsError):
                config.new_file(path, {"changed":True})
            self.assertEqual(path.read_bytes(), raw)

    def test_duplicate_json_and_changed_file_pin_are_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "record.json"
            path.write_text('{"same":1,"same":2}')
            with self.assertRaises(ValueError):
                config.read_json(path)
            path.write_text(json.dumps({"version":1}))
            original = config.pin(path)
            path.write_text(json.dumps({"version":2}))
            with self.assertRaises(ValueError):
                config.check_pin(original)


if __name__ == "__main__":
    unittest.main()
