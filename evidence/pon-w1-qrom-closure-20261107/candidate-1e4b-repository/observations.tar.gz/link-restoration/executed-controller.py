import base64,hashlib,json,os,pathlib,re,subprocess
from urllib.parse import unquote,urlsplit
R=pathlib.Path('/home/qian-qi/work/chain-qrom-closure-publish-20261107')
E=pathlib.Path('/home/qian-qi/work/chain-qrom-closure-20261107-evidence')
O=E/'candidate-A-link-materialization-v1';O.mkdir(mode=0o700)
HEAD='1e4bffc371bcdc53aabc621b6b6cb2485ab36f53'
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='scripts/ci:scripts',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(x):return hashlib.sha256(x).hexdigest()
def blob(x):return hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x,usedforsecurity=False).hexdigest()
need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD,'A moved')
tree={}
for row in subprocess.check_output(['git','ls-tree','-r','-z',HEAD],cwd=R,env=ENV).split(b'\0'):
 if row:
  m,p=row.split(b'\t',1);mode,kind,oid=m.decode().split();tree[p.decode()]=(mode,kind,oid)
restored=[];rounds=[];downloaded=0
def save():
 (O/'report.json').write_text(json.dumps({'schema':'TRNM-W1-A-EXACT-LINK-TARGET-RESTORATION1','candidate':HEAD,'restored':restored,'rounds':rounds,'downloaded_bytes':downloaded,'scope':'Only missing current Markdown link targets that are exact tracked A blobs. No source edit or full-worktree qualification.'},indent=2,sort_keys=True)+'\n')
try:
 for turn in range(16):
  missing={}
  for p in sorted(R.rglob('*.md')):
   relative=str(p.relative_to(R))
   if not p.is_file() or any(x in {'.git','target','__pycache__','.pytest_cache','node_modules'} for x in p.relative_to(R).parts):continue
   text=re.sub(r'^\x60{3}[^\n]*\n.*?^\x60{3}[^\n]*$','',p.read_text(),flags=re.M|re.S)
   for target in re.findall(r'\[[^\]]*\]\(([^\s)]+)\)',text):
    u=urlsplit(target.strip('<>'))
    if u.scheme or u.netloc or not u.path:continue
    q=(p.parent/unquote(u.path)).resolve()
    need(q.is_relative_to(R),'escaping local Markdown target')
    if not q.exists():
     name=str(q.relative_to(R));need(name in tree,'missing target is not a tracked A blob: '+name)
     missing.setdefault(name,[]).append({'source':relative,'target':target})
  rounds.append({'round':turn,'missing_paths':sorted(missing),'missing_count':len(missing)});save()
  print(json.dumps({'stage':'missing-link-targets','round':turn,'count':len(missing),'paths':sorted(missing)}),flush=True)
  if not missing:break
  need(len(restored)+len(missing)<=128,'bounded exact restoration count exceeded')
  for name,links in sorted(missing.items()):
   mode,kind,oid=tree[name];need(kind=='blob' and mode in ('100644','100755'),'nonregular missing target')
   p=subprocess.run(['git','cat-file','blob',oid],cwd=R,env=ENV,capture_output=True)
   provider='local-Git-object';api=None
   if p.returncode==0:data=p.stdout
   else:
    p=subprocess.run(['gh','api','repos/TrillionniumFoundation/Trillionnium-Chain/git/blobs/'+oid],cwd=R,env=ENV,capture_output=True,timeout=120)
    need(p.returncode==0,'exact authenticated blob read failed: '+name)
    v=json.loads(p.stdout);need(v['sha']==oid and v['encoding']=='base64' and type(v['size']) is int and 0<=v['size']<=64*1024*1024,'API target identity/size')
    data=base64.b64decode(v['content'].replace('\n',''),validate=True);need(len(data)==v['size'],'API size mismatch')
    api={'response_bytes':len(p.stdout),'response_sha256':sha(p.stdout),'url':v['url'],'size':v['size'],'git_blob':v['sha']}
    downloaded+=len(data);need(downloaded<=256*1024*1024,'exact restoration byte bound exceeded')
    provider='authenticated-GitHub-exact-blob'
   need(blob(data)==oid,'A target Gitblob differs')
   current=R
   for part in pathlib.Path(name).parts[:-1]:
    current=current/part;need(not current.is_symlink(),'target ancestor symlink');current.mkdir(exist_ok=True)
   fd=os.open(R/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o755 if mode=='100755' else 0o644)
   with os.fdopen(fd,'wb') as f:f.write(data)
   installed=subprocess.run(['git','hash-object','-w','--stdin'],cwd=R,env=ENV,input=data,capture_output=True)
   need(installed.returncode==0 and installed.stdout.decode().strip()==oid,'install verified target Gitblob')
   need(blob((R/name).read_bytes())==oid,'target readback')
   restored.append({'path':name,'mode':mode,'git_blob':oid,'bytes':len(data),'sha256':sha(data),'provider':provider,'api':api,'referenced_by':links});save()
   print(json.dumps({'stage':'restored-link-target','path':name,'bytes':len(data),'sha256':sha(data),'count':len(restored)}),flush=True)
 else:raise ValueError('link target resolution round bound exceeded')
 need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==HEAD,'A moved')
 (O/'complete.json').write_text(json.dumps({'candidate':HEAD,'complete_missing_link_closure':True,'restored_files':len(restored),'downloaded_bytes':downloaded,'remainder_missing':0},indent=2,sort_keys=True)+'\n')
 print(json.dumps({'stage':'link-materialization-complete','restored_files':len(restored),'downloaded_bytes':downloaded}),flush=True)
except BaseException as error:
 save();(O/'failure.txt').write_text(type(error).__name__+': '+str(error)+'\n');raise
