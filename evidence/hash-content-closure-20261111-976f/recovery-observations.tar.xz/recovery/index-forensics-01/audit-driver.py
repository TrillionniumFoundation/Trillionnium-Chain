#!/usr/bin/env python3
"""Read-only independent B worktree/index audit. Never clear flags or checkout."""
from pathlib import Path
from datetime import datetime, timezone
import collections
import hashlib
import json
import os
import stat
import subprocess
import sys
import traceback

ROOT = Path("/home/qq/chain-hash-transitive-976f-20261111")
OUT = Path(str(ROOT) + "-recovery-cprime/index-forensics-01")
B = "9fd6ee29a7a663cef547040d9d42cc36a371a17e"
TREE = "7351f83fa9ac5c0e7540fa64bce06ea6f328602f"
EXPECTED_ENTRIES = 28334
EXPECTED_BYTES = 2578874762
OUT.mkdir(parents=True, exist_ok=False)
(OUT / "commands").mkdir()
summary = {"schema": "trnm-independent-b-index-worktree-forensics-v1",
           "started_utc": datetime.now(timezone.utc).isoformat(),
           "source": B, "tree": TREE, "status": "running",
           "source_or_index_modified": False,
           "not_an_original_source_guard_pass": True,
           "whole_chain_quantum_security_qualified": False}
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def put(name, raw):
    with (OUT / name).open("xb") as f:
        f.write(raw)
def dump(name, value):
    put(name, (json.dumps(value, sort_keys=True, indent=2) + "\n").encode())
def run(label, args, allowed=(0,)):
    command = ["git", "--no-replace-objects", *args]
    p = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    put("commands/" + label + ".stdout", p.stdout)
    put("commands/" + label + ".stderr", p.stderr)
    dump("commands/" + label + ".json", {"argv": command, "exit_code": p.returncode,
         "stdout_bytes": len(p.stdout), "stdout_sha256": sha(p.stdout),
         "stderr_bytes": len(p.stderr), "stderr_sha256": sha(p.stderr)})
    if p.returncode not in allowed:
        raise RuntimeError("Git inspection failed: " + label)
    return p.stdout
def identity(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
def snapshot(path, name):
    if not path.is_absolute():
        path = ROOT / path
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > 64 * 1024 * 1024:
            raise ValueError("nonregular/oversize index metadata")
        parts = []
        while True:
            data = os.read(fd, 1024 * 1024)
            if not data:
                break
            parts.append(data)
        raw = b"".join(parts)
        after = os.fstat(fd)
        if identity(before) != identity(after) or identity(after) != identity(path.lstat()):
            raise ValueError("index metadata changed while read")
        put(name, raw)
        return {"path": str(path), "bytes": len(raw), "sha256": sha(raw),
                "mode": oct(stat.S_IMODE(before.st_mode)),
                "snapshot": name, "mtime_ns": before.st_mtime_ns,
                "ctime_ns": before.st_ctime_ns}
    finally:
        os.close(fd)
try:
    put("audit-driver.py", Path(__file__).read_bytes())
    head = run("head-before", ["rev-parse", "HEAD", "HEAD^{tree}"]).decode().splitlines()
    if head != [B, TREE]:
        raise ValueError("checkout is not the retained B")
    run("git-version", ["--version"])
    run("status", ["status", "--porcelain=v1", "--untracked-files=all"])
    safe_config = r"^(core\.(ignorestat|sparsecheckout|sparsecheckoutcone|fsmonitor|filemode|ignorecase|splitindex)|extensions\.worktreeconfig|index\.sparse)$"
    run("safe-config-all", ["config", "--show-origin", "--get-regexp", safe_config], (0, 1))
    run("safe-config-worktree", ["config", "--worktree", "--show-origin", "--get-regexp", safe_config], (0, 1))
    run("replacement-refs", ["for-each-ref", "--format=%(refname)", "refs/replace/"])
    summary["git_environment"] = {key: os.environ.get(key) for key in (
        "GIT_INDEX_FILE", "GIT_DIR", "GIT_WORK_TREE", "GIT_CONFIG_GLOBAL",
        "GIT_CONFIG_NOSYSTEM", "GIT_CONFIG_COUNT")}
    index_name = run("index-path", ["rev-parse", "--git-path", "index"]).decode().strip()
    summary["index_before"] = snapshot(Path(index_name), "index-before.bin")
    shared_name = run("shared-index-path", ["rev-parse", "--shared-index-path"]).decode().strip()
    summary["shared_index_before"] = snapshot(Path(shared_name), "shared-index-before.bin") if shared_name else None
    sparse_name = run("sparse-pattern-path", ["rev-parse", "--git-path", "info/sparse-checkout"]).decode().strip()
    sparse_path = Path(sparse_name)
    if not sparse_path.is_absolute():
        sparse_path = ROOT / sparse_path
    summary["sparse_patterns"] = snapshot(sparse_path, "sparse-checkout-before.bin") if sparse_path.exists() else None
    raw_tags = run("ls-files-v", ["ls-files", "-v", "-z"])
    raw_stage = run("ls-files-stage", ["ls-files", "--stage", "-z"])
    run("ls-files-debug", ["ls-files", "--debug", "-z"])
    run("ls-files-resolve-undo", ["ls-files", "--resolve-undo", "-z"])
    tags = [item for item in raw_tags.split(b"\0") if item]
    flagged = [item for item in tags if item[:1].islower() or item[:1] == b"S"]
    summary["index_tag_counts"] = dict(collections.Counter(item[:1].decode() for item in tags))
    summary["flagged_count"] = len(flagged)
    dump("flagged-paths.json", [{"tag": item[:1].decode(),
         "path": item[2:].decode("utf-8", "surrogateescape")} for item in flagged])
    raw_tree = run("b-tree", ["ls-tree", "-r", "-z", "--full-tree", B])
    tree_rows = []
    expected_index = {}
    for entry in raw_tree.split(b"\0"):
        if not entry:
            continue
        info, path = entry.split(b"\t", 1)
        mode, kind, oid = info.split(b" ")
        if kind != b"blob" or mode not in (b"100644", b"100755", b"120000"):
            raise ValueError("unsupported B tree entry")
        if path.startswith(b"/") or any(part in (b"", b".", b"..") for part in path.split(b"/")):
            raise ValueError("noncanonical B pathname")
        if path in expected_index:
            raise ValueError("duplicate B pathname")
        expected_index[path] = (mode, oid, b"0")
        tree_rows.append((path, mode, oid))
    actual_index = {}
    duplicate_index = False
    for entry in raw_stage.split(b"\0"):
        if not entry:
            continue
        info, path = entry.split(b"\t", 1)
        fields = tuple(info.split(b" "))
        if path in actual_index:
            duplicate_index = True
        actual_index[path] = fields
    summary["index_stage0_exactly_B"] = not duplicate_index and actual_index == expected_index
    summary["index_stage_difference_count"] = sum(
        actual_index.get(path) != expected_index.get(path)
        for path in set(actual_index) | set(expected_index))
    if len(tree_rows) != EXPECTED_ENTRIES:
        raise ValueError("B tracked count differs from retained observation")
    rootfd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    root_identity = identity(os.fstat(rootfd))
    total_bytes = 0
    eof_probes = 0
    matched = 0
    mismatches = []
    stream_sha = hashlib.sha256()
    with (OUT / "physical-blob-observations.jsonl").open("xb") as rows_out:
        for path, mode, expected_oid in tree_rows:
            row = {"path": path.decode("utf-8", "surrogateescape"),
                   "expected_mode": mode.decode(), "expected_blob": expected_oid.decode()}
            descriptors = []
            try:
                current = os.dup(rootfd)
                descriptors.append(current)
                parents = []
                components = path.split(b"/")
                for component in components[:-1]:
                    child = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                                    dir_fd=current)
                    parents.append((current, component, child, identity(os.fstat(child))))
                    descriptors.append(child)
                    current = child
                leaf = components[-1]
                visible = os.stat(leaf, dir_fd=current, follow_symlinks=False)
                row["observed_mode"] = oct(visible.st_mode)
                row["observed_bytes"] = visible.st_size
                content_sha = hashlib.sha256()
                if mode == b"120000":
                    if not stat.S_ISLNK(visible.st_mode):
                        raise ValueError("expected symlink")
                    body = os.readlink(leaf, dir_fd=current)
                    if not isinstance(body, bytes):
                        body = os.fsencode(body)
                    if identity(visible) != identity(os.stat(leaf, dir_fd=current, follow_symlinks=False)):
                        raise ValueError("symlink changed during read")
                    if total_bytes + len(body) > EXPECTED_BYTES:
                        raise ValueError("B total byte ceiling exceeded")
                    blob = hashlib.sha1(b"blob " + str(len(body)).encode() + b"\0" + body)
                    content_sha.update(body)
                    total_bytes += len(body)
                else:
                    if not stat.S_ISREG(visible.st_mode):
                        raise ValueError("expected regular file")
                    actual_mode = b"100755" if visible.st_mode & 0o111 else b"100644"
                    if actual_mode != mode:
                        raise ValueError("Git executable mode differs")
                    fd = os.open(leaf, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=current)
                    descriptors.append(fd)
                    before = os.fstat(fd)
                    if identity(before) != identity(visible):
                        raise ValueError("leaf changed before read")
                    if total_bytes + before.st_size > EXPECTED_BYTES:
                        raise ValueError("B total byte ceiling exceeded")
                    blob = hashlib.sha1(b"blob " + str(before.st_size).encode() + b"\0")
                    remaining = before.st_size
                    while remaining:
                        body = os.read(fd, min(1024 * 1024, remaining))
                        if not body:
                            raise ValueError("truncated actual file")
                        remaining -= len(body)
                        total_bytes += len(body)
                        blob.update(body)
                        content_sha.update(body)
                    if os.read(fd, 1):
                        raise ValueError("tail beyond observed file size")
                    eof_probes += 1
                    if identity(before) != identity(os.fstat(fd)) or identity(before) != identity(os.stat(leaf, dir_fd=current, follow_symlinks=False)):
                        raise ValueError("actual file changed during read")
                for parent, component, child, before_parent in parents:
                    if before_parent != identity(os.fstat(child)) or before_parent != identity(os.stat(component, dir_fd=parent, follow_symlinks=False)):
                        raise ValueError("directory ancestor changed during read")
                actual_oid = blob.hexdigest()
                row.update({"observed_git_blob": actual_oid, "observed_content_sha256": content_sha.hexdigest()})
                if actual_oid != expected_oid.decode():
                    raise ValueError("complete raw bytes differ from B blob identity")
                row["status"] = "matched"
                matched += 1
            except Exception as exc:
                row["status"] = "mismatch_or_unreadable"
                row["error"] = type(exc).__name__ + ": " + str(exc)
                mismatches.append(row)
            finally:
                for fd in reversed(descriptors):
                    os.close(fd)
            line = (json.dumps(row, sort_keys=True, ensure_ascii=True) + "\n").encode()
            rows_out.write(line)
            stream_sha.update(line)
    if root_identity != identity(os.fstat(rootfd)) or root_identity != identity(ROOT.lstat()):
        raise ValueError("checkout root changed during audit")
    os.close(rootfd)
    after_head = run("head-after", ["rev-parse", "HEAD", "HEAD^{tree}"]).decode().splitlines()
    after_tags = run("ls-files-v-after-readback", ["ls-files", "-v", "-z"])
    after_stage = run("ls-files-stage-after-readback", ["ls-files", "--stage", "-z"])
    summary.update({"tracked_entries": len(tree_rows), "matched_entries": matched,
        "actual_bytes_read": total_bytes, "regular_eof_probes": eof_probes,
        "mismatch_count": len(mismatches), "mismatch_first_20": mismatches[:20],
        "physical_observations_sha256": stream_sha.hexdigest(),
        "head_stable": after_head == [B, TREE],
        "index_flags_stable": raw_tags == after_tags,
        "index_stage_mapping_stable": raw_stage == after_stage})
    dump("all-mismatches.json", mismatches)
    ok = (not mismatches and matched == EXPECTED_ENTRIES and total_bytes == EXPECTED_BYTES
          and summary["index_stage0_exactly_B"] and summary["head_stable"]
          and summary["index_flags_stable"] and summary["index_stage_mapping_stable"])
    summary["status"] = "independent_raw_worktree_and_stage0_match_B" if ok else "REFUSE_PHYSICAL_OR_INDEX_DIFFERENCE"
except Exception as exc:
    summary["status"] = "REFUSE_INSPECTION_ERROR"
    summary["error"] = type(exc).__name__ + ": " + str(exc)
    put("exception-traceback.txt", traceback.format_exc().encode())
summary["finished_utc"] = datetime.now(timezone.utc).isoformat()
dump("summary.json", summary)
print(json.dumps(summary, sort_keys=True), flush=True)
raise SystemExit(0 if summary["status"] == "independent_raw_worktree_and_stage0_match_B" else 2)
