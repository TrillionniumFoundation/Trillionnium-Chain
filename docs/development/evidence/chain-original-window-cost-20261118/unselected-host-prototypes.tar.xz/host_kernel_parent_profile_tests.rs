// Explicit diagnostic only: ordinary temporary files cannot qualify as the
// fixed root-owned cgroup. The canonical-text arm is not used in production.
use super::*;
use std::{hint::black_box, time::Instant};

fn cpu_ns() -> u64 {
    use rustix::time::{clock_gettime_dynamic, ClockId, DynamicClockId};
    let now = clock_gettime_dynamic(DynamicClockId::Known(ClockId::ThreadCPUTime)).unwrap();
    u64::try_from(now.tv_sec).unwrap() * 1_000_000_000 + u64::try_from(now.tv_nsec).unwrap()
}

fn measured(mut call: impl FnMut(), count: usize) -> (u64, u128) {
    let wall = Instant::now();
    let before = cpu_ns();
    for _ in 0..count {
        call();
    }
    (cpu_ns() - before, wall.elapsed().as_nanos())
}

fn canonical_limits(parent: &fs::File, expected: Limits, canonical: &[String; 5]) -> Result<Limits> {
    let [cpu, burst, memory, swap, pids] = &mut [[0; MAX_LIMIT_BYTES + 1]; 5];
    // Even the experimental arm must open/type-check/read every current file
    // through EOF in order before deciding whether parsing can be avoided.
    let observed = [
        read_limit_at(parent, c"cpu.max", cpu)?,
        read_limit_at(parent, c"cpu.max.burst", burst)?,
        read_limit_at(parent, c"memory.max", memory)?,
        read_limit_at(parent, c"memory.swap.max", swap)?,
        read_limit_at(parent, c"pids.max", pids)?,
    ];
    if observed.iter().zip(canonical).all(|(a, b)| *a == b) {
        Ok(expected)
    } else {
        validate_limits(observed[0], observed[1], observed[2], observed[3], observed[4])
    }
}

#[test]
#[ignore = "explicit component cost diagnostic; never a public service acceptance"]
fn fresh_checkpoint_component_cpu_and_canonical_parse_abba() {
    let temporary = tempfile::tempdir().unwrap();
    let parent = temporary.path().join("parent");
    fs::create_dir(&parent).unwrap();
    fs::set_permissions(&parent, fs::Permissions::from_mode(0o700)).unwrap();
    let texts = ["25000 100000\n", "0\n", "2147483648\n", "0\n", "256\n"];
    for (name, value) in ["cpu.max", "cpu.max.burst", "memory.max", "memory.swap.max", "pids.max"].iter().zip(texts) {
        fs::write(parent.join(name), value).unwrap();
    }
    let expected = validate_limits(texts[0], texts[1], texts[2], texts[3], texts[4]).unwrap();
    let canonical = [
        format!("{} {}\n", expected.cpu_quota_us, expected.cpu_period_us),
        "0\n".to_owned(), format!("{}\n", expected.memory_bytes),
        "0\n".to_owned(), format!("{}\n", expected.tasks),
    ];
    let identity = fs::symlink_metadata(&parent).unwrap();
    let boot = fs::read_to_string("/proc/sys/kernel/random/boot_id").unwrap();
    let context = fs::read_to_string("/proc/thread-self/cgroup").unwrap();
    let relative = context.trim().strip_prefix("0::/").unwrap();
    let mut samples = Vec::new();
    for round in 0..12 {
        for (slot, candidate) in [false, true, true, false].into_iter().enumerate() {
            let (cpu, wall) = measured(|| {
                let mut boot_bytes = [0; CONTEXT_STACK_BYTES + 1];
                assert_eq!(read_context(Path::new("/proc/sys/kernel/random/boot_id"), &mut boot_bytes).unwrap().trim(), boot.trim());
                let current = ScopedParentDirectory::open(&parent, &identity).unwrap();
                let mut membership_bytes = [0; CONTEXT_STACK_BYTES + 1];
                let membership = read_context(Path::new("/proc/thread-self/cgroup"), &mut membership_bytes).unwrap();
                assert!(cgroup_within_parent(&membership, relative).unwrap());
                let observed = if candidate {
                    canonical_limits(&current.file, black_box(expected), black_box(&canonical)).unwrap()
                } else {
                    current.read_limits().unwrap()
                };
                current.verify_path(&parent).unwrap();
                assert_eq!(observed, expected);
                black_box(observed);
            }, 256);
            samples.push(serde_json::json!({"round": round, "slot": slot,
                "arm": if candidate { "fresh_files_canonical_parse_prototype" } else { "fresh_files_original_parser" },
                "checks": 256, "thread_cpu_ns": cpu, "wall_ns": wall}));
        }
    }
    let (parse_cpu, parse_wall) = measured(|| {
        black_box(validate_limits(black_box(texts[0]), black_box(texts[1]),
            black_box(texts[2]), black_box(texts[3]), black_box(texts[4])).unwrap());
    }, 100_000);
    println!("{}", serde_json::json!({
        "schema": "trnm-fresh-host-component-cost-v1",
        "selected_production_candidate": false,
        "public_host_qualification": false, "business_window_executed": false,
        "fixture": "ordinary temporary files with real proc context, current-thread CPU and fresh per-check file opens",
        "checks_per_sample": 256, "samples": samples,
        "original_parser_only": {"calls": 100_000, "thread_cpu_ns": parse_cpu, "wall_ns": parse_wall},
        "scope": "component diagnosis only; no privileged parent, no hosted service, no physical-resource or success claim; all five file reads, EOF/type checks and final inode fence retained in both arms"
    }));
}
