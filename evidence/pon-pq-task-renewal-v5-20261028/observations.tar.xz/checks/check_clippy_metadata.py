import importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('check',Path(__file__).with_name('run_typecheck.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=m.run
def clippy(label,argv,env,timeout=600):
    argv=list(argv);argv[0]=str(m.TOOL/'clippy-driver');argv+=['-D','warnings']
    original(label,argv,env,timeout)
m.run=clippy
before=m.source()
try:
    for crate in ['trnm_protocol','trnm_crypto_primitives','trnm_mvcc_fee','trnm_pon_node']:
        m.build(crate,'clippy02',opt=0)
    for crate,target in [('trnm_protocol','lib'),('trnm_mvcc_fee','lib'),('trnm_mvcc_fee','pq5_task_renewal'),('trnm_pon_node','native_pq_v5')]:
        m.build(crate,'clippytests02',target,opt=0)
finally:
    m.dump(m.OUT/'clippy02-source-after.json',{'source_before_after_equal':before==m.source(),'source_before':before,'source_after':m.source(),'scope':'metadata-only explicit graph Clippy; no linked/executed tests; native NOT_RUN'})
