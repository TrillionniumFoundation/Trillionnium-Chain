#!/usr/bin/env python3
"""Build and bind the exact840 exporter only; generate no expiring material."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone

WORK = Path('/home/alex/work')
SOURCE = WORK / 'chain-npq6-export-13c7-v2'
TARGET = WORK / 'chain-npq6-export-13c7-target-v2'
OUTPUT = WORK / 'chain-npq6-export-13c7-evidence-v2'
COMMIT = '840522d0b65b4989f1a2a1d09c0ad51af1a1956d'
TREE = '70377cc0a9c8d029907f6c49bbb8dee1435a6cd1'
SELECTOR = 'export::export_ordinary_npq6_task_and_evaluator_control_material'
SUPPORT = WORK / 'chain-m15-regression-1c14fab4-13c7-runner-v2.py'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    if hashlib.sha256(SUPPORT.read_bytes()).hexdigest() != '750a23f7665477885627a80399b26bb7e887d2f4cf814e7230314123daa18def':
        raise ValueError('fixed support script changed')
    m = module('fixed_native_support', SUPPORT)
    m.require(not SOURCE.exists() and not TARGET.exists(), 'create-only source/target already exists')
    OUTPUT.mkdir(mode=0o700, exist_ok=False)
    manifest = dict(schema='chain-exact840-npq6-exporter-build-v2', commit=COMMIT, tree=TREE,
                    source=str(SOURCE), target=str(TARGET), result='RUNNING', commands=[],
                    started_utc=datetime.now(timezone.utc).isoformat(), runner_sha256=m.sha(__file__),
                    material_generated=False, paired_consumer_executed=False,
                    production_activation=False, whole_chain_quantum_security_qualified=False,
                    outer_timeout_seconds=14400, automatic_retry_added=False,
                    fixture_original_expiry_seconds=300, expiry_changed=False)
    def save():
        (OUTPUT / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    save()
    verifier = env = None
    code = 1
    try:
        m.require(subprocess.run(['pgrep', '-x', 'rustc|clippy-driver'], stdout=subprocess.DEVNULL).returncode == 1,
                  'another heavy compiler is active')
        m.require(json.loads((m.OUTPUT / 'continuation/manifest.json').read_text())['result'] == 'PASS',
                  'original remaining gates are not terminal PASS')
        manifest['old_inputs_before'] = m.check_old_inputs()
        m.require(m.git(m.SOURCE, 'rev-parse', 'HEAD') == m.COMMIT, 'donor source changed')
        m.require(m.git(m.SOURCE, 'rev-parse', COMMIT + '^{tree}') == TREE, 'donor has wrong840 object')
        manifest['previous_refusal'] = m.file_identity(WORK / 'chain-npq6-export-13c7-evidence/manifest.json')
        m.require(manifest['previous_refusal']['sha256'] == '0806cec3b6c8f6349d9c0eae9d9c94d8321333023cab3756b7a2b299786888e2', 'previous refusal changed')
        manifest['original_path_observation_before'] = {
            'head': m.git(m.ORIGINAL, 'rev-parse', 'HEAD'),
            'tree': m.git(m.ORIGINAL, 'rev-parse', 'HEAD^{tree}'),
            'status': m.git(m.ORIGINAL, 'status', '--porcelain'),
            'used_as_source_input': False}
        subprocess.run(['git', 'clone', '--no-hardlinks', '--dissociate', '--no-checkout', str(m.SOURCE), str(SOURCE)], check=True)
        subprocess.run(['git', 'checkout', '-b', 'fix/chain-npq6-export-20261107-13c7-v2', COMMIT], cwd=SOURCE, check=True)
        subprocess.run(['git', 'remote', 'set-url', 'origin', 'https://github.com/TrillionniumFoundation/Trillionnium-Chain.git'], cwd=SOURCE, check=True)
        m.require(not (SOURCE / '.git/objects/info/alternates').exists(), 'source still borrows objects')
        verifier = module('verify_ci_source', SOURCE / 'scripts/ci/verify_ci_source.py')
        manifest['source_before'] = verifier.verify('head', COMMIT, root=SOURCE)
        manifest['donor_source_before'] = verifier.verify('head', m.COMMIT, root=m.SOURCE)
        m.require(manifest['source_before']['tested_tree'] == TREE, 'wrong source tree')
        env, manifest['provider_inputs_before'] = m.prepared_environment()
        provider = json.loads((m.PROVIDER / 'pq-provider/provider.json').read_text())
        m.require(m.sha(SOURCE / 'scripts/ci/prepare_pq_provider.sh') == provider['preparation_script_sha256'], '840 provider preparation differs')
        env['CARGO_TARGET_DIR'] = str(TARGET)
        manifest['environment'] = {k: env.get(k) for k in ['CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'RUST_TEST_THREADS', 'OPENSSL_DIR', 'OPENSSL_STATIC', 'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256', 'TRNM_PQ_OPENSSL_VERSION']}
        save()
        def run(label, argv):
            print(json.dumps(dict(event='start', label=label, argv=argv)), flush=True)
            command = ['python3', 'scripts/ci/record_pq_native_command.py', '--kind', 'head', '--candidate', COMMIT,
                       '--tested', COMMIT, '--label', label, '--output', str(OUTPUT), '--'] + argv
            status = subprocess.run(command, cwd=SOURCE, env=env, check=False).returncode
            manifest['commands'].append(dict(label=label, exit_code=status))
            save()
            m.require(status == 0, label + ' failed: ' + str(status))
            return (OUTPUT / (label + '.log')).read_text()
        run('preflight', ['bash', 'scripts/project-preflight.sh'])
        run('rustc', ['rustc', '+1.95.0', '-Vv'])
        run('cargo', ['cargo', '+1.95.0', '-Vv'])
        TARGET.mkdir(mode=0o700)
        run('independent-debug-cache-copy', ['cp', '-a', '--reflink=auto', str(m.TARGET / 'debug'), str(TARGET / 'debug')])
        m.require((m.TARGET / 'debug').stat().st_ino != (TARGET / 'debug').stat().st_ino, 'target is not independent')
        for old_path in (m.TARGET / 'debug').rglob('*'):
            if old_path.is_file() and not old_path.is_symlink():
                copied = TARGET / 'debug' / old_path.relative_to(m.TARGET / 'debug')
                old, new = old_path.stat(), copied.stat()
                m.require((old.st_dev, old.st_ino) != (new.st_dev, new.st_ino), 'cache copy hardlinks an input')
        base = ['cargo', '+1.95.0', 'test', '--locked', '--manifest-path', 'trillionnium/Cargo.toml',
                '-p', 'trnm-pon-node', '--test', 'pq_application_local_cli', '--features', 'pq-native-openssl']
        log = run('exporter-build', base + ['--no-run', '--message-format=json'])
        artifacts = [json.loads(line) for line in log.splitlines() if line.startswith('{')]
        artifacts = [row for row in artifacts if row.get('reason') == 'compiler-artifact' and row.get('executable')]
        selected = [row for row in artifacts if row['target']['kind'] == ['test'] and row['target']['name'] == 'pq_application_local_cli']
        m.require(len(selected) == 1, 'one actual integration harness is required')
        artifact = selected[0]
        m.require(artifact['target']['src_path'] == str(SOURCE / 'trillionnium/crates/trnm-pon-node/tests/pq_application_local_cli.rs'), 'wrong integration source')
        m.require(artifact['profile']['test'] is True and set(artifact['features']) == {'default', 'pq-native-openssl'}, 'wrong integration profile')
        native = Path(artifact['executable'])
        original = m.file_identity(native)
        retained = OUTPUT / 'pq_application_local_cli-harness'
        with native.open('rb') as src, retained.open('xb') as dst:
            shutil.copyfileobj(src, dst, 1024 * 1024)
            dst.flush()
            os.fsync(dst.fileno())
        retained.chmod(0o555)
        copy = m.file_identity(retained)
        m.require(m.file_identity(native) == original and copy['sha256'] == original['sha256'] and copy['nlink'] == 1, 'harness copy changed')
        binding = dict(artifact=artifact, original=original, retained=copy, all_executable_artifacts=artifacts)
        m.write_json(OUTPUT / 'artifact-binding.json', binding)
        manifest['artifact_binding'] = binding
        listing = run('registry', [str(retained), '--list'])
        names = re.findall(r'^([A-Za-z_][A-Za-z0-9_:]*): test$', listing, re.M)
        ignored = run('ignored-registry', [str(retained), '--ignored', '--list'])
        ignored_names = re.findall(r'^([A-Za-z_][A-Za-z0-9_:]*): test$', ignored, re.M)
        m.require(names.count(SELECTOR) == ignored_names.count(SELECTOR) == 1, 'exporter is not registered exactly once as ignored')
        manifest['registry_names'], manifest['ignored_names'] = names, ignored_names
        m.require(m.file_identity(retained) == copy, 'registered harness changed')
        code = 0
    except Exception as error:
        manifest['error'] = str(error)
        print(json.dumps(dict(event='failed', error=str(error))), flush=True)
    finally:
        try:
            manifest['old_inputs_after'] = m.check_old_inputs()
            m.require(manifest['old_inputs_before'] == manifest['old_inputs_after'], 'old retained inputs changed')
            if verifier is not None:
                manifest['source_after'] = verifier.verify('head', COMMIT, root=SOURCE)
                manifest['donor_source_after'] = verifier.verify('head', m.COMMIT, root=m.SOURCE)
                m.require(manifest['source_before'] == manifest['source_after'] and manifest['donor_source_before'] == manifest['donor_source_after'], 'source changed')
                manifest['original_path_observation_after'] = {
                    'head': m.git(m.ORIGINAL, 'rev-parse', 'HEAD'),
                    'tree': m.git(m.ORIGINAL, 'rev-parse', 'HEAD^{tree}'),
                    'status': m.git(m.ORIGINAL, 'status', '--porcelain'),
                    'used_as_source_input': False}
            if env is not None:
                _, manifest['provider_inputs_after'] = m.prepared_environment()
                m.require(manifest['provider_inputs_before'] == manifest['provider_inputs_after'], 'provider changed')
        except Exception as error:
            manifest['final_identity_error'] = str(error)
            code = 1
        manifest.update(result='PASS' if code == 0 else 'FAIL', exit_code=code, finished_utc=datetime.now(timezone.utc).isoformat())
        save()
    print(json.dumps(dict(result=manifest['result'], output=str(OUTPUT), material_generated=False)), flush=True)
    return code


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    raise SystemExit(main())
