#!/usr/bin/env python3
"""Retain completed 53a90ad6 observations, including failures, without certifying PQ.

Run only after all producers end. Produces a new output directory; never edits
source or existing records. Missing native executions remain explicitly absent.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile

sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
BASE = Path('/workspace/scratch/9d99fced0bf1')
spec = importlib.util.spec_from_file_location('retirement_required_support', BASE / 'run_retirement_required_controls.py')
support = importlib.util.module_from_spec(spec)
spec.loader.exec_module(support)
ROOT, RECORDS, COMMIT, TREE = support.ROOT, support.OUT, support.COMMIT, support.TREE
require = support.require
PLANNED = ['preflight', 'compiler', 'cargo-version', 'locked-graph', 'fuzz-locked-graph',
           'fmt', 'profile-oracle', 'inventory', 'source-pins', 'claim-guard', 'repository',
           'ci-contract', 'test-ci-source-integrity', 'test-record-pq-native-command',
           'test-pq-research-integration', 'test-pq-chain-claim-guard', 'test-pq-authority-surface-scan',
           'components', 'protocol-doc', 'm06-units', 'm06-integrations', 'node-build',
           'node-network', 'required-controls', 'node-continuous-owner', 'clippy',
           'benchmark-build', 'benchmark-run', 'benchmark-reader', 'interop']
RUST_SUMMARY = re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in (.+)$', re.MULTILINE)
NAMED = re.compile(r'^test ([A-Za-z_][A-Za-z0-9_:]*) \.\.\. (ok|FAILED|ignored)(?:.*)$', re.MULTILINE)


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def public_bytes(path):
    require(path.is_file() and not path.is_symlink(), 'only regular public evidence files: ' + str(path))
    require(path.stat().st_size <= 32 * 1024 * 1024, 'unexpected large file in evidence: ' + str(path))
    raw = path.read_bytes()
    require(not raw.startswith((b'\x7fELF', b'!<arch>\n', b'MZ')),
            'compiled binaries/caches are not evidence inputs: ' + str(path))
    require(re.search(rb'^-----BEGIN [^\r\n]*PRIVATE KEY-----', raw, re.MULTILINE) is None,
            'private keys must not enter the evidence archive')
    return raw


def control_build(identity, commands, logs, inputs, roster_sha):
    require(isinstance(identity, dict), 'missing current Node binary identity')
    label = identity['build_receipt_label']
    build = commands.get(label)
    require(build and build['exit_code'] == 0 and build['argv'] == support.BUILD_ARGV,
            'selected native controls lack successful full build')
    require(identity.get('source') == build['before'] == build['after']
            and identity.get('build_receipt_sha256') == digest(inputs['records/' + label + '.json'])
            and identity.get('runner_sha256') == digest(inputs['external/run_retirement_required_controls.py'])
            and identity.get('roster_sha256') == roster_sha, 'Node identity/source/receipt/runner/roster mismatch')
    require(not build['environment'].get('RUSTFLAGS')
            and not build['environment'].get('CARGO_ENCODED_RUSTFLAGS'), 'Node compiler override is outside this run')
    cargo = []
    for line in logs[label].splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if isinstance(row, dict):
            cargo.append(row)
    require([r.get('success') for r in cargo if r.get('reason') == 'build-finished'] == [True],
            'missing successful Node Cargo completion')
    artifacts = [r for r in cargo if r.get('reason') == 'compiler-artifact'
                 and r.get('target', {}).get('name') == 'trnm_pon_node'
                 and r.get('profile', {}).get('test') is True and r.get('executable')]
    require(len(artifacts) == 1 and identity.get('artifact') == artifacts[0], 'Node artifact/build-log mismatch')
    artifact = artifacts[0]
    binary, target = Path(artifact['executable']).resolve(), Path(build['environment']['CARGO_TARGET_DIR']).resolve()
    require(Path(artifact['target']['src_path']).resolve() == ROOT / 'trillionnium/crates/trnm-pon-node/src/lib.rs'
            and set(artifact.get('features', [])) == {'default', 'pq-native-openssl'}
            and identity.get('path') == str(binary) and binary.parent == target / 'debug/deps'
            and binary.name.startswith('trnm_pon_node-')
            and type(identity.get('bytes')) is int and identity['bytes'] > 0
            and re.fullmatch(r'[0-9a-f]{64}', identity.get('sha256', '')), 'wrong Node binary source/path/hash shape')


def controls(documents, commands, logs, tests, inputs, roster_sha, recording_failures, unreadable):
    selected = documents.get('required-selector-results.json', [])
    require(isinstance(selected, list) and len(selected) <= 49
            and [r.get('selector') for r in selected] == tests[:len(selected)], 'wrong or duplicate selector results')
    identity = documents.get('node-test-binary.json')
    observed_children = [f'required-{i:02d}' for i in range(49) if f'required-{i:02d}' in commands]
    if selected or observed_children:
        control_build(identity, commands, logs, inputs, roster_sha)
    unreadable_files = {row['file'] for row in unreadable}
    rows = []
    for index, selector in enumerate(tests):
        row = {'selector': selector, 'outcome': 'not_executed'}
        label = f'required-{index:02d}'
        command = commands.get(label)
        if command:
            expected_argv = [identity['path'], selector, '--exact', '--show-output', '--test-threads=1']
            require(command['argv'] == expected_argv, 'mismatched per-selector native command')
            observed = selected[index] if index < len(selected) else None
            if observed:
                require(observed['label'] == label and observed['argv'] == expected_argv
                        and observed['binary_sha256'] == identity['sha256']
                        and observed['exit_code'] == command['exit_code']
                        and observed['recorder_exit_code'] == (command['exit_code'] if command['exit_code'] >= 0 else 128 - command['exit_code'])
                        and observed['log_sha256'] == command['log_sha256'], 'selector outcome/hash mismatch')
            checked = subprocess.run([sys.executable, 'scripts/ci/check_required_native_test.py',
                                      str(RECORDS / (label + '.log')), '--test', selector],
                                     cwd=ROOT, capture_output=True, text=True)
            if observed:
                require(checked.returncode == observed['execution_check_exit_code'], 'named execution recheck disagrees')
            passed = command['exit_code'] == checked.returncode == 0
            row.update(outcome='passed' if passed else 'failed', receipt_label=label,
                       aggregate_row_retained=observed is not None,
                       native_exit_code=command['exit_code'], named_reader_exit_code=checked.returncode,
                       named_reader_output=checked.stdout + checked.stderr)
        else:
            artifacts = [name for name in inputs if name in {
                'records/' + label + suffix for suffix in ('.json', '.log', '-recorder.txt', '-execution.txt')}]
            if artifacts or index < len(selected):
                row.update(outcome='unknown', receipt_label=label, native_execution_status='unknown',
                           aggregate_row_retained=index < len(selected), retained_artifacts=artifacts,
                           receipt_state='record_failed' if label in recording_failures else
                           'unreadable_json' if label + '.json' in unreadable_files else 'no_validated_command_receipt',
                           execution_credit=False, pass_credit=False)
        rows.append(row)
    batch = documents.get('required-control-batch.json')
    if batch:
        before = {key: identity[key] for key in ('path', 'bytes', 'sha256')}
        require(batch['schema'] == 'trnm-current49-batch-v1' and batch['complete'] is True
                and batch['executed'] == 49 and len(selected) == len(observed_children) == 49
                and batch['binary_before'] == batch['binary_after'] == before
                and batch['source_before'] == batch['source_after'] == identity['source']
                and batch['runner_sha256'] == identity['runner_sha256'], 'batch completion mismatch')
        require(batch['all_passed'] == all(r['outcome'] == 'passed' for r in rows), 'batch verdict mismatch')
    return {'required': 49, 'executed': len(observed_children), 'passed': sum(r['outcome'] == 'passed' for r in rows),
            'unknown': sum(r['outcome'] == 'unknown' for r in rows),
            'not_observed': sum(r['outcome'] == 'not_executed' for r in rows),
            'executed_count_scope': 'validated current-source command receipts only; unknown observations are excluded',
            'selectors': rows, 'binary': identity,
            'batch_completion': batch,
            'complete': bool(batch and batch['all_passed']),
            'child_process_harnesses_counted': False, 'old_45_execution_results_reused': False}


def collect(output):
    require(not output.exists() and not output.is_relative_to(ROOT), 'output must be new and outside source')
    source = support.source_now()
    tests, roster_sha = support.selected_controls()
    inputs, paths, documents, commands, recording_failures, unreadable, logs = {}, {}, {}, {}, {}, [], {}
    for path in sorted(RECORDS.rglob('*')):
        if path.is_dir():
            continue
        name = path.relative_to(RECORDS).as_posix()
        raw = public_bytes(path)
        inputs['records/' + name], paths['records/' + name] = raw, path
        if path.suffix != '.json':
            continue
        try:
            data = json.loads(raw)
        except (ValueError, UnicodeError):
            unreadable.append({'file': name, 'bytes': len(raw), 'sha256': digest(raw), 'native_execution_status': 'unknown'})
            continue
        documents[name] = data
        if not isinstance(data, dict) or data.get('schema') != 'trnm-pq-native-command-v1':
            continue
        require(data.get('status') != 'running', 'producer still running: ' + name)
        require('/' not in name, 'native command receipts must be at the records root')
        if data.get('status') == 'record_failed':
            recording_failures[path.stem] = data
            continue
        command, logfile = support.checked_receipt(path.stem, source)
        commands[path.stem] = command
        logs[path.stem] = logfile.read_text(errors='replace')
    summaries = {}
    for label, text in logs.items():
        summaries[label] = {
            'rust_summaries': [{'result': r[0], 'passed': int(r[1]), 'failed': int(r[2]),
                                'ignored': int(r[3]), 'measured': int(r[4]), 'filtered_out': int(r[5]),
                                'duration_text': r[6]} for r in RUST_SUMMARY.findall(text)],
            'named_tests': [{'name': n, 'outcome': s} for n, s in NAMED.findall(text)],
            'python_unittest_counts': [int(n) for n in re.findall(r'^Ran (\d+) tests? in ', text, re.MULTILINE)],
            'python_unittest_terminal_lines': re.findall(r'^(?:OK(?: \([^\n]*\))?|FAILED \([^\n]*\))$', text, re.MULTILINE)}
    planned = {}
    for label in PLANNED:
        attempts = [n for n in commands if n == label or n.startswith(label + '-retry')]
        planned[label] = {'observed_receipt_labels': attempts,
                          'outcome': 'no_validated_command_receipt' if not attempts else
                          'successful_exit_observed' if any(commands[n]['exit_code'] == 0 for n in attempts) else 'failed_exit_observed',
                          'scope': 'actual argv is retained; exit status alone is not coverage or security qualification'}
    runner = BASE / 'run_retirement_required_controls.py'
    inputs['external/' + runner.name], paths['external/' + runner.name] = public_bytes(runner), runner
    native = controls(documents, commands, logs, tests, inputs, roster_sha, recording_failures, unreadable)
    benchmark = {'raw_data_present': (RECORDS / 'parameter-observations.jsonl').is_file(),
                 'production_tail_qualified': False, 'candidate_87_activated': False}
    if benchmark['raw_data_present']:
        rawpath = RECORDS / 'parameter-observations.jsonl'
        check = subprocess.run([sys.executable, 'evidence/crypto-profile-20261104/recompute_benchmark.py',
                                str(rawpath)], cwd=ROOT, capture_output=True, text=True)
        benchmark.update(independent_recheck_exit_code=check.returncode,
                         independent_recheck_output=check.stdout + check.stderr, raw_sha256=support.sha256(rawpath))
        runtime = documents.get('parameter-run.json')
        if runtime:
            require(runtime['stdout']['sha256'] == benchmark['raw_sha256']
                    and runtime['stdout']['bytes'] == rawpath.stat().st_size, 'benchmark runtime/raw mismatch')
            benchmark['runtime_observation'] = runtime
        benchmark['recheck_is_new_native_run'] = False
    extra = ['run_retirement_exact.py', 'run-current-pq.sh',
             'run_retirement_parameter_observation.py', 'continuation-loss-notice.json',
             'restore-profile-checkout-receipt.json', 'restore-profile-source-verification.json',
             'prepare_retirement_execution.py', 'retirement-execution-generation.json',
             'prepare_retirement_cache.py', 'retirement-cache/cache-complete.json',
             'retirement-cache/Cargo.lock.snapshot']
    extra.append(Path(__file__).name)
    for name in extra:
        path = BASE / name
        if path.is_file():
            inputs['external/' + name], paths['external/' + name] = public_bytes(path), path
    external_sources = {Path(arg) for command in commands.values() for arg in command['argv']
                        if isinstance(arg, str) and Path(arg).is_absolute()
                        and Path(arg).is_relative_to(BASE) and not Path(arg).is_relative_to(ROOT)
                        and Path(arg).suffix in ('.py', '.sh', '.c', '.rs')}
    if (BASE / 'interop-preparation').is_dir():
        external_sources.update(p for p in (BASE / 'interop-preparation').iterdir()
                                if p.suffix in ('.py', '.sh', '.c', '.rs'))
    for path in sorted(external_sources):
        name = 'external/' + path.relative_to(BASE).as_posix()
        raw = public_bytes(path)
        require(name not in inputs or inputs[name] == raw, 'external source changed during collection: ' + name)
        if name not in inputs:
            inputs[name], paths[name] = raw, path
    source_paths = [support.ROSTER, 'AGENTS.md', 'trillionnium/Cargo.toml', 'trillionnium/Cargo.lock',
                    'scripts/ci/record_pq_native_command.py', 'scripts/ci/check_required_native_test.py',
                    'evidence/crypto-profile-20261104/recompute_benchmark.py']
    for name in source_paths:
        inputs['source-contracts/' + name] = (ROOT / name).read_bytes()
    inputs['source-contracts/commit.raw'] = subprocess.check_output(['git', '--no-replace-objects', 'cat-file', 'commit', COMMIT], cwd=ROOT)
    manifest = {n: {'bytes': len(b), 'sha256': digest(b)} for n, b in sorted(inputs.items())}
    inputs['artifact-manifest.json'] = encode({'schema': 'trnm-current-raw-members-v1', 'members': manifest})
    reproduction = {'schema': 'trnm-current-crypto-profile-observations-v1', 'status': 'HOLD',
                    'assembled_utc': datetime.now(timezone.utc).isoformat(), 'source': source,
                    'commands': commands, 'recording_failures': recording_failures,
                    'failed_command_labels': sorted(n for n, c in commands.items() if c['exit_code']),
                    'unreadable_json_observations': unreadable, 'planned_command_inventory': planned,
                    'test_statistics_by_command': summaries, 'required_controls': native,
                    'required_roster_sha256': roster_sha, 'benchmark': benchmark,
                    'test_count_scope': 'actual terminal summaries; overlapping/duplicate runs are not distinct coverage',
                    'prior_unarchived_885_observations': {'recovered': False, 'current_execution_credit': False,
                                                       'notice_included': 'external/continuation-loss-notice.json' in inputs},
                    'native_acceptance_complete': False, 'full_node_regression_claimed': False,
                    'candidate_87_activated': False, 'whole_chain_pq_qualified': False,
                    'qualification_gates': {n: 'UNQUALIFIED' for n in ('authorization', 'proof_pq128',
                        'quantum_mining_fork_choice', 'migration_and_rollback', 'capacity_and_invalid_input', 'independent_end_to_end')},
                    'raw_members': manifest}
    require(support.source_now() == source, 'source changed during collection')
    for name, path in paths.items():
        require(public_bytes(path) == inputs[name], 'input changed during collection: ' + name)
    temporary = Path(tempfile.mkdtemp(prefix='retirement-evidence-', dir=output.parent))
    try:
        archive = temporary / 'raw-observations.tar.gz'
        with archive.open('wb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
                for name, raw in sorted(inputs.items()):
                    info = tarfile.TarInfo(name); info.size = len(raw); info.mode = 0o644
                    tar.addfile(info, io.BytesIO(raw))
        reproduction['raw_archive'] = {'file': archive.name, 'bytes': archive.stat().st_size,
                                       'sha256': support.sha256(archive), 'members': len(inputs)}
        (temporary / 'reproduction.json').write_bytes(encode(reproduction))
        if benchmark['raw_data_present']:
            (temporary / 'parameter-observations.jsonl').write_bytes(inputs['records/parameter-observations.jsonl'])
        require(not output.exists(), 'output appeared during collection')
        os.rename(temporary, output)
    except BaseException:
        shutil.rmtree(temporary, ignore_errors=True)
        raise
    print(json.dumps({'output': str(output), 'status': 'HOLD', 'command_receipts': len(commands),
                      'failed': reproduction['failed_command_labels'], 'required_controls_passed': native['passed']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=BASE / 'retirement-evidence-staging')
    args = parser.parse_args()
    try:
        collect(args.output.absolute())
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        print('REFUSED: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
