import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import traceback

ROOT = Path('/home/qian-qi/chain-daa-monotone-20261111-7f73')
REPO = ROOT / 'publisher'
OUT = ROOT / 'native-intermediate-publication-v1'
BASE = 'd23488c5f9b4a6696c3799b12f14b8af0a1b81fc'
BASE_TREE = '72b106b4458299c37da146b0218b8f5276195b6d'
BRANCH = 'fix/chain-daa-monotone-witness-20261111-7f73'
SLUG = 'TrillionniumFoundation/Trillionnium-Chain'
PREFIX = 'evidence/pon-monotone-daa-20261111/'
ARCHIVE = ROOT / 'native-run-d23488c5-v1.tar.gz'
ARCHIVE_SHA = '6c33da56842862608e365acb7c69d72175538556a2a76b74254f7b0357de9c81'
DESCRIPTOR = ROOT / 'native-run-d23488c5-v1-archive.json'
DESCRIPTOR_SHA = '74dbde813897144c0d220584eb1731c72ccd5f8ff597c0de85924b9eb7939a15'
OUT.mkdir(exist_ok=False)
RECORDS = []


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def run(label, args, *, required=True):
    started = now()
    print(json.dumps({'phase': label, 'state': 'started', 'at': started}), flush=True)
    process = subprocess.run(args, cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout = OUT / (label + '.stdout.log')
    stderr = OUT / (label + '.stderr.log')
    stdout.write_bytes(process.stdout)
    stderr.write_bytes(process.stderr)
    RECORDS.append({'label': label, 'argv': args, 'cwd': str(REPO),
                    'returncode': process.returncode, 'started_utc': started, 'finished_utc': now(),
                    'stdout_path': str(stdout), 'stderr_path': str(stderr),
                    'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr)})
    (OUT / 'commands.json').write_text(json.dumps(RECORDS, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'phase': label, 'state': 'completed', 'returncode': process.returncode}), flush=True)
    if required and process.returncode:
        raise RuntimeError(label + ' failed; original streams retained')
    return process


def git(*args):
    return ['git', '-c', 'credential.helper=', '-c', 'credential.helper=!gh auth git-credential', *args]


def check_source(label, commit):
    run(label, ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                '--expected-head', commit, '--output', str(OUT / (label + '.json'))])


result = {'schema': 'pon-native-intermediate-publication-v1', 'executed_source_commit': BASE,
          'executed_source_tree': BASE_TREE, 'native_execution_repeated': False,
          'reader_execution_started_by_this_script': False, 'public_network_qualification': False,
          'production_activation': False, 'publication_complete': False}
try:
    identity = json.loads(run('github-identity', ['gh', 'api', 'user', '--jq', '{login:.login,id:.id}']).stdout)
    assert identity['login'] == 'ProfHepta' and type(identity['id']) is int
    assert run('initial-head', ['git', 'rev-parse', 'HEAD', 'HEAD^{tree}']).stdout.decode().splitlines() == [BASE, BASE_TREE]
    assert run('initial-branch', ['git', 'branch', '--show-current']).stdout.decode().strip() == BRANCH
    assert not run('initial-clean', ['git', 'status', '--porcelain', '--untracked-files=all']).stdout.strip()
    assert run('remote-before', git('ls-remote', '--heads', 'origin', 'refs/heads/' + BRANCH)).stdout.decode().split()[0] == BASE
    run('preflight-before-edit', ['bash', 'scripts/project-preflight.sh'])
    check_source('source-before', BASE)
    assert ARCHIVE.stat().st_size == 4657951 and sha(ARCHIVE) == ARCHIVE_SHA
    assert sha(DESCRIPTOR) == DESCRIPTOR_SHA
    descriptor = json.loads(DESCRIPTOR.read_text())
    expected_descriptor = {'path': str(ARCHIVE), 'bytes': 4657951, 'sha256': ARCHIVE_SHA}
    expected_descriptor_bytes = (json.dumps(expected_descriptor, sort_keys=True, indent=2) + '\n').encode()
    assert descriptor == expected_descriptor and DESCRIPTOR.read_bytes() == expected_descriptor_bytes
    with tarfile.open(ARCHIVE, 'r:gz') as archive:
        def read_json(name):
            entry = archive.getmember('native-run-d23488c5-v1/' + name)
            assert entry.isfile()
            return json.load(archive.extractfile(entry))
        native_result = read_json('result.json')
        commands = read_json('commands.json')
        assert native_result['tested_commit'] == BASE and native_result['tested_tree'] == BASE_TREE
        assert native_result['required_commands_passed'] is True and native_result['source_ready'] is True
        assert native_result['failed_steps'] == []
        for label in ['native-daa-four-tests', 'clippy-daa-all-features', 'cargo-fmt-check', 'source-before', 'source-after']:
            selected = [item for item in commands if item['label'] == label]
            assert len(selected) == 1 and selected[0]['returncode'] == 0
        native_log = archive.extractfile('native-run-d23488c5-v1/native-daa-four-tests.log').read()
        assert b'test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 65.77s' in native_log
        for name in ['source-before.json', 'source-after.json']:
            source = read_json(name)
            assert source['tested_commit'] == BASE and source['tested_tree'] == BASE_TREE
            assert source['tracked_worktree_verified'] is True
    target = REPO / PREFIX / 'native'
    target.mkdir(exist_ok=False)
    for source, name in [(ARCHIVE, ARCHIVE.name), (DESCRIPTOR, DESCRIPTOR.name)]:
        destination = target / name
        with source.open('rb') as src, destination.open('xb') as dst:
            shutil.copyfileobj(src, dst)
        assert destination.stat().st_size == source.stat().st_size and sha(destination) == sha(source)
    observation = {
        'schema': 'pon-native-recovery-publication-v1', 'phase': 'intermediate-original-byte-recovery',
        'executed_source_commit': BASE, 'executed_source_tree': BASE_TREE,
        'native_archive': {'file': ARCHIVE.name, 'bytes': 4657951, 'sha256': ARCHIVE_SHA},
        'native_descriptor': {'file': DESCRIPTOR.name, 'bytes': len(expected_descriptor_bytes), 'sha256': DESCRIPTOR_SHA},
        'native_tests': {'passed': 4, 'failed': 0, 'ignored': 0, 'filtered_out': 0, 'test_body_seconds': 65.77},
        'affected_all_feature_clippy': 'PASS', 'cargo_formatting': 'PASS',
        'original_native_source_before_after': 'PASS',
        'independent_reader_status_at_publication': 'PENDING',
        'native_execution_repeated': False, 'logical_validation_clock_schedule': True,
        'wall_clock_mining_cadence_measured': False, 'quantum_attack_profitability_measured': False,
        'public_network_qualification': False, 'production_activation': False,
        'qualification': 'HOLD_NO_GO', 'unknown_environment_inputs': 18, 'open_proof_obligations': 13,
        'observed_utc': now(),
        'purpose': 'Publish sealed original bytes for reliable retrieval; implementation remains the executed source.',
    }
    (target / 'recovery-publication.json').write_text(json.dumps(observation, sort_keys=True, indent=2) + '\n')
    paths = [PREFIX + 'native/' + name for name in [ARCHIVE.name, DESCRIPTOR.name, 'recovery-publication.json']]
    run('stage-original-evidence', ['git', 'add', '--', *paths])
    assert set(run('staged-paths', ['git', 'diff', '--cached', '--name-only']).stdout.decode().splitlines()) == set(paths)
    run('diff-check', ['git', 'diff', '--cached', '--check'])
    run('non-evidence-bytes-before', ['git', 'diff', '--exit-code', BASE, '--', '.', ':(exclude)' + PREFIX + '**'])
    assert not run('untracked-before-commit', ['git', 'ls-files', '--others', '--exclude-standard']).stdout.strip()
    run('preflight-before-commit', ['bash', 'scripts/project-preflight.sh'])
    email = str(identity['id']) + '+ProfHepta@users.noreply.github.com'
    run('commit-original-evidence', ['git', '-c', 'user.name=ProfHepta', '-c', 'user.email=' + email,
                                    'commit', '-m', 'docs(pon): retain original native DAA archive for recovery'])
    head = run('published-identity', ['git', 'rev-parse', 'HEAD', 'HEAD^{tree}', 'HEAD^']).stdout.decode().splitlines()
    assert head[2] == BASE
    changed = run('changed-paths', ['git', 'diff', '--name-only', BASE, head[0]]).stdout.decode().splitlines()
    assert set(changed) == set(paths) and all(path.startswith(PREFIX) for path in changed)
    run('non-evidence-bytes-after', ['git', 'diff', '--exit-code', BASE, head[0], '--', '.', ':(exclude)' + PREFIX + '**'])
    check_source('source-after', head[0])
    run('preflight-before-push', ['bash', 'scripts/project-preflight.sh'])
    assert run('remote-before-push', git('ls-remote', '--heads', 'origin', 'refs/heads/' + BRANCH)).stdout.decode().split()[0] == BASE
    run('push-evidence', git('push', 'origin', BRANCH), required=False)
    assert run('remote-after-push', git('ls-remote', '--heads', 'origin', 'refs/heads/' + BRANCH)).stdout.decode().split()[0] == head[0]
    result.update(evidence_commit=head[0], evidence_tree=head[1], changed_paths=changed,
                  non_evidence_bytes_unchanged_from_executed_source=True, archive_sha256=ARCHIVE_SHA,
                  descriptor_sha256=DESCRIPTOR_SHA, remote_head_verified=head[0])
    body = (ROOT / 'daa-draft-pr-body.md').read_text()
    body = body.replace('Native compilation observed; final tests and reader outcomes pending',
                        'Four native tests passed (0 failures/ignored/filtered; 65.77s test body); independent readers pending')
    body = body.replace('Pending in the same original native execution',
                        'Affected DAA fixture, all features, -D warnings: passed')
    body = body.replace('106 + 13 controls still running at preparation of this draft',
                        '119 controls passed; retained campaign and exact-source before/after checks passed')
    body = body.replace('Final native/reader results and raw evidence will be added in an evidence-only child commit and this validation table will be updated.',
                        'The sealed original native bytes are now available in the intermediate evidence-only child. Independent reader results and the consolidated local evidence will be added in the final evidence commit.')
    body += '\n## Original native bytes available for recovery\n\nIntermediate evidence commit `' + head[0] + '` adds only the original native archive, its exact descriptor and a dated recovery observation. The implementation still matches executed source `' + BASE + '` byte-for-byte outside the evidence prefix. Independent readers remain pending; this publication does not run native tests again or grant qualification.\n'
    body_path = OUT / 'pr-body.md'
    body_path.write_text(body)
    run('pr-edit', ['gh', 'pr', 'edit', '920', '--repo', SLUG, '--body-file', str(body_path)], required=False)
    pr = json.loads(run('pr-readback', ['gh', 'pr', 'view', '920', '--repo', SLUG,
                                      '--json', 'headRefOid,baseRefName,isDraft,body,url']).stdout)
    assert pr['headRefOid'] == head[0] and pr['baseRefName'] == 'fix/chain-joint-production-tail-20261110-8e76'
    assert pr['isDraft'] is True and pr['body'] == body
    result.update(publication_complete=True, pull_request=pr['url'])
except BaseException as error:
    (OUT / 'exception.log').write_text(traceback.format_exc())
    result.update(error_type=type(error).__name__, error=str(error))
finally:
    result['finished_utc'] = now()
    (OUT / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True), flush=True)
sys.exit(0 if result.get('publication_complete') else 1)
