import pathlib,subprocess,json,hashlib,os,time
base=pathlib.Path('/home/qian-qi/worktrees/hepta-pq4729-validation-20261104');repo=base/'source';source=json.loads((base/'source-before.json').read_text());assert source['commit']=='5fa90c21dbcd642ff9101951531c5758c683fdac' and source['git_diff_exit']==0
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==source['commit']
env={**os.environ,'PATH':'/home/qian-qi/.cargo/bin:'+os.environ.get('PATH',''),'CARGO_TARGET_DIR':str(base/'target'),'CARGO_BUILD_JOBS':'2'}
for label,args in [('contracts-native',['just','test','-p','codex-hepta-contracts','--locked']),('contracts-strict-clippy',['just','clippy','-p','codex-hepta-contracts','--locked','--','-D','warnings'])]:
 log=base/(label+'.log');start=time.monotonic();print(json.dumps({'started':label,'argv':args,'source':source['commit'],'target':env['CARGO_TARGET_DIR']}),flush=True)
 with log.open('wb') as out:
  result=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 data=log.read_bytes();unchanged=subprocess.call(['git','-C',str(repo),'diff','--quiet','HEAD'])==0
 receipt={'label':label,'argv':args,'source':source,'returncode':result.returncode,'seconds':time.monotonic()-start,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'tracked_source_unchanged':unchanged,'native_attempt_not_retry':True}
 (base/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 if not unchanged:raise SystemExit(3)
print(json.dumps({'complete':True}),flush=True)