from pathlib import Path
import subprocess,json,time,resource,sys,traceback
base=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');base.mkdir(exist_ok=False);out=base/'preparation-1';out.mkdir();(out/'owner.py').write_text(sys.argv[1])
prior=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b/source');src=base/'source';head='f0a8364118df01113c14d6a81fbb6fdb6210e4ff';branch='fix/chain-native-first-graph-host-20261119-2e9b';res={'schema':'chain-next-isolated-source-v1','parent':head,'source':str(src),'stages':[],'complete':False}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,cmd,cwd):
 start=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(cmd,cwd=cwd,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':cmd,'cwd':str(cwd),'exit_code':rc,'wall_seconds':time.monotonic()-start,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['stages'].append(row);save();print(json.dumps(row),flush=True);assert rc==0
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=prior,text=True).strip()=='3db79eb2682ba3bcbbf33557c5eee3b67731028f'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=prior)
 run('original-preflight',['bash','scripts/project-preflight.sh'],prior)
 remote=subprocess.check_output(['git','remote','get-url','origin'],cwd=prior,text=True).strip()
 run('clone-isolated',['git','clone','--shared','--no-checkout',str(prior),str(src)],base)
 run('remote',['git','remote','set-url','origin',remote],src)
 sparse=Path(subprocess.check_output(['git','rev-parse','--git-path','info/sparse-checkout'],cwd=prior,text=True).strip())
 if not sparse.is_absolute():sparse=prior/sparse
 raw=sparse.read_bytes();(out/'original-sparse-checkout').write_bytes(raw)
 run('sparse-config',['git','config','core.sparseCheckout','true'],src)
 target=src/'.git/info/sparse-checkout';target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 run('fetch-evidence-parent',['git','fetch','--no-write-fetch-head','origin',head],src)
 run('checkout',['git','checkout','-b',branch,head],src)
 run('preflight',['bash','scripts/project-preflight.sh'],src)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=src)
 res['head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip();res['tree']=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=src,text=True).strip();assert res['head']==head and res['tree']=='592753ff6410f74bbf3042d774aacaf70f83a808'
 res['complete']=True;save();print(json.dumps(res),flush=True)
except BaseException as exc:
 res['error']=repr(exc);save();(out/'error.log').write_text(traceback.format_exc());raise
