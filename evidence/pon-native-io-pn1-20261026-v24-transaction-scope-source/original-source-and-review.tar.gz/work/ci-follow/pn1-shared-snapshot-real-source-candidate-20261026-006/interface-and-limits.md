# PN1 transaction-boundary source candidate 006

This candidate remains inside PN1 and is based on root Chain `070607b3173e87d0bd5cb9e400198627af7c3405`. It narrows same-connection `COMMIT; BEGIN` ABA acceptance. It has not been compiled or executed. All native/caller/full-campaign qualification flags remain false. Original failed observations and budgets remain unchanged.

## Interface and integration

`trnm_sqlite_io_boundary::TransactionScope::capture(&Connection)` returns an opaque scope that borrows that exact live connection. `scope.unchanged()` accepts only if a real executed `SELECT 0` still reaches the same observer and its transaction-control counter is unchanged. The caller cannot construct the scope, provide another connection at verification, reset its epoch, or detach it from the borrowed connection. Nested scopes share one observer. The held factory installs the observer in `NativeIoLease::finish`; legacy codec fixtures install it lazily and obtain no held/native authority.

The observer belongs to SQLite connection clientdata under a fresh runtime-only key. It is not a signed/stored domain and does not change Snapshot serialization or settings/W1. Every actual `SQLITE_TRACE_STMT` event increments a statement counter. Executed first tokens BEGIN, COMMIT, END, ROLLBACK, SAVEPOINT and RELEASE increment a separate monotone counter. Failed control executions are refused conservatively. Syntax rejected before execution does not generate an epoch transition. `sqlite3_sql(P)` identifies the actual prepared statement, including prepared/cached reuse; trace X may be a synthetic comment and is ignored. EXPLAIN statements are excluded using SQLite's own isexplain API. No commit hook is treated as a read-only identity fence.

Node captures after its own BEGIN and before callbacks. Borrowed/owned read scopes check before returning; the owned read still performs its original explicit rollback/first-error cleanup. `final_read` retains its original changes/autocommit check and adds the execution scope. Both present and absent loads, including callback-error paths, check the encompassing scope. Namespace, full State/COW/history/raw-row checks are retained.

## Source reasoning requiring independent review

The frozen exact SQLite3.51.3 C source implements STMT trace in OP_Init/OP_Trace at execution. Its clientdata destructor runs on allocation failure, replacement or close; BUSY sqlite3_close returns before clientdata destruction. Actual sqlite3Close invokes clientdata destructors before setting ZOMBIE. The destructor clears trace before freeing its stable Box, including the close_v2 ordering; it executes no SQL, and its trace setter uses the existing SQLite connection mutex. This is pinned-version source reasoning, not a portable lifecycle/native execution proof. SQLite's general API does not promise destructor ordering, so a future SQLite change requires review.

Lookup verifies the private observer's exact handle, creator PID and sticky-fault state. Statement callbacks independently verify their actual sqlite3_db_handle. Safe Connection borrowing prevents close or cross-thread shared use during capture/check. The observer does not use global VFS state, so another connection's legitimate commit cannot increment this connection's epoch. No scope destructor owns the observer; SQLite owns exactly one Box until close. On clientdata OOM SQLite owns its destructor call, preventing a second free by Rust.

Both counters use checked monotone increments; overflow makes failure sticky instead of wrapping to an earlier valid epoch. Trace replacement is detected by the real SELECT probe and marks failure sticky. The trace callback does no allocation, SQL execution, lock acquisition, user closure invocation or panic-producing unchecked indexing. It uses statement accessors and atomics only. The destructor deallocates only its own Box after clearing the callback. These facts need compiler/native confirmation and adversarial review; no FFI safety qualification is asserted here.

The first-token scanner follows the pinned ASCII tokenizer: five leading whitespace bytes; VT only as continuation of a whitespace token, not at its start; nonnested block comments, line comments through LF, BOM, and leading empty semicolons. Identifier continuation includes ASCII letters/digits/$/underscore and bytes >=128. Quoted text and keyword prefixes are not transaction tokens. Scanner/parser equivalence is a review obligation, not an assertion that all future SQLite grammar is covered.

## Explicit limits and acceptance status

Fourteen new source controls cover readonly ABA with equal counters/schema, cached END prepared before installation and reused, control attempts and later multi-statement errors, savepoints, normal nested reads and a foreign connection, EXPLAIN/malformed SQL, trace replacement, overflow/PID/foreign statement refusal, connection lifetime, borrowed/owned Node reads, both present/absent load callbacks, first-error preservation and the non-undo boundary. Every control is uncompiled and unexecuted. Private perturbations in mechanism tests do not qualify a public/held caller. The other-connection source control uses two distinct databases; same-file WAL concurrent-reader qualification remains OPEN.

**Post-COMMIT persistent effects remain OPEN.** Trace is observation at execution start and does not veto or undo completed COMMIT. Returning an owner-stop error cannot restore earlier data or retract any external side effect. The new committed-control source assertion only describes expected SQLite rollback behavior after a new transaction; it is not a crash/persistence certification. The unread retained-graph coordinated-reseal limitation from R5 remains OPEN.

The admitted in-process trust boundary excludes arbitrary unsafe FFI that replaces private clientdata or fabricates callback memory. An existing unrelated trace channel at first lazy installation is not preserved; factory connections are fresh and this scope owns their single trace channel. Later tracer replacement fails closed at the execution probe, but this is not protection against a process that can forge private native state. No parser/hook code is a process sandbox.

Remaining gates: independent source review; compilation/strict Clippy/type/lifetime checks on exact source; bounded approved mechanism/native controls; original public prepare and real held caller provenance; all original caps/deadlines/resource/terminal receipts; strict independent reader; full4097 attack. No original1200, DPoP/Bazel or expired campaign window was restarted. No native run, root/ROG edit, commit or push occurred. Existing PN1/PN0–PN6 milestones, production guards, CI and merge NO_GO are unchanged.

## Primary sources

- [SQLite trace registration](https://www.sqlite.org/c3ref/trace_v2.html)
- [STMT trace execution event](https://www.sqlite.org/c3ref/c_trace.html)
- [Connection client data and destructor](https://www.sqlite.org/c3ref/get_clientdata.html)
- [Prepared statement SQL lifetime](https://www.sqlite.org/c3ref/expanded_sql.html)
- [EXPLAIN setting](https://www.sqlite.org/c3ref/stmt_isexplain.html)
- [Prepare-time authorizer](https://www.sqlite.org/c3ref/set_authorizer.html)
- [Commit/rollback hook contract](https://www.sqlite.org/c3ref/commit_hook.html)
- [Connection close and zombie behavior](https://www.sqlite.org/c3ref/close.html)
- [Transaction grammar](https://www.sqlite.org/lang_transaction.html)
- [Savepoint grammar](https://www.sqlite.org/lang_savepoint.html)

The actual pinned amalgamation and line-numbered excerpts are frozen in primary/. The actual C write-transaction condition is the basis for refusing to assume commit-hook coverage for readonly transactions.
