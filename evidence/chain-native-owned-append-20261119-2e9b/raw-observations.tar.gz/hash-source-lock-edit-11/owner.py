from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback,copy
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=s.parent/'hash-source-lock-edit-11';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);res={'schema':'chain-current-hash-source-map-only-repair-v1','complete':False,'stages':[]}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();c=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as a,(out/(name+'.stderr')).open('xb') as b:rc=subprocess.call(args,cwd=s,stdout=a,stderr=b)
 d=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':d.ru_utime-c.ru_utime,'child_system_cpu_seconds':d.ru_stime-c.ru_stime};res['stages'].append(row);save();print(json.dumps(row),flush=True);return rc
def one(t,a,b):assert t.count(a)==1,(a,t.count(a));return t.replace(a,b,1)
try:
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 audit=json.loads((s.parent/'hash-source-audit-10/RESULT.json').read_text())
 assert len(audit['rows'])==31 and all(r['working_tree_equals_parent'] for r in audit['rows'])
 assert [r['path'] for r in audit['changed']]==['trillionnium/crates/trnm-pon-node/src/store.rs']
 assert audit['original_reader_exit']==2
 rel='trillionnium/crates/trnm-pon-node/src/store.rs';row=audit['changed'][0]
 paths=['config/pon/hash-use-contract-v1.json','scripts/ci/hash_use_contract.py','scripts/ci/test_hash_use_contract.py','docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md','config/pon/pq-cross-branch-corpus-v1.json']
 before={p:(s/p).read_bytes() for p in paths}
 for p,data in before.items():
  q=out/'before'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
 manifest=json.loads(before[paths[0]]);old=copy.deepcopy(manifest)
 assert manifest['source_files'][rel]==row['pin']
 manifest['source_files'][rel]=row['actual']
 assert len(manifest['source_files'])==31 and len(manifest['uses'])==19
 semantic=lambda x:{k:v for k,v in x.items() if k!='source_files'}
 canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
 assert semantic(manifest)==semantic(old)
 assert hashlib.sha256(canon(semantic(manifest))).hexdigest()=='29189f8e96a255472577479d46204b2b403a1f8e27806da6aa616e417ced0b5b'
 newlock=hashlib.sha256(canon(manifest['source_files'])).hexdigest()
 (s/paths[0]).write_text(json.dumps(manifest,indent=2)+'\n')
 source=before[paths[1]].decode()
 source=one(source,'REVIEWED_SOURCE_MAP_SHA256 = "5e0801d22adab09c2104b568a8427dafdc0b43b2124951fc1e67a968e49fc3c0"','# The owned-append candidate retains all 31 source paths and 19 uses. Only the\n# previously stale store.rs identity changes; the historical anchors and exact\n# semantic digest remain fixed. A fresh literal rejects the prior source map.\nREVIEWED_SOURCE_MAP_SHA256 = "'+newlock+'"')
 (s/paths[1]).write_text(source)
 test=before[paths[2]].decode()
 addition='''    def test_previous_store_source_pin_cannot_qualify_the_current_map(self):
        data = self.data()
        self.assertEqual(len(data["source_files"]), 31)
        self.assertEqual(len(data["uses"]), 19)
        data["source_files"]["trillionnium/crates/trnm-pon-node/src/store.rs"] = {
            "bytes": 394623,
            "sha256": "9d79fd3c37db4a664d0a01b89e943276e07d2800cc64cb4986a1452ccf8fb820",
        }
        with self.assertRaisesRegex(contract.ContractError, "source map differs"):
            contract.validate_manifest(data)

'''
 test=one(test,'    def test_source_map_cannot_self_repin_changed_source(self):',addition+'    def test_source_map_cannot_self_repin_changed_source(self):')
 (s/paths[2]).write_text(test)
 plan=before[paths[3]].decode()
 plan+='\nThe original repository-truth gate also exposed a stale hash-use source map: only store.rs differed across its 31 actual parent/current sources. The old 394623-byte 9d79fd3c identity is retained as a rejection control; the current 397703-byte cb063dff identity matches the unchanged parent source. The new literal map lock is '+newlock+'. All 19 uses, 31 paths, exact semantic digest 29189f8e96a255472577479d46204b2b403a1f8e27806da6aa616e417ced0b5b, historical e4abb172 review anchor and HOLD_NO_GO/unknown security qualifications remain unchanged. Original repository-truth failures and the original reader refusal remain retained.\n'
 (s/paths[3]).write_text(plan)
 corpus=json.loads(before[paths[4]]);updates=[]
 for relpath in paths[:4]:
  assert relpath in corpus['pinned_blobs']
  actual=subprocess.check_output(['git','hash-object','-w',str(s/relpath)],cwd=s,text=True).strip()
  updates.append({'path':relpath,'previous':corpus['pinned_blobs'][relpath],'current':actual});corpus['pinned_blobs'][relpath]=actual
 (s/paths[4]).write_text(json.dumps(corpus,indent=2)+'\n')
 subprocess.check_call(['git','hash-object','-w',str(s/paths[4])],cwd=s,stdout=subprocess.DEVNULL)
 patch=subprocess.check_output(['git','diff','HEAD','--']+paths,cwd=s);(out/'source.patch').write_bytes(patch)
 res.update(source_map_lock=newlock,semantic_identity_unchanged=True,sources=31,uses=19,qualification=manifest['qualification'],pin_change=row,corpus_changes=updates,patch_bytes=len(patch),patch_sha256=hashlib.sha256(patch).hexdigest());save()
 for name,args in [('current-reader',['python3','-B','scripts/ci/hash_use_contract.py']),('all-original-and-stale-map-controls',['python3','-B','scripts/ci/test_hash_use_contract.py']),('exact-current-cross-branch',['python3','-B','scripts/ci/check_pq_research_integration.py']),('diff-check',['git','diff','--check'])]:run(name,args)
 res['complete']=True;res['all_stages_passed']=all(x['exit_code']==0 for x in res['stages']);save();print(json.dumps(res,indent=2))
except BaseException as e:res['error']=repr(e);save();traceback.print_exc();raise
