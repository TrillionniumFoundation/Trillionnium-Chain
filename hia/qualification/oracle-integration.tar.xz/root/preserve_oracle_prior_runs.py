"""Losslessly archive completed prior runs before removing only their expanded copies."""
from pathlib import Path
import hashlib, io, json, lzma, shutil, stat, tarfile

BASE = Path('/workspace/scratch/a638c5cc4765/oracle-work')
OUT = BASE / 'retained-prior-runs'
OUT.mkdir(mode=0o700)

def identity(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(data)
    return {'bytes': path.stat().st_size, 'sha256': h.hexdigest()}

for label in ('qualification-v2', 'qualification-v3', 'qualification-v4-final', 'qualification-v5-final'):
    source = BASE / label
    assert source.parent == BASE and source.is_dir() and not source.is_symlink()
    rows = {}
    for path in sorted(source.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file():
            st = path.stat()
            assert stat.S_ISREG(st.st_mode), path
            rows[path.relative_to(source).as_posix()] = {
                **identity(path), 'mode': stat.S_IMODE(st.st_mode),
                'mtime_ns': st.st_mtime_ns, 'inode': st.st_ino, 'device': st.st_dev,
            }
        else:
            assert path.is_dir(), path
    raw = (json.dumps({'schema': 'trnm.oracle.completed-run-preservation.v1',
        'source': str(source), 'files': rows}, sort_keys=True, indent=2) + '\n').encode()
    target = OUT / (label + '.tar.xz')
    assert not target.exists()
    with target.open('xb') as stream:
        with tarfile.open(fileobj=stream, mode='w:xz', format=tarfile.USTAR_FORMAT, preset=6) as archive:
            for name, row in rows.items():
                info = tarfile.TarInfo('execution/' + name)
                info.size = row['bytes']; info.mode = row['mode']; info.mtime = 0
                with (source / name).open('rb') as data:
                    archive.addfile(info, data)
            info = tarfile.TarInfo('PRESERVATION.json')
            info.size = len(raw); info.mode = 0o600; info.mtime = 0
            archive.addfile(info, io.BytesIO(raw))
    seen = set()
    with lzma.open(target, 'rb') as stream:
        while True:
            header = stream.read(512)
            assert len(header) == 512
            if header == bytes(512):
                assert stream.read(512) == bytes(512)
                for data in iter(lambda: stream.read(1024 * 1024), b''):
                    assert not any(data)
                break
            item = tarfile.TarInfo.frombuf(header, 'utf-8', 'strict')
            assert item.isfile() and item.name not in seen
            if item.name == 'PRESERVATION.json':
                expected = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'mode': 0o600}
            else:
                assert item.name.startswith('execution/')
                expected = rows[item.name[len('execution/'):]]
            assert item.size == expected['bytes'] and item.mode == expected['mode']
            h = hashlib.sha256(); remaining = item.size
            while remaining:
                data = stream.read(min(remaining, 1024 * 1024)); assert data
                remaining -= len(data); h.update(data)
            assert h.hexdigest() == expected['sha256']
            assert not any(stream.read((-item.size) % 512))
            seen.add(item.name)
    assert seen == {'execution/' + name for name in rows} | {'PRESERVATION.json'}
    decoder = lzma.LZMADecompressor()
    with target.open('rb') as stream:
        while not decoder.eof:
            data = stream.read(65536) if decoder.needs_input else b''
            assert data or not decoder.needs_input
            decoder.decompress(data, max_length=1024 * 1024)
        assert not decoder.unused_data and not stream.read(1)
    assert {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()} == set(rows)
    for name, row in rows.items():
        path = source / name; st = path.stat()
        assert not path.is_symlink() and (st.st_ino, st.st_dev, st.st_mtime_ns, stat.S_IMODE(st.st_mode)) == (
            row['inode'], row['device'], row['mtime_ns'], row['mode'])
        assert identity(path) == {'bytes': row['bytes'], 'sha256': row['sha256']}
    receipt = {'schema': 'trnm.oracle.completed-run-cleanup.v1', 'status': 'PRESERVED_AND_VERIFIED',
        'source': str(source), 'archive': str(target), 'archive_identity': identity(target),
        'files': len(rows), 'preserved_file_bytes': sum(row['bytes'] for row in rows.values()),
        'every_file_read_back': True, 'single_xz_stream': True, 'complete_zero_tar_tail': True,
        'source_unchanged_before_cleanup': True, 'uncompressed_copy_removed': False}
    receipt_path = OUT / (label + '.json')
    receipt_path.write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    shutil.rmtree(source)
    receipt['uncompressed_copy_removed'] = not source.exists()
    assert receipt['uncompressed_copy_removed']
    receipt['free_bytes_after'] = shutil.disk_usage(BASE).free
    receipt_path.write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
