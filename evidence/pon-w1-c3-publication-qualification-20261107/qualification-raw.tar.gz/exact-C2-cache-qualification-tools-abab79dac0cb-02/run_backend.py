#!/usr/bin/env python3
"""Exact frozen-integration backend qualification; no proof or winner dispatch."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time
import tomllib

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
REPO = ROOT / 'integration-repo'
OUT = None
TARGET = None
CACHE_SETUP = None
TOOLCHAIN = Path('/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
COMMIT = None
TREE = None
MANIFEST = 'formal/pon-nakamoto-v1/w1_zkvm/Cargo.toml'
PACKAGE = 'trnm-w1-zk-host-v2'
RUNNER_NAME = 'w1-staged-prover-v2'
GUEST_SHA = '25718312ec3c6f5219d832e3516adfb5f82983156f669c5e7daa15bd22d1798f'
LOCK_SHA = '173776355b019994c22b355aa22f8130b63b3a3c7ab7fba3d1e70af0a15d6a3f'
IMAGE = [1958252411, 3287394615, 1805488136, 1516578702, 78549041, 790278610, 301018785, 4279049364]
OWNED = [
    'formal/pon-nakamoto-v1/w1_zkvm/host/src/bin/w1-staged-prover.rs',
    *['formal/pon-nakamoto-v1/w1_zkvm/host/src/bin/w1_staged_prover/' + name for name in
      ('schedule.rs', 'schedule_tests.rs', 'recursion_tests.rs', 'parallel_segments.rs',
       'parallel_segments_tests.rs', 'guest_identity.rs')],
    'formal/pon-nakamoto-v1/w1_zkvm/host-v2/Cargo.toml',
    'formal/pon-nakamoto-v1/w1_zkvm/methods-v2/Cargo.toml',
    'formal/pon-nakamoto-v1/w1_zkvm/methods-v2/build.rs',
    'formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock',
    'formal/pon-nakamoto-v1/w1_zkvm/RETAINED_V2_GUEST.md',
    'evidence/pon-w1-backend-sdk-20261107/fixed-sdk-contract.json',
    'formal/pon-nakamoto-v1/w1_zkvm/methods/guest/Cargo.lock',
    'formal/pon-nakamoto-v1/w1_zkvm/methods/guest-v2/Cargo.lock',
    'formal/pon-nakamoto-v1/w1_v2_verifier/src/image.rs',
    'evidence/pon-w1-full-v2-20261105/guest.bin',
]


def save(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def save_json(path, value):
    save(path, (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode())


def record(path):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode), str(path)
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
            size += len(block)
    last = path.lstat()
    keys = ('st_dev', 'st_ino', 'st_size', 'st_mode', 'st_mtime_ns', 'st_ctime_ns')
    assert all(getattr(first, key) == getattr(last, key) for key in keys), 'changed while read: ' + str(path)
    assert size == first.st_size
    return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest(),
            'mode': stat.S_IMODE(first.st_mode), 'mtime_ns': first.st_mtime_ns,
            'ctime_ns': first.st_ctime_ns, 'inode': first.st_ino}


def source_identity(path):
    value = json.loads(path.read_bytes())
    assert value['schema'] == 'trnm-ci-source-v1'
    assert value['kind'] == 'head' and value['tested_commit'] == COMMIT
    assert value['tested_tree'] == TREE and value['candidate'] == COMMIT
    assert value['tracked_worktree_verified'] is True
    assert value['tests_executed_by_identity_check'] is False
    return record(path)


def fingerprints(label):
    base = TARGET / 'release/.fingerprint'
    rows = []
    if not base.is_dir():
        return {'status': 'ABSENT', 'rows': rows}
    for directory in sorted(base.iterdir()):
        if not directory.name.startswith(('trnm-w1-zk-host-v2-', 'trnm-w1-zk-methods-v2-')):
            continue
        assert directory.is_dir() and not directory.is_symlink()
        for path in sorted(directory.iterdir()):
            if not path.is_file() or path.is_symlink():
                continue
            assert path.stat().st_size <= 1024 * 1024
            origin = record(path)
            raw = path.read_bytes()
            assert hashlib.sha256(raw).hexdigest() == origin['sha256']
            destination = OUT / 'cargo-fingerprints' / label / directory.name / path.name
            save(destination, raw)
            rows.append({'original': origin, 'raw_copy': record(destination)})
    return {'status': 'OBSERVED', 'rows': rows}


def main():
    global COMMIT, TREE, OUT, TARGET, CACHE_SETUP
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--expected-tree', required=True)
    parser.add_argument('--attempt', required=True)
    parser.add_argument('--target-dir', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--cache-setup', type=Path, required=True)
    parser.add_argument('--cache-setup-sha256', required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{40}', args.expected_head), 'exact final commit required'
    assert re.fullmatch(r'[0-9a-f]{40}', args.expected_tree), 'exact final tree required'
    assert re.fullmatch(r'[0-9]{2}', args.attempt), 'two-digit unique attempt required'
    COMMIT, TREE = args.expected_head, args.expected_tree
    OUT, TARGET = args.output_dir, args.target_dir
    assert OUT.is_absolute() and TARGET.is_absolute() and ROOT in OUT.parents and ROOT in TARGET.parents
    assert REPO not in OUT.parents and REPO not in TARGET.parents
    assert TARGET == ROOT / ('target-backend-exact-' + COMMIT[:12] + '-' + args.attempt)
    assert OUT == ROOT / 'backend-validation' / ('exact-source-' + COMMIT[:12] + '-' + args.attempt)
    cache_pin = record(args.cache_setup)
    assert cache_pin['sha256'] == args.cache_setup_sha256
    CACHE_SETUP = json.loads(args.cache_setup.read_bytes())
    assert CACHE_SETUP['cache_setup_complete'] is True and CACHE_SETUP['role'] == 'backend'
    assert CACHE_SETUP['source_commit'] == COMMIT and CACHE_SETUP['source_tree'] == TREE
    assert CACHE_SETUP['destination_target'] == str(TARGET) and CACHE_SETUP['shared_original_regular_inodes'] == 0
    assert CACHE_SETUP['fresh_cargo_target'] is False and TARGET.is_dir()
    for old in CACHE_SETUP['original_C2_binaries'].values():
        assert record(Path(old['path']))['sha256'] == old['sha256']
    os.sched_setaffinity(0, {10, 11})
    assert os.sched_getaffinity(0) == {10, 11}, 'two requested CPU affinities required'
    OUT.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    excluded = sorted(key for key in env if key.startswith(('RUST', 'CARGO', 'RISC0', 'GIT_'))
                      or key in ('LD_PRELOAD', 'LD_LIBRARY_PATH', 'DYLD_INSERT_LIBRARIES', 'DYLD_LIBRARY_PATH'))
    for key in excluded:
        env.pop(key, None)
    explicit = {
        'PATH': str(TOOLCHAIN) + ':/home/qian-qi/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
        'RUSTUP_TOOLCHAIN': '1.95.0', 'RUSTUP_AUTO_INSTALL': '0',
        'RUSTC': str(TOOLCHAIN / 'rustc'), 'RUSTDOC': str(TOOLCHAIN / 'rustdoc'),
        'RUSTFMT': str(TOOLCHAIN / 'rustfmt'), 'CARGO_HOME': '/home/qian-qi/.cargo',
        'CARGO_TARGET_DIR': str(TARGET), 'CARGO_BUILD_JOBS': '2', 'CARGO_NET_OFFLINE': 'true',
        'CARGO_LOG': 'cargo::core::compiler::fingerprint=info',
        'RISC0_HOME': str(ROOT / 'task-risc0'), 'PYTHONDONTWRITEBYTECODE': '1',
        'RAYON_NUM_THREADS': '2',
    }
    env.update(explicit)
    assert 'RISC0_SKIP_BUILD' not in env and 'RISC0_SKIP_BUILD_KERNELS' not in env
    assert 'RISC0_DEV_MODE' not in env and 'RUSTC_WRAPPER' not in env
    assert 'RUSTC_WORKSPACE_WRAPPER' not in env
    manifest = {'schema': 'TRNM-W1-INTEGRATED-BACKEND-QUALIFICATION1', 'source_commit': COMMIT,
        'source_tree': TREE, 'repo_path': str(REPO), 'target_dir': str(TARGET),
        'qualification_complete': False, 'commands': [], 'errors': [],
        'environment': explicit, 'excluded_inherited_environment_names': excluded,
        'RISC0_SKIP_BUILD_present': False, 'guest_compilation_performed': False,
        'cache_reuse_allowed': True, 'fresh_cargo_target': False,
        'copied_cache_setup': cache_pin, 'original_C2_binaries': CACHE_SETUP['original_C2_binaries'],
        'independent_cleanroom_reconstruction_claimed': False,
        'proof_launched': False, 'native_winner_launched': False,
        'started_unix_ns': time.time_ns(), 'started_monotonic_ns': time.monotonic_ns(),
        'observer_pid': os.getpid(), 'observer_affinity': sorted(os.sched_getaffinity(0)),
        'resource_scope_complete': False, 'wrapper': record(Path(__file__).resolve()),
        'wrapper_argv': sys.argv, 'predecessor_A_wrapper_sha256': 'dfe400b5e605ec3883d09b7a9041a8dfd5830537981bf8db5ffdf6c472b39023'}
    save_json(OUT / 'environment.json', {'explicit': explicit, 'excluded_inherited_names': excluded,
        'only_names_of_excluded_variables_recorded': True})
    for name in ('cgroup', 'status', 'limits'):
        save(OUT / ('observer-proc-' + name + '.raw'), Path('/proc/self', name).read_bytes())
    save(OUT / 'observer-boot-id.raw', Path('/proc/sys/kernel/random/boot_id').read_bytes())

    def command(label, argv, timeout=600):
        directory = OUT / 'commands' / label
        directory.mkdir(parents=True, exist_ok=False)
        row = {'label': label, 'argv': argv, 'cwd': str(REPO), 'environment': explicit,
               'timeout_seconds': timeout, 'started_unix_ns': time.time_ns(),
               'started_monotonic_ns': time.monotonic_ns(), 'exit_code': None,
               'timed_out': False, 'signal_attempts': []}
        save_json(directory / 'command.json', row)
        print(json.dumps({'event': 'COMMAND_STARTED', 'label': label, 'argv': argv}), flush=True)
        child = None
        caught_exception = None
        try:
            with (directory / 'stdout.log').open('xb') as stdout, (directory / 'stderr.log').open('xb') as stderr:
                child = subprocess.Popen(argv, cwd=REPO, env=env, stdout=stdout, stderr=stderr,
                                         start_new_session=True)
                row['pid'] = child.pid
                try:
                    row['exit_code'] = child.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    row['timed_out'] = True
                    for sig, wait in ((signal.SIGTERM, 10), (signal.SIGKILL, 10)):
                        try:
                            os.killpg(child.pid, sig)
                            row['signal_attempts'].append({'signal': int(sig), 'outcome': 'SENT'})
                        except ProcessLookupError:
                            row['signal_attempts'].append({'signal': int(sig), 'outcome': 'ALREADY_ABSENT'})
                        try:
                            row['exit_code'] = child.wait(timeout=wait)
                            break
                        except subprocess.TimeoutExpired:
                            pass
                stdout.flush(); stderr.flush()
                os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
        except BaseException as caught:
            caught_exception = caught
            row['error'] = {'type': type(caught).__name__, 'message': str(caught)}
            if child is not None and child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                    row['exit_code'] = child.wait(timeout=10)
                except BaseException as cleanup:
                    row['cleanup_error'] = {'type': type(cleanup).__name__, 'message': str(cleanup)}
        row['finished_monotonic_ns'] = time.monotonic_ns()
        row['finished_unix_ns'] = time.time_ns()
        for name in ('stdout.log', 'stderr.log', 'command.json'):
            if (directory / name).is_file():
                row[name] = record(directory / name)
        row['success'] = row['exit_code'] == 0 and not row['timed_out'] and 'error' not in row
        save_json(directory / 'result.json', row)
        manifest['commands'].append(row)
        print(json.dumps({'event': 'COMMAND_FINISHED', 'label': label, 'exit_code': row['exit_code'], 'success': row['success']}), flush=True)
        if caught_exception is not None:
            raise caught_exception
        return row

    def must(row):
        assert row['success'], 'required command failed: ' + row['label']

    cargo = str(TOOLCHAIN / 'cargo')
    python = '/usr/bin/python3'
    try:
        membership = Path('/proc/self/cgroup').read_text().strip()
        assert membership.startswith('0::/') and '\n' not in membership, 'single cgroup-v2 membership required'
        cgroup = Path('/sys/fs/cgroup') / membership[3:].lstrip('/')
        assert cgroup.name.startswith('hepta-runtime-job-') and cgroup.name.endswith('.service'), 'normal Hepta-owned job required'
        controls = {}
        for name in ('cpu.max', 'memory.max', 'cpu.stat', 'memory.current', 'memory.peak', 'cgroup.events'):
            contents = (cgroup / name).read_bytes()
            save(OUT / ('observer-cgroup-before-' + name + '.raw'), contents)
            controls[name] = contents.decode().strip()
        quota, period = controls['cpu.max'].split()
        assert quota != 'max' and 0 < int(quota) <= 2 * int(period), 'actual cgroup CPU quota must be at most 2 CPUs'
        assert controls['memory.max'] != 'max' and 0 < int(controls['memory.max']) <= 8589934592, 'actual memory cap must be at most 8 GiB'
        manifest['actual_before_cgroup_controls'] = {'path': str(cgroup), 'controls': controls, 'complete_billing_claimed': False}
        must(command('00-preflight', ['/usr/bin/bash', 'scripts/project-preflight.sh', '--dev'], 90))
        for label, argv in (
                ('01-rustc-version', [str(TOOLCHAIN / 'rustc'), '-vV']),
                ('02-cargo-version', [cargo, '--version', '--verbose']),
                ('03-rustfmt-version', [str(TOOLCHAIN / 'rustfmt'), '--version']),
                ('04-clippy-version', [str(TOOLCHAIN / 'clippy-driver'), '--version'])):
            must(command(label, argv, 30))
        must(command('05-source-before', [python, 'scripts/ci/verify_ci_source.py', '--kind', 'head',
            '--expected-head', COMMIT, '--output', str(OUT / 'source-before.json')], 180))
        manifest['source_before'] = source_identity(OUT / 'source-before.json')
        source_before = {path: record(REPO / path) for path in OWNED}
        manifest['owned_source_before'] = source_before
        assert source_before['formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock']['sha256'] == LOCK_SHA
        assert source_before['evidence/pon-w1-full-v2-20261105/guest.bin']['sha256'] == GUEST_SHA
        save_json(OUT / 'owned-source-before.json', source_before)
        manifest['cargo_fingerprints_before'] = fingerprints('before')
        save_json(OUT / 'cargo-fingerprints-before.json', manifest['cargo_fingerprints_before'])
        configs = []
        for path in (Path('/home/qian-qi/.cargo/config'), Path('/home/qian-qi/.cargo/config.toml')):
            if path.is_file():
                configs.append(record(path))
        manifest['cargo_home_config_file_hashes_only'] = configs
        common = ['--manifest-path', MANIFEST]
        command('06-metadata-default', [cargo, 'metadata', *common, '--locked', '--offline', '--format-version', '1'], 180)
        command('07-metadata-all-features', [cargo, 'metadata', *common, '--all-features', '--locked', '--offline', '--format-version', '1'], 180)
        command('08-fmt-all', [cargo, 'fmt', *common, '--all', '--check'], 180)
        command('09-clippy', [cargo, 'clippy', '--release', *common, '-p', PACKAGE,
            '--all-targets', '--all-features', '--locked', '--offline', '--message-format=json-render-diagnostics',
            '--', '-D', 'warnings'], 1500)
        command('10-test-retained', [cargo, 'test', '--release', *common, '-p', PACKAGE,
            '--bin', RUNNER_NAME, '--all-features', '--locked', '--offline',
            '--message-format=json-render-diagnostics', '--', '--nocapture', '--test-threads=2'], 1500)
        command('11-release-build', [cargo, 'build', '--release', *common, '-p', PACKAGE,
            '--bin', RUNNER_NAME, '--features', 'retained-v2-guest', '--locked', '--offline',
            '--message-format=json-render-diagnostics'], 1500)
        metadata = {}
        for label in ('06-metadata-default', '07-metadata-all-features'):
            value = json.loads((OUT / 'commands' / label / 'stdout.log').read_bytes())
            assert value['target_directory'] == str(TARGET)
            assert any(p['name'] == PACKAGE and p['manifest_path'] == str(REPO / 'formal/pon-nakamoto-v1/w1_zkvm/host-v2/Cargo.toml') for p in value['packages'])
            graph = {'packages': [{'id': p['id'], 'name': p['name'], 'version': p['version'],
                       'source': p['source'], 'manifest_path': p['manifest_path']} for p in value['packages']],
                     'resolve': value['resolve'], 'workspace_members': value['workspace_members'],
                     'workspace_root': value['workspace_root'], 'target_directory': value['target_directory']}
            destination = OUT / (label + '-graph.json')
            save_json(destination, graph)
            metadata[label] = {'package_count': len(value['packages']), 'resolve_node_count': len(value['resolve']['nodes']),
                'workspace_member_count': len(value['workspace_members']), 'graph': record(destination),
                'risc0_packages': [p for p in graph['packages'] if p['name'].startswith('risc0-')]}
        manifest['locked_metadata'] = metadata
        lock = tomllib.loads((REPO / 'formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock').read_text())
        save_json(OUT / 'locked-packages.json', lock['package'])
        manifest['locked_package_records'] = record(OUT / 'locked-packages.json')
        manifest['cargo_json_artifacts'] = {}
        for label in ('09-clippy', '10-test-retained', '11-release-build'):
            events = []
            for line in (OUT / 'commands' / label / 'stdout.log').read_text().splitlines():
                if not line.startswith('{'):
                    continue
                event = json.loads(line)
                if event.get('reason') in ('compiler-artifact', 'build-script-executed', 'build-finished'):
                    events.append(event)
            destination = OUT / (label + '-cargo-artifacts.json')
            save_json(destination, events)
            manifest['cargo_json_artifacts'][label] = {'raw_events': record(destination),
                'fresh_count': sum(e.get('fresh') is True for e in events),
                'rebuilt_count': sum(e.get('fresh') is False for e in events),
                'owned_artifacts': [e for e in events if e.get('reason') == 'compiler-artifact'
                    and any(name in e.get('package_id', '') for name in (PACKAGE, 'trnm-w1-zk-methods-v2'))]}
        test_text = (OUT / 'commands/10-test-retained/stdout.log').read_text()
        test_names = re.findall(r'^test (\S+) \.\.\. ok$', test_text, re.M)
        summaries = re.findall(r'^test result:.*$', test_text, re.M)
        assert len(test_names) == 22, 'expected exactly 22 retained successful tests'
        assert any(re.match(r'test result: ok\. 22 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', line) for line in summaries)
        manifest['test_result'] = {'passed': 22, 'failed': 0, 'ignored': 0, 'names': test_names, 'summary_lines': summaries}
        runner = TARGET / 'release' / RUNNER_NAME
        manifest['runner'] = record(runner)
        with runner.open('rb') as stream:
            header = stream.read(64)
        assert header[:6] == b'\x7fELF\x02\x01' and int.from_bytes(header[18:20], 'little') == 62
        manifest['runner']['kind'] = 'ELF64-little-endian-x86_64'
        manifest['runner']['elf_header_hex'] = header.hex()
        build_events = json.loads((OUT / '11-release-build-cargo-artifacts.json').read_bytes())
        runner_events = [e for e in build_events if e.get('reason') == 'compiler-artifact'
            and e.get('executable') == str(runner) and PACKAGE in e.get('package_id', '')]
        assert len(runner_events) == 1 and 'retained-v2-guest' in runner_events[0]['features']
        manifest['runner']['cargo_reported_fresh'] = runner_events[0]['fresh']
        script_events = [e for e in build_events if e.get('reason') == 'build-script-executed'
                         and 'trnm-w1-zk-methods-v2' in e.get('package_id', '')]
        assert script_events, 'actual Cargo-selected methods-v2 build output required'
        provenance = []
        for index, event in enumerate(script_events):
            directory = Path(event['out_dir'])
            assert TARGET in directory.parents
            original = directory / 'guest-build-provenance.json'
            raw = original.read_bytes()
            value = json.loads(raw)
            assert value['schema'] == 'TRNM-W1-GUEST-BUILD1' and value['mode'] == 'retained-v2-guest'
            assert value['bytes'] == 375928 and value['sha256'] == GUEST_SHA and value['image_id'] == IMAGE
            assert value['sdk_image_checked'] is True and value['guest_compilation_performed'] is False
            retained = record(directory / 'retained-v2-guest.bin')
            assert retained['bytes'] == 375928 and retained['sha256'] == GUEST_SHA
            copy = OUT / 'guest-provenance' / ('%02d-guest-build-provenance.json' % index)
            save(copy, raw)
            methods = directory / 'methods.rs'
            save(OUT / 'guest-provenance' / ('%02d-methods.rs' % index), methods.read_bytes())
            provenance.append({'cargo_build_script_event': event, 'original': record(original),
                'raw_copy': record(copy), 'retained_guest': retained, 'generated_methods': record(methods), 'value': value})
        manifest['guest_build_provenance'] = provenance
        main_source = (REPO / OWNED[0]).read_text()
        begin = main_source.index('fn source_commit()')
        end = main_source.index('\nfn ', begin + 1)
        excerpt = main_source[begin:end]
        assert 'Command::new("git")' in excerpt and '.args(["rev-parse", "HEAD"])' in excerpt
        assert 'scripts/ci/verify_ci_source.py' in excerpt
        save(OUT / 'runtime-source-commit-function.rs.txt', excerpt.encode())
        manifest['source_commit_binding'] = {'kind': 'runtime_git_and_full_source_verifier',
            'compiled_manifest_directory': str(REPO / 'formal/pon-nakamoto-v1/w1_zkvm/host-v2'),
            'resolved_runtime_repo': str((REPO / 'formal/pon-nakamoto-v1/w1_zkvm/host-v2/../../../..').resolve()),
            'head_constant_embedded_by_methods_build_rs': False,
            'source_function_excerpt': record(OUT / 'runtime-source-commit-function.rs.txt'),
            'no_actual_prepare_or_proof_manifest_produced': True}
        assert manifest['source_commit_binding']['resolved_runtime_repo'] == str(REPO)
    except BaseException as caught:
        manifest['errors'].append({'phase': 'qualification', 'type': type(caught).__name__, 'message': str(caught)})
    finally:
        try:
            row = command('12-source-after', [python, 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                '--expected-head', COMMIT, '--output', str(OUT / 'source-after.json')], 180)
            must(row)
            manifest['source_after'] = source_identity(OUT / 'source-after.json')
            source_after = {path: record(REPO / path) for path in OWNED}
            save_json(OUT / 'owned-source-after.json', source_after)
            manifest['owned_source_after'] = source_after
            assert all(source_after[path]['sha256'] == manifest['owned_source_before'][path]['sha256'] for path in OWNED)
            assert source_after['formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock']['sha256'] == LOCK_SHA
            manifest['cargo_fingerprints_after'] = fingerprints('after')
            save_json(OUT / 'cargo-fingerprints-after.json', manifest['cargo_fingerprints_after'])
        except BaseException as caught:
            manifest['errors'].append({'phase': 'after', 'type': type(caught).__name__, 'message': str(caught)})
        try:
            for old in CACHE_SETUP['original_C2_binaries'].values():
                assert record(Path(old['path']))['sha256'] == old['sha256'], 'C2 qualified ELF changed'
            manifest['original_C2_binaries_unchanged_after'] = True
        except BaseException as exc:
            manifest['errors'].append({'label': 'original-C2-preservation', 'type': type(exc).__name__, 'message': str(exc)})
        manifest['qualification_complete'] = (not manifest['errors'] and len(manifest['commands']) == 13
            and all(row['success'] for row in manifest['commands'])
            and manifest.get('test_result', {}).get('passed') == 22
            and bool(manifest.get('guest_build_provenance')) and bool(manifest.get('runner')))
        try:
            for name in ('cpu.max', 'memory.max', 'cpu.stat', 'memory.current', 'memory.peak', 'cgroup.events'):
                save(OUT / ('observer-cgroup-after-' + name + '.raw'), (cgroup / name).read_bytes())
        except BaseException as caught:
            manifest['errors'].append({'phase': 'resource-after-observation', 'type': type(caught).__name__, 'message': str(caught)})
            manifest['qualification_complete'] = False
        manifest['finished_unix_ns'] = time.time_ns()
        manifest['finished_monotonic_ns'] = time.monotonic_ns()
        save_json(OUT / 'manifest.json', manifest)
        summary = {'schema': manifest['schema'], 'qualification_complete': manifest['qualification_complete'],
            'manifest': record(OUT / 'manifest.json'), 'errors': manifest['errors'],
            'commands': [{'label': row['label'], 'exit_code': row['exit_code'], 'success': row['success']} for row in manifest['commands']],
            'runner': manifest.get('runner'), 'test_result': manifest.get('test_result'),
            'source_commit': COMMIT, 'source_tree': TREE, 'proof_launched': False}
        save_json(OUT / 'summary.json', summary)
        print(json.dumps(summary, sort_keys=True), flush=True)
    return 0 if manifest['qualification_complete'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
