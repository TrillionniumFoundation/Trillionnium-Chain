# Hepta prepared-verifier 复用独立源码审查

## 结论与适用边界

当前审读补丁适合进入隔离候选的严格编译与原必要门。未发现扩大接受范围、缓存签名成功结果、借用历史权限或跳过当前 owner 的改动。此结论只属于团队内独立源码审查；`external_acceptance=false`，原 60 秒恢复门和完整跨仓候选尚未据此关闭。

审读基线为 `3bc3ce7c92caf800496a02f208fa6216d7395c7a`，tree `e7939c6daaac6a3c98834fe1baa63ce316917d32`。补丁 `9e0489b38f5e3b3b36454e758d8375ecbf8e1b3bdd9983470256fe8870d8e599`，16,770 字节，共 6 个文件。base、当前 ancillary 和额外 policy/guard/测试源码已与实际候选导出的 `selected-source-blobs.json` 对照；anchor 另外直接读回 exact 3bc 的 `git ls-tree` blob 和运行树文件 SHA-256，非仅靠旧分支继承推导。输入清单及精确绝对路径在 `review.json`。

## 安全边界

| 边界 | 实际代码行为及判断 |
| --- | --- |
| 完整 policy 绑定 | 每次先运行 `validate_for`，再比较 `verifier.policy_bytes() == Some(self.policy_json.as_bytes())`。不使用仅摘要、signer ID 或解析后的语义等价代替全部原始字节。policy 的现有 16,384 字节界限保持。 |
| 历史 policy 与当前 policy 不同 | 不匹配的提示、classical 提示和无提示均走历史 policy 的原构造器。旧历史可继续验签，当前 role 不会替换历史 grant role。classical 提示测试只针对历史完整性，不能赋予 classical 生产准入。 |
| 实际签名 | 成功路径仍执行 H7 envelope 和 grant 两个真实 PQ 验签；所有输入仍走原 shape、binding、role、epoch 和 supplied-time 检查。失败时保留原先的短路顺序，不声称每个失败输入都执行两次验签。 |
| 当前权限 | publication 的 guard revalidate、decision window、当前 anchor、intent 重读、predecessor、durable write 与外部 CAS 顺序保持。unknown/completed recovery 继续获取当前 M15 owner，验证当前 recovery decision，并重新检查 root、release、clock、状态和绑定。历史验签不成为 live admission。 |
| clone 与生命周期 | PQ 类型的 clone 增加两个 `Arc` 引用并复制两个 signer 字符串及标量，不复制展开后的密钥矩阵。没有签名观察或权限字段、全局 cache 或可变公钥接口。借用只在当前调用内有效；不匹配时重建的 verifier 也只在调用内持有。 |
| 资源和分母 | 补丁没有改变 daemon argv、60 秒 attempt 窗口、retry 策略、31 次恢复分母、密码 profile 或攻击/资源预算。源码推断不能代替真实服务完成。 |

## 负控审读

现有两个 retained-proof 测试扩展到匹配 prepared 提示：先成功，再分别改变 grant/H7 detached signature；被改签名先通过 `validate_for`，随后必须被真实验签拒绝。供应时间 `99` 和截止点 `400` 仍拒绝；改变保留的 raw policy 且不改变原绑定仍拒绝。新增同一 fallback selector 覆盖不同 grant/recovery 角色 policy、classical 提示，以及相同公钥但仅 raw whitespace 不同的合法 policy 提示，要求原历史继续成功。最后一项能捕捉错误按解析语义复用而因 policy digest 不同误拒绝历史的问题。原 verifier 与 current-owner role/epoch/revocation 控制保持。

测试源审读与执行严格分开。本 reviewer 没有执行 Rust、Clippy、native 或 workflow；候选 owner 仍须在最终候选上执行原组和新增 fallback selector。预期 policy 组为原 34 + 已有 shape 1 + fallback 1 = 36，不能将源码检查计入这些 36 个真实执行结果。

## 完整调用清单的重要纠正

早期局部 collection 未包含 `signed_intent_anchor.rs:62` 的生产历史验签。实际全仓 caller receipt 显示该入口仍存在，因此原 `verify_historical_for` 与 private `verify_at` 不能直接改成 `cfg(test)`。当前审查保留此纠正；不能把局部搜索无结果等同全仓没有生产调用。

最终 anchor 补丁保留原 3 参数 `check_previous`，由它转入新 helper 的 `None` 路径。完整全仓检索有 9 个调用：只有已持有 verifier 的 admission 两处和 unknown 两处传 `Some`；process-entry、publish-history、cold-current 和 retained-recovery 两处继续走原 wrapper，共 5 个无提示调用。snapshot equality、历史实际签名、closed-history terminal witness，以及所有调用侧的当前 owner 都保留。unknown 中原两次历史验签仍各自执行，没有因共享准备材料而合并。不同 policy 的回退和无提示路径仍有原展开成本，优化收益只由原服务门计量。

## 已执行的证据完整性检查

- 16 个 SOURCE_MAP/ancillary 条目的 SHA-256 与 Git blob 独立重算一致；另核对 policy definition、current recovery admission、既有 PQ 测试 3 个实际源码。
- 13 个 base/ancillary/supporting 路径与基线实际 commit inventory 或 anchor 直接 exact-commit observation 一致。
- `git apply --check` 成功；在本 reviewer 的临时隔离副本应用后，全部 6 个结果与 proposed 文件逐字节相同。未修改提出者或冻结候选源码。
- 完整 caller receipt 已独立读取；未自行另起远程构建或运行。

## 尚需实际执行的关闭条件

隔离 v4 的实际格式化补丁已读回并应用于本 reviewer 的独立副本，全部 6 个输出与实际 formatted pins 一致。相对已审版本只含折行、可选的调用尾逗号及单表达式 closure 外层括号格式变化；没有观察到语义变化。最终审读补丁 SHA 为 `9e0489b38f5e3b3b36454e758d8375ecbf8e1b3bdd9983470256fe8870d8e599`。后续 scoped just-fix 如改变源码，必须另行复核并绑定冻结 head/graph/binary。

严格编译/Clippy 与原 policy/owner 组必须真实通过；原 31 次恢复 daemon 必须在原 60 秒 attempt 预算和原 retry 策略内完成。不能以这个内部源码审查、原组之前的通过，或理论减少的 key preparation 次数替代当前候选结果。
