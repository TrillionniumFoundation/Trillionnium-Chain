#!/usr/bin/env python3
"""Read-only F4 evidence boundary validation; no native/model or archive extraction."""
from pathlib import Path
import hashlib,json,os,re,stat,subprocess,sys,time,traceback
ROOT=Path('/data/chain-six-d9fb-20261108/delivery-source')
OUT=Path('/data/chain-six-d9fb-20261108/evidence/final-integration/consensus-f4-evidence-validation')
HEAD='e9b7a60b9519e39b792199dc8756fb9d1245bab8'
TREE='d7d107818a74fdf4fe95e97d1de5c82664126363'
EVIDENCE='evidence/chain-six-full-20261108'
EXPECTED={'head':HEAD,'tree':TREE,'status':''}
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1',GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
ARCHIVES=(
 'root-history-public-v2.tar.xz','root-campaign-f3-originals.tar.xz',
 'consensus-history.tar.xz','consensus-cell-f3-originals-and-joint-supplement.tar.xz',
 'proof-owner-history.tar.xz','proof-mmcs-f3-originals.tar.xz',
 'github-original-source-guard-failures.tar.xz','github-candidate-and-work-security-diagnosis.tar.xz',
 'github-f3-work-security-review.tar.xz','github-work-security-original-controls.tar.xz',
 'github-native-campaign-original-text-f3.tar.xz','f3-original-source-and-reader-supplements.tar.xz')
PINNED_PROGRAMS={
 EVIDENCE+'/run_root_campaign.py':'6722bd33d33978ff4f467e350dbc8c0519358c6ed10a001e6ef69accc1177490',
 EVIDENCE+'/verify_amortized_independent_roster.py':'49ee3416b896bd0b406ea1b3eaa6846848ab710d5c205fe894103ee7ef57c8e0',
 EVIDENCE+'/test_amortized_independent_roster.py':'0f45393876290e43dc1416f0d03afaf06af5ac9c655371ef167ff3864916b35e',
 EVIDENCE+'/test_root_campaign_amortized_reader.py':'b7fdba3b644bb70d0e3323dad90e4330245805276a7cc5031648d264b5995132',
 'evidence/smollm-same-iteration-20261108/verify_originals.py':'9084bfba788dd0e294104b7cdf046ea7f576cc9f3e3c07eb55de517bc0630e26',
 'evidence/hepta-real-native-learning-20261108/verify_originals.py':'f41dd7231bf402cbc32a4c6ffc24e27298f266e198c67f0a5e26470da3a09d8c',
 'evidence/hepta-real-native-adoption-20261108/verify_originals.py':'f4d2ca88bef079eb9ba52e7fd288be7c0176087d216b01c805026c39cd31b0b6',
}
ROSTERS={
 'amortized-parser-eight':('ExactSixControls',(
 'test_actual_full_six_retained_results',
 'test_fake_ok_changed_count_and_trailing_data_rejected',
 'test_missing_or_duplicate_named_entry',
 'test_only_two_exact_original_docstring_continuations',
 'test_process_failure_extra_stdout_and_boolean_exit_rejected',
 'test_skips_failures_and_expected_failures_rejected',
 'test_source_byte_drift_rejected',
 'test_unknown_identity_or_class_cannot_replace_original')),
 'root-entry-four':('RootStageReaderControls',(
 'test_absent_source_records_reader_error_without_raising',
 'test_actual_fresh_six_uses_the_same_fixed_named_reader',
 'test_changed_actual_status_records_failure_without_raising',
 'test_roster_or_process_failure_cannot_be_promoted')),
}
def require(value,message):
 if not value:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def identity():
 return {name:subprocess.check_output(['git','--no-replace-objects',*args],cwd=ROOT,env=ENV,text=True).strip() for name,args in [('head',['rev-parse','HEAD']),('tree',['rev-parse','HEAD^{tree}']),('status',['status','--porcelain','--untracked-files=all'])]}
def file_hash(path):
 descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  before=os.fstat(descriptor);require(stat.S_ISREG(before.st_mode),'regular input required')
  digest=hashlib.sha256();size=0
  while True:
   block=os.read(descriptor,1024*1024)
   if not block:break
   digest.update(block);size+=len(block)
  after=os.fstat(descriptor)
  require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns) and size==after.st_size,'input changed during read')
  return {'bytes':size,'sha256':digest.hexdigest()}
 finally:os.close(descriptor)
require(identity()==EXPECTED,'clean frozen F4 required')
require(not OUT.exists() and not OUT.is_relative_to(ROOT),'new external output required')
OUT.mkdir(parents=True,exist_ok=False)
report={'schema':'chain-six-f4-delivered-evidence-boundary-validation-v1','source':EXPECTED,'commands':[],'complete':False,'all_passed':False,'qualification':'HOLD_NO_GO','native_or_model_execution_rerun':False,'archive_extraction_executed':False,'historical_failures_reinterpreted':False,'python_version':sys.version,'python_executable_sha256':file_hash(Path(sys.executable).resolve())['sha256'],'started_unix_ns':time.time_ns()}
def save():
 (OUT/'validation.json').write_text(json.dumps(report,sort_keys=True,indent=2)+chr(10))
def execute(label,argv,timeout=1200):
 require(identity()==EXPECTED,'source before '+label)
 row={'label':label,'argv':argv,'timeout_seconds':timeout,'started_unix_ns':time.time_ns()}
 start=time.monotonic();so=OUT/(label+'.stdout');se=OUT/(label+'.stderr')
 with so.open('xb') as stdout,se.open('xb') as stderr:
  try:
   process=subprocess.run(argv,cwd=ROOT,env=ENV,stdout=stdout,stderr=stderr,timeout=timeout,check=False);row['exit_code']=process.returncode
  except subprocess.TimeoutExpired:row.update(exit_code=124,timed_out=True)
  except OSError as error:stderr.write((repr(error)+chr(10)).encode());row.update(exit_code=127,launch_error=repr(error))
 row['elapsed_seconds']=time.monotonic()-start;row['stdout']=file_hash(so);row['stderr']=file_hash(se);row['source_after']=identity()
 row['passed']=row['exit_code']==0 and row['source_after']==EXPECTED
 report['commands'].append(row);save()
 return row,so,se
def frame(row,so,se,owner,methods):
 require(row['exit_code']==0 and so.read_bytes()==b'','test process/stdout')
 expected=''.join(f'{name} (__main__.{owner}.{name}) ... ok'+chr(10) for name in methods)
 actual=se.read_text()
 require(actual.startswith(expected),'fixed delivered test identities/statuses')
 tail=actual[len(expected):]
 require(re.fullmatch(r'\n-{70}\nRan '+str(len(methods))+r' tests in [0-9]+\.[0-9]+s\n\nOK\n',tail) is not None,'exact unittest completion')
 return {'executed_ok':len(methods),'skipped':0,'test_ids':[f'__main__.{owner}.{name}' for name in methods]}
before=None;input_pins={}
try:
 row,_,_=execute('source-before',['/usr/bin/python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',HEAD,'--output',str(OUT/'source-before.json')])
 require(row['passed'],'full source-before failed');before=json.loads((OUT/'source-before.json').read_bytes())
 for path,expected in PINNED_PROGRAMS.items():
  observed=file_hash(ROOT/path);require(observed['sha256']==expected,'reviewed program drift: '+path);input_pins[path]=observed
 manifest_path=ROOT/EVIDENCE/'archive-manifest.json';manifest_raw=manifest_path.read_bytes();manifest=json.loads(manifest_raw)
 require(manifest['schema']=='chain-six-public-original-archive-manifest-v1' and manifest['qualification']=='HOLD_NO_GO','archive scope')
 require(manifest['full_compiled_binary_or_database_export'] is False and manifest['native_tests_rerun_by_archive_verification'] is False and manifest['private_hepta_source_exported'] is False,'archive qualifications changed')
 entries=manifest['files'];paths=[x['path'] for x in entries]
 require(len(entries)==12 and len(set(paths))==12 and set(paths)=={'archives/'+name for name in ARCHIVES},'exact 12-archive roster')
 actual={p.name for p in (ROOT/EVIDENCE/'archives').iterdir() if p.is_file()}
 require(actual==set(ARCHIVES),'archive directory extras/missing')
 archive_rows=[]
 for item in entries:
  rel=item['path'];require(not Path(rel).is_absolute() and '..' not in Path(rel).parts,'archive path')
  observed=file_hash(ROOT/EVIDENCE/rel);require(observed=={'bytes':item['bytes'],'sha256':item['sha256']},'archive bytes: '+rel)
  archive_rows.append({'path':rel,**observed});input_pins[EVIDENCE+'/'+rel]=observed
 input_pins[EVIDENCE+'/archive-manifest.json']=file_hash(manifest_path)
 report['archives']={'passed':True,'count':12,'total_bytes':sum(x['bytes'] for x in archive_rows),'manifest_sha256':sha(manifest_raw),'files':archive_rows,'extracted':False}
 save()
 for label,script in [('amortized-parser-eight','test_amortized_independent_roster.py'),('root-entry-four','test_root_campaign_amortized_reader.py')]:
  row,so,se=execute(label,['/usr/bin/python3','-B',EVIDENCE+'/'+script,'-v'])
  try:row['named_frame']=frame(row,so,se,*ROSTERS[label])
  except Exception as error:row.update(passed=False,reader_error={'type':type(error).__name__,'message':str(error)})
  save()
 for label,script,count in [
  ('original-smollm-233','evidence/smollm-same-iteration-20261108/verify_originals.py',233),
  ('original-native-learning-517','evidence/hepta-real-native-learning-20261108/verify_originals.py',517),
  ('original-native-adoption-417','evidence/hepta-real-native-adoption-20261108/verify_originals.py',417)]:
  row,so,se=execute(label,['/usr/bin/python3','-B',script])
  try:
   require(row['exit_code']==0 and se.read_bytes()==b'','public verifier process')
   value=json.loads(so.read_bytes())
   require(value['qualification']=='HOLD_NO_GO' and value['production_activation'] is False,'public verifier authority')
   if count==233:
    require(value['schema']=='trnm-smollm-original-evidence-replay-v1' and value['result']=='PASS','233 result')
    counts=value['original_files_verified'];require(set(counts)=={'initial','no-update','cell-transfer'} and all(type(x) is int and x>0 for x in counts.values()) and sum(counts.values())==233,'original 233 roster')
    require(value['actual_runtime_rerun'] is False and value['independently_authenticated'] is False,'233 scope')
   elif count==517:
    require(value['schema']=='hepta-real-native-original-record-review-v1' and value['result']=='PASS_ORIGINAL_RESEARCH_RECORDS' and value['original_files']==517,'517 result')
    require(value['successful_native_source']=='27849cbdcfc0d4afc69764d6c1742af22c41c293' and value['disposition']=='NoUpdate' and value['real_new_candidate_adoption'] is False,'517 original source/scope')
   else:
    require(value['schema']=='hepta-real-native-adoption-record-review-v1' and value['result']=='PASS_ORIGINAL_RESEARCH_RECORDS' and value['original_files']==417,'417 result')
    require(value['successful_native_source']=='edf03ecb8a814a0f5e86b1d6a752aeac80b1a978' and value['original_parameter_v3_qualified'] is False and value['product_ope_qualified'] is False and value['general_model_quality_qualified'] is False,'417 original source/scope')
    require([run['real_new_candidate_adoption'] for run in value['runs']]==[False,True] and value['runs'][1]['predicted_answers'][1]==['no']*4 and value['runs'][1]['next_task_answer_correct'] is False,'actual limited adoption result')
   row['original_files_verified']=count;row['public_verifier_result']=value
  except Exception as error:row.update(passed=False,reader_error={'type':type(error).__name__,'message':str(error)})
  save()
 report['complete']=True
except BaseException as error:
 report['driver_error']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 if before is not None:
  try:
   after_row,_,_=execute('source-after',['/usr/bin/python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',HEAD,'--output',str(OUT/'source-after.json')])
   report['full_source_unchanged']=after_row['passed'] and json.loads((OUT/'source-after.json').read_bytes())==before
  except Exception as error:report['source_after_error']=repr(error)
 report['reviewed_inputs_before']=input_pins
 try:
  report['reviewed_inputs_after']={path:file_hash(ROOT/path) for path in input_pins}
  report['reviewed_input_bytes_unchanged']=report['reviewed_inputs_after']==input_pins
 except Exception as error:report['input_after_error']=repr(error)
 report['source_after']=identity();report['finished_unix_ns']=time.time_ns()
 report['all_passed']=report['complete'] and report.get('archives',{}).get('passed') is True and len(report['commands'])==7 and all(x['passed'] for x in report['commands']) and report.get('full_source_unchanged') is True and report.get('reviewed_input_bytes_unchanged') is True and report['source_after']==EXPECTED
 save()
 print(json.dumps({'complete':report['complete'],'all_passed':report['all_passed'],'source_unchanged':report.get('full_source_unchanged'),'archives_verified':report.get('archives',{}).get('count'),'command_count':len(report['commands']),'failed_stages':[x['label'] for x in report['commands'] if not x['passed']],'driver_error':report.get('driver_error'),'qualification':'HOLD_NO_GO'},sort_keys=True),flush=True)
sys.exit(0 if report['all_passed'] else 1)
