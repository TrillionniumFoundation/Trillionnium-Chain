#!/usr/bin/env python3
"""Review-only until explicitly launched: verify one committed C4 on the original gates.

This adapter permits the existing completed S3 Cargo target. It does not modify
source, budgets, original helpers, retained rosters, historical results or the
provider. Cargo's actual `fresh` boolean is preserved. All observations below are
new C4 observations, never inherited S3 passes. The durable job owns this runner
for 7200 seconds; original build/native/Clippy caps remain 3600/900/1800 seconds.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time

# 1. Reviewed inputs. Original external scripts are loaded only after hash checks.
ROOT = Path('/tmp/chain-pq-fa62381e')
S3 = '454ae116159867ff6cddd91b964523df7f7e16f0'
S3_TREE = '3117250c4db0f2ae681d51ed6ee5e6a2fa7555a9'
S3_POSITIVE = Path('/tmp/chain-pq-fa62381e-s3-positive')
TARGET = Path('/tmp/chain-pq-fa62381e-s3-positive-target')
V2 = Path('/tmp/chain-pq-fa62381e-validation-plan-batched64-barrier-v2.py')
V2_SHA = 'effa69e49141bc020bfd0b9861218a7da1729d4811ec7c6003a52c72513ff60b'
LAUNCHER = Path('/tmp/chain-pq-fa62381e-native-launcher.py')
LAUNCHER_SHA = '1894d73d87b631b5d391b4919de182055440e6bcdf783330be7d4f841e120727'
REFERENCE_SHA = '1c64123ef93a3daf280b7fe901738bdb4e32d714ad6e697bfd19a2b65cc7a32b'
ORIGINAL13_SUMMARY_SHA = 'a78bae2efba396f4fc1f84d75dbca7f65de62db8b501fdfbdc149201f0961d09'
REPORT = 'evidence/pq-live-retry-20261111-fa62381e/root-dependency-register-current-report.json'
UNCHANGED_HELPERS = (
    'scripts/ci/record_pq_native_command.py',
    'scripts/ci/verify_ci_source.py',
    'scripts/ci/ci_observation.py',
    'scripts/ci/pinned_native_process.py',
    'scripts/ci/check_required_native_test.py',
    'scripts/project-preflight.sh',
    'scripts/ci/project_boundary.py',
    'formal/pon-nakamoto-v1/bounded_process.py',
)
ORIGINAL13 = [
    ('inventory', ['python3', 'scripts/refresh_distributed_source_inventory.py', '--check']),
    ('repository', ['python3', 'scripts/ci/check_repository.py']),
    ('ci-source', ['python3', 'scripts/ci/check_ci_contract.py']),
    ('corpus-source', ['python3', 'scripts/ci/check_pq_research_integration.py']),
    ('claim-source', ['python3', 'scripts/ci/pq_chain_claim_guard.py']),
    ('source-integrity-controls', ['python3', '-m', 'unittest', 'discover', '-s', 'scripts/ci',
                                   '-p', 'test_ci_source_integrity.py', '-v']),
    ('from-zero-host-controls', ['python3', 'scripts/ci/test_from_zero_host_ci.py']),
    ('workspace-metadata-default', ['cargo', '+1.95.0', 'metadata', '--locked', '--manifest-path',
                                     'trillionnium/Cargo.toml', '--format-version', '1']),
    ('workspace-metadata-all-features', ['cargo', '+1.95.0', 'metadata', '--locked', '--manifest-path',
                                          'trillionnium/Cargo.toml', '--format-version', '1', '--all-features']),
    ('fuzz-metadata-default', ['cargo', '+1.95.0', 'metadata', '--locked', '--manifest-path',
                                'tests/fuzz/Cargo.toml', '--format-version', '1']),
    ('fuzz-metadata-all-features', ['cargo', '+1.95.0', 'metadata', '--locked', '--manifest-path',
                                     'tests/fuzz/Cargo.toml', '--format-version', '1', '--all-features']),
    ('workspace-fmt', ['cargo', '+1.95.0', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml',
                         '--all', '--', '--check']),
    ('fuzz-fmt', ['cargo', '+1.95.0', 'fmt', '--manifest-path', 'tests/fuzz/Cargo.toml',
                    '--all', '--', '--check']),
]
BUILD_COMMAND = ['cargo', '+1.95.0', 'test', '--locked', '--manifest-path',
                 'trillionnium/Cargo.toml', '-p', 'trnm-pon-node', '--lib',
                 '--all-features', '--no-run', '--message-format=json']


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def file_identity(path):
    info = Path(path).lstat()
    require(stat.S_ISREG(info.st_mode), 'nonregular evidence file: ' + str(path))
    return {'bytes': info.st_size, 'sha256': sha(path)}


def read_regular_bytes(path):
    """Hash exactly the bytes consumed by JSON/import-admission checks."""
    path = Path(path)
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), 'nonregular byte input: ' + str(path))
        raw = stream.read()
        after = os.fstat(stream.fileno())
    fingerprint = lambda info: (info.st_dev, info.st_ino, info.st_mode, info.st_size,
                                info.st_mtime_ns, info.st_ctime_ns)
    require(len(raw) == before.st_size and fingerprint(before) == fingerprint(after)
            and fingerprint(path.lstat()) == fingerprint(before),
            'byte input changed during read: ' + str(path))
    return raw, {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write_json(path, value):
    Path(path).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def git(*argv):
    return subprocess.check_output(['git', '--no-replace-objects', *argv], cwd=ROOT)


def load_external(name, path, expected):
    require(file_identity(path)['sha256'] == expected, 'external helper changed: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def runtime_or_graph(path):
    p = Path(path)
    return (p.suffix == '.rs' or p.name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain',
                                           'rust-toolchain.toml')
            or ('.cargo' in p.parts and p.name in ('config', 'config.toml')))


def provider_environment(launcher):
    """Use actual pinned launcher constants and its original admission behavior."""
    require(launcher.ROOT == ROOT, 'original launcher source root differs')
    env_path = launcher.PROVIDER_ROOT / 'github-env'
    receipt_path = launcher.PROVIDER_ROOT / 'receipts/pq-provider/provider.json'
    require(file_identity(env_path)['sha256'] == launcher.ENV_SHA, 'provider environment differs')
    require(file_identity(receipt_path)['sha256'] == launcher.RECEIPT_SHA, 'provider receipt differs')
    provider = {}
    for line in env_path.read_text().splitlines():
        require('=' in line, 'invalid provider environment line')
        key, value = line.split('=', 1)
        require(key in launcher.ENV_KEYS and key not in provider and value,
                'unexpected, duplicate or empty provider key')
        provider[key] = value
    require(set(provider) == launcher.ENV_KEYS, 'incomplete provider environment')
    require(provider['OPENSSL_DIR'] == str(launcher.PREFIX)
            and provider['TRNM_PQ_OPENSSL'] == str(launcher.PREFIX / 'bin/openssl')
            and provider['TRNM_PQ_OPENSSL_SHA256'] == launcher.ARTIFACTS['bin/openssl']
            and provider['OPENSSL_STATIC'] == '1'
            and provider['TRNM_PQ_OPENSSL_VERSION'] == '3.5.9'
            and provider['OPENSSL_CONF'] == '/dev/null', 'provider identity differs')
    for relative, expected in launcher.ARTIFACTS.items():
        require(file_identity(launcher.PREFIX / relative)['sha256'] == expected,
                'provider artifact differs: ' + relative)
    inherited = os.environ.copy()
    disallowed = [key for key, value in inherited.items() if value and (
        key.startswith('CARGO_PROFILE_')
        or key.endswith(('_RUSTFLAGS', '_RUSTC', '_RUSTC_WRAPPER', '_RUSTC_WORKSPACE_WRAPPER'))
        or key in ('RUSTFLAGS', 'RUSTC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'))]
    require(not disallowed, 'inherited compiler/profile overrides: ' + ', '.join(sorted(disallowed)))
    overrides = ('OPENSSL_DIR', 'OPENSSL_LIB_DIR', 'OPENSSL_INCLUDE_DIR',
                 'OPENSSL_STATIC', 'OPENSSL_LIBS', 'OPENSSL_NO_VENDOR')
    cleared = []
    for key in list(inherited):
        if key in overrides or any(key.endswith('_' + name) for name in overrides):
            cleared.append(key)
            del inherited[key]
    inherited.update(provider)
    inherited.update(PATH='/home/qian-qi/.cargo/bin:' + inherited.get('PATH', ''),
                     CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', RUST_TEST_THREADS='1',
                     PYTHONDONTWRITEBYTECODE='1', CARGO_TARGET_DIR=str(TARGET))
    return inherited, {
        'provider_environment_sha256': launcher.ENV_SHA,
        'provider_receipt_sha256': launcher.RECEIPT_SHA,
        'provider_artifact_sha256': launcher.ARTIFACTS,
        'provider_environment': provider,
        'cleared_ambient_openssl_override_keys': sorted(cleared),
        'compiler_profile_overrides_refused': True,
        'default_workspace_profiles': True,
    }


def verify_receipt(path, source, baseline=None):
    receipt_raw, receipt_identity = read_regular_bytes(path)
    receipt = json.loads(receipt_raw)
    require(receipt.get('schema') == 'trnm-pq-native-command-v1', 'source receipt schema differs')
    require(receipt.get('before') == receipt.get('after')
            and isinstance(receipt.get('before'), dict)
            and receipt['before'].get('tested_commit') == source, 'source receipt guard failed')
    if baseline is not None:
        require(receipt['before'] == baseline, 'source receipt differs from initial physical identity')
    log = Path(path).parent / receipt['log_file']
    observed = file_identity(log)
    require(observed == {'bytes': receipt['log_bytes'], 'sha256': receipt['log_sha256']},
            'source-recorded command log differs')
    require(receipt.get('status') in ('command_succeeded', 'command_failed'),
            'source recorder did not complete')
    require(file_identity(path) == receipt_identity, 'source receipt changed during log validation')
    return receipt, receipt_identity


def prior_positive_provenance(v2, selection, provenance):
    """Read historical completion only to establish the reused target's origin."""
    paths = [S3_POSITIVE / item for item in (
        'summary.json', 'native-artifact.json', 'batch/batch-summary.json',
        'commands/node-lib-build.json', 'commands/node-lib-build.log',
        'commands/focused-native-batch.json', 'commands/focused-native-batch.log')]
    identities = {str(path): file_identity(path) for path in paths}
    old = json.loads(paths[0].read_text())
    artifact = json.loads(paths[1].read_text())
    batch = json.loads(paths[2].read_text())
    require(old.get('source') == S3 and old.get('component_validation_passed') is True
            and old.get('named_tests_passed') == 64
            and old.get('retained_controls_passed') == 52
            and old.get('supplemental_controls_passed') == 7
            and old.get('focused_extra_controls_passed') == 5
            and old.get('runner_sha256') == V2_SHA, 'existing positive completion differs')
    require(old.get('selection_provenance') == provenance
            and [tuple(row) for row in artifact.get('selected_tests', [])] == selection,
            'existing positive roster differs')
    require(artifact.get('source') == S3 and artifact.get('runner_sha256') == V2_SHA
            and artifact.get('cargo_artifact', {}).get('fresh') is False,
            'historical fresh artifact record differs')
    require(Path(artifact['executable']).resolve().is_relative_to(TARGET),
            'historical artifact did not use the completed positive target')
    require(batch.get('component_validation_passed') is True
            and batch.get('named_tests_passed') == 64
            and batch.get('artifact_sha256') == identities[str(paths[1])]['sha256'],
            'historical native batch completion differs')
    build, build_identity = verify_receipt(paths[3], S3)
    tested, tested_identity = verify_receipt(paths[5], S3)
    require(build_identity == identities[str(paths[3])]
            and tested_identity == identities[str(paths[5])], 'historical receipts changed during read')
    require(build['status'] == tested['status'] == 'command_succeeded'
            and build['exit_code'] == tested['exit_code'] == 0
            and build['argv'] == BUILD_COMMAND, 'historical positive commands differ')
    require(artifact['build_receipt_sha256'] == identities[str(paths[3])]['sha256']
            and artifact['build_log_sha256'] == identities[str(paths[4])]['sha256'],
            'historical build provenance hashes differ')
    require(TARGET.is_dir() and not TARGET.is_symlink(), 'completed positive target absent')
    return {'source': S3, 'target': str(TARGET), 'files': identities,
            'scope': 'cache directory provenance only; no C4 result is inherited',
            'historical_results_modified': False}


# 2. Per-command recorder: original static argv, serial execution, no hidden retries.
class Observation:
    def __init__(self, out, source, baseline, run_observed):
        self.out, self.source, self.baseline = out, source, baseline
        self.run_observed = run_observed
        self.commands, self.owners = out / 'commands', out / 'owners'
        self.commands.mkdir()
        self.owners.mkdir()
        self.rows = []

    def persist(self):
        write_json(self.out / 'observations.json', self.rows)

    def direct_owner(self, label, argv):
        log = self.owners / (label + '.log')
        started = time.monotonic_ns()
        with log.open('xb') as stream:
            process = subprocess.run(argv, cwd=ROOT, stdout=stream,
                                     stderr=subprocess.STDOUT, check=False)
        return {'command': argv, 'cwd': str(ROOT), 'exit_code': process.returncode,
                'process_exit_code': process.returncode, 'timed_out': False,
                'elapsed_ns': time.monotonic_ns() - started, 'log': log.name,
                'log_identity': file_identity(log), 'executed': True,
                'timeout_scope': 'durable job; original child owners retain their own caps',
                'owns_process_group': False}

    def recorded(self, label, command, owner_timeout=None):
        argv = [sys.executable, '-B', str(ROOT / 'scripts/ci/record_pq_native_command.py'),
                '--kind', 'head', '--candidate', self.source, '--tested', self.source,
                '--label', label, '--output', str(self.commands), '--', *command]
        row = {'label': label, 'command': command, 'source': self.source, 'status': 'running',
               'source_receipt': str(self.commands / (label + '.json'))}
        self.rows.append(row)
        self.persist()
        if owner_timeout is None:
            owner = self.direct_owner(label, argv)
        else:
            owner = self.run_observed(argv, self.owners / (label + '.log'),
                                      cwd=ROOT, timeout=owner_timeout)
        row['owner'] = owner
        try:
            receipt, receipt_identity = verify_receipt(Path(row['source_receipt']), self.source, self.baseline)
            require(receipt['argv'] == command, 'source receipt argv differs from requested command')
        except (OSError, ValueError, KeyError, TypeError) as exc:
            row.update(status='source_guard_or_record_failed', error=str(exc))
            self.persist()
            raise ValueError('stop after incomplete source guard: ' + label) from exc
        success = (owner['exit_code'] == 0 and not owner['timed_out']
                   and receipt['status'] == 'command_succeeded' and receipt['exit_code'] == 0)
        row.update(status='passed' if success else 'failed', exit_code=receipt['exit_code'],
                   receipt_identity=receipt_identity)
        self.persist()
        print(json.dumps({'gate': label, 'status': row['status'],
                          'exit_code': row['exit_code']}, sort_keys=True), flush=True)
        return success, receipt


# 3. Cached Cargo adapter; the existing 64-control native batch stays byte-identical.
def native_phase(obs, out, source, v2, selection, provenance, descriptor_digest):
    ok, receipt = obs.recorded('node-lib-build', BUILD_COMMAND, owner_timeout=3600)
    if not ok:
        return {'status': 'build_failed', 'batch_executed': False, 'passed': False}
    require(v2.select_controls(ROOT) == (selection, provenance), 'roster changed during build')
    source_file = ROOT / 'trillionnium/crates/trnm-pon-node/src/lib.rs'
    artifacts = []
    for line in (obs.commands / 'node-lib-build.log').read_text().splitlines():
        try:
            value = json.loads(line)
        except ValueError:
            continue
        if (isinstance(value, dict) and value.get('reason') == 'compiler-artifact'
                and value.get('target', {}).get('kind') == ['lib']
                and value.get('profile', {}).get('test') is True
                and value.get('executable')
                and Path(value['target']['src_path']).resolve() == source_file):
            artifacts.append(value)
    require(len(artifacts) == 1, 'expected exactly one actual Node libtest Cargo artifact')
    cargo_artifact = artifacts[0]
    executable = Path(cargo_artifact['executable'])
    require(executable.is_absolute() and '..' not in executable.parts
            and executable.resolve().is_relative_to(TARGET)
            and type(cargo_artifact.get('fresh')) is bool
            and {'pq-native-openssl', 'pq-root-v3'}.issubset(cargo_artifact['features']),
            'actual artifact is not the required all-features completed-target result')
    fd = os.open(executable, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        executable_sha, info = descriptor_digest(fd)
        require(os.pread(fd, 4, 0) == b'\x7fELF', 'Cargo test artifact is not ELF')
    finally:
        os.close(fd)
    artifact_path = out / 'native-artifact.json'
    write_json(artifact_path, {
        'source': source, 'executable': str(executable), 'selected_tests': selection,
        'selection_provenance': provenance, 'executable_sha256': executable_sha,
        'executable_bytes': info.st_size, 'device': info.st_dev, 'inode': info.st_ino,
        'cargo_artifact': cargo_artifact,
        'build_receipt_sha256': sha(obs.commands / 'node-lib-build.json'),
        'build_log_sha256': sha(obs.commands / 'node-lib-build.log'),
        'runner_sha256': V2_SHA, 'adapter_sha256': sha(__file__),
        'existing_completed_target_reuse_allowed': True,
        'fresh_target_claimed': False, 'cargo_fresh_value_preserved': True,
    })
    artifact_pin = sha(artifact_path)
    batch = out / 'batch'
    batch.mkdir()
    command = [sys.executable, str(V2), '_native_batch', str(ROOT), str(artifact_path),
               artifact_pin, str(batch), V2_SHA, '900']
    # No additional timeout/process-group around this batch. Its 65 invocations
    # (inventory plus 64 named tests) retain the original 900s owners in V2.
    ok, _ = obs.recorded('focused-native-batch', command)
    require(sha(artifact_path) == artifact_pin, 'native artifact record changed during batch')
    result = json.loads((batch / 'batch-summary.json').read_text())
    passed = (ok and result.get('component_validation_passed') is True
              and result.get('named_tests_passed') == 64
              and result.get('retained_controls_passed') == 52
              and result.get('supplemental_controls_passed') == 7
              and result.get('focused_extra_controls_passed') == 5
              and result.get('artifact_sha256') == artifact_pin
              and result.get('runner_sha256') == V2_SHA
              and result.get('whole_chain_quantum_security_qualified') is False
              and result.get('production_activation') is False)
    return {'status': 'passed' if passed else 'failed', 'passed': passed,
            'batch_executed': True, 'named_tests_passed': result.get('named_tests_passed'),
            'named_tests_required': 64, 'inventory_is_not_an_additional_named_control': True,
            'artifact_identity': file_identity(artifact_path),
            'batch_summary_identity': file_identity(batch / 'batch-summary.json'),
            'actual_cargo_fresh': cargo_artifact['fresh'], 'fresh_target_claimed': False}


# 4. Original launcher owns strict Clippy admission and its original 1800s cap.
def clippy_phase(obs, out, source):
    clippy_out = out / 'strict-clippy'
    require(not clippy_out.exists() and not clippy_out.with_name('strict-clippy-launch').exists(),
            'fresh Clippy output and launch paths required')
    argv = [sys.executable, '-B', str(LAUNCHER), '--mode', 'clippy', '--source', source,
            '--out', str(clippy_out), '--target', str(TARGET)]
    row = {'label': 'strict-clippy', 'command': argv, 'source': source, 'status': 'running'}
    obs.rows.append(row)
    obs.persist()
    row['owner'] = obs.direct_owner('strict-clippy-launcher', argv)
    receipt_path = clippy_out / 'strict-clippy.json'
    try:
        receipt, receipt_identity = verify_receipt(receipt_path, source, obs.baseline)
        launch_path = clippy_out.with_name('strict-clippy-launch') / 'launch.json'
        launch = json.loads(launch_path.read_text())
        require(launch.get('source') == source and launch.get('launcher_sha256') == LAUNCHER_SHA
                and launch.get('target') == str(TARGET), 'Clippy launcher identity differs')
        expected = ['timeout', '--signal=TERM', '--kill-after=10', '1800', 'cargo', '+1.95.0',
                    'clippy', '--locked', '--manifest-path', 'trillionnium/Cargo.toml',
                    '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings']
        require(receipt['argv'] == expected, 'original strict Clippy argv changed')
        passed = (row['owner']['exit_code'] == 0 and receipt['status'] == 'command_succeeded'
                  and receipt['exit_code'] == 0 and launch.get('status') == 'command_succeeded'
                  and launch.get('exit_code') == 0)
        row.update(status='passed' if passed else 'failed', exit_code=receipt['exit_code'],
                   source_receipt=str(receipt_path), receipt_identity=receipt_identity,
                   recorded_command=expected, launch_record=str(launch_path),
                   launch_identity=file_identity(launch_path))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        row.update(status='source_guard_or_record_failed', error=str(exc))
        obs.persist()
        raise
    obs.persist()
    print(json.dumps({'gate': 'strict-clippy', 'status': row['status'],
                      'exit_code': row['exit_code']}, sort_keys=True), flush=True)
    return passed


# 5. Exact committed-source admission, sequential schedule and truthful final ledger.
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--source-tree', required=True)
    parser.add_argument('--runner-sha', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    require(re.fullmatch('[0-9a-f]{40}', args.source), 'full committed C4 SHA required')
    require(re.fullmatch('[0-9a-f]{40}', args.source_tree), 'full committed C4 tree required')
    require(re.fullmatch('[0-9a-f]{64}', args.runner_sha), 'reviewed runner SHA256 required')
    require(file_identity(Path(__file__))['sha256'] == args.runner_sha, 'adapter digest differs')
    require(args.out.is_absolute() and '..' not in args.out.parts, 'canonical absolute output required')
    out = args.out.parent.resolve() / args.out.name
    require(not out.exists() and not out.is_symlink(), 'new C4 observation directory required')
    require(not out.is_relative_to(ROOT) and not out.is_relative_to(TARGET)
            and not TARGET.is_relative_to(out) and not ROOT.is_relative_to(out),
            'output must be separate from source and existing target')
    out.mkdir(parents=True, exist_ok=False)
    sys.dont_write_bytecode = True
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    record = {'schema': 'trnm-committed-c4-original-gates-observation-v1',
              'source': args.source, 'expected_tree': args.source_tree, 'status': 'running',
              'started_utc': datetime.now(timezone.utc).isoformat(),
              'runner_sha256': args.runner_sha, 'previous_positive_source': S3,
              'cache_policy': 'existing completed S3 target; actual Cargo fresh field unmodified',
              'fresh_target_claimed': False, 'original_business_budgets_changed': False,
              'whole_chain_quantum_security_qualified': False, 'production_activation': False,
              'outer_durable_timeout_seconds': 7200,
              'build_owner_timeout_seconds': 3600, 'per_native_invocation_timeout_seconds': 900,
              'strict_clippy_timeout_seconds': 1800,
              'static_commands_individual_timeout_not_invented': True,
              'native': {'status': 'not_started', 'passed': False},
              'clippy': {'status': 'not_started', 'passed': False}}
    write_json(out / 'progress.json', record)
    obs = None
    before = None
    verify = None
    prior = None
    provider = None
    helper_identities = None
    failure = None
    started = time.monotonic_ns()
    try:
        require(ROOT.is_dir() and not ROOT.is_symlink(), 'fixed source root is absent or symlinked')
        require(git('rev-parse', 'HEAD').decode().strip() == args.source, 'HEAD differs from C4')
        require(git('rev-parse', args.source + '^{tree}').decode().strip() == args.source_tree,
                'C4 tree differs')
        require(args.source != S3, 'C4 must be a distinct committed successor')
        require(git('rev-parse', S3 + '^{tree}').decode().strip() == S3_TREE, 'S3 base tree differs')
        subprocess.run(['git', '--no-replace-objects', 'merge-base', '--is-ancestor', S3, args.source],
                       cwd=ROOT, check=True)
        changed = [p.decode() for p in git('diff', '--name-only', '--no-renames', '-z', S3,
                                          args.source, '--').split(b'\0') if p]
        runtime_changes = [p for p in changed if runtime_or_graph(p)]
        boundary = {'base_source': S3, 'current_source': args.source, 'changed_paths': changed,
                    'rust_cargo_toolchain_config_changed_paths': runtime_changes,
                    'scope': 'all Rust sources, Cargo manifests/locks and Cargo/toolchain configuration'}
        write_json(out / 'source-boundary.json', boundary)
        require(not runtime_changes, 'unreviewed S3-to-C4 Rust/Cargo/toolchain change')
        require(not set(changed).intersection(UNCHANGED_HELPERS), 'original source/native helper changed')
        helper_identities = {}
        for path in UNCHANGED_HELPERS:
            actual, identity = read_regular_bytes(ROOT / path)
            expected = git('show', S3 + ':' + path)
            require(actual == expected, 'original helper worktree bytes differ before import: ' + path)
            helper_identities[path] = identity
        v2 = load_external('c4_original_native_v2', V2, V2_SHA)
        launcher = load_external('c4_original_provider_launcher', LAUNCHER, LAUNCHER_SHA)
        env, provider = provider_environment(launcher)
        os.environ.clear()
        os.environ.update(env)
        sys.path.insert(0, str(ROOT / 'scripts/ci'))
        source_module = importlib.import_module('verify_ci_source')
        owner_module = importlib.import_module('ci_observation')
        native_module = importlib.import_module('pinned_native_process')
        for module in (source_module, owner_module, native_module):
            require(Path(module.__file__).resolve().parent == ROOT / 'scripts/ci',
                    'repository helper imported from a different root')
        verify = source_module.verify
        before = verify('head', args.source, root=ROOT)
        require(before['tested_commit'] == args.source and before['tested_tree'] == args.source_tree,
                'initial physical source guard differs')
        write_json(out / 'source-before.json', before)
        selection, provenance = v2.select_controls(ROOT)
        prior = prior_positive_provenance(v2, selection, provenance)
        write_json(out / 'prior-target-provenance.json', prior)
        write_json(out / 'provider.json', provider)
        gates = [(label, list(argv)) for label, argv in ORIGINAL13]
        gates += [
            ('root-register-controls', ['python3', 'scripts/ci/test_pq_root_dependency_register.py', '-v']),
            ('root-register-reproduce', ['python3', 'scripts/ci/pq_root_dependency_register.py', '--root', '.']),
            ('root-register-report-cmp', ['cmp', '--', REPORT,
                                        str(out / 'commands/root-register-reproduce.log')]),
            ('corpus-controls', ['python3', 'scripts/ci/test_pq_research_integration.py']),
            ('claim-controls', ['python3', 'scripts/ci/test_pq_chain_claim_guard.py']),
        ]
        ci_tests_needed = (any(p.startswith('.github/workflows/') for p in changed)
                           or bool(set(changed) & {'scripts/ci/check_ci_contract.py',
                                                  'scripts/ci/test_ci_contract.py'}))
        if ci_tests_needed:
            gates.append(('ci-contract-controls', ['python3', 'scripts/ci/test_ci_contract.py']))
        write_json(out / 'plan.json', {
            'source': args.source, 'tree': args.source_tree, 'runner_sha256': args.runner_sha,
            'original13_reference_sha256': REFERENCE_SHA,
            'original13_historical_summary_sha256': ORIGINAL13_SUMMARY_SHA,
            'historical_summary_is_command_reference_only': True,
            'commands': [{'label': label, 'argv': argv} for label, argv in gates],
            'ci_contract_controls_required_by_changed_paths': ci_tests_needed,
            'selected_tests': selection, 'selection_provenance': provenance,
            'current_root_report': {'path': REPORT, **file_identity(ROOT / REPORT)},
            'original_v2_sha256': V2_SHA, 'original_launcher_sha256': LAUNCHER_SHA,
            'original_helper_identities': helper_identities, 'execution_order': 'serial',
            'native_batch_has_no_additional_timed_process_group': True,
        })
        obs = Observation(out, args.source, before, owner_module.run)
        for label, command in (
            ('preflight', ['bash', 'scripts/project-preflight.sh']),
            ('compiler', ['rustc', '+1.95.0', '-Vv']),
        ):
            ok, _ = obs.recorded(label, command, owner_timeout=180)
            require(ok, 'admission command failed: ' + label)
        for label, command in gates:
            # Ordinary failures remain in the ledger; the recorder's completed,
            # identical physical-source guards are required before proceeding.
            obs.recorded(label, command)
        record['static_gates_completed'] = True
        record['native'] = native_phase(obs, out, args.source, v2, selection, provenance,
                                         native_module.descriptor_digest)
        write_json(out / 'progress.json', record)
        passed = clippy_phase(obs, out, args.source)
        record['clippy'] = {'status': 'passed' if passed else 'failed', 'passed': passed}
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as exc:
        failure = str(exc)
        record['error'] = failure
    finally:
        checks = {}
        try:
            require(verify is not None and before is not None, 'initial physical identity unavailable')
            final = verify('head', args.source, root=ROOT)
            write_json(out / 'source-final.json', final)
            require(final == before, 'final physical source differs from initial C4 identity')
            checks['physical_source_unchanged'] = True
            require(file_identity(__file__)['sha256'] == args.runner_sha, 'adapter changed during run')
            require(file_identity(V2)['sha256'] == V2_SHA
                    and file_identity(LAUNCHER)['sha256'] == LAUNCHER_SHA, 'original external helper changed')
            require({p: file_identity(ROOT / p) for p in UNCHANGED_HELPERS} == helper_identities,
                    'original repository helper bytes changed')
            checks['source_and_external_helpers_unchanged'] = True
            completed_records = 0
            for row in (obs.rows if obs is not None else []):
                if 'receipt_identity' not in row:
                    continue
                receipt, identity = verify_receipt(Path(row['source_receipt']), args.source, before)
                require(identity == row['receipt_identity'], 'completed command receipt changed: ' + row['label'])
                require(receipt['argv'] == row.get('recorded_command', row['command']),
                        'completed command argv changed: ' + row['label'])
                if 'launch_identity' in row:
                    require(file_identity(row['launch_record']) == row['launch_identity'],
                            'completed launcher record changed: ' + row['label'])
                completed_records += 1
            checks['completed_command_evidence_unchanged'] = True
            checks['completed_source_receipts_revalidated'] = completed_records
            require(prior is not None, 'historical cache origin was not established')
            require({p: file_identity(p) for p in prior['files']} == prior['files'],
                    'historical S3 positive evidence changed')
            checks['historical_s3_evidence_unchanged'] = True
            # Recheck pinned provider bytes without treating our already loaded
            # canonical OPENSSL_* keys as newly supplied ambient values.
            require(provider is not None, 'provider identity unavailable')
            require(file_identity(launcher.PROVIDER_ROOT / 'github-env')['sha256'] == launcher.ENV_SHA
                    and file_identity(launcher.PROVIDER_ROOT / 'receipts/pq-provider/provider.json')['sha256']
                    == launcher.RECEIPT_SHA, 'provider metadata changed')
            require(all(file_identity(launcher.PREFIX / p)['sha256'] == expected
                        for p, expected in launcher.ARTIFACTS.items()), 'provider artifact changed')
            checks['provider_bytes_unchanged'] = True
        except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as exc:
            checks['final_guard_error'] = str(exc)
        record['final_guards'] = checks
        rows = obs.rows if obs is not None else []
        record['observations'] = rows
        complete = (failure is None and record.get('static_gates_completed') is True
                    and record['native'].get('passed') is True
                    and record['clippy'].get('passed') is True
                    and rows and all(row.get('status') == 'passed' for row in rows)
                    and 'final_guard_error' not in checks)
        record.update(status='passed' if complete else 'failed',
                      all_requested_gates_passed=bool(complete),
                      finished_utc=datetime.now(timezone.utc).isoformat(),
                      elapsed_ns=time.monotonic_ns() - started)
        write_json(out / 'summary.json', record)
        write_json(out / 'progress.json', record)
        print(json.dumps({'source': args.source, 'status': record['status'],
                          'output': str(out), 'error': failure}, sort_keys=True), flush=True)
    return 0 if record['all_requested_gates_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
