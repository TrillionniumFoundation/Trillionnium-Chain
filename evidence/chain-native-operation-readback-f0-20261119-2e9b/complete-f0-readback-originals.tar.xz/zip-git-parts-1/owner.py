from pathlib import Path
import json,hashlib,sys,time,resource
root=Path('/home/qian-qi/work/chain-native-operation-readback-f0-20261119-2e9b');out=root/'zip-git-parts-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);start=time.monotonic();b=resource.getrusage(resource.RUSAGE_SELF)
raw=(root/'collection/artifact-14496651186.zip').read_bytes();assert len(raw)==17640478 and hashlib.sha256(raw).hexdigest()=='744a0d353fb5055fd111cb5acae33259c0e526a8e4240a8f33752d01bfac5ccd'
rows=[]
for i,offset in enumerate(range(0,len(raw),9000000)):
 chunk=raw[offset:offset+9000000];name='f0-original.zip.part-'+str(i).zfill(3);path=out/name
 with path.open('xb') as f:f.write(chunk)
 rows.append({'path':name,'absolute_path':str(path),'offset':offset,'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(chunk)).encode()+b'\0'+chunk).hexdigest()})
assert b''.join((out/r['path']).read_bytes() for r in rows)==raw
a=resource.getrusage(resource.RUSAGE_SELF)
result={'schema':'chain-exact-original-f0-zip-parts-v1','head':'3db79eb2682ba3bcbbf33557c5eee3b67731028f','run_id':44451798839,'archive_name':'f0-original.zip','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'full_content_git_blob':'92eddc7cbd4d6b489c98a5e8a2414b6d107a32bc','full_blob_uploaded':False,'lossless_concatenation_verified':True,'parts':rows,'wall_seconds':time.monotonic()-start,'self_user_cpu_seconds':a.ru_utime-b.ru_utime,'self_system_cpu_seconds':a.ru_stime-b.ru_stime,'reason':'Complete native gh upload returned401; connector whole body was rejected by16MiB transport limit; same bytes split into two ordinary supported blobs. No credentials changed and no workload repeated.'}
(out/'MANIFEST.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
