"""One synthetic table control: reject stale panic positions for committed S3.

This invokes only the Python failure observer. It dispatches no native process
and does not alter any repository source or test.
"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
RUNNER = Path('/tmp/chain-pq-fa62381e-negative-validation-v3.py')
RUNNER_SHA = '58e2fa946a7dc34cf58e8b357e04c2789da98f8b6218768d8e29651c6cf6b6f7'
SOURCE = Path('/tmp/chain-pq-fa62381e-s3-account_scope_tests.rs')
SOURCE_SHA = '7da5594a8b7e9a61ce147426272ec4b74e167f2b9a55c8fe5c525269082e610d'
SOURCE_COMMIT = '454ae116159867ff6cddd91b964523df7f7e16f0'
SOURCE_BLOB = '676fd6dfa77bf00ad8367885110bd223b51b8391'
ACCOUNT_PATH = 'trillionnium/crates/trnm-pon-node/src/ingress/account_scope_tests.rs'

runner_bytes = RUNNER.read_bytes()
assert hashlib.sha256(runner_bytes).hexdigest() == RUNNER_SHA
source_bytes = SOURCE.read_bytes()
assert len(source_bytes) == 9480
assert hashlib.sha256(source_bytes).hexdigest() == SOURCE_SHA
assert hashlib.sha1(b'blob ' + str(len(source_bytes)).encode() + b'\0' + source_bytes).hexdigest() == SOURCE_BLOB
source_lines = source_bytes.decode().splitlines()

spec = importlib.util.spec_from_file_location('negative_observer_v3_source_lines', RUNNER)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# Obtain the reviewed line constants from the loaded runner's actual lineage
# reader, rather than supplying a second independent set of expectations.
tree = ast.parse(runner_bytes)
lineage = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'verify_lineage')
assignment = next(node for node in lineage.body if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == 'expected' for target in node.targets))
current_lines = []
for node in assignment.value.elts[:3]:
    item = next(value for key, value in zip(node.keys, node.values)
                if isinstance(key, ast.Constant) and key.value == 'panic_line')
    current_lines.append(ast.literal_eval(item))
assert current_lines == [73, 90, 154]
assert source_lines[current_lines[0] - 1].strip() == '.unwrap_err();'
assert source_lines[current_lines[1] - 1].strip() == 'let error = authenticate_request(&wire, &settings, &server).unwrap_err();'
assert source_lines[current_lines[2] - 1].strip() == 'assert_eq!('
assert source_lines[current_lines[2]].strip() == 'connections, 0,'

unwrap_marker = 'called ' + chr(96) + 'Result::unwrap_err()' + chr(96) + ' on an ' + chr(96) + 'Ok' + chr(96) + ' value'
markers = [
    [unwrap_marker],
    [unwrap_marker],
    ['authenticated production_activation-wrong, protected=false', 'left: 1', 'right: 0'],
]
rows = []
for index, (old_line, current_line) in enumerate(zip([69, 86, 148], current_lines)):
    name = mod.SELECTION[index][1]
    expected = {'test': name, 'source_file': ACCOUNT_PATH,
                'panic_line': current_line, 'markers': markers[index]}
    message = '\n'.join(markers[index])
    def transcript(line):
        return (f'running 1 test\ntest {name} ... FAILED\n\nfailures:\n\n---- {name} stdout ----\n\n'
                f'thread {name!r} (123) panicked at crates/trnm-pon-node/src/ingress/account_scope_tests.rs:{line}:14:\n'
                f'{message}\n\nfailures:\n    {name}\n\n'
                'test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 1420 filtered out; finished in 0.01s\n')
    accepted = mod.validate_failed(transcript(current_line), expected)
    assert accepted['panic_line'] == current_line
    assert accepted['expected_assertion_failure_observed'] is True
    try:
        mod.validate_failed(transcript(old_line), expected)
    except ValueError as exc:
        refusal = str(exc)
        assert refusal == 'negative control failed outside the reviewed assertion'
    else:
        raise AssertionError(f'stale assertion line {old_line} accepted for {name}')
    rows.append({'test': name, 'current_line': current_line, 'stale_line': old_line,
                 'current_position_fixture_accepted': True, 'stale_position_fixture_rejected': True,
                 'refusal': refusal, 'same_semantic_markers': True})

result = {
    'scope': 'synthetic Python reviewed-source panic-position classifier only',
    'runner_sha256': RUNNER_SHA,
    'selftest_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'source_commit': SOURCE_COMMIT, 'source_path': ACCOUNT_PATH,
    'source_git_blob_sha1': SOURCE_BLOB, 'source_sha256': SOURCE_SHA,
    'table_controls_passed': 1, 'table_controls_required': 1,
    'cases_passed': len(rows), 'cases_required': 3, 'cases': rows,
    'actual_native_tests_executed': False, 'native_builds_executed': False,
    'component_validation_passed': False,
}
output = Path('/tmp/chain-pq-fa62381e-negative-source-lines-selftest-v3.json')
assert not output.exists()
output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True))
