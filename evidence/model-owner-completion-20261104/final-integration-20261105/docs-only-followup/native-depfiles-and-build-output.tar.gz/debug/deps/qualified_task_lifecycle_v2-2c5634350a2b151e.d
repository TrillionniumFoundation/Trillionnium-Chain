/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/qualified_task_lifecycle_v2-2c5634350a2b151e.d: crates/trnm-mvcc-fee/tests/qualified_task_lifecycle_v2.rs Cargo.toml

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libqualified_task_lifecycle_v2-2c5634350a2b151e.rmeta: crates/trnm-mvcc-fee/tests/qualified_task_lifecycle_v2.rs Cargo.toml

crates/trnm-mvcc-fee/tests/qualified_task_lifecycle_v2.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
