#!/usr/bin/env python3
"""Retain only actual static/component commands; never compile or qualify Node."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import time

ROOT = Path('/workspace/scratch/bb9b841c1d43/history-startup-no-native')
BASE = 'b760ee01cd68362048f9f3cc5221c1ea2904f19e'
IMPLEMENTATION = '8c84a13f8ee64a29f93816fdc417dc726bea9b25'
RAW = Path('/tmp/history-startup-no-native-static-01')
OUT = ROOT / 'evidence/pon-history-startup-no-native-20261028/static-01'
TOOLCHAIN = Path('/workspace/scratch/301262829a43/pon-build-inputs/unpacked/toolchain/bin')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def snapshot():
    result = []
    for raw_path in git('ls-files', '-z').split(b'\0'):
        if not raw_path:
            continue
        relative = raw_path.decode()
        if relative.startswith('evidence/'):
            continue
        path = ROOT / relative
        m = path.lstat()
        assert stat.S_ISREG(m.st_mode), relative
        raw = path.read_bytes()
        result.append(dict(path=relative, mode=oct(stat.S_IMODE(m.st_mode)), bytes=len(raw), sha256=sha(raw)))
    return result

def retained_contract():
    path = 'scripts/ci/run_history_effect_v6_native.py'
    old, new = [ast.parse(value) for value in [git('show', BASE+':'+path).decode(), (ROOT/path).read_text()]]
    def assignment(tree, name):
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets):
                return ast.dump(node.value, include_attributes=False)
        raise AssertionError(name)
    names = ['PREFIX', 'HELPER', 'ORIGINAL_ROSTER', 'STARTUP_ROSTER', 'FOLLOWUP_ROSTER', 'MATERIAL_ROSTER']
    for name in names:
        assert assignment(old, name) == assignment(new, name), name
    path = 'scripts/ci/history_effect_v6_process_guard.py'
    trees = [ast.parse(value) for value in [git('show', BASE+':'+path).decode(), (ROOT/path).read_text()]]
    functions = [{n.name: ast.dump(n, include_attributes=False) for n in tree.body
                  if isinstance(n, ast.FunctionDef) and n.name != 'main'} for tree in trees]
    assert functions[0] == functions[1]
    sys.path.insert(0, str(ROOT / 'scripts/ci'))
    import run_history_effect_v6_native as runner
    assert len(runner.ROSTER) == 23 and len(set(runner.ROSTER)) == 23
    assert len(runner.ORIGINAL_ROSTER) == 16 and len(runner.STARTUP_ROSTER) == 4
    assert len(runner.FOLLOWUP_ROSTER) == 2 and len(runner.CLOSURE_ROSTER) == 1
    assert runner.SOURCE_ENV == 'TRNM_HISTORY_STARTUP_NO_NATIVE_SOURCE_COMMIT'
    source = (ROOT/'scripts/ci/run_history_effect_v6_native.py').read_text()
    for required in ["output / 'native', 600, env", "'runtime_burst_ns': 2_000_000_000",
                     "'fixture_operation_allowance_ns': 4_000_000_000",
                     "'complete_parent_snapshot_attempts': 4"]:
        assert required in source, required
    tracked = set(p.decode() for p in git('ls-files','-z').split(b'\0') if p)
    targets = []
    for name in git('diff','--name-only',BASE,IMPLEMENTATION).decode().splitlines():
        if not name.endswith('.md'):
            continue
        path = ROOT/name
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', path.read_text()):
            if '://' in target or target.startswith('#'):
                continue
            relative = (path.parent / target.split('#',1)[0]).resolve().relative_to(ROOT).as_posix()
            assert relative in tracked, (name, target, relative)
            targets.append(dict(source=name, target=relative, exists_in_exact_tree=True))
    return dict(retained_assignments=names, unchanged_observer_functions=list(functions[0]),
                configured_roster=runner.ROSTER, native_inventory_executed=False,
                original_limits_retained=True, markdown_links=targets)

def main():
    assert git('rev-parse','HEAD').decode().strip() == IMPLEMENTATION
    assert not git('status','--porcelain').strip()
    RAW.mkdir()
    OUT.mkdir(parents=True)
    shutil.copyfile(__file__, RAW/'driver.py')
    env = os.environ.copy()
    env.update(PATH=str(TOOLCHAIN)+os.pathsep+env['PATH'],
               CARGO_HOME='/workspace/scratch/bb9b841c1d43/history-cargo-home',
               CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='1', PYTHONDONTWRITEBYTECODE='1')
    before = snapshot()
    write(RAW/'source-before.json', before)
    receipts=[]
    commands=[
        ('preflight', ['bash','scripts/project-preflight.sh','--audit'], 60, None),
        ('format', ['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--check'], 60, None),
        ('namespace-observer', [sys.executable,'-m','unittest','discover','-s','scripts/ci','-p','test_history_startup_no_native_guard.py','-v'], 60, 4),
        ('original-process-observer', [sys.executable,'-m','unittest','discover','-s','scripts/ci','-p','test_history_effect_v6_guard.py','-v'], 60, 4),
        ('native-runner', [sys.executable,'-m','unittest','discover','-s','scripts/ci','-p','test_history_effect_v6_native_runner.py','-v'], 60, 5),
        ('source-integrity', [sys.executable,'-m','unittest','discover','-s','scripts/ci','-p','test_ci_source_integrity.py','-v'], 60, 34),
        ('project-boundary', [sys.executable,'-m','unittest','discover','-s','scripts/ci','-p','test_project_boundary.py','-v'], 60, 16),
        ('inventory', [sys.executable,'scripts/refresh_distributed_source_inventory.py','--check'], 60, None),
        ('metadata', ['cargo','metadata','--manifest-path','trillionnium/Cargo.toml','--offline','--locked','--no-deps','--format-version','1'], 60, None),
        ('diff-check', ['git','diff','--check'], 60, None),
    ]
    for name, args, limit, count in commands:
        started=time.time_ns()
        path=RAW/(name+'.log')
        with path.open('xb') as out:
            result=subprocess.run(args,cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=limit)
        raw=path.read_bytes()
        receipt=dict(name=name,command=args,returncode=result.returncode,started_ns=started,
                     ended_ns=time.time_ns(),timeout_seconds=limit,raw_bytes=len(raw),raw_sha256=sha(raw))
        passed=result.returncode==0
        if count is not None:
            actual=re.findall(rb'^Ran (\d+) tests? in ',raw,re.M)
            receipt['expected_test_count']=count
            receipt['actual_test_counts']=[int(n) for n in actual]
            passed=passed and actual==[str(count).encode()] and re.search(rb'^OK$',raw,re.M) is not None
        if name=='metadata' and passed:
            metadata=json.loads(raw)
            receipt['workspace_members']=len(metadata['workspace_members'])
            passed=receipt['workspace_members']==25
        receipt['passed']=passed
        receipts.append(receipt)
        write(RAW/(name+'-receipt.json'),receipt)
        print(name, 'PASS' if passed else 'FAIL',flush=True)
    contract=retained_contract()
    write(RAW/'retained-contract.json',contract)
    after=snapshot()
    write(RAW/'source-after.json',after)
    v=os.statvfs(ROOT)
    terminal=dict(schema='history-first-startup-static-component-terminal-v1',
                  implementation_commit=IMPLEMENTATION,implementation_tree=git('rev-parse','HEAD^{tree}').decode().strip(),
                  parent_commit=BASE,commands=receipts,source_unchanged=before==after,
                  source_files=len(before),source_before_sha256=sha((RAW/'source-before.json').read_bytes()),
                  source_after_sha256=sha((RAW/'source-after.json').read_bytes()),
                  node_compile='NOT_RUN',native_full_22_0_1='NOT_RUN',node_clippy='NOT_RUN',
                  local_disk_free_bytes=v.f_bavail*v.f_frsize,retained_local_compile_floor_bytes=256*1024**2,
                  no_compile_reason='Original 256 MiB floor and explicit no-large-local-build instruction; requires independent hosted exact-source execution.',
                  native_budget_seconds=600,runtime_burst_ns=2_000_000_000,operation_allowance_ns=4_000_000_000,
                  complete_parent_snapshot_attempts=4,whole_history_p0_closed=False,
                  passed=all(r['passed'] for r in receipts) and before==after)
    write(RAW/'terminal.json',terminal)
    rows=[]
    for path in sorted(RAW.rglob('*')):
        m=path.lstat()
        assert stat.S_ISREG(m.st_mode)
        raw=path.read_bytes()
        rows.append(dict(path=path.relative_to(RAW).as_posix(),bytes=len(raw),sha256=sha(raw),
                         mode=oct(stat.S_IMODE(m.st_mode)),uid=m.st_uid,gid=m.st_gid,mtime_ns=m.st_mtime_ns))
    archive=OUT/'raw-data.tar.gz'
    with tarfile.open(archive,'x:gz',format=tarfile.PAX_FORMAT) as tar:
        for row in rows:
            tar.add(RAW/row['path'],arcname=row['path'],recursive=False)
    with tarfile.open(archive,'r:gz') as tar:
        assert tar.getnames()==[r['path'] for r in rows]
        for row in rows:
            info=tar.getmember(row['path'])
            assert info.isfile() and info.size==row['bytes'] and oct(info.mode)==row['mode']
            assert sha(tar.extractfile(info).read())==row['sha256']
    write(OUT/'members.json',dict(schema='history-full-static-raw-members-v1',archive=archive.name,
          archive_bytes=archive.stat().st_size,archive_sha256=sha(archive.read_bytes()),
          original_raw_directory=str(RAW),source_test_fixture_credentials_only=True,
          complete_member_readback_passed=True,members=rows))
    write(OUT/'terminal.json',terminal)
    print(json.dumps({k:terminal[k] for k in ['passed','source_unchanged','source_files','node_compile','native_full_22_0_1','node_clippy']}))
    return 0 if terminal['passed'] else 1

if __name__=='__main__':
    raise SystemExit(main())
