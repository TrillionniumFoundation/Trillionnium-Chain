"""Inject a file swap after actual inference and inspect the claimed model bytes.

Only a tiny fabricated model is used. This is an input-identity regression,
not new training, efficacy evidence, or an independent consumer receipt.
"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import copy
import hashlib
import json
import subprocess
import sys
import tempfile

ROOT = Path('/workspace/scratch/51e4e62b58cf/chain')
FORMAL = ROOT / 'formal/pon-nakamoto-v1'
sys.path.insert(0, str(FORMAL))
from contract_wire import H, canonical
from experiments import model_loop
from test_evaluation_bundle import model, rows

source_file = FORMAL / 'experiments/model_loop.py'
before = hashlib.sha256(source_file.read_bytes()).hexdigest()
loaded = model(1)
replacement = copy.deepcopy(loaded)
replacement['base'][0][0] = 11  # This fixture's first feature is zero: outputs stay equal.
loaded_raw, replacement_raw = canonical(loaded), canonical(replacement)
assert loaded_raw != replacement_raw
real_predict = model_loop.predict
calls = []
with tempfile.TemporaryDirectory(prefix='consumer-model-swap-') as directory:
    folder = Path(directory)
    model_path = folder / 'model.json'
    tasks_path = folder / 'consumer.json'
    output = folder / 'inference.json'
    model_path.write_bytes(loaded_raw)
    tasks = rows('consumer', count=3)
    tasks_path.write_bytes(canonical(tasks))
    def swap_after_predict(actual, data, *args, **kwargs):
        computed = real_predict(actual, data, *args, **kwargs)
        calls.append(dict(actual_model=H('artifact', canonical(actual)).hex(),
                          output=computed.tolist()))
        model_path.write_bytes(replacement_raw)
        return computed
    with patch.object(model_loop, 'predict', side_effect=swap_after_predict):
        model_loop.worker(SimpleNamespace(mode='infer', tasks=str(tasks_path),
                                          model=str(model_path), out=str(output)))
    receipt = json.loads(output.read_bytes())
    correct_hash = H('artifact', loaded_raw).hex()
    replaced_hash = H('artifact', replacement_raw).hex()
    result = dict(schema='consumer-model-bytes-swap-probe-v1',
                  command=[sys.executable, str(Path(__file__).resolve())],
                  source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                  source_sha256=before,
                  source_unchanged=before == hashlib.sha256(source_file.read_bytes()).hexdigest(),
                  loaded_model=correct_hash,
                  replacement_model=replaced_hash,
                  artifact_reported_by_actual_worker=receipt['model_artifact'],
                  binds_actually_loaded_bytes=receipt['model_artifact'] == correct_hash,
                  final_file_has_replacement_bytes=model_path.read_bytes() == replacement_raw,
                  model_predict_calls=calls,
                  both_models_predict_same_outputs=real_predict(replacement, [r['x'] for r in tasks]).tolist() == receipt['predictions'],
                  training_consent=receipt['training_consent'],
                  scope='tiny fabricated inference; physical file replacement injected at predict return; no training/efficacy/production claim')
    print(json.dumps(result, sort_keys=True, indent=2))
    if not result['binds_actually_loaded_bytes'] or not result['source_unchanged']:
        raise SystemExit(1)
