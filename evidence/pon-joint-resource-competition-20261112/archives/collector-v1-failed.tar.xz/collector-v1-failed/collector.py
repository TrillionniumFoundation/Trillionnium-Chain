#!/usr/bin/env python3
"""Collect previously executed evidence. Does not execute repository tests or simulators."""
import datetime, hashlib, io, json, math, os, pathlib, re, shutil, stat, subprocess, sys, tarfile, traceback
from evidence_formal_validator import validate_formal_and_posthoc
from evidence_ci_validator import validate_ci
A="43e5c9d6b668276d03e1c7a76f467ec211e1d7dc"
AT="beac87c2431d149dbd6d2de4a2e1eaf0617520cc"
A2="17449baa42429ac98b55c100b1c523ff0abe40d0"
ROOT=pathlib.Path("/home/qian-qi/work/chain-daa-resource-competition-20261112-600e")
STAGE=ROOT.parent/"chain-daa-evidence-stage-600e"
OUT=ROOT.parent/"chain-daa-evidence-final-600e"
PACKET=OUT/"packet"
N=ROOT.parent/"chain-daa-A-43e5c9d6-native-600e"
SUPPORT=ROOT.parent/"chain-daa-native-support-600e"
F=ROOT.parent/"chain-daa-resource-formal-20261112-600e-43e5c9d6b668"
C=F/"campaign"
P=ROOT.parent/"chain-daa-posthoc-600e"
OLD_CI=ROOT.parent/"chain-daa-ci-gates-600e"/("head-"+A)
NEW_CI=ROOT.parent/"chain-daa-ci-gates-600e/ci-guard-repair-and-freeze-v1"
NATIVE_RECEIPT_SHA="f028e870242e0e072ff7e6b3c52682c95720730b6acf7d44537ddde1d1198708"
NATIVE_MANIFEST_SHA="536ad7cb891ec669a9da3e35c0fd7bf1d23aedabef2f9f9ab1cae332fd7064e2"
SOURCE_ARCHIVE_SHA="603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a"
SHA_RE=re.compile(r"[0-9a-f]{64}\Z")
def need(condition,message):
    if not condition: raise ValueError(message)
def uint(x):
    return type(x) is int and x>=0
def pairs(items):
    d={}
    for key,value in items:
        need(key not in d,"duplicate JSON key: "+key);d[key]=value
    return d
def finite(s):
    value=float(s);need(math.isfinite(value),"nonfinite JSON number");return value
def bad_constant(s): raise ValueError("nonfinite JSON constant "+s)
def decode(raw):
    return json.loads(raw,object_pairs_hook=pairs,parse_float=finite,parse_constant=bad_constant)
def read_json(p):
    return decode(pathlib.Path(p).read_bytes())
def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p):
    h=hashlib.sha256()
    with pathlib.Path(p).open("rb") as f:
        while chunk:=f.read(1024*1024): h.update(chunk)
    return h.hexdigest()
def safe(rel):
    need(type(rel) is str and rel and "\\" not in rel,"invalid relative path")
    p=pathlib.PurePosixPath(rel)
    need(not p.is_absolute() and ".." not in p.parts and "." not in p.parts and p.as_posix()==rel,"unsafe relative path "+rel)
    return rel
def ident(p):
    p=pathlib.Path(p);st=p.lstat()
    need(stat.S_ISREG(st.st_mode) and not p.is_symlink(),"nonregular file "+str(p))
    return {"bytes":st.st_size,"sha256":sha_file(p)}
def snapshot(root):
    root=pathlib.Path(root);need(root.is_dir() and not root.is_symlink(),"missing/unsafe directory "+str(root))
    result={}
    for current,dirs,files in os.walk(root,followlinks=False):
        for d in dirs:need(not pathlib.Path(current,d).is_symlink(),"symlink directory")
        for name in files:
            p=pathlib.Path(current,name);rel=safe(p.relative_to(root).as_posix())
            result[rel]=ident(p)
    return dict(sorted(result.items()))
def validate_map(root,expected,extra=()):
    need(type(expected) is dict,"file map required")
    actual=snapshot(root)
    need(set(actual)==set(expected)|set(extra),"file set mismatch "+str(root))
    for rel,record in expected.items():
        safe(rel);need(set(record)=={"bytes","sha256"} and uint(record["bytes"]) and type(record["sha256"]) is str and SHA_RE.fullmatch(record["sha256"]),"invalid identity "+rel)
        need(actual[rel]==record,"file identity mismatch "+str(root/rel))
    return actual
def checked_identity(p,expected):
    need(ident(p)==expected,"pinned artifact mismatch "+str(p))
def write_json(p,obj):
    p=pathlib.Path(p);need(not p.exists(),"refuse overwrite "+str(p))
    p.write_text(json.dumps(obj,sort_keys=True,indent=2,allow_nan=False)+"\n")
def state(stage,**more):
    value={"schema":"trnm-joint-resource-packet-status-v1","stage":stage,"source_A":A,"source_A2":A2,"updated_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),**more}
    t=OUT/"status.tmp";t.write_text(json.dumps(value,sort_keys=True)+"\n");t.replace(OUT/"status.json")
    print(json.dumps({"stage":stage,**more},sort_keys=True),flush=True)
def git(*args):
    p=subprocess.run(["/usr/bin/git","--no-replace-objects",*args],cwd=ROOT,env={**os.environ,"GIT_OPTIONAL_LOCKS":"0"},stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    need(p.returncode==0,"read-only Git failure: "+p.stderr.decode(errors="replace"))
    return p.stdout
def validate_stage():
    receipt_path=STAGE/"stage-A-receipt.json"
    if not receipt_path.is_file():
        p=subprocess.run(["systemctl","--user","show","hepta-runtime-job-1a1cecddef9-2564-1859","--property=ActiveState,SubState,Result,ExecMainStatus"],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
        (OUT/"missing-stage-original-job.stdout.log").write_bytes(p.stdout)
        (OUT/"missing-stage-original-job.stderr.log").write_bytes(p.stderr)
        raise ValueError("original stage receipt absent; original job inspected, partial stage not overwritten")
    receipt=read_json(receipt_path)
    need(receipt["schema"]=="trnm-joint-daa-evidence-stage-v1" and receipt["source_A"]==A and receipt["release_ready"] is False,"stage schema/source")
    expected={}
    for row in receipt["files"]:
        rel=safe(row["path"]);need(rel not in expected,"duplicate stage member")
        expected[rel]={"bytes":row["bytes"],"sha256":row["sha256"]}
    actual=validate_map(STAGE,expected,("stage-A-receipt.json",))
    pins={
      "source-freeze.json":"9f8d50b50de62ae367178cc31c55b8ff83d182a284d3364b1218529c57d4bfa3",
      "formal-execution-summary-A.json":"cdbc237bbad5e0ad9eead69b00fce17f715d1491501d57fb2b4e2e2a947666d9",
      "ci-summary-A-failed.json":"fffe3fae73115b1227a711148b3402f513bbb523abc06cc4481bfc5fd7e8e811",
      "formal-runner.py":"14fd0d544175896e36c2331b194fc8a891ff90b39b779ae6b7d63f13e0c0f56f",
      "ci-runner-A.py":"c7e211a71620ce161ce53a29f468a3b9796eb58ef18714192ee31ffcd9a0612c"}
    for name,digest in pins.items():need(actual[name]["sha256"]==digest,"stage anchor mismatch "+name)
    checked_identity(STAGE/"original-attempts/cloud-development-preserved.tar.gz",{"bytes":32359,"sha256":"7117c81df1b1783ec75625f4396832fea064bbe23bfb59d7e30b19cecc49834b"})
    with tarfile.open(STAGE/"original-attempts/cloud-development-preserved.tar.gz","r:gz") as tf:
        members=tf.getmembers();need(len(members)==10,"cloud archive member count")
        seen=set()
        for m in members:
            safe(m.name);need(m.isfile() and m.name not in seen,"unsafe cloud archive member");seen.add(m.name)
            need(len(tf.extractfile(m).read())==m.size,"cloud archive truncated")
    archives=read_json(STAGE/"raw-archive-inventory-A.json")
    need(set(archives)=={"source-freeze","development-controls","formal-validation-A","ci-validation-A-failed"},"original archive roster")
    for label,meta in archives.items():
        path=STAGE/"archives"/(label+".tar.xz")
        checked_identity(path,{"bytes":meta["archive_bytes"],"sha256":meta["archive_sha256"]})
        expected_members={}
        for row in meta["members"]:
            rel=safe(row["path"]);need(rel not in expected_members,"duplicate archived original")
            expected_members[rel]={"bytes":row["bytes"],"sha256":row["sha256"]}
        seen=set()
        with tarfile.open(path,"r:xz") as tf:
            for m in tf:
                need(m.isfile() and m.name.startswith(label+"/"),"unsafe original tar member")
                rel=safe(m.name[len(label)+1:]);need(rel in expected_members and rel not in seen,"unexpected original tar member")
                h=hashlib.sha256();n=0
                with tf.extractfile(m) as f:
                    while b:=f.read(1024*1024):h.update(b);n+=len(b)
                need({"bytes":n,"sha256":h.hexdigest()}==expected_members[rel],"archived original bytes changed")
                seen.add(rel)
        need(seen==set(expected_members),"missing archived originals")
        # Verify archived bytes against the still-retained original directory too.
        original=pathlib.Path(meta["original_root"])
        for rel,identity in expected_members.items():checked_identity(original/rel,identity)
    freeze=read_json(STAGE/"source-freeze.json")
    need(freeze["commit"]==A and freeze["tree"]==AT and freeze["source_entries"]==26711 and freeze["source_bytes"]==2542453893 and freeze["postcommit_status"]=="","freeze source")
    need(freeze["common_config_unchanged"] is True and freeze["postcommit_all_index_H"] is True and freeze["pushed"] is False,"freeze controls")
    return actual,archives,receipt
def source_report(path,commit,tree,expected_bytes=None):
    d=read_json(path)
    need(d["schema"]=="trnm-ci-source-v1" and d["kind"]=="head" and d["candidate"]==commit and d["tested_commit"]==commit and d["tested_tree"]==tree,"source guard identity")
    need(d["tracked_worktree_verified"] is True and d["tracked_entries"]==26711 and d["tests_executed_by_identity_check"] is False and d["base"] is None and d["prospective_merge"] is None,"source guard scope")
    if expected_bytes is not None:need(d["tracked_bytes"]==expected_bytes,"source guard bytes")
    return d
def unittest_summary(text,count,skips):
    found=re.findall(r"^Ran ([0-9]+) tests? in [0-9.]+s$",text,re.M)
    need(found==[str(count)],"unittest denominator mismatch")
    need(not re.search(r"^(FAILED|ERROR:|FAIL:)",text,re.M),"unexpected unittest failure")
    endings=re.findall(r"^OK(?: \(skipped=([0-9]+)\))?$",text,re.M)
    need(len(endings)==1 and int(endings[0] or 0)==skips,"unittest skip mismatch")
def validate_native():
    checked_identity(N/"receipt.json",{"bytes":(N/"receipt.json").stat().st_size,"sha256":NATIVE_RECEIPT_SHA})
    need(sha_file(N/"manifest.json")==NATIVE_MANIFEST_SHA,"native original manifest pin")
    need((N/"driver.py").read_bytes()==(OUT/"native-driver-expected.py").read_bytes(),"native controller code differs from authorized code")
    receipt=read_json(N/"receipt.json");status=read_json(N/"status.json");manifest=read_json(N/"manifest.json")
    need(manifest["schema"]=="trnm-native-daa-artifacts-v1" and manifest["source_commit"]==A,"native manifest schema")
    expected={}
    for row in manifest["files"]:
        rel=safe(row["path"]);need(rel not in expected,"duplicate native artifact")
        expected[rel]={"bytes":row["bytes"],"sha256":row["sha256"]}
    files=validate_map(N,expected,("manifest.json","status.json"))
    need(status["schema"]=="trnm-native-daa-validation-status-v1" and status["state"]=="COMPLETE" and status["result"]=="PASS" and status["current_step"] is None and status["current_pid"] is None,"native final status")
    need(status["source_commit"]==A and status["source_tree"]==AT and status["receipt_sha256"]==NATIVE_RECEIPT_SHA and status["manifest_sha256"]==NATIVE_MANIFEST_SHA,"native final status identities")
    need(receipt["schema"]=="trnm-native-daa-validation-v1" and receipt["result"]=="PASS" and receipt["source_commit"]==A and receipt["source_tree"]==AT,"native final receipt")
    need(receipt["gates"]=={"format":True,"locked_offline_metadata":True,"pinned_provider":True,"strict_clippy":True,"native_four_tests":True,"four_full_readers_and_controls":True} and all(v is True for v in receipt["gates"].values()),"native gates")
    for k in ("qualification_commands_locked_offline","provider_inputs_unchanged","lockfiles_unchanged","source_after_verified"):need(receipt[k] is True,"native "+k)
    for k in ("source_mutations_allowed","production_activation","physical_or_quantum_attack_qualification"):need(receipt[k] is False,"native "+k)
    need("error" not in receipt and "finalization_error" not in receipt,"native controller error")
    before=source_report(N/"source-before.json",A,AT,2542453893);after=source_report(N/"source-after.json",A,AT,2542453893)
    need(before==after and (N/"source-before.json").read_bytes()==(N/"source-after.json").read_bytes(),"native source before/after")
    need(receipt["lockfiles_before"]==receipt["lockfiles_after"],"native lock identities")
    for row in receipt["lockfiles_before"]:
        path=pathlib.Path(row["path"]);rel=path.relative_to(ROOT).as_posix()
        need(rel in ("trillionnium/Cargo.lock","tests/fuzz/Cargo.lock"),"unexpected locked graph")
        raw=git("show",A+":"+rel);need(len(raw)==row["bytes"] and sha_bytes(raw)==row["sha256"],"lock differs from source A")
    need(len(receipt["lockfiles_before"])==2,"two isolated lockfiles required")
    commands=read_json(N/"commands.json")
    need(len(commands)==27 and receipt["command_count"]==27 and status["commands_completed"]==27,"native command denominator")
    by_name={}
    for row in commands:
        name=row["name"];need(name not in by_name,"duplicate command")
        need(row["cwd"]==str(ROOT) and type(row["exit_code"]) is int,"native command record")
        for stream in ("stdout","stderr"):
            p=N/(name+"."+stream+".log")
            need(row[stream]["path"]==str(p),"native raw log path")
            checked_identity(p,{"bytes":row[stream]["bytes"],"sha256":row[stream]["sha256"]})
        by_name[name]=row
    bad=[{"name":r["name"],"exit_code":r["exit_code"]} for r in commands if r["exit_code"]]
    need(bad==receipt["nonzero_observations"] and len(bad)==1,"initial metadata failure must be retained exactly")
    failed=bad[0]["name"]
    need(failed in ("metadata-default-initial","metadata-all-features-initial","metadata-fuzz-initial"),"unexpected native failure")
    family=failed[:-len("-initial")]
    for suffix in ("-locked-fetch","-qualified"):need(by_name[family+suffix]["exit_code"]==0,"metadata recovery failed")
    for label,manifest_path,all_features in (("metadata-default","trillionnium/Cargo.toml",False),("metadata-all-features","trillionnium/Cargo.toml",True),("metadata-fuzz","tests/fuzz/Cargo.toml",False)):
        finals=[r for r in receipt["metadata_final"] if r["name"].startswith(label+"-")]
        need(len(finals)==1 and finals[0]["exit_code"]==0,"final offline graph missing")
        row=by_name[finals[0]["name"]]
        want=["/home/qian-qi/.cargo/bin/cargo","metadata","--locked","--offline","--format-version","1","--manifest-path",manifest_path]+(["--all-features"] if all_features else [])
        need(row["argv"]==want,"metadata flags changed")
        graph=read_json(N/(row["name"]+".stdout.log"))
        need(type(graph["packages"]) is list and graph["packages"] and graph["resolve"] is not None,"full resolved graph missing")
    expected_clippy=["/home/qian-qi/.cargo/bin/cargo","clippy","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","--workspace","--all-targets","--all-features","--","-D","warnings"]
    expected_native=["/home/qian-qi/.cargo/bin/cargo","test","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","-p","trnm-pon-node","--test","daa_joint_consensus","--","--nocapture","--test-threads=1"]
    need(by_name["strict-clippy"]["argv"]==expected_clippy and by_name["strict-clippy"]["exit_code"]==0,"strict Clippy contract")
    need(by_name["native-four-tests"]["argv"]==expected_native and by_name["native-four-tests"]["exit_code"]==0,"native roster invocation")
    need(by_name["format"]["argv"]==["/home/qian-qi/.cargo/bin/cargo","fmt","--manifest-path","trillionnium/Cargo.toml","--all","--","--check"] and by_name["format"]["exit_code"]==0,"format gate")
    roster={
      "pnh1_three_negative_endpoint_periods_keep_real_w1_and_select_higher_work",
      "pgh2_three_negative_endpoint_periods_keep_real_w1_and_select_higher_work",
      "pnh1_strictly_monotone_compressed_periods_keep_real_w1_and_select_higher_work",
      "pgh2_strictly_monotone_compressed_periods_keep_real_w1_and_select_higher_work"}
    text=(N/"native-four-tests.stdout.log").read_text()
    need(set(re.findall(r"^test (\S+) \.\.\. ok$",text,re.M))==roster,"original four native methods not observed")
    need("test result: ok. 4 passed; 0 failed; 0 ignored;" in text,"native test counts")
    env=receipt["environment_overrides"]
    for k,v in {"RUSTUP_TOOLCHAIN":"1.95.0","CARGO_BUILD_JOBS":"2","CARGO_INCREMENTAL":"0","RUST_TEST_THREADS":"1","PYTHONDONTWRITEBYTECODE":"1","CARGO_HOME":str(SUPPORT/"cargo-home"),"CARGO_TARGET_DIR":str(SUPPORT/"target"),"OPENSSL_STATIC":"1","TRNM_PQ_OPENSSL_VERSION":"3.5.9"}.items():need(env[k]==v,"native environment "+k)
    need(read_json(N/"ambient-build-overrides.json")["present_keys"]==[],"unexpected ambient build override")
    pb=read_json(N/"provider-before.json");pa=read_json(N/"provider-after.json");need(pb==pa,"provider changed")
    for item in pb["inputs"]:
        path=pathlib.Path(item["path"]);path.relative_to(SUPPORT)
        checked_identity(path,{"bytes":item["bytes"],"sha256":item["sha256"]})
    provider=read_json(N/"provider-preparation/pq-provider/provider.json")
    need(provider["schema"]=="trnm-ci-pq-provider-v3" and provider["result"]=="PREPARED_AND_SMOKE_VERIFIED" and provider["exit_code"]==0 and provider["version"]=="3.5.9" and provider["source_archive_sha256_expected"]==SOURCE_ARCHIVE_SHA,"provider preparation")
    for k in ("source_digest_verified","static_build","ml_dsa_65_sign_verify_and_wrong_message_rejection","backend_exported"):need(provider[k] is True,"provider "+k)
    need(provider["native_rust_pq_tests_run_by_preparation"] is False and provider["whole_chain_quantum_security_qualified"] is False and provider["production_activation"] is False,"provider boundary")
    outcomes=[];expected_reader_records=[];total_methods=total_skips=0
    for kind,report_name,reader_script,control_script in (("joint-daa","joint-daa.json","scripts/pon_joint_daa_reader.py","scripts/ci/test_pon_joint_daa_reader.py"),("monotone-daa","monotone-daa.json","scripts/pon_monotone_daa_reader.py","scripts/ci/test_pon_monotone_daa_reader.py")):
        for backend,header in (("pnh1-authenticated","PNH1"),("pgh2-growth","PGH2")):
            raw=N/kind/backend;report_path=raw/report_name;report_identity=ident(report_path)
            report=read_json(report_path);need(report["schema"]==("pon-native-joint-daa-v1" if kind=="joint-daa" else "pon-native-monotone-daa-v1") and report["backend"]==backend and report["header_profile"]==header,"native original report")
            tag=kind+"-"+backend;name=tag+"-reader";r=by_name[name]
            need(r["exit_code"]==0 and r["argv"]==["/usr/bin/python3",reader_script,"--raw-dir",str(raw),"--expected-report-sha256",report_identity["sha256"]],"full reader invocation")
            readback=read_json(N/(name+".stdout.log"))
            need(readback["schema"]==("pon-native-joint-daa-reader-v1" if kind=="joint-daa" else "pon-native-monotone-daa-reader-v1") and readback["record_and_oracle_consistency"]=="PASS" and readback["header_profile"]==header and readback["backend"]==backend,"full reader result")
            need(readback["report_sha256"]==report_identity["sha256"] and readback["unique_full_python_verified_proofs"]==114 and readback["unique_native_admitted_packets_observed"]==114,"114 original proof denominator")
            need(readback["full_python_transcript_and_product_recomputed"] is True and readback["proof_hardness_or_quantum_attack_profitability_qualified"] is False and readback["public_network_qualification"] is False,"reader qualification boundary")
            need(readback["ordinary_height"]==65 and readback["selected_height"]==64 and readback["ordinary_required_chainwork"]==130 and readback["selected_required_chainwork"]==793,"native witness selection")
            packet_ids=readback["packet_identities"];need(len(packet_ids)==114,"native packet count")
            expected_packet_files={}
            for rel,identity in packet_ids.items():
                safe(rel);need(re.fullmatch(r"packets/[0-9a-f]{64}\.pnk",rel) is not None,"packet filename")
                expected_packet_files[rel]=identity
            validate_map(raw,{report_name:report_identity,**expected_packet_files})
            control=tag+"-reader-controls";cr=by_name[control]
            need(cr["exit_code"]==0 and cr["argv"]==["/usr/bin/python3",control_script,"--raw-dir",str(raw)],"reader controls invocation")
            count=22 if kind=="joint-daa" else 26;skips=1 if header=="PNH1" else 0
            unittest_summary((N/(control+".stdout.log")).read_text()+(N/(control+".stderr.log")).read_text(),count,skips)
            total_methods+=count;total_skips+=skips
            expected_reader_records.extend([{"name":name,"exit_code":0},{"name":control,"exit_code":0}])
            outcomes.append({"profile":kind+"/"+backend,"header_profile":header,"full_verified_proofs":114,"selected_height":64,"selected_required_chainwork":793,"ordinary_height":65,"ordinary_required_chainwork":130,"reader_control_methods":count,"reader_control_skips":skips,"report":report_identity})
    need(receipt["reader_final"]==expected_reader_records and total_methods==96 and total_skips==2,"reader complete roster")
    need([{"path":str(N/o["profile"]/("joint-daa.json" if o["profile"].startswith("joint-daa/") else "monotone-daa.json")),**o["report"]} for o in outcomes]==receipt["reports"],"four original report receipt identities")
    need(snapshot(N)==files,"native originals changed during validation")
    return {"source":A,"tree":AT,"result":"PASS","commands":27,"retained_nonzero_observations":bad,"native_methods":4,"native_skips":0,"reader_control_methods":96,"reader_control_passes":94,"reader_control_skips":2,"profiles":outcomes,"source_after_verified":True,"locked_offline_graphs":3,"provider_version":"3.5.9","provider_inputs_unchanged":True,"receipt":ident(N/"receipt.json"),"manifest":ident(N/"manifest.json")},files
def make_archive(root,label):
    initial=snapshot(root);dest=PACKET/"archives"/(label+".tar.xz")
    need(not dest.exists(),"archive already exists")
    with tarfile.open(dest,"w:xz",preset=6) as tf:
        for rel in initial:
            path=root/rel;info=tf.gettarinfo(str(path),arcname=label+"/"+rel)
            need(info.isfile(),"archive nonregular source")
            info.uid=info.gid=0;info.uname=info.gname="";info.mtime=0
            with path.open("rb") as f:tf.addfile(info,f)
    need(snapshot(root)==initial,"archive source changed while collecting")
    checked={}
    with tarfile.open(dest,"r:xz") as tf:
        for member in tf:
            need(member.isfile() and member.name.startswith(label+"/"),"unsafe created tar")
            rel=safe(member.name[len(label)+1:]);need(rel not in checked and rel in initial,"created tar member")
            h=hashlib.sha256();size=0
            with tf.extractfile(member) as f:
                while b:=f.read(1024*1024):h.update(b);size+=len(b)
            checked[rel]={"bytes":size,"sha256":h.hexdigest()}
    need(checked==initial,"lossless archive readback failed")
    return {"original_root":str(root),"members":[{"path":p,**v} for p,v in initial.items()],"archive_bytes":dest.stat().st_size,"archive_sha256":sha_file(dest)}
def copy_file(source,dest):
    need(not dest.exists(),"copy destination exists")
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
    need(ident(source)==ident(dest),"copy byte mismatch")
def main():
    state("validate-completed-stage")
    staged_files,archives,stage_receipt=validate_stage()
    state("validate-formal-and-posthoc")
    formal=validate_formal_and_posthoc(F,C,P,A,AT,ROOT)
    need(snapshot(STAGE/"campaign")==snapshot(C),"staged campaign differs from original complete campaign")
    need((STAGE/"formal-execution-summary-A.json").read_bytes()==(F/"execution-summary.json").read_bytes(),"formal compact summary copy")
    state("validate-native-originals")
    native,native_files=validate_native()
    state("validate-original-and-repaired-CI")
    ci=validate_ci(OLD_CI,NEW_CI,ROOT,A,A2)
    need((STAGE/"ci-summary-A-failed.json").read_bytes()==(OLD_CI/"summary.json").read_bytes(),"original CI compact summary copy")
    freeze=read_json(NEW_CI/"freeze.json");ci_summary=read_json(NEW_CI/"summary.json")
    a2tree=git("rev-parse",A2+"^{tree}").decode().strip();need(freeze["tree"]==a2tree,"actual A2 tree")
    changed=git("diff","--name-only",A,A2,"--").decode().splitlines()
    need(changed==["config/pon/pq-cross-branch-corpus-v1.json","scripts/ci/check_ci_contract.py"],"A2 source scope")
    need(git("show","-s","--format=%P",A2).decode().strip()==A,"A2 direct parent")
    state("copy-validated-stage")
    PACKET.mkdir()
    for rel in staged_files:copy_file(STAGE/rel,PACKET/rel)
    state("archive-native-originals")
    archives["native-validation-A"]=make_archive(N,"native-validation-A")
    state("archive-CI-repair-originals")
    archives["ci-repair-A2"]=make_archive(NEW_CI,"ci-repair-A2")
    state("archive-posthoc-originals")
    archives["posthoc-description-A"]=make_archive(P,"posthoc-description-A")
    copies={
      N/"receipt.json":"native-execution-summary-A.json",
      N/"status.json":"native-controller-status-A.json",
      NEW_CI/"freeze.json":"ci-repair-freeze-A2.json",
      NEW_CI/"summary.json":"ci-repair-summary-A2.json",
      P/"receipt.json":"posthoc-execution-summary.json",
      P/"summary.json":"posthoc-summary.json",
      P/"analysis.json":"fullanalysis.json",
      NEW_CI.parent/"controller-ci-repair-v1.py":"ci-runner-A2.py"}
    for source,relative in copies.items():copy_file(source,PACKET/relative)
    analysis=read_json(P/"analysis.json")
    checked_identity(PACKET/"fullanalysis.json",{"bytes":73566,"sha256":"b5139d1353e7bebe7f4702ec6931a98133143e945ee8c039b62a51ba715f3d65"})
    provenance={"schema":"trnm-joint-resource-source-provenance-v1","source_A":A,"source_A_tree":AT,"source_A2":A2,"source_A2_tree":a2tree,"A2_parent":A,"A_to_A2_changed_files":changed,"all_other_git_tree_paths_and_blobs_identical":True,"native_execution_source":A,"formal_execution_source":A,"CI_repair_execution_source":A2,"native_or_formal_relabelled_as_A2":False,"common_config_before_add_attested":False,"original_cloud_terminal_outcome":"UNKNOWN","new_tests_or_simulator_executions_by_collector":0,"source_mutations_by_collector":False}
    write_json(PACKET/"source-provenance.json",provenance)
    write_json(PACKET/"raw-archive-inventory.json",archives)
    summary={"schema":"trnm-joint-resource-competition-evidence-summary-v1","result":"EVIDENCE_INTEGRITY_PASS","qualification":"HOLD_NO_GO","release_ready":False,"production_activation":False,"source_A":A,"source_A_tree":AT,"source_A2":A2,"source_A2_tree":a2tree,"provenance":provenance,"formal_validation":formal,"native_validation":native,"CI_validation":ci,"by_policy":analysis["by_policy"],"by_policy_quantum_clock":analysis["by_policy_quantum_clock"],"honest_short_epochs":analysis["honest_short_epochs"],"totals":analysis["totals"],"posthoc_original_analysis":ident(P/"analysis.json"),"source_A_CI_failure_retained":True,"source_A_CI_methods":169,"source_A_CI_failures":2,"source_A2_CI_methods":169,"source_A2_CI_skips":0,"initial_native_metadata_failure_retained":native["retained_nonzero_observations"],"old_cloud_validation_terminal_outcome":"UNKNOWN","new_test_or_simulator_executions_by_collector":0,"task_supply_experiment":"UNIMPLEMENTED","physical_resource_fairness_qualified":False,"network_byte_budget_qualified":False,"unknown_inputs":18,"open_proof_obligations":13,"statistical_failure_probability_qualified":False}
    write_json(PACKET/"summary.json",summary)
    templates=read_json(OUT/"templates.json")
    values={"A":A,"AT":AT,"A2":A2,"A2T":a2tree,"NATIVE_FAILURE":native["retained_nonzero_observations"][0]["name"],"NATIVE_EXIT":str(native["retained_nonzero_observations"][0]["exit_code"])}
    for key,name in (("README","README.md"),("PR","PR-body.md")):
        text=templates[key]
        for token,value in values.items():text=text.replace("{{"+token+"}}",value)
        need("{{" not in text,"unresolved documentation template")
        target=PACKET/name if key=="README" else OUT/name
        target.write_text(text)
    need(snapshot(STAGE)==staged_files,"staged originals changed during packet assembly")
    need(snapshot(N)==native_files,"native originals changed during packet assembly")
    state("final-inventory")
    files=snapshot(PACKET)
    manifest={"schema":"trnm-joint-resource-evidence-packet-manifest-v1","source_A":A,"source_A2":A2,"manifest_self_excluded":True,"files":[{"path":path,**identity} for path,identity in files.items()]}
    write_json(PACKET/"manifest.json",manifest)
    physical=snapshot(PACKET);need(set(physical)==set(files)|{"manifest.json"},"final packet inventory")
    for name,value in files.items():need(physical[name]==value,"final packet changed")
    review={"schema":"trnm-joint-resource-evidence-packet-review-v1","result":"PASS","source_A":A,"source_A2":A2,"source_A2_tree":a2tree,"packet_root":str(PACKET),"packet_manifest_sha256":physical["manifest.json"]["sha256"],"packet_file_count":len(physical),"packet_bytes":sum(v["bytes"] for v in physical.values()),"manifest_member_count":len(files),"packet_count_includes_manifest":True,"PR_body_path":str(OUT/"PR-body.md"),"PR_body_sha256":sha_file(OUT/"PR-body.md"),"README_sha256":physical["README.md"]["sha256"],"formal_methods":242,"formal_skips":0,"horizon_runs":128,"paired_comparisons":64,"native_methods":4,"native_reader_profiles":4,"native_full_proofs_per_profile":114,"native_reader_control_methods":96,"native_reader_control_passes":94,"native_reader_control_skips":2,"native_command_observations":27,"native_initial_metadata_nonzero":native["retained_nonzero_observations"],"A_CI_methods":169,"A_CI_failures":2,"A2_CI_methods":169,"A2_CI_skips":0,"A2_only_two_CI_files_changed":True,"source_guard_negative_methods":43,"PQ_corpus_negative_methods":57,"posthoc_new_executions":0,"qualification":"HOLD_NO_GO","release_ready":False,"production_activation":False,"old_cloud_terminal_outcome":"UNKNOWN","common_config_before_add_attested":False,"archive_labels":sorted(archives),"all_collected_originals_rehashed":True,"new_tests_or_simulator_executions_by_collector":0,"git_mutations_by_collector":False,"desired_repository_destination":"evidence/pon-joint-resource-competition-20261112"}
    write_json(OUT/"review-summary.json",review)
    state("COMPLETE",result="PASS",review_summary=str(OUT/"review-summary.json"),review_sha256=sha_file(OUT/"review-summary.json"))
try:
    main()
except BaseException as error:
    trace=traceback.format_exc();(OUT/"collector-error.log").write_text(trace)
    failure={"schema":"trnm-joint-resource-evidence-packet-review-v1","result":"FAIL","source_A":A,"source_A2":A2,"error":str(error),"packet_root":str(PACKET),"partial_packet_publishable":False,"source_mutations_by_collector":False,"new_tests_or_simulator_executions_by_collector":0}
    if not (OUT/"review-summary.json").exists():write_json(OUT/"review-summary.json",failure)
    state("FAILED",result="FAIL",error=str(error));print(trace,file=sys.stderr);sys.exit(1)

