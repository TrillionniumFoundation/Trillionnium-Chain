#!/usr/bin/env python3
"""Run the existing three migration CI selectors on exact1c14 in a private target."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone

WORK = Path('/home/alex/work')
SUPPORT = WORK / 'chain-m15-regression-1c14fab4-13c7-runner-v2.py'
EXPORT = WORK / 'chain-npq6-export-13c7-evidence-v3'
CACHE = WORK / 'chain-npq6-export-13c7-target-v3'
TARGET = WORK / 'chain-migration-1c14fab4-13c7-target'
OUTPUT = WORK / 'chain-migration-1c14fab4-13c7-evidence'
CASES = [
    'npq6_anchored_claim_preserves_obligations_rotates_and_cold_reopens',
    'npq6_migration_requires_both_claim_signatures_and_the_selected_domain',
    'admitted_legacy_checkpoint_cannot_drop_unhandled_work_state_for_migration',
]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def resources():
    return dict(processes=subprocess.check_output(['ps', '-eo', 'pid,ppid,comm,%cpu,rss'], text=True),
                meminfo=Path('/proc/meminfo').read_text(), loadavg=Path('/proc/loadavg').read_text())


def main():
    if hashlib.sha256(SUPPORT.read_bytes()).hexdigest() != '750a23f7665477885627a80399b26bb7e887d2f4cf814e7230314123daa18def':
        raise ValueError('fixed native support changed')
    m = module('fixed_native_support', SUPPORT)
    m.require(not TARGET.exists(), 'migration target already exists')
    OUTPUT.mkdir(mode=0o700, exist_ok=False)
    manifest = dict(schema='chain-npq6-migration-three-native-v1', commit=m.COMMIT, tree=m.TREE,
                    source=str(m.SOURCE), target=str(TARGET), result='RUNNING', commands=[],
                    started_utc=datetime.now(timezone.utc).isoformat(), runner_sha256=m.sha(__file__),
                    exact_required_tests=CASES, selected_features=['default'],
                    outer_timeout_seconds=14400, automatic_retry_added=False,
                    original_full_node_aggregate_unchanged=True,
                    live_legacy_chain_cutover_qualified=False, production_activation=False,
                    whole_chain_quantum_security_qualified=False)

    def save():
        (OUTPUT / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')

    save()
    verifier = env = binding = None
    code = 1
    try:
        manifest['shared_host_resources_before'] = resources()
        manifest['exporter_build_before'] = m.file_identity(EXPORT / 'manifest.json')
        exporter = json.loads((EXPORT / 'manifest.json').read_text())
        m.require(exporter['result'] == 'PASS' and exporter['material_generated'] is False,
                  'owned cache source is not terminal exporter-only PASS')
        m.require(exporter['commit'] == m.OLD and exporter['tree'] == m.OLD_TREE,
                  'owned cache is not bound to840')
        manifest['cache_owner'] = dict(source=str(CACHE), terminal_manifest_sha256=m.sha(EXPORT / 'manifest.json'),
                                      imported_compiled_artifacts_are_not_native_test_evidence=True)
        manifest['old_inputs_before'] = m.check_old_inputs()
        verifier = module('verify_ci_source', m.SOURCE / 'scripts/ci/verify_ci_source.py')
        manifest['source_before'] = verifier.verify('head', m.COMMIT, root=m.SOURCE)
        m.require(manifest['source_before']['tested_tree'] == m.TREE, 'wrong migration source tree')
        env, manifest['provider_inputs_before'] = m.prepared_environment()
        env['CARGO_TARGET_DIR'] = str(TARGET)
        manifest['environment'] = {key: env.get(key) for key in [
            'PATH', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
            'RUST_TEST_THREADS', 'OPENSSL_DIR', 'OPENSSL_STATIC', 'TRNM_PQ_OPENSSL',
            'TRNM_PQ_OPENSSL_SHA256', 'TRNM_PQ_OPENSSL_VERSION', 'OPENSSL_CONF', 'OPENSSL_MODULES']}
        save()

        def run(label, argv):
            print(json.dumps(dict(event='start', label=label, argv=argv)), flush=True)
            command = ['python3', 'scripts/ci/record_pq_native_command.py', '--kind', 'head',
                       '--candidate', m.COMMIT, '--tested', m.COMMIT, '--label', label,
                       '--output', str(OUTPUT), '--'] + argv
            status = subprocess.run(command, cwd=m.SOURCE, env=env, check=False).returncode
            manifest['commands'].append(dict(label=label, exit_code=status))
            save()
            m.require(status == 0, label + ' failed: ' + str(status))
            return (OUTPUT / (label + '.log')).read_text()

        run('preflight', ['bash', 'scripts/project-preflight.sh'])
        run('rustc', ['rustc', '+1.95.0', '-Vv'])
        run('cargo', ['cargo', '+1.95.0', '-Vv'])
        TARGET.mkdir(mode=0o700)
        run('independent-owned-cache-copy', ['cp', '-a', '--reflink=auto', str(CACHE / 'debug'), str(TARGET / 'debug')])
        for old_path in (CACHE / 'debug').rglob('*'):
            if old_path.is_file() and not old_path.is_symlink():
                copied = TARGET / 'debug' / old_path.relative_to(CACHE / 'debug')
                old, new = old_path.stat(), copied.stat()
                m.require((old.st_dev, old.st_ino) != (new.st_dev, new.st_ino), 'copied cache shares a source inode')
        base = ['cargo', '+1.95.0', 'test', '--locked', '--manifest-path', 'trillionnium/Cargo.toml',
                '-p', 'trnm-pon-node', '--test', 'pq_application_migration_v6']
        build = run('migration-build', base + ['--no-run', '--message-format=json'])
        artifacts = [json.loads(line) for line in build.splitlines() if line.startswith('{')]
        artifacts = [row for row in artifacts if row.get('reason') == 'compiler-artifact' and row.get('executable')]
        candidates = [row for row in artifacts if row['target']['kind'] == ['test'] and row['target']['name'] == 'pq_application_migration_v6']
        m.require(len(candidates) == 1, 'expected one actual migration integration harness')
        artifact = candidates[0]
        m.require(artifact['target']['src_path'] == str(m.SOURCE / 'trillionnium/crates/trnm-pon-node/tests/pq_application_migration_v6.rs'), 'wrong migration test source')
        m.require(artifact['features'] == ['default'] and artifact['profile']['test'] is True
                  and artifact['profile']['opt_level'] == '3' and artifact['profile']['debuginfo'] == 2,
                  'migration compilation profile differs from the existing CI invocation')
        native = Path(artifact['executable'])
        original = m.file_identity(native)
        retained = OUTPUT / 'pq_application_migration_v6-harness'
        with native.open('rb') as src, retained.open('xb') as dst:
            shutil.copyfileobj(src, dst, 1024 * 1024)
            dst.flush()
            os.fsync(dst.fileno())
        retained.chmod(0o555)
        copy = m.file_identity(retained)
        m.require(m.file_identity(native) == original and copy['sha256'] == original['sha256']
                  and copy['nlink'] == 1 and copy['inode'] != original['inode'], 'retained migration ELF differs')
        binding = dict(artifact=artifact, original=original, retained=copy, all_executable_artifacts=artifacts)
        m.write_json(OUTPUT / 'artifact-binding.json', binding)
        manifest['artifact_binding'] = binding
        listing = run('registry', [str(retained), '--list'])
        names = re.findall(r'^([A-Za-z_][A-Za-z0-9_:]*): test$', listing, re.M)
        ignored = run('ignored-registry', [str(retained), '--ignored', '--list'])
        m.require(len(names) == len(CASES) and set(names) == set(CASES), 'migration registry differs from the three required cases')
        m.require(re.findall(r'^([A-Za-z_][A-Za-z0-9_:]*): test$', ignored, re.M) == [], 'migration registry contains ignored tests')
        manifest['registry_names'] = names
        for index, name in enumerate(CASES):
            m.require(m.file_identity(native) == original, 'migration ELF changed before exact execution')
            label = 'migration-' + format(index, '02d')
            run(label, base + [name, '--', '--exact', '--show-output', '--test-threads=1'])
            run(label + '-execution', ['python3', 'scripts/ci/check_required_native_test.py',
                                      str(OUTPUT / (label + '.log')), '--test', name])
            m.require(m.file_identity(native) == original, 'migration ELF rebuilt or changed during exact execution')
        manifest['actual_named_tests_passed'] = len(CASES)
        code = 0
    except Exception as error:
        manifest['error'] = str(error)
        print(json.dumps(dict(event='failed', error=str(error))), flush=True)
    finally:
        try:
            manifest['old_inputs_after'] = m.check_old_inputs()
            m.require(manifest['old_inputs_before'] == manifest['old_inputs_after'], 'retained old inputs changed')
            manifest['exporter_build_after'] = m.file_identity(EXPORT / 'manifest.json')
            m.require(manifest['exporter_build_before'] == manifest['exporter_build_after'], 'exporter receipt changed')
            if verifier is not None:
                manifest['source_after'] = verifier.verify('head', m.COMMIT, root=m.SOURCE)
                m.require(manifest['source_before'] == manifest['source_after'], 'migration source changed')
            if env is not None:
                _, manifest['provider_inputs_after'] = m.prepared_environment()
                m.require(manifest['provider_inputs_before'] == manifest['provider_inputs_after'], 'provider changed')
            if binding is not None:
                m.require(m.file_identity(binding['original']['path']) == binding['original'], 'compiled migration ELF changed')
                m.require(m.file_identity(binding['retained']['path']) == binding['retained'], 'retained migration ELF changed')
        except Exception as error:
            manifest['final_identity_error'] = str(error)
            code = 1
        manifest['shared_host_resources_after'] = resources()
        manifest.update(result='PASS' if code == 0 else 'FAIL', exit_code=code,
                        finished_utc=datetime.now(timezone.utc).isoformat())
        save()
    print(json.dumps(dict(result=manifest['result'], output=str(OUTPUT))), flush=True)
    return code


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    raise SystemExit(main())
