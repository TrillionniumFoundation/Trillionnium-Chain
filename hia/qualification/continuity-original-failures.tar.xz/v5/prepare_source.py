"""Create an isolated exact-453 source copy without changing the existing task."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import time
import traceback
import sys

OLD = Path('/tmp/trnm-typedstore-rust-20261116-jqi3qetj')
SOURCE = OLD / 'repo-v2'
HEAD = '453326b335af9375f2f6796d4e906cb4cdf2ce4d'
TREE = 'fc5a31e67b207078ee1b01ad98e918df11ad8b8f'
ROOT = Path(tempfile.mkdtemp(prefix='trnm-continuity-original-v5-20261116-'))
LOG = ROOT / 'preparation'
LOG.mkdir(mode=0o700)
(ROOT / 'prepare_source.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1])
report = {'schema':'trnm.continuity.original-source-preparation.v1',
    'status':'RUNNING','root':str(ROOT),'repository':str(ROOT/'repo'),
    'source_repository':str(SOURCE),'shared_target':str(OLD/'isolated-cargo-target'),
    'expected_head':HEAD,'expected_tree':TREE,'stages':[],
    'github_write':False,'service_provisioned':False,'original_rust_executed':False}
started = time.monotonic()
env = dict(os.environ, GIT_TERMINAL_PROMPT='0')

def run(name, args, *, data=None, cwd=None, timeout=120):
    done = subprocess.run(args, input=data, cwd=cwd, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    (LOG/(name+'.stdout')).write_bytes(done.stdout)
    (LOG/(name+'.stderr')).write_bytes(done.stderr)
    report['stages'].append({'name':name,'exit_code':done.returncode,
        'stdout_sha256':hashlib.sha256(done.stdout).hexdigest(),
        'stderr_sha256':hashlib.sha256(done.stderr).hexdigest()})
    if done.returncode:
        raise RuntimeError(name+': '+done.stderr[-8000:].decode(errors='replace'))
    return done.stdout

try:
    if not SOURCE.is_dir() or SOURCE.is_symlink():
        raise ValueError('Previously owned exact source is absent or symbolic')
    if not (OLD/'isolated-cargo-target').is_dir():
        raise ValueError('Previously owned Cargo cache is absent')
    for expression, expected in [('HEAD',HEAD),('HEAD^{tree}',TREE)]:
        actual = run('prior-'+('head' if expression=='HEAD' else 'tree'),
            ['git','-C',str(SOURCE),'rev-parse',expression],timeout=20).decode().strip()
        if actual != expected:
            raise ValueError('Prior Git identity differs')
    origin = run('prior-origin',['git','-C',str(SOURCE),'remote','get-url','origin'],timeout=20).decode().strip()
    if origin != 'https://github.com/TrillionniumFoundation/Trillionnium-Chain.git':
        raise ValueError('Previously observed canonical origin differs: '+origin)
    report['canonical_origin']=origin
    report['rustc'] = run('rustc-version',['rustc','-Vv'],timeout=20).decode()
    report['cargo'] = run('cargo-version',['cargo','-V'],timeout=20).decode()
    report['disk_free_bytes'] = shutil.disk_usage(ROOT).free
    run('clone',['git','clone','--no-hardlinks','--no-checkout',str(SOURCE),str(ROOT/'repo')],timeout=180)
    repo = ROOT/'repo'
    run('set-new-private-origin',['git','-C',str(repo),'remote','set-url','origin',origin],timeout=20)
    run('sparse-init',['git','-C',str(repo),'sparse-checkout','init','--no-cone'])
    run('sparse-set',['git','-C',str(repo),'sparse-checkout','set','--no-cone','--stdin'],
        data=b'/*\n!/evidence/\n')
    run('checkout',['git','-C',str(repo),'checkout','--detach',HEAD],timeout=180)
    for expression, expected in [('HEAD',HEAD),('HEAD^{tree}',TREE)]:
        actual = run('new-'+('head' if expression=='HEAD' else 'tree'),
            ['git','-C',str(repo),'rev-parse',expression],timeout=20).decode().strip()
        if actual != expected:
            raise ValueError('Fresh Git identity differs')
    if run('new-status',['git','-C',str(repo),'status','--porcelain=v1']).strip():
        raise ValueError('Fresh isolated Git source is dirty')
    run('preflight',['bash','scripts/project-preflight.sh','--audit'],cwd=repo,timeout=90)
    report['status']='SOURCE_READY_ONLY'
except BaseException as error:
    report.update(status='FAIL',error=repr(error),traceback=traceback.format_exc())
finally:
    report['elapsed_seconds']=time.monotonic()-started
    (ROOT/'preparation.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps(report,sort_keys=True),flush=True)
if report['status']!='SOURCE_READY_ONLY':
    raise SystemExit(1)
