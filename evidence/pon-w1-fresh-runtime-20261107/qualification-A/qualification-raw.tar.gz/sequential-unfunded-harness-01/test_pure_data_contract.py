#!/usr/bin/env python3
"""Four small pure-data controls; no repo imports, subprocesses, or proof dispatch."""
import copy
import importlib.util
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location("external_unfunded_harness", Path(__file__).with_name("run_sequential_unfunded.py"))
h = importlib.util.module_from_spec(spec)
spec.loader.exec_module(h)


class PureDataContract(unittest.TestCase):
    def test_explicit_qualified_identity_and_duplicate_rejection(self):
        value = {"schema": h.QUALIFICATION_SCHEMA, "qualification_complete": True,
                 "repo_path": str(h.REPO), "source_commit": "1" * 40,
                 "source_tree": "2" * 40,
                 "binaries": {name: {"path": "/unused/" + name, "bytes": 1,
                                     "sha256": h.R0VM_SHA if name == "r0vm" else "3" * 64,
                                     "kind": "pure-data-example"} for name in h.BINARY_NAMES}}
        self.assertEqual(h.parse_qualification(value), value)
        changed = copy.deepcopy(value)
        changed["qualification_complete"] = False
        with self.assertRaises(ValueError):
            h.parse_qualification(changed)
        changed = copy.deepcopy(value)
        changed["binaries"]["r0vm"]["sha256"] = "4" * 64
        with self.assertRaises(ValueError):
            h.parse_qualification(changed)
        with self.assertRaises(ValueError):
            h.json_object(b'{"original_deadline":1,"original_deadline":2}')

    def test_new_file_guard_detects_mutation_symlink_and_overwrite(self):
        with tempfile.TemporaryDirectory(prefix="w1-unfunded-data-") as temporary:
            root = Path(temporary)
            path = root / "small.bin"
            h.write_new(path, b"original\n")
            chosen = h.file_record(path)
            self.assertEqual(chosen["bytes"], 9)
            h.require_binding(h.file_record(path), chosen)
            path.write_bytes(b"different")
            with self.assertRaises(ValueError):
                h.require_binding(h.file_record(path), chosen)
            link = root / "link.bin"
            link.symlink_to(path)
            with self.assertRaises(ValueError):
                h.file_record(link)
            output = root / "new-output"
            h.new_directory(output, ())
            with self.assertRaises(FileExistsError):
                h.new_directory(output, ())
            with self.assertRaises(FileExistsError):
                h.write_new(path, b"must not overwrite")

    def test_original_deadline_pair_cannot_rebase_or_round_up(self):
        boot = "11111111-2222-4333-8444-555555555555"
        other = "21111111-2222-4333-8444-555555555555"
        h.validate_deadline(1000 + h.MAX_BUDGET_NS, boot, boot, 1000)
        for deadline, supplied in ((1000, boot), (1001 + h.MAX_BUDGET_NS, boot),
                                   (2000, other), (True, boot)):
            with self.assertRaises(ValueError):
                h.validate_deadline(deadline, supplied, boot, 1000)
        for deadline in (1, 999999999, 1000000001, 9876543212345678):
            seconds = h.deadline_seconds(deadline)
            numerator, denominator = seconds.as_integer_ratio()
            self.assertLessEqual(numerator * 1000000000, deadline * denominator)
        self.assertEqual(h.PLAN["segment_workers"], 1)
        self.assertEqual(h.PLAN["compression_mode"], "sequential")
        self.assertEqual(h.PLAN["compression_workers"] * h.PLAN["rayon_threads"], 8)
        self.assertEqual(list(h.GRACE.values())[:3], [30, 12, 5])

    def test_resource_limits_require_actual_matching_raw_membership(self):
        with tempfile.TemporaryDirectory(prefix="w1-unfunded-cgroup-data-") as temporary:
            directory = Path(temporary)
            observation = {"affinity": list(range(12, 20)),
                           "membership_cgroup_paths": ["/observed-only/owned-unit"], "files": []}
            for name, raw in (("cpu.max", b"800000 100000\n"), ("memory.max", b"8589934592\n")):
                h.write_new(directory / name, raw)
                record = h.file_record(directory / name)
                observation["files"].append({"path": "/observed-only/owned-unit/" + name,
                    "raw_file": name, "sha256": record["sha256"], "bytes": record["bytes"], "status": "OBSERVED"})
            accepted = h.require_resource_sample(observation, directory)
            self.assertEqual(accepted["status"], "OBSERVED_SAMPLE_MATCHES")
            self.assertFalse(accepted["complete_process_tree_billing"])
            unknown = copy.deepcopy(observation)
            unknown["files"][0]["status"] = "UNKNOWN"
            with self.assertRaises(ValueError):
                h.require_resource_sample(unknown, directory)
            (directory / "cpu.max").write_bytes(b"400000 100000\n")
            changed = h.file_record(directory / "cpu.max")
            observation["files"][0].update({key: changed[key] for key in ("sha256", "bytes")})
            with self.assertRaises(ValueError):
                h.require_resource_sample(observation, directory)


if __name__ == "__main__":
    unittest.main(verbosity=2)
