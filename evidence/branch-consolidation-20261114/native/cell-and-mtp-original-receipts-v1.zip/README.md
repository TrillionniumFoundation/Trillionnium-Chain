# Cell and original wall-clock controls: original receipts

Cell selected commit: 283981a062158f3b41eea42d52f56eaee457ba97.
T08 selected commit: d81418ff49c3290c1abdb0e0fa0dec3ebe22aeb4.
The index binds every original log and source/summary artifact separately.

Cell Linux: 19 release + 13 availability + 8 network-budget + 4 cancellation
controls, zero failed/ignored, strict all-target Clippy; job 1a1d83ef373-392-d0b.
The first Mac availability run was 12 passed / 1 failed. It remains verbatim
in cell-mac/all-availability-controls.log. The subsequent unchanged-baseline
and isolated-port runs each passed that control. They neither reproduce nor
explain the original failure. Other original Mac suites and Clippy are included.

T08 Linux: both original controls passed, zero ignored, plus selected-test
strict Clippy; job 1a1d8458deb-392-d39. The original two complete test bodies
retain every assertion/diagnostic and original 4096-attempt, 2-second and
150-millisecond limits. The separate adapter patch changes only the fixture
to current Registered/bootstrap material and the explicit Settings argument.

These are component observations on the source identities in the receipts.
They do not certify the final combined root tree, all historical branches,
the hosted four-second confirmation gate, activation or release qualification.
