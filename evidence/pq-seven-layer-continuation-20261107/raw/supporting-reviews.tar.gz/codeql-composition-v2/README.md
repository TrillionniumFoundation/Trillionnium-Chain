# CodeQL workflow composition v2

This scratch candidate preserves the reviewed first composition and the exact
post-analysis observation block added by
`3d1b6507671ec694ce58e86d4063a125c8deeb66`. The patch is based on captured
`e36cfb88956a0e35e53d74c5ab71c94c628439d9` files and changes only the workflow
and its existing test. The copied source verifier is unchanged.

## Preserved behavior

- Keep real pinned CodeQL queries, Rust/Python/Actions, and both PR head and
  prospective-merge lanes: six PR combinations. Pushes retain three head lanes.
- Preserve `upload: never`; default setup remains responsible for Code Scanning
  uploads. No repository security setting was changed.
- Verify exact source before and after analysis with the real verifier and
  compare its deterministic JSON bytes. Verifier and comparison failures remain
  nonzero through `set -euo pipefail` and `tee`.
- Gate the main SARIF artifact on successful readback of genuine parseable
  SARIF. Keep original SARIF with source records, logs and actual step outcomes.
  Identity JSON alone cannot satisfy that artifact. Absent or invalid SARIF
  permits only the explicitly separate diagnostics artifact.
- Retain the concurrent ten-line observation block byte-for-byte, immediately
  before the after-source check. It writes NUL-delimited Git status and changed
  names plus a diff-stat record, even when source will subsequently be refused.

The source comparison checks two observations, not uninterrupted immutability
throughout extraction and query execution. Local SARIF fixtures are controls,
not substitute scan output. This work did not execute CodeQL or GitHub Actions,
change default scan scope, or qualify native runtime behavior.

## Actual local results

The twelve controls passed, including the original four SARIF cases, the first
composition's source/matrix/outcome controls, and the additional real-Git
observation control. That control changes a tracked file and creates an
untracked filename containing a newline. It checks both tracked-plus-untracked
and untracked-only states, preserves the raw NUL-delimited paths, and confirms
that the real after-source check still fails in each case.

`controls.stdout`, `controls.stderr` and `validation-summary.json` retain the
actual result: **12 tests, exit 0, 1.355 seconds**. YAML parsing and
`git apply --check --whitespace=error-all` against the e36 scratch snapshot also
passed. `prior-v1-files.json` verifies that all fifteen files in the original
11-control artifact remain unchanged.

| Candidate file | Git blob |
| --- | --- |
| `.github/workflows/codeql-real-exact-source.yml` | `614d7c1d26a06f221265b241ceb84c0d04f01330` |
| `scripts/ci/test_codeql_retention.py` | `ef5479e859528e19d843343bc0ab658e9b4d3df6` |
| `scripts/ci/verify_ci_source.py` (unchanged) | `c775290c138c3b41a32e654f56ed5cbe9acec3ee` |

Run the candidate controls with:

```bash
python3 -B candidate/scripts/ci/test_codeql_retention.py
```

`combined.patch` is based on e36; resolve it with the concurrent target rather
than applying it as a replacement for unrelated target changes. Update the
workflow/test source pins after composition. The recorded repository status
shows the parent's later merge already in progress when this scratch candidate
was finalized; this task did not edit the shared repository.

The frozen e36 native receipts retain their original identity and failed
disposition. A later CI-only composition must describe that mapping without
presenting those receipts as fresh native execution on the publication source.
