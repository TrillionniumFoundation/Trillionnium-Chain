#!/usr/bin/env python3
"""Complete the retained A analysis after correcting only an evidence-source path."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
BASE = ROOT / 'full-A-terminal-analysis-01'
OUT = BASE / 'completion-02'
REPO = ROOT / 'repo'
A = 'd3037ca5dfb6f301757c159b7888dca9b0317be0'
TREE = 'd4a8f84cdc896b9454ce0d03a164f8916e6afdf9'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    s = path.lstat()
    require(stat.S_ISREG(s.st_mode), 'ordinary original file')
    raw = path.read_bytes()
    e = path.lstat()
    require(all(getattr(s, k) == getattr(e, k) for k in ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')), 'stable file read')
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}, raw


def write(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())


def save(path, value):
    write(path, (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode())


def source(label):
    report = OUT / (label + '.json')
    argv = ['/usr/bin/python3', str(REPO / 'scripts/ci/verify_ci_source.py'), '--kind', 'head', '--expected-head', A, '--output', str(report)]
    result = subprocess.run(argv, cwd=REPO, capture_output=True, timeout=60, stdin=subprocess.DEVNULL,
                            env={**os.environ, 'PYTHONDONTWRITEBYTECODE':'1'})
    write(OUT / (label + '.stdout.log'), result.stdout); write(OUT / (label + '.stderr.log'), result.stderr)
    save(OUT / (label + '.command.json'), {'argv':argv,'exit':result.returncode})
    require(result.returncode == 0, 'exact A source guard')
    p, b = pin(report); v=json.loads(b)
    require(v['tested_commit']==A and v['tested_tree']==TREE and v['tracked_worktree_verified'] is True, 'exact A bytes')
    return p


def decode_cell(v):
    return bytes.fromhex(v['bytes_hex']) if type(v) is dict and 'bytes_hex' in v else v


def table_rows(dump, name):
    t = next(x for x in dump['tables'] if x['name']==name)
    require(t['complete_rows'] is True, 'complete copied table required')
    return [dict(zip(t['columns'], map(decode_cell,row))) for row in t['rows']]


def main(payload):
    require(BASE.is_dir() and not OUT.exists(), 'one new completion addendum')
    OUT.mkdir()
    write(OUT / 'complete_analysis.py', SCRIPT_TEXT.encode())
    report={'schema':'TRNM-W1-A-TERMINAL-ANALYSIS-COMPLETION1','analysis_complete':False,'errors':[],
            'source_commit':A,'source_tree':TREE,'proofs_dispatched':0,'original_database_connections_opened':0,
            'original_databases_written':False,'private_database_copies_excluded_from_publication':True,
            'source_checks':{},'started_monotonic_ns':time.monotonic_ns()}
    try:
        report['source_checks']['before']=source('source-before')
        predecessor_pin, raw=pin(BASE/'manifest.json'); prior=json.loads(raw)
        report['predecessor_manifest']=predecessor_pin
        require(prior['analysis_complete'] is False and prior['errors']==[{'type':'FileNotFoundError','message':"[Errno 2] No such file or directory: '/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/repo/scripts/w1_full_staged_run.py'"}], 'only the retained evidence-source path failure is repairable here')
        report['predecessor_failure_preserved']=prior['errors']
        inventory_pin, raw=pin(BASE/'original-file-inventory.json'); inventory=json.loads(raw)['files']
        indexed={x['path']:x for x in inventory}
        report['original_file_inventory']=inventory_pin
        report['original_file_inventory_rows']=len(inventory)
        report['corrected_source_originals']=[]
        for rel in ('formal/pon-nakamoto-v1/experiments/w1_full_staged_run.py','scripts/run_w1_postwin_proof.py'):
            p,b=pin(REPO/rel); write(OUT/'source-originals'/rel,b); report['corrected_source_originals'].append(p)
        selected=[]
        for arm,name in (('funded-balanced','proof'),('sequential-unfunded','postwin')):
            d=ROOT/(arm+'-run-01')
            selected += [d/name/'result.json',d/name/'controller/result.json',d/name/'checkpoint/stages.jsonl',
                         d/name/'checkpoint/manifest.json',d/name/'checkpoint/succinct.bin',d/'native-winner/result.json']
        selected += [ROOT/'funded-balanced-run-01/funded-result.json',ROOT/'funded-balanced-run-01/native-generation-v2.sqlite',
                     ROOT/'funded-research-node-01/native.sqlite',ROOT/'funded-research-node-01/native.sqlite.w1-generation-owner-v2.sqlite',
                     ROOT/'experiment-launch-plans-01/funded-balanced-config.json']
        report['rechecked_original_facts']=[]
        for p in selected:
            actual,_=pin(p); old=indexed[str(p)]
            require(all(actual[k]==old[k] for k in ('path','bytes','sha256')), 'retained original fact changed')
            if p.suffix=='.sqlite':
                require(all(not Path(str(p)+s).exists() for s in ('-wal','-shm','-journal')), 'original DB sidecar appeared')
            report['rechecked_original_facts'].append(actual)
        report['arms']=prior['arms']; report['funding']=prior['funding']
        b=prior['arms']['funded-balanced']; s=prior['arms']['sequential-unfunded']
        require(b['input_sha256']==s['input_sha256'] and b['guest_sha256']==s['guest_sha256'] and b['image_id']==s['image_id'], 'same full relation and fixed input')
        require(b['receipt']['sha256']!=s['receipt']['sha256'], 'distinct actual receipts expected')
        report['comparison']={'fresh_full_proof_trials':2,'funded_fresh_trials':1,'unfunded_fresh_trials':1,
            'shared_fixed_input':True,'different_receipt_bytes':True,
            'full_pipeline_balanced_minus_sequential_seconds':b['timing_seconds']['fresh_full_pipeline']-s['timing_seconds']['fresh_full_pipeline'],
            'full_pipeline_balanced_divided_by_sequential':b['timing_seconds']['fresh_full_pipeline']/s['timing_seconds']['fresh_full_pipeline'],
            'shared_host_causal_benefit_established':False,'population_p99_established':False,
            'scope':'One fixed-input fresh proof per plan, simultaneously on a shared host. Equal requested eight-CPU quota and eight-GiB memory; different core sets, worker plans, owner path and internal verifier Rayon settings. No randomized repeated experiment.'}
        native=json.loads((BASE/'private-analysis-only/research-native-sqlite-readback.json').read_bytes())
        active=table_rows(native,'active'); blocks=table_rows(native,'blocks'); deltas=table_rows(native,'deltas')
        intent=json.loads((ROOT/'funded-balanced-run-01/native-funded-intent.json').read_bytes())
        require(len(active)==1 and active[0]['tip'].hex()==intent['native_reserve_tip'] and len(blocks)==2,
                'unchanged isolated native Reserve tip')
        require(sorted(x['height'] for x in blocks)==[0,1]
                and next(x for x in blocks if x['height']==0)['id'].hex()==intent['native_reserve_parent']
                and next(x for x in blocks if x['height']==1)['id']==active[0]['tip']
                and all(x['block']==active[0]['tip'] for x in deltas),'actual canonical isolated chain')
        task_key='task:'+intent['task']; t=next(x for x in deltas if x['key']==task_key)
        task=json.loads(t['after'])
        require(t['before'] is None and task['status']=='reserved' and task['remaining']==1000 and task['output'] is None,
                'actual reserved native task row')
        owner=next(x for x in deltas if x['key']=='account:'+task['owner'])
        provider=[x for x in deltas if x['key']=='account:'+task['provider']]
        require(provider==[],'no provider account delta in original isolated chain')
        native_facts={'schema':'TRNM-W1-A-NATIVE-FUNDING-ROW-ANALYSIS1','source_database_pin':native['original_pin'],
            'current_tip':active[0]['tip'].hex(),'generation':active[0]['generation'],'height':1,'native_task':intent['task'],
            'native_task_key':task_key,'native_task_row':task,'owner_before':json.loads(owner['before']),'owner_after':json.loads(owner['after']),
            'canonical_post_genesis_blocks':1,'provider_account_delta_present':False,'provider_account_balance_not_independently_decoded':True,
            'native_settlement_or_cancel_block_present':False,'provider_payment_authorized':False,'native_task_refund_observed':False,
            'scope':'Nonsecret canonical rows from a stable private copy of the isolated research Node. Its current tip is exactly the original Reserve tip; only genesis and Reserve blocks exist. No original DB was opened by SQLite.'}
        save(OUT/'native-funding-rows.json',native_facts); report['native_funding_rows']=pin(OUT/'native-funding-rows.json')[0]
        report['current_terminal_scope_observations']={arm:values['readback'] for arm,values in prior['arms'].items()}
        report['original_source_files_unchanged']=True
        report['analysis_complete']=True
        review_dir=BASE/'cold-launch-static-review-01'
        require(not review_dir.exists(),'new cold launcher static review destination')
        review_dir.mkdir()
        sources=[]
        for name, expected in [('launch_owner_cancel_cold.py','1d3c3324253c58b5dbf59eba97e402f928273e17c9e4ac84e206065032a404b8'),
                               ('launch_owner_cancel_cold_v2.py','dffffa4cfedf49957de8fdc492b4a30a804beea4e4b6e70024b6f16bed681001')]:
            text=payload['cold_sources'][name]
            require(hashlib.sha256(text.encode()).hexdigest()==expected,'exact cold review source')
            write(review_dir/name,text.encode()); sources.append(pin(review_dir/name)[0])
        review={'schema':'TRNM-W1-COLD-LAUNCHER-STATIC-REVIEW1','sources':sources,'review_type':'read source + AST only',
                'executed_launcher':False,'executed_mock_or_heavy_test':False,'new_high_confidence_blockers':[],
                'v1_findings':['Require actual full affinity after setaffinity.','Recheck owner ELF before exec after preflight.','Original successful operation terminal must be an external prerequisite; result.json is pre-handoff.'],
                'v2_resolution':['Actual affinity equals all eight declared CPU IDs.','Owner ELF, original qualification/config, terminal receipt and launch declaration rechecked before exec.','Pinned actual original terminal receipt requires succeeded0, complete/durable and no cancellation/timeout; bound to original launch argv, interpreter, cwd, declaration, cgroup/job, boot and deadline.'],
                'cold_semantics':'Exact frozen C1 cold selector checks retained dispatch intent before begin and original config/statement/task/journal/job/clock; calls only existing operation reconcile, does not dispatch proof/cancel/payment, and does not renew original proof deadline.',
                'scope_limit':'Static review is not proof of future cold process success, current resource settlement, all descendants reaped, or payment authorization.'}
        save(review_dir/'review.json',review); report['cold_static_review']=pin(review_dir/'review.json')[0]
    except BaseException as exc:
        report['analysis_complete']=False;report['errors'].append({'type':type(exc).__name__,'message':str(exc)})
    finally:
        try:report['source_checks']['after']=source('source-after')
        except BaseException as exc:report['analysis_complete']=False;report['errors'].append({'scope':'source-after','message':str(exc)})
        report['completed_monotonic_ns']=time.monotonic_ns()
        save(OUT/'manifest.json',report)
        public=[pin(p)[0] for p in sorted(BASE.rglob('*')) if p.is_file() and 'private-analysis-only' not in p.parts]
        save(OUT/'publishable-file-inventory.json',{'schema':'TRNM-W1-A-PUBLISHABLE-INVENTORY1','exclude':['private-analysis-only/**'],
             'excludes_node_databases':True,'files':public})
        print(json.dumps({'analysis_complete':report['analysis_complete'],'manifest':pin(OUT/'manifest.json')[0],
                          'publishable_inventory':pin(OUT/'publishable-file-inventory.json')[0],
                          'native_funding_rows':report.get('native_funding_rows'),'cold_static_review':report.get('cold_static_review'),
                          'errors':report['errors']}))
    return 0 if report['analysis_complete'] else 1


if __name__=='__main__':
    raise SystemExit(main(INPUT_PAYLOAD))
