#!/usr/bin/env python3
"""Run the original nine V4 release/default sampler controls once.

Sampler correctness and SQLite layout qualification are separate observations.
Plain original Cargo output does not identify the selected SQLite build-script
OUT_DIR; candidate cache outputs alone never grant qualification to this ELF.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tarfile
import traceback

sys.dont_write_bytecode = True
import run_exact_selected_controls as common

COMMON_SHA = 'a8f8656fe25038fb67939b360b42631b6856dab9bd302365cd53591be2108e55'
ORIGINAL_ARCHIVE = 'evidence/pon-six-workpackages-20261106/composition/native-validation.tar.gz'
ORIGINAL_ARCHIVE_SHA = 'e1428cef1eb47be13788b7c8c24404033f37e8858695198006b13a3fc1736caf'
EXAMPLE = 'pon_w1_preparation_strategy_v4'
LABEL = 'v4-sampler-release'
ORIGINAL_ARGS = ['test', '--locked', '--offline', '--release', '--manifest-path',
                 'trillionnium/Cargo.toml', '-p', 'trnm-pon-node', '--example',
                 EXAMPLE, '--', '--test-threads=1']
NAMES = (
    'tests::all_six_structures_match_full_limb_and_independent_scalar_replay',
    'tests::both_preparations_reject_noncanonical_material_even_in_zero_products',
    'tests::exact_shards_reject_unfrozen_targets_horizons_and_extra_arguments',
    'tests::external_raw_material_is_exact_bounded_and_never_promoted_to_provenance',
    'tests::factorial_search_keeps_every_miss_and_identical_complete_winners',
    'tests::last_product_mutation_wraps_canonically_and_changes_only_that_word',
    'tests::valid_acquisition_and_late_product_refusal_keep_full_statement_identity',
    'w1_material::tests::default_materials_include_exact_continuity_fixture_and_reported_ranks',
    'w1_material::tests::material_bytes_require_exact_length_and_canonical_field_values',
)
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
SUMMARY = re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; '
                     r'(\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s$', re.M)


def original_contract(repo: Path, out: Path) -> dict:
    archive = repo / ORIGINAL_ARCHIVE
    identity = common.file_receipt(archive)
    common.require(identity['sha256'] == ORIGINAL_ARCHIVE_SHA, 'original sampler archive changed')
    selected = ['05-v4-sampler-release-receipt.json', '05-v4-sampler-release.log',
                '05-v4-sampler-release-source-before.json', '05-v4-sampler-release-source-after.json']
    with tarfile.open(archive, 'r:gz') as reader:
        members = reader.getmembers()
        values = {}
        for name in selected:
            matches = [m for m in members if m.name == name]
            common.require(len(matches) == 1 and matches[0].isfile(), 'original member absent/ambiguous: ' + name)
            stream = reader.extractfile(matches[0])
            common.require(stream is not None, 'original member unreadable: ' + name)
            values[name] = stream.read()
            (out / 'originals' / name).write_bytes(values[name])
    receipt = json.loads(values[selected[0]])
    before, after = [json.loads(values[n]) for n in selected[2:]]
    common.require(receipt['command'] == ['cargo', *ORIGINAL_ARGS], 'original Cargo argv differs')
    common.require(before['identity'] == after['identity'], 'original source identities differ')
    original_log = values[selected[1]]
    common.require(hashlib.sha256(original_log).hexdigest() == receipt['log']['sha256'], 'original log hash differs')
    observed = re.findall(r'^test (\S+) \.\.\. ok$', original_log.decode(), re.M)
    common.require(len(observed) == 9 and set(observed) == set(NAMES), 'original nine names differ')
    return {'archive': identity, 'original_measured_source': before['identity'],
            'original_argv': receipt['command'], 'names': list(NAMES),
            'scope': 'retained original recipe only; its execution is not credited to the new source'}


def mount_observation(path: Path) -> dict:
    result = {'path': str(path), 'resolved': str(path.resolve()), 'device': path.stat().st_dev}
    try:
        candidates = []
        for line in Path('/proc/self/mountinfo').read_text().splitlines():
            left, right = line.split(' - ', 1)
            fields = left.split()
            mount = Path(re.sub(r'\\([0-7]{3})', lambda m: chr(int(m[1], 8)), fields[4]))
            if path.resolve().is_relative_to(mount):
                candidates.append((len(str(mount)), {'mountpoint': str(mount), 'filesystem': right.split()[0]}))
        if candidates:
            result.update(max(candidates, key=lambda x: x[0])[1])
    except Exception as error:
        result['mount_observation_error'] = repr(error)
    return result


def witness_observations(release_dirs: list[Path], out: Path, phase: str) -> dict:
    """Read candidate outputs, preserving freshness without inferring ELF binding."""
    rows, errors = [], []
    directory = out / 'sqlite' / phase
    directory.mkdir(parents=True)
    paths = sorted({p for release in release_dirs for p in (release / 'build').glob('trnm-sqlite-io-boundary-*/output')})
    for index, path in enumerate(paths):
        row = {'output_path': str(path), 'selected_for_actual_elf_verified': False}
        try:
            row['output'] = common.snapshot_file(path, directory / f'{index:02d}-output.txt')
            text = (directory / f'{index:02d}-output.txt').read_text(errors='replace')
            row['declares_layout_witness'] = 'cargo:rustc-cfg=trnm_sqlite_layout_witness' in text.splitlines()
            row['declares_expected_fence'] = ('cargo:rustc-env=TRNM_SQLITE3_BUILD_FENCE=' + common.SQLITE_FENCE) in text.splitlines()
            row['declares_expected_amalgamation'] = ('cargo:rustc-env=TRNM_SQLITE3_AMALGAMATION_SHA256=' + common.SQLITE_AMALGAMATION_SHA256) in text.splitlines()
            row['contains_unqualified'] = 'UNQUALIFIED' in text
            row['symbols'] = {}
            for name in ['trnm-witness-symbols.stdout', 'trnm-witness-symbols.stderr']:
                source = path.parent / 'out' / name
                if source.is_file():
                    row['symbols'][name] = common.snapshot_file(source, directory / f'{index:02d}-{name}')
            archive = path.parent / 'out/libtrnm_sqlite_layout_witness.a'
            row['witness_archive_identity'] = common.file_receipt(archive) if archive.is_file() else None
        except Exception as error:
            row['inspection_error'] = repr(error)
            errors.append({'path': str(path), 'error': repr(error)})
        rows.append(row)
    return {'candidate_outputs': rows, 'inspection_errors': errors,
            'scope': 'read-only release-directory observations; no cache cleanup, rebuild or selected-unit qualification inferred'}


def harness_observations(text: str) -> dict:
    text = ANSI.sub('', text)
    announcements = re.findall(r'^\s*Running (.+)$', text, re.M)
    elf_rows = re.findall(r'^\s*Running unittests examples/' + EXAMPLE + r'\.rs \(([^\n()]+)\)\s*$', text, re.M)
    running = [int(n) for n in re.findall(r'^running (\d+) tests?$', text, re.M)]
    results = SUMMARY.findall(text)
    named = re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)(?:,.*)?$', text, re.M)
    counts = None if len(results) != 1 else dict(zip(['passed', 'failed', 'ignored', 'measured', 'filtered'], map(int, results[0][1:6])))
    passed = (len(announcements) == len(elf_rows) == 1 and running == [9]
              and len(results) == 1 and results[0][0] == 'ok'
              and counts == {'passed': 9, 'failed': 0, 'ignored': 0, 'measured': 0, 'filtered': 0}
              and len(named) == 9 and {n for n, _ in named} == set(NAMES)
              and all(status == 'ok' for _, status in named))
    return {'announcements': announcements, 'announced_elf_paths': elf_rows, 'running': running,
            'summaries': results, 'counts': counts, 'named_results': named, 'passed': passed,
            'scope': 'one actual Cargo example harness; nine exact names, no ignored/filtered credit or library-count substitution'}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo-root', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--cargo-proxy', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo_root.resolve(strict=True)
    out = args.output.resolve()
    common.require(re.fullmatch(r'[0-9a-f]{40}', args.expected_head) is not None, 'full expected commit required')
    common.require(not out.is_relative_to(repo), 'evidence must remain outside source')
    out.mkdir(parents=True, exist_ok=False)
    for name in ['native', 'recorder', 'originals', 'inputs']:
        (out / name).mkdir()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    report = {'schema': 'trnm-v4-sampler-release-validation-v1', 'started_utc': common.utc_now(),
              'expected_head': args.expected_head, 'runner': common.file_receipt(Path(__file__).resolve()),
              'source_before': None, 'source_after': None, 'native': None, 'harness': None,
              'registry': None, 'elf': None, 'errors': [], 'passed': False,
              'environment': {k: env.get(k) for k in (*common.ENV_KEYS, 'TMPDIR', 'CARGO_BUILD_TARGET', 'RUSTUP_TOOLCHAIN')},
              'profile_environment_overrides': {k: v for k, v in env.items() if k.startswith('CARGO_PROFILE_')},
              'scope': 'original nine sampler controls under release/default features; no SQLite boundary, production throughput or service-SLO qualification',
              'retry_policy': 'none; one original Cargo invocation and one read-only actual-ELF --list',
              'sqlite': {'status': 'UNKNOWN', 'qualified_by_this_run': False, 'selected_unit_binding_verified': False}}
    release_dirs, before_witness = [], {'candidate_outputs': []}
    cargo_log = ''
    try:
        helper = common.file_receipt(Path(common.__file__).resolve())
        common.require(helper['sha256'] == COMMON_SHA, 'reviewed common helper changed')
        report['common_helper'] = helper
        common.snapshot_file(Path(__file__).resolve(), out / 'inputs/sampler-runner.py')
        report['source_before'] = common.source_checkpoint(repo, args.expected_head, out, 'source-before', env)
        common.require(report['source_before']['passed'], 'source-before failed')
        source = report['source_before']['receipt']
        report['original_contract'] = original_contract(repo, out)
        for key in ['RUSTC', 'RUSTDOC']:
            common.require(bool(env.get(key)) and Path(env[key]).is_absolute() and Path(env[key]).is_file(), key + ' must be an actual absolute toolchain path')
        common.require(not any(k.startswith('CARGO_PROFILE_RELEASE_') for k in env), 'external release profile override changes the original recipe')
        for key in ['CARGO_TARGET_DIR', 'TMPDIR']:
            common.require(bool(env.get(key)) and Path(env[key]).is_absolute(), key + ' must be explicit and absolute')
            path = Path(env[key]).resolve(strict=True)
            common.require(path.is_dir() and not path.is_relative_to(repo), key + ' must be an existing task directory outside source')
            report[key + '_observation'] = mount_observation(path)
        target = Path(env['CARGO_TARGET_DIR']).resolve(strict=True)
        release_dirs = [target / 'release', *sorted(target.glob('*/release'))]
        before_witness = witness_observations(release_dirs, out, 'before')
        report['sqlite']['before'] = before_witness
        cargo = str(args.cargo_proxy.absolute())  # keep rustup's cargo argv[0]
        report['cargo_proxy_target'] = common.file_receipt(args.cargo_proxy.resolve(strict=True))
        argv = [cargo, '+1.95.0', *ORIGINAL_ARGS]
        report['argv'] = argv
        recorder = repo / 'scripts/ci/record_pq_native_command.py'
        report['original_recorder'] = common.file_receipt(recorder)
        execution = common.run_capture([sys.executable, str(recorder), '--kind', 'head',
            '--candidate', args.expected_head, '--tested', args.expected_head,
            '--label', LABEL, '--output', str(out / 'native'), '--', *argv],
            repo, env, out / 'recorder' / LABEL)
        report['recorder_execution'] = execution
        receipt_path = out / 'native' / (LABEL + '.json')
        log_path = out / 'native' / (LABEL + '.log')
        value = json.loads(receipt_path.read_text())
        log_identity = common.file_receipt(log_path)
        report['native'] = {'receipt': value, 'receipt_identity': common.file_receipt(receipt_path),
                            'log_identity': log_identity, 'native_exit': value.get('exit_code')}
        log_bound = (value.get('log_file') == log_path.name
                     and value.get('log_sha256') == log_identity['sha256']
                     and value.get('log_bytes') == log_identity['size'])
        source_bound = (value.get('before') == value.get('after') == source
                        and value.get('argv') == argv
                        and value.get('status') in ('command_succeeded', 'command_failed'))
        report['native'].update(log_verified=log_bound, source_bound=source_bound,
            passed=log_bound and source_bound and value.get('exit_code') == 0 and common.capture_passed(execution))
        cargo_log = log_path.read_text(errors='replace')
        report['harness'] = harness_observations(cargo_log)
        common.require(log_bound and source_bound, 'original native log/source receipt is incomplete')
        elf_rows = report['harness']['announced_elf_paths']
        common.require(len(elf_rows) == 1, 'Cargo did not announce one actual sampler ELF')
        binary = Path(elf_rows[0])
        common.require(binary.is_absolute() and binary.parent.name == 'examples'
                       and binary.parent.parent.name == 'release'
                       and binary.resolve(strict=True).is_relative_to(target), 'announced sampler ELF is outside the declared release target')
        before_elf = common.file_receipt(binary)
        with binary.open('rb') as stream:
            common.require(stream.read(4) == b'\x7fELF', 'announced sampler is not an ELF')
        common.require(os.access(binary, os.X_OK), 'announced sampler ELF is not executable')
        report['elf'] = {'identity_before_registry': before_elf,
                         'scope': 'post-original-command byte identity of Cargo-announced executable; no pre-execution loader attestation'}
        release_dirs = [binary.parent.parent]
        listing = common.run_capture([str(binary), '--list'], repo / 'trillionnium/crates/trnm-pon-node', env, out / 'registry')
        listing_text = Path(listing['stdout_path']).read_text()
        names = re.findall(r'^(\S+): test$', ANSI.sub('', listing_text), re.M)
        report['registry'] = {'execution': listing, 'names': names,
            'passed': common.capture_passed(listing) and len(names) == 9 and len(set(names)) == 9
            and set(names) == set(NAMES) and not re.search(r': benchmark$', listing_text, re.M)}
        report['elf']['identity_after_registry'] = common.file_receipt(binary)
        report['elf']['unchanged_across_registry'] = before_elf == report['elf']['identity_after_registry']
        common.require(report['elf']['unchanged_across_registry'], 'sampler ELF changed during registry read')
    except Exception:
        report['errors'].append(traceback.format_exc())
    finally:
        try:
            after = witness_observations(release_dirs, out, 'after')
            old = {r['output_path']: r.get('output', {}).get('input') for r in before_witness['candidate_outputs']}
            for row in after['candidate_outputs']:
                row['existed_before_original_command'] = row['output_path'] in old
                row['output_identity_changed_during_command'] = old.get(row['output_path']) != row.get('output', {}).get('input')
            report['sqlite']['after'] = after
            warnings = [line for line in cargo_log.splitlines() if 'trnm SQLite I/O boundary UNQUALIFIED:' in line]
            report['sqlite'].update(status='UNQUALIFIED_OBSERVED_IN_CARGO_LOG' if warnings else 'UNKNOWN_SELECTED_RELEASE_UNIT_BINDING',
                current_cargo_unqualified_warning_lines=warnings,
                explanation='The original plain Cargo command does not bind a selected SQLite build-script OUT_DIR to this ELF. Fresh or cached candidate outputs and absence of warnings are not qualification. Sampler tests grant none.')
        except Exception:
            report['sqlite']['inspection_error'] = traceback.format_exc()
        try:
            report['source_after'] = common.source_checkpoint(repo, args.expected_head, out, 'source-after', env)
            common.require(report['source_after']['passed'] and report['source_before'] is not None
                           and report['source_before']['receipt'] == report['source_after']['receipt'], 'final source identity differs')
            if report['elf'] is not None:
                final_elf = common.file_receipt(Path(report['elf']['identity_before_registry']['path']))
                report['elf']['identity_after_source_check'] = final_elf
                common.require(final_elf == report['elf']['identity_before_registry'], 'sampler ELF changed before final source check')
        except Exception:
            report['errors'].append(traceback.format_exc())
        report['finished_utc'] = common.utc_now()
        report['passed'] = (not report['errors'] and (report['native'] or {}).get('passed') is True
                            and (report['harness'] or {}).get('passed') is True
                            and (report['registry'] or {}).get('passed') is True)
        common.write_json(out / 'summary.json', report)
        (out / 'sampler.exit').write_text('0\n' if report['passed'] else '1\n')
        common.write_json(out / 'receipt-sha256.json', [common.file_receipt(p) for p in sorted(out.rglob('*')) if p.is_file()])
    print(json.dumps({'passed': report['passed'], 'native_exit': (report['native'] or {}).get('native_exit'),
                      'counts': (report['harness'] or {}).get('counts'), 'sqlite': report['sqlite']['status'],
                      'errors': report['errors']}), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
