import os,signal,time
from pathlib import Path
signal.signal(signal.SIGTERM,signal.SIG_IGN)
if os.fork(): os._exit(0)
os.setsid()
if os.fork(): os._exit(0)
os.setsid()
Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/collector-controls-desktop-ec265-01/test_actual_original_timeout_reaps_after_root_has_exited/running').write_text(str(os.getpid()))
time.sleep(3)
