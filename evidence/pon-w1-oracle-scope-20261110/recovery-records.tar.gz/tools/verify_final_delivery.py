#!/usr/bin/env python3
"""Check an evidence-only delivery without changing the tested implementation."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/0776da4af99b')
REPO = ROOT / 'repo'
OUT = ROOT / 'final-delivery-checks'
HEAD = '8dc625abe7116c75223a95f9be5931ca6075bf89'
BASE = 'e4abb172147e941b62483652b0ceabaae4317624'
SOURCE = '6e39f27357ce7c030f5662ada3d524fecb58d63e'


def run(name, argv, timeout=1200):
    start = time.time_ns()
    stdout, stderr = OUT / (name + '.stdout.log'), OUT / (name + '.stderr.log')
    with stdout.open('xb') as out, stderr.open('xb') as err:
        result = subprocess.run(argv, cwd=REPO, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
                                stdout=out, stderr=err, check=False, timeout=timeout)
    row = {'argv': argv, 'exit_code': result.returncode, 'started_unix_ns': start,
           'elapsed_ns': time.time_ns() - start, 'executed_commit': HEAD}
    for key, path in [('stdout', stdout), ('stderr', stderr)]:
        data = path.read_bytes()
        row[key] = {'path': path.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    (OUT / (name + '.receipt.json')).write_text(json.dumps(row, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'step': name, 'exit_code': result.returncode}), flush=True)
    return row


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=REPO)
    changed = subprocess.check_output(['git', 'diff', '--name-only', SOURCE, HEAD], cwd=REPO, text=True).splitlines()
    assert len(changed) == 14 and all(p.startswith('evidence/pon-w1-oracle-scope-20261110/') for p in changed)
    evidence = 'evidence/pon-w1-oracle-scope-20261110/'
    bridge = ['python3', '-B', 'formal/pon-nakamoto-v1/w1_quantum_native_bridge.py',
              '--archive', evidence + 'native-fullpath-e4abb172.zip',
              '--artifact-sha256', 'd9ce3ead97f87759707829220525f50420126fa0347cbd64ec46aeb69bbd57c9',
              '--native-source', BASE, '--native-tree', '016ebf3deeac88d6d7a782edf563f2291ebe17f5',
              '--preregistration-sha256', '9ba442904cc481e8371ff90bef97908dd1f0dcf59ce442375b18d0fd8a10f443',
              '--binary-sha256', 'fe18172189e555693c701d0d6b686c519e2a4c5d7a55ecdf999cb7c4e77db7b7',
              '--verify', evidence + 'reports/bridge-result.json',
              '--output', str(OUT / 'bridge-after-evidence-child.json')]
    rows = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        jobs = [pool.submit(run, 'evidence-child-bridge-replay', bridge),
                pool.submit(run, 'evidence-child-repository', ['python3', '-B', 'scripts/ci/check_repository.py'])]
        rows.extend(job.result() for job in jobs)
    rows.append(run('evidence-child-corpus', ['python3', '-B', 'scripts/ci/check_pq_research_integration.py']))
    rows.append(run('whole-delivery-whitespace', ['git', 'diff', '--check', BASE, HEAD]))
    assert all(row['exit_code'] == 0 for row in rows)
    original = (REPO / evidence / 'reports/bridge-result.json').read_bytes()
    rebuilt = (OUT / 'bridge-after-evidence-child.json').read_bytes()
    assert original == rebuilt
    bundle = ROOT / 'w1-oracle-8dc625abe711.bundle'
    rows.append(run('delivery-bundle-create', ['git', 'bundle', 'create', str(bundle), BASE + '..HEAD']))
    rows.append(run('delivery-bundle-verify', ['git', 'bundle', 'verify', str(bundle)]))
    rows.append(run('delivery-bundle-heads', ['git', 'bundle', 'list-heads', str(bundle)]))
    assert all(row['exit_code'] == 0 for row in rows)
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=REPO)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
    data = bundle.read_bytes()
    summary = {'schema': 'trnm-w1-evidence-child-final-verification-v1',
               'delivery_commit': HEAD, 'tested_implementation_commit': SOURCE,
               'evidence_only_paths': changed, 'repository_clean': True,
               'original_bridge_report_preserved_after_actual_child_replay': True,
               'bridge_report_sha256': hashlib.sha256(original).hexdigest(),
               'bundle': {'path': str(bundle), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                          'required_base': BASE, 'contains_two_new_commits': True},
               'steps': rows, 'all_final_checks_passed': True,
               'strict_clippy_executed': False, 'push_executed': False, 'draft_pr_created': False,
               'security_gate': 'HOLD', 'quantum_hardware_executed': False}
    (OUT / 'final-verification.json').write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'delivery_commit': HEAD, 'bundle': summary['bundle'], 'all_final_checks_passed': True}), flush=True)


if __name__ == '__main__':
    main()
