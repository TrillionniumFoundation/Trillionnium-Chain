import argparse,hashlib,json,os,pathlib,subprocess,sys,time
ROOT=pathlib.Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
A="d3037ca5dfb6f301757c159b7888dca9b0317be0"
def read(p):return json.loads(pathlib.Path(p).read_text())
def pin(p):
 p=pathlib.Path(p)
 return {"path":str(p),"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
def write(p,value):
 with pathlib.Path(p).open("x") as f:
  json.dump(value,f,indent=2,sort_keys=True);f.write("\n");f.flush();os.fsync(f.fileno())
 fd=os.open(str(pathlib.Path(p).parent),os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def identity():
 member=pathlib.Path("/proc/self/cgroup").read_text()
 assert member.startswith("0::/") and "hepta-runtime-job-" in member
 cg=pathlib.Path("/sys/fs/cgroup")/member.strip()[3:].lstrip("/")
 return {"pid":os.getpid(),"proc_stat":pathlib.Path("/proc/self/stat").read_text(),"boot_id":pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip(),"cgroup_membership":member,"cpu_max":(cg/"cpu.max").read_text(),"memory_max":(cg/"memory.max").read_text(),"affinity":sorted(os.sched_getaffinity(0)),"nice":os.getpriority(os.PRIO_PROCESS,0)}
os.umask(0o077)

parser=argparse.ArgumentParser()
parser.add_argument("--plan",required=True,type=pathlib.Path)
parser.add_argument("--config",required=True,type=pathlib.Path)
args=parser.parse_args()
out=ROOT/"funded-balanced-launch-01";out.mkdir(exist_ok=False)
os.sched_setaffinity(0,set(range(8)))
plan=read(args.plan)
assert plan["config_without_clock"]["expected_commit"]==A
before=identity();assert before["affinity"]==list(range(8))
clock=time.monotonic_ns();deadline=clock+7200*1_000_000_000
generator=ROOT/"experiment-config-tools-01/prepare_funded_config.py"
argv=["/usr/bin/python3.12","-B",str(generator),"finalize","--plan",str(args.plan),"--config",str(args.config),"--deadline-monotonic-ns",str(deadline),"--boot-id",before["boot_id"]]
declaration={"schema":"TRNM-W1-FUNDED-LAUNCH-OBSERVATION1","source_commit":A,"selected_monotonic_ns":clock,"original_deadline_monotonic_ns":deadline,"original_deadline_boot_id":before["boot_id"],"initial_identity":before,"plan":pin(args.plan),"generator":pin(generator),"wrapper":pin(pathlib.Path(__file__).resolve()),"finalize_argv":argv,"proof_deadline_can_be_extended":False}
write(out/"declaration.json",declaration)
with (out/"finalize.stdout").open("xb") as so,(out/"finalize.stderr").open("xb") as se:
 result=subprocess.run(argv,stdout=so,stderr=se,timeout=120)
 so.flush();os.fsync(so.fileno());se.flush();os.fsync(se.fileno())
write(out/"finalize-result.json",{"exit":result.returncode,"stdout":pin(out/"finalize.stdout"),"stderr":pin(out/"finalize.stderr"),"observed_monotonic_ns":time.monotonic_ns(),"original_deadline_monotonic_ns":deadline})
if result.returncode:raise SystemExit(result.returncode)
assert time.monotonic_ns()<deadline
owner=plan["owner_test"]
assert pin(owner["path"])=={k:owner[k] for k in ("path","bytes","sha256")}
owner_argv=[owner["path"],"store::async_w1_generation_v2::tests::heavy::funded_fresh_full_w1_generation","--exact","--ignored","--test-threads=1","--nocapture"]
write(out/"owner-exec-intent.json",{"argv":owner_argv,"config":pin(args.config),"owner_binary":owner,"identity":identity(),"observed_monotonic_ns":time.monotonic_ns(),"original_deadline_monotonic_ns":deadline,"original_deadline_boot_id":before["boot_id"],"funded_generation_outcome":"not_yet_observed"})
os.environ["TRNM_W1_FUNDED_CONFIG"]=str(args.config)
os.environ["PYTHONDONTWRITEBYTECODE"]="1"
os.execv(owner_argv[0],owner_argv)
