#!/usr/bin/env python3
"""Summarize exact-source readback; production/full-limb are the same kernel here."""
from collections import Counter
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


report = json.loads((HERE / "performance-report.json").read_text())
provenance = json.loads((HERE / "provenance-report.json").read_text())
binding = json.loads((HERE / "source-binding/DEFAULT_KERNEL.json").read_text())
assert report["reader_source"]["source_commit"] == binding["source_commit"]
assert binding["selected_kernel"] == "FullLimb"
assert sha(HERE / "source-binding" / binding["source_path"]) == binding["source_sha256"]
assert report["capture_count"] == 12 and report["all_requested_lanes_present"]
assert provenance["result"] == "PASS_RETAINED_CONSISTENCY_CHECKS"
head = report["reader_source"]["source_commit"]
summary = {
    "schema": "pon-w1-independent-default-limb-performance-summary-v1",
    "run_id": report["run_id"], "source_binding": binding,
    "result": "PASS_RETAINED_READER_AND_PROVENANCE_CONSISTENCY",
    "new_native_execution": False, "capture_count": 12,
    "all_requested_lanes_present": True,
    "cross_host_legal_search_fingerprints_match": report["cross_host_legal_search_fingerprints_match"],
    "production_and_full_limb_are_same_arithmetic_kernel": True,
    "production_vs_full_limb_ratio_interpretation": "Repeated timed invocations through two public entries of the same kernel. Relative timing is not an arithmetic implementation speedup or independent verifier evidence.",
    "legal_lanes": [], "false_trace_lanes": [],
    "retained_old_limb_faster_cpu_cohorts": [],
    "limitations": report["limitations"] + [
        "The earlier e885/8d9 production label meant Transposed; on this exact final 7c5 source it means FullLimb. Do not pool those labels as one unchanged implementation.",
        "Earlier Intel head legal/Product aggregate regressions against transcript-only limb remain historical evidence; no slower run is discarded.",
        "Cross-run host models and execution conditions differ. Before/after wall or CPU changes across those runs are not a controlled same-host causal comparison.",
    ],
}
totals = {"legal_record_counts": Counter(), "false_trace_record_counts": Counter(), "legal_strategy_attempts": 0, "false_trace_attempts": 0}


def lane_identity(item):
    v = item["validation"]
    return {"artifact_id": v["artifact_id"], "architecture": v["architecture"],
            "source_kind": "head" if v["source_commit"] == head else "prospective-merge",
            "source_commit": v["source_commit"], "reported_cpu_fields": v["reported_cpu_fields"]}


def cpu_comparison(paths, candidate, baseline="limb"):
    a, b = paths[candidate]["cpu_ns"], paths[baseline]["cpu_ns"]
    return {"candidate_cpu_ns": a, "baseline_cpu_ns": b, "candidate_over_baseline": a / b,
            "candidate_saved_fraction": 1 - a / b}


def cohort_distribution(cohorts, candidate):
    values = [c["sums_ns"][candidate]["cpu_ns"] / c["sums_ns"]["limb"]["cpu_ns"] for c in cohorts]
    return {"count": len(values), "candidate_faster": sum(v < 1 for v in values),
            "candidate_slower": sum(v > 1 for v in values), "ties": sum(v == 1 for v in values),
            "minimum_candidate_over_limb": min(values), "maximum_candidate_over_limb": max(values)}


def retain_slower(item, family):
    for cohort in item["raw"]["cohorts"]:
        comparisons = {path: cpu_comparison(cohort["sums_ns"], path)
                       for path in ("production", "full-limb-experimental")
                       if cohort["sums_ns"][path]["cpu_ns"] > cohort["sums_ns"]["limb"]["cpu_ns"]}
        if comparisons:
            summary["retained_old_limb_faster_cpu_cohorts"].append({
                **lane_identity(item), "family": family, "key": cohort["key"],
                "key_fields": ["case", "class", "target_index", "reuse_winners", "sample", "strategy"] if family == "legal-strategy" else ["case", "class", "sample"],
                "slower_entry_comparisons": comparisons,
                "all_path_cpu_ns": {k: v["cpu_ns"] for k, v in cohort["sums_ns"].items()},
            })


for item in report["legal_strategy"]:
    raw = item["raw"]
    totals["legal_record_counts"].update(raw["record_counts"])
    totals["legal_strategy_attempts"] += raw["attempts_across_all_measured_strategy_invocations"]
    lane = {**lane_identity(item), "complete_record_counts": raw["record_counts"],
            "complete_strategy_attempts": raw["attempts_across_all_measured_strategy_invocations"],
            "exhausted_searches": raw["exhausted_searches"], "semantic_alerts": item["semantic_alerts"], "cases": {},
            "dispatcher": {"strategy": "frozen-public-dispatch-v1",
                           "inclusive_total_costs_ns": item["total_strategy_costs_ns"],
                           "generic_over_dispatch": item["generic_over_dispatch"],
                           "dispatch_over_generic_cpu": 1 / item["generic_over_dispatch"]["cpu_ns"],
                           "slower_aggregate_cpu": item["generic_over_dispatch"]["cpu_ns"] < 1,
                           "class_cpu_ratios": {c: {"generic_over_dispatch": x["generic_over_dispatch"]["cpu_ns"],
                                                    "dispatch_over_generic": 1 / x["generic_over_dispatch"]["cpu_ns"]}
                                                for c, x in item["class_costs"].items()}}}
    for case, data in raw["cases"].items():
        cohorts = [c for c in raw["cohorts"] if c["key"][0] == case]
        lane["cases"][case] = {
            "sums_ns": data["sums_ns"],
            "default_over_old_limb": cpu_comparison(data["sums_ns"], "production"),
            "explicit_full_over_old_limb": cpu_comparison(data["sums_ns"], "full-limb-experimental"),
            "same_kernel_explicit_full_over_default_cpu": data["sums_ns"]["full-limb-experimental"]["cpu_ns"] / data["sums_ns"]["production"]["cpu_ns"],
            "cpu_cohort_distributions_against_old_limb": {path: cohort_distribution(cohorts, path)
                                                        for path in ("production", "full-limb-experimental")},
        }
    retain_slower(item, "legal-strategy")
    summary["legal_lanes"].append(lane)

for item in report["false_trace"]:
    cohorts = item["actual_reuse_cohorts"]
    totals["false_trace_record_counts"].update(item["raw"]["record_counts"])
    totals["false_trace_attempts"] += sum(c["attempts"] for c in cohorts)
    denominator = sum(c["full_attacker_cohort_total"]["cpu_ns"] for c in cohorts)
    paths = list(cohorts[0]["verification"])
    sums = {name: sum(c["verification"][name]["cpu_ns"] for c in cohorts) for name in paths}
    lane = {**lane_identity(item), "mode": item["mode"], "complete_record_counts": item["raw"]["record_counts"],
            "all_attempts": sum(c["attempts"] for c in cohorts),
            "exhausted_searches": sum(c["exhausted_searches"] for c in cohorts), "semantic_alerts": item["semantic_alerts"],
            "actual_inclusive_attacker_cohort_cpu_ns": denominator, "actual_receiver_cpu_ns": sums,
            "receiver_over_complete_attacker_cpu": {name: value / denominator for name, value in sums.items()},
            "per_material_receiver_over_attacker_range": {
                name: {"minimum": min(c["receiver_rejection_cpu_over_full_attacker_cpu"][name] for c in cohorts),
                       "maximum": max(c["receiver_rejection_cpu_over_full_attacker_cpu"][name] for c in cohorts)}
                for name in paths}}
    if item["mode"] == "full-limb":
        data = item["raw"]["cases"]["Transcript"]
        lane["comparison"] = {
            "default_over_old_limb": cpu_comparison(data["sums_ns"], "production"),
            "explicit_full_over_old_limb": cpu_comparison(data["sums_ns"], "full-limb-experimental"),
            "same_kernel_explicit_full_over_default_cpu": sums["full-limb-experimental"] / sums["production"],
            "cpu_cohort_distributions_against_old_limb": {path: cohort_distribution(item["raw"]["cohorts"], path)
                                                        for path in ("production", "full-limb-experimental")},
        }
        retain_slower(item, "false-trace")
    summary["false_trace_lanes"].append(lane)

totals["all_verifier_calls"] = totals["legal_record_counts"]["verifier"] + totals["false_trace_record_counts"]["verifier"]
totals["all_semantic_alerts"] = sum(len(x["semantic_alerts"]) for x in report["legal_strategy"] + report["false_trace"])
totals["cohorts_with_old_limb_faster_than_either_default_or_explicit_full_cpu"] = len(summary["retained_old_limb_faster_cpu_cohorts"])
totals["old_limb_faster_cpu_comparison_counts"] = {
    path: sum(path in c["slower_entry_comparisons"] for c in summary["retained_old_limb_faster_cpu_cohorts"])
    for path in ("production", "full-limb-experimental")}
totals["slower_dispatcher_aggregate_lanes"] = sum(x["dispatcher"]["slower_aggregate_cpu"] for x in summary["legal_lanes"])
summary["totals"] = totals
summary["qualification"] = {
    "hardness_accepted": False, "work_profile_qualified": False, "resource_fairness_qualified": False,
    "independent_hardware_qualified": False, "public_service_accepted": False, "production_activation": False,
    "legal_samples_per_class": 2, "unchanged_required_samples_per_class": 8,
}
summary["provenance"] = {
    "original_cost_zip_artifacts": len(provenance["artifacts"]), "cost_captures": 12,
    "all_original_zip_digests_and_members_match": True, "all_captured_binary_sha_and_ELF_architecture_match": True,
    "all_manifest_reader_fields_match": True, "metadata_graph_count": provenance["metadata_graph_count"],
    "distinct_metadata_graph_count": len(provenance["distinct_metadata_graph_sha256"]),
    "legal_jobs_have_separate_metadata_graph": True, "cargo_limits": provenance["limitations"][1],
}
summary["inputs"] = {name: sha(HERE / name) for name in ("performance-report.json", "provenance-report.json", "reader-source/SOURCE.json", "source-binding/DEFAULT_KERNEL.json")}
(HERE / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
print(json.dumps({"summary": str(HERE / "summary.json"), "totals": totals}), flush=True)
