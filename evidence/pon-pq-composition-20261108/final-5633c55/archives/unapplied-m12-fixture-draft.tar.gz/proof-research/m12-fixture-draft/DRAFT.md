# M12 authenticated-Current test injection draft

Status: draft only, based on `5633c55219c01c689f670c2ca35d122e39f3f791`. This patch has not been applied to the integration tree, compiled, formatted by Rust tooling, or executed. The original Node suite failure and its as-yet-unavailable panic remain separate observations. This proposal fixes a statically established fixture-stage mismatch; it does not claim that mismatch caused the observed failure.

## Exact proposed change

The existing fixture invokes its one-shot second SQLite writer inside `Transport::exchange`, after the witness service has produced a reply but before `WitnessClient::current()` has completed reply signature verification and its final 250 ms deadline check. Consequently that writer is part of the client exchange's elapsed budget.

The draft puts one optional `#[cfg(test)]` callback on the exact `NodeGenerationOwnerV3` instance. `mutate` consumes it immediately after `self.check_current()?` succeeds and before `with_recovery_fence_v3` starts the actual guarded SQLite transaction. The callback therefore follows successful client signature/deadline checks and equality with the validated local checkpoint. The real second writer can then change the local journal in the precise interval that the transaction-head guard must detect.

The test still calls the public `owner.begin(f.id)` and opens a real second `NativeGenerationStoreV2` connection to perform the same cancellation. The expected error must still contain `TRANSACTION_HEAD`. Quarantine, unchanged signed witness checkpoint, retained `[61; 32]` cancellation, and absence of dispatch intent are preserved. A new explicit counter requires exactly one injection; the original refusal assertion also reports its count and exact error. `DispatchDecisionV2` has no Debug implementation, so the result is extracted with `.err().expect(...)`, not `unwrap_err()`.

The obsolete transport callback fields, alias and branch are removed from the fixture. A later independent witness read cannot consume a leftover transport hook. The existing test names and test count remain unchanged.

## Scope and cleanup

All additions to the owner implementation are individually guarded by `#[cfg(test)]`; the non-test implementation has no added field, allocation, callback, public method, transaction branch, signed domain or storage schema. The Rust source file bytes necessarily change. Removing the four added test-only regions and their adjacent explanatory comment reproduces the original owner file byte-for-byte; this is a source-level check, not a compiler equivalence proof.

The callback is owner-instance-local, accepts an owned `FnOnce + Send + 'static`, and cannot be installed over an armed callback. `Option::take()` clears it before invocation. If it panics, the panic propagates and the test fails; normal unwinding drops callback captures and any temporary SQLite connection. No recovery-fence transaction has been installed at that point. There is no global or thread-local hook, held callback mutex, caught panic, fake success or claim that a panicked owner remains usable. If the authenticated Current check fails first, the hook is never run, the existing owner quarantine behavior remains, and the unused callback drops with that owner.

The original `MAX_EXCHANGE = Duration::from_millis(250)` code, all witness request/reply checks, the original business deadline, SQLite busy timeout, transaction-head guard and production error strings are unchanged. No deadline, retry, budget or allowed-error set is enlarged. Callback wall time is deliberately outside the witness Current exchange because this test targets the subsequent local transaction interval; this does not relax the timing contract of any witness exchange.

## Review and execution status

Only baseline extraction, patch construction and source-level checks were performed in this task-owned draft directory. The integration repository remained clean at the original HEAD, and both baseline source files matched it before and after drafting. The project preflight passed before draft edits. No Cargo, Rust compiler, Rust formatter, native test, remote job, commit or push was run.

After the original panic is available, the root task can decide whether to apply this proposal to a new isolated, explicitly identified candidate. Any later native result must bind that candidate and preserve the original failure; passing this one fixture would not establish whole-chain PQ security, independent witness custody, production rollback qualification, or a general timing budget.
