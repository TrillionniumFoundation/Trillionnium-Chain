from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback,re,gzip,ast
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source')
out=s.parent/'current-registration-9'
out.mkdir(exist_ok=False)
(out/'owner.py').write_text(sys.argv[1])
inp=json.loads(sys.argv[2]);(out/'inputs.json').write_text(json.dumps(inp,indent=2)+'\n')
env=os.environ.copy();env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];env['PYTHONDONTWRITEBYTECODE']='1'
res={'schema':'chain-owned-append-current-registration-v1','complete':False,'stages':[],'source_parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as o,(out/(name+'.stderr')).open('xb') as e:rc=subprocess.call(args,cwd=s,env=env,stdout=o,stderr=e)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime}
 for k in ('stdout','stderr'):
  raw=(out/(name+'.'+k)).read_bytes();row[k+'_bytes']=len(raw);row[k+'_sha256']=hashlib.sha256(raw).hexdigest()
 res['stages'].append(row);save();print(json.dumps(row),flush=True);return rc
def replace_once(text,before,after):
 assert text.count(before)==1,(before,text.count(before))
 return text.replace(before,after,1)
def historical_constants(text):
 d={}
 for node in ast.parse(text).body:
  if isinstance(node,ast.Assign):
   for name in node.targets:
    if isinstance(name,ast.Name) and (name.id.startswith('HISTORICAL_') or name.id=='REGISTRY_SHA256'):
     d[name.id]=ast.literal_eval(node.value)
 return d
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def blob(p):return subprocess.check_output(['git','hash-object','-w',str(p)],cwd=s,text=True).strip()
try:
 assert res['source_parent']=='f0a8364118df01113c14d6a81fbb6fdb6210e4ff'
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 tracked_before=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=s,text=True).splitlines()
 (out/'tracked-before.json').write_text(json.dumps(tracked_before,indent=2)+'\n')
 paths=['config/pon/authenticated-current-roster-v1.json','scripts/ci/test_authenticated_suite_count.py','.github/workflows/pon-recent-batch-acceptance.yml','.github/workflows/pon-original-workspace-large-state-cpu.yml','scripts/ci/check_pq_research_integration.py','scripts/ci/test_pq_research_integration.py','config/pon/pq-cross-branch-corpus-v1.json','docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md']
 before={p:(s/p).read_bytes() for p in paths}
 for p,data in before.items():
  target=out/'before'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 reader=before[paths[1]].decode();historical=historical_constants(reader)
 native_path=s.parent/'authenticated-original-include-ignored-8/native-authenticated.log'
 registry_path=s.parent/'native-registry-5/registry.stdout'
 raw_native=native_path.read_bytes();raw_registry=registry_path.read_bytes()
 assert hashlib.sha256(raw_native).hexdigest()=='83ca708525ff68f8bfa67db329b769507f109f78ca5db832e8580e9c692dc371'
 assert hashlib.sha256(raw_registry).hexdigest()=='53145dd409aa99a75cab15fa96e66a102ccc19f731f2b016ae62e29cdeab3559'
 current=sorted(re.findall(r'^(store::native_authenticated::[A-Za-z0-9_:]+): test$',raw_registry.decode(),re.M))
 old=json.loads(before[paths[0]])['tests']
 assert len(current)==len(set(current))==133
 assert set(current)-set(old)==set(inp['expectedTests']) and set(old)<set(current)
 assert len([x for x in current if x.startswith('store::native_authenticated::post_write_readback::tests::')])==55
 executed=re.findall(r'^test (store::native_authenticated::[A-Za-z0-9_:]+) \.\.\. ok$',raw_native.decode(),re.M)
 assert sorted(executed)==current
 summaries=[x for x in raw_native.decode().splitlines() if x.startswith('test result:')]
 assert len(summaries)==1 and summaries[0].startswith('test result: ok. 133 passed; 0 failed; 0 ignored;')
 roster={'schema':'trnm-authenticated-current-roster-v1','tests':current}
 (s/paths[0]).write_text(json.dumps(roster,indent=2)+'\n');roster_sha=sha(s/paths[0])
 evidence=s/inp['evidence'];evidence.mkdir(parents=True,exist_ok=False)
 (evidence/'native-authenticated.log.gz').write_bytes(gzip.compress(raw_native,mtime=0))
 (evidence/'node-registry.log.gz').write_bytes(gzip.compress(raw_registry,mtime=0))
 native_result=json.loads((s.parent/'authenticated-original-include-ignored-8/RESULT.json').read_text())
 registry_result=json.loads((s.parent/'native-registry-5/RESULT.json').read_text())
 rust_paths=[p for p in tracked_before if p.endswith('.rs')]+[p for p in inp['required'] if p.endswith('.rs')]
 rust_paths=sorted(set(rust_paths))
 provenance={'schema':'chain-owned-append-current-controls-v1','source_parent':res['source_parent'],'scope':'Actual default-feature release libtest registry and complete authenticated module invocation; no complete workspace, F0, cryptographic or publication qualification.','source_sha256':{p:sha(s/p) for p in rust_paths},'authenticated':native_result,'registry_result':registry_result,'raw_native_sha256':hashlib.sha256(raw_native).hexdigest(),'raw_registry_sha256':hashlib.sha256(raw_registry).hexdigest(),'authenticated_count':133,'postwrite_count':55,'original_97_historical_fixtures_unchanged':True,'previous_127_fixtures_retained_and_not_current':True,'public_v3_current_result':{'passed':294,'failed':1,'ignored':2,'failed_test':'ingress::public_v3::scalar_cpu::metered_fact_tests::continuously_distinct_bad_products_exhaust_one_original_prepaid_domain','attempts':512,'initial_credit_ns':400000000,'paid_cpu_debit_ns':298399949,'remaining_credit_ns':101600051,'minimum_start_reserve_ns':100000000},'prior_f0_run':44451798839,'prior_f0_30s_goals':1,'prior_f0_4s_goals':0,'prior_f0_goals_denominator':6,'prior_f0_root_connection_393_observer_incomplete':True,'new_f0_executed':False,'money':None}
 (evidence/'PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
 (evidence/'README.md').write_text('# Actual owned-append candidate controls\n\nThese deterministic gzip files retain the complete bytes of one actual default-feature release node registry and the complete original authenticated-module invocation, including ignored controls and the original retained-delta cost output. The native result is 133 passed, 0 failed, 0 ignored; the actual post-write subgroup contains 55 controls. The reader requires every exact registered name.\n\nThe frozen historical 97-control observations and the prior 127-control observations retain their original bytes and identities. Neither supplies the current 133 executions. This fixture does not qualify the complete workspace, original F0, public service liveness, cryptographic acceptance, or full Chain cost completeness.\n\nThe current public-v3 complete group remains 294 passed, 1 failed and 2 ignored: the unchanged 512-attempt paid-CPU depletion assertion failed with 298399949 ns actually paid from its original 400000000 ns initial credit. Its 100000000 ns start reserve was not crossed. No synthetic CPU, reduced budget or extra attempt was added. Prior F0 run 44451798839 remains failed (30-second goals 1/6, four-second goals 0/6), and ROOT connection 393 remains incompletely observed. The observer lock repair cannot reconstruct that historical cost.\n\nPROVENANCE.json records the original commands, raw hashes and actual source bytes. A new original F0 remains pending at this source-registration point. All earlier preparation and native failures remain retained in the candidate evidence archive and cost ledger.\n')
 reader=reader.replace('evidence/chain-native-operation-readback-20261119-2e9b/controls',inp['evidence'])
 for a,b in [('186d9594bc6af2fc4eeffdb895547c16bc0ac3bf443c410c92e2c18614dd5425',roster_sha),('38ef82773e04943365b8a16fbe420fdb345fc493ed1a4e5ae20c2b2055cd77e9',hashlib.sha256(raw_native).hexdigest()),('2e3c2c5a355fe61d1358e4c9b591d1b0cf868a63a8d45ea857fac4225540f4e4',hashlib.sha256(raw_registry).hexdigest())]:
  reader=replace_once(reader,a,b)
 for a,b in [('127','133'),('49','55'),('84','90'),('30','36')]:reader=re.sub(r'\b'+a+r'\b',b,reader)
 old_walk="""        expected = [POSTWRITE_PREFIX + name for name in re.findall(r'#\\[test\\]\\s*fn (\\w+)\\(', source.read_text())]
        for path, module in re.findall(r'#\\[path = "([^"]+)"\\]\\s*mod (\\w+);', source.read_text()):
            expected += [POSTWRITE_PREFIX + module + '::' + name for name in
                         re.findall(r'#\\[test\\]\\s*fn (\\w+)\\(', (source.parent / path).read_text())]
"""
 new_walk="""        visited = set()
        def declared_tests(path, prefix):
            # Follow only the real declared module edges, including nested controls.
            self.assertTrue(path.is_relative_to(source.parent))
            self.assertNotIn(path, visited)
            visited.add(path)
            text = path.read_text()
            names = [prefix + name for name in re.findall(r'#\\[test\\]\\s*fn (\\w+)\\(', text)]
            for child, module in re.findall(r'#\\[path = "([^"]+)"\\]\\s*mod (\\w+);', text):
                names += declared_tests((path.parent / child).resolve(), prefix + module + '::')
            return names
        expected = declared_tests(source, POSTWRITE_PREFIX)
"""
 reader=replace_once(reader,old_walk,new_walk)
 reader=replace_once(reader,'class WorkspaceSemanticRegistry(unittest.TestCase):\n','class WorkspaceSemanticRegistry(unittest.TestCase):\n'+inp['priorMethod'])
 assert historical_constants(reader)==historical
 (s/paths[1]).write_text(reader)
 workflow=before[paths[2]].decode()
 begin=workflow.index('if test "$suite" = store::native_authenticated::; then\n              grep')
 end=workflow.index('          PYLOG',begin)
 section=workflow[begin:end]
 for a,b in [('127','133'),('49','55'),('30','36')]:section=re.sub(r'\b'+a+r'\b',b,section)
 section=replace_once(section,'186d9594bc6af2fc4eeffdb895547c16bc0ac3bf443c410c92e2c18614dd5425',roster_sha)
 workflow=workflow[:begin]+section+workflow[end:]
 native_rel='trillionnium/crates/trnm-pon-node/src/store/native_authenticated.rs'
 workflow=replace_once(workflow,'e67c78df5baffe4a10491c5c47fc223eb8f44bea',blob(s/native_rel))
 trigger='      - .github/workflows/pon-recent-batch-acceptance.yml\n'
 workflow=replace_once(workflow,trigger,''.join('      - '+p+'\n' for p in inp['required'])+trigger)
 pins=[]
 for rel,wanted in re.findall(r'test "\$\(git hash-object ([^)]+)\)" = ([0-9a-f]{40})',workflow):
  actual=blob(s/rel);assert actual==wanted,(rel,actual,wanted);pins.append({'path':rel,'git_blob':actual})
 res['all_current_literal_source_pins']=pins
 (s/paths[2]).write_text(workflow)
 workspace=before[paths[3]].decode()
 workspace=replace_once(workspace,'prefix("node", "postwrite-readback", "store::native_authenticated::post_write_readback::tests::", 49)','prefix("node", "postwrite-readback", "store::native_authenticated::post_write_readback::tests::", 55)')
 (s/paths[3]).write_text(workspace)
 checker=before[paths[4]].decode()
 newset='# Exact owned-append and observer controls; these pins grant no F0 qualification.\nOWNED_APPEND_OBSERVATION_REQUIRED_PATHS = frozenset((\n'+''.join('    '+repr(p)+',\n' for p in inp['required'])+'))\nNATIVE_REQUIRED_PATHS |= OWNED_APPEND_OBSERVATION_REQUIRED_PATHS\n\n'
 checker=replace_once(checker,'def is_pq_source(parts: tuple[str, ...]) -> bool:',newset+'def is_pq_source(parts: tuple[str, ...]) -> bool:')
 (s/paths[4]).write_text(checker)
 tests=before[paths[5]].decode()
 tests=replace_once(tests,'    def test_authenticated_caller_v5_sources_cannot_omit_or_mutate(self):',inp['addMethod']+'\n    def test_authenticated_caller_v5_sources_cannot_omit_or_mutate(self):')
 (s/paths[5]).write_text(tests)
 plan=before[paths[7]].decode()
 plan+='\n### 2026-11-19 owned native append and observer lock candidate\n\nThe original first-graph profile identified repeated account-graph walks. The candidate carries only a fully verified original parent in the same actual GraphScope, Record and complete Root, after the unchanged native save_node writes and exact passive archive schema checks. Actual private write counts bind the operation; additional writes, another scope, transaction ABA, callbacks and cancellation keep the original complete reader/refusal. The child still receives its complete State and exposed-edge traversal; the original four slots, sixteen frontier entries, Host physical checks, locks and budgets remain unchanged. Six real signed native append controls bring the post-write subgroup to 55 and authenticated module to 133.\n\nThe observer snapshot copies the request row then releases that guard before task/phase inspection. It captures both closed flags before copying, so a later write/close does not make a stale copy complete. All 39 original/new observer controls pass; the original instrumented path fails all three new controls, and the intermediate release-only implementation fails the late-close control. This does not reconstruct the old ROOT connection 393 or assert full historical cost completeness.\n\nCurrent native validation: authenticated 133/133 with original include-ignored and retained-delta output; post-write 55/55; native-store 37 passed/5 ignored; detached 25 passed/1 ignored; History 56 passed/1 ignored; strict all-target release Clippy and format pass. Exact locked Linux node dependency tree and complete workspace metadata now pass with unchanged Cargo.lock. The public-v3 group remains 294 passed/1 failed/2 ignored: the original fixed 512-attempt depletion assertion has paid CPU 298399949 ns from 400000000 ns credit, leaving 101600051 ns, above the unchanged 100000000 ns start reserve. That current failure is retained without synthetic work, reduced credit, added attempts or rerun-to-green.\n\nHistorical F0 44451798839 remains failed (30-second goals 1/6 and four-second goals 0/6); the new original F0 is pending. Current exact 133/55 registration uses actual logs in evidence/chain-native-owned-append-20261119-2e9b/controls. Historical 97 and previous 127 fixtures remain byte-identical and cannot qualify this candidate. Full workspace, public service liveness, complete cost, owner adoption and cryptographic qualification are not inferred from these local controls.\n'
 (s/paths[7]).write_text(plan)
 manifest=json.loads(before[paths[6]])
 prior_required=set(manifest['required_paths']);prior_pins=dict(manifest['pinned_blobs'])
 assert not set(inp['required'])&prior_required
 manifest['required_paths']=sorted(prior_required|set(inp['required']))
 changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=s,text=True).splitlines()
 updated=[]
 for rel in sorted(set(changed)|set(inp['required'])):
  if rel in prior_pins or rel in inp['required']:
   current_blob=blob(s/rel)
   if manifest['pinned_blobs'].get(rel)!=current_blob:
    updated.append({'path':rel,'previous':manifest['pinned_blobs'].get(rel),'current':current_blob})
   manifest['pinned_blobs'][rel]=current_blob
 assert prior_required<=set(manifest['required_paths'])
 assert set(prior_pins)<=set(manifest['pinned_blobs'])
 (s/paths[6]).write_text(json.dumps(manifest,indent=2)+'\n')
 res['manifest_required_before']=len(prior_required);res['manifest_required_after']=len(manifest['required_paths']);res['changed_pins']=updated;res['roster_sha256']=roster_sha
 for rel in paths+inp['required']:res.setdefault('changed_sources',{})[rel]={'bytes':(s/rel).stat().st_size,'sha256':sha(s/rel),'git_blob':blob(s/rel)}
 (out/'source.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--']+paths,cwd=s))
 res['historical_guard_constants_unchanged']=True
 save()
 for name,args in [('diff-check',['git','diff','--check']),('authenticated-current-reader',['python3','-B','scripts/ci/test_authenticated_suite_count.py']),('cross-branch-integration-reader',['python3','-B','scripts/ci/check_pq_research_integration.py']),('cross-branch-integration-controls',['python3','-B','scripts/ci/test_pq_research_integration.py']),('authority-current-controls',['python3','-B','scripts/ci/test_pq_authority_effect_register.py'])]:
  run(name,args)
 res['complete']=True;res['all_stages_passed']=all(x['exit_code']==0 for x in res['stages']);save()
 print(json.dumps({'complete':True,'all_stages_passed':res['all_stages_passed'],'required_before':res['manifest_required_before'],'required_after':res['manifest_required_after'],'pins_updated':len(updated),'result':str(out/'RESULT.json')}),flush=True)
except BaseException as e:
 res['error']=repr(e);save();traceback.print_exc();raise
