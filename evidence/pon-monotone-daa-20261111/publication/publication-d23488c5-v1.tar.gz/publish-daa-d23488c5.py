import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path('/home/qian-qi/chain-daa-monotone-20261111-7f73')
SOURCE = ROOT / 'publisher'
OUT = ROOT / 'publication-d23488c5-v1'
BUNDLE = ROOT / 'daa-implementation.bundle'
COMMIT = 'd23488c5f9b4a6696c3799b12f14b8af0a1b81fc'
TREE = '72b106b4458299c37da146b0218b8f5276195b6d'
BRANCH = 'fix/chain-daa-monotone-witness-20261111-7f73'
BASE_BRANCH = 'fix/chain-joint-production-tail-20261110-8e76'
REPO = 'TrillionniumFoundation/Trillionnium-Chain'
URL = 'https://github.com/' + REPO + '.git'
BODY = ROOT / 'daa-draft-pr-body.md'
OUT.mkdir(exist_ok=False)
RECORDS = []


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(label, args, *, cwd=None, required=True):
    before = now()
    clock = time.monotonic()
    print(json.dumps({'phase': label, 'state': 'started', 'at': before}), flush=True)
    process = subprocess.run(args, cwd=cwd or ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout = OUT / (label + '.stdout.log')
    stderr = OUT / (label + '.stderr.log')
    stdout.write_bytes(process.stdout)
    stderr.write_bytes(process.stderr)
    record = {'label': label, 'argv': args, 'cwd': str(cwd or ROOT), 'returncode': process.returncode,
              'started_utc': before, 'finished_utc': now(), 'elapsed_seconds': time.monotonic() - clock,
              'stdout_path': str(stdout), 'stderr_path': str(stderr),
              'stdout_sha256': sha(stdout), 'stderr_sha256': sha(stderr)}
    RECORDS.append(record)
    (OUT / 'commands.json').write_text(json.dumps(RECORDS, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'phase': label, 'state': 'completed', 'returncode': process.returncode}), flush=True)
    if required and process.returncode:
        raise RuntimeError(label + ' failed; original streams retained')
    return process


def git_args(*args):
    return ['git', '-c', 'credential.helper=', '-c', 'credential.helper=!gh auth git-credential', *args]


result = {'tested_commit': COMMIT, 'tested_tree': TREE, 'branch': BRANCH,
          'base_branch': BASE_BRANCH, 'native_source_checkout_mutated': False,
          'production_activation': False, 'public_network_qualification': False}
try:
    identity = run('github-identity', ['gh', 'api', 'user', '--jq', '.login'])
    assert identity.stdout.decode().strip() == 'ProfHepta'
    result['github_identity'] = 'ProfHepta'
    assert BUNDLE.stat().st_size == 39479
    assert sha(BUNDLE) == '731940e7c4fcb1c0fc2cabd0a9bca5f3de7354a5a5b8c82217a9f0d4d0d64c72'
    assert not SOURCE.exists()
    run('clone-publisher', ['git', 'clone', '--no-hardlinks', str(ROOT / 'source'), str(SOURCE)])
    run('bundle-verify', ['git', 'bundle', 'verify', str(BUNDLE)], cwd=SOURCE)
    run('bundle-fetch', ['git', 'fetch', str(BUNDLE), 'HEAD'], cwd=SOURCE)
    actual = run('bundle-head', ['git', 'rev-parse', 'FETCH_HEAD'], cwd=SOURCE).stdout.decode().strip()
    assert actual == COMMIT
    branch = run('publisher-branch', ['git', 'branch', '--show-current'], cwd=SOURCE).stdout.decode().strip()
    if branch != BRANCH:
        run('candidate-checkout', ['git', 'switch', '-c', BRANCH, COMMIT], cwd=SOURCE)
    actual = run('publisher-identity', ['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=SOURCE).stdout.decode().splitlines()
    assert actual == [COMMIT, TREE]
    run('set-publisher-origin', ['git', 'remote', 'set-url', 'origin', URL], cwd=SOURCE)
    run('preflight', ['bash', 'scripts/project-preflight.sh'], cwd=SOURCE)
    run('source-before', ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py',
                         '--kind', 'head', '--expected-head', COMMIT,
                         '--output', str(OUT / 'source-before.json')], cwd=SOURCE)
    clean = run('publisher-clean', ['git', 'status', '--porcelain', '--untracked-files=all'], cwd=SOURCE)
    assert not clean.stdout.strip()
    before = run('remote-branch-before', git_args('ls-remote', '--heads', 'origin', 'refs/heads/' + BRANCH), cwd=SOURCE)
    existing = before.stdout.decode().strip()
    assert not existing or existing.split()[0] == COMMIT
    if not existing:
        run('push-candidate', git_args('push', '--set-upstream', 'origin', BRANCH), cwd=SOURCE, required=False)
    after = run('remote-branch-after', git_args('ls-remote', '--heads', 'origin', 'refs/heads/' + BRANCH), cwd=SOURCE)
    assert after.stdout.decode().split()[0] == COMMIT
    result['remote_head_verified'] = COMMIT
    run('base-branch', ['gh', 'api', 'repos/' + REPO + '/git/ref/heads/' + BASE_BRANCH, '--jq', '.object.sha'])
    fields = 'number,url,state,isDraft,headRefOid,baseRefName'
    listed = run('pr-before', ['gh', 'pr', 'list', '--repo', REPO, '--head', BRANCH,
                             '--state', 'all', '--json', fields])
    prs = json.loads(listed.stdout)
    assert len(prs) <= 1
    if not prs:
        run('pr-create', ['gh', 'pr', 'create', '--repo', REPO, '--base', BASE_BRANCH,
                         '--head', BRANCH, '--draft', '--title',
                         'test(pon): bind monotone DAA work witness and native result types',
                         '--body-file', str(BODY)], required=False)
    verified = run('pr-after', ['gh', 'pr', 'list', '--repo', REPO, '--head', BRANCH,
                                '--state', 'all', '--json', fields])
    prs = json.loads(verified.stdout)
    assert len(prs) == 1
    pr = prs[0]
    assert pr['headRefOid'] == COMMIT and pr['baseRefName'] == BASE_BRANCH
    assert pr['state'] == 'OPEN' and pr['isDraft'] is True
    result['pull_request'] = pr
    run('source-after', ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py',
                        '--kind', 'head', '--expected-head', COMMIT,
                        '--output', str(OUT / 'source-after.json')], cwd=SOURCE)
    result['publication_complete'] = True
except BaseException as error:
    (OUT / 'exception.log').write_text(traceback.format_exc())
    result.update(publication_complete=False, error_type=type(error).__name__, error=str(error))
finally:
    result['finished_utc'] = now()
    (OUT / 'result.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True), flush=True)
sys.exit(0 if result.get('publication_complete') else 1)
