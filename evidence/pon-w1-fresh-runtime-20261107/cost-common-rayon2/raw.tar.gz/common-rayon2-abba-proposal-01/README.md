# Common-Rayon-2 ABBA cost study — unexecuted proposal 01

**Status: NOT RUN; receipt binding UNOBSERVED.** No benchmark/native verification/receipt verification or proof-generation command is dispatched by proposal validation.

## One fixed common comparison

The real programs are from frozen A d3037ca5dfb6f301757c159b7888dca9b0317be0, tree d4a8f84cdc896b9454ce0d03a164f8916e6afdf9. The observer invokes the existing scripts/run_w1_deployment_comparison.py, with its pinned strict release w1-verify-v2. It does not replace the comparison algorithm.

One independent Hepta job requests CPUQuota 200%, MemoryMax 8 GiB, CPU affinity 8..9 and RAYON_NUM_THREADS=2. These conditions are checked from the actual cgroup/affinity and from each retained stage's environment. Both receipt arms receive the same conditions. Affinity avoids the known live full-job CPU ranges 0..7 and 12..19; this is not a claim of fully controlled host load.

Arm order is fixed: generation-arm-1, then generation-arm-2. Each invokes --repeats 10: native, proof, proof, native repeated ten times. Therefore each arm has 40 planned rows (20 native and 20 proof); the combined denominator is 80. The "A" and "B" letters inside ABBA mean native and proof verification, not the two generation arms.

All raw results, failed rows, actual exits, stage declarations, process identities, logs and artifact pins remain under the new output. Missing arm/result data stays unknown. The observer does not call an unobserved row "not dispatched" merely because readback failed. Following an actual failed arm, cancellation, deadline or unknown cleanup, the remaining arm is not launched; its planned rows remain in the denominator. No retries, row replacement or favorable-sample selection are allowed.

## Binding must wait for real generation terminals

binding.template.json has null/unobserved values and state WAITING_FOR_ACTUAL_GENERATION_TERMINALS. It is intentionally rejected by the executable.

The future binding must externally pin:

* One common 49,506-byte input, 318-byte header and 64-byte independently selected expected artifacts. The header is the declared nonce-0 context and expected artifacts have their original independent SHA.
* Each actual saved receipt's full raw path, byte count and SHA256.
* Each original full-generation job's authoritative durable terminal JSON, copied unchanged from the Hepta status result. The parser requires a terminal state, actual integer exit_code, output_complete/output_durable and distinct job_id values. A nonzero generation exit stays nonzero; binding does not turn it into successful generation.
* Original internal comparison result pins, when observed. Missing prior comparisons use null, not a fabricated result.

The two old internal ABBA runs used Rayon 4 and 8. Their original raw records remain separate and cannot be pooled with the new common2 sample. The new actual verifier checks every receipt and the complete native relation. After both arms finish, work_id and full public journal identity must also agree. The external binding itself does not constitute mathematical verification.

The caller supplies both the study declaration SHA and the independently reviewed binding SHA. An unbound template fails before a benchmark is spawned or a new experiment output is created.

## Clock, cleanup and statistics

The cost study gets a new local 600-second CLOCK_MONOTONIC deadline once setup is finished. Both arms receive that same absolute deadline and boot. It is exclusively a post-generation cost experiment: it does not rebase or extend either original 7200-second generation task, and creates zero new proofs.

The outer comparator supervision allows a 12-second TERM grace above the existing 5-second verifier-stage grace. A's existing owned Hepta cgroup Scope supplies bounded emergency cleanup. Cleanup cannot make a late comparison eligible. A canceled final snapshot/last row remains canceled through the real process exit and cancellation sidecar.

The existing comparator computes finite-sample medians and nearest-rank p95/p99. Each distribution has 20 repetitions of one fixed native claim or one fixed receipt. They are not 20 independent proof generations and do not estimate a population prover tail. The observer copies these statistics and, only after complete acceptance of both arms, reports arm2/arm1's proof inner **ratio of medians**. This is not the median of paired ratios. Sequential arm order and uncontrolled shared host load remain limits on causal comparison.

Inner verifier timing and cold-process supervision wall time remain separate. Do not add the owned-cgroup CPU delta to nested stage wait4 measurements, or sum nested RSS as peak memory. Full process-tree resource qualification, Node admission, funding/M12 recovery, WAN completion and deployment benefit are not established by this cost study.

## Future command

Only after real binding and parent review:

    /usr/bin/python3 run_common_rayon2_abba.py --execute \
      --declaration declaration.json --declaration-sha256 DECLARATION_SHA \
      --binding ACTUAL_BINDING_JSON --binding-sha256 ACTUAL_BINDING_SHA

proposed-hepta-launch.template.json is NOT_SUBMITTED and has unresolved binding arguments. It must not be sent as an actual job request. The one intended output is ROOT/common-rayon2-abba-A-01, which the observer creates exclusively.

Proposal validation runs AST parsing and seven pure data/negative-decision controls only. These controls exercise no successful prover or verifier stub and supply no measurement evidence.
