import argparse,datetime,hashlib,json,os,pathlib,re,resource,signal,subprocess,time
p=argparse.ArgumentParser();p.add_argument("name");p.add_argument("--timeout",type=int,required=True);p.add_argument("argv",nargs=argparse.REMAINDER);a=p.parse_args()
if a.argv and a.argv[0]=="--":a.argv=a.argv[1:]
root=pathlib.Path("/workspace/scratch/56818e4fba76/chain-history-next");out=pathlib.Path("/tmp/history-checkpoint-r8")/a.name;out.mkdir(parents=True,exist_ok=False)
def git(*argv):return subprocess.check_output(["git",*argv],cwd=root).decode().strip()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
(out/"runner.py").write_bytes(pathlib.Path(__file__).read_bytes())
paths=subprocess.check_output(["git","ls-files","-z"],cwd=root).split(b"\0")
manifest=[]
for raw in paths:
 if not raw:continue
 name=raw.decode();path=root/name
 if path.is_file() and (name.startswith(("trillionnium/","config/")) or name in ("rust-toolchain.toml","scripts/project-preflight.sh","scripts/ci/project_boundary.py","AGENTS.md")):
  manifest.append({"path":name,"bytes":path.stat().st_size,"sha256":sha(path)})
(out/"source-manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
diff=subprocess.check_output(["git","diff","--binary"],cwd=root);(out/"source.diff").write_bytes(diff)
env=os.environ.copy();env.update({"PATH":"/root/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:"+env["PATH"],"CARGO_TARGET_DIR":"/tmp/target-history-56818e4fba76","CARGO_BUILD_JOBS":"1","CARGO_INCREMENTAL":"0","CARGO_HOME":"/tmp/pure-pon-cargo-20261027"})
started=datetime.datetime.now(datetime.timezone.utc).isoformat();before=resource.getrusage(resource.RUSAGE_CHILDREN);t=time.monotonic();timed=False
with (out/"stdout.txt").open("wb") as stdout,(out/"stderr.txt").open("wb") as stderr:
 child=subprocess.Popen(a.argv,cwd=root,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=child.wait(timeout=a.timeout)
 except subprocess.TimeoutExpired:
  timed=True;os.killpg(child.pid,signal.SIGKILL);code=child.wait()
after=resource.getrusage(resource.RUSAGE_CHILDREN)
receipt={"schema":"history-checkpoint-exact-source-control-v1","name":a.name,"source_commit":git("rev-parse","HEAD"),"source_tree":git("rev-parse","HEAD^{tree}"),"source_status":git("status","--porcelain"),"runner_sha256":sha(out/"runner.py"),"source_scope":"all tracked materialized trillionnium and config inputs plus toolchain/preflight/AGENTS; includes tracked source dirty diff; no PQ feature","source_manifest_sha256":sha(out/"source-manifest.json"),"source_paths":len(manifest),"source_diff_sha256":sha(out/"source.diff"),"argv":a.argv,"env_overrides":{k:env[k] for k in ("PATH","CARGO_TARGET_DIR","CARGO_BUILD_JOBS","CARGO_INCREMENTAL","CARGO_HOME")},"started_utc":started,"elapsed_seconds":time.monotonic()-t,"exit_code":code,"timed_out":timed,"outer_timeout_seconds":a.timeout,"child_user_seconds":after.ru_utime-before.ru_utime,"child_system_seconds":after.ru_stime-before.ru_stime,"child_max_rss_kib":after.ru_maxrss,"stdout_sha256":sha(out/"stdout.txt"),"stderr_sha256":sha(out/"stderr.txt")}
if a.argv and pathlib.Path(a.argv[0]).is_file():receipt["binary_sha256"]=sha(a.argv[0])
matches=re.findall(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;",(out/"stdout.txt").read_text(errors="replace"))
receipt["harness_results"]=[{"outcome":r[0],"passed":int(r[1]),"failed":int(r[2]),"ignored":int(r[3])} for r in matches]
expect_tests=bool(a.argv and "history-r8-" in pathlib.Path(a.argv[0]).name and "--list" not in a.argv)
zero=expect_tests and not any(r["passed"]+r["failed"]>0 for r in receipt["harness_results"])
receipt["zero_tests_executed"]=zero
(out/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n");print(json.dumps(receipt));raise SystemExit(2 if zero else code if code>=0 else 128-code)
