import json, os
from pathlib import Path
report = json.loads((Path(os.environ['PQ_OUT']) / 'full-controls/result.json').read_text())
rows = report['cases']
assert report['schema'] == 'TRNM-W1-HARDENED-VERIFIER-CONTROLS1'
expected_names = {
    'valid', 'trailing', 'truncated', 'declared_seal_length_overflow',
    'composite_tag', 'groth16_tag', 'fake_tag', 'wrong_header',
    'journal_byte_0', 'journal_byte_20', 'journal_byte_338',
    'journal_byte_370', 'journal_byte_402', 'journal_byte_16817',
    'control_id', 'verifier_parameters', 'hash_function',
    'hash_function_sha256', 'hash_function_blake2b', 'claim_digest',
    'seal_first', 'seal_body', 'seal_last', 'seal_empty',
    'seal_short', 'seal_invalid_field',
}
assert len(rows) == len(expected_names) == 26
assert {row['name'] for row in rows} == expected_names
assert report['all_passed'] is True and all(row['passed'] is True for row in rows)
assert all(row['observed']['outcome'] == ('ACCEPT' if row['name'] == 'valid' else 'REJECT') for row in rows)
assert report['fake_proofs_used'] is False and report['consensus_admission'] is False
print('26 actual receipt controls passed; consensus admission remains false')
