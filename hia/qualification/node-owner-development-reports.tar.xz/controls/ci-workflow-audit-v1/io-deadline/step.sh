set -euo pipefail
deadline_observations="$RUNNER_TEMP/hia-node-pool-smoke-observations/io-deadline-controls"
mkdir -p "$deadline_observations"
deadline_status=0
python3 -B -m unittest hia.platform.mempool_node.test_io_deadline -v > "$deadline_observations/stdout.raw" 2> "$deadline_observations/stderr.raw" || deadline_status=$?
printf '%s\n' "$deadline_status" > "$deadline_observations/exit-code.txt"
cat -- "$deadline_observations/stdout.raw"
cat -- "$deadline_observations/stderr.raw" >&2
exit "$deadline_status"
