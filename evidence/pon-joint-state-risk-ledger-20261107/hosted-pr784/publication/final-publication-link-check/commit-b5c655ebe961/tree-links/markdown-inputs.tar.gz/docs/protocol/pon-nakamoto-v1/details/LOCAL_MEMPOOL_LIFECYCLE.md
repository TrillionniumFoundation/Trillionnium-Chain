# Native local queued PNX1 lifecycle

The existing Node M07/M08 SQLite/lock owner retains a bounded local queue using
M05 TypedAdmissionGate and the exact M06 executor. This is the explicit local
profile `native-local-queued-pnx1-v2`, not a second execution engine, task ledger,
external-effect supervisor or consensus mechanism. Public-development-v2 still exposes
only block Submit/Head/History; this module adds no transport operation.

## Identity, limits and persistent facts

`Node::enable_local_mempool(PoolLimits)` explicitly selects a context committed to
network, parameters, genesis and the deterministic serialized limits. The local DDL
hash includes its four tables. Older store schema/context is refused; no table import,
silent migration, fallback or change to existing chain transaction signatures is added.
Existing blocks can be validated into a fresh owner normally; the local queue is not a
consensus state key. Reopening alone supplies no new checked mining batch.

Limits are1..256 retained raw transactions,1..524288 raw bytes,1..16 members per local
group, a critical reserve below total record capacity,1..4096 retained removal digests
and an explicitly selected nonzero preview-miner identity. Pending, sequence-consumed,
expired and blocked archives **all** consume the same row/byte budgets. Each raw PNX1
is at most2048 bytes. If new admission needs capacity, V2 may evict whole branch-relative terminal cache
groups as specified below; queued/blocked or partly terminal groups stay protected. A
full protected queue rejects explicitly. Each group preserves original order/bytes/digest/signer/nonce/expiry/fee-limit;
fixed eight-byte nonce/expiry/fee columns preserve the full wire u64 range.

The M05 adapter privately borrows the immutable original raw slice rather than
cloning that body merely to decode it. It re-encodes canonical PNX1, checks the
exact H(tx-id, complete signed bytes) and signer, and invokes the existing M06 main
preparation for the selected tag, network, expiry and strict Ed25519 signature.
M05 signer-scoped replay/recheck operates against the exact pending sequence prefix.
Its `max_gas` bridge is the configured command base-fee plus encoded-byte fee, and
`max_bytes` is measured canonical envelope length. These are derived local admission
bounds; PNX1 has no signed gas field and this is not arbitrary-program gas metering,
a measured CPU lower bound or a computational-hardness certificate.

Ready metadata is bound using an invocation-local bounded digest-to-original-raw
index. Duplicate digests refuse before any replacement; each ready digest consumes
one entry, its body must match every original byte, and successful draining leaves
no unmatched entry. This removes repeated reverse scans and PNX1 decoding solely
from this binding step. Full canonical M05 checks remain required; successful
same-operation main-signature facts may be reused as specified below. M06
uses the operation-local suffix builder below for growing prefixes; no signature
or admission verdict survives the owner operation.

After typed checks, M06 checks the complete candidate prefix against one immutable
parent using the configured preview miner. This handles actual funds/fees, nonce
sequences, funding dependencies, profile gates and control semantics. Success is a
local execution preview; its proposed state, fees, nonce, subsidy and receipts are
never installed into chain state by queue admission. Actual block creation/admission
must run the existing authoritative work and execution path again.

## Operation-local parent preparation and remaining cost

Every pool owner invocation reads and root-checks the actual active parent.
After the first successful typed check it binds that immutable State and its complete
canonical bytes once, using `CheckedExecutionParent`. Rust's shared borrow prevents
mutation of that State during the binding lifetime. Every subsequent group preview in
that same invocation uses the same original parent. A submit invocation also reuses
that checked original parent for its final pending-prefix preview after
reconciliation; pool-only writes cannot change the owned
parent State. Before new admission it rechecks namespace, parent ID, generation,
height and recorded root. `POOL_PARENT_CHANGED` refuses an unexpected ID, generation
or height change during that same owner call; a recorded-root mismatch refuses `ROOT`.
The binding and all prefix scratch are dropped before the public owner call
returns. They are never persisted, published as an active commitment, or shared
with another invocation. Cold reopen,
the next admission, mining-batch creation and batch validation still obtain and check
their actual parent. Both existing parent/generation SQL fences remain mandatory
before reconciliation publication and new admission commit.
This relies on the existing single-owner boundary and adds no SQL snapshot isolation
or guarantee against a rogue second connection mutating chain records mid-operation.

Accepted raw scratch storage appends one group's original bodies and truncates that
append on failure. It no longer clones all previously accepted raw bodies per group.
The group order, typed checks and first-error classifications are unchanged, including
a blocked middle group followed by an independent valid group. Parent binding is lazy
so a typed admission error still precedes parent execution preparation errors.

### Same-operation M05 main-signature facts

Each `PendingPreview` retains private `CheckedPnxSignature` values only after the
entire candidate has passed the actual M05 gate and M06 preview. The real
`Hooks::verify_signature` mints a value only after `validate_main_envelope` has
checked canonical decoding, selected tag/profile, network, expiry and strict main
signature, and its result matches the adapter and queued metadata. The value binds
every original signed byte, the height, parent ID and shared-borrow identities of
the actual parent State and complete Config. The Config snapshot is owned by the
operation's `PoolParent`, so pool-only SQL writes cannot change or invalidate this
immutable borrow. No Node cache, durable row or public API holds these facts.

Reuse requires every retained raw at its original prefix position and the same
complete context. A replacement, reorder, truncation or context mismatch selects
ordinary native signature checking; it does not raise an earlier synthetic error.
The unchanged M06 full-byte prefix check still runs after M05. Every invocation
continues to reconstruct the actual `TypedAdmissionGate`, canonical metadata,
digest/raw index, signer-scoped nonce progression, fee/resource checks, lane limits
and ready bodies for all positions. Capacity-before-signature and all existing
first-refusal ordering are retained. Both `BeforePrepare` and `AfterPrepare`
cancellation callbacks remain around every M05 position, including reused ones.

Fresh signature facts are staged beside the attempted suffix. Relation rejection,
cancellation or unwind discards them without changing the accepted facts. Capacity
for publication is reserved before M06 can commit its new in-memory prefix; success
then moves initialized values without allocation. The same private vector may move
from reconciliation to the final submit preview within that one owner call. A new
owner call, mining-batch preview or batch validation starts with no signature facts.
M06 keeps its own strict signature and all state-dependent checks.

For N valid single-member groups, M05 main-envelope checks are N instead of
N(N+1)/2 within one operation. The actual M05 lane admissions, canonical decoding,
nonce/recheck operations and ready-body checks remain N(N+1)/2. Rejected suffix
work is repeated on retry and is not subtracted from observed cost. Successful
facts add at most 256 retained complete raws / 524288 body bytes, plus Vec,
reference and allocator overhead; staged attempted facts and the existing gate,
M06 prefix and output memory also remain. The bounded full-byte prefix comparison
is nonpreemptive. This is neither a physical RSS bound nor an end-to-end complexity
or latency guarantee.

### Same-block incremental M06 prefix

`CheckedExecutionParent::into_prefix_with_control` consumes the complete checked
original-parent binding into `CheckedTransactionPrefix`. Its fixed `PrefixContext`
contains the original height, parent ID and preview miner; configuration is frozen
for that operation. The existing `ExecutionSession` remains a complete-block
session and is not reused here, because advancing it would run another block's
mandatory actions and subsidy.

The shared M06 `prepare_block_state` executes original mandatory expiry, maturity,
model cleanup and parent continuity checks once. The builder retains that state
before the current block's reward and subsidy. Every call compares every original
accepted transaction byte with the beginning of the supplied full prefix, then runs
the same M06 `prepare` and `apply_prepared` only for the newly appended suffix.
Funding dependencies, signatures, nonce progression and all selected model/task
rules use the accumulated state in canonical transaction order.

For each candidate group, the shared complete-block epilogue computes total fees,
exact reward identity/maturity, issued supply, conservation and continuity capacity.
The original-parent commitment adapter still encodes the entire resulting State,
checks all protocol/cache bounds and returns complete State, ordered receipts,
root and original-parent deltas. These epilogue writes are then removed from the
scratch state so the next group cannot spend the pending subsidy, repeat mandatory
actions or reuse a completed block as its parent.

Changed-key before-images retain the previous accepted prefix throughout suffix
application, epilogue and commitment. A relation rejection, local cancellation or
unwind restores all changes from the attempted group, including an earlier valid
member of a later-invalid group. No failed group advances fees, receipts, raw
prefix or nonces. Cancellation remains distinct from an application rejection:
it ends the owner call and cannot be relabelled as a merely Blocked transaction.
The Node still checks current restricted-owner permission against the complete
prefix before this computation and preserves both original SQL fences.

For N accepted single-member groups in one reconciliation, M06 prepares/applies
N transaction positions instead of N(N+1)/2. A submit operation carries this same
scratch across its reconciliation and final new-bundle check. Output metrics count
the new M06 suffix only; output State, receipts and deltas cover the entire prefix.
There are no spawned M06 workers on this serial Pool preview path, and actual
caller CPU accounting still covers its complete work.

This is not an end-to-end linear-time claim. M05 still rebuilds and admits the
complete prefix at every candidate group; only its fixed-context main-signature
facts have the bounded reuse above. Every result retains full State encoding,
root/continuity/conservation checks and a complete output State; caller-defined
cache limits still choose the complete-root fallback. Mining-batch selection and
public mutable-batch validation still perform their own full checks after their
required reconciliation. New operations reread actual State. SQLite, root building,
deep ancestry and other native stages remain nonpreemptive; the single Node owner
and service-latency/public-throughput acceptance are unchanged.

The retained historical `immutable_parent_preview_component_timing` test compares
fresh parent
preparation per prefix with an operation-local binding on 16 signed prefixes and 4099
state keys (4096 inert synthetic padding entries), checking every root. This state
shape is a component fixture, not proof that native transactions generate that state.
Cold and warm parent-cache paths are reported separately
in four rotating arms with eight samples each. They include M06 execution and commitments,
but exclude M05 admission, SQLite, lock waiting and concurrent clients. The ordinary
`immutable_parent_previews_match_full_execution_including_failures_and_rebind` selector
checks exact state/root/receipts and failure strings against full execution, including
invalid signatures, nonce ordering, cold binding and zero optional-cache budgets.

Resource limits remain distinct: retained raws are capped at 524288 bytes; valid
protocol canonical state is at most 65536 keys, 160 key bytes and 4096 value bytes per
entry (266 MiB of key/value payload at all maxima). The optional derived-cache limits
are 8 MiB payload and 512 MiB software workspace charge; exceeding those selects full
root computation, not rejection of otherwise valid protocol state. The operation-local
binding retains canonical parent bytes for the operation and does not lower those
protocol limits. These figures exclude JSON/allocator overhead, cloned executor State,
SQLite page cache and WAL, process RSS and filesystem allocation. No physical memory,
physical disk or execution deadline cap is implemented by this change. Such limits need
separate process/storage enforcement and an explicit failure/recovery policy, rather
than silently redefining valid state or labelling a software charge as a physical bound.

## Admission-triggered terminal cache eviction V2

V2 has a fresh profile/context/group hash domain and metadata DDL; opening a V1
owner refuses before database mutation. V1 source and evidence retain their original
finite-cache behavior. This is a fresh local storage continuation, not a consensus or
transaction signature change. See the exact algorithm and diagnostics in
[LOCAL_MEMPOOL_CACHE_V2](LOCAL_MEMPOOL_CACHE_V2.md).

Only a new, validated admission that needs row/byte space triggers cache eviction.
The owner selects oldest whole SequenceConsumed/Expired groups only when **every**
member is expired or its nonce has been consumed in the actual active branch.
Queued, Blocked and partly terminal groups are protected. Capacity reclaim, fixed-size
GC counters/hash head and insertion of the new complete group commit atomically.
Invalid native/M05/M06 admission or a failed SQL insertion leaves evicted raw groups
and counters intact. Reads, reconciliation, duplicate receipts and unsuccessful
protected-full submissions do not evict cache.

Cache eviction makes no local revocation or exact-inclusion/finality claim. It creates
no removal tombstone and promises no automatic requeue. After a heavier fork a valid
original raw may be resubmitted and fully checked again. Explicit operator pruning
below remains monotonic, independently capped and irreversible locally across reorg.

## Atomic local groups and exact mining batches

`pool_submit(raw)` and `pool_submit_bundle(raws)` perform resource/capacity, canonical,
strict signature/replay and complete M06 prefix checks before one SQLite transaction
writes the group and all members. A failed second row rolls back the first row and
group header. Rebuilding the real TypedAdmissionGate yields actual admission/ready
metadata counts for the full reconstructed pending prefix, not only new submitted
members; no fake PendingNonceReservation token or committed-chain fact is
created. SQLite owns durable local reservations. Owner group order is retained; M05
lane pop order is not permitted to split a group or reorder signed account sequences.

This protects **local queue and batch assembly only**. A block producer may separately
include signed transactions. Consensus renewal atomicity requires the single
[V3 tag22](QUALIFIED_TASK_LIFECYCLE_V3.md); a V2 tag19/tag21 local bundle cannot fix its
sole-task liveness gap.

`pool_mining_batch(parent,generation,max_records,max_bytes)` requires the actual active
parent and generation, selects an intact prefix of complete queued groups, rechecks
M05/M06 and returns original raws plus group IDs and local context. A group exceeding
the batch budget is not partially returned. `pool_validate_batch(&batch)` checks exact
retained group order/raw bytes, current status, preview miner and parent/generation,
then executes the current checks again. `pool_batch_is_current` is only a cheap context/
generation fence and grants no authenticity or chain activation. A miner must recheck
before use; actual Node validation still decides admission, activation and confirmation.

## Reopen, branch changes, statuses and local pruning

`pool_reconcile` replays complete original groups against the actual active parent in
insertion order. `pool_status` explicitly performs this reconciliation. A valid pending
group is Queued; expired groups are Expired; an active ledger sequence already consumed
is SequenceConsumed; temporarily invalid application/sequence prefixes are Blocked.
SequenceConsumed does **not** assert this exact transaction was mined. Exact inclusion
and confirmation remain normal chain observations. New groups cannot replace a queued
signer/nonce conflict. A matching retained group returns a bounded duplicate receipt
with its current state, not a new reservation or an execution guarantee.

Retained raw groups can become Queued again after a heavier fork restores their
unexpired account sequence and application state. They undergo strict typed and whole
M06 checks before reuse, including after restart. Branch-relative classification may
change; its local insertion/removal facts do not roll back with a chain reorganization.

`pool_status_snapshot` is bounded read-only and never invokes M06. It reports actual
active parent/generation, last checked parent/generation and `classification_current`.
A chain change makes its old classification visibly stale. A public status adapter
must preserve this scope instead of quietly triggering whole-prefix execution or
promoting stale Queued/SequenceConsumed to inclusion or confirmation.

`pool_prune_terminal(group)` is explicit local pruning only. It cannot prune Queued
facts. One atomic SQLite transaction records each original signed transaction digest
and removes its terminal group; regrouping, replay or a chain reorg cannot silently
resurrect locally removed signed members. Raw-digest removal history has its own
finite budget; full removal history refuses further prune. These logical row/byte
budgets are not a physical SQLite/WAL, chain archive or whole-disk quota. No global duplicate filter,
infinite physical retention, source fairness or chain-external permission is inferred.

## Native tests and remaining scope

`trnm-mvcc-fee/tests/incremental_prefix.rs` compares every signed growing prefix
with a separate complete M06 invocation. Cases include cross-account funding,
fees, one mandatory expiry, the full twenty-reward maturity queue, legacy and
continuity profiles, changed prefix/actual-parent bytes, invalid partial groups,
cancellation through output, unwind, and capacity rejection followed by a valid
same-nonce append. It checks complete state, ordered receipts, root and actual
suffix signature/apply counts, without claiming a native reachable maximum-state
history from the component capacity fixture.

`store::mempool::incremental_prefix_tests` observes actual M06 stage callbacks
through native Pool reconciliation and submission. Six retained single-member
groups plus one new group execute seven M06 transaction positions and one
mandatory prologue. It also observes seven actual M05 main-envelope calls while
all 28 M05 admission positions retain their callbacks. The next mining-batch call
observes seven fresh reconciliation checks plus seven separate batch checks.
The resulting batch is mined and admitted through normal
Work/M06, compared with the complete original-parent reference, and cold reopened.
Its second control checks cancellation and invalid new suffix rollback before a
successful same-nonce retry. These are exact source test definitions; their
execution status belongs to the committed-source qualification receipt.

The same module compares twelve concrete signature, encoding, replay, duplicate,
fee, funds, raw replacement/reorder/truncation refusals with a forced-fresh M05
control on the same accepted M06 prefix. It checks actual native call counts,
unchanged prior facts and a valid same-nonce retry. Real typed-gate checks rebind
parent ID, State allocation, height and the complete Config allocation, including
equal-byte copies, expired height and a wrong network. Five cancellation points
and five caught unwind points preserve both prior prefixes before retry.
The private adapter's original raw pointer is also checked, without claiming that
metadata, decoded payload or commitment allocations have disappeared.

The explicitly invoked `normal_m05_signature_reuse_component_timing` selector
compares six alternating pairs on sixteen signed growing prefixes. Both arms use
the current source and execute all real M05 gates, M06 epilogues and commitments;
the repeated-check arm discards successful facts between prefixes, including that
discard cost. Each arm observes 136 typed admissions and 136 or 16 actual main
validation calls. Complete state, root and receipts are compared with fresh full
M06 outside the timers. Parent SQL reads, Config snapshot, pool persistence,
lock waiting, work proofs, transport and physical isolation are outside its scope.
These results cannot be represented as historical-binary or endpoint speedup.

`trnm-pon-node/tests/local_mempool.rs` exercises actual Node/M05/M06/SQLite behavior:
queued funding across groups and sequential sender nonces, exact restart and policy
mismatch, real signed fee/profile/expiry/conflict rejection, row/byte limits, failed
source control bundle without partial admission, intact two-control batch and actual
block execution, mutable-batch binding rejection, stale read-only snapshot, actual
heavier-fork raw restoration, per-raw removal monotonicity/regrouping rejection, finite
archives/removal history, admission-triggered terminal-cache eviction and its rollback,
partly terminal protection, real second-SQLite-row fault rollback and previous DDL shape
rejection. An explicitly invoked ignored selector also executes4500 signed nonce-bearing
raws in563 actual native packets with an eight-record retained pool and one restart;
its logical chain timestamps do not measure sustained wall-clock or public service.
These are scoped tests, not independent public-security or economics acceptance.

The operation-local parent test changes canonical actual KV between separate pool
calls and requires `ROOT` refusal from both reconciliation and new admission without
inserting a group. Restoring the original bytes permits ordinary admission again;
previews and a cold reopen preserve the exact active chain State. This checks that
the shared binding cannot become an authority cache across calls.

An earlier parent-binding baseline/candidate experiment measured36 successful
submit operations in
18 pairs, with three pairs per condition on a shared host. Each condition used
1000 or8000 funded accounts (1008 or8024 actual State keys), and0,4 or12 retained
groups of16 members. All228 complete original-parent State/root/ordered-receipt
comparisons and36 same-packet `FUNDS` refusals with complete SQL rollback passed.
Operation wall medians in milliseconds, baseline to candidate, were respectively
8.310 to7.028,40.933 to38.060 and140.562 to172.387 for1000 accounts;
62.172 to53.432,96.195 to79.488 and294.997 to246.953 for8000 accounts.
The1000-account/12-group condition regressed: two of its three pairs were slower.
The other conditions' median improvements do not establish universal speedup,
statistical significance, tail latency or an endpoint SLA. Timers cover only the
actual submit operation; setup, reference replay and complete closed SQL checks
remain in the whole experiment. Its closed parent receipt SHA-256 is
`33afd7bc7d105fcb14ae972c673080df0136a3911f648b691dd383f20a22c965`.
That earlier experiment does not measure the incremental suffix implementation
and does not replace qualification of the combined source.

The exact raw index optimizes only ready-metadata binding. An explicitly invoked
ignored unit selector compares that component on256 ordinary signed transfer raws
and reports32 elapsed samples for the previous scan and the bounded index. Signature
validity is checked before those timers. It excludes whole M05/M06 execution,
reconciliation, proofs, SQLite, owner contention and transport; its measurements
cannot certify endpoint throughput or public fairness.

One reconciliation still admits every growing group prefix through the real M05
queue. With256 single-member groups this revisits32896 admission positions; with16
groups of16 it revisits2176. These are operation counts for fully valid prefixes,
not measured runtime bounds. The16-member cap applies per group, not to the number
of groups. Successful M05 main checks and M06 preparation/application now cover
each retained transaction once within the operation, while M06 mandatory actions
run once and every candidate still receives its complete epilogue, conservation
checks, output State clone and root construction. The finalized block executor is
not called as if each group were another block; the separate prefix boundary above
retains the exact original parent, subsidy and mandatory-action semantics.

Reconciliation reconstructs bounded queues and validates prefixes conservatively;
its work can grow with configured queue size. It is local synchronous work, not a
cheap public resource-protection proof. Continuous mining, wall-clock/task-material
renewal, public transaction RPC, operator custody and WAN/service qualification require
their own exact owner integration and observations. No automatic source re-signature,
legacy/random mining fallback, transaction execution outside the chain, ML value or
hard-work acceptance is introduced by these queued facts.
