import datetime,hashlib,json,os,pathlib,re,subprocess,sys,time,traceback
R=pathlib.Path('/home/qq/chain-system-security-20261112-306929')
HEAD='bac6b7659bd7e2d633e25c2da0add60f6a10c7fb'
TREE='371c3f55de7940e276496efe2008b537ba4d8268'
BASE=pathlib.Path('/home/qq/chain-system-security-native-receipts-20261112-306929')
PREV=BASE/'root-native-bac6b765'
O=BASE/'root-continuation-v4-full-bac6b765'
P=pathlib.Path('/home/qq/chain-system-security-root-provider-20261112-306929')
O.mkdir(parents=True,exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,value):
 with (O/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git','-C',str(R),*args],text=True).strip()
try:
 previous=json.loads((PREV/'summary.json').read_text())
 configuration=json.loads((PREV/'configuration.json').read_text())
 assert previous['source']==HEAD and previous['source_before_after_equal']
 assert previous['commands'][-1]['label']=='workspace-strict-clippy'
 assert previous['commands'][-1]['actual_status'] in ('command_succeeded','command_failed')
 assert git('rev-parse','HEAD')==HEAD and git('rev-parse','HEAD^{tree}')==TREE
 assert not git('status','--porcelain=v1')
 E=dict(os.environ)
 for key,value in configuration['environment'].items():
  if value is None:assert E.get(key) is None, 'unexpected environment '+key
  else:E[key]=value
 E['PYTHONPATH']=str(R/'scripts/ci')
 assert E['RUSTC']=='/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc'
 assert E['CARGO_TARGET_DIR']==str(R/'trillionnium/target')
 provider_raw=(P/'observations/pq-provider/provider.json').read_bytes()
 assert sha(provider_raw)=='509219f0ebd60c563342a509a9751a98222b44890a28552c8003e751924a9eeb'
 provider=json.loads(provider_raw)
 env_raw=(P/'provider.env').read_bytes()
 assert sha(env_raw)=='6de317bdd1826065aefeae7335a552dfae7b87e421a8f1aa66d32aa31adab2ed'
 for key,value in dict(line.split('=',1) for line in env_raw.decode().splitlines()).items():assert E[key]==value
 def provider_check():
  results=[]
  for row in provider['native_backend_inputs']:
   b=pathlib.Path(row['path']).read_bytes()
   assert len(b)==row['bytes'] and sha(b)==row['sha256']
   results.append({'path':row['path'],'bytes':len(b),'sha256':sha(b)})
  assert len(results)==5
  return results
 before_provider=provider_check()
 helpers={}
 for path,digest in configuration['source_helpers_sha256'].items():
  raw=(R/path).read_bytes()
  assert raw==subprocess.check_output(['git','-C',str(R),'show',HEAD+':'+path])
  assert sha(raw)==digest;helpers[path]=digest
 sys.path.insert(0,str(R/'scripts/ci'))
 from verify_ci_source import verify
 import run_pq_root_continuation_v4 as v4
 assert [len(v4.FLOOR),len(v4.PROVIDER),len(v4.CALLBACK_BUDGET)]==[9,14,6]
 source_before=verify('head',HEAD,root=R);save('source-before.json',source_before)
 save('configuration.json',{'source':HEAD,'tree':TREE,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_runner':'scripts/ci/run_pq_root_continuation_v4.py','source_helpers_sha256':helpers,'original_timeout_seconds_per_target':1200,'expected_names':{'recovery-floor':list(v4.FLOOR),'provider-readback':list(v4.PROVIDER),'callback-budget':list(v4.CALLBACK_BUDGET)},'native_method_count':29,'overlaps_prior_scoped_provider_methods':14,'total_unique_v5_and_full_v4_methods':66,'prior_observation_directory':str(PREV),'provider_before':before_provider,'environment':{k:E.get(k) for k in configuration['environment']},'original_profiles_features_and_budgets_modified':False,'status':'HOLD','production_activation':False})
 command=['python3','scripts/ci/run_pq_root_continuation_v4.py','--out',str(O/'v4-continuation')]
 argv=['python3','scripts/ci/record_pq_native_command.py','--kind','head','--candidate',HEAD,'--tested',HEAD,'--label','root-continuation-v4-full','--output',str(O/'records'),'--',*command]
 start=time.monotonic()
 with (O/'root-continuation-v4-full.driver.log').open('xb') as f:p=subprocess.run(argv,cwd=R,env=E,stdout=f,stderr=subprocess.STDOUT)
 receipt=json.loads((O/'records/root-continuation-v4-full.json').read_text())
 original=json.loads((O/'v4-continuation/summary.json').read_text())
 assert original['source']==HEAD and len(original['commands'])==3
 expected=[('recovery-floor',9),('provider-readback',14),('callback-budget',6)]
 complete=p.returncode==0 and original.get('component_execution_passed') and receipt['status']=='command_succeeded'
 for row,(name,count) in zip(original['commands'],expected):
  assert row['name']==name
  observation=row.get('observation')
  complete=bool(complete and row['exit_code']==0 and observation and observation['passed']==count and observation['filtered_out']==0 and row['error'] is None)
 source_after=verify('head',HEAD,root=R);save('source-after.json',source_after);assert source_before==source_after
 after_provider=provider_check();save('provider-after.json',after_provider);assert before_provider==after_provider
 binaries={}
 for log in sorted((O/'v4-continuation').glob('*.log')):
  for value in re.findall(r'Running [^\n]*\(([^()\n]+)\)',log.read_text(errors='replace')):
   path=pathlib.Path(value)
   if not path.is_absolute():path=R/path
   if path.is_file():
    b=path.read_bytes()
    if b[:4]==b'\x7fELF':binaries[str(path)]={'bytes':len(b),'sha256':sha(b),'recorded_after_execution_without_live_inode_pin':True}
 save('native-binaries-after.json',binaries)
 report={'schema':'trnm-root-full-v4-supplement-result-v1','source':HEAD,'tree':TREE,'recorder_argv':argv,'recorder_exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'original_runner_report':original,'all_29_methods_verified':bool(complete),'prior_v5_37_verified':previous['v5_complete_inventory_passed'],'all_66_unique_methods_verified':bool(complete and previous['v5_complete_inventory_passed']),'prior_scoped_14_overlap_not_added':14,'prior_workspace_strict_clippy_passed':previous['workspace_all_targets_all_features_strict_clippy_passed'],'source_before_after_equal':source_before==source_after,'provider_before_after_equal':before_provider==after_provider,'status':'HOLD','production_activation':False,'independent_custody_verified':False,'actual_external_effects_verified':False,'native_m15_production_integration_complete':False}
 save('summary.json',report);print(json.dumps(report),flush=True)
 raise SystemExit(0 if complete else 1)
except BaseException as e:
 if not isinstance(e,SystemExit) or e.code:
  save('launcher-terminal-failure.json',{'source':HEAD,'error_type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),'status':'HOLD'})
 raise
