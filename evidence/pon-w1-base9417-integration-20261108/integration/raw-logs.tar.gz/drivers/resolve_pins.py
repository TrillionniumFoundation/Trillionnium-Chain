#!/usr/bin/env python3
"""Resolve only the fixed C8 exact-blob conflicts and append the sole plan."""
from pathlib import Path
import hashlib,json,re,subprocess

REPO=Path('/home/qian-qi/work/chain-w1-base9417-integration-20261108-ec265b')
OUT=Path('/home/qian-qi/work/chain-w1-base9417-adversarial-integration-20261108-ec265b-01/resolution-01')
C7='40a3a45d6b8afc5c4706c5235fec47634f4aabbe'
BASE='9417e495165865ef6c1288b39084856e31020634'
WORKFLOW='.github/workflows/pon-recent-batch-acceptance.yml'
CORPUS='config/pon/pq-cross-branch-corpus-v1.json'
STORE='trillionnium/crates/trnm-pon-node/src/store.rs'
INVENTORY='trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs'
PLAN='docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
OUT.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def dump(x):return (json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def write(p,b):
    with p.open('xb') as f:f.write(b)
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def snap(ref,path):return git('show',ref+':'+path)
p=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=REPO,capture_output=True)
write(OUT/'preflight.stdout',p.stdout);write(OUT/'preflight.stderr',p.stderr)
assert p.returncode==0
assert git('rev-parse','HEAD').decode().strip()==C7
assert git('rev-parse','MERGE_HEAD').decode().strip()==BASE
assert set(git('diff','--name-only','--diff-filter=U').decode().splitlines())=={WORKFLOW,CORPUS}
ancestor=git('merge-base',C7,BASE).decode().strip()
ours=json.loads(snap(C7,CORPUS));theirs=json.loads(snap(BASE,CORPUS));old=json.loads(snap(ancestor,CORPUS))
store_bytes=(REPO/STORE).read_bytes();store_blob=blob(store_bytes)
workflow_before=(REPO/WORKFLOW).read_bytes();corpus_before=(REPO/CORPUS).read_bytes()
write(OUT/'workflow-conflict.original',workflow_before);write(OUT/'corpus-conflict.original',corpus_before)
wf_ours=snap(C7,WORKFLOW)
old_store=ours['pinned_blobs'][STORE]
assert wf_ours.count(('= '+old_store).encode())==1
wf_final=wf_ours.replace(('= '+old_store).encode(),('= '+store_blob).encode())
conflicts=re.findall(rb'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> '+BASE.encode()+rb'\n',workflow_before,re.S)
assert len(conflicts)==1 and old_store.encode() in conflicts[0][0]
wf_resolved=re.sub(rb'<<<<<<< HEAD\n.*?=======\n.*?>>>>>>> '+BASE.encode()+rb'\n',
    lambda _:b'          test "$(git hash-object '+STORE.encode()+b')" = '+store_blob.encode()+b'\n',workflow_before,flags=re.S)
assert wf_resolved==wf_final
workflow_blob=blob(wf_final)
blocks=re.findall(rb'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> '+BASE.encode()+rb'\n',corpus_before,re.S)
assert len(blocks)==2
def choose(match):
    a,b=match.group(1),match.group(2)
    if WORKFLOW.encode() in a:
        assert b'.github/workflows/pon-w1-transparent-profile.yml' in a
        assert a.count(ours['pinned_blobs'][WORKFLOW].encode())==1
        return a.replace(ours['pinned_blobs'][WORKFLOW].encode(),workflow_blob.encode())
    assert STORE.encode() in a
    return a.replace(ours['pinned_blobs'][STORE].encode(),store_blob.encode())
corpus_final=re.sub(rb'<<<<<<< HEAD\n(.*?)=======\n(.*?)>>>>>>> '+BASE.encode()+rb'\n',choose,corpus_before,flags=re.S)
assert b'<<<<<<<' not in corpus_final and b'>>>>>>>' not in corpus_final
m=json.loads(corpus_final)
keys=set(ours['pinned_blobs'])|set(theirs['pinned_blobs'])
assert set(m['pinned_blobs'])==keys
required=set(ours['required_paths'])|set(theirs['required_paths'])
assert set(m['required_paths'])==required and len(m['required_paths'])==len(required)
for parent in (ours,theirs):
    assert [x for x in m['required_paths'] if x in parent['required_paths']]==parent['required_paths']
assert {k:v for k,v in m.items() if k not in ('pinned_blobs','required_paths')}=={k:v for k,v in ours.items() if k not in ('pinned_blobs','required_paths')}
expected={}
overlapping_conflicts=[]
for key in keys:
    a=ours['pinned_blobs'].get(key);b=theirs['pinned_blobs'].get(key);o=old['pinned_blobs'].get(key)
    if a==b:expected[key]=a
    elif a==o:expected[key]=b
    elif b==o:expected[key]=a
    else:
        assert key in (STORE,WORKFLOW),key
        overlapping_conflicts.append(key)
        expected[key]=store_blob if key==STORE else workflow_blob
assert m['pinned_blobs']==expected
assert m['pinned_blobs'][INVENTORY]==blob((REPO/INVENTORY).read_bytes())=='c4fd4e40d80c2a2d0387c23432c56c57ca3fe135'
assert (REPO/INVENTORY).read_bytes()==snap(C7,INVENTORY)
for key in ['trillionnium/crates/trnm-pon-node/src/store/historical_commitment.rs','trillionnium/crates/trnm-pon-node/src/store/historical_commitment_tests.rs','scripts/ci/test_history_stage_diagnostic.py','trillionnium/crates/trnm-pon-node/tests/history_stage_diagnostic.rs']:
    assert (REPO/key).read_bytes()==snap(BASE,key)
    assert m['pinned_blobs'][key]==blob((REPO/key).read_bytes())
for key,pin in m['pinned_blobs'].items():
    actual=wf_final if key==WORKFLOW else (REPO/key).read_bytes()
    assert blob(actual)==pin,('unexpected pin mismatch',key,pin,blob(actual))
plan_before=(REPO/PLAN).read_bytes()
assert plan_before==snap(C7,PLAN)
write(OUT/'plan-tail-before.txt',b'\n'.join(plan_before.splitlines()[-18:])+b'\n')
paragraph='''\n\n2026-11-08 C8 固定 9417 整合候选：C7 `40a3a45d6b8afc5c4706c5235fec47634f4aabbe` 的独立精确资格实际为 69 commands、655 普通 PASS、4 ignored；其昂贵 operation 仅保留 launch-Unknown，未取得 heavy/cold 执行证据，C5/C6 既有真实路径不转记为 C7。本候选从冻结 C7 正常合入固定 `9417e495165865ef6c1288b39084856e31020634`（直接父 `91c1b7da0f0b1f41c088d9ac0b2ee160b550b80c`），理由是实际 prospective 整合在 recent-batch workflow 与 PQ corpus 出现精确 pin 冲突，且上游包含真实生产 historical commitment 的有界 replay-prefix／current-parent 算术保留变化。保留双方 W1/M12 与原缓存边界控制、上游两组既有方法内的新增子例、History source.json 自引用修正及全部必要 pins／required 路径；仅按自动合并后的实际 store.rs、最终 workflow 字节重绑冲突 pin。生成清单为已有路径的 include_bytes 登记，保持原字节并独立 --check；不改 source guard、事件上下文、原 deadline 或接受条件。C8 尚待其最终 commit/tree 的全量精确构建与执行资格以及新 event/base/head/merge tuple；候选检查不继承 C7 PASS，不新增完整 proof、正向付款、完整资源结算或四门资格。冻结仅针对本固定 base，不自动追随以后远端 base 漂移。\n'''
plan_final=plan_before+paragraph.encode()
# Every byte to change is verified above; only the two resolved pins and sole plan are written.
assert (REPO/WORKFLOW).read_bytes()==workflow_before and (REPO/CORPUS).read_bytes()==corpus_before
(REPO/WORKFLOW).write_bytes(wf_final)
(REPO/CORPUS).write_bytes(corpus_final)
(REPO/PLAN).write_bytes(plan_final)
assert (REPO/STORE).read_bytes()==store_bytes
git('add','--',WORKFLOW,CORPUS,PLAN)
assert git('ls-files','-u')==b''
changed={k:{'old':ours['pinned_blobs'].get(k),'new':v} for k,v in m['pinned_blobs'].items() if ours['pinned_blobs'].get(k)!=v}
report={'schema':'TRNM-W1-C8-EXACT-PIN-CONFLICT-RESOLUTION1','parent':C7,'fixed_base':BASE,'merge_base':ancestor,
    'conflicted_paths':[WORKFLOW,CORPUS],'resolved_overlapping_pin_paths':sorted(overlapping_conflicts),
    'store_auto_merge_sha256':sha(store_bytes),'store_auto_merge_blob':store_blob,'store_bytes_modified_by_resolution':False,
    'workflow_sha256':sha(wf_final),'workflow_blob':workflow_blob,'workflow_only_store_pin_rebound':True,
    'corpus_sha256':sha(corpus_final),'pin_count':len(m['pinned_blobs']),'required_count':len(m['required_paths']),
    'old_c7_pin_count':len(ours['pinned_blobs']),'old_c7_required_count':len(ours['required_paths']),
    'pin_changes_from_c7':changed,'added_required_from_c7':sorted(required-set(ours['required_paths'])),
    'both_parent_pin_path_and_required_unions_preserved':True,'both_parent_required_order_preserved':True,
    'other_corpus_fields_unchanged_from_c7':True,'all_resolved_pins_match_actual_bytes':True,
    'inventory_sha256':sha((REPO/INVENTORY).read_bytes()),'inventory_blob':m['pinned_blobs'][INVENTORY],
    'inventory_bytes_changed':False,'plan_before_sha256':sha(plan_before),'plan_after_sha256':sha(plan_final),
    'plan_append_sha256':sha(paragraph.encode()),'source_guards_or_deadlines_changed':False,'tests_executed_by_resolution':0}
write(OUT/'resolution.json',dump(report))
write(OUT/'resolved-full-diff.patch',git('diff','--binary',C7))
write(OUT/'resolved-stat.txt',git('diff','--stat',C7))
print(json.dumps(report),flush=True)
