#!/usr/bin/env python3
"""Package already observed original 285982d7 CI results; never execute CI/tests."""
import hashlib
import io
import json
import re
import tarfile
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
HEAD = '285982d78a4f62a064841cb0f106d18c865e19c5'
TREE = 'ce074eb1857a92c9b47ea317b841777fcfc63c04'
REPO_URL = 'https://github.com/TrillionniumFoundation/Trillionnium-Chain'
API = 'https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain'
OUT = BASE / 'final-evidence-285982d7'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def put(name, raw):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == raw, f'Immutable evidence changed: {path}'
    else:
        path.write_bytes(raw)
    return str(path.relative_to(OUT))


def put_json(name, value):
    return put(name, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode())


polls = [json.loads(path.read_text()) for path in sorted(HERE.glob('poll-[0-9]*.json'))]
latest = polls[-1]
assert latest['source_head'] == HEAD
assert len(latest['summary']) == 5
assert all(row['run_status'] == 'completed' for row in latest['summary']), 'Do not package pending workflows as final'
stamp = latest['observed_at_utc'].replace('-', '').replace(':', '').replace(' ', 'T', 1).replace(' UTC', 'Z')
primary = {}
for poll in polls:
    assert poll['source_head'] == HEAD
    for record in poll['records']:
        if 'data' in record:
            primary[(record['key'], record['kind'])] = {'observed_at_utc': poll['observed_at_utc'], **record}
assert len(primary) == 10
for record in primary.values():
    if record['kind'] == 'run':
        assert record['data']['head_sha'] == HEAD and record['data']['run_attempt'] == 1
status_path = put_json('primary-api/status-and-run-job-records.json', {
    'schema': 'current-original-ci-final-status-v1', 'source_head': HEAD, 'source_tree': TREE,
    'snapshot_utc': latest['observed_at_utc'], 'summary': latest['summary'],
    'primary_records': list(primary.values()),
    'scope': 'Original attempt 1 only. Run/job API calls are non-atomic; every source record keeps its own retrieval UTC. No reruns or cancellations.',
})

summary_names = [
    'campaign-business-readback.json', 'campaign-business-summary.json', 'campaign-budget-readback.json',
    'f0-business-readback.json', 'f0-business-summary.json', 'f0-budget-readback.json',
    'large-cpu-all-matrices-summary.json', 'workspace-original-artifact-summary.json',
    'pq-system-original-artifact-summary.json', 'pq-terminal-counts-4-matrices.json',
    'artifact-rollup-latest.json',
]
summaries = {name: put('summaries/' + name, (HERE / name).read_bytes()) for name in summary_names}
pq = json.loads((HERE / 'pq-terminal-counts-4-matrices.json').read_text())
assert pq['source_head'] == HEAD and pq['source_tree'] == TREE and pq['full_matrix_log_count'] == 4
assert pq['workflow_status'] == 'completed'
job_logs = []
for path in sorted(HERE.glob('job-[0-9]*.log')):
    raw = path.read_bytes()
    job_logs.append({'path': put('job-logs/' + path.name, raw), 'bytes': len(raw), 'sha256': sha(raw)})
assert len(job_logs) == 26, 'Need original terminal logs for all five workflow families'

artifacts = []
host_count = 0
for path in sorted(HERE.glob('artifact-[0-9]*.json')):
    metadata = json.loads(path.read_text())
    assert metadata['workflow_run']['head_sha'] == HEAD
    local = path.with_suffix('.zip')
    raw = local.read_bytes()
    assert metadata['digest'] == 'sha256:' + sha(raw) and metadata['size_in_bytes'] == len(raw)
    aid = metadata['id']
    clean = {key: value for key, value in metadata.items() if key not in ['download_url', 'file_id', 'local_path', 'zip_entries']}
    clean.update({
        'artifact_browser_url': f"{REPO_URL}/actions/runs/{metadata['workflow_run']['id']}/artifacts/{aid}",
        'archive_download_api': f'{API}/actions/artifacts/{aid}/zip',
        'archive_included_in_bundle': False, 'downloaded_bytes_sha256_verified': True,
        'actual_bytes': len(raw), 'actual_sha256': sha(raw),
    })
    entries = []
    with zipfile.ZipFile(local) as archive:
        for info in archive.infolist():
            name = info.filename
            assert not name.startswith('/') and '..' not in Path(name).parts
            if info.is_dir() or info.file_size > 262144:
                continue
            leaf = Path(name).name
            business = metadata['workflow_run']['id'] in [42185197057, 42185197083]
            if business:
                wanted = leaf in {'hardware.json', 'results.json', 'result.json', 'source-before.json', 'source-after.json', 'source-before-campaigns.json', 'inside-before.json', 'inside-after.json', 'outside-before.json', 'outside-after.json', 'child-result.json', 'controller-result.json', 'binary.json', 'prepared.json', 'predeclared.json'} or bool(re.fullmatch(r'run-[123]-(result|source-after|resource-before|resource-after)\.json', leaf)) or ('resource' in leaf and leaf.endswith('.json'))
            else:
                wanted = name.endswith(('.json', '.tsv', '.execution.stderr', '.exit')) or (name.startswith('semantic-controls/') and name.endswith('.log')) or leaf in {'independent-readback.log', 'cell-current-api-readback.log', 'growth-scale.exits.txt', 'registry-check.stderr'} or (metadata['name'].startswith('original-large-state-') and name.endswith('.log'))
            if not wanted:
                continue
            entry = archive.read(name)
            dest = put(f'artifact-reports/{aid}/{name}', entry)
            entries.append({'zip_entry': name, 'bytes': len(entry), 'sha256': sha(entry), 'path': dest})
            if leaf in {'inside-before.json', 'inside-after.json', 'outside-before.json', 'outside-after.json'}:
                observation = json.loads(entry)
                assert observation['limits'] == {'cpu.max': '25000 100000', 'cpu.max.burst': '0', 'memory.max': '2147483648', 'memory.swap.max': '0', 'pids.max': '256'}
                host_count += 1
    clean['extracted_entry_manifest'] = put_json(f'artifact-reports/{aid}/extracted-entry-manifest.json', {
        'artifact_id': aid, 'archive_sha256': sha(raw), 'entries': entries,
        'selection': 'Byte-exact small source/control/resource/result records only. Giant telemetry, raw ZIPs and ELF files are omitted; full original IDs, byte sizes, digests and download API endpoints remain available while retained by GitHub.',
    })
    put_json(f'artifact-reports/{aid}/primary-artifact-metadata.json', clean)
    artifacts.append(clean)
assert host_count == 44
artifact_path = put_json('manifests/artifacts.json', {'source_head': HEAD, 'snapshot_utc': latest['observed_at_utc'], 'artifacts': artifacts})

for name in ['summarize_business_artifact.py', 'summarize_workspace_artifacts.py', 'summarize_pq_system_artifacts.py', 'summarize_terminal_pq_counts.py', 'analyze_finished_artifacts.py', 'build_current_evidence.py']:
    put('readers/' + name, (HERE / name).read_bytes())

campaign = json.loads((HERE / 'campaign-business-summary.json').read_text())
f0 = json.loads((HERE / 'f0-business-summary.json').read_text())
table_rows = '\n'.join(f"| {row['key']} | [{row['run_id']}]({REPO_URL}/actions/runs/{row['run_id']}) | {row['run_conclusion']} |" for row in latest['summary'])
node_rows = '\n'.join(f"| {row['artifact_name']} | {row['final_node_library_result']['passed']} | {row['final_node_library_result']['failed']} | {row['final_node_library_result']['ignored']} |" for row in pq['matrices'])
readme = f'''# Original CI observations for 285982d7

Snapshot: **{latest['observed_at_utc']}**. Candidate `{HEAD}`, tree `{TREE}`. Every run is original attempt 1; no rerun or cancellation is substituted for earlier evidence.

| Workflow | Original run | Terminal conclusion |
| --- | --- | --- |
{table_rows}

The campaign remains failed: all three baseline first confirmations took 21.205759120 / 21.203138983 / 21.305650019 seconds, and each attack phase had zero confirmations. F0 remains failed: **0/6** planned slots met the four-second SLO; its one baseline confirmation arrived after **24.901798841 seconds from the scheduled slot** (24.901311617 seconds from actual start), and ROOT had no confirmation. These are finite native fixture observations, not real-difficulty WAN confirmation times or production TPS.

The original large-state CPU workflow has four successful matrices, four named native controls each, on the explicitly seeded 8,625,548-byte custom-genesis fixture. Workspace has four matrices with actual **80 passed / 0 failed / 0 ignored** selected controls, plus the original four CPU/public-loop controls. Registry selection alone is not counted as execution. Growth remains a finite local observation; its cold recovery costs and false public/throughput qualification flags are preserved in the raw records.

## Actual complete Node-library summaries

| Original artifact | Passed | Failed | Ignored |
| --- | ---: | ---: | ---: |
{node_rows}

The complete harness summary is the last one in each Node log. Three filtered child harness results are not added to it. The 52 native, 14 TLS/ordinary-binary, 13 scope and full-library suites overlap and must not be summed as unique tests. Primitive/SDK observations do not grant whole-chain quantum-security acceptance.

## Budget and provenance

All {host_count} actual before/after inside/outside Host snapshots retain `/sys/fs/cgroup/trnmponpublic.slice`, CPU `25000 100000` (0.25 CPU), CPU burst 0, memory 2,147,483,648 bytes, swap 0 and 256 tasks. Campaign and F0 controller before/after snapshots retain CPU `400000 100000`, memory 17,179,869,184 bytes and nice 10; this separate external-actor/controller allocation does not enlarge the shared public receiver/verifier Host.

Host checkpoint CPU is nested within caller CPU. It must not be added to caller CPU, and a missing telemetry cohort is unknown rather than zero. Similar runner models and equal cgroup limits do not establish a controlled cross-run performance comparison. The F0 hardware record does not include CPU model.

`{status_path}` retains primary run/job API records with individual retrieval UTC timestamps; `{artifact_path}` retains original artifact IDs, full ZIP SHA-256/size and source identity. Small selected archive entries are byte-exact, with entry digests. Raw giant telemetry, ZIPs and ELF files are omitted, and remain retrievable from their original artifacts subject to GitHub retention. Every included file is covered by the file manifest; all complete terminal job logs are included.

The old b173 failures, the old 9e50 four-matrix 79/80 and 1169/1/32 failures, and the 1986 conflict-blocked zero-run observation remain separate. The old final evidence archive is `final-evidence-20261106T081354Z.zip`, 5,191,414 bytes, SHA-256 `a109fc9f1941f66e135eba717e61144a6e4ad0aa4cc888ee3d6d4f5e16c06a35`; this later bundle does not overwrite it. No code, source pin, workflow, threshold or branch is changed by these readers.
'''
readme_path = put('README.md', readme.encode())
index_path = put_json('manifests/index.json', {
    'schema': 'current-throughput-evidence-index-v1', 'snapshot_utc': latest['observed_at_utc'],
    'source_head': HEAD, 'source_tree': TREE, 'status_path': status_path,
    'artifact_manifest': artifact_path, 'artifact_count': len(artifacts),
    'job_logs': job_logs, 'summaries': summaries, 'readme': readme_path,
    'fixed_host_snapshot_count': host_count,
})
files = [{'path': str(path.relative_to(OUT)), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
         for path in sorted(OUT.rglob('*')) if path.is_file() and path.name != 'file-hashes.json']
put_json('manifests/file-hashes.json', {'schema': 'evidence-bundle-file-digests-v1', 'files': files})
archive_path = BASE / f'final-evidence-285982d7-{stamp}.zip'
assert not archive_path.exists()
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(OUT.rglob('*')):
        if path.is_file():
            archive.write(path, str(path.relative_to(OUT)))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for record in files:
        raw = archive.read(record['path'])
        assert len(raw) == record['bytes'] and sha(raw) == record['sha256']
    assert all(not archive.read(name).startswith(b'\x7fELF') for name in archive.namelist())
    all_members = [{'path': name, 'bytes': len(archive.read(name)), 'sha256': sha(archive.read(name))}
                   for name in sorted(archive.namelist())]
member_manifest_path = BASE / f'final-evidence-285982d7-{stamp}.members.json'
member_manifest_raw = (json.dumps({
    'schema': 'evidence-carrier-all-member-digests-v1', 'source_head': HEAD,
    'snapshot_utc': latest['observed_at_utc'], 'members': all_members,
}, ensure_ascii=False, indent=2) + '\n').encode()
assert not member_manifest_path.exists()
member_manifest_path.write_bytes(member_manifest_raw)
tar_path = BASE / f'final-evidence-285982d7-{stamp}.tar.xz'
partial_tar = tar_path.with_suffix(tar_path.suffix + '.partial')
assert not tar_path.exists() and not partial_tar.exists()
with tarfile.open(partial_tar, mode='w:xz', format=tarfile.PAX_FORMAT, preset=6) as archive:
    for record in all_members:
        name = record['path']
        assert not name.startswith('/') and '..' not in Path(name).parts
        raw = (OUT / name).read_bytes()
        assert len(raw) == record['bytes'] and sha(raw) == record['sha256']
        info = tarfile.TarInfo(name)
        info.type = tarfile.REGTYPE
        info.size = len(raw)
        info.mode = 0o644
        info.mtime = 0
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        archive.addfile(info, io.BytesIO(raw))
with tarfile.open(partial_tar, mode='r:xz') as archive, zipfile.ZipFile(archive_path) as original:
    members = archive.getmembers()
    assert len(members) == len(all_members)
    assert [member.name for member in members] == [record['path'] for record in all_members]
    assert len({member.name for member in members}) == len(members)
    for member, record in zip(members, all_members):
        assert member.isfile() and not member.issym() and not member.islnk()
        assert not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert member.mode == 0o644 and member.uid == member.gid == member.mtime == 0
        raw = archive.extractfile(member).read()
        assert len(raw) == record['bytes'] and sha(raw) == record['sha256']
        assert raw == original.read(member.name), 'Tar carrier differs from original ZIP member'
partial_tar.rename(tar_path)
receipt = {'schema': 'current-evidence-archive-readback-v1', 'source_head': HEAD,
           'snapshot_utc': latest['observed_at_utc'], 'directory': str(OUT), 'index': index_path,
           'artifact_count': len(artifacts), 'file_count': len(files) + 1,
           'archive': str(archive_path), 'archive_bytes': archive_path.stat().st_size,
           'archive_sha256': sha(archive_path.read_bytes()), 'zip_crc_and_file_hashes_verified': True,
           'solid_tar_xz': str(tar_path), 'solid_tar_xz_bytes': tar_path.stat().st_size,
           'solid_tar_xz_sha256': sha(tar_path.read_bytes()),
           'member_manifest': str(member_manifest_path),
           'member_manifest_sha256': sha(member_manifest_raw),
           'safe_regular_members_only': True, 'tar_and_zip_members_byte_equal': True}
receipt_raw = (json.dumps(receipt, ensure_ascii=False, indent=2) + '\n').encode()
(HERE / f'evidence-bundle-readback-{stamp}.json').write_bytes(receipt_raw)
print(json.dumps(receipt))
