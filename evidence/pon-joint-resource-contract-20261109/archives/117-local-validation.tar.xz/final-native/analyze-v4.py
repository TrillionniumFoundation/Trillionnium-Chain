from pathlib import Path
import hashlib,json
root=Path('/workspace/scratch/pon-joint-58fd59-build')
def observation(path):
 result={'records':0,'semantics_sha256':None};h=hashlib.sha256()
 skip={'timing','total_with_observation_and_verification','total_before_terminal_record'}
 with path.open('rb') as source:
  for line in source:
   row=json.loads(line);row={key:value for key,value in row.items() if key not in skip}
   h.update(json.dumps(row,sort_keys=True,separators=(',',':')).encode()+b'\n');result['records']+=1
 result['semantics_sha256']=h.hexdigest();return result
old=observation(root/'fc5-native/v4-observation/complete.jsonl')
new=observation(root/'final-native/v4-observation/complete.jsonl')
assert old==new,(old,new)
result={'schema':'pon-w1-v4-lint-semantic-readback-v1','before_head':'fc5c44ca91c56e77ca2ffc9943e10f0f777a5937','after_head':'11791e2da79b69322271be2cffe03725165151d1','before':old,'after':new,'timing_fields_excluded':['timing','total_with_observation_and_verification','total_before_terminal_record'],'scope':'all fixed-roster record fields apart from listed timing measurements; comparison does not transfer source, process or resource qualification','cost_lower_bound_proved':False,'production_qualified':False}
(root/'final-native/v4-semantic-preservation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
