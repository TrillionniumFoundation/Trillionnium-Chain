#!/usr/bin/env python3
import hashlib,json,os,pathlib,subprocess,sys,time
tool=pathlib.Path('/home/qian-qi/work/chain-w1-c7-root-tools-20261108-ec265b')
v=pathlib.Path('/home/qian-qi/work/chain-w1-c7-root-validation-20261108-ec265b')
repo=pathlib.Path('/home/qian-qi/work/chain-w1-base96-integration-20261108-ec265b')
head='40a3a45d6b8afc5c4706c5235fec47634f4aabbe'
prep_path=v/'preparation-01/owner-empty-preparation.json';prep=json.loads(prep_path.read_text())
target=pathlib.Path(prep['target']);st=target.stat()
assert st.st_dev==prep['device'] and st.st_ino==prep['inode'] and not list(target.iterdir())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
plan=tool/'owner-plan.json';driver=tool/'qualify_source.py'
assert hashlib.sha256(driver.read_bytes()).hexdigest()=='d3c6953430a8efce70396eac88c891aa91501633013c09d5018f0b00e9fb7d1f'
argv=[sys.executable,str(driver),'--repo',str(repo),'--head',head,'--out',str(v/'exact-owner-01'),'--plan',str(plan),'--target',str(target)]
record={'schema':'TRNM-W1-C7-OWNER-LAUNCH-BINDING1','source_commit':head,'preparation_sha256':hashlib.sha256(prep_path.read_bytes()).hexdigest(),'target':str(target),'device':st.st_dev,'inode':st.st_ino,'observed_entries':0,'empty_checked_before_exec':True,'plan_sha256':hashlib.sha256(plan.read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'argv':argv,'pid':os.getpid(),'cgroup':pathlib.Path('/proc/self/cgroup').read_text(),'monotonic_ns':time.monotonic_ns()}
with (v/'owner-launch-binding.json').open('x') as f:f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True);os.execv(sys.executable,argv)
