#!/usr/bin/env python3
"""Record bounded source/model checks on one clean commit; never qualify PQ."""
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    repo, out = args.repo.resolve(), args.out.resolve()
    if out.is_relative_to(repo) or out.exists():
        raise SystemExit('output must be fresh and outside repository')
    out.mkdir(parents=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    results = []

    def run(name, argv, cwd=None, tests=False):
        destination = out / name
        destination.mkdir()
        start = time.monotonic()
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        timeout = False
        with (destination/'stdout.log').open('wb') as stdout, (destination/'stderr.log').open('wb') as stderr:
            try:
                completed = subprocess.run(argv, cwd=cwd or repo, env=env, stdout=stdout,
                                           stderr=stderr, timeout=900)
                code = completed.returncode
            except subprocess.TimeoutExpired:
                code, timeout = None, True
        stdout = (destination/'stdout.log').read_bytes()
        stderr = (destination/'stderr.log').read_bytes()
        combined = (stdout+stderr).decode('utf-8', 'replace')
        counts = [int(n) for n in re.findall(r'Ran (\d+) tests? in ', combined)] if tests else []
        valid = code == 0 and (not tests or (len(counts) == 1 and counts[0] > 0
                 and re.search(r'\nOK(?: \([^\n]+\))?\s*\Z', combined) is not None))
        receipt = dict(name=name, command=[str(x) for x in argv], cwd=str(cwd or repo),
                       started_utc=started, duration_seconds=round(time.monotonic()-start, 3),
                       exit_code=code, timed_out=timeout, result='PASS' if valid else 'FAILED_OR_BLOCKED',
                       unittest_counts=counts, stdout_sha256=hashlib.sha256(stdout).hexdigest(),
                       stderr_sha256=hashlib.sha256(stderr).hexdigest())
        (destination/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
        print(json.dumps({key:receipt[key] for key in ('name','exit_code','result','unittest_counts')}), flush=True)
        return receipt

    source = [sys.executable, '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
              '--expected-head', args.expected_head]
    for name, command in [('preflight', ['bash', 'scripts/project-preflight.sh']),
                           ('source-before', source)]:
        result = run(name, command)
        results.append(result)
        if result['result'] != 'PASS':
            raise SystemExit('initial source/preflight refused; raw receipt retained')

    checks = [
        ('corpus', 'scripts/ci/check_pq_research_integration.py', False),
        ('corpus-negatives', 'scripts/ci/test_pq_research_integration.py', True),
        ('lifetime', 'scripts/ci/pq_lifetime_budget.py', False),
        ('lifetime-negatives', 'scripts/ci/test_pq_lifetime_budget.py', True),
        ('authority-effects', 'scripts/ci/pq_authority_effect_register.py', False),
        ('authority-effect-negatives', 'scripts/ci/test_pq_authority_effect_register.py', True),
        ('authority-traces', 'scripts/ci/pq_authority_trace.py', False),
        ('authority-trace-negatives', 'scripts/ci/test_pq_authority_trace.py', True),
        ('authority-surface-negatives', 'scripts/ci/test_pq_authority_surface_scan.py', True),
        ('claim-guard', 'scripts/ci/pq_chain_claim_guard.py', False),
        ('claim-guard-negatives', 'scripts/ci/test_pq_chain_claim_guard.py', True),
        ('root-policy', 'formal/pon-nakamoto-v1/test_pq_root_recovery_policy_v1.py', True),
        ('sponge-accounting', 'formal/pon-nakamoto-v1/p3_shared_primitive_qualification/pruned_mmcs/test_sponge_accounting.py', True),
        ('ci-contract', 'scripts/ci/test_ci_contract.py', True),
        ('ci-source-integrity', 'scripts/ci/test_ci_source_integrity.py', True),
        ('project-boundary', 'scripts/ci/test_project_boundary.py', True),
        ('repository-markdown', 'scripts/ci/check_repository.py', False),
        ('repository-negatives', 'scripts/ci/test_repository.py', True),
        ('fri-algebra-replay', 'scripts/ci/test_w1_fri_algebra_replay.py', True),
        ('fri-algebra-independent', 'scripts/ci/test_w1_fri_algebra_review_compare.py', True),
        ('fri-algebra-reader', 'scripts/ci/test_w1_fri_algebra_report_check.py', True),
        ('material-runtime-bridge', 'scripts/test_llm_material_runtime_bridge.py', True),
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        pending = [pool.submit(run, name, [sys.executable, '-B', script], tests=tests)
                   for name, script, tests in checks]
        for task in pending:
            results.append(task.result())
    results.append(run('inventory', [sys.executable, '-B', 'scripts/refresh_distributed_source_inventory.py', '--check']))
    results.append(run('source-after', source))
    same_source = ((out/'source-before/stdout.log').read_bytes()
                   == (out/'source-after/stdout.log').read_bytes())
    summary = dict(schema='trnm-pq-composition-source-campaign-v1', commit=args.expected_head,
                   result='PASS_SOURCE_CHECKS_HOLD' if same_source and all(r['result']=='PASS' for r in results) else 'FAILED_OR_BLOCKED',
                   commands=results, source_receipts_equal=same_source,
                   native_tests_executed=False, whole_chain_pq_qualified=False,
                   production_activation=False, final_use_qualified=False,
                   tests_retried=False)
    (out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='commands'}), flush=True)
    return 0 if summary['result']=='PASS_SOURCE_CHECKS_HOLD' else 1


if __name__ == '__main__':
    raise SystemExit(main())
