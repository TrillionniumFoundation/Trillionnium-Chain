from pathlib import Path
import json,hashlib,shutil,subprocess,sys
out=Path("/tmp/history-checkpoint-r8");rows=[json.loads(x) for x in (out/"candidate-corrected-build/stdout.txt").read_text().splitlines() if x.startswith("{")]
a=next(x for x in rows if x.get("reason")=="compiler-artifact" and x["target"]["name"]=="trnm_pon_node" and x.get("executable"));assert a["features"]==["default"],a["features"]
b=Path("/tmp/target-history-56818e4fba76/history-r8-candidate-corrected-node");shutil.copy2(a["executable"],b)
(out/"candidate-corrected-binary.json").write_text(json.dumps({"base_commit":"189ba3adfd9a22c7cfc1537eab535e9eb7c442df","source_diff_sha256":json.loads((out/"candidate-corrected-build/receipt.json").read_text())["source_diff_sha256"],"path":str(b),"sha256":hashlib.sha256(b.read_bytes()).hexdigest(),"features":a["features"],"profile":a["profile"]},indent=2)+"\n")
groups=[
("candidate-corrected-history-boundaries","ingress::history_import::tests::",180,False),
("candidate-corrected-native-inactive","store::native_authenticated_tests::native_inactive_page_parents_use_checked_material_without_early_activation",90,False),
("candidate-corrected-native-graph","native_node_reader_",60,False),
("candidate-corrected-admission-parent","store::admission_parent_tests::",90,False),
("candidate-corrected-cpu-live","ingress::public_v3::scalar_cpu::tests::",60,False),
("candidate-corrected-cpu-completion","ingress::public_v3::scalar_cpu::completion_tests::",120,False),
("candidate-corrected-cpu-poison","ingress::public_v3::tests::live_cpu_poisoned_request_registry_disables_global_starts_without_deadlock",60,False),
("candidate-corrected-reorg-cancellation","store::reorg_cancellation::tests::",120,False),
("candidate-corrected-reorg-real-depletion","store::reorg_cancellation::tests::actual_full_w1_depletion_terminates_intent_and_admits_an_independent_honest_mutation",120,True),
("candidate-corrected-host-parent","host_kernel_parent::",60,False),
("candidate-corrected-host-required","ingress::tests::public_loopback_history_requires_real_fixed_host_parent",60,False)]
failed=[]
for name,filter_,limit,ignored in groups:
 args=["python3","/tmp/history_checkpoint_r8_runner.py","--timeout",str(limit),name,"--",str(b),filter_,"--nocapture","--test-threads=1"]
 if ignored:args.append("--ignored")
 r=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 receipt=json.loads((out/name/"receipt.json").read_text()) if (out/name/"receipt.json").exists() else {}
 print(json.dumps({"name":name,"wrapper_rc":r.returncode,"elapsed_seconds":receipt.get("elapsed_seconds"),"harness_results":receipt.get("harness_results"),"stderr":r.stderr[-1000:]}),flush=True)
 if r.returncode:failed.append(name)
(out/"candidate-corrected-controls-index.json").write_text(json.dumps({"groups":len(groups),"failed":failed},indent=2)+"\n")
sys.exit(bool(failed))
