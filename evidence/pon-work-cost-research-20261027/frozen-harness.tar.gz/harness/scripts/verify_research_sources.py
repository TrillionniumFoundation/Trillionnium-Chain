#!/usr/bin/env python3
"""Verify exact public Git blob identities before accepting local evidence."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def verify(root=ROOT):
    manifest=json.loads((root/'source-manifest.json').read_text());checks=[]
    prefix='trillionnium/crates/trnm-crypto-primitives/src/'
    for item in manifest['files']:
        path=root/'upstream'/item['path']
        if blob(path.read_bytes())!=item['sha']:raise ValueError('SOURCE_MISMATCH '+item['path'])
        checks.append(str(path.relative_to(root)))
        if item['path'].startswith(prefix):
            compiled=root/'src'/item['path'].removeprefix(prefix)
            if blob(compiled.read_bytes())!=item['sha']:raise ValueError('COMPILED_SOURCE_MISMATCH '+str(compiled))
            checks.append(str(compiled.relative_to(root)))
    third=json.loads((root/'vendor/hex/SOURCE.json').read_text())
    for item in third['files']:
        path=root/'vendor/hex'/item['path']
        if blob(path.read_bytes())!=item['sha']:raise ValueError('HEX_SOURCE_MISMATCH '+str(path))
        checks.append(str(path.relative_to(root)))
    parallel=json.loads((root/'parallel-source-manifest.json').read_text())
    for item in parallel['files']:
        path=root/'upstream-parallel'/item['path']
        if blob(path.read_bytes())!=item['sha']:raise ValueError('PARALLEL_SOURCE_MISMATCH '+str(path))
        checks.append(str(path.relative_to(root)))
    return dict(result='PASS',source_commit=manifest['source_commit'],checked_files=len(checks),checks=checks,scope='copied W1 module graph plus Python oracle/config, not full workspace')
if __name__=='__main__':print(json.dumps(verify(),indent=2))
