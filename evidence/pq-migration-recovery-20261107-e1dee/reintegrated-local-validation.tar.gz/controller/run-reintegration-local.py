import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/e1dee205f3d3/chain')
VALIDATION = ROOT.parent / 'validation'
SOURCE = '2c51e15e5b4f57b133b53cc9c386431e29563db5'
TREE = '3f62762d719765b920cb7c7f1c1621440f98818e'
TIME = Path('/workspace/scratch/13c7239fbcac/tools/gnu-time')
TOOLCHAIN = '/workspace/scratch/d5a18aa06915/toolchains/rust-1.95.0/bin'

parser = argparse.ArgumentParser()
parser.add_argument('group', choices=['source', 'ci'])
args = parser.parse_args()
output = VALIDATION / ('reintegrated-' + args.group + '-2c51e15')
output.mkdir(exist_ok=False)
env = dict(os.environ)
env['PATH'] = TOOLCHAIN + ':' + env['PATH']
env['CARGO_HOME'] = '/workspace/scratch/e1dee205f3d3/cargo-home'
env['PYTHONDONTWRITEBYTECODE'] = '1'

if args.group == 'source':
    env['RUSTC'] = TOOLCHAIN + '/rustc'
    commands = [('preflight', ['bash', 'scripts/project-preflight.sh'])]
    old = json.loads((VALIDATION / 'source-controls-9fb011c/summary.json').read_text())
    commands += [(item['label'], item['command']) for item in old]
else:
    env.pop('RUSTC', None)
    assert hashlib.sha256(TIME.read_bytes()).hexdigest() == '3b11dec50514a8473e9f6efa7a34d584d0657538c09988f61b72d38ad4991a10'
    commands = []
    for label in ['preflight', 'public-readiness', 'rust-shards', 'ci-execution', 'ci-contract-tests', 'ci-contract']:
        old = json.loads((VALIDATION / 'integrated-ci-9fb011c' / (label + '.json')).read_text())
        commands.append((label, old['argv']))

summary = []
for label, command in commands:
    cmd = ['python3', 'scripts/ci/record_pq_native_command.py', '--kind', 'head', '--candidate', SOURCE,
           '--tested', SOURCE, '--label', label, '--output', str(output), '--'] + command
    with (output / (label + '-recorder.log')).open('wb') as log:
        result = subprocess.run(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt_path = output / (label + '.json')
    receipt = json.loads(receipt_path.read_text()) if receipt_path.exists() else None
    item = {'label': label, 'argv': command, 'recorder_exit': result.returncode,
            'exit_code': receipt['exit_code'] if receipt else None}
    summary.append(item)
    (output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(item), flush=True)
    if result.returncode != 0 or receipt is None or receipt['exit_code'] != 0:
        raise SystemExit(result.returncode or 1)
    assert receipt['before'] == receipt['after']
    assert receipt['before']['tested_commit'] == SOURCE
    assert receipt['before']['tested_tree'] == TREE
    content = (output / receipt['log_file']).read_bytes()
    assert len(content) == receipt['log_bytes']
    assert hashlib.sha256(content).hexdigest() == receipt['log_sha256']
print(json.dumps({'group': args.group, 'all_commands_passed': True, 'receipts_and_logs_verified': True}), flush=True)
