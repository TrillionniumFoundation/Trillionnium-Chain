"""One real candidate-only Cell transfer over controlled loopback, no install."""
from pathlib import Path
import hashlib
import json
import os
import selectors
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/3d4ec372c488/hepta-chain')
RUN = ROOT.parent / 'hepta-v4-run-002'
OUT = ROOT.parent / 'hepta-v4-cell-002'
MATERIALS = Path('/workspace/scratch/301262829a43/pon-hepta-impl/materials-legacy-i09')
BINARY = Path('/workspace/scratch/301262829a43/pon-work-impl/artifacts/trnm-cell-provider-fixed-57fbdfe')
sys.path.insert(0, str(ROOT / 'scripts'))
import llm_inherited_runtime as inherited
import llm_runtime_pilot as runtime

os.environ.update(PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', HF_HUB_OFFLINE='1',
                  TRANSFORMERS_OFFLINE='1', OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2')
SOURCE = 'c86cabce381ff24f0e002693eb46d9b7a49e1690'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
assert runtime.file_sha(BINARY) == 'e9b71c605cb15f37dc6522a19fffc428f455381122b76ba051c4e7d3ba3b2bb1'
parent = runtime.read_json(RUN / 'candidate-parent.json')
contract, _, _ = inherited.read_parent(parent)
runtime.verify_materials(MATERIALS)
OUT.mkdir(mode=0o700)
stage = OUT / 'consumer-parent'
stage.mkdir(mode=0o700)
summary = dict(schema='controlled-candidate-cell-byte-readback-v1', outcome='running',
    source=SOURCE, caller_sha256=runtime.file_sha(__file__), binary_sha256=runtime.file_sha(BINARY),
    candidate=parent, material_snapshot=runtime.file_sha(MATERIALS / 'material-manifest.json'),
    preexisting_backbone_reused=True, source_backbone_transferred=False,
    independent_nodes=False, ordinary_installation=False, selected=False,
    product_qualification=False, public_reward=False, phases=[], members=[])
server = None
server_prefix = ''
begin = time.monotonic_ns()
limits = ['--cache-max-bytes', str(4*1024**2), '--cache-max-chunks', '16',
          '--cache-max-manifests', '16', '--cache-max-db-bytes', str(16*1024**2)]
family = runtime.read_json(ROOT / 'config/pon/model-family-smollm2-135m-v1.json')
context = ['--family', family['id'], '--base', contract['backbone']['index_root'],
           '--parent', parent['file_sha256'], '--tokenizer', contract['tokenizer']['files_root'],
           '--layout', parent['contract'], '--runtime', runtime.file_sha(ROOT / 'scripts/llm_neural_read_worker.py')]


def command(name, args, timeout=120):
    start = time.monotonic_ns()
    with (OUT / (name + '.stdout')).open('xb') as stdout, (OUT / (name + '.stderr')).open('xb') as stderr:
        result = subprocess.run([str(v) for v in args], stdout=stdout, stderr=stderr, timeout=timeout)
    summary['phases'].append(dict(name=name, command=[str(v) for v in args],
        exit_code=result.returncode, wall_ns=time.monotonic_ns()-start))
    runtime.save(OUT / 'result.json', summary)
    result.check_returncode()
    return json.loads((OUT / (name + '.stdout')).read_bytes())


try:
    for i, name in enumerate(('target-contract.json', 'wrapped-adapter.json', 'artifact.safetensors')):
        source = Path(parent['directory']) / name
        packed = command('pack-' + str(i), [BINARY, 'pack', *limits, '--store', OUT / 'producer.sqlite',
            '--input', source, *context])
        assert packed['payload_sha256'] == runtime.file_sha(source)
        summary['members'].append(dict(name=name, source_sha256=runtime.file_sha(source), pack=packed))
    total = sum(m['pack']['bytes'] for m in summary['members'])
    chunks = sum(m['pack']['chunks'] for m in summary['members'])
    release = command('prepare', [BINARY, 'prepare-release', *limits, '--store', OUT / 'producer.sqlite',
        '--manifests', ','.join(m['pack']['manifest'] for m in summary['members']),
        '--output', OUT / 'source-release.tcr1', '--max-bytes', str(total), '--max-chunks', str(chunks),
        '--overall-ms', '120000'])
    assert release['cells'] == 3 and release['payload_bytes'] == total
    connections = 2 * (chunks + 3)
    response = 2 * total + 3 * 1048576 + 9 * connections
    stderr = (OUT / 'provider.stderr').open('x')
    argv = [str(BINARY), 'serve', '--store', str(OUT / 'producer.sqlite'), '--bind', '127.0.0.1:0',
            '--seconds', '45', '--bounded-workers', '2', '--max-connections', str(connections),
            '--max-served-bytes', str(response)]
    runtime.save(OUT / 'provider-command.json', dict(command=argv, caller_source=summary['caller_sha256']))
    server = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=stderr, text=True)
    with selectors.DefaultSelector() as selector:
        selector.register(server.stdout, selectors.EVENT_READ)
        if not selector.select(5): raise TimeoutError('listener announcement missing')
        server_prefix = server.stdout.readline()
    if not server_prefix:
        server.wait(timeout=2)
        raise RuntimeError('provider exited before listener; see original provider.stderr')
    address = json.loads(server_prefix)['address']
    start = time.monotonic()
    deadline = start + 35
    fetch = command('fetch-release', [BINARY, 'fetch-release', *limits, '--store', OUT / 'consumer.sqlite',
        '--release-file', OUT / 'source-release.tcr1', '--release', release['release'], '--peers', address,
        '--output', OUT / 'consumer-release.tcr1', '--max-bytes', str(total), '--max-chunks', str(chunks),
        '--overall-ms', '35000', '--request-ms', '2000', '--max-response-bytes', str(response),
        '--max-connections', str(connections), '--parallelism', '2'], timeout=37)
    assert fetch['release'] == release['release'] and fetch['cells'] == 3
    assert fetch['downloaded_chunks'] == chunks and fetch['cached_chunks'] == 0
    assert fetch['received_response_bytes'] <= response and fetch['connection_attempts'] <= connections
    assert runtime.file_sha(OUT / 'source-release.tcr1') == runtime.file_sha(OUT / 'consumer-release.tcr1')
    for i, member in enumerate(summary['members']):
        remaining = int((deadline-time.monotonic())*1000)
        assert remaining >= 10
        fetched = command('materialize-' + str(i), [BINARY, 'fetch', *limits,
            '--store', OUT / 'consumer.sqlite', '--manifest', member['pack']['manifest'], '--peers', '',
            '--output', stage / member['name'], '--max-bytes', str(member['pack']['bytes']),
            '--overall-ms', str(remaining), '--request-ms', str(min(2000,remaining)),
            '--parallelism', '1', '--max-connections', '1', '--max-response-bytes', '0'], timeout=remaining/1000+2)
        assert fetched['connection_attempts'] == fetched['downloaded_bytes'] == fetched['received_response_bytes'] == 0
        assert runtime.file_sha(stage / member['name']) == member['source_sha256']
        member['fetch'] = fetched
        member['received_sha256'] = runtime.file_sha(stage / member['name'])
    assert time.monotonic() <= deadline
    summary['transfer'] = dict(elapsed_seconds=time.monotonic()-start, release=release,
        fetch=fetch, exact_members_verified=True, original_seconds=35)
    remainder, _ = server.communicate(timeout=50)
    (OUT / 'provider.stdout').write_text(server_prefix + remainder)
    stderr.close()
    summary['provider_exit_code'] = server.returncode
    assert server.returncode == 0
    fetched_parent = dict(parent, directory=str(stage))
    inherited.read_parent(fetched_parent)
    descriptor = stage / 'parent-material.json'
    runtime.save(descriptor, fetched_parent)
    request = OUT / 'next-request.json'
    runtime.save(request, dict(schema='hepta-smollm-inference-input-v1', request_id='post-v4-cell-001',
        prompt='Answer with only yes or no. Is 103 greater than 102?'))
    command('next-readback', [sys.executable, '-s', '-B', ROOT / 'scripts/llm_inherited_runtime.py', 'infer',
        '--materials', MATERIALS, '--parent', descriptor, '--parent-sha256', runtime.file_sha(descriptor),
        '--input', request, '--input-sha256', runtime.file_sha(request), '--operation-id', 'post-v4-cell-001',
        '--output', OUT / 'next-readback', '--threads', '2', '--steps', '10'], timeout=610)
    actual = runtime.read_json(OUT / 'next-readback/worker/actual-receipt.json')
    terminal = runtime.read_json(OUT / 'next-readback/supervisor.json')
    assert actual['outcome'] == terminal['outcome'] == 'success'
    assert actual['actual_loaded_parent'] == actual['artifact'] == parent['adapter']
    assert actual['forward_executed'] is True and all(v is False for v in actual['authority'].values())
    summary.update(outcome='completed', actual_loaded_candidate=actual['actual_loaded_parent'],
        next_task_response=actual['prediction']['response']['decoded_outputs'],
        next_task_receipt_sha256=runtime.file_sha(OUT / 'next-readback/worker/actual-receipt.json'),
        actual_readback_supervisor=terminal)
except BaseException as error:
    summary.update(outcome='failed', error_type=type(error).__name__, error=str(error))
    raise
finally:
    if server is not None and server.poll() is None:
        server.terminate()
        try: remainder, _ = server.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            server.kill(); remainder, _ = server.communicate()
        (OUT / 'provider.stdout').write_text(server_prefix + remainder)
        summary['provider_cleanup_exit_code'] = server.returncode
    if server is not None:
        summary['provider_terminal_exit_code'] = server.wait(timeout=2)
    summary['wall_ns'] = time.monotonic_ns()-begin
    summary['source_unchanged'] = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == SOURCE
    runtime.save(OUT / 'result.json', summary)
