# Frozen native reader controls — new recording

The original 36 controls were evaluated in two ephemeral tool cells. Their output was visible in the session but was not spooled into separate files. **`recording-01-new` is a new execution and new recording, not a reconstruction of those original raw outputs.**

This run occurred at `2026-11-07T11:08:53Z`, exited `0`, and recorded **36 controls passed, 0 failed**. Two separately labelled observations also passed: a wholly absent phase remains `PENDING`, and the authentic historical `1c14` transcript partitions 1,282 registered tests into 1,249 parent passes and 33 ignored while excluding three child summaries and thirteen additional `running` observations.

The controls only import and exercise the frozen Python reader. Synthetic transcripts, missing files and mutated receipts are supplied in memory. The source reads are Git/read-only file operations. No native/product tests or product entrypoints are executed, and this result does not replace or override the real e36 native phase's failures.

## Retained files

| File | Purpose |
| --- | --- |
| `run_controls.py` | Reusable 36-control script plus two separately reported observations |
| `recording-01-new/controls.stdout.log` | Raw per-control output and final summary |
| `recording-01-new/controls.stderr.log` | Raw stderr; empty in this run |
| `recording-01-new/controls-report.json` | Machine-readable assertions/refusals, input hashes, scope and false qualification flags |
| `recording-01-new/run.json` | Actual argv/cwd/timestamps/exit code, elapsed time and output/script hashes |

Frozen reader SHA-256: `1020381741509dbd1694629bfe6f67bcd3db3c77064804ea6040400e6ec31934`.

Reusable control script SHA-256: `e51eeadd145dbb271f590f88994fd3e65f8110d4223e12dc40381056b27b05f3`.

New report SHA-256: `8b6f07c4ef2de7336226c72b1df56631aab635ee1b950aeedd5882bd86a3ea95`.

## Reproduction

The source checkout must contain the frozen commit recorded by the native `runner.json`; the authentic compiler receipt/log and historical archive must be available. Change paths as needed, and choose a **new** report path. The subject reader must retain the exact frozen SHA-256 above.

```bash
python3 -B run_controls.py \
  --reader /workspace/scratch/a6448796d7e7/read_native_results.py \
  --root /workspace/scratch/a6448796d7e7/chain-pq \
  --native-output /workspace/scratch/a6448796d7e7/validation-e36cfb88/native \
  --historical-archive /workspace/scratch/a6448796d7e7/chain-pq/evidence/pq-m15-native-followthrough-20261107/targeted-and-complete-native.tar.gz \
  --report /absolute/new/control-report.json
```

The report explicitly sets `recording_kind=new_recording_not_original`, `native_or_product_tests_executed=false`, `reader_modified=false`, `repository_modified=false`, and `does_not_override_actual_native_phase_failures=true`. Whole-chain PQ, public WAN and production activation remain false.
