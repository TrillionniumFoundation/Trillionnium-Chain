#!/usr/bin/env python3
"""Derive all 27 ea909 native slots from the retained actual artifact.

No native binary, workflow, timing experiment or external acceptance is run.
"""
from pathlib import Path
from zipfile import ZipFile
import collections
import hashlib
import json

from analyze_f0_9f77 import active_phases, digest, numeric_summary, stage_delta

ROOT = Path(__file__).resolve().parent
ZIP = ROOT / "native-ea909-42329179267/native-campaign-ea909-13557079786.zip"
OUT = ROOT / "native-ea909-42329179267"
SHA = "ea956d9a4ee086a164b905ca1cbbe29f7125dd503fe59c7998f7cddbb3324c17"
HEAD = "ea909124cc460f364bd17b009073306014133f48"
TREE = "96712231eba3d333bdfebefa9c22c80ea1794d04"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    OUT.mkdir(exist_ok=True)
    archive = ZIP.read_bytes()
    assert len(archive) == 69_000_777 and sha(archive) == SHA
    source_path = ROOT / "gate-map-source-9f77f433/trillionnium/crates/trnm-pon-node/tests/public_v3_multiprocess.rs"
    source_metadata = json.loads(source_path.with_name(source_path.name + ".source.json").read_text())
    source = source_path.read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(source)).encode() + b"\0" + source).hexdigest()
    assert blob == source_metadata["blob_sha"]
    assert sha(source) == source_metadata["sha256"]
    current_tree = json.loads((ROOT / "gate-map-ea909/tree-pon-node-new.json").read_text())
    assert not current_tree["truncated"]
    actual_source_blob = next(row["sha"] for row in current_tree["tree"] if row["path"] == "tests/public_v3_multiprocess.rs")
    assert actual_source_blob == blob
    verified = []
    phases = []
    rounds = []
    packets = []
    reports = []
    with ZipFile(ZIP) as z:
        inventory = json.loads(z.read("artifact-files.json"))
        zip_entries = len(z.namelist())
        assert len(set(z.namelist())) == zip_entries
        assert {e["path"] for e in inventory["files"]} == set(z.namelist()) - {"artifact-files.json"}
        assert len(inventory["files"]) == zip_entries - 1
        for entry in inventory["files"]:
            h = hashlib.sha256()
            count = 0
            with z.open(entry["path"]) as f:
                while chunk := f.read(1024 * 1024):
                    count += len(chunk)
                    h.update(chunk)
            assert count == entry["bytes"] and h.hexdigest() == entry["sha256"], entry["path"]
            verified.append(entry)
        result = json.loads(z.read("results.json"))
        assert result["expected_head"] == HEAD and result["expected_tree"] == TREE
        assert result["original_inputs"] == {
            "attacker_processes": [0, 24, 24], "business_blocks": 21,
            "modes": ["baseline", "from-zero", "late-product"],
            "phase_seconds": 30, "seed_blocks": 4, "seed_transfers": 1024,
        }
        assert result["planned_complete_runs"] == 3
        assert result["original_inputs"]["phase_seconds"] == 30
        assert result["public_phase_placement"]["receiver_and_verifier_cpu_max"] == "25000 100000"
        assert result["public_phase_placement"]["receiver_and_verifier_memory_max"] == "2147483648"
        assert result["public_phase_placement"]["original_3x3_workload_and_depletion_predicates_changed"] is False
        assert result["complete_success"] is False
        binary = z.read("public_v3_multiprocess.bin")
        assert len(binary) == result["binary"]["bytes"]
        assert sha(binary) == result["binary"]["sha256_before"] == result["binary"]["sha256_after"]
        source_before = json.loads(z.read("source-before-campaigns.json"))
        source_after = json.loads(z.read("source-after-native.json"))
        assert source_before == source_after
        assert source_before["tested_commit"] == HEAD and source_before["tested_tree"] == TREE
        for run in range(1, 4):
            path = f"run-{run}-raw/report.json"
            raw = z.read(path)
            report = json.loads(raw)
            run_result = json.loads(z.read(f"run-{run}-result.json"))
            readback = json.loads(z.read(f"run-{run}-phase-readback.json"))
            run_source = json.loads(z.read(f"run-{run}-source-after.json"))
            assert run_source == source_before
            assert sha(raw) == run_result["report_sha256"]
            assert run_result["report_validation_failure"] is None
            assert run_result["phase_startup_errors"] == []
            assert run_result["complete_success"] is False
            assert run_result["original_criteria_met"] is False
            reports.append({
                "run": run, "report_entry": path, "report_bytes": len(raw),
                "report_sha256": sha(raw), "result": run_result,
                "readback_entry": f"run-{run}-phase-readback.json",
                "readback_sha256": sha(z.read(f"run-{run}-phase-readback.json")),
                "source_after": run_source,
                "preparation": {key: report["preparation"][key] for key in (
                    "actual_signed_seed_transfers", "business_blocks", "cpu_ns", "seed_blocks",
                    "state_backend", "wall_ns")},
                "best_observed_cold_legal_method": report["best_observed_cold_legal_method"],
                "selection_candidates_cpu_ns": report["selection_candidates_cpu_ns"],
                "finite_experiment_criteria_met": report["finite_experiment_criteria_met"],
            })
            assert len(report["phases"]) == 3
            for phase_ordinal, phase in enumerate(report["phases"]):
                name = phase["mode"]
                assert name == ["baseline", "from-zero", "late-product"][phase_ordinal]
                assert phase["duration_seconds"] == 30
                assert phase["public_resource_policy"]["policy_id"] == result["expected_public_policy_id"]
                retained = readback["phases"][phase_ordinal]
                confirmations = phase["confirmations"]
                count = sum(row["confirmed_inside_pressure_window"] is True for row in confirmations)
                assert retained["mode"] == name
                assert retained["scheduled_confirmation_rounds"] == 3
                assert retained["observed_confirmation_rounds"] == len(confirmations)
                assert retained["confirmed_rounds"] == count
                assert retained["unobserved_scheduled_rounds"] == 3 - len(confirmations)
                for ordinal in range(3):
                    matches = [row for row in confirmations if row["round"] == ordinal]
                    assert len(matches) <= 1
                    row = matches[0] if matches else None
                    confirmed = row is not None and row["confirmed_inside_pressure_window"] is True
                    if confirmed:
                        observation = row["observation"]
                        assert observation["confirmed"] is True and observation["depth"] == 6
                        assert observation["finalized"] is False and observation["execution_authority"] is False
                        assert row["ended_ns"] < 30_000_000_000
                    rounds.append({
                        "run": run, "phase": name, "round": ordinal,
                        "scheduled_offset_ns_from_exact_source": (1 + 4 * ordinal) * 1_000_000_000,
                        "phase_deadline_ns": 30_000_000_000,
                        "actual_started_ns": row["started_ns"] if row else None,
                        "actual_ended_ns": row["ended_ns"] if row else None,
                        "observed": bool(matches), "confirmed_before_original_30s_end": confirmed,
                        "classification": "confirmed_before_phase_end" if confirmed else
                                          "observed_not_confirmed" if row else "unobserved_planned_slot",
                        "original_observation": row,
                        "four_second_slo_applied_to_this_native_gate": False,
                    })
                submissions = phase["submissions"]
                for index in range(21):
                    attempts = [row for row in submissions if row["packet_index"] == index]
                    packets.append({
                        "run": run, "phase": name, "packet_index": index, "round": index // 7,
                        "observed_attempts": len(attempts),
                        "ack_before_phase_end": any(row["status"] == "ok" and row["returned_after_window"] is False for row in attempts),
                        "ack_is_not_confirmation": True,
                        "attempts": [{key: row[key] for key in (
                            "started_ns", "ended_ns", "status", "error", "returned_after_window",
                            "elapsed_wall_ns", "calling_process_cpu_ns", "metrics")} for row in attempts],
                    })

                history = []
                for index, row in enumerate(phase["history"]):
                    ci = row.get("client_import")
                    native = ci["native_import_observation"] if ci else None
                    hs = native["host_checks"] if native else []
                    history.append({
                        "ordinal": index,
                        "network": {key: row[key] for key in (
                            "started_ns", "ended_ns", "elapsed_wall_ns", "calling_process_cpu_ns",
                            "status", "error", "returned_after_window", "request")},
                        "client_import": {key: value for key, value in ci.items()
                                          if key != "native_import_observation"} if ci else None,
                        "client_confirmation": row.get("client_confirmation"),
                        "host_checks": hs,
                        "host_totals_nested": {key: sum(point[key] or 0 for point in hs)
                                               for key in ("calls_started", "calls_completed", "calls_accepted",
                                                           "calls_rejected", "calls_unfinished", "thread_cpu_ns",
                                                           "wall_ns", "cpu_clock_unknown_calls", "wall_clock_unknown_calls")},
                        "native_import_metadata": {key: native[key] for key in (
                            "clock_scope", "host_cpu_includes_each_calling_thread", "host_cpu_is_full_worker_cpu",
                            "phase_cpu_excludes_scoped_workers", "measurement_failures", "schema", "supplied_packets")}
                            if native else None,
                        "active_page_phases": active_phases(native["phases"]) if native else [],
                        "packets": [{"packet_index": packet["packet_index"],
                                     "packet_id": digest(packet["packet_id"]),
                                     "active_phases": active_phases(packet["phases"])}
                                    for packet in native["packets"]] if native else [],
                    })
                current_packets = [row for row in packets if row["run"] == run and row["phase"] == name]
                imports = [row["client_import"] for row in history if row["client_import"] is not None]
                phases.append({
                    "run": run, "phase": name, "planned_confirmations": 3,
                    "observed_confirmation_rounds": len(confirmations), "confirmed_rounds": count,
                    "unobserved_planned_rounds": 3 - len(confirmations),
                    "business_packets": {
                        "planned": 21, "attempts": len(submissions),
                        "with_attempts": sum(row["observed_attempts"] > 0 for row in current_packets),
                        "acks_before_phase_end": sum(row["ack_before_phase_end"] for row in current_packets),
                        "no_attempts": sum(row["observed_attempts"] == 0 for row in current_packets),
                    },
                    "finite_phase_criteria_met": phase["finite_phase_criteria_met"],
                    "verifier_errors": phase["verifier_errors"], "service_outcome": phase["service_outcome"],
                    "initial_tip": phase["initial_tip"], "final_client_tip": phase["final_client_tip"],
                    "final_receiver_tip": phase["final_receiver_tip"],
                    "receiver_client_state_equal": phase["receiver_client_state_equal"],
                    "public_resource_policy": phase["public_resource_policy"],
                    "setup_cpu_ns": phase["receiver_and_verifier_setup_cpu_ns"],
                    "setup_wall_ns": phase["receiver_and_verifier_setup_wall_ns"],
                    "whole_parent_phase_cpu_ns": phase["whole_parent_phase_cpu_ns"],
                    "whole_parent_phase_wall_ns": phase["whole_parent_phase_wall_ns"],
                    "history": history,
                    "history_totals": {
                        "network_calls": len(history), "client_import_entered": len(imports),
                        "client_import_succeeded": sum(row["succeeded"] is True for row in imports),
                        "client_import_errors": [{"error": error, "count": number}
                                                 for error, number in collections.Counter(row["error"] for row in imports).items()],
                        "network_wall_ns": numeric_summary([row["network"]["elapsed_wall_ns"] for row in history]),
                        "client_import_wall_ns": numeric_summary([row["wall_ns"] for row in imports]),
                        "client_import_thread_cpu_ns": numeric_summary([row["thread_cpu_ns"] for row in imports]),
                        "host_nested": {key: sum(row["host_totals_nested"][key] for row in history)
                                        for key in ("calls_started", "calls_completed", "calls_accepted", "calls_rejected",
                                                    "thread_cpu_ns", "wall_ns", "cpu_clock_unknown_calls", "wall_clock_unknown_calls")},
                    },
                    "native_stage_deltas_nested": {
                        who: stage_delta(phase[who + "_before"], phase[who + "_after"])
                        for who in ("client_native_history_arithmetic", "native_history_arithmetic")
                    },
                    "account_graph_span_is_complete_traversal_count": False,
                    "initial_meter": phase["initial_meter"], "final_meter": phase["final_meter"],
                    "final_actual_flow": phase["final_actual_flow"],
                    "genuine_budget_depletion_observed": phase["genuine_budget_depletion_observed"],
                    "phase_process_context": phase["phase_process_context"],
                    "receiver_observer_metadata": {key: value for key, value in phase["receiver_observation"].items()
                                                   if key != "records"},
                })

    assert len(rounds) == 27 and len(packets) == 189 and len(phases) == 9
    observed = sum(row["observed"] for row in rounds)
    confirmed = sum(row["confirmed_before_original_30s_end"] for row in rounds)
    value = {
        "schema": "independent-internal-original-native-campaign-failure-analysis-v1",
        "candidate": HEAD, "tree": TREE, "run_id": 42329179267, "run_attempt": 1, "pr": 756,
        "job_id": 128271490587, "artifact_id": 13557079786,
        "archive": {"path": str(ZIP), "bytes": len(archive), "sha256": sha(archive),
                    "downloaded_by_this_analysis": True, "verified_inventory_files": len(verified),
                    "verified_inventory_bytes": sum(row["bytes"] for row in verified)},
        "source_before_after_same": source_before, "original_campaign_result": result,
        "exact_source_schedule": {"path": str(source_path), "git_blob_sha": blob, "current_ea909_blob_verified": True,
                                  "sha256": sha(source), "schedule_seconds": [1, 5, 9],
                                  "window_seconds": 30, "rounds_per_phase": 3},
        "planned_confirmations": 27, "observed_rounds": observed, "confirmed_before_original_30s_end": confirmed,
        "observed_not_confirmed": observed - confirmed, "unobserved_planned_rounds": 27 - observed,
        "planned_business_packet_exposures": 189,
        "four_second_f0_or_from_zero_gate_replaced": False,
        "reports": reports, "phases": phases, "rounds": rounds, "business_packet_exposures": packets,
        "interpretation_boundaries": [
            "Native campaign confirmation criterion is original 30-second phase window. No F0 four-second criterion is substituted.",
            "All 27 scheduled confirmation slots are retained. Unobserved slots stay failed; transport/read/ACK is not confirmation.",
            "Client import includes complete-page activation; separate ordinary client confirmation is retained where entered.",
            "Host CPU is nested in client phases and sums actual invoking-thread Host intervals; it is not additive to import/thread CPU nor full-worker CPU.",
            "Store account_graph/verify_state counters count observer spans; they do not by themselves prove complete graph traversals. Scoped graph/current-account branches require path-specific evidence.",
            "History network, import and receiver observer timestamps have declared local epochs; durations are not joined by subtracting cross-owner timestamps.",
            "No new native, build, workflow, retry, budget or source mutation was performed by this analysis.",
        ],
        "old_9f_outcomes_inherited": False,
        "external_acceptance": False, "complete_success": False,
    }
    out = OUT / "analysis.json"
    out.write_text(json.dumps(value, indent=2) + "\n")
    manifest = {
        "schema": "retained-ea909-native-archive-verification-v1",
        "archive": value["archive"], "files": verified,
        "zip_entries": zip_entries, "downloaded_again": False,
        "analysis_path": str(out), "analysis_bytes": out.stat().st_size,
        "analysis_sha256": sha(out.read_bytes()),
        "script_sha256": sha(Path(__file__).read_bytes()),
        "helper_script_sha256": sha((ROOT / "analyze_f0_9f77.py").read_bytes()),
    }
    (OUT / "verification-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({key: value for key, value in manifest.items() if key != "files"}, indent=2))
    print(json.dumps([{"run": row["run"], "phase": row["phase"],
                       "observed": row["observed_confirmation_rounds"], "confirmed": row["confirmed_rounds"],
                       "history_calls": row["history_totals"]["network_calls"],
                       "host_calls": row["history_totals"]["host_nested"]["calls_completed"],
                       "import_wall_ns": row["history_totals"]["client_import_wall_ns"]["known_sum"],
                       "import_cpu_ns": row["history_totals"]["client_import_thread_cpu_ns"]["known_sum"],
                       "host_cpu_nested_ns": row["history_totals"]["host_nested"]["thread_cpu_ns"]}
                      for row in phases], indent=2))


if __name__ == "__main__":
    main()
