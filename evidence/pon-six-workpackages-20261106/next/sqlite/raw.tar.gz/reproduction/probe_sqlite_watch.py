import datetime,hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path

phase=sys.argv[1]
assert phase in ('before','after')
root=Path('/workspace/scratch/62902f6722b7/chain-next')
out=Path('/workspace/scratch/62902f6722b7/sqlite-watch')/phase
out.mkdir(parents=True,exist_ok=False)
target=Path('/workspace/scratch/62902f6722b7/sqlite-watch-target')
compiler=os.environ['RUSTC']
assert Path(compiler).is_absolute()
def source():
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'status':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),
 'build_rs_sha256':hashlib.sha256((root/'trillionnium/crates/trnm-sqlite-io-boundary/build.rs').read_bytes()).hexdigest()}
records=[]
for label,rustc in [('relative','rustc'),('absolute',compiler)]:
 env=os.environ.copy();env['RUSTC']=rustc;env['CARGO_TARGET_DIR']=str(target)
 command=['cargo','check','--offline','--locked','--manifest-path','trillionnium/Cargo.toml','-p','trnm-sqlite-io-boundary']
 begin=source();start=time.monotonic();usage0=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(label+'.log')).open('xb') as log:
  completed=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 usage1=resource.getrusage(resource.RUSAGE_CHILDREN)
 outputs=[]
 for p in sorted((target/'debug/build').glob('trnm-sqlite-io-boundary-*/output')):
  data=p.read_bytes();copy=label+'-'+p.parent.name+'-output.txt';(out/copy).write_bytes(data)
  outputs.append({'path':str(p),'copy':copy,'sha256':hashlib.sha256(data).hexdigest(),
   'mtime_ns':p.stat().st_mtime_ns,'rustc_watch':b'cargo:rerun-if-env-changed=RUSTC\n' in data,
   'qualified_cfg':b'cargo:rustc-cfg=trnm_sqlite_layout_witness' in data,
   'unqualified_reason':next((x for x in data.decode().splitlines() if 'UNQUALIFIED:' in x),None)})
 logdata=(out/(label+'.log')).read_bytes()
 row={'phase':phase,'label':label,'command':command,'RUSTC':rustc,'target':str(target),'exit_code':completed.returncode,
  'wall_seconds':time.monotonic()-start,'waited_child_cpu_seconds':usage1.ru_utime+usage1.ru_stime-usage0.ru_utime-usage0.ru_stime,
  'source_before':begin,'source_after':source(),'build_outputs':outputs,
  'log_sha256':hashlib.sha256(logdata).hexdigest(),'log_bytes':len(logdata)}
 records.append(row);(out/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n')
 print(json.dumps(row),flush=True)
(out/'summary.json').write_text(json.dumps({'phase':phase,'commands':records,'new_native_tests_executed':False},indent=2)+'\n')
