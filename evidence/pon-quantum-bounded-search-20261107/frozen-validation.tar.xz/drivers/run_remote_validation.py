#!/usr/bin/env python3
"""Retain actual command outputs on an exactly committed source tree."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(repo, expected):
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
    if head != expected:
        raise ValueError('HEAD_CHANGED')
    tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=repo, text=True).strip()
    entries = subprocess.check_output(['git', 'ls-tree', '-r', '-z', 'HEAD'], cwd=repo).split(b'\0')
    inventory = []
    for entry in entries:
        if not entry:
            continue
        meta, name = entry.split(b'\t', 1)
        mode, kind, expected_blob = meta.decode().split()
        path = repo / name.decode()
        status = path.lstat()
        if kind != 'blob' or mode not in ('100644', '100755', '120000'):
            raise ValueError('UNSUPPORTED_TRACKED_ENTRY:' + str(path))
        if mode == '120000':
            if not stat.S_ISLNK(status.st_mode):
                raise ValueError('SOURCE_TYPE:' + str(path))
            raw = os.readlink(path).encode()
        else:
            if not stat.S_ISREG(status.st_mode) or bool(status.st_mode & 0o111) != (mode == '100755'):
                raise ValueError('SOURCE_MODE:' + str(path))
            raw = path.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw,
                              usedforsecurity=False).hexdigest()
        if actual != expected_blob:
            raise ValueError('SOURCE_BYTES:' + str(path))
        inventory.append((name.decode(), mode, actual, hashlib.sha256(raw).hexdigest()))
    return {'head': head, 'tree': tree, 'tracked_files': len(inventory),
            'inventory_sha256': hashlib.sha256(json.dumps(inventory, separators=(',', ':')).encode()).hexdigest()}


def commands(group, out):
    py = sys.executable
    formal = 'formal/pon-nakamoto-v1'
    if group == 'quantum':
        return [[py, '-B', '-m', 'unittest', 'discover', '-s', formal, '-p', pattern, '-v'] for pattern in
                ('test_quantum*.py', 'test_w1*.py', 'test_reversible_components.py',
                 'test_fast_daa_reference_component.py', 'test_parallel_variable_ohie.py')] + [
                 [py, '-B', '-m', 'unittest', 'discover', '-s', formal + '/experiments',
                  '-p', 'test_w1_bounded_search_campaign.py', '-v']]
    if group == 'repository':
        return [['bash', 'scripts/project-preflight.sh'], *[
            [py, '-B', 'scripts/ci/' + name] for name in
            ('test_ci_source_integrity.py', 'test_ci_contract.py', 'test_pq_research_integration.py',
             'check_pq_research_integration.py', 'check_repository.py')],
            [py, '-B', 'scripts/refresh_distributed_source_inventory.py', '--check'],
            ['git', 'diff', '--check']]
    if group == 'campaign':
        script = formal + '/experiments/w1_bounded_search_campaign.py'
        path = str(out / 'campaign.json')
        return [[py, '-B', script, '--observe', path], [py, '-B', script, '--verify', path]]
    if group == 'rust':
        cargo = 'cargo'
        return [['bash', 'scripts/project-preflight.sh'], [cargo, '--version'], ['rustc', '--version'],
                [os.environ['TRNM_PQ_OPENSSL'], 'version'],
                [cargo, 'metadata', '--offline', '--locked', '--manifest-path', 'trillionnium/Cargo.toml', '--all-features', '--format-version', '1'],
                [cargo, 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check'],
                [cargo, 'clippy', '--offline', '--locked', '--manifest-path', 'trillionnium/Cargo.toml',
                 '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings']]
    raise ValueError(group)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--head', required=True)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--group', choices=('quantum', 'repository', 'campaign', 'rust'), required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    before = source(args.repo, args.head)
    (args.out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    rows = []
    for index, command in enumerate(commands(args.group, args.out)):
        started = datetime.now(timezone.utc).isoformat()
        start = time.monotonic()
        log = args.out / f'{index:02d}.log'
        with log.open('xb') as stream:
            try:
                result = subprocess.run(command, cwd=args.repo, stdout=stream, stderr=subprocess.STDOUT,
                                        timeout=1800 if args.group == 'rust' else 600)
                code, timeout = result.returncode, False
            except subprocess.TimeoutExpired:
                code, timeout = None, True
        row = {'index': index, 'command': command, 'started_utc': started,
               'elapsed_wall_seconds': time.monotonic() - start, 'exit_code': code,
               'timeout': timeout, 'log': log.name, 'sha256': digest(log)}
        rows.append(row)
        (args.out / 'commands.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(json.dumps(row), flush=True)
    after = source(args.repo, args.head)
    (args.out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    if before != after:
        raise ValueError('SOURCE_IDENTITY_CHANGED')
    report = {'group': args.group, 'source': before,
              'status': 'PASS' if all(row['exit_code'] == 0 for row in rows) else 'FAIL',
              'commands': len(rows), 'native_quantum_execution': False,
              'whole_chain_qualified': False, 'production_activation': False}
    (args.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report), flush=True)
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
