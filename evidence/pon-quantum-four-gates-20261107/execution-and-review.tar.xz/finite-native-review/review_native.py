#!/usr/bin/env python3
"""Read-only independent arithmetic and accounting audit of one frozen native run.

This script does not call the finite optimizer, finite verifier, bridge sampler,
or interval probability kernel. It checks supplied full-native census receipts,
packet identity, DAA/work, dense rational amplitudes, graph values and selected
native outcomes. The bridge's separate scalar W1 replay and Rust build/run
receipts remain the authority for full W1/native execution; this is not a new
hardware experiment or a proof of an unbounded network-security statement.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
import json
from math import lcm
from pathlib import Path
import random
import re
import struct
import subprocess
import sys
from datetime import datetime, timezone


def require(value, message):
    if not value:
        raise AssertionError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(canonical(value))


def exact(value):
    require(isinstance(value, dict) and set(value) == {'numerator', 'denominator'}, 'ratio fields')
    require(type(value['numerator']) is int and type(value['denominator']) is int, 'ratio integer types')
    result = Fraction(value['numerator'], value['denominator'])
    require(ratio(result) == value, 'ratio canonical form')
    return result


def ratio(value):
    return {'numerator': value.numerator, 'denominator': value.denominator}


def unique(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, 'duplicate JSON key')
        out[key] = value
    return out


def dense_probabilities(size, marked, count):
    # Relative amplitudes start at 1; divide the squared amplitudes by N.
    amplitudes = [Fraction(1)] * size
    for _ in range(count):
        flipped = [-value if i in marked else value for i, value in enumerate(amplitudes)]
        mean = sum(flipped, Fraction(0)) / size
        amplitudes = [2 * mean - value for value in flipped]
    probabilities = [value * value / size for value in amplitudes]
    require(sum(probabilities) == 1, 'dense state normalization')
    return probabilities


class Audit:
    def __init__(self, repo, directory, expected_head, expected_tree):
        self.repo, self.directory = repo.resolve(), directory.resolve()
        self.expected_head, self.expected_tree = expected_head, expected_tree
        self.inputs = {}
        self.before = self.source_snapshot()
        require(self.before['git_head'] == expected_head and self.before['git_tree'] == expected_tree,
                'local source is not the requested frozen commit/tree')
        require(self.before['worktree_status'] == '', 'local frozen source is dirty')
        self.header_fields = json.loads((repo / 'config/pon/ledger-v1.json').read_text())['header']
        self.fixture = self.read_json('native-fixture.json')
        self.quantum = self.read_json('finite-certificate.json')
        self.classical = self.read_json('classical-certificate.json')
        self.samples = self.read_json('bridge-samples.json')
        self.replay = self.read_json('native-replay.json')
        self.blocks, self.histories, self.contexts = {}, {}, {}
        self.packet_paths = set()

    def source_snapshot(self):
        def git(*args):
            return subprocess.check_output(['git', *args], cwd=self.repo, text=True).strip()
        return {'git_head': git('rev-parse', 'HEAD'), 'git_tree': git('rev-parse', 'HEAD^{tree}'),
                'worktree_status': git('status', '--porcelain=v1', '--untracked-files=all')}

    def read(self, relative):
        path = (self.directory / relative).resolve()
        require(path.is_relative_to(self.directory) and not (self.directory / relative).is_symlink(), 'input path')
        data = path.read_bytes()
        old = self.inputs.setdefault(str(path.relative_to(self.directory)), sha(data))
        require(old == sha(data), 'input changed between reads')
        return data

    def read_json(self, relative):
        return json.loads(self.read(relative), object_pairs_hook=unique)

    def check_source_map(self, mapping):
        for name, expected in mapping.items():
            path = (self.repo / name).resolve()
            require(path.is_relative_to(self.repo) and not (self.repo / name).is_symlink(), 'source path')
            require(sha(path.read_bytes()) == expected, 'source file hash: ' + name)

    def header(self, raw):
        require(len(raw) == 318 and raw[:6] == b'PNH1\x01\x00', 'native header encoding')
        position, result = 6, {}
        for field in self.header_fields:
            size = 32 if field['type'] == 'hash32' else 8
            value = raw[position:position + size]
            result[field['name']] = value.hex() if size == 32 else int.from_bytes(value, 'little')
            position += size
        require(position == len(raw), 'header field inventory')
        return result

    def check_packet(self, row):
        relative = row['packet_file']
        require(re.fullmatch(r'packets/[0-9a-f]{64}\.pnk', relative) is not None, 'packet filename')
        require(relative == 'packets/' + row['block_id'] + '.pnk', 'packet block filename binding')
        raw = self.read(relative)
        self.packet_paths.add(relative)
        require(sha(raw) == row['packet_sha256'], 'packet digest')
        require(len(raw) == 320 + 4 + 3 * 64 * 64 * 4 + 32 and raw[318:320] == b'\0\0', 'native packet shape')
        header, proof = raw[:318], raw[320:]
        require(proof[:4] == b'PNW1' and len(proof) == row['proof_bytes'], 'native proof shape')
        require(sha(proof) == row['proof_sha256'] and proof[-32:].hex() == row['trace'], 'proof digest/trace')
        require(header.hex() == row['header_hex'], 'retained header bytes')
        preimage = b'TRNM-PON1\0' + struct.pack('<H', 5) + b'block'
        preimage += struct.pack('<I', len(header)) + header + struct.pack('<I', 32) + proof[-32:]
        require(sha(preimage) == row['block_id'], 'independent block identity')
        decoded = self.header(header)
        for decoded_key, row_key in [('parent', 'parent_id'), ('height', 'height'), ('timestamp', 'timestamp'),
                                     ('target', 'target_hex'), ('nonce', 'nonce')]:
            require(decoded[decoded_key] == row[row_key], 'packet metadata ' + row_key)
        return decoded

    @staticmethod
    def work(target):
        return (1 << 256) // (target + 1)

    def add_block(self, row):
        identifier, height = row['block_id'], row['height']
        target, chainwork = int(row['target_hex'], 16), int(row['chainwork_hex'], 16)
        if height == 0:
            require(row['parent_id'] is None and chainwork == 0 and target == (1 << 255) - 1, 'genesis premise')
            history = []
        else:
            parent = self.blocks[row['parent_id']]
            history = self.histories[row['parent_id']]
            expected_target = int(parent['target_hex'], 16)
            require(height == parent['height'] + 1, 'parent height')
            if height % 16 == 0:
                desired = 15 * 10
                observed = max(1, parent['timestamp'] - history[15]['timestamp'])
                clamped = min(4 * desired, max((desired + 3) // 4, observed))
                expected_target = min((1 << 255) - 1, max(1, expected_target * clamped // desired))
            require(target == expected_target, 'native required target')
            require(chainwork == int(parent['chainwork_hex'], 16) + self.work(target), 'native chainwork')
            if 'required_work_hex' in row:
                require(int(row['required_work_hex'], 16) == self.work(target), 'required work encoding')
            timestamps = sorted(r['timestamp'] for r in history[:11])
            require(row['timestamp'] > timestamps[len(timestamps) // 2], 'native median time')
            require(row['timestamp'] <= self.fixture['clock_origin_timestamp'] + 120, 'native future time')
        if identifier in self.blocks:
            require(self.blocks[identifier]['header_hex'] == row['header_hex'], 'duplicate block identity differs')
        self.blocks[identifier], self.histories[identifier] = row, [row] + history

    def audit_fixture(self):
        fixture = self.fixture
        require(fixture['schema'] == 'trnm-w1-native-finite-dag-v1', 'fixture schema')
        require(fixture['native_source']['git_head'] == self.expected_head, 'fixture source commit')
        require(fixture['native_source']['worktree_status'] == '', 'native fixture dirty source')
        self.check_source_map(fixture['native_source']['source_sha256'])
        require(self.read_json('native-source-before.json') == fixture['native_source'], 'native export source before/after')
        require(fixture['nonce_bits'] == 3 and fixture['max_private_extensions'] == 2, 'fixed finite domain/depth')
        require((fixture['interval'], fixture['spacing_seconds'], fixture['future_skew_seconds']) == (16, 10, 120), 'native rules')
        require(fixture['fixed_plan'] == {'nonce_bits': 3, 'private_miner': 1,
                'root_timestamp': fixture['genesis_timestamp'] + 16,
                'child_timestamp': fixture['genesis_timestamp'] + 17,
                'sample_seed': 9, 'horizon_seconds': '4', 'max_attempts': 2}, 'fixed plan')
        require(fixture['initial_resources']['coherent_quantum_state_supplied'] is False and
                fixture['initial_resources']['winner_advice_available_to_fixed_policy_sampler'] is False and
                fixture['initial_resources']['observer_has_full_census'] is True, 'initial advice scope')
        for field in ['quantum_hardware_executed', 'quantum_mining_qualified', 'production_activation',
                      'original_service_profile_requalified', 'online_search_sample_executed']:
            require(fixture['claims'][field] is False, 'fixture overclaim: ' + field)
        prefix = fixture['prefix']
        require(len(prefix['packets']) == 15 and len(prefix['parent_first_headers']) == 16, 'prefix inventory')
        for row in reversed(prefix['parent_first_headers']):
            if row['height']:
                self.check_packet(row)
            self.add_block(row)
        require(prefix['tip_id'] == prefix['parent_first_headers'][0]['block_id'], 'prefix tip')
        for row in prefix['packets']:
            require(row['block_id'] in self.blocks, 'prefix packet/header inventory')
            self.check_packet(row)
        self.check_packet(fixture['public_tip'])
        self.add_block(fixture['public_tip'])
        summaries = []
        for context in sorted(fixture['contexts'], key=lambda row: (row['height'], row['context_id'])):
            name = context['context_id']
            require(name not in self.contexts, 'unique context ID')
            self.contexts[name] = context
            rows = context['all_nonce_outcomes']
            require([r['nonce'] for r in rows] == list(range(8)), 'complete nonce inventory')
            winners = [r['nonce'] for r in rows if r['native_winner']]
            require([r['nonce'] for r in context['winner_children']] == winners, 'complete winner children')
            template = self.header(bytes.fromhex(context['template_spec']['header_hex']))
            require(template['parent'] == context['parent_id'] and template['height'] == context['height'], 'template context')
            require(context['template_spec']['shape'] == {'n': 64, 'r': 8, 'field_bits': 32, 'noise_counters': 128}, 'native W1 shape')
            for row in rows:
                self.check_packet(row)
                self.add_block(row)
                require(row['parent_id'] == context['parent_id'], 'nonce parent ID')
                require(row['complete_native_proof_generated'] is True, 'offline full proof generation')
                require(row['native_fixture_admitted'] == row['native_winner'], 'offline admission inventory')
                require(row['native_verifier_error'] == (None if row['native_winner'] else 'Target'), 'native target outcome')
            for child in context['winner_children']:
                require({k: v for k, v in child.items() if k != 'child_context_id'} == rows[child['nonce']], 'winner row binding')
            summaries.append({'context_id': name, 'parent_id': context['parent_id'], 'height': context['height'],
                              'N': 8, 'M_full': len(winners), 'full_accepted_nonces': winners,
                              'target_hex': rows[0]['target_hex'], 'required_work': self.work(int(rows[0]['target_hex'], 16)),
                              'chainwork': int(rows[0]['chainwork_hex'], 16),
                              'offline_native_proofs_generated': 8, 'offline_native_winners_admitted': len(winners)})
        root = self.contexts[fixture['root_context_id']]
        require(root['parent_id'] == prefix['tip_id'] and root['height'] == 16, 'private root')
        child_ids = set()
        for context in self.contexts.values():
            for child in context['winner_children']:
                if context['height'] == 16:
                    require(child['child_context_id'] in self.contexts, 'missing actual-parent child domain')
                    require(self.contexts[child['child_context_id']]['parent_id'] == child['block_id'], 'unique nonce child parent')
                    child_ids.add(child['child_context_id'])
                else:
                    require(context['height'] == 17 and child['child_context_id'] is None, 'finite depth closure')
        require(child_ids | {fixture['root_context_id']} == set(self.contexts), 'DAG context closure')
        controls = fixture['native_negative_controls']
        expected = {'mathematically-valid-wrong-target': 'TARGET', 'mathematically-valid-future-time': 'TIME_DEFERRED',
                    'mathematically-valid-unknown-parent': 'UNKNOWN_PARENT'}
        require({r['name']: r['native_admission_error'] for r in controls['rows']} == expected, 'negative native controls')
        for row in controls['rows']:
            self.check_packet(row)
            require(row['credited_chainwork'] is False, 'rejected work credit')
        require(controls['identical_future_packet_later_admitted'] is True and controls['activation_requested'] is False,
                'future-time control distinction')
        return {'contexts': summaries, 'native_negative_controls': expected,
                'prefix_blocks': 15, 'public_blocks': 1,
                'prefix_chainwork': int(prefix['chainwork_hex'], 16),
                'public_chainwork': int(fixture['public_tip']['chainwork_hex'], 16),
                'prefix_classical_proof_attempts': sum(r['complete_classical_proof_attempts'] for r in prefix['packets']),
                'public_classical_proof_attempts': fixture['public_tip']['complete_classical_proof_attempts'],
                'initial_resources': fixture['initial_resources'],
                'count_scope': 'offline full native census; initial history/census preparation is outside the modeled horizon'}

    def context_for(self, state):
        if not state['private_chain']:
            return self.fixture['root_context_id']
        tip = state['private_chain'][-1]
        return next(child['child_context_id'] for context in self.contexts.values()
                    for child in context['winner_children'] if child['block_id'] == tip)

    def tip_work(self, state):
        identifier = state['private_chain'][-1] if state['private_chain'] else self.fixture['prefix']['tip_id']
        return int(self.blocks[identifier]['chainwork_hex'], 16)

    def choices(self, state, parameters):
        now, horizon = exact(state['time']), Fraction(parameters['horizon_seconds'])
        public_time = Fraction(self.fixture['public_tip']['publication_at_seconds'])
        actions = [{'kind': 'stop'}]
        if state['private_chain']:
            actions.append({'kind': 'publish'})
        if now < public_time <= horizon:
            actions.append({'kind': 'wait-for-public'})
        if now < horizon and state['attempts'] < parameters['max_attempts'] and self.context_for(state) is not None:
            actions += [{'kind': 'search', 'iterations': q} for q in parameters['iterations']]
        return actions

    def fixed_action(self, state, parameters, q):
        choices = self.choices(state, parameters)
        lead = self.tip_work(state) > int(self.fixture['public_tip']['chainwork_hex'], 16)
        if lead and exact(state['time']) >= Fraction(self.fixture['public_tip']['publication_at_seconds']) and {'kind': 'publish'} in choices:
            return {'kind': 'publish'}
        if lead and {'kind': 'wait-for-public'} in choices:
            return {'kind': 'wait-for-public'}
        search = {'kind': 'search', 'iterations': q}
        return search if search in choices else {'kind': 'stop'}

    def declared_search_phases(self, certificate, state, context_id, q):
        parameters = certificate['parameters']
        fixture_index = next(i for i, row in enumerate(self.fixture['contexts']) if row['context_id'] == context_id)
        costs = parameters['classical_costs'][fixture_index]
        setup = int(state['resident_context'] != context_id)
        ns = lambda value: Fraction(value, 10**9)
        if parameters['execution_kind'] == 'classical-uniform-q0':
            return [('classical_task_and_template_setup', ns(setup * (costs['task_preprocessing_ns'] + costs['per_search_setup_ns']))),
                    ('classical_nonce_generation', ns(costs['per_trial_reset_readout_ns'])),
                    ('candidate_check', ns(costs['per_completed_trial_candidate_check_ns']))]
        machine = certificate['machine_envelope']
        model, lifecycle = parameters['physical_model'], parameters['lifecycle_model']
        resource = machine['domain_resources'][certificate['context_order'].index(context_id)]
        envelope = machine['envelope']
        distance = envelope['code_distance_for_whole_schedule']
        peak = envelope['logical_patches_reserved_and_initialized_per_processor']
        ceil_div = lambda value, divisor: (value + divisor - 1) // divisor
        init_batches = ceil_div(peak, lifecycle['initialization_parallel_patches'])
        readout_batches = ceil_div(resource['nonce_bits'], lifecycle['readout_parallel_bits'])
        t_states = resource['prepare_units']['t_states'] + q * resource['iteration_units']['t_states']
        attempts = t_states * lifecycle['factory_attempts_per_state']
        gates = resource['prepare_gate_commands'] + q * resource['iteration_gate_commands']
        controller = gates + attempts + init_batches + readout_batches + int(t_states > 0)
        per_distance = {
            'initialize': init_batches * lifecycle['initialization_cycles_per_distance'],
            'factory_startup': lifecycle['factory_startup_cycles_per_distance'] if t_states else 0,
            'logical_gates': resource['prepare_units']['data_cycles_per_distance'] + q * resource['iteration_units']['data_cycles_per_distance'],
            'factory_attempt_service': attempts * resource['factory_t_cycles_per_distance'],
            'factory_discard_reset': attempts * lifecycle['factory_discard_reset_cycles_per_distance'],
            'terminal_readout': readout_batches * lifecycle['readout_cycles_per_distance'],
        }
        seconds_per_cycle = Fraction(model['cycle_ns']) / 10**9
        timed = {name: cycles * distance * seconds_per_cycle for name, cycles in per_distance.items()}
        timed['controller_waits'] = controller * lifecycle['controller_cycles_per_command'] * seconds_per_cycle
        phases = [('task_preprocessing', ns(costs['task_preprocessing_ns'] * setup)),
                  ('processor_setup', ns(costs['per_search_setup_ns'] * setup)),
                  ('input_transfer', ns(setup * (lifecycle['transfer_fixed_ns'] + resource['controller_input_bytes'] * lifecycle['transfer_ns_per_byte'])))]
        phases += [(name, timed[name]) for name in ['initialize', 'factory_startup', 'logical_gates',
                   'factory_attempt_service', 'factory_discard_reset', 'controller_waits', 'terminal_readout']]
        phases += [('host_readout_turnaround', ns(costs['per_trial_reset_readout_ns'])),
                   ('output_transfer', ns(lifecycle['transfer_fixed_ns'] + resource['nonce_result_bytes'] * lifecycle['transfer_ns_per_byte'])),
                   ('candidate_check', ns(costs['per_completed_trial_candidate_check_ns']))]
        return phases

    def audit_certificate(self, record, execution_kind):
        require(record['schema'] == 'trnm-w1-finite-consensus-certificate-v1' and record['status'] == 'COMPLETE', 'complete certificate')
        require(record['certificate_sha256'] == digest({k: v for k, v in record.items() if k != 'certificate_sha256'}), 'certificate content digest')
        require(record['fixture_sha256'] == digest(self.fixture), 'canonical fixture binding')
        self.check_source_map(record['source_sha256'])
        parameters, nodes = record['parameters'], record['nodes']
        require(parameters['execution_kind'] == execution_kind and parameters['predicate'] == 'full', 'execution class')
        require(parameters['iterations'] == ([0, 1] if execution_kind == 'constructed-quantum' else [0]), 'declared q class')
        require(parameters['horizon_seconds'] == '4' and parameters['max_attempts'] == 2 and parameters['physical_qubit_budget'] == 10**16, 'fixed budget')
        require(record['scope']['whole_machine_error_bound_composed'] is True and record['scope']['physical_clock_calibrated'] is False, 'conditional lifecycle scope')
        for field in ['mixed_quantum_classical_consensus_security_proved', 'attacker_minimum_cost_proved',
                      'quantum_hardware_executed', 'quantum_mining_qualified', 'production_activation']:
            require(record['scope'][field] is False, 'certificate overclaim: ' + field)
        for row in record['literal_domain_summaries']:
            context = self.contexts[row['context_id']]
            require(row['domain_size'] == 8 and row['native_shape'] is True, 'certificate native domain')
            require(row['full_accepted_nonces'] == [r['nonce'] for r in context['all_nonce_outcomes'] if r['native_winner']], 'certificate census binding')
        initial = {'time': ratio(Fraction(0)), 'attempts': 0, 'private_chain': [], 'resident_context': None}
        initial_key, queue, reachable = digest(initial), [digest(initial)], set()
        require(nodes[initial_key]['state'] == initial and len(nodes) == record['state_count'], 'initial graph state')
        total_edges = 0
        for key, node in nodes.items():
            require(key == digest(node['state']), 'state digest')
            state = node['state']
            require([row['action'] for row in node['actions']] == self.choices(state, parameters), 'closed action coverage')
            values = []
            for action_row in node['actions']:
                action, edges = action_row['action'], action_row['edges']
                require(sum((exact(e['probability']) for e in edges), Fraction(0)) == 1, 'transition mass')
                total_edges += len(edges)
                expected = Fraction(0)
                if action['kind'] == 'search':
                    context = self.contexts[self.context_for(state)]
                    marked = {row['nonce'] for row in context['all_nonce_outcomes'] if row['native_winner']}
                    probs = dense_probabilities(8, marked, action['iterations'])
                    available = edges[0]['observation']['nonce_available']
                    if available:
                        require([e['observation']['nonce'] for e in edges] == [i for i, p in enumerate(probs) if p], 'full categorical support')
                    else:
                        require(len(edges) == 1 and exact(edges[0]['probability']) == 1, 'unmeasured branch must remain aggregated')
                for edge in edges:
                    observation = edge['observation']
                    start, finish = exact(state['time']), exact(observation['time'])
                    require(start <= finish <= 4, 'finite phase horizon')
                    if 'phases' in observation:
                        paid_total, partial = Fraction(0), False
                        for phase in observation['phases']:
                            planned, paid = exact(phase['planned']), exact(phase['paid'])
                            require(not partial and 0 <= paid <= planned and phase['complete'] == (paid == planned), 'phase accounting')
                            require(paid == min(planned, Fraction(4) - start - paid_total), 'deadline clipped phase charge')
                            paid_total += paid
                            partial = not phase['complete']
                        require(start + paid_total == finish, 'total phase time')
                    if action['kind'] == 'search':
                        require(observation['context_id'] == context['context_id'] and observation['parent_id'] == context['parent_id'], 'search context parent')
                        planned = self.declared_search_phases(record, state, context['context_id'], action['iterations'])
                        if observation['winner'] is True:
                            fixture_index = next(i for i, row in enumerate(self.fixture['contexts']) if row['context_id'] == context['context_id'])
                            planned += [('proof', Fraction(parameters['classical_costs'][fixture_index]['per_winner_proof_ns'], 10**9))]
                        require([(phase['phase'], exact(phase['planned'])) for phase in observation['phases']] == planned[:len(observation['phases'])], 'independent per-action same-distance lifecycle clock')
                        if len(observation['phases']) < len(planned):
                            require(observation['phases'] and observation['phases'][-1]['complete'] is False, 'search cannot omit an affordable next phase')
                        completed_phases = {phase['phase'] for phase in observation['phases'] if phase['complete']}
                        nonce_phase = 'classical_nonce_generation' if execution_kind == 'classical-uniform-q0' else 'output_transfer'
                        require(observation['nonce_available'] == (nonce_phase in completed_phases), 'nonce delivery stage')
                        require(observation['candidate_check_complete'] == ('candidate_check' in completed_phases), 'candidate check stage')
                        require(observation['proof_complete'] == ('proof' in completed_phases), 'winner proof stage')
                        if observation['nonce_available']:
                            nonce = observation['nonce']
                            require(exact(edge['probability']) == probs[nonce], 'independent dense-vector probability')
                            require(observation['measurement_complete'] == (execution_kind == 'constructed-quantum'), 'classical draw is not measurement')
                            if observation['candidate_check_complete']:
                                require(observation['winner'] == (nonce in marked), 'full native acceptance')
                        else:
                            require(observation['nonce'] is None and observation['winner'] is None and edge['next_state'] is None and edge['terminal_risk'] == 0, 'no pre-readout result')
                        if observation['proof_complete']:
                            winner = context['all_nonce_outcomes'][observation['nonce']]
                            require(winner['native_winner'] and observation['block_id'] == winner['block_id'], 'proof nonce identity')
                            require(observation['private_chain'] == state['private_chain'] + [winner['block_id']], 'private proof chain')
                        elif edge['next_state'] is not None:
                            require(observation['private_chain'] == state['private_chain'], 'miss cannot advance branch')
                        if edge['next_state'] is not None:
                            require(edge['next_state'] == {'time': observation['time'], 'attempts': state['attempts'] + 1,
                                    'private_chain': observation['private_chain'], 'resident_context': context['context_id']}, 'search state/attempt/residency transition')
                    if action['kind'] == 'publish':
                        owner = {child['block_id']: i for i, context_row in enumerate(self.fixture['contexts']) for child in context_row['winner_children']}
                        propagation = sum((Fraction(parameters['classical_costs'][owner[block]]['per_winner_propagation_ns'], 10**9) for block in state['private_chain']), Fraction(0))
                        require(observation['phases'][0]['phase'] == 'serial_bundle_propagation' and exact(observation['phases'][0]['planned']) == propagation, 'complete bundle propagation cost')
                        if len(observation['phases']) == 2:
                            admissible = max(Fraction(max(0, self.blocks[block]['timestamp'] - self.fixture['clock_origin_timestamp'] - 120)) for block in state['private_chain'])
                            require(observation['phases'][1]['phase'] == 'future_admission_wait' and exact(observation['phases'][1]['planned']) == max(Fraction(0), admissible - start - propagation), 'native future deferral clock')
                        legal = observation['publication_complete'] and finish >= Fraction(self.fixture['public_tip']['publication_at_seconds'])
                        lead = self.tip_work(state) > int(self.fixture['public_tip']['chainwork_hex'], 16)
                        require(edge['terminal_risk'] == int(legal and lead), 'strict required-work publication event')
                    if action['kind'] == 'stop':
                        require(len(edges) == 1 and edge['next_state'] is None and edge['terminal_risk'] == 0 and finish == start, 'stop has no work benefit')
                    following = edge['next_state']
                    if following is None:
                        require(edge['terminal_risk'] in (0, 1), 'terminal risk')
                        continuation = Fraction(edge['terminal_risk'])
                    else:
                        require(edge['terminal_risk'] is None, 'nonterminal risk')
                        next_key = digest(following)
                        require(next_key in nodes and nodes[next_key]['state'] == following, 'closed state graph')
                        require(following['attempts'] > state['attempts'] or (following['attempts'] == state['attempts'] and exact(following['time']) > start), 'acyclic rank')
                        continuation = exact(nodes[next_key]['value'])
                    expected += exact(edge['probability']) * continuation
                require(exact(action_row['value']) == expected, 'Bellman action expectation')
                values.append(expected)
            require(exact(node['value']) == max(values), 'Bellman exact maximum')
            require(node['maximizing_action'] == node['actions'][values.index(max(values))]['action'], 'Bellman tie convention')
        while queue:
            key = queue.pop()
            if key in reachable:
                continue
            reachable.add(key)
            for row in nodes[key]['actions']:
                queue += [digest(edge['next_state']) for edge in row['edges'] if edge['next_state'] is not None]
        require(reachable == set(nodes), 'no unreachable or omitted states')
        require(record['risk_upper'] == nodes[initial_key]['value'], 'initial Bellman value')
        fixed = {}
        for q in parameters['iterations']:
            mass, success, stopped = defaultdict(Fraction), Fraction(0), Fraction(0)
            mass[initial_key] = Fraction(1)
            for key in sorted(nodes, key=lambda key: (nodes[key]['state']['attempts'], exact(nodes[key]['state']['time']))):
                state = nodes[key]['state']
                action = self.fixed_action(state, parameters, q)
                row = next(r for r in nodes[key]['actions'] if r['action'] == action)
                for edge in row['edges']:
                    flow = mass[key] * exact(edge['probability'])
                    if edge['next_state'] is None:
                        stopped += flow
                        success += flow * edge['terminal_risk']
                    else:
                        mass[digest(edge['next_state'])] += flow
            require(stopped == 1 and ratio(success) == record['fixed_policy_risks'][str(q)], 'independent fixed-policy mass flow')
            fixed[str(q)] = ratio(success)
        coupling = record['conditional_machine_risk_bounds']
        envelope = record['machine_envelope'] if execution_kind == 'constructed-quantum' else record['classical_host_envelope']
        eps = exact(envelope['envelope']['whole_plan_failure_union_upper'])
        require(eps == sum((exact(v) for v in envelope['envelope']['failure_union_components_upper'].values()), Fraction(0)), 'fault union sum')
        require(eps == exact(coupling['failure_union_upper']), 'fault coupling binding')
        for value, bound in [(exact(record['risk_upper']), coupling['census_advised_action_envelope'])] + [
                (exact(value), coupling['fixed_q_policies'][q]) for q, value in fixed.items()]:
            require(exact(bound['lower']) == max(0, value - eps) and exact(bound['upper']) == min(1, value + eps), 'independent event coupling')
        if execution_kind == 'constructed-quantum':
            require(envelope['record_sha256'] == digest({k: v for k, v in envelope.items() if k != 'record_sha256'}), 'machine record digest')
            expected_schedule = [[i, 1] for i in range(len(self.contexts)) for _ in range(2)]
            require(envelope['premises']['schedule'] == expected_schedule and envelope['premises']['processors'] == 1, 'whole DAG K qmax reservation')
            require(envelope['premises']['reserved_maximum_winners'] == 2, 'K winner reservation')
            require(envelope['envelope']['events_all_processors']['proofs_reserved'] == 2 and envelope['envelope']['events_all_processors']['propagations'] == 2, 'K proof and propagation events')
            hardware = {key: envelope['envelope'][key] for key in ['code_distance_for_whole_schedule', 'logical_patches_reserved_and_initialized_per_processor', 'physical_qubits_all_processors']}
        else:
            require(record['machine_envelope'] is None and record['constructed_binding'] is None, 'classical implementation must not use QPU binder')
            require(envelope['physical_qubits'] == 0 and exact(envelope['quantum_fault_probability']) == 0, 'classical zero QPU')
            d, k = len(self.contexts), 2
            require(envelope['events']['host_calls_including_proofs'] == 2 * d + 2 * d * k + k, 'classical host event reservation')
            lifecycle = parameters['lifecycle_model']
            require(eps == (2 * d + 2 * d * k + k) * Fraction(lifecycle['host_call_failure_bound']) + k * Fraction(lifecycle['propagation_failure_bound']), 'classical conditional event union')
            hardware = {'physical_qubits_all_processors': 0, 'host_events': envelope['events']}
        witness = record['positive_path']
        if exact(record['risk_upper']) == 0:
            require(witness is None, 'zero ideal value has no positive witness')
        else:
            require(witness is not None and witness['sampled_execution'] is False, 'existential witness label')
            product = self.check_trajectory(record, witness['trajectory'])
            require(ratio(product) == witness['probability'] and witness['trajectory'][-1]['edge']['terminal_risk'] == 1, 'positive witness probability')
        return {'execution_kind': execution_kind, 'states': len(nodes), 'transition_edges': total_edges,
                'ideal_census_advised_envelope': record['risk_upper'], 'ideal_fixed_policy_risks': fixed,
                'epsilon': ratio(eps), 'epsilon_decimal_approx': format(float(eps), '.12g'),
                'conditional_risk_intervals': coupling, 'hardware_reservation': hardware,
                'positive_advice_path_present': witness is not None,
                'positive_advice_path_probability': None if witness is None else witness['probability'],
                'scope': record['scope']}

    def check_trajectory(self, certificate, trajectory):
        state = {'time': ratio(Fraction(0)), 'attempts': 0, 'private_chain': [], 'resident_context': None}
        product = Fraction(1)
        for index, step in enumerate(trajectory):
            require(step['state'] == state, 'trajectory state chain')
            row = next(row for row in certificate['nodes'][digest(state)]['actions'] if row['action'] == step['action'])
            require(step['edge'] in row['edges'], 'trajectory edge')
            product *= exact(step['edge']['probability'])
            state = step['edge']['next_state']
            require((state is None) == (index == len(trajectory) - 1), 'terminal trajectory position')
        return product

    def audit_runs(self):
        samples, replay = self.samples, self.replay
        require(samples['schema'] == 'trnm-w1-native-bridge-samples-v1' and replay['schema'] == 'trnm-w1-native-bridge-replay-v1', 'run schemas')
        require(samples['source']['git_head'] == self.expected_head and replay['native_source'] == self.fixture['native_source'], 'sample/replay source identity')
        self.check_source_map(samples['source']['source_sha256'])
        for name, field in [('native-fixture.json', 'fixture_sha256'), ('bridge-samples.json', 'samples_sha256')]:
            require(replay[field] == self.inputs[name], 'native replay raw input binding')
        require(samples['fixture_sha256'] == self.inputs['native-fixture.json'], 'sample raw fixture binding')
        for name, field in [('finite-certificate.json', 'certificate_file_sha256'), ('classical-certificate.json', 'classical_certificate_file_sha256')]:
            require(samples[field] == self.inputs[name], 'sample raw certificate binding')
        require(samples['independently_checked_packet_records'] == 16 + 8 * len(self.contexts), 'scalar packet record count')
        receipt = replay['independent_python_verifier']['receipt']
        require(receipt['status'] == 'VERIFIED' and receipt['source_snapshot'] == samples['source'], 'independent bridge verifier receipt')
        require(receipt['verified_inputs'] == {name: self.inputs[name] for name in ['native-fixture.json', 'finite-certificate.json', 'classical-certificate.json', 'bridge-samples.json']}, 'verifier exact input digest set')
        require(replay['verified_raw_inputs_unchanged_through_native_replay'] is True, 'native TOCTOU result')
        for field in ['quantum_hardware_executed', 'quantum_mining_qualified', 'production_activation',
                      'original_service_profile_requalified', 'real_time_search_budget_verified', 'native_public_ingress_executed']:
            require(replay['claims'][field] is False, 'native replay overclaim: ' + field)
        expected_names = ['fixed-q0-seed9', 'fixed-q1-seed9']
        if self.quantum['positive_path'] is not None:
            expected_names.append('observer-advice-quantum-positive-path')
        expected_names.append('classical-q0-seed9')
        if self.classical['positive_path'] is not None:
            expected_names.append('observer-advice-classical-positive-path')
        require([row['name'] for row in samples['runs']] == expected_names and [row['name'] for row in replay['runs']] == expected_names, 'fixed and advice inventory')
        summaries = []
        for sample, native in zip(samples['runs'], replay['runs']):
            name, raw = sample['name'], sample['raw_observation']
            advice = name.startswith('observer-advice-')
            classical = name in ('classical-q0-seed9', 'observer-advice-classical-positive-path')
            certificate = self.classical if classical else self.quantum
            trajectory = raw['trajectory']
            path_probability = self.check_trajectory(certificate, trajectory)
            require(native['sample_sha256'] == digest(sample), 'native serialized sample binding')
            if advice:
                require(raw == certificate['positive_path'] and raw['sampled_execution'] is False, 'advice witness must remain distinguished')
            else:
                q = 1 if name == 'fixed-q1-seed9' else 0
                require(raw['seed'] == 9 and raw['iterations'] == q and raw['policy_reads_marked_count_or_bellman_values'] is False, 'predeclared fixed policy')
                rng = random.Random(9)
                for step in trajectory:
                    action = self.fixed_action(step['state'], certificate['parameters'], q)
                    require(step['action'] == action, 'fixed observable policy choice')
                    edges = next(row['edges'] for row in certificate['nodes'][digest(step['state'])]['actions'] if row['action'] == action)
                    denominator = lcm(*(exact(e['probability']).denominator for e in edges))
                    draw, cumulative, selected = rng.randrange(denominator), 0, None
                    for edge in edges:
                        cumulative += int(exact(edge['probability']) * denominator)
                        if draw < cumulative:
                            selected = edge
                            break
                    require(selected == step['edge'], 'independent exact seeded trajectory replay')
            checks = [(i, step['edge']['observation']) for i, step in enumerate(trajectory)
                      if step['edge']['observation'].get('candidate_check_complete') is True]
            require(len(native['candidate_probes']) == len(checks) == native['completed_candidate_checks_replayed'], 'all completed checks replayed')
            for (index, observed), probe in zip(checks, native['candidate_probes']):
                row = self.contexts[observed['context_id']]['all_nonce_outcomes'][observed['nonce']]
                require(probe['trajectory_index'] == index and probe['context_id'] == observed['context_id'] and probe['nonce'] == observed['nonce'], 'probe modeled check identity')
                require(probe['parent_id'] == row['parent_id'] and probe['candidate_block_id'] == row['block_id'], 'probe actual nonce parent/block identity')
                require(probe['packet_sha256'] == row['packet_sha256'] and probe['proof_sha256'] == row['proof_sha256'], 'fresh native proof bytes equal retained bytes')
                require(probe['native_winner'] == row['native_winner'] == observed['winner'], 'probe winner/miss agreement')
                require(probe['native_private_producer_admitted'] == observed['proof_complete'] == probe['modeled_proof_complete'], 'private proof completion/admission')
                require(probe['native_receiver_admission_authorized_by_this_probe'] is False and probe['actual_cpu_proof_used_as_quantum_clock_calibration'] is False, 'probe scope')
                for timing in ['actual_prepare_elapsed_ns', 'actual_proof_elapsed_ns', 'actual_candidate_verification_elapsed_ns']:
                    require(type(probe[timing]) is int and probe[timing] >= 0, 'native measured timing')
            terminal = trajectory[-1]['edge']['observation']
            complete_proofs = [observed for _, observed in checks if observed['proof_complete']]
            require(native['private_proofs_held'] == len(complete_proofs), 'private completed proof count')
            require(sample['publication_complete'] == terminal.get('publication_complete', False), 'publication completion')
            require(sample['logical_elapsed_seconds_exact'] == terminal['time'], 'logical elapsed')
            require(sample['native_observed_now'] == self.fixture['clock_origin_timestamp'] + int(exact(terminal['time'])), 'native logical validation clock')
            require(sample['expected_reorganization'] == (trajectory[-1]['edge']['terminal_risk'] == 1) == native['reorganized'], 'native reorganization event')
            submitted = sample['packets_to_submit']
            require(len(native['admissions']) == len(submitted), 'receiver admission count')
            require(not submitted or sample['publication_complete'], 'unpublished block admission')
            parent, active = self.fixture['prefix']['tip_id'], self.fixture['public_tip']['block_id']
            for selected, admitted in zip(submitted, native['admissions']):
                require(selected['parent_id'] == parent and admitted['parent_id'] == parent, 'receiver sequential parent')
                for field in ['context_id', 'nonce', 'block_id']:
                    require(admitted[field] == selected[field], 'receiver selected path')
                require(any(observed['block_id'] == selected['block_id'] for observed in complete_proofs), 'receiver block proved in this modeled path')
                if int(self.blocks[selected['block_id']]['chainwork_hex'], 16) > int(self.blocks[active]['chainwork_hex'], 16):
                    active = selected['block_id']
                require(admitted['selected_tip'] == active and admitted['native_library_admitted'] is True, 'strict-work native selection')
                require(admitted['public_ingress_executed'] is False and admitted['quantum_hardware_executed'] is False, 'receiver library scope')
                parent = selected['block_id']
            require(native['before']['tip'] == self.fixture['public_tip']['block_id'] and native['after']['tip'] == active, 'native tips')
            require(int(native['after']['chainwork_hex'], 16) == int(self.blocks[active]['chainwork_hex'], 16), 'native selected work')
            require(native['authenticated_reopen_equal'] is True and native['real_quantum_machine'] is False, 'native authenticated reopen scope')
            if not submitted:
                require(native['before'] == native['after'], 'empty receiver path is unchanged')
            cpu = {field: sum(probe[field] for probe in native['candidate_probes']) for field in
                   ['actual_prepare_elapsed_ns', 'actual_proof_elapsed_ns', 'actual_candidate_verification_elapsed_ns']}
            first_partial = next((phase for step in trajectory for phase in step['edge']['observation'].get('phases', []) if not phase['complete']), None)
            summaries.append({'name': name, 'observation_kind': sample['observation_kind'], 'advice_selected': advice,
                              'path_probability': ratio(path_probability), 'logical_elapsed_seconds': terminal['time'],
                              'search_attempts': sum(step['action']['kind'] == 'search' for step in trajectory),
                              'quantum_measurements_complete': sum(step['edge']['observation'].get('measurement_complete') is True for step in trajectory),
                              'completed_candidate_checks': len(checks), 'completed_checked_misses': sum(not observed['winner'] for _, observed in checks),
                              'completed_checked_winners': sum(observed['winner'] for _, observed in checks),
                              'modeled_winner_proofs_complete': len(complete_proofs),
                              'fresh_cpu_probe_proofs_generated_including_misses': len(native['candidate_probes']),
                              'private_producer_admissions': sum(probe['native_private_producer_admitted'] for probe in native['candidate_probes']),
                              'publication_complete': sample['publication_complete'], 'receiver_admissions': len(native['admissions']),
                              'reorganized': native['reorganized'], 'authenticated_reopen_equal': native['authenticated_reopen_equal'],
                              'native_before_height': native['before']['height'], 'native_after_height': native['after']['height'],
                              'native_after_chainwork': int(native['after']['chainwork_hex'], 16),
                              'selected_nonces': [{'context_id': observed['context_id'], 'nonce': observed['nonce'], 'parent_id': observed['parent_id'], 'winner': observed['winner']} for _, observed in checks],
                              'cpu_probe_elapsed_ns_sums': cpu,
                              'native_candidate_costs_are_clock_calibration': False,
                              'first_partial_phase': first_partial})
        return summaries

    def finish(self):
        fixture_summary = self.audit_fixture()
        quantum_summary = self.audit_certificate(self.quantum, 'constructed-quantum')
        classical_summary = self.audit_certificate(self.classical, 'classical-uniform-q0')
        require(self.quantum['parameters']['classical_costs'] == self.classical['parameters']['classical_costs'] and
                self.quantum['parameters']['physical_model'] == self.classical['parameters']['physical_model'] and
                self.quantum['parameters']['lifecycle_model'] == self.classical['parameters']['lifecycle_model'], 'separate implementation shared declared premises')
        runs = self.audit_runs()
        root = self.contexts[self.fixture['root_context_id']]
        depth_two_winners = sum(len(self.contexts[child['child_context_id']]['winner_children']) for child in root['winner_children'])
        simple_two_success_probability = Fraction(depth_two_winners, 64)
        # The fixed campaign reserves at most two attempts; two accepted extensions
        # are required to beat the public h16 branch. Explicit host costs fit 4s.
        costs = self.classical['parameters']['classical_costs']
        per_domain = [Fraction(sum(row[k] for k in ['task_preprocessing_ns', 'per_search_setup_ns',
                       'per_trial_reset_readout_ns', 'per_completed_trial_candidate_check_ns',
                       'per_winner_proof_ns', 'per_winner_propagation_ns']), 10**9) for row in costs]
        require(2 * max(per_domain) <= 4, 'hand count two-success path fits classical budget')
        require(simple_two_success_probability == exact(self.classical['risk_upper']) == exact(self.classical['fixed_policy_risks']['0']), 'independent two-level nonce hand count')
        after = self.source_snapshot()
        require(after == self.before, 'local source changed during review')
        for name, expected in self.inputs.items():
            require(sha((self.directory / name).read_bytes()) == expected, 'evidence changed during review')
        counted = ['search_attempts', 'quantum_measurements_complete', 'completed_candidate_checks',
                   'completed_checked_misses', 'completed_checked_winners', 'modeled_winner_proofs_complete',
                   'fresh_cpu_probe_proofs_generated_including_misses', 'private_producer_admissions',
                   'publication_complete', 'receiver_admissions', 'reorganized', 'authenticated_reopen_equal']
        totals = {'runs': len(runs), 'fixed_policy_runs': sum(not row['advice_selected'] for row in runs),
                  'observer_advice_runs': sum(row['advice_selected'] for row in runs),
                  **{key: sum(row[key] for row in runs) for key in counted},
                  'count_scope': 'inventory across separate fresh replay runs; not cumulative trials of one attack or one probability estimate'}
        return {'schema': 'trnm-independent-native-finite-review-v1', 'result': 'PASS',
                'source_before': self.before, 'source_after': after, 'fixture_summary': fixture_summary,
                'quantum_certificate': quantum_summary, 'classical_certificate': classical_summary,
                'classical_independent_two_success_count': {'accepted_depth_two_nonce_pairs': depth_two_winners,
                    'possible_ordered_nonce_pairs': 64, 'probability': ratio(simple_two_success_probability)},
                'runs': runs, 'native_run_inventory_totals': totals, 'unique_packet_files_checked': len(self.packet_paths),
                'input_file_sha256': dict(sorted(self.inputs.items())), 'evidence_unchanged_during_review': True,
                'independence': {'finite_optimizer_called': False, 'finite_verifier_called': False,
                    'bridge_sampler_called': False, 'production_interval_kernel_called': False,
                    'probability_method': 'independent dense rational state vector',
                    'value_method': 'raw certificate Bellman arithmetic and independent policy forward flow',
                    'full_W1_scalar_recomputation_performed_by_this_driver': False,
                    'native_execution_reperformed_by_this_driver': False},
                'scope': ['fixed existing h15 prefix and h16 public tip; no further honest mining',
                    'complete bounded nonce DAG at native W1 matrix/noise shape; finite policy class only',
                    'full-native proof validation relies on separately source-bound scalar and Rust replay receipts',
                    'cost/fault premises remain uncalibrated; initial prefix/census costs recorded separately',
                    'fixed samples and observer-selected existential witnesses are distinct runs',
                    'fresh CPU probe proof generation includes misses and is not a quantum timing calibration',
                    'no hardware, whole-network security, attacker-minimum-cost, profitability, or production qualification']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--expected-tree', required=True)
    args = parser.parse_args()
    report = Audit(args.repo, args.evidence, args.expected_head, args.expected_tree).finish()
    report['reviewed_at_utc'] = datetime.now(timezone.utc).isoformat()
    report['driver_sha256'] = sha(Path(__file__).read_bytes())
    report['command_argv'] = [sys.executable, *sys.argv]
    with args.output.open('x') as stream:
        json.dump(report, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'result': report['result'], 'source': args.expected_head,
                      'contexts': len(report['fixture_summary']['contexts']), 'runs': len(report['runs']),
                      'quantum_ideal_risk': report['quantum_certificate']['ideal_census_advised_envelope'],
                      'classical_ideal_risk': report['classical_certificate']['ideal_census_advised_envelope'],
                      'output_sha256': sha(args.output.read_bytes()), 'output': str(args.output)}, sort_keys=True))


if __name__ == '__main__':
    main()
