import subprocess,sys
p=subprocess.Popen(['/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12','-c','import sys;sys.exit(37)'])
print(p.wait(),flush=True)
sys.exit(23)
