"""Read-only independent audit of the fixed native-owner campaign.

This performs extra post-campaign chain queries and reports them separately.
It never changes the ledger, source, original reports or packet bytes.
"""
import hashlib,json,pathlib,sqlite3,sys,time,subprocess,os
from collections import Counter
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey,Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding,PublicFormat

ROOT=pathlib.Path('/workspace/scratch/10a9f8f2cba0/chain-fairness')
OUT=pathlib.Path('/dev/shm/chain-fresh-transfer-10a9f8f2cba0/owner-exact-e95e2eb9')
DEST=pathlib.Path('/dev/shm/chain-fresh-transfer-10a9f8f2cba0/owner-independent-audit-e95e2eb9.json')
SHA='e95e2eb9f456a37ec8841def69db79f49fbba7cb'
sys.path.insert(0,str(ROOT/'formal/pon-nakamoto-v1'))
from contract_wire import canonical,unique
from grouped_fresh_admission_wire_v0 import pon_hash,decode_body,material_commitments
from grouped_legal_strategy_v0 import independent_reference,REPRESENTATION
from experiments.grouped_cell_operator_v0 import input_commitment,statement_commitment

start=time.perf_counter_ns();cpu=time.process_time_ns();checks=[]
step_calls=seed_calls=0
def need(ok,name):
    checks.append({'check':name,'passed':bool(ok)})
    if not ok:raise AssertionError(name)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(path.read_bytes(),object_pairs_hook=unique)
def public(i):
    seed=pon_hash(b'DEV-ONLY-GROUPED-OWNER-KEY',i.to_bytes(8,'big'))
    return Ed25519PrivateKey.from_private_bytes(seed).public_key().public_bytes(Encoding.Raw,PublicFormat.Raw)
def edverify(public_key,signature,message):
    Ed25519PublicKey.from_public_bytes(public_key).verify(signature,message)
def claim_bytes(c):
    p=c['product'];raw=b''.join(bytes.fromhex(c[n]) for n in ['model_commitment','input_commitment','statement_commitment'])
    for name in ['router_outputs','logits']:
        rows=p[name];raw+=len(rows).to_bytes(8,'big')
        raw+=b''.join(x.to_bytes(8,'big',signed=True) for row in rows for x in row)
    for rows in [p['routes'],p['predictions'],*p['groups']]:
        raw+=len(rows).to_bytes(8,'big')+b''.join(x.to_bytes(8,'big') for x in rows)
    raw+=b''.join(p[n].to_bytes(8,'big') for n in ['useful_dense_macs','padded_macs','nonempty_expert_groups'])
    return raw
def fingerprint(wire,policy):
    c=wire['command']
    return pon_hash(b'pon-grouped-owner-submission-v0',policy,bytes.fromhex(wire['receiver']),
        bytes.fromhex(c['request_id']),bytes.fromhex(c['candidate']),claim_bytes(c['claim']),bytes.fromhex(c['proof_hex']))
def seal_frame(tag,*parts):
    return b'TRNM-GROUPED-FRESH-SEAL0\0'+len(tag).to_bytes(2,'big')+tag+b''.join(len(p).to_bytes(4,'big')+p for p in parts)
profile=hashlib.sha256(seal_frame(b'profile',b'pon-grouped-int257-sealed-research-v0',
    b'pon-routed-int257-grouped-research-v0',b'signed-i32-coeff-i64-accum-bias8-lowest-argmax',
    (64).to_bytes(2,'big'),(16).to_bytes(2,'big'))).digest()

r=read(OUT/'report.json');config=read(OUT/'config.json');prep=read(OUT/'owner/preparation.json')
need(r['status']=='PASS' and r['exact_committed_source_verified'] and not r['failures'],'exact_source_campaign_pass')
need(r['expected_source_sha']==SHA and r['source_before']['commit']==r['source_after']['commit']==SHA,'source_commit')
need(r['source_before']['tracked_tree_clean'] and r['source_after']['tracked_tree_clean'],'tracked_tree_clean_before_after')
for name,item in r['source_before']['relevant_sources'].items():
    need(item['tracked_at_head'] and item['matches_head_bytes'] and item['actual_sha256']==r['source_after']['relevant_sources'][name]['actual_sha256'],f'source_pin:{name}')
build=read(pathlib.Path('/dev/shm/native-owner-final-build.json'))
for name,h in build['source_after'].items():
    committed=subprocess.check_output(['git','show',SHA+':'+name],cwd=ROOT)
    need(sha(committed)==h and sha((ROOT/name).read_bytes())==h,f'final_build_source:{name}')
runner=pathlib.Path(read(OUT/'request.json')['runner'])
need(sha(runner.read_bytes())==r['runner_sha256']==prep['runner_sha256'],'runner_bytes')

capsule=(OUT/'owner/capsule.bin').read_bytes();body_raw=bytes.fromhex(prep['admission_pin']['body_hex'])
need(len(capsule)==862 and capsule[:6]==b'PGAC\0\0' and capsule[6:734]==body_raw and len(body_raw)==728,'capsule_raw_body')
body=decode_body(body_raw);freeze=config['freeze']
need(all(body['intent'][k]==v for k,v in freeze.items() if k!='now_ns'),'all_freeze_fields')
need(all(row['scope']==body['intent']['authorization_scope'] for row in config['requests']),'all_request_scopes')
materials=material_commitments(config['init'],config['requests'],now_ns=1)
need(all(body['intent'][k]==v for k,v in materials.items()),'independent_model_and_preinput_commitments')
registry=pon_hash(b'pon-grouped-owner-fixture-registry-v0',bytes.fromhex(materials['model_commitment']),bytes.fromhex(materials['request_precommitment']))
registry_digest=pon_hash(b'pon-grouped-owner-fixture-config-v0',(OUT/'config.json').read_bytes())
need(body['intent']['registry_id']==registry.hex() and body['intent']['registry_digest']==registry_digest.hex(),'registry_id_and_config_digest')
need(body['intent']['operation_id']==pon_hash(b'pon-grouped-owner-fixture-operation-v0',registry_digest).hex(),'operation_id')
need(body['intent']['transactions_commitment']==pon_hash(b'transactions-empty').hex() and body['intent']['registry_sequence']==1 and body['intent']['previous_registry_digest']=='00'*32,'remaining_canonical_intent_fields')
for role,index,offset in [(1,40,734),(2,41,798)]:
    key=public(index)
    need(key.hex()==prep['admission_pin']['requester_key' if role==1 else 'source_key'],'fixture_capsule_key_'+str(role))
    edverify(key,capsule[offset:offset+64],pon_hash(b'pon-grouped-fresh-capsule-signature-v0',bytes((role,)),body_raw))
    need(True,'independent_capsule_signature_'+str(role))
admission_policy=pon_hash(b'pon-grouped-fresh-external-policy-v0',public(40),public(41),(1).to_bytes(8,'big'),registry_digest,hashlib.sha256(capsule).digest(),body_raw)
need(admission_policy.hex()==prep['admission_pin']['policy_id'],'admission_policy_id')
reference,reference_cost=independent_reference(config['init'],[dict(row,generation=config['init']['model_version'],representation=REPRESENTATION) for row in config['requests']])
candidates={item['nonce']:item for item in prep['candidates']};raw_registry=b''
for nonce,item in sorted(candidates.items()):
    candidate_raw=b'PGCE\0\0'+body_raw+nonce.to_bytes(8,'big')
    ch=pon_hash(b'pon-grouped-fresh-challenge-v0',candidate_raw);ident=pon_hash(b'pon-grouped-fresh-work-id-v0',candidate_raw)
    need(ch.hex()==item['challenge'] and ident.hex()==item['candidate'],'candidate_'+str(nonce))
    context=dict(chain=body['branch']['network'],parent=body['branch']['parent'],challenge=ch.hex(),batch_id=body['intent']['batch_id'])
    inputs=input_commitment(materials['model_commitment'],{'context':context,'requests':config['requests']})
    statement=statement_commitment(materials['model_commitment'],inputs,context,reference)
    need(item['claim']['product']==reference and item['claim']['model_commitment']==materials['model_commitment']
         and item['claim']['input_commitment']==inputs and item['claim']['statement_commitment']==item['statement']==statement,'full_reference_and_statement_'+str(nonce))
    raw_registry+=ident+nonce.to_bytes(8,'big')+ch+bytes.fromhex(statement)
target=bytes.fromhex(body['branch']['target'])
relation_id=pon_hash(b'pon-grouped-owner-material-v0',admission_policy,target,raw_registry)
policy=pon_hash(b'pon-grouped-verifier-authority-policy-v0',public(75),bytes.fromhex(config['epoch']),config['generation'].to_bytes(8,'big'),config['aggregate_limit'].to_bytes(8,'big'),config['per_candidate_limit'].to_bytes(8,'big'),relation_id,b''.join(sorted([public(73),public(74)])))
need(relation_id.hex()==prep['policy']['relation'] and policy.hex()==prep['policy']['policy'],'independent_owner_policy')

# Post-campaign audit calls are additional real queries, not covered by owner K.
endpoints={};audit_trace=[]
for nonce in [1,2,3,4,5,6]:
    c=candidates[nonce]
    state=hashlib.sha256(seal_frame(b'seed',profile,bytes.fromhex(c['challenge']),bytes.fromhex(c['statement']))).digest();seed_calls+=1
    for index in range(1,65):
        preimage=seal_frame(b'step',profile,bytes.fromhex(c['challenge']),index.to_bytes(2,'big'),state)
        state=hashlib.sha256(preimage).digest();step_calls+=1
        audit_trace.append({'nonce':nonce,'index':index,'input_hex':preimage.hex(),'output_hex':state.hex()})
    endpoints[c['candidate']]=state
producer=[json.loads(line,object_pairs_hook=unique) for line in (OUT/'producer-trace.ndjson').read_bytes().splitlines()]
need(len(producer)==192,'producer_trace_count')
need(producer==[row for row in audit_trace if row['nonce'] in [2,3,6]],'all_producer_step_preimages_and_outputs')

server_frames=Counter();client_frames=Counter();new_receipts=[];known_seed=known_steps=known_cell=0
raw_total_in=raw_total_out=0;response_signatures=receiver_signatures=0
for phase in range(1,5):
    directory=OUT/f'phase-{phase}';service=read(directory/'service-report.json');endpoint=read(directory/'endpoint.json')
    need(endpoint['policy']==policy.hex() and endpoint['authority']==public(75).hex() and endpoint['runner_sha256']==r['runner_sha256'],'endpoint_pin_'+str(phase))
    for index,event in enumerate(service['events'],1):
        request_raw=(directory/f'packets/{index:04}.request.json').read_bytes();response_raw=(directory/f'packets/{index:04}.response.json').read_bytes()
        wire=json.loads(request_raw,object_pairs_hook=unique);response=json.loads(response_raw,object_pairs_hook=unique)
        need(request_raw==canonical(wire)+b'\n' and response_raw==canonical(response)+b'\n','canonical_frames_'+str(phase)+'_'+str(index))
        fp=fingerprint(wire,policy);action={'reserve':1,'execute':2}[wire['command']['action']]
        edverify(bytes.fromhex(wire['receiver']),bytes.fromhex(wire['signature_hex']),pon_hash(b'pon-grouped-owner-receiver-signature-v0',bytes((action,)),fp));receiver_signatures+=1
        edverify(public(75),bytes.fromhex(response['signature_hex']),pon_hash(b'pon-grouped-owner-response-v0',policy,canonical(response['payload'])));response_signatures+=1
        need(response['authority']==public(75).hex() and response['payload']['request_sha256']==sha(request_raw) and response['payload']['policy']==policy.hex(),'response_binding_'+str(phase)+'_'+str(index))
        need(sha(request_raw)==event['request_sha256'] and sha(response_raw)==event['response_sha256'] and len(request_raw)==event['request_bytes'] and len(response_raw)==event['response_bytes_written'],'raw_frame_counters_'+str(phase)+'_'+str(index))
        server_frames[(sha(request_raw),sha(response_raw))]+=1;raw_total_in+=len(request_raw);raw_total_out+=len(response_raw)
        body=response['payload']['body']
        if body['ok'] and body['result']['state']=='complete':
            value=body['result'];receipt=value['receipt'];proof=bytes.fromhex(wire['command']['proof_hex'])
            need(receipt['request_fingerprint']==fp.hex() and receipt['receiver']==wire['receiver'] and receipt['request_id']==wire['command']['request_id'] and receipt['candidate']==wire['command']['candidate'],'receipt_full_request_binding_'+str(phase)+'_'+str(index))
            actual=endpoints[receipt['candidate']];valid=proof[102:]==actual
            need((receipt['outcome'] in ['verified_hit','verified_miss'])==valid,'independent_endpoint_relation_'+str(phase)+'_'+str(index))
            if valid:
                need(receipt['endpoint']==actual.hex() and (receipt['outcome']=='verified_hit')==(actual<=target),'independent_target_'+str(phase)+'_'+str(index))
            if value['cached']:
                need(value['new_step_queries']==value['new_seed_queries']==value['new_full_cell_calls']==0 and not value['new_candidate_completion'] and value['cached_response_does_not_revalidate_context'],'cached_cost_and_history_'+str(phase)+'_'+str(index))
            else:
                new_receipts.append(receipt);known_seed+=receipt['cost']['seed_queries'];known_steps+=receipt['cost']['step_queries'];known_cell+=receipt['cost']['full_cell_calls']
                need(receipt['cost']['full_cell_verified'] and receipt['cost']['step_queries']==64 and receipt['cost']['seed_queries']==1,'full_replay_counters_'+str(phase)+'_'+str(index))
    for receiver in [73,74]:
        client=read(OUT/f'phase-{phase}-receiver-{receiver}.report.json')
        for event in client['events']:
            raw=bytes.fromhex(event['request_raw_hex']);answer=bytes.fromhex(event['response_raw_hex'])
            need(event['authenticated_fixture_response'] and len(raw)==event['request_bytes_written'] and len(answer)==event['response_bytes'],'client_byte_counter_'+str(phase)+'_'+str(receiver)+'_'+str(event['planned_index']))
            client_frames[(sha(raw),sha(answer))]+=1
need(server_frames==client_frames and sum(server_frames.values())==30,'all_30_client_owner_frame_pairs')
need(known_steps==704 and known_seed==known_cell==11 and len(new_receipts)==11,'aggregate_callback_costs')
need(raw_total_in==sum(p['application_bytes_to_owner'] for p in r['phases'])==53460,'aggregate_input_frame_bytes')
need(raw_total_out==sum(p['application_bytes_from_owner'] for p in r['phases']),'aggregate_output_frame_bytes')

db=sqlite3.connect((OUT/'owner/authority.sqlite').as_uri()+'?mode=ro&immutable=1',uri=True)
context=db.execute('SELECT schema,hex(policy),issued FROM context').fetchone()
need(context==('pon-grouped-verification-authority-v0',policy.hex().upper(),12),'sql_context')
rows=db.execute('SELECT sequence,receiver,request_id,candidate,fingerprint,state,receipt FROM submissions ORDER BY sequence').fetchall()
need(len(rows)==12 and [x[0] for x in rows]==list(range(1,13)),'sql_sequences')
state_counts=Counter(row[5] for row in rows);need(state_counts=={'complete':11,'reserved':1},'sql_dispositions')
by_sequence={v['sequence']:v for v in new_receipts}
for seq,receiver,request,candidate,fp,state,raw in rows:
    if raw:
        receipt=json.loads(raw,object_pairs_hook=unique)
        need(receipt==by_sequence[seq] and receipt['receiver']==receiver.hex() and receipt['request_id']==request.hex() and receipt['candidate']==candidate.hex() and receipt['request_fingerprint']==fp.hex(),'sql_receipt_'+str(seq))
closed=db.execute('SELECT candidate,sequence,endpoint FROM closed_candidates').fetchall();db.close()
need(len(closed)==3,'sql_three_closed_candidates')
for c,seq,e in closed:need(by_sequence[seq]['first_record'] and by_sequence[seq]['candidate']==c.hex() and e==endpoints[c.hex()],'sql_closed_binding_'+str(seq))
need(sum(v['first_record'] for v in new_receipts)==3 and all(v['chainwork_awarded']==0 for v in new_receipts),'no_duplicate_first_record_or_credit')
outcomes=Counter(v['outcome'] for v in new_receipts)

processes=r['all_processes'];need(len(processes)==13 and all(p['exit_code']==0 and p['status']=='exited' for p in processes),'all_13_processes_exited')
need(len({p['pid'] for p in processes})==13,'distinct_process_identities_in_campaign')
need(len([p for p in processes if p['label'].startswith('receiver-')])==8 and len([p for p in processes if p['label'].startswith('owner-')])==4,'receiver_owner_process_denominators')
usage={role:sum(p['user_seconds']+p['system_seconds'] for p in processes if (p['label'].startswith('owner-') if role=='owner' else p['label'].startswith('receiver-') if role=='receiver' else p['label']=='prepare')) for role in ['owner','receiver','prepare']}
native_cpu=sum(usage.values());all_children_cpu=r['all_children_user_seconds']+r['all_children_system_seconds']
need(native_cpu<=all_children_cpu+1e-6,'native_cpu_is_subset_of_all_children')
preps=[prep['prepare_cost']]+[read(OUT/f'phase-{p}/service-report.json')['startup_prepare_cost'] for p in range(1,5)]
need(all(p['prepared_model_instances']==1 and p['direct_business_observations']==16 and p['direct_business_macs']==16*16*6*257 and p['seal_step_queries']==0 and p['seal_seed_queries']==0 for p in preps),'five_complete_startup_preparations')
need(r['final_snapshot']['full_cell_verified_calls']==11 and r['final_snapshot']['verified_cell_macs_known']==11*37008 and r['final_snapshot']['incomplete_cell_macs_unknown_upper']==0,'cell_mac_intervals')

result={'schema':'pon-grouped-owner-independent-audit-v0','status':'PASS','source_commit':SHA,'source_runner_sha256':r['runner_sha256'],
    'report_sha256':sha((OUT/'report.json').read_bytes()),'checks':checks,'checks_passed':len(checks),
    'independent_capsule_signatures':2,'independent_receiver_signatures':receiver_signatures,'independent_owner_response_signatures':response_signatures,
    'frames_received_bytes':raw_total_in,'frames_sent_bytes':raw_total_out,'frames_each_direction':30,
    'native_owner_steps':known_steps,'native_owner_seeds':known_seed,'native_full_cell_calls':known_cell,'producer_steps':192,'producer_seeds':3,
    'post_campaign_audit_chain_step_queries':step_calls,'post_campaign_audit_seed_queries':seed_calls,
    'post_campaign_audit_reference_macs':reference_cost.reference_macs,'post_campaign_audit_reference_additions':reference_cost.reference_additions,
    'post_campaign_audit_cost_scope':'Additional independent audit, outside original campaign K and timing. Include in an expanded assistance/accounting horizon; endpoints are not exported by this report.',
    'whole_before_audit_report_wall_ns':time.perf_counter_ns()-start,'audit_process_cpu_ns':time.process_time_ns()-cpu,
    'campaign_native_cpu_seconds_by_role':usage,'campaign_native_cpu_seconds_total':native_cpu,'campaign_all_children_cpu_seconds':all_children_cpu,
    'startup_direct_business_macs':sum(p['direct_business_macs'] for p in preps),'startup_merge_additions':sum(p['cached_model_merge_additions'] for p in preps),
    'verified_callback_macs':11*37008,'outcomes':dict(outcomes),'final_reserved':12,'final_complete':11,'final_reserved_abandoned':1,
    'all_keys_public_test_fixtures':True,'independent_operators':False,'global_budget_proved':False,'physical_durability_proved':False,'chainwork_awarded':0}
with DEST.open('x') as f:json.dump(result,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({k:result[k] for k in ['status','checks_passed','independent_capsule_signatures','independent_receiver_signatures','independent_owner_response_signatures','post_campaign_audit_chain_step_queries','campaign_native_cpu_seconds_by_role','startup_direct_business_macs','outcomes']},indent=2))
