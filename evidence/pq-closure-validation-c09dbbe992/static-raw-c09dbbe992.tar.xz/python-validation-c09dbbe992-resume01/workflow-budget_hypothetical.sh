set -euo pipefail
python3 scripts/w1_qrom_conditional_budget.py --example-input \
  > "$W1_QROM_OUT/budget-hypothetical-input.json" 2> "$W1_QROM_OUT/budget-hypothetical-input.log"
python3 scripts/w1_qrom_conditional_budget.py --input "$W1_QROM_OUT/budget-hypothetical-input.json" \
  > "$W1_QROM_OUT/budget-hypothetical.json" 2> "$W1_QROM_OUT/budget-hypothetical.log"
