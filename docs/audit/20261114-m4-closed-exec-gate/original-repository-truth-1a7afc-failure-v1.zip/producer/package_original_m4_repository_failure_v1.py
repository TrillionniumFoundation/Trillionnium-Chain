import pathlib,sys,os,stat,json,hashlib,zipfile,datetime
BASE=pathlib.Path("/home/qian-qi/chain-final-consolidation-20261114-root")
SRC=BASE/"final-repository-truth-offline-1a7afc-v1"
OUT=BASE/"package-original-repository-truth-1a7afc-failure-v1"
assert not sys.flags.optimize and SRC.resolve(strict=True)==SRC
OUT.mkdir(mode=0o700,exist_ok=False)
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p):
 p=pathlib.Path(p); assert p.resolve(strict=True)==p
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  a=os.fstat(fd); assert stat.S_ISREG(a.st_mode) and a.st_nlink==1 and a.st_size<=4*1024*1024
  with os.fdopen(os.dup(fd),"rb") as f: b=f.read()
  z=os.fstat(fd); assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns) and len(b)==a.st_size
  return b
 finally: os.close(fd)
raw=read(SRC/"summary.json")
assert sha(raw)=="61322d80d4bb3439f2115d62b50ff3c0be42e9b10bf17f82193d5d01935a71e6"
j=json.loads(raw)
assert j["status"]=="failed" and j["head"]=="1a7afcdb820b051d1e4bfde3d436f96fc050c487" and j["tree"]=="18c3d20df915f5c31ee38c7037775c61e5c12e3f" and j["source_before_after_verified"] is True
assert len(j["steps"])==18
expected=["initial-head","initial-status","pre-update-preflight","local-bundle-verify","local-bundle-list-heads","fetch-exact-local-bundle","fetched-commit","fetched-tree","fast-forward-ancestry","fast-forward","preflight-audit","rust-version","cargo-version","conformance-environment","runtime-environment","verify-source-before","repository-truth","verify-source-after"]
assert [s["label"] for s in j["steps"]]==expected
assert [s["label"] for s in j["steps"] if s["exit"]!=0]==["repository-truth"]
rows=[]; payload={}
def add(p,n,b=None):
 assert n not in payload and not n.startswith("/") and ".." not in pathlib.PurePosixPath(n).parts
 b=read(p) if b is None else b; payload[n]=b
 rows.append({"path":n,"bytes":len(b),"sha256":sha(b),"origin":{"host":"rog","path":str(p)}})
add(SRC/"summary.json","original/summary.json",raw)
for s in j["steps"]:
 for stream in ("stdout","stderr"):
  p=pathlib.Path(s[stream+"_path"]); assert p.parent==SRC and p.name==s["label"]+"."+stream
  b=read(p); assert len(b)==s[stream+"_bytes"] and sha(b)==s[stream+"_sha256"]
  add(p,"original/"+p.name,b)
identity=[]
for name in ("source-before.json","source-after.json"):
 b=read(SRC/name); assert len(b)==423 and sha(b)=="5b4957027bf81224ac50742d5b1a1b2857d47ef9dfd75c8bc98d1dd007c668a5"
 identity.append(json.loads(b));add(SRC/name,"original/"+name,b)
assert identity[0]==identity[1] and identity[0]["tested_commit"]==j["head"] and identity[0]["tested_tree"]==j["tree"]
assert len(payload)==39
driver=BASE/"run_final_rog_repository_truth_offline_v4.py"; b=read(driver)
assert len(b)==15187 and sha(b)=="bbc62032fcb58443ee36cd59408c49d2d9694c5f709c48a30b6daf714a5ddd38"
add(driver,"producer/"+driver.name,b)
me=pathlib.Path(__file__).resolve(strict=True);add(me,"producer/"+me.name)
rows.sort(key=lambda x:x["path"])
index={"schema":"trnm-original-local-lane-receipt-package-v1","head":j["head"],"tree":j["tree"],"original_result":"failed","original_file_count":39,"source_before_after_equal":True,"original_lane_argv":["bash","scripts/ci/ci_job.sh","repository-truth"],"original_lane_exit":1,"original_lane_elapsed_seconds":j["steps"][16]["elapsed_seconds"],"files":rows}
ix=(json.dumps(index,indent=2,sort_keys=True)+"\n").encode()
(OUT/"EVIDENCE_INDEX.json").write_bytes(ix)
zpath=OUT/"original-repository-truth-1a7afc-failure-v1.zip"
with zipfile.ZipFile(zpath,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in sorted({**payload,"EVIDENCE_INDEX.json":ix}.items()):
  info=zipfile.ZipInfo(n,(2026,11,14,0,0,0));info.create_system=3;info.external_attr=(stat.S_IFREG|0o600)<<16;info.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(info,b)
with zipfile.ZipFile(zpath,"r") as z:
 assert z.testzip() is None and len(z.infolist())==len(payload)+1
 for r in rows:
  b=z.read(r["path"]);assert len(b)==r["bytes"] and sha(b)==r["sha256"]
 assert z.read("EVIDENCE_INDEX.json")==ix
for r in rows:
 b=read(r["origin"]["path"]); assert len(b)==r["bytes"] and sha(b)==r["sha256"]
zb=read(zpath)
summary={"schema":"trnm-original-M4-repository-failure-package-completion-v1","finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"zip":{"path":str(zpath),"bytes":len(zb),"sha256":sha(zb)},"index":{"path":str(OUT/"EVIDENCE_INDEX.json"),"bytes":len(ix),"sha256":sha(ix)},"payload_file_count":len(rows),"zip_member_count":len(rows)+1,"original_execution_file_count":39,"original_execution_bytes":sum(r["bytes"] for r in rows if r["path"].startswith("original/")),"all_member_CRC_SHA_verified":True,"original_files_unchanged":True,"source_or_Git_objects_modified":False,"tests_rerun":False,"original_result":"failed","failure":"CollectorControls.test_actual_post_fork_identity_failure_reaps_gated_root_without_exec: root_returncode -15 != 125"}
sb=(json.dumps(summary,indent=2,sort_keys=True)+"\n").encode(); (OUT/"summary.json").write_bytes(sb); print(json.dumps({"summary_path":str(OUT/"summary.json"),"summary_bytes":len(sb),"summary_sha256":sha(sb),**summary}),flush=True)
