set -euo pipefail
python3 scripts/w1_qrom_historical_fixture.py --repo-root "$GITHUB_WORKSPACE" \
  --output-dir "$W1_QROM_OUT" 2>&1 | tee "$W1_QROM_OUT/implementation.log"
