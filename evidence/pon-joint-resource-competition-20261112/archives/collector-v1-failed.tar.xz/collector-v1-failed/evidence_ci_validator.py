"""Read-only, fail-closed validation of retained A/A2 CI evidence."""
from __future__ import annotations

from datetime import datetime, timezone
import ast
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess

A_OBSERVED = "43e5c9d6b668276d03e1c7a76f467ec211e1d7dc"
CHECKER = "scripts/ci/check_ci_contract.py"
CORPUS = "config/pon/pq-cross-branch-corpus-v1.json"
TEST = "scripts/ci/test_ci_contract.py"
OLD_BLOB = "8c84ca65e93b8cccdbd0311a3c35dd70b366b5fd"
HELPER_SHA = "c7e211a71620ce161ce53a29f468a3b9796eb58ef18714192ee31ffcd9a0612c"
OLD_SUMMARY_SHA = "fffe3fae73115b1227a711148b3402f513bbb523abc06cc4481bfc5fd7e8e811"
OLD_MANIFEST_SHA = "8a8eee950222b94373cbae958861654a9a01588b6c48960cbdd617a59ae1e3d1"
FAILED_CI_SHA = "e72186175eab587f34d82286a66fd2a7433b02661a9a567432d25fcbd7197c2e"
SOURCE_NEG_SHA = "6b587a349d7d8fa0521af27ab06eb47ccff365bcd81eff3123ffe832a2f7cc59"
PQ_NEG_SHA = "fc23deba51996c07ead19e484142442fef0b45b6a6259f406de0f23bd64b0415"
PY = "/usr/bin/python3"
OVERRIDES = {"PATH": "/usr/bin:/bin:/usr/local/bin",
             "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1"}
MIN_FREE = 14 * 1024**3
HEX40 = re.compile(r"[0-9a-f]{40}\Z")
HEX64 = re.compile(r"[0-9a-f]{64}\Z")


def _need(condition, message):
    if not condition:
        raise ValueError("CI_EVIDENCE: " + message)


def _same(left, right):
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def _keys(value, wanted, label):
    _need(type(value) is dict and set(value) == set(wanted), label + " keys")


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        _need(key not in result, "duplicate JSON key " + key)
        result[key] = value
    return result


def _loads(raw):
    def bad(value):
        raise ValueError("CI_EVIDENCE: nonfinite JSON " + value)
    return json.loads(raw.decode("utf-8"), object_pairs_hook=_pairs, parse_constant=bad)


def _file(path):
    info = path.lstat()
    _need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "nonregular or hardlinked artifact " + str(path))
    return info


def _raw(path, bound=16 * 1024 * 1024):
    info = _file(path)
    _need(info.st_size <= bound, "reader bound " + str(path))
    raw = path.read_bytes()
    after = path.lstat()
    _need((info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
          == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
          "artifact changed while reading " + str(path))
    return raw


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _json(path):
    return _loads(_raw(path))


def _time(value, label):
    _need(type(value) is str, label + " timestamp type")
    parsed = datetime.fromisoformat(value)
    _need(parsed.tzinfo is not None and parsed.utcoffset() == timezone.utc.utcoffset(parsed),
          label + " must be UTC")
    return parsed


def _interval(row, label):
    start = _time(row["started_utc"], label)
    end = _time(row["ended_utc"], label)
    _need(end >= start, label + " reversed interval")
    return start, end


def _relative(value):
    _need(type(value) is str and value and "\\" not in value, "artifact path type")
    path = PurePosixPath(value)
    _need(not path.is_absolute() and all(part not in ("", ".", "..") for part in path.parts)
          and str(path) == value, "noncanonical artifact path " + value)
    return path


def _manifest(root, schema, identity):
    _need(root.is_absolute() and root.is_dir() and not root.is_symlink()
          and root.resolve() == root, "canonical evidence directory")
    manifest = _json(root / "manifest.json")
    _keys(manifest, {"schema", "files"} | set(identity), "manifest")
    _need(manifest["schema"] == schema, "manifest schema")
    for key, value in identity.items():
        _need(_same(manifest[key], value), "manifest identity " + key)
    entries = manifest["files"]
    _need(type(entries) is dict and entries, "empty manifest")
    actual = set()
    for parent, directories, files in os.walk(root, followlinks=False):
        for name in directories:
            _need(not (Path(parent) / name).is_symlink(), "symlink directory")
        for name in files:
            path = Path(parent) / name
            _file(path)
            actual.add(path.relative_to(root).as_posix())
    _need(actual == set(entries) | {"manifest.json"}, "manifest/filesystem inventory mismatch")
    for relative, wanted in entries.items():
        _relative(relative)
        _keys(wanted, {"bytes", "sha256"}, "manifest file")
        _need(type(wanted["bytes"]) is int and wanted["bytes"] >= 0
              and type(wanted["sha256"]) is str and HEX64.fullmatch(wanted["sha256"]),
              "manifest digest type")
        raw = _raw(root / relative)
        _need(len(raw) == wanted["bytes"] and _sha(raw) == wanted["sha256"],
              "manifest file differs " + relative)
    return manifest


RECORD_KEYS = {
    "schema", "name", "argv", "cwd", "timeout_seconds", "expected_exit_code",
    "expected_unittest_count", "output_check", "expected_head", "environment_overrides",
    "started_utc", "ended_utc", "elapsed_monotonic_seconds", "state", "exit_code",
    "pid", "exception", "stdout", "stderr", "evaluation", "expectation_met",
}


def _stream(directory, value, name):
    _keys(value, {"file", "bytes", "sha256"}, name + " stream")
    _need(value["file"] == name + ".raw" and type(value["bytes"]) is int
          and value["bytes"] >= 0 and type(value["sha256"]) is str
          and HEX64.fullmatch(value["sha256"]), name + " stream metadata")
    raw = _raw(directory / value["file"])
    _need(len(raw) == value["bytes"] and _sha(raw) == value["sha256"], name + " raw mismatch")
    return raw


def _unittest(stdout, stderr, count, *, failed=False):
    text = (stdout + b"\n" + stderr).decode("utf-8")
    _need(re.findall(r"^Ran ([0-9]+) tests? in ", text, re.M) == [str(count)], "unittest denominator")
    if failed:
        _need(re.findall(r"^FAILED.*$", text, re.M) == ["FAILED (failures=2)"], "original failure footer")
        _need(not re.findall(r"^OK(?: \(.*\))?$", text, re.M), "failed suite claims OK")
    else:
        _need(re.findall(r"^OK(?: \(.*\))?$", text, re.M) == ["OK"], "no-skip unittest footer")
        _need(not re.search(r"^.* \.\.\. skipped(?: |$)|^FAILED|^ERROR:", text, re.M),
              "skipped or failed unittest")


def _record(root, relative, *, name, cwd, head, argv, tests=None, check=None,
            expected=0, actual=0, success=True):
    _relative(relative)
    directory = (root / relative).parent
    row = _json(root / relative)
    _keys(row, RECORD_KEYS, "command record")
    _need(row["schema"] == "trnm-daa-external-ci-command-v1", "command schema")
    for key, wanted in (("name", name), ("cwd", cwd), ("expected_head", head), ("argv", argv),
                        ("expected_unittest_count", tests), ("output_check", check),
                        ("expected_exit_code", expected), ("exit_code", actual),
                        ("environment_overrides", OVERRIDES)):
        _need(_same(row[key], wanted), name + " changed " + key)
    _need(row["state"] == "completed" and row["exception"] is None
          and row["expectation_met"] is success, name + " terminal state")
    _need(type(row["pid"]) is int and row["pid"] > 0
          and type(row["timeout_seconds"]) in (int, float) and row["timeout_seconds"] > 0,
          name + " pid/timeout")
    elapsed = row["elapsed_monotonic_seconds"]
    _need(type(elapsed) in (int, float) and math.isfinite(elapsed) and elapsed >= 0, name + " elapsed")
    _interval(row, name)
    stdout, stderr = (_stream(directory, row[k], k) for k in ("stdout", "stderr"))
    evaluation = row["evaluation"]
    if not success:
        _need(_same(evaluation, {"errors": ["unexpected exit code"]}), "original failed evaluation")
        _unittest(stdout, stderr, tests, failed=True)
        return row, stdout, stderr
    if tests is not None:
        _keys(evaluation, {"errors", "observed_unittest_counts"}, "suite evaluation")
        _need(evaluation["errors"] == [] and _same(evaluation["observed_unittest_counts"], [tests]),
              "suite evaluation count")
        _unittest(stdout, stderr, tests)
    elif check == "inventory":
        _need(_same(evaluation, {"errors": []}), "inventory evaluation")
        _need(stdout.strip() == b"distributed source inventory: PASS", "inventory report")
    else:
        _keys(evaluation, {"errors", "checker_report"}, "checker evaluation")
        _need(evaluation["errors"] == [], "checker errors")
        parsed = _loads(stdout)
        _need(_same(parsed, evaluation["checker_report"]), "checker JSON/raw mismatch")
    return row, stdout, stderr


def _source(row, commit, tree, count, size):
    data = row["evaluation"]["checker_report"]
    _keys(data, {"schema", "kind", "tested_commit", "tested_tree", "candidate", "base",
                 "prospective_merge", "tracked_worktree_verified", "tracked_entries",
                 "tracked_bytes", "tests_executed_by_identity_check"}, "source report")
    wanted = {"schema": "trnm-ci-source-v1", "kind": "head", "tested_commit": commit,
              "tested_tree": tree, "candidate": commit, "base": None, "prospective_merge": None,
              "tracked_worktree_verified": True, "tracked_entries": count, "tracked_bytes": size,
              "tests_executed_by_identity_check": False}
    _need(_same(data, wanted), "complete source guard identity")


def _check_report(row, kind, *, head=None, tree=None):
    data = row["evaluation"]["checker_report"]
    _need(type(data) is dict, "checker object")
    if kind == "preflight":
        _need(data.get("result") == "PASS" and data.get("mode") == "--audit"
              and data.get("remote_policy_mutated") is False, "audit preflight")
    elif kind == "ci":
        _need(data.get("tests_executed") is False and type(data.get("head_jobs")) is int
              and data["head_jobs"] == 5 and type(data.get("merge_lanes")) is int
              and data["merge_lanes"] == 5, "actual CI checker")
    elif kind == "pq":
        _need(data.get("schema") == "trnm-pq-cross-branch-check-v1"
              and data.get("status") == "HOLD_NO_GO" and type(data.get("exact_source_blobs")) is int
              and data["exact_source_blobs"] == 915 and data.get("cryptographic_acceptance") is False
              and data.get("node_activated") is False, "PQ current corpus/HOLD")
    elif kind == "repository":
        _need(data.get("result") == "PASS" and data.get("head") == head and data.get("tree") == tree
              and data.get("source_state") == "committed-clean"
              and data.get("runtime_implemented") is False and data.get("activation") is False,
              "repository exact source")
        for key, value in (("workspace_packages", 26), ("rust_files", 1390), ("local_links", 6163)):
            _need(type(data.get(key)) is int and data[key] == value, "repository " + key)
    elif kind in ("joint", "joint-refusal"):
        _need(data.get("contract_validation") == "PASS" and data.get("qualification") == "HOLD_NO_GO"
              and data.get("production_activation") is False
              and data.get("security_probability_calibrated") is False
              and data.get("unknown_parameter_count") == 18 and len(data.get("open_obligations", [])) == 13,
              "joint HOLD")
        for key in ("actual_lifetime_failure_bound", "common_prefix_failure_bound",
                    "chain_growth_failure_bound", "chain_quality_failure_bound", "six_confirmations_failure_bound"):
            _need(key in data and data[key] is None, "invented joint bound")
        if kind == "joint-refusal":
            _need(data.get("qualification_request") == "REFUSED_UNPROVED_JOINT_CONSENSUS",
                  "expected qualification refusal absent")
    else:
        raise ValueError("CI_EVIDENCE: unknown checker " + kind)


def _git(R, *argv):
    environment = {key: value for key, value in os.environ.items() if not key.startswith("GIT_")}
    result = subprocess.run(["git", "--no-replace-objects", "-C", str(R), *argv],
                            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            env=environment, timeout=120)
    _need(result.returncode == 0, "read-only Git failure: " + repr(argv) + ": " + result.stderr.decode(errors="replace"))
    return result.stdout


def _object(R, kind, oid):
    raw = _git(R, "cat-file", kind, oid)
    _need(hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == oid,
          "Git object content hash")
    return raw


def _tree(R, commit):
    raw = _object(R, "commit", commit)
    header = raw.split(b"\n\n", 1)[0].splitlines()
    trees = [line[5:].decode() for line in header if line.startswith(b"tree ")]
    parents = [line[7:].decode() for line in header if line.startswith(b"parent ")]
    _need(len(trees) == 1 and HEX40.fullmatch(trees[0]), "commit tree")
    _object(R, "tree", trees[0])
    rows = {}
    for entry in _git(R, "ls-tree", "-r", "-l", "-z", "--full-tree", commit).split(b"\0"):
        if not entry:
            continue
        metadata, name = entry.split(b"\t", 1)
        mode, kind, oid, size = metadata.split()
        path = name.decode("utf-8")
        _relative(path)
        _need(path not in rows and kind == b"blob" and size.isdigit(), "tracked tree inventory")
        rows[path] = (mode.decode(), kind.decode(), oid.decode(), int(size))
    return trees[0], parents, rows


def _approved_patch(old):
    anchor = """JOINT_CONSENSUS_QUALIFICATION_COMMANDS = (
    'python3 formal/pon-nakamoto-v1/joint_consensus_qualification.py --check',
    'python3 formal/pon-nakamoto-v1/test_joint_consensus_qualification.py',
    'python3 formal/pon-nakamoto-v1/test_dynamic_participation_v1.py',
    'python3 formal/pon-nakamoto-v1/test_joint_production_tail_v1.py',
)"""
    addition = """JOINT_RESOURCE_COMPETITION_COMMANDS = (
    "python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_quantum_probability_sampling.py' -v",
    "python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_joint_resource_competition_campaign.py' -v",
)"""
    loop = """    for command in JOINT_CONSENSUS_QUALIFICATION_COMMANDS:
        require(code_lines(lanes['repository-truth']).count(command) == 1
                and code_lines(script).count(command) == 1,
                'joint consensus qualification controls must execute exactly once in repository-truth')
"""
    extra = """    for command in JOINT_RESOURCE_COMPETITION_COMMANDS:
        require(code_lines(lanes['repository-truth']).count(command) == 1
                and code_lines(script).count(command) == 1,
                'joint resource competition controls must execute exactly once in repository-truth')
"""
    text = old.decode()
    _need(text.count(anchor) == text.count(loop) == 1 and "JOINT_RESOURCE_COMPETITION_COMMANDS" not in text,
          "approved patch anchors")
    expected = text.replace(anchor, anchor + "\n\n" + addition, 1).replace(loop, loop + extra, 1)
    ast.parse(expected)
    return expected.encode()


def _plan_gate(name, argv, cwd, timeout=600, tests=None, check=None, expected=0):
    return {"name": name, "argv": argv, "cwd": cwd, "timeout_seconds": timeout,
            "expected_exit_code": expected, "expected_unittest_count": tests, "output_check": check}


def _gate_roster(head, cwd, *, old):
    source = [PY, "-B", "scripts/ci/verify_ci_source.py", "--kind", "head", "--expected-head", head]
    rows = [_plan_gate("source-before", source, cwd, check="source"),
            _plan_gate("preflight-audit", ["/bin/bash", "scripts/project-preflight.sh", "--audit"], cwd, check="preflight"),
            _plan_gate("ci-contract-negatives", [PY, "-B", TEST, "-v"], cwd, 1800, tests=169)]
    if old:
        rows += [_plan_gate("source-integrity-negatives", [PY, "-B", "scripts/ci/test_ci_source_integrity.py", "-v"], cwd, tests=43),
                 _plan_gate("pq-corpus-negatives", [PY, "-B", "scripts/ci/test_pq_research_integration.py", "-v"], cwd, tests=57)]
    rows += [_plan_gate("ci-contract-current", [PY, "-B", CHECKER], cwd, check="ci"),
             _plan_gate("pq-corpus-current", [PY, "-B", "scripts/ci/check_pq_research_integration.py"], cwd, check="pq"),
             _plan_gate("repository-and-markdown-links", [PY, "-B", "scripts/ci/check_repository.py"], cwd, check="repository")]
    if old:
        rows += [_plan_gate("distributed-source-inventory", [PY, "-B", "scripts/refresh_distributed_source_inventory.py", "--check"], cwd, check="inventory"),
                 _plan_gate("joint-qualification-current-hold", [PY, "-B", "formal/pon-nakamoto-v1/joint_consensus_qualification.py", "--check"], cwd, check="joint"),
                 _plan_gate("joint-unproved-qualification-refusal", [PY, "-B", "formal/pon-nakamoto-v1/joint_consensus_qualification.py", "--require-qualified"], cwd, check="joint-refusal", expected=3)]
    return rows + [_plan_gate("source-after", source, cwd, check="source")]


def _verify_roster(root, roster, head, tree, size, *, prefix="", old=False):
    result = {}
    last_end = None
    for specification in roster:
        name = specification["name"]
        failed = old and name == "ci-contract-negatives"
        row, stdout, stderr = _record(root, prefix + name + "/record.json", name=name,
            cwd=specification["cwd"], head=head, argv=specification["argv"],
            tests=specification["expected_unittest_count"], check=specification["output_check"],
            expected=specification["expected_exit_code"],
            actual=1 if failed else specification["expected_exit_code"], success=not failed)
        _need(_same({key: row[key] for key in specification}, specification), "gate/plan mismatch")
        began, ended = _interval(row, name)
        _need(last_end is None or began >= last_end, "overlapping sequential gate clocks")
        last_end = ended
        if specification["output_check"] == "source":
            _source(row, head, tree, 26711, size)
        elif specification["output_check"] not in (None, "inventory"):
            _check_report(row, specification["output_check"], head=head, tree=tree)
        result[name] = row
    return result


def _operation_records(repair, summary, canonical, cwd, A, A2, tree, test_raw, git_paths):
    mapping = {
        "canonical-head-before": (["git", "rev-parse", "HEAD"], canonical),
        "repair-head-before": (["git", "rev-parse", "HEAD"], cwd),
        "repair-branch-before": (["git", "branch", "--show-current"], cwd),
        "repair-status-before": (["git", "status", "--porcelain"], cwd),
        "common-directory": (["git", "rev-parse", "--path-format=absolute", "--git-common-dir"], cwd),
        "initial-index": (["git", "ls-files", "-v", "-z"], cwd),
        "initial-tree": (["git", "ls-tree", "-r", "-z", "--full-tree", A], cwd),
        "unchanged-test-before": (["git", "show", A + ":" + TEST], cwd),
        "approved-diff-paths": (["git", "diff", "--name-only"], cwd),
        "approved-diff": (["git", "diff", "--", CHECKER, CORPUS], cwd),
        "unchanged-other-ci": (["git", "diff", "--exit-code", A, "--", TEST, "scripts/ci/ci_job.sh"], cwd),
        "diff-whitespace": (["git", "diff", "--check"], cwd),
        "canonical-head-before-commit": (["git", "rev-parse", "HEAD"], canonical),
        "stage-approved-delta": (["git", "add", "--", CHECKER, CORPUS], cwd),
        "staged-paths": (["git", "diff", "--cached", "--name-only"], cwd),
        "staged-preflight": (["/bin/bash", "scripts/project-preflight.sh", "--staged"], cwd),
        "freeze-a2": (["git", "commit", "-m", "ci: enforce one lane for quantum resource controls"], cwd),
        "a2-head": (["git", "rev-parse", "HEAD"], cwd),
        "a2-tree": (["git", "rev-parse", "HEAD^{tree}"], cwd),
        "a2-parent": (["git", "rev-parse", "HEAD^"], cwd),
        "a2-delta": (["git", "diff-tree", "--no-commit-id", "--name-only", "-r", "HEAD"], cwd),
        "a2-clean": (["git", "status", "--porcelain"], cwd),
        "canonical-head-final": (["git", "rev-parse", "HEAD"], canonical),
    }
    optional = {
        "worktree-config-enabled": (["git", "config", "--bool", "extensions.worktreeConfig"], cwd),
        "disable-sparse-worktree": (["git", "config", "--worktree", "core.sparseCheckout", "false"], cwd),
        "disable-sparse-cone-worktree": (["git", "config", "--worktree", "core.sparseCheckoutCone", "false"], cwd),
        "clear-skip-flags": (["git", "update-index", "--no-skip-worktree", "-z", "--stdin"], cwd),
        "clear-assume-flags": (["git", "update-index", "--no-assume-unchanged", "-z", "--stdin"], cwd),
        "materialize-index": (["git", "checkout-index", "--all", "--force"], cwd),
        "materialized-index": (["git", "ls-files", "-v", "-z"], cwd),
        "materialized-tree": (["git", "ls-tree", "-r", "-z", "--full-tree", A], cwd),
    }
    items = summary["operation_records"]
    _need(type(items) is list and items, "operations missing")
    names = [row.get("name") for row in items]
    wanted = list(mapping)
    if any(name in optional for name in names):
        position = wanted.index("initial-tree") + 1
        wanted[position:position] = list(optional)
    _need(names == wanted, "operation inventory/order")
    mapping.update(optional)
    files = set()
    outputs = {}
    base_keys = {"name", "argv", "cwd", "started_utc", "ended_utc", "exit_code",
                 "state", "environment_overrides", "stdout", "stderr"}
    for item in items:
        _keys(item, {"name", "record", "exit_code", "state"}, "operation summary")
        name = item["name"]
        relative = "operations/" + name + "/record.json"
        _need(item["record"] == relative and type(item["exit_code"]) is int
              and item["exit_code"] == 0 and item["state"] == "completed", "operation terminal")
        row = _json(repair / relative)
        stdin_needed = name in ("clear-skip-flags", "clear-assume-flags")
        _keys(row, base_keys | ({"stdin"} if stdin_needed else set()), "operation record")
        argv, directory = mapping[name]
        _need(row["name"] == name and _same(row["argv"], argv) and row["cwd"] == directory
              and _same(row["environment_overrides"], OVERRIDES)
              and type(row["exit_code"]) is int and row["exit_code"] == 0
              and row["state"] == "completed", "operation binding")
        _interval(row, name)
        parent = (repair / relative).parent
        stdout = _stream(parent, row["stdout"], "stdout")
        _stream(parent, row["stderr"], "stderr")
        outputs[name] = stdout
        files.update({relative, str(PurePosixPath(relative).parent / "stdout.raw"),
                      str(PurePosixPath(relative).parent / "stderr.raw")})
        if stdin_needed:
            _keys(row["stdin"], {"bytes", "sha256"}, "operation stdin")
            raw = _raw(parent / "stdin.raw")
            _need(type(row["stdin"]["bytes"]) is int and len(raw) == row["stdin"]["bytes"]
                  and _sha(raw) == row["stdin"]["sha256"]
                  and raw == b"\0".join(path.encode() for path in git_paths) + b"\0", "operation stdin binding")
            files.add(str(PurePosixPath(relative).parent / "stdin.raw"))
    for name in ("canonical-head-before", "repair-head-before", "canonical-head-before-commit", "a2-parent", "canonical-head-final"):
        _need(outputs[name].strip() == A.encode(), "operation A identity")
    _need(outputs["a2-head"].strip() == A2.encode() and outputs["a2-tree"].strip() == tree.encode(),
          "operation A2 identity")
    _need(outputs["repair-branch-before"].strip() == b"fix/chain-daa-resource-ci-guard-20261112-600e",
          "isolated branch")
    for name in ("repair-status-before", "a2-clean", "unchanged-other-ci", "diff-whitespace"):
        _need(outputs[name] == b"", "unexpected dirty/control output")
    _need(outputs["unchanged-test-before"] == test_raw, "old test original bytes")
    for name in ("approved-diff-paths", "staged-paths", "a2-delta"):
        _need(outputs[name].decode().splitlines() == sorted([CHECKER, CORPUS]), "operation changed-file scope")
    staged = _loads(outputs["staged-preflight"])
    _need(staged.get("result") == "PASS" and staged.get("mode") == "--staged"
          and staged.get("remote_policy_mutated") is False, "staged preflight")
    final_index = outputs.get("materialized-index", outputs["initial-index"])
    indexed = [row for row in final_index.split(b"\0") if row]
    _need(len(indexed) == 26711 and all(row.startswith(b"H ") for row in indexed)
          and [row[2:].decode() for row in indexed] == list(git_paths), "final all-H index")
    return files, bool(set(names) & set(optional))


def validate_ci(old_root: Path, repair_root: Path, R: Path, A: str, A2: str) -> dict:
    """Validate retained receipts and Git objects only; execute no repository programs."""
    old_root, repair_root, R = Path(old_root), Path(repair_root), Path(R)
    _need(A == A_OBSERVED and type(A2) is str and HEX40.fullmatch(A2) and A2 != A,
          "reviewed commit parameters")
    _need(R.is_absolute() and R.is_dir() and not R.is_symlink() and R.resolve() == R, "Git root")
    old_manifest = _manifest(old_root, "trnm-daa-external-ci-manifest-v1", {"expected_head": A})
    new_manifest = _manifest(repair_root, "trnm-daa-ci-guard-repair-manifest-v1", {"source_A": A, "A2": A2})
    _need(_sha(_raw(old_root / "summary.json")) == OLD_SUMMARY_SHA
          and _sha(_raw(old_root / "manifest.json")) == OLD_MANIFEST_SHA, "original A receipts changed")
    treeA, _, entriesA = _tree(R, A)
    tree2, parents2, entries2 = _tree(R, A2)
    _need(parents2 == [A] and len(entriesA) == len(entries2) == 26711
          and set(entriesA) == set(entries2), "A2 ancestry/tree inventory")
    changed = sorted(path for path in entriesA if entriesA[path] != entries2[path])
    _need(changed == sorted([CHECKER, CORPUS]), "A2 is not the exact two-file delta")
    _need(all(entriesA[path][:2] == entries2[path][:2] for path in changed), "changed object modes")
    sizeA, size2 = sum(row[3] for row in entriesA.values()), sum(row[3] for row in entries2.values())
    _need(sizeA == 2542453893 and treeA == "beac87c2431d149dbd6d2de4a2e1eaf0617520cc", "original A tree/bytes")
    old_checker = _object(R, "blob", entriesA[CHECKER][2])
    new_checker = _object(R, "blob", entries2[CHECKER][2])
    _need(entriesA[CHECKER][2] == OLD_BLOB and new_checker == _approved_patch(old_checker),
          "unapproved checker logic")
    old_corpus = _object(R, "blob", entriesA[CORPUS][2])
    new_corpus = _object(R, "blob", entries2[CORPUS][2])
    pin = '"' + CHECKER + '": "' + OLD_BLOB + '"'
    _need(old_corpus.decode().count(pin) == 1, "old current pin")
    _need(new_corpus == old_corpus.decode().replace(pin, '"' + CHECKER + '": "' + entries2[CHECKER][2] + '"', 1).encode(),
          "corpus contains more than one pin change")
    _need(len(_loads(new_corpus)["pinned_blobs"]) == 915, "current corpus denominator")
    test_raw = _object(R, "blob", entriesA[TEST][2])
    _need(entriesA[TEST] == entries2[TEST], "169 test object changed")
    test_sha = _sha(test_raw)

    old_summary = _json(old_root / "summary.json")
    _keys(old_summary, {"schema", "expected_head", "started_utc", "ended_utc", "controller_sha256",
        "planned_commands", "observed_commands", "not_observed", "source_before_passed", "source_after_passed",
        "controller_error", "complete", "all_expected_outcomes_observed", "qualification", "release_ready", "records"},
        "A summary")
    _need(old_summary["schema"] == "trnm-daa-external-ci-summary-v1" and old_summary["expected_head"] == A
          and old_summary["controller_sha256"] == HELPER_SHA
          and _same(old_summary["planned_commands"], 12) and _same(old_summary["observed_commands"], 12)
          and old_summary["not_observed"] == [] and old_summary["controller_error"] is None
          and old_summary["complete"] is True and old_summary["source_before_passed"] is True
          and old_summary["source_after_passed"] is True and old_summary["all_expected_outcomes_observed"] is False
          and old_summary["qualification"] == "HOLD_NO_GO" and old_summary["release_ready"] is False, "A original outcomes")
    _interval(old_summary, "A summary")
    old_plan = _json(old_root / "plan.json")
    _keys(old_plan, {"schema", "expected_head", "source_root", "evidence_root", "controller",
        "controller_sha256", "controller_argv", "controller_cwd", "python_executable",
        "python_version", "platform", "environment_overrides", "started_utc", "gates", "scope"}, "A plan")
    _need(old_plan.get("schema") == "trnm-daa-external-ci-plan-v1"
          and old_plan.get("expected_head") == A and old_plan.get("controller_sha256") == HELPER_SHA, "A plan")
    canonical = old_plan["source_root"]
    _need(canonical == "/home/qian-qi/work/chain-daa-resource-competition-20261112-600e"
          and _same(old_plan["environment_overrides"], OVERRIDES)
          and old_plan["python_executable"] == PY, "original execution context")
    old_roster = _gate_roster(A, canonical, old=True)
    _need(_same(old_plan["gates"], old_roster), "A fixed gate roster")
    _need(old_summary["records"] == [row["name"] + "/record.json" for row in old_roster], "A record roster")
    old_rows = _verify_roster(old_root, old_roster, A, treeA, sizeA, old=True)
    expected_old = {"plan.json", "summary.json"}
    for row in old_roster:
        expected_old.update(row["name"] + "/" + name for name in ("record.json", "stdout.raw", "stderr.raw"))
    _need(set(old_manifest["files"]) == expected_old, "A exact artifact inventory")
    failed_raw = _raw(old_root / "ci-contract-negatives/stderr.raw")
    _need(len(failed_raw) == 31555 and _sha(failed_raw) == FAILED_CI_SHA, "original 169 failure raw identity")
    failure_text = failed_raw.decode()
    failures = re.findall(r"^FAIL: (.*)$", failure_text, re.M)
    _need(len(failures) == 2 and all("MergedQualificationLaneTests.test_joint_resource_commands_cannot_be_omitted_moved_or_skipped" in line
          and "mutation='duplicated in fuzz lane'" in line for line in failures), "original two subcases")
    for suite in ("test_quantum_probability_sampling.py", "test_joint_resource_competition_campaign.py"):
        _need(sum(suite in line for line in failures) == 1, "original failing suite")
    _need(failure_text.count("AssertionError: ValueError not raised") == 2, "original assertion failures")
    _need(_sha(_raw(old_root / "source-integrity-negatives/stderr.raw")) == SOURCE_NEG_SHA
          and _sha(_raw(old_root / "pq-corpus-negatives/stderr.raw")) == PQ_NEG_SHA, "A retained passing raw identities")

    summary = _json(repair_root / "summary.json")
    _keys(summary, {"schema","source_A","A2","started_utc","ended_utc","status","all_expected_outcomes_observed",
        "controller_error","scope_only_two_files","existing_169_tests_unchanged","canonical_head_after",
        "canonical_head_unchanged","common_config_sha256_before","common_config_sha256_after",
        "common_config_unchanged_during_routine","common_config_before_add_attested","development_controls",
        "validation_planned","validation_observed","validation_complete","validation_records","operation_records",
        "qualification","release_ready","native_or_formal_execution_source","canonical_source_writes_performed"}, "A2 summary")
    _need(summary["schema"] == "trnm-daa-ci-guard-repair-summary-v1" and summary["source_A"] == A
          and summary["A2"] == A2 and summary["status"] == "PASS" and summary["controller_error"] is None
          and summary["canonical_head_after"] == A and summary["qualification"] == "HOLD_NO_GO"
          and summary["native_or_formal_execution_source"] == A, "A2 summary identity")
    for key in ("all_expected_outcomes_observed","scope_only_two_files","existing_169_tests_unchanged",
                "canonical_head_unchanged","common_config_unchanged_during_routine","validation_complete"):
        _need(summary[key] is True, "A2 missing success " + key)
    for key in ("common_config_before_add_attested","release_ready","canonical_source_writes_performed"):
        _need(summary[key] is False, "A2 overclaim " + key)
    _need(_same(summary["validation_planned"], 7) and _same(summary["validation_observed"], 7), "seven complete gates")
    _interval(summary, "A2 summary")
    common_hash = summary["common_config_sha256_before"]
    _need(type(common_hash) is str and HEX64.fullmatch(common_hash)
          and common_hash == summary["common_config_sha256_after"], "common config routine scope")

    freeze = _json(repair_root / "freeze.json")
    _keys(freeze, {"schema","source_A","commit","tree","parent","scope_only_two_files","changed_files",
        "checker_before_blob","checker_after_blob","checker_before_sha256","checker_after_sha256",
        "corpus_before_sha256","corpus_after_sha256","negative_test_sha256_before","negative_test_sha256_after",
        "existing_169_tests_unchanged","development_controls_passed","common_config_sha256_before",
        "common_config_sha256_after","common_config_span","canonical_head_at_freeze","canonical_source_writes_performed",
        "native_or_formal_execution_source","frozen_utc","production_activation"}, "A2 freeze")
    _need(freeze["schema"] == "trnm-daa-ci-guard-repair-freeze-v1"
          and freeze["source_A"] == freeze["parent"] == freeze["canonical_head_at_freeze"] == A
          and freeze["commit"] == A2 and freeze["tree"] == tree2
          and freeze["changed_files"] == changed, "freeze Git identity")
    for key in ("scope_only_two_files","existing_169_tests_unchanged","development_controls_passed"):
        _need(freeze[key] is True, "freeze qualification " + key)
    _need(freeze["canonical_source_writes_performed"] is False and freeze["production_activation"] is False
          and freeze["native_or_formal_execution_source"] == A, "freeze runtime scope")
    _need(freeze["common_config_span"] == "routine only; pre-worktree-add identity was not recorded"
          and freeze["common_config_sha256_before"] == freeze["common_config_sha256_after"] == common_hash,
          "freeze common configuration overclaim")
    for key, value in (("checker_before_blob", OLD_BLOB), ("checker_after_blob", entries2[CHECKER][2]),
        ("checker_before_sha256", _sha(old_checker)), ("checker_after_sha256", _sha(new_checker)),
        ("corpus_before_sha256", _sha(old_corpus)), ("corpus_after_sha256", _sha(new_corpus)),
        ("negative_test_sha256_before", test_sha), ("negative_test_sha256_after", test_sha)):
        _need(freeze[key] == value, "freeze byte binding " + key)
    frozen_at = _time(freeze["frozen_utc"], "freeze")

    plan = _json(repair_root / "plan.json")
    _keys(plan, {"schema", "source_A", "repair_root", "canonical_root", "controller", "controller_sha256",
        "helper_sha256", "started_utc", "allowed_source_delta", "existing_tests_are_unchanged",
        "minimum_free_bytes_before_full_materialization", "development_controls", "A2_validation_gates",
        "native_or_formal_execution_source", "production_activation"}, "repair plan")
    _need(plan.get("schema") == "trnm-daa-ci-guard-repair-plan-v1" and plan.get("source_A") == A
          and plan.get("canonical_root") == canonical and plan.get("allowed_source_delta") == changed
          and plan.get("existing_tests_are_unchanged") is True and plan.get("helper_sha256") == HELPER_SHA
          and _same(plan.get("minimum_free_bytes_before_full_materialization"), MIN_FREE)
          and plan.get("production_activation") is False, "repair plan")
    cwd = plan["repair_root"]
    _need(cwd == "/home/qian-qi/work/chain-daa-resource-ci-guard-20261112-600e", "isolated repair path")
    _need(plan["development_controls"] == ["focused-new-negative-method-1", "actual-ci", "current-corpus-915"]
          and plan["native_or_formal_execution_source"] == "A only; this controller performs no native or scientific campaign",
          "repair declared scope")
    source = [PY, "-B", "scripts/ci/verify_ci_source.py", "--kind", "head", "--expected-head", A]
    dev_specs = [
        _plan_gate("preflight-before-edits", ["/bin/bash","scripts/project-preflight.sh","--audit"], cwd, check="preflight"),
        _plan_gate("source-before-repair", source, cwd, check="source"),
        _plan_gate("focused-new-negative-method", [PY,"-B",TEST,"MergedQualificationLaneTests.test_joint_resource_commands_cannot_be_omitted_moved_or_skipped","-v"], cwd, tests=1),
        _plan_gate("actual-ci", [PY,"-B",CHECKER], cwd, check="ci"),
        _plan_gate("current-corpus", [PY,"-B","scripts/ci/check_pq_research_integration.py"], cwd, check="pq")]
    _need(_same(summary["development_controls"], [{"name": row["name"],"expectation_met":True} for row in dev_specs]),
          "development roster")
    dev_rows = _verify_roster(repair_root, dev_specs, A, treeA, sizeA, prefix="development/")
    _need(all(_time(row["ended_utc"], "development") <= frozen_at for row in dev_rows.values()), "development after freeze")
    roster = _gate_roster(A2, cwd, old=False)
    _need(plan.get("A2_validation_gates") == [row["name"] for row in roster], "A2 declared roster")
    validation_plan = _json(repair_root / "validation/plan.json")
    _keys(validation_plan, {"schema","expected_head","gates","controller_sha256"}, "A2 validation plan")
    _need(validation_plan["schema"] == "trnm-daa-ci-guard-A2-validation-plan-v1"
          and validation_plan["expected_head"] == A2 and _same(validation_plan["gates"], roster)
          and validation_plan["controller_sha256"] == plan["controller_sha256"], "A2 validation plan identity")
    wanted_records = ["validation/" + row["name"] + "/record.json" for row in roster]
    _need(summary["validation_records"] == wanted_records, "A2 recorded roster")
    new_rows = _verify_roster(repair_root, roster, A2, tree2, size2, prefix="validation/")
    _need(_time(new_rows["source-before"]["started_utc"], "A2 source") >= frozen_at, "A2 validation before freeze")
    disk = _json(repair_root / "validation/disk-before-suite.json")
    _keys(disk, {"free_bytes","minimum_free_bytes","purpose","observed_utc"}, "suite disk")
    _need(type(disk["free_bytes"]) is int and disk["free_bytes"] >= MIN_FREE
          and _same(disk["minimum_free_bytes"], MIN_FREE), "suite disk guard")
    _time(disk["observed_utc"], "disk")

    op_files, materialized = _operation_records(repair_root, summary, canonical, cwd, A, A2, tree2, test_raw, entriesA)
    preconditions = _json(repair_root / "preconditions.json")
    _keys(preconditions, {"source_A", "common_config_sha256_before", "common_config_span", "free_bytes_before",
        "initial_index", "all_26711_H_physical_and_raw_A_verified"} | ({"materialized_index", "free_before_full_materialization"}
        if materialized else set()), "repair preconditions")
    _need(preconditions.get("source_A") == A
          and preconditions.get("common_config_sha256_before") == common_hash
          and preconditions.get("common_config_span") == "this repair routine after worktree add; no pre-add attestation"
          and preconditions.get("all_26711_H_physical_and_raw_A_verified") is True, "repair preconditions")
    final_index = preconditions.get("materialized_index", preconditions.get("initial_index"))
    _need(_same(final_index, {"tracked_entries":26711,"index_flags":{"H":26711},"missing_count":0,"missing_first":[]}),
          "full isolated source inventory")
    if materialized:
        _need(type(preconditions.get("free_before_full_materialization")) is int
              and preconditions["free_before_full_materialization"] >= MIN_FREE, "materialization disk guard")
    else:
        _need("materialized_index" not in preconditions and "free_before_full_materialization" not in preconditions,
              "invented materialization")
    wanted_new = {"plan.json","preconditions.json","freeze.json","summary.json",
                  "validation/plan.json","validation/disk-before-suite.json"} | op_files
    for prefix, specs in (("development/", dev_specs), ("validation/", roster)):
        for row in specs:
            wanted_new.update(prefix + row["name"] + "/" + name for name in ("record.json","stdout.raw","stderr.raw"))
    _need(set(new_manifest["files"]) == wanted_new, "A2 exact artifact inventory")
    for meta, expected_file, expected_sha in (
            (old_plan, old_root.parent / "controller-v1.py", HELPER_SHA),
            (plan, repair_root.parent / "controller-ci-repair-v1.py", plan["controller_sha256"])):
        _need(type(expected_sha) is str and HEX64.fullmatch(expected_sha)
              and meta["controller"] == str(expected_file.resolve())
              and _sha(_raw(expected_file)) == expected_sha, "controller source identity")
    return {"schema":"trnm-independent-ci-evidence-readback-v1","result":"PASS",
        "source_A":A,"source_A_tree":treeA,"source_A2":A2,"source_A2_tree":tree2,
        "A_original_ci_tests":169,"A_original_failed_subcases":2,
        "A_source_integrity_tests_passed":43,"A_pq_corpus_tests_passed":57,
        "A2_ci_tests_passed":169,"A2_validation_gates":7,"A2_current_corpus_pins":915,
        "A2_source_guard_entries":26711,"A2_source_guard_bytes":size2,
        "A2_only_changed_files":changed,"unchanged_other_tracked_objects":len(entriesA)-2,
        "existing_169_test_sha256":test_sha,"original_failure_preserved":True,
        "canonical_source_writes_performed":False,"common_config_unchanged_during_routine":True,
        "common_config_before_add_attested":False,"native_or_formal_execution_source":A,
        "repository_programs_executed_by_this_validator":False,"receipt_validation_only":True,
        "qualification":"HOLD_NO_GO","release_ready":False,
        "old_manifest_sha256":_sha(_raw(old_root/"manifest.json")),
        "repair_manifest_sha256":_sha(_raw(repair_root/"manifest.json"))}

