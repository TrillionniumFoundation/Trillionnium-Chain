# Root V6 selected prior evidence, v2

This package preserves the previous v1 archive members unchanged and adds selected originals for the failed source reconstruction and successful physical materialization repair. It is not a claim to contain all bootstrap logs.

The source commit is 92934b64f80ee9b20bcc070a08ca0966b7c5741d with tree b1882c2e46827abfd1db5f8744be043d5776df6d. The first reconstruction committed that exact tree but the original physical verifier rejected 530 skip-worktree entries. The repair materialized only those 530 missing paths, changed no existing file contents or shared Git configuration, and passed the unmodified complete verifier on 28,777 entries and 2,597,032,120 bytes. Source commit and tree stayed unchanged.

Original outer job stdout/stderr and authenticated terminal observations are included. The only removed status field is the opaque runtime launch_nonce; the original status JSON-text SHA256 is retained. Both original failed and successful job identities remain explicit.

The old cloud source-only logs and reports were lost when the cloud filesystem was replaced. complete remains false. Historical summaries are not presented as original logs. The old native 52-test result with 4 failures and 3 errors, and the fresh-native historical UNKNOWN, remain in prior-v1.

COLLECTION_SCOPE.json and FILE_MANIFEST.json define every included file and each omission. The full 886,449-byte plan source stdout, full duplicated tracked-path listings/inputs, source postimages, credentials and full environment are excluded. The 530-path actual materialization list and checkout input are retained.

The committed source mode/blob identity observation was made read-only during packaging. Its fourteen blob bytes were hashed in memory and are not archived. No ROOT source, index, original observation, test result, or running validation was modified by this packager. No Rust tests or production activation were performed.
