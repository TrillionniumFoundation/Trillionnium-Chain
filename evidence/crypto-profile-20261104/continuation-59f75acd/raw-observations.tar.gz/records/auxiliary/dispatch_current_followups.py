#!/usr/bin/env python3
"""Serial finite followups; preserve every original recorder result."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

BASE = Path('/workspace/scratch/9d99fced0bf1')
OUT = BASE / 'current-validation'
STATE = BASE / 'followup-dispatch.json'
RUNNER = BASE / 'run_current_exact.py'
state = {'started_utc': datetime.now(timezone.utc).isoformat(),
         'waits_for': 'components.json', 'steps': [], 'complete': False}
if STATE.exists():
    raise SystemExit('preserve existing dispatch')

def save():
    temporary = STATE.with_suffix('.tmp')
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    temporary.replace(STATE)

def run(label, argv):
    entry = {'label': label, 'argv': argv,
             'started_utc': datetime.now(timezone.utc).isoformat()}
    state['steps'].append(entry)
    save()
    result = subprocess.run(['python3', str(RUNNER), label, *argv], cwd=BASE)
    entry.update(exit_code=result.returncode,
                 finished_utc=datetime.now(timezone.utc).isoformat())
    save()
    print(json.dumps(entry), flush=True)
    return result.returncode

save()
while True:
    prior = json.loads((OUT / 'components.json').read_text())
    if prior.get('status') != 'running':
        state['components_terminal_status'] = prior.get('status')
        state['components_exit_code'] = prior.get('exit_code')
        save()
        break
    time.sleep(5)

preflight = run('preflight-followups', ['bash', 'scripts/project-preflight.sh'])
if preflight:
    raise SystemExit(preflight)

code = run('benchmark-build', ['cargo', 'build', '--locked', '--offline', '--release',
           '--manifest-path', 'trillionnium/Cargo.toml', '-p', 'trnm-crypto-primitives',
           '--example', 'pq_parameter_bench', '--message-format=json'])
if code == 0:
    rows = []
    for line in (OUT / 'benchmark-build.log').read_text().splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if isinstance(row, dict):
            rows.append(row)
    if [r.get('success') for r in rows if r.get('reason') == 'build-finished'] != [True]:
        raise SystemExit('missing complete successful Cargo build-finished')
    artifacts = [r for r in rows if r.get('reason') == 'compiler-artifact'
                 and r.get('target', {}).get('name') == 'pq_parameter_bench'
                 and r.get('executable')]
    if len(artifacts) != 1:
        raise SystemExit('ambiguous benchmark executable')
    artifact = artifacts[0]
    binary = Path(artifact['executable']).resolve(strict=True)
    with binary.open('rb') as stream:
        binary_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    identity = {'artifact': artifact, 'path': str(binary),
                'bytes': binary.stat().st_size, 'sha256': binary_hash,
                'build_receipt_sha256': hashlib.sha256((OUT / 'benchmark-build.json').read_bytes()).hexdigest(),
                'observed_utc': datetime.now(timezone.utc).isoformat()}
    (OUT / 'benchmark-build-artifact.json').write_text(json.dumps(identity, indent=2) + '\n')
    code = run('benchmark-run', ['python3', str(BASE / 'run_current_parameter_observation.py'), str(binary)])
    if code == 0:
        run('benchmark-reader', ['python3', 'evidence/crypto-profile-20261104/recompute_benchmark.py',
                               str(OUT / 'parameter-observations.jsonl')])
run('protocol-doc', ['cargo', 'test', '--locked', '--offline', '--manifest-path',
                    'trillionnium/Cargo.toml', '-p', 'trnm-protocol', '--doc'])
state.update(complete=True, finished_utc=datetime.now(timezone.utc).isoformat())
save()
