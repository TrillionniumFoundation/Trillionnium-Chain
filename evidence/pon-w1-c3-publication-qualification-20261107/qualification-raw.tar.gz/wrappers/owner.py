#!/usr/bin/env python3
"""Qualify an explicitly supplied clean commit; never execute ignored entries."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
RUSTUP_BIN = Path('/home/qian-qi/.cargo/bin')
NODE = 'trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2'
M12 = 'trillionnium/crates/trnm-service-settlement/src/native_generation_budget_v2'
OWNED_RUST = [NODE + '.rs', NODE + '/task_owner.rs', NODE + '/tests.rs',
              NODE + '/tests/heavy.rs', NODE + '/tests/heavy/cancellation.rs',
              NODE + '/tests/heavy/cancellation/tests.rs', M12 + '.rs', M12 + '/tests.rs']
SELECTORS = [
    'store::async_w1_generation_v2::tests::heavy::funded_fresh_full_w1_generation',
    'store::async_w1_generation_v2::tests::heavy::funded_fresh_full_w1_generation_owner_cancel_after_segment_start',
    'store::async_w1_generation_v2::tests::heavy::funded_w1_owner_cancellation_cold_reconcile',
]


RETAINED_UPSTREAM_COMMIT = 'cb314bb4656e5da4844325cd83994ab4764fe8e9'
RETAINED_TEST_GROUPS = [{'label': 'legacy-admission-root-tests', 'filter': 'store::legacy_admission_root_tests::', 'source_path': 'trillionnium/crates/trnm-pon-node/src/store/legacy_admission_root_tests.rs', 'source_bytes': 10064, 'source_sha256': 'b3c88d1838f9fb091c4cf2f87220bf2366646ff752cd44748256277d44ad5e19', 'source_git_blob': '5a04c88b1c7d6db76ccb0c773931730b7e82c565', 'selectors': ['store::legacy_admission_root_tests::ordinary_admission_final_root_rechecks_warm_active_state_and_claim']}, {'label': 'legacy-reorg-root-tests', 'filter': 'store::legacy_reorg_root_tests::', 'source_path': 'trillionnium/crates/trnm-pon-node/src/store/legacy_reorg_root_tests.rs', 'source_bytes': 14872, 'source_sha256': 'c38d076d57631d773176c6ae6ab7504bfb97aff635cde5c27753109d848c2f4b', 'source_git_blob': '86ddedea0b03e0016707b5b0a0fbc940d2472ab2', 'selectors': ['store::legacy_reorg_root_tests::legacy_reorg_root_keeps_signed_history_cursor_and_cold_publication', 'store::legacy_reorg_root_tests::legacy_reorg_root_rechecks_untouched_rows_root_claims_and_original_errors', 'store::legacy_reorg_root_tests::legacy_reorg_root_keeps_all_tail_cancellation_boundaries_and_rollback', 'store::legacy_reorg_root_tests::legacy_reorg_root_never_selects_the_growth_or_authenticated_relation', 'store::legacy_reorg_root_tests::legacy_reorg_root_preserves_pq_v2_and_v6_state_validation']}]
RETAINED_SELECTORS = [name for group in RETAINED_TEST_GROUPS for name in group['selectors']]
RETAINED_SOURCE_PATHS = ['trillionnium/crates/trnm-pon-node/src/store.rs',
                         *[group['source_path'] for group in RETAINED_TEST_GROUPS]]
OWNED_RUST += [group['source_path'] for group in RETAINED_TEST_GROUPS]
EXPECTED_COMMAND_LABELS = [
    'preflight', 'source-before', 'cargo-version', 'rustc-version',
    'locked-graph-default', 'locked-graph-all-features', 'owned-fmt',
    'm12-strict-clippy', 'node-strict-clippy', 'm12-tests', 'node-short-tests',
    'legacy-admission-root-tests', 'legacy-reorg-root-tests',
    'owner-no-run-json', 'owner-elf-list', 'source-after',
]


def require(ok, message):
    if not ok:
        raise ValueError(message)


def record(path):
    path = Path(path)
    first = path.lstat()
    require(stat.S_ISREG(first.st_mode), 'regular retained file required: ' + str(path))
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    last = path.lstat()
    keys = ('st_dev', 'st_ino', 'st_size', 'st_mode', 'st_mtime_ns', 'st_ctime_ns')
    require(all(getattr(first, key) == getattr(last, key) for key in keys), 'file changed while hashing')
    return {'path': str(path), 'bytes': first.st_size, 'sha256': digest.hexdigest()}


def save(path, value):
    path = Path(path)
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def result_count(raw, passed, ignored):
    found = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;.*$', raw, re.M)
    require(found == [('ok', str(passed), '0', str(ignored))], 'exact Rust test count/outcome required')


def stop_unreaped_group(child):
    """Only an original, still-waitable leader reserves the PGID for signaling."""
    result = {'signal_attempts': [], 'errors': [], 'all_descendants_reaped': None}
    if child.returncode is not None:
        result['state'] = 'leader-already-reaped; no saved PGID signal'
        return result
    try:
        observation = os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
        require(observation is None or observation.si_pid == child.pid, 'unexpected original child observation')
    except BaseException as exc:
        result['state'] = 'original leader ownership unknown; no signal'
        result['errors'].append(f'{type(exc).__name__}: {exc}')
        return result
    try:
        os.killpg(child.pid, signal.SIGKILL)
        result['signal_attempts'].append({'group': child.pid, 'signal': signal.SIGKILL, 'result': 'sent'})
    except ProcessLookupError:
        result['signal_attempts'].append({'group': child.pid, 'signal': signal.SIGKILL, 'result': 'group absent'})
    except BaseException as exc:
        result['errors'].append(f'{type(exc).__name__}: {exc}')
    try:
        result['returncode'] = child.wait(timeout=10)
        result['state'] = 'original child wait returned after group signal attempt'
    except BaseException as exc:
        result['state'] = 'original child completion unknown'
        result['errors'].append(f'{type(exc).__name__}: {exc}')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--tree', required=True)
    parser.add_argument('--repo', type=Path, default=ROOT / 'integration-repo')
    parser.add_argument('--target', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    require(re.fullmatch(r'[0-9a-f]{40}', args.commit) and re.fullmatch(r'[0-9a-f]{40}', args.tree),
            'real immutable commit and tree must be supplied')
    repo, target, out = args.repo, args.target, args.out
    require(all(p.is_absolute() for p in (repo, target, out)), 'absolute paths required')
    require(repo.is_dir() and target.is_dir() and out.parent.is_dir() and not out.exists(),
            'existing repository/cache and new output required')
    require(not out.is_relative_to(repo) and not target.is_relative_to(repo), 'all outputs must remain outside source')
    out.mkdir(exist_ok=False)
    env = os.environ.copy()
    excluded = []
    for key in list(env):
        if key.startswith(('RUST', 'CARGO', 'RISC0', 'GIT_', 'TRNM_W1_')) or key in ('LD_PRELOAD', 'LD_LIBRARY_PATH'):
            excluded.append(key)
            env.pop(key)
    explicit = {'PATH': str(RUSTUP_BIN) + ':/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
                'RUSTUP_TOOLCHAIN': '1.95.0', 'RUSTUP_AUTO_INSTALL': '0', 'CARGO_HOME': '/home/qian-qi/.cargo',
                'CARGO_TARGET_DIR': str(target), 'CARGO_BUILD_JOBS': '2', 'CARGO_NET_OFFLINE': 'true',
                'PYTHONDONTWRITEBYTECODE': '1', 'RAYON_NUM_THREADS': '2', 'LANG': 'C', 'LC_ALL': 'C'}
    env.update(explicit)
    manifest = {'schema': 'TRNM-W1-EXACT-OWNER-BUILD-QUALIFICATION1', 'source_commit': args.commit,
                'source_tree': args.tree, 'repo_path': str(repo), 'target': str(target),
                'fresh_cargo_target': False, 'cache_reuse_allowed': True,
                'independent_reproducible_build_established': False, 'qualification_complete': False,
                'heavy_proof_run': False, 'ignored_entries_executed': False,
                'environment': explicit, 'excluded_inherited_environment_names': sorted(excluded),
                'resource_request': {'affinity': [20, 21], 'cpu_quota_percent': 200, 'memory_max_bytes': 8589934592},
                'commands': [], 'errors': [], 'binaries': {}, 'started_monotonic_ns': time.monotonic_ns(),
                'wrapper': record(Path(__file__).resolve())}
    save(out / 'declaration.json', manifest)
    source_before_ok = False

    def run(label, argv, *, cwd=None, timeout=600):
        directory = out / 'commands' / label
        directory.mkdir(parents=True, exist_ok=False)
        selected_cwd = repo if cwd is None else cwd
        row = {'label': label, 'argv': list(map(str, argv)), 'cwd': str(selected_cwd),
               'started_monotonic_ns': time.monotonic_ns(), 'timeout_seconds': timeout,
               'exit': None, 'timed_out': False, 'error': None}
        save(directory / 'declaration.json', row)
        child = None
        try:
            with (directory / 'stdout.log').open('xb') as so, (directory / 'stderr.log').open('xb') as se:
                child = subprocess.Popen(row['argv'], cwd=selected_cwd, env=env,
                                         stdin=subprocess.DEVNULL, stdout=so, stderr=se, start_new_session=True)
                row['pid'] = child.pid
                try:
                    row['exit'] = child.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    row['timed_out'] = True
                    # The original leader has not been reaped. Kill its owned
                    # group before wait; do not signal a saved PGID after reap.
                    os.killpg(child.pid, signal.SIGKILL)
                    row['exit'] = child.wait(timeout=10)
                    row['timeout_cleanup'] = 'original process group killed before leader reap'
                so.flush(); os.fsync(so.fileno())
                se.flush(); os.fsync(se.fileno())
        except BaseException as exc:
            row['error'] = f'{type(exc).__name__}: {exc}'
            if child is not None:
                row['exception_cleanup'] = stop_unreaped_group(child)
        finally:
            row['completed_monotonic_ns'] = time.monotonic_ns()
            for name in ('stdout', 'stderr'):
                p = directory / (name + '.log')
                row[name] = record(p) if p.exists() else None
            save(directory / 'result.json', row)
            manifest['commands'].append(row)
            print(json.dumps({'label': label, 'exit': row['exit'], 'timed_out': row['timed_out'],
                              'error': row['error'], 'path': str(directory / 'result.json')}), flush=True)
        require(row['exit'] == 0 and not row['timed_out'] and row['error'] is None, label + ' failed')
        return directory

    def source(label):
        raw = out / (label + '.json')
        run(label, ['/usr/bin/python3', repo / 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                    '--expected-head', args.commit, '--output', raw], timeout=180)
        observed = json.loads(raw.read_bytes())
        require(observed['schema'] == 'trnm-ci-source-v1' and observed['kind'] == 'head'
                and observed['tested_commit'] == args.commit and observed['tested_tree'] == args.tree
                and observed['candidate'] == args.commit and observed['tracked_worktree_verified'] is True
                and observed['tests_executed_by_identity_check'] is False, 'exact raw source guard binding')
        with raw.open('rb') as stream:
            os.fsync(stream.fileno())
        return {**record(raw), 'tested_commit': observed['tested_commit'], 'tested_tree': observed['tested_tree']}

    try:
        actual_affinity = sorted(os.sched_getaffinity(0))
        require(actual_affinity == [20, 21], 'owner gate must use requested 20,21 affinity')
        membership = Path('/proc/self/cgroup').read_text().strip()
        require(membership.startswith('0::/') and '\n' not in membership, 'unambiguous own cgroup required')
        cg = Path('/sys/fs/cgroup') / membership[3:].lstrip('/')
        require('/hepta-runtime-job-' in str(cg) and str(cg).endswith('.service'), 'owned Hepta gate scope required')
        resource = {'affinity': actual_affinity, 'membership': membership, 'cgroup': str(cg),
                    'cpu_max': (cg / 'cpu.max').read_text().strip(),
                    'memory_max': (cg / 'memory.max').read_text().strip(),
                    'continuous_enforcement_qualified': False}
        quota, period = resource['cpu_max'].split()
        require(quota != 'max' and int(quota) == 2 * int(period)
                and resource['memory_max'] == '8589934592', 'actual requested owner gate limits required')
        save(out / 'resource-before.json', resource)
        manifest['resource_observation'] = record(out / 'resource-before.json')
        run('preflight', ['/bin/bash', 'scripts/project-preflight.sh', '--dev'], timeout=90)
        manifest['source_before'] = source('source-before')
        source_before_ok = True
        manifest['source_clean_before'] = True
        manifest['locks_before'] = {'trillionnium/Cargo.lock': record(repo / 'trillionnium/Cargo.lock')}
        manifest['owned_source_before'] = {name: record(repo / name) for name in OWNED_RUST}
        manifest['retained_upstream_commit'] = RETAINED_UPSTREAM_COMMIT
        manifest['retained_test_groups'] = RETAINED_TEST_GROUPS
        manifest['retained_source_before'] = {name: record(repo / name) for name in RETAINED_SOURCE_PATHS}
        for group in RETAINED_TEST_GROUPS:
            retained = manifest['retained_source_before'][group['source_path']]
            raw = (repo / group['source_path']).read_bytes()
            blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
            require(retained['bytes'] == group['source_bytes']
                    and retained['sha256'] == group['source_sha256']
                    and blob == group['source_git_blob'], 'retained tests differ from reviewed upstream blobs')
        run('cargo-version', [RUSTUP_BIN / 'cargo', '--version', '--verbose'], timeout=30)
        run('rustc-version', [RUSTUP_BIN / 'rustc', '-vV'], timeout=30)
        cargo = [str(RUSTUP_BIN / 'cargo')]
        workspace = repo / 'trillionnium'
        for label, flags in (('locked-graph-default', []), ('locked-graph-all-features', ['--all-features'])):
            directory = run(label, [*cargo, 'metadata', '--locked', '--offline', '--format-version', '1', *flags],
                            cwd=workspace, timeout=180)
            graph = json.loads((directory / 'stdout.log').read_bytes())
            require(Path(graph['workspace_root']) == workspace and graph.get('resolve', {}).get('nodes'), 'full resolved locked graph required')
            package_names = {p['name'] for p in graph['packages']}
            require({'trnm-pon-node', 'trnm-service-settlement'} <= package_names, 'owner/M12 absent from locked graph')
            save(directory / 'graph-readback.json', {'packages': len(graph['packages']),
                 'resolved_nodes': len(graph['resolve']['nodes']), 'workspace_members': graph['workspace_members'],
                 'all_features': bool(flags), 'raw_graph': record(directory / 'stdout.log')})
        run('owned-fmt', [RUSTUP_BIN / 'rustfmt', '--check', '--edition', '2021', '--config', 'skip_children=true',
                          *[repo / p for p in OWNED_RUST]], timeout=90)
        for label, package in (('m12-strict-clippy', 'trnm-service-settlement'), ('node-strict-clippy', 'trnm-pon-node')):
            run(label, [*cargo, 'clippy', '--locked', '--offline', '-p', package, '--lib', '--tests', '--', '-D', 'warnings'],
                cwd=workspace, timeout=900)
        m12 = run('m12-tests', [*cargo, 'test', '--locked', '--offline', '-p', 'trnm-service-settlement',
                               'native_generation_budget_v2', '--lib', '--', '--test-threads=1'], cwd=workspace, timeout=600)
        result_count((m12 / 'stdout.log').read_text(), 10, 0)
        node = run('node-short-tests', [*cargo, 'test', '--locked', '--offline', '-p', 'trnm-pon-node',
                                      'async_w1_generation_v2', '--lib', '--', '--test-threads=1'], cwd=workspace, timeout=1500)
        node_raw = (node / 'stdout.log').read_text()
        result_count(node_raw, 15, 3)
        ignored = re.findall(r'^test (\S+) \.\.\. ignored,.*$', node_raw, re.M)
        require(sorted(ignored) == sorted(SELECTORS), 'only the three explicit heavy/cold entries may be ignored')
        retained_counts = {}
        for group in RETAINED_TEST_GROUPS:
            checked = run(group['label'], [*cargo, 'test', '--locked', '--offline', '-p', 'trnm-pon-node',
                                          group['filter'], '--lib', '--', '--test-threads=1'],
                          cwd=workspace, timeout=600)
            retained_raw = (checked / 'stdout.log').read_text()
            result_count(retained_raw, len(group['selectors']), 0)
            observed_names = re.findall(r'^test (\S+) \.\.\. ok$', retained_raw, re.M)
            require(sorted(observed_names) == sorted(group['selectors']),
                    'retained native test names must match each reviewed selector exactly once')
            readback = {'source_commit': args.commit, 'source_tree': args.tree,
                        'upstream_commit': RETAINED_UPSTREAM_COMMIT, 'filter': group['filter'],
                        'required_exact_selectors': group['selectors'], 'observed_passed': observed_names,
                        'passed': len(observed_names), 'failed': 0, 'ignored': 0,
                        'stdout': record(checked / 'stdout.log')}
            save(checked / 'test-readback.json', readback)
            retained_counts[group['label']] = readback
        manifest['retained_test_counts'] = retained_counts
        artifact = run('owner-no-run-json', [*cargo, 'test', '--locked', '--offline', '-p', 'trnm-pon-node',
                                           '--lib', '--no-run', '--message-format=json'], cwd=workspace, timeout=600)
        candidates = [r for line in (artifact / 'stdout.log').read_text().splitlines()
                      if (r := json.loads(line)).get('reason') == 'compiler-artifact'
                      and r.get('executable') and r.get('target', {}).get('name') == 'trnm_pon_node'
                      and r.get('profile', {}).get('test') is True]
        require(len(candidates) == 1, 'exactly one actual owner test Cargo artifact required')
        row = candidates[0]
        executable = Path(row['executable'])
        require(executable.is_absolute() and executable.is_relative_to(target), 'artifact escaped explicit target')
        before_list = record(executable)
        save(out / 'owner-cargo-artifact.json', row)
        listed = run('owner-elf-list', [executable, '--list'], cwd=workspace, timeout=60)
        names = re.findall(r'^(\S+): test$', (listed / 'stdout.log').read_text(), re.M)
        require(len(names) >= 18 and all(names.count(name) == 1 for name in SELECTORS), 'three exact ELF entry names required once')
        require(all(names.count(name) == 1 for name in RETAINED_SELECTORS),
                'all six retained native test entries must occur exactly once in the actual owner ELF')
        require(record(executable) == before_list, 'owner ELF changed during listing')
        save(out / 'owner-entry-readback.json', {'actual_list_command': [str(executable), '--list'],
             'total_listed_tests': len(names), 'required_exact_selectors': SELECTORS,
             'all_three_present_once': True, 'ignored_entries_executed': False,
             'required_retained_exact_selectors': RETAINED_SELECTORS,
             'all_six_retained_present_once': True,
             'source_commit': args.commit, 'source_tree': args.tree, 'executable': before_list,
             'cargo_artifact': record(out / 'owner-cargo-artifact.json'), 'list_stdout': record(listed / 'stdout.log')})
        manifest['binaries']['owner_test'] = {**before_list, 'kind': 'repository_build',
                                              'cargo_artifact_fresh': row['fresh'],
                                              'cargo_command_executed_on_this_commit': True}
        manifest['entry_readback'] = record(out / 'owner-entry-readback.json')
        manifest['locks_after'] = {'trillionnium/Cargo.lock': record(repo / 'trillionnium/Cargo.lock')}
        manifest['owned_source_after'] = {name: record(repo / name) for name in OWNED_RUST}
        manifest['retained_source_after'] = {name: record(repo / name) for name in RETAINED_SOURCE_PATHS}
        require(manifest['retained_source_before'] == manifest['retained_source_after'],
                'retained store/test source changed')
        require(manifest['locks_before'] == manifest['locks_after'], 'locked graph changed source lock')
        require(manifest['owned_source_before'] == manifest['owned_source_after'], 'owned source changed')
        manifest['test_counts'] = {'node_passed': 15, 'node_explicit_ignored': 3, 'm12_passed': 10, 'm12_ignored': 0}
        manifest['test_counts'].update(legacy_admission_passed=1, legacy_admission_ignored=0,
                                       legacy_reorg_passed=5, legacy_reorg_ignored=0)
    except BaseException as exc:
        manifest['errors'].append(f'{type(exc).__name__}: {exc}')
    finally:
        if source_before_ok:
            try:
                manifest['source_after'] = source('source-after')
                manifest['source_clean_after'] = True
            except BaseException as exc:
                manifest['errors'].append('source-after: ' + f'{type(exc).__name__}: {exc}')
        manifest['completed_monotonic_ns'] = time.monotonic_ns()
        manifest['qualification_complete'] = (not manifest['errors'] and source_before_ok
            and manifest.get('source_clean_after') is True and 'owner_test' in manifest['binaries']
            and [r['label'] for r in manifest['commands']] == EXPECTED_COMMAND_LABELS
            and all(r['exit'] == 0 and not r['timed_out'] and r['error'] is None for r in manifest['commands']))
        save(out / 'manifest.json', manifest)
        print(json.dumps({'qualification_complete': manifest['qualification_complete'],
                          'manifest': record(out / 'manifest.json'), 'errors': manifest['errors']}), flush=True)
    return 0 if manifest['qualification_complete'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
