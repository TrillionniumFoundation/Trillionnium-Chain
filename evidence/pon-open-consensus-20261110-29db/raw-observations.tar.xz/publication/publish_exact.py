#!/usr/bin/env python3
"""Publish exact Git objects with observed-head checks, nonforce update, and readback."""
import base64
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

REPO = 'TrillionniumFoundation/Trillionnium-Chain'
BRANCH = 'fix/chain-pon-native-boundaries-20261110-02769a'
API = 'repos/' + REPO
ALLOWED_PREFIXES = ('config/', 'docs/', 'scripts/', 'formal/', 'trillionnium/',
                    'evidence/', 'examples/')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def api(method, path, body=None):
    argv = ['gh', 'api', '--hostname', 'github.com', '--method', method, path]
    if body is not None:
        argv += ['--input', '-']
    result = subprocess.run(argv, input=None if body is None else json.dumps(body).encode(),
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    if result.returncode:
        raise RuntimeError('GitHub request failed: ' + method + ' ' + path
                           + '; exit=' + str(result.returncode)
                           + '; detail=' + result.stderr.decode(errors='replace')[:1000])
    return json.loads(result.stdout)


def git_hash(kind, raw):
    return hashlib.sha1(kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def identity_line(kind, person):
    date = datetime.datetime.fromisoformat(person['date'].replace('Z', '+00:00'))
    require(date.utcoffset() == datetime.timedelta(0), 'commit identity date must be UTC')
    require(not any(c in person['name'] + person['email'] for c in '\r\n'),
            'commit identity must not contain line breaks')
    return f"{kind} {person['name']} <{person['email']}> {int(date.timestamp())} +0000\n"


def main():
    path, expected_digest, receipt_path = sys.argv[1:]
    compressed = Path(path).read_bytes()
    require(hashlib.sha256(compressed).hexdigest() == expected_digest,
            'payload digest differs from reviewed digest')
    payload = json.loads(gzip.decompress(compressed))
    require(payload['schema'] == 'pon-exact-continuation-publication-v1',
            'unsupported publication schema')
    require(payload['repository'] == REPO and payload['branch'] == BRANCH,
            'publication repository or branch differs from reviewed destination')
    expected = payload['expected_remote']
    commits = payload['commits']
    require(commits and len(commits) <= 16, 'publication requires 1 to 16 commits')
    for commit in commits:
        require(commit['parent'] == expected, 'publication commits are not a linear continuation')
        for key in ('commit', 'tree', 'parent', 'parent_tree'):
            require(re.fullmatch('[a-f0-9]{40}', commit[key]), 'invalid object ID: ' + key)
        raw = (f"tree {commit['tree']}\nparent {commit['parent']}\n"
               + identity_line('author', commit['author'])
               + identity_line('committer', commit['committer'])
               + '\n' + commit['message']).encode()
        require(git_hash('commit', raw) == commit['commit'],
                'commit bytes differ from reviewed object ID')
        paths = set()
        for entry in commit['entries']:
            name = entry['path']
            require(name not in paths and not name.startswith('/') and '..' not in Path(name).parts,
                    'duplicate or unsafe publication path: ' + name)
            require(name.startswith(ALLOWED_PREFIXES), 'publication path outside reviewed roots: ' + name)
            require(entry['mode'] in ('100644', '100755') and entry['type'] == 'blob',
                    'unsupported publication entry mode or type: ' + name)
            require(git_hash('blob', base64.b64decode(entry['data_base64'], validate=True)) == entry['sha'],
                    'blob bytes differ from reviewed object ID: ' + name)
            paths.add(name)
        expected = commit['commit']

    receipt = Path(receipt_path)
    state = {'schema': 'pon-exact-continuation-publication-receipt-v1',
             'repository': REPO, 'branch': BRANCH, 'payload_sha256': expected_digest,
             'expected_remote': payload['expected_remote'], 'intended_head': expected,
             'events': [], 'status': 'STARTED'}
    if receipt.exists():
        old = json.loads(receipt.read_text())
        require(old['payload_sha256'] == expected_digest, 'receipt belongs to a different payload')
        state['events'] = old['events']

    def record(kind, **facts):
        state['events'].append({'kind': kind, **facts})
        pending = receipt.with_suffix('.pending')
        pending.write_text(json.dumps(state, indent=2) + '\n')
        pending.replace(receipt)
        print(json.dumps({'kind': kind, **facts}), flush=True)

    try:
        require(api('GET', 'user')['login'] == 'ProfHepta',
                'authenticated GitHub identity is not ProfHepta')
        current = api('GET', API + '/git/ref/heads/' + BRANCH)['object']['sha']
        require(current in (payload['expected_remote'], expected),
                'remote branch changed; review before retry')
        record('authorization-and-observed-head-check', login='ProfHepta', observed_head=current)
        for commit in commits:
            parent = api('GET', API + '/git/commits/' + commit['parent'])
            require(parent['tree']['sha'] == commit['parent_tree'],
                    'remote parent tree differs from reviewed parent tree')
            entries = []
            for entry in commit['entries']:
                blob = api('POST', API + '/git/blobs', {'encoding': 'base64', 'content': entry['data_base64']})
                require(blob['sha'] == entry['sha'], 'created blob differs from reviewed source')
                entries.append({key: entry[key] for key in ('path', 'mode', 'type', 'sha')})
            tree = api('POST', API + '/git/trees', {'base_tree': commit['parent_tree'], 'tree': entries})
            require(tree['sha'] == commit['tree'], 'created tree differs from reviewed source')
            created = api('POST', API + '/git/commits', {
                'message': commit['message'], 'tree': commit['tree'], 'parents': [commit['parent']],
                'author': commit['author'], 'committer': commit['committer']})
            require(created['sha'] == commit['commit'], 'created commit differs from reviewed source')
            record('exact-commit-created', commit=created['sha'], tree=tree['sha'], files=len(entries))
        current = api('GET', API + '/git/ref/heads/' + BRANCH)['object']['sha']
        require(current in (payload['expected_remote'], expected),
                'concurrent branch update; no ref mutation')
        if current != expected:
            # These reads are observations, not an atomic expected-head comparison.
            # A racing divergent update is protected by the server's nonforce check.
            api('PATCH', API + '/git/refs/heads/' + BRANCH, {'sha': expected, 'force': False})
        readback = api('GET', API + '/git/ref/heads/' + BRANCH)['object']['sha']
        require(readback == expected, 'branch readback differs from reviewed intended head')
        state['status'] = 'PUBLISHED_AND_READ_BACK'
        record('branch-readback', commit=readback)
    except Exception as error:
        state['status'] = 'FAILED_OR_INCOMPLETE'
        record('failure', error=str(error))
        raise


if __name__ == '__main__':
    main()
