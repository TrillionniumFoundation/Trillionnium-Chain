from pathlib import Path
from urllib.parse import unquote,urlsplit
import json,subprocess,re,sys,time,resource,hashlib,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'source-link-input-restore-20';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);(out/'preparation-errors.json').write_text(json.dumps([{'stage':'controller JavaScript compilation before any native tool invocation','error':'SyntaxError: Unexpected string','cause':'Markdown fence literal in JavaScript raw template','native_process_started':False,'native_cost':None}])+'\n');head='e8b0ec93ab6a6a1ff5e36cfcf9d1179e030a5975';res={'schema':'chain-original-git-markdown-link-input-restore-v1','head':head,'restored':[],'waves':[],'complete':False};start=time.monotonic();c0=resource.getrusage(resource.RUSAGE_CHILDREN)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()==head
 diff=subprocess.check_output(['git','diff','HEAD'],cwd=src);res['unchanged_working_diff_sha256']=sha(diff)
 with (out/'preflight.log').open('xb') as f:assert subprocess.call(['bash','scripts/project-preflight.sh'],cwd=src,stdout=f,stderr=subprocess.STDOUT)==0
 entries=subprocess.check_output(['git','ls-tree','-rz',head],cwd=src).split(b'\0');tracked={}
 for entry in entries:
  if entry:
   meta,path=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();tracked[path.decode()]={'mode':mode,'kind':kind,'oid':oid}
 for wave in range(40):
  missing={}
  for path in src.rglob('*.md'):
   if any(x in {'.git','target','__pycache__','.pytest_cache','node_modules'} for x in path.relative_to(src).parts):continue
   assert not path.is_symlink()
   text=re.sub(r'^'+chr(96)*3+r'[^\n]*\n.*?^'+chr(96)*3+r'[^\n]*$', '',path.read_text(),flags=re.M|re.S)
   for target in re.findall(r'\[[^\]]*\]\(([^\s)]+)\)',text):
    u=urlsplit(target.strip('<>'))
    if u.scheme or u.netloc or not u.path:continue
    resolved=(path.parent/unquote(u.path)).resolve();assert resolved.is_relative_to(src),str(path)+target
    if not resolved.exists():missing.setdefault(str(resolved.relative_to(src)),[]).append({'source':str(path.relative_to(src)),'target':target})
  res['waves'].append({'wave':wave,'missing':missing});save()
  if not missing:break
  requested=set()
  for name in missing:
   if name in tracked:requested.add(name)
   else:
    children=[p for p in tracked if p.startswith(name+'/')]
    assert children,'missing in frozen Git: '+name
    preferred=[p for p in children if Path(p).name=='README.md'];requested.add(sorted(preferred or children)[0])
  for name in sorted(requested):
   entry=tracked[name];assert entry['mode'] in ('100644','100755') and entry['kind']=='blob'
   path=src/name
   if path.exists():continue
   raw=subprocess.check_output(['git','show',head+':'+name],cwd=src);assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==entry['oid']
   path.parent.mkdir(parents=True,exist_ok=True)
   with path.open('xb') as f:f.write(raw)
   path.chmod(0o755 if entry['mode']=='100755' else 0o644)
   res['restored'].append({'path':name,'bytes':len(raw),'sha256':sha(raw),'git_blob':entry['oid']});save()
   if len(res['restored'])%20==0:print(json.dumps({'wave':wave,'exact_original_git_files_restored':len(res['restored'])}),flush=True)
 else:raise RuntimeError('dependency observation wave bound reached')
 assert subprocess.check_output(['git','diff','HEAD'],cwd=src)==diff
 c=resource.getrusage(resource.RUSAGE_CHILDREN);res.update(complete=True,wall_seconds=time.monotonic()-start,child_user_cpu_seconds=c.ru_utime-c0.ru_utime,child_system_cpu_seconds=c.ru_stime-c0.ru_stime);save();print(json.dumps({'complete':True,'restored':len(res['restored']),'bytes':sum(x['bytes'] for x in res['restored']),'wall_seconds':res['wall_seconds']}),flush=True)
except BaseException as e:res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
