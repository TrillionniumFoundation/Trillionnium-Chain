#!/usr/bin/env python3
"""External observation owner for the frozen B scoped verification only."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path('/workspace/scratch/e4648d82092d/chain')
OUT = Path('/workspace/scratch/e4648d82092d/verification/scoped-b-resumed')
EXPECTED = '523a4f431b65f8a52128962f5880c4030e3e05db'
ROSTER = 'ee2b11492a362bd4be2f2df4e7ad691f4dd8a78cd9df884979cb3409e117745f'
BEFORE = Path('/workspace/scratch/e4648d82092d/verification/committed-b/source-before.json')
BEFORE_SHA = '68b23e7425686170f9190f09949809ec34650f4ad2025a1d47ea1062b26c6043'
EVIDENCE = ROOT / 'evidence/pon-quantum-lifetime-20261111-e464'
sys.path.insert(0, str(ROOT / 'scripts/ci'))
import ci_observation


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return ci_observation.digest(path)


def create_json(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def unique(items):
    value = {}
    for key, item in items:
        if key in value:
            raise ValueError('duplicate JSON key')
        value[key] = item
    return value


def bad_constant(value):
    raise ValueError('nonfinite JSON constant: ' + value)


DECODER = json.JSONDecoder(object_pairs_hook=unique, parse_constant=bad_constant)


def decode(raw):
    text = raw.decode('utf-8').strip()
    value, end = DECODER.raw_decode(text)
    if text[end:].strip():
        raise ValueError('trailing non-JSON output')
    return value


def git_guard():
    commands = [
        ['git', '--no-replace-objects', 'rev-parse', 'HEAD'],
        ['git', '--no-replace-objects', 'diff', '--no-ext-diff', '--quiet'],
        ['git', '--no-replace-objects', 'diff', '--cached', '--no-ext-diff', '--quiet'],
        ['git', '--no-replace-objects', 'status', '--porcelain=v1', '--untracked-files=all'],
    ]
    records = []
    for command in commands:
        p = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        records.append({'command': command, 'exit_code': p.returncode,
                        'stdout': p.stdout, 'stderr': p.stderr})
    valid = (all(r['exit_code'] == 0 for r in records)
             and records[0]['stdout'].strip() == EXPECTED
             and records[3]['stdout'] == '')
    return {'at_utc': now(), 'matches_expected_head_and_clean_index_status': valid,
            'full_physical_source_verification': False, 'commands': records}


def report_comparison(raw, reference):
    actual = decode(raw)
    expected = decode(reference.read_bytes())
    return {
        'reference': str(reference.relative_to(ROOT)),
        'reference_file_sha256': sha(reference),
        'full_canonical_json_equal': canonical(actual) == canonical(expected),
        'actual_canonical_sha256': hashlib.sha256(canonical(actual)).hexdigest(),
        'reference_canonical_sha256': hashlib.sha256(canonical(expected)).hexdigest(),
    }


def run_one(label, command, *, expected_exit=0, expected_count=None,
            report=None, refusal=None, kind='unittest'):
    before = git_guard()
    if not before['matches_expected_head_and_clean_index_status']:
        raise RuntimeError('refuse changed source before ' + label)
    log = OUT / (label + '.log')
    started = now()
    observation = ci_observation.run(command, log, timeout=900, env=ENV,
                                     cwd=ROOT, expected_source=None)
    after = git_guard()
    raw = log.read_bytes()
    text = raw.decode('utf-8', errors='replace')
    summaries = re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$', text, re.MULTILINE)
    record = {
        'label': label, 'kind': kind, 'started_at_utc': started, 'finished_at_utc': now(),
        'expected_source': EXPECTED,
        'source_ownership': 'Shared full physical source-before/source-after are owned by parent; this command uses HEAD/index/status checks and ci_observation.run(expected_source=None).',
        'full_physical_source_before': str(BEFORE), 'full_physical_source_before_sha256': BEFORE_SHA,
        'head_index_status_before': before, 'head_index_status_after': after,
        'observation': observation,
        'log_bytes': len(raw), 'log_sha256': sha(log),
        'expected_exit_code': expected_exit,
        'exit_expectation_matches': observation['exit_code'] == expected_exit,
        'actual_process_succeeded': observation['process_exit_code'] == 0,
        'unittest_summaries': [{'tests_run': int(n), 'seconds': float(t)} for n, t in summaries],
        'unittest_tests_run': sum(int(n) for n, _ in summaries) if summaries else None,
        'observed_method_failure_lines': [line for line in text.splitlines() if line.endswith(' ... FAIL')],
        'observed_method_error_lines': [line for line in text.splitlines() if line.endswith(' ... ERROR')],
        'observed_skip_lines': [line for line in text.splitlines() if ' ... skipped ' in line],
        'expected_test_count': expected_count,
    }
    checks = [record['exit_expectation_matches'], not observation['timed_out'],
              after['matches_expected_head_and_clean_index_status']]
    if expected_count is not None:
        record['test_count_expectation_matches'] = record['unittest_tests_run'] == expected_count
        checks.append(record['test_count_expectation_matches'])
    try:
        if report is not None and refusal is None:
            record['report_comparison'] = report_comparison(raw, report)
            checks.append(record['report_comparison']['full_canonical_json_equal'])
        if refusal is not None:
            content = text.lstrip()
            value, end = DECODER.raw_decode(content)
            tail = content[end:].strip()
            expected_report = decode(report.read_bytes())
            same = canonical(value) == canonical(expected_report)
            record['refusal_full_report_equal'] = same
            checks.append(same)
            if refusal == 'current':
                diagnostic = decode(tail.encode())
                match = (diagnostic.get('status') == 'REFUSE'
                         and diagnostic.get('reason') == 'selected proof profile is not eligible for current use'
                         and diagnostic.get('current_proof_use_eligible') is False
                         and diagnostic.get('whole_chain_pq_qualified') is False)
                record['refusal_diagnostic'] = diagnostic
            else:
                match = tail == 'REFUSED_UNPROVED_NATIVE_QUANTUM_SECURITY'
                record['refusal_diagnostic'] = tail
            record['refusal_diagnostic_matches'] = match
            checks.append(match)
        if kind in ('qrom-run', 'qrom-check'):
            named = decode((OUT / 'qrom/named-controls.json').read_bytes())
            record['qrom_named_completion_sha256'] = sha(OUT / 'qrom/named-controls.json')
            record['qrom_required_tests'] = named['required_tests']
            record['qrom_roster_sha256'] = named['roster_sha256']
            record['qrom_started_tests'] = sum(len(s['started_ids']) for s in named['suites'])
            record['qrom_success_tests'] = sum(len(s['success_ids']) for s in named['suites'])
            record['qrom_qualification'] = named['qualification']
            checks.append(named['required_tests'] == 105 and named['roster_sha256'] == ROSTER
                          and record['qrom_started_tests'] == record['qrom_success_tests'] == 105)
    except (OSError, ValueError, KeyError, TypeError) as error:
        record['inspection_error'] = type(error).__name__ + ': ' + str(error)
        checks.append(False)
    record['all_declared_expectations_match'] = all(checks)
    create_json(OUT / (label + '.json'), record)
    RECORDS.append(record)
    print(json.dumps({'label': label, 'exit_code': observation['exit_code'],
                      'expected_exit_code': expected_exit,
                      'tests_run': record['unittest_tests_run'],
                      'expectations_match': record['all_declared_expectations_match'],
                      'elapsed_seconds': observation['elapsed_ns'] / 1e9}), flush=True)
    if not after['matches_expected_head_and_clean_index_status']:
        raise RuntimeError('source changed after ' + label)


assert sha(BEFORE) == BEFORE_SHA
physical_before = decode(BEFORE.read_bytes())
assert physical_before['tested_commit'] == EXPECTED
assert physical_before['tracked_worktree_verified'] is True
assert git_guard()['matches_expected_head_and_clean_index_status']
OUT.mkdir(exist_ok=False)
(OUT / 'qrom').mkdir()
ENV = dict(os.environ)
ENV['PYTHONDONTWRITEBYTECODE'] = '1'
ENV['PYTHONUNBUFFERED'] = '1'
RECORDS = []
started_at = now()
PYTHON = sys.executable
formal_tests = sorted((ROOT / 'formal/pon-nakamoto-v1').glob('test_quantum*.py'))
assert len(formal_tests) == 7
formal_tests += [ROOT / 'formal/pon-nakamoto-v1' / name for name in (
    'test_w1_quantum_oracle.py', 'test_w1_marked_domain.py', 'test_w1_quantum_restricted_oracle.py')]
PRIOR = Path('/workspace/scratch/e4648d82092d/verification/scoped-b')
INTERRUPTION = decode((PRIOR / 'interruption-observation.json').read_bytes())
number = 11
fatal = None
try:
    for name, count in (('test_pq_proof_profile_binding.py', 31),
                        ('test_w1_lifetime_ledger.py', 19)):
        number += 1
        run_one(f'{number:02d}-{Path(name).stem}',
                [PYTHON, 'scripts/ci/' + name, '-v'], expected_count=count)
    for mode in ('run', 'check'):
        number += 1
        run_one(f'{number:02d}-qrom-{mode}',
                [PYTHON, 'scripts/ci/w1_qrom_closure_controls.py', mode,
                 '--roster-sha256', ROSTER, '--output', str(OUT / 'qrom')],
                expected_count=105 if mode == 'run' else None, kind='qrom-' + mode)
    report_commands = [
        ('lifetime', [PYTHON, 'scripts/w1_lifetime_ledger.py', '--input', str(EVIDENCE / 'lifetime-input.json')], 'lifetime-report.json'),
        ('upstream', [PYTHON, 'scripts/ci/w1_upstream_security.py'], 'upstream-security-report.json'),
        ('binding', [PYTHON, 'scripts/ci/pq_proof_profile_binding.py'], 'proof-profile-binding-report.json'),
        ('persistent', [PYTHON, 'formal/pon-nakamoto-v1/quantum_posterior_policy.py', '--request', str(EVIDENCE / 'persistent-request.json')], 'persistent-report.json'),
        ('refresh', [PYTHON, 'formal/pon-nakamoto-v1/quantum_posterior_policy.py', '--request', str(EVIDENCE / 'refresh-request.json')], 'refresh-report.json'),
    ]
    for label, command, reference in report_commands:
        number += 1
        run_one(f'{number:02d}-replay-{label}', command, report=EVIDENCE / reference, kind='report-replay')
    for name in ('persistent', 'refresh'):
        number += 1
        run_one(f'{number:02d}-verify-{name}',
                [PYTHON, 'formal/pon-nakamoto-v1/quantum_posterior_policy.py',
                 '--request', str(EVIDENCE / (name + '-request.json')),
                 '--verify', str(EVIDENCE / (name + '-report.json'))],
                report=EVIDENCE / (name + '-report.json'), kind='posterior-verify')
    for name, script, reference in (
        ('upstream', 'scripts/ci/w1_upstream_security.py', 'upstream-security-report.json'),
        ('binding', 'scripts/ci/pq_proof_profile_binding.py', 'proof-profile-binding-report.json')):
        number += 1
        run_one(f'{number:02d}-require-current-{name}', [PYTHON, script, '--require-current'],
                expected_exit=2, report=EVIDENCE / reference, refusal='current', kind='expected-refusal')
    number += 1
    run_one(f'{number:02d}-require-qualified-posterior',
            [PYTHON, 'formal/pon-nakamoto-v1/quantum_posterior_policy.py',
             '--request', str(EVIDENCE / 'refresh-request.json'),
             '--verify', str(EVIDENCE / 'refresh-report.json'), '--require-qualified'],
            expected_exit=3, report=EVIDENCE / 'refresh-report.json', refusal='qualified',
            kind='expected-refusal')
except BaseException as error:
    fatal = type(error).__name__ + ': ' + str(error)
    print(json.dumps({'fatal': fatal}), flush=True)
finally:
    final_guard = git_guard()
    prior_now = {str(p.relative_to(PRIOR)): sha(p) for p in sorted(PRIOR.rglob('*'))
                 if p.is_file() and p.name != 'interruption-observation.json'}
    prior_unchanged = prior_now == INTERRUPTION['original_artifact_sha256']
    summary = {
        'schema': 'trnm-scoped-committed-b-observation-v1',
        'started_at_utc': started_at, 'finished_at_utc': now(),
        'expected_source': EXPECTED, 'source_before': physical_before,
        'source_before_path': str(BEFORE), 'source_before_sha256': BEFORE_SHA,
        'source_after_owned_by_parent': True,
        'individual_commands_full_source_verified': False,
        'final_head_index_status': final_guard,
        'runner_sha256': sha(Path(__file__)),
        'ci_observation_sha256': sha(ROOT / 'scripts/ci/ci_observation.py'),
        'environment_overrides': {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUNBUFFERED': '1'},
        'fatal': fatal, 'planned_commands': 14, 'completed_commands': len(RECORDS),
        'prior_interruption': INTERRUPTION,
        'prior_interruption_sha256': sha(PRIOR / 'interruption-observation.json'),
        'prior_artifacts_unchanged': prior_unchanged,
        'prior_completed_unittest_tests': 222,
        'combined_completed_commands_excluding_interrupted_attempt': 11 + len(RECORDS),
        'independent_unittest_tests_run': sum(r['unittest_tests_run'] or 0 for r in RECORDS if r['kind'] == 'unittest'),
        'fixed_qrom_roster': {'sha256': ROSTER, 'required_tests': 105,
                            'overlap_note': 'The QROM roster repeats the 19 lifetime-ledger tests already executed independently; counts are executions, not unique tests.'},
        'zero_exit_commands': sum(r['observation']['exit_code'] == 0 for r in RECORDS),
        'nonzero_commands': [{'label': r['label'], 'exit_code': r['observation']['exit_code'],
                              'expected_exit_code': r['expected_exit_code'],
                              'expectation_matches': r['all_declared_expectations_match']}
                             for r in RECORDS if r['observation']['exit_code'] != 0],
        'all_declared_expectations_match': fatal is None and len(RECORDS) == 14 and prior_unchanged
            and all(r['all_declared_expectations_match'] for r in RECORDS)
            and final_guard['matches_expected_head_and_clean_index_status'],
        'commands': RECORDS,
        'artifact_sha256': {str(p.relative_to(OUT)): sha(p) for p in sorted(OUT.rglob('*')) if p.is_file()},
        'scope': {'quantum_hardware_executed': False, 'physical_error_calibration': False,
                  'all_algorithm_attacker_cost_bound': False, 'whole_chain_pq_qualified': False,
                  'production_activation': False},
    }
    create_json(OUT / 'manifest.json', summary)
    print(json.dumps({k: summary[k] for k in ('completed_commands', 'independent_unittest_tests_run',
                     'zero_exit_commands', 'nonzero_commands', 'all_declared_expectations_match', 'fatal')},
                     sort_keys=True), flush=True)
sys.exit(0 if summary['all_declared_expectations_match'] else 1)
