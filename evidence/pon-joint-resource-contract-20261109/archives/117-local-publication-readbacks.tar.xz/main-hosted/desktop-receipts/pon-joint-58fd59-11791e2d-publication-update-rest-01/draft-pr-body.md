## Why

This continuation addresses three concrete gaps on #821 that affect the joint PoN source, clock and resource contract:

1. The W1 cost experiments retained completed-search or completed-cohort receipts only after the work. An interrupted attempt or failed cohort could disappear from the retained lifecycle.
2. A mandatory Host resource callback could finish after the original deadline, allowing the next History owner action to start with an expired budget.
3. Public PGH2 admission checked the target against the current time, but final activation used the unobserved History API. A currently eligible target can retain an ancestor that is ineligible under the fresh clock.

## Changes

- **Stream the W1 lifecycle.** Add the separately named native V4 observer and strict reader. Setup, preparation, search, each attempt and both full verifiers have flushed lifecycle boundaries. Missing completion remains unknown. A canonical digest and count bind all observed trials across producer arms, including losing trials. V2/V3 selectors, signed domains and record meanings remain intact.
- **Keep the original History deadline.** Recheck the same absolute deadline after the mandatory Host callback and before returning authority to the owner action. Preserve the callback's original failure priority, mandatory resource observations and durable-work accounting.
- **Bind public activation to the current clock.** Use the existing observed-history activation API with a fresh current time for both newly admitted and exactly duplicated PGH2 packets. Full verification remains charged, and a duplicate cannot manufacture a second W1 completion.

Focused regressions, CI contract entries, exact-source inventory and PQ source pins accompany these changes. The follow-up commit scopes the intentional retained-wrapper dead-code allowances and uses an equivalent mutable-enumeration loop.

## Exact stacked source

| Identity | Value |
| --- | --- |
| Base | #821 — `fix/chain-six-full-d9fb-20261108` |
| Base commit | `e798d7125724d4b9f98c24d00cc80031f2eab4a9` |
| Implementation | `11791e2da79b69322271be2cffe03725165151d1` |
| Implementation tree | `162552848110fda532504b78865a16930bc6d9bb` |
| Retained implementation parent | `fc5c44ca91c56e77ca2ffc9943e10f0f777a5937` |

The desktop bare repository is an object transport. Preflight, builds and runtime observations use the complete implementation checkout.

## Validation on the final implementation

**Draft / HOLD / NO-GO.** Local results below belong to `11791e2da79b69322271be2cffe03725165151d1` / tree `162552848110fda532504b78865a16930bc6d9bb`.

| Check | Observed result |
| --- | --- |
| Complete source preflight and clean checkout | PASS; 26,124 entries / 2,485,379,627 bytes |
| Independent static matrix | 15/15 commands PASS; six Python suites ran 342 named tests; all 15 source-before/source-after pairs match |
| Locked/offline Cargo graph, formatting, source inventory, links and corpus pins | PASS within that static matrix; qualification flags remain unchanged |
| Retained native example tests | V2: 10 PASS; V3: 9 PASS; V4: 11 PASS |
| Strict Clippy | PASS: `cargo clippy --workspace --all-targets --all-features --locked --offline -- -D warnings` |
| Complete native V4 observation | Process exit 0; reader exit 0 |
| Real terminated-process V4 control | SIGTERM exit -15; reader exit 3; incomplete, unfinished cost null, consensus credit 0 |
| Native library tests on ai395 | Running; no passing final-source library result claimed |

The complete V4 run retained **23,069 records, 936 cohorts, 1,888 searches, 3,848 completed attempts, 3,776 full-verifier calls and 288 candidate records**. Source-before/source-after identities match. Removing only the three declared timing fields yields the same 23,069-record semantic stream as the historical `fc5c44ca` observation. This is a diagnostic consistency result, not a universal cost lower bound.

### Hosted snapshot

Snapshot time: **2026-11-09 03:09:52 UTC**. Each run below is bound to head `11791e2d`; source receipts still distinguish the head and prospective-merge lanes.

| Workflow | Run | Status / conclusion |
| --- | --- | --- |
| Original native campaign | [42553751914](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553751914) | completed / failure; 1 non-success jobs observed |
| Work and time contract V1 | [42553751985](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553751985) | completed / success |
| Required baseline | [42553751938](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553751938) | in_progress / pending; 6 non-success jobs observed |
| W1 QROM implementation | [42553751987](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553751987) | completed / failure; 2 non-success jobs observed |

Observed unsuccessful jobs:

- Original native campaign: **original native campaign (x64, head, release)** — failure.
- Required baseline: **cross-arch-cost (arm64)** — failure.
- Required baseline: **cross-arch-cost (x64)** — failure.
- Required baseline: **protocol-contract** — failure.
- Required baseline: **external-evidence-contract** — failure.
- Required baseline: **prospective-merge (external-evidence-contract)** — failure.
- Required baseline: **prospective-merge (protocol-contract)** — failure.
- W1 QROM implementation: **W1 QROM implementation (head, x64)** — failure.
- W1 QROM implementation: **W1 QROM implementation (prospective-merge, x64)** — failure.

The head and prospective-merge QROM lanes retain a real `INPUT_REJECTED` from the historical fixed-source pin (`main.rs`: 9,233 expected bytes versus 11,172 actual bytes). The measured source, guard, contract, workflow and related tests are unchanged from base `e798d712`; the current-source observer retains the same refusal. The later scope-report steps were skipped.

A hosted failure remains a failure while attribution is in progress. A passing workflow whose name contains “security” does not establish a security theorem or production qualification.

### Retained unsuccessful observations

Two local native library test attempts ended via **SIGKILL; the cause is unknown**. Historical `fc5c44ca` strict Clippy reported three diagnostics, addressed by the final commit. Final-source Clippy also retained an **ENOSPC** attempt before the same command and flags passed after cache cleanup. These observations remain separate from their successful successors.

The original #821 campaign retained **0/3 confirmations**. This continuation has not closed those failures. Exact-source runtime receipts and hosted artifacts will be added separately, retaining all original outcomes.

## Resource and qualification boundaries

The original 0.25-core / 2-GiB RAM / zero-swap / 256-PID contract, four-second / 16-hostile service case, three-run campaign, full History, capacity/churn and independent-confirmation criteria remain intact. The additional current-clock walk is O(history depth) and belongs in the original end-to-end budget.

The V4 diagnostic target has ideal terminal-hash density **one half**. It does not fill MU1's **one-sixteenth** experiment or any of its **16 unknown classical/quantum cost points**. Missing finishes remain unknown; timing scopes overlap and are not additive; no observer event adds consensus credit.

These changes do not establish an all-legal-algorithm cost lower bound, joint timestamp/DAA/cumulative-credit security, or a positive honest-service floor under the declared adversary. Qualification and activation remain false or unknown. This draft does not authorize merge or activation.

## Review references

- [Joint source, clock and resource contract](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/11791e2da79b69322271be2cffe03725165151d1/docs/research/PON_JOINT_RESOURCE_CONTRACT_20261108.md)
- [V4 lifecycle observation contract](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/11791e2da79b69322271be2cffe03725165151d1/docs/research/PON_W1_LIFECYCLE_COST_V4.md)