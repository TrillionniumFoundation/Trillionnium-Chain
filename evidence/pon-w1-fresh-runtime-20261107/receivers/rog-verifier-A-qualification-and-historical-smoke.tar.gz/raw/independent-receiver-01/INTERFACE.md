# Independent ROG receipt receiver

This is an external research harness. It does not modify canonical source A,
generate proofs, search for a nonce, call a provider, dispatch funding, authorize
payment, or admit a block. Root alone starts an actual receive operation.

## Fixed independent statement authority

ROG repository: `/home/qian-qi/work/chain-w1-funded-owner-20261107-r01/repo`.
Required source A is commit `d3037ca5dfb6f301757c159b7888dca9b0317be0`, tree
`d4a8f84cdc896b9454ce0d03a164f8916e6afdf9`.

The receiver always passes this pre-existing local file to its independently
built SDK 3.0.6 verifier:

```text
/home/qian-qi/work/chain-w1-funded-owner-20261107-r01/prepared-inputs/expected-artifacts.bin
```

It must be exactly 64 bytes, SHA256
`802adcdd951cfb4cd7271df22c3bca6af66fee9f40454c74f8b5ff2c98a1b683`.
The independently retained prepared-input manifest must have SHA256
`ff209bd2845671b6d52f8c68599e4cf9e3f06ccfb54c3285efe67a3a956cf718`.
These expectations never come from receipt contents or transferred artifacts.

The fixed verifier profile is `trnm-w1-risc0-3.0.6-poseidon2-join-v2`, with the
actual image ID array
`[1958252411,3287394615,1805488136,1516578702,78549041,790278610,301018785,4279049364]`.

## ROG qualification, after root announces A is pushed

No source fetch, checkout or build is authorized by preparing this file alone.
After root's explicit pushed-A notification, use normal Git fetch and the real
clean ROG checkout of A. Build the standalone verifier with actual locked Cargo
release invocation, record Cargo's executable artifact and cache flag, and retain
real source-before/source-after reports. Do not describe a cache-assisted build
as independent byte-for-byte reproducibility.

The resulting caller-pinned qualification has schema
`TRNM-W1-ROG-VERIFIER-QUALIFICATION1`, with:

- `qualification_complete: true`, `repo_path`, fixed `source_commit/source_tree`;
- `source_clean_before: true`, `source_clean_after: true`;
- `source_before/source_after` objects containing actual `report_path`, `sha256`,
  `tested_commit`, `tested_tree`;
- `verifier: {path, bytes, sha256, kind: "repository_build"}` and the resolved
  actual `python: {path, bytes, sha256}`;
- `profile_id`, `sdk: "3.0.6"`, integer `image_id`;
- `source_files` with raw SHA256 for the receiver, comparison and stage-measure
  Python files, source guard, verifier main/image/Cargo manifest/lock;
- `receiver_harness_sha256`, actual build commands and logs, cache/fresh-target
  facts, and `independent_reproducible_build_established: false`.

The harness checks actual qualification/file bytes before importing the pinned
measure module. Each receive also executes the real exact-source guard before
and after the one full verification, inside its local budget.

## Incoming bundle for a future receipt

Root transfers four original files into a new external inbox directory:

| Fixed incoming name | Original content |
|---|---|
| `header.bin` | Actual new native winner header, 318 bytes |
| `winner-result.json` | Original winner `result.json`, unchanged |
| `winner-intent.json` | Original pre-search `intent.json`, unchanged |
| `succinct.bin` | Actual full-v2 receipt, at most 16 MiB |

The same directory contains root's immutable `request.json`. Root independently
pins its SHA256 before transfer and supplies that exact hash to the receiver.
The request is an object with these fields:

```text
schema = TRNM-W1-ROG-RECEIVE-REQUEST1
request_id = original stable receive identifier
source_commit = d3037ca5dfb6f301757c159b7888dca9b0317be0
source_tree = d4a8f84cdc896b9454ce0d03a164f8916e6afdf9
expected_artifacts_sha256 = fixed independent 64-byte file SHA above
parent = {
  operation: original 64-character lowercase hex operation,
  original_boot_id: actual parent Linux boot UUID,
  original_deadline_ns: original integer parent CLOCK_MONOTONIC deadline
}
files = {
  header.bin: {bytes, sha256},
  winner-result.json: {bytes, sha256},
  winner-intent.json: {bytes, sha256},
  succinct.bin: {bytes, sha256}
}
```

The descriptions above are an interface, not a fabricated request. All concrete
values must come from the actual parent operation and original retained bytes.
The filename set is exact; no expected-artifacts file is selected from the inbox.
The prepared A/B material and original nonce-zero template remain fixed. The
historical template already had nonce zero, so this is not random sampling.

The receiver checks the winner/intent's common parent boot/deadline, reported
ordering, header/challenge/task/nonce and independent artifact bindings. It does
not compare any parent monotonic value with the ROG clock. Hashing caller records
binds their bytes, not the truth of the caller's original timestamp. Because the
complete native input is not transferred, `input_sha256` is retained as reported
provenance and is explicitly not claimed to have been independently rehashed.
The complete proof itself is still verified against the exact incoming header
and original local expected64 by the fixed verifier.

## Receive command: root only

Use the actual qualified resolved ROG Python, the absolute harness path, and real
qualification/request hashes:

```text
PYTHON receive_w1_on_rog.py receive
  --qualification ABS_ROG_QUALIFICATION_JSON
  --qualification-sha256 ACTUAL_QUALIFICATION_SHA256
  --request ABS_INBOX/request.json
  --request-sha256 ORIGINAL_REQUEST_SHA256
  --out ABS_NEW_EXTERNAL_OUTPUT
  --local-seconds 60
```

The receiver selects one local deadline at harness entry, at most 60 seconds
later. Qualification/input checking, exact-source guards, verifier startup,
full verification and ACK publication all consume this same local budget. It
passes **ROG's own** deadline and boot to the existing A receiver, never the
parent's values. Outer cleanup grace is 12 seconds and the nested receiver's
stage grace is 5 seconds; cleanup does not extend eligibility.

Successful `ack.json` is a pre-handoff verification observation. Root must also
observe the receiver process's actual exit zero, complete transport, and absence
of `operation-cancellation.json`. Timeout, cancellation, unknown cleanup or late
publication cannot authorize a successful receipt handoff. Raw stage/receiver
outputs remain retained on failure; no automatic retry or deadline renewal occurs.

## Desktop acceptance of remote ACK

Root reads and validates the complete ACK under its original desktop boot and
clock, binding the expected request hash, operation, receipt/header hashes,
original expected64, source and ROG qualification. Only then does desktop record
its own actual `CLOCK_MONOTONIC` ACK-observed timestamp and compare it with the
unchanged original parent deadline. ROG timestamps are never subtracted from
desktop timestamps. A remote verification may be valid yet arrive too late.

Every ROG ACK keeps `parent_timeliness_evaluated: false`,
`parent_deadline_satisfied: null`, `cross_host_latency_ns: null`,
`new_proofs_generated: 0`, and admission/payment/deployment qualification false.
It does not independently prove that the incoming receipt was freshly generated;
that fact belongs to the parent's complete fresh pipeline evidence. This is an
actual separate-host verification observation, not a WAN deployment benchmark
or a substitute for the blocked Kaggle/Colab provider paths.

## Exactly one historical smoke after the actual build

The separate `historical-smoke` mode uses the pinned genuine old full-v2 receipt
and header from the ROG repository. It uses the same local original expected64
and real verifier path, but requires no fabricated winner or parent clock data:

```text
PYTHON receive_w1_on_rog.py historical-smoke
  --qualification ABS_ROG_QUALIFICATION_JSON
  --qualification-sha256 ACTUAL_QUALIFICATION_SHA256
  --out ABS_NEW_HISTORICAL_SMOKE_OUTPUT
  --local-seconds 60
```

This runs one full verification and generates zero proofs. Preparation of this
interface and the five pure metadata controls do not perform that smoke.
