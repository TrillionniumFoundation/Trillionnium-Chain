#!/usr/bin/env python3
"""Run exact, isolated source qualifications; keep expected red failures intact."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

TASK = Path('/home/qian-qi/work/chain-pq-migration-recovery-e1dee-20261106')
BASE = '840522d0b65b4989f1a2a1d09c0ad51af1a1956d'
RED = '555d2e5bb338fa67d8b08f77f2bd86d68850fbf5'
FIXED = '2058225aa0d50ca57b1eb0d5f520d7f4eefae69b'
FIXED_TREE = '94f94114935d643a899b8c7c63f87dbb1b4432a1'
TEST_BLOB = '623013c6d93589d120b9b6eec58698f60156294c'
TEST_PATH = 'trillionnium/crates/trnm-checkpoint-store/tests/socket_ownership.rs'
ORIGIN = 'https://github.com/TrillionniumFoundation/Trillionnium-Chain.git'
SOURCE = TASK / 'source'
RED_SOURCE = TASK / 'red-source'
PREP = TASK / 'records/native-source-preparation'
COMMANDS = []


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def save(path, value):
    path = Path(path)
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def emit(value):
    print(json.dumps(value, sort_keys=True), flush=True)


def preparation(label, argv, source=SOURCE):
    log = PREP / (label + '.log')
    with log.open('xb') as stream:
        result = subprocess.run(argv, cwd=source, stdout=stream,
                                stderr=subprocess.STDOUT, check=False)
    receipt = {'label': label, 'argv': argv, 'cwd': str(source),
               'exit_code': result.returncode, 'log_sha256': digest(log),
               'log_bytes': log.stat().st_size}
    save(PREP / (label + '.json'), receipt)
    emit(receipt)
    if result.returncode:
        raise RuntimeError('source preparation refused: ' + label)
    return log.read_text()


def load_environment(target):
    extra = json.loads((TASK / 'environment.json').read_text())
    extra['CARGO_TARGET_DIR'] = str(TASK / target)
    env = os.environ.copy()
    # Preserve proxy/credential identity. Reject unrelated compiler overrides.
    forbidden = ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER',
                 'RUSTC_WORKSPACE_WRAPPER']
    for key in forbidden:
        if env.get(key):
            raise RuntimeError('unapproved compiler override: ' + key)
    if any(k.startswith('CARGO_PROFILE_') for k in env):
        raise RuntimeError('unapproved Cargo profile override')
    env.update(extra)
    env['GIT_TERMINAL_PROMPT'] = '0'
    return env


def record(source, head, out, environment, label, command, expected_code=0):
    emit({'event': 'command_start', 'source': head, 'label': label,
          'argv': command, 'expected_exit_code': expected_code})
    start = time.monotonic_ns()
    recorder = ['/usr/bin/python3', 'scripts/ci/record_pq_native_command.py',
                '--kind', 'head', '--candidate', head, '--tested', head,
                '--label', label, '--output', str(out), '--', *command]
    result = subprocess.run(recorder, cwd=source, env=environment, check=False)
    receipt = json.loads((out / (label + '.json')).read_text())
    summary = {'source': head, 'label': label, 'argv': command,
               'actual_exit_code': result.returncode,
               'expected_exit_code': expected_code,
               'record_status': receipt['status'],
               'recorded_command_exit': receipt['exit_code'],
               'duration_ns_including_source_verification': time.monotonic_ns() - start,
               'log_sha256': receipt.get('log_sha256'),
               'log_bytes': receipt.get('log_bytes')}
    COMMANDS.append(summary)
    emit({'event': 'command_complete', **summary})
    expected_status = 'command_succeeded' if expected_code == 0 else 'command_failed'
    if (result.returncode != expected_code or receipt['exit_code'] != expected_code
            or receipt['status'] != expected_status
            or receipt['before'] != receipt['after']):
        raise RuntimeError('unexpected native result: ' + label)
    return out / (label + '.log')


def executables(build_log, target):
    rows = []
    for line in build_log.read_text().splitlines():
        if not line.startswith('{'):
            continue
        value = json.loads(line)
        if value.get('reason') != 'compiler-artifact' or not value.get('executable'):
            continue
        path = Path(value['executable'])
        if not path.resolve().is_relative_to(target.resolve()):
            raise RuntimeError('binary outside isolated target')
        rows.append({'path': str(path), 'sha256': digest(path),
                     'size': path.stat().st_size, 'target': value['target'],
                     'profile': value['profile'], 'package_id': value['package_id']})
    if not rows:
        raise RuntimeError('no actual Cargo test executable')
    return rows


def recheck_binaries(rows):
    for row in rows:
        path = Path(row['path'])
        if path.stat().st_size != row['size'] or digest(path) != row['sha256']:
            raise RuntimeError('binary changed during native tests: ' + str(path))


def actual_tests(log):
    text = log.read_text()
    return {'passed': re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\. ok$', text, re.M),
            'failed': re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\. FAILED$', text, re.M),
            'ignored': re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\. ignored', text, re.M),
            'summaries': re.findall(r'^test result: .+$', text, re.M)}


def main():
    PREP.mkdir(mode=0o700)
    preparation('correct-base-branch', ['/usr/bin/git', 'branch', '-m',
                'fix/chain-pq-migration-recovery-e1dee-native-base'])
    preparation('base-preflight', ['/bin/bash', 'scripts/project-preflight.sh'])
    bundles = [('recovery-red.bundle',
                '8a7d0e61009c756ac360ae5c418a3a7cd410123027efafd5c04ef93e2333286b', RED),
               ('pq-migration-recovery.bundle',
                '056f6333204e67414b48da32edb95177b2f4ae1821f13add00f83afaa17bcf98', FIXED)]
    for index, (name, expected, head) in enumerate(bundles):
        path = TASK / name
        if digest(path) != expected:
            raise RuntimeError('bundle digest mismatch')
        preparation(f'bundle-{index}-verify', ['/usr/bin/git', 'bundle', 'verify', str(path)])
        preparation(f'bundle-{index}-import', ['/usr/bin/git', 'fetch', '--no-tags', str(path), head])
    preparation('clone-red', ['/usr/bin/git', 'clone', '--shared', '--no-checkout',
                              '--local', str(SOURCE), str(RED_SOURCE)])
    preparation('red-canonical-origin', ['/usr/bin/git', 'remote', 'set-url', 'origin', ORIGIN], RED_SOURCE)
    preparation('red-bundle-import', ['/usr/bin/git', 'fetch', '--no-tags', str(TASK / 'recovery-red.bundle'), RED], RED_SOURCE)
    preparation('red-checkout', ['/usr/bin/git', 'checkout', '-b',
                                'test/chain-pq-recovery-red-e1dee-native', RED], RED_SOURCE)
    preparation('red-implementation-unchanged', ['/usr/bin/git', 'diff', '--exit-code',
                 BASE, RED, '--', 'trillionnium/crates/trnm-checkpoint-store/src'], RED_SOURCE)
    if preparation('red-test-blob', ['/usr/bin/git', 'rev-parse', 'HEAD:' + TEST_PATH], RED_SOURCE).strip() != TEST_BLOB:
        raise RuntimeError('red public test blob mismatch')
    preparation('fixed-checkout', ['/usr/bin/git', 'checkout', '-b',
                                   'fix/chain-pq-migration-recovery-e1dee-native-fixed', FIXED])
    if preparation('fixed-tree', ['/usr/bin/git', 'rev-parse', 'HEAD^{tree}']).strip() != FIXED_TREE:
        raise RuntimeError('fixed source tree mismatch')
    if preparation('fixed-test-blob', ['/usr/bin/git', 'rev-parse', 'HEAD:' + TEST_PATH]).strip() != TEST_BLOB:
        raise RuntimeError('fixed public test blob mismatch')
    for source, head, target, phase in [(RED_SOURCE, RED, 'target-red', 'red'),
                                        (SOURCE, FIXED, 'target-fixed', 'fixed')]:
        out = TASK / ('records/native-' + phase)
        out.mkdir(mode=0o700)
        environment = load_environment(target)
        cargo = str(Path(environment['RUSTC']).with_name('cargo'))
        flags = ['--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml']
        record(source, head, out, environment, 'preflight', ['/bin/bash', 'scripts/project-preflight.sh'])
        record(source, head, out, environment, 'rustc', [environment['RUSTC'], '-Vv'])
        record(source, head, out, environment, 'cargo', [cargo, '-V'])
        if phase == 'red':
            args = [cargo, 'test', *flags, '-p', 'trnm-checkpoint-store', '--test', 'socket_ownership']
            build = record(source, head, out, environment, 'socket-build', [*args, '--no-run', '--message-format=json'])
            binaries = executables(build, TASK / target)
            save(out / 'binaries-before.json', binaries)
            log = record(source, head, out, environment, 'socket-red', [*args, '--', '--test-threads=1'], 101)
            recheck_binaries(binaries)
            save(out / 'binaries-after.json', binaries)
            tests = actual_tests(log)
            if len(tests['failed']) != 2 or tests['passed'] or tests['ignored']:
                raise RuntimeError('red test failure count differs from required 2')
            save(out / 'tests.json', tests)
            emit({'red_expected_failures_preserved': tests, 'red_is_pass': False})
            continue
        scopes = [('checkpoint', 'trnm-checkpoint-store', ['--all-targets'], []),
                  ('node-migration', 'trnm-pon-node', ['--lib'], ['pq_migration_inventory']),
                  ('m06-migration', 'trnm-mvcc-fee', ['--lib'], ['migration_inventory_v1'])]
        for name, package, target_args, selectors in scopes:
            args = [cargo, 'test', *flags, '-p', package, *target_args]
            build = record(source, head, out, environment, name + '-build',
                           [*args, '--no-run', '--message-format=json'])
            binaries = executables(build, TASK / target)
            save(out / (name + '-binaries-before.json'), binaries)
            log = record(source, head, out, environment, name + '-tests',
                         [*args, '--no-fail-fast', *selectors, '--', '--test-threads=1'])
            recheck_binaries(binaries)
            save(out / (name + '-binaries-after.json'), binaries)
            tests = actual_tests(log)
            if tests['failed'] or tests['ignored'] or not tests['passed']:
                raise RuntimeError('required test execution missing or unsuccessful: ' + name)
            if selectors and len(tests['passed']) != 7:
                raise RuntimeError('required migration test roster count differs from 7: ' + name)
            save(out / (name + '-tests-observation.json'), tests)
            if name == 'checkpoint':
                record(source, head, out, environment, 'probe-build',
                       [cargo, 'build', *flags, '-p', 'trnm-checkpoint-store', '--example', 'checkpoint_fault_domain_probe'])
                built_probe = TASK / target / 'debug/examples/checkpoint_fault_domain_probe'
                probe = TASK / 'retained-checkpoint-fault-domain-probe'
                with built_probe.open('rb') as original, probe.open('xb') as retained:
                    shutil.copyfileobj(original, retained)
                    retained.flush()
                    os.fsync(retained.fileno())
                os.chmod(probe, 0o555)
                if digest(probe) != digest(built_probe):
                    raise RuntimeError('retained probe differs from built binary')
                probe_info = {'path': str(probe), 'built_path': str(built_probe),
                              'size': probe.stat().st_size, 'sha256': digest(probe),
                              'source': head, 'tree': FIXED_TREE}
                save(out / 'probe-binary.json', probe_info)
                record(source, head, out, environment, 'probe-prepare',
                       [str(probe), 'prepare', str(TASK / 'exercise')])
                record(source, head, out, environment, 'probe-prepare-alternate',
                       [str(probe), 'prepare-alternate', str(TASK / 'alternate-exercise')])
                if digest(probe) != probe_info['sha256']:
                    raise RuntimeError('probe binary changed during preparation')
                emit({'event': 'probe_ready_for_independent_pin_transfer',
                      'fresh_pin': str(TASK / 'exercise/fresh-export.bin'),
                      'binary': probe_info})
        record(source, head, out, environment, 'workspace-clippy',
               [cargo, 'clippy', *flags, '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings'])
    save(TASK / 'records/native-phase-complete.json',
         {'schema': 'trnm-isolated-pq-native-phase-v1', 'status': 'completed',
          'red_failures_preserved': True, 'fixed_source': FIXED, 'red_source': RED,
          'commands': COMMANDS, 'two_host_custody_exercise_completed': False,
          'whole_node_rollback_qualified': False, 'production_activation': False})
    emit({'event': 'native_phase_complete', 'fixed_source': FIXED, 'red_expected_failed': 2,
          'two_host_custody_exercise_completed': False})


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        path = TASK / 'records/native-phase-failure.json'
        if not path.exists():
            save(path, {'error': str(error), 'commands': COMMANDS,
                        'automatic_retry': False, 'status': 'failed'})
        emit({'event': 'native_phase_failed', 'error': str(error)})
        sys.exit(1)
