#!/usr/bin/env python3
"""Observe the fixed Cell continuation; no command can grant qualification."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import time

ROOT = Path('/workspace/scratch/487d55b3efb1/chain-storage')
OUT = Path(sys.argv[1]).resolve()
OUT.mkdir(parents=True, exist_ok=False)
SOURCE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
# Explicit reviewed roster; an omitted module must fail even if listing succeeds.
EXPECTED_NEW_TESTS = frozenset([
  "cell::discovery::pq3::directory::deadline_tests::lookup_commit_contention_keeps_original_deadline",
  "cell::discovery::pq3::directory::deadline_tests::lookup_owner_contention_keeps_original_deadline",
  "cell::discovery::pq3::directory::deadline_tests::lookup_writer_contention_keeps_original_deadline",
  "cell::discovery::pq3::directory::deadline_tests::publish_commit_contention_keeps_original_deadline",
  "cell::discovery::pq3::directory::deadline_tests::publish_owner_contention_keeps_original_deadline",
  "cell::discovery::pq3::directory::deadline_tests::publish_writer_contention_keeps_original_deadline",
  "cell::discovery::pq3::directory_tests::actual_mldsa_v3_binds_every_unsigned_byte_and_rejects_other_namespaces",
  "cell::discovery::pq3::directory_tests::bounded_epoch_churn_cannot_consume_permanent_owner_capacity",
  "cell::discovery::pq3::directory_tests::epoch_and_wire_column_corruption_fail_before_pruning_or_ack",
  "cell::discovery::pq3::directory_tests::failed_deadline_does_not_retire_epoch_or_change_durable_state",
  "cell::discovery::pq3::directory_tests::full_512_slot_epoch_recovers_without_widening_database_or_replay_limits",
  "cell::discovery::pq3::directory_tests::key_expiry_returns_active_quota_and_is_rechecked_after_verification",
  "cell::discovery::pq3::directory_tests::manifest_expiry_reclaims_active_slots_across_operations_and_restart",
  "cell::discovery::pq3::directory_tests::owner_expiry_reclaims_active_quota_and_renewal_must_repay_it",
  "cell::discovery::pq3::directory_tests::randomized_mldsa_equivalence_keeps_original_wire_and_changed_statement_fails",
  "cell::discovery::pq3::directory_tests::read_only_usage_advances_its_fence_after_reconciling_a_higher_revision",
  "cell::discovery::pq3::directory_tests::read_only_usage_refuses_rewinding_a_revision_already_observed_in_process",
  "cell::discovery::pq3::directory_tests::shorter_latest_ttl_cannot_resurrect_a_long_lived_lower_sequence",
  "cell::discovery::pq3::directory_tests::signed_epoch_limits_ttl_skew_and_integer_overflow",
  "cell::discovery::pq3::directory_tests::source_and_prefix_limits_release_expired_capacity_without_origin_reassignment",
  "cell::discovery::pq3::directory_tests::unrepresentable_epoch_end_cannot_commit_an_unrecoverable_directory_clock",
  "cell::discovery::pq3::directory_tests::v3_never_migrates_v1_v2_or_changes_pinned_roster_and_namespace",
  "cell::discovery::pq3::directory_tests::withdrawal_returns_active_quota_but_persists_replay_evidence",
  "cell::discovery::pq3::multisource_tests::real_tcp_malicious_first_source_cannot_overwrite_later_authenticated_provider",
  "cell::discovery::pq3::multisource_tests::real_tcp_native_low_owner_flood_keeps_later_source_before_and_after_active_quota",
  "cell::discovery::pq3::server_tests::real_tcp_rendezvous_prioritizes_ninth_active_provider_over_eight_withdrawn_rows",
  "cell::discovery::pq3::server_tests::real_tcp_rendezvous_skips_expired_or_revoked_key_while_record_ttl_is_live",
  "cell::discovery::pq3::transport_tests::actual_server_bounds_signing_and_mandatory_self_verification_together",
  "cell::discovery::pq3::transport_tests::duplicate_source_keys_and_wrong_generations_fail_before_connecting",
  "cell::discovery::pq3::transport_tests::epoch_rollover_resets_sequence_without_reusing_old_sources_or_expiry",
  "cell::discovery::pq3::transport_tests::maximum_signed_result_fits_original_byte_cap_and_binds_last_record",
  "cell::discovery::pq3::transport_tests::native_response_binds_complete_query_nonce_target_result_status_and_lifetime",
  "cell::discovery::pq3::transport_tests::real_tcp_authenticated_announce_cold_fetch_withdrawal_and_failed_denominators",
  "cell::discovery::pq3::transport_tests::real_tcp_failed_payload_retains_shared_session_connection_and_byte_totals",
  "cell::discovery::pq3::transport_tests::real_tcp_partial_byte_exhaustion_prevents_another_dial_and_deadline_is_original",
  "cell::discovery::pq3::transport_tests::real_tcp_replayed_and_unsigned_replies_keep_actual_failure_denominator",
  "cell::residency::version::tests::complete_disk_bytes_and_model_only_residency_cannot_admit_a_complete_version",
  "cell::residency::version::tests::complete_version_admission_and_lookup_keep_the_original_task_cutoff",
  "cell::residency::version::tests::complete_version_cancellation_is_latched_even_on_a_mismatching_lookup",
  "cell::residency::version::tests::complete_version_charges_shared_allocations_once_but_each_context_mapping_separately",
  "cell::residency::version::tests::complete_version_next_task_reads_actual_model_and_environment_after_cache_loss",
  "cell::residency::version::tests::complete_version_rejects_another_tmr1_lineage_even_when_all_closures_match",
  "cell::residency::version::tests::complete_version_task_limits_charge_environment_bytes_references_and_closure",
  "cell::residency::version::tests::environment_only_residency_and_corrupted_missing_environment_never_create_partial_readiness",
  "cell::residency::version::tests::paired_lookup_rechecks_task_and_both_current_contexts_before_any_consumer_call"
])
ENV = dict(os.environ)
ENV['PATH'] = '/workspace/scratch/2b54b253422c/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:' + ENV['PATH']
ENV['CARGO_HOME'] = '/workspace/scratch/487d55b3efb1/cargo-home'
ENV['CARGO_TARGET_DIR'] = '/tmp/cell-storage-v3-487d55-target'
ENV['CARGO_BUILD_JOBS'] = '1'
ENV['TMPDIR'] = '/workspace/scratch/487d55b3efb1/runtime-tmp'
Path(ENV['TMPDIR']).mkdir(exist_ok=True)
ENV['RUST_TEST_THREADS'] = '1'
ENV['CARGO_INCREMENTAL'] = '0'
ENV['CARGO_PROFILE_DEV_DEBUG'] = '0'
ENV['CARGO_PROFILE_TEST_DEBUG'] = '0'
for line in Path('/workspace/scratch/487d55b3efb1/provider-setup/provider.env').read_text().splitlines():
    key, value = line.split('=', 1)
    if key not in {'OPENSSL_DIR', 'OPENSSL_STATIC', 'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256',
                   'TRNM_PQ_OPENSSL_VERSION', 'OPENSSL_CONF', 'OPENSSL_MODULES'}:
        raise ValueError('unexpected provider environment key')
    ENV[key] = value

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

summary = dict(schema='trnm-cell-storage-network-v3-validation-v1', source=SOURCE,
               base='0dc13a92cc49e9a751a2b6cf7cc96524f1244a2a', started_at=utc(),
               scope='Shared Linux x86_64 component checks; no fixed-resource Host/WAN/operator/Hepta FinalUse qualification',
               commands=[], complete=False, passed=False, production_qualified=False)
summary['build_environment'] = {key: ENV[key] for key in
    ['CARGO_BUILD_JOBS', 'RUST_TEST_THREADS', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG',
     'CARGO_PROFILE_TEST_DEBUG', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'TRNM_PQ_OPENSSL_SHA256']}
summary['build_environment']['TMPDIR'] = ENV['TMPDIR']
runner_bytes = Path(__file__).read_bytes()
(OUT/'runner.py').write_bytes(runner_bytes)
summary['runner_sha256'] = hashlib.sha256(runner_bytes).hexdigest()

monitor_stop = threading.Event()
def resource_monitor():
    """Record resources inside the same execution namespace as the commands."""
    with (OUT/'resources.jsonl').open('x') as stream:
        while True:
            row = {'time': utc(), 'filesystems': {}}
            for path in [str(ROOT), '/tmp', ENV['TMPDIR'], ENV['CARGO_TARGET_DIR']]:
                try:
                    fs = os.statvfs(path)
                    row['filesystems'][path] = dict(available_bytes=fs.f_bavail*fs.f_frsize,
                        free_bytes=fs.f_bfree*fs.f_frsize, free_inodes=fs.f_favail)
                except OSError as error:
                    row['filesystems'][path] = {'error': str(error)}
            row['memory_kib'] = {}
            try:
                for line in Path('/proc/meminfo').read_text().splitlines():
                    key, value = line.split(':', 1)
                    if key in {'MemTotal', 'MemAvailable', 'MemFree', 'SwapFree'}:
                        row['memory_kib'][key] = int(value.split()[0])
            except OSError as error:
                row['memory_error'] = str(error)
            stream.write(json.dumps(row, sort_keys=True)+'\n')
            stream.flush()
            if monitor_stop.wait(2):
                break

monitor = threading.Thread(target=resource_monitor, daemon=True)
monitor.start()

def save():
    pending = OUT / 'summary.pending'
    pending.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    pending.replace(OUT / 'summary.json')

def process_group_state(pgid):
    """Observe only the fresh process group owned by this command."""
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return 'absent'
    except OSError:
        return 'unknown'
    return 'present'

def wait_for_process_group(process, seconds):
    end = time.monotonic() + seconds
    while True:
        # Reap the direct child if possible; its exit alone is not group cleanup.
        process.poll()
        state = process_group_state(process.pid)
        if state == 'absent' and process.returncode is not None:
            return True, state
        if state == 'unknown' or time.monotonic() >= end:
            return False, state
        time.sleep(min(0.05, max(0.0, end - time.monotonic())))

def cleanup_process_group(process):
    """Bound TERM and KILL waits; never continue on unconfirmed cleanup."""
    result = dict(scope='owned-process-group', pgid=process.pid, complete=False,
                  stages=[], direct_child_exit_code=None)
    for sig, seconds in [(signal.SIGTERM, 5.0), (signal.SIGKILL, 5.0)]:
        stage = dict(signal=sig.name, wait_seconds=seconds, sent=False)
        try:
            os.killpg(process.pid, sig)
            stage['sent'] = True
        except ProcessLookupError:
            stage['already_absent'] = True
        except OSError as error:
            stage['signal_error'] = str(error)
        complete, state = wait_for_process_group(process, seconds)
        stage['observed_group_state'] = state
        stage['complete'] = complete
        result['stages'].append(stage)
        if complete:
            result['complete'] = True
            break
    result['direct_child_exit_code'] = process.returncode
    return result

commands = [
    ('preflight', ['bash', 'scripts/project-preflight.sh', '--audit'], 120),
    ('source-before', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                       '--expected-head', SOURCE, '--output', str(OUT/'source-before.json')], 180),
    ('graph-default', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1',
                       '--manifest-path', 'trillionnium/Cargo.toml'], 180),
    ('graph-all-features', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1',
                            '--manifest-path', 'trillionnium/Cargo.toml', '--all-features'], 180),
    ('graph-fuzz', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1',
                    '--manifest-path', 'tests/fuzz/Cargo.toml'], 180),
    ('format', ['cargo', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check'], 180),
    ('version-vector', ['python3', '-B', 'scripts/cell_complete_version_vector.py', '--check'], 120),
    ('native-list', ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml',
                      '-p', 'trnm-data-availability', '--lib', '--', '--list'], 300),
    ('p2p-complete', ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml',
                       '-p', 'trnm-data-availability', '--', '--test-threads=1'], 1200),
    ('native-example', ['cargo', 'run', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml',
                         '-p', 'trnm-data-availability', '--example', 'cell_discovery_pq_v3', '--',
                         str(OUT/'native-example')], 300),
    ('clippy-workspace', ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml',
                            '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings'], 1200),
    ('source-negative', ['python3', '-B', 'scripts/ci/test_ci_source_integrity.py'], 180),
    ('pq-source-negative', ['python3', '-B', 'scripts/ci/test_pq_research_integration.py'], 300),
    ('ci-contract', ['python3', '-B', 'scripts/ci/test_ci_contract.py'], 300),
    ('repository', ['python3', '-B', 'scripts/ci/check_repository.py'], 300),
    ('pq-source-pins', ['python3', '-B', 'scripts/ci/check_pq_research_integration.py'], 120),
    ('inventory', ['python3', '-B', 'scripts/refresh_distributed_source_inventory.py', '--check'], 120),
    ('source-after', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                      '--expected-head', SOURCE, '--output', str(OUT/'source-after.json')], 180),
    ('clean-worktree', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], 120),
]
summary['planned_command_count'] = len(commands)
summary['process_policy'] = dict(start_new_session=True,
                               timeout_cleanup='TERM then KILL for the owned process group',
                               term_wait_seconds=5, kill_wait_seconds=5,
                               stop_on_unconfirmed_cleanup=True)
save()
stopped_early = False
for label, argv, timeout in commands:
    started = time.monotonic()
    stamp = utc()
    timed_out = False
    code = None
    cleanup = None
    launch_error = None
    interrupted = False
    path = OUT / (label + '.log')
    print('START', label, flush=True)
    with path.open('xb') as stream:
        try:
            process = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
        except OSError as error:
            launch_error = str(error)
        else:
            try:
                code = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                cleanup = cleanup_process_group(process)
                code = process.returncode
            except KeyboardInterrupt:
                interrupted = True
                cleanup = cleanup_process_group(process)
                code = process.returncode
    raw = path.read_bytes()
    cleanup_incomplete = cleanup is not None and not cleanup['complete']
    passed = code == 0 and not timed_out and not interrupted and not cleanup_incomplete
    if label == 'clean-worktree':
        passed = passed and not raw
    summary['commands'].append(dict(label=label, argv=argv, log=path.name, exit_code=code,
                                    timeout=timed_out, timeout_seconds=timeout, passed=passed,
                                    interrupted=interrupted, launch_error=launch_error,
                                    process_group_cleanup=cleanup,
                                    log_may_still_change=cleanup_incomplete,
                                    started_at=stamp, elapsed_seconds=time.monotonic()-started,
                                    bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                                    log_observed_at=utc()))
    save()
    print('END', label, 'PASS' if passed else 'FAIL', code, flush=True)
    if cleanup_incomplete or interrupted:
        stopped_early = True
        summary['stop_reason'] = ('unconfirmed process-group cleanup' if cleanup_incomplete
                                  else 'runner interrupted')
        summary['unattempted_commands'] = [item[0] for item in commands[len(summary['commands']):]]
        save()
        break

monitor_stop.set()
monitor.join(timeout=5)
summary['resource_monitor_finished'] = not monitor.is_alive()
listing_path = OUT/'native-list.log'
native_path = OUT/'p2p-complete.log'
listing = listing_path.read_text(errors='replace') if listing_path.exists() else ''
native = native_path.read_text(errors='replace') if native_path.exists() else ''
names = re.findall(r'^(cell::(?:discovery::pq3::|residency::version::).+): test$', listing, re.M)
case_results = [dict(name=match.group(1), status=match.group(2),
                     log_line=native.count('\n', 0, match.start()) + 1)
                for match in re.finditer(r'^test (.+) \.\.\. (ok|FAILED|ignored)(?:, [^\n]*)?$', native, re.M)]
ok_names = {row['name'] for row in case_results if row['status'] == 'ok'}
failed_names = sorted({row['name'] for row in case_results if row['status'] == 'FAILED'})
observed_names = {row['name'] for row in case_results}
missing = sorted(EXPECTED_NEW_TESTS - ok_names)
groups = {prefix: sum(name.startswith(prefix) for name in names)
          for prefix in ['cell::discovery::pq3::directory_tests::',
                         'cell::discovery::pq3::directory::',
                         'cell::discovery::pq3::transport_tests::',
                         'cell::discovery::pq3::multisource_tests::',
                         'cell::discovery::pq3::server_tests::',
                         'cell::residency::version::tests::']}
counts = [dict(status=status, passed=int(a), failed=int(b), ignored=int(c), measured=int(d), filtered=int(e))
          for status,a,b,c,d,e in re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', native)]
totals = {key: sum(row[key] for row in counts) for key in ['passed', 'failed', 'ignored', 'measured', 'filtered']}
roster_ok = set(names) == EXPECTED_NEW_TESTS and len(set(names)) == len(names) and not missing
roster_ok = roster_ok and groups['cell::residency::version::tests::'] == 9
roster_ok = roster_ok and groups['cell::discovery::pq3::multisource_tests::'] == 2
roster_ok = roster_ok and groups['cell::discovery::pq3::server_tests::'] == 2
roster_ok = roster_ok and bool(counts) and all(row['status'] == 'ok' and row['failed'] == row['ignored'] == row['filtered'] == 0 for row in counts)
native_command = next((row for row in summary['commands'] if row['label'] == 'p2p-complete'), None)
results = dict(required_new_tests=sorted(EXPECTED_NEW_TESTS), listed_new_tests=names,
               not_listed_new_tests=sorted(EXPECTED_NEW_TESTS-set(names)),
               groups=groups, missing_new_tests=missing,
               not_observed_new_tests=sorted(set(names) - observed_names),
               failed_new_tests=sorted(set(names) & set(failed_names)),
               all_observed_test_cases=case_results, failed_test_names=failed_names,
               native_command=native_command,
               native_log_present=native_path.exists(), native_listing_present=listing_path.exists(),
               complete_target_results=counts, roster_passed=roster_ok,
               passed=roster_ok and native_command is not None and native_command['passed'],
               reported_test_totals=totals,
               reported_executed_test_denominator=totals['passed'] + totals['failed'],
               reported_selected_test_denominator=sum(totals[key] for key in ['passed', 'failed', 'ignored', 'measured']),
               total_successful_tests_including_doctests=totals['passed'],
               total_failed_tests_including_doctests=totals['failed'])
(OUT/'native-results.json').write_text(json.dumps(results, indent=2, sort_keys=True)+'\n')
summary.update(complete=not stopped_early and len(summary['commands']) == len(commands),
               completed_at=utc(), new_native_test_names=len(names),
               attempted_command_count=len(summary['commands']), stopped_early=stopped_early,
               passed=not stopped_early and len(summary['commands']) == len(commands)
                      and all(row['passed'] for row in summary['commands']) and roster_ok)
save()
print(json.dumps(dict(source=SOURCE, passed=summary['passed'], complete=summary['complete'],
                      attempted_commands=len(summary['commands']), planned_commands=len(commands),
                      new_native_tests=len(names), missing=missing)), flush=True)
sys.exit(0 if summary['passed'] else 1)
