# Independent review of three inherited PQ corpus pin deltas

Reviewed isolated branch HEAD `db33e48673ffb839fdb73ec22bfd9920e5569a43`, tree
`963ac18527e176a9a8d393658c41e4f386f95b7b`. Worktree was clean. No production
files, root worktree, archive extraction, native/PQ execution, Cargo or CI were
used or modified. The only new files for this review are in this `/tmp`
directory. `review.json` binds the full old/new blobs and all supporting source.

## Repin scope

| File | Old pinned blob | Current blob | Original old-blob source |
| --- | --- | --- | --- |
| `ingress.rs` | `e880e9ba05cea8c753b0bdff71037dd6fb95d950` | `8b07b468b8b79b51f49583f9da3ea122231db9fb` | `7acad34a46f63208448b4dbdf0624548f64f6405` |
| `ingress/public_v3.rs` | `66f2e543cf2172d9b3a38bd11c25b4916eb4fcbb` | `59f51dcadb5a0a575eaa14734edbce74accade09` | `48aaeddb1ab5115169cb1bc8d80647888bba3d2d` |
| `store.rs` | `7a0b5048a1099e8a2b3bf8c90354e0b2a370d66b` | `51f73baed12ba839c965a2e3cb2ffbbd9c6fc131` | `7acad34a46f63208448b4dbdf0624548f64f6405` |

Each current blob is already present at integration commit
`8a35529679c3d176fd7586ab1ecf4e004f25af79` and at `189ba3`. They are not from
the later three-check History patch. Exact diffs are retained next to this
report. The file changes are +240/-31, +20/-11 and +216/-35 respectively.

Repinning is justified as correction of inherited source bindings, with all
qualification gates false. It must not be described as mere formatting or as
independent native acceptance. These differences alter execution scheduling,
recovery and database format.

## Findings about authority

No new classical/PQ authorization bypass was found in these differences. This
is a scoped code review, not a proof covering the full repository.

- `require_classical_network_profile()` still refuses `PqNetworkV1`; it is
  called inside the exported legacy listener, both V2 entrypoints and V3
  startup. There is no new listener-level escape into a classical profile.
- Native open still binds PQ backend to `pq_network` policy, requires a PQ
  network owner for a PQ account profile, and forbids combining PQ namespace
  with restricted/mining/continuous owners. Feature-free builds cannot select
  the PQ variant or its distinct DDL namespace.
- `PqNetworkPolicy::verify_request` still performs the actual native verifier,
  pins peer/purpose/network/owner generation/sequence/expiry/payload, and checks
  canonical JSON before producing `VerifiedRequest`. The shared dispatcher
  still receives this verified request, complete W1 and the same progress
  control; no signature check is replaced by a digest or parser result.
- The cloned M06 `Config` retains its PQ account policy. In `pon_executor`
  `prepare()` chooses `pq_accounts::prepare()` when that policy is selected;
  `validate_main_envelope()` rejects the PQ account profile, and lifecycle
  commands requiring a legacy envelope reject the transfer-only PQ command.
  The intentionally separate PQ-transport-only profile can still use classical
  application accounts; that is an acknowledged incomplete migration, not
  evidence of whole-native PQ integration.

## Execution changes that affect PQ evidence

The new `admit_shared_checked()` uses one private `DetachedExecutionLease`,
executes the bound M06 outside the Node mutex and reacquires the original owner
for publication. It carries the original caller's progress/control and scoped
worker accounting; it does not create/refill a second CPU account. Its opaque
execution result is not constructible from a public arbitrary output. Owner
inode, database inode, network, parameters, genesis, backend and actual SQLite
epoch are pinned. A changed parent is fully rechecked. A final `CommitFence`
is checked after `BEGIN IMMEDIATE`, before writes, and the original delta,
packet, full-State, ancestry and active-tip checks remain before commit.

The explicit large-snapshot path keeps the original fully checked held-owner
M06 schedule. It is a scheduling/capacity alternative, not a work or signature
fallback. Restricted/mining/continuous/growth and ROOT-cache owners are
excluded from detachment.

**`detached_execution_supported()` does not exclude `PqNetworkV1`.** A normal
PQ transport owner therefore can use detached M06 too. The PQ `handle()` passes
its actual deadline/expiry/revocation control into execution and complete W1.
This expands what exact-source PQ testing must cover. Tests from the old pinned
blobs cannot establish that the new detached path preserves all PQ revocation,
nonce and recovery behavior.

The new authenticated pending-activation helper applies to the classic signed
transport only after `authenticate_request()`. It requires the exact existing
pending frame, recovered replay ledger, canonical request bytes, exact durable
packet/target and unchanged SQL epoch. It writes no new nonce and authorizes no
new target. Typed cancellation now returns a nonterminal signed failure before
the classic finish/ACK path; a separate real retry has its own original deadline.
It must not be credited as PQ pending-operation recovery, which has a separate
ledger and finish rule.

## Reorganization and schema scope

The common `BASE_DDL` gains the 629-byte `reorg_lifecycle_v1` row definition.
All selected backends, including PQ, include this base DDL in their schema hash.
The existing domains are unchanged, but resulting exact IDs change; namespace
metadata and full schema checks reject an old layout. This is not automatic
legacy database migration. The legacy reader's independently retained old
4775-byte/8c2627fa vector and current 5404-byte/9cfc3648 vector must remain
distinct.

The public V3 signed resource commitment changes r13 to r14 and has fresh
fixed vectors plus predecessor-cookie rejection controls. Numeric burst,
refill, reserve and deadline values do not change in this delta. The new 25 ms
termination allowance is reserved within the original paid owner, not added
credit.

Reorg now distinguishes pending `done=0`, completed `done=1` and cancelled
unpublished staging `done=2`. A lifecycle entry pins old/target/generation,
slot/root and owner. Cancellation checks the original reservation and actual
SQL epoch, uses no busy wait, a bounded VDBE handler and an SQL authorizer that
allows only `reorg.done` plus three lifecycle terminal fields. It cannot write
active State, block facts, peer replay, PQ revocation, CPU journals or nonce.
Exactly two metadata row updates are verified. A completed durable native fact
stays committed; future reclaim of unused staging belongs to the next original
paid native intent.

## Static conditional recovery counterexample — not yet executed

An unresolved PQ-specific boundary is visible in the exact current source:

1. `PqServer::handle()` produces `PQ_NETWORK_DEADLINE`, `PQ_NETWORK_EXPIRED` and
   `PQ_NETWORK_REVOKED` from its real control closure.
2. `error.rs` has none of these exact `ErrorCode` variants/strings. They become
   `ErrorKind::Unclassified`; they are not `Cancelled`.
3. `finish_or_cancel_reorg()` cleans unpublished staging only for typed
   `Cancelled`, `PublicMutationCpuBudget` or `OwnerContinuousCpuBudget`.
4. If a PQ control error occurs after original reorg intent commit, this branch
   therefore returns the original error without invoking metadata cancellation.
5. The separate PQ handler attempts to finalize complete error outcomes under
   its own operation/sequence policy. For deadline/expiry this can retain a
   failure result; revocation can prevent finish. This does not itself remove
   `reorg.done=0`.
6. Every later `begin_pq_network_request()` first calls `ready()`, before replay
   lookup, so a still-pending intent blocks even a different valid peer. The
   new classic pending-activation recovery helper is not on this PQ path.

This is a source-level conditional liveness/recovery risk, not a demonstrated
signature bypass, actual attack, measured denial of service or proof that the
cut can be reached under a particular workload. It is a reason to keep native
PQ/recovery gates false while correcting corpus pins.

### Concrete reproduction plan for the root owner

Reuse the genuine OpenSSL ML-DSA test keys and two-peer policy from
`ingress/pq_network/tests.rs`. Construct the real left/right/target/honest PoN
branches as in `authenticated_recovery_tests.rs::Running::new()`: activate
left, admit right, acquire complete valid W1 for the heavier right child and an
independent honest left child. Retain all real producer work and exact packets.

Set the existing test-only `cancel_next_activation_intent_for_test()` before
serving. It pauses only after the real intent transaction and repeatedly calls
the actual original progress check, with an 11-second assertion ceiling. Use
the PQ listener's unchanged 10-second request deadline. Do not manufacture an
Error to stand in for elapsed time; separately verify the intended durable cut
was actually reached. This remains an injected scheduling cut, not a physical
process-kill or WAN observation.

Retain the first full signed request bytes, any response, actual deadline and
failure, then inspect `reorg`, lifecycle, active tip/generation/slot, full State,
both peers' sequence/audit records, and original CPU/account facts. A timed-out
socket may have no completed response even if a failure was retained locally.
Send every predeclared follow-up: original peer retry, next sequence, different
authorized peer's Head and genuine honest Submit; keep all failures and
unattempted planned work in the denominator. Cold reopen is a separate control
and must not be relabeled as live recovery. Classic-listener substitution is
forbidden by the expected PQ namespace boundary and is not a recovery method.

If a fix is required, preserve the exact wire diagnostics and original PQ
operation/sequence policy. Use typed local producer identities for deadline /
expiry / revocation handling; do not classify arbitrary remote strings by a
prefix. Prove cleanup leaves active state, nonce, revocation and CPU accounting
unchanged except for explicitly authorized original operation finalization.
Do not copy the classic nonterminal ACK rule into PQ without specifying its
separate retained-response semantics. Re-run the real cut plus retained
negatives, including actual revocation during detached work, rather than
claiming existing reorg-after-revocation tests cover the new scenario.

## Qualification limits

The existing PQ reorg test revokes a peer and then performs a local ordinary
activation; it verifies revocation survives that completed reorg and cold
reopen. It does not exercise a live authenticated PQ Submit cancelled after
intent commit. Existing passing PQ tests are valuable baselines, but cannot
discharge this missing scenario, whole authorization migration, Host paid-CPU
fairness, hardware antirollback or WAN acceptance. Current default-feature
History tests likewise are not optional-feature PQ evidence.

All original failures, old source pins and native qualification boundaries
must remain in the repin receipt. This review changes no release gate.
