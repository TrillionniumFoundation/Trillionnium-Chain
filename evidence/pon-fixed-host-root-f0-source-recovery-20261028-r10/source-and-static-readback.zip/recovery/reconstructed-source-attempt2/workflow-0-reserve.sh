set -euo pipefail
out="$RUNNER_TEMP/pon-fixed-host-root-f0-$GITHUB_RUN_ID-$GITHUB_RUN_ATTEMPT"
mkdir "$out"
printf 'OUT=%s\n' "$out" >> "$GITHUB_ENV"
printf 'CARGO_HOME=%s/cargo-fixed-host-root-f0\n' "$RUNNER_TEMP" >> "$GITHUB_ENV"
printf 'CARGO_TARGET_DIR=%s/target-fixed-host-root-f0\n' "$RUNNER_TEMP" >> "$GITHUB_ENV"
export F0_PREDECLARED_OUT="$out"
python3 - <<'PY'
from datetime import datetime, timezone
import json, os, re
from pathlib import Path
out = Path(os.environ['F0_PREDECLARED_OUT'])
head = os.environ['EXPECTED_HEAD']
if re.fullmatch('[0-9a-f]{40}', head) is None:
    raise ValueError('full event head SHA required')
phases = ['baseline', 'valid-work-root']
value = {
    'schema': 'fixed-host-root-f0-workflow-predeclaration-v1',
    'head': head, 'tree': None, 'source_kind': 'event-head',
    'run_id': os.environ['GITHUB_RUN_ID'], 'run_attempt': os.environ['GITHUB_RUN_ATTEMPT'],
    'job_id': os.environ['GITHUB_JOB'], 'created_utc': datetime.now(timezone.utc).isoformat(),
    'selector': 'fixed_public_host_root_rejection_and_signed_confirmation_diagnostic',
    'planned_complete_runs': 1, 'planned_phases': phases,
    'planned_confirmations': 6, 'planned_business_packet_exposures': 42,
    'all_planned_rounds': [
        {'phase': phase, 'round': number, 'scheduled_offset_ns': (1+number*4)*1000000000,
         'actual_started_ns': None, 'actual_ended_ns': None,
         'four_second_slo_met': False, 'status': 'unobserved'}
        for phase in phases for number in range(3)],
    'all_planned_business_packets': [
        {'phase': phase, 'packet_index': number, 'observed_attempts': 0,
         'timely_network_ack': False, 'ack_is_not_confirmation': True}
        for phase in phases for number in range(21)],
    'public_host': {'cpu_max': '25000 100000', 'memory_max': '2147483648'},
    'paid_burst_ns': 2000000000, 'paid_refill_ns_per_second': 250000000,
    'phase_window_ns': 30000000000, 'new_f0_four_second_slo_ns': 4000000000,
    'slo_from_scheduled_time_includes_queue_and_final_observer': True,
    'old_root_per_round_four_second_predicate_existed': False,
    'controller_ceiling_is_not_reserved_physical_capacity': True,
    'selector_invocation_attempted': False, 'native_execution_observed': False,
    'service_remaining': 'unknown', 'independent_wan_qualification': False,
    'f1_implemented': False, 'production_activation': False,
}
with (out/'workflow-predeclared.json').open('x') as stream:
    json.dump(value, stream, indent=2, sort_keys=True)
    stream.write('\n')
(out/'SCOPE.txt').write_text(
    'One finite x64 head baseline/ROOT pair: 6 confirmations and 42 business exposures. '
    'All unobserved, failed and late outcomes remain. No independent operators, '
    'multi-day WAN, quantum hardness, production or F1 qualification. '
    'Controller 4-core/16GiB limits are ceilings; actual RAM and affinity are recorded.\n')
PY
