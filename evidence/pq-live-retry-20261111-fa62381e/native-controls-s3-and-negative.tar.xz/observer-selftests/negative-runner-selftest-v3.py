"""Synthetic observer controls only; no Cargo, ELF, or native test dispatch."""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
from unittest import mock

sys.dont_write_bytecode = True
RUNNER = Path('/tmp/chain-pq-fa62381e-negative-validation-v3.py')
OLD_RUNNER = Path('/tmp/chain-pq-fa62381e-negative-validation.py')
EXPECTED_SHA = '58e2fa946a7dc34cf58e8b357e04c2789da98f8b6218768d8e29651c6cf6b6f7'
OLD_EXPECTED_SHA = '4ee230a9a7d0ee4a8efa18f955f6dc8972e66037a1d36fb1f6f5514603403ca8'
OUTPUT = Path('/tmp/chain-pq-fa62381e-negative-classifier-selftest-v3.json')


def load_module(path, name, expected):
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    assert actual == expected, (path, actual)
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value, actual


mod, pin = load_module(RUNNER, 'negative_observer_v3', EXPECTED_SHA)
old, old_pin = load_module(OLD_RUNNER, 'negative_observer_v1', OLD_EXPECTED_SHA)

# Preserve the original nine failure-reader controls and their exact fixture.
name = mod.SELECTION[0][1]
marker = 'called ' + chr(96) + 'Result::unwrap_err()' + chr(96) + ' on an ' + chr(96) + 'Ok' + chr(96) + ' value'
expect = {'test': name, 'source_file': 'trillionnium/crates/trnm-pon-node/src/ingress/account_scope_tests.rs',
          'panic_line': 73, 'markers': [marker]}
raw = (f'running 1 test\ntest {name} ... FAILED\n\nfailures:\n\n---- {name} stdout ----\n\n'
       f'thread {name!r} (123) panicked at crates/trnm-pon-node/src/ingress/account_scope_tests.rs:73:14:\n'
       f'{marker}: Session\n\nfailures:\n    {name}\n\n'
       'test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 1420 filtered out; finished in 0.01s\n')
result = mod.validate_failed(raw, expect)
assert result['result'] == 'FAIL' and result['expected_assertion_failure_observed'] is True
bad = [
    raw.replace('running 1 test', 'running 0 tests'), raw + raw,
    raw.replace('0 passed; 1 failed; 0 ignored', '0 passed; 0 failed; 1 ignored'),
    raw.replace(name, 'wrong::test'), raw.replace('.rs:73:14:', '.rs:74:14:'),
    raw.replace('/ingress/account_scope_tests.rs', '/provider/failure.rs'),
    raw.replace(marker, 'unrelated provider error'),
    raw.replace('failures:\n    ' + name + '\n\n', ''),
]
for index, value in enumerate(bad):
    try:
        mod.validate_failed(value, expect)
    except ValueError:
        continue
    raise AssertionError(f'bad failure transcript accepted: {index}')


def fixture(root, artifact_pin=None):
    output = root / 'out'
    output.mkdir()
    artifact = root / 'artifact.json'
    artifact.write_text(json.dumps({'executable_sha256': 'e' * 64,
                                    'build_receipt_sha256': 'b' * 64}))
    actual_pin = mod.digest(artifact)
    selected_pin = actual_pin if artifact_pin is None else artifact_pin
    release = root / 'release.json'
    expected = {
        'schema': 'trnm-pq-negative-native-release-v1',
        'status': 'positive-native-controls-complete',
        'negative_source': 'a' * 40, 'positive_source': 'c' * 40,
        'native_artifact_sha256': selected_pin, 'executable_sha256': 'e' * 64,
    }
    return output, artifact, selected_pin, release, expected


# Preserve the original five coordination cases, including atomic publication.
barrier_controls = 0
for mode in ('valid', 'wrong-source', 'symlink', 'oversized', 'timeout'):
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        output, artifact, artifact_pin, release, expected = fixture(root)
        writer = None
        if mode == 'valid':
            def publish():
                while not (output / 'build-ready.json').exists():
                    time.sleep(0.005)
                temporary_release = root / 'release.pending'
                temporary_release.write_text(json.dumps(expected))
                os.replace(temporary_release, release)
            writer = threading.Thread(target=publish)
            writer.start()
        elif mode == 'wrong-source':
            release.write_text(json.dumps({**expected, 'negative_source': 'd' * 40}))
        elif mode == 'symlink':
            target = root / 'other.json'
            target.write_text(json.dumps(expected))
            release.symlink_to(target)
        elif mode == 'oversized':
            release.write_bytes(b'x' * 8193)
        refused = False
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                mod.await_negative_release(output, release, artifact, artifact_pin,
                                           'a' * 40, 'c' * 40, pin, 0.02 if mode == 'timeout' else 1)
        except (OSError, ValueError):
            refused = True
        finally:
            if writer:
                writer.join()
        assert refused == (mode != 'valid'), mode
        ready = json.loads((output / 'build-ready.json').read_text())
        assert ready['native_tests_started'] is False
        assert ready['component_validation_passed'] is False
        assert (output / 'negative-release-observation.json').exists() == (mode == 'valid')
        barrier_controls += 1

# The wrong artifact pin must refuse even readiness publication, despite a
# syntactically matching release already being available.
with tempfile.TemporaryDirectory() as temporary:
    output, artifact, artifact_pin, release, expected = fixture(Path(temporary), '0' * 64)
    release.write_text(json.dumps(expected))
    try:
        mod.await_negative_release(output, release, artifact, artifact_pin,
                                   'a' * 40, 'c' * 40, pin, 1)
    except ValueError as exc:
        assert str(exc) == 'build provenance artifact changed'
    else:
        raise AssertionError('wrong artifact pin accepted')
    assert not (output / 'build-ready.json').exists()
    assert not (output / 'negative-release-observation.json').exists()


def observe_late_release(module, runner_pin):
    with tempfile.TemporaryDirectory() as temporary:
        output, artifact, artifact_pin, release, expected = fixture(Path(temporary))
        release.write_text(json.dumps(expected))
        refused = False
        message = None
        with mock.patch.object(module.time, 'monotonic', side_effect=[0.0, 0.0, 2.0]) as clock:
            with contextlib.redirect_stdout(io.StringIO()):
                try:
                    module.await_negative_release(output, release, artifact, artifact_pin,
                                                  'a' * 40, 'c' * 40, runner_pin, 1)
                except ValueError as exc:
                    refused, message = True, str(exc)
        return {'refused': refused, 'message': message,
                'release_observation_written': (output / 'negative-release-observation.json').exists(),
                'build_ready_written': (output / 'build-ready.json').exists(),
                'monotonic_calls': clock.call_count}


# The same synthetic elapsed-time schedule reproduces the original acceptance
# bug and proves v3 refuses it after its artifact and runner checks.
late_current = observe_late_release(mod, pin)
late_old = observe_late_release(old, old_pin)
assert late_current == {
    'refused': True, 'message': 'negative execution barrier timed out before accepting release',
    'release_observation_written': False, 'build_ready_written': True, 'monotonic_calls': 3,
}
assert late_old == {
    'refused': False, 'message': None,
    'release_observation_written': True, 'build_ready_written': True, 'monotonic_calls': 2,
}

# Mutate the pathname immediately after a read returns. The parsed identity
# must stay with the validated snapshot, even though the file now differs.
with tempfile.TemporaryDirectory() as temporary:
    artifact = Path(temporary) / 'artifact.json'
    original = b'{"identity":"validated-build"}'
    replacement = b'{"identity":"replacement-build"}'
    artifact.write_bytes(original)
    real_read_bytes = Path.read_bytes
    changed = []
    def replace_after_read(path):
        data = real_read_bytes(path)
        if path == artifact:
            artifact.write_bytes(replacement)
            changed.append(True)
        return data
    with mock.patch.object(Path, 'read_bytes', new=replace_after_read):
        value = mod.read_pinned_artifact(artifact, hashlib.sha256(original).hexdigest())
    assert changed == [True]
    assert value == {'identity': 'validated-build'}
    assert artifact.read_bytes() == replacement

report = {
    'classifier_controls_passed': 1 + len(bad),
    'retained_barrier_controls_passed': barrier_controls,
    'new_regression_controls_passed': 3,
    'current_runner_controls_passed': 1 + len(bad) + barrier_controls + 3,
    'current_runner_controls_required': 17,
    'prior_version_counterexamples_observed': 1,
    'late_release_current': late_current, 'late_release_prior': late_old,
    'wrong_pin_refused_before_build_ready': True,
    'validated_snapshot_used_after_path_change': True,
    'runner_sha256': pin, 'prior_runner_sha256': old_pin,
    'selftest_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'actual_native_tests_executed': False, 'native_builds_executed': False,
    'component_validation_passed': False,
    'scope': 'synthetic Python failure-reader, release timing, and artifact-snapshot controls only',
}
with OUTPUT.open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps(report, sort_keys=True))
