import pathlib,hashlib,json,subprocess
s=pathlib.Path('/home/qq/chain-host-stat-20261118-2e9b-source');v=pathlib.Path('/home/qq/chain-native-root-body-delay-20261118-2e9b-validation')
files=[p for p in v.rglob('*') if p.is_file()]
plan=s/'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
data={'validation_files':len(files),'validation_bytes':sum(p.stat().st_size for p in files),'validation_largest':sorted([{'path':str(p.relative_to(v)),'size':p.stat().st_size} for p in files],key=lambda r:r['size'],reverse=True)[:20],'plan_exists':plan.exists(),'plan_d952_blob':subprocess.check_output(['git','rev-parse','d95239eda6a666458aa264ddeaf993d6d9fbf37d:'+str(plan.relative_to(s))],cwd=s,text=True).strip(),'plan_current_blob':subprocess.check_output(['git','hash-object',str(plan)],cwd=s,text=True).strip() if plan.exists() else None,'plan_tail':'\n'.join(plan.read_text().splitlines()[-90:]) if plan.exists() else None,'gates_text':(v/'write-complete-v4/inline-pins-1/ci-contract.stdout').read_text(),'driver_files':[str(p.relative_to(v)) for p in files if p.suffix=='.py']}
print(json.dumps(data,indent=2))
