#!/usr/bin/env python3
"""Restore only exact fuzz-lock registry packages from previously checked archives."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import time
import tomllib

BASE = Path('/workspace/scratch/c9b48df754d6')
REPO = BASE / 'chain-quantum-next'
CARGO = BASE / 'cargo-fuzz'
CACHE = CARGO / 'registry/cache/index.crates.io-1949cf8c6b5b557f'
LOCK = REPO / 'tests/fuzz/Cargo.lock'
CONFIG = CARGO / 'config.toml'
OUT = Path(__file__).resolve().parent
STAGING = CARGO / 'vendor.restore-20261107'
VENDOR = CARGO / 'vendor'
HISTORICAL = BASE / 'validation-next/fuzz-locked-metadata/verified-directory-source.json'
MIN_START = 1024 ** 3
MIN_REMAINING = 500 * 1024 ** 2


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def free_bytes() -> int:
    v = os.statvfs(CARGO)
    return v.f_bfree * v.f_frsize


def snapshot() -> dict:
    return {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
        'lock_sha256': sha(LOCK.read_bytes()),
        'config_sha256': sha(CONFIG.read_bytes()),
    }


def verify_tree(directory: Path, package_checksum: str) -> tuple[dict[str, str], int]:
    metadata = json.loads((directory / '.cargo-checksum.json').read_text())
    if metadata.get('package') != package_checksum:
        raise ValueError(f'package checksum mismatch: {directory.name}')
    files = {}
    size = 0
    for path in sorted(directory.rglob('*')):
        if path.is_symlink():
            raise ValueError(f'symlink in vendor: {path}')
        if path.is_file() and path.name != '.cargo-checksum.json':
            data = path.read_bytes()
            files[path.relative_to(directory).as_posix()] = sha(data)
            size += len(data)
    if files != metadata.get('files'):
        raise ValueError(f'file checksum mismatch: {directory.name}')
    return files, size


def main() -> int:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = snapshot()
    prior = json.loads(HISTORICAL.read_text())
    old_rows = {(p['name'], p['version']): p for p in prior['registry_packages']}
    packages = [p for p in tomllib.loads(LOCK.read_text())['package']
                if p.get('source', '').startswith('registry+')]
    expected_keys = {(p['name'], p['version']) for p in packages}
    if len(packages) != 136 or len(expected_keys) != 136 or set(old_rows) != expected_keys:
        raise ValueError('exact-lock package set differs from checked historical inventory')
    if before['lock_sha256'] != prior['cargo_lock_sha256']:
        raise ValueError('fuzz lock no longer matches checked historical source')
    if VENDOR.exists():
        raise ValueError('final vendor directory already exists; refusing replacement')
    initial_free = free_bytes()
    if initial_free < MIN_START:
        raise RuntimeError(f'insufficient initial free space: {initial_free}')
    if STAGING.exists():
        raise ValueError('staging directory exists; refusing implicit overwrite')
    STAGING.mkdir()
    rows = []
    samples = [{'after_packages': 0, 'free_bytes': initial_free}]
    result = 'INCOMPLETE'
    error = None
    try:
        for p in packages:
            available = free_bytes()
            if available < MIN_REMAINING:
                raise RuntimeError(f'paused at free-space floor: {available}')
            stem = p['name'] + '-' + p['version']
            archive = CACHE / (stem + '.crate')
            archive_data = archive.read_bytes()
            archive_hash = sha(archive_data)
            old = old_rows[(p['name'], p['version'])]
            if archive_hash != p['checksum'] or archive_hash != old['archive_sha256']:
                raise ValueError(f'archive mismatch: {stem}')
            destination = STAGING / stem
            destination.mkdir()
            file_hashes = {}
            total_size = 0
            with tarfile.open(archive, 'r:gz') as bundle:
                for member in bundle:
                    name = PurePosixPath(member.name)
                    if (name.is_absolute() or '..' in name.parts or not name.parts
                            or name.parts[0] != stem or not (member.isdir() or member.isfile())):
                        raise ValueError(f'unsafe or unsupported archive entry: {member.name}')
                    relative = PurePosixPath(*name.parts[1:])
                    if relative.as_posix() == '.':
                        if not member.isdir():
                            raise ValueError(f'archive root is not directory: {stem}')
                        continue
                    path = destination.joinpath(*relative.parts)
                    if member.isdir():
                        path.mkdir(parents=True, exist_ok=True)
                        continue
                    if relative.as_posix() == '.cargo-checksum.json':
                        raise ValueError('upstream archive unexpectedly contains cargo checksum file')
                    if len(file_hashes) % 64 == 0 and free_bytes() < MIN_REMAINING:
                        raise RuntimeError('paused at free-space floor during package extraction')
                    path.parent.mkdir(parents=True, exist_ok=True)
                    source = bundle.extractfile(member)
                    if source is None:
                        raise ValueError(f'unreadable regular file: {member.name}')
                    data = source.read()
                    if len(data) != member.size:
                        raise ValueError(f'truncated archive member: {member.name}')
                    with path.open('xb') as sink:
                        sink.write(data)
                    path.chmod(0o755 if member.mode & 0o111 else 0o644)
                    file_hashes[relative.as_posix()] = sha(data)
                    total_size += len(data)
            checksum = {'files': file_hashes, 'package': archive_hash}
            with (destination / '.cargo-checksum.json').open('xb') as sink:
                sink.write(canonical(checksum))
            verified_files, verified_bytes = verify_tree(destination, archive_hash)
            if verified_files != file_hashes or verified_bytes != total_size:
                raise ValueError(f'readback mismatch: {stem}')
            if len(file_hashes) != old['files'] or total_size != old['unpacked_bytes']:
                raise ValueError(f'historical file inventory mismatch: {stem}')
            rows.append({
                'name': p['name'], 'version': p['version'], 'source': p['source'],
                'archive_path': str(archive), 'archive_sha256': archive_hash,
                'archive_bytes': len(archive_data), 'expected_lock_sha256': p['checksum'],
                'files': len(file_hashes), 'unpacked_bytes': total_size,
                'file_inventory_sha256': sha(canonical(file_hashes)),
                'directory_checksum_sha256': sha((destination / '.cargo-checksum.json').read_bytes()),
                'historical_archive_and_inventory_match': True,
                'all_extracted_file_checksums_reverified': True,
            })
            samples.append({'after_packages': len(rows), 'free_bytes': free_bytes()})
        # Verify every package once more before publishing the completed cache.
        for row in rows:
            files, size = verify_tree(STAGING / (row['name'] + '-' + row['version']), row['archive_sha256'])
            if sha(canonical(files)) != row['file_inventory_sha256'] or size != row['unpacked_bytes']:
                raise ValueError('final whole-directory readback failed')
            if sha(Path(row['archive_path']).read_bytes()) != row['archive_sha256']:
                raise ValueError('source archive changed while restoring')
        after = snapshot()
        if after['lock_sha256'] != before['lock_sha256'] or after['config_sha256'] != before['config_sha256']:
            raise ValueError('lock or local cargo config changed during restoration')
        os.rename(STAGING, VENDOR)
        result = 'PASS'
    except Exception as exc:
        error = f'{type(exc).__name__}: {exc}'
        after = snapshot()
    receipt = {
        'schema': 'trnm-exact-fuzz-vendor-restore-v1', 'result': result,
        'started_at_utc': started, 'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'command': 'PYTHONDONTWRITEBYTECODE=1 python ' + str(Path(__file__).resolve()),
        'driver_sha256': sha(Path(__file__).read_bytes()),
        'source_before': before, 'source_after': after,
        'historical_inventory_path': str(HISTORICAL),
        'historical_inventory_sha256': sha(HISTORICAL.read_bytes()),
        'scope': 'isolated exact-lock cache restoration only; no cargo invocation or repository edit',
        'native_build_executed': False, 'metadata_executed': False,
        'repository_written_by_driver': False, 'config_written_by_driver': False,
        'source_archives_written_by_driver': False, 'network_used': False,
        'lock_and_config_unchanged': before['lock_sha256'] == after['lock_sha256'] and before['config_sha256'] == after['config_sha256'],
        'source_head_observed_unchanged': before['head'] == after['head'],
        'vendor_directory': str(VENDOR), 'incomplete_staging_directory': str(STAGING) if STAGING.exists() else None,
        'completed_registry_packages': len(rows), 'expected_registry_packages': len(packages),
        'archive_bytes': sum(r['archive_bytes'] for r in rows),
        'unpacked_regular_bytes': sum(r['unpacked_bytes'] for r in rows),
        'regular_files': sum(r['files'] for r in rows),
        'registry_packages': rows,
        'space_limits': {'minimum_start_free_bytes': MIN_START, 'pause_below_free_bytes': MIN_REMAINING},
        'free_space_samples': samples, 'final_free_bytes': free_bytes(), 'error': error,
    }
    receipt_path = OUT / 'receipt.json'
    with receipt_path.open('x') as sink:
        json.dump(receipt, sink, sort_keys=True, indent=2)
        sink.write('\n')
        sink.flush()
        os.fsync(sink.fileno())
    print(json.dumps({k: receipt[k] for k in ('result', 'completed_registry_packages', 'regular_files',
                                           'unpacked_regular_bytes', 'lock_and_config_unchanged',
                                           'source_head_observed_unchanged', 'final_free_bytes', 'error')}, indent=2))
    print('receipt_path=' + str(receipt_path))
    print('receipt_sha256=' + sha(receipt_path.read_bytes()))
    return 0 if result == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
