//! Actual SmolLM next-use after TCA3 cold recovery and CHB1 sealed FD handoff.
//! Explicit single-operator research admission; no CURRENT/FinalUse/payment.

#[cfg(target_os = "linux")]
fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    linux::run()
}

#[cfg(not(target_os = "linux"))]
fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    Err("Linux immutable memfd and original wait4 owner required".into())
}

#[cfg(target_os = "linux")]
mod linux {
    use std::{
        collections::BTreeMap,
        error::Error,
        fs::{self, OpenOptions},
        io::{Read, Write},
        os::{
            fd::OwnedFd,
            unix::{
                fs::{OpenOptionsExt, PermissionsExt},
                net::UnixStream,
            },
        },
        path::{Path, PathBuf},
        process::{Command, Stdio},
        sync::atomic::AtomicBool,
        thread,
        time::{Duration, Instant, SystemTime, UNIX_EPOCH},
    };

    use serde::Deserialize;
    use serde_json::{json, Value};
    use sha2::{Digest, Sha256};
    use trnm_crypto_primitives::pq_auth::PqNativeSigningKey;
    use trnm_data_availability::cell::{pq::*, *};
    use trnm_protocol::pq_frame::ml_dsa_65_key_id_from_spki;
    use zeroize::Zeroizing;

    type Result<T> = std::result::Result<T, Box<dyn Error + Send + Sync>>;
    const BOOTSTRAP: &str = include_str!("../../../../scripts/cell_sealed_bootstrap_v1.py");
    const WORKER: &str = "scripts/llm_cell_sealed_worker_v1.py";
    const SNAPSHOT: &str = "runtime/runtime-snapshot.json";
    const SNAPSHOT_BOUND: u64 = 512 * 1024 * 1024;

    #[derive(Clone, Deserialize)]
    #[serde(deny_unknown_fields)]
    struct Input {
        path: PathBuf,
        sha256: String,
    }

    #[derive(Deserialize)]
    #[serde(deny_unknown_fields)]
    struct Context {
        family: String,
        base: String,
        parent: String,
        tokenizer: String,
        layout: String,
        runtime: String,
    }

    #[derive(Deserialize)]
    #[serde(deny_unknown_fields)]
    struct Spec {
        schema: String,
        operation: String,
        context: Context,
        environment_generation: u64,
        model: BTreeMap<String, Input>,
        environment: BTreeMap<String, Input>,
        python: Input,
        output: PathBuf,
        seconds: u64,
        max_snapshot_bytes: u64,
        runtime_rss_bytes: u64,
        threads: u32,
        material_profile: String,
        parent: CellHostResearchParentV1,
        requests: Vec<CellHostResearchQueryV1>,
    }

    fn check(value: bool, reason: &'static str) -> Result<()> {
        if value {
            Ok(())
        } else {
            Err(reason.into())
        }
    }

    fn digest(value: &str) -> Result<[u8; 32]> {
        check(
            value.len() == 64
                && value
                    .bytes()
                    .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)),
            "canonical independent SHA-256 pin required",
        )?;
        Ok(hex::decode(value)?
            .try_into()
            .map_err(|_| "digest length")?)
    }

    fn id(operation: &[u8; 32], domain: &[u8], extra: &[u8]) -> [u8; 32] {
        let mut hash = Sha256::new();
        hash.update(b"TRNM/Cell/SealedResearchOperation/v1\0");
        hash.update(operation);
        hash.update((domain.len() as u32).to_be_bytes());
        hash.update(domain);
        hash.update(extra);
        hash.finalize().into()
    }

    fn read_pinned(input: &Input, maximum: u64) -> Result<Vec<u8>> {
        check(
            input.path.is_absolute(),
            "independent input path must be absolute",
        )?;
        let mut file = OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
            .open(&input.path)?;
        let before = file.metadata()?;
        check(
            before.is_file() && before.len() > 0 && before.len() <= maximum,
            "bounded regular input required",
        )?;
        let mut raw = Vec::new();
        Read::by_ref(&mut file)
            .take(maximum + 1)
            .read_to_end(&mut raw)?;
        check(
            raw.len() as u64 == before.len()
                && file.metadata()?.len() == before.len()
                && <[u8; 32]>::from(Sha256::digest(&raw)) == digest(&input.sha256)?,
            "independent input bytes changed",
        )?;
        Ok(raw)
    }

    fn write_new(path: &Path, bytes: &[u8]) -> Result<()> {
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(path)?;
        file.write_all(bytes)?;
        file.sync_all()?;
        Ok(())
    }

    fn read_observation(path: &Path) -> Result<Vec<u8>> {
        let mut file = OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
            .open(path)?;
        let info = file.metadata()?;
        check(
            info.is_file() && info.len() > 0 && info.len() <= 131072,
            "bounded original observation",
        )?;
        let mut raw = Vec::new();
        Read::by_ref(&mut file).take(131073).read_to_end(&mut raw)?;
        check(
            raw.len() as u64 == info.len(),
            "original observation length",
        )?;
        Ok(raw)
    }

    fn cache(path: &Path) -> Result<CellStoreV1> {
        Ok(CellStoreV1::open(
            path,
            CellCacheConfigV4 {
                max_database_bytes: 1024 * 1024 * 1024,
                max_logical_bytes: SNAPSHOT_BOUND,
                max_chunk_rows: 2048,
                max_manifest_rows: 128,
            },
        )?)
    }

    fn owner(
        closure: &CellReleaseClosureV1,
        roles: Vec<CellFileRoleV1>,
        maximum: u64,
    ) -> CellLoaderContextV1 {
        CellLoaderContextV1 {
            closure_id: closure.id(),
            context: closure.release().context().clone(),
            selected_generation: closure.selected_generation(),
            loader_profile: closure.loader_profile(),
            required_roles: roles,
            max_payload_bytes: maximum,
            max_chunks: 2048,
        }
    }

    fn session(deadline: Instant, maximum: u64) -> Result<CellContentReadSessionV2> {
        Ok(CellContentReadSessionV2::new(
            CellReleaseLimitsV1 {
                max_payload_bytes: maximum,
                max_chunks: 2048,
                deadline,
            },
            1,
        )?)
    }

    fn pack(
        store: &CellStoreV1,
        inputs: &BTreeMap<String, Input>,
        context: &CellContextV1,
        environment: bool,
        deadline: Instant,
    ) -> Result<(Vec<CellManifestV1>, Vec<CellClosureFileV1>)> {
        let mut manifests = Vec::new();
        let mut files = Vec::new();
        for (path, input) in inputs {
            check(Instant::now() < deadline, "original research deadline")?;
            check(input.path.is_absolute(), "absolute original payload source")?;
            let mut source = OpenOptions::new()
                .read(true)
                .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
                .open(&input.path)?;
            let info = source.metadata()?;
            check(
                info.is_file() && info.len() > 0 && info.len() <= SNAPSHOT_BOUND,
                "bounded original payload source",
            )?;
            // Capture from one original regular FD with the caller's deadline
            // checked at each bounded chunk. Only these same captured bytes
            // enter the original CAS; no later mutable source reopen is used.
            let chunk_bytes = MAX_CHUNK_BYTES as usize;
            let mut buffer = vec![0; chunk_bytes];
            let mut remaining = info.len();
            let mut full = Sha256::new();
            let mut chunks = Vec::new();
            while remaining > 0 {
                check(
                    Instant::now() < deadline,
                    "original payload capture deadline",
                )?;
                let size = remaining.min(chunk_bytes as u64) as usize;
                source.read_exact(&mut buffer[..size])?;
                check(Instant::now() < deadline, "original payload read deadline")?;
                let chunk = CellChunkV1 {
                    size: size as u32,
                    sha256: Sha256::digest(&buffer[..size]).into(),
                };
                store.put_chunk(&chunk, &buffer[..size])?;
                full.update(&buffer[..size]);
                chunks.push(chunk);
                remaining -= size as u64;
            }
            check(
                source.read(&mut [0; 1])? == 0 && source.metadata()?.len() == info.len(),
                "original payload length changed",
            )?;
            let manifest = CellManifestV1::new(
                context.clone(),
                info.len(),
                full.finalize().into(),
                chunk_bytes as u32,
                chunks,
            )?;
            check(
                manifest.payload_sha256() == digest(&input.sha256)?,
                "packed input differs from independent pin",
            )?;
            check(
                Instant::now() < deadline,
                "original payload final capture deadline",
            )?;
            store.put_manifest(manifest.id(), &manifest.encode())?;
            let role = if environment {
                CellFileRoleV1::Configuration
            } else if path == "base/model.safetensors" {
                CellFileRoleV1::Base
            } else if path.starts_with("base/tokenizer") || path == "base/special_tokens_map.json" {
                CellFileRoleV1::Tokenizer
            } else if path == "adapter/artifact.safetensors" {
                CellFileRoleV1::Adapter
            } else {
                CellFileRoleV1::Configuration
            };
            files.push(CellClosureFileV1 {
                path: path.clone(),
                role,
                manifest: manifest.id(),
                payload_sha256: manifest.payload_sha256(),
                payload_bytes: manifest.size(),
                dependencies: vec![],
            });
            manifests.push(manifest);
        }
        Ok((manifests, files))
    }

    fn observe(spec: &Spec, report: &mut Value) -> Result<()> {
        check(
            (1..=300).contains(&spec.seconds),
            "original bounded research duration",
        )?;
        let started = Instant::now();
        let deadline = started + Duration::from_secs(spec.seconds);
        let operation = digest(&spec.operation)?;
        check(
            spec.schema == "trnm.cell-sealed-research-source.v1"
                && operation != [0; 32]
                && (1..=300).contains(&spec.seconds)
                && (1..=SNAPSHOT_BOUND).contains(&spec.max_snapshot_bytes)
                && (1..=8 * 1024_u64.pow(3)).contains(&spec.runtime_rss_bytes)
                && (1..=4).contains(&spec.threads)
                && spec.model.len() == 11
                && spec.environment.len() <= 32
                && spec.environment_generation > 0,
            "fresh research profile and finite original bounds",
        )?;
        let worker_input = spec
            .environment
            .get(WORKER)
            .ok_or("complete sealed worker absent")?;
        check(
            read_pinned(
                spec.environment
                    .get("scripts/cell_sealed_bootstrap_v1.py")
                    .ok_or("bootstrap absent")?,
                2 * 1024 * 1024,
            )? == BOOTSTRAP.as_bytes(),
            "compiled bootstrap does not match admitted environment",
        )?;
        let context = CellContextV1 {
            family: spec.context.family.clone(),
            base: digest(&spec.context.base)?,
            parent: digest(&spec.context.parent)?,
            tokenizer: digest(&spec.context.tokenizer)?,
            layout: digest(&spec.context.layout)?,
            runtime: digest(&spec.context.runtime)?,
        };
        check(
            context.runtime == digest(&worker_input.sha256)?,
            "worker context pin",
        )?;
        context.validate()?;
        read_pinned(&spec.python, 512 * 1024 * 1024)?;
        report["stage"] = json!("pack independently pinned actual sources");
        let source_path = spec.output.join("publisher.sqlite");
        let source = cache(&source_path)?;
        let (environment_manifests, environment_files) =
            pack(&source, &spec.environment, &context, true, deadline)?;
        let environment = CellReleaseClosureV1::new(
            context.clone(),
            spec.environment_generation,
            id(&operation, b"environment-loader", &[]),
            (0..environment_files.len() as u16).collect(),
            environment_files,
        )?;
        let mut model_context = context.clone();
        model_context.runtime = environment.id();
        let (model_manifests, mut model_files) =
            pack(&source, &spec.model, &model_context, false, deadline)?;
        check(
            model_files
                .first()
                .is_some_and(|f| f.path == "adapter/artifact.safetensors"),
            "complete model root",
        )?;
        model_files[0].dependencies = (1..model_files.len() as u16).collect();
        let model = CellModelReleaseRootV1::new(
            CellReleaseClosureV1::new(
                model_context,
                spec.parent.generation,
                id(&operation, b"model-loader", &[]),
                vec![0],
                model_files,
            )?,
            vec![],
        )?;
        let model_owner = owner(
            model.closure(),
            vec![
                CellFileRoleV1::Base,
                CellFileRoleV1::Tokenizer,
                CellFileRoleV1::Adapter,
            ],
            spec.max_snapshot_bytes,
        );
        let environment_owner = owner(
            &environment,
            vec![CellFileRoleV1::Configuration],
            spec.max_snapshot_bytes,
        );
        let mut manifests = model_manifests;
        manifests.extend(environment_manifests);
        manifests.sort_by_key(CellManifestV1::id);
        let version = CellVersionManifestV1::new(model, environment, manifests)?;
        let owner_view = CellVersionLoaderContextV1 {
            commitment: version.commitment(),
            model: &model_owner,
            environment: &environment_owner,
        };
        let total: u64 = version.manifests().iter().map(CellManifestV1::size).sum();
        check(
            total <= spec.max_snapshot_bytes,
            "complete-version original memory allowance",
        )?;
        let content = CellVersionContentV2::capture_cached(
            &version,
            &source,
            &owner_view,
            &mut session(deadline, spec.max_snapshot_bytes)?,
        )?;
        report["input"] = json!({"payload_bytes": total, "manifest_count": version.manifests().len(),
            "tcv1": hex::encode(version.commitment()), "tcv2": hex::encode(content.commitment()),
            "independent_input_pins": true});

        report["stage"] = json!("original TCA3 complete physical retention");
        let config = CellVersionRetentionConfigV3 {
            retention: CellRetentionConfigV1 {
                store_id: id(&operation, b"store", &[]),
                capacity_bytes: SNAPSHOT_BOUND,
                maximum_obligations: 128,
            },
            maximum_versions: 16,
            maximum_metadata_bytes: 64 << 20,
        };
        let contract = CellVersionRetentionContractV3 {
            operation,
            funding_operation: id(&operation, b"declared-local-funding", &[]),
            responsible_owner: id(&operation, b"local-research-owner", &[]),
            failure_domain: id(&operation, b"single-host-domain", &[]),
            replica_index: 0,
            required_replicas: 1,
            retain_from_height: 1,
            retain_until_height: 100,
            repair_deadline_height: 90,
            version: version.clone(),
            model: CellVersionLoaderPinV3::from_context(&model_owner),
            environment: CellVersionLoaderPinV3::from_context(&environment_owner),
            tensor_model: None,
            snapshot: None,
            objects: version
                .manifests()
                .iter()
                .map(|m| CellRetentionContractV1 {
                    operation: id(&operation, b"object", &m.id()),
                    funding_operation: id(&operation, b"object-funding", &m.id()),
                    manifest: m.clone(),
                    retain_from_height: 1,
                    retain_until_height: 100,
                    maximum_repair_bytes: m.size(),
                    successor: None,
                })
                .collect(),
        };
        let archive_path = spec.output.join("retained");
        let mut archive = CellVersionRetentionStoreV3::create(&archive_path, config.clone())?;
        archive.reserve_version(contract, archive.anchor(deadline)?, deadline)?;
        archive.acknowledge_version(operation, &source, deadline)?;
        let anchor = archive.anchor(deadline)?;
        write_new(
            &spec.output.join("independent-catalog-anchor.cva3"),
            &anchor.encode(),
        )?;
        drop(archive);
        drop(source);
        fs::remove_file(&source_path)?;
        for extension in ["sqlite-wal", "sqlite-shm"] {
            let path = source_path.with_extension(extension);
            if path.exists() {
                fs::remove_file(path)?;
            }
        }
        report["stage"] = json!("reopen anchored owner and actual cold arena restore");
        let mut archive = CellVersionRetentionStoreV3::open(&archive_path, config, anchor)?;
        let consumer = cache(&spec.output.join("consumer.sqlite"))?;
        check(
            consumer.cache_usage()?.chunk_rows == 0,
            "consumer must be actually cold",
        )?;
        archive.populate_cache(operation, &consumer, deadline)?;
        report["cold_restore"] = json!({"source_cache_absent": !source_path.exists(),
            "anchored_reopen": true, "actual_target_readback": true,
            "consumer_chunks": consumer.cache_usage()?.chunk_rows,
            "m12_funding_admitted": false, "retention_heights_are_research_terms": true});

        report["stage"] = json!("actual CPV4 consumer verification and joint residency");
        let timestamp = SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs();
        let mut seed = Zeroizing::new([0_u8; 32]);
        getrandom::getrandom(seed.as_mut()).map_err(|_| "research key generation failed")?;
        let spki = PqNativeSigningKey::public_spki_from_seed(&seed);
        let key_id = ml_dsa_65_key_id_from_spki(&spki).map_err(|_| "research SPKI")?;
        let key = PqNativeSigningKey::from_owned_seed(seed, key_id)?;
        let key_pin = CellPqKeyPinV2 {
            key_id,
            generation: 1,
            spki,
            not_before: timestamp.saturating_sub(1),
            expires_at: timestamp + 300,
            revoked_at: None,
        };
        let authorization = CellPqContentAuthorizationV4::sign(
            CellPqContentStatementV4 {
                network: id(&operation, b"research-network", &[]),
                parameters: id(&operation, b"research-parameters", &[]),
                content: content.commitment(),
                signer_key_id: key_pin.key_id,
                signer_spki_sha512: CellPqContentStatementV4::signer_commitment(&key_pin.spki),
                generation: 1,
                sequence: 1,
                issued_at: timestamp,
                expires_at: timestamp + 300,
                withdrawn: false,
            },
            &key,
        )?;
        let expected = CellPqContentExpectationV4 {
            authority: CellPqReleaseExpectationV2 {
                network: id(&operation, b"research-network", &[]),
                parameters: id(&operation, b"research-parameters", &[]),
                key: &key_pin,
                sequence: 1,
                now: SystemTime::now().duration_since(UNIX_EPOCH)?.as_secs(),
            },
            loader: owner_view,
            content: content.commitment(),
        };
        let mut read_session = session(deadline, spec.max_snapshot_bytes)?;
        let verified =
            authorization.verify_cached_at(&content, &consumer, &expected, &mut read_session)?;
        let cancelled = AtomicBool::new(false);
        let limits = CellResidencyConfigV1 {
            max_resident_bytes: spec.max_snapshot_bytes,
            max_resident_closures: 2,
            max_chunk_references: 2048,
        };
        let mut pool = CellResidencyV1::new(limits)?;
        for (closure, owner) in [
            (version.model().closure(), &model_owner),
            (version.environment(), &environment_owner),
        ] {
            pool.prepare_cached(&consumer, closure, owner, deadline, &cancelled)?;
        }
        // Both closures must be admitted together under the same finite RAM
        // owner before creating any process-visible snapshot.
        let admitted = pool.admit_local_version(
            operation,
            &version,
            &expected.loader,
            limits,
            deadline,
            &cancelled,
        )?;
        admitted.with_local(operation, &expected.loader, |_| ())?;
        drop(admitted);
        let seal_limits = CellSealedLoaderLimitsV1 {
            max_snapshot_bytes: spec.max_snapshot_bytes,
            max_files: 64,
        };
        let model_bundle =
            pool.seal_declared_loader(&model_owner, seal_limits, deadline, &cancelled)?;
        let environment_bundle =
            pool.seal_declared_loader(&environment_owner, seal_limits, deadline, &cancelled)?;
        let descriptor = CellHostHandoffDescriptorV1 {
            operation,
            owner_generation: 1,
            content: content.commitment(),
            version: version.commitment(),
            model_closure: version.model().closure().id(),
            environment_closure: version.environment().id(),
            model_generation: spec.parent.generation,
            environment_generation: spec.environment_generation,
            worker_context: context,
            worker_path: WORKER.into(),
            runtime_snapshot_path: SNAPSHOT.into(),
            runtime_snapshot_sha256: digest(
                &spec
                    .environment
                    .get(SNAPSHOT)
                    .ok_or("runtime snapshot absent")?
                    .sha256,
            )?,
        };
        let descriptor_pin = descriptor.commitment()?;
        let handoff = descriptor.bind_authenticated(
            descriptor_pin,
            &verified,
            &expected,
            (&model_bundle, &environment_bundle),
            deadline,
        )?;
        write_new(
            &spec.output.join("owner-handoff.chb1"),
            &descriptor.encode()?,
        )?;
        write_new(&spec.output.join("owner-content.tcv2"), &content.encode())?;
        write_new(
            &spec.output.join("owner-authorization.cpv4"),
            &authorization.encode()?,
        )?;
        // The two actual task reads must remain possible without either local
        // cache pathname. Only this operation's newly created cache is removed;
        // the original input materials and retained owner remain untouched.
        drop(consumer);
        let consumer_path = spec.output.join("consumer.sqlite");
        fs::remove_file(&consumer_path)?;
        for extension in ["sqlite-wal", "sqlite-shm"] {
            let path = consumer_path.with_extension(extension);
            if path.exists() {
                fs::remove_file(path)?;
            }
        }
        report["sealed_cache_independence"] = json!({
            "publisher_cache_absent": !source_path.exists(),
            "consumer_cache_absent": !consumer_path.exists(),
            "original_source_materials_preserved": true,
        });
        let execution = CellHostResearchExecutionV1 {
            schema: "trnm.cell-sealed-research-execution.v1".into(),
            operation: spec.operation.clone(),
            descriptor: hex::encode(descriptor_pin),
            environment_pins: spec
                .environment
                .iter()
                .map(|(path, input)| (path.clone(), input.sha256.clone()))
                .collect(),
            max_snapshot_bytes: spec.max_snapshot_bytes,
            runtime_rss_bytes: spec.runtime_rss_bytes,
            python: spec.python.path.to_str().ok_or("Python path UTF-8")?.into(),
            python_sha256: spec.python.sha256.clone(),
            output: spec.output.to_str().ok_or("output path UTF-8")?.into(),
            threads: spec.threads,
            material_profile: spec.material_profile.clone(),
            parent: spec.parent.clone(),
            requests: spec.requests.clone(),
        };
        write_new(
            &spec.output.join("independent-execution-inputs.json"),
            &serde_json::to_vec_pretty(&execution)?,
        )?;
        report["handoff"] = json!({"descriptor": hex::encode(descriptor_pin),
            "worker_sha256": worker_input.sha256, "model_bytes": model_bundle.snapshot_bytes(),
            "environment_bytes": environment_bundle.snapshot_bytes(),
            "kernel_descriptors": model_bundle.file_count() + environment_bundle.file_count(),
            "signer_key_id": hex::encode(key_id), "single_operator_research_key": true});

        report["stage"] = json!("original wait4 owner and two actual sealed-byte forwards");
        check(Instant::now() < deadline, "original process start deadline")?;
        let (mut producer, receiver) = UnixStream::pair()?;
        let receiver: OwnedFd = receiver.into();
        let stdout = OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(spec.output.join("supervisor.stdout"))?;
        let stderr = OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(spec.output.join("supervisor.stderr"))?;
        let temporary = spec.output.join("python-tmp");
        fs::create_dir(&temporary)?;
        fs::set_permissions(&temporary, fs::Permissions::from_mode(0o700))?;
        let bootstrap_sha = hex::encode(Sha256::digest(BOOTSTRAP.as_bytes()));
        // The only executed bootstrap is the exact source embedded in this
        // binary and compared above with its independently pinned sealed member.
        let mut child = Command::new(&spec.python.path)
            .args(["-I", "-S", "-B", "-X"])
            .arg(format!(
                "pycache_prefix={}",
                spec.output.join("unused-supervisor-bytecode").display()
            ))
            .args(["-c", BOOTSTRAP])
            .arg(hex::encode(descriptor_pin))
            .arg(&worker_input.sha256)
            .args(["supervisor", "stdin"])
            .arg(&bootstrap_sha)
            .env_clear()
            .env("LANG", "C.UTF-8")
            .env("LC_ALL", "C.UTF-8")
            .env("TMPDIR", &temporary)
            .stdin(Stdio::from(receiver))
            .stdout(stdout)
            .stderr(stderr)
            .spawn()?;
        let handed = handoff.send_research_fds_v1(&mut producer, &execution, deadline, &cancelled);
        drop(producer);
        let mut terminated = false;
        let mut termination_error = None;
        if handed.is_err() {
            if let Err(error) = rustix::process::kill_process(
                rustix::process::Pid::from_child(&child),
                rustix::process::Signal::TERM,
            ) {
                termination_error = Some(error.to_string());
            }
            terminated = true;
        }
        let status = loop {
            if let Some(status) = child.try_wait()? {
                break status;
            }
            if Instant::now() >= deadline && !terminated {
                // TERM invokes the original cooperative supervisor, which owns
                // termination and the exact wait4 of its child. We retain all
                // sealed data until that owner has itself exited. No refund or
                // successful-use receipt is emitted while cleanup is pending.
                if let Err(error) = rustix::process::kill_process(
                    rustix::process::Pid::from_child(&child),
                    rustix::process::Signal::TERM,
                ) {
                    termination_error = Some(error.to_string());
                }
                terminated = true;
            }
            thread::sleep(Duration::from_millis(20));
        };
        report["process"] = json!({"exit_code": status.code(), "termination_requested": terminated,
            "termination_error": termination_error,
            "elapsed_ms": started.elapsed().as_millis(), "original_seconds": spec.seconds,
            "sealed_bundles_held_until_supervisor_exit": true});
        handed?;
        check(
            status.success() && !terminated && Instant::now() < deadline,
            "actual research worker or original deadline failed; retain raw observations",
        )?;
        let final_result: Value = serde_json::from_slice(&read_observation(
            &spec.output.join("next-use-result.json"),
        )?)?;
        check(
            final_result["observations"] == 2
                && final_result["connector_complete"] == true
                && final_result["failures"]
                    .as_array()
                    .is_some_and(Vec::is_empty)
                && final_result["supervisor"]["outcome"] == "success"
                && final_result["supervisor"]["waited_child_reaped"] == true,
            "original wait4 and two fresh actual forward receipts required",
        )?;
        report["stage"] = json!("complete research next-use");
        report["actual_next_use"] = final_result;
        check(
            Instant::now() < deadline,
            "original final observation deadline",
        )?;
        Ok(())
    }

    pub fn run() -> Result<()> {
        let arguments: Vec<_> = std::env::args().collect();
        check(
            arguments.len() == 3,
            "usage: cell_sealed_research_next_use_v1 SOURCE_JSON INDEPENDENT_SHA256",
        )?;
        let raw = read_pinned(
            &Input {
                path: PathBuf::from(&arguments[1]),
                sha256: arguments[2].clone(),
            },
            128 * 1024,
        )?;
        let spec: Spec = serde_json::from_slice(&raw)?;
        check(
            spec.output.is_absolute(),
            "absolute create-only output required",
        )?;
        fs::create_dir(&spec.output)?;
        fs::set_permissions(&spec.output, fs::Permissions::from_mode(0o700))?;
        write_new(&spec.output.join("original-source-inputs.json"), &raw)?;
        let mut report = json!({"schema": "trnm.cell-sealed-research-native.v1", "stage": "initial",
            "source_input_sha256": arguments[2], "original_hepta_owner_used": false,
            "hepta_final_use": false, "installation_authorized": false, "m12_funding_admitted": false,
            "independent_operators": false, "production_activation": false});
        let result = observe(&spec, &mut report);
        report["passed"] = json!(result.is_ok());
        if let Err(error) = &result {
            report["error"] = json!(error.to_string());
        }
        write_new(
            &spec.output.join("native-result.json"),
            &serde_json::to_vec_pretty(&report)?,
        )?;
        println!("{}", serde_json::to_string(&report)?);
        result
    }
}
