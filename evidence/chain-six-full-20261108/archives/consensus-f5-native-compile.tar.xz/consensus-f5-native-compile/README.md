# Exact F5 native compile validation

All eight requested stages passed on commit
ab610cf95a6ec39b38e20e64e6367f5b529b3633, tree
abd4442d789b29889960f9b0acc712b9fefed498.

The original complete source verifier checked 26,114 tracked entries and
2,483,808,033 bytes before and after. Both records are byte-identical and the
worktree remained clean. The original project preflight passed.

The exact Cargo +1.95.0 Clippy command selected trnm-pon-node, all targets and
all features, with --locked --offline, two jobs and -D warnings. It passed in
91.429555 seconds. This compiles the shared generated inventory consumers
including examples and test targets; it does not execute their tests.

The original workspace format check passed in 20.624572 seconds. Three original
locked, offline, complete metadata commands passed: the default workspace graph
contains 176 packages and 26 workspace members; the all-features graph contains
181 packages and 26 members; the fuzz graph contains 149 packages and one member.
Their full original JSON output is included, not only aggregate counts.
The reader checked complete resolve data, workspace identity, local package
boundaries and the external target directory.

Actual Cargo and rustc versions were 1.95.0. The actual OpenSSL 3.5.9 binary
matched SHA-256 8ff7dd91270fd4a8fc377031f0fd2f2cee1cd17a32ce30e4fd773a25730a120f.
The Runtime request retained CPU quota 200 percent, memory maximum 8 GiB,
nice 10, two Cargo jobs and a 1200-second limit per gate. No timeout occurred.
Complete command stdout/stderr, argv, timings, environment identity and source
guards are in this directory. Runtime job 1a1bd3f0286-138b0-649 ended succeeded,
exit 0, with complete durable output; its launch and terminal records are included.

This is a compile and source-integrity observation. No native executable or test
was run here, no native benchmark budget was changed, and no original failed
observation was reclassified. The qualification remains HOLD_NO_GO.

The archive contains all files named in MANIFEST.json plus that manifest,
with byte-for-byte archive readback verification. No build cache, compiled
binary, database or repository checkout is included.
