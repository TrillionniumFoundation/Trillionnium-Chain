#!/usr/bin/env python3
"""Run the original Node library suite, then its original 52 PQ controls.

Scratch-only adapter: no build, retry, ignored-test opt-in, or new test is added.
The original workflow supplies both the required-selector builder and the full
library libtest arguments. The actual ELF registry supplies observed counts.
External historical build/provider receipts are retained, not reconstructed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import sys
import tomllib
import traceback

import run_exact_selected_controls as common

WORKFLOW = '.github/workflows/pon-pq-system-continuation.yml'
MANIFEST = 'config/pon/pq-system-required-tests-v1.json'
REQUIRED_STEP = 'Execute every required native effect and rejection control'
FULL_STEP = 'Preserve the complete original Node library regression suite'
EXPECTED_BUILDER_SHA256 = '0b873548a9d2f480deba28ec3a4cc86476013946d6f20d2a245d9127cf6235cd'
EXPECTED_COMMON_SHA256 = 'a8f8656fe25038fb67939b360b42631b6856dab9bd302365cd53591be2108e55'
EXPECTED_REQUIRED_COUNT = 52
TARGETS = {'node': ('trnm-pon-node', 'trnm_pon_node')}


def full_library_command(workflow: Path) -> dict:
    text = workflow.read_text()
    marker = '      - name: ' + FULL_STEP + '\n'
    common.require(text.count(marker) == 1, 'full Node library workflow step is not unique')
    step = text.split(marker, 1)[1].split('\n      - name:', 1)[0]
    commands = [line.strip() for line in step.splitlines()
                if line.strip().startswith('bash "$PQ_OUT/run-command.sh" node-lib ')]
    common.require(len(commands) == 1, 'expected one original full Node library command')
    argv = shlex.split(commands[0])
    common.require(argv.count('--') == 1, 'ambiguous original Cargo/libtest separator')
    separator = argv.index('--')
    cargo = argv[:separator]
    common.require('--lib' in cargo and '--all-features' in cargo
                   and ['-p', 'trnm-pon-node'] == cargo[cargo.index('-p'):cargo.index('-p') + 2],
                   'original full library command changed its package/features')
    flags = argv[separator + 1:]
    common.require('--show-output' in flags and '--test-threads=1' in flags,
                   'original full library capture/thread policy changed')
    common.require('--ignored' not in flags and '--include-ignored' not in flags,
                   'this reviewed full-suite runner does not opt into ignored controls')
    # Preserve any original --skip arguments verbatim; do not invent exclusions.
    return {'original_shell_command': commands[0], 'original_argv': argv,
            'libtest_argv': flags}


def require_node_profile(repo: Path, artifact: dict, target_dir: Path) -> dict:
    package = tomllib.loads((repo / 'trillionnium/crates/trnm-pon-node/Cargo.toml').read_text())
    workspace = tomllib.loads((repo / 'trillionnium/Cargo.toml').read_text())
    declared = workspace['profile']['test']['package']['trnm-pon-node']
    observed = artifact['artifact']['profile']
    features = sorted(package['features'])
    common.require(features == ['default', 'pq-native-openssl'], 'reviewed Node feature set changed')
    common.require(artifact['artifact']['features'] == features, 'Node ELF is not all-features')
    common.require(declared['opt-level'] == 3 and declared['debug-assertions'] is True
                   and declared['overflow-checks'] is True, 'original Node test profile changed')
    common.require(observed['test'] is True and observed['opt_level'] == '3'
                   and observed['debug_assertions'] is True and observed['overflow_checks'] is True,
                   'actual Node ELF does not retain the original test profile/checks')
    common.require(Path(artifact['binary']).resolve(strict=True).parent == target_dir / 'debug/deps',
                   'Node ELF is outside the supplied original debug/deps target')
    return {'declared_package_profile': declared, 'actual_profile': observed,
            'all_features': features, 'target_directory': str(target_dir)}


def require_build_receipt(build: dict, source: dict, out: Path) -> dict:
    linked = build['external_build_receipt']
    common.require(linked is not None, 'the actual external build receipt is required')
    value = linked['receipt']
    common.require(type(value.get('exit_code')) is int and value['exit_code'] == 0,
                   'external build did not finish with an actual zero exit')
    common.require(value.get('source') == source['tested_commit']
                   and value.get('tree') == source['tested_tree'],
                   'external build source/tree differs from current execution source')
    common.require(value.get('features') == 'all-features'
                   and value.get('profile') == 'test (unmodified)',
                   'external build did not record the original all-features test profile')
    command = value.get('command')
    common.require(isinstance(command, list) and all(isinstance(item, str) for item in command),
                   'external build command is not an argument array')
    common.require(all(flag in command for flag in ('--locked', '--lib', '--all-features',
                                                    '--no-run', '--message-format=json'))
                   and '--release' not in command, 'external build command is not the original test build')
    provider = value.get('provider_receipt')
    common.require(isinstance(provider, str) and bool(provider),
                   'missing actual provider receipt path')
    provider_path = Path(provider)
    if not provider_path.is_absolute():
        # This producer stores paths relative to its build receipt directory.
        # Bind that explicit base; do not search the cwd or accept path escape.
        base = Path(linked['files']['input']['path']).parent.resolve(strict=True)
        common.require(provider_path.as_posix() == provider and '..' not in provider_path.parts,
                       'noncanonical relative provider receipt path')
        provider_path = base / provider_path
        common.require(provider_path.resolve(strict=True).is_relative_to(base),
                       'relative provider receipt escapes the build receipt directory')
    preserved = common.snapshot_file(provider_path, out / 'build-inputs/provider-receipt.json')
    return {'source': value['source'], 'tree': value['tree'], 'exit_code': value['exit_code'],
            'provider_reference': provider, 'provider_receipt': preserved,
            'scope': 'actual supplied build and provider records; no historical source checkpoint is manufactured'}


def full_library_verdict(execution: dict, registry_count: int) -> dict:
    """Read the original final harness summary without assuming a suite count."""
    result = {'passed': False, 'registry_count': registry_count,
              'scope': 'full original libtest invocation, including its ordinary child harness entries; '
                       'not a substitute for the 52 meaningful required controls'}
    try:
        text = Path(execution['stdout_path']).read_text()
        summaries = re.findall(
            r'^test result: (ok|FAILED)\. ([0-9]+) passed; ([0-9]+) failed; '
            r'([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out; '
            r'finished in ([0-9]+(?:\.[0-9]+)?)s$', text, re.M)
        common.require(bool(summaries), 'missing terminal full-library harness summary')
        status, passed, failed, ignored, measured, filtered, seconds = summaries[-1]
        counts = dict(zip(('passed', 'failed', 'ignored', 'measured', 'filtered'),
                          map(int, (passed, failed, ignored, measured, filtered))))
        running = re.search(r'^running ([0-9]+) tests?$', text, re.M)
        common.require(running is not None, 'missing actual full-library running count')
        result.update(harness_status=status, counts=counts, harness_seconds=seconds,
                      running=int(running[1]))
        common.require(sum(counts.values()) == registry_count,
                       'full-library result does not account for the actual registry')
        common.require(int(running[1]) + counts['filtered'] == registry_count,
                       'full-library running/filter count does not match actual registry')
        result['passed'] = (common.capture_passed(execution) and status == 'ok'
                            and counts['passed'] > 0 and counts['failed'] == 0
                            and counts['measured'] == 0)
    except Exception:
        result['error'] = traceback.format_exc()
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--remote-root', type=Path, default=common.DEFAULT_REMOTE_ROOT)
    parser.add_argument('--repo-root', type=Path)
    parser.add_argument('--build-jsonl', type=Path, required=True)
    parser.add_argument('--build-stderr', type=Path, required=True)
    parser.add_argument('--build-receipt', type=Path, required=True)
    parser.add_argument('--target-dir', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    common.require(re.fullmatch(r'[0-9a-f]{40}', args.expected_head) is not None,
                   'expected head must be an exact Git commit')
    repo = (args.repo_root or args.remote_root / 'repo').resolve(strict=True)
    target_dir = args.target_dir.resolve(strict=True)
    out = args.output.resolve()
    common.require(not out.is_relative_to(repo), 'receipts must remain outside the source checkout')
    out.mkdir(parents=True, exist_ok=False)
    controls = out / 'required-controls'
    controls.mkdir()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', RUST_TEST_THREADS='1',
               CARGO_TARGET_DIR=str(target_dir))
    report = {'schema': 'trnm-pq-actual-elf-required-controls-v1', 'started_utc': common.utc_now(),
              'expected_head': args.expected_head, 'repo': str(repo),
              'runner': common.file_receipt(Path(__file__).resolve()),
              'shared_helper': common.file_receipt(Path(common.__file__).resolve()),
              'planned_full_library_invocations': 1, 'planned_required_controls': EXPECTED_REQUIRED_COUNT,
              'retry_policy': 'none', 'source_before': None, 'source_after': None,
              'build': None, 'full_library': None, 'dispatches': [], 'selectors': [], 'errors': [],
              'scope': 'original all-features Node library suite plus explicit 52 PQ component controls; '
                       'not whole-chain PQ qualification, fixed Host confirmation acceptance, or production TPS'}
    artifact = None
    try:
        common.require(report['shared_helper']['sha256'] == EXPECTED_COMMON_SHA256,
                       'shared helper differs from the reviewed version')
        report['source_before'] = common.source_checkpoint(repo, args.expected_head, out, 'source-before', env)
        common.require(report['source_before']['passed'], 'original source-before checker failed')
        report['build'] = common.load_build_artifacts(
            repo, args.build_jsonl.resolve(strict=True), args.build_stderr.resolve(strict=True),
            out, TARGETS, build_receipt=args.build_receipt.resolve(strict=True))
        report['build_binding'] = require_build_receipt(report['build'], report['source_before']['receipt'], out)
        artifact = report['build']['artifacts']['node']
        report['node_profile'] = require_node_profile(repo, artifact, target_dir)
        workflow = repo / WORKFLOW
        report['workflow'] = common.file_receipt(workflow)
        builder = common.extract_heredoc(workflow, 'PY', REQUIRED_STEP)
        common.require(hashlib.sha256(builder.encode()).hexdigest() == EXPECTED_BUILDER_SHA256,
                       'original required-selector builder changed from the reviewed version')
        builder_path = controls / 'original-required-selector-builder.py'
        with builder_path.open('x') as stream:
            stream.write(builder)
        roster = controls / 'required-tests.tsv'
        report['builder_source'] = common.file_receipt(builder_path)
        report['builder'] = common.run_capture([sys.executable, str(builder_path), str(roster)],
                                               repo, env, controls / 'required-selector-builder')
        common.require(common.capture_passed(report['builder']), 'original 52-selector builder failed')
        selected = [line.split('\t') for line in roster.read_text().splitlines()]
        manifest = json.loads((repo / MANIFEST).read_text())
        common.require(len(selected) == EXPECTED_REQUIRED_COUNT
                       and selected == [[f'native-{index:02d}', name]
                                        for index, name in enumerate(manifest['tests'])],
                       'original required roster order/count changed')
        report['manifest'] = common.file_receipt(repo / MANIFEST)
        report['child_process_harnesses_not_counted'] = manifest['child_process_harnesses_not_counted']
        registry_run = common.run_capture([artifact['binary'], '--list', '--format', 'terse'],
                                          Path(artifact['cwd']), env, controls / 'node-registry')
        report['registry_execution'] = registry_run
        common.require(common.capture_passed(registry_run), 'actual Node libtest registry failed')
        names = re.findall(r'^([A-Za-z_][A-Za-z0-9_:]*): test$',
                           Path(registry_run['stdout_path']).read_text(), re.M)
        common.require(names and len(names) == len(set(names)), 'empty or duplicate actual Node registry')
        common.require(all(selector in names for _label, selector in selected),
                       'required PQ control missing from actual Node registry')
        report['registry_count'] = len(names)
        common.write_json(controls / 'required-plan.json', {
            'selected': selected, 'actual_registry_count': len(names), 'retry_policy': 'none',
            'child_process_harnesses_not_counted': report['child_process_harnesses_not_counted'],
        })
        full_command = full_library_command(workflow)
        report['original_full_library_command'] = full_command
        common.require(common.file_receipt(Path(artifact['binary'])) == artifact['identity'],
                       'Node ELF changed before full library suite')
        full = common.run_capture([artifact['binary'], *full_command['libtest_argv']],
                                  Path(artifact['cwd']), env, out / 'node-lib',
                                  time_output=out / 'node-lib.resources.txt')
        report['full_library'] = {'execution': full, 'verdict': full_library_verdict(full, len(names))}
        common.write_json(out / 'node-lib.execution.json', report['full_library'])
        common.require(common.file_receipt(Path(artifact['binary'])) == artifact['identity'],
                       'Node ELF changed during full library suite')
        required_flags = '"$selector" -- --exact --show-output --test-threads=1; then'
        required_section = workflow.read_text().split('      - name: ' + REQUIRED_STEP + '\n', 1)[1]
        required_section = required_section.split('\n      - name:', 1)[0]
        common.require(required_section.count(required_flags) == 1,
                       'original required-control capture/thread policy changed')
        with (controls / 'test-exits.tsv').open('x') as exits:
            exits.write('label\tselector\tnative_exit\tlog_exit\treader_exit\tconfirmed\n')
            exits.flush()
            for index, (label, selector) in enumerate(selected):
                report['dispatches'].append({'index': index, 'label': label, 'selector': selector})
                print(json.dumps({'event': 'required-start', 'label': label, 'selector': selector}), flush=True)
                result = common.run_required_selector(artifact, 'pq-required', selector, index,
                                                      repo, controls, env, capture_flag='--show-output')
                result['original_workflow_label'] = label
                report['selectors'].append(result)
                exits.write(f'{label}\t{selector}\t{result["native"]["native_exit"]}\t'
                            f'{result["native"]["log_exit"]}\t{result["reader_exit"]}\t'
                            f'{int(result["confirmed_named_execution"])}\n')
                exits.flush()
                print(json.dumps({'event': 'required-finish', 'label': label, 'passed': result['passed']}), flush=True)
    except Exception:
        report['errors'].append(traceback.format_exc())
    finally:
        if artifact is not None:
            try:
                after = common.file_receipt(Path(artifact['binary']))
                report['artifact_after'] = {'identity': after, 'unchanged': after == artifact['identity']}
                common.require(after == artifact['identity'], 'Node ELF changed during this run')
            except Exception:
                report['errors'].append(traceback.format_exc())
        try:
            report['source_after'] = common.source_checkpoint(repo, args.expected_head, out, 'source-after', env)
            common.require(report['source_after']['passed'], 'original source-after checker failed')
            common.require(report['source_before'] is not None
                           and report['source_before']['receipt'] == report['source_after']['receipt'],
                           'source-before and source-after differ')
        except Exception:
            report['errors'].append(traceback.format_exc())
        report['dispatched_selector_count'] = len(report['dispatches'])
        report['completed_selector_receipts'] = len(report['selectors'])
        report['confirmed_named_execution_count'] = sum(row['confirmed_named_execution'] for row in report['selectors'])
        report['passed_selector_count'] = sum(row['passed'] for row in report['selectors'])
        report['finished_utc'] = common.utc_now()
        report['passed'] = (not report['errors'] and report['full_library'] is not None
                            and report['full_library']['verdict']['passed']
                            and report['completed_selector_receipts'] == EXPECTED_REQUIRED_COUNT
                            and report['confirmed_named_execution_count'] == EXPECTED_REQUIRED_COUNT
                            and report['passed_selector_count'] == EXPECTED_REQUIRED_COUNT)
        (out / 'pq-required.exit').write_text('0\n' if report['passed'] else '1\n')
        common.write_json(out / 'summary.json', report)
        common.write_json(out / 'receipt-sha256.json',
                          [common.file_receipt(path) for path in sorted(out.rglob('*')) if path.is_file()])
    print(json.dumps({'passed': report['passed'], 'output': str(out),
                      'full_library': report['full_library']['verdict'] if report['full_library'] else None,
                      'required_confirmed': report['confirmed_named_execution_count'],
                      'required_passed': report['passed_selector_count']}), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
