#!/usr/bin/env python3
"""Observe the fixed Cell continuation; no command can grant qualification."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/487d55b3efb1/chain-storage')
OUT = Path(sys.argv[1]).resolve()
OUT.mkdir(parents=True, exist_ok=False)
SOURCE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
ENV = dict(os.environ)
ENV['PATH'] = '/workspace/scratch/2b54b253422c/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:' + ENV['PATH']
ENV['CARGO_HOME'] = '/workspace/scratch/487d55b3efb1/cargo-home'
ENV['CARGO_TARGET_DIR'] = '/tmp/cell-storage-v3-487d55-target'
ENV['CARGO_BUILD_JOBS'] = '2'
ENV['RUST_TEST_THREADS'] = '1'
ENV['CARGO_INCREMENTAL'] = '0'
ENV['CARGO_PROFILE_DEV_DEBUG'] = '0'
ENV['CARGO_PROFILE_TEST_DEBUG'] = '0'
for line in Path('/workspace/scratch/487d55b3efb1/provider-setup/provider.env').read_text().splitlines():
    key, value = line.split('=', 1)
    if key not in {'OPENSSL_DIR', 'OPENSSL_STATIC', 'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256',
                   'TRNM_PQ_OPENSSL_VERSION', 'OPENSSL_CONF', 'OPENSSL_MODULES'}:
        raise ValueError('unexpected provider environment key')
    ENV[key] = value

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

summary = dict(schema='trnm-cell-storage-network-v3-validation-v1', source=SOURCE,
               base='0dc13a92cc49e9a751a2b6cf7cc96524f1244a2a', started_at=utc(),
               scope='Shared Linux x86_64 component checks; no fixed-resource Host/WAN/operator/Hepta FinalUse qualification',
               commands=[], complete=False, passed=False, production_qualified=False)
summary['build_environment'] = {key: ENV[key] for key in
    ['CARGO_BUILD_JOBS', 'RUST_TEST_THREADS', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG',
     'CARGO_PROFILE_TEST_DEBUG', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'TRNM_PQ_OPENSSL_SHA256']}

def save():
    pending = OUT / 'summary.pending'
    pending.write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    pending.replace(OUT / 'summary.json')

commands = [
    ('preflight', ['bash', 'scripts/project-preflight.sh', '--audit'], 120),
    ('source-before', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                       '--expected-head', SOURCE, '--output', str(OUT/'source-before.json')], 180),
    ('graph-default', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1',
                       '--manifest-path', 'trillionnium/Cargo.toml'], 180),
    ('graph-all-features', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1',
                            '--manifest-path', 'trillionnium/Cargo.toml', '--all-features'], 180),
    ('graph-fuzz', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1',
                    '--manifest-path', 'tests/fuzz/Cargo.toml'], 180),
    ('format', ['cargo', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check'], 180),
    ('version-vector', ['python3', '-B', 'scripts/cell_complete_version_vector.py', '--check'], 120),
    ('native-list', ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml',
                      '-p', 'trnm-data-availability', '--lib', '--', '--list'], 300),
    ('p2p-complete', ['cargo', 'test', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml',
                       '-p', 'trnm-data-availability', '--', '--test-threads=1'], 1200),
    ('native-example', ['cargo', 'run', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml',
                         '-p', 'trnm-data-availability', '--example', 'cell_discovery_pq_v3', '--',
                         str(OUT/'native-example')], 300),
    ('clippy-workspace', ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml',
                            '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings'], 1200),
    ('source-negative', ['python3', '-B', 'scripts/ci/test_ci_source_integrity.py'], 180),
    ('pq-source-negative', ['python3', '-B', 'scripts/ci/test_pq_research_integration.py'], 300),
    ('ci-contract', ['python3', '-B', 'scripts/ci/test_ci_contract.py'], 300),
    ('repository', ['python3', '-B', 'scripts/ci/check_repository.py'], 300),
    ('pq-source-pins', ['python3', '-B', 'scripts/ci/check_pq_research_integration.py'], 120),
    ('inventory', ['python3', '-B', 'scripts/refresh_distributed_source_inventory.py', '--check'], 120),
    ('source-after', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                      '--expected-head', SOURCE, '--output', str(OUT/'source-after.json')], 180),
    ('clean-worktree', ['git', 'status', '--porcelain=v1', '--untracked-files=all'], 120),
]
save()
for label, argv, timeout in commands:
    started = time.monotonic()
    stamp = utc()
    timed_out = False
    code = None
    path = OUT / (label + '.log')
    print('START', label, flush=True)
    with path.open('xb') as stream:
        try:
            process = subprocess.run(argv, cwd=ROOT, env=ENV, stdout=stream,
                                     stderr=subprocess.STDOUT, timeout=timeout, check=False)
            code = process.returncode
        except subprocess.TimeoutExpired:
            timed_out = True
    raw = path.read_bytes()
    passed = code == 0 and not timed_out
    if label == 'clean-worktree':
        passed = passed and not raw
    summary['commands'].append(dict(label=label, argv=argv, log=path.name, exit_code=code,
                                    timeout=timed_out, timeout_seconds=timeout, passed=passed,
                                    started_at=stamp, elapsed_seconds=time.monotonic()-started,
                                    bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
    save()
    print('END', label, 'PASS' if passed else 'FAIL', code, flush=True)

listing = (OUT/'native-list.log').read_text(errors='replace')
native = (OUT/'p2p-complete.log').read_text(errors='replace')
names = re.findall(r'^(cell::(?:discovery::pq3::|residency::version::).+): test$', listing, re.M)
ok_names = set(re.findall(r'^test (.+) \.\.\. ok$', native, re.M))
missing = sorted(set(names) - ok_names)
groups = {prefix: sum(name.startswith(prefix) for name in names)
          for prefix in ['cell::discovery::pq3::directory_tests::',
                         'cell::discovery::pq3::directory::',
                         'cell::discovery::pq3::transport_tests::',
                         'cell::discovery::pq3::multisource_tests::',
                         'cell::residency::version::tests::']}
counts = [dict(passed=int(a), failed=int(b), ignored=int(c), measured=int(d), filtered=int(e))
          for a,b,c,d,e in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', native)]
roster_ok = len(names) == 43 and len(set(names)) == len(names) and not missing
roster_ok = roster_ok and groups['cell::residency::version::tests::'] == 9
roster_ok = roster_ok and groups['cell::discovery::pq3::multisource_tests::'] == 2
roster_ok = roster_ok and bool(counts) and all(row['failed'] == row['ignored'] == row['filtered'] == 0 for row in counts)
results = dict(required_new_tests=names, groups=groups, missing_new_tests=missing,
               complete_target_results=counts, passed=roster_ok,
               total_successful_tests_including_doctests=sum(row['passed'] for row in counts))
(OUT/'native-results.json').write_text(json.dumps(results, indent=2, sort_keys=True)+'\n')
summary.update(complete=True, completed_at=utc(), new_native_test_names=len(names),
               passed=all(row['passed'] for row in summary['commands']) and roster_ok)
save()
print(json.dumps(dict(source=SOURCE, passed=summary['passed'], commands=len(commands),
                      new_native_tests=len(names), missing=missing)), flush=True)
sys.exit(0 if summary['passed'] else 1)
