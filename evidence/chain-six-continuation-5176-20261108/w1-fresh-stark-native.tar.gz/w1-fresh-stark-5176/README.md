# W1 fresh generation and native integration, 5176

This archive preserves one new execution of the current pinned research backend. The
complete W1 proof set contains two real STARK components, scheduled SHA and packed
arithmetic. It reuses a fixed native statement and produces the same deterministic
proof bytes as the historical run. Independent fresh statements: 0. New complete
proof generation executions: 1. No retained proof was read by this generation.

Source build commit: 6f2c5ce28bf39fd4548f6312d2eebe363c77da4b, based on
e798d7125724d4b9f98c24d00cc80031f2eab4a9. The later CI-only commit does not
retroactively change this runtime build identity. The source manifest binds the
actual selected crate, lockfile and include-file bytes. Toolchains and third-party
Cargo dependency sources are not bundled; this is not a complete hermetic build
closure, authenticated provenance or production qualification.

Measured generation: 8.991340855835006 s outer wall; independent verification:
0.9682171139866114 s outer wall. Eleven ordinary negative controls all reached
their required refusal frontiers. The current native adapter then regenerated the
same fixed fixture and completed five admission/cancellation cases, four independent
cold reopens and the nine-slot shared owner with exhaustion status (11 processes).

The research processes used CPU affinity 0..7, RAYON_NUM_THREADS=8 and an observed
cgroup CPU quota of 800000/100000, memory.max=8589934592 and memory.swap.max=max.
The original public resource profile was not used. No same-resource net benefit,
concrete NI/PQ security, complete lifecycle bound or production activation is claimed.
SQLite's external-RUSTFLAGS UNQUALIFIED warning is preserved in the adapter build
logs. The first sparse adapter build failure is retained without alteration.

## Contents and reconstruction

Files are content-addressed under objects/ to avoid repeating identical proof
copies across native operations. manifest.json maps every included logical path,
size, mode and SHA256. Both actual compiled executable binaries are included and
explicitly named in the manifest; they use target-cpu=native for the recorded host.
Only duplicated/mutated ordinary-negative-case input directories are omitted.
Their full original digests and exact reconstruction helper are included. All
ordinary-negative process stdout, stderr, timings and result observations remain.

After unpacking the archive to a new directory:

    python3 restore.py /new/path/restored
    python3 reconstruct-negative-cases.py /new/path/restored /new/path/negative-cases

The second command reconstructs every omitted case input and requires exact
equality to the original recorded byte lengths and SHA256 digests. It does not
run proof verification. restore.py verifies all included objects before writing
each logical file. The bundle validation separately verifies archive object bytes,
performs a complete restore and checks all omitted negative-case reconstructions.

The restored experiment/ tree contains original raw records and absolute historical
paths in commands. helpers/ contains the pinned reusable ordinary-control and native
process harnesses; binaries/ contains the two current compiled programs; source/
contains the recorded application source inputs; retained-native-fixture/ identifies
the existing statement input. No file under retained-native-fixture/ is labelled as
a newly generated proof. The actual new proof outputs are under
experiment/generation-01/proof/.

Qualification remains HOLD_NO_GO. Runtime observations are not production,
whole-chain composition or independent operator evidence.
