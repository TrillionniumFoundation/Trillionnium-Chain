#!/usr/bin/env python3
"""Review only the last runner name-matching delta; preserve v2/v3 scope."""
import ast
import hashlib
import json
import pathlib
import re
import subprocess
import time

WORK = pathlib.Path('/home/qian-qi/work/p3-mmcs-binding-dded70360575-v1')
REPO = WORK / 'repo-runner-v3'
OUT = WORK / 'runner-review-v4'
RUNNER = 'formal/pon-nakamoto-v1/p3_shared_primitive_qualification/run_qualification_checks.py'
BASE = '1fe2f31c70977a030aec73b63fe0617f34d15a77'
V2 = '70293cec717416ed57a97b0d326909c4227963e6'
V3 = 'e55f7f84fbaeda2a3a033edd294773db7be3a903'
FINAL_RUNNER_SHA = '410d5c2fccf0b131fec24cbfc5f68bceaaafbd693d5c55e0e6444e37641bf1e5'
EXAMPLE = 'formal/pon-nakamoto-v1/w1_public_stark_research/examples/tagged_sha3_mmcs_binding.rs'
EXAMPLE_SHA = 'a1fc0496f4013879f859eaaa9a556ebd9cd308901e8bff2d56f8cfa796c1a22a'
OUT.mkdir(exist_ok=False)
records = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def run(name, argv):
    started = time.monotonic()
    p = subprocess.run(argv, cwd=REPO, capture_output=True)
    (OUT / (name + '.stdout.txt')).write_bytes(p.stdout)
    (OUT / (name + '.stderr.txt')).write_bytes(p.stderr)
    record = dict(stage=name, argv=argv, exit_code=p.returncode,
                  wall_seconds=time.monotonic()-started,
                  stdout_sha256=sha(p.stdout), stderr_sha256=sha(p.stderr))
    records.append(record)
    print(json.dumps(record), flush=True)
    if p.returncode:
        raise SystemExit(name + ': ' + p.stderr.decode(errors='replace'))
    return p.stdout


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=REPO)


assert git('rev-parse', 'HEAD').decode().strip() == V3
assert not git('status', '--porcelain')
run('preflight-before-edit', ['bash', 'scripts/project-preflight.sh'])
data = (WORK / 'runner-final-v4.py').read_bytes()
assert sha(data) == FINAL_RUNNER_SHA
ast.parse(data)
(REPO / RUNNER).write_bytes(data)
git('add', '--', RUNNER)
assert git('diff', '--cached', '--name-only').decode().splitlines() == [RUNNER]
run('preflight-staged', ['bash', 'scripts/project-preflight.sh', '--staged'])
run('commit-final-runner', ['git', 'commit', '-m', 'test(p3): match complete native test names in qualification gate'])
head = git('rev-parse', 'HEAD').decode().strip()
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
assert git('diff', '--name-only', V3, head).decode().splitlines() == [RUNNER]
assert git('diff', '--name-only', V2, head).decode().splitlines() == [RUNNER]
assert sha((REPO / EXAMPLE).read_bytes()) == EXAMPLE_SHA
assert not git('status', '--porcelain')
for label, old, new in [('base-to-v2', BASE, V2), ('v2-to-v3', V2, V3), ('v3-to-v4', V3, head)]:
    (OUT / (label + '.patch')).write_bytes(git('diff', '--binary', '--full-index', old, new))
for label, commit in [('v2', V2), ('v3', V3), ('v4', head)]:
    (OUT / (label + '-runner.py')).write_bytes(git('show', commit + ':' + RUNNER))
    (OUT / (label + '-commit.txt')).write_bytes(git('cat-file', 'commit', commit))
    (OUT / (label + '-changed-files.txt')).write_bytes(git('diff-tree', '--no-commit-id', '--name-status', '-r', commit))
run('preflight-final', ['bash', 'scripts/project-preflight.sh'])
run('source-before', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', head, '--output', str(OUT / 'source-before.json')])
parsed = ast.parse((REPO / RUNNER).read_text())
loops = [n for n in ast.walk(parsed) if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == 'required']
assert len(loops) == 1
names = ast.literal_eval(loops[0].iter)
assert len(names) == 11 and len(set(names)) == 11
code = compile(ast.Module(body=loops, type_ignores=[]), RUNNER, 'exec')
log_data = (WORK / 'runner-review-v3/rust-tests.stdout.txt').read_bytes()
log = log_data.decode('utf-8')
assert sha(log_data) == '9042433c41e42ed76a626fd27ef56cfc1abafb34e0ec63ea7449b408b920e9a7'
exec(code, {'re': re, 'log': log})
target_line = 'test tests::' + names[0] + ' ... ok'
assert log.splitlines().count(target_line) == 1
missing = '\n'.join(line for line in log.splitlines() if line != target_line) + '\n'
prefixed = log.replace(target_line, 'test tests::prefix_' + names[0] + ' ... ok')
assert names[0] + ' ... ok' in prefixed
negative_records = []
for kind, mutation in [('remove-required-name', missing), ('prefix-required-name', prefixed)]:
    try:
        exec(code, {'re': re, 'log': mutation})
    except SystemExit as error:
        assert str(error) == 'Pruned MMCS regression did not pass: ' + names[0]
        negative_records.append(dict(kind=kind, expected_rejection=str(error), rejected=True,
                                     derived_log_sha256=sha(mutation.encode())))
    else:
        raise SystemExit('Mutated parser input was not rejected: ' + kind)
review = dict(schema='p3.pruned-mmcs.exact-name-parser-review.v1',
              source_log='../runner-review-v3/rust-tests.stdout.txt', source_log_sha256=sha(log_data),
              runner_sha256=sha(data), mechanism='execute the actual required-name For AST from the final runner',
              required_tests=names, positive_original_log_pass=True,
              negative_inputs_are_derived_strings_not_new_cargo_runs=True,
              negatives=negative_records)
(OUT / 'parser-review.json').write_text(json.dumps(review, indent=2) + '\n')
binary = WORK / 'target-runner-v3/release/examples/tagged_sha3_mmcs_binding'
v3_summary = json.loads((WORK / 'runner-review-v3/summary.json').read_text())
binary_sha = sha(binary.read_bytes())
assert binary_sha == v3_summary['audit_executable_sha256'] == '10f18b7d11784d1dfdc72b9104f006460b144636ca810364fba90274a43136a4'
report = run('native-report', [str(binary)])
assert sha(report) == v3_summary['native_report_sha256']
run('source-after', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', head, '--output', str(OUT / 'source-after.json')])
assert (OUT / 'source-before.json').read_bytes() == (OUT / 'source-after.json').read_bytes()
assert sha(binary.read_bytes()) == binary_sha
assert not git('status', '--porcelain')
changed = git('diff', '--name-only', BASE, head).decode().splitlines()
assert len(changed) == 7
files = []
for path in changed:
    entry = git('ls-tree', head, '--', path).decode().strip().split('\t')[0].split()
    content = (REPO / path).read_bytes()
    files.append(dict(path=path, mode=entry[0], git_blob_sha1=entry[2], sha256=sha(content), bytes=len(content)))
summary = dict(schema='p3.pruned-mmcs.final-runner-delta-review.v4', result='PASS',
               baseline_commit=BASE, full_gate_commit=V2, rust_rerun_commit=V3,
               commit=head, tree=tree, changed_since_v3=[RUNNER], changed_since_v2=[RUNNER],
               full_focused_gate_reexecuted=False, rust_tests_reexecuted=False,
               inherited_v3_rust_tests=79, inherited_new_named_rust_tests=11,
               parser_original_log_pass=True, parser_rejected_mutations=2,
               native_report_reexecuted=True, native_rejection_controls=v3_summary['native_rejection_controls'],
               example_source_sha256=EXAMPLE_SHA, audit_executable_sha256=binary_sha,
               native_report_sha256=sha(report), source_receipts_equal=True,
               records=records, files=files,
               qualification='HOLD_NO_GO', concrete_security_bits=None,
               complete_repository_ci=False, production_activation=False)
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(dict(stage='final-runner-delta-review-pass', commit=head, tree=tree,
                      summary_sha256=sha((OUT/'summary.json').read_bytes()),
                      parser_rejected_mutations=2)), flush=True)
