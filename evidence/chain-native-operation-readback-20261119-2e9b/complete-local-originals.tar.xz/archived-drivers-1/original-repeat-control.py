from pathlib import Path
import subprocess,json,time,resource,hashlib,os,sys
base=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b');src=base/'source';e=base/'original-repeat-control-1';e.mkdir(exist_ok=False)
def run(name,cmd,env=None):
 t=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (e/(name+'.stdout')).open('xb') as out,(e/(name+'.stderr')).open('xb') as err:
  p=subprocess.Popen(cmd,cwd=src,env=env,stdout=out,stderr=err);pid=p.pid;rc=p.wait()
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 v={'command':cmd,'cwd':str(src),'pid':pid,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':after.ru_utime-before.ru_utime,'child_system_cpu_seconds':after.ru_stime-before.ru_stime}
 (e/(name+'.json')).write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v),flush=True);return rc
assert run('preflight',['bash','scripts/project-preflight.sh'])==0
p=src/'trillionnium/crates/trnm-pon-node/src/store/native_authenticated/post_write_readback/frontier_tests.rs'
old=p.read_bytes();assert hashlib.sha256(old).hexdigest()=='4fab7ad3886d9a70be229c1717dd9e58432e5b6a507f3c81af6680bf83594fe8'
p.write_bytes(old+sys.argv[1].encode())
(e/'new-test.rs').write_text(sys.argv[1])
diff=subprocess.check_output(['git','diff','--binary'],cwd=src);(e/'test-only.patch').write_bytes(diff)
env=os.environ.copy();env.update(PATH='/home/qq/.cargo/bin:'+env['PATH'],CARGO_TARGET_DIR=str(base/'target'),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true')
rc=run('original-production-repeat',['/home/qq/.cargo/bin/cargo','+1.95.0','test','--offline','--locked','--release','--jobs','2','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib','store::native_authenticated::post_write_readback::tests::frontier::completed_different_root_reuses_original_scope_without_new_frontier','--','--exact','--nocapture','--test-threads=1'],env)
assert subprocess.check_output(['git','diff','--binary'],cwd=src)==diff
res={'schema':'original-completed-graph-repeat-control-v1','base_commit':'f088f1d4f8a50aff0c5ecd465480b2aeee6e5e94','production_unchanged':True,'only_change':'new deterministic callback-count control','native_exit_code':rc,'full_physical_cost_closed':False}
(e/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res),flush=True)
