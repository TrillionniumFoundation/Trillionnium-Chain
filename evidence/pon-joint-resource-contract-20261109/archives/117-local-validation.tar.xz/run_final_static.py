from pathlib import Path
import os,json,subprocess,datetime,hashlib,time
repo=Path("/workspace/scratch/pon-joint-58fd59-build/chain")
out=Path("/workspace/scratch/pon-joint-58fd59-build/final-static")
out.mkdir(exist_ok=False)
sha="11791e2da79b69322271be2cffe03725165151d1"
toolchain=Path("/workspace/scratch/5faaca703596/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu")
env=dict(os.environ)
env.update(CARGO_HOME="/workspace/scratch/5faaca703596/toolchain/cargo",RUSTUP_HOME="/workspace/scratch/5faaca703596/toolchain/rustup",RUSTC=str(toolchain/"bin/rustc"),RUSTDOC=str(toolchain/"bin/rustdoc"),CARGO_TARGET_DIR="/workspace/scratch/pon-joint-58fd59-build/target",LD_LIBRARY_PATH=str(toolchain/"lib"),OPENSSL_LIB_DIR="/usr/lib/x86_64-linux-gnu",OPENSSL_INCLUDE_DIR="/usr/include",RUST_TEST_THREADS="1",PYTHONDONTWRITEBYTECODE="1")
env["PATH"]=str(toolchain/"bin")+os.pathsep+env["PATH"]
commands=[
("01-preflight",["bash","scripts/project-preflight.sh"]),
("02-source-integrity",["python3","scripts/ci/test_ci_source_integrity.py","-v"]),
("03-ci-contract-tests",["python3","scripts/ci/test_ci_contract.py","-v"]),
("04-corpus-tests",["python3","scripts/ci/test_pq_research_integration.py","-v"]),
("05-project-boundary-tests",["python3","scripts/ci/test_project_boundary.py","-v"]),
("06-repository-tests",["python3","scripts/ci/test_repository.py","-v"]),
("07-ci-contract-check",["python3","scripts/ci/check_ci_contract.py"]),
("08-repository-check",["python3","scripts/ci/check_repository.py"]),
("09-corpus-check",["python3","scripts/ci/check_pq_research_integration.py"]),
("10-distributed-check",["python3","scripts/refresh_distributed_source_inventory.py","--check"]),
("11-lifecycle-reader-tests",["python3","scripts/ci/test_w1_lifecycle_cost_v4.py","-v"]),
("12-metadata-default",[str(toolchain/"bin/cargo"),"metadata","--manifest-path","trillionnium/Cargo.toml","--locked","--offline","--format-version","1"]),
("13-metadata-all-features",[str(toolchain/"bin/cargo"),"metadata","--manifest-path","trillionnium/Cargo.toml","--locked","--offline","--format-version","1","--all-features"]),
("14-metadata-fuzz",[str(toolchain/"bin/cargo"),"metadata","--manifest-path","tests/fuzz/Cargo.toml","--locked","--offline","--format-version","1"]),
("15-fmt-check",[str(toolchain/"bin/cargo"),"fmt","--manifest-path","trillionnium/Cargo.toml","--all","--","--check"]),
]
meta={"schema":"pon-final-static-validation-orchestration-v1","source":sha,"tree":"162552848110fda532504b78865a16930bc6d9bb","started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"native_execution_claimed":False,"environment":{k:env[k] for k in ["CARGO_HOME","RUSTUP_HOME","RUSTC","RUSTDOC","CARGO_TARGET_DIR","LD_LIBRARY_PATH","OPENSSL_LIB_DIR","OPENSSL_INCLUDE_DIR","RUST_TEST_THREADS","PYTHONDONTWRITEBYTECODE","PATH"]},"results":[]}
meta["runner_sha256"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(out/"environment.json").write_text(json.dumps(meta["environment"],indent=2)+"\n")
(out/"orchestration.json").write_text(json.dumps(meta,indent=2)+"\n")
for label,command in commands:
    args=["python3","scripts/ci/record_pq_native_command.py","--kind","head","--candidate",sha,"--tested",sha,"--label",label,"--output",str(out),"--"]+command
    print(json.dumps({"starting":label,"utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}),flush=True)
    start=time.monotonic()
    with (out/(label+".recorder.stdout")).open("xb") as stdout, (out/(label+".recorder.stderr")).open("xb") as stderr:
        run=subprocess.run(args,cwd=repo,env=env,stdout=stdout,stderr=stderr)
    record=json.loads((out/(label+".json")).read_text()) if (out/(label+".json")).exists() else {}
    result={"label":label,"recorder_exit":run.returncode,"command_exit":record.get("exit_code"),"status":record.get("status"),"seconds":time.monotonic()-start,"before_after_equal":record.get("before")==record.get("after") and record.get("before") is not None}
    if label.startswith(("12-","13-","14-")) and record.get("exit_code")==0:
        raw=(out/(label+".log")).read_text()
        result["cargo_lock_messages"]=[line for line in raw.splitlines() if "Blocking waiting" in line]
        graphs=[]
        for line in raw.splitlines():
            if line.startswith("{"):
                try:
                    data=json.loads(line)
                    if isinstance(data,dict) and "workspace_members" in data and "packages" in data:
                        graphs.append(data)
                except json.JSONDecodeError:
                    pass
        if len(graphs)==1:
            result.update(workspace_members=len(graphs[0]["workspace_members"]),packages=len(graphs[0]["packages"]))
        else:
            result["graph_summary_parse_error"]="EXPECTED_ONE_METADATA_JSON_OBJECT"
    meta["results"].append(result)
    (out/"orchestration.json").write_text(json.dumps(meta,indent=2)+"\n")
    print(json.dumps(result),flush=True)
meta["finished_utc"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
meta["all_commands_passed"]=all(x["status"]=="command_succeeded" and x["recorder_exit"]==0 and x["before_after_equal"] for x in meta["results"])
(out/"orchestration.json").write_text(json.dumps(meta,indent=2)+"\n")
print(json.dumps({"completed":True,"all_commands_passed":meta["all_commands_passed"],"count":len(meta["results"])}),flush=True)
