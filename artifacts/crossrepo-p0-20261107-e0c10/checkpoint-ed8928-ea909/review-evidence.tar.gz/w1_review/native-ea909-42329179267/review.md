# ea909 原三轮 native campaign：完整 27 次确认与成本审读

**结论：原 3 次完整 campaign 均失败；27 次计划确认中 6 次成功、9 次已进入但失败、12 次未进入。** 全部 27 个计划位置和 189 个业务包暴露均保留。三轮 baseline 各完成前两次确认，第三次到原截止失败；六个攻击 phase 各进入首轮确认而未成功，后两轮未进入。这里使用原 30 秒 phase 条件，不改为 F0 四秒条件。

原始 GitHub run `42329179267` / attempt 1 / job `128271490587` / PR #756，实际 source `ea909124cc460f364bd17b009073306014133f48`，tree `96712231eba3d333bdfebefa9c22c80ea1794d04`，head lane。GitHub 终态为 failure，三轮实际执行均返回 101；没有 phase startup error 或 report-validation failure。本分析未启动新 native、build、workflow 或重试。依据：[jobs.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-ea909-42329179267/jobs.json)、[analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-ea909-42329179267/analysis.json)。

## 1. 原始库存、实际 binary 与预算

| 项目 | 核对结果 |
| --- | --- |
| 原始 artifact | `13557079786`，69,000,777 B；SHA256 `ea956d9a4ee086a164b905ca1cbbe29f7125dd503fe59c7998f7cddbb3324c17`，与 GitHub advertised digest/size 一致 |
| 全库存 | ZIP 1,766 entries；inventory 1,765 files，429,415,560 bytes；全部逐文件 size/SHA256 匹配，无重复或未登记文件（inventory 自身除外） |
| 实际 test binary | 11,798,560 B；SHA256 `27c59f6dbf8cf565bf3713cf22442e2273f14b388cb794082b99cd43801541cd`；before／after／ZIP retained bytes 全一致 |
| 编译配置 | Rust 1.95.0；release `opt_level=3`，debug assertions=false；实际 build 与 measured campaign 分离 |
| 源绑定 | source-before-campaigns、三个 run-source-after、source-after-native 均相同 ea909／9671，tracked worktree verified；原 run report 摘要逐一匹配 |
| 原工作负载 | 1,024 个实际签名 seed transfers、4 seed blocks、每 phase 21 business blocks；3 rounds 的预定 offsets 为 1/5/9 秒；确认 depth=6，非 finality/physical execution authority |
| 攻击者与窗口 | baseline 0、from-zero 24、late-product 24 个外部 actor；每 phase 原 30 秒；每完整 run 外层 timeout 600 秒 |
| public receiver／verifier 实际资源 | 36 个 inside／outside before／after 读回均为 `cpu.max=25000 100000`、burst 0、memory 2147483648、swap 0、PIDs 256，固定 root-owned parent `/sys/fs/cgroup/trnmponpublic.slice`；read errors 为空 |
| controller 域 | 原 controller CPU 4 核配额、16 GiB、nice 10；攻击者留在 controller 域，未将该预算混称 public quarter CPU |
| public policy | `7407c22c85e06aecf4a80b36e0448fed09d36f1c3709b30d31602c399ac5ff73`；与原门相同 |

ZIP 和逐文件核验见 [verification-manifest.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-ea909-42329179267/verification-manifest.json)，实际 Host 边界和 actor/receiver 费用见 [cost-scope-analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-ea909-42329179267/cost-scope-analysis.json)。此处没有使用旧 9f 的结果补全 ea909 的分母或通过。

## 2. 九个 phase 的完整分母

| Run | Phase | 计划确认 | 已进入 | 原 30s 内确认 | 未进入 | 已尝试包／计划包 | 及时 ACK | History 成功／进入 |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | baseline | 3 | 3 | 2 | 0 | 18/21 | 17 | 14/14 |
| 1 | from-zero | 3 | 1 | 0 | 2 | 7/21 | 7 | 6/7 |
| 1 | late-product | 3 | 1 | 0 | 2 | 7/21 | 7 | 6/7 |
| 2 | baseline | 3 | 3 | 2 | 0 | 18/21 | 17 | 14/14 |
| 2 | from-zero | 3 | 1 | 0 | 2 | 7/21 | 7 | 6/7 |
| 2 | late-product | 3 | 1 | 0 | 2 | 7/21 | 7 | 6/7 |
| 3 | baseline | 3 | 3 | 2 | 0 | 17/21 | 16 | 14/14 |
| 3 | from-zero | 3 | 1 | 0 | 2 | 7/21 | 7 | 6/7 |
| 3 | late-product | 3 | 1 | 0 | 2 | 7/21 | 7 | 6/7 |

189 个计划包中 95 个实际尝试、92 个取得原 phase 内 ACK、94 个未尝试。所有 ACK 和 history 成功均不替代独立客户端确认。三个 baseline 的第三轮已进入，但只来得及发送部分业务包；攻击 phase 的首轮 7 个包虽均 ACK，独立客户端仍未完成原确认。

## 3. 全部 27 次确认的实际时钟

| Run | Phase | Round | 预定 offset(s) | 实际开始(s) | 实际结束(s) | 原 30s 内确认 | 结局 |
| ---: | --- | ---: | ---: | ---: | ---: | --- | --- |
| 1 | baseline | 0 | 1.000000 | 1.000606 | 15.089784 | true | 确认 |
| 1 | baseline | 1 | 5.000000 | 15.089865 | 29.096955 | true | 确认 |
| 1 | baseline | 2 | 9.000000 | 29.097065 | 30.001493 | false | 已进入失败 |
| 1 | from-zero | 0 | 1.000000 | 1.072634 | 30.074540 | false | 已进入失败 |
| 1 | from-zero | 1 | 5.000000 | — | — | false | 未进入，保留失败分母 |
| 1 | from-zero | 2 | 9.000000 | — | — | false | 未进入，保留失败分母 |
| 1 | late-product | 0 | 1.000000 | 1.074553 | 30.075584 | false | 已进入失败 |
| 1 | late-product | 1 | 5.000000 | — | — | false | 未进入，保留失败分母 |
| 1 | late-product | 2 | 9.000000 | — | — | false | 未进入，保留失败分母 |
| 2 | baseline | 0 | 1.000000 | 1.001105 | 15.087280 | true | 确认 |
| 2 | baseline | 1 | 5.000000 | 15.087362 | 29.004482 | true | 确认 |
| 2 | baseline | 2 | 9.000000 | 29.004580 | 30.086109 | false | 已进入失败 |
| 2 | from-zero | 0 | 1.000000 | 1.001998 | 30.078363 | false | 已进入失败 |
| 2 | from-zero | 1 | 5.000000 | — | — | false | 未进入，保留失败分母 |
| 2 | from-zero | 2 | 9.000000 | — | — | false | 未进入，保留失败分母 |
| 2 | late-product | 0 | 1.000000 | 1.079059 | 30.081124 | false | 已进入失败 |
| 2 | late-product | 1 | 5.000000 | — | — | false | 未进入，保留失败分母 |
| 2 | late-product | 2 | 9.000000 | — | — | false | 未进入，保留失败分母 |
| 3 | baseline | 0 | 1.000000 | 1.000356 | 15.281664 | true | 确认 |
| 3 | baseline | 1 | 5.000000 | 15.281743 | 29.388625 | true | 确认 |
| 3 | baseline | 2 | 9.000000 | 29.388716 | 30.001334 | false | 已进入失败 |
| 3 | from-zero | 0 | 1.000000 | 1.060128 | 30.062076 | false | 已进入失败 |
| 3 | from-zero | 1 | 5.000000 | — | — | false | 未进入，保留失败分母 |
| 3 | from-zero | 2 | 9.000000 | — | — | false | 未进入，保留失败分母 |
| 3 | late-product | 0 | 1.000000 | 1.064773 | 30.066332 | false | 已进入失败 |
| 3 | late-product | 1 | 5.000000 | — | — | false | 未进入，保留失败分母 |
| 3 | late-product | 2 | 9.000000 | — | — | false | 未进入，保留失败分母 |

baseline 首轮实际确认位于 phase 15.087–15.282 秒，第二轮位于 29.004–29.389 秒；后续轮从完成前轮后才开始，排队时长保留，不重置预定时间。六个攻击 phase 的首轮到 30.062–30.081 秒才以失败结束。原 30 秒截止不因末次返回略晚而延长。

## 4. 历史导入和 Host 成本

| Run | Phase | Import wall(s) | Import thread CPU(s) | Host calls | Host CPU(s，嵌套) | Host拒绝 |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1 | baseline | 23.722478 | 5.470669 | 166,703 | 4.127543 | 0 |
| 1 | from-zero | 24.659495 | 2.327752 | 57,814 | 1.822520 | 0 |
| 1 | late-product | 24.474269 | 2.223195 | 54,487 | 1.734758 | 0 |
| 2 | baseline | 23.679237 | 5.467855 | 166,703 | 4.126432 | 0 |
| 2 | from-zero | 24.668275 | 2.345748 | 57,466 | 1.834204 | 0 |
| 2 | late-product | 24.563778 | 2.300398 | 56,161 | 1.798423 | 0 |
| 3 | baseline | 24.126483 | 5.515932 | 166,703 | 4.157310 | 0 |
| 3 | from-zero | 24.498929 | 2.363063 | 58,013 | 1.849582 | 0 |
| 3 | late-product | 24.381747 | 2.338909 | 58,268 | 1.840531 | 0 |

全部 84 次 history 请求均进入 client import，78 次 import 成功、6 次以 `PUBLIC_REQUEST_DEADLINE` 失败。842,318 次 Host 检查全部开始、完成并接受，0 拒绝，CPU／wall 未知计数均为 0。import thread CPU 合计 30.353521 秒，Host 嵌套 CPU 23.291302 秒。这两个总和不可相加；Host 统计实际调用线程的 Host 区间，不是所有 scoped worker 的全部 CPU。

六个攻击 phase 的前 6 页 import 均成功，第 7 页进入后在原 deadline 失败；因此不能把“完成了 6 页”说成完整历史同步。baseline 每轮的最终 complete-page activation 占用更长时间，实际 span 见逐页记录。仅凭 account_graph／verify_state／complete_root span 个数仍不能推导同次数完整图遍历；本分析保留原 span 和 Host 数据，不把全部成本强行归给一个函数。

### 全部 84 次 history import

#### Run 1

| Phase | # | Import开始(s) | Import结束(s) | Wall(s) | Thread CPU(s) | Host calls | Host CPU(s，嵌套) | 结果 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| baseline | 0 | 2.789469 | 4.393624 | 1.604155 | 0.292802 | 9,256 | 0.231195 | accepted |
| baseline | 1 | 4.405586 | 5.508715 | 1.103128 | 0.273333 | 8,758 | 0.215869 | accepted |
| baseline | 2 | 5.586885 | 6.704031 | 1.117146 | 0.273880 | 8,765 | 0.216873 | accepted |
| baseline | 3 | 6.716048 | 7.901509 | 1.185461 | 0.272116 | 8,772 | 0.213240 | accepted |
| baseline | 4 | 7.912596 | 9.102133 | 1.189537 | 0.278188 | 8,779 | 0.217949 | accepted |
| baseline | 5 | 9.114014 | 10.322447 | 1.208433 | 0.280974 | 8,786 | 0.218180 | accepted |
| baseline | 6 | 10.333153 | 14.886881 | 4.553727 | 1.045535 | 29,957 | 0.737213 | accepted |
| baseline | 7 | 16.989434 | 18.197353 | 1.207920 | 0.284723 | 9,109 | 0.226585 | accepted |
| baseline | 8 | 18.209840 | 19.402256 | 1.192417 | 0.278782 | 8,834 | 0.219645 | accepted |
| baseline | 9 | 19.414087 | 20.607004 | 1.192917 | 0.279527 | 8,841 | 0.220696 | accepted |
| baseline | 10 | 20.618921 | 21.810460 | 1.191539 | 0.280684 | 8,848 | 0.218785 | accepted |
| baseline | 11 | 21.896060 | 23.087312 | 1.191252 | 0.279562 | 8,855 | 0.218642 | accepted |
| baseline | 12 | 23.099183 | 24.295821 | 1.196638 | 0.283571 | 8,862 | 0.221172 | accepted |
| baseline | 13 | 24.306675 | 28.894882 | 4.588207 | 1.066990 | 30,281 | 0.751500 | accepted |
| from-zero | 0 | 4.877397 | 9.173796 | 4.296399 | 0.370846 | 9,116 | 0.291249 | accepted |
| from-zero | 1 | 9.188400 | 12.779665 | 3.591265 | 0.347907 | 8,758 | 0.271634 | accepted |
| from-zero | 2 | 12.889580 | 16.572932 | 3.683353 | 0.349055 | 8,765 | 0.273852 | accepted |
| from-zero | 3 | 16.677054 | 20.279445 | 3.602390 | 0.352146 | 8,772 | 0.274416 | accepted |
| from-zero | 4 | 20.383895 | 24.174387 | 3.790492 | 0.358360 | 8,779 | 0.279138 | accepted |
| from-zero | 5 | 24.273899 | 28.075095 | 3.801196 | 0.360580 | 8,786 | 0.276417 | accepted |
| from-zero | 6 | 28.179972 | 30.074372 | 1.894400 | 0.188859 | 4,838 | 0.155814 | PUBLIC_REQUEST_DEADLINE |
| late-product | 0 | 4.984029 | 9.182892 | 4.198863 | 0.366525 | 9,116 | 0.286375 | accepted |
| late-product | 1 | 9.288157 | 13.276670 | 3.988513 | 0.363848 | 8,758 | 0.285004 | accepted |
| late-product | 2 | 13.377584 | 17.080405 | 3.702821 | 0.352069 | 8,765 | 0.278030 | accepted |
| late-product | 3 | 17.180141 | 21.177747 | 3.997606 | 0.361663 | 8,772 | 0.281600 | accepted |
| late-product | 4 | 21.281203 | 25.377739 | 4.096536 | 0.363572 | 8,779 | 0.282201 | accepted |
| late-product | 5 | 25.481272 | 29.278083 | 3.796811 | 0.354147 | 8,786 | 0.273122 | accepted |
| late-product | 6 | 29.382296 | 30.075414 | 0.693119 | 0.061371 | 1,511 | 0.048426 | PUBLIC_REQUEST_DEADLINE |

#### Run 2

| Phase | # | Import开始(s) | Import结束(s) | Wall(s) | Thread CPU(s) | Host calls | Host CPU(s，嵌套) | 结果 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| baseline | 0 | 2.804674 | 4.309427 | 1.504754 | 0.285712 | 9,256 | 0.224715 | accepted |
| baseline | 1 | 4.391668 | 5.502472 | 1.110804 | 0.270210 | 8,758 | 0.213634 | accepted |
| baseline | 2 | 5.514102 | 6.697886 | 1.183784 | 0.270722 | 8,765 | 0.213976 | accepted |
| baseline | 3 | 6.709785 | 7.901290 | 1.191505 | 0.279302 | 8,772 | 0.219881 | accepted |
| baseline | 4 | 7.913821 | 9.102954 | 1.189133 | 0.279018 | 8,779 | 0.218628 | accepted |
| baseline | 5 | 9.115415 | 10.319473 | 1.204058 | 0.276916 | 8,786 | 0.214477 | accepted |
| baseline | 6 | 10.330812 | 14.809977 | 4.479166 | 1.050713 | 29,957 | 0.742478 | accepted |
| baseline | 7 | 16.916125 | 18.195842 | 1.279717 | 0.289721 | 9,109 | 0.230471 | accepted |
| baseline | 8 | 18.207309 | 19.398928 | 1.191618 | 0.280278 | 8,834 | 0.219432 | accepted |
| baseline | 9 | 19.411255 | 20.595110 | 1.183855 | 0.275346 | 8,841 | 0.216962 | accepted |
| baseline | 10 | 20.607801 | 21.796301 | 1.188500 | 0.278605 | 8,848 | 0.217761 | accepted |
| baseline | 11 | 21.807261 | 23.000375 | 1.193113 | 0.280962 | 8,855 | 0.220128 | accepted |
| baseline | 12 | 23.013032 | 24.203005 | 1.189973 | 0.281937 | 8,862 | 0.220625 | accepted |
| baseline | 13 | 24.215205 | 28.804461 | 4.589257 | 1.068412 | 30,281 | 0.753266 | accepted |
| from-zero | 0 | 4.788697 | 8.978192 | 4.189495 | 0.369508 | 9,182 | 0.290623 | accepted |
| from-zero | 1 | 9.082903 | 12.778295 | 3.695392 | 0.357757 | 8,758 | 0.279615 | accepted |
| from-zero | 2 | 12.880528 | 16.578479 | 3.697951 | 0.349537 | 8,765 | 0.274660 | accepted |
| from-zero | 3 | 16.683302 | 20.283746 | 3.600443 | 0.361617 | 8,772 | 0.281257 | accepted |
| from-zero | 4 | 20.382030 | 23.984717 | 3.602687 | 0.358831 | 8,779 | 0.278538 | accepted |
| from-zero | 5 | 24.086741 | 28.077296 | 3.990555 | 0.373226 | 8,786 | 0.286229 | accepted |
| from-zero | 6 | 28.186447 | 30.078199 | 1.891752 | 0.175272 | 4,424 | 0.143282 | PUBLIC_REQUEST_DEADLINE |
| late-product | 0 | 4.984134 | 9.284929 | 4.300796 | 0.374591 | 9,142 | 0.293288 | accepted |
| late-product | 1 | 9.389973 | 13.182272 | 3.792299 | 0.361979 | 8,758 | 0.285091 | accepted |
| late-product | 2 | 13.282316 | 16.980904 | 3.698588 | 0.364478 | 8,765 | 0.286333 | accepted |
| late-product | 3 | 17.086928 | 20.683033 | 3.596105 | 0.352338 | 8,772 | 0.274181 | accepted |
| late-product | 4 | 20.790885 | 24.585123 | 3.794238 | 0.358054 | 8,779 | 0.278076 | accepted |
| late-product | 5 | 24.684932 | 28.580570 | 3.895638 | 0.360869 | 8,786 | 0.277587 | accepted |
| late-product | 6 | 28.594844 | 30.080958 | 1.486114 | 0.128089 | 3,159 | 0.103867 | PUBLIC_REQUEST_DEADLINE |

#### Run 3

| Phase | # | Import开始(s) | Import结束(s) | Wall(s) | Thread CPU(s) | Host calls | Host CPU(s，嵌套) | 结果 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| baseline | 0 | 2.800882 | 4.386376 | 1.585494 | 0.295251 | 9,256 | 0.233031 | accepted |
| baseline | 1 | 4.398467 | 5.586960 | 1.188493 | 0.274558 | 8,758 | 0.216860 | accepted |
| baseline | 2 | 5.599598 | 6.785469 | 1.185872 | 0.276262 | 8,765 | 0.219253 | accepted |
| baseline | 3 | 6.797471 | 7.990318 | 1.192847 | 0.281052 | 8,772 | 0.221374 | accepted |
| baseline | 4 | 8.002414 | 9.191788 | 1.189374 | 0.277876 | 8,779 | 0.218018 | accepted |
| baseline | 5 | 9.203939 | 10.477007 | 1.273068 | 0.283277 | 8,786 | 0.219759 | accepted |
| baseline | 6 | 10.489091 | 15.080994 | 4.591904 | 1.062497 | 29,957 | 0.749088 | accepted |
| baseline | 7 | 17.192628 | 18.400681 | 1.208053 | 0.286636 | 9,109 | 0.227446 | accepted |
| baseline | 8 | 18.413446 | 19.597473 | 1.184027 | 0.279869 | 8,834 | 0.220773 | accepted |
| baseline | 9 | 19.609217 | 20.810311 | 1.201094 | 0.277706 | 8,841 | 0.218730 | accepted |
| baseline | 10 | 20.822694 | 22.082568 | 1.259874 | 0.281329 | 8,848 | 0.219122 | accepted |
| baseline | 11 | 22.094660 | 23.289064 | 1.194404 | 0.279721 | 8,855 | 0.217927 | accepted |
| baseline | 12 | 23.301499 | 24.502189 | 1.200690 | 0.279296 | 8,862 | 0.217314 | accepted |
| baseline | 13 | 24.514488 | 29.185777 | 4.671289 | 1.080600 | 30,281 | 0.758616 | accepted |
| from-zero | 0 | 4.864044 | 9.160916 | 4.296872 | 0.374766 | 9,111 | 0.294267 | accepted |
| from-zero | 1 | 9.264018 | 12.770649 | 3.506630 | 0.357336 | 8,758 | 0.280190 | accepted |
| from-zero | 2 | 12.962943 | 16.476450 | 3.513507 | 0.351370 | 8,765 | 0.275776 | accepted |
| from-zero | 3 | 16.572441 | 20.166875 | 3.594433 | 0.360997 | 8,772 | 0.281571 | accepted |
| from-zero | 4 | 20.270464 | 23.971516 | 3.701051 | 0.359895 | 8,779 | 0.279497 | accepted |
| from-zero | 5 | 24.073293 | 27.864716 | 3.791423 | 0.361785 | 8,786 | 0.277380 | accepted |
| from-zero | 6 | 27.966919 | 30.061930 | 2.095011 | 0.196917 | 5,042 | 0.160902 | PUBLIC_REQUEST_DEADLINE |
| late-product | 0 | 4.964890 | 9.074316 | 4.109426 | 0.370236 | 9,158 | 0.293156 | accepted |
| late-product | 1 | 9.183696 | 12.867518 | 3.683822 | 0.351720 | 8,758 | 0.276825 | accepted |
| late-product | 2 | 12.967052 | 16.673693 | 3.706642 | 0.360592 | 8,765 | 0.282502 | accepted |
| late-product | 3 | 16.868115 | 20.470416 | 3.602301 | 0.350265 | 8,772 | 0.274698 | accepted |
| late-product | 4 | 20.571329 | 24.064912 | 3.493583 | 0.348718 | 8,779 | 0.273025 | accepted |
| late-product | 5 | 24.079689 | 27.866577 | 3.786888 | 0.355606 | 8,786 | 0.274337 | accepted |
| late-product | 6 | 28.067098 | 30.066183 | 1.999085 | 0.201771 | 5,250 | 0.165986 | PUBLIC_REQUEST_DEADLINE |

## 5. 攻击者与接收端：完整失败费用

144 个外部攻击 actor 的完整 report 均保留，无 cap 或 parent kill。它们合计发出 9,823 次调用：5,018 个签名 `WORK:Transcript` 拒绝、4,661 个签名 `WORK:Product` 拒绝、144 个 `EAGAIN` I/O 错误，0 个成功回复。接收端按完整 public request body digest 对应到 hostile／honest／history，所有记录均有归类；接收端拒绝数与调用方收到的签名回复数保持各自口径，末端取消不被隐去。

| Run | Attack | Calls | 签名工作拒绝 | I/O错误 | Whole actor CPU(s) | Acquisition CPU(s，嵌套) | attempts／misses | 已进入 dispatch CPU(s)／未进入数 |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | from-zero | 1,719 | 1,695 | 24 | 2.499005 | 0.016450 | 53/29 | 3.687193 / 22 |
| 1 | late-product | 1,604 | 1,580 | 24 | 2.348492 | 0.036500 | 51/27 | 3.841734 / 22 |
| 2 | from-zero | 1,690 | 1,666 | 24 | 2.459242 | 0.016420 | 53/29 | 3.662368 / 21 |
| 2 | late-product | 1,558 | 1,534 | 24 | 2.262142 | 0.036341 | 51/27 | 3.769204 / 22 |
| 3 | from-zero | 1,681 | 1,657 | 24 | 2.461141 | 0.016683 | 53/29 | 3.641156 / 22 |
| 3 | late-product | 1,571 | 1,547 | 24 | 2.268526 | 0.036910 | 51/27 | 3.758037 / 20 |

from-zero 每 phase 的 24 次初始 acquisition 合计 53 次尝试、29 个 miss；late-product 为 51 次尝试、27 个 miss。这类实际攻击复用各 actor 自己支付取得的包，再支付每次传输 challenge；不会把初始构造免费，也不会将其按每次重复调用再虚增。逐 actor 的 setup calls、diagnostic、traffic CPU、call trials、失败阶段、RSS、原始 report 摘要均在 cost-scope-analysis。whole entry、entire actor、acquisition、diagnostic、traffic 和 call CPU 是不同包含关系，不能层层累加。

上表 receiver 列为实际进入 dispatch 的已知 CPU 之和；未进入 dispatch 的 20–22 个记录分别保留 null，没有把它们补成零费用或删除。该区间之外的 transport／authentication／等待成本仍在各自 scope，不能由此推断为免费。

### public 进程、实际内核配额与信用

| Run | Phase | Whole public process CPU(s) | Public parent kernel CPU(s) | Setup CPU(s，嵌套) | 剩余 paid credit(s) | 真正耗尽 |
| ---: | --- | ---: | ---: | ---: | ---: | --- |
| 1 | baseline | 8.307214 | 8.342222 | 1.082089 | 1.997127 | false |
| 1 | from-zero | 8.744042 | 8.786263 | 1.087554 | 1.999689 | false |
| 1 | late-product | 8.732704 | 8.773142 | 1.086061 | 1.999910 | false |
| 2 | baseline | 8.333784 | 8.370312 | 1.087817 | 1.982747 | false |
| 2 | from-zero | 8.741703 | 8.785447 | 1.088759 | 1.999936 | false |
| 2 | late-product | 8.735825 | 8.778836 | 1.084123 | 1.999461 | false |
| 3 | baseline | 8.326255 | 8.362056 | 1.080914 | 1.991092 | false |
| 3 | from-zero | 8.751225 | 8.796057 | 1.101140 | 1.999783 | false |
| 3 | late-product | 8.725691 | 8.765624 | 1.078157 | 1.999506 | false |

全部九个 phase 的 `genuine_budget_depletion_observed=false`，balance identity 原记录为已验证。public kernel 样本包含 setup／shutdown，进程 CPU 也不等于单次 confirmation；throttled_usec 不是额外 CPU 工作。“诚实确认失败”与“信用耗尽”是两个原条件，本分析没有替换。对并发 actor wall 的求和、wait4 最大 RSS 或应用字节都不提升为整个系统的 wall／同时峰值内存／物理网络成本。

## 6. 同 artifact 的原合法成本选择

原 campaign 还保留每 run 的 8 个既有合法方法、cold／reuse 两种方式、每方式 3 个样本×4 次搜索。全部 24 个方法 actor 的 raw report 已与嵌入 report 内容核对，并记录各文件摘要；共 576 次合法搜索及对应实际验证，各 mode 每 12 次搜索有 19 次物理尝试／7 个 miss。它是原生 campaign 自己的固定比较，不等于扩大后的 V5 17-strategy grid，也不证明全部硬件和合法策略中的最优。

| Run | 原报告 best observed cold method | 材料／业务准备 CPU(s) | 该 cold 方法 acquisition CPU／12 winners(s) | 独立验证 CPU／12 calls(s) |
| ---: | --- | ---: | ---: | ---: |
| 1 | maintenance-limb | 2.142852 | 0.007831 | 0.005949 |
| 2 | maintenance-limb | 2.108466 | 0.007795 | 0.005922 |
| 3 | maintenance-limb | 2.124207 | 0.007906 | 0.005961 |

各方法还保留 same-task／target 的独立 from-zero samples，所有失败 ticket、diagnostics 和费用独立列出。旧 9f 的 V5 全成本审查包仍有其实际 binary／资源范围，不能用这份不同原生网格为其缺测单元补零。

## 7. 可据此采取的判断

ea909 在这三次实测中完成了 6 个 baseline 确认，完整 27 次分母仍未通过；攻击期间的完整历史导入尤其未完成。当前原始记录能够排除“作业未启动”“仅名册失败”“binary 身份漂移”作为这三轮失败的解释。它没有建立具体源码修改与性能变化之间的因果，也不证明单一瓶颈。独立客户端确认、history 同步、原条件和全部失败分母仍是关闭服务门的依据。

所有结论均为内部原始证据审读。未创建新的 source pass，external acceptance=false。

## 8. 可复核文件

- [analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-ea909-42329179267/analysis.json)：27 rounds、189 packet slots、84 history import 与 Host、原始三轮结果和 source/binary 身份。
- [cost-scope-analysis.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-ea909-42329179267/cost-scope-analysis.json)：144 attack actors、9 receiver partitions、36 Host 边界、24 合法成本 actor 及不相加口径。
- [verification-manifest.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-ea909-42329179267/verification-manifest.json)：全部 1,765 inventory 文件核验。
- [native-campaign-ea909-13557079786.zip](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-ea909-42329179267/native-campaign-ea909-13557079786.zip)：未经改写的原始 GitHub artifact。
- [receipt-index.json](sandbox:/workspace/scratch/e0c10cd6a255/w1_review/native-ea909-42329179267/receipt-index.json)：本次分析、脚本和记录的字节数／摘要。
