from pathlib import Path
import hashlib, json

BASE=Path('/workspace/scratch/a638c5cc4765'); ROOT=BASE/'Trillionnium-Chain'; FINAL=BASE/'owner-extension-final-v2'
def load(path): return json.loads(path.read_bytes())
def identify(path):
    data=path.read_bytes(); return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def dump(path,data): path.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
def archive(label):
    rb=load(BASE/(label+'-archive-readback.json'))
    vol=load(ROOT/'hia/qualification'/(label+'-development.parts/manifest.json'))
    assert rb['bytes']==vol['archive']['bytes'] and rb['sha256']==vol['archive']['sha256']
    return {'logical_name':label+'-development.tar.xz','manifest':label+'-development.parts/manifest.json',
            **vol['archive'],'parts':len(vol['parts']),'regular_members':rb['regular_members'],'logical_bytes':rb['logical_bytes'],
            'member_index':'MANIFEST.json','member_index_identity':rb['manifest'],
            'all_declared_members_read_completely':True,'single_xz_stream':True,'tar_tail_all_zero':True,
            'physical_volume_readback':'PASS'}
def common(label,scope):
    rb=load(BASE/(label+'-final-readback.json')); run=load(FINAL/(label+'.execution.json'))
    return {'schema':'trnm.hia.'+label+'-development.v1','base_commit':'88dd3c4afa80fd87284f4a114e3868ee6c5d4ed4',
            'scope':scope,'archive':archive(label),'final_execution':{
                'status':'PASS','test_methods':rb['finalized_tests'],'finalized':True,'source_unchanged':True,
                'wall_seconds':run['wall_seconds'],'source_inputs':rb['source_inputs_verified'],
                'complete_report_sha256':rb['report_sha256'],'actual_original_comparisons':rb['actual_original_pairs_verified']},
            'independent_readback':{'status':'PASS','record_member':'independent-readback.json',
                'verifier_member':'independent-reader.py','files_read':rb['complete_files_read'],
                'logical_bytes_read':rb['logical_bytes_read'],'runtime_reexecuted':False},
            'source_profile':'Pinned HIA self-host compiler; Linux x86_64 shared-library target, external linker and calloc/free; private owned state and staged output.',
            'hosted_execution':'NOT_RUN for this source increment at preparation',
            'whole_chain_native':False,'old_stack_can_be_removed':False,'retirement_accepted':False,'production_activation':False}

gov=common('governance','Complete original GovernanceGuard public lifecycle and private Clone/audit behavior within finite owned sessions; fixed no-input boundary fixture remains separate.')
rb=load(BASE/'governance-final-readback.json')
gov['final_execution'].update(complete_report_member='final/report.json',public_operations=6185,fixed_fixture_operations=193,
    native_processes=100,native_calls=144,original_retained_tests={'governance':45,'audit':3},allocator_runs=12,actual_allocation_refusals=11)
gov['native_and_original_artifacts']=rb['artifacts']
gov['failure_reporting_controls']={'actual_process_controls':rb['negative_process_controls'],
    'one_of_nine_old_roster':'INCOMPLETE despite unittest exit 0','actual_old_one_method_assertion':'FAIL',
    'final_roster_methods':10,'full_current_source_snapshot':True}
gov['preserved_history']={'initial_compile':'Actual SSA compiler refusal retained','initial_qualification':'Actual row-index assertion failure retained',
    'initial_merged_run':'Actual ENOSPC failure retained, never promoted to PASS','prior_success_iterations':'Excluded redundant prior successful runs; only final complete qualification is canonical.'}
gov['remaining']=['Live durable Node governance custody and authenticated execution','Whole-package and whole-chain retirement gates']
gov['final_formatting_correction']=load(BASE/'governance-whitespace-correction/correction.json')
dump(ROOT/'hia/qualification/governance-development.json',gov)

guard=common('control-guard','Original immutable LocalPlanGuardV0 evaluation policy plus an explicitly new local Ed25519 signature-provider profile; no production identity is inferred.')
rb=load(BASE/'control-guard-final-readback.json'); report=load(FINAL/'control-guard/observations.json')
guard['final_execution'].update(complete_report_member='final/observations.json',native_calls=1367,successful_session_evaluations=462,
    additional_native_extent_controls=6,original_retained_tests=5,allocator_runs=7,actual_allocation_refusals=3)
guard['profile']=report['profile'];guard['actual_signature_verification']=report['actual_signature_verification']
guard['original_production_signature_provider_found']=False
guard['native_and_original_artifacts']=rb.get('artifacts',{})
guard['independent_readback'].update(blob_references=rb['blob_references_verified'],unreferenced_blobs=0)
guard['native_worker_observations']='Complete parsed actual NativeModule observations; original Rust and allocator processes also retain complete actual raw streams.'
guard['preserved_history']={'initial_authoring_and_build_failures':'Actual observations retained with their own source identities',
    'initial_merged_run':'Actual ENOSPC class-setup failure has no completed successful report'}
guard['remaining']=['Production and post-quantum identity/provider policy','Live authenticated plan application and persistent Node integration','Whole-package and whole-chain retirement gates']
dump(ROOT/'hia/qualification/control-guard-development.json',guard)

peer=common('peer-lease','Original private lease/recovery value operations, Clone/Drop, ordering, projection decoding and full 8 MiB body hashing; durable journal and live authority are separate owners.')
rb=load(BASE/'peer-lease-final-readback.json')
peer['final_execution'].update(complete_report_member='final/report.json',public_operations=8095,native_processes=56,native_calls=66,
    allocator_runs=6,actual_allocation_refusals=4)
peer['native_and_original_artifacts']=rb.get('artifacts',{})
peer['original_retained_execution']={'status':'PASS','host':'rog','job_id':'1a1eec4371f-ffbe-2c3',
    'argv_policy':'cargo test --offline --locked --no-fail-fast -p trnm-peer-lease --all-features --message-format=json -- --test-threads=1',
    'outer_tests':121,'outer_filtered':0,'outer_ignored':0,'nested_child_tests_not_added':2,'executed_binaries_and_libraries':16,
    'actual_binary_bytes':231382068,'full_archive':rb['remote_archive'],'full_source_archive':rb['remote_source_archive'],
    'full_source_files':1700,'all_binary_and_source_bytes_read_by_root':True,
    'local_retained_test_reexecution':False,'local_unchanged_crate_build_role':'Independent API adapter only; --no-run is not a replacement for the remote complete test run.'}
peer['preserved_history']={'qualification_v1':'FAIL: local original Unix socket operations denied; old test and README complete source bytes were not retained, only observed hashes. Its native value comparisons do not grant complete qualification or source reproduction.',
    'initial_merged_run':'FAIL/INCOMPLETE after actual Cargo ENOSPC setup failure',
    'partial_reporter_control':'INCOMPLETE: one of thirteen methods, although unittest exits 0',
    'failure_reporter_control':'FAIL: actual one-method assertion failure',
    'reporter_control_source_bytes':'All reported hashes match separately preserved source snapshots; these are retained matching bytes, not a claim of contemporaneous snapshot creation.',
    'negative_driver_supplement':'native-extension-integration.tar.xz / peer-lease/qualification-report-negative.py'}
peer.update(durable_journal_owner_implemented=False,unix_authority_implemented=False,native_core_authentication_implemented=False)
peer['remaining']=['Private durable journal, locks, fsync and crash recovery owner','Unix daemon/client and authenticated Core authority','Native payload/body/recovery ownership and live Node integration','Whole-package and whole-chain retirement gates']
dump(ROOT/'hia/qualification/peer-lease-development.json',peer)

race=load(BASE/'work-handshake-race-readback.json'); full=load(BASE/'work-handshake-final-readback.json')
regression=load(BASE/'work-race-next/work/full-readback/qualification-full/report.json')
work={'schema':'trnm.hia.work-handshake-development.v1','base_commit':'88dd3c4afa80fd87284f4a114e3868ee6c5d4ed4',
    'scope':'Fix both real ready/go startup races in HIA-emitted Work owners, preserving fixed instruction addresses and sizes; complete native regression remains finite.',
    'archive':archive('work-handshake'),
    'frozen_owned_sources':load(BASE/'work-race-next/work/frozen-owned-v1.json'),
    'final_native_build':regression['build']['images'],'source_inputs':regression['source_inputs'],
    'deterministic_races':{'status':'PASS','actual_cases':24,'old_races_reproduced':4,'fixed_races':4,'invalid_word_controls':16,
        'whole_archive_members_read':race['complete_archive_members'],'complete_artifacts_read':race['complete_artifacts'],
        'code_or_general_register_writes':0,'normal_case_private_writes':0,
        'invalid_state_injection':'Only explicitly named invalid-2 and invalid-4294967295 controls; not normal race cases.',
        'job_id':'1a1eece0f29-ffbe-2f8','archive':race['archive']},
    'full_native_regression':full,'full_regression_job_id':'1a1eedbcc7f-ffbe-340',
    'same_actual_clock_2199_input':load(BASE/'work-race-next/work/clock-2199-same-input.json'),
    'original_build_negative_fixture':{'path':'work-handshake-original-build.tar.xz',**identify(ROOT/'hia/qualification/work-handshake-original-build.tar.xz')},
    'historical_failure':'The complete actual 5a hosted failure ZIP and diagnostics are inside the final archive; original failure remains unchanged.',
    'root_readback':'Every member of both complete remote archives, all raw artifact hashes and full semantic/trace/primitive observations were independently reread against root source bytes.',
    'runtime_reexecuted_by_readers':False,'actual_original_Rust_reexecuted':False,
    'hosted_execution':'NOT_RUN for this source increment at preparation',
    'remaining':['Fresh commit-bound hosted qualification','Production fixed-parent authority','Live Node/Paid integration','Original four-second/16-request service gate','All whole-chain retirement requirements'],
    'whole_chain_native':False,'old_stack_can_be_removed':False,'production_activation':False}
correction=load(BASE/'governance-whitespace-correction/correction.json')
assert correction['path'] not in regression['source_inputs']
assert regression['final_root_snapshot']['files'][correction['path']]==correction['before']
assert identify(ROOT/correction['path'])==correction['after']
for name,expected in regression['source_inputs'].items():
    assert identify(ROOT/name)==expected
work['post_runtime_integration_snapshot_delta']={**correction,
    'work_source_closure_135_unchanged':True,
    'interpretation':'The retained full Work run and root readback bind their actual earlier 20-file integration snapshot. One unrelated governance test then lost one extra final LF and was fully requalified separately. All 135 Work sources and actual native images remain byte-identical; no Work execution is relabeled to the changed governance test.'}
dump(ROOT/'hia/qualification/work-handshake-development.json',work)
print(json.dumps({'written':['governance-development.json','control-guard-development.json','peer-lease-development.json','work-handshake-development.json']}))
