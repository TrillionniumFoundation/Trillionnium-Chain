import hashlib,json,pathlib,os,stat,subprocess,sys,time
P=pathlib.Path('/tmp/chain-pq-fa62381e-s3-positive')
N=pathlib.Path('/tmp/chain-pq-fa62381e-s3-negative')
S='454ae116159867ff6cddd91b964523df7f7e16f0'
NS='f7c51532cc6657360b97226d9f396158253cea78'
NR='58e2fa946a7dc34cf58e8b357e04c2789da98f8b6218768d8e29651c6cf6b6f7'
record_path=pathlib.Path('/tmp/chain-pq-fa62381e-s3-clippy-guard.json')
launcher=pathlib.Path('/tmp/chain-pq-fa62381e-native-launcher.py')
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 with os.fdopen(fd,'rb') as f:
  before=os.fstat(f.fileno());assert stat.S_ISREG(before.st_mode) and before.st_nlink==1
  b=f.read();after=os.fstat(f.fileno())
  fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
  assert fields(before)==fields(after)==fields(p.stat(follow_symlinks=False))
 return b
pins={}
def data(p):
 b=read(p);pins[str(p)]=sha(b);return json.loads(b)
assert not record_path.exists()
ps=data(P/'summary.json');assert ps['component_validation_passed'] is True and ps['named_tests_passed']==64 and ps['source']==S and ps['phase_error'] is None
ns=data(N/'summary.json');bs=data(N/'batch/batch-summary.json')
assert ns['source']==NS and ns['positive_source']==S and ns['runner_sha256']==NR
for row in (ns,bs):
 assert row['negative_control_expectations_met'] is True and row['component_validation_passed'] is False
 assert row['native_tests_passed']==2 and row['native_tests_failed']==5 and row['phase_error'] is None
 assert row['whole_chain_quantum_security_qualified'] is False and row['production_activation'] is False
 assert row['original_business_budgets_changed'] is False
assert bs['expected_outcomes_matched']==7 and bs['native_batch_exit_code']==1
receipt=data(N/'commands/negative-native-batch.json')
assert receipt['status']=='command_failed' and receipt['exit_code']==1
assert receipt['before']==receipt['after']==data(N/'source-before.json')==data(N/'source-final.json')==data(N/'source-after-batch.json')
assert receipt['before']['tested_commit']==NS and receipt['before']['tested_tree']=='628f0d54ad9127471cc3902b50b915c4df2dcad7' and receipt['before']['tracked_worktree_verified'] is True
assert sha(read(N/'commands/negative-native-batch.log'))==receipt['log_sha256']
assert sha(read(pathlib.Path('/tmp/chain-pq-fa62381e-negative-tools/chain-pq-fa62381e-negative-validation-v3.py')))==NR
assert sha(read(launcher))=='1894d73d87b631b5d391b4919de182055440e6bcdf783330be7d4f841e120727'
record={'status':'native_observations_complete_clippy_authorized','source':S,'negative_source':NS,'positive_named_passes':64,'negative_actual_passes':2,'negative_actual_failures':5,'negative_expectations_matched':7,'negative_native_batch_exit_code':1,'negative_component_validation_passed':False,'whole_chain_quantum_security_qualified':False,'production_activation':False,'native_result_pins':pins,'business_budgets_changed':False}
with record_path.open('x') as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'guard_status':record['status'],'positive64':True,'negative_expected_failures':5,'negative_passes':2,'native_batch_exit':1,'guard_record_sha256':sha(read(record_path))}),flush=True)
command=[sys.executable,'-B',str(launcher),'--mode','clippy','--source',S,'--out','/tmp/chain-pq-fa62381e-s3-clippy','--target','/tmp/chain-pq-fa62381e-s3-positive-target']
result=subprocess.run(command,cwd='/tmp/chain-pq-fa62381e',check=False)
raise SystemExit(result.returncode if result.returncode>=0 else 128-result.returncode)
