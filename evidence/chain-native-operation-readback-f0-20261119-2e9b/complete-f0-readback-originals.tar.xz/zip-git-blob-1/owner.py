from pathlib import Path
from datetime import datetime,timezone
import base64,json,hashlib,subprocess,time,resource,sys,traceback
root=Path('/home/qian-qi/work/chain-native-operation-readback-f0-20261119-2e9b');out=root/'zip-git-blob-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
res={'schema':'chain-original-f0-zip-git-blob-publication-v1','parent_candidate':'3db79eb2682ba3bcbbf33557c5eee3b67731028f','post_count':0,'complete':False}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
try:
 receipt=json.loads((root/'collection/COLLECTION.json').read_text());assert receipt['complete_download'] is True and receipt['run_id']==44451798839
 path=root/'collection/artifact-14496651186.zip';raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
 assert len(raw)==17640478 and digest=='744a0d353fb5055fd111cb5acae33259c0e526a8e4240a8f33752d01bfac5ccd'
 blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();res.update(bytes=len(raw),sha256=digest,expected_git_blob=blob)
 payload=out/'blob-request.json'
 with payload.open('x') as f:json.dump({'encoding':'base64','content':base64.b64encode(raw).decode()},f,separators=(',',':'))
 command=['/usr/bin/gh','api','--method','POST','repos/TrillionniumFoundation/Trillionnium-Chain/git/blobs','--input',str(payload)]
 start=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN);res.update(command=command,post_count=1,started_utc=datetime.now(timezone.utc).isoformat());save()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:
  p=subprocess.Popen(command,stdout=so,stderr=se);res['pid']=p.pid;save();rc=p.wait()
 a=resource.getrusage(resource.RUSAGE_CHILDREN);res.update(exit_code=rc,wall_seconds=time.monotonic()-start,child_user_cpu_seconds=a.ru_utime-b.ru_utime,child_system_cpu_seconds=a.ru_stime-b.ru_stime);save()
 assert rc==0
 actual=json.loads((out/'stdout').read_text());assert actual['sha']==blob
 res['response']=actual;res['complete']=True;save();print(json.dumps(res),flush=True)
except BaseException as exc:
 res['error']=repr(exc);save();(out/'error.log').write_text(traceback.format_exc());raise
