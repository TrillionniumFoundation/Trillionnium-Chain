from pathlib import Path
import ast, datetime, hashlib, importlib.util, json, os, signal, stat, subprocess, sys, threading, time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
LIVE=Path('/home/qian-qi/Documents/Codex/2026-10-25/github-trillionnium-chain-https-github-com/work/root-chain-integration-20261026')
OUT=HERE/'check'
TARGET_LIMIT=6*1024**3
COLLECTION_LIMIT=8*1024**3
TARGET_RESERVE=512*1024**2
FINAL_RESERVE=256*1024**2
target=HERE/'fresh-dev-check-target'
tmp=HERE/'fresh-build-tmp'
state={'child':None,'violations':[],'samples':0,'target_peak':0,'collection_peak':0,'vanished_during_scans':0,'pending_stop':False,'spawn_handoff_stop':False,'last_group_signal_before_reap':False,'child_reaped':False}
stop=threading.Event();reaper=threading.Lock();thread=None;bounded=None;original_popen=None;patched=False;out_owned=False
stdout=b'';stderr=b'';before=None;admission=None;start=time.monotonic();errors=[];actual_owner=None
record={'schema':'pn1-transaction006-development-typecheck-actual-v1','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'normal_build_process_pass':False,'exit_code':None,'role':'normal development Cargo check --tests; no tests executed','publicprepare':False,'release_profile':False,'prepared':False,'native_qualification':False,'full_guard_enabled':False,'old_original1200_and_remaining164257ms_untouched':True,'no_old_target_ELF_reuse':True,'filesystem_or_physical_quota_claimed':False,'cooperative_monitor_not_every_instant_peak_proof':True,'whole_writer_qualified':False,'original_three_FD_caller_qualified':False,'independent_reader_qualified':False,'full4097_qualified':False,'task_complete':False,'merge_ready':False}

def failed(phase, error):
    errors.append({'phase': phase, 'error': repr(error)})
    record['normal_build_process_pass'] = False

def measure(root):
    if not root.is_dir() or root.is_symlink():
        raise ValueError('missing or symlink owned-tree root')
    total = 0
    vanished = 0
    for base, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            path = Path(base) / name
            try:
                status = path.lstat()
            except FileNotFoundError:
                vanished += 1
                continue
            if stat.S_ISLNK(status.st_mode):
                total += len(os.fsencode(os.readlink(path)))
            elif stat.S_ISREG(status.st_mode):
                total += status.st_size
            elif not stat.S_ISDIR(status.st_mode):
                raise ValueError('unknown owned build object type')
    return total, vanished

def sample():
    target_bytes, vanished_target = measure(target)
    collection_bytes, vanished_collection = measure(HERE)
    state['samples'] += 1
    state['target_peak'] = max(state['target_peak'], target_bytes)
    state['collection_peak'] = max(state['collection_peak'], collection_bytes)
    state['vanished_during_scans'] += vanished_target + vanished_collection
    if target_bytes + TARGET_RESERVE > TARGET_LIMIT or collection_bytes + FINAL_RESERVE > COLLECTION_LIMIT:
        raise ValueError('conservative normal-build admission reserve/cap reached')
    return target_bytes, collection_bytes

def signal_owned_group_locked():
    # The helper never reaps before its final wait. This same lock serializes
    # our last possible signal with that final, already-terminal reap.
    child = state['child']
    if child is not None and not state['child_reaped']:
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        state['last_group_signal_before_reap'] = True

def monitor():
    while not stop.wait(.25):
        try:
            sample()
        except BaseException as error:
            with reaper:
                state['violations'].append(repr(error))
                state['pending_stop'] = True
                try:
                    signal_owned_group_locked()
                except BaseException as signal_error:
                    state['violations'].append('monitor-stop-failed: ' + repr(signal_error))
            return

def watched_popen(*args, **kwargs):
    child = original_popen(*args, **kwargs)
    real_wait = child.wait

    def owned_wait(*wait_args, **wait_kwargs):
        # This exact pinned helper calls wait() only after its final killpg.
        # Wait for WNOWAIT terminal status without holding the signal lock;
        # the final reap is then immediate and serialized with every signal.
        if wait_args or wait_kwargs:
            raise ValueError('unexpected bounded-helper wait arguments')
        while True:
            with reaper:
                try:
                    terminal = os.waitid(os.P_PID, child.pid,
                                         os.WEXITED | os.WNOHANG | os.WNOWAIT)
                except InterruptedError:
                    terminal = None
                if terminal is not None:
                    if terminal.si_pid != child.pid or terminal.si_code not in (os.CLD_EXITED, os.CLD_KILLED, os.CLD_DUMPED):
                        raise ValueError('unexpected final WNOWAIT child status')
                    returncode = real_wait()
                    state['child_reaped'] = True
                    state['child'] = None
                    return returncode
            time.sleep(.005)

    child.wait = owned_wait
    with reaper:
        state['child'] = child
        if state['pending_stop']:
            state['spawn_handoff_stop'] = True
            try:
                signal_owned_group_locked()
            except BaseException as error:
                # Preserve the child for the bounded helper's own cleanup.
                state['violations'].append('spawn-handoff-stop-failed: ' + repr(error))
    return child

def save_json(name, value):
    try:
        if not out_owned:
            raise ValueError('output directory was not exclusively created by this attempt')
        (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
        return True
    except BaseException as error:
        failed('write-' + name, error)
        return False

def sources():
    return [{'path':row['path'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for row in admission['source_pins'] for data in [(LIVE/row['path']).read_bytes()]]

def source_status():
    def git(*args):
        result=subprocess.run(['git','-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false',*args],cwd=LIVE,capture_output=True,timeout=10,check=True)
        return result.stdout.decode().strip()
    return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain=v1','--untracked-files=all'))

try:
    OUT.mkdir(exist_ok=False);out_owned=True
    save_json('initial-failure-receipt.json',record)
    pre=subprocess.run(['bash','scripts/project-preflight.sh','--dev'],cwd=LIVE,capture_output=True,timeout=30)
    (OUT/'preflight.stdout').write_bytes(pre.stdout);(OUT/'preflight.stderr').write_bytes(pre.stderr)
    if pre.returncode:raise ValueError('project preflight failed')
    admission=json.loads((HERE/'admission.json').read_text())
    expected=dict(head=admission['head'],tree=admission['tree'],status='')
    source_before=source_status();record['source_before']=source_before
    if source_before!=expected:raise ValueError('exact clean development source mismatch')
    before=sources()
    if before!=admission['source_pins']:raise ValueError('source pins mismatch')
    external=admission['external_C_source'];cdata=Path(external['path']).read_bytes()
    if len(cdata)!=external['bytes'] or hashlib.sha256(cdata).hexdigest()!=external['sha256']:raise ValueError('pinned SQLite C source mismatch')
    save_json('source-before.json',before)
    helper=LIVE/'formal/pon-nakamoto-v1/bounded_process.py'
    spec=importlib.util.spec_from_file_location('bounded_process',helper);bounded=importlib.util.module_from_spec(spec);sys.modules[spec.name]=bounded;spec.loader.exec_module(bounded)
    sys.path.insert(0,str(LIVE/'scripts'));sys.path.insert(0,str(LIVE/'scripts/ci'))
    import run_pon_native_io_component as component
    if component.bounded_process is not bounded:raise ValueError('one exact bounded_process module required')
    component.validate_build_environment(os.environ)
    resources=component.resource_observation()
    leaf=resources['limits'][0]
    if leaf['cpu.max']!='200000 100000' or leaf['memory.max']!='8589934592':raise ValueError('actual development 2CPU/8GiB cgroup mismatch')
    if resources['nice']<10:raise ValueError('development nice admission mismatch')
    for row in resources['limits']:
        value=row['cpu.max']
        if value is not None:
            quota,period=value.split()
            if int(period)<=0 or (quota!='max' and int(quota)<2*int(period)):raise ValueError('ancestor CPU below development declaration')
        maximum=row['memory.max']
        if maximum not in (None,'max') and int(maximum)<8589934592:raise ValueError('ancestor memory below development declaration')
    save_json('resources-before.json',resources)
    target.mkdir(exist_ok=False);tmp.mkdir(exist_ok=False)
    if any(target.iterdir()):raise ValueError('new development target not empty')
    env={key:value for key,value in os.environ.items() if not key.startswith('TRNM_')}
    env.update(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2',CARGO_NET_OFFLINE='true',RUSTUP_TOOLCHAIN='1.95.0',TMPDIR=str(tmp),PYTHONDONTWRITEBYTECODE='1')
    cpus=sorted(os.sched_getaffinity(0))[:2]
    if len(cpus)!=2:raise ValueError('two eligible affinity CPUs required')
    argv=['taskset','--cpu-list',','.join(map(str,cpus)),'prlimit','--as=3221225472','--','/home/qian-qi/.cargo/bin/cargo','check','-p','trnm-pon-node','-p','trnm-sqlite-io-boundary','--tests','--locked','--offline','--message-format=json']
    child_timeout=min(560.0,620.0-(time.monotonic()-start)-45.0)
    if child_timeout<=0:raise ValueError('no positive development child budget with final reserve')
    record.update(argv=argv,cwd=str(LIVE/'trillionnium'),fresh_target=str(target),new_target_empty_before_child=True,TMPDIR=str(tmp),cargo_jobs=2,toolchain_environment='1.95.0',cpu_affinity=cpus,AS_limit_bytes=3221225472,cgroup_required_cpu_percent=200,cgroup_required_memory_max_bytes=8589934592,child_timeout_seconds=child_timeout,outer_timeout_seconds=620,stdout_stderr_limit_bytes_each=4194304,target_cap_bytes=TARGET_LIMIT,target_reserve_bytes=TARGET_RESERVE,collection_cap_bytes=COLLECTION_LIMIT,collection_reserve_bytes=FINAL_RESERVE)
    initial=sample();record['initial_target_collection_bytes']=list(initial)
    original_popen=bounded.subprocess.Popen;bounded.subprocess.Popen=watched_popen;patched=True
    actual_owner=component.NativeChildOwner()
    thread=threading.Thread(target=monitor);thread.start()
    try:
        result=actual_owner.run(argv,timeout=child_timeout,stdout_limit=4*1024**2,stderr_limit=4*1024**2,cwd=LIVE/'trillionnium',env=env)
        record['exit_code']=result.returncode;stdout,stderr=result.stdout,result.stderr
    except bounded.ProcessFailure as error:
        record.update(exit_code=error.returncode,owner_failure=str(error),stdout_truncated=error.stdout_truncated,stderr_truncated=error.stderr_truncated);stdout,stderr=error.stdout,error.stderr
    record['native_process_owner']=actual_owner.value
    actual_owner.complete(record['exit_code'])
except BaseException as error:
    failed('development-check',error)
finally:
    if patched:bounded.subprocess.Popen=original_popen
    stop.set()
    if thread is not None:thread.join(timeout=6)
    if thread is not None and thread.is_alive():failed('monitor','monitor thread terminal unknown')
    if actual_owner is not None:record['native_process_owner']=actual_owner.value
    if out_owned:
        try:(OUT/'stdout.log').write_bytes(stdout);(OUT/'stderr.log').write_bytes(stderr)
        except BaseException as error:failed('raw-publication',error)
        try:
            final_target,vanished=measure(target);final_collection,vanished2=measure(HERE)
            record.update(target_final_bytes=final_target,collection_final_before_receipt_bytes=final_collection,final_scan_vanished=vanished+vanished2)
            if vanished+vanished2:failed('final-measure','final owned scan incomplete')
        except BaseException as error:failed('final-measure',error)
        try:
            after=sources();source_after=source_status();record['source_after']=source_after;record['source_before_after_equal']=before==after and source_after==expected
            if not record['source_before_after_equal']:failed('source-after','source identity changed')
            save_json('source-after.json',after)
            cdata=Path(admission['external_C_source']['path']).read_bytes()
            record['C_source_after_equal']=len(cdata)==admission['external_C_source']['bytes'] and hashlib.sha256(cdata).hexdigest()==admission['external_C_source']['sha256']
            if not record['C_source_after_equal']:failed('C-source-after','C source changed')
        except BaseException as error:failed('source-after',error)
        try:
            rows=[json.loads(line) for line in stdout.splitlines() if line]
            (OUT/'cargo-events.json').write_text(json.dumps(rows,indent=2)+'\n')
            errors_from_rust=[row for row in rows if row.get('reason')=='compiler-message' and row.get('message',{}).get('level')=='error']
            record['compiler_errors']=errors_from_rust
            record['build_finished_events']=[row for row in rows if row.get('reason')=='build-finished']
            checked_tests=[row for row in rows if row.get('reason')=='compiler-artifact' and row.get('profile',{}).get('test') is True and row.get('target',{}).get('name') in ('trnm_pon_node','trnm_sqlite_io_boundary')]
            record['actual_checked_test_crates']=[{'target':row['target'],'profile':row['profile'],'fresh':row.get('fresh')} for row in checked_tests]
            record['native_C_build_events']=[row for row in rows if row.get('reason')=='build-script-executed' and 'trnm-sqlite-io-boundary' in row.get('package_id','')]
        except BaseException as error:failed('cargo-json',error)
        record.update(finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds_before_result_publication=time.monotonic()-start,stdout_bytes=len(stdout),stderr_bytes=len(stderr),stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),owned_tree_monitor=state|{'child':None},errors=errors)
        owner=record.get('native_process_owner',{})
        process_pass=(record.get('exit_code')==0 and not record.get('owner_failure') and not errors and not state['violations'] and state['child_reaped'] and owner.get('reaped') is True and owner.get('original_identity_alive_after_wait') is False and record.get('source_before_after_equal') is True and record.get('C_source_after_equal') is True and record.get('target_final_bytes',TARGET_LIMIT+1)+TARGET_RESERVE<=TARGET_LIMIT and record.get('collection_final_before_receipt_bytes',COLLECTION_LIMIT+1)+FINAL_RESERVE<=COLLECTION_LIMIT and record['elapsed_seconds_before_result_publication']<620)
        record['normal_build_process_pass']=process_pass
        record['actual_14_control_functions_typechecked_only']=process_pass and len(record.get('actual_checked_test_crates',[]))==2
        record['new_controls_executed']=False
        save_json('result.json',record)
        print(json.dumps({k:record.get(k) for k in ('schema','exit_code','normal_build_process_pass','actual_14_control_functions_typechecked_only','new_controls_executed','elapsed_seconds_before_result_publication','stdout_bytes','stderr_bytes','errors')}))
raise SystemExit(0 if record['normal_build_process_pass'] else 1)
