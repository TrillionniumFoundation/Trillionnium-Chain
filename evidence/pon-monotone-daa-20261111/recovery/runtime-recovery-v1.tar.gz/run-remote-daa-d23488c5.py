import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import tarfile
import time
import traceback

ROOT = Path('/home/qian-qi/chain-daa-monotone-20261111-7f73')
SOURCE = ROOT / 'source'
OUT = ROOT / 'native-run-d23488c5-v1'
BUNDLE = ROOT / 'daa-implementation.bundle'
BASE = '249f772cc2a2ace5e363fd5fbfec4241a26f4d4d'
COMMIT = 'd23488c5f9b4a6696c3799b12f14b8af0a1b81fc'
TREE = '72b106b4458299c37da146b0218b8f5276195b6d'
BRANCH = 'fix/chain-daa-monotone-witness-20261111-7f73'
CARGO = '/home/qian-qi/.cargo/bin/cargo'
RUSTC = '/home/qian-qi/.cargo/bin/rustc'
NATIVE_PATH = 'trillionnium/crates/trnm-pon-node/tests/daa_joint_consensus.rs'
OUT.mkdir(exist_ok=False)
ENV = os.environ.copy()
ENV.update(CARGO_TARGET_DIR=str(ROOT / 'target'), CARGO_BUILD_JOBS='2')
ENV['PATH'] = '/home/qian-qi/.cargo/bin:' + ENV.get('PATH', '')
COMMANDS = []
FAILED = []


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE, text=True).strip()


def run(label, args, *, separate=False, required=True, env=None):
    started = now()
    clock = time.monotonic()
    stdout_path = OUT / (label + ('.stdout.json' if separate else '.log'))
    stderr_path = OUT / (label + '.stderr.log') if separate else stdout_path
    selected_env = ENV if env is None else env
    print(json.dumps({'phase': label, 'state': 'started', 'at': started, 'argv': args}), flush=True)
    with stdout_path.open('wb') as stdout:
        if separate:
            with stderr_path.open('wb') as stderr:
                process = subprocess.run(args, cwd=SOURCE, env=selected_env, stdout=stdout, stderr=stderr)
        else:
            process = subprocess.run(args, cwd=SOURCE, env=selected_env, stdout=stdout, stderr=subprocess.STDOUT)
    record = {
        'label': label, 'argv': args, 'cwd': str(SOURCE), 'started_utc': started,
        'finished_utc': now(), 'elapsed_seconds': time.monotonic() - clock,
        'returncode': process.returncode, 'required': required,
        'stdout_path': str(stdout_path), 'stderr_path': str(stderr_path),
        'stdout_sha256': sha(stdout_path), 'stderr_sha256': sha(stderr_path),
        'stdout_bytes': stdout_path.stat().st_size, 'stderr_bytes': stderr_path.stat().st_size,
        'recorded_environment': {name: selected_env[name] for name in (
            'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'TRNM_JOINT_DAA_EVIDENCE_DIR',
            'TRNM_MONOTONE_DAA_EVIDENCE_DIR') if name in selected_env},
    }
    COMMANDS.append(record)
    write_json(OUT / 'commands.json', COMMANDS)
    print(json.dumps({'phase': label, 'state': 'completed', 'returncode': process.returncode,
                      'elapsed_seconds': record['elapsed_seconds']}), flush=True)
    if required and process.returncode:
        FAILED.append(label)
    return process.returncode, stdout_path


def require_run(label, args, **kwargs):
    result = run(label, args, **kwargs)
    if result[0]:
        raise RuntimeError(label + ' failed; exact log retained')
    return result


def source_check(label):
    return run(label, ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py',
                       '--kind', 'head', '--expected-head', COMMIT,
                       '--output', str(OUT / (label + '.json'))])


source_ready = False
try:
    write_json(OUT / 'context.json', {
        'schema': 'pon-monotone-native-execution-context-v1',
        'expected_commit': COMMIT, 'expected_tree': TREE, 'expected_parent': BASE,
        'branch': BRANCH, 'host_alias': 'desktop', 'platform': platform.platform(),
        'logical_validation_clocks': True, 'wall_clock_mining_cadence_measured': False,
        'attacker_resource_fraction_measured': False, 'quantum_profitability_measured': False,
        'public_network_qualification': False, 'production_activation': False,
        'started_utc': now(), 'target_directory': ENV['CARGO_TARGET_DIR'],
        'build_jobs': ENV['CARGO_BUILD_JOBS'],
    })
    assert BUNDLE.stat().st_size == 39479
    assert sha(BUNDLE) == '731940e7c4fcb1c0fc2cabd0a9bca5f3de7354a5a5b8c82217a9f0d4d0d64c72'
    assert git('rev-parse', 'HEAD') == BASE
    assert not git('status', '--porcelain', '--untracked-files=all')
    require_run('preflight-base', ['bash', 'scripts/project-preflight.sh'])
    require_run('bundle-verify', ['git', 'bundle', 'verify', str(BUNDLE)])
    require_run('bundle-fetch', ['git', 'fetch', str(BUNDLE), 'HEAD'])
    assert git('rev-parse', 'FETCH_HEAD') == COMMIT
    existing = subprocess.run(['git', 'show-ref', '--verify', '--quiet', 'refs/heads/' + BRANCH], cwd=SOURCE)
    if existing.returncode == 0:
        assert git('rev-parse', 'refs/heads/' + BRANCH) == BASE
        require_run('candidate-switch', ['git', 'switch', BRANCH])
        require_run('candidate-fast-forward', ['git', 'merge', '--ff-only', COMMIT])
    else:
        assert existing.returncode == 1
        require_run('candidate-switch', ['git', 'switch', '-c', BRANCH, COMMIT])
    assert git('rev-parse', 'HEAD') == COMMIT
    assert git('rev-parse', 'HEAD^{tree}') == TREE
    assert git('rev-parse', 'HEAD^') == BASE
    assert git('branch', '--show-current') == BRANCH
    assert sha(SOURCE / NATIVE_PATH) == '73114fb5e02ed07ee9431c6b64f24c740c3403b6ae3016e945078e0b283ef1ec'
    require_run('preflight-candidate', ['bash', 'scripts/project-preflight.sh'])
    if source_check('source-before')[0]:
        raise RuntimeError('source-before failed')
    source_ready = True
    for label, args in [
        ('cargo-version', [CARGO, '-V']), ('rustc-version', [RUSTC, '-Vv']),
        ('rustfmt-version', ['/home/qian-qi/.cargo/bin/rustfmt', '-V']),
        ('clippy-version', [CARGO, 'clippy', '-V']),
    ]:
        require_run(label, args)
    graph_summaries = []
    for label, flags in [('graph-default', []), ('graph-all-features', ['--all-features'])]:
        code, output = run(label, [CARGO, 'metadata', '--locked', '--manifest-path',
                                  'trillionnium/Cargo.toml', '--format-version', '1', *flags], separate=True)
        if code == 0:
            graph = json.loads(output.read_text())
            graph_summaries.append({'label': label, 'workspace_members': len(graph['workspace_members']),
                                    'packages': len(graph['packages']),
                                    'resolve_nodes': len(graph['resolve']['nodes']),
                                    'graph_sha256': sha(output)})
    write_json(OUT / 'graph-summaries.json', graph_summaries)
    run('cargo-fmt-check', [CARGO, 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check'])
    test_env = ENV.copy()
    test_env.update(TRNM_JOINT_DAA_EVIDENCE_DIR=str(OUT / 'joint-daa'),
                    TRNM_MONOTONE_DAA_EVIDENCE_DIR=str(OUT / 'monotone-daa'))
    assert not Path(test_env['TRNM_JOINT_DAA_EVIDENCE_DIR']).exists()
    assert not Path(test_env['TRNM_MONOTONE_DAA_EVIDENCE_DIR']).exists()
    test_code, test_log = run('native-daa-four-tests', [CARGO, 'test', '--locked', '--manifest-path',
                        'trillionnium/Cargo.toml', '-p', 'trnm-pon-node', '--test',
                        'daa_joint_consensus', '--', '--nocapture', '--test-threads=1'], env=test_env)
    test_text = test_log.read_text(errors='replace')
    paths = re.findall(r'Running tests/daa_joint_consensus\.rs \(([^\n]+)\)', test_text)
    if paths:
        assert len(paths) == 1
        binary = Path(paths[0])
        if not binary.is_absolute():
            binary = SOURCE / binary
        binary = binary.resolve(strict=True)
        assert binary.is_file() and os.access(binary, os.X_OK)
        assert binary.is_relative_to(ROOT / 'target')
        write_json(OUT / 'native-binary.json', {
            'path': str(binary), 'sha256': sha(binary), 'bytes': binary.stat().st_size,
            'binding': 'exact cargo Running tests/daa_joint_consensus.rs log line',
            'cargo_log_sha256': sha(test_log), 'tested_source': COMMIT,
        })
    if test_code == 0:
        assert 'test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in test_text
        assert (OUT / 'native-binary.json').is_file()
        exports = []
        for namespace, filename in [('joint-daa', 'joint-daa.json'), ('monotone-daa', 'monotone-daa.json')]:
            for profile in ['pnh1-authenticated', 'pgh2-growth']:
                directory = OUT / namespace / profile
                report = directory / filename
                files = list((directory / 'packets').glob('*.pnk'))
                assert len(files) == 114
                data = json.loads(report.read_text())
                assert len(data['records']) == 114
                exports.append({'namespace': namespace, 'profile': profile,
                                'packet_files': len(files), 'records': len(data['records']),
                                'report_path': str(report), 'report_sha256': sha(report)})
        write_json(OUT / 'native-export-manifest.json', exports)
    run('clippy-daa-all-features', [CARGO, 'clippy', '--locked', '--manifest-path',
                     'trillionnium/Cargo.toml', '-p', 'trnm-pon-node', '--test',
                     'daa_joint_consensus', '--all-features', '--', '-D', 'warnings'])
except BaseException as error:
    FAILED.append('execution-exception')
    (OUT / 'execution-exception.log').write_text(traceback.format_exc())
    print(json.dumps({'state': 'exception', 'type': type(error).__name__, 'message': str(error)}), flush=True)
finally:
    if source_ready:
        try:
            source_check('source-after')
        except BaseException:
            FAILED.append('source-after-exception')
            (OUT / 'source-after-exception.log').write_text(traceback.format_exc())
    write_json(OUT / 'result.json', {
        'schema': 'pon-monotone-native-execution-result-v1', 'tested_commit': COMMIT,
        'tested_tree': TREE, 'finished_utc': now(), 'failed_steps': FAILED,
        'required_commands_passed': not FAILED, 'source_ready': source_ready,
        'scope': 'finite native fixture, exact source and selected development gates',
        'public_network_qualification': False, 'production_activation': False,
    })
    archive = ROOT / 'native-run-d23488c5-v1.tar.gz'
    assert not archive.exists()
    with tarfile.open(archive, 'w:gz') as stream:
        stream.add(OUT, arcname=OUT.name)
    archive_receipt = {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive)}
    write_json(ROOT / 'native-run-d23488c5-v1-archive.json', archive_receipt)
    print(json.dumps({'state': 'finished', 'failed_steps': FAILED, 'archive': archive_receipt}), flush=True)
sys.exit(1 if FAILED else 0)
