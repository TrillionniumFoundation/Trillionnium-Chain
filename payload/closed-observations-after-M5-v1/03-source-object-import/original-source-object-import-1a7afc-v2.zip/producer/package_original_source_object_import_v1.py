import pathlib,sys,os,stat,json,hashlib,zipfile,datetime
BASE=pathlib.Path("/home/qian-qi/chain-final-consolidation-20261114-root")
SRC=BASE/"external-evidence-object-import-1a7afc-v2"
OUT=BASE/"package-original-source-object-import-1a7afc-v2"
assert not sys.flags.optimize and SRC.resolve(strict=True)==SRC and not OUT.exists()
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 p=pathlib.Path(p);assert p.resolve(strict=True)==p
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
 try:
  a=os.fstat(fd);assert stat.S_ISREG(a.st_mode) and a.st_nlink==1 and a.st_size<=4*1024*1024
  with os.fdopen(os.dup(fd),"rb") as f:b=f.read()
  z=os.fstat(fd);assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns) and len(b)==a.st_size
  return b
 finally:os.close(fd)
raw=read(SRC/"summary.json");assert len(raw)==114574 and sha(raw)=="f91eb93242dcf20dbc4f02107f9b5c188a0a91aec7d17e5903dc5a53ff46e749"
j=json.loads(raw);assert j["status"]=="IMPORTED_AND_VERIFIED" and not j["errors"] and j["import_exit"]==0 and j["source_before"]==j["source_after"] and j["source_unchanged"] and j["raw_object_readback_complete"] and j["fourteen_tree_closure_verified"]
assert j["expected_head"]=="1a7afcdb820b051d1e4bfde3d436f96fc050c487" and j["expected_tree"]=="18c3d20df915f5c31ee38c7037775c61e5c12e3f"
assert j["driver_sha256"]=="b691bdc0542b2a335283e59bb75954d6d7b996e42b86d4aa8db6b0af9c2c3faa" and j["network_calls"]==0 and j["lane_run"] is False
paths=sorted(SRC.iterdir());assert len(paths)<=400
payload={};rows=[]
def add(p,n,b=None):
 assert n not in payload and not n.startswith("/") and ".." not in pathlib.PurePosixPath(n).parts
 b=read(p) if b is None else b;payload[n]=b
 rows.append({"path":n,"bytes":len(b),"sha256":sha(b),"origin":{"host":"rog","path":str(p)}})
for p in paths:add(p,"original/"+p.name)
assert sum(len(b) for b in payload.values())<=16*1024*1024
def verify_meta(v):
 if isinstance(v,dict):
  if set(("path","bytes","sha256")).issubset(v) and pathlib.Path(v["path"]).parent==SRC:
   b=payload["original/"+pathlib.Path(v["path"]).name];assert len(b)==v["bytes"] and sha(b)==v["sha256"]
  for q in v.values():verify_meta(q)
 elif isinstance(v,list):
  for q in v:verify_meta(q)
verify_meta(j)
readback=json.loads(payload["original/readback-3912.json"])
assert len(readback)==3912 and len({r["oid"] for r in readback})==3912 and sum(r["bytes"] for r in readback)==509417482 and all(r["git_sha1_verified"] for r in readback)
rb=[s for s in j["steps"] if s["label"]=="stream-readback-exact-3912"];assert len(rb)==1 and rb[0]["verified_count"]==3912 and rb[0]["failure"] is None and rb[0]["exit"]==0 and rb[0]["stdout_retained"] is False
driver=BASE/"import_external_evidence_source_capsule_v2.py";b=read(driver)
assert len(b)==28961 and sha(b)=="b691bdc0542b2a335283e59bb75954d6d7b996e42b86d4aa8db6b0af9c2c3faa"
add(driver,"producer/"+driver.name,b)
me=pathlib.Path(__file__).resolve(strict=True);add(me,"producer/"+me.name)
rows.sort(key=lambda x:x["path"])
index={"schema":"trnm-original-source-capsule-import-receipt-package-v1","original_result":j["status"],"original_head":j["expected_head"],"original_tree":j["expected_tree"],"original_file_count":len(paths),"source_before_after_equal":True,"raw_readback_objects":3912,"raw_readback_bytes":509417482,"fourteen_tree_closure_verified":True,"files":rows}
ix=(json.dumps(index,indent=2,sort_keys=True)+"\n").encode()
OUT.mkdir(mode=0o700)
(OUT/"EVIDENCE_INDEX.json").write_bytes(ix)
zpath=OUT/"original-source-object-import-1a7afc-v2.zip"
with zipfile.ZipFile(zpath,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in sorted({**payload,"EVIDENCE_INDEX.json":ix}.items()):
  info=zipfile.ZipInfo(n,(2026,11,14,0,0,0));info.create_system=3;info.external_attr=(stat.S_IFREG|0o600)<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b)
with zipfile.ZipFile(zpath,"r") as z:
 assert z.testzip() is None and len(z.infolist())==len(payload)+1
 for r in rows:
  b=z.read(r["path"]);assert len(b)==r["bytes"] and sha(b)==r["sha256"]
 assert z.read("EVIDENCE_INDEX.json")==ix
assert sorted(SRC.iterdir())==paths
for r in rows:
 b=read(r["origin"]["path"]);assert len(b)==r["bytes"] and sha(b)==r["sha256"]
zb=read(zpath)
summary={"schema":"trnm-original-source-object-import-package-completion-v1","finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"zip":{"path":str(zpath),"bytes":len(zb),"sha256":sha(zb)},"index":{"path":str(OUT/"EVIDENCE_INDEX.json"),"bytes":len(ix),"sha256":sha(ix)},"payload_file_count":len(rows),"zip_member_count":len(rows)+1,"original_execution_file_count":len(paths),"original_execution_bytes":sum(r["bytes"] for r in rows if r["path"].startswith("original/")),"all_member_CRC_SHA_verified":True,"original_files_unchanged":True,"source_or_Git_objects_modified":False,"tests_rerun":False,"original_result":j["status"],"complete_lane_claimed":False}
sb=(json.dumps(summary,indent=2,sort_keys=True)+"\n").encode();(OUT/"summary.json").write_bytes(sb)
print(json.dumps({"summary_path":str(OUT/"summary.json"),"summary_bytes":len(sb),"summary_sha256":sha(sb),**summary}),flush=True)
