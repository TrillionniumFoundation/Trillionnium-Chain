from pathlib import Path
import os,sys,json,time,resource,subprocess,hashlib,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/resume-20261120-e9e051/source');out=src.parent/'repository-tail-diagnostic-5';out.mkdir(exist_ok=False)
(out/'owner.py').write_text(sys.argv[1]);res={'schema':'chain-original-repository-input-continuation-v1','complete':False,'commands':[],'source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'runtime_source_unchanged':True,'f0_repeated':False}
env=os.environ.copy();env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];env['RUST_TEST_THREADS']='1';env['CARGO_TARGET_DIR']=str(src.parent/'target');(out/'temp').mkdir();env['TMPDIR']=str(out/'temp');res['temporary_filesystem_matches_source']=os.stat(out/'temp').st_dev==os.stat(src).st_dev;assert res['temporary_filesystem_matches_source']
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 localenv=dict(env,TRNM_CI_RECEIPT_DIR=str(out/(name+'-receipts')))
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=src,env=localenv,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'argv':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['commands'].append(row);save();print(json.dumps(row),flush=True)
 if rc:print((out/(name+'.stderr')).read_text(errors='replace')[-6500:],flush=True);raise RuntimeError(name+' failed')
try:
 run('preflight',['bash','scripts/project-preflight.sh'])
 original=(src.parent.parent/'repository-tail-diagnostic-75/original-tail.sh').read_bytes();marker=b'    python3 scripts/ci/test_read_original_native_campaign.py '
 assert original.count(marker)==1
 suffix=original[original.index(marker):]
 body=b'#!/usr/bin/env bash\nset -euo pipefail\nexport RUST_TEST_THREADS="${RUST_TEST_THREADS:-1}"\n# Exact original suffix; not a complete repository qualification.\n'+suffix
 (out/'original-suffix.sh').write_bytes(body);res['original_suffix_sha256']=hashlib.sha256(suffix).hexdigest();res['source_diff_sha256']=hashlib.sha256(subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src)).hexdigest();save()
 run('original-suffix',['bash',str(out/'original-suffix.sh')])
 res['complete_repository_truth_passed']=False;res['preserved_failure']='legacy source erasure and r21/r22 source identity failures retained; prior hardlink failure retained and same-filesystem TMPDIR supplied for reader'
 res['complete']=True;res['remaining_suffix_passed']=True;save();print(json.dumps({'complete':True,'remaining_suffix_passed':True}),flush=True)
except BaseException as e:
 res['complete']=True;res['remaining_suffix_passed']=False;res['error']=repr(e);save();(out/'owner.error').write_text(traceback.format_exc());raise
