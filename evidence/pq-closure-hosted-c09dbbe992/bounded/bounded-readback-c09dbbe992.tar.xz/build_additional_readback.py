#!/usr/bin/env python3
"""Package already downloaded C1 observations, without network or test execution."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import tarfile
import zipfile

B = Path(__file__).resolve().parent
R = B / 'status-refresh-c09dbbe992-20261111'
OUT = R / 'public-readback'
HEAD = 'c09dbbe9921da12db8bf7240a8a95a0e9a789e50'
MERGE = '61589dddd13e7495369aaecad9212668049417c1'
TREE = 'f15a7ee4a0f5455eaf965db01dcd49e02a5f22b6'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def put(name, raw):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(raw)


def read(path):
    return json.loads(path.read_bytes())


def projected(value):
    kept, omitted = {}, {}
    for key, item in value.items():
        raw = encoded(item)
        if not isinstance(item, (dict, list)) or len(raw) <= 131072:
            kept[key] = item
        else:
            omitted[key] = {'json_type': type(item).__name__, 'length': len(item),
                            'reencoded_json_bytes': len(raw), 'reencoded_json_sha256': sha(raw)}
    return {'retained_original_fields': kept, 'omitted_large_fields': omitted}


def archive_index(z):
    result = {}
    for info in z.infolist():
        name = info.filename
        assert name not in result and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
        assert not info.is_dir() and (info.external_attr >> 16) & 0o170000 in (0, 0o100000)
        raw = z.read(info)
        assert len(raw) == info.file_size
        result[name] = {'path': name, 'bytes': len(raw), 'sha256': sha(raw)}
    return result


def original_zip(a):
    p = R / 'artifacts' / f"artifact-{a['id']}.zip"
    raw = p.read_bytes()
    assert len(raw) == a['size_in_bytes'] and 'sha256:' + sha(raw) == a['digest']
    return p, raw


def main():
    OUT.mkdir()
    # Explicit directory allowlist; the private download transport is elsewhere.
    for folder in ('api', 'logs', 'transport'):
        for p in sorted((R / folder).iterdir()):
            assert p.is_file() and not p.is_symlink()
            put(folder + '/' + p.name, p.read_bytes())
    for p in sorted((R / 'artifacts').glob('*-download.json')):
        put('download-observations/' + p.name, p.read_bytes())
    local = []
    for a in read(R / 'api/local-codeql-artifacts.json')['artifacts']:
        path, raw = original_zip(a)
        put('local-codeql/' + path.name, raw)
        with zipfile.ZipFile(path) as z:
            index = archive_index(z)
            step_name = next(n for n in index if n.endswith('/step-outcomes.json'))
            step = json.loads(z.read(step_name))
            prefix = step_name[:-len('step-outcomes.json')]
            before = json.loads(z.read(prefix + 'source-before.json'))
            after = json.loads(z.read(prefix + 'source-after.json'))
            expected = HEAD if step['source_kind'] == 'head' else MERGE
            assert before == after and before['tested_commit'] == expected and before['tested_tree'] == TREE
            assert step['expected_source_commit'] == expected and step['code_scanning_upload'] == 'never'
            assert all(v == 'success' for v in step['outcomes'].values())
            sarif = []
            for n in index:
                if n.endswith('.sarif'):
                    doc = json.loads(z.read(n))
                    assert doc['version'] == '2.1.0' and isinstance(doc['runs'], list) and doc['runs']
                    sarif.append({**index[n], 'runs': len(doc['runs']),
                        'results': sum(len(row.get('results', [])) for row in doc['runs'])})
            assert sarif
            row = {'artifact': a, 'source_before': before, 'source_after': after,
                   'step_outcomes': step, 'sarif': sarif, 'zip_members': list(index.values())}
            local.append(row)
    assert {(r['step_outcomes']['language'], r['step_outcomes']['source_kind']) for r in local} == {
        (language, source) for language in ('actions', 'python', 'rust') for source in ('head', 'prospective-merge')}
    put('local-codeql-summary.json', encoded({'source_head': HEAD, 'source_merge': MERGE,
        'six_cells_complete': True, 'code_scanning_upload': 'never',
        'api_producer_or_pr_security_gate_qualification_inferred': False, 'cells': local}))
    fresh = []
    for a in read(R / 'api/w1-work-security-artifacts.json')['artifacts']:
        if not a['name'].startswith('w1-fresh-service-'):
            continue
        path, _ = original_zip(a)
        lane = 'head' if '-head-' in a['name'] else 'prospective-merge'
        expected = HEAD if lane == 'head' else MERGE
        prefix = 'fresh-service/' + lane
        with zipfile.ZipFile(path) as z:
            index = archive_index(z)
            m = json.loads(z.read('fresh-service/manifest.json'))
            assert m['source_before'] == m['source_after']
            assert m['source_expected'] == m['source_before']['commit'] == expected
            assert m['source_before']['tree'] == TREE
            assert m['binary_sha256_before'] == m['binary_sha256_after']
            listed = {'fresh-service/' + n for n in m['files']}
            for name, digest in m['files'].items():
                assert index['fresh-service/' + name]['sha256'] == digest
            scope = {n for n in index if n.startswith('fresh-service/')} - {'fresh-service/manifest.json'}
            assert listed == scope
            put(prefix + '/zip-member-index.json', encoded(list(index.values())))
            for name, meta in index.items():
                if meta['bytes'] <= 262144 and PurePosixPath(name).suffix in ('.json', '.log', '.txt', '.py'):
                    put(prefix + '/raw/' + name, z.read(name))
            reports = []
            for variant in ('original', 'fresh'):
                name = f'fresh-service/{variant}/report.json'
                report = json.loads(z.read(name))
                projected_report = {**index[name], 'scope': 'labelled exact field projection; full original remains in hash-bound ZIP',
                    'top_level': projected({k: v for k, v in report.items() if k != 'phases'}),
                    'phases': [projected(p) for p in report['phases']]}
                put(prefix + '/projections/' + variant + '.json', encoded(projected_report))
                phases = []
                for p in report['phases']:
                    fields = ('mode', 'workers', 'requested_window_ns', 'finite_business_target_met',
                        'invariant_target_met', 'client_confirmed_transactions', 'client_confirmed_before_original_window_end',
                        'full_native_state_equal', 'verification_errors')
                    phases.append({**{k: p.get(k) for k in fields},
                        'last_history_replay': {k: v for k, v in p['independent_history_page_replay'][-1].items()
                                               if not isinstance(v, (dict, list))}})
                reports.append({'variant': variant, 'member': index[name], 'finite_target_met': report['finite_target_met'],
                                'phases': phases})
            original_log = z.read('fresh-service/original.log')
            fresh_log = z.read('fresh-service/fresh.log')
            assert sha(original_log) == m['runs'][0]['log_sha256'] and sha(fresh_log) == m['runs'][1]['log_sha256']
            assert b'fresh challenges failed the original four-second/six-depth business target' in fresh_log
            fresh.append({'lane': lane, 'artifact': a, 'manifest': m,
                'all_zip_members_hashed': len(index), 'nested_manifest_files_verified': len(listed),
                'nested_manifest_complete_coverage': True, 'reports': reports,
                'classification': 'actual original four-second/six-depth confirmation business failure; source/build/host succeeded'})
    assert len(fresh) == 2
    put('fresh-service-summary.json', encoded({'source_head': HEAD, 'source_merge': MERGE, 'lanes': fresh,
                                             'budgets_or_acceptance_changed': False, 'native_tests_run_by_reader': 0}))
    runs = read(R / 'api/runs-c09dbbe992.json')
    baseline = read(R / 'api/required-baseline-jobs.json')
    merge_log = (R / 'logs/prospective-external-log.log').read_text()
    assert 'Ran 71 tests' in merge_log and 'FAILED (failures=46, errors=22)' in merge_log
    assert 'durable backend selected implementation' in merge_log
    summary = {
        'schema': 'c1-hosted-bounded-refresh-v1',
        'assembled_utc': datetime.now(timezone.utc).isoformat(),
        'api_timing': {'first_batch_exact_started_utc': None,
            'first_batch_observed_before_utc': '2026-11-11T05:07:03Z',
            'second_batch_started_utc': '2026-11-11T05:07:03Z',
            'second_batch_finished_utc': '2026-11-11T05:07:04Z',
            'additional_log_and_artifact_metadata_observed_before_utc': '2026-11-11T05:08:32Z',
            'note': 'No timestamp is invented for the first API batch; raw API update timestamps and retained download times are separate.'},
        'source': {'head': HEAD, 'merge': MERGE, 'base': '31543fb6dde565b62b47436e0b1d399b6d0bd772', 'tree': TREE},
        'pr_head_at_readback': read(R / 'api/pr-901.json')['head']['sha'],
        'workflow_runs': [{k: r[k] for k in ('id', 'name', 'path', 'status', 'conclusion', 'head_sha', 'updated_at')} for r in runs['workflow_runs']],
        'required_baseline_jobs': [{k: j[k] for k in ('id', 'name', 'status', 'conclusion', 'started_at', 'completed_at')} for j in baseline['jobs']],
        'required_run_level_and_job_level_raw_statuses_retained_separately': True,
        'local_codeql': {'run_id': 42955582992, 'success_cells': 6, 'retained_sarif_artifacts': 6,
            'exact_source_receipts_verified': True, 'upload': 'never', 'api_export_gap_closed': False},
        'new_failures': [
            {'run_id': 42955583052, 'job_id': 130309764799, 'source': MERGE,
             'classification': 'same stale durable selected-body source binding as the C1 head failure',
             'tests_run': 71, 'failures': 46, 'errors': 22,
             'C2_outcome_inferred_from_C1': False},
            {'run_id': 42955582893, 'job_id': 130309765098, 'source': HEAD,
             'classification': 'actual fresh and original four-second confirmation business failure'},
            {'run_id': 42955582893, 'job_id': 130309765213, 'source': MERGE,
             'classification': 'actual fresh and original four-second confirmation business failure'},
        ],
        'running_or_queued_jobs_are_not_passes': True, 'further_monitoring_performed': False,
        'old_315_results_substituted': False, 'native_tests_run_by_reader': 0,
    }
    put('bounded-refresh-summary.json', encoded(summary))
    put('build_additional_readback.py', Path(__file__).read_bytes())
    files = [{'path': str(p.relative_to(OUT)), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
             for p in sorted(OUT.rglob('*')) if p.is_file()]
    put('FILES.json', encoded(files))
    put('SHA256SUMS', ''.join(f"{r['sha256']}  {r['path']}\n" for r in files).encode())
    target = R / 'bounded-readback-c09dbbe992.tar.xz'
    with target.open('xb') as stream, tarfile.open(fileobj=stream, mode='w:xz', preset=6) as archive:
        for p in sorted(OUT.rglob('*')):
            if p.is_file():
                raw = p.read_bytes(); info = tarfile.TarInfo(str(p.relative_to(OUT)))
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                archive.addfile(info, io.BytesIO(raw))
    receipt = {'path': target.name, 'bytes': target.stat().st_size, 'sha256': sha(target.read_bytes()),
               'indexed_files': len(files), 'scope': 'bounded C1 refresh; no test rerun or source mutation'}
    with (R / 'bounded-readback-receipt.json').open('x') as f:
        json.dump(receipt, f, indent=2);f.write('\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
