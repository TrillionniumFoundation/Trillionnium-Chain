import pathlib,subprocess,json,hashlib,time,os,signal,re,threading,concurrent.futures
root=pathlib.Path('/data/chain-six-5176-20261108/source');out=root.parent/'evidence/validation-f0';out.mkdir(exist_ok=False)
head='4505a598d6ec2644a175e47398d4a5f3f054bc5e';env=os.environ.copy()
prefix='/home/qian-qi/workspace/pon-demand-acceptance-20261107-root525798dad3c2/build-runtime/trnm-pq-provider-3.5.9.DYf2qEaX/install'
env.update(PYTHONDONTWRITEBYTECODE='1',CARGO_TARGET_DIR='/data/chain-six-5176-20261108/targets/npq6',CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',OPENSSL_DIR=prefix,OPENSSL_LIB_DIR=prefix+'/lib',OPENSSL_INCLUDE_DIR=prefix+'/include',OPENSSL_STATIC='1',GIT_PAGER='cat',PAGER='cat')
groups=json.loads("[[{\"name\":\"check_repository\",\"args\":[\"python3\",\"-B\",\"scripts/ci/check_repository.py\"],\"timeout\":300},{\"name\":\"check_pq_research_integration\",\"args\":[\"python3\",\"-B\",\"scripts/ci/check_pq_research_integration.py\"],\"timeout\":300},{\"name\":\"test_ci_source_integrity\",\"args\":[\"python3\",\"-B\",\"scripts/ci/test_ci_source_integrity.py\"],\"timeout\":300},{\"name\":\"test_pq_research_integration\",\"args\":[\"python3\",\"-B\",\"scripts/ci/test_pq_research_integration.py\"],\"timeout\":300},{\"name\":\"test_codeql_retention\",\"args\":[\"python3\",\"-B\",\"scripts/ci/test_codeql_retention.py\"],\"timeout\":300},{\"name\":\"test_public_readiness_evidence\",\"args\":[\"python3\",\"-B\",\"scripts/ci/test_public_readiness_evidence.py\"],\"timeout\":300},{\"name\":\"test_w1_current_source_observation\",\"args\":[\"python3\",\"-B\",\"scripts/ci/test_w1_current_source_observation.py\"],\"timeout\":300},{\"name\":\"test_w1_current_source_mapping\",\"args\":[\"python3\",\"-B\",\"scripts/ci/test_w1_current_source_mapping.py\"],\"timeout\":300}],[{\"name\":\"cargo-graph\",\"args\":[\"/home/qian-qi/.cargo/bin/cargo\",\"+1.95.0\",\"metadata\",\"--manifest-path\",\"trillionnium/Cargo.toml\",\"--locked\",\"--offline\",\"--format-version\",\"1\"],\"timeout\":300},{\"name\":\"all-format\",\"args\":[\"/home/qian-qi/.cargo/bin/cargo\",\"+1.95.0\",\"fmt\",\"--manifest-path\",\"trillionnium/Cargo.toml\",\"--all\",\"--\",\"--check\"],\"timeout\":180},{\"name\":\"settlement-package\",\"args\":[\"/home/qian-qi/.cargo/bin/cargo\",\"+1.95.0\",\"test\",\"--manifest-path\",\"trillionnium/Cargo.toml\",\"--locked\",\"--offline\",\"-p\",\"trnm-service-settlement\",\"--\",\"--test-threads=1\"],\"timeout\":900},{\"name\":\"npq6-cli\",\"args\":[\"/home/qian-qi/.cargo/bin/cargo\",\"+1.95.0\",\"test\",\"--manifest-path\",\"trillionnium/Cargo.toml\",\"--locked\",\"--offline\",\"-p\",\"trnm-pon-node\",\"--features\",\"pq-native-openssl\",\"--test\",\"pq_application_local_cli\",\"--\",\"--test-threads=1\"],\"timeout\":900},{\"name\":\"growth\",\"args\":[\"/home/qian-qi/.cargo/bin/cargo\",\"+1.95.0\",\"test\",\"--manifest-path\",\"trillionnium/Cargo.toml\",\"--locked\",\"--offline\",\"-p\",\"trnm-pon-node\",\"--features\",\"pq-native-openssl\",\"--lib\",\"native_growth_v2_\",\"--\",\"--test-threads=1\"],\"timeout\":1800},{\"name\":\"consensus\",\"args\":[\"/home/qian-qi/.cargo/bin/cargo\",\"+1.95.0\",\"test\",\"--manifest-path\",\"trillionnium/Cargo.toml\",\"--locked\",\"--offline\",\"-p\",\"trnm-pon-node\",\"--features\",\"pq-native-openssl\",\"--lib\",\"consensus::tests::\",\"--\",\"--test-threads=1\"],\"timeout\":900},{\"name\":\"daa_joint_consensus\",\"args\":[\"/home/qian-qi/.cargo/bin/cargo\",\"+1.95.0\",\"test\",\"--manifest-path\",\"trillionnium/Cargo.toml\",\"--locked\",\"--offline\",\"-p\",\"trnm-pon-node\",\"--features\",\"pq-native-openssl\",\"--test\",\"daa_joint_consensus\",\"--\",\"--test-threads=1\"],\"timeout\":900},{\"name\":\"daa_adversarial_schedule\",\"args\":[\"/home/qian-qi/.cargo/bin/cargo\",\"+1.95.0\",\"test\",\"--manifest-path\",\"trillionnium/Cargo.toml\",\"--locked\",\"--offline\",\"-p\",\"trnm-pon-node\",\"--features\",\"pq-native-openssl\",\"--test\",\"daa_adversarial_schedule\",\"--\",\"--test-threads=1\"],\"timeout\":900},{\"name\":\"native_task_operation_v2\",\"args\":[\"/home/qian-qi/.cargo/bin/cargo\",\"+1.95.0\",\"test\",\"--manifest-path\",\"trillionnium/Cargo.toml\",\"--locked\",\"--offline\",\"-p\",\"trnm-pon-node\",\"--features\",\"pq-native-openssl\",\"--test\",\"native_task_operation_v2\",\"--\",\"--test-threads=1\"],\"timeout\":900},{\"name\":\"strict-clippy-trnm-service-settlement\",\"args\":[\"/home/qian-qi/.cargo/bin/cargo\",\"+1.95.0\",\"clippy\",\"--manifest-path\",\"trillionnium/Cargo.toml\",\"--locked\",\"--offline\",\"-p\",\"trnm-service-settlement\",\"--all-targets\",\"--all-features\",\"--\",\"-D\",\"warnings\"],\"timeout\":1800},{\"name\":\"strict-clippy-trnm-pon-node\",\"args\":[\"/home/qian-qi/.cargo/bin/cargo\",\"+1.95.0\",\"clippy\",\"--manifest-path\",\"trillionnium/Cargo.toml\",\"--locked\",\"--offline\",\"-p\",\"trnm-pon-node\",\"--all-targets\",\"--all-features\",\"--\",\"-D\",\"warnings\"],\"timeout\":1800}]]")
records=[];lock=threading.Lock()
def run(row):
 start=time.monotonic();name=row['name'];timeout=False
 with (out/(name+'.stdout')).open('wb') as so,(out/(name+'.stderr')).open('wb') as se:
  proc=subprocess.Popen(row['args'],cwd=root,env=env,stdout=so,stderr=se,start_new_session=True)
  try:code=proc.wait(timeout=row.get('timeout',300))
  except subprocess.TimeoutExpired:
   timeout=True;os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   code=124
 result=dict(row,exit=code,seconds=time.monotonic()-start,timed_out=timeout)
 texts=(out/(name+'.stdout')).read_text(errors='replace')+(out/(name+'.stderr')).read_text(errors='replace')
 if 'test' in row['args'] and row['args'][0].endswith('/cargo'):
  result['native_summaries']=re.findall(r'test result: (?:ok|FAILED)\. ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored;',texts)
  result['nonempty_native_execution']=any(int(a)>0 for a,b,c in result['native_summaries'])
  if code==0 and not result['nonempty_native_execution']:result['exit']=125
 with lock:
  records.append(result);(out/'progress.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(result),flush=True)
 return result['exit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
assert run({'name':'preflight','args':['bash','scripts/project-preflight.sh']})==0
verify=['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',head]
assert run({'name':'source-before','args':verify+['--output',str(out/'source-before.json')],'timeout':600})==0
def group(rows):
 for row in rows:run(row)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 list(pool.map(group,groups))
run({'name':'current-mapping-cli','args':['python3','-B','scripts/w1_current_source_mapping.py','--root',str(root),'--expected-head',head,'--output',str(out/'current-mapping.json')]})
run({'name':'source-after','args':verify+['--output',str(out/'source-after.json')],'timeout':600})
same=(out/'source-before.json').read_bytes()==(out/'source-after.json').read_bytes()
report={'source_commit':head,'records':records,'source_unchanged':same,'all_passed':same and all(r['exit']==0 for r in records),'production_activation':False,'security_disposition':'HOLD_NO_GO'}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'result':'PASS' if report['all_passed'] else 'FAIL','source_unchanged':same,'source_commit':head}),flush=True)
