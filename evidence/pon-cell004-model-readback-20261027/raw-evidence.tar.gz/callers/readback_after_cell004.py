"""Read only the completed Cell004 material through the original backend.

This evidence caller never installs/selects a candidate or creates an authority.
The declared ordinary-task gate stays false even when a backend forward succeeds.
"""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
CHAIN = ROOT / "chain-native-c96022"
RUN = ROOT / "real-model-run-001"
CELL = RUN / "cell-handoff-fixed-serving-004"
OUT = RUN / "post-cell004-backend-readback"
PYTHON = ROOT / "model-env-3123-offline/bin/python"
sys.path.insert(0, str(CHAIN / "scripts"))
import llm_runtime_pilot as runtime
import llm_inherited_runtime as inherited
from llm_runtime_candidate_observation_v1 import _terminal


def sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


assert not OUT.exists()
handoff = runtime.read_json(CELL / "handoff.json")
assert handoff["status"] == "failed"
assert handoff["transfer"]["all_members_verified"] is True
assert handoff["transfer"]["within_original_deadline"] is True
assert handoff["transfer"]["limit_seconds"] == 35
assert handoff["release"]["prepare"]["release"] == "0c3b841b42f507129d24bb3f335c90756e8057fb06883c9bf62d3100bfdd0cfd"
assert handoff["native_consumer_status"] == "UNAVAILABLE"
assert handoff["native_receipt_status"] == "UNVERIFIED"
assert handoff["error"].startswith("native Hepta consumer UNAVAILABLE;")
assert handoff["producer_exit_code_before_consumer_load"] == 0
assert len(handoff["members"]) == 11
for member in handoff["members"]:
    assert sha(member["destination"]) == member["pack"]["payload_sha256"]
    assert member["fetch"]["downloaded_chunks"] == 0
    assert member["fetch"]["connection_attempts"] == 0
    assert member["fetch"]["received_response_bytes"] == 0

parent_path = CELL / "consumer-parent/parent-material.json"
parent = runtime.read_json(parent_path)
assert parent["directory"] == str(CELL / "consumer-parent")
assert parent["adapter"] == "d3b3e79ee9432f467881b9b7fd5eef1c6d2908da6fce73de9fd786f541094dc6"
assert parent["file_sha256"] == "eaa627e8937afa9f23fb8ab97c89d03f8e59748c6016cd610772bc594f81a90b"
inherited.read_parent(parent)
frozen = runtime.read_json(RUN / "frozen-sequence.json")
request = dict(schema="hepta-smollm-inference-input-v1", request_id="post-fetch-readback-001",
               prompt=frozen["next_request"])
assert request["prompt"] == "Answer with only yes or no. Is 103 greater than 102?"
request_path = RUN / "cell004-next-request.json"
with request_path.open("xb") as file:
    file.write(runtime.canonical(request) + b"\n")

args = [str(PYTHON), str(CHAIN / "scripts/llm_inherited_runtime.py"), "infer",
    "--materials", str(CELL / "consumer-materials"), "--parent", str(parent_path),
    "--parent-sha256", sha(parent_path), "--input", str(request_path),
    "--input-sha256", sha(request_path), "--operation-id", request["request_id"],
    "--output", str(OUT), "--threads", "2", "--steps", "10"]
summary = dict(schema="controlled-post-cell-backend-readback-observation-v1",
    source_chain="c96022b897c1235fdbdbfcfa32764403511c6aab",
    caller_sha256=sha(__file__), original_backend_sources=inherited.source_pins(),
    handoff_sha256=sha(CELL / "handoff.json"), command=args,
    scope="actual-downloaded-candidate-backend-forward-not-ordinary-installation-or-task",
    ordinary_installation=False, ordinary_task_used=False, hepta_final_use=False,
    model_quality_qualified=False, public_reward_eligible=False, outcome="running")
runtime.save(RUN / "post-cell004-readback-invocation.json", summary)
env = dict(os.environ, HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
           PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1",
           OMP_NUM_THREADS="2", MKL_NUM_THREADS="2", OPENBLAS_NUM_THREADS="2")
started = time.monotonic_ns()
try:
    with (ROOT / "evidence/post-cell004-backend-readback.log").open("xb") as log:
        process = subprocess.run(args, cwd=CHAIN, env=env, stdout=log, stderr=subprocess.STDOUT)
    summary["exit_code"] = process.returncode
    assert process.returncode == 0
    actual = runtime.read_json(OUT / "worker/actual-receipt.json")
    plan = runtime.read_json(OUT / "execution-plan.json")
    supervisor = runtime.read_json(OUT / "supervisor.json")
    _terminal(supervisor, plan["runtime"]["inference_budget"])
    assert actual["actual_loaded_parent"] == actual["artifact"] == parent["adapter"]
    assert actual["forward_executed"] is True and actual["outcome"] == "success"
    assert all(flag is False for flag in actual["authority"].values())
    assert inherited.source_pins() == summary["original_backend_sources"]
    summary.update(outcome="backend-forward-observed", actual_receipt_sha256=sha(OUT / "worker/actual-receipt.json"),
        supervisor_sha256=sha(OUT / "supervisor.json"), loaded_adapter=actual["actual_loaded_parent"],
        decoded_outputs=actual["prediction"]["response"]["decoded_outputs"],
        generated_tokens=actual["prediction"]["generated_tokens"],
        original_handoff_unavailable_failure_preserved=True)
except BaseException as error:
    summary.update(outcome="failed", error_type=type(error).__name__, error=str(error))
    raise
finally:
    summary["outer_wall_ns"] = time.monotonic_ns() - started
    runtime.save(RUN / "post-cell004-readback-observation.json", summary)
    print(json.dumps(summary), flush=True)
