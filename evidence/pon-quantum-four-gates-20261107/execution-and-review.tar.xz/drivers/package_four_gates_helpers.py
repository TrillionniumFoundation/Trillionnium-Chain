#!/usr/bin/env python3
"""Deterministic archive and exact-source receipt checks for the four-gate evidence."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import lzma
import re
import tarfile

HEAD = 'ec3a939706592c6ec9dd677b70589a7e8860cdfd'
TREE = '94a2dd1ebda9ce4eb262b6887b739e623616f08a'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def json_bytes(value):
    return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()

def collect(directory, prefix, exclude_names=()):
    rows={}
    for path in sorted(directory.rglob('*')):
        if '__pycache__' in path.parts or path.suffix == '.pyc' or path.name in exclude_names:
            continue
        if path.is_symlink():
            raise ValueError('UNEXPECTED_EVIDENCE_SYMLINK:'+str(path))
        if path.is_file():
            name=str(PurePosixPath(prefix)/PurePosixPath(path.relative_to(directory).as_posix()))
            if name.startswith('/') or '..' in PurePosixPath(name).parts:
                raise ValueError('ARCHIVE_PATH')
            rows[name]=path.read_bytes()
    return rows

def archive(destination, rows, scope):
    if destination.exists():
        raise ValueError('DO_NOT_OVERWRITE_ARCHIVE')
    raw=io.BytesIO()
    members=[]
    with tarfile.open(fileobj=raw,mode='w',format=tarfile.USTAR_FORMAT) as tar:
        for name,content in sorted(rows.items()):
            item=tarfile.TarInfo(name)
            item.size=len(content);item.mode=0o644;item.mtime=0
            item.uid=item.gid=0;item.uname=item.gname=''
            tar.addfile(item,io.BytesIO(content))
            members.append({'path':name,'bytes':len(content),'mode':item.mode,'sha256':sha(content)})
    data=lzma.compress(raw.getvalue(),preset=6)
    with destination.open('xb') as stream:
        stream.write(data)
    # Inspect the actual retained archive, not only its in-memory construction.
    with lzma.open(destination,'rb') as decoded:
        with tarfile.open(fileobj=decoded,mode='r|') as tar:
            seen=[]
            for item in tar:
                assert item.isfile() and not item.pax_headers
                content=tar.extractfile(item).read()
                seen.append({'path':item.name,'bytes':len(content),'mode':item.mode,'sha256':sha(content)})
    assert seen==members
    return {'scope':scope,'bytes':len(data),'sha256':sha(data),'uncompressed_tar_bytes':len(raw.getvalue()),'members':members}

def check_frozen_groups(base):
    result={};counts={}
    for group in ('quantum','repository','economics','rust','fuzz'):
        directory=base/group
        before=json.loads((directory/'source-before.json').read_text())
        after=json.loads((directory/'source-after.json').read_text())
        assert before==after and before['head']==HEAD and before['tree']==TREE
        report=json.loads((directory/'result.json').read_text())
        assert report['status']=='PASS' and report['source']==before
        commands=json.loads((directory/'commands.json').read_text())
        assert len(commands)==report['commands']
        unit_count=0
        for command in commands:
            assert command['exit_code']==0 and command['timeout'] is False
            log=(directory/command['log']).read_bytes()
            assert sha(log)==command['sha256']
            unit_count+=sum(map(int,re.findall(rb'^Ran (\d+) tests? in ',log,re.M)))
        result[group]=report;counts[group]=unit_count
    assert counts=={'quantum':412,'repository':189,'economics':18,'rust':0,'fuzz':0}
    return {'groups':result,'python_unit_counts':counts,'distinct_python_tests':sum(counts.values())}
