#!/usr/bin/env python3
"""Apply the reviewed checkpoint test synchronization after sealed C1 observations."""
import argparse
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/chain-pq-boundary-closure-20261112-4150')
C1 = '921acc94fa7af15cb1728ab2718c62f48ad93c89'
BASE = '8970e2c81abbf48e2a4d3f0802d79624ab20fadd'
INGRESS = 'de7acc8a59d77f11be4c17c380cc9c2bca91905c'
PRIOR = Path('/home/qian-qi/work/pq-boundary-validation-20261112-4150-v1')
PACKET = Path('/home/qian-qi/work/pq-boundary-checkpoint-socket-package-4150.json')
CI_PACKET = Path('/home/qian-qi/work/pq-boundary-checkpoint-ci-package-4150.json')
TEST = 'trillionnium/crates/trnm-checkpoint-store/tests/socket_ownership.rs'
CI_PATHS = {'.github/workflows/pon-pq-system-continuation.yml',
            'scripts/ci/check_ci_contract.py', 'scripts/ci/test_ci_contract.py'}
CORPUS = 'config/pon/pq-cross-branch-corpus-v1.json'
BUDGET = 'config/pon/pq128-lifetime-budget-v1.json'
LOCK = 'config/pon/pq128-source-lock-v1.json'
ROOT_REGISTER = 'config/pon/pq-root-dependency-register-v3.json'
PLAN = 'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
INVENTORY = 'trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs'
ALLOWED = CI_PATHS | {TEST, CORPUS, BUDGET, LOCK, PLAN, INVENTORY}
NOTE = '''**PQ retained-control synchronization and CI harness alignment, 2026-11-12 — HOLD:**

The first joint source `921acc94fa7af15cb1728ab2718c62f48ad93c89`
completed its observations with three failed commands retained: each complete
DA library lane passed 733 methods and failed the existing 65/128-chunk capacity
control at its original ten-second absolute deadline; the checkpoint package
exposed a copied-lease test scheduling race. All fifteen new TCV3 methods ran
successfully in both lanes, and the 63 exact PQ controls and strict Clippy
passed. Those successes do not replace the retained full-library failures.

The copied-lease test assumed an idle first owner while the second owner's
live-listener probe wakes it. The existing production guard correctly rejects
the replaced lease inode. Synchronize the test with a confirmed POSIX stop,
retain its live listener and original lock, restore the original lease before
resuming the positive case, and require actual service afterward. Add a separate
negative case that resumes before restoration and requires actual fencing with
unchanged journal bytes. Keep production guards, the original three selectors,
Cargo graphs and protocol formats unchanged; require the new fourth selector
in the hosted checkpoint step and its failure-propagation controls.

The first local harness omitted the repository CI's existing
`RUST_TEST_THREADS=1`. Subsequent observations use that setting and explicit
single-threaded DA/checkpoint invocation while retaining the original deadlines
and workloads. This is a new observation on its own committed source, not a
rewrite of the prior results or proof that every parallel failure was caused
by scheduling. Preserve both complete observation sets.

Re-anchor the same twenty-one declared implementation objects to this source
checkpoint. Their byte identities and all eight unknown/null probability terms
remain unchanged, as do the Root register's frozen scope and unproved bounds.
Ordinary callers, public WAN qualification, historical migration, independent
custody, W1/DAA hardness, FinalUse and production gates remain unqualified.

'''


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw,
                        usedforsecurity=False).hexdigest()


def put(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    assert args.output.is_absolute() and not out.is_relative_to(ROOT)
    out.mkdir(exist_ok=False)
    (out / 'executed-followup.py').write_bytes(Path(__file__).read_bytes())
    os.chdir(ROOT)
    os.environ['PATH'] = '/home/qian-qi/.cargo/bin:' + os.environ['PATH']
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    os.environ['GIT_NO_LAZY_FETCH'] = '1'
    os.environ['GIT_NO_REPLACE_OBJECTS'] = '1'
    sys.dont_write_bytecode = True
    records = []

    def run(label, argv, timeout=600):
        start = time.monotonic_ns()
        p = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, timeout=timeout)
        (out / (label + '.stdout')).write_bytes(p.stdout)
        (out / (label + '.stderr')).write_bytes(p.stderr)
        row = {'label': label, 'argv': argv, 'returncode': p.returncode,
               'elapsed_ns': time.monotonic_ns() - start}
        records.append(row)
        put(out / 'commands.json', records)
        print(json.dumps(row), flush=True)
        p.check_returncode()
        return p.stdout.decode().strip()

    def git(*argv):
        return subprocess.check_output(['git', *argv], cwd=ROOT, text=True).strip()

    def object_bytes(revision, name):
        return subprocess.check_output(['git', 'cat-file', 'blob', revision + ':' + name], cwd=ROOT)

    def changed():
        names = set(git('diff', '--name-only', C1).splitlines())
        names.update(git('ls-files', '--others', '--exclude-standard').splitlines())
        assert names <= ALLOWED, sorted(names - ALLOWED)
        return names

    def refresh_corpus(label):
        names = changed() - {CORPUS}
        old = json.loads((ROOT / CORPUS).read_bytes())
        value = copy.deepcopy(old)
        for name, expected in old['pinned_blobs'].items():
            actual = blob((ROOT / name).read_bytes())
            assert actual == expected or name in names, ('unrelated stale pin', name)
        rows = []
        for name in sorted(names):
            raw = (ROOT / name).read_bytes()
            assert len(raw) <= 4_194_304
            rows.append({'path': name, 'before': value['pinned_blobs'].get(name),
                         'after': blob(raw), 'sha256': sha(raw), 'bytes': len(raw)})
            value['pinned_blobs'][name] = blob(raw)
            if name not in value['required_paths']:
                value['required_paths'].append(name)
        assert all(value[k] == old[k] for k in old if k not in ('pinned_blobs', 'required_paths'))
        assert set(old['required_paths']) <= set(value['required_paths'])
        put(ROOT / CORPUS, value)
        put(out / (label + '.json'), rows)

    run('preflight-before-inspection', ['bash', 'scripts/project-preflight.sh'])
    assert git('rev-parse', 'HEAD') == C1 and not git('status', '--porcelain')
    prior = json.loads((PRIOR / 'validation.json').read_bytes())
    assert prior['source'] == C1 and prior['completed'] is True
    assert prior['all_requested_component_checks_passed'] is False
    assert prior['failures'] == ['da-default-lib', 'da-all-features-lib', 'checkpoint-tests']
    assert len(prior['commands']) == 90 and 'error' not in prior
    assert prior['source_before'] == prior['source_after']
    assert prior['provider_before'] == prior['provider_after']
    assert prior['provider_after']['all_five_match'] is True
    for name, pin in prior['artifact_files'].items():
        raw = (PRIOR / name).read_bytes()
        assert {'bytes': len(raw), 'sha256': sha(raw)} == pin, name
    sys.path.insert(0, str(ROOT / 'scripts/ci'))
    from verify_ci_source import verify
    assert verify('head', C1, None, None, ROOT) == prior['source_after']
    put(out / 'retained-prior-observation.json', {
        'source': C1, 'directory': str(PRIOR), 'validation_sha256': sha((PRIOR / 'validation.json').read_bytes()),
        'completed': True, 'failures': prior['failures'], 'all_requested_component_checks_passed': False,
        'raw_artifacts_unchanged': True, 'new_native_execution_claimed': False})
    test_raw, ci_raw = PACKET.read_bytes(), CI_PACKET.read_bytes()
    assert sha(test_raw) == '1711e1c999922d92336fb56f3237b92b7b14d773b4faaa93b09e56a400bee4ef'
    assert sha(ci_raw) == '5dc034c2d4f910fc613eddad092c69e9f60f209dc52657d9b1740601f36a1908'
    test, ci = json.loads(test_raw), json.loads(ci_raw)
    assert len(test['files']) == 1 and test['files'][0]['path'] == TEST
    assert {row['path'] for row in ci['files']} == CI_PATHS
    for row in test['files'] + ci['files']:
        raw = (ROOT / row['path']).read_bytes()
        assert sha(raw) == row['before_sha256'], row['path']
        assert raw == object_bytes(C1, row['path'])
    row = test['files'][0]
    replacement = base64.b64decode(row['content_base64'], validate=True)
    assert sha(replacement) == row['after_sha256']
    assert blob((ROOT / TEST).read_bytes()) == row['base_git_blob']
    patch = out / 'reviewed-ci.patch'
    patch.write_text(ci['patch'])
    assert sha(patch.read_bytes()) == ci['patch_sha256']
    run('ci-patch-check', ['git', 'apply', '--check', str(patch)])
    run('preflight-before-edit', ['bash', 'scripts/project-preflight.sh'])
    (ROOT / TEST).write_bytes(replacement)
    run('ci-patch-apply', ['git', 'apply', str(patch)])
    for row in ci['files']:
        assert sha((ROOT / row['path']).read_bytes()) == row['after_sha256']
    run('format-checkpoint-tests', ['rustfmt', '+1.95.0', '--edition', '2021', TEST])
    run('refresh-native-inventory', ['python3', '-B', 'scripts/refresh_distributed_source_inventory.py'])
    plan = ROOT / PLAN
    assert not plan.read_text().startswith(NOTE.splitlines()[0])
    plan.write_text(NOTE + plan.read_text())
    refresh_corpus('reviewed-followup-pins')
    run('workspace-fmt', ['cargo', '+1.95.0', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check'])
    run('preflight-runtime-commit', ['bash', 'scripts/project-preflight.sh'])
    run('stage-runtime', ['git', 'add', '--'] + sorted(changed()))
    run('runtime-whitespace', ['git', 'diff', '--cached', '--check'])
    run('runtime-commit', ['git', 'commit', '-s', '-m', 'test(pq): synchronize copied-lease owner controls without weakening fencing'])
    r = git('rev-parse', 'HEAD')
    put(out / 'runtime.json', {'source': r, 'base': BASE, 'ingress_source': INGRESS})
    old_budget, old_lock = json.loads((ROOT / BUDGET).read_bytes()), json.loads((ROOT / LOCK).read_bytes())
    budget, lock = copy.deepcopy(old_budget), copy.deepcopy(old_lock)
    assert len(lock['files']) == 21
    bindings = []
    for name, expected in lock['files'].items():
        raw = object_bytes(r, name)
        assert raw == (ROOT / name).read_bytes() and sha(raw) == expected
        bindings.append({'path': name, 'sha256': expected, 'implementation_bytes_unchanged': True})
    assert object_bytes(r, ROOT_REGISTER) == object_bytes(C1, ROOT_REGISTER)
    run('preflight-source-register', ['bash', 'scripts/project-preflight.sh'])
    budget['experiment']['source_revision'] = lock['source_revision'] = r
    assert all(term['status'] == 'unknown' and term['bound'] is None for term in budget['terms'])
    assert len(budget['events']) == len(budget['terms']) == 8
    put(ROOT / BUDGET, budget)
    put(ROOT / LOCK, lock)
    put(out / 'lifetime-reviewed-source.json', bindings)
    refresh_corpus('reviewed-final-pins')
    run('stage-source-register', ['git', 'add', '--', BUDGET, LOCK, CORPUS])
    run('metadata-whitespace', ['git', 'diff', '--cached', '--check'])
    run('preflight-source-commit', ['bash', 'scripts/project-preflight.sh'])
    run('source-register-commit', ['git', 'commit', '-s', '-m', 'security(pq): rebind unchanged components to synchronized control source'])
    c = git('rev-parse', 'HEAD')
    assert set(git('diff', '--name-only', r, c).splitlines()) == {BUDGET, LOCK, CORPUS}
    assert not git('status', '--porcelain')
    for row in bindings:
        assert sha(object_bytes(c, row['path'])) == row['sha256']
    put(out / 'candidate.json', {'source': c, 'runtime_revision': r, 'base': BASE,
        'ingress_source': INGRESS, 'native_tests_executed_on_candidate': False,
        'whole_chain_pq_qualified': False, 'production_activation': False})
    print(json.dumps({'candidate_ready': c, 'runtime_revision': r,
                      'prior_source': C1, 'native_tests_executed': False}), flush=True)


if __name__ == '__main__':
    main()
