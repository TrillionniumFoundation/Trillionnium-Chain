from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,subprocess,time,resource,hashlib,sys,traceback,threading
root=Path('/home/qian-qi/work/chain-native-operation-readback-f0-20261119-2e9b');out=root/'automatic-ci-at-f0-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
repo='TrillionniumFoundation/Trillionnium-Chain';head='3db79eb2682ba3bcbbf33557c5eee3b67731028f';res={'schema':'chain-complete-exact-head-automatic-ci-v1','head':head,'requests':[],'runs':[],'all_final':False,'business_qualification':False,'full_physical_cost_closed':False}
started=time.monotonic();cpu_before=resource.getrusage(resource.RUSAGE_CHILDREN);lock=threading.Lock()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save():
 with lock:(out/'SNAPSHOT.json').write_text(json.dumps(res,indent=2)+'\n')
def api(name,endpoint):
 dest=out/(name+'.stdout');err=out/(name+'.stderr');begin=time.monotonic();utc=datetime.now(timezone.utc).isoformat()
 with dest.open('xb') as so,err.open('xb') as se:p=subprocess.Popen(['/usr/bin/gh','api',endpoint],stdout=so,stderr=se);rc=p.wait()
 row={'name':name,'endpoint':endpoint,'started_utc':utc,'exit_code':rc,'wall_seconds':time.monotonic()-begin,'stdout_bytes':dest.stat().st_size,'stdout_sha256':sha(dest.read_bytes()),'stderr_bytes':err.stat().st_size,'stderr_sha256':sha(err.read_bytes()),'per_request_child_cpu_seconds':None,'cpu_note':'parallel read requests; aggregate child CPU recorded at end only'}
 with lock:res['requests'].append(row)
 save();return rc,dest
def pages(name,endpoint,key):
 combined=[];total=None
 for page in range(1,101):
  rc,path=api(name+'-page-'+str(page),endpoint+('&' if '?' in endpoint else '?')+'per_page=100&page='+str(page))
  if rc: return {'api_error':True,'complete':False,'items':combined,'last_exit_code':rc}
  obj=json.loads(path.read_text());current=obj[key];total=obj['total_count']
  combined.extend(current)
  if len(combined)>=total:
   assert len(combined)==total
   return {'api_error':False,'complete':True,'items':combined,'total_count':total}
 raise RuntimeError('read pagination bound reached')
def one_run(run):
 rid=run['id'];result={'run':run}
 result['jobs']=pages('run-'+str(rid)+'-jobs','repos/'+repo+'/actions/runs/'+str(rid)+'/jobs?filter=all','jobs')
 result['artifacts']=pages('run-'+str(rid)+'-artifacts','repos/'+repo+'/actions/runs/'+str(rid)+'/artifacts','artifacts')
 rc,p=api('run-'+str(rid)+'-timing','repos/'+repo+'/actions/runs/'+str(rid)+'/timing');result['timing_exit_code']=rc
 if rc==0:result['timing']=json.loads(p.read_text())
 result['failed_job_log_requests']=[]
 for job in result['jobs']['items']:
  if job['conclusion'] in ('failure','cancelled','timed_out','action_required','startup_failure','stale'):
   rc,p=api('job-'+str(job['id'])+'-log','repos/'+repo+'/actions/jobs/'+str(job['id'])+'/logs')
   result['failed_job_log_requests'].append({'job_id':job['id'],'name':job['name'],'conclusion':job['conclusion'],'exit_code':rc,'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
 return result
try:
 seen=set()
 for iteration in range(1):
  roster=pages('roster-'+str(iteration),'repos/'+repo+'/actions/runs?head_sha='+head,'workflow_runs')
  assert roster['complete'] is True
  runs=roster['items'];assert all(r['head_sha']==head for r in runs)
  ids={r['id'] for r in runs};assert len(ids)==len(runs) and seen.issubset(ids);seen|=ids
  pending=[r['id'] for r in runs if r['status']!='completed']
  res['roster']=runs;res['observed_run_ids']=sorted(seen);res['poll_count']=iteration+1;save()
  print(json.dumps({'ci_poll':iteration,'runs':len(runs),'automatic_runs':sum(r['event']!='workflow_dispatch' for r in runs),'pending':pending,'observed_utc':datetime.now(timezone.utc).isoformat()}),flush=True)
  res['snapshot_pending_run_ids']=pending;res['observation_is_timepoint_not_all_jobs_final']=bool(pending);break
 else:res['observation_limit_reached']=True
 with ThreadPoolExecutor(max_workers=4) as executor:
  for future in as_completed([executor.submit(one_run,r) for r in runs]):
   row=future.result();res['runs'].append(row);save()
   print(json.dumps({'ci_run_collected':row['run']['id'],'name':row['run']['name'],'conclusion':row['run']['conclusion'],'job_count':len(row['jobs']['items']),'failed_job_logs':len(row['failed_job_log_requests'])}),flush=True)
 res['runs'].sort(key=lambda x:x['run']['id']);res['all_final']=all(r['status']=='completed' for r in runs)
 res['complete_job_denominators']=all(r['jobs']['complete'] for r in res['runs'])
 res['all_observed_failed_job_logs_retained']=all(x['exit_code']==0 for r in res['runs'] for x in r['failed_job_log_requests'])
 res['api_failures']=[x for x in res['requests'] if x['exit_code']!=0]
 res['ended_utc']=datetime.now(timezone.utc).isoformat();res['total_wall_seconds']=time.monotonic()-started
 a=resource.getrusage(resource.RUSAGE_CHILDREN);res['aggregate_child_user_cpu_seconds']=a.ru_utime-cpu_before.ru_utime;res['aggregate_child_system_cpu_seconds']=a.ru_stime-cpu_before.ru_stime
 save()
 print(json.dumps({'ci_collection_complete':True,'run_count':len(res['runs']),'automatic_runs':sum(r['run']['event']!='workflow_dispatch' for r in res['runs']),'all_final':res['all_final'],'failed_jobs':sum(len(r['failed_job_log_requests']) for r in res['runs']),'api_failures':len(res['api_failures'])}),flush=True)
except BaseException as exc:
 res['error']=repr(exc);save();(out/'error.log').write_text(traceback.format_exc());raise
