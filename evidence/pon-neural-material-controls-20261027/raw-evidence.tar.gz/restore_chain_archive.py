"""Verify a CI git archive against the exact Git tree before isolated checkout."""
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import zlib

here = Path(__file__).resolve().parent
commit = json.loads((here / 'ci-artifacts/chain-commit.json').read_text())
archive = here / 'ci-artifacts/chain-source.tar.gz'
root = here / 'chain-native-c96022'
root.mkdir()
subprocess.run(['git', 'init', '-q', '-b', 'fix/chain-model-closure-20261027'], cwd=root, check=True)
subprocess.run(['git', 'remote', 'add', 'origin', 'https://github.com/TrillionniumFoundation/Trillionnium-Chain.git'], cwd=root, check=True)
objects = root / '.git/objects'


def put(kind, raw, expected=None):
    encoded = kind.encode() + b' ' + str(len(raw)).encode() + b'\0' + raw
    digest = hashlib.sha1(encoded).hexdigest()
    if expected is not None:
        assert digest == expected, (kind, digest, expected)
    target = objects / digest[:2] / digest[2:]
    target.parent.mkdir(exist_ok=True)
    if not target.exists():
        target.write_bytes(zlib.compress(encoded))
    return digest


groups = {'': {}}
files = []
with tarfile.open(archive, 'r:gz') as source:
    assert source.pax_headers.get('comment') == commit['sha']
    for member in source:
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts and '.git' not in path.parts
        assert str(path) == member.name.rstrip('/') and member.size <= 128 * 1024**2
        parent = '' if str(path.parent) == '.' else str(path.parent)
        groups.setdefault(parent, {})
        if member.isdir():
            groups.setdefault(str(path), {})
            groups[parent][path.name] = ('40000', None, str(path))
            continue
        assert member.isfile() or member.issym(), (member.name, member.type)
        assert path.name not in groups[parent]
        if member.issym():
            assert member.name == 'codex-rs/vendor/bubblewrap/LICENSE' and member.linkname == 'COPYING'
            raw = member.linkname.encode()
            mode = '120000'
        else:
            raw = source.extractfile(member).read()
            assert len(raw) == member.size
            mode = '100755' if member.mode & 0o111 else '100644'
        sha = (hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
               if str(path).startswith('evidence/') else put('blob', raw))
        groups[parent][path.name] = (mode, sha, None)
        files.append((str(path), mode, sha))


def tree(directory):
    entries = groups[directory]
    raw = bytearray()
    for name, (mode, sha, child) in sorted(entries.items(), key=lambda x:
            (x[0] + ('/' if x[1][0] == '40000' else '')).encode()):
        if child is not None:
            sha = tree(child)
        raw += mode.encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(sha)
    return put('tree', bytes(raw))


observed_tree = tree('')
assert observed_tree == commit['tree']['sha'], (observed_tree, commit['tree']['sha'])
assert commit['verification']['reason'] == 'unsigned'
assert commit['author'] == commit['committer']
person = commit['author']
stamp = int(datetime.datetime.fromisoformat(person['date'].replace('Z', '+00:00')).timestamp())
identity = f"{person['name']} <{person['email']}> {stamp}"
prefix = f"tree {commit['tree']['sha']}\n" + ''.join(f"parent {p['sha']}\n" for p in commit['parents'])
matched = None
for offset in range(-12 * 60, 14 * 60 + 1):
    zone = ('+' if offset >= 0 else '-') + f'{abs(offset)//60:02}{abs(offset)%60:02}'
    for ending in ('', '\n'):
        raw = (prefix + f'author {identity} {zone}\ncommitter {identity} {zone}\n\n' + commit['message'] + ending).encode()
        encoded = b'commit ' + str(len(raw)).encode() + b'\0' + raw
        if hashlib.sha1(encoded).hexdigest() == commit['sha']:
            matched = raw
            break
    if matched is not None:
        break
assert matched is not None, 'commit reconstruction failed'
put('commit', matched, commit['sha'])
subprocess.run(['git', 'update-ref', 'refs/heads/fix/chain-model-closure-20261027', commit['sha']], cwd=root, check=True)
(root / '.git/shallow').write_text(commit['sha'] + '\n')
subprocess.run(['git', 'read-tree', commit['sha']], cwd=root, check=True)
omitted = [p for p, _, _ in files if p.startswith('evidence/')]
subprocess.run(['git', 'update-index', '--skip-worktree', '--stdin'], cwd=root, input='\n'.join(omitted)+'\n', text=True, check=True)
subprocess.run(['git', 'config', 'core.sparseCheckout', 'true'], cwd=root, check=True)
(root / '.git/info/sparse-checkout').write_text('/*\n!/evidence/\n')
subprocess.run(['git', 'checkout-index', '--all'], cwd=root, check=True)
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True)
assert not status, status
report = dict(archive_sha256=hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest(),
              commit=commit['sha'], tree=observed_tree, exact_blobs=len(files),
              exact_trees=len(groups), checkout=str(root), git_status='clean')
(here / 'evidence/chain-source-restoration.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
