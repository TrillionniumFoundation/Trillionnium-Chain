
import os,json,pathlib,hashlib,subprocess,time,sys
base=pathlib.Path("/home/qian-qi/work/cell-complete-93ddee66e1b3-20261107"); repo=base/'chain-final'; log=base/'concurrent-native-acc2'
log.mkdir(mode=0o700,exist_ok=True)
expected_head='acc2ec24fac7e6fbebb49384fc7efc7c9f8b2030'
expected_tree='e59270db7fe6ea77e01362b591dd98e4e93d62fe'
provider=pathlib.Path('/home/qian-qi/work/chain-throughput-20261105-87309-pq-provider-v3/runner-temp/trnm-pq-provider-3.5.9.UUgi1jCA/install')
env=os.environ.copy()
env.update({'CARGO_TARGET_DIR':str(base/'native-cell-target'),'CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'2','RUST_BACKTRACE':'1',
'OPENSSL_DIR':str(provider),'OPENSSL_STATIC':'1','OPENSSL_CONF':'/dev/null','OPENSSL_MODULES':str(provider/'lib/ossl-modules'),
'TRNM_PQ_OPENSSL':str(provider/'bin/openssl'),'TRNM_PQ_OPENSSL_VERSION':'3.5.9',
'TRNM_PQ_OPENSSL_SHA256':'1b22ceacafda4831aa7a7836a3619a4261394a9e4a09bf64580d43a6f214a562',
'CELL_NATIVE_V1_EVIDENCE_DIR':str(log/'a5-cli')})
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(name,data):
    with (log/name).open('xb') as f:f.write(data)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def fence(label):
    head=git('rev-parse','HEAD').decode().strip(); tree=git('rev-parse','HEAD^{tree}').decode().strip()
    assert head==expected_head and tree==expected_tree,(head,tree)
    scopes=['trillionnium','config/pon','tests/fuzz','formal/pon-nakamoto-v1/vectors']
    entries=[]; missing=[]
    for entry in git('ls-tree','-r','-z','HEAD','--',*scopes).split(b'\0'):
        if not entry:continue
        header,name=entry.split(b'\t',1); mode,kind,object_id=header.decode().split()
        rel=name.decode(); p=repo/rel
        if kind!='blob':raise RuntimeError(('non-blob build scope',rel,kind))
        if not p.exists() and not p.is_symlink():
            missing.append(rel); continue
        raw=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
        blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        assert blob==object_id,('working bytes differ from HEAD',rel,blob,object_id)
        entries.append({'path':rel,'mode':mode,'git_blob':object_id,'bytes':len(raw),'sha256':sha(raw),'symlink':p.is_symlink()})
    assert not any(x.startswith('trillionnium/') or x.startswith('config/pon/') for x in missing),('missing compiled workspace/config',missing)
    a4=json.loads((base/'native-validation/final-source-fence.json').read_bytes())
    for rel,value in a4['source_sha256'].items():assert sha((repo/rel).read_bytes())==value,rel
    assert sha((repo/'trillionnium/Cargo.lock').read_bytes())==a4['cargo_lock_sha256']
    status=git('status','--porcelain=v1','--untracked-files=all').decode()
    sparse=subprocess.run(['git','sparse-checkout','list'],cwd=repo,capture_output=True,text=True)
    record={'head':head,'tree':tree,'scope_prefixes':scopes,'materialized_tracked_files':entries,'missing_due_to_sparse_checkout':missing,
      'materialized_scope_payload_bytes':sum(v['bytes'] for v in entries),
      'status_porcelain':status,'sparse_checkout_list':sparse.stdout.splitlines(),'sparse_checkout_list_returncode':sparse.returncode,
      'a4_native_ten_files_and_cargo_lock_unchanged':True,'cargo_lock_sha256':a4['cargo_lock_sha256'],
      'entire_repository_materialization_claimed':False,
      'source_set_sha256':sha(json.dumps(entries,sort_keys=True,separators=(',',':')).encode())}
    save(label+'.json',(json.dumps(record,sort_keys=True,indent=2)+'\n').encode())
    print(json.dumps({'step':label,'head':head,'files':len(entries),'missing_sparse':len(missing),'source_set_sha256':record['source_set_sha256'],'status_clean':status==''}),flush=True)
    return record
def run(name,args,cwd):
    t=time.monotonic()
    with (log/(name+'.stdout')).open('xb') as out,(log/(name+'.stderr')).open('xb') as err:
        p=subprocess.run(args,cwd=cwd,env=env,stdout=out,stderr=err)
    result={'args':args,'cwd':str(cwd),'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-t}
    save(name+'.json',(json.dumps(result,sort_keys=True,indent=2)+'\n').encode())
    print(json.dumps({'step':name,**result}),flush=True)
    if p.returncode:sys.exit(p.returncode)
before=fence('source-before')
assert before['status_porcelain']=='','worktree was not clean before verification'
run('preflight',['bash','scripts/project-preflight.sh'],repo)
selected={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','RUST_BACKTRACE','OPENSSL_DIR','OPENSSL_STATIC','OPENSSL_CONF','OPENSSL_MODULES','TRNM_PQ_OPENSSL','TRNM_PQ_OPENSSL_VERSION','TRNM_PQ_OPENSSL_SHA256','CELL_NATIVE_V1_EVIDENCE_DIR']}
for key in ['RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_PROFILE_TEST_DEBUG','CARGO_PROFILE_DEV_DEBUG','RUSTC_WRAPPER']:
    if key in env:selected[key]=env[key]
provider_files={p:sha((provider/p).read_bytes()) for p in ['bin/openssl','lib/libcrypto.a','lib/libssl.a','include/openssl/opensslv.h','include/openssl/configuration.h']}
prior_provider=json.loads((base/'native-validation/provider-artifacts.json').read_bytes())['artifacts_sha256']
assert provider_files==prior_provider
save('build-environment.json',(json.dumps({'selected_environment':selected,'provider_artifacts_sha256':provider_files,'provider_matches_a4':True},sort_keys=True,indent=2)+'\n').encode())
cargo='/home/qian-qi/.cargo/bin/cargo'
run('rustc',['/home/qian-qi/.cargo/bin/rustc','+1.95.0','--version','--verbose'],repo)
run('cargo',[cargo,'+1.95.0','--version','--verbose'],repo)
run('provider',[str(provider/'bin/openssl'),'version','-a'],repo)
run('cell-tests',[cargo,'+1.95.0','test','--locked','--offline','-p','trnm-pon-node','--test','cell_native_v1','--','--nocapture'],repo/'trillionnium')
run('clippy',[cargo,'+1.95.0','clippy','--locked','--offline','-p','trnm-pon-node','--lib','--bin','trnm-pon-node','--test','cell_native_v1','--all-features','--','-D','warnings'],repo/'trillionnium')
run('fmt',[cargo,'+1.95.0','fmt','--all','--','--check'],repo/'trillionnium')
run('metadata',[cargo,'+1.95.0','metadata','--offline','--locked','--manifest-path','trillionnium/Cargo.toml','--format-version','1'],repo)
after=fence('source-after-gates')
assert before['source_set_sha256']==after['source_set_sha256']
save('binary-after-gates.json',(json.dumps({'path':str(base/'native-cell-target/debug/trnm-pon-node'),'sha256':sha((base/'native-cell-target/debug/trnm-pon-node').read_bytes()),'head':expected_head,'source_set_sha256':after['source_set_sha256']},sort_keys=True,indent=2)+'\n').encode())
print(json.dumps({'status':'concurrent_native_gates_pass','tests':12,'new_consensus_activation':False}),flush=True)
