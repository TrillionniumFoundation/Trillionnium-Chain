#!/usr/bin/env python3
"""Seal current and prior PQ component logs in an evidence-only child; never push.

Run only after the reviewed validator has completed on the supplied committed C.
This script records past source/provider observations, not live executable
attestation, independent custody, historical migration, or whole-chain safety.
All post-commit receipts go to the separate --output directory.
"""
from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile
import tempfile
import time

BASE = '8970e2c81abbf48e2a4d3f0802d79624ab20fadd'
BASE_TREE = 'fbd1a451b911d218bbb48548892fc8cd53eaf66b'
INGRESS = Path('/home/qian-qi/work/pq-boundary-ingress-20261112-4150')
DEPENDENCY_FETCH = Path('/home/qian-qi/work/pq-boundary-dependency-fetch-20261112-4150')
HISTORICAL = Path('/home/qian-qi/work/pq-boundary-inherited-campaign-4150.tar.gz')
HISTORICAL_SHA256 = '4c2dd851828e0fedaf4f7196f5e212a21545942208ec243b1a8d0b2e41c34bd6'
VALIDATOR_SHA256 = '32c62906c12f636f91ba00f2d192da8a7aacd8010a4af21e113eb0a02f94d9b9'
PRIOR_VALIDATOR_SHA256 = 'ee6019a69aa1e54bda384690906035c83d47606aed3c12dde84e0f051bd74453'
CI_V2_VALIDATOR_SHA256 = 'c452e455a1a9e18a3867fdff4a10fa6cf7877aa510f5a46012ab28ecd7b0ff5f'
CI_V4_VALIDATOR_SHA256 = '4b0a3e514509d51984a022a5841b0dd3bc4386c345ef9847d61a16840866c7d0'
PRIOR_VALIDATOR_ALLOWLIST = frozenset((PRIOR_VALIDATOR_SHA256, CI_V2_VALIDATOR_SHA256,
                                     CI_V4_VALIDATOR_SHA256))
REQUIRED_PRIOR_SOURCE = '921acc94fa7af15cb1728ab2718c62f48ad93c89'
REQUIRED_INTERRUPTED_SOURCE = '13bdc38023d57607a9ba81f52e123f7fb556bec3'
REQUIRED_INTERRUPTED_VALIDATION_SHA256 = '42efd7039031ada68472ed2907a01b1714482d65edd8b2f921ee35f3ae64003c'
REQUIRED_C3_SOURCE = 'f0fa8c3c0372d0c5dafccd2683b31fda322e42f2'
REQUIRED_C3_RUNTIME = '01d765e3c2636779ddc0982dff7e6e13f8a2e197'
# Frozen from the completed C3 original receipt and raw logs after independent
# verification of all 190 artifacts, source/provider records and native outcomes.
REQUIRED_C3_VALIDATION_BYTES = 123716
REQUIRED_C3_VALIDATION_SHA256 = '5377cd204a07538e86afdc8ecc2154d925a24cd79d2a426920930b68b961e65e'
REQUIRED_C3_FAILURES = ('da-default-lib', 'da-all-features-lib')
REQUIRED_C3_DA_SUMMARIES = {
    'da-default-lib': [
        {'result': 'FAILED', 'passed': 741, 'failed': 1, 'ignored': 0,
         'measured': 0, 'filtered_out': 0},
    ],
    'da-all-features-lib': [
        {'result': 'FAILED', 'passed': 739, 'failed': 3, 'ignored': 0,
         'measured': 0, 'filtered_out': 0},
    ],
}
REQUIRED_PRIOR_SOURCES = frozenset((REQUIRED_PRIOR_SOURCE, REQUIRED_INTERRUPTED_SOURCE,
                                   REQUIRED_C3_SOURCE))
REQUIRED_PRIOR_FAILURES = ('da-default-lib', 'da-all-features-lib', 'checkpoint-tests')
REQUIRED_INTERRUPTED_FAILURES = ('da-default-lib', 'da-all-features-lib', 'pq-native-41')
RETAINED_CACHE_TESTS = (
    'cell::version_retention::tests::shard_plan::capacity::retained_shard_plan_initial_128_profile_accepts_complete_65_and_128_chunk_catalogs',
    'cell::erasure::provider::tests::provider_six_shard_cache_batch_rejects_late_bad_pins_and_wires_before_any_write',
) + tuple('cell::store::wal_tests::' + name for name in (
    'paired_manifest_chunk_batch_rejects_invalid_late_member_without_prefix',
    'paired_manifest_chunk_batch_obeys_member_and_byte_bounds',
    'paired_manifest_chunk_batch_rolls_back_late_quota_failure',
    'paired_manifest_chunk_batch_preserves_original_deadline_atomicity',
    'paired_manifest_chunk_batch_reader_refusal_and_cold_reopen',
)) + (
    'cell::retention::tests::retention_population_preserves_original_deadline_during_cache_writer_contention',
    'cell::retention::tests::retained_origin_bytes_rehydrate_existing_peer_protocol_after_cache_loss',
    'cell::store::wal_tests::held_reader_refuses_entire_eight_chunk_batch_then_original_retry_survives_cold_reopen',
)
PEER_LIFECYCLE_TESTS = tuple('cell::bep52_peer::tests::' + name for name in (
    'tcp_slow_fragmented_handshake_does_not_renew_original_deadline',
    'tcp_slow_fragmented_fetch_peer_preserves_original_deadline',
    'tcp_peer_without_connection_has_bounded_cleanup',
)) + (
    'cell::discovery::sequence_tests::tcp_newer_same_endpoint_short_ttl_expires_mid_manifest_without_publication',
)
CHECKPOINT_SOCKET_TESTS = (
    'rejected_nonprivate_socket_parent_does_not_unlink_existing_listener',
    'different_admitted_journal_cannot_replace_a_live_checkpoint_endpoint',
    'copied_lease_record_cannot_replace_a_live_checkpoint_endpoint',
    'copied_lease_probe_fences_owner_before_lease_restoration',
)
PROVIDER_HELPER_SHA256 = '363fa66725ddedf2a6fa1e34b785b31c2e8ddeaa767f058766b2037c0f4ea492'
SOURCE_READER_SHA256 = '0ddfd07719eae98913348c82b06d3e4522d721c353d9b01d6deac0dfda619946'
EVIDENCE = 'evidence/pon-pq-boundary-closure-20261112'
CORPUS = 'config/pon/pq-cross-branch-corpus-v1.json'
BUDGET = 'config/pon/pq128-lifetime-budget-v1.json'
SOURCE_LOCK = 'config/pon/pq128-source-lock-v1.json'
ROOT_REGISTER = 'config/pon/pq-root-dependency-register-v3.json'
MAX_FILE_BYTES = 4_194_304
GRAPH_PATHS = ('trillionnium/Cargo.toml', 'trillionnium/Cargo.lock',
               'tests/fuzz/Cargo.toml', 'tests/fuzz/Cargo.lock', 'rust-toolchain.toml')
TCV3_TESTS = tuple('cell::version_content_closure_v3::tests::' + name for name in (
    'tcv3_cold_cache_reads_full_model_environment_and_explicit_ancestor',
    'tcv3_missing_parent_is_not_an_origin_or_legacy_digest_wrapper',
    'tcv3_checks_independent_full_pin_and_exact_selected_roots_before_scanning',
    'tcv3_rejects_duplicate_legacy_alias_even_when_strong_claims_differ',
    'tcv3_alternate_ancestor_content_changes_root_and_cannot_pass_actual_scan',
    'tcv3_unreachable_extra_origin_and_non_decreasing_parent_generation_refuse',
    'tcv3_foreign_family_cannot_be_imported_as_an_ancestor',
    'tcv3_shared_transitive_ancestor_is_scanned_once_per_declared_version',
    'tcv3_graph_rejects_cycle_and_overdeep_paths_including_shared_subgraphs',
    'tcv3_member_scans_share_the_original_finite_session',
    'tcv3_failed_late_member_keeps_both_reservations_and_no_partial_readback',
    'tcv3_requires_exact_retained_owner_set_epoch_and_window_before_reads',
    'tcv3_missing_actual_cache_bytes_refuse_despite_complete_pinned_metadata',
    'tcv3_namespace_canonical_order_counts_and_all_byte_boundaries_are_strict',
    'tcv3_commitment_matches_independent_python_vector_without_tcv2_domain_alias',
))
# These independently frozen C3 tuples must not follow a future current-roster
# edit. The historical V4 validator is bound to its own committed source above.
C3_RETAINED_CACHE_TESTS = (
    'cell::version_retention::tests::shard_plan::capacity::retained_shard_plan_initial_128_profile_accepts_complete_65_and_128_chunk_catalogs',
    'cell::erasure::provider::tests::provider_six_shard_cache_batch_rejects_late_bad_pins_and_wires_before_any_write',
) + tuple('cell::store::wal_tests::' + name for name in (
    'paired_manifest_chunk_batch_rejects_invalid_late_member_without_prefix',
    'paired_manifest_chunk_batch_obeys_member_and_byte_bounds',
    'paired_manifest_chunk_batch_rolls_back_late_quota_failure',
    'paired_manifest_chunk_batch_preserves_original_deadline_atomicity',
    'paired_manifest_chunk_batch_reader_refusal_and_cold_reopen',
))
C3_PEER_LIFECYCLE_TESTS = tuple('cell::bep52_peer::tests::' + name for name in (
    'tcp_slow_fragmented_handshake_does_not_renew_original_deadline',
    'tcp_slow_fragmented_fetch_peer_preserves_original_deadline',
    'tcp_peer_without_connection_has_bounded_cleanup',
))
C3_CHECKPOINT_SOCKET_TESTS = (
    'rejected_nonprivate_socket_parent_does_not_unlink_existing_listener',
    'different_admitted_journal_cannot_replace_a_live_checkpoint_endpoint',
    'copied_lease_record_cannot_replace_a_live_checkpoint_endpoint',
    'copied_lease_probe_fences_owner_before_lease_restoration',
)
C3_TCV3_TESTS = tuple('cell::version_content_closure_v3::tests::' + name for name in (
    'tcv3_cold_cache_reads_full_model_environment_and_explicit_ancestor',
    'tcv3_missing_parent_is_not_an_origin_or_legacy_digest_wrapper',
    'tcv3_checks_independent_full_pin_and_exact_selected_roots_before_scanning',
    'tcv3_rejects_duplicate_legacy_alias_even_when_strong_claims_differ',
    'tcv3_alternate_ancestor_content_changes_root_and_cannot_pass_actual_scan',
    'tcv3_unreachable_extra_origin_and_non_decreasing_parent_generation_refuse',
    'tcv3_foreign_family_cannot_be_imported_as_an_ancestor',
    'tcv3_shared_transitive_ancestor_is_scanned_once_per_declared_version',
    'tcv3_graph_rejects_cycle_and_overdeep_paths_including_shared_subgraphs',
    'tcv3_member_scans_share_the_original_finite_session',
    'tcv3_failed_late_member_keeps_both_reservations_and_no_partial_readback',
    'tcv3_requires_exact_retained_owner_set_epoch_and_window_before_reads',
    'tcv3_missing_actual_cache_bytes_refuse_despite_complete_pinned_metadata',
    'tcv3_namespace_canonical_order_counts_and_all_byte_boundaries_are_strict',
    'tcv3_commitment_matches_independent_python_vector_without_tcv2_domain_alias',
))
EXPECTED_LABELS = (
    'preflight', 'rust-version', 'cargo-version', 'graphs-unchanged',
    'graph-default', 'graph-all-features', 'graph-fuzz', 'formatting',
    'source-negatives', 'lifetime-controls', 'root-register-controls',
    'ci-contract-controls', 'corpus-controls', 'claim-controls', 'ci-contract',
    'corpus-current', 'lifetime-current', 'root-register-current', 'claim-current',
    'native-inventory', 'repository-links', 'whitespace', 'preflight-native',
    'da-default-lib', 'da-all-features-lib', 'checkpoint-tests',
) + tuple(f'pq-native-{index:02d}' for index in range(63)) + ('strict-clippy',)
SUMMARY = re.compile(
    r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; '
    r'(\d+) measured; (\d+) filtered out; finished in [0-9]+(?:\.[0-9]+)?s$', re.M)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def require_c3_profile_frozen():
    require(type(REQUIRED_C3_VALIDATION_BYTES) is int and REQUIRED_C3_VALIDATION_BYTES > 0
            and isinstance(REQUIRED_C3_VALIDATION_SHA256, str)
            and re.fullmatch('[0-9a-f]{64}', REQUIRED_C3_VALIDATION_SHA256) is not None,
            'C3 completed validation byte length and SHA-256 have not been frozen')
    require(type(REQUIRED_C3_FAILURES) is tuple and bool(REQUIRED_C3_FAILURES)
            and len(set(REQUIRED_C3_FAILURES)) == len(REQUIRED_C3_FAILURES)
            and tuple(label for label in EXPECTED_LABELS if label in REQUIRED_C3_FAILURES)
            == REQUIRED_C3_FAILURES,
            'C3 completed exact failure-label roster has not been frozen')
    require(type(REQUIRED_C3_DA_SUMMARIES) is dict
            and set(REQUIRED_C3_DA_SUMMARIES) == {'da-default-lib', 'da-all-features-lib'}
            and all(type(rows) is list for rows in REQUIRED_C3_DA_SUMMARIES.values()),
            'C3 completed DA summaries have not been frozen')
    for rows in REQUIRED_C3_DA_SUMMARIES.values():
        for row in rows:
            require(type(row) is dict
                    and set(row) == {'result', 'passed', 'failed', 'ignored', 'measured', 'filtered_out'}
                    and row['result'] in ('ok', 'FAILED')
                    and all(type(row[key]) is int and row[key] >= 0
                            for key in ('passed', 'failed', 'ignored', 'measured', 'filtered_out')),
                    'C3 frozen DA summary is malformed')


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


def decode_json(raw):
    return json.loads(raw, object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def put(path, value):
    with path.open('xb') as stream:
        stream.write(json_bytes(value))


def fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink,
            info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def canonical_relative(value):
    require(isinstance(value, str) and '\\' not in value and '\x00' not in value,
            'invalid relative path')
    path = PurePosixPath(value)
    require(value and not path.is_absolute() and str(path) == value
            and all(part not in ('', '.', '..') for part in path.parts),
            'noncanonical relative path: ' + value)
    return value


def canonical_absolute(path, exists=True):
    require(path.is_absolute() and path == path.resolve(strict=exists),
            'absolute path must not traverse symlinks or aliases: ' + str(path))
    return path


def open_regular(path):
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1,
            'expected a single-link regular original: ' + str(path))
    stream = os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK), 'rb')
    if fingerprint(os.fstat(stream.fileno())) != fingerprint(before):
        stream.close()
        raise RuntimeError('original changed while opening: ' + str(path))
    return stream, before


def read_original(path):
    stream, before = open_regular(path)
    with stream:
        raw = stream.read()
        require(fingerprint(os.fstat(stream.fileno())) == fingerprint(before)
                and fingerprint(path.lstat()) == fingerprint(before),
                'original changed while reading: ' + str(path))
    require(len(raw) == before.st_size, 'original length changed: ' + str(path))
    return raw


def load(path):
    return decode_json(read_original(path))


def sha_bytes(raw):
    return hashlib.sha256(raw).hexdigest()


def hash_original(path):
    stream, before = open_regular(path)
    with stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        require(fingerprint(os.fstat(stream.fileno())) == fingerprint(before)
                and fingerprint(path.lstat()) == fingerprint(before),
                'original changed while hashing: ' + str(path))
    return {'bytes': before.st_size, 'sha256': digest}


def git_blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw,
                        usedforsecurity=False).hexdigest()


def inventory(directories, extra_files):
    rows = {}
    for label, directory in sorted(directories.items()):
        canonical_relative(label)
        canonical_absolute(directory)
        require(directory.is_dir(), 'missing input directory: ' + str(directory))
        count = 0
        for current, subdirs, filenames in os.walk(directory, followlinks=False):
            subdirs.sort()
            filenames.sort()
            for name in subdirs:
                require(not (Path(current) / name).is_symlink(), 'symlink input directory')
            for name in filenames:
                path = Path(current) / name
                relative = canonical_relative(path.relative_to(directory).as_posix())
                member = label + '/' + relative
                require(member not in rows, 'duplicate archive name: ' + member)
                rows[member] = {'original_path': str(path), **hash_original(path)}
                count += 1
        require(count > 0, 'empty evidence input: ' + str(directory))
    for member, path in sorted(extra_files.items()):
        canonical_relative(member)
        canonical_absolute(path)
        require(member not in rows, 'duplicate archive name: ' + member)
        rows[member] = {'original_path': str(path), **hash_original(path)}
    return dict(sorted(rows.items()))


def checked_source_receipt(value, expected):
    require(value.get('schema') == 'trnm-ci-source-v1'
            and value.get('kind') == 'head'
            and value.get('candidate') == value.get('tested_commit') == expected
            and value.get('base') is None and value.get('prospective_merge') is None
            and value.get('tracked_worktree_verified') is True
            and value.get('tests_executed_by_identity_check') is False
            and type(value.get('tracked_entries')) is int and value['tracked_entries'] > 0
            and type(value.get('tracked_bytes')) is int and value['tracked_bytes'] > 0
            and re.fullmatch('[0-9a-f]{40}', value.get('tested_tree', '')) is not None,
            'invalid full tracked-source receipt for ' + expected)


def native_summaries(text):
    return [{'result': row[0], **dict(zip(
        ('passed', 'failed', 'ignored', 'measured', 'filtered_out'), map(int, row[1:])))}
        for row in SUMMARY.findall(text)]


def inspect_historical(path):
    require(hash_original(path) == {'bytes': 5719, 'sha256': HISTORICAL_SHA256},
            'historical compact archive is absent or differs from its reviewed bytes')
    members = {}
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive:
            canonical_relative(member.name)
            require(member.isfile() and member.name not in members
                    and member.size <= MAX_FILE_BYTES, 'unexpected historical archive member')
            stream = archive.extractfile(member)
            require(stream is not None, 'historical member is unreadable')
            raw = stream.read()
            require(len(raw) == member.size, 'historical member was truncated')
            members[member.name] = {'bytes': member.size, 'sha256': sha_bytes(raw), 'raw': raw}
    prefix = 'pq-budget-campaign-43161361291-compact/'
    require(len(members) == 12, 'historical compact member roster changed')
    def document(name):
        return decode_json(members[prefix + name]['raw'])
    provenance = document('artifact-provenance.json')
    summary = document('summary.json')
    require(provenance['artifact_id'] == 13922513442
            and provenance['original_archive_bytes'] == 70260101
            and provenance['original_archive_sha256'] ==
            'c5aed8edbdfee0f34303895b552d6348d344b43ffe6e7672615e0726938f5d8f'
            and provenance['original_archive_included_in_compact_package'] is False,
            'historical artifact provenance changed')
    for row in provenance['retained_original_members']:
        actual = members[prefix + canonical_relative(row['path'])]
        require(actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'],
                'historical retained member differs: ' + row['path'])
    before = document('source-before.json')
    checked_source_receipt(before, BASE)
    require(before['tested_tree'] == BASE_TREE, 'historical source tree changed')
    for name in ('source-after.json', 'run-1-source-after.json',
                 'run-2-source-after.json', 'run-3-source-after.json'):
        require(document(name) == before, 'historical source observations disagree')
    require(summary['complete_success'] is False
            and summary['new_candidate_campaign_pass_claimed'] is False
            and summary['candidate_campaign_executed_by_this_review'] is False
            and len(summary['attempts']) == 3
            and all(row['exit_code'] == 101 and row['original_criteria_met'] is False
                    for row in summary['attempts']), 'historical failures were promoted')
    return {'classification': 'inherited-historical-failure-not-retested-on-C',
            'source': before, 'original_artifact': provenance,
            'compact_archive': hash_original(path),
            'compact_members': {name: {k: v for k, v in row.items() if k != 'raw'}
                                for name, row in members.items()},
            'retained_original_stderr_files': 3, 'failed_attempt_exit_codes': [101, 101, 101],
            'original_large_zip_and_three_raw_reports_included': False,
            'new_candidate_campaign_executed': False}


def inspect_ingress(root, git):
    baseline = load(INGRESS / 'baseline-source.json')
    fixed = load(INGRESS / 'fix/fixed-source.json')
    b, i = baseline['head'], fixed['head']
    require(baseline['base'] == BASE and fixed['baseline'] == b, 'ingress source ancestry mismatch')
    require(git('show', '-s', '--format=%P', b).split() == [BASE]
            and git('show', '-s', '--format=%P', i).split() == [b],
            'ingress checkpoints do not form the reviewed source chain')
    test_path = 'trillionnium/crates/trnm-pon-node/src/ingress/account_scope_tests.rs'
    require(set(git('diff', '--name-only', BASE, b).splitlines()) == {test_path},
            'baseline is not tests-only')
    require(set(git('diff', '--name-only', b, i).splitlines()) == {
        'trillionnium/crates/trnm-pon-node/src/ingress/pq_network.rs',
        'trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs'},
        'ingress repair changed unreviewed files')
    for directory, head, tree in ((INGRESS, b, baseline['tree']),
                                  (INGRESS / 'fix', i, fixed['tree'])):
        before = load(directory / 'source-before-identity.json')
        after = load(directory / 'source-after-identity.json')
        checked_source_receipt(before, head)
        require(before == after and before['tested_tree'] == tree
                and git('rev-parse', head + '^{tree}') == tree,
                'ingress source observations differ')
        provider_before = load(directory / 'provider-before.json')
        require(provider_before == load(directory / 'provider-after.json')
                and provider_before.get('all_five_match') is True,
                'ingress provider observations differ')
    baseline_command = load(INGRESS / 'baseline-default.json')
    baseline_result = load(INGRESS / 'baseline-results.json')
    require(baseline_command['source'] == b and baseline_command['exit_code'] == 101
            and baseline_command['timed_out'] is False
            and baseline_result['source'] == b
            and baseline_result['results'] == [baseline_command]
            and baseline_result['provider_unchanged'] is True,
            'baseline failure receipt changed')
    text = read_original(INGRESS / 'baseline-default.stdout').decode()
    rows = native_summaries(text)
    require(len(rows) == 1 and rows[0]['result'] == 'FAILED'
            and (rows[0]['passed'], rows[0]['failed'], rows[0]['ignored'], rows[0]['measured']) == (6, 3, 0, 0),
            'baseline raw log does not retain six passes and three failures')
    method_pattern = r'^test (ingress::account_scope_tests::[A-Za-z0-9_]+) \.\.\. (ok|FAILED)\s*$'
    methods = re.findall(method_pattern, text, re.M)
    require(len(methods) == len({name for name, _ in methods}) == 9
            and sum(state == 'FAILED' for _, state in methods) == 3,
            'baseline methods are incomplete or ambiguous')
    expected = sorted(name for name, _ in methods)
    fixed_result = load(INGRESS / 'fix/fixed-results.json')
    require(fixed_result['source'] == i and fixed_result['provider_unchanged'] is True
            and fixed_result['provider_all_five_match'] is True
            and fixed_result['source_unchanged'] is True
            and fixed_result['source_after_exit_code'] == 0
            and [row['lane'] for row in fixed_result['tests']] == ['default', 'all-features'],
            'repair completion receipt is incomplete')
    repaired = []
    for lane, declared in zip(('default', 'all-features'), fixed_result['tests']):
        label = 'fixed-' + lane
        row = load(INGRESS / 'fix' / (label + '.json'))
        require(row['exit_code'] == 0 and row['timed_out'] is False
                and row['source_cwd'] == str(root)
                and all(declared.get(key) == value for key, value in row.items()),
                'repair command did not complete: ' + lane)
        text = read_original(INGRESS / 'fix' / (label + '.stdout')).decode()
        observed = re.findall(method_pattern, text, re.M)
        summaries = native_summaries(text)
        require(len(observed) == 9 and sorted(name for name, _ in observed) == expected
                and all(state == 'ok' for _, state in observed)
                and len(summaries) == 1 and summaries[0]['result'] == 'ok'
                and (summaries[0]['passed'], summaries[0]['failed'],
                     summaries[0]['ignored'], summaries[0]['measured']) == (9, 0, 0, 0),
                'repair raw log lacks the complete original nine controls: ' + lane)
        repaired.append({'lane': lane, 'source': i, 'summary': summaries[0],
                         'log': 'ingress/fix/' + label + '.stdout'})
    return {'baseline_source': b, 'baseline_tree': baseline['tree'],
            'repair_source': i, 'repair_tree': fixed['tree'],
            'baseline_summary': rows[0], 'baseline_failed_methods': [
                name for name, state in methods if state == 'FAILED'],
            'repair_observations': repaired, 'unique_methods': 9,
            'source_and_provider_before_after_equal': True,
            'scope': 'past separate source observations; not live executable attestation'}


def inspect_operator_interruptions(directory, head, commands, manifest):
    """Bind retained operator records to original commands; never signal a process."""
    results = sorted(directory.glob('operator-interruption-*-result.json'))
    intents = {path.name[:-len('-intent.json')] for path in
               directory.glob('operator-interruption-*-intent.json')}
    require(intents == {path.name[:-len('-result.json')] for path in results},
            'operator interruption intent/result pairs are incomplete')
    rows = {row['label']: row for row in commands}
    observed = []
    used_labels = set()

    def pinned_file(path):
        relative = canonical_relative(path.relative_to(directory).as_posix())
        pin = hash_original(path)
        require(manifest.get(relative) == pin,
                'operator record is not in the original completed validator manifest: ' + relative)
        return {'path': relative, **pin}

    for result_path in results:
        intent_path = result_path.with_name(result_path.name[:-len('-result.json')] + '-intent.json')
        result, intent = load(result_path), load(intent_path)
        context = dict(result)
        require(context.pop('signal_dispatched', None) is True,
                'operator signal dispatch was not confirmed')
        dispatched = context.pop('dispatched_unix_seconds', None)
        require(context == intent, 'operator intent and dispatch result differ')
        require(result.get('schema') == 'pq-operator-test-interruption-v1'
                and result.get('source') == head and result.get('signal') == 'SIGTERM via pidfd'
                and result.get('automatic_timeout_expired') is False
                and result.get('native_assertion_failure_claimed') is False
                and result.get('production_process') is False,
                'unreviewed operator interruption scope')
        for key in ('target_pid', 'target_start_ticks', 'parent_pid'):
            require(type(result.get(key)) is int and result[key] > 0,
                    'operator process identity is incomplete: ' + key)
        timestamp = result.get('observed_unix_seconds')
        require(type(timestamp) in (int, float) and type(dispatched) in (int, float)
                and math.isfinite(timestamp) and math.isfinite(dispatched)
                and 0 < timestamp <= dispatched, 'operator interruption timestamps are invalid')
        label = result.get('label')
        require(label in rows and label not in used_labels, 'operator interruption label is missing or repeated')
        row = rows[label]
        require(row['component_check_passed'] is False and row['exit_code'] == -15
                and type(row.get('elapsed_ns')) is int
                and type(row.get('timeout_seconds')) is int
                and 0 < row['elapsed_ns'] < row['timeout_seconds'] * 1_000_000_000,
                'original command does not match a pre-timeout SIGTERM interruption')
        require(result['argv'] == ['timeout', '--kill-after=20', str(row['timeout_seconds'])] + row['argv'],
                'interrupted timeout argv differs from the original validator command')
        snapshots = []
        for path in sorted(directory.glob('operator-readonly-process-observation*.json')):
            snapshot = load(path)
            matches = [process for process in snapshot.get('processes', [])
                       if process.get('pid') == result['target_pid']
                       and process.get('ppid') == result['parent_pid'] and process.get('comm') == 'timeout']
            if not matches:
                continue
            require(snapshot.get('schema') == 'pq-readonly-process-observation-v1'
                    and snapshot.get('root_pid') == result['parent_pid']
                    and snapshot.get('process_signals_sent') is False
                    and snapshot.get('source_mutated') is False
                    and type(snapshot.get('observed_unix_seconds')) in (int, float)
                    and math.isfinite(snapshot['observed_unix_seconds'])
                    and 0 < snapshot['observed_unix_seconds'] <= timestamp,
                    'pre-stop process snapshot is inconsistent')
            snapshots.append(pinned_file(path))
        require(snapshots, 'operator interruption has no matching retained pre-stop process snapshot')
        used_labels.add(label)
        observed.append({
            'classification': 'operator-interruption', 'source': head, 'label': label,
            'exit_code': row['exit_code'], 'elapsed_ns': row['elapsed_ns'],
            'declared_outer_timeout_seconds': row['timeout_seconds'],
            'automatic_timeout_expired': False, 'native_assertion_failure_claimed': False,
            'complete_native_command_observation': False, 'root_cause_independently_proved': False,
            'intent': pinned_file(intent_path), 'result': pinned_file(result_path),
            'readonly_process_snapshots': snapshots, 'operator_record': result,
            'scope': 'retained operator intent, confirmed dispatch and corresponding command termination; no live process revalidation',
        })
    return observed


def inspect_validation(root, directory, head, check_native, *, current=True, blob=None, git=None):
    c3_prior = head == REQUIRED_C3_SOURCE and not current
    if head == REQUIRED_C3_SOURCE:
        require(not current, 'C3 is a retained unsuccessful prior batch, not the current candidate')
        require_c3_profile_frozen()
    named_record_consistency = current or c3_prior
    # Current roster expansions must not change the historical selector view.
    tcv3_tests = TCV3_TESTS if current else C3_TCV3_TESTS
    peer_tests = PEER_LIFECYCLE_TESTS if current else C3_PEER_LIFECYCLE_TESTS
    retained_tests = RETAINED_CACHE_TESTS if current else C3_RETAINED_CACHE_TESTS
    checkpoint_tests = CHECKPOINT_SOCKET_TESTS if current else C3_CHECKPOINT_SOCKET_TESTS
    peer_method_count, retained_method_count, da_method_count = (
        (4, 10, 29) if current else (3, 7, 25)
    )
    value = load(directory / 'validation.json')
    require(value.get('schema') == 'trnm-pq-boundary-component-observations-v1'
            and value.get('completed') is True
            and value.get('source') == head and 'error' not in value,
            'validator did not complete on its declared source')
    if current:
        require(value.get('all_requested_component_checks_passed') is True
                and value.get('failures') == [], 'current validator did not pass its complete batch')
    if named_record_consistency:
        require(type(value.get('runtime_test_threads')) is int and value['runtime_test_threads'] == 1
                and value.get('harness_basis') ==
                'repository CI RUST_TEST_THREADS=1; business deadlines unchanged',
                'named-control validator record does not contain the reviewed CI harness')
    require(value.get('qualification') == 'HOLD'
            and value.get('whole_chain_pq_qualified') is False
            and value.get('production_activation') is False
            and value.get('ordinary_caller_switched') is False
            and value.get('actual_lifetime_failure_bound') is None,
            'validator qualification boundaries changed')
    validator_sha = hash_original(directory / 'executed-validator.py')['sha256']
    require(validator_sha in ({VALIDATOR_SHA256} if current else PRIOR_VALIDATOR_ALLOWLIST),
            'unreviewed validator bytes')
    require(hash_original(directory / 'provider-helper.py')['sha256'] == PROVIDER_HELPER_SHA256,
            'unreviewed provider identity helper')
    for name, pin in value['artifact_files'].items():
        require(hash_original(directory / canonical_relative(name)) == pin,
                'validator artifact changed: ' + name)
    before = value['source_before']
    checked_source_receipt(before, head)
    if git is not None:
        require(git('rev-parse', head + '^{tree}') == before['tested_tree'],
                'recorded validation tree differs from the immutable source object')
    require(before == value['source_after'], 'validator source before/after mismatch')
    for name in ('source-before.json', 'source-before-native.json', 'source-after.json'):
        require(load(directory / name) == before, 'validator source record mismatch: ' + name)
    require(value['provider_before'] == value['provider_after']
            and value['provider_before'].get('all_five_match') is True
            and value['provider_selection'].get('compatible') is True
            and value.get('compiler_override_names') == [],
            'validator provider inputs or compiler overrides changed')
    commands = value['commands']
    require(tuple(row['label'] for row in commands) == EXPECTED_LABELS,
            'validator command roster is not the reviewed complete batch')
    require(all(type(row.get('component_check_passed')) is bool for row in commands),
            'validator command verdict is not explicit')
    failed = [row['label'] for row in commands if not row['component_check_passed']]
    require(value['failures'] == failed
            and value['all_requested_component_checks_passed'] is (not failed),
            'validator overall verdict disagrees with its original command verdicts')
    if head == REQUIRED_PRIOR_SOURCE:
        require(not current and validator_sha == PRIOR_VALIDATOR_SHA256
                and tuple(failed) == REQUIRED_PRIOR_FAILURES,
                'the required C1 observation no longer preserves its three original failures')
    if head == REQUIRED_INTERRUPTED_SOURCE:
        require(not current and validator_sha == CI_V2_VALIDATOR_SHA256
                and tuple(failed) == REQUIRED_INTERRUPTED_FAILURES,
                'the required C2 batch has lost its original three command failures')
        require(hash_original(directory / 'validation.json') == {
            'bytes': 120352, 'sha256': REQUIRED_INTERRUPTED_VALIDATION_SHA256},
            'the original completed C2 receipt bytes changed')
    if c3_prior:
        require(validator_sha == CI_V4_VALIDATOR_SHA256
                and tuple(failed) == REQUIRED_C3_FAILURES,
                'the required C3 batch has lost its original completed command verdicts')
        require(hash_original(directory / 'validation.json') == {
            'bytes': REQUIRED_C3_VALIDATION_BYTES, 'sha256': REQUIRED_C3_VALIDATION_SHA256},
            'the original completed C3 receipt bytes changed')
    require([decode_json(line) for line in read_original(directory / 'commands.jsonl').splitlines()]
            == commands, 'validator commands.jsonl disagrees with validation.json')
    logs = {}
    for row in commands:
        label = row['label']
        require(load(directory / (label + '.json')) == row
                and type(row['exit_code']) is int
                and (not row['component_check_passed'] or row['exit_code'] == 0),
                'inconsistent validator command: ' + label)
        require(row['log'] == label + '.log'
                and hash_original(directory / row['log']) == {
                    'bytes': row['log_bytes'], 'sha256': row['log_sha256']},
                'validator raw log changed: ' + label)
        logs[label] = directory / row['log']
    interruptions = inspect_operator_interruptions(directory, head, commands, value['artifact_files'])
    if current:
        require(not interruptions, 'current successful batch cannot borrow an interrupted command')
    if head == REQUIRED_INTERRUPTED_SOURCE:
        require(any(row['label'] == 'da-default-lib' for row in interruptions),
                'C2 default interruption is missing its original operator provenance')
    if named_record_consistency:
        for label in ('da-default-lib', 'da-all-features-lib', 'checkpoint-tests'):
            row = next(row for row in commands if row['label'] == label)
            require(row['argv'][-5:] == ['--', '--format', 'pretty', '--test-threads', '1'],
                    'named-control native invocation omits explicit single-threaded pretty output: ' + label)
    frozen = load(directory / 'tcv3-frozen-native-roster.json')
    require(frozen == {'tests': list(tcv3_tests), 'unique_methods': 15},
            'TCV3 independent native roster changed')
    if named_record_consistency:
        require(load(directory / 'peer-lifecycle-frozen-native-roster.json') == {
            'tests': list(peer_tests), 'unique_methods': peer_method_count},
            'peer-lifecycle independent native roster changed')
        require(load(directory / 'retained-cache-frozen-native-roster.json') == {
            'tests': list(retained_tests), 'unique_methods': retained_method_count},
            'retained-cache independent native roster changed')
        require(len(tcv3_tests) == len(set(tcv3_tests)) == 15
                and len(peer_tests) == len(set(peer_tests)) == peer_method_count
                and len(retained_tests) == len(set(retained_tests)) == retained_method_count
                and len(set(tcv3_tests + peer_tests + retained_tests)) == da_method_count,
                'DA required method groups differ from their own frozen source roster')
    da = []
    tcv3_successful = 0
    for label in ('da-default-lib', 'da-all-features-lib'):
        text = read_original(logs[label]).decode()
        summaries = native_summaries(text)
        if current:
            require(len(summaries) == 1 and summaries[0]['result'] == 'ok'
                    and summaries[0]['passed'] >= len(tcv3_tests + peer_tests + retained_tests)
                    and all(summaries[0][key] == 0 for key in ('failed', 'ignored', 'measured', 'filtered_out')),
                    'current DA full-library log is incomplete or failed: ' + label)
        coverage = {name: re.findall(r'^test ' + re.escape(name) + r' \.\.\. (\S+)\s*$', text, re.M)
                    for name in tcv3_tests}
        if current or head == REQUIRED_PRIOR_SOURCE:
            require(all(states == ['ok'] for states in coverage.values()),
                    'DA log lacks the recorded exact TCV3 methods: ' + label)
        if head == REQUIRED_PRIOR_SOURCE:
            require(len(summaries) == 1 and summaries[0]['result'] == 'FAILED'
                    and summaries[0]['passed'] == 733 and summaries[0]['failed'] == 1,
                    'C1 full-library failure no longer matches the original 733/1 observation')
        if head == REQUIRED_INTERRUPTED_SOURCE and label == 'da-default-lib':
            require(not summaries and all(states == [] for states in coverage.values()),
                    'C2 interrupted default log no longer matches its incomplete native observation')
        if head == REQUIRED_INTERRUPTED_SOURCE and label == 'da-all-features-lib':
            require(len(summaries) == 1 and summaries[0]['result'] == 'FAILED'
                    and summaries[0]['passed'] == 733 and summaries[0]['failed'] == 1
                    and 'CacheWriterBusy' in text,
                    'C2 all-features original 733/1 and CacheWriterBusy report changed')
        if c3_prior:
            require(summaries == REQUIRED_C3_DA_SUMMARIES[label],
                    'C3 completed DA summary differs from its original observation: ' + label)
        recorded = next(row for row in commands if row['label'] == label)
        require(recorded['tcv3_named_executions'] == coverage,
                'DA recorded named coverage disagrees with raw log')
        if named_record_consistency:
            require(recorded.get('native_summaries') == [
                {key: value for key, value in summary.items() if key != 'result'}
                for summary in summaries],
                'DA recorded summary disagrees with raw log: ' + label)
        peer_coverage = {name: re.findall(r'^test ' + re.escape(name) + r' \.\.\. (\S+)\s*$', text, re.M)
                         for name in peer_tests}
        if named_record_consistency:
            require(recorded.get('peer_lifecycle_named_executions') == peer_coverage,
                    'DA recorded peer/discovery methods disagree with raw log: ' + label)
        if current:
            require(all(states == ['ok'] for states in peer_coverage.values()),
                    'current DA log lacks four unique passed peer/discovery methods: ' + label)
        retained_coverage = {name: re.findall(r'^test ' + re.escape(name) + r' \.\.\. (\S+)\s*$', text, re.M)
                             for name in retained_tests}
        if named_record_consistency:
            require(recorded.get('retained_cache_named_executions') == retained_coverage,
                    'DA recorded retained-cache methods disagree with raw log: ' + label)
        if current:
            require(all(states == ['ok'] for states in retained_coverage.values()),
                    'current DA log lacks ten unique passed retained-cache methods: ' + label)
        successful = sum(states == ['ok'] for states in coverage.values())
        tcv3_successful += successful
        da.append({'label': label, 'summaries': summaries, 'tcv3_roster_methods': 15,
                   'tcv3_successful_executions': successful,
                   'full_library_check_passed': recorded['component_check_passed'],
                   'current_peer_lifecycle_names_observed': peer_coverage,
                   'peer_lifecycle_acceptance_checked': current,
                   'peer_lifecycle_record_consistency_checked': named_record_consistency,
                   'current_retained_cache_names_observed': retained_coverage,
                   'retained_cache_acceptance_checked': current,
                   'retained_cache_record_consistency_checked': named_record_consistency,
                   'mentions_cache_writer_busy': 'CacheWriterBusy' in text,
                   'underlying_failure_cause_independently_proved': False,
                   'mentions_cell_absolute_deadline': 'cell absolute deadline' in text})
    checkpoint_text = read_original(logs['checkpoint-tests']).decode()
    checkpoint_summaries = native_summaries(checkpoint_text)
    checkpoint_coverage = {name: re.findall(r'^test ' + re.escape(name) + r' \.\.\. (\S+)\s*$',
                                          checkpoint_text, re.M) for name in checkpoint_tests}
    checkpoint_row = next(row for row in commands if row['label'] == 'checkpoint-tests')
    if named_record_consistency:
        require(checkpoint_row.get('checkpoint_socket_named_executions') == checkpoint_coverage
                and checkpoint_row.get('native_summaries') == [
                    {key: value for key, value in summary.items() if key != 'result'}
                    for summary in checkpoint_summaries],
                'checkpoint recorded methods or summaries disagree with raw log')
    if current:
        require(checkpoint_summaries and all(row['result'] == 'ok' and row['failed'] == 0
                                            for row in checkpoint_summaries)
                and all(states == ['ok'] for states in checkpoint_coverage.values()),
                'current checkpoint log lacks four unique passed socket methods')
    elif head == REQUIRED_PRIOR_SOURCE:
        require(any(row['failed'] > 0 for row in checkpoint_summaries)
                and checkpoint_coverage['copied_lease_record_cannot_replace_a_live_checkpoint_endpoint'] == ['FAILED'],
                'C1 copied-lease failure is not retained in its original checkpoint log')
    if blob is not None:
        retained = decode_json(blob(head, 'config/pon/pq-system-required-tests-v1.json'))
        supplemental = decode_json(blob(head, 'config/pon/pq-system-supplemental-tests-v1.json'))
    else:
        retained = load(root / 'config/pon/pq-system-required-tests-v1.json')
        supplemental = load(root / 'config/pon/pq-system-supplemental-tests-v1.json')
    require(retained['expected_meaningful_controls'] == len(retained['tests']) == 52
            and supplemental['expected_meaningful_controls'] == len(supplemental['tests']) == 11,
            'PQ native source rosters changed')
    names = retained['tests'] + supplemental['tests']
    require(len(set(names)) == 63, 'duplicate PQ exact selectors')
    require(load(directory / 'native-pq-exact-roster.json') == {
        'retained': retained, 'supplement': supplemental, 'tests': names},
        'PQ executed roster differs from its own source')
    exact_successes = 0
    for index, name in enumerate(names):
        label = f'pq-native-{index:02d}'
        row = next(row for row in commands if row['label'] == label)
        require('--exact' in row['argv'] and name in row['argv'], 'PQ exact selector mismatch: ' + name)
        try:
            with logs[label].open(encoding='utf-8') as stream:
                parsed = check_native(stream, name)
        except ValueError:
            require(not current and row['component_check_passed'] is False,
                    'recorded PQ success has no successful exact transcript: ' + name)
        else:
            require(row.get('named_execution') == parsed, 'PQ exact execution mismatch: ' + name)
            if row['component_check_passed']:
                exact_successes += 1
    if head == REQUIRED_INTERRUPTED_SOURCE:
        require(exact_successes == 62,
                'C2 PQ41 failure must not be converted into a successful exact execution')
    return value, {'commands': len(commands), 'da_library_lanes': da,
                   'passed_commands': len(commands) - len(failed), 'failed_commands': failed,
                   'all_requested_component_checks_passed': value['all_requested_component_checks_passed'],
                   'operator_interruptions': interruptions,
                   'failed_command_labels_without_operator_interruption': [
                       label for label in failed if label not in {row['label'] for row in interruptions}],
                   'validator_sha256': validator_sha,
                   'runtime_test_threads': value.get('runtime_test_threads'),
                   'harness_basis': value.get('harness_basis', 'not explicitly pinned by the original validator'),
                   'tcv3_unique_roster_methods': 15, 'tcv3_successful_executions': tcv3_successful,
                   'current_da_required_unique_methods': 29 if current else None,
                   'current_da_required_successful_executions': 58 if current else None,
                   'pq_retained_unique_methods': 52, 'pq_supplemental_unique_methods': 11,
                   'pq_native_commands': 63, 'pq_successful_exact_executions': exact_successes,
                   'checkpoint_native_summaries': checkpoint_summaries,
                   'current_checkpoint_socket_names_observed': checkpoint_coverage,
                   'checkpoint_four_method_acceptance_checked': current,
                   'checkpoint_record_consistency_checked': named_record_consistency,
                   'strict_clippy_passed': next(row for row in commands
                                               if row['label'] == 'strict-clippy')['component_check_passed'],
                   'full_validation_manifest_and_original_logs_rechecked': True}


def write_archive(path, roster):
    with path.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                for member, pin in roster.items():
                    original = Path(pin['original_path'])
                    stream, before = open_regular(original)
                    with stream:
                        require(before.st_size == pin['bytes'], 'original size changed: ' + member)
                        info = tarfile.TarInfo(member)
                        info.size = pin['bytes']
                        info.mode = 0o644
                        info.uid = info.gid = info.mtime = 0
                        archive.addfile(info, stream)
                        require(fingerprint(os.fstat(stream.fileno())) == fingerprint(before)
                                and fingerprint(original.lstat()) == fingerprint(before),
                                'original changed while archiving: ' + member)
    observed = {}
    with tarfile.open(path, 'r|gz') as archive:
        for member in archive:
            require(member.isfile() and member.name in roster and member.name not in observed,
                    'archive roster mismatch')
            stream = archive.extractfile(member)
            require(stream is not None, 'archive member is unreadable')
            observed[member.name] = {'bytes': member.size,
                                    'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}
    require(observed == {name: {'bytes': row['bytes'], 'sha256': row['sha256']}
                         for name, row in roster.items()}, 'archive lost or changed original bytes')


def split_archive(path, destination):
    original = hash_original(path)
    count = max(1, (original['bytes'] + MAX_FILE_BYTES - 1) // MAX_FILE_BYTES)
    parts = []
    reconstructed = hashlib.sha256()
    total = 0
    with path.open('rb') as stream:
        for index in range(count):
            name = 'raw-evidence.tar.gz' if count == 1 else f'raw-evidence.tar.gz.part{index + 1:04d}'
            raw = stream.read(MAX_FILE_BYTES)
            require(raw and len(raw) <= MAX_FILE_BYTES, 'archive split was truncated')
            with (destination / name).open('xb') as output:
                output.write(raw)
            reconstructed.update(raw)
            total += len(raw)
            parts.append({'path': name, 'bytes': len(raw), 'sha256': sha_bytes(raw)})
        require(not stream.read(1), 'archive grew while splitting')
    require(total == original['bytes'] and reconstructed.hexdigest() == original['sha256'],
            'archive reconstruction differs')
    return {'schema': 'trnm-pq-evidence-archive-v1', 'format': 'gzip-compressed-posix-tar',
            'archive': {'name': 'raw-evidence.tar.gz', **original}, 'parts': parts,
            'maximum_committed_file_bytes': MAX_FILE_BYTES,
            'reconstruction': 'Concatenate parts in the listed order; verify archive bytes and SHA-256 before reading the tar.'}


def main():
    require(not sys.flags.optimize and os.environ.get('PYTHONOPTIMIZE', '') in ('', '0'),
            'finalizer and its child readers require non-optimized Python')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--head', required=True)
    parser.add_argument('--validation', type=Path, required=True)
    parser.add_argument('--apply', dest='application', type=Path, required=True)
    parser.add_argument('--prior-validation', dest='prior_validations', type=Path,
                        action='append', default=[], help='Repeat to retain complete earlier validation directories.')
    parser.add_argument('--prior-apply', dest='prior_applications', type=Path,
                        action='append', default=[], help='Repeat to retain earlier application directories.')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    # Require the frozen historical profile before creating output or touching a repo.
    require_c3_profile_frozen()
    require(re.fullmatch('[0-9a-f]{40}', args.head) is not None, '--head must be the full C commit')
    root = canonical_absolute(args.root)
    validation = canonical_absolute(args.validation)
    application = canonical_absolute(args.application)
    prior_validations = [canonical_absolute(path) for path in args.prior_validations]
    prior_applications = [canonical_absolute(path) for path in args.prior_applications]
    output = canonical_absolute(args.output, exists=False)
    inputs = {'ingress': INGRESS, 'dependency-fetch': DEPENDENCY_FETCH,
              'apply': application, 'validation': validation}
    inputs.update({f'prior-validation-{index:02d}': path
                   for index, path in enumerate(prior_validations, 1)})
    inputs.update({f'prior-apply-{index:02d}': path
                   for index, path in enumerate(prior_applications, 1)})
    for path in (output, *inputs.values()):
        require(not path.is_relative_to(root), 'evidence inputs and receipts must stay outside the checkout')
    for path in inputs.values():
        require(not output.is_relative_to(path) and not path.is_relative_to(output),
                'output must be disjoint from all original evidence directories')
    require(len(set(inputs.values())) == len(inputs), 'aliased input directories')
    for first in inputs.values():
        require(not any(first != other and first.is_relative_to(other) for other in inputs.values()),
                'overlapping input evidence directories')
    output.mkdir(exist_ok=False)
    receipt = {'schema': 'trnm-pq-evidence-finalization-v4', 'source_C': args.head,
               'runtime_R': None, 'evidence_E': None, 'completed': False,
               'required_prior_sources': sorted(REQUIRED_PRIOR_SOURCES),
               'qualification': 'HOLD', 'whole_chain_pq_qualified': False,
               'production_activation': False, 'ordinary_caller_switched': False,
               'actual_lifetime_failure_bound': None, 'native_tests_executed_on_E': False}
    sys.dont_write_bytecode = True
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    os.environ['GIT_NO_LAZY_FETCH'] = '1'
    os.environ['GIT_NO_REPLACE_OBJECTS'] = '1'
    os.environ['PATH'] = '/home/qian-qi/.cargo/bin:' + os.environ['PATH']
    os.chdir(root)
    command_index = 0

    def run(label, argv, timeout=600):
        nonlocal command_index
        command_index += 1
        name = f'{command_index:02d}-{label}'
        started = time.monotonic_ns()
        print(json.dumps({'started': label}), flush=True)
        stdout, stderr = output / (name + '.stdout'), output / (name + '.stderr')
        with stdout.open('xb') as out, stderr.open('xb') as err:
            process = subprocess.run(['timeout', '--kill-after=20', str(timeout)] + argv,
                                     cwd=root, stdout=out, stderr=err)
        row = {'label': label, 'argv': argv, 'exit_code': process.returncode,
               'elapsed_ns': time.monotonic_ns() - started, 'timeout_seconds': timeout,
               'stdout': {'path': stdout.name, **hash_original(stdout)},
               'stderr': {'path': stderr.name, **hash_original(stderr)}}
        put(output / (name + '.json'), row)
        with (output / 'commands.jsonl').open('a') as stream:
            stream.write(json.dumps(row, sort_keys=True) + '\n')
        print(json.dumps({'finished': label, 'exit_code': process.returncode}), flush=True)
        require(process.returncode == 0, 'finalizer command failed: ' + label)
        return read_original(stdout).decode().strip()

    def git(*arguments):
        return subprocess.check_output(['git', '--no-replace-objects', *arguments],
                                       cwd=root, text=True).strip()

    def blob(revision, path):
        return subprocess.check_output(['git', '--no-replace-objects', 'cat-file', 'blob',
                                        revision + ':' + canonical_relative(path)], cwd=root)

    def parents(revision):
        return git('show', '-s', '--format=%P', revision).split()

    try:
        with (output / 'executed-finalizer.py').open('xb') as stream:
            stream.write(read_original(Path(__file__).resolve()))
        run('preflight-before-inspection', ['bash', 'scripts/project-preflight.sh'])
        require(git('rev-parse', 'HEAD') == args.head and not git('status', '--porcelain', '--untracked-files=all'),
                'checkout is not clean at C')
        source_reader = root / 'scripts/ci/verify_ci_source.py'
        require(read_original(source_reader) == blob(args.head, 'scripts/ci/verify_ci_source.py')
                and hash_original(source_reader)['sha256'] == SOURCE_READER_SHA256,
                'unreviewed source reader')
        native_reader = root / 'scripts/ci/check_required_native_test.py'
        require(read_original(native_reader) == blob(args.head, 'scripts/ci/check_required_native_test.py'),
                'dirty native log reader')
        sys.path.insert(0, str(root / 'scripts/ci'))
        from verify_ci_source import verify
        from check_required_native_test import validate as check_native
        current_source = verify('head', args.head, None, None, root)
        put(output / 'source-C-before.json', current_source)
        extras = {'historical/pq-boundary-inherited-campaign-4150.tar.gz': HISTORICAL,
                  'tooling/executed-finalizer.py': output / 'executed-finalizer.py'}
        roster = inventory(inputs, extras)
        put(output / 'original-files-before.json', roster)
        value, components = inspect_validation(root, validation, args.head, check_native, blob=blob, git=git)
        require(current_source == value['source_before'], 'current C differs from the actual tested source')
        prior_observations = []
        for index, directory in enumerate(prior_validations, 1):
            label = f'prior-validation-{index:02d}'
            prior_head = load(directory / 'validation.json')['source']
            require(re.fullmatch('[0-9a-f]{40}', prior_head) is not None,
                    'noncanonical prior validation source')
            run(label + '-ancestor', ['git', '--no-replace-objects', 'merge-base',
                                     '--is-ancestor', prior_head, args.head])
            require(blob(prior_head, 'scripts/ci/check_required_native_test.py')
                    == blob(args.head, 'scripts/ci/check_required_native_test.py'),
                    'prior native transcript needs its own reviewed reader')
            prior, observed = inspect_validation(root, directory, prior_head, check_native,
                                                 current=False, blob=blob, git=git)
            prior_observations.append({
                'archive_label': label, 'directory': str(directory), 'source': prior['source_before'],
                'validation_file': hash_original(directory / 'validation.json'),
                'component_observations': observed, 'completed': True,
                'all_requested_component_checks_passed': prior['all_requested_component_checks_passed'],
                'failures': prior['failures'], 'classification': 'separate-prior-batch-original-verdict-retained',
                'new_native_execution_claimed': False,
            })
        prior_sources = {row['source']['tested_commit'] for row in prior_observations}
        require(REQUIRED_PRIOR_SOURCES <= prior_sources,
                'v4 must retain the original C1, C2 and C3 batches through repeated --prior-validation')
        prior_application_observations = []
        for index, directory in enumerate(prior_applications, 1):
            label = f'prior-apply-{index:02d}'
            old_candidate = load(directory / 'candidate.json')
            old_runtime = load(directory / 'runtime.json')
            old_c, old_r = old_candidate['source'], old_candidate['runtime_revision']
            require(old_c in prior_sources and old_candidate['base'] == old_runtime['base'] == BASE
                    and old_runtime['source'] == old_r
                    and old_candidate['ingress_source'] == old_runtime['ingress_source']
                    and old_candidate['native_tests_executed_on_candidate'] is False
                    and old_candidate['whole_chain_pq_qualified'] is False
                    and old_candidate['production_activation'] is False,
                    'prior application is not bound to a retained prior validation source')
            run(label + '-ancestor', ['git', '--no-replace-objects', 'merge-base',
                                     '--is-ancestor', old_c, args.head])
            require(parents(old_c) == [old_r]
                    and set(git('diff', '--name-only', old_r, old_c).splitlines()) == {CORPUS, BUDGET, SOURCE_LOCK},
                    'prior C is not its declared metadata-only successor of prior R')
            if old_c == REQUIRED_C3_SOURCE:
                require(old_r == REQUIRED_C3_RUNTIME,
                        'C3 original application no longer identifies its actual R3 checkpoint')
            prior_application_observations.append({
                'archive_label': label, 'directory': str(directory), 'candidate_receipt': old_candidate,
                'runtime_receipt': old_runtime, 'new_native_execution_claimed': False,
                'matching_prior_validation_labels': [row['archive_label'] for row in prior_observations
                                                      if row['source']['tested_commit'] == old_c],
            })
        require(REQUIRED_PRIOR_SOURCES <= {row['candidate_receipt']['source']
                                           for row in prior_application_observations},
                'v4 must retain the original C1, C2 and C3 applications through repeated --prior-apply')
        receipt['prior_validations'] = prior_observations
        receipt['prior_applications'] = prior_application_observations
        candidate = load(application / 'candidate.json')
        runtime = load(application / 'runtime.json')
        r = candidate['runtime_revision']
        require(candidate['source'] == args.head and candidate['base'] == BASE
                and runtime['source'] == r and runtime['base'] == BASE
                and candidate['ingress_source'] == runtime['ingress_source']
                and candidate['native_tests_executed_on_candidate'] is False
                and candidate['whole_chain_pq_qualified'] is False
                and candidate['production_activation'] is False,
                'application source attribution is inconsistent')
        require(parents(args.head) == [r]
                and set(git('diff', '--name-only', r, args.head).splitlines()) == {CORPUS, BUDGET, SOURCE_LOCK},
                'C is not the declared metadata-only successor of R')
        receipt['runtime_R'] = r
        ingress = inspect_ingress(root, git)
        require(candidate['ingress_source'] == ingress['repair_source'],
                'current application ingress attribution changed')
        run('ingress-runtime-ancestor', ['git', '--no-replace-objects', 'merge-base', '--is-ancestor',
                                        ingress['repair_source'], r])
        test_path = 'trillionnium/crates/trnm-pon-node/src/ingress/account_scope_tests.rs'
        require(blob(ingress['baseline_source'], test_path) == blob(args.head, test_path),
                'original ingress regression controls were rewritten')
        for path in GRAPH_PATHS:
            require(blob(BASE, path) == blob(args.head, path), 'dependency graph changed: ' + path)
        budget, lock, root_register = load(root / BUDGET), load(root / SOURCE_LOCK), load(root / ROOT_REGISTER)
        require(budget['experiment']['source_revision'] == lock['source_revision'] == r
                and len(budget['events']) == len(budget['terms']) == 8
                and all(term['status'] == 'unknown' and term['bound'] is None for term in budget['terms'])
                and len(lock['files']) == 21, 'lifetime source or unknown boundaries changed')
        for path, digest in lock['files'].items():
            require(sha_bytes(blob(r, path)) == sha_bytes(blob(args.head, path)) == digest,
                    'lifetime declared runtime source mismatch: ' + path)
        require(decode_json(blob(REQUIRED_PRIOR_SOURCE, SOURCE_LOCK))['files'] == lock['files']
                and blob(REQUIRED_PRIOR_SOURCE, ROOT_REGISTER) == blob(args.head, ROOT_REGISTER),
                'the twenty-one declared component objects or Root register changed after C1')
        require(root_register['actual_lifetime_failure_bound'] is None
                and root_register['composition_coverage_proved'] is False,
                'Root dependency register was promoted')
        historical = inspect_historical(HISTORICAL)
        corpus_before_raw = read_original(root / CORPUS)
        corpus_before = decode_json(corpus_before_raw)
        for path, pin in corpus_before['pinned_blobs'].items():
            require(git_blob(read_original(root / canonical_relative(path))) == pin,
                    'unchanged corpus pin is stale: ' + path)
        put(output / 'existing-corpus-pins-verified.json', {
            'source': args.head, 'count': len(corpus_before['pinned_blobs']),
            'corpus_sha256': sha_bytes(corpus_before_raw), 'unrelated_pins_rewritten': False})
        require(inventory(inputs, extras) == roster, 'original evidence changed during inspection')
        archive = output / 'raw-evidence.tar.gz'
        print(json.dumps({'started': 'archive-original-bytes', 'files': len(roster)}), flush=True)
        write_archive(archive, roster)
        require(inventory(inputs, extras) == roster, 'original evidence changed during archival')
        stage = output / 'staged-evidence'
        stage.mkdir()
        archive_manifest = split_archive(archive, stage)
        put(stage / 'archive-manifest.json', archive_manifest)
        put(stage / 'original-files.json', {'schema': 'trnm-pq-original-file-roster-v1',
            'files': roster, 'file_count': len(roster),
            'input_directories': {label: str(path) for label, path in inputs.items()},
            'scope': 'Every original regular file in all declared current and prior input directories, the retained compact historical archive, and this finalizer; no filtering or replacement of failed commands.'})
        observations = {
            'schema': 'trnm-pq-boundary-closure-observations-v4', 'qualification': 'HOLD',
            'source_C': current_source, 'runtime_R': {'commit': r, 'tree': git('rev-parse', r + '^{tree}'),
                                                    'parents': parents(r)},
            'evidence_E': {'binding': 'first owning evidence-only Git child of C; exact E and its full source receipt are recorded externally after commit',
                           'native_tests_executed_on_E': False},
            'application_receipt': candidate, 'component_observations': components,
            'prior_validations': prior_observations, 'prior_applications': prior_application_observations,
            'required_prior_sources': sorted(REQUIRED_PRIOR_SOURCES),
            'prior_failure_results_replaced_by_current_passes': False,
            'ingress_observations': ingress, 'historical_campaign': historical,
            'validator_validation_sha256': hash_original(validation / 'validation.json')['sha256'],
            'source_before_after_equal': True, 'provider_before_after_equal': True,
            'source_observation_scope': 'complete batch before and after; not live executable attestation',
            'lifetime_domains': [{'covers': term['covers'], 'status': 'unknown', 'bound': None}
                                 for term in budget['terms']],
            'declared_lifetime_source_files': 21, 'transitive_implementation_graph_coverage_proved': False,
            'whole_chain_pq_qualified': False, 'actual_lifetime_failure_bound': None,
            'composition_coverage_proved': False, 'production_activation': False,
            'ordinary_caller_switched': False, 'historical_migration_authenticated': False,
            'undeclared_semantic_dependency_closure_proved': False, 'independent_custody_proved': False,
            'current_final_use_authority_granted': False, 'new_candidate_campaign_executed': False,
            'archive_files': len(roster), 'archive': archive_manifest['archive'],
        }
        put(stage / 'observations.json', observations)
        archive_links = '\n'.join('- [' + part['path'] + '](' + part['path'] + '): '
                                  + str(part['bytes']) + ' bytes, SHA-256 `' + part['sha256'] + '`.'
                                  for part in archive_manifest['parts'])
        prior_rows = '\n'.join(
            '| `' + row['archive_label'] + '` | `' + row['source']['tested_commit'] + '` | '
            + str(row['component_observations']['passed_commands']) + ' passed commands; '
            + str(len(row['failures'])) + ' failed commands: '
            + (', '.join('`' + label + '`' for label in row['failures']) or 'none') + ' | '
            + (', '.join('`' + interruption['label'] + '` (operator SIGTERM, exit '
                        + str(interruption['exit_code']) + ')' for interruption in
                        row['component_observations']['operator_interruptions']) or 'none') + ' |'
            for row in prior_observations)
        prior_apply_rows = '\n'.join(
            '| `' + row['archive_label'] + '` | `' + row['runtime_receipt']['source'] + '` | `'
            + row['candidate_receipt']['source'] + '` |'
            for row in prior_application_observations)
        c3_components = next(row['component_observations'] for row in prior_observations
                             if row['source']['tested_commit'] == REQUIRED_C3_SOURCE)
        c3_failed_labels = ', '.join('`' + label + '`'
                                     for label in c3_components['failed_commands'])
        c3_da_rows = '\n'.join(
            '| `' + row['label'] + '` | '
            + ('; '.join(summary['result'] + ': ' + str(summary['passed']) + ' passed, '
                         + str(summary['failed']) + ' failed, ' + str(summary['ignored']) + ' ignored, '
                         + str(summary['measured']) + ' measured, '
                         + str(summary['filtered_out']) + ' filtered out'
                         for summary in row['summaries']) or 'No completed libtest summary')
            + ' | ' + str(row['tcv3_successful_executions']) + ' |'
            for row in c3_components['da_library_lanes'])
        readme = f'''# PQ entry and explicit content-lineage component observations

## Result and qualification

The reviewed component batch completed on committed source **C = `{args.head}`**.
Its {components['commands']} recorded commands, original logs, complete tracked-source
observations, and provider observations were rechecked before this evidence was
created. The retained PQ roster executed 52 original plus 11 supplemental exact
methods. Both DA library lanes each executed all 15 named TCV3 methods (30
executions across two feature selections). The checkpoint package also recorded
one passed execution of each of the four frozen socket-ownership methods.
Both current DA lanes each recorded one passed execution of all four frozen
peer/discovery methods, including bounded cleanup when no connection arrives
and the real short-TTL transfer refusal. Each lane also recorded all ten
retained-cache methods: the unchanged 65/128 capacity control, six provider/store
paired-batch controls, and the existing retention-deadline, cache-loss rehydration
and eight-chunk reader-refusal controls. These three DA groups
contain 29 distinct methods per lane, with 58 successful executions across the
two lanes; this does not replace the full-library summary.
The current batch explicitly used the repository CI's `RUST_TEST_THREADS=1`,
and each DA/checkpoint command passed `--test-threads 1`. Full library counts and other checks
remain in [observations.json](observations.json) and the unmodified validation logs.

Qualification remains **HOLD**. All eight lifetime terms remain `unknown` with
`bound = null`; the actual lifetime failure bound remains null and composition
coverage remains unproved. Ordinary callers were not switched. TCV3 observes
complete explicitly declared content ancestry under a separately selected pin
and the original finite session. These observations do not establish historical
authenticity, undeclared semantic dependencies, independent custody, current
FinalUse authority, public WAN safety, W1/DAA hardness, or whole-chain PQ safety.
The lifetime source lock covers twenty-one declared implementation files. This
direct inventory is partial; identity and execution checks over the complete
committed source do not prove complete transitive implementation coverage.

## Source identities

| Role | Commit | Meaning |
| --- | --- | --- |
| Historical #940 | `{BASE}` | Previous campaign source; its failures remain historical. |
| B | `{ingress['baseline_source']}` | Tests-only ingress source: 6 passed and 3 failed. |
| I | `{ingress['repair_source']}` | Ingress repair: the same 9 controls passed in each of two feature lanes. |
| R | `{r}` | Runtime source checkpoint before lifetime source-register metadata. |
| C | `{args.head}` | Actual committed source of the final native component batch. |
| E | This evidence-only child of C | Contains these records and additive corpus pins; no native rerun is attributed to E. |

C changes only the corpus and lifetime source metadata relative to its current R.
The ingress repair I is an ancestor of R; intermediate source changes keep their
own commits and application records. E changes
only this directory and additive corpus pins relative to C. The post-commit full
source/corpus/link/runtime checks and exact E identity are written to the external
finalizer output directory, so their creation cannot modify the committed E.
Before/after file observations do not authenticate a continuously running
executable. Historical and current observations retain their own source identities.

## Original failures and retained inputs

The archive contains every regular original file from the ingress baseline and
repair directory, dependency-fetch directory, application directory, and completed
validation directory, plus every supplied prior validation/application directory,
including unsuccessful command outputs. The ingress
baseline's three failing controls are preserved alongside the repaired 9 + 9.
No successful component result deletes or replaces an earlier failure.

The original C1 batch completed all 90 commands with **87 passing commands and
three failed commands**. Both DA libraries reported 733 passed and one failed
method, while all fifteen TCV3 methods passed in each lane. The checkpoint
copied-lease method failed in its original source. Its logs, original verdicts,
source/provider receipts, and original application records are kept separately
from the current batch. The first validator did not explicitly pin the CI thread
setting. The later harness choice and source changes do not establish that every
earlier failure was caused by scheduling, and do not rewrite that batch as passed.

| Prior archive namespace | Actual tested source | Original command verdicts | Operator interruptions |
| --- | --- | --- | --- |
{prior_rows}

The additional C2 source `{REQUIRED_INTERRUPTED_SOURCE}` retains its own complete
90-command validator record. Its default DA command was interrupted by the
operator with PID-bound SIGTERM after the separately retained join/accept wait
observation. The command returned -15 before its declared 1,800-second outer
timeout. Its partial default log has no completed libtest summary and no
successful TCV3 executions. This interruption is not recorded as a native
assertion failure or an automatically expired timeout. Other C2 command outcomes
come from their own original records; no aggregate C2 verdict is inferred from
this one stopped command. Operator intent, dispatch result, readonly process
snapshot and command-log hashes remain in the original validation directory
inside the archive. Their preservation does not independently prove a root cause
or revalidate a live process identity.

C2's other retained failures are separate: the all-features DA log reports
733 passed and one failed method with the error text `CacheWriterBusy`, and
`pq-native-41` remains a failed named control. The error name alone does not
establish writer contention or exclude original-deadline expiry. Only 62 of C2's
63 exact PQ commands have successful named-execution observations; later batch
successes do not rewrite that count or its original refusal.

The subsequent C3 source `{REQUIRED_C3_SOURCE}` and its original application from
R3 `{REQUIRED_C3_RUNTIME}` are also retained separately. Its complete
{c3_components['commands']}-command record contains {c3_components['passed_commands']}
passing commands and the original failed command labels {c3_failed_labels}.
The original validation receipt's byte length, SHA-256, exact failed-label roster
and full DA summaries are independently frozen in the retained finalizer.

| C3 original DA lane | Original complete summaries | Successful TCV3 executions |
| --- | --- | --- |
{c3_da_rows}

C3's original V4 rosters, CI thread settings, and recorded named outcomes are
checked against its own raw logs. Every original failed state remains in those
records. {c3_components['pq_successful_exact_executions']} of C3's 63 exact PQ
commands have successful named-execution observations. The current candidate's
all-pass requirements remain separate from these historical consistency checks.
Current successful results do not replace a C3 failure or prove its cause.

| Prior application namespace | Prior runtime checkpoint | Prior candidate |
| --- | --- | --- |
{prior_apply_rows}

The raw `validation.json` files remain byte-identical to their respective original
records. Their command counts and outcomes are never combined into a synthetic
successful batch. A prior application receipt describes source preparation only;
it does not itself assert successful native execution.

The nested historical compact archive is the reviewed 5,719-byte object with
SHA-256 `{HISTORICAL_SHA256}`. It includes the three original stderr logs, original
results and source receipts, provenance, and a derived summary. Its three campaign
invocations returned 101 on #940. This candidate has not rerun that campaign.
The original 70,260,101-byte zip and the three large raw report members are **not**
embedded in this compact package. Their retained provenance and individual hashes
identify [GitHub artifact 13922513442](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43161361291/artifacts/13922513442).
The original zip SHA-256 is
`c5aed8edbdfee0f34303895b552d6348d344b43ffe6e7672615e0726938f5d8f`.

## Archive verification

[original-files.json](original-files.json) records each original file's absolute
source path, archive member name, byte length, and SHA-256. The archive was read
back and every member checked against that roster. Input inventories were checked
again after archival. Tar metadata is normalized; every original file's content
is preserved byte for byte.

[archive-manifest.json](archive-manifest.json) lists the ordered archive parts and
their hashes. Concatenate parts in that exact order if the archive is split;
verify the resulting byte length and SHA-256 before reading the gzip/tar. Each
committed file is at most 4 MiB. The complete archive is {archive_manifest['archive']['bytes']}
bytes with SHA-256 `{archive_manifest['archive']['sha256']}`.

{archive_links}

No production configuration, test predicate, business budget, deadline, or
dependency graph is changed by this evidence commit. No push is performed by
the finalizer. The finalizer's own exact source is retained as
`tooling/executed-finalizer.py` inside the raw archive.
'''
        with (stage / 'README.md').open('xb') as stream:
            stream.write(readme.encode())
        staged_files = {EVIDENCE + '/' + path.name: read_original(path)
                        for path in sorted(stage.iterdir())}
        require(all(len(raw) <= MAX_FILE_BYTES for raw in staged_files.values()),
                'a generated evidence file exceeds the corpus reader limit')
        require(not (root / EVIDENCE).exists() and not (root / EVIDENCE).is_symlink(),
                'evidence destination already exists; refusing to overwrite or amend it')
        corpus_after = copy.deepcopy(corpus_before)
        for name, raw in staged_files.items():
            require(name not in corpus_after['pinned_blobs'] and name not in corpus_after['required_paths'],
                    'new evidence collides with an existing corpus entry: ' + name)
            corpus_after['pinned_blobs'][name] = git_blob(raw)
            corpus_after['required_paths'].append(name)
        require(all(corpus_after[key] == value for key, value in corpus_before.items()
                    if key not in ('pinned_blobs', 'required_paths'))
                and all(corpus_after['pinned_blobs'][name] == value
                        for name, value in corpus_before['pinned_blobs'].items())
                and corpus_after['required_paths'][:len(corpus_before['required_paths'])]
                == corpus_before['required_paths'], 'corpus update is not purely additive')
        corpus_after_raw = json_bytes(corpus_after)
        put(output / 'planned-repository-mutation.json', {
            'source_C': args.head, 'paths': sorted([CORPUS, *staged_files]),
            'new_evidence': {name: {'bytes': len(raw), 'sha256': sha_bytes(raw), 'git_blob': git_blob(raw)}
                             for name, raw in staged_files.items()},
            'corpus_before_sha256': sha_bytes(corpus_before_raw),
            'corpus_after_sha256': sha_bytes(corpus_after_raw),
            'existing_pins_unchanged': True})
        require(inventory(inputs, extras) == roster, 'original inputs changed before evidence publication')
        require(verify('head', args.head, None, None, root) == current_source,
                'C changed during evidence preparation')
        run('preflight-before-repository-mutation', ['bash', 'scripts/project-preflight.sh'])
        require(read_original(root / CORPUS) == corpus_before_raw, 'corpus changed before publication')
        (root / EVIDENCE).mkdir()
        for name, raw in staged_files.items():
            with (root / name).open('xb') as stream:
                stream.write(raw)
        with tempfile.NamedTemporaryFile(mode='wb', prefix='.pq-evidence-corpus-',
                                         dir=(root / CORPUS).parent, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(corpus_after_raw)
            stream.flush()
            os.fsync(stream.fileno())
        require(read_original(root / CORPUS) == corpus_before_raw, 'corpus changed during publication')
        os.replace(temporary, root / CORPUS)
        allowed = {CORPUS, *staged_files}
        dirty = set(git('diff', '--name-only', args.head).splitlines())
        dirty.update(git('ls-files', '--others', '--exclude-standard').splitlines())
        require(dirty == allowed, 'working tree changed outside the evidence-only scope')
        run('preflight-before-commit', ['bash', 'scripts/project-preflight.sh'])
        run('stage-evidence', ['git', 'add', '--', *sorted(allowed)])
        require(set(git('diff', '--cached', '--name-only').splitlines()) == allowed,
                'staged changes exceed the reviewed evidence scope')
        run('staged-whitespace', ['git', 'diff', '--cached', '--check'])
        require(git('rev-parse', 'HEAD') == args.head, 'HEAD changed before evidence commit')
        run('evidence-commit', ['git', 'commit', '-s', '-m',
                              'docs(pq): retain exact-source component observations and original failures'])
        e = git('rev-parse', 'HEAD')
        receipt['evidence_E'] = e
        put(output / 'evidence-commit-created.json', {
            'source_C': args.head, 'runtime_R': r, 'evidence_E': e,
            'post_commit_verification_completed': False})
        require(e != args.head and parents(e) == [args.head], 'E is not a direct evidence child of C')
        require(set(git('diff', '--name-only', args.head, e).splitlines()) == allowed,
                'E changes runtime or unexpected source')
        require('Signed-off-by: ' in git('show', '-s', '--format=%B', e), 'evidence commit lacks sign-off')
        require(blob(e, CORPUS) == corpus_after_raw, 'committed corpus differs from the reviewed addition')
        for name, raw in staged_files.items():
            require(blob(e, name) == raw, 'committed evidence differs: ' + name)
        tree_c = git('ls-tree', '-r', args.head).splitlines()
        tree_e = git('ls-tree', '-r', e).splitlines()
        def unchanged_entries(rows):
            return [row for row in rows if row.split('\t', 1)[1] != CORPUS
                    and not row.split('\t', 1)[1].startswith(EVIDENCE + '/')]
        require(unchanged_entries(tree_c) == unchanged_entries(tree_e),
                'C and E differ outside the evidence/corpus namespace')
        for path in GRAPH_PATHS:
            require(blob(BASE, path) == blob(args.head, path) == blob(e, path),
                    'post-commit dependency graph mismatch: ' + path)
        require(blob(e, BUDGET) == blob(args.head, BUDGET)
                and blob(e, SOURCE_LOCK) == blob(args.head, SOURCE_LOCK)
                and blob(e, ROOT_REGISTER) == blob(args.head, ROOT_REGISTER),
                'post-commit security qualification metadata changed')
        run('preflight-after-commit', ['bash', 'scripts/project-preflight.sh'])
        e_source = verify('head', e, None, None, root)
        put(output / 'source-E-before-checks.json', e_source)
        for label, command in (
            ('corpus-after-commit', ['python3', '-B', 'scripts/ci/check_pq_research_integration.py']),
            ('links-after-commit', ['python3', '-B', 'scripts/ci/check_repository.py']),
            ('native-inventory-after-commit', ['python3', '-B', 'scripts/refresh_distributed_source_inventory.py', '--check']),
            ('lifetime-after-commit', ['python3', '-B', 'scripts/ci/pq_lifetime_budget.py']),
            ('root-register-after-commit', ['python3', '-B', 'scripts/ci/pq_root_dependency_register.py']),
        ):
            run(label, command)
        after = verify('head', e, None, None, root)
        put(output / 'source-E-after-checks.json', after)
        require(after == e_source, 'E changed during post-commit readers')
        for path, pin in corpus_before['pinned_blobs'].items():
            require(git_blob(read_original(root / canonical_relative(path))) == pin,
                    'existing corpus pin changed after evidence commit: ' + path)
        receipt.update(completed=True, evidence_source=e_source,
                       all_existing_corpus_pins_unchanged=True,
                       runtime_and_dependency_graphs_unchanged=True,
                       original_files=len(roster), component_observations=components)
        print(json.dumps({'completed': True, 'source_C': args.head, 'runtime_R': r,
                          'evidence_E': e, 'qualification': 'HOLD', 'pushed': False}), flush=True)
    except BaseException as error:
        receipt['error'] = type(error).__name__ + ': ' + str(error)
        print(json.dumps({'completed': False, 'error': receipt['error'],
                          'evidence_E': receipt['evidence_E']}), flush=True)
        raise
    finally:
        # This receipt is deliberately external. Never amend E to insert its own hash.
        put(output / 'finalization.json', receipt)


if __name__ == '__main__':
    main()
