
#include <stddef.h>
#include <stdint.h>
extern void *__libc_calloc(size_t, size_t);
extern void __libc_free(void *);
static _Thread_local int active;
static _Thread_local uint64_t calls, fail_at, denied, alive, peak, invalid;
static _Thread_local void *owned[64];
void *calloc(size_t n, size_t m) {
    if (active) {
        calls++;
        if (calls == fail_at) { denied++; return NULL; }
    }
    void *p = __libc_calloc(n,m);
    if (active && p) {
        int saved=0;
        for (size_t i=0;i<64;i++) if (!owned[i]) {owned[i]=p;saved=1;break;}
        if (!saved) invalid++;
        alive++; if (alive>peak) peak=alive;
    }
    return p;
}
void free(void *p) {
    if (active && p) {
        int found=0;
        for (size_t i=0;i<64;i++) if (owned[i]==p) {owned[i]=NULL;found=1;break;}
        if (found) alive--; else invalid++;
    }
    __libc_free(p);
}
typedef uint64_t (*entry)(const void *, uint64_t, void *, uint64_t, void *, uint64_t);
uint64_t vault_fault_invoke(entry f,const void *in,uint64_t ni,void *out,uint64_t no,
                           void *scratch,uint64_t ns,uint64_t selected) {
    calls=denied=alive=peak=invalid=0;fail_at=selected;
    for (size_t i=0;i<64;i++) owned[i]=NULL;
    active=1;uint64_t result=f(in,ni,out,no,scratch,ns);active=0;return result;
}
uint64_t vault_fault_calls(void) {return calls;}
uint64_t vault_fault_denied(void) {return denied;}
uint64_t vault_fault_alive(void) {return alive;}
uint64_t vault_fault_peak(void) {return peak;}
uint64_t vault_fault_invalid(void) {return invalid;}
