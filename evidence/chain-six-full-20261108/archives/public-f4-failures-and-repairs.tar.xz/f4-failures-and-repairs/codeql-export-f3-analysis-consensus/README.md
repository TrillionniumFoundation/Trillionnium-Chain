# Original F3 CodeQL export refusal

The original CodeQL exporter remains **FAIL / incomplete**. This directory is a read-only diagnosis of [run 42518203708, job 128845846447](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42518203708/job/128845846447), not a new scan or a successful PR security verdict.

## Verified original observations

- Exporter source: `1a446a79700cc093a2b1a7f10367ef4a5ddbd680`; source before and after matched. Project audit and all 16 offline exporter controls passed.
- The existing command kept `--wait-seconds 1200 --poll-seconds 30` and exited 1. All **39** retained poll snapshots contained zero raw analyses and zero raw CodeQL checks for both the exact head and prospective merge. The 38 printed wait messages are followed by the final rejected snapshot.
- PR 821 was resolved correctly from the original `pull_request` event. An empty `EXPORT_PR_NUMBER` is normal for that code path, which reads the event's number.
- Original source tuple: head `1a446a79700cc093a2b1a7f10367ef4a5ddbd680`, base `7e044b65454f4c9ea505591727332acffb33e7e5`, prospective merge `24350527a77a3caee6f1e7a21973874664ab603f`.

## Source configuration and interpretation

The original PR targeted `fix/chain-p0-unified-qualification-20261108-99b5`. That branch does not match the explicit `codeql-real-exact-source.yml` PR base filter, which lists `main` and `fix/chain-six-axis-performance-20261103`. The head branch also does not match that workflow's push filter. The exporter workflow has no corresponding PR base filter.

The explicit analysis workflow deliberately specifies `upload: never` and retains local SARIF separately; its local artifacts cannot stand in for uploaded Code Scanning API analyses. The original PR was a draft, but this evidence does **not** establish draft status as the cause of the missing API data, nor establish why default setup supplied no exact-source result.

The exporter correctly requires nonempty exact-source checks and analyses in `snapshot()`, preserves intermediate snapshots, and refuses at its original deadline. No branch trigger, upload permission, empty-result requirement, stabilization requirement, or time limit was changed. No workflow or analysis producer was rerun. Missing data is not a PASS and is not a finding that the source is vulnerability-free.

## Retained material

The artifact was retrieved through normal read-only GitHub API calls. Artifact ID `13633451849` belongs to the original run and head. Its original ZIP is **216,774 bytes**, SHA256 `c681da51e41a4a76d753104a69c1421a9d7f992efde16301aa575b01be2ba429`; the ZIP contains 205 members, and every file listed in the original hash inventory matched. The ZIP digest also binds the inventory files themselves. The complete ZIP, original job log, metadata, selected original records, all-poll summary, exact F3 public scripts/workflows, and complete Runtime launch/terminal/stream records are retained.

`MANIFEST.json` binds the publication inputs by full byte counts and SHA256. Diagnosis and publication operations confer no independent authentication, production activation, or PR security-gate qualification.
