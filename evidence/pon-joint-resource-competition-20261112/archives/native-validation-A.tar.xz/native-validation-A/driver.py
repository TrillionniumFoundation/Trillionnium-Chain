#!/usr/bin/env python3
"""Exact-source native qualification; artifacts and mutable caches stay outside Git."""
import hashlib, json, os, pathlib, shutil, subprocess, sys, time, tomllib, traceback
ROOT=pathlib.Path("/home/qian-qi/work/chain-daa-resource-competition-20261112-600e")
OUT=pathlib.Path("/home/qian-qi/work/chain-daa-A-43e5c9d6-native-600e")
SUPPORT=pathlib.Path("/home/qian-qi/work/chain-daa-native-support-600e")
HEAD="43e5c9d6b668276d03e1c7a76f467ec211e1d7dc"
TREE="beac87c2431d149dbd6d2de4a2e1eaf0617520cc"
CARGO="/home/qian-qi/.cargo/bin/cargo"
PIN="603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a"
MIN_FREE=6*1024**3
started=time.time()
steps=[]
state={"schema":"trnm-native-daa-validation-status-v1","source_commit":HEAD,"source_tree":TREE,"state":"RUNNING","started_unix":started,"current_step":"initialization","commands_completed":0}
env=dict(os.environ)
overrides={"PATH":"/home/qian-qi/.cargo/bin:"+env.get("PATH","/usr/bin:/bin"),
"RUSTUP_TOOLCHAIN":"1.95.0","CARGO_HOME":str(SUPPORT/"cargo-home"),
"CARGO_TARGET_DIR":str(SUPPORT/"target"),"CARGO_BUILD_JOBS":"2","CARGO_INCREMENTAL":"0",
"CARGO_TERM_COLOR":"never","RUST_TEST_THREADS":"1","PYTHONDONTWRITEBYTECODE":"1",
"GIT_OPTIONAL_LOCKS":"0"}
env.update(overrides)
provider_before=None
def digest(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open("rb") as f:
  while b:=f.read(1024*1024): h.update(b)
 return h.hexdigest()
def identity(p):
 p=pathlib.Path(p)
 return {"path":str(p),"bytes":p.stat().st_size,"sha256":digest(p)}
def write_json(path,value):
 path=pathlib.Path(path); tmp=path.with_name(path.name+".tmp")
 tmp.write_text(json.dumps(value,sort_keys=True,indent=2)+"\n");tmp.replace(path)
def status(**values):
 state.update(values);state["updated_unix"]=time.time();state["disk_free_bytes"]=shutil.disk_usage(ROOT).free
 write_json(OUT/"status.json",state)
def run(name,argv,run_env=None):
 assert all(isinstance(x,str) for x in argv)
 status(current_step=name,commands_completed=len(steps))
 before=time.time(); out=OUT/(name+".stdout.log");err=OUT/(name+".stderr.log")
 with out.open("xb") as fo,err.open("xb") as fe:
  p=subprocess.Popen(argv,cwd=ROOT,env=env if run_env is None else run_env,stdout=fo,stderr=fe)
  status(current_pid=p.pid)
  while p.poll() is None:
   time.sleep(5)
   status(current_pid=p.pid)
 code=p.returncode
 row={"name":name,"argv":argv,"cwd":str(ROOT),"exit_code":code,"started_unix":before,
      "elapsed_wall_seconds":round(time.time()-before,3),"stdout":identity(out),"stderr":identity(err)}
 steps.append(row);write_json(OUT/"commands.json",steps)
 status(commands_completed=len(steps),last_completed=name,last_exit_code=code,current_pid=None)
 print(json.dumps({"step":name,"exit":code,"wall_seconds":row["elapsed_wall_seconds"]}),flush=True)
 return row
def must(row):
 if row["exit_code"] != 0: raise RuntimeError(row["name"]+" failed; original logs retained")
 return row
def guard(name):
 return run(name,["/usr/bin/python3","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",HEAD,"--output",str(OUT/(name+".json"))])
def require_space(stage):
 free=shutil.disk_usage(ROOT).free
 record={"stage":stage,"free_bytes":free,"minimum_start_free_bytes":MIN_FREE,"passed":free>=MIN_FREE}
 write_json(OUT/(stage+"-disk.json"),record)
 if free<MIN_FREE: raise RuntimeError(stage+": retained 6 GiB disk start guard failed")
def backend_identity():
 receipt=json.loads((OUT/"provider-preparation/pq-provider/provider.json").read_text())
 paths=[x["path"] for x in receipt["native_backend_inputs"] if x.get("available") is not False]
 return {"receipt":identity(OUT/"provider-preparation/pq-provider/provider.json"),"inputs":[identity(p) for p in paths]}
def seed_cache():
 home=SUPPORT/"cargo-home";home.mkdir()
 packages={}
 lock_receipts=[]
 for relative in ("trillionnium/Cargo.lock","tests/fuzz/Cargo.lock"):
  path=ROOT/relative;lock_receipts.append(identity(path))
  data=tomllib.loads(path.read_text())
  for item in data["package"]:
   if item.get("source","").startswith("registry+"):
    key=(item["name"],item["version"],item["source"])
    if key in packages and packages[key].get("checksum") != item.get("checksum"):
     raise RuntimeError("conflicting locked package checksums")
    packages[key]=item
 copied=[];missing=[];mismatch=[]
 shared=pathlib.Path("/home/qian-qi/.cargo/registry")
 indexes=sorted((shared/"index").glob("index.crates.io-*"))
 for source in indexes:
  if source.is_symlink() or not source.is_dir(): continue
  config=source/"config.json"
  if config.is_file():
   target=home/"registry/index"/source.name/"config.json"
   target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(config,target)
 for (name,version,source_url),item in sorted(packages.items()):
  if source_url!="registry+https://github.com/rust-lang/crates.io-index":
   missing.append({"name":name,"version":version,"reason":"registry requires locked fetch"});continue
  n=name.lower()
  rel="1/"+n if len(n)==1 else "2/"+n if len(n)==2 else "3/"+n[0]+"/"+n if len(n)==3 else n[:2]+"/"+n[2:4]+"/"+n
  for source in indexes:
   path=source/".cache"/rel
   if path.is_file() and not path.is_symlink():
    dest=home/"registry/index"/source.name/".cache"/rel
    dest.parent.mkdir(parents=True,exist_ok=True)
    if not dest.exists(): shutil.copy2(path,dest)
  accepted=False
  for cache in sorted((shared/"cache").glob("index.crates.io-*")):
   path=cache/(name+"-"+version+".crate")
   if not path.is_file() or path.is_symlink():continue
   actual=digest(path)
   if actual!=item.get("checksum"):
    mismatch.append({"path":str(path),"expected":item.get("checksum"),"actual":actual});continue
   dest=home/"registry/cache"/cache.name/path.name
   dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
   copied.append(identity(dest));accepted=True;break
  if not accepted:missing.append({"name":name,"version":version,"reason":"no checksum-matching cached archive"})
 write_json(OUT/"cache-seed.json",{"schema":"trnm-locked-cache-seed-v1","source_cache_read_only":True,"lockfiles":lock_receipts,"registry_packages":len(packages),"copied_archives":copied,"missing":missing,"rejected_mismatches":mismatch})
 return lock_receipts
def missing_dependency(row):
 text=pathlib.Path(row["stderr"]["path"]).read_text(errors="replace").lower()
 return any(x in text for x in ("no matching package named","failed to download","attempting to make an http request, but --offline was specified","failed to get","unable to update"))
def metadata(name,manifest,all_features=False):
 command=[CARGO,"metadata","--locked","--offline","--format-version","1","--manifest-path",manifest]
 if all_features:command.append("--all-features")
 result=run(name+"-initial",command)
 if result["exit_code"] and missing_dependency(result):
  fetched=run(name+"-locked-fetch",[CARGO,"fetch","--locked","--manifest-path",manifest])
  if fetched["exit_code"]==0:result=run(name+"-qualified",command)
 return result
receipt={"schema":"trnm-native-daa-validation-v1","source_commit":HEAD,"source_tree":TREE,
 "root":str(ROOT),"evidence_directory":str(OUT),"support_directory":str(SUPPORT),
 "started_unix":started,"result":"RUNNING","qualification_commands_locked_offline":True,
 "source_mutations_allowed":False,"production_activation":False,
 "physical_or_quantum_attack_qualification":False,"environment_overrides":overrides}
write_json(OUT/"receipt.json",receipt)
try:
 must(run("project-preflight",["/usr/bin/bash","scripts/project-preflight.sh"]))
 must(guard("source-before"))
 forbidden=[k for k in os.environ if k.startswith("CARGO_PROFILE_") or k in ("RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUSTC","RUSTDOC","CARGO_BUILD_TARGET")]
 write_json(OUT/"ambient-build-overrides.json",{"present_keys":forbidden})
 if forbidden:raise RuntimeError("unreviewed ambient build overrides")
 SUPPORT.mkdir()
 for relative in ("target","runner-temp"):
  (SUPPORT/relative).mkdir()
 write_json(SUPPORT/"owner.json",{"source_commit":HEAD,"source_tree":TREE,"root":str(ROOT),"task":"native-daa-qualification-600e"})
 require_space("initial")
 locks=seed_cache()
 receipt["lockfiles_before"]=locks
 for name,args in [
  ("rustc-version",["/home/qian-qi/.cargo/bin/rustc","--version","--verbose"]),
  ("cargo-version",[CARGO,"--version"]),
  ("rustfmt-version",["/home/qian-qi/.cargo/bin/rustfmt","--version"]),
  ("clippy-version",[CARGO,"clippy","--version"]),
  ("compiler-version",["/usr/bin/cc","--version"])]:
  must(run(name,args))
 fmt=run("format",[CARGO,"fmt","--manifest-path","trillionnium/Cargo.toml","--all","--","--check"])
 metadata_rows=[
  metadata("metadata-default","trillionnium/Cargo.toml"),
  metadata("metadata-all-features","trillionnium/Cargo.toml",True),
  metadata("metadata-fuzz","tests/fuzz/Cargo.toml")]
 receipt["metadata_final"]=[{"name":r["name"],"exit_code":r["exit_code"]} for r in metadata_rows]
 candidates=[
 "/tmp/chain-pq-fa62381e-provider/source-via-gh/openssl-3.5.9.tar.gz",
 "/tmp/chain-pq-fa62381e-provider/attempt-4-gh-source/runner/trnm-pq-provider-3.5.9.lcOEkd1h/openssl-3.5.9.tar.gz",
 "/home/qian-qi/.local/state/chain-dynamic-input-bound-20261110-685a/strict-clippy-pinned-provider-05/runner-temp/trnm-pq-provider-3.5.9.VnWmWr6N/openssl-3.5.9.tar.gz",
 "/home/qian-qi/work/chain-throughput-20261105-87309-pq-provider-v2/runner-temp/trnm-pq-provider-3.5.9.hDNl2Hst/openssl-3.5.9.tar.gz"]
 observations=[];selected=None
 for candidate in candidates:
  p=pathlib.Path(candidate)
  if not p.is_file() or p.is_symlink():
   observations.append({"path":candidate,"regular_available":False});continue
  item=identity(p);item["matches_expected_sha256"]=item["sha256"]==PIN;observations.append(item)
  if item["matches_expected_sha256"]:selected=candidate;break
 write_json(OUT/"provider-source-selection.json",{"expected_sha256":PIN,"candidates":observations,"selected":selected,"fallback":"exact repository script download" if selected is None else None})
 provider_env=dict(env)
 provider_env.update({"RUNNER_TEMP":str(SUPPORT/"runner-temp"),"GITHUB_ENV":str(OUT/"provider-environment.env"),"TRNM_CI_RECEIPT_DIR":str(OUT/"provider-preparation")})
 if selected:provider_env["TRNM_PQ_SOURCE_ARCHIVE"]=selected
 (OUT/"provider-environment.env").touch(exist_ok=False)
 require_space("provider")
 provider=run("provider-prepare",["/usr/bin/bash","scripts/ci/prepare_pq_provider.sh"],provider_env)
 must(provider)
 allowed={"OPENSSL_DIR","OPENSSL_STATIC","TRNM_PQ_OPENSSL","TRNM_PQ_OPENSSL_SHA256","TRNM_PQ_OPENSSL_VERSION","OPENSSL_CONF","OPENSSL_MODULES"}
 exports={}
 for line in (OUT/"provider-environment.env").read_text().splitlines():
  key,value=line.split("=",1)
  if key not in allowed or key in exports:raise RuntimeError("unexpected provider export")
  exports[key]=value
 if set(exports)!=allowed or exports["TRNM_PQ_OPENSSL_VERSION"]!="3.5.9" or exports["OPENSSL_STATIC"]!="1":raise RuntimeError("incomplete pinned provider exports")
 env.update(exports);overrides.update(exports)
 provider_before=backend_identity();write_json(OUT/"provider-before.json",provider_before)
 if digest(exports["TRNM_PQ_OPENSSL"])!=exports["TRNM_PQ_OPENSSL_SHA256"]:raise RuntimeError("provider executable export digest mismatch")
 must(run("provider-version",[exports["TRNM_PQ_OPENSSL"],"version","-a"]))
 must(run("provider-list",[exports["TRNM_PQ_OPENSSL"],"list","-providers"]))
 require_space("strict-clippy")
 clippy=run("strict-clippy",[CARGO,"clippy","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","--workspace","--all-targets","--all-features","--","-D","warnings"])
 require_space("native-four-tests")
 native_env=dict(env)
 native_env.update({"TRNM_JOINT_DAA_EVIDENCE_DIR":str(OUT/"joint-daa"),"TRNM_MONOTONE_DAA_EVIDENCE_DIR":str(OUT/"monotone-daa")})
 native=run("native-four-tests",[CARGO,"test","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","-p","trnm-pon-node","--test","daa_joint_consensus","--","--nocapture","--test-threads=1"],native_env)
 reports=[];reader_rows=[]
 if native["exit_code"]==0:
  for kind,report_name,reader,tester in (
   ("joint-daa","joint-daa.json","scripts/pon_joint_daa_reader.py","scripts/ci/test_pon_joint_daa_reader.py"),
   ("monotone-daa","monotone-daa.json","scripts/pon_monotone_daa_reader.py","scripts/ci/test_pon_monotone_daa_reader.py")):
   for backend in ("pnh1-authenticated","pgh2-growth"):
    raw=OUT/kind/backend
    original=identity(raw/report_name);reports.append(original)
    tag=kind+"-"+backend
    reader_rows.append(run(tag+"-reader",["/usr/bin/python3",reader,"--raw-dir",str(raw),"--expected-report-sha256",original["sha256"]]))
    reader_rows.append(run(tag+"-reader-controls",["/usr/bin/python3",tester,"--raw-dir",str(raw)]))
 receipt["reports"]=reports
 receipt["reader_final"]=[{"name":r["name"],"exit_code":r["exit_code"]} for r in reader_rows]
 receipt["gates"]={"format":fmt["exit_code"]==0,"locked_offline_metadata":all(r["exit_code"]==0 for r in metadata_rows),"pinned_provider":provider["exit_code"]==0,"strict_clippy":clippy["exit_code"]==0,"native_four_tests":native["exit_code"]==0,"four_full_readers_and_controls":len(reader_rows)==8 and all(r["exit_code"]==0 for r in reader_rows)}
 receipt["result"]="PASS" if all(receipt["gates"].values()) else "FAIL"
except Exception as error:
 receipt["result"]="FAIL";receipt["error"]=str(error)
 (OUT/"controller-error.log").write_text(traceback.format_exc())
finally:
 try:
  if provider_before is not None:
   provider_after=backend_identity();write_json(OUT/"provider-after.json",provider_after)
   receipt["provider_inputs_unchanged"]=provider_after==provider_before
   if not receipt["provider_inputs_unchanged"]:receipt["result"]="FAIL"
  lock_after=[identity(ROOT/p) for p in ("trillionnium/Cargo.lock","tests/fuzz/Cargo.lock")]
  receipt["lockfiles_after"]=lock_after
  receipt["lockfiles_unchanged"]=receipt.get("lockfiles_before")==lock_after
  if not receipt["lockfiles_unchanged"]:receipt["result"]="FAIL"
  source_after=guard("source-after")
  receipt["source_after_verified"]=source_after["exit_code"]==0
  if source_after["exit_code"]!=0:receipt["result"]="FAIL"
 except Exception as error:
  receipt["finalization_error"]=str(error);receipt["result"]="FAIL"
  (OUT/"finalization-error.log").write_text(traceback.format_exc())
 receipt["environment_overrides"]=overrides
 receipt["finished_unix"]=time.time();receipt["elapsed_wall_seconds"]=round(time.time()-started,3)
 receipt["command_count"]=len(steps);receipt["nonzero_observations"]=[{"name":s["name"],"exit_code":s["exit_code"]} for s in steps if s["exit_code"]]
 receipt["disk_free_bytes_after"]=shutil.disk_usage(ROOT).free
 write_json(OUT/"receipt.json",receipt)
 manifest=[]
 for p in sorted(OUT.rglob("*")):
  if p.is_file() and not p.is_symlink() and p.name not in ("manifest.json","status.json"):
   item=identity(p);item["path"]=str(p.relative_to(OUT));manifest.append(item)
 write_json(OUT/"manifest.json",{"schema":"trnm-native-daa-artifacts-v1","source_commit":HEAD,"files":manifest})
 status(state="COMPLETE",result=receipt["result"],current_step=None,current_pid=None,receipt_sha256=digest(OUT/"receipt.json"),manifest_sha256=digest(OUT/"manifest.json"))
 print(json.dumps({"result":receipt["result"],"receipt":str(OUT/"receipt.json"),"receipt_sha256":digest(OUT/"receipt.json"),"command_count":len(steps)}),flush=True)
sys.exit(0 if receipt["result"]=="PASS" else 1)
