"""Reproduce old consumer/producer split checks using fabricated tiny rows.

This is a source-bound regression observation, not model efficacy, independent
training provenance, forged owner authority, or a production reward exploit.
"""
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import sys
import tempfile

ROOT = Path('/workspace/scratch/51e4e62b58cf/chain')
FORMAL = ROOT / 'formal/pon-nakamoto-v1'
sys.path.insert(0, str(FORMAL))
from contract_wire import H, canonical
from evaluation_bundle import (CONTROL_ORDER, artifact_id, evaluate_bundle,
                               freeze_bundle, partition_manifest, verify_bundle)
from experiments.settle_model import verify_observation
from test_evaluation_bundle import model, rows

SOURCES = ['formal/pon-nakamoto-v1/' + name for name in (
    'evaluation_bundle.py', 'experiments/settle_model.py', 'experiments/model_loop.py',
    'model_contract.py', 'evaluation.py', 'contract_wire.py', 'ledger.py',
    'test_evaluation_bundle.py')]


def sources():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in SOURCES}


before = sources()
current = model(0)
candidate = model(0)
candidate['deltas'][0][1][-1] = 10
controls = {name: copy.deepcopy(current) for name in CONTROL_ORDER}
original = {name: rows(name) for name in ('train', 'calibration', 'evaluation_a', 'evaluation_b', 'consumer')}


def freeze(partitions):
    return freeze_bundle(source_commit='ab' * 20, round_number=1, parent_release='00' * 32,
                         current=current, candidate=candidate, controls=controls, partitions=partitions)


raw, expected = freeze(original)
observations = []
for name, field, omitted in (
        ('overlap-content', 'source_content_sha256', None),
        ('overlap-task', 'id', None),
        ('overlap-group', 'file', None),
        ('missing-train', None, 'train'),
        ('missing-consumer', None, 'consumer')):
    partitions = copy.deepcopy(original)
    bundle = json.loads(raw)
    if field is not None:
        partitions['train'][0][field] = partitions['evaluation_a'][0][field]
        try:
            freeze(partitions)
        except ValueError as error:
            producer = str(error)
        else:
            producer = 'accepted'
        bundle['partitions']['train'] = partition_manifest(partitions['train'])
    else:
        producer = 'valid-full-inputs-before-file-omission'
    supplied = canonical(bundle)
    digest = H('evaluation-bundle-v3', supplied).hex()
    observation = dict(case=name, producer=producer, mutated_partition='train' if field else None,
                       field=field, omitted=omitted,
                       expected_digest_source='test owner deliberately pins the new self-consistent bundle')
    try:
        checked = verify_bundle(supplied, digest)
    except ValueError as error:
        observation['consumer_bundle'] = str(error)
    else:
        observation['consumer_bundle'] = 'accepted'
        with tempfile.TemporaryDirectory(prefix='partition-counterexample-') as directory:
            folder = Path(directory)
            (folder / 'evaluation-bundle.json').write_bytes(supplied)
            (folder / 'model.json').write_bytes(canonical(candidate))
            for partition, data in partitions.items():
                if partition != omitted:
                    (folder / (partition + '.json')).write_bytes(canonical(data))
            reports = {}
            for partition in ('evaluation_a', 'evaluation_b'):
                output = folder / (partition + '-result.json')
                process = subprocess.run([
                    sys.executable, str(FORMAL / 'experiments/model_loop.py'),
                    '--mode', 'evaluate', '--tasks', str(folder / (partition + '.json')),
                    '--model', str(folder / 'model.json'),
                    '--evaluation-bundle', str(folder / 'evaluation-bundle.json'),
                    '--bundle-hash', digest, '--partition', partition,
                    '--calibration', str(folder / 'calibration.json'), '--out', str(output)],
                    capture_output=True, text=True, check=True, timeout=30, cwd=ROOT)
                reports[partition] = json.loads(output.read_bytes())
            report = dict(source='ab' * 20,
                          models=dict(artifact_hash=artifact_id(candidate), bytes=len(canonical(candidate))),
                          evaluation_bundle=digest, results=reports)
            (folder / 'report.json').write_text(json.dumps(report, sort_keys=True))
            try:
                retained, actual = verify_observation(folder, digest)
            except (ValueError, FileNotFoundError) as error:
                observation['settlement_consumer'] = type(error).__name__ + ': ' + str(error)
            else:
                observation['settlement_consumer'] = 'accepted'
                observation['candidate_matches'] = actual == candidate
                observation['primary_score'] = retained['results']['evaluation_a']['whole_gain']['score']
                observation['marginal_score'] = retained['results']['evaluation_a']['marginal'][0]['score']
                evaluated = evaluate_bundle(supplied, digest, partitions['evaluation_a'], 'evaluation_a',
                                            calibration_rows=partitions['calibration'])
                observation['public_reward_eligible'] = evaluated['public_reward_eligible']
    observations.append(observation)
after = sources()
result = dict(schema='evaluation-partition-counterexample-v1',
              source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
              source_files_sha256=before, source_files_unchanged=before == after,
              command=[sys.executable, str(Path(__file__).resolve())],
              fixture_scope='fabricated 24-row integer models; no training or independent custody claim',
              expected_digest_attack=False, production_reward_exploit=False,
              cases=observations)
print(json.dumps(result, indent=2, sort_keys=True))
if before != after:
    raise SystemExit('source changed during observation')
