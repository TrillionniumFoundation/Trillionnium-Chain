from pathlib import Path
import sys,json,hashlib,time,resource
root=Path('/home/qian-qi/work/chain-native-owned-append-f0-20261119-2e9b');out=root/'zip-parts-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);t=time.monotonic();c0=resource.getrusage(resource.RUSAGE_SELF)
receipt=json.loads((root/'collection/COLLECTION.json').read_text());assert receipt['complete_download'] is True and receipt['every_manifest_member_verified'] is True
raw=Path(receipt['artifact_zip']).read_bytes();assert len(raw)==18781500 and hashlib.sha256(raw).hexdigest()=='6f0550eff271a1f6b2328595cf75b2099b5b34963460df16bd7220412f84d46b'
parts=[]
for i,off in enumerate(range(0,len(raw),8000000)):
 part=raw[off:off+8000000];path=out/('f0-original.zip.part-'+str(i+1).zfill(2))
 with path.open('xb') as f:f.write(part)
 assert path.read_bytes()==part
 parts.append({'path':path.name,'absolute_path':str(path),'offset':off,'bytes':len(part),'sha256':hashlib.sha256(part).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(part)).encode()+b'\0'+part).hexdigest()})
assert b''.join(Path(p['absolute_path']).read_bytes() for p in parts)==raw
c=resource.getrusage(resource.RUSAGE_SELF);res={'schema':'chain-exact-original-provider-zip-parts-v1','head':'e8b0ec93ab6a6a1ff5e36cfcf9d1179e030a5975','run_id':44465153982,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'provider_digest_verified':True,'manifest_original_files':443,'full_zip_members':444,'parts':parts,'all_part_bytes_reassembled_to_original':True,'wall_seconds':time.monotonic()-t,'self_user_cpu_seconds':c.ru_utime-c0.ru_utime,'self_system_cpu_seconds':c.ru_stime-c0.ru_stime}
(out/'MANIFEST.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
