from pathlib import Path
import sys,json,hashlib,subprocess,importlib.util,contextlib,unittest,time,traceback,os,ast
root=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo");base=root.parent/"foundation-ci-proposal-v1";candidate=base/"candidate";out=base/"validation-v2";out.mkdir(mode=0o700)
(out/"driver.py").write_text(sys.argv[1]);started=time.monotonic_ns();report={"status":"FAIL","scope":"HELPER_AND_TRANSFER_CONTROLS","native_runtime_executed":False,"original_cargo_executed":False}
def need(v,m):
 if not v:raise ValueError(m)
def identity(p):
 raw=p.read_bytes();return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def load_module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
 if "." in name and name.rsplit(".",1)[0] in sys.modules:setattr(sys.modules[name.rsplit(".",1)[0]],name.rsplit(".",1)[1],mod)
 return mod
names=["hia/tools/qualify_foundation_ci.py","hia/tests/test_foundation_ci.py"];before={n:identity(candidate/n) for n in names}
try:
 pre=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=root,capture_output=True);(out/"preflight.stdout.raw").write_bytes(pre.stdout);(out/"preflight.stderr.raw").write_bytes(pre.stderr);need(pre.returncode==0,"Preflight failed")
 for name in names:ast.parse((candidate/name).read_text())
 os.chdir(root);sys.path.insert(0,str(root));import hia.tools,hia.tests
 ci=load_module("hia.tools.qualify_foundation_ci",candidate/"hia/tools/qualify_foundation_ci.py");ci.ROOT=root
 test=load_module("hia.tests.test_foundation_ci",candidate/"hia/tests/test_foundation_ci.py")
 modules=[test]
 for name in ("test_execution_ci","test_genesis_ci"):
  path=root/("hia/tests/"+name+".py")
  if path.exists():modules.append(load_module("hia.tests."+name,path))
 suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(m) for m in modules])
 report["modules"]=[m.__name__ for m in modules]
 with (out/"tests.stdout.raw").open("w") as stdout,(out/"tests.stderr.raw").open("w") as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
  result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(suite)
 report["tests"]={"run":result.testsRun,"failures":[[str(t),e] for t,e in result.failures],"errors":[[str(t),e] for t,e in result.errors],"skips":[[str(t),e] for t,e in result.skipped]}
 need(result.wasSuccessful() and not result.skipped,"Actual boundary controls failed")
 wrapper=out/"cli_loader.py"
 wrapper.write_text("from pathlib import Path\nimport sys,importlib.util\nroot=Path("+repr(str(root))+")\ncandidate=Path("+repr(str(candidate))+")\nsys.path.insert(0,str(root))\nimport hia.tools\nspec=importlib.util.spec_from_file_location('hia.tools.qualify_foundation_ci',candidate/'hia/tools/qualify_foundation_ci.py')\nm=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);setattr(hia.tools,'qualify_foundation_ci',m);m.ROOT=root\nraise SystemExit(m.main())\n")
 env={k:v for k,v in os.environ.items() if k not in ("PYTHONOPTIMIZE","TRNM_EXPECTED_SOURCE_SHA","GITHUB_RUN_ID","GITHUB_RUN_ATTEMPT","RUNNER_TEMP")}
 controls=[]
 for flag in ("-O","-OO"):
  command=[sys.executable,"-B",flag,str(wrapper),"unpack"]
  r=subprocess.run(command,cwd=root,env=env,capture_output=True,timeout=20)
  (out/("cli"+flag+".stdout.raw")).write_bytes(r.stdout);(out/("cli"+flag+".stderr.raw")).write_bytes(r.stderr)
  need(r.returncode!=0 and b"refuses optimized Python" in r.stderr,"Optimized public CLI did not refuse")
  controls.append({"argv":command,"exit":r.returncode,"actual_candidate_entry":True})
 report["public_cli_controls"]=controls
 report["source_after"]={n:identity(candidate/n) for n in names};need(report["source_after"]==before,"Candidate changed")
 source_before={n:identity(base/"baseline"/n) for n in names};need({n:identity(root/n) for n in names}==source_before,"Canonical c390 source changed")
 report.update(status="PASS",source_before=before,canonical_source_after="MATCH")
except BaseException as e:report["failure"]={"error":repr(e),"traceback":traceback.format_exc()};raise
finally:
 report["elapsed_ns"]=time.monotonic_ns()-started;(out/"report.json").write_text(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+"\n")
 print(json.dumps({"status":report["status"],"elapsed_ns":report["elapsed_ns"],"tests":report.get("tests"),"public_cli_controls":report.get("public_cli_controls"),"failure":report.get("failure")}),flush=True)
