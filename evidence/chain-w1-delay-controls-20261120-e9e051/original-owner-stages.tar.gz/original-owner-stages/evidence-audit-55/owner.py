from pathlib import Path
import json,sys,time,resource,hashlib,subprocess
root=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');out=root/'evidence-audit-55';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);t=time.monotonic();b=resource.getrusage(resource.RUSAGE_SELF);rows=[]
for p in sorted(root.iterdir()):
 if p.name in ('source','target') or p.is_symlink():continue
 if p.is_dir():
  files=[x for x in p.rglob('*') if x.is_file() and not x.is_symlink()];rows.append({'name':p.name,'files':len(files),'bytes':sum(x.stat().st_size for x in files),'latest_ns':max((x.stat().st_mtime_ns for x in files),default=0),'results':[str(x.relative_to(p)) for x in files if x.name in ('RESULT.json','READOUT.json','owner.error','error.log')]})
r={'directories':rows,'dirty_paths':subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root/'source',text=True).splitlines(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root/'source',text=True).strip()};raw=(json.dumps(r,indent=2)+'\n').encode();(out/'READOUT.json').write_bytes(raw);a=resource.getrusage(resource.RUSAGE_SELF);(out/'RESULT.json').write_text(json.dumps({'wall_seconds':time.monotonic()-t,'self_user_cpu_seconds':a.ru_utime-b.ru_utime,'self_system_cpu_seconds':a.ru_stime-b.ru_stime,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'child_cpu_for_readonly_git_unknown':True},indent=2)+'\n');print(json.dumps(r),flush=True)
