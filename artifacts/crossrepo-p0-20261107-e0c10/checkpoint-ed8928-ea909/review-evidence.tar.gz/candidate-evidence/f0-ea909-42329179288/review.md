# ea909 原 F0：完整六轮仍为 0/6

本次分析读取已经完成的 [F0 run 42329179288](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42329179288)，没有重新启动 campaign、改变预算或生成新的通过结果。实际 job 为 `128271490610`，artifact 为 `13557039238`。新源码的服务门仍失败。

## 固定源码、二进制和原分母

源码 before/after 都是 `ea909124cc460f364bd17b009073306014133f48`，tree `96712231eba3d333bdfebefa9c22c80ea1794d04`。保留二进制为 11,799,176 bytes，SHA256 `5386f8dce794a0843d27bf89075dab89b1c996fcde2515ee3e697b5c50f60361`；实际编译 profile 为 opt-level 3、test=true，前后观察与存档内容相符。

ZIP 为 16,600,732 bytes，SHA256 `1c9a21b4c476f870b93a96c8973f2f13f7a25a54f748304a3ec6c6cae272c4d3`。443 个 inventory 文件共 66,003,030 bytes，逐文件大小和 SHA256 全部一致。分析从当前 ea909 的真实源文件只提取两个纯报告 reader；它们独立重算出相同的六轮、42 项业务包暴露。原 source reader SHA256 为 `abf75f729dcb54d7c2bebf2c54c253c5164e801b7ebcc642bb8ba58290518cca`。

四秒 SLO 从原计划偏移 1、5、9 秒起算，包含排队和迟到；30 秒 phase 结束不是新的四秒起点。quarter CPU、2 GiB、零 swap、256 PIDs、24 个 ROOT 攻击者、原 1024 seed transfers、4 seed blocks、21 business blocks均保留。

| 阶段 | 计划轮数 | 实际进入 | 未进入，仍计失败 | 30 秒 phase 内确认 | 原四秒内确认 |
|---|---:|---:|---:|---:|---:|
| baseline | 3 | 2 | 1 | 1 | 0 |
| valid-work-root | 3 | 1 | 2 | 0 | 0 |
| 合计 | 6 | 3 | 3 | 1 | **0** |

baseline 第一轮从计划起点耗时 26.609530715 秒，在 phase 时钟 27.609530715 秒确认；因此它是一次真实但迟到的确认。第二轮到 phase 30.000855611 秒失败，第三轮没有进入。压力阶段第一轮到 30.007684843 秒未确认，后两轮没有进入。缺失项没有从分母删除。

## ACK 与历史同步分别核算

| 阶段 | 计划业务包 | 有尝试的包 | 总尝试 | phase 结束前 ACK | 原该轮四秒截止前 ACK | 未尝试 |
|---|---:|---:|---:|---:|---:|---:|
| baseline | 21 | 14 | 14 | 14 | 7 | 7 |
| valid-work-root | 21 | 4 | 15 | 3 | 1 | 17 |
| 合计 | 42 | 18 | 29 | 17 | 8 | 24 |

ACK 没有改记为独立确认。baseline 发出了 8 次实际 history 请求，网络层全部返回；前 7 页 ordinary import 成功，第 8 页以 `PUBLIC_REQUEST_DEADLINE` 失败。压力阶段没有进入 history 请求或 import；其零 CPU 不是零成本同步通过。

baseline 的所有 history network wall 合计 0.097878023 秒，client import wall 合计 24.210850959 秒，import thread CPU 为 5.385580827 秒。其中 83,539 次 Host 检查全部完成并接受，0 拒绝、0 未知时钟；嵌套 Host CPU 为 4.547923372 秒，约占 import CPU 的 84.446%。这两项是包含关系，不能相加。62 个 account_graph observer spans 也不能解释成 62 次已证明的完整图遍历。

两个阶段结束时 receiver 与 client 的最终 tip/state 不相等。第一轮迟到确认、部分历史导入成功和后续未同步状态均保持各自含义。

## 原攻击与资源成本

24/24 个攻击 actor ready，保留 386 次调用：206 个实际签名 ROOT 拒绝、128 个 EAGAIN、51 个 FRAME_DEADLINE、1 个 PUBLIC_CLIENT_DEADLINE。actor 报告没有 cap 或 parent kill。接收端保留 baseline 22 条、压力阶段 401 条连接观察，0 丢弃、0 measurement failure。

压力阶段 15 次诚实尝试中的 grant wait 为 1.010225236–1.496469061 秒；已知的 paid-task queue wait 为 0.314209077–0.580448044 秒。一个缺失 queue clock 保持未知。10 条 dispatch 记录以 `PUBLIC_REQUEST_CANCELLED` 结束；不能将后来已经取消的工作当成成功交付。

baseline 的实际 cgroup CPU 增量为 8.392609 秒，346 个 period 中 332 个被 throttle；压力阶段为 8.989961 秒，360 个 period 中 359 个被 throttle。这些 cgroup 增量包含各自的 setup/shutdown，不能当作纯 import CPU。两个阶段最小采样 paid credit 分别为 1,980,762,000 ns 和 1,981,711,602 ns，均未出现真实 credit depletion。物理 CPU 配额与逻辑 paid credit 是不同观察，服务失败不等于原 genuine-depletion 条件通过。

真实 producer preparation 另有 2.464425241 秒 CPU、2.500838873 秒 wall，范围是签名、Node 搜索尝试、执行和 durable reference preparation；其 Node 搜索分母在原报告中不可用，未补造。网络 calling-process CPU、import thread CPU、receiver dispatch 和嵌套 stage 时钟不混加。

## 结论与边界

原 reader 给出的失败仍是 `BASELINE_MUST_PASS` / `NATIVE_F0_FAILED`。finalizer 已确认全部本次拥有的服务为空；失败来自原服务条件，没有把清理错误当作服务缺口的替代解释。

本次只有内部原始证据审读，没有外部独立验收。与 9f 的不同确认数、耗时和 CPU 不能单独证明修复造成性能收益：两次不是同一物理运行，也没有受控因果实验。当前 source 的 F0 门为 **HOLD / 0 of 6**，还不能关闭原四秒端到端确认及历史同步要求。

可复核文件：[summary.json](summary.json)、[analysis.json](analysis.json)、[analysis-receipt.json](analysis-receipt.json)、[analysis-identity-diff.patch](analysis-identity-diff.patch)。完整原始 ZIP 由上述 GitHub run/artifact ID 和 SHA256 标识。
