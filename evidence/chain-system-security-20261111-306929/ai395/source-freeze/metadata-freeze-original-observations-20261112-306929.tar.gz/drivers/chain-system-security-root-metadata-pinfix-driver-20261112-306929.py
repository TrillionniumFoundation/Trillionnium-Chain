import datetime,hashlib,json,os,pathlib,subprocess,sys,time,traceback
R=pathlib.Path('/home/qq/chain-system-security-20261112-306929')
O=pathlib.Path('/home/qq/chain-system-security-native-receipts-20261112-306929/root-metadata-freeze-f21')
BASE='813620f387199bef3eae2493e2af07c70444db58'
OLD='7f83ea843d6d1578a475a7a0c4dc026da564a795'
LOCK='3eef9a9a1431914cae0f25f49a009a6103cf30caf0bc5f189918ad71fe91b71d'
OLD_LOCK='f7454a2cc0e38d0bb243d6ec56419a7bc3386108f0e5dfb2baf810f5be02e17f'
O.mkdir(parents=True,exist_ok=False)
E=dict(os.environ)
TC=pathlib.Path('/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu')
E.update(PATH=str(TC/'bin')+':'+E.get('PATH','/usr/bin:/bin'),RUSTC=str(TC/'bin/rustc'),LD_LIBRARY_PATH=str(TC/'lib'),CARGO_HOME='/home/qq/.cargo',CARGO_TARGET_DIR=str(R/'trillionnium/target'),CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1',PYTHONPATH=str(R/'scripts/ci'))
records=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def put(p,s): (R/p).write_text(s)
def jsonout(name,value):
 with (O/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def command(name,argv,expected=0):
 start=time.monotonic()
 with (O/(name+'.stdout.log')).open('xb') as stdout,(O/(name+'.stderr.log')).open('xb') as stderr:
  p=subprocess.run(argv,cwd=R,env=E,stdout=stdout,stderr=stderr)
 row={'name':name,'argv':argv,'cwd':str(R),'exit_code':p.returncode,'expected_exit_code':expected,'elapsed_seconds':time.monotonic()-start,'logs':[]}
 for suffix in ['stdout.log','stderr.log']:
  f=O/(name+'.'+suffix);b=f.read_bytes();row['logs'].append({'path':f.name,'bytes':len(b),'sha256':sha(b)})
 records.append(row);jsonout(name+'.json',row)
 print(json.dumps({'name':name,'exit_code':p.returncode,'elapsed_seconds':row['elapsed_seconds']}),flush=True)
 assert p.returncode==expected,(name,p.returncode,expected)
 return row
try:
 parent='f21d6be70d8880a4a81c00902fdaee1897a06e31'
 assert git('rev-parse','HEAD').decode().strip()==parent
 assert git('rev-parse','HEAD^').decode().strip()==BASE
 assert not git('status','--porcelain=v1')
 command('preflight',['bash','scripts/project-preflight.sh'])
 manifest_path='config/pon/pq-cross-branch-corpus-v1.json'
 original=git('show',parent+':'+manifest_path)
 assert (R/manifest_path).read_bytes()==original
 m=json.loads(original)
 expected={
 'config/pon/pq-authority-effects-v1.json':'7779393c9919bf66eedc155c604a5d658adb72db',
 'scripts/ci/pq_authority_effect_register.py':'c387c55c920707f803408b8543a02aa215263339',
 'scripts/ci/test_pq_authority_effect_register.py':'6cb38de367e34bd31c9a4aece39467976a2382a7',
 'docs/security/PQ_AUTHORITY_EFFECT_REGISTER_V1.md':'cc1085716b5d0b77541440952171827f2d54cf9c',
 'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md':'4769c2ed7ab47f60b84f8cf281114e6098e6b6ff'}
 assert len(m['pinned_blobs'])==1162
 review=[]
 for path,old_blob in expected.items():
  assert m['pinned_blobs'][path]==old_blob
  raw=git('show',parent+':'+path);assert (R/path).read_bytes()==raw
  blob=git('rev-parse',parent+':'+path).decode().strip()
  assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
  assert blob!=old_blob
  m['pinned_blobs'][path]=blob
  review.append({'path':path,'prior_blob':old_blob,'reviewed_blob':blob,'sha256':sha(raw),'bytes':len(raw),'source_commit':parent})
 old=json.loads(original)
 assert len(m['pinned_blobs'])==len(old['pinned_blobs'])
 assert all(m[k]==old[k] for k in m if k!='pinned_blobs')
 assert all(v==old['pinned_blobs'][p] for p,v in m['pinned_blobs'].items() if p not in expected)
 put(manifest_path,json.dumps(m,indent=2,sort_keys=True)+'\n')
 jsonout('pin-update-review.json',{'schema':'trnm-reviewed-metadata-corpus-pin-update-v1','reviewed_metadata_commit':parent,'runtime_review_base':BASE,'only_reviewed_metadata_paths_changed':review,'unchanged_other_pins':1162-len(expected),'original_failure_receipt':'../root-metadata-freeze-813/freeze-failure.json','preserved_required_paths':len(m['required_paths']),'native_tests_executed':False,'status':'HOLD'})
 command('metadata-diff-check',['git','diff','--check','--',manifest_path])
 command('reviewed-corpus-before-commit',['python3','scripts/ci/check_pq_research_integration.py'])
 command('commit-preflight',['bash','scripts/project-preflight.sh'])
 command('metadata-add',['git','add','--',manifest_path])
 command('metadata-commit',['git','-c','user.name=Codex','-c','user.email=codex@openai.com','commit','-s','-m','chore(security): retain reviewed metadata in the complete source corpus'])
 head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
 assert git('rev-parse','HEAD^').decode().strip()==parent and not git('status','--porcelain=v1')
 sys.path.insert(0,str(R/'scripts/ci'))
 from verify_ci_source import verify
 before=verify('head',head,root=R);jsonout('source-before-gates.json',before)
 command('authority-current',['python3','scripts/ci/pq_authority_effect_register.py'])
 command('root-current',['python3','scripts/ci/pq_root_dependency_register.py'])
 command('corpus-current',['python3','scripts/ci/check_pq_research_integration.py'])
 command('authority-and-root-controls',['python3','-m','unittest','test_pq_authority_effect_register','test_pq_root_dependency_register','test_run_pq_root_witness_v5','-v'])
 command('source-rejection-controls',['python3','scripts/ci/test_ci_source_integrity.py'])
 command('repository-links',['python3','scripts/ci/check_repository.py'])
 command('cargo-format',[str(TC/'bin/cargo'),'fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'])
 command('locked-default-graph',[str(TC/'bin/cargo'),'metadata','--locked','--manifest-path','trillionnium/Cargo.toml','--format-version','1'])
 command('locked-all-features-graph',[str(TC/'bin/cargo'),'metadata','--locked','--manifest-path','trillionnium/Cargo.toml','--all-features','--format-version','1'])
 after=verify('head',head,root=R);jsonout('source-after-gates.json',after);assert before==after
 bundle=O/'combined-metadata-from-813.bundle'
 command('metadata-bundle',['git','bundle','create',str(bundle),'HEAD','^'+BASE])
 command('metadata-bundle-verify',['git','bundle','verify',str(bundle)])
 b=bundle.read_bytes()
 result={'schema':'trnm-combined-metadata-freeze-v1','head':head,'tree':tree,'base':BASE,'clean':not git('status','--porcelain=v1'),'full_source_before_after_equal':before==after,'source_before':before,'source_after':after,'commands':records,'bundle':str(bundle),'bundle_bytes':len(b),'bundle_sha256':sha(b),'native_tests_executed':False,'status':'HOLD','production_activation':False}
 jsonout('freeze-result.json',result)
 print(json.dumps({'head':head,'tree':tree,'source_verified':True,'bundle':str(bundle),'bytes':len(b),'sha256':sha(b),'receipt':str(O/'freeze-result.json')}),flush=True)
except BaseException as error:
 failure={'error_type':type(error).__name__,'error':str(error),'traceback':traceback.format_exc(),'commands':records,'status':'HOLD','native_tests_executed':False}
 try:failure['current_head']=git('rev-parse','HEAD').decode().strip()
 except BaseException:pass
 jsonout('freeze-failure.json',failure)
 raise
