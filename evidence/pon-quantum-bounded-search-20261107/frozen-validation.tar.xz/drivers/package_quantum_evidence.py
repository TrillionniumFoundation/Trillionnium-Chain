#!/usr/bin/env python3
"""Package retained observations without rerunning or relabelling them."""
from pathlib import Path
import hashlib
import io
import json
import re
import shutil
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/c9b48df754d6')
REPO = ROOT / 'chain-quantum-next'
DEST = REPO / 'evidence/pon-quantum-bounded-search-20261107'
HEAD = 'aa46f28505ac6d7cf4bb9830db043510a5aac3e2'
TREE = '9ba43628c3004950f4d79392301dba306adb5a1f'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def json_bytes(data):
    return (json.dumps(data, indent=2, sort_keys=True) + '\n').encode()


def collect(directory, prefix):
    rows = {}
    for path in sorted(directory.rglob('*')):
        if path.is_symlink():
            raise ValueError('SYMLINK_IN_EVIDENCE:' + str(path))
        if path.is_file() and path.suffix != '.download':
            rows[prefix + '/' + str(path.relative_to(directory))] = path.read_bytes()
    return rows


def archive(name, rows, scope):
    manifest = {
        'schema': 'trnm-evidence-archive-members-v1',
        'scope': scope,
        'self_excluded': 'MEMBERS.json',
        'files': {k: {'bytes': len(v), 'sha256': sha(v)} for k, v in sorted(rows.items())},
    }
    rows = {**rows, 'MEMBERS.json': json_bytes(manifest)}
    path = DEST / name
    with tarfile.open(path, 'w:xz', preset=6) as stream:
        for key, raw in sorted(rows.items()):
            info = tarfile.TarInfo(key)
            info.size, info.mtime, info.mode = len(raw), 0, 0o644
            stream.addfile(info, io.BytesIO(raw))
    with tarfile.open(path, 'r:xz') as stream:
        assert set(stream.getnames()) == set(rows)
        for key, raw in rows.items():
            assert stream.extractfile(key).read() == raw
    return {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()),
            'members': len(rows), 'scope': scope}


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True).strip() == TREE
    frozen = ROOT / 'validation-frozen'
    development = ROOT / 'validation-next'
    groups = {}
    for group in ('quantum', 'repository', 'campaign', 'rust'):
        base = frozen / group
        before = json.loads((base / 'source-before.json').read_text())
        assert before == json.loads((base / 'source-after.json').read_text())
        assert before['head'] == HEAD and before['tree'] == TREE
        commands = json.loads((base / 'commands.json').read_text())
        for row in commands:
            assert sha((base / row['log']).read_bytes()) == row['sha256']
        groups[group] = json.loads((base / 'result.json').read_text())
    assert groups['rust']['status'] == 'FAIL'
    assert all(groups[x]['status'] == 'PASS' for x in ('quantum', 'repository', 'campaign'))
    counts = []
    for index in range(6):
        matches = re.findall(r'^Ran (\d+) tests? in ', (frozen / 'quantum' / f'{index:02d}.log').read_text(), re.M)
        assert len(matches) == 1
        counts.append(int(matches[0]))
    assert counts == [153, 105, 17, 11, 36, 19] and sum(counts) == 341
    supplemental = json.loads((development / 'fuzz-locked-metadata/fuzz-metadata-supplemental.json').read_text())
    assert supplemental['result'] == 'PASS'
    assert supplemental['source_before'] == supplemental['source_after']
    assert supplemental['source_before']['tested_commit'] == HEAD
    assert supplemental['original_failure']['original_log_and_result_unchanged']
    for key, expected in supplemental['artifacts_sha256'].items():
        assert sha((development / 'fuzz-locked-metadata' / key).read_bytes()) == expected
    for name in ('frozen-22', 'frozen-10'):
        receipt = json.loads((development / 'bounded-independent' / name / 'receipt.json').read_text())
        assert receipt['exit_code'] == 0 and receipt['source_stable']
        for side in ('before', 'after'):
            assert receipt[side]['head'] == HEAD and receipt[side]['tree'] == TREE
        for kind in ('stdout', 'stderr'):
            ext = 'json' if kind == 'stdout' else 'txt'
            assert sha((development / 'bounded-independent' / name / (kind + '.' + ext)).read_bytes()) == receipt[kind + '_sha256']
    campaign = (frozen / 'campaign/campaign.json').read_bytes()
    review = json.loads((development / 'bounded-independent/campaign_summary_review.json').read_text())
    assert sha(campaign) == review['input_sha256']
    assert review['run_count'] == 16 and review['completed_grover_iterations_all_runs'] == 0
    assert review['online_proofs_generated'] == review['native_blocks_admitted'] == 0
    DEST.mkdir(parents=True, exist_ok=True)
    (DEST / 'campaign.json').write_bytes(campaign)

    frozen_rows = collect(frozen, 'frozen-validation')
    frozen_rows.update(collect(development / 'fuzz-locked-metadata', 'supplemental/fuzz-locked-metadata'))
    for name in ('frozen-22', 'frozen-10'):
        frozen_rows.update(collect(development / 'bounded-independent' / name, 'supplemental/bounded-independent/' + name))
    for path in sorted((development / 'bounded-independent').glob('campaign_summary_review.*')):
        frozen_rows['supplemental/bounded-independent/' + path.name] = path.read_bytes()
    for name in ('independent_driver.py', 'constructed_driver.py'):
        frozen_rows['supplemental/bounded-independent/' + name] = (development / 'bounded-independent' / name).read_bytes()
    frozen_rows['drivers/run_frozen_validation.py'] = (ROOT / 'run_frozen_validation.py').read_bytes()
    frozen_rows['drivers/package_quantum_evidence.py'] = Path(__file__).read_bytes()
    frozen_archive = archive('frozen-validation.tar.xz', frozen_rows,
        'Actual observations at aa46f285; original Rust aggregate FAIL retained alongside separate cache-repaired metadata PASS. Downloaded crate bytes excluded; official URLs and lock checksums retained.')

    development_rows = collect(development, 'development-observations')
    development_rows = {k: v for k, v in development_rows.items() if not any(part in k for part in (
        '/fuzz-locked-metadata/', '/bounded-independent/frozen-22/',
        '/bounded-independent/frozen-10/', '/bounded-independent/campaign_summary_review.'))}
    development_archive = archive('development-observations.tar.xz', development_rows,
        'Original failures, development controls and repeated observations with their original source identities. prepared-frozen-* scripts are plans, not evidence of execution. constructed-01 and constructed-02 both used the same post-fix physical-model source and are repeats of ten control groups.')

    qualification = {
        'schema': 'trnm-w1-bounded-search-qualification-v1',
        'status': 'Draft / HOLD',
        'base_source': '7a98f27f99abccc28da2f1f3cc60bdaa2eca4890',
        'frozen_source': groups['quantum']['source'],
        'source_scope': 'Tests and campaign refer to the exact implementation commit; the later evidence-only commit is not represented as a fresh execution of these suites.',
        'local_lint_environment': {
            'cargo': (frozen / 'rust/01.log').read_text().strip(),
            'rustc': (frozen / 'rust/02.log').read_text().strip(),
            'openssl': (frozen / 'rust/03.log').read_text().strip(),
            'debug_symbols': False, 'cargo_incremental': False,
            'cargo_build_jobs': 2,
            'target_directory': '/workspace/scratch/c9b48df754d6/target',
            'runtime_or_provider_parity_claimed': False,
        },
        'validation': {
            'original_groups': groups,
            'quantum_test_counts': dict(zip(['quantum', 'w1', 'reversible_components', 'fast_daa', 'parallel_variable_ohie', 'bounded_campaign'], counts)),
            'quantum_tests_total': 341,
            'source_integrity_negative_tests': 43,
            'ci_contract_tests': 106,
            'pq_integration_tests': 38,
            'pq_corpus_source_pins': 688,
            'strict_clippy_workspace_all_targets_all_features_warnings_denied': 'PASS',
            'cargo_fmt': 'PASS',
            'main_full_locked_offline_metadata': 'PASS',
            'fuzz_metadata_initial': 'FAIL: missing exact local crates',
            'fuzz_metadata_supplemental': {'status': 'PASS', 'packages': 149, 'registry_packages': 136,
                'lockfile_changed': False, 'shared_cache_changed': False, 'compilation_or_fuzz_execution': False,
                'receipt': 'frozen-validation.tar.xz:supplemental/fuzz-locked-metadata/fuzz-metadata-supplemental.json'},
            'independent_frozen_controls': {'bounded_controls': 22, 'constructed_control_groups': 10,
                'add_to_unit_test_total': False, 'source_files_checked_before_after': 255},
            'independent_development_controls': {'full_state_amplitude_comparisons': 120, 'horizon_ledger_cases': 137,
                'counted_as_frozen_execution': False},
            'full_rust_runtime_test_suite_executed': False,
            'remote_ci_execution_claimed': False,
        },
        'campaign': {
            'file': 'campaign.json', 'bytes': len(campaign), 'sha256': sha(campaign),
            'groups': review['groups'], 'run_count': 16,
            'model_deliveries_using_q_zero': 8,
            'first_iteration_censored_runs': 4,
            'empty_domain_schedule_exhausted_runs': 4,
            'completed_model_measurement_batches': 24,
            'completed_model_candidate_checks': 84,
            'completed_grover_iterations': 0,
            'online_proofs_generated': 0, 'native_blocks_admitted': 0,
            'interpretation_limits': review['interpretation_limits'],
        },
        'qualification': {
            'constructed_fixed_context_cost_binding_implemented': True,
            'generic_complete_quantum_cost': None,
            'quantum_work_lower_bound_proved': False,
            'quantum_mining_qualified': False,
            'physical_clocks_measured': False,
            'full_machine_error_accounting_complete': False,
            'quantum_hardware_executed': False,
            'external_schedule_precommitment_attested': False,
            'native_service_acceptance_profile_satisfied': False,
            'profitable_executable_quantum_fork_attack_demonstrated': False,
            'mixed_quantum_classical_consensus_security_proved': False,
            'production_activation': False,
        },
        'remaining_work': [
            'Calibrate physical, controller, loading, measurement, proof and propagation costs and complete machine-level error accounting.',
            'Evaluate economical alternative legal W1 implementations, preprocessing reuse and equal real resource budgets; a constructed upper bound is not an attacker lower bound.',
            'Connect native-valid, costed adversarial Bailey-Sattath-style schedules to dynamic DAA, timestamps, forks and competing quantum/classical miners.',
            'Develop a justified mixed quantum/classical consensus security argument; failed attack reproduction and slow illustrative circuits do not establish security.',
        ],
        'archives': {'frozen-validation.tar.xz': frozen_archive, 'development-observations.tar.xz': development_archive},
    }
    (DEST / 'qualification.json').write_bytes(json_bytes(qualification))
    print(json.dumps({'packaged': str(DEST), 'archives': qualification['archives'], 'quantum_tests': 341, 'campaign_sha256': sha(campaign)}))


if __name__ == '__main__':
    main()
