from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,sys,traceback
root=Path('/home/qq/chain-system-security-20261112-306929')
expected='bac6b7659bd7e2d633e25c2da0add60f6a10c7fb'
campaign=root/'trillionnium/target/chain-system-security-receipts/incentives-bac6b7659bd7-20261112-v1'
preparation=json.loads((campaign/'python-pinned/preparation-terminal.json').read_bytes())
native=json.loads((campaign/'terminal.json').read_bytes())
configuration=json.loads((campaign/'configuration.json').read_bytes())
assert preparation['ready'] is True and native['command_campaign_passed'] is True
assert preparation['source_commit']==native['source_commit']==configuration['source_commit']==expected
python=preparation['python']
env=dict(os.environ,**configuration['environment'],GIT_OPTIONAL_LOCKS='0',GIT_TERMINAL_PROMPT='0')
env['PYTHONPATH']=str(root/'formal/pon-nakamoto-v1')
env['PATH']=str(Path(python).parent)+os.pathsep+env.get('PATH','')
def git(*args):return subprocess.check_output(['git',*args],cwd=root,env=env).decode().strip()
assert git('rev-parse','HEAD')==expected and git('status','--porcelain')==''
subprocess.run(['bash','scripts/project-preflight.sh'],cwd=root,env=env,check=True)
out=campaign/'python-pinned/checks'
out.mkdir()
(out/'started.json').write_text(json.dumps({'source_commit':expected,'native_run_id':native['run_id'],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_tests_started':False,'pid':os.getpid()},sort_keys=True,indent=2)+'\n')
results=[]
def inputs():
 rows=[]
 for path in sorted((campaign/'vectors').iterdir()):
  assert path.is_file() and not path.is_symlink()
  raw=path.read_bytes();value=json.loads(raw)
  assert value['run_id']==native['run_id']
  rows.append({'path':path.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'kind':value['kind'],'name':value['name'],'run_id':value['run_id'],'arithmetic_case_count':len(value['native']['cases']) if value['kind']=='arithmetic' else None})
 assert len(rows)==13 and len({row['path'] for row in rows})==13
 return rows
before=inputs()
(out/'native-inputs-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
for row in json.loads((campaign/'helper-provenance.json').read_bytes()):
 assert hashlib.sha256((campaign/'helpers'/row['name']).read_bytes()).hexdigest()==row['sha256']
split_hash_before=hashlib.sha256((campaign/'native-split.json').read_bytes()).hexdigest()
def run(name,argv,count=None):
 command=[python,str(campaign/'helpers/run_incentive_check.py'),'--name',name,'--repo',str(root),'--output',str(out),'--',*argv]
 process=subprocess.run(command,cwd=root,env=env)
 receipt=json.loads((out/(name+'.receipt.json')).read_bytes())
 row={'name':name,'argv':argv,'exit_code':process.returncode,'receipt':name+'.receipt.json'}
 results.append(row)
 assert process.returncode==receipt['exit_code']==0,name+' failed'
 assert receipt['source_commit_before']==receipt['source_commit_after']==expected
 assert receipt['source_status_before']==receipt['source_status_after']==''
 if count is not None:
  raw=(out/(name+'.stderr.log')).read_text()
  counts=[int(value) for value in re.findall(r'^Ran ([0-9]+) tests? in ',raw,re.M)]
  assert counts==[count] and re.search(r'^OK$',raw,re.M),name+' missing expected Python results'
  row['python_test_count']=count
 print(json.dumps(row,sort_keys=True),flush=True)
failed=None;same_source=False;after=[]
try:
 run('versions',[python,'-c','import json,sys,numpy,cryptography;assert numpy.__version__=="1.26.4";assert cryptography.__version__=="50.0.2";print(json.dumps({"python":sys.version,"executable":sys.executable,"numpy":numpy.__version__,"cryptography":cryptography.__version__},sort_keys=True))'])
 run('composition-oracle',[python,'formal/pon-nakamoto-v1/test_model_composition_oracle.py','-v'],8)
 run('composition-native-python',[python,'formal/pon-nakamoto-v1/test_model_composition.py','-v'],5)
 run('split-independent',[python,str(campaign/'helpers/verify_incentive_split_receipt.py'),'--repo',str(root),'--receipt',str(campaign/'native-split.json')])
 checked=json.loads((out/'split-independent.stdout.log').read_bytes())
 assert checked['result']=='COUNTEREXAMPLE_REPRODUCED' and checked['observations']['alias_net_account_increase']==26814
 run('split-independent-mutations',[python,str(campaign/'helpers/check_receipt_mutations.py'),'--repo',str(root),'--receipt',str(campaign/'native-split.json')])
 controls=json.loads((out/'split-independent-mutations.stdout.log').read_bytes())
 assert controls['all_rejected'] is True and len(controls['controls'])==6 and all(row['rejected'] is True for row in controls['controls'])
 after=inputs()
 assert before==after
 assert hashlib.sha256((campaign/'native-split.json').read_bytes()).hexdigest()==split_hash_before
except BaseException as error:
 failed={'class':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
 (out/'native-inputs-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
 baseline=json.loads((campaign/'source-before.json').read_bytes())
 checks=[];missing=[];mismatches=[]
 for row in baseline['checks']:
  path=root/row['path']
  if row['mode']=='120000':
   if not path.is_symlink():missing.append(row['path']);continue
   raw=os.fsencode(os.readlink(path))
  else:
   if not path.is_file() or path.is_symlink():missing.append(row['path']);continue
   raw=path.read_bytes()
  actual=hashlib.sha256(raw).hexdigest()
  if actual!=row['sha256']:mismatches.append({'path':row['path'],'expected':row['sha256'],'actual':actual})
  checks.append({'path':row['path'],'bytes':len(raw),'sha256':actual})
 same_source=(not missing and not mismatches and git('rev-parse','HEAD')==expected and git('status','--porcelain')=='')
 source={'schema':'chain-incentive-pinned-python-source-after-v1','scope':'all-source-before-HEAD-tracked-paths','source_commit':expected,'tree':git('rev-parse','HEAD^{tree}'),'files':len(checks),'bytes':sum(row['bytes'] for row in checks),'missing':missing,'mismatches':mismatches,'checks':checks,'unchanged':same_source}
 (out/'source-after.json').write_text(json.dumps(source,sort_keys=True,indent=2)+'\n')
 summary={'schema':'chain-incentive-pinned-python-comparison-v1','source_commit':expected,'native_run_id':native['run_id'],'native_tests_started':False,'same_native_input_bytes':before==after,'native_split_sha256':split_hash_before,'results':results,'failure':failed,'source_unchanged':same_source,'pinned_python_subset_passed':failed is None and same_source and before==after,'complete_protocol_contract_lane_claimed':False,'prior_system_python_observation_qualifies_pinned_gate':False,'production_activation':False,'economic_security_qualified':False}
 (out/'terminal.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
 print(json.dumps({'pinned_python_subset_passed':summary['pinned_python_subset_passed'],'source_unchanged':same_source,'terminal':str(out/'terminal.json')},sort_keys=True),flush=True)
raise SystemExit(0 if summary['pinned_python_subset_passed'] else 1)
