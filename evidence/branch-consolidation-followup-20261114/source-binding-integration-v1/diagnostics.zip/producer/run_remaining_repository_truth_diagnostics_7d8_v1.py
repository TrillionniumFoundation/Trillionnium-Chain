#!/usr/bin/python3
"""Run unchanged remaining repository-truth commands as separate diagnostics.
This never qualifies the original fail-fast lane or hosted CI.
"""
import datetime,hashlib,json,os,pathlib,re,signal,stat,subprocess,sys,time
BASE=pathlib.Path("/home/qian-qi/chain-final-consolidation-20261114-root")
SOURCE=BASE/"source"
HEAD="7d8d4c59fcd01480a12e1c64835b202079091800"
TREE="47b283f20c7b2afdb668316c26d098e378b4b849"
CI_SHA="625e2b0da839618033638cb0b141f0daa146022d3d0527d46eb0164ef1e6010b"
EVIDENCE=BASE/"remaining-repository-truth-diagnostics-7d8d4c-v1"
PYTHON=BASE/"final-python312-env/bin/python"
RUNTIME=BASE/"final-runtime-release-env/bin/python"
TOOLCHAIN="/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin"
def require(ok,message):
    if not ok:raise ValueError(message)
def digest(data):return hashlib.sha256(data).hexdigest()
def regular(path):
    path=pathlib.Path(path);a=path.lstat()
    require(stat.S_ISREG(a.st_mode) and a.st_nlink==1,"regular single-link file required")
    ident=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    with os.fdopen(os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK),"rb") as f:
        require(ident(os.fstat(f.fileno()))==ident(a),"path changed before read")
        raw=f.read()
        require(ident(os.fstat(f.fileno()))==ident(a),"file changed during read")
    require(ident(path.lstat())==ident(a),"path changed after read")
    return raw
def commands(raw):
    require(digest(raw)==CI_SHA,"original CI script changed")
    lines=raw.decode("utf-8").splitlines(keepends=True)
    marker="    python3 scripts/ci/test_hash_use_contract.py\n"
    require(lines.count(marker)==1,"unique failed command marker required")
    start=lines.index(marker)+1
    end=next(i for i in range(start,len(lines)) if lines[i].strip()==";;")
    units=[];i=start
    while i<end:
        if not lines[i].strip() or lines[i].lstrip().startswith("#"):
            i+=1;continue
        begin=i
        if lines[i].strip()=="(":
            i+=1
            while i<end and lines[i]!="    )\n":i+=1
            require(i<end,"unclosed original subshell")
            i+=1
        else:
            require(lines[i].startswith("    python3 ") or lines[i].startswith('    "'),"unreviewed shell statement")
            while lines[i].rstrip("\n").endswith("\\"):
                i+=1;require(i<end,"unclosed continuation")
            i+=1
        body="".join(lines[begin:i])
        units.append({"ordinal":len(units)+1,"line_start":begin+1,"line_end":i,
                      "original_shell":body,"sha256":digest(body.encode())})
    require(units[0]["original_shell"]=="    python3 scripts/ci/hash_use_contract.py\n","diagnostic start differs")
    require(units[-1]["original_shell"]=="    python3 scripts/test_qualification_runtime.py\n","diagnostic end differs")
    return units
def main():
    require(not sys.flags.optimize and os.getuid()!=0,"unoptimized nonroot interpreter required")
    require(os.environ.get("GITHUB_ACTIONS","").lower() not in ("1","true"),"not a hosted run")
    require(BASE.resolve(strict=True)==BASE and SOURCE.resolve(strict=True)==SOURCE,"canonical paths required")
    units=commands(regular(SOURCE/"scripts/ci/ci_job.sh"))
    EVIDENCE.mkdir(mode=0o700,exist_ok=False)
    (EVIDENCE/"tmp").mkdir(mode=0o700)
    (EVIDENCE/"ci-observations").mkdir(mode=0o700)
    env=os.environ.copy()
    env.update(PATH=str(PYTHON.parent)+":"+TOOLCHAIN+":/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin",
               TRNM_RUNTIME_RELEASE_PYTHON=str(RUNTIME),TRNM_CI_RECEIPT_DIR=str(EVIDENCE/"ci-observations"),
               TMPDIR=str(EVIDENCE/"tmp"),CARGO_TARGET_DIR=str(BASE/"target"),CARGO_BUILD_JOBS="2",
               CARGO_INCREMENTAL="0",RUST_TEST_THREADS="1",CARGO_TERM_COLOR="never",
               PYTHONDONTWRITEBYTECODE="1",PYTHONOPTIMIZE="0",GIT_NO_REPLACE_OBJECTS="1",
               GIT_NO_LAZY_FETCH="1",GIT_TERMINAL_PROMPT="0")
    summary={"schema":"root-original-repository-truth-continuation-diagnostics-v1","head":HEAD,"tree":TREE,
             "source":str(SOURCE),"status":"running","qualification_granted":False,"hosted_ci_qualification":False,
             "qualifies_original_full_lane":False,"original_full_lane_remains_failed":True,
             "original_failure_summary_sha256":"79d37af0ecec1749098bdfd1cfc7127de2cf9aa928b7271ca4ef8de39cd4061b",
             "original_ci_script_sha256":CI_SHA,"diagnostic_policy":"original remaining command bytes, independent fail-fast shell per unit; continue to inventory later failures",
             "global_diagnostic_budget_seconds":2700,"command_plan":units,"steps":[],"errors":[],
             "producer":{"path":str(pathlib.Path(__file__).resolve(strict=True)),"sha256":digest(regular(__file__))},
             "environment":{k:env[k] for k in ("PATH","TRNM_RUNTIME_RELEASE_PYTHON","TRNM_CI_RECEIPT_DIR","TMPDIR","CARGO_TARGET_DIR","CARGO_BUILD_JOBS","CARGO_INCREMENTAL","RUST_TEST_THREADS","CARGO_TERM_COLOR","PYTHONDONTWRITEBYTECODE","PYTHONOPTIMIZE","GIT_NO_REPLACE_OBJECTS","GIT_NO_LAZY_FETCH","GIT_TERMINAL_PROMPT")},
             "started_at":datetime.datetime.now(datetime.timezone.utc).isoformat()}
    def save():(EVIDENCE/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
    def run(label,argv,timeout,unit=None):
        row={"label":label,"argv":argv,"cwd":str(SOURCE),"timeout_seconds":timeout}
        if unit is not None:row["original_unit"]=unit
        start=time.monotonic()
        with (EVIDENCE/(label+".stdout")).open("xb") as out,(EVIDENCE/(label+".stderr")).open("xb") as err:
            try:
                proc=subprocess.Popen(argv,cwd=SOURCE,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
                try:code=proc.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    try:os.killpg(proc.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    try:proc.wait(timeout=10)
                    except subprocess.TimeoutExpired:err.write(b"Owned process did not terminate after timeout.\n")
                    code=124
            except OSError as error:err.write((repr(error)+"\n").encode());code=127
        row.update(exit=code,elapsed_seconds=round(time.monotonic()-start,3))
        for channel in ("stdout","stderr"):
            path=EVIDENCE/(label+"."+channel);raw=regular(path)
            row[channel]={"path":str(path),"bytes":len(raw),"sha256":digest(raw)}
        summary["steps"].append(row);save()
        print(json.dumps({"label":label,"exit":code,"elapsed_seconds":row["elapsed_seconds"]}),flush=True)
        return row
    before=None
    try:
        row=run("preflight-audit",["bash","scripts/project-preflight.sh","--audit"],300)
        require(row["exit"]==0,"preflight failed")
        row=run("source-before",[str(PYTHON),"-B","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",HEAD,"--output",str(EVIDENCE/"source-before.json")],300)
        require(row["exit"]==0,"initial source verification failed")
        before=json.loads(regular(EVIDENCE/"source-before.json"))
        require(before["tested_tree"]==TREE and before["tracked_worktree_verified"] is True,"source tree differs")
        require(regular(EVIDENCE/"source-before.json")==regular(EVIDENCE/"source-before.stdout"),"before output differs")
        for unit in units:
            syntax=subprocess.run(["bash","-n","-c",unit["original_shell"]],cwd=SOURCE,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
            require(syntax.returncode==0,"invalid original command unit "+str(unit["ordinal"]))
        deadline=time.monotonic()+2700
        for unit in units:
            remaining=deadline-time.monotonic()
            if remaining<=0:
                summary["errors"].append("diagnostic budget exhausted; remaining original units not executed");break
            label="unit-%03d-lines-%d-%d"%(unit["ordinal"],unit["line_start"],unit["line_end"])
            row=run(label,["bash","-euo","pipefail","-c",unit["original_shell"]],remaining,unit)
            if row["exit"]==124:
                summary["errors"].append("diagnostic unit timed out; remaining units not executed");break
    except Exception as error:
        summary["errors"].append(type(error).__name__+": "+str(error))
    finally:
        try:
            row=run("source-after",[str(PYTHON),"-B","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",HEAD,"--output",str(EVIDENCE/"source-after.json")],300)
            after=json.loads(regular(EVIDENCE/"source-after.json")) if row["exit"]==0 else None
            summary["source_before_after_verified"]=before is not None and before==after
            require(summary["source_before_after_verified"],"final source identity differs")
            require(regular(EVIDENCE/"source-after.json")==regular(EVIDENCE/"source-after.stdout"),"after output differs")
        except Exception as error:summary["errors"].append("final source verification: "+repr(error))
        runs=[s for s in summary["steps"] if "original_unit" in s]
        summary["executed_original_units"]=len(runs)
        summary["nonzero_original_units"]=[{"ordinal":s["original_unit"]["ordinal"],"label":s["label"],"exit":s["exit"],"line_start":s["original_unit"]["line_start"],"original_shell":s["original_unit"]["original_shell"]} for s in runs if s["exit"]!=0]
        summary["status"]="diagnostics-completed" if len(runs)==len(units) and not summary["errors"] else "diagnostics-incomplete"
        summary["finished_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
    print(json.dumps({"status":summary["status"],"units":len(units),"executed":summary["executed_original_units"],"nonzero":len(summary["nonzero_original_units"]),"summary":str(EVIDENCE/"summary.json"),"sha256":digest(regular(EVIDENCE/"summary.json"))}),flush=True)
    return 0 if summary["status"]=="diagnostics-completed" else 1
if __name__=="__main__":sys.exit(main())
