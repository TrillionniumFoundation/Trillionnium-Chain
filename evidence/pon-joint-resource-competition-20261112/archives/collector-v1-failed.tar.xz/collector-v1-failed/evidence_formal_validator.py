"""Read-only, standard-library verification of the frozen A evidence.

No simulator, tests, or repository programs are imported or executed.
The only child processes read immutable Git objects. This helper verifies
retained observations; it supplies no new independent experimental samples.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
import ast
import gzip
import hashlib
import io
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess

A_EXPECTED = "43e5c9d6b668276d03e1c7a76f467ec211e1d7dc"
T_EXPECTED = "beac87c2431d149dbd6d2de4a2e1eaf0617520cc"
REMOTE_ROOT = Path("/home/qian-qi/work/chain-daa-resource-competition-20261112-600e")
REMOTE_FORMAL = Path("/home/qian-qi/work/chain-daa-resource-formal-20261112-600e-43e5c9d6b668")
REMOTE_POSTHOC = Path("/home/qian-qi/work/chain-daa-posthoc-600e")
RUNNER = Path("/home/qian-qi/work/chain-daa-resource-formal-runner-20261112-600e.py")
MODULES = (
    "test_quantum_adversarial_search", "test_quantum_network_sim",
    "test_w1_marked_domain", "test_quantum_resource_clock",
    "test_quantum_candidate_check_clock", "test_quantum_probability_sampling",
    "test_joint_resource_competition_campaign", "test_quantum_daa_model",
    "test_fast_daa_reference_component", "test_branch_time_daa_v1",
    "test_joint_consensus_qualification",
)
LABELS = ("00-preflight", "01-source-before", "02-formal-tests",
          "03-campaign", "04-replay", "05-source-after")
POLICIES = ("fixed-target", "periodic-target")
ENVIRONMENTS = ("steady", "delay", "participation", "proof_cost")
ARMS = {"name", "quantum_strategy", "quantum_timestamp_mode",
        "private_timestamp_step", "private_release_seconds"}
HEX = re.compile(r"[0-9a-f]{64}\Z")


def require(condition, message):
    if not condition:
        raise ValueError("EVIDENCE_" + message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def equal(left, right, message):
    require(canonical(left) == canonical(right), message)


def keys(value, names, message):
    require(type(value) is dict and set(value) == set(names.split()), message)


def integer(value, message):
    require(type(value) is int and value >= 0, message)
    return value


def number(value, message):
    require(type(value) in (int, float) and math.isfinite(value) and value >= 0, message)
    return value


def credit(value):
    require(type(value) is str and re.fullmatch(r"0|[1-9][0-9]*", value), "CREDIT")
    return int(value)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def no_duplicates(pairs):
    result = {}
    for name, value in pairs:
        require(name not in result, "DUPLICATE_KEY")
        result[name] = value
    return result


def nonfinite(value):
    raise ValueError("EVIDENCE_NONFINITE_" + value)


def strict_json(raw):
    value = json.loads(raw.decode("utf-8"), object_pairs_hook=no_duplicates, parse_constant=nonfinite)
    def check(item):
        if type(item) is float:
            require(math.isfinite(item), "NONFINITE_NUMBER")
        elif type(item) is dict:
            for child in item.values():
                check(child)
        elif type(item) is list:
            for child in item:
                check(child)
    check(value)
    return value


def stamp(value):
    require(type(value) is str, "TIMESTAMP_TYPE")
    parsed = datetime.fromisoformat(value)
    require(parsed.tzinfo is not None and parsed.utcoffset().total_seconds() == 0, "UTC_TIMESTAMP")
    return parsed


def relative(name):
    require(type(name) is str and name and "\\" not in name, "RELATIVE_NAME")
    path = PurePosixPath(name)
    require(not path.is_absolute() and str(path) == name
            and all(part not in ("", ".", "..") for part in path.parts), "RELATIVE_PATH")
    return name


def physical_inventory(directory):
    before = directory.lstat()
    require(stat.S_ISDIR(before.st_mode), "DIRECTORY")
    names = set()
    def walk(folder, prefix=""):
        for entry in os.scandir(folder):
            info = entry.stat(follow_symlinks=False)
            name = prefix + entry.name
            if stat.S_ISDIR(info.st_mode):
                require(directory == REMOTE_FORMAL and name == "campaign", "UNEXPECTED_DIRECTORY")
                walk(Path(entry.path), name + "/")
            else:
                require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "NONREGULAR_INVENTORY")
                names.add(relative(name))
    walk(directory)
    return names


class Reader:
    def __init__(self):
        self.observed = {}

    def read(self, path, limit=64_000_000):
        path = Path(path)
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(path, flags)
        try:
            before = os.fstat(fd)
            require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
                    and 0 <= before.st_size <= limit, "FILE_BOUND")
            chunks, count = [], 0
            while True:
                part = os.read(fd, 1_048_576)
                if not part:
                    break
                count += len(part)
                require(count <= limit, "FILE_GROWTH")
                chunks.append(part)
            after = os.fstat(fd)
        finally:
            os.close(fd)
        def identity(s):
            return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        require(identity(before) == identity(after) and count == before.st_size, "FILE_CHANGED")
        current = path.lstat()
        require(identity(current) == identity(after) and stat.S_ISREG(current.st_mode)
                and current.st_nlink == 1, "PATH_CHANGED")
        raw = b"".join(chunks)
        signature = (len(raw), digest(raw))
        if path in self.observed:
            require(self.observed[path] == signature, "INPUT_REPLACED")
        self.observed[path] = signature
        return raw

    def json(self, path):
        return strict_json(self.read(path))

    def pinned(self, path, size, sha):
        raw = self.read(path)
        require(len(raw) == size and digest(raw) == sha, "KNOWN_ORIGINAL_HASH")
        return raw

    def final_check(self):
        for path in tuple(self.observed):
            self.read(path)


def summarize_pairs(pairs):
    deltas = [int(item["private_minus_honest_quantum_adopted_credit"]) for item in pairs]
    return {"pairs": len(pairs), "private_more_credit": sum(n > 0 for n in deltas),
            "equal_credit": sum(n == 0 for n in deltas), "private_less_credit": sum(n < 0 for n in deltas),
            "paired_credit_delta_sum": str(sum(deltas))}


def validate_formal_and_posthoc(F: Path, C: Path, P: Path, A: str, T: str,
                               R: Path | None = None) -> dict:
    """Validate immutable original evidence, returning descriptive aggregates.

    F/C/P are original remote output locations, not rewritten copies.
    R is the repository used solely to read source A Git objects.
    Raises ValueError/OSError/JSON errors on any incomplete or altered input.
    """
    F, C, P = Path(F), Path(C), Path(P)
    R = Path(R) if R is not None else REMOTE_ROOT
    require(A == A_EXPECTED and T == T_EXPECTED, "FROZEN_IDENTITY")
    require(F == REMOTE_FORMAL and C == F / "campaign" and P == REMOTE_POSTHOC
            and R == REMOTE_ROOT, "ORIGINAL_PATHS")
    reader = Reader()
    f_inventory, c_inventory, p_inventory = (physical_inventory(path) for path in (F, C, P))
    runner_raw = reader.pinned(RUNNER, 9167,
        "14fd0d544175896e36c2331b194fc8a891ff90b39b779ae6b7d63f13e0c0f56f")
    # The separately observed posthoc identity anchors its hashes of all original
    # campaign members; internal manifests alone would not provide that anchor.
    analysis_raw = reader.pinned(P / "analysis.json", 73566,
        "b5139d1353e7bebe7f4702ec6931a98133143e945ee8c039b62a51ba715f3d65")
    analysis = strict_json(analysis_raw)
    post_stdout_raw = reader.pinned(P / "analysis.stdout.log", 5547,
        "633c4b51e50525bd7ac9d0e67b9308d5adc1d880e4a42fa3a45b24bdb648a979")
    post_stdout = strict_json(post_stdout_raw)

    roster = reader.json(C / "roster.json")
    report = reader.json(C / "report.json")
    manifest_raw = reader.read(C / "manifest.json")
    manifest = strict_json(manifest_raw)
    keys(roster, "schema seeds duration_seconds cases contract", "ROSTER_KEYS")
    equal(roster["schema"], "trnm-joint-resource-competition-campaign-v1-roster", "ROSTER_SCHEMA")
    equal(roster["seeds"], [6101, 6102, 6103, 6104], "SEEDS")
    equal(roster["duration_seconds"], 3600.0, "HORIZON")
    require(type(roster["cases"]) is list and len(roster["cases"]) == 128, "ROSTER_LENGTH")
    expected_cases = []
    for seed in range(6101, 6105):
        for clock in (0.15, 0.05):
            for environment in ENVIRONMENTS:
                for policy in POLICIES:
                    for arm in ("honest", "private"):
                        name = f"{environment}_q{int(round(clock * 1000))}_{policy.replace('-', '_')}_{arm}"
                        expected_cases.append((name + "_s" + str(seed), name, seed, clock, environment, policy, arm))
    case_ids = [row[0] for row in expected_cases]
    expected_c = {"roster.json", "report.json"} | {case + suffix for case in case_ids
                                                    for suffix in (".json", ".jsonl.gz")}
    require(len(expected_c) == 258, "EXPECTED_COHORT_COUNT")
    keys(manifest, "schema files_sha256", "CAMPAIGN_MANIFEST_KEYS")
    equal(manifest["schema"], "trnm-joint-resource-competition-campaign-v1-manifest", "CAMPAIGN_MANIFEST_SCHEMA")
    require(type(manifest["files_sha256"]) is dict and set(manifest["files_sha256"]) == expected_c,
            "CAMPAIGN_MANIFEST_INVENTORY")
    require(c_inventory == expected_c | {"manifest.json"}, "CAMPAIGN_PHYSICAL_INVENTORY")
    campaign_bytes = 0
    for name, wanted in manifest["files_sha256"].items():
        relative(name)
        require(type(wanted) is str and HEX.fullmatch(wanted), "CAMPAIGN_SHA_TYPE")
        raw = reader.read(C / name)
        require(digest(raw) == wanted, "CAMPAIGN_MEMBER_HASH")
        campaign_bytes += len(raw)

    expected_f = {label + suffix for label in LABELS
                  for suffix in (".started.json", ".receipt.json", ".stdout.log", ".stderr.log")}
    expected_f |= {"command-plan.json", "execution-summary.json", "source-before.json", "source-after.json"}
    expected_f |= {"campaign/" + name for name in c_inventory}
    f_manifest = reader.json(F / "execution-manifest.json")
    keys(f_manifest, "schema files", "FORMAL_MANIFEST_KEYS")
    equal(f_manifest["schema"], "trnm-joint-resource-formal-execution-manifest-v1", "FORMAL_MANIFEST_SCHEMA")
    require(type(f_manifest["files"]) is dict and set(f_manifest["files"]) == expected_f
            and len(expected_f) == 287, "FORMAL_MANIFEST_INVENTORY")
    require(f_inventory == expected_f | {"execution-manifest.json"}, "FORMAL_PHYSICAL_INVENTORY")
    for name, item in f_manifest["files"].items():
        relative(name)
        keys(item, "bytes sha256", "FORMAL_MEMBER_KEYS")
        integer(item["bytes"], "FORMAL_MEMBER_SIZE")
        require(type(item["sha256"]) is str and HEX.fullmatch(item["sha256"]), "FORMAL_MEMBER_SHA")
        raw = reader.read(F / name)
        require(len(raw) == item["bytes"] and digest(raw) == item["sha256"], "FORMAL_MEMBER_CONTENT")

    formal_cwd = str(R / "formal/pon-nakamoto-v1")
    source_argv = ["/usr/bin/python3", "scripts/ci/verify_ci_source.py", "--kind", "head", "--expected-head", A]
    expected_commands = [
        {"label": LABELS[0], "argv": ["bash", "scripts/project-preflight.sh"], "cwd": str(R), "timeout_seconds": 60},
        {"label": LABELS[1], "argv": source_argv + ["--output", str(F / "source-before.json")],
         "cwd": str(R), "timeout_seconds": 300},
        {"label": LABELS[2], "argv": ["/usr/bin/python3", "-m", "unittest", "-v", *MODULES],
         "cwd": formal_cwd, "timeout_seconds": 1200},
        {"label": LABELS[3], "argv": ["/usr/bin/python3", "experiments/joint_resource_competition_campaign.py",
                                      "--out", str(C)], "cwd": formal_cwd, "timeout_seconds": 1200},
        {"label": LABELS[4], "argv": ["/usr/bin/python3", "experiments/joint_resource_competition_campaign.py",
                                      "--verify", str(C)], "cwd": formal_cwd, "timeout_seconds": 1200},
        {"label": LABELS[5], "argv": source_argv + ["--output", str(F / "source-after.json")],
         "cwd": str(R), "timeout_seconds": 300},
    ]
    plan = reader.json(F / "command-plan.json")
    keys(plan, "schema expected_source root runner_sha256 runner_file python platform planned_at_utc commands "
               "formal_modules campaign environment_overrides outer_process_limits "
               "old_cloud_validation_terminal_outcome qualification", "PLAN_KEYS")
    equal(plan["schema"], "trnm-joint-resource-formal-execution-plan-v1", "PLAN_SCHEMA")
    equal(plan["expected_source"], A, "PLAN_SOURCE")
    equal(plan["root"], str(R), "PLAN_ROOT")
    equal(plan["runner_file"], str(RUNNER), "PLAN_RUNNER")
    equal(plan["runner_sha256"], digest(runner_raw), "PLAN_RUNNER_HASH")
    equal(plan["commands"], expected_commands, "PLAN_COMMANDS")
    equal(plan["formal_modules"], list(MODULES), "PLAN_MODULES")
    equal(plan["campaign"], {"runs": 128, "duration_seconds": 3600.0,
          "per_case_cpu_limit_seconds": 10.0, "seeds": [6101, 6102, 6103, 6104],
          "replay_is_preplanned_second_execution_of_the_same_seeded_cases": True}, "PLAN_CAMPAIGN")
    equal(plan["environment_overrides"], {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1"}, "PLAN_ENV")
    equal(plan["outer_process_limits"], {"cpu_quota_percent": 200, "memory_max_bytes": 8589934592}, "PLAN_LIMITS")
    equal(plan["old_cloud_validation_terminal_outcome"], "UNKNOWN", "OLD_CLOUD_UNKNOWN")
    equal(plan["qualification"], "conditional research, no production or security theorem", "PLAN_SCOPE")

    formal_summary_raw = reader.pinned(F / "execution-summary.json", 6816,
        "cdbc237bbad5e0ad9eead69b00fce17f715d1491501d57fb2b4e2e2a947666d9")
    formal_summary = strict_json(formal_summary_raw)
    keys(formal_summary, "schema source ended_utc planned_commands completed_commands not_run "
         "all_planned_commands_pass source_before_after_identical commands old_cloud_validation_terminal_outcome "
         "production_consensus_activation release_ready", "FORMAL_SUMMARY_KEYS")
    equal(formal_summary["schema"], "trnm-joint-resource-formal-execution-v1", "FORMAL_SUMMARY_SCHEMA")
    equal(formal_summary["source"], A, "FORMAL_SOURCE")
    for key, value in {"planned_commands": 6, "completed_commands": 6, "not_run": [],
                       "all_planned_commands_pass": True, "source_before_after_identical": True,
                       "old_cloud_validation_terminal_outcome": "UNKNOWN",
                       "production_consensus_activation": False, "release_ready": False}.items():
        equal(formal_summary[key], value, "FORMAL_SUCCESS_" + key)
    require(type(formal_summary["commands"]) is list and len(formal_summary["commands"]) == 6, "FORMAL_COMMAND_COUNT")
    started_keys = "label argv cwd started_utc timeout_seconds returncode timed_out spawn_error stdout_file stderr_file"
    receipt_keys = started_keys + " pid ended_utc wall_seconds stdout_bytes stderr_bytes stdout_sha256 stderr_sha256 passed"
    previous_end = stamp(plan["planned_at_utc"])
    for expected, receipt in zip(expected_commands, formal_summary["commands"]):
        label = expected["label"]
        equal(reader.json(F / (label + ".receipt.json")), receipt, "FORMAL_RECEIPT_COPY")
        keys(receipt, receipt_keys, "FORMAL_RECEIPT_KEYS")
        started = reader.json(F / (label + ".started.json"))
        keys(started, started_keys, "FORMAL_STARTED_KEYS")
        for key, value in expected.items():
            equal(receipt[key], value, "FORMAL_COMMAND_" + key)
            equal(started[key], value, "FORMAL_STARTED_" + key)
        for key in ("started_utc", "stdout_file", "stderr_file"):
            equal(started[key], receipt[key], "FORMAL_START_MATCH")
        equal([started["returncode"], started["timed_out"], started["spawn_error"]], [None, False, None], "FORMAL_INITIAL")
        equal([receipt["returncode"], receipt["timed_out"], receipt["spawn_error"], receipt["passed"]],
              [0, False, None, True], "FORMAL_TERMINAL")
        require(integer(receipt["pid"], "PID") > 0, "PID_POSITIVE")
        begin, end = stamp(receipt["started_utc"]), stamp(receipt["ended_utc"])
        require(previous_end <= begin <= end, "FORMAL_STAGE_ORDER")
        previous_end = end
        number(receipt["wall_seconds"], "FORMAL_WALL")
        for stream in ("stdout", "stderr"):
            name = label + "." + stream + ".log"
            equal(receipt[stream + "_file"], name, "FORMAL_LOG_PATH")
            raw = reader.read(F / name)
            equal(receipt[stream + "_bytes"], len(raw), "FORMAL_LOG_LENGTH")
            equal(receipt[stream + "_sha256"], digest(raw), "FORMAL_LOG_HASH")
        if label != "02-formal-tests":
            require(reader.read(F / (label + ".stderr.log")) == b"", "UNEXPECTED_STDERR")
    require(previous_end <= stamp(formal_summary["ended_utc"]), "FORMAL_END_ORDER")

    guard = {"base": None, "candidate": A, "kind": "head", "prospective_merge": None,
             "schema": "trnm-ci-source-v1", "tested_commit": A, "tested_tree": T,
             "tests_executed_by_identity_check": False, "tracked_bytes": 2542453893,
             "tracked_entries": 26711, "tracked_worktree_verified": True}
    guard_sha = "0806a79437cb91eb5a36682165a6ee1dba98969c38c1221cfb32f7f27ea7e210"
    for name, label in (("source-before.json", LABELS[1]), ("source-after.json", LABELS[5])):
        raw = reader.pinned(F / name, 423, guard_sha)
        equal(strict_json(raw), guard, "SOURCE_GUARD")
        require(reader.read(F / (label + ".stdout.log")) == raw, "SOURCE_GUARD_LOG")
    test_raw = reader.pinned(F / "02-formal-tests.stderr.log", 41758,
        "0f45b90e7e83cc345bab6f90d50b105df7d32a9ce14df4611489884f018283cd")
    require(reader.read(F / "02-formal-tests.stdout.log") == b"", "TEST_STDOUT")
    test_text = test_raw.decode("utf-8")
    matches = re.findall(r"^test_\S+ \(([^)]+)\) \.\.\. ok$", test_text, flags=re.M)
    require(len(matches) == len(set(matches)) == 242, "UNIQUE_TESTS")
    require(set(item.split(".", 1)[0] for item in matches) == set(MODULES), "TEST_MODULE_SET")
    require(len([line for line in test_text.splitlines() if " ... " in line]) == 242, "NON_OK_TEST")
    require(test_text.endswith("\nRan 242 tests in 33.648s\n\nOK\n"), "TEST_TERMINAL")
    campaign_stdout = strict_json(reader.pinned(F / "03-campaign.stdout.log", 750,
        "9826c82bfaaf3d191cd45d8bd9620d68f43ff0941fe3169c5facdead374e337b"))
    replay_stdout = strict_json(reader.pinned(F / "04-replay.stdout.log", 221,
        "46c8ebbcd704ec21f18b050903ac2dd7e2c54c882b9dece1f8991aee62806053"))
    equal(replay_stdout, {"result": "COMPLETE_PAIRED_REPLAY_AND_READBACK_PASS", "runs": 128, "pairs": 64,
          "native_w1_verified": False, "physical_resource_fairness_qualified": False,
          "network_byte_budget_qualified": False, "release_ready": False}, "REPLAY_RESULT")

    keys(report, "schema source argv roster_sha256 contract observations comparison actual_python_process", "REPORT_KEYS")
    equal(report["schema"], "trnm-joint-resource-competition-campaign-v1", "REPORT_SCHEMA")
    equal(report["argv"], expected_commands[3]["argv"][1:], "REPORT_ARGV")
    equal(report["roster_sha256"], manifest["files_sha256"]["roster.json"], "REPORT_ROSTER_HASH")
    equal(report["observations"], [case + ".json" for case in case_ids], "REPORT_ROSTER_ORDER")
    source = report["source"]
    keys(source, "git_head source_sha256 all_source_files_committed_at_head uncommitted_source_files", "SOURCE_KEYS")
    equal(source["git_head"], A, "CAMPAIGN_SOURCE")
    equal(source["all_source_files_committed_at_head"], True, "SOURCE_COMMITTED")
    equal(source["uncommitted_source_files"], [], "SOURCE_UNCOMMITTED")
    require(type(source["source_sha256"]) is dict and source["source_sha256"], "SOURCE_FILES")
    git_env = dict(os.environ)
    git_env.update({"GIT_NO_REPLACE_OBJECTS": "1", "GIT_NO_LAZY_FETCH": "1", "GIT_OPTIONAL_LOCKS": "0"})
    def git(*args):
        result = subprocess.run(["git", *args], cwd=R, env=git_env, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, check=False, timeout=60)
        require(result.returncode == 0, "GIT_OBJECT_READ")
        return result.stdout
    require(git("cat-file", "-t", A) == b"commit\n", "SOURCE_COMMIT_TYPE")
    require(git("rev-parse", A + "^{tree}").decode().strip() == T, "SOURCE_TREE")
    blobs = {}
    for name, wanted in source["source_sha256"].items():
        relative(name)
        require(type(wanted) is str and HEX.fullmatch(wanted), "SOURCE_HASH_TYPE")
        blobs[name] = git("show", A + ":" + name)
        require(digest(blobs[name]) == wanted, "SOURCE_BLOB_HASH")
    campaign_source_name = "formal/pon-nakamoto-v1/experiments/joint_resource_competition_campaign.py"
    require(campaign_source_name in blobs, "CAMPAIGN_SOURCE_BOUND")
    tree = ast.parse(blobs[campaign_source_name])
    contract_nodes = [node.value for node in tree.body if isinstance(node, ast.Assign)
                      and any(isinstance(target, ast.Name) and target.id == "CONTRACT" for target in node.targets)]
    require(len(contract_nodes) == 1, "SOURCE_CONTRACT_ASSIGNMENT")
    contract = ast.literal_eval(contract_nodes[0])
    equal(roster["contract"], contract, "ROSTER_SOURCE_CONTRACT")
    require(type(report["contract"]) is dict and "simulator_assumptions" in report["contract"], "REPORT_ASSUMPTIONS")
    equal({k: v for k, v in report["contract"].items() if k != "simulator_assumptions"},
          contract, "REPORT_SOURCE_CONTRACT")

    records, gzip_rows = [], 0
    record_keys = "case_id parameters execution summary error trace_file trace_rows readback readback_error"
    for metadata, parameters in zip(expected_cases, roster["cases"]):
        case_id, name, seed, clock, environment, policy, arm = metadata
        require(type(parameters) is dict, "PARAMETERS")
        for key, wanted in {"name": name, "seed": seed, "duration_seconds": 3600.0, "policy": policy,
                            "quantum_iteration_seconds": clock, "quantum_clock_rounding": "upward",
                            "max_events": 30000, "max_blocks": 3000, "max_trace_rows": 100000,
                            "max_pending_events": 30000, "cpu_limit_seconds": 10.0}.items():
            equal(parameters[key], wanted, "ROSTER_PARAMETER_" + key)
        equal(parameters["quantum_strategy"], "honest-tip" if arm == "honest" else "private-branch", "ARM")
        equal(parameters["quantum_timestamp_mode"], "wall" if arm == "honest" else "compressed", "TIMESTAMP_MODE")
        equal(parameters["private_release_seconds"], None if arm == "honest" else 2700.0, "RELEASE")
        if arm == "private":
            equal(parameters["private_timestamp_step"], 1, "PRIVATE_STEP")
        record = reader.json(C / (case_id + ".json"))
        keys(record, record_keys, "CASE_KEYS")
        equal(record["case_id"], case_id, "CASE_ID")
        equal(record["parameters"], parameters, "CASE_PARAMETERS")
        equal([record["execution"], record["error"], record["readback_error"]], ["returned", None, None], "CASE_RETURNED")
        summary, checked = record["summary"], record["readback"]
        require(type(summary) is dict and type(checked) is dict, "CASE_PAYLOAD")
        equal(summary["termination"], "horizon", "CASE_HORIZON")
        equal(summary["trace_limit_reached"], False, "CASE_TRACE_LIMIT")
        equal(summary["observation_seconds"], 3600.0, "CASE_OBSERVATION")
        equal(checked["all_declared_capacity_checks_pass"], True, "CAPACITY_CHECK")
        for flag in ("physical_resource_fairness_qualified", "network_byte_budget_qualified"):
            equal(checked[flag], False, "READBACK_SCOPE")
        expected_trace = case_id + ".jsonl.gz"
        equal(record["trace_file"], expected_trace, "TRACE_FILE")
        wanted_rows = integer(record["trace_rows"], "TRACE_ROWS")
        equal(summary["trace_rows"], wanted_rows, "SUMMARY_TRACE_ROWS")
        require(0 < wanted_rows <= 100000, "TRACE_COUNT_BOUND")
        count, decompressed = 0, 0
        with gzip.GzipFile(fileobj=io.BytesIO(reader.read(C / expected_trace)), mode="rb") as stream:
            while True:
                row_raw = stream.readline(2_000_001)
                if not row_raw:
                    break
                require(len(row_raw) <= 2_000_000, "TRACE_LINE_BOUND")
                decompressed += len(row_raw)
                require(decompressed <= 512_000_000, "TRACE_EXPANSION_BOUND")
                row = strict_json(row_raw)
                require(type(row) is dict and type(row.get("kind")) is str, "TRACE_OBJECT")
                at = number(row.get("at_seconds"), "TRACE_TIME")
                require(at <= 3600.0, "TRACE_AFTER_HORIZON")
                count += 1
                require(count <= wanted_rows, "TRACE_EXTRA_ROW")
        require(count == wanted_rows, "GZIP_COMPLETE_ROWS")
        gzip_rows += count
        credit(checked["quantum_adopted_credit"])
        credit(checked["classical_adopted_credit"])
        integer(summary["blocks_created"], "BLOCK_COUNT")
        require(checked["quantum_adopted_blocks"] + checked["classical_adopted_blocks"]
                == summary["observer_added_blocks"], "ADOPTED_BLOCKS")
        equal(str(credit(checked["quantum_adopted_credit"]) + credit(checked["classical_adopted_credit"])),
              summary["observer_added_chainwork"], "ADOPTED_WORK")
        records.append(record)

    comparison_pairs, pairs, detail_map = [], [], {}
    for offset in range(0, 128, 2):
        honest, private = records[offset:offset + 2]
        hp, pp = honest["parameters"], private["parameters"]
        premise = {key: value for key, value in hp.items() if key not in ARMS}
        equal(premise, {key: value for key, value in pp.items() if key not in ARMS}, "PAIR_BUDGET")
        delta = credit(private["readback"]["quantum_adopted_credit"]) - credit(honest["readback"]["quantum_adopted_credit"])
        comparison_pairs.append({
            "honest": honest["case_id"], "private": private["case_id"], "policy": hp["policy"], "seed": hp["seed"],
            "resource_premises_sha256": digest(canonical(premise)), "declared_resource_premises_equal": True,
            "complete": True, "private_minus_honest_quantum_adopted_credit": str(delta),
            "private_has_more_adopted_credit": delta > 0,
            "private_probe_confirmation_reversals": private["summary"]["probe"]["confirmation_reversals"],
            "private_observer_max_reorg_depth": private["summary"]["observer_max_reorg_depth"]})
        pair_id = honest["case_id"] + "__vs__" + private["case_id"]
        environment = expected_cases[offset][4]
        pair = {"pair_id": pair_id, "policy": hp["policy"], "environment": environment,
                "quantum_iteration_seconds": hp["quantum_iteration_seconds"], "seed": hp["seed"],
                "honest_case": honest["case_id"], "private_case": private["case_id"],
                "private_minus_honest_quantum_adopted_credit": str(delta)}
        pairs.append(pair)
        detail_map[pair_id] = dict(pair)
        for arm, record in (("honest", honest), ("private", private)):
            summary, checked = record["summary"], record["readback"]
            detail_map[pair_id][arm] = {
                "case_id": record["case_id"], "original_file": record["case_id"] + ".json",
                "original_sha256": manifest["files_sha256"][record["case_id"] + ".json"],
                "termination": summary["termination"], "observation_seconds": summary["observation_seconds"],
                "quantum_adopted_credit": checked["quantum_adopted_credit"],
                "classical_adopted_credit": checked["classical_adopted_credit"],
                "quantum_adopted_blocks": checked["quantum_adopted_blocks"],
                "classical_adopted_blocks": checked["classical_adopted_blocks"],
                "observer_added_chainwork": summary["observer_added_chainwork"],
                "blocks_created": summary["blocks_created"], "trace_rows": record["trace_rows"],
                "observer_reorgs": summary["observer_reorgs"], "observer_max_reorg_depth": summary["observer_max_reorg_depth"],
                "probe": summary["probe"], "resource_charges": checked["resource_charges"]}
    by_policy = [{"policy": policy, **summarize_pairs([p for p in pairs if p["policy"] == policy])} for policy in POLICIES]
    equal(by_policy, [
        {"policy": "fixed-target", "pairs": 32, "private_more_credit": 0, "equal_credit": 3,
         "private_less_credit": 29, "paired_credit_delta_sum": "-165403879"},
        {"policy": "periodic-target", "pairs": 32, "private_more_credit": 16, "equal_credit": 3,
         "private_less_credit": 13, "paired_credit_delta_sum": "2187125401"}], "OBSERVED_POLICY_TOTALS")
    report_groups = []
    for group in by_policy:
        report_groups.append({"policy": group["policy"], "planned_pairs": 32, "complete_pairs": 32,
            "incomplete_pairs": 0, "private_more_credit_pairs": group["private_more_credit"],
            "equal_credit_pairs": group["equal_credit"], "private_less_credit_pairs": group["private_less_credit"],
            "paired_credit_delta_sum": group["paired_credit_delta_sum"], "conditional_descriptive_counts_only": True})
    comparison = {"planned_runs": 128, "returned_runs": 128, "complete_readback_runs": 128,
        "planned_pairs": 64, "complete_pairs": 64, "pairs": comparison_pairs, "by_policy": report_groups,
        "security_probability_estimated": False,
        "cross_policy_credit_units": "same initial prefix and integer required-work formula; endogenous targets differ",
        "physical_resource_fairness_qualified": False, "network_byte_budget_qualified": False,
        "task_supply_experiment_performed": False, "release_ready": False}
    equal(report["comparison"], comparison, "REPORT_COMPARISON")
    equal(campaign_stdout, {"result": "CONDITIONAL_PAIRED_OBSERVATIONS", "planned_runs": 128,
        "complete_readback_runs": 128, "planned_pairs": 64, "complete_pairs": 64, "source_committed": True,
        "by_policy": report_groups, "release_ready": False}, "CAMPAIGN_STDOUT")

    groups, clocks, cells = defaultdict(list), defaultdict(list), defaultdict(list)
    for pair in pairs:
        groups[(pair["policy"], pair["environment"])].append(pair)
        clocks[(pair["policy"], pair["quantum_iteration_seconds"])].append(pair)
        cells[(pair["policy"], pair["environment"], pair["quantum_iteration_seconds"])].append(pair)
    by_environment = [{"policy": key[0], "environment": key[1], **summarize_pairs(values)}
                      for key, values in sorted(groups.items())]
    by_clock = [{"policy": key[0], "quantum_iteration_seconds": key[1], **summarize_pairs(values)}
                for key, values in sorted(clocks.items())]
    by_cell = [{"policy": key[0], "environment": key[1], "quantum_iteration_seconds": key[2],
                **summarize_pairs(values)} for key, values in sorted(cells.items())]
    for row in by_environment:
        equal(row["pairs"], 8, "ENV_DENOMINATOR")
    for row in by_cell:
        equal(row["pairs"], 4, "CELL_DENOMINATOR")
    clock_values = {
        ("fixed-target", 0.05): (0, 0, 16, "-148780966"),
        ("fixed-target", 0.15): (0, 3, 13, "-16622913"),
        ("periodic-target", 0.05): (16, 0, 0, "2199728042"),
        ("periodic-target", 0.15): (0, 3, 13, "-12602641"),
    }
    for row in by_clock:
        more, same, less, total = clock_values[(row["policy"], row["quantum_iteration_seconds"])]
        equal({k: v for k, v in row.items() if k not in ("policy", "quantum_iteration_seconds")},
              {"pairs": 16, "private_more_credit": more, "equal_credit": same,
               "private_less_credit": less, "paired_credit_delta_sum": total}, "OBSERVED_CLOCK_TOTALS")

    def count_value(record, key):
        return integer(record["summary"][key], "COUNTER_" + key)
    totals = {
        "runs": 128, "pairs": 64,
        "termination_histogram": dict(sorted(Counter(r["summary"]["termination"] for r in records).items())),
        "blocks_created": sum(count_value(r, "blocks_created") for r in records),
        "trace_rows": sum(integer(r["trace_rows"], "TRACE_COUNT") for r in records),
        "observer_added_blocks": sum(count_value(r, "observer_added_blocks") for r in records),
        "observer_reorgs": sum(count_value(r, "observer_reorgs") for r in records),
        "maximum_observer_reorg_depth": max(count_value(r, "observer_max_reorg_depth") for r in records),
        "observer_reorg_beyond_confirmation_depth_events": sum(count_value(r, "observer_reorg_beyond_confirmation_depth") for r in records),
        "pairwise_prefix_samples": sum(count_value(r, "pairwise_prefix_samples") for r in records),
        "pairwise_prefix_disagreements_below_common_height_minus_k": sum(
            count_value(r, "pairwise_prefix_disagreements_below_common_height_minus_k") for r in records),
        "probe_confirmation_reversals": sum(integer(r["summary"]["probe"]["confirmation_reversals"], "PROBE_REVERSALS") for r in records),
        "runs_with_probe_confirmation_reversals": sum(r["summary"]["probe"]["confirmation_reversals"] > 0 for r in records),
    }
    probe_fields = {}
    probe_keys = set(records[0]["summary"]["probe"])
    require(all(set(record["summary"]["probe"]) == probe_keys for record in records), "PROBE_FIELD_SET")
    for key in sorted(probe_keys):
        values = [record["summary"]["probe"][key] for record in records]
        present = [value for value in values if value is not None]
        item = {"runs": len(values), "null_runs": len(values) - len(present)}
        if not present:
            item["type"] = "all-null"
        elif all(type(value) is bool for value in present):
            item.update({"type": "boolean", "true_runs": sum(value is True for value in present),
                         "false_runs": sum(value is False for value in present)})
        elif all(type(value) in (int, float) for value in present):
            item.update({"type": "number", "nonnull_runs": len(present), "minimum": min(present),
                         "maximum": max(present), "sum": sum(present)})
        elif all(type(value) is str for value in present):
            item.update({"type": "string", "value_counts": dict(sorted(Counter(present).items()))})
        else:
            raise ValueError("EVIDENCE_PROBE_TYPE")
        probe_fields[key] = item
    totals["probe_original_fields"] = probe_fields
    totals["probe_field_aggregation_scope"] = "original names retained; numeric sums are descriptive, not probabilities"
    honest_records = [r for r in records if r["parameters"]["quantum_strategy"] == "honest-tip"]
    def short(record):
        return integer(record["readback"]["integer_policy_readback"]["positive_short_epochs_accepted"], "SHORT_EPOCH")
    short_epochs = {
        "all_runs_positive_short_epochs_accepted": sum(short(r) for r in records),
        "honest_runs": len(honest_records),
        "honest_runs_with_positive_short_epochs_accepted": sum(short(r) > 0 for r in honest_records),
        "honest_runs_positive_short_epochs_accepted": sum(short(r) for r in honest_records),
        "by_policy": [{"policy": policy,
                       "honest_runs": sum(r["parameters"]["policy"] == policy for r in honest_records),
                       "honest_runs_with_positive_short_epochs_accepted": sum(
                           r["parameters"]["policy"] == policy and short(r) > 0 for r in honest_records),
                       "honest_runs_positive_short_epochs_accepted": sum(
                           short(r) for r in honest_records if r["parameters"]["policy"] == policy)}
                      for policy in POLICIES],
        "scope": "generated-block checks in all-honest cases; not only the final canonical chain",
        "fixed_target_has_no_periodic_retarget_epochs": True,
    }
    equal([totals["blocks_created"], totals["trace_rows"], totals["probe_confirmation_reversals"],
           totals["maximum_observer_reorg_depth"], totals["termination_histogram"]],
          [53964, 543115, 16, 260, {"horizon": 128}], "OBSERVED_TOTALS")
    require(gzip_rows == totals["trace_rows"], "ALL_GZIP_ROWS")
    equal([short_epochs["all_runs_positive_short_epochs_accepted"], short_epochs["honest_runs"],
           short_epochs["honest_runs_with_positive_short_epochs_accepted"],
           short_epochs["honest_runs_positive_short_epochs_accepted"]], [103, 64, 5, 5], "OBSERVED_SHORT_EPOCHS")
    equal(short_epochs["by_policy"][1], {"policy": "periodic-target", "honest_runs": 32,
          "honest_runs_with_positive_short_epochs_accepted": 5,
          "honest_runs_positive_short_epochs_accepted": 5}, "OBSERVED_HONEST_PERIODIC_EPOCHS")

    ranked = sorted(pairs, key=lambda p: (-abs(int(p["private_minus_honest_quantum_adopted_credit"])), p["pair_id"]))
    selected = [p["pair_id"] for p in ranked[:4]]
    for policy in POLICIES:
        candidate = next(p["pair_id"] for p in ranked if p["policy"] == policy)
        if candidate not in selected:
            selected.append(candidate)
    negative = min(pairs, key=lambda p: (int(p["private_minus_honest_quantum_adopted_credit"]), p["pair_id"]))
    if negative["pair_id"] not in selected:
        selected.append(negative["pair_id"])
    expected_analysis = {
        "schema": "trnm-joint-resource-posthoc-description-v1", "source": A,
        "started_utc": analysis["started_utc"], "ended_utc": analysis["ended_utc"],
        "original_campaign_directory": str(C), "original_manifest_sha256": digest(manifest_raw),
        "original_manifest_members": 258, "original_member_bytes": campaign_bytes,
        "original_report_sha256": manifest["files_sha256"]["report.json"],
        "original_roster_sha256": manifest["files_sha256"]["roster.json"],
        "input_hashes_reverified_after_analysis": True,
        "scope": "posthoc descriptive aggregation of all retained original 128 cases",
        "new_simulator_executions": 0, "new_independent_samples": 0,
        "attack_probability_estimated": False, "policy_or_seed_selection_performed": False,
        "by_policy": by_policy, "by_policy_environment": by_environment,
        "by_policy_quantum_clock": by_clock, "by_policy_environment_quantum_clock": by_cell,
        "totals": totals, "honest_short_epochs": short_epochs,
        "largest_absolute_paired_delta_ids": [p["pair_id"] for p in ranked[:4]],
        "most_negative_paired_delta_id": negative["pair_id"],
        "selected_extreme_details": [detail_map[pair_id] for pair_id in selected],
        "extreme_selection_scope": "posthoc reporting only; no seed deletion, model tuning or qualification inference",
        "all_pair_deltas": pairs,
        "limitations": [
            "Offered hypothetical clocks/processors match; physical resource fairness is unqualified.",
            "The delivery-delay model has no bandwidth/byte/validation-queue budget.",
            "Proof-cost and participation sensitivities are not task-supply experiments.",
            "Prefix/reorganization counters are finite proxies, not CP/CG/CQ failure probabilities.",
            "A private quantum miner's extra adopted credit is not a physical-resource or profitable-network attack proof.",
            "The declared strategy is compressed-only with scheduled release, not an optimal Bailey-Sattath policy.",
            "Across-policy credit totals are endogenous to target evolution and do not supply a common physical price."],
        "physical_resource_fairness_qualified": False, "network_byte_budget_qualified": False,
        "production_consensus_activation": False, "release_ready": False,
    }
    equal(analysis, expected_analysis, "FULL_POSTHOC_RECOMPUTATION")
    require(stamp(formal_summary["ended_utc"]) <= stamp(analysis["started_utc"])
            <= stamp(analysis["ended_utc"]), "POSTHOC_ORDER")
    expected_small = {k: v for k, v in expected_analysis.items() if k != "all_pair_deltas"}
    expected_small["all_pair_deltas_retained_in"] = str(P / "analysis.json")
    equal(reader.json(P / "summary.json"), expected_small, "POSTHOC_SMALL_SUMMARY")
    equal(post_stdout, {"result": "POSTHOC_DESCRIPTION_RECORDED", "output": str(P / "analysis.json"),
        "analysis_bytes": len(analysis_raw), "analysis_sha256": digest(analysis_raw), "new_simulator_executions": 0,
        "by_policy": by_policy, "by_policy_quantum_clock": by_clock, "honest_short_epochs": short_epochs,
        "totals": totals}, "POSTHOC_STDOUT")

    post_manifest = reader.json(P / "inventory.json")
    keys(post_manifest, "schema directory members inventory_self_excluded member_count member_bytes", "POST_INVENTORY_KEYS")
    equal(post_manifest["schema"], "trnm-joint-resource-posthoc-inventory-v1", "POST_INVENTORY_SCHEMA")
    equal(post_manifest["directory"], str(P), "POST_INVENTORY_ROOT")
    equal(post_manifest["inventory_self_excluded"], True, "POST_SELF_EXCLUDED")
    expected_p = {"analysis.json", "analysis.py", "analysis.stderr.log", "analysis.stdout.log",
                  "preflight.stderr.log", "preflight.stdout.log", "receipt.json", "summary.json"}
    require(p_inventory == expected_p | {"inventory.json"}, "POST_PHYSICAL_INVENTORY")
    require(type(post_manifest["members"]) is list, "POST_MEMBERS")
    require([item.get("name") for item in post_manifest["members"]] == sorted(expected_p), "POST_MEMBER_NAMES")
    post_bytes = 0
    for item in post_manifest["members"]:
        keys(item, "name size sha256", "POST_MEMBER_KEYS")
        raw = reader.read(P / item["name"])
        equal(item["size"], len(raw), "POST_MEMBER_BYTES")
        equal(item["sha256"], digest(raw), "POST_MEMBER_HASH")
        post_bytes += len(raw)
    equal(post_manifest["member_count"], 8, "POST_MEMBER_COUNT")
    equal(post_manifest["member_bytes"], post_bytes, "POST_MEMBER_SUM")
    script_raw = reader.pinned(P / "analysis.py", 17671,
        "9dc5b8f2449349e0a1353f174f3f373c1d2941796a5ac72329862273fdec00e0")
    receipt = reader.json(P / "receipt.json")
    keys(receipt, "schema source scope new_simulator_executions new_independent_samples attack_probability_estimated "
         "original_campaign_directory output_directory script started_utc ended_utc stages exception "
         "all_planned_stages_pass physical_resource_fairness_qualified network_byte_budget_qualified "
         "production_consensus_activation release_ready", "POST_RECEIPT_KEYS")
    for key, wanted in {
        "schema": "trnm-joint-resource-posthoc-execution-v1", "source": A,
        "scope": "one posthoc descriptive readback of original retained 128 cases; no simulator execution",
        "new_simulator_executions": 0, "new_independent_samples": 0, "attack_probability_estimated": False,
        "original_campaign_directory": str(C), "output_directory": str(P),
        "script": {"path": str(P / "analysis.py"), "size": len(script_raw), "sha256": digest(script_raw)},
        "exception": None, "all_planned_stages_pass": True, "physical_resource_fairness_qualified": False,
        "network_byte_budget_qualified": False, "production_consensus_activation": False, "release_ready": False,
    }.items():
        equal(receipt[key], wanted, "POST_RECEIPT_" + key)
    require(type(receipt["stages"]) is list and len(receipt["stages"]) == 2, "POST_STAGE_COUNT")
    stage_plan = [("preflight", ["/usr/bin/bash", "scripts/project-preflight.sh"], str(R), 90),
                  ("analysis", ["/usr/bin/python3", str(P / "analysis.py")], str(P), 180)]
    previous_end = stamp(receipt["started_utc"])
    for stage, (name, argv, cwd, timeout) in zip(receipt["stages"], stage_plan):
        keys(stage, "name argv cwd started_utc ended_utc elapsed_wall_seconds timeout_seconds timed_out "
             "spawn_error returncode stdout stderr", "POST_STAGE_KEYS")
        equal([stage["name"], stage["argv"], stage["cwd"], stage["timeout_seconds"]],
              [name, argv, cwd, timeout], "POST_STAGE_COMMAND")
        equal([stage["returncode"], stage["timed_out"], stage["spawn_error"]], [0, False, None], "POST_STAGE_SUCCESS")
        require(previous_end <= stamp(stage["started_utc"]) <= stamp(stage["ended_utc"]), "POST_STAGE_ORDER")
        previous_end = stamp(stage["ended_utc"])
        number(stage["elapsed_wall_seconds"], "POST_ELAPSED")
        for stream in ("stdout", "stderr"):
            raw = reader.read(P / (name + "." + stream + ".log"))
            equal(stage[stream], {"path": str(P / (name + "." + stream + ".log")),
                                 "size": len(raw), "sha256": digest(raw)}, "POST_STAGE_LOG")
        require(reader.read(P / (name + ".stderr.log")) == b"", "POST_STDERR")
    require(previous_end <= stamp(receipt["ended_utc"]), "POST_END_ORDER")
    require(stamp(receipt["stages"][1]["started_utc"]) <= stamp(analysis["started_utc"])
            <= stamp(analysis["ended_utc"]) <= stamp(receipt["stages"][1]["ended_utc"]), "ANALYSIS_TIMING")
    reader.final_check()
    require(physical_inventory(F) == f_inventory and physical_inventory(C) == c_inventory
            and physical_inventory(P) == p_inventory, "FINAL_INVENTORY_CHANGED")
    return {
        "schema": "trnm-retained-formal-posthoc-verification-v1", "source": A, "tree": T,
        "formal_pass": True, "formal_commands": 6, "unittest_methods": 242,
        "unittest_unique_identifiers": 242, "unittest_skips": 0,
        "source_guard_equal": True, "source_git_blob_hashes_verified": len(blobs),
        "campaign_runs": 128, "complete_pairs": 64, "gzip_trace_files": 128,
        "gzip_trace_rows": gzip_rows, "termination_histogram": totals["termination_histogram"],
        "formal_files": len(f_inventory), "formal_bytes": sum(reader.observed[F / name][0] for name in f_inventory),
        "formal_manifest_sha256": digest(reader.read(F / "execution-manifest.json")),
        "campaign_files": len(c_inventory), "campaign_bytes": sum(reader.observed[C / name][0] for name in c_inventory),
        "campaign_manifest_sha256": digest(manifest_raw),
        "posthoc_files": len(p_inventory), "posthoc_bytes": sum(reader.observed[P / name][0] for name in p_inventory),
        "posthoc_inventory_sha256": digest(reader.read(P / "inventory.json")),
        "posthoc_analysis_sha256": digest(analysis_raw), "posthoc_stdout_sha256": digest(post_stdout_raw),
        "by_policy": by_policy, "by_policy_environment": by_environment,
        "by_policy_quantum_clock": by_clock, "by_policy_environment_quantum_clock": by_cell,
        "honest_short_epochs": short_epochs, "totals": totals,
        "selected_extreme_details": expected_analysis["selected_extreme_details"],
        "new_simulator_executions": 0, "new_independent_samples": 0,
        "input_hashes_reverified_at_end": True, "old_cloud_validation_terminal_outcome": "UNKNOWN",
        "physical_resource_fairness_qualified": False, "network_byte_budget_qualified": False,
        "production_consensus_activation": False, "release_ready": False,
    }

