import datetime,hashlib,json,os,resource,subprocess,time
from pathlib import Path
root=Path('/workspace/scratch/62902f6722b7/chain-next')
out=Path('/workspace/scratch/62902f6722b7/sqlite-watch/native')
out.mkdir(parents=True,exist_ok=False)
env=os.environ.copy();env['CARGO_TARGET_DIR']='/workspace/scratch/62902f6722b7/sqlite-watch-target'
env['TRNM_PN1_VFS_FINITE_CONTROL_V2_DIR']=str(out/'public-api')
env['TRNM_PN1_HELD_V1_DIR']=str(out/'held-directory')
common=['cargo','test','--offline','--locked','--manifest-path','trillionnium/Cargo.toml','-p','trnm-sqlite-io-boundary','--all-features']
commands=[('library',common+['--lib','--','--test-threads=1']),
 ('public-api',common+['--test','native_public_api_v2','finite_native_public_api_controls_v2','--','--ignored','--exact','--test-threads=1']),
 ('held-directory',common+['--test','native_held_directory_v1','--','--ignored','--test-threads=1'])]
records=[]
for label,command in commands:
 start=time.monotonic();u0=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(label+'.log')).open('xb') as log:
  p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 u1=resource.getrusage(resource.RUSAGE_CHILDREN);raw=(out/(label+'.log')).read_bytes()
 record={'label':label,'command':command,'exit':p.returncode,'wall_seconds':time.monotonic()-start,
  'waited_child_cpu_seconds':u1.ru_utime+u1.ru_stime-u0.ru_utime-u0.ru_stime,
  'log_sha256':hashlib.sha256(raw).hexdigest(),'log_bytes':len(raw),
  'build_rs_sha256':hashlib.sha256((root/'trillionnium/crates/trnm-sqlite-io-boundary/build.rs').read_bytes()).hexdigest()}
 records.append(record);(out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record),flush=True)
(out/'summary.json').write_text(json.dumps({'source_base':'0ca272d09d1522b0ffd740e441b6d3de1ed81de6','commands':records,'public_service_acceptance':False},indent=2)+'\n')
