import pathlib,json,sys,os,stat,hashlib,tarfile,subprocess
payload=json.load(sys.stdin)
parent=pathlib.Path('/data/chain-six-5176-20261108');root=parent/'source';experiment=parent/'f0-proof-supplement'
summary=json.loads((experiment/'summary.json').read_text());assert summary['result']=='PASS'
expected='4505a598d6ec2644a175e47398d4a5f3f054bc5e';assert summary['source_head']==expected and summary['source_binary_inputs_unchanged']
assert summary['new_complete_proofs_generated']==0 and summary['all_15_stark_inputs_identical']
plan=json.loads((experiment/'build-plan.json').read_text())
prior_bundle=parent/'fresh-stark-public-bundle';prior_manifest=json.loads((prior_bundle/'manifest.json').read_text())
prior_archive=parent/'w1-fresh-stark-native-5176-20261109.tar.gz'
def sha(data):return hashlib.sha256(data).hexdigest()
prior_sha=sha(prior_archive.read_bytes());assert prior_sha=='5c42a370d3c39c0d144047f0c2308c5b113a1e752e51fb90061643aa699f68f8'
bundle=parent/'f0-proof-public-bundle';bundle.mkdir();objects=bundle/'objects';objects.mkdir()
files={};object_records={}
def include(path,relative,expected_record=None):
 before=path.lstat()
 if not stat.S_ISREG(before.st_mode):raise ValueError('non-regular input: '+str(path))
 data=path.read_bytes();after=path.lstat()
 key=lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 assert key(before)==key(after) and len(data)==before.st_size,'unstable bundle input'
 record={'bytes':len(data),'sha256':sha(data),'mode':stat.S_IMODE(before.st_mode)}
 if expected_record is not None:assert record['sha256']==expected_record['sha256'] and record['bytes']==expected_record['bytes'],relative
 if record['sha256'] not in object_records:
  with (objects/record['sha256']).open('xb') as stream:stream.write(data)
  object_records[record['sha256']]={'bytes':len(data)}
 files[relative]=record
for path in sorted(experiment.rglob('*')):
 if path.is_file():include(path,'experiment/'+str(path.relative_to(experiment)))
for relative,pin in plan['source_inputs'].items():include(root/relative,'source/'+relative,pin)
for delta in summary['adapter_input_differences']:
 path=delta['path'];record=prior_manifest['files']['source/'+path]
 include(prior_bundle/'objects'/record['sha256'],'prior-source-differences/'+path,record)
gen_dir=parent/'fresh-stark/generation-01';gen=json.loads((gen_dir/'summary.json').read_text())
for filename in ['sha.proof.bin','arith.proof.bin']:
 include(gen_dir/'proof'/filename,'reused-proof-inputs/'+filename,gen['outputs']['proof/'+filename])
for name in ['summary.json','plan.json']:
 include(gen_dir/name,'original-generation-records/'+name)
include(root/'formal/pon-nakamoto-v1/w1_node_adapter_research/run_node_controls.py','helpers/run_node_controls.py')
diff_paths=[d['path'] for d in summary['adapter_input_differences']]
diff=subprocess.check_output(['git','-C',str(root),'diff',summary['prior_generation_source_head'],expected,'--',*diff_paths])
(bundle/'source-delta.patch').write_bytes(diff)
manifest={'schema':'trnm-f0-native-proof-supplement-content-addressed-5176-v1','runtime_source_head':expected,
 'prior_generation_source_head':summary['prior_generation_source_head'],'prior_generation_relabelled_as_f0':False,
 'prior_archive_sha256':prior_sha,'new_complete_proofs_generated':0,'all_15_stark_inputs_identical':True,
 'adapter_source_input_differences':summary['adapter_input_differences'],'original_public_resource_profile':False,
 'production_activation':False,'production_vfs_qualified':False,'qualification':'HOLD_NO_GO','third_party_build_closure_complete':False,
 'files':files,'objects':object_records,'omitted_files':[]}
(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(bundle/'README.md').write_text(payload['readme']);(bundle/'restore.py').write_text(payload['restore'])
(bundle/'package-runner.py').write_bytes(pathlib.Path('/proc/self/cmdline').read_bytes().split(b'\0')[2])
restored=parent/'f0-proof-bundle-restore-validation'
with (bundle/'restore-validation.stdout').open('xb') as out,(bundle/'restore-validation.stderr').open('xb') as err:
 subprocess.run(['/usr/bin/python3',str(bundle/'restore.py'),str(restored)],stdout=out,stderr=err,check=True,timeout=120)
archive=parent/'w1-f0-native-proof-supplement-5176-20261109.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=6) as tar:tar.add(bundle,arcname='w1-f0-native-proof-supplement-5176',recursive=True)
count=0
with tarfile.open(archive,'r:gz') as tar:
 for member in tar.getmembers():
  path=pathlib.PurePosixPath(member.name)
  assert not path.is_absolute() and '..' not in path.parts
  if member.isfile() and len(path.parts)==3 and path.parts[1]=='objects':
   data=tar.extractfile(member).read();assert sha(data)==path.parts[2] and len(data)==object_records[path.parts[2]]['bytes'];count+=1
assert count==len(object_records)
assert sha(prior_archive.read_bytes())==prior_sha
result={'schema':manifest['schema'],'result':'PASS','archive_path':str(archive),'archive_bytes':archive.stat().st_size,
 'archive_sha256':sha(archive.read_bytes()),'manifest_path':str(bundle/'manifest.json'),'manifest_sha256':sha((bundle/'manifest.json').read_bytes()),
 'logical_files':len(files),'unique_objects':len(object_records),'all_archive_objects_verified':True,'all_logical_files_restored':True,
 'source_head':expected,'prior_generation_source_head':summary['prior_generation_source_head'],'prior_archive_unchanged':True,
 'adapter_inputs_compared':1526,'adapter_input_differences':len(summary['adapter_input_differences']),'all_15_stark_inputs_identical':True,
 'native_controls':summary['controls'],'current_f0_binary':summary['binary'],'records':summary['records'],
 'new_complete_proofs_generated':0,'original_public_resource_profile':False,'qualification':'HOLD_NO_GO'}
(parent/'f0-proof-bundle-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
