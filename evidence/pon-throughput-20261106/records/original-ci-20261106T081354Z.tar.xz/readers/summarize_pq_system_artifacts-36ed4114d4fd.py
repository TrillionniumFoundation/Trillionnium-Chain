#!/usr/bin/env python3
"""Summarize downloaded original PQ controls/full artifacts without rerunning tests."""
import csv
import hashlib
import io
import json
import re
import zipfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
HEAD = "9e50ca8e1ce655ef2f4686bd0ab58120b30c4632"
TREE = "8d67d4812661393cfc9dba2474c279d8285d6dee"
REPO = "TrillionniumFoundation/Trillionnium-Chain"
RUN = 42179335849


def test_results(text):
    return [{"result": m[0], **{k: int(v) for k, v in zip(("passed", "failed", "ignored", "measured", "filtered_out"), m[1:])}}
            for m in re.findall(r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out", text)]


def summarize(meta_path):
    meta = json.loads(meta_path.read_text())
    if not meta.get("name", "").startswith("pq-system-"):
        return None
    aid = int(meta_path.stem.split("-")[1])
    path = BASE / f"artifact-{aid}.zip"
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert "sha256:" + digest == meta["digest"]
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        names = set(z.namelist())
        commands = {}
        for name in names:
            if not name.endswith(".json"):
                continue
            try:
                data = json.loads(z.read(name))
            except (ValueError, UnicodeError):
                continue
            if not isinstance(data, dict) or data.get("schema") != "trnm-pq-native-command-v1":
                continue
            log = z.read(data["log_file"])
            log_text = log.decode(errors="replace")
            assert len(log) == data["log_bytes"] and hashlib.sha256(log).hexdigest() == data["log_sha256"]
            for source in (data["before"], data["after"]):
                assert source["candidate"] == HEAD and source["tested_tree"] == TREE and source["tracked_worktree_verified"] is True
            assert data["before"] == data["after"]
            commands[name[:-5]] = {"record_path": name, "argv": data["argv"], "status": data["status"], "exit_code": data["exit_code"],
                "elapsed_ns": data["elapsed_ns"], "source": data["before"], "source_before_after_equal": True,
                "log_path": data["log_file"], "log_sha256": data["log_sha256"], "log_bytes": len(log),
                "log_digest_verified": True, "libtest_results": test_results(log_text)}
            failed_tests = re.findall(r"^test (\S+) \.\.\. FAILED$", log_text, flags=re.MULTILINE)
            if failed_tests:
                failures = []
                lines = log_text.splitlines()
                for failed in failed_tests:
                    marker = f"---- {failed} stdout ----"
                    starts = [i for i, line in enumerate(lines) if line == marker]
                    assert len(starts) == 1, (failed, starts)
                    first = starts[0]
                    last = next((i for i in range(first + 1, len(lines)) if lines[i].startswith("---- ") or lines[i] == "failures:"), len(lines))
                    excerpt = "\n".join(lines[first:last]) + "\n"
                    failures.append({"test": failed, "source_log": data["log_file"], "source_log_sha256": data["log_sha256"], "first_line": first + 1, "last_line": last, "excerpt": excerpt})
                commands[name[:-5]]["native_failed_tests"] = failed_tests
                commands[name[:-5]]["native_failure_excerpts"] = failures
        def required(path, tls=False):
            rows = list(csv.reader(io.StringIO(z.read(path).decode()), delimiter="\t"))
            output = []
            for row in rows:
                label, selector = row[0], row[-1]
                execution_path = label + "-execution.json"
                result = json.loads(z.read(execution_path))
                assert result["test"] == selector
                command = commands[label]
                expected = {"result": "ok", "passed": 1, "failed": 0, "ignored": 0, "measured": 0}
                matched = len(command["libtest_results"]) == 1 and all(command["libtest_results"][0][k] == v for k, v in expected.items())
                output.append({"label": label, "selector": selector, "registry_kind": row[1] if tls else "lib",
                    "execution_path": execution_path, "execution": result, "native_log_exactly_one_pass": matched,
                    "exit_code": command["exit_code"], "log_path": command["log_path"]})
            return output
        native = required("required-tests.tsv")
        tls = required("tls-required.tsv", True)
        scopes = []
        for name in sorted(names):
            if name.startswith("scope-") and name.endswith("-execution.json"):
                data = json.loads(z.read(name))
                label = name[:-len("-execution.json")]
                scopes.append({"execution_path": name, "execution": data, "exit_code": commands[label]["exit_code"], "native_results": commands[label]["libtest_results"]})
        special = {label: commands[label] for label in ("public-submit-pq-owner", "public-submit-recovery", "node-lib", "clippy") if label in commands}
        return {"artifact_id": aid, "artifact_name": meta["name"], "artifact_url": f"https://github.com/{REPO}/actions/runs/{RUN}/artifacts/{aid}",
            "run_id": RUN, "run_url": f"https://github.com/{REPO}/actions/runs/{RUN}", "archive_sha256": digest, "archive_bytes": len(raw), "archive_local_path": str(path),
            "is_pre_full_regression_snapshot": meta["name"].startswith("pq-system-controls-"),
            "source": commands["build"]["source"], "command_count": len(commands),
            "commands": commands, "nonzero_commands": [v for v in commands.values() if v["exit_code"] != 0],
            "required_native_controls": native, "required_tls_controls": tls, "required_scope_controls": scopes, "special_suites": special,
            "qualification": "Finite controls only; partial artifacts do not imply terminal job/workflow success. Controls overlap with full library/regression suites and must not be summed as unique tests. No TPS or whole-chain quantum-security qualification."}


items = [v for p in sorted(BASE.glob("artifact-[0-9]*.json")) if (v := summarize(p)) is not None]
out = BASE / "pq-system-original-artifact-summary.json"
out.write_text(json.dumps({"schema": "original-pq-system-artifact-summary-v1", "head": HEAD, "tree": TREE, "run_id": RUN, "artifacts": items}, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"path": str(out), "sha256": hashlib.sha256(out.read_bytes()).hexdigest(), "matrices": [{"artifact_id": i["artifact_id"], "name": i["artifact_name"], "native_controls": len(i["required_native_controls"]), "native_pass": sum(r["native_log_exactly_one_pass"] and r["exit_code"] == 0 for r in i["required_native_controls"]), "tls_controls": len(i["required_tls_controls"]), "tls_pass": sum(r["native_log_exactly_one_pass"] and r["exit_code"] == 0 for r in i["required_tls_controls"]), "scope_controls": len(i["required_scope_controls"]), "scope_pass": sum(r["execution"].get("result") == "PASS" and r["exit_code"] == 0 for r in i["required_scope_controls"]), "node_library": i["special_suites"].get("node-lib", {}).get("libtest_results"), "nonzero_commands": [c["record_path"] for c in i["nonzero_commands"]]} for i in items]}))
