import pathlib,os,json,hashlib,shutil,importlib.util,stat,time
task=pathlib.Path("/home/qian-qi/work/chain-pq-migration-recovery-e1dee-20261106")
spec=importlib.util.spec_from_file_location("native_runner",task/"native-validation-v1.py")
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
out=task/"records/rollback-verification";out.mkdir(mode=0o700)
env=runner.load_environment("target-fixed");head=runner.FIXED
binary=task/"retained-checkpoint-fault-domain-probe"
expected_binary="8151dfced4ed72986279e6bb4404dd9ac96ff0b1ef3ddbe40e62aff249395b70"
expected_pin="6b1cbc4afafca25b15c40e849f827a387c3a1354be338494f1d2d7fe600e54d3"
assert runner.digest(binary)==expected_binary
# Read-only preservation of the failed 205 test executable if it has not yet
# been replaced by the separately owned corrected build; never touch its target.
old=task/"records/native-fixed/node-migration-binaries-before.json"
retained=task/"retained-original-native-205";retained.mkdir(mode=0o700)
observations=[]
for row in json.loads(old.read_text()):
 source=pathlib.Path(row["path"]);destination=retained/(source.name+"-"+row["sha256"])
 observation={"source_path":str(source),"expected_sha256":row["sha256"],"expected_size":row["size"]}
 try:
  with source.open("rb") as original,destination.open("xb") as target:
   before=os.fstat(original.fileno());h=hashlib.sha256()
   for data in iter(lambda:original.read(1024*1024),b""):h.update(data);target.write(data)
   target.flush();os.fsync(target.fileno());after=os.fstat(original.fileno())
  os.chmod(destination,0o555)
  observation.update(retained_path=str(destination),actual_sha256=h.hexdigest(),
    actual_size=destination.stat().st_size,opened_inode_before=before.st_ino,opened_inode_after=after.st_ino,
    preserved_matches_original=(h.hexdigest()==row["sha256"] and destination.stat().st_size==row["size"]))
 except OSError as error:observation.update(preserved_matches_original=False,error=str(error))
 observations.append(observation)
runner.save(out/"original-node-binary-preservation.json",observations)
runner.record(task/"source",head,out,env,"preflight",["/bin/bash","scripts/project-preflight.sh"])
exercise=task/"exercise";node=exercise/"node";current=exercise/"retained-current-node"
returned=exercise/"returned-from-x230.bin";alternate=task/"alternate-exercise"
assert runner.digest(returned)==expected_pin
old_snapshot=json.loads((task/"records/rollback-preparation/result.json").read_text())
expected=old_snapshot["after_restore"]
def inventory(root):
 result={}
 for p in sorted(root.iterdir()):
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
  result[p.name]={"sha256":runner.digest(p),"size":info.st_size,"mode":stat.S_IMODE(info.st_mode)}
 return result
assert inventory(node)==expected
pin=returned.read_bytes();alternate_pin=(alternate/"fresh-export.bin").read_bytes()
assert len(pin)==84 and len(alternate_pin)==84
assert int.from_bytes(pin[12:20],"big")==int.from_bytes(alternate_pin[12:20],"big")==2
assert pin[20:52]!=alternate_pin[20:52]
cases=[
 ("fresh-independent-pin-rejects-restored-old-world",node/"checkpoint.log",returned,1),
 ("fresh-independent-pin-accepts-current-world",current/"checkpoint.log",returned,0),
 ("valid-alternate-same-count-world",alternate/"node/checkpoint.log",alternate/"fresh-export.bin",0),
 ("same-count-different-root-refused",current/"checkpoint.log",alternate/"fresh-export.bin",1),
 ("old-pin-refuses-locally-newer-world",current/"checkpoint.log",node/"local-pin.bin",1)]
for label,log,expectation,code in cases:
 runner.record(task/"source",head,out,env,label,[str(binary),"verify",str(log),str(expectation)],code)
 assert inventory(node)==expected
withheld=exercise/"withheld-returned-from-x230.bin"
assert not withheld.exists();os.rename(returned,withheld)
runner.record(task/"source",head,out,env,"known-fresh-pin-unavailable-refuses",
 [str(binary),"verify",str(node/"checkpoint.log"),str(returned)],1)
assert inventory(node)==expected
os.rename(withheld,returned)
assert runner.digest(returned)==expected_pin and runner.digest(binary)==expected_binary
result={"schema":"trnm-two-host-checkpoint-recovery-observation-v1","created_unix_ns":time.time_ns(),
 "source":head,"tree":runner.FIXED_TREE,"runtime_host":"rog","custody_host":"x230",
 "custody_fsync_job":"1a1b34e0fc9-fc05-81e8","restore_job":"1a1b35132ed-fc05-8201",
 "fresh_pin_returned_after_restore":True,"fresh_pin_sha256":expected_pin,"fresh_pin_record_count":2,
 "fresh_pin_root":pin[20:52].hex(),"alternate_pin_record_count":2,"alternate_pin_root":alternate_pin[20:52].hex(),
 "same_count_roots_differ":True,"probe_sha256":expected_binary,
 "full_declared_namespace_restore_verified":True,"restored_files_unchanged_by_refusals":True,
 "coherent_old_world_without_external_freshness_remains_accepted_counterexample":True,
 "positive_and_negative_commands":runner.COMMANDS,"original_node_binary_preservation":observations,
 "controlled_synthetic_test_data_only":True,"physical_power_failure_tested":False,
 "production_key_custody_qualified":False,"independent_administrator_qualified":False,
 "whole_node_runtime_effects_qualified":False,"production_activation":False}
runner.save(out/"result.json",result)
print(json.dumps({"status":"two-real-host-control-exercise-completed","source":head,"runtime_host":"rog","custody_host":"x230",
 "fresh_pin_rejects_restored_old_world":True,"correct_current_world_accepted":True,
 "same_count_different_root_refused":True,"missing_pin_refused":True,"old_world_counterexample_retained":True,
 "production_custody_qualified":False,"whole_node_effects_qualified":False}),flush=True)

