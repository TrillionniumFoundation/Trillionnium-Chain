//! Actual correct-product / false-transcript negative controls.
//! This is attack-cost research against the primitive, not a Node traffic test.
use super::*;

pub fn run(out: &Path, samples: usize, cases: &[&str]) -> AnyResult<()> {
    if samples == 0 || samples > 64 || cases.is_empty() {
        return Err("negative control bounds".into());
    }
    fs::create_dir(out)?;
    let mut rows = Vec::new();
    for case in cases {
        let (a, b) = material(case)?;
        let ((task, prefix), setup_wall, setup_cpu) = measure(|| {
            let task = pon_work::task_id(&a, &b).map_err(work_error)?;
            // Charge actual public-product computation and serialization once.
            let product: Vec<u32> = (0..N)
                .flat_map(|i| {
                    let a = &a;
                    let b = &b;
                    (0..N).map(move |j| {
                        ((0..N)
                            .map(|k| u128::from(a[i * N + k]) * u128::from(b[k * N + j]))
                            .sum::<u128>()
                            % Q) as u32
                    })
                })
                .collect();
            let mut prefix = b"PNW1".to_vec();
            for values in [&a, &b, &product] {
                for value in values {
                    prefix.extend_from_slice(&value.to_le_bytes());
                }
            }
            Ok((task, prefix))
        })?;
        for sample in 0..samples {
            let ((h, c, proof, trials), forge_wall, forge_cpu) = measure(|| {
                let h = header(task, (sample + 1) as u64, 4);
                let c = hash(b"challenge", &[&h]);
                let target: Hash = h[118..150].try_into().unwrap();
                let mut proof = prefix.clone();
                for nonce in 0_u64..65536 {
                    let trace = hash(
                        b"p0-false-trace-correct-product-v1",
                        &[&(sample as u64).to_le_bytes(), &nonce.to_le_bytes()],
                    );
                    if hash(b"ticket", &[&c, &trace]) <= target {
                        proof.extend_from_slice(&trace);
                        return Ok((h, c, proof, nonce + 1));
                    }
                }
                Err("correct-product negative search exhausted".into())
            })?;
            let target: Hash = h[118..150].try_into().unwrap();
            let (_, precheck_wall, precheck_cpu) = measure(|| {
                pon_work::precheck_proof_statement(c, task, target, &proof).map_err(work_error)
            })?;
            let (result, reject_wall, reject_cpu) =
                measure(|| Ok(pon_work::verify(c, task, target, &proof).err()))?;
            if result != Some(WorkError::Transcript) {
                return Err("correct-product false transcript did not reject".into());
            }
            let mut tiles = 0;
            let observed = pon_work::verify_with_progress(c, task, target, &proof, &mut |point| {
                if matches!(point, pon_work::VerificationProgress::TranscriptTile { .. }) {
                    tiles += 1;
                }
                Ok::<_, std::convert::Infallible>(())
            });
            if !matches!(
                observed,
                Err(pon_work::VerificationError::Relation(WorkError::Transcript))
            ) || tiles != 512
            {
                return Err("negative-control replay boundary mismatch".into());
            }
            let path = format!("correct-product-{case}-{sample}.bin");
            let mut bytes = h;
            bytes.extend_from_slice(&proof);
            write_new(&out.join(&path), &bytes)?;
            rows.push(json!({
                "case":case,"sample":sample,"task":hex(&task),"hash_trials":trials,
                "public_product_setup_wall_ns":setup_wall,"public_product_setup_cpu_ns":setup_cpu,
                "setup_shared_across_samples":samples,"setup_is_charged_once_per_case":true,
                "forge_wall_ns":forge_wall,"forge_cpu_ns":forge_cpu,
                "precheck_wall_ns":precheck_wall,"precheck_cpu_ns":precheck_cpu,
                "full_reject_wall_ns":reject_wall,"full_reject_cpu_ns":reject_cpu,
                "cheap_original_precheck_passed":true,"correct_product_bytes":true,
                "all_512_tiles_observed_in_separate_replay":true,
                "full_verifier_result":"Transcript","node_entry_executed":false,
                "path":path,"bytes":bytes.len(),"sha256":digest(&bytes)
            }));
        }
    }
    let binary = fs::read(std::env::current_exe()?)?;
    write_json(
        &out.join("raw.json"),
        &json!({
            "schema":"trnm-w1-correct-product-false-trace-cost-v1",
            "source_commit":statement::SOURCE_COMMIT,"binary_sha256":digest(&binary),
            "target_bits":4,"samples":samples,"cases":cases,"rows":rows,
            "public_product_semantics_reviewed_at":"5e797326b9c7635e43b93f97c65a309e51eafb46",
            "scope":"Exact W1 primitive rejection; full correct C computed and charged in setup. No Node, task eligibility, networking or reward call.",
            "cached_product_filter_is_not_a_transcript_proof":true,
            "independent_security_puzzle":false,"succinct_proof":false,
            "global_minimum_attack_cost_proved":false
        }),
    )?;
    println!(
        "{}",
        json!({"event":"correct_product_negative_controls_complete","rows":rows.len(),"node_entry_executed":false})
    );
    Ok(())
}
