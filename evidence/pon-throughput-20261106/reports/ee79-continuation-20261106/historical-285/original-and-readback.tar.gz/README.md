# Historical cost evidence recovered after executor loss

This archive re-reads the original failed native campaign at commit `285982d78a4f62a064841cb0f106d18c865e19c5`, tree `ce074eb1857a92c9b47ea317b841777fcfc63c04`. It is a **post-executor-loss recomputation**, not a new native benchmark or current-source qualification. The lost original historical-cost-readback receipt has not been recovered or recreated. The new receipt is explicitly named `post-executor-loss-readback-receipt.json`.

## Provenance and reproducibility

The original GitHub workflow is run 42185197057, job 127783768291, artifact 13487374156, attempt 1. The fresh GitHub readback still reports failure. The downloaded ZIP is 65,252,256 bytes with SHA256 `311f2e16e8b35adda91727d6ed3a162054a9ec51bd291252827bc5019e357e9a`. The complete ZIP is retained beside this compact archive, but is not included in it. Selected original entries are byte-exact; `selected-entry-manifest.json` records their hashes. No archived binary was executed.

`run-1-report.json.gz` losslessly contains the original `run-1-raw/report.json`: 31,228,413 bytes, SHA256 `3c3daa37eeb2584e82ea7551f3821c451bbb8463c697f722068c1632224a7d58`. Its recompressed bytes reproduce the previously recorded gzip exactly: 2,369,982 bytes, SHA256 `20c6610b9e646786ec4d2cbbf39529b7688ff0bd64ec715d7657ebf0af41c662`. The compression method and earlier nonmatching compression attempts are recorded separately.

The reader plus all four local dependencies were copied directly from Git blobs at `af1441ef62e036eca60f4bd756b7a332b685f8c9`; see `reader-source-manifest.json`. This binds the reader implementation without claiming the concurrently modified checkout is a tested clean head. The original before/after source receipts are identical and identify only the historical 285982d7 source.

The new reader returned exit 0 and recreated the former coverage bytes exactly: 546,525 bytes, SHA256 `b0f0b823fc293c156d191d816ac607c450245dec235860846de142621a32144f`. Byte equality does not recover the lost original execution receipt.

To reproduce in an extracted copy, decompress the report to `original-selected/run-1-raw/report.json`, then run:

```sh
python3 -B reader-source-af144/scripts/ci/throughput_cost_coverage.py original-selected/run-1-raw/report.json --report-sha256 3c3daa37eeb2584e82ea7551f3821c451bbb8463c697f722068c1632224a7d58 --source original-selected/source-before.json --source-after original-selected/source-after.json --expected-head 285982d78a4f62a064841cb0f106d18c865e19c5 --expected-tree ce074eb1857a92c9b47ea317b841777fcfc63c04 --kind head --output replay-cost-coverage.json
```

## Preserved outcome and cost limits

All three original campaigns retain exit 101 and failed original criteria. This coverage reads run 1 only. Its baseline observed one confirmation; both attack phases observed zero. These observations do not meet the original business criterion. No ACK is counted as confirmation.

All three run-1 listener epochs report zero PQ authentication attempts; zero attempts are not a PQ performance measurement. Full-pipeline CPU, physical network bytes, cold-recovery CPU and other absent measurements remain null. Host/native import CPU intervals remain nested within caller intervals and are never added as independent domains. Each epoch retains its own timestamps; historical telemetry does not qualify later source.

The file manifest covers this compact archive's files except the manifest itself. Original giant raw report bytes are recoverable from the included gzip; other original artifact entries remain in the retained ZIP and GitHub artifact, subject to retention.
