import pathlib,subprocess,json,time,hashlib,zipfile,stat,resource
out=pathlib.Path.home()/'work/chain-native-root-delay-f0-20261119-2e9b';assert out.is_dir();rec=out/'collection';assert not rec.exists();rec.mkdir()
repo='TrillionniumFoundation/Trillionnium-Chain';run_id=44441548029;head='333fe8cd89f0ec855e7b856e99e40f48f56c2137';stages=[];result={'schema':'chain-original-f0-complete-readback-v1','run_id':run_id,'expected_head':head,'business_dispatches_in_this_owner':0,'all_artifacts_requested':True,'f0_qualified':False,'stages':stages}
def save():
 (rec/'COLLECTION.json').write_text(json.dumps(result,indent=2)+'\n')
def run(name,args,binary=False):
 start=time.monotonic();ru=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (rec/(name+('.zip' if binary else '.stdout'))).open('xb') as so,(rec/(name+'.stderr')).open('xb') as se:p=subprocess.Popen(args,stdout=so,stderr=se);rc=p.wait()
 ra=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args,'returncode':rc,'wall_seconds':time.monotonic()-start,'child_user_cpu_seconds':ra.ru_utime-ru.ru_utime,'child_system_cpu_seconds':ra.ru_stime-ru.ru_stime};stages.append(row);save();print(json.dumps(row),flush=True);return rc
result['started_ns']=str(time.time_ns());save()
run('watch',['/usr/bin/gh','run','watch',str(run_id),'--repo',repo,'--exit-status','--interval','30'])
api='/repos/'+repo+'/actions/runs/'+str(run_id)
assert run('run',['/usr/bin/gh','api',api])==0
r=json.loads((rec/'run.stdout').read_text());assert r['id']==run_id and r['head_sha']==head and r['status']=='completed';result['actual_workflow_conclusion']=r['conclusion'];save()
assert run('jobs',['/usr/bin/gh','api',api+'/jobs?per_page=100'])==0
jobs=json.loads((rec/'jobs.stdout').read_text());assert len(jobs['jobs'])==jobs['total_count']
for j in jobs['jobs']:run('job-'+str(j['id'])+'-logs',['/usr/bin/gh','api','/repos/'+repo+'/actions/jobs/'+str(j['id'])+'/logs'])
assert run('artifacts',['/usr/bin/gh','api',api+'/artifacts?per_page=100'])==0
a=json.loads((rec/'artifacts.stdout').read_text());assert len(a['artifacts'])==a['total_count'];result['artifact_ids']=[x['id'] for x in a['artifacts']];save()
for artifact in a['artifacts']:
 assert not artifact['expired'];name='artifact-'+str(artifact['id']);assert run(name,['/usr/bin/gh','api','/repos/'+repo+'/actions/artifacts/'+str(artifact['id'])+'/zip'],True)==0
 target=rec/name;target.mkdir()
 with zipfile.ZipFile(rec/(name+'.zip')) as z:
  for item in z.infolist():
   p=pathlib.PurePosixPath(item.filename);assert not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(item.external_attr>>16)
  z.extractall(target)
files=[]
for p in sorted(rec.rglob('*')):
 if p.is_file() and p.name!='COLLECTION.json':
  raw=p.read_bytes();files.append({'path':str(p.relative_to(rec)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
result.update({'finished_ns':str(time.time_ns()),'files':files,'complete_download':True,'business_reader_verdict':'NOT_EVALUATED_BY_COLLECTOR'});save();print(json.dumps({'run_id':run_id,'artifacts':result['artifact_ids'],'files':len(files),'complete_download':True,'workflow_conclusion':r['conclusion']}),flush=True)
