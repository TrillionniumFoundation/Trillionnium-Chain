import os,sys
sys.path.insert(0,'/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/resource-comparison-audit-ec265-01/scripts')
import w1_owned_process_collector_v1 as c
original=c.process_identity
failed=False
def fail_once(pid,boot):
 global failed
 if pid not in (os.getpid(),os.getppid()) and not failed:
  failed=True
  raise OSError('actual post-fork proc read fault control')
 return original(pid,boot)
c.process_identity=fail_once
sys.exit(c.main(['--out', '/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/collector-controls-desktop-ec265-01/test_actual_post_fork_identity_failure_reaps_gated_root_without_exec/collector', '--deadline-monotonic-ns', '1187874433160386', '--deadline-boot-id', '14f92beb-43c6-4786-839e-b57307ae8048', '--cleanup-grace-seconds', '2', '--cwd', '/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/collector-controls-desktop-ec265-01/test_actual_post_fork_identity_failure_reaps_gated_root_without_exec', '--executable-sha256', 'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f', '--', '/usr/bin/python3.12', '/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/collector-controls-desktop-ec265-01/test_actual_post_fork_identity_failure_reaps_gated_root_without_exec/payload.py']))
