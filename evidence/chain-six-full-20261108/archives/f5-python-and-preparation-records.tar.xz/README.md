# F5 exact Python checks and preparation records

The checked commit is ab610cf95a6ec39b38e20e64e6367f5b529b3633, tree abd4442d789b29889960f9b0acc712b9fefed498.

All 257 fixed named Python controls passed: CI contract 164, source integrity 43 and repository 50. Original CI/repository/inventory/corpus CLIs passed. The current corpus retains 899 pins and 807 required paths. The integrated ML-DSA reader reproduces the four original refusals with the original reader, accepts the four original intended compile-fail logs with the corrected reader and rejects 19 mutated logs. The original 517-file real-learning verifier passes with the exact one-path raw storage mapping and unchanged original export manifest. Full tracked-source checks before and after are identical. Source integrity and unit identities are exact; no native/model/cryptographic experiment was rerun by this validation.

The first preparation job failed before modifying source because the extracted archive contained its documented root directory and the driver initially looked one level too high. Its original traceback and output remain under f5-preparation-runtime. The corrected preparation rechecked all extracted original members, applied the reviewed patches, refreshed only the generated inventory and committed the clean F5 source. Executed drivers and raw command outputs are included. Unexecuted draft validation scripts are not observations and are excluded.

The separate native compile archive records F5 strict Clippy, formatting and three locked/offline dependency graphs. F3 native execution, F4 original FAIL, hosted business failures, CodeQL API absence and the original incomplete ML-DSA hosted continuation remain unchanged. This archive does not establish independent operation, useful general learning, production admission or complete quantum soundness. Qualification remains HOLD / NO-GO.

The final evidence publication is a later commit. Its changed paths are checked separately; this archive never relabels F5 execution as a later-head experiment. Manifest checks and tar member readbacks are storage checks, not new execution.
