#!/usr/bin/env python3
"""Preserve verification bytes without changing any repository source.

The archive contains original observations with distinct source/result scopes.
Packaging/readback success never changes an embedded command result.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/e4648d82092d')
REPOSITORY = ROOT / 'chain'
VERIFICATION = ROOT / 'verification'
STAGING = ROOT / 'final-evidence-staging'
SOURCE = '523a4f431b65f8a52128962f5880c4030e3e05db'
TREE = '51b57df779e46bb16518c5c6c7aef90e48faa06d'
LIMIT = 4 * 1024 * 1024
MAX_MEMBER = 256 * 1024 * 1024
EXCLUDED_REVIEW_DRAFT = 'pr-review-draft.md'
SOURCE_HELPERS = (
    'scripts/ci/ci_observation.py',
    'scripts/ci/verify_ci_source.py',
    'scripts/ci/tool-versions.env',
    'scripts/project-preflight.sh',
    'formal/pon-nakamoto-v1/bounded_process.py',
)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data,
                        usedforsecurity=False).hexdigest()


def fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def read_regular(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode) or before.st_size > MAX_MEMBER:
            raise ValueError('UNEXPECTED_MEMBER_TYPE_OR_SIZE: ' + str(path))
        with os.fdopen(descriptor, 'rb', closefd=False) as stream:
            data = stream.read(MAX_MEMBER + 1)
        if (len(data) != before.st_size or fingerprint(before) != fingerprint(os.fstat(descriptor))
                or fingerprint(before) != fingerprint(path.lstat())):
            raise ValueError('SOURCE_CHANGED_DURING_READ: ' + str(path))
        return data, stat.S_IMODE(before.st_mode)
    finally:
        os.close(descriptor)


def verification_paths(final):
    result, omitted = [], []
    for path in sorted(VERIFICATION.rglob('*')):
        relative = path.relative_to(VERIFICATION).as_posix()
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode):
            raise ValueError('UNEXPECTED_SYMLINK: ' + relative)
        if stat.S_ISDIR(info.st_mode):
            continue
        if relative == EXCLUDED_REVIEW_DRAFT:
            omitted.append({'path': 'verification/' + relative,
                            'reason': 'Review prose draft, not an execution observation.'})
            continue
        if not final and relative in ('committed-b/source-after.json', 'committed-b/source-after.log'):
            omitted.append({'path': 'verification/' + relative,
                            'reason': 'Draft packaging only; the root whole-source-after guard is not yet frozen.'})
            continue
        if not stat.S_ISREG(info.st_mode):
            raise ValueError('UNEXPECTED_MEMBER_TYPE: ' + relative)
        result.append(path)
    return result, omitted


def verify_final_requirements():
    for name in ('source-before.json', 'source-after.json'):
        path = VERIFICATION / 'committed-b' / name
        data, _ = read_regular(path)
        value = json.loads(data)
        if (value.get('tested_commit') != SOURCE or value.get('tested_tree') != TREE
                or value.get('tracked_worktree_verified') is not True
                or value.get('tracked_entries') != 28341
                or value.get('tracked_bytes') != 2578941912):
            raise ValueError('FINAL_SOURCE_GUARD_NOT_MATCHED: ' + str(path))
    native = VERIFICATION / 'native/native-third-attempt-e464-20261112T003331Z.tar.gz'
    data, _ = read_regular(native)
    if sha256(data) != '2273c4cbb070d3ba4534337488a6f2676c61e48027dcf59f714a64f08bb2360d':
        raise ValueError('THIRD_NATIVE_ARCHIVE_NOT_MATCHED')


def write_json(path, value):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True)
    parser.add_argument('--final', action='store_true')
    args = parser.parse_args()
    if (not args.label or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-_' for c in args.label)):
        raise ValueError('NONCANONICAL_LABEL')
    if args.final:
        verify_final_requirements()
    output = STAGING / args.label
    output.mkdir(parents=False, exist_ok=False)
    paths, omitted = verification_paths(args.final)
    data_by_name = {}
    rows = []

    def add(name, path, source_kind, source_blob=None):
        if (name in data_by_name or PurePosixPath(name).is_absolute()
                or '..' in PurePosixPath(name).parts):
            raise ValueError('NONCANONICAL_OR_DUPLICATE_MEMBER')
        data, mode = read_regular(path)
        if source_blob is not None and git_blob(data) != source_blob:
            raise ValueError('HELPER_SOURCE_NOT_MATCHED: ' + name)
        data_by_name[name] = data
        rows.append({'path': name, 'bytes': len(data), 'sha256': sha256(data),
                     'git_blob_sha1': git_blob(data), 'mode_octal': oct(mode),
                     'source_kind': source_kind})

    for path in paths:
        add('verification/' + path.relative_to(VERIFICATION).as_posix(), path,
            'original-observation-or-recorded-runner')
    for relative in SOURCE_HELPERS:
        blob = subprocess.check_output(
            ['/usr/bin/git', '--no-replace-objects', 'rev-parse', SOURCE + ':' + relative],
            cwd=REPOSITORY, text=True).strip()
        add('source-helpers/' + relative, REPOSITORY / relative,
            'exact-frozen-B-helper', blob)
    add('packaging/build_evidence_archive.py', Path(__file__), 'archive-producer')
    rows.sort(key=lambda row: row['path'])
    archive = output / 'validation-evidence.tar.xz'
    with archive.open('xb') as raw:
        with tarfile.open(fileobj=raw, mode='w:xz', preset=6, format=tarfile.PAX_FORMAT) as tar:
            for row in rows:
                info = tarfile.TarInfo(row['path'])
                info.size, info.mode = row['bytes'], int(row['mode_octal'], 8)
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                tar.addfile(info, io.BytesIO(data_by_name[row['path']]))
    # Re-open every archived member and compare actual bytes, not just its header.
    with tarfile.open(archive, 'r:xz') as tar:
        members = tar.getmembers()
        if [m.name for m in members] != [r['path'] for r in rows]:
            raise ValueError('READBACK_MEMBERS_MISMATCH')
        for member, row in zip(members, rows):
            if not member.isfile() or member.size != row['bytes']:
                raise ValueError('READBACK_TYPE_OR_SIZE')
            data = tar.extractfile(member).read()
            if sha256(data) != row['sha256'] or data != data_by_name[member.name]:
                raise ValueError('READBACK_CONTENT')
    after_paths, after_omitted = verification_paths(args.final)
    if after_paths != paths or after_omitted != omitted:
        raise ValueError('VERIFICATION_MEMBER_SET_CHANGED_DURING_PACKAGING')
    for path in paths:
        data, _ = read_regular(path)
        if data != data_by_name['verification/' + path.relative_to(VERIFICATION).as_posix()]:
            raise ValueError('VERIFICATION_MEMBER_CHANGED_DURING_PACKAGING: ' + str(path))
    encoded = archive.read_bytes()
    archive_identity = {'filename': archive.name, 'bytes': len(encoded),
                        'sha256': sha256(encoded), 'git_blob_sha1': git_blob(encoded)}
    manifest = {'schema': 'trnm-local-validation-evidence-members-v1',
                'mode': 'FROZEN_AFTER_ROOT_SOURCE_GUARDS' if args.final else 'DRAFT_NOT_FOR_CORPUS',
                'created_at_utc': datetime.now(timezone.utc).isoformat(),
                'source_scope': 'Original pre-B partial exploration and frozen-B observations retain their distinct recorded identities and outcomes.',
                'frozen_B_commit': SOURCE, 'frozen_B_tree': TREE,
                'archive': archive_identity, 'member_count': len(rows),
                'total_member_bytes': sum(row['bytes'] for row in rows),
                'verification_member_count': len(paths),
                'verification_member_bytes': sum(len(data_by_name['verification/' + p.relative_to(VERIFICATION).as_posix()]) for p in paths),
                'excluded_non_evidence_or_unfinished_draft_paths': omitted,
                'all_members_read_back_and_bytes_verified': True,
                'original_verification_files_unchanged_during_packaging': True,
                'archive_included_in_itself': False,
                'packaging_success_promotes_no_original_command_result': True,
                'whole_chain_pq_qualified': False,
                'members': rows}
    manifest_path = output / 'validation-evidence.members.json'
    write_json(manifest_path, manifest)
    parts = []
    if len(encoded) > LIMIT:
        for index, offset in enumerate(range(0, len(encoded), LIMIT)):
            data = encoded[offset:offset + LIMIT]
            part = output / (archive.name + '.part-' + str(index).zfill(3))
            with part.open('xb') as stream:
                stream.write(data)
            parts.append({'index': index, 'path': part.name, 'offset_bytes': offset,
                          'bytes': len(data), 'sha256': sha256(data),
                          'git_blob_sha1': git_blob(data)})
        if b''.join((output / part['path']).read_bytes() for part in parts) != encoded:
            raise ValueError('ORDERED_PART_READBACK_MISMATCH')
        write_json(output / 'validation-evidence.parts.json', {
            'schema': 'trnm-evidence-byte-parts-v1',
            'scope': 'Byte-preserving storage; no command result or acceptance is promoted.',
            'per_file_source_read_limit_bytes': LIMIT, 'archive': archive_identity,
            'reconstruction': {'operation': 'Concatenate every part in listed order and verify the complete archive identity and member manifest.', 'part_count': len(parts)},
            'parts': parts, 'qualification': {'new_native_execution': False, 'whole_chain_pq_qualified': False}})
    receipt = {'schema': 'trnm-local-validation-evidence-packaging-v1',
               'mode': manifest['mode'], 'archive': archive_identity,
               'manifest': {'filename': manifest_path.name, 'bytes': manifest_path.stat().st_size,
                            'sha256': sha256(manifest_path.read_bytes()),
                            'git_blob_sha1': git_blob(manifest_path.read_bytes())},
               'member_count': len(rows), 'all_members_verified': True,
               'reader_per_file_limit_bytes': LIMIT, 'parts': parts,
               'repository_publish_files': ([part['path'] for part in parts] + ['validation-evidence.parts.json'] if parts else [archive.name]) + [manifest_path.name, 'validation-evidence.packaging.json'],
               'original_observation_statuses_unchanged': True,
               'no_repository_files_modified': True}
    write_json(output / 'validation-evidence.packaging.json', receipt)
    print(json.dumps({'output_directory': str(output), 'mode': manifest['mode'],
                      'archive': archive_identity, 'member_count': len(rows),
                      'verification_member_count': len(paths),
                      'total_member_bytes': manifest['total_member_bytes'],
                      'manifest_bytes': manifest_path.stat().st_size,
                      'part_count': len(parts), 'readback_verified': True}, sort_keys=True))


if __name__ == '__main__':
    main()
