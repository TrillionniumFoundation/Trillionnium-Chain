#!/usr/bin/env python3
"""Verify one sealed native archive and extract regular files into fresh scratch."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import tarfile

ROOT = Path("/workspace/scratch/7f73fe002713/daa-native-archive-recovery-v1")
EXPECTED_SIZE = 4657951
EXPECTED_SHA256 = "6c33da56842862608e365acb7c69d72175538556a2a76b74254f7b0357de9c81"
ARCHIVE_ROOT = "native-run-d23488c5-v1"


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_new(path, value):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--git-recovery-provenance", required=True, type=Path)
    args = parser.parse_args()
    assert args.archive.is_file() and not args.archive.is_symlink()
    assert args.archive.stat().st_size == EXPECTED_SIZE
    assert sha256(args.archive) == EXPECTED_SHA256
    provenance = json.loads(args.git_recovery_provenance.read_text())
    assert provenance["result"] == "PASS"
    assert provenance["archive_bytes"] == EXPECTED_SIZE
    assert provenance["archive_sha256"] == EXPECTED_SHA256
    assert provenance["frozen_source_commit"] == "d23488c5f9b4a6696c3799b12f14b8af0a1b81fc"
    assert provenance["checkout_performed"] is False
    assert provenance["native_or_reader_execution_performed"] is False
    assert provenance["retained_rpc_chunk_count"] == 36
    assert re.fullmatch("[0-9a-f]{40}", provenance["publication_commit"])
    assert re.fullmatch("[0-9a-f]{40}", provenance["native_archive_git_blob"])
    assert provenance["native_archive_git_path"] == "evidence/pon-monotone-daa-20261111/native/native-run-d23488c5-v1.tar.gz"
    assert provenance["evidence_only_changed_paths"] and all(
        path.startswith("evidence/pon-monotone-daa-20261111/")
        for path in provenance["evidence_only_changed_paths"])
    prior_chunks = json.loads((ROOT / "saved-chunks-at-pause.json").read_text())
    assert len(prior_chunks) == 36
    compared = {}
    with args.archive.open("rb") as handle:
        for name, expected in sorted(prior_chunks.items()):
            chunk = ROOT / "chunks" / name
            offset = int(name.removesuffix(".bin"))
            assert chunk.is_file() and not chunk.is_symlink()
            assert chunk.stat().st_size == expected["bytes"]
            assert sha256(chunk) == expected["sha256"]
            handle.seek(offset)
            actual = handle.read(expected["bytes"])
            assert hashlib.sha256(actual).hexdigest() == expected["sha256"]
            assert actual == chunk.read_bytes()
            compared[name] = {**expected, "offset": offset, "matches_complete_archive": True}
    archive = ROOT / (ARCHIVE_ROOT + ".tar.gz")
    if archive.exists():
        assert archive.is_file() and not archive.is_symlink()
        assert archive.stat().st_size == EXPECTED_SIZE and sha256(archive) == EXPECTED_SHA256
    else:
        with args.archive.open("rb") as source, archive.open("xb") as dest:
            shutil.copyfileobj(source, dest)
        assert archive.stat().st_size == EXPECTED_SIZE and sha256(archive) == EXPECTED_SHA256
    extract_root = ROOT / "extracted"
    assert not extract_root.exists(), "refuse to reuse an extraction directory"
    expanded = 0
    names = set()
    inventory = {}
    with tarfile.open(archive, "r:gz") as bundle:
        members = bundle.getmembers()
        assert len(members) <= 4096
        for member in members:
            name = PurePosixPath(member.name)
            assert name.parts and not name.is_absolute() and ".." not in name.parts, member.name
            assert name.parts[0] == ARCHIVE_ROOT, member.name
            assert member.isdir() or member.isfile(), member.name
            assert name.as_posix() not in names, member.name
            names.add(name.as_posix())
            assert 0 <= member.size <= 32 * 1024 * 1024, member.name
            expanded += member.size
        assert expanded <= 128 * 1024 * 1024
        extract_root.mkdir(mode=0o700)
        for member in members:
            path = extract_root / PurePosixPath(member.name)
            if member.isdir():
                path.mkdir(mode=0o700, parents=True, exist_ok=True)
                continue
            path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with bundle.extractfile(member) as source, path.open("xb") as dest:
                shutil.copyfileobj(source, dest)
            assert path.stat().st_size == member.size
            inventory[path.relative_to(extract_root).as_posix()] = {
                "bytes": member.size, "sha256": sha256(path)}
    write_new(ROOT / "extracted-files.json", inventory)
    report = {
        "schema": "pon-native-archive-local-recovery-verification-v2",
        "verified_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "archive": {"path": str(archive), "bytes": EXPECTED_SIZE, "sha256": EXPECTED_SHA256},
        "git_recovery_provenance": provenance,
        "git_recovery_provenance_file": {
            "path": str(args.git_recovery_provenance),
            "bytes": args.git_recovery_provenance.stat().st_size,
            "sha256": sha256(args.git_recovery_provenance)},
        "partial_binary_rpc_chunks": 36,
        "complete_archive_recovery_route": "normal Git fetch and git show by parent; whole archive verified locally",
        "all_saved_rpc_chunks_match": True,
        "saved_rpc_chunk_comparisons": compared,
        "safe_extraction": {
            "directory": str(extract_root), "regular_files": len(inventory),
            "expanded_file_bytes": sum(row["bytes"] for row in inventory.values()),
            "archive_members": len(members), "absolute_or_parent_paths_rejected": True,
            "only_directories_and_regular_files": True,
            "duplicate_member_names_rejected": True,
            "file_owner_mode_metadata_not_applied": True},
        "reader_execution_started": False,
        "independent_host_authentication": False,
        "production_activation": False}
    write_new(ROOT / "archive-verification.json", report)
    print(json.dumps({"archive_verified": True, "saved_rpc_chunks_matched": 36,
                      "regular_files_extracted": len(inventory), "reader_execution_started": False}))


if __name__ == "__main__":
    main()
