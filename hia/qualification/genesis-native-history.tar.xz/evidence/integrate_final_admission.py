from pathlib import Path
import ast,hashlib,json,os,subprocess,sys,time,traceback,contextlib,io
BASE=Path("/tmp/trnm-genesis-owner-20261116-8ppak97a")
ROOT=BASE/"repo"
OWNED=ROOT/"hia/platform/genesis_store"
PROPOSAL=Path("/tmp/trnm-genesis-oracle-proposal-20261116-cu0hyqjz")
def identity(raw): return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def need(value,message):
    if not value: raise RuntimeError(message)
receipt={"schema":"trnm.genesis-final-admission-development.v1","status":"FAIL","controls":[]}
try:
    pre=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (BASE/"final-admission-preflight.stdout.raw").write_bytes(pre.stdout)
    (BASE/"final-admission-preflight.stderr.raw").write_bytes(pre.stderr)
    need(pre.returncode==0,"Project preflight")
    for filename,source,expected in [
      ("rust_oracle.py","rust_oracle.proposed.v3.py",{"bytes":65692,"sha256":"2ce7ad909231aa38418fda0e83e597a0afffbcb37eea217a50b958705fd5a2b6"}),
      ("test_integrity.py","test_integrity.proposed.v2.py",{"bytes":25885,"sha256":"9947ba9b199b726f64f37c2e0b9acbdf47e585b4ff1d549b2bf001b7d2c3a7f5"})]:
        raw=(PROPOSAL/source).read_bytes()
        need(identity(raw)==expected,"Proposal source mismatch")
        ast.parse(raw)
        with (OWNED/filename).open("xb") as stream:
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
        need((OWNED/filename).read_bytes()==raw,"Copied source differs")
    sys.path.insert(0,str(ROOT))
    from hia.platform.genesis_store import build, rust_oracle as oracle,native_io as nio, qualify as q
    manifest=build.source_manifest(ROOT)
    need(manifest==oracle.complete_source_manifest(ROOT),"Actual builder/oracle source closure differs")
    originals=build.original_manifest(ROOT)
    need(originals==oracle.original_manifest(ROOT),"Actual original manifest differs")
    raw=__import__("hia.platform.genesis_store.cases",fromlist=["canonical_bytes"]).canonical_bytes()
    need(identity(raw)=={"bytes":2234,"sha256":"cfa3dde3dc0a02a02a1d3f543b7a5cb83199996a642dda7221291391cf47089c"},"Canonical30 bytes changed")
    need(len(list(OWNED.iterdir()))==15,"Owned file count differs from final15")
    receipt.update({"source_inputs":manifest,"original_sources":originals,
        "source_set_sha256":identity(json.dumps(manifest,sort_keys=True,separators=(",",":")).encode())["sha256"],
        "owned_files":15,"native_source_files":len(manifest),"original_source_files":len(originals),"canonical_corpus":identity(raw)})
    receipt["controls"].append({"name":"actual current15 full builder/oracle source and original closure","status":"PASS"})
    output=BASE/"final-admission-integrity.json"
    test=subprocess.run([sys.executable,"-B","-m","hia.platform.genesis_store.test_integrity","--report",str(output)],
        cwd=ROOT,env={**os.environ,"PYTHONDONTWRITEBYTECODE":"1"},stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (BASE/"final-admission-integrity.stdout.raw").write_bytes(test.stdout)
    (BASE/"final-admission-integrity.stderr.raw").write_bytes(test.stderr)
    need(test.returncode==0,"Integrity controls failed")
    report=json.loads(output.read_bytes())
    need(report["status"]=="PASS" and report["controls_completed"]==104 and report["test_groups"]==8,"Integrity totals")
    receipt["integrity"]={"report":str(output),**identity(output.read_bytes())}
    receipt["controls"].append({"name":"actual final source admission fixture and CLI controls","status":"PASS",
        "groups":8,"controls":104,"native_or_original_runtime_execution":False})
    actual=BASE/"cold-durability-v6/cold-settlement/stdout.raw"
    raw=actual.read_bytes()
    need(len(raw)==4893 and identity(raw[320:])=={"bytes":4573,"sha256":"15162736136c9df0844325dfc76b6eb934e66ef5cbe481be246c20b86708d979"},"Historical actual V6 output")
    nio.parse_success(raw)
    decoder=[]
    for offset in (8,12,448,452,468,479):
        mutant=bytearray(raw);mutant[320+512+offset]^=1
        try:nio.parse_success(bytes(mutant))
        except ValueError as error:decoder.append({"offset":offset,"status":"REJECTED","error":str(error),"mutant":identity(mutant)})
        else:raise RuntimeError("Fixed decoder accepted SDO1 mutation "+str(offset))
    need(actual.read_bytes()==raw,"Historical raw altered")
    receipt["controls"].append({"name":"six actual historical record decoder mutants now rejected","status":"PASS",
        "actual_positive_source":str(actual),"actual_positive":identity(raw),"mutants":decoder,
        "new_native_processes":0})
    original_build=q.Build;original_observer=q.observe_semantic;original_argv=sys.argv[:]
    controller=[]
    for label,source_fail,prepare_fail in (("primary-and-cleanup",False,False),("primary-cleanup-source",True,False),("captured-builder-prepare",False,True)):
        checks=[]
        class FakeBuild:
            def __init__(self,output):
                self.pinned=object();self.manifest={"test-input":identity(b"controller-negative-fixture")}
                self.inputs={"test-input":b"controller-negative-fixture"};self.original={"fixture":identity(b"x")}
            def build(self):
                if prepare_fail:raise RuntimeError("INJECTED_PREPARE_FAILURE")
                return b"",{"source_set_sha256":"test-only","executable":identity(b"")}
            def check_sources(self):
                checks.append("checked")
                if source_fail:raise RuntimeError("INJECTED_SOURCE_FAILURE")
        class FakeSession:
            output=Path("controller-negative-fixture-no-process")
            process=None
            def cleanup(self):raise RuntimeError("INJECTED_CLEANUP_FAILURE")
        def observer(suite):
            suite.sessions.append(FakeSession())
            raise RuntimeError("INJECTED_PRIMARY_FAILURE")
        q.Build=FakeBuild;q.observe_semantic=observer
        output=BASE/("controller-evidence-"+label)
        sys.argv=["qualify","--suite","semantic","--output",str(output)]
        capture=io.StringIO()
        with contextlib.redirect_stdout(capture):exit_code=q.main()
        failure=json.loads((output/"failure.json").read_bytes())
        final=json.loads((output/"report.json").read_bytes())
        need(exit_code==1 and final["status"]=="FAIL","Controller failure was promoted to success")
        need(("INJECTED_PREPARE_FAILURE" if prepare_fail else "INJECTED_PRIMARY_FAILURE") in failure["primary_error"]["error"],"Primary error was overwritten")
        need(bool(checks),"Failure branch skipped captured source recheck")
        need(failure["source_after"]["status"]==("FAIL" if source_fail else "PASS"),"Source failure attribution lost")
        need(len(failure["cleanup_errors"])==(0 if prepare_fail else 1),"Cleanup failure lost")
        controller.append({"name":label,"status":"PASS","exit_code":exit_code,
            "failure_report":identity((output/"failure.json").read_bytes()),"actual_source_checks":len(checks)})
        (output/"controller-stdout.raw").write_text(capture.getvalue())
    q.Build=original_build;q.observe_semantic=original_observer;sys.argv=original_argv
    receipt["controls"].append({"name":"primary cleanup and source failures all preserved","status":"PASS",
        "controls":controller,"injected_controller_failures":True,"native_or_original_runtime_execution":False})
    need(build.source_manifest(ROOT)==manifest,"Source changed during admission")
    need(build.original_manifest(ROOT)==originals,"Original source changed during admission")
    receipt["status"]="PASS"
except BaseException as error:
    receipt["failure"]={"error":repr(error),"traceback":traceback.format_exc()}
finally:
    (BASE/"final-admission-development.json").write_text(json.dumps(receipt,sort_keys=True,indent=2)+"\n")
    print(json.dumps({"status":receipt["status"],"source_set_sha256":receipt.get("source_set_sha256"),
        "owned_files":receipt.get("owned_files"),"native_source_files":receipt.get("native_source_files"),
        "original_source_files":receipt.get("original_source_files"),"failure":receipt.get("failure")}),flush=True)
raise SystemExit(0 if receipt["status"]=="PASS" else 1)
