import hashlib,json,os,re,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
positive=Path('/tmp/chain-pq-fa62381e')
negative=Path('/tmp/chain-pq-negative-fa62381e')
out=Path('/tmp/chain-pq-negative-source-fa62381e-s3')
S3='454ae116159867ff6cddd91b964523df7f7e16f0'
BASE='6c35f94d9387fac41c1547f05742d70150320b2e'
N='f7c51532cc6657360b97226d9f396158253cea78'
assert out.is_dir()
for name in ('source-lineage.json','negative-source.diff','negative-source.bundle'):
    assert not (out/name).exists(),name
def git(root,*args,text=True):
    return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root,text=text)
def logged(label,command,cwd):
    with (out/(label+'.log')).open('xb') as stream:
        result=subprocess.run(command,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT)
    assert result.returncode==0,label+' failed'
assert git(positive,'rev-parse','HEAD').strip()==S3
assert git(negative,'rev-parse','HEAD').strip()==N
assert git(negative,'rev-parse','HEAD^').strip()==S3
print(json.dumps({'negative_source':N,'negative_tree':git(negative,'rev-parse','HEAD^{tree}').strip(),'metadata_finalization':'starting','native_tests_executed':False}),flush=True)
logged('negative-post-formatting-preflight',['bash','scripts/project-preflight.sh'],negative)
sys.path.insert(0,str(positive/'scripts/ci'))
from verify_ci_source import verify
positive_before=verify('head',S3,root=positive)
negative_identity=verify('head',N,root=negative)
ingress='trillionnium/crates/trnm-pon-node/src/ingress.rs'
witness='trillionnium/crates/trnm-pon-node/src/pq_rollback_witness.rs'
assert git(negative,'diff-tree','--no-commit-id','--name-only','-r',N).splitlines()==[ingress,witness]
assert git(negative,'show',N+':'+witness,text=False)==git(negative,'show',BASE+':'+witness,text=False)
base_ingress=git(negative,'show',BASE+':'+ingress)
negative_ingress=git(negative,'show',N+':'+ingress)
module='#[cfg(test)]\nmod account_scope_tests;\n\n'
assert negative_ingress.count(module)==1 and negative_ingress.replace(module,'',1)==base_ingress
positive_after=verify('head',S3,root=positive)
assert positive_after==positive_before
account='trillionnium/crates/trnm-pon-node/src/ingress/account_scope_tests.rs'
witness_tests='trillionnium/crates/trnm-pon-node/src/pq_rollback_witness/tests.rs'
for path in (account,witness_tests,'trillionnium/Cargo.lock','tests/fuzz/Cargo.lock',
             'config/pon/pq-system-required-tests-v1.json','config/pon/pq-system-supplemental-tests-v1.json'):
    assert git(negative,'show',N+':'+path,text=False)==git(negative,'show',S3+':'+path,text=False),path
assert hashlib.sha256((negative/account).read_bytes()).hexdigest()=='7da5594a8b7e9a61ce147426272ec4b74e167f2b9a55c8fe5c525269082e610d'
account_raw=(negative/account).read_text()
assert account_raw.splitlines()[72].strip()=='.unwrap_err();'
assert account_raw.splitlines()[89].strip()=='let error = authenticate_request(&wire, &settings, &server).unwrap_err();'
assert account_raw.splitlines()[153].strip()=='assert_eq!('
witness_raw=(negative/witness_tests).read_text()
live_at=witness_raw.index('retry.advance(forged, next).unwrap_err().to_string(),')
cold_start=witness_raw.index('fn cold_reopen_refuses_database_retry_history_and_accepts_new_successors()')
cold_at=witness_raw.index('.unwrap_err()',cold_start)
unwrap_marker='called '+chr(96)+'Result::unwrap_err()'+chr(96)+' on an '+chr(96)+'Ok'+chr(96)+' value'
expected=[
{'test':'ingress::account_scope_tests::invalid_account_scope_refuses_classical_session_and_signed_request','source_file':account,'panic_line':73,'markers':[unwrap_marker]},
{'test':'ingress::account_scope_tests::current_local_scope_refuses_previously_valid_classical_request','source_file':account,'panic_line':90,'markers':[unwrap_marker]},
{'test':'ingress::account_scope_tests::invalid_account_scope_never_connects_or_advances_classical_clients','source_file':account,'panic_line':154,'markers':['authenticated production_activation-wrong, protected=false','left: 1','right: 0']},
{'test':'pq_rollback_witness::tests::live_retry_refuses_changed_durable_predecessor_at_the_same_head','source_file':witness_tests,'panic_line':witness_raw[:live_at].count('\n')+1,'markers':[unwrap_marker]},
{'test':'pq_rollback_witness::tests::cold_reopen_refuses_database_retry_history_and_accepts_new_successors','source_file':witness_tests,'panic_line':witness_raw[:cold_at].count('\n')+1,'markers':[unwrap_marker]},
]
(out/'negative-source.diff').write_bytes(git(negative,'diff','--binary','--full-index',S3,N,text=False))
logged('negative-bundle',['git','bundle','create',str(out/'negative-source.bundle'),'HEAD','^'+S3],negative)
logged('negative-bundle-verify',['git','bundle','verify',str(out/'negative-source.bundle')],negative)
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
critical=[ingress,witness,account,witness_tests,'trillionnium/Cargo.lock','tests/fuzz/Cargo.lock',
'config/pon/pq-system-required-tests-v1.json','config/pon/pq-system-supplemental-tests-v1.json',
'scripts/ci/record_pq_native_command.py','scripts/ci/pinned_native_process.py',
'scripts/ci/ci_observation.py','scripts/ci/verify_ci_source.py']
report={'schema':'trnm-isolated-pq-negative-source-v1','metadata_correction':{'initial_job':'1a1cb325383-2564-a57','initial_exit_code':1,'reason':'pre-formatting account assertion line constants; no source or native test failure','source_unchanged_by_metadata_completion':True},'positive_source':S3,'base_behavior_source':BASE,
'negative_source':N,'negative_tree':git(negative,'rev-parse','HEAD^{tree}').strip(),
'changed_paths':[ingress,witness],'positive_source_before':positive_before,
'positive_source_after':positive_after,'negative_source_identity':negative_identity,
'failure_expectations':expected,'native_tests_executed':False,
'source_files_sha256':{path:sha(negative/path) for path in critical},
'whole_chain_quantum_security_qualified':False,'production_activation':False,
'qualification_scope':'isolated intentionally regressed source for seven named controls only',
'artifact_sha256':{p.name:sha(p) for p in out.iterdir() if p.is_file()}}
(out/'source-lineage.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'negative_source':N,'positive_source':S3,'changed_paths':[ingress,witness],
'failure_expectations':expected,'output':str(out),'positive_source_unchanged':True,
'native_build_started':False},sort_keys=True))