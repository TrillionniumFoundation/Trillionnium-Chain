import unittest
class Probe(unittest.TestCase):
    def test_observed(self):
        self.assertEqual(2 + 3, 5)
