#!/usr/bin/env python3
"""Additional exact-source SQLite I/O campaign; never requalifies earlier runs.

Build three existing test harnesses once in a fresh normal-native Cargo target.
Require the original #799 actual build-output fence, then execute the full
library and the two exact finite integration parents, preserving all failures.
Only each finite parent/helper process receives the source-required resource
limits; compilers and other campaigns are untouched. No automatic retries.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import stat
import subprocess
import sys
import time

SCHEMA = "trnm-additional-bounded-io-campaign-v1"
HEAD = "5633c55219c01c689f670c2ca35d122e39f3f791"
PACKAGE = "trnm-sqlite-io-boundary"
PACKAGE_DIR = "trillionnium/crates/" + PACKAGE
FENCE = "sqlite-3.51.3-normal-native-linux-layout-v3"
AS_BYTES = 3 * 1024 ** 3
FILE_BYTES = 16 * 1024 ** 2
PARENTS = {
    "native_public_api_v2": {
        "parent": "finite_native_public_api_controls_v2",
        "child": "native_public_api_v2_case_child",
        "variable": "TRNM_PN1_VFS_FINITE_CONTROL_V2_DIR",
        "schema": "pn1-vfs-finite-native-public-api-control-v2",
        "case_schema": "pn1-vfs-finite-native-case-observation-v2",
        "cases": ["rollback_to_wal", "multiple_connections", "same_lease_cold_reopen",
                  "real_file_cap_sticky", "attach_uri_path_refusals", "memory_real_deleted_temp",
                  "memory_drop_order", "disk_drop_order", "failed_owner_claim_consumed",
                  "bare_named_memory_permanent_registration"],
    },
    "native_held_directory_v1": {
        "parent": "finite_native_held_directory_controls_v1",
        "child": "native_held_directory_v1_case_child",
        "variable": "TRNM_PN1_HELD_V1_DIR",
        "schema": "pn1-native-held-directory-controls-v1",
        "case_schema": "pn1-native-held-directory-case-v1",
        "cases": ["held_parent_rename_sqlite_cold", "nondirectory_parent_claim",
                  "bad_basename_escape_claim", "existing_symlink_claim"],
    },
}


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def save(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")


def record(path: Path) -> dict:
    before = path.stat(follow_symlinks=False)
    require(stat.S_ISREG(before.st_mode), "not a regular file: " + str(path))
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    after = path.stat(follow_symlinks=False)
    identity = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(identity(before) == identity(after), "file changed during read: " + str(path))
    return {"path": str(path), "bytes": after.st_size, "sha256": digest.hexdigest()}


def process_context(directory: Path) -> dict:
    rows = Path("/proc/self/cgroup").read_text()
    cgroups = {}
    for row in rows.splitlines():
        parts = row.split(":", 2)
        if len(parts) == 3 and parts[0:2] == ["0", ""]:
            base = (Path("/sys/fs/cgroup") / parts[2].lstrip("/")).resolve()
            if base.is_relative_to(Path("/sys/fs/cgroup")):
                for name in ("cpu.max", "memory.max", "memory.current", "pids.max"):
                    path = base / name
                    if path.is_file():
                        cgroups[str(path)] = path.read_text().strip()
    return {"pid": os.getpid(), "uid": os.getuid(), "gid": os.getgid(),
            "nice": os.getpriority(os.PRIO_PROCESS, 0), "cpu_affinity": sorted(os.sched_getaffinity(0)),
            "proc_self_limits": Path("/proc/self/limits").read_text(),
            "proc_self_cgroup": rows, "cgroup_limits": cgroups,
            "rlimit_as": resource.getrlimit(resource.RLIMIT_AS),
            "rlimit_fsize": resource.getrlimit(resource.RLIMIT_FSIZE),
            "disk": dict(zip(("total", "used", "free"), shutil.disk_usage(directory)))}


def native_exec(specification: dict) -> None:
    """A fresh helper applies limits only to itself, records, then execs the ELF."""
    binary = Path(specification["binary"]).resolve(strict=True)
    receipt = Path(specification["receipt"])
    observed = record(binary)
    require(observed == specification["binary_record"], "native ELF changed before exec")
    if specification["finite_limits"]:
        for which, value in ((resource.RLIMIT_AS, AS_BYTES), (resource.RLIMIT_FSIZE, FILE_BYTES)):
            old = resource.getrlimit(which)
            require(old[1] == resource.RLIM_INFINITY or old[1] >= value,
                    "existing hard limit is below the reviewed finite prerequisite")
            resource.setrlimit(which, (value, value))
    argv = [str(binary), *specification["args"]]
    save(receipt, {"schema": SCHEMA + "/native-exec", "binary": observed, "argv": argv,
                   "cwd": str(Path.cwd()), "finite_limits": specification["finite_limits"],
                   "context": process_context(receipt.parent),
                   "loader_path": os.environ.get("LD_LIBRARY_PATH"),
                   "whole_chain_pq_qualified": False})
    os.execve(binary, argv, dict(os.environ))


def list_names(path: Path) -> list[str]:
    names = []
    for line in path.read_text().splitlines():
        match = re.fullmatch(r"test (\S+)", line)
        require(match is not None, "unrecognized discovery record")
        names.append(match.group(1))
    require(len(names) == len(set(names)), "duplicate test discovery")
    return sorted(names)


def results(path: Path, expected: list[str]) -> dict:
    observed = {}
    for line in path.read_text().splitlines():
        result, name = line.rsplit(" ", 1)
        require(name in expected and name not in observed, "unexpected or duplicate test result")
        require(result == "ok" or result == "failed" or result.startswith(("failed: ", "ignored")),
                "unrecognized native result")
        observed[name] = result
    require(set(observed) == set(expected), "native execution did not account for the exact roster")
    return observed


class Campaign:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.repo = args.repo.resolve(strict=True)
        self.out = args.out.resolve()
        self.script = Path(__file__).resolve(strict=True)
        self.python = Path(sys.executable).resolve(strict=True)
        self.cargo = args.cargo.resolve(strict=True)
        self.rustc = args.rustc.resolve(strict=True)
        self.cargo_home = args.cargo_home.resolve(strict=True)
        require(sys.platform.startswith("linux") and os.getuid() != 0, "reviewed Linux non-root operator required")
        require(not self.out.exists() and not self.out.is_relative_to(self.repo), "fresh external output required")
        require(self.rustc.name == "rustc" and self.rustc.parent.name == "bin"
                and self.cargo.parent == self.rustc.parent, "real canonical toolchain binaries required")
        self.toolchain = self.rustc.parent.parent
        self.loader = (self.toolchain / "lib").resolve(strict=True)
        require(self.loader == self.toolchain / "lib" and self.loader.is_dir(), "canonical toolchain/lib required")
        self.out.mkdir(mode=0o700)
        self.target = self.out / "native-target"
        self.env = {name: os.environ[name] for name in ("HOME", "USER", "LOGNAME") if name in os.environ}
        self.env.update({"PATH": str(self.rustc.parent) + ":/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
                         "TZ": "UTC", "PYTHONDONTWRITEBYTECODE": "1", "CARGO_HOME": str(self.cargo_home),
                         "CARGO_TARGET_DIR": str(self.target), "CARGO_NET_OFFLINE": "true", "CARGO_TERM_COLOR": "never",
                         "CARGO_BUILD_JOBS": "2", "CARGO_INCREMENTAL": "0", "RUSTC": str(self.rustc),
                         "RUSTDOC": str(self.rustc.with_name("rustdoc")), "RUST_TEST_THREADS": "1", "RUST_BACKTRACE": "0",
                         "LD_LIBRARY_PATH": str(self.loader), "GIT_OPTIONAL_LOCKS": "0", "GIT_NO_REPLACE_OBJECTS": "1",
                         "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_SYSTEM": os.devnull, "GIT_CONFIG_GLOBAL": os.devnull,
                         "GIT_ATTR_NOSYSTEM": "1", "GIT_TERMINAL_PROMPT": "0"})
        self.commands, self.failures, self.harnesses = [], [], {}
        self.report = {"schema": SCHEMA, "expected_head": HEAD, "source_repository": str(self.repo),
                       "runner": record(self.script), "started_unix_seconds": time.time(),
                       "scope": "existing finite SQLite component controls with corrected loader environment",
                       "earlier_campaigns_requalified": False, "source_modified": False, "retries": 0,
                       "whole_chain_pq_qualified": False, "production_activation": False,
                       "Node_AuthenticatedV1_requalified": False, "full_W1_4097_qualified": False,
                       "full_campaign_held_FD_bridge_implemented": False,
                       "environment": self.env, "normal_native_cargo_layout": True,
                       "tool_binaries": [record(p) for p in (self.python, self.cargo, self.rustc)],
                       "parent_context": process_context(self.out), "commands": self.commands,
                       "failures": self.failures, "harnesses": self.harnesses,
                       "required_integration_roster": PARENTS}
        save(self.out / "campaign-start.json", self.report)

    def command(self, label: str, argv: list[str], *, env: dict | None = None,
                cwd: Path | None = None, timeout: int = 300, heavy: bool = False) -> dict:
        require(not any(row["label"] == label for row in self.commands), "command repeated")
        result = {"label": label, "argv": argv, "cwd": str(cwd or self.repo), "attempts": 1,
                  "started_unix_seconds": time.time(), "exit_code": None, "timed_out": False}
        self.commands.append(result)
        save(self.out / (label + ".started.json"), result)
        stdout, stderr = self.out / (label + ".stdout.log"), self.out / (label + ".stderr.log")
        started, child = time.monotonic(), None
        print(json.dumps({"starting": label, "argv": argv}), flush=True)
        try:
            with stdout.open("xb") as out, stderr.open("xb") as err:
                require(not heavy or shutil.disk_usage(self.out).free >= 8 * 1024 ** 3,
                        "less than 8 GiB free; command blocked")
                child = subprocess.Popen(argv, cwd=cwd or self.repo, env=env or self.env,
                                         stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True)
                deadline = started + timeout
                while child.poll() is None:
                    try:
                        child.wait(timeout=max(0.01, min(30, deadline - time.monotonic())))
                    except subprocess.TimeoutExpired:
                        free = shutil.disk_usage(self.out).free
                        result["timed_out"] = time.monotonic() >= deadline
                        if result["timed_out"] or heavy and free < 8 * 1024 ** 3:
                            result["resource_abort"] = not result["timed_out"]
                            self.stop(child)
                            break
                        print(json.dumps({"running": label, "elapsed_seconds": time.monotonic() - started,
                                          "free_bytes": free}), flush=True)
                result["exit_code"] = child.returncode
        except BaseException as error:
            if child is not None and child.poll() is None:
                self.stop(child)
            result["error"] = f"{type(error).__name__}: {error}"
            if not isinstance(error, Exception):
                raise
        finally:
            result["elapsed_seconds"] = time.monotonic() - started
            result["logs"] = [record(path) for path in (stdout, stderr) if path.is_file()]
            result["passed"] = result["exit_code"] == 0 and not any(result.get(key) for key in
                                                                       ("error", "timed_out", "resource_abort"))
            save(self.out / (label + ".receipt.json"), result)
            print(json.dumps({"finished": label, "passed": result["passed"], "exit_code": result["exit_code"]}), flush=True)
        return result

    @staticmethod
    def stop(child: subprocess.Popen) -> None:
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=5)

    def source_guard(self, label: str) -> None:
        path = self.out / (label + ".source.json")
        result = self.command(label, [str(self.python), "-B", "scripts/ci/verify_ci_source.py",
                                     "--kind", "head", "--expected-head", HEAD, "--output", str(path)])
        require(result["passed"], "raw tracked-source guard failed: " + label)
        value = json.loads(path.read_text())
        require(value["tested_commit"] == HEAD and value["tracked_worktree_verified"] is True,
                "wrong source guard readback")
        self.report[label] = value

    def fence(self, label: str) -> None:
        destination = self.out / label
        destination.mkdir(mode=0o700)
        rows = []
        # This is the exact original #799 normal-native readback predicate.
        for path in sorted((self.target / "debug/build").glob(PACKAGE + "-*/output")):
            raw = path.read_bytes()
            text = raw.decode()
            copy = destination / (path.parent.name + ".txt")
            with copy.open("xb") as stream:
                stream.write(raw)
            qualified = ("cargo:rustc-cfg=trnm_sqlite_layout_witness\n" in text
                         and "cargo:rustc-env=TRNM_SQLITE3_BUILD_FENCE=" + FENCE + "\n" in text
                         and "UNQUALIFIED:" not in text and "TRNM_SQLITE3_UNQUALIFIED_REASON=" not in text)
            rows.append({"source": str(path), "retained": record(copy), "qualified": qualified})
        result = {"passed": bool(rows) and all(row["qualified"] for row in rows), "outputs": rows,
                  "scope": "actual retained build-script qualification markers"}
        self.report[label] = result
        save(self.out / (label + ".json"), result)
        require(result["passed"], "SQLite build fence missing or unqualified")

    def native(self, label: str, target_name: str, test_args: list[str], *, limits: bool = False,
               env: dict | None = None, timeout: int = 300) -> dict:
        binary = self.harnesses[target_name]["binary"]
        specification = {"binary": binary["path"], "binary_record": binary,
                         "receipt": str(self.out / (label + ".native-exec.json")),
                         "finite_limits": limits, "args": test_args}
        outcome = self.command(label, [str(self.python), "-B", str(self.script), "__native_exec__",
                                       json.dumps(specification, separators=(",", ":"))],
                               cwd=self.repo / PACKAGE_DIR, env=env, timeout=timeout, heavy=True)
        require(record(Path(binary["path"])) == binary, "native executable changed after invocation")
        return outcome

    def child_readback(self, target_name: str, base: Path) -> dict:
        contract = PARENTS[target_name]
        path = base / "all-planned-child-terminals.json"
        value = json.loads(path.read_text())
        require(value["schema"] == contract["schema"] and value["planned_cases"] == contract["cases"],
                "integration case roster/schema changed")
        terminals = value["terminals"]
        require([row["case"] for row in terminals] == contract["cases"], "missing/duplicate/reordered child terminals")
        records, errors = [], []
        for terminal in terminals:
            case = terminal["case"]
            directory = base / case
            try:
                receipt = json.loads((directory / "case-result.json").read_text())
                started = json.loads((directory / "child-start.json").read_text())
                go = json.loads((directory / "parent-go.json").read_text())
                persisted_terminal = json.loads((directory / "parent-observed-terminal.json").read_text())
                require(terminal == persisted_terminal, "aggregate/per-case terminal mismatch")
                require(receipt["schema"] == contract["case_schema"] and receipt["case"] == case,
                        "wrong case receipt schema or identity")
                require(receipt["pid"] == terminal["pid"] == started["pid"] == go["pid"], "child PID mismatch")
                require(terminal["kernel_start_tick"] == started["kernel_start_tick"] == go["kernel_start_tick"],
                        "child kernel start identity mismatch")
                require(terminal["alive_and_bound_before_release"] is True and terminal["wait_completed"] is True
                        and terminal["exit_code"] == 0 and terminal["success"] is True
                        and terminal["timed_out"] is False and terminal["original_PID_identity_alive_after_wait"] is False
                        and terminal["case_receipt_present"] is True, "child did not complete successfully")
                require(isinstance(receipt.get("observed"), dict) and receipt["observed"], "empty case observation")
                require(receipt["component_only"] is True and receipt["full_guard_enabled"] is False
                        and receipt["full_W1_4097_qualified"] is False, "case qualification boundary changed")
                if target_name == "native_held_directory_v1":
                    require(receipt["ok"] is True and receipt["work_panic"] is False and receipt["error"] is None
                            and receipt["finalization_errors"] == [] and terminal["controller_error"] is None
                            and terminal["case_result_ok"] is True, "held case/finalization failed")
                records.append({"case": case, "passed": True, "pid": terminal["pid"],
                                "receipt": record(directory / "case-result.json"),
                                "terminal": record(directory / "parent-observed-terminal.json")})
            except Exception as error:
                errors.append({"case": case, "error": f"{type(error).__name__}: {error}"})
        readback = {"planned": len(contract["cases"]), "passed": len(records), "records": records, "errors": errors}
        save(self.out / (target_name + ".children.json"), readback)
        self.report[target_name + "-children"] = readback
        require(not errors and len(records) == len(contract["cases"]), "one or more child case receipts failed readback")
        return readback

    def run(self) -> None:
        require(self.command("project-preflight", ["/bin/bash", "scripts/project-preflight.sh"])["passed"], "preflight failed")
        self.source_guard("source-before")
        for label, binary, flags, prefix in (("rustc-version", self.rustc, ["-Vv"], "rustc 1.95.0 "),
                                              ("cargo-version", self.cargo, ["-V"], "cargo 1.95.0 ")):
            require(self.command(label, [str(binary), *flags])["passed"], "toolchain version command failed")
            require((self.out / (label + ".stdout.log")).read_text().startswith(prefix), "wrong Rust 1.95 toolchain")
        require("host: x86_64-unknown-linux-gnu\n" in (self.out / "rustc-version.stdout.log").read_text(), "wrong native host")
        source = self.repo / PACKAGE_DIR / "src/transaction_scope_tests.rs"
        library_names = sorted("transaction_scope::tests::" + name for name in
                               re.findall(r"#\[test\]\s+fn ([a-z0-9_]+)\(\)", source.read_text()))
        require(len(library_names) == 13, "reviewed library source roster changed")
        self.report["library_source_roster"] = {"source": record(source), "names": library_names}
        for target_name, contract in PARENTS.items():
            source = self.repo / PACKAGE_DIR / "tests" / (target_name + ".rs")
            text = source.read_text()
            match = re.search(r'const CASES: \[&str; \d+\] = \[(.*?)\];', text, re.S)
            require(match is not None and re.findall(r'"([a-z0-9_]+)"', match.group(1)) == contract["cases"],
                    "integration source case roster changed")
            self.report[target_name + "-source"] = record(source)
        graph = self.command("locked-metadata", [str(self.cargo), "metadata", "--locked", "--offline",
                                                "--manifest-path", "trillionnium/Cargo.toml", "--format-version", "1"])
        require(graph["passed"], "locked offline dependency graph failed")
        metadata = json.loads((self.out / "locked-metadata.stdout.log").read_text())
        require(Path(metadata["target_directory"]).resolve() == self.target and metadata["resolve"]["nodes"],
                "metadata did not resolve the isolated dependency graph")
        build = self.command("build-three-harnesses", [str(self.cargo), "test", "--locked", "--offline",
                             "--manifest-path", "trillionnium/Cargo.toml", "-p", PACKAGE, "--no-run",
                             "--lib", "--test", "native_public_api_v2", "--test", "native_held_directory_v1",
                             "--message-format=json"], timeout=1800, heavy=True)
        require(build["passed"], "native build failed; no retry")
        for line in (self.out / "build-three-harnesses.stdout.log").read_text().splitlines():
            if not line.startswith("{"):
                continue
            item = json.loads(line)
            if item.get("reason") != "compiler-artifact" or not item.get("executable") or not item["profile"]["test"]:
                continue
            if Path(item["manifest_path"]).resolve() != self.repo / PACKAGE_DIR / "Cargo.toml":
                continue
            name = item["target"]["name"]
            binary = Path(item["executable"]).resolve(strict=True)
            require(binary.is_relative_to(self.target / "debug/deps") and name not in self.harnesses,
                    "unexpected native artifact layout or duplicate harness")
            self.harnesses[name] = {"binary": record(binary), "cargo_artifact": item}
        require(set(self.harnesses) == {"trnm_sqlite_io_boundary", *PARENTS}, "expected exactly three native harnesses")
        self.fence("sqlite-fence-before-tests")
        for name in self.harnesses:
            logfile = self.out / (name + ".discovery.libtest.log")
            observed = self.native(name + "-list", name, ["--list", "--format=pretty", "--color=never", "--logfile", str(logfile)])
            require(observed["passed"], "native discovery failed; no retry")
            actual = list_names(logfile)
            expected = library_names if name == "trnm_sqlite_io_boundary" else sorted(
                [PARENTS[name]["parent"], PARENTS[name]["child"]])
            require(actual == expected, "compiled native roster differs from required source")
            self.harnesses[name]["discovered_roster"] = actual
        logfile = self.out / "library-results.libtest.log"
        library = self.native("library-full", "trnm_sqlite_io_boundary",
                              ["--format=pretty", "--color=never", "--test-threads=1", "--logfile", str(logfile)])
        try:
            values = results(logfile, library_names)
            self.report["library_results"] = values
            require(library["passed"] and all(value == "ok" for value in values.values()), "library tests failed or ignored")
        except Exception as error:
            self.failures.append("library: " + str(error))
        for name, contract in PARENTS.items():
            base = self.out / (name + "-evidence")
            logfile = self.out / (name + ".results.libtest.log")
            outcome = self.native(name + "-parent", name,
                                  [contract["parent"], "--exact", "--ignored", "--nocapture", "--test-threads=1",
                                   "--format=pretty", "--color=never", "--logfile", str(logfile)],
                                  limits=True, env=dict(self.env, **{contract["variable"]: str(base)}), timeout=360)
            try:
                readback = results(logfile, [contract["parent"]])
                self.report[name + "-parent-result"] = readback
                self.child_readback(name, base)
                require(outcome["passed"] and readback[contract["parent"]] == "ok", "integration parent failed or was ignored")
            except Exception as error:
                self.failures.append(name + ": " + str(error))
        self.fence("sqlite-fence-after-tests")

    def finish(self) -> int:
        self.report["finished_unix_seconds"] = time.time()
        self.report["final_context"] = process_context(self.out)
        self.report["failed_commands"] = [row["label"] for row in self.commands if not row["passed"]]
        self.report["runner_after"] = record(self.script)
        if self.report["runner_after"] != self.report["runner"]:
            self.failures.append("runner changed during execution")
        retained = []
        for target_name in PARENTS:
            base = self.out / (target_name + "-evidence")
            if base.exists():
                for path in sorted(base.rglob("*")):
                    info = path.lstat()
                    if stat.S_ISREG(info.st_mode):
                        retained.append(record(path))
                    elif stat.S_ISLNK(info.st_mode):
                        retained.append({"path": str(path), "symlink_target": os.readlink(path), "followed": False})
        save(self.out / "integration-artifacts.json", retained)
        self.report["integration_artifact_manifest"] = record(self.out / "integration-artifacts.json")
        self.report["result"] = "PASS_SCOPED_NATIVE_IO" if not self.failures and not self.report["failed_commands"] else "FAILED_OR_BLOCKED"
        save(self.out / "summary.json", self.report)
        print(json.dumps({"result": self.report["result"], "summary": str(self.out / "summary.json"),
                          "failures": self.failures, "whole_chain_pq_qualified": False}), flush=True)
        return 0 if self.report["result"] == "PASS_SCOPED_NATIVE_IO" else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--expected-head", choices=[HEAD], required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--cargo", type=Path, required=True)
    parser.add_argument("--rustc", type=Path, required=True)
    parser.add_argument("--cargo-home", type=Path, required=True)
    campaign = Campaign(parser.parse_args())
    try:
        campaign.run()
    except BaseException as error:
        campaign.failures.append(f"{type(error).__name__}: {error}")
    finally:
        try:
            campaign.source_guard("source-after")
        except BaseException as error:
            campaign.failures.append("final source guard: " + str(error))
        return campaign.finish()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "__native_exec__":
        native_exec(json.loads(sys.argv[2]))
    else:
        raise SystemExit(main())
