#!/usr/bin/env python3
"""Record selected controls and the actual QROM workflow bodies at one commit."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time
import textwrap
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/d4d2da8133e2/chain-pq-closure')
COMMIT = 'c09dbbe9921da12db8bf7240a8a95a0e9a789e50'
SUITES = [
    'scripts/ci/test_hash_use_contract.py',
    'scripts/ci/test_pq_lifetime_budget.py',
    'scripts/ci/test_pq_authority_effect_register.py',
    'scripts/ci/test_pq_root_dependency_register.py',
    'scripts/ci/test_run_pq_root_continuation_v4.py',
    'scripts/ci/test_run_pq_root_witness_v5.py',
    'scripts/ci/test_consensus_roster.py',
    'scripts/ci/test_w1_lifetime_ledger.py',
    'scripts/ci/test_cell_storage_convergence_ci.py',
    'scripts/ci/test_pq_research_integration.py',
    'scripts/ci/test_ci_contract.py',
    'scripts/ci/test_codeql_retention.py',
    'scripts/test_export_codeql_analysis.py',
]
CHECKS = [
    'scripts/ci/hash_use_contract.py',
    'scripts/ci/pq_lifetime_budget.py',
    'scripts/ci/pq_authority_effect_register.py',
    'scripts/ci/pq_root_dependency_register.py',
    'scripts/ci/check_ci_contract.py',
    'scripts/ci/check_pq_research_integration.py',
    'scripts/ci/pq_chain_claim_guard.py',
]
STEPS = ['named_tests', 'historical_controls', 'implementation',
         'current_implementation', 'budget_unknown', 'budget_hypothetical',
         'report_scopes']

def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)

def write(path, data):
    with Path(path).open('x') as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write('\n')

def identity():
    head = git('rev-parse', 'HEAD').decode().strip()
    status = git('status', '--porcelain').decode()
    assert head == COMMIT and not status, (head, status)
    return {'commit': head, 'tree': git('rev-parse', 'HEAD^{tree}').decode().strip()}

def snapshot(output):
    before = identity()
    skipped = {line[2:].decode() for line in git('ls-files', '-v', '-z').split(b'\0')
               if line.startswith(b'S ')}
    rows, absent = [], []
    entries = git('ls-tree', '-rlz', '--full-tree', COMMIT).split(b'\0')
    with subprocess.Popen(['git', '--no-replace-objects', 'cat-file', '--batch'],
                          cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE) as reader:
        for item in filter(None, entries):
            meta, name = item.split(b'\t', 1)
            mode, kind, oid, size = meta.split()
            relative, path = name.decode(), ROOT / name.decode()
            if not path.exists() and not path.is_symlink():
                assert relative in skipped, relative
                absent.append(relative)
                continue
            assert kind == b'blob'
            reader.stdin.write(oid + b'\n'); reader.stdin.flush()
            assert reader.stdout.readline().split() == [oid, b'blob', size]
            expected = reader.stdout.read(int(size))
            assert len(expected) == int(size) and reader.stdout.read(1) == b'\n'
            if mode == b'120000':
                assert path.is_symlink()
                actual = os.fsencode(os.readlink(path))
            else:
                assert not path.is_symlink() and path.is_file()
                assert bool(path.stat().st_mode & 0o111) == (mode == b'100755')
                actual = path.read_bytes()
            assert actual == expected, relative
            rows.append({'path': relative, 'git_blob': oid.decode(), 'mode': mode.decode(),
                         'bytes': len(actual), 'sha256': hashlib.sha256(actual).hexdigest()})
        reader.stdin.close()
        assert reader.wait(timeout=30) == 0
    assert identity() == before
    result = {**before, 'scope': 'all-materialized-tracked-bytes-compared-to-git',
              'full_checkout_materialized': False, 'files': rows,
              'unmaterialized_sparse_paths': absent}
    write(output, result)
    return result

def workflow_body(text, step):
    lines = text.splitlines()
    starts = [i for i, line in enumerate(lines) if line == '        id: ' + step]
    assert len(starts) == 1
    start = starts[0]
    end = next((i for i in range(start + 1, len(lines)) if lines[i].startswith('      - name:')), len(lines))
    block = lines[start:end]
    offset = block.index('        run: |') + 1
    result = textwrap.dedent('\n'.join(block[offset:])) + '\n'
    assert '${{' not in result
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out
    out.mkdir()
    qrom = out / 'qrom-observations'; qrom.mkdir()
    write(out / 'recovery-context.json', {
        'prior_output': '/workspace/scratch/d4d2da8133e2/python-validation-c09dbbe992',
        'prior_completed_suites': 9, 'prior_completed_outer_tests': 204,
        'prior_integration_suite_terminal_state': 'unknown_no_receipt',
        'same_uninterrupted_run_claimed': False,
        'original_suites_repeated': False,
        'started_utc': datetime.now(timezone.utc).isoformat(),
    })
    before = snapshot(out / 'source-before.json')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_NO_LAZY_FETCH='1',
               GITHUB_WORKSPACE=str(ROOT), W1_QROM_OUT=str(qrom))
    commands = [(Path(p).stem, ['python3', '-B', p], True) for p in SUITES[9:]]
    commands += [(Path(p).stem, ['python3', '-B', p], False) for p in CHECKS]
    workflow = (ROOT / '.github/workflows/pon-w1-qrom-implementation.yml').read_text()
    for step in STEPS:
        script = out / ('workflow-' + step + '.sh')
        script.write_text(workflow_body(workflow, step))
        commands.append(('workflow-' + step, ['bash', str(script)], False))
    rows = []
    for name, argv, suite in commands:
        row = {'name': name, 'argv': argv, 'source_before': identity(), 'timeout_seconds': 900}
        row['started_utc'] = datetime.now(timezone.utc).isoformat()
        start = time.monotonic()
        stdout, stderr = out / (name + '.stdout.log'), out / (name + '.stderr.log')
        with stdout.open('xb') as normal, stderr.open('xb') as errors:
            proc = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                    stdout=normal, stderr=errors, start_new_session=True)
            row['pid'] = proc.pid
            row['pid_namespace'] = os.readlink('/proc/self/ns/pid')
            write(out / (name + '.started.json'), row)
            print(json.dumps({'started': name, 'pid': proc.pid, 'started_utc': row['started_utc']}), flush=True)
            try:
                code = proc.wait(timeout=900)
                row['timed_out'] = False
            except subprocess.TimeoutExpired:
                row['timed_out'] = True
                os.killpg(proc.pid, signal.SIGTERM)
                try: code = proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL); code = proc.wait(timeout=30)
        row.update(finished_utc=datetime.now(timezone.utc).isoformat(), exit_code=code, elapsed_seconds=time.monotonic()-start,
                   source_after=identity(), passed=code == 0 and not row['timed_out'])
        for key, path in [('stdout', stdout), ('stderr', stderr)]:
            raw = path.read_bytes()
            row[key] = {'name': path.name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        if suite:
            raw = stderr.read_text()
            matches = re.findall(r'^Ran (\d+) tests? in .+$', raw, re.M)
            row['outer_tests'] = int(matches[-1]) if matches else None
            row['passed'] = row['passed'] and bool(matches) and int(matches[-1]) > 0 and bool(re.search(r'^OK$', raw, re.M))
        write(out / (name + '.receipt.json'), row)
        rows.append(row)
        print(json.dumps({k: row.get(k) for k in ('name', 'exit_code', 'passed', 'outer_tests', 'elapsed_seconds')}), flush=True)
    after = snapshot(out / 'source-after.json')
    report = {'source': identity(), 'source_unchanged': before == after, 'commands': rows,
              'all_selected_commands_passed': before == after and all(r['passed'] for r in rows),
              'status': 'HOLD_NO_GO', 'whole_chain_pq_qualified': False,
              'production_activation': False, 'hosted_ci_observed': False}
    write(out / 'summary.json', report)
    return 0 if report['all_selected_commands_passed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
