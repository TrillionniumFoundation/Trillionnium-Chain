# Retained historical pressure artifact unavailable

This is a read-only diagnosis of GitHub job 128582077185 in run 42431784210,
attempt 1, on source dcd114a9dc1308e069bae205cf3e091f62046ccc. The job remains
**FAILURE**. This package does not recover or replace the missing historical
artifact, waive a gate, rerun pressure work, or establish pressure acceptance.

## Exact observed failure

The failed second step was **Retrieve exact historical failed artifact without
reclassifying it**. It requested artifact **11531476198** from historical run
**37730166589**. The complete original job log reports **Found 0 artifact(s)**,
then **None of the provided artifact IDs were found**. The following diagnostics
step was skipped. This failure occurred during artifact retrieval, before those
diagnostics or any native test in this job.

- [Current failed job](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42431784210/job/128582077185)
- [Historical run](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/37730166589)
- [Artifact metadata API](https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/actions/artifacts/11531476198)
- [Historical run artifact API](https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/actions/runs/37730166589/artifacts?per_page=100)

The authenticated read observed HTTP 404 for the artifact and a successful
historical-run artifact listing with total_count 0. These observations do not
establish whether retention expiry, deletion or another availability condition
caused the absence. Node deprecation warnings in the job log are retained and
are not substituted for the actual artifact-download error.

## Unchanged inherited workflow

PR #785 targets the exact head of PR #779:
4a7e07e970d5bdb79626dda6bc98ae7906a02f18. The entire workflow file at that base
and at dcd114a9dc1308e069bae205cf3e091f62046ccc is byte-identical: 21,445 bytes,
Git blob 560efaa34806ca4687f8ffc8c540bc462536b458, SHA256
609e7a909977354c22d7503b4031225fb7b51cfb02b853fb9d147a355b9e3053.

- [Head workflow](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/dcd114a9dc1308e069bae205cf3e091f62046ccc/.github/workflows/pon-priority-acceptance.yml#L17-L54)
- [Base workflow](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/4a7e07e970d5bdb79626dda6bc98ae7906a02f18/.github/workflows/pon-priority-acceptance.yml#L17-L54)

The job is not intended to stay red. If retrieval succeeds, its diagnostics
check the historical source commit, report schema and bounded input/output
sizes, then print the historical phase facts. They contain no forced failure
and do not assert successful historical pressure acceptance. This publication
does not change those rules and does not claim that the old artifact itself
has been verified by the failed current job.

## Bounded repository search

The ROG report retains the completed filename inventory of 7,446 files under
evidence and docs; an experiments root was absent. Exact textual searches for
the artifact ID, historical run ID and required historical source found no
matches in the selected text formats within those roots.

Six relevant archive/manifest candidates were then inspected. Their full
candidate names, source bindings, sizes, SHA256 values, inspected member names
and explicit scope are in observations/rog-archive-readback.json. The service
archives inspected bind other sources, including f2588fe..., c028445... and
b173c1f..., and cannot be relabeled as the required 560d44ac... artifact.

This is **not an exhaustive search of every nested archive, host, backup or
historical checkout**. No verified byte-identical complete replacement was
established. A report, hash list, partial archive, different source's archive or
new execution is not the missing original artifact.

## Included originals and read history

github/ contains byte-exact retained current job metadata/logs, the original
404/empty-list API bodies and original GitHub workflow content responses.
workflow/ contains the corresponding exact decoded workflow bytes. The ROG
inventory and bounded archive-review reports are retained byte-exact with
their original-file SHA256 bindings. Their task-local paths describe collection
provenance; no profile, authentication configuration or credential store is
included.

read-attempts/ preserves the relevant original request receipts, network
timeout diagnostics and bounded partial-clone Git reads. The partial-clone
inventory was incomplete and is not used to claim repository absence. A
pre-dispatch helper invocation with a relative executable name was refused;
the subsequent absolute-path read invocation was admitted. No CI run was
restarted, cancelled, commented on or modified.

The raw workflow contains GitHub expression references to github.token and
the original job log contains the platform's masked token placeholder. Neither
is an authentication token. No authentication material, private adapter or SDK
implementation is published.

## Manifest and scope

MANIFEST.json lists every public member except itself using path, bytes and
sha256. The deterministic tar.gz contains those files plus MANIFEST.json and
has been read back against every member. The archive receipt is external to
the archive to avoid a self-referential digest.

This package documents an unresolved inherited evidence-availability gate.
All security-work qualification flags remain HOLD/false and chainwork remains
zero. It supplies no independent demand, public-query completeness, physical
cost lower bound or native consensus registration.
