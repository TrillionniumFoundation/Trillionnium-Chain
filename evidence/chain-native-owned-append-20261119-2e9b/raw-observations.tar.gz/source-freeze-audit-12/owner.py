from pathlib import Path
import subprocess,json,hashlib,time,resource,sys,traceback
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=s.parent/'source-freeze-audit-12';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);inp=json.loads(sys.argv[2]);(out/'retained-prior-read-probe.json').write_text(json.dumps(inp['prior_failed_read_probe'],indent=2)+'\n');res={'schema':'chain-owned-append-unchanged-contract-and-source-audit-v1','complete':False};t=time.monotonic();r=resource.getrusage(resource.RUSAGE_CHILDREN)
try:
 paths=['.github/workflows/pon-fixed-host-root-f0.yml','scripts/run_fixed_host_root_f0.py','scripts/read_original_native_campaign.py','trillionnium/crates/trnm-pon-node/src/host_kernel_parent.rs','trillionnium/crates/trnm-pon-node/src/ingress/public_v3/scalar_cpu.rs','trillionnium/crates/trnm-pon-node/src/ingress/public_v3/scalar_cpu_metered_fact_tests.rs','trillionnium/crates/trnm-pon-node/tests/public_v3_multiprocess.rs','config/systemd/trnmponpublic.slice','trillionnium/Cargo.lock','trillionnium/Cargo.toml']
 rows=[]
 for p in paths:
  a=(s/p).read_bytes();b=subprocess.check_output(['git','show','HEAD:'+p],cwd=s);assert a==b,p;rows.append({'path':p,'bytes':len(a),'sha256':hashlib.sha256(a).hexdigest(),'unchanged':True})
 assert rows[0]['sha256']==inp['expected_f0_sha256']
 provenance=json.loads((s/'evidence/chain-native-owned-append-20261119-2e9b/controls/PROVENANCE.json').read_text())
 for p,wanted in provenance['source_sha256'].items():assert hashlib.sha256((s/p).read_bytes()).hexdigest()==wanted,p
 changed=subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=s,text=True).splitlines();untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=s,text=True).splitlines()
 hashes={}
 for p in changed+untracked:
  raw=(s/p).read_bytes();hashes[p]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()}
 a=resource.getrusage(resource.RUSAGE_CHILDREN);res.update(complete=True,source_parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),invariants=rows,actual_tested_rust_sources=provenance['source_sha256'],changed=changed,untracked=untracked,source_files=hashes,wall_seconds=time.monotonic()-t,child_user_cpu_seconds=a.ru_utime-r.ru_utime,child_system_cpu_seconds=a.ru_stime-r.ru_stime)
 (out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({'complete':True,'source_parent':res['source_parent'],'invariants':rows,'changed':changed,'untracked':untracked},indent=2))
except BaseException as e:res['error']=repr(e);(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');traceback.print_exc();raise
