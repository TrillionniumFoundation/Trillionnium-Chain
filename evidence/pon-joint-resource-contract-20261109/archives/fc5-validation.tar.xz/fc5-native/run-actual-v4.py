from pathlib import Path
import datetime,hashlib,json,os,resource,signal,subprocess,sys,time
root=Path('/workspace/scratch/pon-joint-58fd59-build/chain')
out=root.parent/'fc5-native'/'v4-observation'
out.mkdir(exist_ok=False)
binary=root.parent/'target/release/examples/pon_w1_lifecycle_cost_v4'
head='fc5c44ca91c56e77ca2ffc9943e10f0f777a5937'
sys.path.insert(0,str(root/'scripts/ci'))
from verify_ci_source import verify
before=verify('head',head,root=root)
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy();env.update(json.loads((root.parent/'fc5-native/serial-environment.json').read_text())['environment'])
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def run(name,terminate):
 raw=out/(name+'.jsonl');err=out/(name+'.stderr')
 argv=[str(binary),'--actual-lifecycle-v4']
 rec={'name':name,'head':head,'argv':argv,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'public_resource_contract_measured':False,'source_binary_resource_identity_authenticated_by_reader':False,'signal_inside_specific_native_instruction_observed':False,'consensus_credit_added':0,'production_qualified':False,'binary_before':{'path':str(binary),'bytes':binary.stat().st_size,'sha256':sha(binary)},'deadline_seconds':600,'signal_request':None}
 prior=resource.getrusage(resource.RUSAGE_CHILDREN);beg=time.monotonic_ns()
 with raw.open('xb') as stream,err.open('xb') as stderr:
  child=subprocess.Popen(argv,cwd=root,env=env,stdout=subprocess.PIPE if terminate else stream,stderr=stderr)
  rec['pid']=child.pid
  try:
   rec['loaded_executable']={'path':os.readlink(f'/proc/{child.pid}/exe'),'sha256':sha(f'/proc/{child.pid}/exe')}
   rec['process_stat_observed']=Path(f'/proc/{child.pid}/stat').read_text()
  except OSError as e:rec['process_identity_observation_error']=str(e)
  if terminate:
   for line in child.stdout:
    stream.write(line);stream.flush()
    if rec['signal_request'] is None and line.endswith(b'\n'):
     row=json.loads(line)
     if row.get('kind')=='attempt-start':
      rec['signal_request']={'signal':signal.SIGTERM,'after_observed_sequence':row['sequence'],'after_observed_kind':row['kind'],'elapsed_ns':time.monotonic_ns()-beg}
      child.send_signal(signal.SIGTERM)
   child.stdout.close()
  try:code=child.wait(timeout=600)
  except subprocess.TimeoutExpired:
   rec['outer_timeout']=True;child.kill();code=child.wait()
 rec['exit_code']=code;rec['wall_ns']=time.monotonic_ns()-beg
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 rec['serial_child_rusage_delta']={'user_seconds':after.ru_utime-prior.ru_utime,'system_seconds':after.ru_stime-prior.ru_stime,'scope':'one serial native child; source verifier/reader outside interval'}
 rec['binary_after']={'bytes':binary.stat().st_size,'sha256':sha(binary)}
 rec['raw']={'file':raw.name,'bytes':raw.stat().st_size,'sha256':sha(raw)}
 rec['stderr']={'file':err.name,'bytes':err.stat().st_size,'sha256':sha(err)}
 readargv=[sys.executable,str(root/'scripts/pon_w1_lifecycle_cost_v4.py'),str(raw),'--process-exit-code',str(code)]
 with (out/(name+'-readback.json')).open('xb') as stdout,(out/(name+'-readback.stderr')).open('xb') as stderr:
  read=subprocess.run(readargv,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=120)
 rec['reader_argv']=readargv;rec['reader_exit_code']=read.returncode
 (out/(name+'-receipt.json')).write_text(json.dumps(rec,indent=2)+'\n')
 print(json.dumps({'name':name,'exit_code':code,'reader_exit_code':read.returncode,'raw_bytes':raw.stat().st_size,'receipt':str(out/(name+'-receipt.json'))}),flush=True)
 return code,read.returncode
full=run('complete',False);stopped=run('terminated',True)
after=verify('head',head,root=root)
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert before==after
assert full==(0,0),full
assert stopped==(-signal.SIGTERM,3),stopped
