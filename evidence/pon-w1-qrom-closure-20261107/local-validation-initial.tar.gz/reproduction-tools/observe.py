#!/usr/bin/env python3
"""Retain exact local validation observations; temporary task orchestration."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--name', required=True)
parser.add_argument('--cwd', required=True)
parser.add_argument('--timeout', type=int, default=600)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
root = Path('/workspace/scratch/4a83c49617d8/validation')
root.mkdir(exist_ok=True)
record = root / (args.name + '.json')
if record.exists():
    raise SystemExit('refusing to replace existing observation: ' + str(record))
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
begin = time.monotonic()
process = subprocess.Popen(command, cwd=args.cwd, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, start_new_session=True)
timed_out = False
try:
    stdout, stderr = process.communicate(timeout=args.timeout)
except subprocess.TimeoutExpired:
    timed_out = True
    os.killpg(process.pid, signal.SIGKILL)
    stdout, stderr = process.communicate()
for suffix, data in [('stdout', stdout), ('stderr', stderr)]:
    (root / (args.name + '.' + suffix + '.log')).write_bytes(data)
data = {'name': args.name, 'command': command, 'cwd': args.cwd,
        'started_utc': start, 'elapsed_seconds': time.monotonic() - begin,
        'exit_code': process.returncode, 'timed_out': timed_out,
        'stdout_bytes': len(stdout), 'stderr_bytes': len(stderr),
        'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
        'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
        'scope': 'Observed command result, not cryptographic or production qualification.'}
record.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
print(json.dumps(data, sort_keys=True))
print((stdout + stderr).decode('utf-8', errors='replace')[-3000:])
raise SystemExit(process.returncode if process.returncode >= 0 else 2)
