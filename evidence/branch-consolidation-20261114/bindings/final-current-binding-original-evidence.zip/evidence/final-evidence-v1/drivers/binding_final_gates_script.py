from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
root=Path('/private/tmp/chain-final-current-bindings-20261114')
out=Path('/private/tmp/chain-final-current-bindings-evidence-20261114/final-gates-v1');out.mkdir()
(out/'pid.json').write_text(json.dumps({'pid':os.getpid(),'started':time.time()})+'\n')
env={**os.environ,'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','GIT_NO_LAZY_FETCH':'1','TMPDIR':'/private/tmp/chain-final-current-bindings-evidence-20261114/final-checkpoint-v1/canonical-tmp','PYTHONDONTWRITEBYTECODE':'1','GIT_PAGER':'cat','PAGER':'cat'}
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-c','core.commitGraph=false',*args],cwd=root,env=env)
assert git('rev-parse','HEAD').decode().strip()=='5c04c60e463462d9df8884786e0d5bb32af08a64'
paths=git('diff','--name-only').decode().splitlines();assert len(paths)==34
assert not any(p.endswith(('.rs','Cargo.toml','Cargo.lock')) for p in paths)
before={p:sha((root/p).read_bytes()) for p in paths}
steps=[]
for name,args in [
('01-preflight',['bash','scripts/project-preflight.sh']),
('02-ci-contract',[sys.executable,'scripts/ci/check_ci_contract.py']),
('03-current-corpus',[sys.executable,'scripts/ci/check_pq_research_integration.py']),
('04-repository',[sys.executable,'scripts/ci/check_repository.py']),
('05-diff-check',['git','diff','--check'])]:
    with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:
        r=subprocess.run(args,cwd=root,env=env,stdout=so,stderr=se,check=False)
    row={'name':name,'args':args,'exit':r.returncode,'stdout_sha256':sha((out/(name+'.stdout')).read_bytes()),'stderr_sha256':sha((out/(name+'.stderr')).read_bytes())}
    steps.append(row);(out/'steps.json').write_text(json.dumps(steps,indent=2,sort_keys=True)+'\n');print(json.dumps(row),flush=True)
    if r.returncode:sys.exit(r.returncode)
after={p:sha((root/p).read_bytes()) for p in paths};assert before==after
files=[]
for p in paths:
    b=(root/p).read_bytes();base=git('show','HEAD:'+p)
    files.append({'path':p,'before_bytes':len(base),'before_sha256':sha(base),'before_git_blob':hashlib.sha1(b'blob '+str(len(base)).encode()+b'\0'+base).hexdigest(),'after_bytes':len(b),'after_sha256':sha(b),'after_git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
summary={'base':'5c04c60e463462d9df8884786e0d5bb32af08a64','all_gates_passed':True,'inputs_before_after_equal':True,'paths':files,'steps':steps,'rust_source_changes':False,'full_ci_contract_suite_not_repeated':True,'root_ci_fixture_commit':'51c215b45c41180fc044ec806fde39c7ceffb75c','root_ci_fixture_path_outside_232_source_union':True}
(out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({'all_gates_passed':True,'paths':len(paths),'summary_sha256':sha((out/'summary.json').read_bytes())}),flush=True)
