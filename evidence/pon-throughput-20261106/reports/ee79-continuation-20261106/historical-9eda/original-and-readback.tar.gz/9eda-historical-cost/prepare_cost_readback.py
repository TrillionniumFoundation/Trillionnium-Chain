from pathlib import Path
import datetime
import gzip
import hashlib
import json
import shutil
import subprocess
import time
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent / 'trillionnium-chain'
HEAD = '9eda0ada15be1702269e08e527917568c710f4d3'
TREE = '6b2437a1224683464c68a540fc59ff7c8eccdaa3'
READER = '0bca28ebf59058b6aba9db5eb956c4479556e9ee'
READER_TREE = '06e394f20b8f491c4ea1f91a357e2b6e8a4c0812'
CARRIER = ROOT / 'carrier'
INPUTS = ROOT / 'expanded-inputs'
FILES = [
    'scripts/ci/throughput_cost_coverage.py',
    'scripts/pon_public_v3_phase_read.py',
    'scripts/pon_public_v3_policy_read.py',
    'scripts/ci/read_native_cache_observation.py',
    'config/pon/public-resource-profile-vectors-v1.json',
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


assert git('rev-parse', READER + '^{tree}').decode().strip() == READER_TREE
assert not CARRIER.exists() and not INPUTS.exists()
CARRIER.mkdir()
INPUTS.mkdir()
source_dir = CARRIER / 'original'
source_dir.mkdir()
reader_dir = CARRIER / 'reader-source'
reader_dir.mkdir()
coverage_dir = CARRIER / 'coverage'
coverage_dir.mkdir()
api_dir = CARRIER / 'api'
api_dir.mkdir()
for name in ['api-workflow-run-artifacts.json', 'api-workflow-run-jobs.json', 'download-receipt.json']:
    shutil.copyfile(ROOT / name, api_dir / name)

reader_files = []
for name in FILES:
    data = git('show', READER + ':' + name)
    path = reader_dir / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    reader_files.append({'repo_path': name, 'bytes': len(data), 'sha256': digest(data),
                         'git_blob': git('rev-parse', READER + ':' + name).decode().strip()})
write_json(CARRIER / 'reader-source-manifest.json', {
    'schema': 'historical-cost-reader-source-blobs-v1', 'reader_commit': READER,
    'reader_tree': READER_TREE, 'files': reader_files,
    'scope': 'Exact committed reader and dependencies only; original native execution remains bound to9eda.'})

archive = ROOT / 'artifact-13495362625.zip'
assert archive.stat().st_size == 65440211
assert digest(archive.read_bytes()) == '24ba87d4e957a9dc99a64177e4410b5a0da9208a3c00a637b43dc629e5d9a55b'
extracted = []
reports = []
with zipfile.ZipFile(archive) as zipped:
    original_manifest = json.loads(zipped.read('artifact-files.json'))
    entries = {entry['path']: entry for entry in original_manifest['files']}

    def checked_member(name):
        data = zipped.read(name)
        if name != 'artifact-files.json':
            expected = entries[name]
            assert len(data) == expected['bytes'], name
            assert digest(data) == expected['sha256'], name
        return data

    names = [
        'artifact-files.json', 'SCOPE.txt', 'results.json', 'run-native-campaign.py',
        'source-before-campaigns.json', 'source-before-build.json', 'source-before.json',
        'source-after-native.json', 'source-after.json', 'binary-before.json',
        'build.step.json', 'build.stdout.log', 'build.stderr.log', 'hardware.json',
        'resource-before-build.json', 'resource-after-native.json', 'preflight.log',
        'cargo-version.txt', 'rustc-version.txt', 'systemd-version.txt',
    ]
    for number in [1, 2, 3]:
        names.extend(f'run-{number}{suffix}' for suffix in [
            '-source-after.json', '-result.json', '.step.json', '.stdout.log', '.stderr.log',
            '-resource-before.json', '-resource-after.json',
        ])
        names.append(f'run-{number}-raw/campaign-failure.json')
    for name in names:
        data = checked_member(name)
        destination = source_dir / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        extracted.append({'archive_member': name, 'carrier_file': destination.relative_to(CARRIER).as_posix(),
                          'bytes': len(data), 'sha256': digest(data),
                          'original_artifact_manifest_checked': name != 'artifact-files.json'})
    results = json.loads((source_dir / 'results.json').read_text())
    before = json.loads((source_dir / 'source-before-campaigns.json').read_text())
    assert before['tested_commit'] == HEAD and before['tested_tree'] == TREE
    assert before['tracked_worktree_verified'] and not before['tests_executed_by_identity_check']
    for name in ['source-before-build.json', 'source-before.json', 'source-after-native.json',
                 'source-after.json', 'run-1-source-after.json', 'run-2-source-after.json',
                 'run-3-source-after.json']:
        assert json.loads((source_dir / name).read_text()) == before, name
    assert results['expected_head'] == HEAD and results['expected_tree'] == TREE
    assert results['source_after'] == before
    assert results['failure'] == 'ORIGINAL_THREE_RUN_CAMPAIGN_FAILED'
    assert len(results['attempts']) == results['planned_complete_runs'] == 3
    assert digest((source_dir / 'run-native-campaign.py').read_bytes()) == results['runner_sha256']
    for attempt in results['attempts']:
        number = attempt['number']
        assert not attempt['complete_success'] and not attempt['original_criteria_met']
        assert attempt['step']['returncode'] == 101
        for stream in ['stdout', 'stderr']:
            data = (source_dir / attempt['step'][stream]).read_bytes()
            assert len(data) == attempt['step'][stream + '_bytes']
            assert digest(data) == attempt['step'][stream + '_sha256']
            assert not attempt['step'][stream + '_truncated']
        member = f'run-{number}-raw/report.json'
        data = checked_member(member)
        assert digest(data) == attempt['report_sha256']
        plain = INPUTS / f'run-{number}-report.json'
        plain.write_bytes(data)
        packed = gzip.compress(data, compresslevel=9, mtime=0)
        gzip_path = source_dir / f'run-{number}-report.json.gz'
        gzip_path.write_bytes(packed)
        assert gzip.decompress(packed) == data
        reports.append({'number': number, 'archive_member': member, 'plain_input': str(plain),
                        'original_report_bytes': len(data), 'original_report_sha256': digest(data),
                        'gzip_file': gzip_path.relative_to(CARRIER).as_posix(), 'gzip_bytes': len(packed),
                        'gzip_sha256': digest(packed), 'gzip_mtime': 0,
                        'losslessly_matches_original_zip_member': True})

commands = []
for report in reports:
    number = report['number']
    output = coverage_dir / f'run-{number}-cost-coverage.json'
    argv = ['python3', '-B', str(reader_dir / 'scripts/ci/throughput_cost_coverage.py'),
            report['plain_input'], '--report-sha256', report['original_report_sha256'],
            '--source', str(source_dir / 'source-before-campaigns.json'),
            '--source-after', str(source_dir / f'run-{number}-source-after.json'),
            '--expected-head', HEAD, '--expected-tree', TREE, '--output', str(output)]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic_ns()
    result = subprocess.run(argv, cwd=reader_dir, capture_output=True)
    elapsed = time.monotonic_ns() - clock
    stdout = coverage_dir / f'run-{number}-reader.stdout.log'
    stderr = coverage_dir / f'run-{number}-reader.stderr.log'
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    command = {'number': number, 'argv': argv, 'cwd': str(reader_dir), 'started_utc': started,
               'elapsed_ns': elapsed, 'returncode': result.returncode, 'reader_commit': READER,
               'original_native_execution_head': HEAD, 'new_native_execution': False,
               'stdout': stdout.relative_to(CARRIER).as_posix(), 'stdout_sha256': digest(result.stdout),
               'stdout_bytes': len(result.stdout), 'stderr': stderr.relative_to(CARRIER).as_posix(),
               'stderr_sha256': digest(result.stderr), 'stderr_bytes': len(result.stderr),
               'output': output.relative_to(CARRIER).as_posix() if output.exists() else None,
               'output_sha256': digest(output.read_bytes()) if output.exists() else None}
    commands.append(command)
    write_json(coverage_dir / f'run-{number}-reader-command.json', command)
    assert result.returncode == 0, result.stderr.decode()
    print(json.dumps({'report': number, 'reader_exit': result.returncode,
                      'output_bytes': output.stat().st_size, 'output_sha256': command['output_sha256']}), flush=True)

write_json(CARRIER / 'readback-receipt.json', {
    'schema': 'pon-9eda-historical-cost-readback-v1',
    'original_execution_source_head': HEAD, 'original_execution_source_tree': TREE,
    'reader_commit': READER, 'reader_tree': READER_TREE,
    'github_run_id': 42201852774, 'github_job_id': 127838794285, 'github_artifact_id': 13495362625,
    'archive_bytes': archive.stat().st_size, 'archive_sha256': digest(archive.read_bytes()),
    'original_result': 'ORIGINAL_THREE_RUN_CAMPAIGN_FAILED',
    'original_native_exit_codes': [101, 101, 101],
    'retained_source_receipts_equal': True, 'reports': reports,
    'copied_original_files': extracted, 'reader_files': reader_files, 'reader_commands': commands,
    'source_files_modified': False, 'new_native_execution': False,
    'native_performance_qualified': False, 'cross_source_improvement_claimed': False,
    'scope': 'Original9eda failure, independently API/hash verified and re-read; not0bca native performance.'})
print(json.dumps({'status': 'ALL_THREE_COST_READERS_COMPLETED', 'carrier': str(CARRIER),
                  'original_failure_preserved': True, 'new_native_execution': False}), flush=True)
