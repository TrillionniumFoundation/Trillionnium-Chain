from pathlib import Path
import os,sys,json,hashlib,stat,tarfile,time,subprocess,traceback,shutil
root=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo");base=root.parent/"ci-c390-readback-v1"
out=base/"verified-batch-host-readback-copy-cleanup-v1";out.mkdir(mode=0o700)
(out/"driver.py").write_text(sys.argv[1])
started=time.monotonic_ns();report={"schema":"trnm.verified-ci-readback-copy-cleanup-index.v1","status":"FAIL","artifacts":[]}
CONFIGS=[[14300313900,12852865,"448290c665e56856712c7f6f566b8a766b53db580daa485f2b7904cb3c5296d3"],[14300313335,8048793,"284b2ca7cfc15b0acfb64486be88cc605dfe43acc01576e4ddb2ffac34cb816a"],[14300787115,13032423,"fc2aef6f38eee8bc0cd8d87de39536accedd9828192e27c88573bde8b8de3e9c"],[14300602740,8795891,"caf227cb6defe02a5b26b25a1f2bc133894008e8bae6b0c8458b3d24bcccd062"],[14300299370,9505317,"bd380b9b961ce3c030b6276468711ec3c88fb94aa54852b869c4e4f34a61257b"],[14300298642,9256268,"e53b6078c0683146937ca1f5d293ca7e7ccb4de09f58b0ce8499923872b3602b"],[14301465206,4416239,"d0b40bf1b430b9f09c5e2ecab6f8b1cb54347ffcd7b4ddee7636dde1725cdba0"],[14302600832,42632361,"cf8fbc5843440137c074c2bff9da50cd8c1a6d9a27ba9d03b4a1401d1937201e"],[14302198574,98249441,"66c4d55e1fafcd608e9f5606651b52a26e8c2a303037319c3050b6252e3cb7d2"],[14300299588,247580815,"b3f49fd5d165048362a544f9a83508850dfaa23cb0668d82c0fde38170ad7ca3"]]
def need(v,m):
 if not v:raise ValueError(m)
def ident(p):
 s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1,"Nonregular or linked evidence: "+str(p))
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(1<<20),b""):h.update(b)
 return {"bytes":s.st_size,"sha256":h.hexdigest()}
def stamp(p):
 s=p.lstat();return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns]

try:
 p=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=root,capture_output=True)
 (out/"preflight.stdout.raw").write_bytes(p.stdout);(out/"preflight.stderr.raw").write_bytes(p.stderr);need(p.returncode==0,"Preflight failed")
 need(subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()=="c3901ff19c26815205d9cdd6975fc24ecc51ae88","Head moved")
 need(subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True)=="","Canonical source dirty")
 for aid,zipbytes,zipsha in CONFIGS:
  item={"artifact_id":aid,"status":"FAIL","deleted":[]};report["artifacts"].append(item)
  artifact=base/str(aid);container=artifact/("independent-readback-v1" if aid==14300299588 else "independent-batch-readback-v1")
  source=container/"unpacked";qualification=container/"report.json";q=json.loads(qualification.read_text())
  expected_lineage={"attempt":1,"git_head":"c3901ff19c26815205d9cdd6975fc24ecc51ae88","run_id":"44019939486"}
  need(q["status"]=="PASS" and q["source_after"]=="MATCH" and q["expected_lineage"]==expected_lineage,"Readback incomplete")
  archive=container/("package/complete-evidence.tar.xz" if aid==14300299588 else "container/evidence.tar.xz")
  expected_archive=q["archive"]["archive"] if aid==14300299588 else q["archive"]
  expected_zip={"bytes":zipbytes,"sha256":zipsha};original_zip=artifact/"artifact.zip"
  need(ident(archive)==expected_archive,"Retained complete archive differs")
  need(ident(original_zip)==expected_zip,"Retained original ZIP differs")
  need(source.is_dir() and not source.is_symlink(),"Private expanded root absent/linked")
  members={};dirs={};seen=set()
  with tarfile.open(archive,"r:xz") as tf:
   for member in tf:
    rel=Path(member.name);need(not rel.is_absolute() and member.name==rel.as_posix() and all(x not in ("",".","..") for x in rel.parts),"Unsafe member")
    need(member.name not in seen,"Duplicate member");seen.add(member.name);target=source/rel
    for a in [source,*list(target.parents)[:len(rel.parts)-1]]:need(a.is_dir() and not a.is_symlink(),"Linked parent")
    if member.isdir():need(target.is_dir() and not target.is_symlink(),"Directory differs");continue
    need(member.isfile(),"Special member cannot be discarded")
    before=stamp(target);need(stat.S_ISREG(before[2]) and before[3]==1 and before[4]==member.size,"Expanded member metadata differs")
    h=hashlib.sha256();count=0
    with tf.extractfile(member) as incoming,open(target,"rb") as actual:
     while True:
      block=incoming.read(1<<20)
      if not block:break
      need(actual.read(len(block))==block,"Expanded full bytes differ: "+member.name)
      h.update(block);count+=len(block)
     need(actual.read(1)==b"" and count==member.size,"Expanded extent differs")
    need(stamp(target)==before,"Expanded file changed while checking")
    members[member.name]={"bytes":count,"sha256":h.hexdigest(),"stamp":before,"archived_mode":member.mode}
  observed=set()
  for a,ds,fs in os.walk(source,followlinks=False):
   p=Path(a);dirs[str(p.relative_to(source))]=stamp(p)
   for name in ds:need((p/name).is_dir() and not (p/name).is_symlink(),"Unexpected linked directory")
   for name in fs:
    f=p/name;need(f.is_file() and not f.is_symlink(),"Unexpected special node");observed.add(f.relative_to(source).as_posix())
  need(observed==set(members),"Expanded path set differs")
  plan={"schema":"trnm.complete-archive-recoverable-copy.v1","source":str(source),"retained_archive":str(archive),"archive":expected_archive,"retained_zip":str(original_zip),"zip":expected_zip,"qualification":ident(qualification),"files":members,"directories":dirs,"regular_bytes":sum(x["bytes"] for x in members.values()),"full_payload_comparison":True}
  raw=(json.dumps(plan,sort_keys=True,indent=2)+"\n").encode();planpath=out/(str(aid)+"-plan.json")
  with planpath.open("xb") as f:f.write(raw);f.flush();os.fsync(f.fileno())
  need(ident(archive)==expected_archive and ident(original_zip)==expected_zip,"Retained archive changed before deletion")
  for name,member in members.items():
   target=source/name;need(stamp(target)==member["stamp"],"Changed file before exact unlink");target.unlink();item["deleted"].append(name)
  for name in sorted(dirs,key=lambda x:len(Path(x).parts),reverse=True):
   if name!=".":(source/name).rmdir()
  source.rmdir()
  need(ident(archive)==expected_archive and ident(original_zip)==expected_zip,"Retained archive changed after deletion")
  need(ident(qualification)==plan["qualification"],"Semantic readback report changed")
  item.update(status="PASS",deleted_files=len(members),deleted_bytes=plan["regular_bytes"],proof={"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()},complete_archive_retained=True,original_zip_retained=True,semantic_readback_report_retained=True)
  (out/"progress.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
  print(json.dumps({k:v for k,v in item.items() if k!="deleted"}),flush=True)
 report.update(status="PASS",deleted_files=sum(x["deleted_files"] for x in report["artifacts"]),deleted_bytes=sum(x["deleted_bytes"] for x in report["artifacts"]),source_head=expected_lineage["git_head"])
except BaseException as e:report["failure"]={"error":repr(e),"traceback":traceback.format_exc()};raise
finally:
 report["elapsed_ns"]=time.monotonic_ns()-started;report["free_bytes_after"]=shutil.disk_usage(base).free
 (out/"report.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
 print(json.dumps({k:v for k,v in report.items() if k!="artifacts"}),flush=True)
