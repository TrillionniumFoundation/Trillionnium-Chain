import os,json,stat,hashlib,re,sys,time
from pathlib import Path
os.sched_setaffinity(0,{20,21})
root=Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery');q=root/'clean-C3-build-qualification-01'
out=q/'owner-node-m12-01';records=q/'owner-connector-records-01'
records.mkdir()
def require(v,m):
 if not v:raise ValueError(m)
def pin(p):
 s=p.lstat();require(stat.S_ISREG(s.st_mode) and s.st_nlink==1,'single-link regular file')
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 e=p.lstat();require((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(e.st_dev,e.st_ino,e.st_size,e.st_mtime_ns,e.st_ctime_ns),'file changed while read')
 return {'path':str(p),'bytes':s.st_size,'sha256':h.hexdigest()}
def save(p,v):
 with p.open('x') as f:json.dump(v,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def j(p,cap=1024*1024):
 with p.open('rb') as f:b=f.read(cap+1)
 require(len(b)<=cap,'bounded JSON');return json.loads(b)
payload=json.load(sys.stdin)
with (records/'postgate-collector.py').open('x') as f:
 f.write(payload['collector_source']);f.flush();os.fsync(f.fileno())
save(records/'tool-records.json',payload['tool_records'])
with (records/'gate-terminal.raw.json').open('x') as f:
 f.write(payload['gate_terminal_raw']);f.flush();os.fsync(f.fileno())
terminal=json.loads(payload['gate_terminal_raw'])
require(terminal['job_id']=='1a1b874bfc6-12894-f89' and terminal['state']=='succeeded' and terminal['exit_code']==0 and terminal['output_complete'] is True and terminal['output_durable'] is True and not terminal['timed_out'] and not terminal['cancelled'],'actual owner terminal')
m=j(out/'manifest.json')
require(m['qualification_complete'] is True and m['source_commit']=='abab79dac0cb89eb2753d3f579119ac135650eb5' and m['source_tree']=='194808f4a0db5d642aa746beb251ca9e9532cebb','actual C3 source/gate')
require(len(m['commands'])==16 and all(x['exit']==0 and not x['timed_out'] and x['error'] is None for x in m['commands']),'all16commands')
expected_counts={'node_passed':15,'node_explicit_ignored':3,'m12_passed':10,'m12_ignored':0,'legacy_admission_passed':1,'legacy_admission_ignored':0,'legacy_reorg_passed':5,'legacy_reorg_ignored':0}
require(m['test_counts']==expected_counts,'actual count contract')
for row in m['commands']:
 for kind in ['stdout','stderr']:
  observed=pin(Path(row[kind]['path']))
  require(all(observed[k]==row[kind][k] for k in ['path','bytes','sha256']),'retained command log changed')
new=m['binaries']['owner_test'];new_actual=pin(Path(new['path']))
require(all(new_actual[k]==new[k] for k in ['path','bytes','sha256']),'new actual owner ELF')
require(Path(new['path']).is_relative_to(root/'target-owner-exact-source-abab79dac0cb89eb2753d3f579119ac135650eb5-01'),'new target')
entry=j(out/'owner-entry-readback.json')
require(entry['all_three_present_once'] is True and entry['all_six_retained_present_once'] is True and entry['ignored_entries_executed'] is False,'actual ELF selectors')
before=j(out/'source-before.json');after=j(out/'source-after.json')
require(before==after and before['tested_commit']==m['source_commit'] and before['tested_tree']==m['source_tree'] and before['tracked_worktree_verified'] is True,'before/after source')
source_manifest=root/'clean-C2-build-qualification-01/owner-node-m12-01/manifest.json'
require(pin(source_manifest)['sha256']=='8e0eb2105eb92385321123797eb6b31c5c59654e19c6a3386dbe4a0028aa8b76','historical C2 manifest')
old=j(source_manifest)['binaries']['owner_test'];old_actual=pin(Path(old['path']))
require(all(old_actual[k]==old[k] for k in ['path','bytes','sha256']),'original C2 owner changed after gate')
cache=q/'owner-node-m12-01-cache-setup/manifest.json';c=j(cache)
require(c['cache_setup_complete'] is True and c['copied_cache_from_C2'] is True and c['source_commit']==m['source_commit'] and c['shared_original_regular_inodes']==0,'actual C2 isolated copy')
absence=q/'owner-original-paths-readback-02/observation.json'
require(pin(absence)['sha256']=='daa185c7e66cc3af6516a7f1270d9fe4cb0674f03089bc530a5a54cf69b9b2ee','prior path absence observation')
r={'schema':'TRNM-W1-C3-OWNER-POSTGATE-READBACK1','source_commit':m['source_commit'],'source_tree':m['source_tree'],'actual_gate_job_id':terminal['job_id'],'actual_terminal':{'state':terminal['state'],'exit_code':terminal['exit_code'],'output_complete':terminal['output_complete'],'output_durable':terminal['output_durable'],'timed_out':terminal['timed_out'],'cancelled':terminal['cancelled']},'qualification_complete':True,'commands_verified':16,'test_counts':m['test_counts'],'owner_manifest':pin(out/'manifest.json'),'source_before':pin(out/'source-before.json'),'source_after':pin(out/'source-after.json'),'cache_manifest':pin(cache),'owner_ELF':new_actual,'cargo_artifact':pin(out/'owner-cargo-artifact.json'),'entry_readback':pin(out/'owner-entry-readback.json'),'total_listed_tests':entry['total_listed_tests'],'original_C2_owner_after_gate':old_actual,'original_C2_owner_unchanged_after_gate':True,'original_C1_C1b_bytes_revalidated':False,'prior_fixed_paths_absence_observation':pin(absence),'tool_records':pin(records/'tool-records.json'),'gate_terminal_raw':pin(records/'gate-terminal.raw.json'),'collector_source':pin(records/'postgate-collector.py'),'fresh_cargo_target':False,'independent_reproducible_build_established':False,'heavy_proofs_executed':0,'ignored_entries_executed':False,'observed_monotonic_ns':time.monotonic_ns()}
save(q/'owner-postgate-readback.json',r)
print(json.dumps({'readback':pin(q/'owner-postgate-readback.json'),**r},sort_keys=True,allow_nan=False))
