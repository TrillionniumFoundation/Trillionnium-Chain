#!/usr/bin/env python3
"""Retain actual command outputs on an exactly committed source tree."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(repo, expected):
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
    if head != expected:
        raise ValueError('HEAD_CHANGED')
    tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=repo, text=True).strip()
    entries = subprocess.check_output(['git', 'ls-tree', '-r', '-z', 'HEAD'], cwd=repo).split(b'\0')
    inventory = []
    for entry in entries:
        if not entry:
            continue
        meta, name = entry.split(b'\t', 1)
        mode, kind, expected_blob = meta.decode().split()
        path = repo / name.decode()
        status = path.lstat()
        if kind != 'blob' or mode not in ('100644', '100755', '120000'):
            raise ValueError('UNSUPPORTED_TRACKED_ENTRY:' + str(path))
        if mode == '120000':
            if not stat.S_ISLNK(status.st_mode):
                raise ValueError('SOURCE_TYPE:' + str(path))
            raw = os.readlink(path).encode()
        else:
            if not stat.S_ISREG(status.st_mode) or bool(status.st_mode & 0o111) != (mode == '100755'):
                raise ValueError('SOURCE_MODE:' + str(path))
            raw = path.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw,
                              usedforsecurity=False).hexdigest()
        if actual != expected_blob:
            raise ValueError('SOURCE_BYTES:' + str(path))
        inventory.append((name.decode(), mode, actual, hashlib.sha256(raw).hexdigest()))
    return {'head': head, 'tree': tree, 'tracked_files': len(inventory),
            'inventory_sha256': hashlib.sha256(json.dumps(inventory, separators=(',', ':')).encode()).hexdigest()}



# The source(repo, expected) function above is copied verbatim from run_remote_validation.py.
import re
import resource
import shutil
import signal
import traceback

DRIVER_STARTED = time.monotonic()
FORMAL = 'formal/pon-nakamoto-v1'
MANIFEST = 'trillionnium/Cargo.toml'
CLAIMS = dict(quantum_hardware_executed=False, exclusive_calibration=False,
              physical_hardware_calibrated=False, quantum_mining_qualified=False,
              whole_chain_qualified=False, production_activation=False)
ROOT_TESTS = (
    'canonical_root_role_keys_round_trip_through_both_tagged_envelopes',
    'tagged_root_role_keys_reject_duplicates_aliases_and_unknown_roles',
    'all_three_service_keys_are_excluded_from_offline_root_and_every_online_role',
    'valid_dual_quorum_successor_cannot_reuse_an_independent_service_key',
    'expired_old_root_keeps_dual_quorum_recovery_and_cold_proof_replay',
    'expired_root_recovery_requires_both_real_quorums_and_a_fresh_successor')
SEALED_TESTS = (
    'sealed_copy_survives_in_place_source_rewrite_and_path_replacement',
    'sealed_handoff_retains_reserved_descriptor_as_read_only_and_cloexec',
    'read_only_sealed_object_still_rejects_a_successful_permission_change',
    'source_rewrite_or_path_exchange_during_sealing_refuses_authentication',
    'inherited_fifo_without_writer_is_refused_before_any_blocking_open',
    'unsealed_regular_input_and_a_different_sealed_descriptor_are_rejected',
    'native_elf_profile_rejects_interpreter_dependencies_search_paths_and_wrong_machine')
NATIVE_TESTS = {
    'base-export': 'quantum_native_bridge_tests::export_source_bound_native_dag_fixture',
    'base-replay': 'quantum_native_bridge_tests::replay_source_bound_native_search_samples',
    'competition-export': 'quantum_native_bridge_tests::competition::export_source_bound_native_competition_fixture',
    'competition-replay': 'quantum_native_bridge_tests::competition::replay_source_bound_native_competition_samples'}


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    temporary = path.with_name(path.name + '.pending')
    with temporary.open('w', encoding='utf-8') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def strict_json(raw):
    def pairs(rows):
        result = {}
        for key, value in rows:
            if key in result:
                raise ValueError('DUPLICATE_JSON_KEY:' + key)
            result[key] = value
        return result
    def invalid(value):
        raise ValueError('NONFINITE_JSON:' + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def identity(path):
    path = Path(path).absolute()
    resolved = path.resolve(strict=True)
    status = resolved.stat()
    if not stat.S_ISREG(status.st_mode):
        raise ValueError('NOT_REGULAR_FILE:' + str(path))
    with resolved.open('rb') as stream:
        header = stream.read(64)
    return {'path': str(path), 'resolved_path': str(resolved), 'size_bytes': status.st_size,
            'mode': oct(stat.S_IMODE(status.st_mode)), 'sha256': digest(resolved),
            'elf_magic': header[:4] == b'\x7fELF',
            'elf_machine': int.from_bytes(header[18:20], 'little' if header[5:6] == b'\x01' else 'big')
                           if header[:4] == b'\x7fELF' and len(header) >= 20 else None}


def full_inventory(repo):
    entries = subprocess.check_output(['git', 'ls-tree', '-r', '-z', 'HEAD'], cwd=repo).split(b'\0')
    rows = []
    for entry in entries:
        if not entry:
            continue
        meta, raw_name = entry.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        name = raw_name.decode()
        path = repo / name
        raw = os.readlink(path).encode() if mode == '120000' else path.read_bytes()
        rows.append((name, mode, blob, hashlib.sha256(raw).hexdigest()))
    return rows


def parse_counts(output):
    python = [int(value) for value in re.findall(r'^Ran (\d+) tests? in ', output, re.M)]
    rust = []
    pattern = (r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; '
               r'(\d+) ignored; (\d+) measured; (\d+) filtered out;')
    for match in re.finditer(pattern, output, re.M):
        rust.append(dict(zip(('outcome', 'passed', 'failed', 'ignored', 'measured', 'filtered_out'),
                             [match[1], *map(int, match.groups()[1:])])))
    return {'python_ran_tests': python, 'rust_summaries': rust}


class PrerequisiteFailure(Exception):
    pass


class SourceFailure(Exception):
    pass


class Driver:
    def __init__(self, args):
        self.args, self.repo, self.out = args, args.repo.resolve(), args.out.resolve()
        self.rows, self.skipped, self.tool_files = [], [], {}
        self.before, self.after, self.abort = None, None, None
        self.env_path = args.env_file.resolve()
        self.env_raw = self.env_path.read_bytes()
        self.env_digest = hashlib.sha256(self.env_raw).hexdigest()
        configured = strict_json(self.env_raw)
        if type(configured) is not dict or any(type(k) is not str or type(v) is not str
                                               for k, v in configured.items()):
            raise ValueError('ENV_FILE_MUST_BE_STRING_MAP')
        for key in ('PATH', 'RUSTC', 'RUSTDOC', 'CARGO_HOME', 'CARGO_TARGET_DIR',
                    'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256', 'TRNM_RESEARCH_PYTHON'):
            if not configured.get(key):
                raise ValueError('MISSING_ENV:' + key)
        if configured.get('CARGO_BUILD_JOBS') != '1':
            raise ValueError('BUILD_JOBS_MUST_REMAIN_ONE')
        self.env = dict(configured, LC_ALL='C', LANG='C', PYTHONUNBUFFERED='1',
                        PYTHONDONTWRITEBYTECODE='1', CARGO_NET_OFFLINE='true')
        # Preserve the declared HOME unchanged; do not inherit unrelated shell credentials.
        os.environ.clear()
        os.environ.update(self.env)
        self.python = self.env['TRNM_RESEARCH_PYTHON']
        self.cargo = shutil.which('cargo', path=self.env['PATH'])
        self.bash = shutil.which('bash', path=self.env['PATH'])
        if not self.cargo or not self.bash:
            raise ValueError('MISSING_CARGO_OR_BASH')
        self.out.mkdir(parents=True, exist_ok=False)
        (self.out / 'commands').mkdir()
        (self.out / 'sources').mkdir()
        self.native = self.out / 'native'
        self.cargo_configs = self.cargo_config_snapshot()
        target = Path(self.env['CARGO_TARGET_DIR']).absolute()
        self.target_cache = {
            'path': str(target), 'exists_at_driver_start': target.exists(),
            'reuse_existing_target_cache': target.exists(),
            'clean_rebuild_requested': False,
            'cache_contents_are_not_a_reproducible_build_attestation': True,
            'current_test_elf_must_come_from_current_successful_cargo_json': True}
        write_json(self.out / 'external-cargo-inputs.json', {
            'configuration_files': self.cargo_configs, 'target_cache': self.target_cache,
            'config_bytes_are_hashed_not_printed': True,
            'all_toolchain_and_loaded_library_dependencies_inventoried': False,
            'toolchain_dependencies_calibrated': False, **CLAIMS})
        write_json(self.out / 'declaration.json', {
            'schema': 'trnm-competing-gates-validation-driver-v1', 'created_utc': utc(),
            'argv': sys.argv, 'repo': str(self.repo), 'expected_head': args.head,
            'environment_file': str(self.env_path), 'environment_file_sha256': self.env_digest,
            'effective_environment': self.env, 'driver': identity(__file__),
            'source_helper': 'verbatim source(repo, expected) from run_remote_validation.py',
            'command_timeout_seconds_maximum': 1800, 'timeout_termination_grace_seconds': 5,
            'network_dependency_downloads_permitted': False,
            'command_clock_scope': 'outer child lifetime includes spawn, interpreter imports/startup, '
                                   'nested commands, final child report serialization/fsync and exit',
            'cpu_scope': 'RUSAGE_CHILDREN deltas; observations, not exclusive machine calibration',
            'whole_node_failure_suppresses_independent_bridge': False,
            'untracked_and_ignored_repository_files_permitted': False,
            'untracked_guard_command': ['git', 'ls-files', '--others', '-z'],
            'untracked_guard_exclusion_options': [],
            'external_cargo_configurations': self.cargo_configs,
            'target_cache': self.target_cache,
            'all_toolchain_and_loaded_library_dependencies_inventoried': False,
            'toolchain_dependencies_calibrated': False, **CLAIMS})

    def cargo_config_snapshot(self):
        # Bind both Cargo spellings, including absence. Configuration contents
        # may contain secrets: retain only paths, metadata, and digests.
        cargo_home = Path(self.env['CARGO_HOME']).absolute()
        rows = []
        for name in ('config', 'config.toml'):
            path = cargo_home / name
            row = {'path': str(path), 'exists': os.path.lexists(path)}
            if row['exists']:
                status = path.lstat()
                if not (stat.S_ISREG(status.st_mode) or stat.S_ISLNK(status.st_mode)):
                    raise ValueError('CARGO_CONFIG_NOT_REGULAR_OR_SYMLINK:' + str(path))
                row['file_type'] = 'symlink' if stat.S_ISLNK(status.st_mode) else 'regular'
                if stat.S_ISLNK(status.st_mode):
                    row['symlink_target'] = os.readlink(path)
                row['identity'] = identity(path)
            rows.append(row)
        return rows

    def untracked_paths(self):
        # Deliberately no --exclude-standard or other exclusion: ignored extra
        # source/config/build.rs files must be rejected as well. Never read them.
        raw = subprocess.check_output(['git', 'ls-files', '--others', '-z'], cwd=self.repo)
        return [name.decode('utf-8', errors='surrogateescape') for name in raw.split(b'\0') if name]

    def guard(self, name):
        extra_paths, current_configs = None, None
        try:
            extra_paths = self.untracked_paths()
            if extra_paths:
                raise ValueError('UNTRACKED_OR_IGNORED_REPOSITORY_FILES')
            if hashlib.sha256(self.env_path.read_bytes()).hexdigest() != self.env_digest:
                raise ValueError('ENVIRONMENT_FILE_CHANGED')
            current_configs = self.cargo_config_snapshot()
            if current_configs != self.cargo_configs:
                raise ValueError('EXTERNAL_CARGO_CONFIGURATION_CHANGED')
            observed = source(self.repo, self.args.head)
            if self.before is not None and observed != self.before:
                raise ValueError('SOURCE_IDENTITY_CHANGED')
            for key, previous in self.tool_files.items():
                if identity(previous['path']) != previous:
                    raise ValueError('TOOL_CHANGED:' + key)
            # Recheck extras after the full tracked-file scan as well.
            extra_paths = self.untracked_paths()
            if extra_paths:
                raise ValueError('UNTRACKED_OR_IGNORED_REPOSITORY_FILES')
            write_json(self.out / 'sources' / (name + '.json'),
                       {'status': 'VERIFIED', 'checked_utc': utc(), **observed,
                        'untracked_or_ignored_paths': extra_paths,
                        'external_cargo_configurations': current_configs})
            return observed
        except Exception as error:
            write_json(self.out / 'sources' / (name + '.json'),
                       {'status': 'FAILED', 'checked_utc': utc(), 'error': repr(error),
                        'untracked_or_ignored_paths': extra_paths,
                        'external_cargo_configurations': current_configs})
            raise SourceFailure(str(error)) from error

    def run(self, name, command, *, timeout=1800, required=True, expected_python=None,
            expected_names=None, rust_nonzero=False, extra_env=None):
        if not 1 <= timeout <= 1800:
            raise ValueError('TIMEOUT_OUT_OF_RANGE')
        index = len(self.rows)
        stem = f'{index:02d}-{name}'
        log = self.out / 'commands' / (stem + '.log')
        record_path = self.out / 'commands' / (stem + '.json')
        command = [str(value) for value in command]
        start = time.monotonic()
        row = {'index': index, 'name': name, 'argv': command, 'cwd': str(self.repo),
               'started_utc': utc(), 'timeout_seconds': timeout, 'required': required,
               'environment_file_sha256': self.env_digest, 'environment_overrides': extra_env or {},
               'state': 'STARTED', 'log': str(log.relative_to(self.out)),
               'exit_code': None, 'timed_out': False, 'executed': False, **CLAIMS}
        self.rows.append(row)
        write_json(record_path, row)
        write_json(self.out / 'commands.json', self.rows)
        fatal, process = None, None
        with log.open('xb') as stream:
            try:
                row['source_before'] = self.guard(stem + '-before')
                env = dict(self.env, **(extra_env or {}))
                before_cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
                child_start = time.monotonic()
                process = subprocess.Popen(command, cwd=self.repo, env=env, stdout=stream,
                                           stderr=subprocess.STDOUT, start_new_session=True)
                row['executed'], row['pid'] = True, process.pid
                try:
                    row['exit_code'] = process.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    row['timed_out'] = True
                    try:
                        os.killpg(process.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        pass
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    row['exit_code'] = process.wait()
                row['child_elapsed_wall_seconds'] = time.monotonic() - child_start
                after_cpu = resource.getrusage(resource.RUSAGE_CHILDREN)
                row['child_user_cpu_seconds'] = after_cpu.ru_utime - before_cpu.ru_utime
                row['child_system_cpu_seconds'] = after_cpu.ru_stime - before_cpu.ru_stime
                row['cumulative_children_peak_rss_kib'] = after_cpu.ru_maxrss
                row['peak_rss_is_command_exclusive'] = False
            except BaseException as error:
                if process is not None and process.poll() is None:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    row['exit_code'] = process.wait()
                row['exception'] = repr(error)
                stream.write((traceback.format_exc() + '\n').encode())
                if isinstance(error, (SourceFailure, KeyboardInterrupt, SystemExit)):
                    fatal = error
            finally:
                stream.flush()
                os.fsync(stream.fileno())
                try:
                    row['source_after'] = self.guard(stem + '-after')
                except SourceFailure as error:
                    row['source_after_error'] = repr(error)
                    fatal = error
        raw = log.read_bytes()
        output = raw.decode('utf-8', errors='replace')
        row.update(state='FINISHED', ended_utc=utc(), elapsed_wall_seconds=time.monotonic() - start,
                   log_sha256=hashlib.sha256(raw).hexdigest(), log_bytes=len(raw), **parse_counts(output))
        checks = []
        if expected_python is not None:
            values = row['python_ran_tests']
            checks.append({'kind': 'python-test-count', 'expected': expected_python, 'actual': values,
                           'pass': values == [expected_python] if type(expected_python) is int
                                   else len(values) == 1 and values[0] > 0})
        if expected_names is not None:
            names = re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\.', output, re.M)
            summaries = row['rust_summaries']
            checks.append({'kind': 'exact-rust-test-inventory', 'expected': sorted(expected_names),
                           'actual': sorted(names), 'pass': sorted(names) == sorted(expected_names)
                           and len(summaries) == 1 and summaries[0]['outcome'] == 'ok'
                           and summaries[0]['passed'] == len(expected_names)
                           and summaries[0]['failed'] == summaries[0]['ignored'] == summaries[0]['measured'] == 0})
        if rust_nonzero:
            summaries = row['rust_summaries']
            checks.append({'kind': 'nonzero-node-suite', 'pass': len(summaries) == 1
                           and summaries[0]['passed'] + summaries[0]['failed'] > 0})
        row['checks'] = checks
        row['pass'] = (row['exit_code'] == 0 and not row['timed_out'] and 'exception' not in row
                       and fatal is None and all(check['pass'] for check in checks))
        write_json(record_path, row)
        write_json(self.out / 'commands.json', self.rows)
        print(json.dumps({key: row[key] for key in ('index', 'name', 'exit_code', 'timed_out',
                                                    'pass', 'elapsed_wall_seconds', 'log_sha256')}, sort_keys=True), flush=True)
        if fatal is not None:
            raise fatal
        return row

    def need(self, row):
        if not row['pass']:
            raise PrerequisiteFailure('FAILED_PREREQUISITE:' + row['name'])
        return row

    def tools(self):
        names = {'python': self.python, 'driver_python': sys.executable, 'cargo': self.cargo,
                 'rustc': self.env['RUSTC'], 'rustdoc': self.env['RUSTDOC'],
                 'openssl': self.env['TRNM_PQ_OPENSSL'], 'bash': self.bash}
        for name in ('git', 'rustfmt', 'cargo-clippy', 'clippy-driver', 'ld', 'cc'):
            value = shutil.which(name, path=self.env['PATH'])
            if value:
                names[name] = value
        self.tool_files = {name: identity(path) for name, path in names.items()}
        write_json(self.out / 'tool-identities.json', self.tool_files)
        if self.tool_files['openssl']['sha256'] != self.env['TRNM_PQ_OPENSSL_SHA256']:
            raise PrerequisiteFailure('OPENSSL_EXECUTABLE_HASH_MISMATCH')
        for name, command in (
            ('python-version', [self.python, '--version']),
            ('cargo-version', [self.cargo, '-Vv']),
            ('rustc-version', [self.env['RUSTC'], '-Vv']),
            ('rustfmt-version', ['rustfmt', '--version']),
            ('clippy-version', [self.cargo, 'clippy', '--version']),
            ('openssl-version', [self.env['TRNM_PQ_OPENSSL'], 'version', '-a']),
            ('host-uname', ['uname', '-a'])):
            self.need(self.run(name, command, timeout=60))

    def extract_elf(self, row):
        records = []
        for line in (self.out / row['log']).read_text().splitlines():
            try:
                value = strict_json(line)
            except ValueError:
                continue
            if type(value) is dict:
                records.append(value)
        matches = [value for value in records if value.get('reason') == 'compiler-artifact'
                   and value.get('target', {}).get('name') == 'trnm_pon_node'
                   and value.get('target', {}).get('kind') == ['lib']
                   and value.get('profile', {}).get('test') is True and value.get('executable')]
        finished = [value for value in records if value.get('reason') == 'build-finished']
        if len(matches) != 1 or len(finished) != 1 or finished[0].get('success') is not True:
            raise PrerequisiteFailure('CURRENT_CARGO_TEST_ELF_NOT_UNIQUE_OR_BUILD_INCOMPLETE')
        elf = Path(matches[0]['executable'])
        if not elf.is_absolute() or not elf.resolve().is_relative_to(Path(self.env['CARGO_TARGET_DIR']).resolve()):
            raise PrerequisiteFailure('CARGO_TEST_ELF_OUTSIDE_DECLARED_TARGET')
        measured = identity(elf)
        if not measured['elf_magic']:
            raise PrerequisiteFailure('CURRENT_TEST_EXECUTABLE_NOT_ELF')
        self.tool_files['native_test_elf'] = measured
        write_json(self.out / 'native-test-elf.json', {
            'source': self.before, 'cargo_log_sha256': row['log_sha256'],
            'compiler_artifact': matches[0], 'identity': measured,
            'selection': 'unique current successful Cargo compiler-artifact, no filename glob', **CLAIMS})
        write_json(self.out / 'tool-identities.json', self.tool_files)
        return str(elf)

    def named(self, key, elf):
        name = NATIVE_TESTS[key]
        row = self.run('native-' + key, [elf, name, '--exact', '--ignored', '--nocapture', '--test-threads=1'],
                       expected_names=[name], extra_env={'TRNM_W1_NATIVE_BRIDGE_EVIDENCE_DIR': str(self.native)})
        checker = self.run('native-' + key + '-named-check', [self.python, '-B',
            'scripts/ci/check_required_native_test.py', self.out / row['log'], '--test', name], timeout=60)
        return row['pass'] and checker['pass']

    def skip(self, name, reason):
        self.skipped.append({'name': name, 'reason': reason})
        write_json(self.out / 'skipped.json', self.skipped)

    def execute(self):
        self.before = self.guard('initial')
        inventory = full_inventory(self.repo)
        inventory_sha = hashlib.sha256(json.dumps(inventory, separators=(',', ':')).encode()).hexdigest()
        if inventory_sha != self.before['inventory_sha256']:
            raise SourceFailure('FULL_INVENTORY_SNAPSHOT_CHANGED')
        write_json(self.out / 'source-inventory.json', {'source': self.before,
                   'columns': ['path', 'git_mode', 'git_blob_sha1', 'sha256'], 'entries': inventory})
        self.need(self.run('preflight', [self.bash, 'scripts/project-preflight.sh'], timeout=300))
        self.tools()
        for name, directory, pattern in (
            ('quantum-python', FORMAL, 'test_quantum*.py'),
            ('w1-python', FORMAL, 'test_w1*.py'),
            ('reversible-python', FORMAL, 'test_reversible_components.py'),
            ('fast-daa-python', FORMAL, 'test_fast_daa_reference_component.py'),
            ('parallel-ohie-python', FORMAL, 'test_parallel_variable_ohie.py'),
            ('experiment-w1-python', FORMAL + '/experiments', 'test_w1*.py')):
            self.run(name, [self.python, '-B', '-m', 'unittest', 'discover', '-s', directory,
                            '-p', pattern, '-v'], expected_python='positive')
        for name, script, count in (
            ('economics-unit', 'test_pon_w1_observed_economics_v1.py', 18),
            ('source-integrity-unit', 'test_ci_source_integrity.py', 43),
            ('ci-contract-unit', 'test_ci_contract.py', 108),
            ('pq-integration-unit', 'test_pq_research_integration.py', 38)):
            self.run(name, [self.python, '-B', 'scripts/ci/' + script], expected_python=count)
        for name, argv in (
            ('pq-integration-check', ['scripts/ci/check_pq_research_integration.py']),
            ('repository-links', ['scripts/ci/check_repository.py']),
            ('distributed-source-inventory', ['scripts/refresh_distributed_source_inventory.py', '--check'])):
            self.run(name, [self.python, '-B', *argv])
        self.run('tracked-diff-whitespace', ['git', 'diff', '--check'], timeout=120)
        self.run('economics-full-ledger', [self.python, '-B', 'scripts/pon_w1_observed_economics_v1.py',
                 '--archive-index', 'evidence/pon-six-workpackages-20261106/strategy/raw-archive-index.json',
                 '--output', self.out / 'observed-economics.json'])
        self.run('fuzz-offline-full-metadata', [self.cargo, 'metadata', '--offline', '--locked',
                 '--manifest-path', 'tests/fuzz/Cargo.toml', '--all-features', '--format-version', '1'],
                 timeout=300, required=False)
        self.need(self.run('main-offline-full-metadata', [self.cargo, 'metadata', '--offline', '--locked',
                 '--manifest-path', MANIFEST, '--all-features', '--format-version', '1']))
        self.need(self.run('rustfmt-all-check', [self.cargo, 'fmt', '--manifest-path', MANIFEST,
                                                '--all', '--', '--check']))
        self.need(self.run('strict-workspace-clippy', [self.cargo, 'clippy', '--offline', '--locked',
                 '--manifest-path', MANIFEST, '--workspace', '--all-targets', '--all-features',
                 '--jobs', '1', '--', '-D', 'warnings']))
        build = self.need(self.run('node-lib-test-build-json', [self.cargo, 'test', '--offline', '--locked',
                 '--manifest-path', MANIFEST, '-p', 'trnm-pon-node', '--lib', '--all-features',
                 '--jobs', '1', '--no-run', '--message-format=json']))
        elf = self.extract_elf(build)
        for label, prefix, names in (
            ('release-owner-root-six', 'release_owner::root_separation_tests::', ROOT_TESTS),
            ('release-owner-sealed-seven', 'release_owner::sealed_tests::', SEALED_TESTS)):
            self.run(label, [elf, prefix, '--nocapture', '--test-threads=1'],
                     expected_names=[prefix + name for name in names])
        self.run('whole-node-lib', [elf, '--test-threads=1'], rust_nonzero=True)
        if self.named('base-export', elf):
            observed = self.run('base-python-observe', [self.python, '-B',
                FORMAL + '/experiments/w1_native_bridge.py', '--observe', self.native])
            if observed['pass']:
                self.named('base-replay', elf)
                self.run('base-python-verify', [self.python, '-B',
                    FORMAL + '/experiments/w1_native_bridge.py', '--verify', self.native])
            else:
                self.skip('base-native-replay', 'base Python observation failed; artifacts retained')
            if self.named('competition-export', elf):
                observed = self.run('competition-python-observe', [self.python, '-B',
                    FORMAL + '/experiments/w1_native_competition.py', '--observe', self.native])
                if observed['pass']:
                    self.named('competition-replay', elf)
                    self.run('competition-python-verify', [self.python, '-B',
                        FORMAL + '/experiments/w1_native_competition.py', '--verify', self.native])
                else:
                    self.skip('competition-native-replay', 'competition Python observation failed')
            else:
                self.skip('competition-observation-and-replay', 'competition native export failed')
            for name, script in (
                ('original-eighteen-frontier', 'w1_machine_frontier.py'),
                ('new-fifty-four-service-frontier', 'w1_service_architecture_frontier.py')):
                self.run(name, [self.python, '-B', FORMAL + '/experiments/' + script,
                    '--native-directory', self.native, '--output', self.out / (name + '.json')])
            cache = self.out / 'preprocessing-cache-observation.json'
            cache_command = [self.python, '-B', FORMAL + '/experiments/w1_preprocessing_cache_campaign.py',
                             '--native-directory', self.native]
            observed = self.run('preprocessing-cache-observe', [*cache_command, '--observe', cache])
            if observed['pass']:
                self.run('preprocessing-cache-verify', [*cache_command, '--verify', cache])
            else:
                self.skip('preprocessing-cache-verify', 'observation failed; report/journal retained')
        else:
            self.skip('all-fixture-dependent-observations', 'original native export or named check failed')
        self.after = self.guard('final')

    def finish(self):
        try:
            self.after = self.guard('final-retained')
        except BaseException as error:
            self.abort = self.abort or repr(error)
        failures = [row['name'] for row in self.rows if row['required'] and not row.get('pass', False)]
        incomplete = [row['name'] for row in self.rows if not row['required'] and not row.get('pass', False)]
        status = 'FAIL' if failures or self.abort else 'INCOMPLETE' if incomplete or self.skipped else 'PASS'
        result = {'schema': 'trnm-competing-gates-validation-result-v1', 'status': status,
                  'expected_head': self.args.head, 'source_before': self.before, 'source_after': self.after,
                  'commands': len(self.rows), 'failed_required_commands': failures,
                  'incomplete_optional_commands': incomplete, 'skipped': self.skipped, 'abort': self.abort,
                  'tests': [{'name': row['name'], 'exit_code': row['exit_code'], 'pass': row.get('pass', False),
                             **{key: row.get(key, []) for key in ('python_ran_tests', 'rust_summaries')}}
                            for row in self.rows],
                  'driver_elapsed_wall_seconds_through_summary': time.monotonic() - DRIVER_STARTED,
                  'timing_is_exclusive_or_calibrated': False,
                  'untracked_and_ignored_repository_files_permitted': False,
                  'external_cargo_configurations': self.cargo_configs,
                  'target_cache': self.target_cache,
                  'all_toolchain_and_loaded_library_dependencies_inventoried': False,
                  'toolchain_dependencies_calibrated': False, **CLAIMS}
        write_json(self.out / 'result.json', result)
        artifacts = []
        for path in sorted(self.out.rglob('*')):
            if path.is_file() and path.name not in ('artifact-inventory.json', 'driver-completion.json'):
                artifacts.append({'path': str(path.relative_to(self.out)), 'size_bytes': path.stat().st_size,
                                  'sha256': digest(path)})
        write_json(self.out / 'artifact-inventory.json', {'artifacts': artifacts})
        write_json(self.out / 'driver-completion.json', {
            'status': status, 'completed_utc': utc(), 'result_sha256': digest(self.out / 'result.json'),
            'artifact_inventory_sha256': digest(self.out / 'artifact-inventory.json'),
            'elapsed_wall_seconds_through_report_and_artifact_inventory': time.monotonic() - DRIVER_STARTED,
            'scope_excludes_only_this_final_completion_record_and_interpreter_exit': True, **CLAIMS})
        print(json.dumps({'status': status, 'commands': len(self.rows), 'failed_required_commands': failures,
                          'incomplete_optional_commands': incomplete, 'abort': self.abort, **CLAIMS}), flush=True)
        return 0 if status == 'PASS' else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--head', required=True)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--env-file', required=True, type=Path)
    parser.add_argument('--quantum-hardware-executed', choices=('false',), default='false')
    parser.add_argument('--exclusive-calibration', choices=('false',), default='false')
    args = parser.parse_args()
    if re.fullmatch(r'[0-9a-f]{40}', args.head) is None:
        parser.error('--head must be an exact lowercase SHA-1 commit')
    driver = Driver(args)
    try:
        driver.execute()
    except BaseException as error:
        driver.abort = repr(error)
        write_json(driver.out / 'driver-exception.json',
                   {'error': repr(error), 'traceback': traceback.format_exc(), 'observed_utc': utc(), **CLAIMS})
        driver.skip('remaining-stages', 'driver stopped on prerequisite, source, or fatal failure')
    finally:
        return driver.finish()


if __name__ == '__main__':
    raise SystemExit(main())
