import os,signal,time
from pathlib import Path
signal.signal(signal.SIGTERM,signal.SIG_IGN)
if os.fork(): os._exit(0)
os.setsid()
if os.fork(): os._exit(0)
os.setsid()
Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/collector-controls-desktop-ec265-01/test_actual_cancel_reaps_detached_ignoring_descendant/running').write_text(str(os.getpid()))
time.sleep(3)
