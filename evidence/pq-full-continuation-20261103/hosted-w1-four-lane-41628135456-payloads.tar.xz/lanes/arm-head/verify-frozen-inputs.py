import hashlib, os
from pathlib import Path
expected = {
    'W1_HEADER': '7b96038f228a1eedccf7b29ffc54802aba691be7259e33937846c6bf6126d78f',
    'W1_RECEIPT': 'ca4d3c9f5159b7001abae7491604cadbbbfa97c0f93d90d5943e48936813ca2b',
    'W1_LIFT': 'd2b06a1feca2d15e8dc5741b43f481a82c32d7d3dab01e413d357012467093d3',
}
observed = {key: hashlib.sha256(Path(os.environ[key]).read_bytes()).hexdigest() for key in expected}
print(observed)
assert observed == expected
