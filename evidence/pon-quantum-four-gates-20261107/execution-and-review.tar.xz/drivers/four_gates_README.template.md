# PoN quantum four-gate continuation — research / HOLD

This continuation connects a declared complete machine lifecycle, bounded
implementation comparisons, exact finite fork probabilities, and source-bound
native Node execution. It does not qualify quantum mining, prove a cheapest
legal attacker implementation, establish mixed-network settlement security, or
authorize production activation.

The implementation was frozen **before** the final observations:

- Source commit: `ec3a939706592c6ec9dd677b70589a7e8860cdfd`.
- Source tree: `94a2dd1ebda9ce4eb262b6887b739e623616f08a`.
- Parent: `5d7ca0f5e260b65f5a2b8ab09dfd038718129346`, the published #773 head.
- Local validation checked all **10,997 tracked files** against committed raw
  bytes, modes and Git blob identities before and after every group. Its common
  inventory SHA256 is `5afb7fbd7443dd5dc6d77659be93b937e25794d93fc1775866b3dda21622d5b4`.
- The current GitHub connector returned HTTP 403, `Sorry. Your account was
  suspended`. No replacement credential or account bypass was attempted. These
  new commits were not published through that connector. The delivery Git bundle
  preserves the exact local commit identities; it requires the parent above.

## Status of the four gates

| Gate | New evidence | Remaining boundary |
| --- | --- | --- |
| Complete machine cost and error accounting | Whole-schedule distance and allocation, initialization, input transfer, control, bounded factory retries/discards, readout, full candidate checking, proofs, propagation and a conditional fault union | The parameters are illustrative. There is no calibrated machine, compiled physical layout, measured control service, energy/capital price or physical execution guarantee. |
| Cheapest legal implementation and amortization | An explicit 18-cell constructed grid and strict reparse of complete historical CPU ledgers with setup and failed attempts retained | The grid is a finite list of constructions. It does not enumerate all algorithms/caches, prove a lower bound, or equate real total quantum/classical resources. |
| Native valid adversarial execution | Complete native packets, real DAA/timestamp/work checks and a source-bound bridge from completed modeled events to Node | Native CPU execution and declared quantum action clocks are separate observations. No QPU or live public ingress is exercised; the public competitor is a fixed conditional history. |
| Mixed quantum/classical consensus argument | Exact finite Bellman certificates, an independent checker, fixed-policy forward probabilities and conditional additive fault bounds | The action class and horizon are bounded. Continuous honest mining, arbitrary timestamp policies, arbitrary quantum algorithms and full settlement security are outside this theorem. |

## Actual native observations

@@NATIVE_RESULT@@

The fixed declaration is one processor, a three-bit nonce window (eight complete
nonce values in each retained context), at most two private attempts/extensions,
a four-second **modeled** horizon, quantum iteration choices `q=(0,1)`, and
sample seed `9`. The root/child timestamps and the original native consensus
rules are fixed in source. The physical-qubit cap is `10^16`; this is an
illustrative model cap, not available or measured hardware. The independent
classical implementation uses uniform `q=0` draws without allocating a QPU.

The prefix through height 15 and the public height-16 block are explicit
preexisting conditional resources. Their generation receipts are retained. The
complete offline census is observer advice, not uncharged online quantum work.
There is no additional honest mining after the declared public block. A native
fork replacement in this setting is a conditional execution witness, not a
reproduction of a live-network quantum attack.

## Machine and finite-model results

@@MACHINE_RESULT@@

[The finite-model note](../../formal/pon-nakamoto-v1/FINITE_QUANTUM_CONSENSUS.md)
contains the theorem, assumptions and proof. For every policy in the declared
finite action class, an independently checked Bellman supersolution `V` bounds
the ideal replacement probability by `V(initial)`. The state retains every
winner's complete block identity and successor; different nonces do not collapse
into a fictitious common parent.

Under the explicit lifecycle contract, fault events have conditional probability
bounds given the complete prior history, and the real timed execution equals the
ideal process outside their union. If that union is at most `epsilon`, every
fixed policy with ideal probability `p` has an actual probability in
`[max(0,p-epsilon), min(1,p+epsilon)]`. The same uniform coupling bounds the finite
class optimum. Fault independence is not assumed. The contract itself is not a
hardware measurement. An incomplete state graph returns no bound.

The optimizer may use census-derived advice to choose among the declared actions.
It is not a cheapest arbitrary miner and does not allow arbitrary
function-dependent initialization or direct selection of a known winning nonce.
The fixed-q sampler does not inspect the census to select its action. A separately
labelled positive path is an observer-selected existential witness, not the
fixed-seed sample. Source binding is not an external timestamped precommitment.

The large-q probability module uses outward dyadic intervals; the finite fork
module independently uses exact `Fraction` amplitudes for its small-q action
class. Both retain legal winners outside a restricted phase-marked set. They
handle empty/full sets and exact overshoot without turning a small positive
probability into zero.

## Historical CPU ledger reparse

The new reader streamed and verified all **16 archive parts, 197 members and
954,889,727 payload bytes**. Including tar headers/padding, it consumed
955,023,360 bytes. All 48 original process stdout receipts bind bijectively to
the 36 cost shards and 12 separate control shards. The cost grid contains 144
strategy cohorts and 6,144 unique search streams, rather than independent
cryptographic security trials.

The 36 cost shards contain 1,152 setup calls, 28,032 searches, **464,320 nonce
attempts**, **436,288 misses**, 28,032 target hits, 246,176 serialized proof
materializations and 12,108,905,088 cumulative serialized proof bytes. The native
verifier observations include 56,064 legal `Accepted` outcomes and 56,064
`Product` rejection controls. These are verifier outcomes, not block admissions.
The separate control shards retain search exhaustion cases.

The fixed CPU budgets are 1 ms, 10 ms, 100 ms and 1 s. Each counterfactual
strategy pays common material setup once, preserves sample order, pays all
complete searches and the consumed part of an incomplete search, and receives
no unfinished proof/attempt credit. Unknown within-cohort overhead is charged
up front. No new samples are extrapolated when the retained schedule ends.

Across the retained same-input cohorts, the observed slowest/fastest producer-CPU
ratio ranges from approximately 1.0324 to 1.9427; setup's share ranges from
approximately 0.0061% to 37.31%. These are descriptive historical comparisons,
not confidence bounds or an executable per-sample best-strategy oracle. Separate
verification, propagation, evidence writing, energy and capital costs are not
included in those CPU budgets.

Crucially, the raw experiment belongs to historical base
`b173c1f52d927522af67df30dd08ecfb2e3a1bb0` with its declared dirty inputs and binary
identity. Nine of its 95 declared source inputs differ from this implementation.
The report explicitly records those mismatches and
`fresh_measurement_on_current_source=false`. Recomputing a report does not make
its historical timings fresh measurements.

## Exact-source validation

| Observation | Result |
| --- | --- |
| Quantum, W1, reversible and DAA related Python tests | 412 passed |
| Observed-economics reader tests | 18 passed |
| Negative CI source-integrity tests | 43 passed |
| CI contract tests | 108 passed |
| PQ research integration controls | 38 passed |
| Distinct Python test total | **619 passed** |
| Existing source pins | 688 checked |
| Local Markdown links at implementation freeze | 3,597 checked |
| Main locked/offline all-feature dependency graph | 181 packages, 26 workspace members |
| Fuzz locked/offline all-feature dependency graph | 149 packages; metadata only, no fuzz execution |
| Rust formatting | Passed |
| Strict workspace Clippy, all targets/all features, warnings denied | Passed |
| Native Node regression and explicit bridge tests | @@NATIVE_TESTS@@ |

The native bridge tests are intentionally ignored in the default test inventory
and are explicitly executed by exact test name. Their output is checked for the
required executed test. Compilation or an ignored test is not a passing native
experiment. CI registration and negative controls enforce those commands.

## Retained unsuccessful observations

The development archive retains the initial incomplete CI block registration,
its failing test output and the corrected registration; the local native
code-generation attempt terminated by `SIGKILL` before any tests (the cause is
not established); and the disk-full patch-write interruption with truncation
and successful atomic restoration hashes. The final frozen file bytes passed
syntax/type checks and the full validation above.

The remote record retains the missing-origin preflight failure and subsequent
canonical-origin configuration in the new isolated repository. It also retains
two deliberately cancelled native build attempts: the first lacked the normal
real toolchain loader directory, while the second reused the unqualified cached
SQLite build. A fresh target with the actual normal loader environment let the
unchanged build guard generate its real SQLite layout witness. No qualification
token, source, lock, budget or test gate was changed to hide these observations.

The GitHub 403 is a publication failure, not a native execution or consensus
result. Later evidence-only commits do not imply another execution of the test
suites at a different source SHA.

## Literature and the scope of the argument

[Bailey and Sattath](https://arxiv.org/html/2403.08023v2) describe the mismatch
between cumulative classical work increasing by `c` and ideal Grover search
cost scaling by approximately `sqrt(c)`. Their mechanism requires a much richer
variable-difficulty trajectory and extremely fast fault-tolerant quantum
hardware. The bounded native bridge does not reproduce that long-horizon attack.
Changing signatures or blindly replacing chainwork by square-root weights does
not follow from this experiment.

[Cojocaru, Garay and Song, Section 4.1, equation 10](https://arxiv.org/pdf/2311.03723)
use `nu_D = max_x Pr[f(x)=1]` for the distributional hybrid-query bound. It is not
an arbitrary fixed census's average `M/N`. For a point distribution on a known
function containing a winner, this parameter is one. Function-dependent advice
and preprocessing must be addressed before invoking a black-box hardness result.

[Machine resource estimation](https://arxiv.org/html/2211.07629v1) spans algorithm,
architecture, error correction and device assumptions. The lifecycle fields
implemented here are an auditable contract for such inputs; their presence does
not calibrate those inputs or prove physical feasibility.

## Files and reproduction

@@FILES@@

The Git bundle requires the published parent commit named above. Import it into
a repository that contains that parent and create a separate worktree at the
**implementation** SHA. Evidence is attached in a later commit; use its extracted
record directory as input to that implementation. The reader intentionally
refuses a different source HEAD or source bytes.

With the declared Rust 1.95.0 / OpenSSL 3.5.9 environment and normal Cargo loader
paths prepared, the native sequence is:

```bash
bash scripts/project-preflight.sh
export TRNM_W1_NATIVE_BRIDGE_EVIDENCE_DIR=/absolute/fresh/observation-directory
cargo test --locked --offline --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib --all-features quantum_native_bridge_tests::export_source_bound_native_dag_fixture -- --exact --ignored --nocapture --test-threads=1
python3 formal/pon-nakamoto-v1/experiments/w1_native_bridge.py --observe "$TRNM_W1_NATIVE_BRIDGE_EVIDENCE_DIR"
cargo test --locked --offline --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib --all-features quantum_native_bridge_tests::replay_source_bound_native_search_samples -- --exact --ignored --nocapture --test-threads=1
python3 formal/pon-nakamoto-v1/experiments/w1_machine_frontier.py --native-directory "$TRNM_W1_NATIVE_BRIDGE_EVIDENCE_DIR" --output /absolute/fresh/machine-frontier.json
```

The directory and output file must be fresh. Complete command receipts, actual
source/binary identities, packet bytes and partial/failed attempts are retained
in the archives. The four general security gates remain **HOLD**.
