from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import shutil,subprocess,time

task=Path('/workspace/scratch/7e8b6061b88c')
root=task/'chain-stark-work'
head='eeeaafbc742d4b384e8e8b0d53c65b7e8b3bf182'
base=task/'validation'/head/'rust'
out=task/'validation'/head/'clippy-retry-02'
out.mkdir(exist_ok=False)
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==head and git('status','--porcelain')==''
source={'head':head,'tree':git('rev-parse','HEAD^{tree}'),'clean_before':True}
old=json.loads((base/'strict-clippy.json').read_text())
env=dict(os.environ)
recorded=json.loads((base/'environment.json').read_text())
for key,value in recorded.items():
    if value is None:env.pop(key,None)
    else:env[key]=value
previous=json.loads((base/'selected-build-inputs-after.json').read_text())['files']
def inputs():
    return [{'path':r['path'],'bytes':Path(r['path']).stat().st_size,
             'sha256':hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()} for r in previous]
before=inputs()
assert before==previous
preflight=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=root,text=True,capture_output=True)
(out/'preflight.stdout').write_text(preflight.stdout)
(out/'preflight.stderr').write_text(preflight.stderr)
assert preflight.returncode==0
free=shutil.disk_usage(task).free
assert free>512*1024*1024
started=datetime.now(timezone.utc).isoformat()
t=time.monotonic()
with (out/'strict-clippy.stdout').open('xb') as stdout,(out/'strict-clippy.stderr').open('xb') as stderr:
    p=subprocess.run(old['argv'],cwd=root,env=env,stdout=stdout,stderr=stderr)
source.update(clean_after=git('status','--porcelain')=='',head_after=git('rev-parse','HEAD'),tree_after=git('rev-parse','HEAD^{tree}'))
after=inputs()
row={'schema':'TRNM-EXACT-CLIPPY-RETRY1','name':'strict-clippy','argv':old['argv'],
     'source':source,'started_utc':started,'elapsed_seconds':time.monotonic()-t,
     'exit_code':p.returncode,'preflight_exit_code':preflight.returncode,
     'reason':'Prior retry was terminated by SIGKILL. The task abandoned test fixture was removed; source and compiler flags are unchanged. Cause of SIGKILL is not established. Original records retained.',
     'free_disk_before_bytes':free,'free_disk_after_bytes':shutil.disk_usage(task).free,
     'selected_build_inputs_equal_before_after':before==after,
     'selected_build_inputs_equal_to_previous_attempt':before==previous,
     'selected_build_inputs_scope':'Selected tooling/provider files only, not complete compiler closure.',
     'selected_build_inputs_before':before,'selected_build_inputs_after':after,
     'partial_same_source_target_reused':True,'environment':recorded,
     'unittest_method_counts':[],'unittest_outcomes':[],
     'native_proof_execution_claimed':False,'production_qualified':False,
     'logs':{}}
for kind in ['stdout','stderr']:
    data=(out/('strict-clippy.'+kind)).read_bytes()
    row['logs'][kind]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(out/'summary.json').write_text(json.dumps(row,indent=2)+'\n')
shutil.copyfile(__file__,out/'runner.py')
print(json.dumps({k:row[k] for k in ['exit_code','elapsed_seconds','source','selected_build_inputs_equal_before_after']}),flush=True)
