#!/usr/bin/env python3
"""List actual ignored registrations; never execute or qualify those tests."""
import argparse
import importlib.util
import json
from pathlib import Path
import re

RUNNER_SHA = '2944189be70e53103debc4a9ae0a95866cde53ddbf3271a314b716614458074d'
PREFIX = 'store::native_authenticated::'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--head', required=True)
    args = parser.parse_args()
    args.repo = args.repo.resolve(strict=True)
    args.out = args.out.resolve(strict=True)
    runner = Path(__file__).with_name('run_native_qualification.py')
    spec = importlib.util.spec_from_file_location('pinned_native_runner', runner)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.require(helper.file_facts(runner)['sha256'] == RUNNER_SHA, 'original 114 runner required')
    env = helper.environment(args.repo)
    artifacts = helper.selected_artifacts(args, env)
    node = artifacts['selected']['node']
    summary = helper.strict_json((args.out / 'semantic-controls/execution-summary.json').read_text())
    helper.require(summary['status'] == 'passed' and summary['passed_controls'] == 114,
                   'completed original 114 controls required before this registration observation')
    helper.require(summary['artifacts_after']['node'] == node['binary'],
                   'same actual Node ELF as completed controls required')
    registry = summary['registries']['node']['log']
    helper.check_fingerprint(registry)
    names = re.findall(r'^([^\s]+): test$', Path(registry['path']).read_text(), re.M)
    registered = [name for name in names if name.startswith(PREFIX)]
    helper.require(len(registered) == len(set(registered)) == 118,
                   '118 actual registrations required, independent of test execution')
    command = [node['binary']['path'], PREFIX, '--list', '--ignored', '--format', 'terse']
    result = helper.run_logged(command, Path(node['cwd']), args.out,
                               'authenticated-ignored-list', env)
    helper.require(result['exit_code'] == 0, 'actual ignored-registration list failed')
    ignored = re.findall(r'^([^\s]+): test$',
                         (args.out / 'authenticated-ignored-list.log').read_text(), re.M)
    helper.require(len(ignored) == len(set(ignored)) and set(ignored) <= set(registered),
                   'ignored registrations must be a unique subset of this exact prefix')
    helper.check_fingerprint(node['binary'])
    helper.check_fingerprint(registry)
    report = dict(schema='trnm-authenticated-native-registration-observation-v1',
        head=args.head, prefix=PREFIX, source=artifacts['source'], binary=node['binary'],
        registered_count=len(registered), ignored_count=len(ignored), ignored=ignored,
        default_workspace_test_profile_excludes_ignored=True,
        all_118_executed=False, release_with_include_ignored_executed=False,
        tests_executed_by_this_command=False, command=result,
        scope='actual original workspace test-profile ELF registration only; no release or ignored-test execution qualification')
    helper.write_json(args.out / 'authenticated-prefix-registration.json', report, exclusive=True)
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
