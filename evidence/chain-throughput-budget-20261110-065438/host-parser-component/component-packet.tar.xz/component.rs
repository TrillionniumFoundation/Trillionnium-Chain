// Source-extracted scalar parser. No Node, Host observer, I/O or Cargo.
type Result<T> = std::result::Result<T, &'static str>;
const MAX_MEMORY_BYTES: u64 = 2 * 1024 * 1024 * 1024;
const MAX_TASKS: u64 = 256;
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct Limits {
    cpu_quota_us: u64,
    cpu_period_us: u64,
    memory_bytes: u64,
    tasks: u64,
}

fn numeric(text: &str, limit: u64) -> Option<u64> {
    let value = text.trim().parse::<u64>().ok()?;
    (value > 0 && value <= limit).then_some(value)
}

// The maximum CPU bandwidth is <= 250,000,000 ns per second per
// entire host parent. Explicit finite ceilings only; never accept "max".
fn validate_limits(
    cpu: &str,
    burst: &str,
    memory: &str,
    swap: &str,
    pids: &str,
) -> Result<Limits> {
    let mut parts = cpu.split_ascii_whitespace();
    let (quota, period) = match (parts.next(), parts.next(), parts.next()) {
        (Some(quota), Some(period), None) => (quota, period),
        _ => return Err("PUBLIC_HOST_KERNEL_LIMITS".into()),
    };
    let quota = numeric(quota, 250_000).ok_or("PUBLIC_HOST_KERNEL_LIMITS")?;
    let period = numeric(period, 1_000_000).ok_or("PUBLIC_HOST_KERNEL_LIMITS")?;
    let memory = numeric(memory, MAX_MEMORY_BYTES).ok_or("PUBLIC_HOST_KERNEL_LIMITS")?;
    let tasks = numeric(pids, MAX_TASKS).ok_or("PUBLIC_HOST_KERNEL_LIMITS")?;
    if quota.checked_mul(4).is_none_or(|value| value > period)
        || burst.trim() != "0"
        || swap.trim() != "0"
    {
        return Err("PUBLIC_HOST_KERNEL_LIMITS".into());
    }
    Ok(Limits {
        cpu_quota_us: quota,
        cpu_period_us: period,
        memory_bytes: memory,
        tasks,
    })
}

use std::hint::black_box;
use std::os::raw::{c_int, c_long};
use std::time::Instant;

#[repr(C)]
struct Timespec { tv_sec: c_long, tv_nsec: c_long }
unsafe extern "C" { fn clock_gettime(clock: c_int, value: *mut Timespec) -> c_int; }
fn thread_cpu_ns() -> u64 {
    let mut value = Timespec { tv_sec: 0, tv_nsec: 0 };
    // Linux CLOCK_THREAD_CPUTIME_ID, not elapsed wall time or an assumed CPU rate.
    assert_eq!(unsafe { clock_gettime(3, &mut value) }, 0);
    assert!(value.tv_sec >= 0 && (0..1_000_000_000).contains(&value.tv_nsec));
    (value.tv_sec as u64).checked_mul(1_000_000_000).unwrap()
        .checked_add(value.tv_nsec as u64).unwrap()
}

#[inline(never)]
fn reference(input: [&str; 5], expected: Limits) -> Result<Limits> {
    let actual = validate_limits(input[0], input[1], input[2], input[3], input[4])?;
    if actual == expected { Ok(actual) } else { Err("PUBLIC_HOST_KERNEL_LIMITS_CHANGED") }
}

#[inline(never)]
fn comparison_then_original(input: [&str; 5], expected_text: [&str; 5], expected: Limits) -> Result<Limits> {
    if input == expected_text { Ok(expected) } else { reference(input, expected) }
}

fn main() {
    let canonical = ["25000 100000\n", "0\n", "2147483648\n", "0\n", "256\n"];
    let expected = validate_limits(canonical[0], canonical[1], canonical[2], canonical[3], canonical[4]).unwrap();
    // Expectations derive only from the already validated immutable Limits.
    // This experiment never reads sysfs/procfs, retains a live verdict, or caches a file.
    let text = [format!("{} {}\n", expected.cpu_quota_us, expected.cpu_period_us),
                "0\n".to_owned(), format!("{}\n", expected.memory_bytes),
                "0\n".to_owned(), format!("{}\n", expected.tasks)];
    let expected_text = text.each_ref().map(String::as_str);
    assert_eq!(canonical, expected_text);
    let cases = [
        canonical,
        ["25000\t100000", " 0 ", "+2147483648", "\n0\n", "+256"],
        ["025000 0100000\n", "0", "02147483648", "0", "0256"],
        ["25000 100000\n", "0", "\u{2003}2147483648\u{2003}", "0", "256"],
        ["10000 100000\n", "0", "2147483648", "0", "256"],
        ["25001 100000\n", "0", "2147483648", "0", "256"],
        ["25000 100000 extra", "0", "2147483648", "0", "256"],
        ["25000 100000", "1", "2147483648", "0", "256"],
        ["25000 100000", "0", "max", "0", "256"],
        ["25000 100000", "0", "2147483648", "1", "256"],
        ["25000 100000", "0", "2147483648", "0", "257"],
        ["25000 100000", "0", "18446744073709551616", "0", "256"],
        ["25000\u{2003}100000", "0", "2147483648", "0", "256"],
        ["0 100000", "0", "2147483648", "0", "256"],
        ["25000 100000", "0", "2147483648", "0", "-1"],
    ];
    for (index, input) in cases.iter().enumerate() {
        assert_eq!(comparison_then_original(black_box(*input), black_box(expected_text), black_box(expected)),
                   reference(black_box(*input), black_box(expected)), "component input {index}");
    }
    eprintln!("PARSER_COMPONENT_INPUT_EQUIVALENCE {} cases; no fresh read/EOF/UTF8/Host authority claim", cases.len());
    const ITERATIONS: u64 = 250_000;
    println!("round,slot,arm,iterations,thread_cpu_ns,wall_ns");
    for round in 0..16 {
        for (slot, candidate) in [false, true, true, false].into_iter().enumerate() {
            // Each sample has the same already verified canonical input. Every
            // timed result must equal the original parser's exact four values.
            // These common checks deliberately remain part of both measurements.
            let cpu_start = thread_cpu_ns();
            let wall_start = Instant::now();
            for _ in 0..ITERATIONS {
                let input = black_box(canonical);
                let expected = black_box(expected);
                let value = if candidate {
                    comparison_then_original(input, black_box(expected_text), expected)
                } else {
                    reference(input, expected)
                };
                assert_eq!(black_box(value), Ok(expected));
            }
            let wall_ns = wall_start.elapsed().as_nanos();
            let cpu_ns = thread_cpu_ns().checked_sub(cpu_start).unwrap();
            println!("{round},{slot},{},{ITERATIONS},{cpu_ns},{wall_ns}",
                     if candidate { "exact_compare_then_original" } else { "original_parse_and_compare" });
        }
    }
}
