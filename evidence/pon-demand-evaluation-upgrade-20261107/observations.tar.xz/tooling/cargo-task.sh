#!/usr/bin/env bash
set -euo pipefail
export CARGO_HOME=/workspace/scratch/525798dad3c2/cargo-home
export RUSTUP_HOME=/workspace/scratch/270e2a9ce94f/toolchain/rustup
export PATH="/workspace/scratch/270e2a9ce94f/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH"
export CARGO_TARGET_DIR=/workspace/scratch/525798dad3c2/cargo-target
export CARGO_BUILD_JOBS=2
export OPENSSL_DIR=/workspace/scratch/270e2a9ce94f/pq-provider/trnm-pq-provider-3.5.9.7u1wjN7Q/install
export OPENSSL_STATIC=1
export OPENSSL_NO_VENDOR=1
export OPENSSL_CONF=/dev/null
export OPENSSL_MODULES="$OPENSSL_DIR/lib/ossl-modules"
export LD_LIBRARY_PATH=/workspace/scratch/270e2a9ce94f/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/lib
exec cargo "$@"
