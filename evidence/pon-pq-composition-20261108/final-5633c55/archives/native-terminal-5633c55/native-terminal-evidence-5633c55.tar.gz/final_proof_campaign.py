#!/usr/bin/env python3
"""Run one pinned, clean-source native MMCS campaign; never grant PQ qualification.

Requires the desktop Rust 1.95.0 toolchain and pre-existing offline dependencies.
This script, output directory and fresh Cargo target must all be outside the repo.
No installation, retry, Git mutation or production activation is performed.
"""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

BIN = Path("/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin")
CARGO_HOME = "/home/qian-qi/.cargo"
EXAMPLE = "tagged_sha3_mmcs_binding"
ORIGINAL_RUNNER_SHA256 = "410d5c2fccf0b131fec24cbfc5f68bceaaafbd693d5c55e0e6444e37641bf1e5"
HISTORICAL_COMMAND = ["git", "diff", "--exit-code", "cc836dfc13ef0006eb0878abd8cb5eca9a76bec0",
                      "HEAD", "--", "trillionnium", "config", "qualification"]
TESTS = set("""
sponge_padding_counts_rate_boundaries_and_the_length_suffix
sponge_cached_prefix_continuation_is_not_full_message_telemetry
sponge_query_log_counts_repeated_hash_calls_before_deduplication
sponge_artificial_roles_are_separated_from_actual_sha3_calls
sponge_collision_recheck_retains_both_output_message_lengths
sponge_accounting_overflow_fails_without_partial_updates
sponge_accounting_rejects_truncated_wrong_suffix_and_uncovered_roles
sha_profile_pruned_mixed_heights_restore_to_native_paths
carry_profile_pruned_mixed_heights_restore_to_native_paths
extension_flattening_preserves_exact_rows_and_shared_paths
real_hash_rejects_duplicate_injection_shape_index_and_sibling_controls
deliberately_colliding_leaves_yield_full_framed_collision
arbitrary_siblings_and_injected_row_conflict_yield_branch_collision
shared_coordinate_is_the_reduced_matrix_row_not_the_global_index
conflict_search_never_erases_an_earlier_duplicate_value
a_single_row_conflict_needs_no_authentication_sibling
disjoint_valid_queries_are_not_reported_as_a_binding_violation
an_extra_cap_entry_is_outside_the_fixed_profile
""".split())


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def identity(path: Path) -> dict:
    path = path.resolve(strict=True)
    before = path.stat()
    digest = sha(path)
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            == (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
            "file changed while hashing: " + str(path))
    return {"path": str(path), "bytes": after.st_size, "sha256": digest}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", required=True, type=Path)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--target-dir", required=True, type=Path)
    parser.add_argument("--timeout-seconds", type=int, default=1800)
    args = parser.parse_args()
    root = args.repository.resolve(strict=True)
    out, target = args.output.resolve(), args.target_dir.resolve()
    runner = Path(__file__).resolve(strict=True)
    require(root.is_dir(), "repository must be a directory")
    require(re.fullmatch(r"[0-9a-f]{40}", args.expected_head) is not None, "expected HEAD must be a full SHA")
    require(args.timeout_seconds > 0, "timeout must be positive")
    require(not any(path.is_relative_to(root) for path in (out, target, runner)), "all campaign artifacts must be outside the repo")
    require(not out.is_relative_to(target) and not target.is_relative_to(out), "output and target must be disjoint")
    require(not out.exists() and not target.exists(), "output and target must both be fresh")
    out.mkdir(parents=True, exist_ok=False)
    target.mkdir(parents=True, exist_ok=False)
    research = root / "formal/pon-nakamoto-v1/w1_public_stark_research"
    scope = root / "formal/pon-nakamoto-v1/p3_shared_primitive_qualification"
    manifest = research / "Cargo.toml"
    original_runner = scope / "run_qualification_checks.py"

    # Explicit compilers/plugins and offline operation; do not inherit wrappers
    # or alternate flags that would silently change the stated build profile.
    removed = {key for key in os.environ if key.startswith("GIT_")}
    removed.update({"RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTC_WRAPPER",
                    "RUSTC_WORKSPACE_WRAPPER", "CARGO_BUILD_TARGET", "CARGO_BUILD_RUSTFLAGS",
                    "CARGO_BUILD_RUSTC", "CARGO_BUILD_RUSTC_WRAPPER", "CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER"})
    env = {key: value for key, value in os.environ.items() if key not in removed}
    overrides = {
        "PATH": str(BIN) + os.pathsep + os.environ.get("PATH", os.defpath),
        "CARGO_HOME": CARGO_HOME, "CARGO_TARGET_DIR": str(target), "CARGO": str(BIN / "cargo"),
        "RUSTC": str(BIN / "rustc"), "RUSTDOC": str(BIN / "rustdoc"), "RUSTFMT": str(BIN / "rustfmt"),
        "RUSTUP_TOOLCHAIN": "1.95.0-x86_64-unknown-linux-gnu", "CARGO_INCREMENTAL": "0",
        "CARGO_NET_OFFLINE": "true", "CARGO_NET_RETRY": "0", "CARGO_TERM_COLOR": "never",
        "PYTHONDONTWRITEBYTECODE": "1", "GIT_TERMINAL_PROMPT": "0", "GIT_NO_REPLACE_OBJECTS": "1",
        "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull, "GIT_ATTR_NOSYSTEM": "1",
    }
    env.update(overrides)
    records, errors, binaries = [], [], {}
    source_before = source_after = None
    dependency_before = dependency_after = None
    historical = None
    native_steps_passed = False
    toolchain_before = {}
    toolchain_unchanged = False
    reader_result = None
    runner_before = identity(runner)
    runner_after = None

    def save(name: str, value: object) -> None:
        with (out / name).open("x") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")

    def run(name: str, argv: list, permitted: tuple[int, ...] = (0,),
            expected_program_identity: dict | None = None) -> dict:
        require(not any(row["name"] == name for row in records), "no command retries are allowed")
        argv = list(map(str, argv))
        record = {"name": name, "argv": argv, "cwd": str(root), "attempt": 1,
                  "started_utc": datetime.now(timezone.utc).isoformat(), "exit_code": None}
        save(name + ".started.json", record)
        print(json.dumps({"start": name, "argv": argv}), flush=True)
        program = None
        process = None
        started = time.perf_counter()
        try:
            resolved = shutil.which(argv[0], path=env["PATH"])
            require(resolved is not None, "executable unavailable: " + argv[0])
            program = Path(resolved).resolve(strict=True)
            record["program_before"] = identity(program)
            if expected_program_identity is None:
                expected_program_identity = next((value for value in toolchain_before.values()
                                                  if value["path"] == str(program)), None)
            if expected_program_identity is not None:
                record["expected_program_identity"] = expected_program_identity
                require(record["program_before"] == expected_program_identity,
                        "executable differs from the pinned/emitted artifact: " + str(program))
            with (out / (name + ".stdout.txt")).open("xb") as stdout, (out / (name + ".stderr.txt")).open("xb") as stderr:
                process = subprocess.Popen(argv, cwd=root, env=env, stdout=stdout, stderr=stderr,
                                           start_new_session=True)
                try:
                    record["exit_code"] = process.wait(timeout=args.timeout_seconds)
                except subprocess.TimeoutExpired:
                    record["timed_out"] = True
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    record["exit_code"] = process.wait()
        except (OSError, RuntimeError) as error:
            record["launch_or_identity_error"] = str(error)
        finally:
            if process is not None and process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                record["exit_code"] = process.wait()
            record["wall_seconds"] = time.perf_counter() - started
            record["finished_utc"] = datetime.now(timezone.utc).isoformat()
            for stream in ("stdout", "stderr"):
                path = out / (name + "." + stream + ".txt")
                if not path.exists():
                    path.touch(exist_ok=False)
                record[stream + "_sha256"] = sha(path)
                record[stream + "_bytes"] = path.stat().st_size
            if program is not None:
                try:
                    record["program_after"] = identity(program)
                except (OSError, RuntimeError) as error:
                    record["program_after_error"] = str(error)
            records.append(record)
            save(name + ".status.json", record)
            print(json.dumps(record), flush=True)
        require(record.get("program_before") == record.get("program_after") and "program_before" in record,
                name + ": executable identity changed or is unavailable")
        require("launch_or_identity_error" not in record and not record.get("timed_out")
                and record["exit_code"] in permitted,
                name + ": command failed, see its original logs")
        return record

    def source(label: str) -> dict:
        run(label, [sys.executable, "-B", root / "scripts/ci/verify_ci_source.py", "--kind", "head",
                    "--expected-head", args.expected_head, "--output", out / (label + ".json")])
        value = json.loads((out / (label + ".json")).read_text())
        require(value["tested_commit"] == args.expected_head and value["tracked_worktree_verified"] is True,
                "source identity check did not bind the expected clean HEAD")
        return value

    def built_elf(label: str, test: bool) -> Path:
        paths = set()
        for line in (out / (label + ".stdout.txt")).read_text().splitlines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(item, dict):
                continue
            if (item.get("reason") == "compiler-artifact" and item.get("executable")
                    and item.get("target", {}).get("name") == EXAMPLE
                    and item.get("target", {}).get("kind") == ["example"]
                    and item.get("profile", {}).get("test") is test):
                paths.add(Path(item["executable"]))
        require(len(paths) == 1, label + ": expected exactly one emitted example ELF")
        path = paths.pop()
        require(not path.is_symlink() and path.resolve(strict=True).is_relative_to(target), "ELF outside the fresh target")
        with path.open("rb") as handle:
            header = handle.read(20)
        require(header[:6] == b"\x7fELF\x02\x01" and int.from_bytes(header[18:20], "little") == 62,
                "expected a native x86-64 little-endian ELF")
        binaries[label] = identity(path)
        return path

    cargo = [BIN / "cargo"]
    flags = ["--manifest-path", manifest, "--release", "--all-features", "--locked", "--offline",
             "--target-dir", target, "--example", EXAMPLE]
    dependency_command = [sys.executable, "-B", scope / "pruned_mmcs/verify_upstream_source.py",
                          "--repository", root, "--cargo-metadata", out / "metadata.stdout.txt"]
    save("campaign-inputs.json", {"expected_head": args.expected_head, "repository": str(root),
         "output": str(out), "target": str(target), "runner": runner_before,
         "environment_overrides": overrides, "removed_inherited_keys": sorted(set(os.environ) & removed),
         "timeout_seconds_per_command": args.timeout_seconds, "retry_policy": "none",
         "qualification": "HOLD_NO_GO", "qualified": False, "security_bits": None})
    try:
        source_before = source("source-before")
        toolchain_before = {name: identity(BIN / name) for name in
                            ("cargo", "rustc", "rustdoc", "rustfmt", "cargo-fmt", "cargo-clippy", "clippy-driver")}
        save("toolchain-before.json", toolchain_before)
        run("rustc-version", [BIN / "rustc", "--version", "--verbose"])
        run("cargo-version", [BIN / "cargo", "--version"])
        require(re.search(r"^release: 1\.95\.0$", (out / "rustc-version.stdout.txt").read_text(), re.MULTILINE) is not None,
                "rustc is not exactly 1.95.0")
        require((out / "cargo-version.stdout.txt").read_text().startswith("cargo 1.95.0 "), "cargo version drift")

        # Extract the unchanged original assertion without executing the rest of
        # that historical runner. Exit 1 remains a refusal, never a passed gate.
        require(sha(original_runner) == ORIGINAL_RUNNER_SHA256, "original historical runner changed")
        calls = [node for node in ast.walk(ast.parse(original_runner.read_text()))
                 if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "run"
                 and len(node.args) >= 2 and isinstance(node.args[0], ast.Constant)
                 and node.args[0].value == "unchanged-runtime-scope"]
        require(len(calls) == 1 and ast.literal_eval(calls[0].args[1]) == HISTORICAL_COMMAND,
                "historical unchanged-runtime-scope command is not the pinned original")
        observation = run("historical-unchanged-runtime-scope", HISTORICAL_COMMAND, permitted=(0, 1))
        historical = {"original_runner_sha256": ORIGINAL_RUNNER_SHA256, "argv": HISTORICAL_COMMAND,
                      "exit_code": observation["exit_code"], "historical_gate_passed": observation["exit_code"] == 0,
                      "disposition": "REFUSED_INTEGRATED_RUNTIME_DIFF" if observation["exit_code"] == 1 else "NO_RUNTIME_DIFF",
                      "full_historical_runner_executed": False, "historical_runner_qualified": False}
        save("historical-scope-observation.json", historical)

        run("metadata", cargo + ["metadata", "--manifest-path", manifest, "--locked", "--offline", "--format-version", "1"])
        graph = json.loads((out / "metadata.stdout.txt").read_text())
        p3 = [p for p in graph["packages"] if p["name"].startswith("p3-")]
        require(p3 and all(p["version"] == "0.8.0" for p in p3), "locked P3 graph drift")
        require([p["version"] for p in graph["packages"] if p["name"] == "sha3"] == ["0.10.9"], "SHA3 graph drift")
        run("dependency-source-before", dependency_command)
        dependency_before = sha(out / "dependency-source-before.stdout.txt")
        run("format", cargo + ["fmt", "--manifest-path", manifest, "--", "--check"])
        run("strict-example-clippy", cargo + ["clippy", *flags, "--", "-D", "warnings"])
        run("build-example-tests", cargo + ["test", *flags, "--no-run", "--message-format=json"])
        test_elf = built_elf("build-example-tests", True)
        run("release-example-tests", [test_elf], expected_program_identity=binaries["build-example-tests"])
        log = (out / "release-example-tests.stdout.txt").read_text()
        require(re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;", log)
                == [("18", "0", "0", "0", "0")], "expected exactly 18 complete, unfiltered example tests")
        names = re.findall(r"^test tests::([a-zA-Z0-9_]+) \.\.\. ok$", log, re.MULTILINE)
        require(len(names) == 18 and set(names) == TESTS, "required example test names did not all pass")
        run("build-example", cargo + ["build", *flags, "--message-format=json"])
        example_elf = built_elf("build-example", False)
        run("native-mmcs-report", [example_elf], expected_program_identity=binaries["build-example"])
        run("independent-accounting-reader", [sys.executable, "-B", scope / "pruned_mmcs/check_sponge_accounting.py",
                                               out / "native-mmcs-report.stdout.txt"])
        reader_result = json.loads((out / "independent-accounting-reader.stdout.txt").read_text())
        require(reader_result["status"] == "ACCOUNTING_CONSISTENT"
                and reader_result["source_report_sha256"] == sha(out / "native-mmcs-report.stdout.txt")
                and reader_result["qualified"] is False and reader_result["security_bits"] is None
                and reader_result["native_permutation_telemetry"] is False
                and reader_result["adversary_lifetime_query_budget"] is None, "reader scope or report binding drift")
        native_steps_passed = True
    except (Exception, KeyboardInterrupt) as error:
        errors.append(type(error).__name__ + ": " + str(error))
    finally:
        if dependency_before is not None:
            try:
                run("dependency-source-after", dependency_command)
                dependency_after = sha(out / "dependency-source-after.stdout.txt")
                require(dependency_before == dependency_after, "dependency sources changed during the campaign")
            except (Exception, KeyboardInterrupt) as error:
                errors.append("dependency-source-after: " + str(error))
        try:
            source_after = source("source-after")
            require(source_before == source_after and source_before is not None, "source pre/post mismatch")
        except (Exception, KeyboardInterrupt) as error:
            errors.append("source-after: " + str(error))
        try:
            after = {name: identity(BIN / name) for name in toolchain_before}
            save("toolchain-after.json", after)
            toolchain_unchanged = bool(toolchain_before) and after == toolchain_before
            require(toolchain_unchanged, "toolchain identity changed or was not established")
        except (Exception, KeyboardInterrupt) as error:
            errors.append("toolchain-after: " + str(error))
        try:
            runner_after = identity(runner)
            require(runner_after == runner_before, "campaign script changed while running")
        except (Exception, KeyboardInterrupt) as error:
            errors.append("runner-after: " + str(error))
        passed = native_steps_passed and not errors
        status = "NATIVE_CHECKS_PASSED" if passed else "NATIVE_CHECKS_INCOMPLETE_OR_FAILED"
        if passed and historical and historical["exit_code"] == 1:
            status += "_WITH_HISTORICAL_SCOPE_REFUSAL"
        summary = {"schema": "p3.mmcs.final-native-campaign.v1", "status": status,
                   "expected_head": args.expected_head, "source_before": source_before, "source_after": source_after,
                   "source_unchanged": source_before is not None and source_before == source_after,
                   "dependency_source_before_sha256": dependency_before, "dependency_source_after_sha256": dependency_after,
                   "toolchain_unchanged": toolchain_unchanged, "commands": records, "emitted_elfs": binaries,
                   "accounting_reader": reader_result, "historical_scope_observation": historical,
                   "scoped_native_checks_passed": passed, "required_example_tests": 18, "errors": errors,
                   "runner_before": runner_before, "runner_after": runner_after,
                   "runner_unchanged": runner_before == runner_after,
                   "qualification": "HOLD_NO_GO", "qualified": False,
                   "security_bits": None, "adversary_lifetime_query_budget": None, "native_permutation_telemetry": False,
                   "full_historical_runner_qualified": False, "complete_repository_ci": False, "production_activation": False}
        save("final-proof-campaign.json", summary)
        print(json.dumps({"status": status, "summary": str(out / "final-proof-campaign.json"),
                          "summary_sha256": sha(out / "final-proof-campaign.json"), "errors": errors}), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
