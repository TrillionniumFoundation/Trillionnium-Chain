#!/usr/bin/env python3
"""Package terminal 7586 ROG suite and sampler evidence without execution.

Uses only the Python standard library. Run once, after the composed suite has
written its final summary and the independent release/default sampler is also
terminal. Native failures remain failures. Sampler SQLite UNKNOWN/UNQUALIFIED
observations never grant boundary qualification. Earlier 2859 build history
belongs to its separate immutable archive, not to this new source.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import traceback


HEAD = '7586d3e209b38246402e34cf73a27aa9b907bc9c'
TREE = 'fc0e51b1235470b972de41f2d677f6d5948f4868'
SUITE = 'validation/rog-composed-7586-native-suite'
SAMPLER = 'validation/rog-composed-7586-sampler'
BUILD_PREFIX = 'rog-composed-7586-component-build'
BUILD_SUFFIXES = ('-source-before.json', '.jsonl', '.stderr', '.json', '-source-after.json')
HELPERS = {
    'run_exact_selected_controls.py': 'a8f8656fe25038fb67939b360b42631b6856dab9bd302365cd53591be2108e55',
    'run_pq_required_controls_v2.py': '94bccecdc9a33ac140633ab677af3b17f600c1483377c5b94083bcbed7bc3680',
    'run_composed_cell_controls.py': '4ed5320de1668893212dde62970a8ed53adb25717237f7cc74b42a3e623f905e',
    'run_composed_native_validation.py': 'f210388a49e176df7beb3935a68c421bab7d345d9cf78422bb55e4c3a027a6fc',
    'run_sampler_release_validation.py': '12989500334c0bc1a8ff41211113328eee87c5bb9a4cfef88983510c1c9069be',
}
PROVIDER = 'validation/rog-provider/pq-provider/provider.json'
GATES = ('controls-80', 'pq-full-and-required', 'cell-controls', 'strict-workspace-clippy')
FORBIDDEN_DIRS = {'.git', '.ssh', '__pycache__', 'target', 'targets', 'cache', 'caches', '.cache', 'keys', 'private-keys', 'provider-temp', 'node_modules'}
FORBIDDEN_SUFFIXES = ('.db', '.db-wal', '.db-shm', '.sqlite', '.sqlite3', '.sqlite-wal', '.sqlite-shm', '.sqlite3-wal', '.sqlite3-shm', '.key', '.pem', '.der', '.p8', '.p12', '.pfx', '.jks', '.keystore', '.pub', '.bin', '.o', '.a', '.so', '.dylib', '.rlib', '.rmeta', '.exe', '.pyc', '.pyo')
FORBIDDEN_NAMES = {'id_rsa', 'id_ed25519', 'id_dsa', 'id_ecdsa', 'credentials', 'credential', '.env'}
PRIVATE_KEY = re.compile(br'-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----')


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encoded(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def fingerprint(info: os.stat_result) -> tuple:
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def safe_member(name: str) -> None:
    path = PurePosixPath(name)
    require(bool(name) and not path.is_absolute() and '..' not in path.parts
            and '.' not in path.parts and path.as_posix() == name
            and not any(c in name for c in ('\\', '\n', '\r', '\0')),
            'unsafe relative archive member: ' + repr(name))


def inside_regular(root: Path, member: str) -> Path:
    safe_member(member)
    path = root
    parts = PurePosixPath(member).parts
    for part in parts[:-1]:
        path /= part
        info = path.lstat()
        require(stat.S_ISDIR(info.st_mode), 'non-directory or symlink ancestor: ' + str(path))
    path /= parts[-1]
    require(stat.S_ISREG(path.lstat().st_mode), 'non-regular or symlink input: ' + str(path))
    return path


def read_regular(path: Path) -> tuple[bytes, tuple]:
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'non-regular or symlink input: ' + str(path))
    expected = fingerprint(before)
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        require(fingerprint(os.fstat(stream.fileno())) == expected, 'input changed before open: ' + str(path))
        data = stream.read()
        require(fingerprint(os.fstat(stream.fileno())) == expected, 'input changed during read: ' + str(path))
    require(fingerprint(path.lstat()) == expected, 'input replaced during read: ' + str(path))
    return data, expected


def path_exclusion(member: str) -> str | None:
    parts = PurePosixPath(member).parts
    if any(p.lower() in FORBIDDEN_DIRS or p.lower().startswith('target-') for p in parts):
        return 'excluded build/cache/key directory'
    name = parts[-1].lower()
    if name in FORBIDDEN_NAMES or name.endswith(FORBIDDEN_SUFFIXES):
        return 'excluded database, binary, cache, or key filename'
    return None


def content_exclusion(data: bytes) -> str | None:
    if data.startswith(b'\x7fELF'):
        return 'ELF magic'
    if data.startswith(b'SQLite format 3\0'):
        return 'SQLite database magic'
    if PRIVATE_KEY.search(data):
        return 'private-key PEM marker; content excluded without recording key bytes'
    return None


def timestamp(value: object, label: str) -> None:
    require(isinstance(value, str) and bool(value), 'missing terminal time: ' + label)
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(parsed.tzinfo is not None, 'terminal time lacks timezone: ' + label)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('/home/qian-qi/work/chain-throughput-20261106-1eed'))
    parser.add_argument('--expected-head', default=HEAD)
    parser.add_argument('--expected-tree', default=TREE)
    parser.add_argument('--output-prefix', type=Path, required=True)
    args = parser.parse_args()
    require(re.fullmatch(r'[0-9a-f]{40}', args.expected_head) is not None, 'expected head is not a full SHA')
    require(re.fullmatch(r'[0-9a-f]{40}', args.expected_tree) is not None, 'expected tree is not a full SHA')
    require((args.expected_head, args.expected_tree) == (HEAD, TREE), 'this frozen packager is only for the reviewed 7586 source')
    root = args.root.resolve(strict=True)
    prefix = args.output_prefix.absolute()
    require(prefix.parent.resolve(strict=True) == root / 'validation', 'output prefix must be directly in task validation directory')
    require(not prefix.name.startswith(BUILD_PREFIX), 'output collides with build prefix')
    require(prefix.name not in {Path(SUITE).name, Path(SAMPLER).name}, 'output collides with an evidence directory')
    paths = {key: Path(str(prefix) + suffix) for key, suffix in {
        'archive': '.tar.xz', 'manifest': '.manifest.json', 'checksums': '.SHA256SUMS',
        'index': '.index.json', 'receipt': '.package-receipt.json', 'failure': '.package-failure.json',
    }.items()}
    require(not any(p.exists() or p.is_symlink() for p in paths.values()), 'immutable output or failure record already exists')
    created = now()
    inputs: dict[str, dict] = {}
    excluded: list[dict] = []
    discovered_tree_names: dict[str, set[str]] = {}
    phase = 'input selection'

    def add(member: str, required: bool = True) -> bool:
        safe_member(member)
        if member in inputs:
            return True
        reason = path_exclusion(member)
        if reason is not None:
            require(not required, 'required evidence would be excluded: ' + member + ': ' + reason)
            excluded.append({'path': member, 'reason': reason})
            return False
        path = inside_regular(root, member)
        data, ident = read_regular(path)
        reason = content_exclusion(data)
        if reason is not None:
            require(not required, 'required evidence would be excluded: ' + member + ': ' + reason)
            excluded.append({'path': member, 'bytes': len(data), 'reason': reason})
            return False
        inputs[member] = {'data': data, 'fingerprint': ident, 'path': str(path)}
        return True

    def value(member: str) -> dict:
        require(member in inputs, 'required retained JSON missing: ' + member)
        result = json.loads(inputs[member]['data'])
        require(isinstance(result, dict), 'expected JSON object: ' + member)
        return result

    def ref(member: str) -> dict:
        require(member in inputs, 'required artifact is absent or excluded: ' + member)
        data = inputs[member]['data']
        return {'archive_member': member, 'bytes': len(data), 'sha256': digest(data)}

    def bound_source(record: object, label: str) -> dict:
        require(isinstance(record, dict), 'source checkpoint absent: ' + label)
        receipt = record.get('receipt')
        require(isinstance(receipt, dict), 'source receipt absent: ' + label)
        require(receipt.get('tested_commit') == args.expected_head
                and receipt.get('tested_tree') == args.expected_tree,
                'source identity differs: ' + label)
        return receipt

    def identity_matches(identity: object, member: str) -> None:
        require(isinstance(identity, dict), 'missing runtime file identity: ' + member)
        actual = ref(member)
        require(identity.get('sha256') == actual['sha256']
                and identity.get('size', identity.get('bytes')) == actual['bytes'],
                'runtime file identity differs: ' + member)

    def terminal_summary(member: str, schema: str) -> dict:
        result = value(member)
        require(result.get('schema') == schema, 'unexpected summary schema: ' + member)
        timestamp(result.get('finished_utc'), member)
        require(type(result.get('passed')) is bool and isinstance(result.get('errors'), list),
                'summary lacks terminal outcome fields: ' + member)
        before = bound_source(result.get('source_before'), member + ':before')
        after = bound_source(result.get('source_after'), member + ':after')
        require(before == after, 'source receipt changed in completed gate: ' + member)
        return result

    def terminal_capture(record: object, label: str) -> dict:
        require(isinstance(record, dict), 'capture execution record missing: ' + label)
        timestamp(record.get('finished_utc'), label)
        require(type(record.get('native_exit')) is int or bool(record.get('spawn_error')),
                'capture execution not terminal: ' + label)
        return record

    def discover_tree(member_root: str) -> None:
        tree_path = root / member_root
        require(stat.S_ISDIR(tree_path.lstat().st_mode), 'evidence directory missing or symlinked: ' + member_root)
        discovered = set()
        for current, dirs, names in os.walk(tree_path, followlinks=False):
            dirs.sort()
            for name in list(dirs):
                path = Path(current) / name
                member = path.relative_to(root).as_posix()
                safe_member(member)
                reason = path_exclusion(member)
                if reason is None and not stat.S_ISDIR(path.lstat().st_mode):
                    reason = 'non-directory or symlink tree entry'
                if reason:
                    excluded.append({'path': member, 'reason': reason, 'subtree_not_followed': True})
                    dirs.remove(name)
            for name in sorted(names):
                path = Path(current) / name
                member = path.relative_to(root).as_posix()
                safe_member(member)
                discovered.add(member)
                if not stat.S_ISREG(path.lstat().st_mode):
                    excluded.append({'path': member, 'reason': 'non-regular file or symlink; not followed'})
                    continue
                add(member, required=False)
        discovered_tree_names[member_root] = discovered

    try:
        # Reject live or incomplete summaries before writing any archive.
        add(SUITE + '/summary.json')
        top = terminal_summary(SUITE + '/summary.json', 'trnm-composed-native-validation-v1')
        require(top.get('expected_head') == args.expected_head, 'suite expected source differs')
        steps = top.get('steps')
        require(isinstance(steps, list) and all(isinstance(s, dict) for s in steps)
                and [s.get('label') for s in steps] == list(GATES),
                'not all four planned gates have terminal driver entries')
        add(SAMPLER + '/summary.json')
        sampler = terminal_summary(SAMPLER + '/summary.json', 'trnm-v4-sampler-release-validation-v1')
        require(sampler.get('expected_head') == args.expected_head, 'sampler expected source differs')
        source = bound_source(top.get('source_before'), 'suite source-before')
        require(bound_source(sampler.get('source_before'), 'sampler source-before') == source,
                'suite and sampler source receipts differ')
        for member_root in (SUITE, SAMPLER):
            discover_tree(member_root)

        phase = 'terminal gate and source binding'
        child_schemas = {
            'controls-80': 'trnm-exact-selected-native-controls-v1',
            'pq-full-and-required': 'trnm-pq-actual-elf-required-controls-v1',
            'cell-controls': 'trnm-composed-cell-controls-v1',
        }
        observed = []
        for step in steps:
            label = step['label']
            gate_member = SUITE + '/' + label + '.gate.json'
            require(value(gate_member) == step, 'terminal gate file differs from driver summary: ' + label)
            execution = terminal_capture(step.get('execution'), label + ':driver')
            code = execution.get('native_exit')
            row = {'label': label, 'driver_native_exit': code, 'passed_as_reported': step.get('passed'), 'gate': ref(gate_member)}
            if label in child_schemas:
                member = SUITE + '/' + label + '/summary.json'
                child = terminal_summary(member, child_schemas[label])
                identity_matches(step.get('summary_identity'), member)
                row.update(summary=ref(member), finished_utc=child['finished_utc'],
                           child_passed_as_reported=child['passed'], collector_errors_as_reported=child['errors'])
                if label == 'pq-full-and-required':
                    row['full_library_as_reported'] = (child.get('full_library') or {}).get('verdict')
                row['observed_as_reported'] = step.get('observed', {})
            else:
                member = SUITE + '/clippy/strict-workspace-clippy.json'
                clippy = value(member)
                require(clippy.get('status') in {'command_succeeded', 'command_failed', 'record_failed'}
                        and type(clippy.get('elapsed_ns')) is int,
                        'Clippy recorder is not terminal')
                identity_matches(step.get('receipt_identity'), member)
                log_member = SUITE + '/clippy/strict-workspace-clippy.log'
                identity_matches(step.get('log_identity'), log_member)
                row.update(receipt=ref(member), status_as_reported=clippy['status'],
                           native_exit_as_reported=clippy.get('exit_code'))
            observed.append(row)

        phase = 'terminal sampler evidence binding'
        exit_member = SAMPLER + '/sampler.exit'
        require(inputs.get(exit_member, {}).get('data') == (b'0\n' if sampler['passed'] else b'1\n'),
                'sampler terminal exit file missing or differs from its reported result')
        sampler_manifest_member = SAMPLER + '/receipt-sha256.json'
        require(sampler_manifest_member in inputs, 'sampler final file receipt is missing')
        sampler_manifest = json.loads(inputs[sampler_manifest_member]['data'])
        require(isinstance(sampler_manifest, list) and bool(sampler_manifest),
                'sampler final file receipt is not a nonempty list')
        sampler_manifest_names = set()
        for item in sampler_manifest:
            require(isinstance(item, dict) and isinstance(item.get('path'), str), 'malformed sampler file identity')
            path = Path(item['path'])
            require(path.is_absolute() and path.is_relative_to(root / SAMPLER), 'sampler file receipt escapes its evidence directory')
            member = path.relative_to(root).as_posix()
            safe_member(member)
            require(member not in sampler_manifest_names, 'duplicate sampler file identity: ' + member)
            identity_matches(item, member)
            sampler_manifest_names.add(member)
        sqlite = sampler.get('sqlite')
        require(isinstance(sqlite, dict) and sqlite.get('qualified_by_this_run') is False
                and sqlite.get('selected_unit_binding_verified') is False,
                'sampler unexpectedly claims SQLite selected-unit qualification')
        # Failed commands may never produce a harness or registry. Preserve
        # those null observations and the collector errors, without inventing
        # counts or treating a successful --list as a successful native test.
        sampler_captures = []
        for key, result_member in (
            ('recorder_execution', SAMPLER + '/recorder/v4-sampler-release.result.json'),
            ('registry', SAMPLER + '/registry.result.json'),
        ):
            capture = sampler.get(key)
            if key == 'registry' and capture is not None:
                require(isinstance(capture, dict), 'malformed sampler registry observation')
                capture = capture.get('execution')
            if capture is None:
                sampler_captures.append({'label': key, 'recorded': False})
                continue
            terminal_capture(capture, 'sampler:' + key)
            require(value(result_member) == capture, 'sampler capture result differs: ' + key)
            sampler_captures.append({'label': key, 'recorded': True, 'result': ref(result_member),
                'native_exit_as_reported': capture.get('native_exit'),
                'log_exit_as_reported': capture.get('log_exit'),
                'spawn_error_as_reported': capture.get('spawn_error'),
                'capture_errors_as_reported': capture.get('capture_errors')})
        sampler_native = sampler.get('native')
        sampler_native_refs = None
        if sampler_native is not None:
            require(isinstance(sampler_native, dict), 'malformed sampler native observation')
            member = SAMPLER + '/native/v4-sampler-release.json'
            native = value(member)
            require(native == sampler_native.get('receipt'), 'sampler native receipt differs from summary')
            require(native.get('status') in {'command_succeeded', 'command_failed', 'record_failed'}
                    and type(native.get('elapsed_ns')) is int, 'sampler native receipt not terminal')
            require(native.get('before') == native.get('after') == source,
                    'sampler native source receipts are incomplete or differ')
            identity_matches(sampler_native.get('receipt_identity'), member)
            log_member = SAMPLER + '/native/v4-sampler-release.log'
            identity_matches(sampler_native.get('log_identity'), log_member)
            log_ref = ref(log_member)
            require(native.get('log_file') == PurePosixPath(log_member).name
                    and native.get('log_sha256') == log_ref['sha256']
                    and native.get('log_bytes') == log_ref['bytes'], 'sampler original log binding differs')
            sampler_native_refs = {'receipt': ref(member), 'log': log_ref,
                'native_exit_as_reported': native.get('exit_code'),
                'status_as_reported': native.get('status'),
                'passed_as_reported': sampler_native.get('passed')}
        sampler_observed = {
            'summary': ref(SAMPLER + '/summary.json'), 'finished_utc': sampler['finished_utc'],
            'passed_as_reported': sampler['passed'], 'errors_as_reported': sampler['errors'],
            'scope_verbatim': sampler.get('scope'), 'argv_as_reported': sampler.get('argv'),
            'original_contract_as_reported': sampler.get('original_contract'),
            'harness_as_reported': sampler.get('harness'),
            'registry_as_reported': sampler.get('registry'),
            'elf_identity_as_reported': sampler.get('elf'),
            'native': sampler_native_refs, 'captures': sampler_captures,
            'final_file_receipt': ref(sampler_manifest_member),
            'original_file_identities_verified': len(sampler_manifest_names),
            'sqlite_as_reported': sqlite,
            'sqlite_qualification_granted_by_packaging': False,
            'no_counts_combined_with_node_library_or_four_gate_results': True,
        }

        phase = 'current-source component build and auxiliary evidence'
        prefix_member = 'validation/' + BUILD_PREFIX
        records = {}
        for suffix in BUILD_SUFFIXES:
            member = prefix_member + suffix
            add(member)
            records[suffix] = {'present': True, **ref(member)}
        before = value(prefix_member + '-source-before.json')
        after = value(prefix_member + '-source-after.json')
        require(before == after == source, 'component build source-before/after receipts differ from the suite')
        wrapper = value(prefix_member + '.json')
        require(wrapper.get('source') == args.expected_head and wrapper.get('tree') == args.expected_tree,
                'component build wrapper source differs')
        timestamp(wrapper.get('finished_utc'), 'component build wrapper')
        require(type(wrapper.get('exit_code')) is int, 'component build wrapper lacks an actual terminal exit')
        builds = [{'prefix': BUILD_PREFIX, 'records': records,
                   'wrapper_exit_code_as_recorded': wrapper.get('exit_code'),
                   'scope_as_recorded': wrapper.get('scope'),
                   'no_wrapper_exit_inferred_from_partial_cargo_output': True}]
        for name, expected in HELPERS.items():
            member = 'validation/' + name
            add(member)
            require(ref(member)['sha256'] == expected, 'reviewed helper changed: ' + name)
            if name == 'run_sampler_release_validation.py':
                identity = sampler.get('runner')
            else:
                identity = top.get('runner') if name == 'run_composed_native_validation.py' else top.get('helpers', {}).get(name)
            identity_matches(identity, member)
        identity_matches(sampler.get('common_helper'), 'validation/run_exact_selected_controls.py')
        require(ref(SAMPLER + '/inputs/sampler-runner.py')['sha256'] == HELPERS['run_sampler_release_validation.py'],
                'sampler retained runner copy differs from the reviewed helper')
        add(PROVIDER)
        provider = value(PROVIDER)

        phase = 'manifest construction'
        files = [{'archive_member': name, 'source_path': item['path'], 'bytes': len(item['data']),
                  'sha256': digest(item['data'])} for name, item in sorted(inputs.items())]
        index = {
            'schema': 'trnm-composed-rog-evidence-index-v1', 'created_utc': created,
            'expected_head': args.expected_head, 'expected_tree': args.expected_tree,
            'suite': ref(SUITE + '/summary.json'), 'suite_passed_as_reported': top['passed'],
            'suite_scope_verbatim': top.get('scope'), 'suite_errors_as_reported': top['errors'],
            'gates': observed, 'sampler': sampler_observed, 'build_attempts': builds,
            'earlier_2859_build_attempts_included': False,
            'actual_runner_and_helpers': [ref('validation/' + name) for name in HELPERS],
            'provider_receipt': ref(PROVIDER), 'provider_status_as_reported': provider.get('result'),
            'exclusions': excluded,
            'scope': 'Lossless evidence packaging only. Four-gate and independent release/default sampler failures remain their original results; SQLite UNKNOWN/UNQUALIFIED remains unqualified by this run. Earlier 2859 build failures stay in their separate archive. No native execution, build, source modification, network call, or new performance acceptance.',
        }
        packager_bytes, packager_fingerprint = read_regular(Path(__file__).absolute())
        manifest = {
            'schema': 'trnm-composed-rog-evidence-files-v1', 'created_utc': created,
            'original_regular_files': len(files), 'original_bytes': sum(r['bytes'] for r in files),
            'source': {'expected_head': args.expected_head, 'expected_tree': args.expected_tree,
                       'proof_scope': 'retained original runner source receipts; this packager executes no source checker'},
            'files': files, 'excluded_entries': excluded,
            'earlier_2859_build_attempts_included': False,
            'generated_metadata_not_original_records': ['packaging/manifest.json', 'packaging/SHA256SUMS', 'packaging/index.json', 'packaging/package_composed_7586_evidence.py'],
            'container': 'solid XZ, deterministic regular tar members, zero timestamps/uids/gids, no symlink/hardlink/absolute/traversal entries',
        }
        manifest_bytes = encoded(manifest)
        index_bytes = encoded(index)
        checksums = ''.join(r['sha256'] + '  ' + r['archive_member'] + '\n' for r in files).encode()
        generated = {
            'packaging/manifest.json': manifest_bytes,
            'packaging/index.json': index_bytes,
            'packaging/SHA256SUMS': checksums,
            'packaging/package_composed_7586_evidence.py': packager_bytes,
        }
        payload = {name: item['data'] for name, item in inputs.items()}
        require(not (set(payload) & set(generated)), 'generated metadata collides with original evidence')
        payload.update(generated)

        phase = 'solid archive write and complete readback'
        with paths['archive'].open('xb') as raw:
            with lzma.LZMAFile(raw, 'w', format=lzma.FORMAT_XZ, check=lzma.CHECK_CRC64, preset=6) as compressed:
                with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
                    for name, data in sorted(payload.items()):
                        safe_member(name)
                        info = tarfile.TarInfo(name)
                        info.size = len(data)
                        info.mode = 0o644
                        info.uid = info.gid = info.mtime = 0
                        info.uname = info.gname = ''
                        info.type = tarfile.REGTYPE
                        archive.addfile(info, io.BytesIO(data))
        archive_bytes, archive_fingerprint = read_regular(paths['archive'])
        seen = set()
        with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:xz') as archive:
            for item in archive.getmembers():
                safe_member(item.name)
                require(item.isfile() and not item.islnk() and not item.issym(), 'non-regular archive member')
                require(item.name in payload and item.name not in seen, 'unexpected or duplicate archive member')
                require((item.mode, item.uid, item.gid, item.mtime, item.uname, item.gname) == (0o644, 0, 0, 0, '', ''), 'archive metadata changed')
                stream = archive.extractfile(item)
                require(stream is not None and stream.read() == payload[item.name], 'archive byte readback failed: ' + item.name)
                seen.add(item.name)
        require(seen == set(payload), 'archive omits selected evidence')

        phase = 'original input recheck and sidecar publication'
        for member, item in inputs.items():
            path = inside_regular(root, member)
            data, ident = read_regular(path)
            require(ident == item['fingerprint'] and data == item['data'], 'evidence changed while packaging: ' + member)
        require(read_regular(Path(__file__).absolute()) == (packager_bytes, packager_fingerprint), 'packager source changed')
        require(read_regular(paths['archive']) == (archive_bytes, archive_fingerprint), 'archive changed during readback')
        # Re-list both permitted trees to catch late-added evidence.
        for member_root, discovered in discovered_tree_names.items():
            after_names = set()
            for current, dirs, names in os.walk(root / member_root, followlinks=False):
                dirs[:] = sorted(name for name in dirs
                                 if path_exclusion((Path(current) / name).relative_to(root).as_posix()) is None
                                 and stat.S_ISDIR((Path(current) / name).lstat().st_mode))
                after_names.update((Path(current) / name).relative_to(root).as_posix() for name in names)
            require(after_names == discovered, 'evidence tree membership changed while packaging: ' + member_root)
        for key, data in [('manifest', manifest_bytes), ('checksums', checksums), ('index', index_bytes)]:
            with paths[key].open('xb') as stream:
                stream.write(data)
            require(read_regular(paths[key])[0] == data, 'sidecar readback differs: ' + key)
        receipt = {
            'schema': 'trnm-composed-rog-package-receipt-v1', 'created_utc': created, 'finished_utc': now(),
            'expected_head': args.expected_head, 'expected_tree': args.expected_tree,
            'archive': {'path': str(paths['archive']), 'bytes': len(archive_bytes), 'sha256': digest(archive_bytes),
                        'regular_members': len(payload), 'original_regular_files': len(inputs),
                        'all_member_bytes_read_back': True, 'only_safe_regular_members': True},
            'sidecars': {key: {'path': str(paths[key]), 'bytes': len(data), 'sha256': digest(data)}
                         for key, data in [('manifest', manifest_bytes), ('checksums', checksums), ('index', index_bytes)]},
            'packager_sha256': digest(packager_bytes), 'all_selected_inputs_rechecked_unchanged': True,
            'suite_and_sampler_memberships_rechecked_unchanged': True,
            'suite_passed_as_reported': top['passed'], 'sampler_passed_as_reported': sampler['passed'],
            'sampler_sqlite_status_as_reported': sqlite.get('status'),
            'sqlite_qualification_granted_by_packaging': False,
            'earlier_2859_build_attempts_included': False,
            'excluded_entries': excluded, 'no_native_test_build_source_mutation_or_network_api': True,
        }
        with paths['receipt'].open('xb') as stream:
            stream.write(encoded(receipt))
        print(json.dumps(receipt, ensure_ascii=False, indent=2), flush=True)
        return 0
    except Exception:
        failure = {'schema': 'trnm-composed-rog-package-failure-v1', 'created_utc': created,
                   'failed_utc': now(), 'phase': phase, 'traceback': traceback.format_exc(),
                   'native_execution_or_build': False,
                   'partial_outputs_retained': [str(p) for key, p in paths.items() if key != 'failure' and p.exists()],
                   'policy': 'No retry, missing-summary substitution, or successful publication receipt. Preserve this failed packaging attempt.'}
        with paths['failure'].open('xb') as stream:
            stream.write(encoded(failure))
        print(json.dumps(failure, ensure_ascii=False, indent=2), flush=True)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
