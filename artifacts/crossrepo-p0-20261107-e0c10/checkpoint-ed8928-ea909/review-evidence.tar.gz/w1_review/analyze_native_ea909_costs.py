"""Read actor/receiver/economic cost scopes from the verified ea909 native ZIP."""
from collections import Counter
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

from analyze_f0_9f77 import aggregate_receiver, digest, histogram, numeric_summary

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'native-ea909-42329179267'
CORE = json.loads((OUT / 'analysis.json').read_text())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def counts(values):
    return [{'value': value, 'count': n} for value, n in Counter(values).items()]


def num(rows, key):
    return numeric_summary([r.get(key) for r in rows])


def call_costs(calls):
    return {
        'calls': len(calls), 'status': counts(r['status'] for r in calls),
        'errors': counts(r['error'] for r in calls),
        'signed_reply_errors': counts(r.get('response', {}).get('value', {}).get('error')
            for r in calls if isinstance(r.get('response'), dict) and r['status'] == 'refused'),
        'returned_after_window': sum(r['returned_after_window'] is True for r in calls),
        'accepted_replies': sum(r['status'] == 'ok' for r in calls),
        'calling_process_cpu_ns': num(calls, 'calling_process_cpu_ns'),
        'call_wall_ns_sum_is_not_single_elapsed_time': num(calls, 'elapsed_wall_ns'),
        'recorded_request_body_bytes': num(calls, 'recorded_request_bytes'),
        'physical_network_bytes_established': False,
        'solution_trials': numeric_summary([(r.get('metrics') or {}).get('solution_trials') for r in calls]),
        'failed_stages': counts((r.get('metrics') or {}).get('failed_stage') for r in calls),
    }


def child_costs(child, member):
    report = child['report']
    result = report['result']
    assert report['kind'] == 'attack'
    acquisition = result['acquisition']
    return {
        'raw_report_member': member, 'raw_report_sha256': None,
        'exit_success': child['exit_success'], 'exit_status': child['exit_status'],
        'parent_forced_kill': child['parent_forced_kill'],
        'spawn_to_reap_wall_ns': child['spawn_to_reap_wall_ns'],
        'report_error': report['error'], 'whole_entry_cpu_ns': report['whole_entry_cpu_ns'],
        'whole_entry_wall_ns': report['whole_entry_wall_ns'],
        'actor_result_without_calls': {k: v for k, v in result.items() if k != 'calls'},
        'call_costs': call_costs(result['calls']), 'rss': report['rss'],
        'acquisition_attempts': len(acquisition['attempts']),
        'acquisition_misses': sum(a['target_hit'] is False for a in acquisition['attempts']),
        'acquisition_target_hits': sum(a['target_hit'] is True for a in acquisition['attempts']),
    }


def economic_costs(child, member):
    report = child['report']
    result = report['result']
    modes = []
    for mode in result['modes']:
        samples = mode['samples']
        searches = [s for sample in samples for s in sample['searches']]
        attempts = [a for search in searches for a in search['attempts']]
        modes.append({
            'reuse_preparation': mode['reuse_preparation'], 'samples': len(samples),
            'searches': len(searches), 'physical_attempts': len(attempts),
            'misses': sum(a['target_hit'] is False for a in attempts),
            'target_hits': sum(a['target_hit'] is True for a in attempts),
            'winner_verifier_calls': sum(len(s['verified_winners']) for s in samples),
            'verified_winners': sum('Ok' in verdict for s in samples for verdict in s['verified_winners']),
            'winner_verdicts': counts(json.dumps(verdict, sort_keys=True) for s in samples for verdict in s['verified_winners']),
            'all_sample_errors': [error for s in samples for error in s['errors']],
            'sample_acquisition_cpu_ns': num(samples, 'acquisition_cpu_ns'),
            'sample_acquisition_wall_ns': num(samples, 'acquisition_wall_ns'),
            'independent_verification_cpu_ns': num(samples, 'independent_verification_cpu_ns'),
            'independent_verification_wall_ns': num(samples, 'independent_verification_wall_ns'),
            'initial_setup_cpu_ns_nested': num(samples, 'initial_setup_cpu_ns'),
            'search_setup_cpu_ns_nested': num(searches, 'setup_cpu_ns'),
            'search_cpu_ns_nested': num(searches, 'search_cpu_ns'),
        })
    false_samples = result['same_task_target_from_zero_samples']
    false_searches = [s for sample in false_samples for s in sample['searches']]
    false_attempts = [a for s in false_searches for a in s['attempts']]
    return {
        'raw_report_member': member, 'raw_report_sha256': None,
        'exit_success': child['exit_success'], 'parent_forced_kill': child['parent_forced_kill'],
        'report_error': report['error'], 'whole_entry_cpu_ns': report['whole_entry_cpu_ns'],
        'whole_entry_wall_ns': report['whole_entry_wall_ns'], 'rss': report['rss'],
        'method': result['method'], 'method_index': result['method_index'], 'scope': result['scope'],
        'modes': modes,
        'same_task_target_from_zero': {
            'samples': len(false_samples), 'searches': len(false_searches), 'attempts': len(false_attempts),
            'misses': sum(a['target_hit'] is False for a in false_attempts),
            'target_hits': sum(a['target_hit'] is True for a in false_attempts),
            'acquisition_cpu_ns': num(false_samples, 'acquisition_cpu_ns'),
            'acquisition_wall_ns': num(false_samples, 'acquisition_wall_ns'),
            'diagnostic_cpu_ns': num(false_samples, 'diagnostic_cpu_ns'),
            'diagnostic_wall_ns': num(false_samples, 'diagnostic_wall_ns'),
            'diagnostics': counts(json.dumps(d, sort_keys=True) for s in false_samples for d in s['relation_diagnostics']),
        },
    }


phases, economics = [], []
with ZipFile(CORE['archive']['path']) as archive:
    for run in range(1, 4):
        report_member = f'run-{run}-raw/report.json'
        raw = archive.read(report_member)
        assert sha(raw) == CORE['reports'][run - 1]['report_sha256']
        report = json.loads(raw)
        for child in report['economics']:
            member = f'run-{run}-raw/cost-{child["report"]["result"]["method_index"]}/report.json'
            assert json.loads(archive.read(member)) == child['report']
            row = economic_costs(child, member)
            row.update(run=run, raw_report_sha256=sha(archive.read(member)))
            economics.append(row)
        for phase in report['phases']:
            name = phase['mode']
            host_boundaries = {}
            for boundary in ('outside-before', 'inside-before', 'inside-after', 'outside-after'):
                member = f'run-{run}-raw/{name}-host-control/host/{boundary}.json'
                boundary_raw = archive.read(member)
                observed = json.loads(boundary_raw)
                assert observed['limits'] == {'cpu.max': '25000 100000', 'cpu.max.burst': '0',
                    'memory.max': '2147483648', 'memory.swap.max': '0', 'pids.max': '256'}
                assert observed['read_errors'] == {}
                assert observed['parent']['canonical_path'] == '/sys/fs/cgroup/trnmponpublic.slice'
                assert observed['parent']['uid'] == observed['parent']['gid'] == 0
                assert observed['parent']['directory'] is True and observed['parent']['symlink'] is False
                host_boundaries[boundary] = {'member': member, 'sha256': sha(boundary_raw),
                    **{k: observed[k] for k in ('limits', 'parent', 'counters', 'read_errors', 'thread_cgroup',
                        'thread_privileges', 'installed_unit_sha256', 'boot_id', 'observed_utc', 'host_readiness_only')}}
            children = []
            calls = []
            acquisitions = []
            for ordinal, child in enumerate(phase['children']):
                member = f'run-{run}-raw/{name}/attacker-{ordinal:02d}/report.json'
                assert json.loads(archive.read(member)) == child['report']
                row = child_costs(child, member)
                row['raw_report_sha256'] = sha(archive.read(member))
                children.append(row)
                calls.extend(child['report']['result']['calls'])
                acquisitions.append(child['report']['result']['acquisition'])
            assert len(children) == phase['attacker_processes_ready'] == (0 if name == 'baseline' else 24)
            honest = {r['public_request_body_digest'] for r in phase['submissions']}
            hostile = {r['public_request_body_digest'] for r in acquisitions}
            history = {r['public_request_body_digest'] for r in phase['history']}
            assert not honest.intersection(hostile | history) and not hostile.intersection(history)
            receiver = phase['receiver_observation']['records']
            categories = {
                'honest': [r for r in receiver if digest(r['body_digest']) in honest],
                'hostile': [r for r in receiver if digest(r['body_digest']) in hostile],
                'history': [r for r in receiver if digest(r['body_digest']) in history],
                'unclassified': [r for r in receiver if digest(r['body_digest']) not in honest | hostile | history],
            }
            assert sum(map(len, categories.values())) == len(receiver)
            before, after = (phase['phase_process_context'][key] for key in ('host_before', 'host_after'))
            actual_credits = [r['meter']['Ok']['actual_flow']['remaining_paid_credit_ns']
                for r in phase['budget_samples'] if 'Ok' in r['meter']]
            row = {
                'run': run, 'phase': name, 'raw_report_member': report_member,
                'actual_host_boundary_observations': host_boundaries,
                'kernel_before': before, 'kernel_after': after,
                'public_parent_kernel_delta': {k: after[k] - before[k] for k in
                    ('cpu_usage_usec', 'cpu_nr_periods', 'cpu_nr_throttled', 'cpu_throttled_usec')},
                'kernel_scope': 'fixed public parent snapshot interval includes setup/shutdown; throttle time is not CPU work',
                'whole_parent_phase_cpu_ns': phase['whole_parent_phase_cpu_ns'],
                'whole_parent_phase_wall_ns': phase['whole_parent_phase_wall_ns'],
                'setup_cpu_ns': phase['receiver_and_verifier_setup_cpu_ns'],
                'setup_wall_ns': phase['receiver_and_verifier_setup_wall_ns'],
                'receiver_observer': {k: v for k, v in phase['receiver_observation'].items() if k != 'records'},
                'receiver_all': aggregate_receiver(receiver),
                'receiver_categories': {k: aggregate_receiver(v) for k, v in categories.items()},
                'attack': {
                    'actors_requested': phase['attacker_processes_requested'], 'actors_ready': phase['attacker_processes_ready'],
                    'actor_reports_successful_without_cap_or_kill': phase['actor_reports_successful_without_cap_or_kill'],
                    'calls_overlapping_each_observed_round': phase['attack_calls_overlapping_each_signed_round'],
                    'call_totals': call_costs(calls), 'all_actor_whole_entry_cpu_ns': num(children, 'whole_entry_cpu_ns'),
                    'all_actor_whole_entry_wall_ns_concurrent_not_elapsed': num(children, 'whole_entry_wall_ns'),
                    'all_acquisition_cpu_ns_nested_in_actor': num(acquisitions, 'acquisition_cpu_ns'),
                    'all_acquisition_wall_ns_concurrent': num(acquisitions, 'acquisition_wall_ns'),
                    'all_diagnostic_cpu_ns_nested_in_actor': num(acquisitions, 'diagnostic_cpu_ns'),
                    'setup_calls': sum(r['setup_calls'] for r in acquisitions),
                    'attempts': sum(len(r['attempts']) for r in acquisitions),
                    'misses': sum(a['target_hit'] is False for r in acquisitions for a in r['attempts']),
                    'target_hits': sum(a['target_hit'] is True for r in acquisitions for a in r['attempts']),
                    'diagnostic_results': counts(json.dumps(r['diagnostic_result'], sort_keys=True) for r in acquisitions),
                    'children': children,
                },
                'controller_children_os_usage': {
                    'before': phase['children_os_usage_before'], 'after': phase['children_os_usage_after'],
                    'delta_cpu_ns': sum(phase['children_os_usage_after'][k] - phase['children_os_usage_before'][k]
                        for k in ('system_cpu_ns', 'user_cpu_ns')),
                },
                'public_phase_children_os_usage': {'before': phase['public_phase_children_os_usage_before'],
                    'after': phase['public_phase_children_os_usage_after']},
                'external_controller_observation': phase['external_controller_observation'],
                'whole_phase_rss': phase['rss'], 'budget_samples': len(phase['budget_samples']),
                'sampled_remaining_paid_credit_ns': numeric_summary(actual_credits),
                'sampled_budget_depletion': sum(r['meter'].get('Ok', {}).get('depleted') is True for r in phase['budget_samples']),
                'genuine_budget_depletion_observed': phase['genuine_budget_depletion_observed'],
                'final_actual_flow': phase['final_actual_flow'], 'completion_work_observation': phase['completion_work_observation'],
                'service_outcome': phase['service_outcome'], 'full_work_accepted': phase['full_work_accepted'],
                'full_work_failed': phase['full_work_failed'],
            }
            phases.append(row)

assert len(phases) == 9 and len(economics) == 24
value = {
    'schema': 'ea909-original-native-actor-receiver-cost-scopes-v1',
    'source_head': CORE['candidate'], 'source_tree': CORE['tree'], 'artifact_id': CORE['artifact_id'],
    'run_id': CORE['run_id'], 'job_id': CORE['job_id'], 'source_kind': 'head',
    'core_analysis': {'path': str(OUT / 'analysis.json'), 'sha256': sha((OUT / 'analysis.json').read_bytes())},
    'phases': phases, 'original_economic_method_observations': economics,
    'interpretation_boundaries': [
        'All public-parent/client/Host/receiver CPU scopes are nested or overlapping; do not add their sums.',
        'External attacker whole-entry CPU is a different owner scope. Acquisition, diagnostic and call costs are nested inside it.',
        'Concurrent actor wall times are sums of durations, not one elapsed campaign latency.',
        'Receiver records are partitioned by exact public request body digest; unmatched transport/setup records remain unclassified.',
        'Retained application byte counts do not establish physical network byte counts.',
        'Original economic method measurements use their own exact native grid and cold/reused selectors; not the expanded V5 grid or global best-known proof.',
        'No new native work, model simulation, benchmark or workflow was executed; independent external acceptance remains false.',
    ],
    'external_acceptance': False, 'old_9f_results_inherited': False,
}
path = OUT / 'cost-scope-analysis.json'
path.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()),
    'attack_actors': sum(p['attack']['actors_ready'] for p in phases),
    'attack_calls': sum(p['attack']['call_totals']['calls'] for p in phases)}, indent=2))
