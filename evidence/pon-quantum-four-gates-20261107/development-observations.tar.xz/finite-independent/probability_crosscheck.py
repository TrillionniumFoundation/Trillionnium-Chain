"""Independent exact-Fraction / directed-interval audit; no implementation edits."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/c9b48df754d6/chain-quantum-next')
sys.path.insert(0, str(ROOT / 'formal/pon-nakamoto-v1'))
sys.dont_write_bytecode = True
from w1_finite_consensus import exact_nonce_probabilities
from w1_search_probability import grover_success_bounds

NAMES = ('w1_finite_consensus.py', 'w1_search_probability.py', 'w1_machine_envelope.py',
         'w1_constructed_search.py', 'quantum_oracle_resources.py', 'w1_marked_domain.py')

def sources():
    return {name: hashlib.sha256((ROOT/'formal/pon-nakamoto-v1'/name).read_bytes()).hexdigest() for name in NAMES}

started = datetime.now(timezone.utc).isoformat()
before = sources()
count = 0
for size in (1, 2, 4, 8, 16, 64):
    for marked in sorted({0, 1, size//4, size//2, 3*size//4, size}):
        for q in (0, 1, 2, 3, 7, 16, 31, 64):
            distribution = exact_nonce_probabilities(size, tuple(range(marked)), q)
            for accepted in sorted({marked, (marked+size)//2, size}):
                single = sum(distribution[:accepted])
                for processors in (1, 3):
                    exact = 1 - (1-single)**processors
                    bound = grover_success_bounds(size, marked, accepted, q, processors)
                    assert 0 <= bound.lower <= exact <= bound.upper <= 1, (size,marked,accepted,q,processors)
                    count += 1
periodic = 0
for q in (99_999_998, 99_999_999, 100_000_000):
    for size,marked,values in ((4,1,(Fraction(1,4),Fraction(1),Fraction(1,4))),
                               (4,3,(Fraction(3,4),Fraction(0),Fraction(3,4))),
                               (2,1,(Fraction(1,2),)*3)):
        for processors in (1,3):
            exact = 1-(1-values[q % 3])**processors
            bound = grover_success_bounds(size,marked,marked,q,processors)
            assert bound.lower == bound.upper == exact, (size,marked,q,processors)
            periodic += 1
after = sources()
assert before == after
print(json.dumps({'status':'PASS','started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),
 'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'source_before':before,'source_after':after,'source_unchanged':True,
 'finite_fraction_interval_comparisons':count,'large_q_exact_period_controls':periodic,
 'q_range_exact_kernel':[0,64],'large_q_maximum':100_000_000,
 'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'command':'python /workspace/scratch/c9b48df754d6/validation-four-gates/finite-independent/probability_crosscheck.py',
 'quantum_hardware_executed':False,'consensus_security_proved':False},indent=2,sort_keys=True))
