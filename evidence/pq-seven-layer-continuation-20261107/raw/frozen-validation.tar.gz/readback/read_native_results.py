#!/usr/bin/env python3
"""Independently read a frozen native phase; never run or qualify the system.

This task-local reader uses frozen Git blobs, recorder receipts, actual libtest
registries, Cargo harness boundaries and the --show-output parent name lists.
Nested child summaries are observations, never additional parent passes.

Exit 0: the recorded phase and all required readbacks passed.
Exit 1: a failure or contradiction was observed.
Exit 2: evidence is missing or still running (PENDING, not a pass).
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tomllib


PLANNED = [
    "compiler", "provider-version", "node-build", "node-registry", "node-full",
    "tls-cli-and-witness-registry", "tls-cli-and-witness",
    "migration-v6-and-feature-off-registry", "migration-v6-and-feature-off",
    "checkpoint-release-registry", "checkpoint-release",
    "sqlite-build-requalification", "strict-clippy",
]
CARGO_COMMON = ["--offline", "--locked", "--manifest-path", "trillionnium/Cargo.toml"]
NAME = r"[A-Za-z_][A-Za-z_0-9]*(?:::[A-Za-z_][A-Za-z_0-9]*)*"
NAME_RE = re.compile(NAME)
RUNNING = re.compile(r"^\s+Running (?P<descriptor>[^()\n]+?) \((?P<path>[^()\n]+)\)$")
SUMMARY = re.compile(
    r"^test result: (?P<outcome>ok|FAILED)\. (?P<passed>\d+) passed; "
    r"(?P<failed>\d+) failed; (?P<ignored>\d+) ignored; (?P<measured>\d+) measured; "
    r"(?P<filtered>\d+) filtered out; finished in (?P<seconds>\d+(?:\.\d+)?)s$"
)
MIGRATION = [
    "npq6_anchored_claim_preserves_obligations_rotates_and_cold_reopens",
    "npq6_migration_requires_both_claim_signatures_and_the_selected_domain",
    "admitted_legacy_checkpoint_cannot_drop_unhandled_work_state_for_migration",
]
FALSE_FLAGS = {
    "whole_chain_pq_qualified": False,
    "whole_chain_quantum_security_qualified": False,
    "public_wan_qualified": False,
    "production_activation": False,
    "consensus_authority": False,
    "whole_node_rollback_protection": False,
}


class Invalid(ValueError):
    pass


class Pending(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Invalid(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def strict_object(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, "duplicate JSON key: " + key)
        obj[key] = value
    return obj


def decode_json(data, origin):
    try:
        return json.loads(data, object_pairs_hook=strict_object)
    except (UnicodeError, json.JSONDecodeError) as error:
        raise Invalid(f"invalid JSON in {origin}: {error}") from error


def read_bytes(path):
    if not path.exists():
        raise Pending("missing evidence: " + str(path))
    require(path.is_file() and not path.is_symlink(), "evidence is not a regular non-symlink file: " + str(path))
    return path.read_bytes()


def read_json(path):
    return decode_json(read_bytes(path), str(path))


def digest_record(data, path):
    return {"path": str(path), "sha256": sha(data), "bytes": len(data)}


def canonical_sha(value, length=64):
    return isinstance(value, str) and re.fullmatch("[0-9a-f]{" + str(length) + "}", value) is not None


def exact_names(values, count, origin):
    require(isinstance(values, list) and len(values) == count, f"{origin}: expected {count} names")
    require(all(isinstance(v, str) and NAME_RE.fullmatch(v) for v in values), origin + ": invalid test name")
    require(len(set(values)) == len(values), origin + ": duplicate test names")
    return sorted(values)


def frozen_git(root, *args):
    result = subprocess.run(["git", "--no-replace-objects", *args], cwd=root,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    require(result.returncode == 0, "frozen Git read failed: " + result.stderr.decode(errors="replace").strip())
    return result.stdout


def parse_registry(text, origin):
    """A registry is one actual --list harness, with an exact terminal count."""
    names, counts = [], []
    for number, line in enumerate(text.splitlines(), 1):
        entry = re.fullmatch(f"({NAME}): test", line)
        if entry:
            names.append(entry[1])
        elif match := re.fullmatch(r"(\d+) tests?, (\d+) benchmarks?", line):
            counts.append((number, int(match[1]), int(match[2])))
        elif line.strip():
            raise Invalid(f"{origin}:{number}: unexpected registry content: {line[:160]}")
    require(len(counts) == 1, f"{origin}: registry must have exactly one summary")
    number, count, benches = counts[0]
    require(benches == 0, origin + ": benchmark entries are not test qualification")
    require(not any(line.strip() for line in text.splitlines()[number:]), origin + ": registry has content after summary")
    names = exact_names(names, count, origin)
    return {"tests": count, "benchmarks": benches, "names": names, "summary_line": number}


def split_harnesses(text, origin):
    lines = text.splitlines()
    headers = [(i, RUNNING.fullmatch(line)) for i, line in enumerate(lines) if RUNNING.fullmatch(line)]
    require(headers, origin + ": missing Cargo Running harness boundaries")
    prefix = lines[:headers[0][0]]
    require(not any(SUMMARY.fullmatch(line) or re.fullmatch(r"running \d+ tests?", line) for line in prefix),
            origin + ": unbound test transcript before first Cargo harness")
    require(not any(re.match(r"\s*Doc-tests\b", line) for line in lines),
            origin + ": unexpected doc-test harness; extend the reader explicitly")
    harnesses = []
    for index, (start, header) in enumerate(headers):
        end = headers[index + 1][0] if index + 1 < len(headers) else len(lines)
        path = header["path"]
        require(Path(path).is_absolute(), origin + ": harness executable is not absolute")
        harnesses.append({"descriptor": header["descriptor"], "path": path,
                          "header_line": start + 1, "body_line_offset": start + 1,
                          "body": "\n".join(lines[start + 1:end]) + "\n"})
    keys = [(h["descriptor"], h["path"]) for h in harnesses]
    require(len(keys) == len(set(keys)), origin + ": duplicate Cargo harness identity")
    return harnesses


def parent_name_list(lines, heading, count, registry, summary_line, origin):
    if count == 0:
        return [], None
    candidates = []
    for index, line in enumerate(lines[:summary_line]):
        if line != heading + ":":
            continue
        pos = index + 1
        while pos < summary_line and not lines[pos].strip():
            pos += 1
        names = []
        while pos < summary_line and lines[pos].startswith("    "):
            value = lines[pos][4:]
            if not NAME_RE.fullmatch(value):
                break
            names.append(value)
            pos += 1
        if (len(names) == count and len(set(names)) == count and set(names) <= registry
                and (pos == summary_line or not lines[pos].strip())):
            candidates.append((names, index + 1))
    require(len(candidates) == 1,
            f"{origin}: expected one parent {heading} name list of {count}; found {len(candidates)}")
    names, line = candidates[0]
    return sorted(names), line


def parse_parent(text, registry, origin):
    """Bind a unique unfiltered parent to its registry, not to the last summary.

    Child libtest stdout inherits file descriptors and can attach a parent 'ok'
    to a child's name. Only the complete --show-output parent roster partitions
    passes; standalone inline ok lines are retained as corroboration, not totals.
    """
    lines = text.splitlines()
    summaries, starts = [], []
    for i, line in enumerate(lines):
        if match := SUMMARY.fullmatch(line):
            item = {key: int(match[key]) for key in ("passed", "failed", "ignored", "measured", "filtered")}
            item.update(outcome=match["outcome"], seconds=float(match["seconds"]), line=i + 1)
            summaries.append(item)
        if match := re.fullmatch(r"running (\d+) tests?", line):
            starts.append({"line": i + 1, "tests": int(match[1])})
    count = registry["tests"]
    require(starts and starts[0]["tests"] == count, origin + ": initial parent running count differs from registry")
    candidates = [s for s in summaries if s["filtered"] == 0 and s["measured"] == 0
                  and s["passed"] + s["failed"] + s["ignored"] == count]
    require(len(candidates) == 1, f"{origin}: expected one unfiltered parent summary for {count}; found {len(candidates)}")
    parent = candidates[0]
    require(parent["line"] > starts[0]["line"], origin + ": parent summary precedes running line")
    require(not any(s["line"] > parent["line"] for s in summaries), origin + ": more summaries follow the matched parent")
    require(not any(s["line"] > parent["line"] for s in starts), origin + ": more test runs follow the matched parent")
    require((parent["outcome"] == "ok") == (parent["failed"] == 0), origin + ": summary outcome disagrees with failure count")
    universe = set(registry["names"])
    passed, passed_line = parent_name_list(lines, "successes", parent["passed"], universe, parent["line"] - 1, origin)
    failed, failed_line = parent_name_list(lines, "failures", parent["failed"], universe, parent["line"] - 1, origin)
    ignored, ignored_details, inline_pass = [], [], set()
    for i, line in enumerate(lines[:parent["line"] - 1]):
        if match := re.fullmatch(f"test ({NAME}) \\.\\.\\. ignored(?:, (.*))?", line):
            ignored.append(match[1])
            ignored_details.append({"name": match[1], "reason": match[2] or "", "line": i + 1})
        if match := re.fullmatch(f"test ({NAME}) \\.\\.\\. ok", line):
            inline_pass.add(match[1])
    ignored = exact_names(ignored, parent["ignored"], origin + " ignored entries")
    require(not (set(passed) & set(failed) or set(passed) & set(ignored) or set(failed) & set(ignored)),
            origin + ": pass/fail/ignore names overlap")
    require(set(passed) | set(failed) | set(ignored) == universe,
            origin + ": pass/fail/ignore names do not partition the actual registry")
    return {
        "status": "PASS" if parent["failed"] == 0 else "FAIL",
        "registry_tests": count, "registry_names": registry["names"],
        "parent_summary": parent, "parent_running": starts[0],
        "parent_passed_names": passed, "parent_failed_names": failed,
        "parent_ignored_names": ignored, "parent_ignored_details": ignored_details,
        "parent_successes_list_line": passed_line, "parent_failures_list_line": failed_line,
        "inline_ok_names_in_parent_pass_roster": sorted(inline_pass & set(passed)),
        "inline_ok_names_outside_parent_pass_roster_not_credited": sorted(inline_pass - set(passed)),
        "parent_pass_names_without_standalone_inline_ok": sorted(set(passed) - inline_pass),
        "nested_summary_observations_not_credited": [s for s in summaries if s is not parent],
        "additional_running_observations_not_credited": starts[1:],
        "complete_registry_partition": True,
        "zero_test_harness": count == 0,
        "transcript_line_numbers_relative_to_harness_body": True,
    }


class Reader:
    def __init__(self, root, output):
        self.root = root.resolve(strict=True)
        self.output = output.absolute()
        self.head = None
        self.tree = None
        self.receipts = {}
        self.logs = {}
        self.source_files = {}
        self.report = {
            "schema": "trnm-task-native-readback-v1",
            "generated_utc": datetime.now(timezone.utc).isoformat(),
            "reader": digest_record(Path(__file__).read_bytes(), Path(__file__).resolve()),
            "native_output": str(self.output), "checks": {}, "commands": {},
            "scope": "independent transcript and recorded source/ELF binding readback; component evidence only",
            "claim_guard": "HOLD", **FALSE_FLAGS,
            "limitations": [
                "Recorder and ELF digest records are local execution evidence, not independent hardware attestation.",
                "Passing component tests do not establish public WAN operation, all-ledger rollback resistance, quantum mining security, or whole-chain PQ-128.",
                "Ordinary Node binaries, CLI/Witness, migration, checkpoint and release harnesses are separate from the Node library count.",
                "--all-targets does not execute doc-tests; absent doc-tests are not zero-test passes.",
                "Live evidence may be incomplete; PENDING never grants qualification.",
            ],
        }

    def check(self, name, function):
        try:
            result = function()
            result.setdefault("status", "PASS")
        except Pending as error:
            result = {"status": "PENDING", "reason": str(error)}
        except (Invalid, OSError, UnicodeError, KeyError, TypeError, IndexError, tomllib.TOMLDecodeError) as error:
            result = {"status": "FAIL", "reason": str(error)}
        self.report["checks"][name] = result
        return result

    def blob(self, name):
        if self.head is None:
            if self.report["checks"].get("frozen_source", {}).get("status") == "FAIL":
                raise Invalid("frozen source identity failed validation")
            raise Pending("frozen source identity not yet available")
        data = frozen_git(self.root, "show", self.head + ":" + name)
        self.source_files[name] = {"sha256": sha(data), "bytes": len(data), "commit": self.head}
        return data

    def identity(self):
        runner = read_json(self.output / "runner.json")
        require(isinstance(runner, dict), "runner must be an object")
        require(runner.get("phase") == "native", "runner phase is not native")
        require(canonical_sha(runner.get("head"), 40) and canonical_sha(runner.get("tree"), 40), "invalid frozen Git identity")
        require(runner.get("planned_commands") == PLANNED, "runner native command plan differs from the reviewed 13 commands")
        require(runner.get("original_profiles_unchanged") is True, "runner does not preserve original profiles")
        require(runner.get("whole_chain_pq_qualified") is False and runner.get("production_qualified") is False,
                "runner improperly elevates qualification")
        require(canonical_sha(runner.get("runner_sha256")), "missing runner digest")
        head, tree = runner["head"], runner["tree"]
        actual = frozen_git(self.root, "rev-parse", "--verify", head + "^{commit}").decode().strip()
        actual_tree = frozen_git(self.root, "rev-parse", "--verify", head + "^{tree}").decode().strip()
        require(actual == head and actual_tree == tree, "runner commit/tree disagree with frozen Git objects")
        self.head, self.tree = head, tree
        current_head = frozen_git(self.root, "rev-parse", "HEAD").decode().strip()
        self.report.update(tested_commit=head, tested_tree=tree)
        return {"head": head, "tree": tree, "current_checkout_head": current_head,
                "current_checkout_is_tested_head": current_head == head,
                "runner_sha256": runner["runner_sha256"],
                "frozen_manifests_read_from_git_objects": True,
                "runner_record": digest_record(read_bytes(self.output / "runner.json"), self.output / "runner.json")}

    def manifests(self):
        core_name = "config/pon/pq-system-required-tests-v1.json"
        tls_name = "config/pon/pq-native-tls-required-tests-v1.json"
        witness_name = "config/pon/pq-native-tls-witness-required-tests-v1.json"
        core = decode_json(self.blob(core_name), core_name)
        tls = decode_json(self.blob(tls_name), tls_name)
        witness = decode_json(self.blob(witness_name), witness_name)
        for value, schema in ((core, "trnm-pq-system-required-tests-v1"),
                              (tls, "trnm-pq-native-tls-required-tests-v1"),
                              (witness, "trnm-pq-native-tls-witness-required-tests-v1")):
            require(value.get("schema") == schema, "unexpected frozen manifest schema: " + schema)
            require(value.get("whole_chain_quantum_security_qualified") is False, schema + ": PQ qualification must stay false")
        require(core.get("expected_meaningful_controls") == 52, "core manifest does not require 52 meaningful controls")
        require(core.get("original_business_budgets_changed") is False, "core manifest changes original budgets")
        require(tls.get("expected_controls") == {"lib": 13, "cli": 4, "feature-off": 1}, "TLS manifest control counts changed")
        require(witness.get("expected_controls") == {"cli": 5} and witness.get("harness") == "pq_tls_witness_cli",
                "Witness manifest harness/count changed")
        for value in (tls, witness):
            for flag in ("production_activation", "consensus_authority", "public_wan_accepted"):
                require(value.get(flag) is False, "frozen TLS manifest promotes " + flag)
        require(witness.get("whole_node_rollback_protection") is False, "Witness manifest promotes whole-node rollback protection")
        self.required = {
            "core": exact_names(core["tests"], 52, core_name),
            "tls_lib": exact_names(tls["scopes"]["lib"], 13, tls_name + " lib"),
            "tls_cli": exact_names(tls["scopes"]["cli"], 4, tls_name + " cli"),
            "feature_off": exact_names(tls["scopes"]["feature-off"], 1, tls_name + " feature-off"),
            "witness_cli": exact_names(witness["scopes"]["cli"], 5, witness_name),
            "migration_v6": sorted(MIGRATION),
        }
        require(not set(self.required["core"]) & set(self.required["tls_lib"]), "core and TLS lib scopes overlap")
        excluded = core.get("child_process_harnesses_not_counted")
        require(isinstance(excluded, list) and excluded, "missing explicit child harness exclusion")
        exact_names(excluded, len(excluded), core_name + " child exclusions")
        require(not set(excluded) & set(self.required["core"] + self.required["tls_lib"]), "child harness counted as a meaningful control")
        migration = self.blob("trillionnium/crates/trnm-pon-node/tests/pq_application_migration_v6.rs").decode()
        source_names = re.findall(r"#\[test\]\s*fn\s+([A-Za-z_][A-Za-z_0-9]*)\s*\(", migration)
        require(sorted(source_names) == self.required["migration_v6"], "frozen NPQ6 integration test roster changed")
        self.excluded = excluded
        return {"required": self.required, "child_process_harnesses_not_counted": excluded,
                "distinct_required_parent_lib_passes": 65, "separate_ordinary_binary_controls": 9,
                "separate_default_feature_controls": 4, "all_qualification_flags_remain_false": True}

    def receipt(self, label):
        path = self.output / (label + ".json")
        raw = read_bytes(path)
        value = decode_json(raw, str(path))
        require(value.get("schema") == "trnm-pq-native-command-v1", label + ": invalid recorder schema")
        require(value.get("whole_chain_quantum_security_qualified") is False, label + ": recorder promotes PQ qualification")
        status = value.get("status")
        require(status in ("running", "command_succeeded", "command_failed", "record_failed"), label + ": invalid recorder status")
        summary = {"status": "FAIL" if status in ("command_failed", "record_failed") else "PENDING", "recorder_status": status,
                   "receipt": digest_record(raw, path), "argv": value.get("argv"), "exit_code": value.get("exit_code")}
        self.report["commands"][label] = summary
        if status == "running":
            raise Pending(label + ": recorder is still running")
        if status == "record_failed":
            raise Invalid(label + ": recorder failed: " + str(value.get("error", "no error recorded")))
        if self.head is None:
            if self.report["checks"].get("frozen_source", {}).get("status") == "FAIL":
                raise Invalid(label + ": frozen source identity failed validation")
            raise Pending(label + ": frozen source identity not yet available")
        before, after = value.get("before"), value.get("after")
        require(isinstance(before, dict) and before == after, label + ": before/after source identity differs or is missing")
        require(before.get("schema") == "trnm-ci-source-v1" and before.get("kind") == "head", label + ": source is not exact head")
        require(before.get("candidate") == self.head and before.get("tested_commit") == self.head
                and before.get("tested_tree") == self.tree, label + ": recorded source differs from frozen head/tree")
        require(before.get("tracked_worktree_verified") is True and before.get("tests_executed_by_identity_check") is False,
                label + ": tracked raw-byte verification is missing or misrepresented")
        require(before.get("base") is None and before.get("prospective_merge") is None, label + ": unexpected merge-source claim")
        require(Path(value.get("cwd", "")).resolve() == self.root, label + ": command cwd differs from repository")
        require(value.get("log_file") == label + ".log", label + ": noncanonical log file")
        data = read_bytes(self.output / value["log_file"])
        require(value.get("log_sha256") == sha(data) and value.get("log_bytes") == len(data), label + ": raw log hash/size mismatch")
        text = data.decode("utf-8")
        require("\x00" not in text and "\x1b" not in text, label + ": log contains ambiguous terminal control bytes")
        argv = value.get("argv")
        require(isinstance(argv, list) and all(isinstance(v, str) for v in argv) and len(argv) > 2
                and argv[:2] == ["timeout", "1500"], label + ": command lacks the reviewed timeout/argv")
        require(type(value.get("exit_code")) is int, label + ": exit code missing or non-integer")
        require((status == "command_succeeded") == (value["exit_code"] == 0), label + ": status/exit contradiction")
        require(type(value.get("elapsed_ns")) is int and value["elapsed_ns"] >= 0, label + ": invalid elapsed time")
        require(isinstance(value.get("environment"), dict), label + ": environment is missing")
        self.receipts[label] = value
        self.logs[label] = text
        summary.update(status="PASS" if status == "command_succeeded" else "FAIL",
                       log=digest_record(data, self.output / value["log_file"]),
                       source_verified_before_and_after=True, elapsed_ns=value["elapsed_ns"])
        return summary

    def command(self, label, expected):
        if label not in self.receipts:
            previous = self.report["checks"].get("receipt:" + label, {})
            if previous.get("status") == "FAIL":
                raise Invalid(label + ": prerequisite receipt failed validation")
            raise Pending(label + ": complete validated command receipt unavailable")
        require(self.receipts[label]["argv"][2:] == expected, label + ": command differs from original reviewed targets/features")
        return self.logs[label]

    def hash_binding(self, label, paths, ordinary_node=False):
        before = read_json(self.output / (label + "-elf-before.json"))
        after = read_json(self.output / (label + "-elf-after.json"))
        require(isinstance(before, dict) and before and before == after, label + ": ELF hash records missing, empty, or changed")
        expected = set(paths)
        if ordinary_node:
            env = self.receipts[label + "-registry"]["environment"]
            target = env.get("CARGO_TARGET_DIR")
            require(isinstance(target, str) and Path(target).is_absolute(), label + ": absolute CARGO_TARGET_DIR is missing")
            expected.add(str(Path(target) / "debug/trnm-pon-node"))
            require(self.receipts[label]["environment"].get("CARGO_TARGET_DIR") == target,
                    label + ": execution changed CARGO_TARGET_DIR")
        require(set(before) == expected, label + ": ELF hash records do not exactly cover advertised harnesses and ordinary binary")
        for path, entry in before.items():
            require(Path(path).is_absolute() and isinstance(entry, dict)
                    and canonical_sha(entry.get("sha256")) and type(entry.get("bytes")) is int and entry["bytes"] > 0,
                    label + ": malformed ELF digest record")
        return {"before_equals_after": True, "artifacts": before,
                "ordinary_binary_separately_bound": ordinary_node,
                "current_files_rehashed": False,
                "reason_no_current_rehash": "Later Cargo feature selections may replace the ordinary Node binary; each execution uses its own before/after identity records."}

    def node(self):
        build = ["cargo", "test", *CARGO_COMMON, "-p", "trnm-pon-node", "--lib", "--all-features", "--no-run", "--message-format=json"]
        build_log = self.command("node-build", build)
        artifacts = []
        for line in build_log.splitlines():
            if not line.startswith("{"):
                continue
            item = decode_json(line, "node-build compiler message")
            if (item.get("reason") == "compiler-artifact" and item.get("target", {}).get("name") == "trnm_pon_node"
                    and item["target"].get("kind") == ["lib"] and item.get("executable")):
                artifacts.append(item)
        require(len(artifacts) == 1, "node-build: actual library test executable is not unique")
        artifact = artifacts[0]
        binary = artifact["executable"]
        require(Path(binary).is_absolute() and artifact.get("profile", {}).get("test") is True, "node-build: executable is not an absolute test-profile library artifact")
        require("pq-native-openssl" in artifact.get("features", []), "node-build: PQ native TLS feature not compiled")
        registry_log = self.command("node-registry", [binary, "--list"])
        registry = parse_registry(registry_log, "node-registry")
        full = self.command("node-full", ["cargo", "test", *CARGO_COMMON, "-p", "trnm-pon-node", "--lib", "--all-features",
                                          "--", "--show-output", "--test-threads=1"])
        harnesses = split_harnesses(full, "node-full")
        require(len(harnesses) == 1 and harnesses[0]["descriptor"] == "unittests src/lib.rs"
                and harnesses[0]["path"] == binary, "node-full: execution harness differs from the built/listed library ELF")
        before = read_json(self.output / "node-elf-before.json")
        after = read_json(self.output / "node-elf-after.json")
        require(before == after and before.get("path") == binary and before.get("target") == artifact["target"]
                and before.get("profile") == artifact["profile"] and canonical_sha(before.get("sha256"))
                and type(before.get("bytes")) is int and before["bytes"] > 0, "node-full: library ELF identity changed or is not bound to compiler artifact")
        result = parse_parent(harnesses[0]["body"], registry, "node-full parent library")
        require(hasattr(self, "required"), "required manifests were not validated")
        parent_pass = set(result["parent_passed_names"])
        inline_pass = set(result["inline_ok_names_in_parent_pass_roster"])
        controls = {}
        for scope in ("core", "tls_lib"):
            required = set(self.required[scope])
            missing = sorted(required - parent_pass)
            missing_inline = sorted(required - inline_pass)
            controls[scope] = {"expected": len(required), "parent_passes": len(required & parent_pass),
                               "missing_from_parent_passes": missing, "missing_inline_ok_corroboration": missing_inline,
                               "names": sorted(required), "status": "PASS" if not missing and not missing_inline else "FAIL"}
        result.update(status="PASS" if result["status"] == "PASS" and all(v["status"] == "PASS" for v in controls.values()) else "FAIL",
                      required_controls=controls, library_elf=before, library_elf_unchanged=True,
                      compiler_artifact_features=artifact["features"], cargo_harness_header_line=harnesses[0]["header_line"],
                      execution_body_line_offset=harnesses[0]["body_line_offset"],
                      child_process_harnesses_not_credited_as_required_controls=self.excluded,
                      other_harness_counts_added_to_library=False)
        return result

    def grouped(self, label, base_command, expected, ordinary_node=False):
        listed = self.command(label + "-registry", [*base_command, "--", "--list"])
        executed = self.command(label, [*base_command, "--", "--show-output", "--test-threads=1"])
        registries = split_harnesses(listed, label + "-registry")
        executions = split_harnesses(executed, label)
        identities = lambda seq: [(h["descriptor"], h["path"]) for h in seq]
        require(identities(registries) == identities(executions), label + ": registry/execution Cargo harness identities differ")
        expected_keys = {(v["descriptor"], v["stem"]): v for v in expected}
        require(len(expected_keys) == len(expected), label + ": duplicate expected harness")
        seen, harness_results = set(), []
        for listing, execution in zip(registries, executions):
            path = Path(listing["path"])
            match = re.fullmatch(r"(.+)-[0-9a-f]+", path.name)
            require(match is not None, label + ": noncanonical Cargo test executable name")
            key = (listing["descriptor"], match[1])
            require(key in expected_keys and key not in seen, label + ": unexpected or duplicate harness " + repr(key))
            seen.add(key)
            spec = expected_keys[key]
            registry = parse_registry(listing["body"], label + " registry " + listing["descriptor"])
            if spec.get("required_names") is not None:
                require(registry["names"] == sorted(spec["required_names"]), label + ": required registry mismatch for " + listing["descriptor"])
            require(registry["tests"] > 0 or spec["kind"] == "example",
                    label + ": substantive harness registered zero tests: " + listing["descriptor"])
            item = parse_parent(execution["body"], registry, label + " " + listing["descriptor"])
            if item["parent_ignored_names"]:
                item["status"] = "FAIL"
                item["required_scope_reason"] = "This separately required harness must not silently ignore registered controls."
            if spec.get("required_names") is not None and set(spec["required_names"]) != set(item["parent_passed_names"]):
                item["status"] = "FAIL"
            item.update(package=spec["package"], kind=spec["kind"], source_path=spec["source"],
                        descriptor=listing["descriptor"], executable=listing["path"],
                        registry_header_line=listing["header_line"], execution_header_line=execution["header_line"],
                        registry_body_line_offset=listing["body_line_offset"], execution_body_line_offset=execution["body_line_offset"])
            if registry["tests"] == 0:
                item["zero_harness_explanation"] = "Cargo --all-targets built and ran this example harness with zero registered tests; it contributes no behavioral test passes."
            harness_results.append(item)
        require(seen == set(expected_keys), label + ": missing expected Cargo harnesses: " + repr(sorted(set(expected_keys) - seen)))
        hashes = self.hash_binding(label, [h["path"] for h in registries], ordinary_node)
        return {"status": "PASS" if all(h["status"] == "PASS" for h in harness_results) else "FAIL",
                "harnesses": harness_results, "elf_bindings": hashes, "harnesses_counted_independently": True,
                "counts_added_to_node_library": False, "doc_tests_executed": False,
                "doc_tests_status": "NOT_EXECUTED", "doc_tests_reason": "No --doc command is in the reviewed native phase."}

    def named_groups(self, tls):
        if not hasattr(self, "required"):
            if self.report["checks"].get("frozen_required_manifests", {}).get("status") == "FAIL":
                raise Invalid("required manifests failed validation")
            raise Pending("required manifests not yet available")
        if tls:
            label = "tls-cli-and-witness"
            command = ["cargo", "test", *CARGO_COMMON, "-p", "trnm-pon-node", "--all-features", "--test", "pq_tls_cli", "--test", "pq_tls_witness_cli"]
            names = [("pq_tls_cli", "tls_cli"), ("pq_tls_witness_cli", "witness_cli")]
        else:
            label = "migration-v6-and-feature-off"
            command = ["cargo", "test", *CARGO_COMMON, "-p", "trnm-pon-node", "--test", "pq_application_migration_v6", "--test", "pq_tls_feature_gate"]
            names = [("pq_application_migration_v6", "migration_v6"), ("pq_tls_feature_gate", "feature_off")]
        expected = []
        for name, scope in names:
            source = f"trillionnium/crates/trnm-pon-node/tests/{name}.rs"
            self.blob(source)
            expected.append({"descriptor": f"tests/{name}.rs", "stem": name, "package": "trnm-pon-node", "kind": "integration",
                             "source": source, "required_names": self.required[scope]})
        return self.grouped(label, command, expected, ordinary_node=True)

    def checkpoint_inventory(self):
        expected = []
        for package in ("trnm-checkpoint-store", "trnm-release-bundle"):
            prefix = "trillionnium/crates/" + package + "/"
            manifest = tomllib.loads(self.blob(prefix + "Cargo.toml").decode())
            require(manifest.get("package", {}).get("name") == package, "package name changed: " + package)
            require(all(manifest["package"].get(flag, True) is True for flag in ("autotests", "autoexamples", "autobenches")),
                    package + ": automatic target discovery disabled")
            require(not any(manifest.get(k) for k in ("lib", "test", "example", "bench")), package + ": custom target metadata needs explicit reader review")
            sources = frozen_git(self.root, "ls-tree", "-r", "--name-only", self.head, "--", prefix).decode().splitlines()
            require(prefix + "src/lib.rs" in sources, package + ": missing default library target")
            targets = [("src/lib.rs", "unittests", package.replace("-", "_"), "lib")]
            bins = manifest.get("bin", [])
            if package == "trnm-checkpoint-store":
                require(bins == [{"name": "trnm-external-node-checkpoint-v2", "path": "src/main.rs"}], package + ": binary target metadata changed")
                targets.append(("src/main.rs", "unittests", "trnm_external_node_checkpoint_v2", "bin"))
            else:
                require(not bins and prefix + "src/main.rs" not in sources, package + ": unexpected binary target")
            for source in sources:
                relative = source[len(prefix):]
                require(not relative.startswith(("src/bin/", "benches/")), package + ": new binary/benchmark target requires explicit review")
                if relative.startswith(("tests/", "examples/")) and relative.endswith(".rs"):
                    require(relative.count("/") == 1, package + ": nested test/example source needs explicit review")
                    is_example = relative.startswith("examples/")
                    targets.append((relative, "unittests" if is_example else "", Path(relative).stem.replace("-", "_"), "example" if is_example else "integration"))
            for source, prefix_label, stem, kind in targets:
                self.blob(prefix + source)
                expected.append({"descriptor": (prefix_label + " " + source).strip(), "stem": stem,
                                 "package": package, "kind": kind, "source": prefix + source})
        return expected

    def checkpoint(self):
        return self.grouped("checkpoint-release", ["cargo", "test", *CARGO_COMMON, "-p", "trnm-checkpoint-store", "-p", "trnm-release-bundle",
                            "--all-targets", "--no-fail-fast"], self.checkpoint_inventory())

    def ancillary_commands(self):
        self.command("compiler", ["rustc", "-Vv"])
        require(re.search(r"^rustc \d+\.\d+", self.logs["compiler"], re.MULTILINE), "compiler version transcript missing")
        if "provider-version" not in self.receipts:
            raise Pending("provider-version receipt unavailable")
        provider = self.receipts["provider-version"]["environment"].get("TRNM_PQ_OPENSSL")
        require(isinstance(provider, str) and Path(provider).is_absolute(), "absolute provider executable is missing")
        self.command("provider-version", [provider, "version"])
        require(re.search(r"^OpenSSL \d+\.\d+", self.logs["provider-version"], re.MULTILINE), "provider version transcript missing")
        if "sqlite-build-requalification" not in self.receipts:
            raise Pending("sqlite-build-requalification receipt unavailable")
        command = self.receipts["sqlite-build-requalification"]["argv"][2:]
        require(len(command) == 10 and command[:2] == ["python3", "scripts/ci/check_sqlite_build_requalification.py"]
                and command[2:6] == ["--output", str(self.output / "sqlite-requalification"), "--target", str(self.output / "sqlite-target")]
                and command[6] == "--rustc" and command[8] == "--cargo" and Path(command[7]).is_absolute()
                and Path(command[9]) == Path(command[7]).with_name("cargo"), "SQLite requalification command differs from the reviewed command")
        self.command("strict-clippy", ["cargo", "clippy", *CARGO_COMMON, "--workspace", "--all-targets", "--all-features", "--", "-D", "warnings"])
        return {"scope": "exact command receipt/hash/exit verification; these are not Node library tests",
                "compiler_version": self.logs["compiler"].strip(), "provider_version": self.logs["provider-version"].strip()}

    def final_manifest(self):
        value = read_json(self.output / "result.json")
        if self.head is None:
            if self.report["checks"].get("frozen_source", {}).get("status") == "FAIL":
                raise Invalid("final manifest: frozen source identity failed validation")
            raise Pending("final manifest: frozen source identity not yet available")
        require(value.get("phase") == "native" and value.get("head") == self.head and value.get("tree") == self.tree,
                "final runner source/phase differs")
        require(value.get("planned_commands") == PLANNED, "final runner plan differs")
        for flag in ("whole_chain_pq_qualified", "public_wan_qualified", "production_activation"):
            require(value.get(flag) is False, "final runner promotes " + flag)
        require(value.get("native_execution_readback_required") is True, "final runner bypasses native readback")
        commands = value.get("commands")
        require(isinstance(commands, list) and all(isinstance(c, dict) for c in commands), "final command records missing")
        labels = [c.get("label") for c in commands]
        require(len(set(labels)) == len(labels) and set(labels) <= set(PLANNED), "final command set has duplicates or unexpected entries")
        missing = sorted(set(PLANNED) - set(labels))
        require(value.get("not_executed") == missing, "final not_executed is inconsistent")
        failed = []
        for entry in commands:
            label = entry["label"]
            if label not in self.receipts:
                if self.report["checks"].get("receipt:" + label, {}).get("status") == "FAIL":
                    raise Invalid(label + ": final manifest points to an invalid receipt")
                raise Pending(label + ": final manifest lacks complete validated command evidence")
            receipt = self.receipts[label]
            require(entry.get("receipt_sha256") == sha(read_bytes(self.output / (label + ".json"))), label + ": final receipt digest differs")
            require(entry.get("command") == receipt["argv"][2:] and entry.get("cap_seconds") == 1500,
                    label + ": final command argv differs from receipt")
            require(entry.get("status") == receipt["status"] and entry.get("command_exit") == receipt["exit_code"], label + ": final status differs from receipt")
            require(type(entry.get("recorder_exit")) is int and entry.get("execution_readback_ok") is True,
                    label + ": final recorder/readback status absent or invalid")
            if receipt["status"] != "command_succeeded" or entry["recorder_exit"] != 0:
                failed.append(label)
        all_ok = not missing and not failed and len(commands) == len(PLANNED)
        require(value.get("all_commands_succeeded") is all_ok, "final all_commands_succeeded contradicts its command records")
        require(read_json(self.output / "progress.json") == commands, "progress and final command records disagree")
        return {"status": "PASS" if all_ok else "FAIL" if failed else "PENDING",
                "planned_commands": PLANNED, "recorded_commands": labels, "not_executed": missing,
                "failed_commands": failed, "all_commands_succeeded": all_ok}

    def read(self):
        self.check("frozen_source", self.identity)
        self.check("frozen_required_manifests", self.manifests)
        for label in PLANNED:
            result = self.check("receipt:" + label, lambda label=label: self.receipt(label))
            if label not in self.report["commands"]:
                self.report["commands"][label] = result
        self.check("node_library", self.node)
        self.check("tls_cli_and_witness", lambda: self.named_groups(True))
        self.check("migration_v6_and_feature_off", lambda: self.named_groups(False))
        self.check("checkpoint_and_release", self.checkpoint)
        self.check("ancillary_command_shapes", self.ancillary_commands)
        self.check("final_runner_manifest", self.final_manifest)
        self.report["frozen_source_files"] = self.source_files
        statuses = Counter(v["status"] for v in self.report["checks"].values())
        known_failures = sorted(label for label, v in self.report["commands"].items()
                                if v.get("recorder_status") in ("command_failed", "record_failed"))
        status = "FAIL" if statuses["FAIL"] or known_failures else "PENDING" if statuses["PENDING"] else "PASS"
        self.report.update(status=status, check_status_counts=dict(statuses),
                           known_failed_commands=known_failures,
                           complete_native_readback_passed=status == "PASS",
                           native_readback_does_not_upgrade_hold=True)
        return self.report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--native-output", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    destination = args.output.absolute()
    require(not destination.resolve().is_relative_to(root), "readback output must stay outside the frozen repository")
    require(not destination.exists(), "readback output already exists; use a new path to preserve prior observations")
    reader = Reader(root, args.native_output)
    result = reader.read()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "output": str(destination),
                      "tested_commit": result.get("tested_commit"),
                      "check_status_counts": result["check_status_counts"], **FALSE_FLAGS}, sort_keys=True))
    return {"PASS": 0, "FAIL": 1, "PENDING": 2}[result["status"]]


if __name__ == "__main__":
    raise SystemExit(main())
