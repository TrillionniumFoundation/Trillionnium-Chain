#!/usr/bin/env python3
"""Copy a closed C1 cache without shared inodes, then run exact-source gates."""
import argparse
from contextlib import ExitStack
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import time

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
REPO = ROOT / 'integration-repo'
C1 = 'cb557c5e59b00ba7c6b1d40f78fbe51031a26f11'
Q = ROOT / 'clean-C1-build-qualification-01/qualification.json'
QSHA = '5b1243d0b2b623041c1a1eba1f6043c59d20e15c2b686ada2f24d179da8e84dc'
ROLES = {
    'backend': {'source_target': ROOT / 'target-w1-host-v2-integration', 'binary_roles': ('runner',),
                'cpus': {10, 11}, 'gate': 'run_backend.py',
                'gate_sha256': '409635b4757670904b1c504c61cd7f732e9b860199dcb80dc55432349380e256'},
    'native': {'source_target': ROOT / 'target-native-integration', 'binary_roles': ('native_winner', 'verifier'),
               'cpus': {22, 23}, 'gate': 'run_native_verifier.py',
               'gate_sha256': '151ff02dacb836d965f6c8fad2d4cf2e793fa112c5632557c24189ee834b05b1'},
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    path = Path(path); before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'ordinary pinned file required')
    digest = hashlib.sha256()
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        opened = os.fstat(stream.fileno())
        require((opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino), 'pin replaced before read')
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    after = path.lstat()
    require(all(getattr(before, k) == getattr(after, k) for k in
                ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')), 'pin changed while read')
    return {'path': str(path), 'bytes': before.st_size, 'sha256': digest.hexdigest()}


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)
    return pin(path)


def snapshot(root):
    require(root.is_dir() and not root.is_symlink(), 'real cache root')
    rows = {}
    stack = [root]
    while stack:
        directory = stack.pop()
        with os.scandir(directory) as scan:
            children = sorted(scan, key=lambda entry: entry.name)
        for entry in children:
            path = Path(entry.path); observed = path.lstat(); relative = str(path.relative_to(root))
            row = {'mode': observed.st_mode, 'device': observed.st_dev, 'inode': observed.st_ino,
                   'bytes': observed.st_size, 'mtime_ns': observed.st_mtime_ns, 'ctime_ns': observed.st_ctime_ns}
            if stat.S_ISLNK(observed.st_mode):
                target = os.readlink(path)
                require(not Path(target).is_absolute() and path.resolve().is_relative_to(root),
                        'cache symlink escapes isolated target')
                row.update(kind='symlink', target=target)
            elif stat.S_ISREG(observed.st_mode): row['kind'] = 'file'
            elif stat.S_ISDIR(observed.st_mode): row['kind'] = 'directory'; stack.append(path)
            else: raise ValueError('special cache entry refused')
            rows[relative] = row
            require(len(rows) <= 100000, 'bounded cache inventory')
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--role', choices=sorted(ROLES), required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--expected-tree', required=True)
    parser.add_argument('--attempt', required=True)
    args = parser.parse_args()
    require(re.fullmatch('[0-9a-f]{40}', args.expected_head) and args.expected_head != C1
            and re.fullmatch('[0-9a-f]{40}', args.expected_tree), 'explicit new actual commit/tree required')
    require(re.fullmatch('[0-9]{2}', args.attempt), 'unique two-digit attempt')
    selected = ROLES[args.role]
    os.sched_setaffinity(0, selected['cpus'])
    require(os.sched_getaffinity(0) == selected['cpus'], 'actual two requested CPU IDs')
    tag = args.expected_head[:12] + '-' + args.attempt
    target = ROOT / ('target-' + args.role + '-exact-' + tag)
    gate_out = (ROOT / 'backend-validation' / ('exact-source-' + tag) if args.role == 'backend'
                else ROOT / ('clean-exact-native-verifier-' + tag))
    out = ROOT / 'exact-source-cache-setups' / (args.role + '-' + tag)
    require(not out.exists() and not out.is_symlink() and not target.exists() and not target.is_symlink()
            and not gate_out.exists() and not gate_out.is_symlink(), 'new external output/cache only; no retry overwrite')
    out.parent.mkdir(exist_ok=True); out.mkdir()
    report = {'schema': 'TRNM-W1-EXACT-SOURCE-CACHE-SETUP1', 'role': args.role,
              'source_commit': args.expected_head, 'source_tree': args.expected_tree,
              'source_target': str(selected['source_target']), 'destination_target': str(target),
              'gate_output': str(gate_out), 'cache_setup_complete': False, 'errors': [], 'commands': [],
              'fresh_cargo_target': False, 'copied_cache_from_C1': True,
              'independent_reproducible_build_established': False,
              'actual_reflink_vs_byte_copy_split': 'not observed; requested reflink with normal byte-copy fallback',
              'fresh_proof_generations': 0, 'started_monotonic_ns': time.monotonic_ns(),
              'adapter': pin(__file__)}
    save(out / 'declaration.json', report)
    try:
        member = Path('/proc/self/cgroup').read_text().strip()
        require(member.startswith('0::/') and '\n' not in member, 'actual cgroup-v2 identity')
        group = Path('/sys/fs/cgroup') / member[3:].lstrip('/')
        require(group.name.startswith('hepta-runtime-job-') and group.name.endswith('.service'), 'owned Hepta gate job')
        controls = {name: (group / name).read_text() for name in ('cpu.max', 'memory.max', 'cgroup.events')}
        quota, period = controls['cpu.max'].split()
        require(quota != 'max' and int(quota) == 2 * int(period), 'actual 200% CPU gate quota')
        require(controls['memory.max'].strip() == str(8589934592), 'actual eight-GiB gate memory cap')
        report['resource_observation'] = {'membership_raw': member, 'controls_raw': controls,
            'affinity': sorted(os.sched_getaffinity(0)), 'complete_process_tree_billing': False}

        def command(label, argv, timeout=180):
            stdout, stderr = out / (label + '.stdout'), out / (label + '.stderr')
            row = {'label': label, 'argv': argv, 'cwd': str(REPO), 'exit': None, 'error': None,
                   'started_monotonic_ns': time.monotonic_ns(), 'timeout_seconds': timeout}
            caught = None
            with stdout.open('xb') as so, stderr.open('xb') as se:
                try:
                    completed = subprocess.run(argv, cwd=REPO, stdin=subprocess.DEVNULL, stdout=so, stderr=se,
                                               timeout=timeout, check=False)
                    row['exit'] = completed.returncode
                except BaseException as exc:
                    caught = exc; row['error'] = {'type': type(exc).__name__, 'message': str(exc)}
                finally:
                    so.flush(); os.fsync(so.fileno()); se.flush(); os.fsync(se.fileno())
            row.update(stdout=pin(stdout), stderr=pin(stderr), finished_monotonic_ns=time.monotonic_ns())
            report['commands'].append(row)
            save(out / (label + '.command.json'), row)
            if caught is not None: raise caught
            require(row['exit'] == 0, label + ' failed')
            return stdout

        command('preflight', ['/usr/bin/bash', 'scripts/project-preflight.sh', '--dev'])
        command('source-before', ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                                 '--expected-head', args.expected_head, '--output', str(out / 'source-before.json')])
        source_before = json.loads((out / 'source-before.json').read_bytes())
        require(source_before['tested_commit'] == args.expected_head and source_before['tested_tree'] == args.expected_tree
                and source_before['tracked_worktree_verified'] is True, 'actual exact clean source')
        report['source_before'] = pin(out / 'source-before.json')
        require(pin(Q)['sha256'] == QSHA, 'original complete C1 qualification changed')
        q = json.loads(Q.read_bytes())
        require(q['qualification_complete'] is True and q['source_commit'] == C1, 'actual qualified C1 predecessor')
        gate = Path(__file__).resolve().parent / selected['gate']
        require(pin(gate)['sha256'] == selected['gate_sha256'], 'reviewed gate bytes changed')
        report['gate'] = pin(gate); report['original_C1_qualification'] = pin(Q)
        source = selected['source_target']
        originals = {}
        for role in selected['binary_roles']:
            row = q['binaries'][role]
            expected = {key: row[key] for key in ('path', 'bytes', 'sha256')}
            require(source in Path(row['path']).parents and pin(row['path']) == expected, 'original C1 ELF changed')
            originals[role] = expected
        report['original_C1_binaries'] = originals
        with ExitStack() as held:
            locks = [source / profile / '.cargo-lock' for profile in ('debug', 'release')
                     if (source / profile / '.cargo-lock').exists()]
            require(locks, 'actual original Cargo profile lock required')
            for lock in locks:
                require(lock.is_file() and not lock.is_symlink(), 'ordinary Cargo lock')
                stream = held.enter_context(lock.open('rb'))
                fcntl.flock(stream, fcntl.LOCK_SH | fcntl.LOCK_NB)
            report['source_read_locks'] = [str(path) for path in locks]
            before = snapshot(source)
            amount = sum(row['bytes'] for row in before.values() if row['kind'] == 'file')
            filesystem = os.statvfs(ROOT); available = filesystem.f_bavail * filesystem.f_frsize
            require(amount <= 32 * 1024**3 and available >= amount + 1024**3, 'bounded full-copy disk budget')
            save(out / 'source-cache-before.json', before)
            target.mkdir()
            command('copy-cache', ['/usr/bin/cp', '--reflink=auto', '--recursive', '--no-dereference',
                '--preserve=mode,timestamps', str(source) + '/.', str(target)], 600)
            after, copied = snapshot(source), snapshot(target)
            require(before == after and set(before) == set(copied), 'original cache changed or copy incomplete')
            source_inodes = {(row['device'], row['inode']) for row in before.values() if row['kind'] == 'file'}
            for relative, old in before.items():
                new = copied[relative]
                require(old['kind'] == new['kind'], 'copy kind changed')
                if old['kind'] == 'file':
                    require((new['device'], new['inode']) not in source_inodes and new['bytes'] == old['bytes'],
                            'destination shares original regular inode or size changed')
                elif old['kind'] == 'symlink': require(old['target'] == new['target'], 'relative symlink changed')
            copied_roles = {}
            for role, old in originals.items():
                require(pin(old['path']) == old, 'original C1 ELF changed during copy')
                new = pin(target / Path(old['path']).relative_to(source))
                require(new['sha256'] == old['sha256'] and new['bytes'] == old['bytes'], 'copied C1 ELF bytes differ')
                copied_roles[role] = new
            save(out / 'destination-cache.json', copied)
            report.update(shared_original_regular_inodes=0, original_cache_snapshot_unchanged=True,
                copied_C1_binaries=copied_roles, cache_logical_bytes=amount, available_bytes_before=available,
                new_target_directory_created=True, cache_regular_files=sum(r['kind'] == 'file' for r in before.values()))
        command('source-after-copy', ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
             '--expected-head', args.expected_head, '--output', str(out / 'source-after-copy.json')])
        require(pin(out / 'source-before.json')['sha256'] == pin(out / 'source-after-copy.json')['sha256'],
                'source changed while copying cache')
        require(pin(gate)['sha256'] == selected['gate_sha256'], 'reviewed gate changed before handoff')
        report['source_after_copy'] = pin(out / 'source-after-copy.json')
        report['cache_setup_complete'] = True
    except BaseException as exc:
        report['errors'].append({'type': type(exc).__name__, 'message': str(exc)})
    report['finished_monotonic_ns'] = time.monotonic_ns()
    manifest = save(out / 'manifest.json', report)
    print(json.dumps({'cache_setup_complete': report['cache_setup_complete'], 'manifest': manifest,
                      'errors': report['errors']}), flush=True)
    if not report['cache_setup_complete']: return 1
    argv = ['/usr/bin/python3', '-B', str(gate), '--expected-head', args.expected_head,
            '--expected-tree', args.expected_tree, '--attempt', args.attempt, '--target-dir', str(target),
            '--output-dir', str(gate_out), '--cache-setup', manifest['path'], '--cache-setup-sha256', manifest['sha256']]
    save(out / 'gate-exec-intent.json', {'argv': argv, 'same_PID_exec': True,
         'original_C1_target_not_used_for_build': True, 'gate_outcome': 'NOT_YET_OBSERVED'})
    os.execv(argv[0], argv)


if __name__ == '__main__':
    raise SystemExit(main())
