import sys,json,pathlib,subprocess,hashlib,os,stat,time,collections
root=pathlib.Path("/home/qian-qi/work/chain-root-operation-recovered-20261112-df05")
obs=pathlib.Path("/home/qian-qi/work/chain-root-reconstruction-20261112-df05-v2")
old=pathlib.Path("/home/qian-qi/work/chain-root-reconstruction-20261112-df05")
head="92934b64f80ee9b20bcc070a08ca0966b7c5741d"
tree="b1882c2e46827abfd1db5f8744be043d5776df6d"
branch="fix/chain-root-operation-recovered-20261112-df05"
key="chain-root-recovered-df05-index-materialization-v2"
stage="initialization"
commands=[]
env=os.environ.copy()
env["GIT_NO_LAZY_FETCH"]="1"
env["PYTHONPYCACHEPREFIX"]=str(obs/"pycache")
env["PYTHONDONTWRITEBYTECODE"]="1"
git_repair=["git","-c","core.sparseCheckout=false","-c","core.sparseCheckoutCone=false","-c","core.ignorestat=false"]
def make_json(path,value):
    with path.open("x",encoding="utf-8") as f:json.dump(value,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
def atomic_json(path,value):
    pending=path.with_name(path.name+".pending")
    make_json(pending,value);os.link(pending,path);pending.unlink()
    fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
def run(name,argv,input=None,accepted=(0,)):
    make_json(obs/(name+".command.json"),{"argv":argv,"cwd":str(root),"accepted_exit_codes":list(accepted),"input_nul_paths":None if input is None else {"bytes":len(input),"sha256":hashlib.sha256(input).hexdigest()},"environment_overrides":{"GIT_NO_LAZY_FETCH":"1","PYTHONPYCACHEPREFIX":env["PYTHONPYCACHEPREFIX"],"PYTHONDONTWRITEBYTECODE":"1"}})
    if input is not None:(obs/(name+".stdin.nul")).write_bytes(input)
    started=time.time()
    with (obs/(name+".stdout")).open("xb") as out,(obs/(name+".stderr")).open("xb") as err:
        result=subprocess.run(argv,cwd=root,env=env,input=input,stdout=out,stderr=err)
        out.flush();err.flush();os.fsync(out.fileno());os.fsync(err.fileno())
    stdout=(obs/(name+".stdout")).read_bytes();stderr=(obs/(name+".stderr")).read_bytes()
    record={"name":name,"exit_code":result.returncode,"accepted":result.returncode in accepted,"duration_seconds":time.time()-started,"stdout_bytes":len(stdout),"stdout_sha256":hashlib.sha256(stdout).hexdigest(),"stderr_bytes":len(stderr),"stderr_sha256":hashlib.sha256(stderr).hexdigest()}
    make_json(obs/(name+".result.json"),record);commands.append(record)
    print(json.dumps({**record,"stdout_tail":stdout[-400:].decode(errors="replace"),"stderr_tail":stderr[-500:].decode(errors="replace")}),flush=True)
    if result.returncode not in accepted:raise RuntimeError("command failed: "+name)
    return stdout
def identity(prefix):
    assert run(prefix+"-head",["git","rev-parse","HEAD"]).decode().strip()==head
    assert run(prefix+"-tree",["git","rev-parse","HEAD^{tree}"]).decode().strip()==tree
    assert run(prefix+"-branch",["git","branch","--show-current"]).decode().strip()==branch
def flags(raw):
    entries=[v for v in raw.split(b"\0") if v]
    return {"entries":len(entries),"tags":dict(collections.Counter(v[:1].decode("ascii") for v in entries)),"hidden_entries":sum(v[:1].islower() or v[:1]==b"S" for v in entries)}
try:
    obs.mkdir(exist_ok=False)
    prior=(old/"FAILED.json").read_bytes()
    prior_sha=hashlib.sha256(prior).hexdigest()
    prior_failure=json.loads(prior)
    assert prior_failure["stage"]=="complete-original-physical-source-verification"
    make_json(obs/"PRIOR_FAILURE_BINDING.json",{"job_id":"1a1ced39a5a-2564-1878","path":str(old/"FAILED.json"),"sha256":prior_sha,"preserved_without_rewrite":True,"repair_operation_key":key,"reason":"Remove worktree-local hidden index flags and materialize missing tracked paths; keep source commit/tree unchanged"})
    stage="diagnose-new-worktree"
    run("preflight-before",["bash","scripts/project-preflight.sh"])
    identity("before")
    assert run("before-index-tree",["git","write-tree"]).decode().strip()==tree
    before_raw=run("before-index-flags",["git","ls-files","-v","-z"])
    before_flags=flags(before_raw)
    make_json(obs/"INDEX_FLAGS_BEFORE.json",before_flags)
    for i,option in enumerate(["core.sparseCheckout","core.sparseCheckoutCone","core.ignorestat","index.sparse","extensions.worktreeConfig"]):
        run("selective-config-"+str(i),["git","config","--show-origin","--get-all",option],accepted=(0,1))
    paths_raw=run("all-tracked-nul-paths",["git","ls-files","-z"])
    paths=[p for p in paths_raw.split(b"\0") if p]
    assert len(paths)==len(set(paths)) and len(paths)==28777
    for p in paths:
        assert not p.startswith(b"/") and all(c not in (b"",b".",b"..") for c in p.split(b"/"))
    stage="rebuild-only-this-index-with-ephemeral-git-overrides"
    run("read-committed-tree-into-this-index",git_repair+["read-tree","--reset",head])
    run("clear-skip-worktree",git_repair+["update-index","--no-skip-worktree","-z","--stdin"],input=paths_raw)
    run("clear-assume-unchanged",git_repair+["update-index","--no-assume-unchanged","-z","--stdin"],input=paths_raw)
    assert run("index-tree-after-flags",["git","write-tree"]).decode().strip()==tree
    stage="materialize-only-physically-missing-tracked-paths"
    root_bytes=os.fsencode(root)
    missing=[]
    for p in paths:
        physical=root_bytes+b"/"+p
        try:os.lstat(physical)
        except FileNotFoundError:
            # Refuse a substituted symlink parent before allowing Git to create.
            parent=root_bytes
            for component in p.split(b"/")[:-1]:
                parent+=b"/"+component
                try:s=os.lstat(parent)
                except FileNotFoundError:break
                if not stat.S_ISDIR(s.st_mode):raise RuntimeError("non-directory tracked parent: "+os.fsdecode(p))
            missing.append(p)
    missing_raw=b"".join(p+b"\0" for p in missing)
    (obs/"missing-tracked-paths.nul").write_bytes(missing_raw)
    make_json(obs/"MATERIALIZATION.json",{"tracked_paths":len(paths),"missing_paths":len(missing),"missing_paths_sha256":hashlib.sha256(missing_raw).hexdigest(),"existing_worktree_paths_overwritten":False,"shared_configuration_modified":False,"original_source_commit_unchanged":True})
    if missing:
        run("checkout-only-missing-paths",git_repair+["checkout-index","-z","--stdin"],input=missing_raw)
    run("refresh-real-index-stat",git_repair+["update-index","--really-refresh"])
    run("clear-skip-after-refresh",git_repair+["update-index","--no-skip-worktree","-z","--stdin"],input=paths_raw)
    run("clear-assume-after-refresh",git_repair+["update-index","--no-assume-unchanged","-z","--stdin"],input=paths_raw)
    after_raw=run("plain-git-flags-after",["git","ls-files","-v","-z"])
    after_flags=flags(after_raw)
    make_json(obs/"INDEX_FLAGS_AFTER.json",after_flags)
    assert after_flags["hidden_entries"]==0,"hidden flags remain"
    stage="original-full-physical-source-verification-without-repair-overrides"
    physical=json.loads(run("verify-original-complete-source",["/usr/bin/python3","-B","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",head,"--output",str(obs/"VERIFIED_PHYSICAL_SOURCE.json")]))
    assert physical["tested_commit"]==head and physical["tested_tree"]==tree and physical["tracked_worktree_verified"] is True
    assert physical["tracked_entries"]==28777 and physical["tracked_bytes"]==2597032120
    identity("after")
    assert not run("final-clean",["git","status","--porcelain=v1","--untracked-files=all"]).strip()
    run("final-preflight",["bash","scripts/project-preflight.sh"])
    final_flags=flags(run("final-plain-index-flags",["git","ls-files","-v","-z"]))
    assert final_flags["hidden_entries"]==0
    assert hashlib.sha256((old/"FAILED.json").read_bytes()).hexdigest()==prior_sha
    frozen={"head":head,"tree":tree,"branch":branch,"worktree":str(root),"expected_cloud_source":"87bf6bb07c4ccdd75741cfb79c7447d8d8c54758","same_full_tree":True}
    make_json(obs/"REPAIR_REPORT.json",{"status":"PASS_PHYSICAL_MATERIALIZATION_REPAIR","operation_key":key,"frozen":frozen,"prior_failure_sha256":prior_sha,"before_flags":before_flags,"after_flags":final_flags,"missing_paths_materialized":len(missing),"source_commit_and_tree_unchanged":True,"shared_configuration_modified":False,"original_physical_verifier_unmodified":True,"physical_source":physical,"commands":commands,"rust_tests_executed":False,"production_activation":False})
    stage="publish-frozen-v2"
    atomic_json(obs/"FROZEN.json",frozen)
    print(json.dumps({"status":"FROZEN","sentinel":str(obs/"FROZEN.json"),**frozen}),flush=True)
except BaseException as error:
    failure={"stage":stage,"error_type":type(error).__name__,"error":str(error),"operation_key":key,"head":head,"expected_tree":tree,"commands":commands,"rust_tests_executed":False,"old_failure_preserved":True,"shared_configuration_modified":False}
    if obs.exists() and not (obs/"FROZEN.json").exists() and not (obs/"FAILED.json").exists():atomic_json(obs/"FAILED.json",failure)
    print(json.dumps({"status":"FAILED",**failure}),file=sys.stderr,flush=True)
    raise
