import json,hashlib
from pathlib import Path
b=Path('/home/qian-qi/work');p=b/'w1-baseline-9082-campaign-165d/manifest.json'
a=p.stat();raw=p.read_bytes();z=p.stat();assert (a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(z.st_ino,z.st_size,z.st_mtime_ns,z.st_ctime_ns)
m=json.loads(raw);assert m['expected_commit']=='165d286b687e0a73d7fe68148d2179274fc0c0b8' and m['result']=='COMPLETE_COMPONENT_OBSERVATION';assert m['source_before']==m['source_after']
r={'scope':'derived read-only component measurements; no security qualification','source':m['source_before'],'manifest_bytes':len(raw),'manifest_sha256':hashlib.sha256(raw).hexdigest(),'binary_sha256':m['binary_sha256'],'host':m['host'],'cells':[]}
for s in m['shards']:
 q=s['reader'];assert q['status']=='COMPONENT_OBSERVATION'
 c={'target':s['target_index'],'horizon':s['horizon'],'counts':q['counts'],'arms':[]}
 for a in q['arms']:
  c['arms'].append({'name':a['name'],'wins':a['accepted_winners'],'attempts':a['attempts'],'misses':a['misses'],'materialized':a['materialized'],'exhausted':a['exhausted'],'producer':a['producer_total'],'setup':a['paid_setup'],'samples_cpu_ns':[x['producer_total']['cpu_ns'] for x in a['samples']],'samples_wall_ns':[x['producer_total']['wall_ns'] for x in a['samples']],'samples_winners':[x['accepted_winners'] for x in a['samples']]})
 r['cells'].append(c)
v=b/'w1-baseline-9082-validation-165d/checks-phase.json'
if v.is_file():
 try:
  q=json.loads(v.read_bytes());r['checks']={'success':q['success'],'commands':[{'command':x['command'],'exit_code':x['exit_code'],'timed_out':x['timed_out']} for x in q['commands']],'markdown_links_passed':q['markdown_links_passed']}
 except Exception as e:r['checks']={'read_error':str(e)}
else:r['checks']={'complete':False}
print(json.dumps(r,separators=(',',':')),flush=True)
