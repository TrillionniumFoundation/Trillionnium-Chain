from pathlib import Path
import datetime,hashlib,json,os,re,shutil,signal,subprocess,sys,time
base=Path('/home/qian-qi/chain-hepta-481716-native-check');source=base/'source';target=base/'retained-test-target-01'
package=sys.argv[1]
allowed={'trnm-data-availability','trnm-crypto-primitives','trnm-pon-node','trnm-protocol','trnm-release-bundle'}
assert package in allowed
out=base/'m5'/('direct-'+package+'-01');out.mkdir()
head='3ad605ecdac4b3b123dff83c1cb7458430acd776';tree='fbbb4dca143775bae75ea825ff502f368e122ebb'
def save(name,obj):(out/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def snapshot():
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=source,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=source,text=True).splitlines(),'cargo_lock_sha256':hashlib.sha256((source/'trillionnium/Cargo.lock').read_bytes()).hexdigest()}
def identity(path):
 before=path.stat();h=hashlib.sha256()
 assert path.resolve().is_relative_to(target.resolve()) and path.is_file() and not path.is_symlink()
 with path.open('rb') as f:
  assert f.read(4)==b'\x7fELF';f.seek(0)
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 after=path.stat();assert (before.st_size,before.st_mtime_ns,before.st_ino)==(after.st_size,after.st_mtime_ns,after.st_ino)
 return {'path':str(path),'bytes':after.st_size,'sha256':h.hexdigest(),'cfg_test':True,'cargo_profile':'test','ordinary_daemon_build_identity':None,'ordinary_daemon_load_identity':None}
started=time.monotonic();before=snapshot();save('source-before.json',before)
summary={'schema':'m5-unfiltered-unified-artifact-library-test-v1','source_head':head,'source_tree':tree,'package':package,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'NOT_STARTED','outer_job_timeout_seconds':900,'test_process_timeout_seconds':850,'source_edited':False,'native_daemon_executed':False,'host_four_second_service_executed':False,'thirty_second_campaign_executed':False,'ignored_tests_explicitly_enabled':False}
active=None;artifact=None
try:
 assert before['head']==head and before['tree']==tree and not before['status']
 assert before['cargo_lock_sha256']=='f9e57d73899c5d9fabd4f5b4fedf45256b8db4efb448d15680d070bbcfcb30bd'
 build=json.loads((base/'m5/five-package-build-01/summary.json').read_text())
 assert build['result']=='PASS' and build['all_five_test_artifacts_reported'] and build['source_before_after_equal']
 artifact_record=json.loads((base/'m5/five-package-build-01/compiler-artifact-test-identities.json').read_text())
 matches=[a for a in artifact_record['artifacts'] if a['package']==package];assert len(matches)==1
 record=matches[0];artifact=Path(record['path']);initial=identity(artifact)
 assert initial['bytes']==record['bytes'] and initial['sha256']==record['sha256']
 save('test-elf-before.json',initial)
 meta=record['package_metadata'];cwd=Path(meta['manifest_path']).parent
 assert cwd==source/'trillionnium/crates'/package and cwd.is_dir()
 observed=json.loads((base/'m5/running-test-context-01/summary.json').read_text())['observed_test_processes']
 node=[p for p in observed if Path(p['executable']).name.startswith('trnm_pon_node-')]
 assert len(node)==1
 prior_env=node[0]['selected_runtime_environment'];env=dict(os.environ)
 for k in list(env):
  if k.startswith('CARGO_PKG_') or k in ('CARGO_MANIFEST_DIR','CARGO_MANIFEST_PATH','CARGO_CRATE_NAME','CARGO_BIN_NAME','RUST_TEST_THREADS','RUST_BACKTRACE'):env.pop(k)
 for k in ('CARGO','PATH','LD_LIBRARY_PATH','DYLD_LIBRARY_PATH','DYLD_FALLBACK_LIBRARY_PATH','RUST_BACKTRACE','RUST_TEST_THREADS'):
  if k in prior_env:env[k]=prior_env[k]
 env['CARGO_TARGET_DIR']=str(target);env['PYTHONDONTWRITEBYTECODE']='1'
 env['CARGO_MANIFEST_DIR']=str(cwd);env['CARGO_MANIFEST_PATH']=meta['manifest_path']
 version=re.fullmatch(r'(\d+)\.(\d+)\.(\d+)(?:-([^+]+))?(?:\+.+)?',meta['version']);assert version
 fields={'NAME':meta['name'],'VERSION':meta['version'],'VERSION_MAJOR':version.group(1),'VERSION_MINOR':version.group(2),'VERSION_PATCH':version.group(3),'VERSION_PRE':version.group(4) or '','AUTHORS':':'.join(meta['authors']),'DESCRIPTION':meta.get('description') or '','HOMEPAGE':meta.get('homepage') or '','LICENSE':meta.get('license') or '','LICENSE_FILE':meta.get('license_file') or '','REPOSITORY':meta.get('repository') or '','RUST_VERSION':meta.get('rust_version') or '','README':meta.get('readme') or ''}
 for k,v in fields.items():env['CARGO_PKG_'+k]=v
 linked=[]
 for line in (base/'m5/five-package-build-01/five-package-build.stdout.log').read_text().splitlines():
  event=json.loads(line)
  if event.get('reason')=='build-script-executed':
   for value in event.get('linked_paths',[]):
    raw=value.split('=',1)[1] if '=' in value else value;p=Path(raw)
    if p.is_dir() and p.resolve().is_relative_to(target.resolve()) and str(p) not in linked:linked.append(str(p))
 existing=[p for p in env.get('LD_LIBRARY_PATH','').split(':') if p]
 env['LD_LIBRARY_PATH']=':'.join(dict.fromkeys(linked+existing))
 selected={k:v for k,v in env.items() if k.startswith('CARGO_PKG_') or k in ('CARGO','CARGO_MANIFEST_DIR','CARGO_MANIFEST_PATH','CARGO_TARGET_DIR','LD_LIBRARY_PATH','PATH','RUST_BACKTRACE','RUST_TEST_THREADS','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS')}
 save('execution-context.json',{'argv':[str(artifact)],'cwd':str(cwd),'cwd_basis':'Exact Cargo package metadata manifest_path parent; Cargo Book cargo-test working-directory rule','cargo_rule_url':'https://doc.rust-lang.org/cargo/commands/cargo-test.html#working-directory-of-tests','selected_runtime_environment':selected,'common_environment_basis':'Observed original Cargo-launched node process from exact owned job, with package fields replaced from actual selected package metadata and owned build-script linked paths retained','package_metadata':meta,'observed_context_receipt':'m5/running-test-context-01/summary.json','build_script_linked_paths_added':linked,'unlisted_inherited_environment_not_recorded':True,'identical_complete_Cargo_DA_environment_not_asserted':True,'no_filter_or_ignored_flag':True})
 with (out/'preflight.stdout.log').open('xb') as stdout,(out/'preflight.stderr.log').open('xb') as stderr:
  preflight=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=source,stdout=stdout,stderr=stderr,timeout=60)
 assert preflight.returncode==0,'preflight failed'
 command={'argv':[str(artifact)],'cwd':str(cwd),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':850,'disk_free_before':shutil.disk_usage(base).free}
 save('command.json',command);print(json.dumps({'stage':'direct-unfiltered-library','package':package,'state':'STARTED','cwd':str(cwd),'artifact':initial}),flush=True)
 t=time.monotonic()
 with (out/'test.stdout.log').open('xb') as stdout,(out/'test.stderr.log').open('xb') as stderr:
  active=subprocess.Popen([str(artifact)],cwd=cwd,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  try:command['returncode']=active.wait(timeout=850)
  except subprocess.TimeoutExpired:
   command['timed_out']=True;os.killpg(active.pid,signal.SIGTERM)
   try:active.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(active.pid,signal.SIGKILL);active.wait()
   command['returncode']=active.returncode
  active=None
 command['elapsed_seconds']=time.monotonic()-t;command['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();command['disk_free_after']=shutil.disk_usage(base).free
 for stream in ('stdout','stderr'):
  raw=(out/('test.'+stream+'.log')).read_bytes();command[stream+'_bytes']=len(raw);command[stream+'_sha256']=hashlib.sha256(raw).hexdigest()
 save('command.json',command)
 stdout=(out/'test.stdout.log').read_text(errors='replace')
 pattern=r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([^\n]+)'
 rows=[]
 for match in re.finditer(pattern,stdout):
  status,*values=match.groups();rows.append(dict(status=status,**dict(zip(('passed','failed','ignored','measured','filtered_out'),map(int,values[:5]))),elapsed=values[5],raw_line=match.group(0)))
 top=[r for r in rows if r['filtered_out']==0];nested=[r for r in rows if r['filtered_out']!=0]
 roster_match=re.search(r'(?m)^running (\d+) tests?$',stdout)
 roster=int(roster_match.group(1)) if roster_match else None
 status_lines=[line for line in stdout.splitlines() if line.startswith('test ') and not line.startswith('test result:') and ' ... ' in line]
 ignored_lines=[line for line in status_lines if ' ... ignored' in line]
 save('all-test-status-lines.json',{'main_roster_count':roster,'all_observed_status_lines':status_lines,'ignored_lines':ignored_lines,'nested_subprocess_status_lines_are_preserved_not_added_to_main_roster':True})
 complete=len(top)==1 and roster is not None and top[0]['passed']+top[0]['failed']+top[0]['ignored']==roster
 summary.update(test_returncode=command['returncode'],timed_out=command.get('timed_out',False),main_roster_count=roster,top_level_results=top,nested_or_filtered_results=nested,main_harness_complete=complete,observed_ignored_line_count=len(ignored_lines),ignored_tests_remain_unexecuted=bool(ignored_lines) or any(r['ignored'] for r in top),all_retained_release_service_gates_closed=False)
 if package=='trnm-data-availability':
  summary['expected_715_roster']=roster==715
  summary['live_original_negative_control_passed']=any('closure_probe_rejects_a_live_original_descriptor' in line and line.endswith(' ... ok') for line in status_lines)
  summary['original_corruption_test_passed']=any('copied_byte_corruption_is_rejected_by_postseal_full_hash_without_partial_bundle' in line and line.endswith(' ... ok') for line in status_lines)
  complete=complete and summary['expected_715_roster'] and summary['live_original_negative_control_passed'] and summary['original_corruption_test_passed']
 summary['result']=('PASS_WITH_IGNORED' if top[0]['ignored'] else 'PASS') if command['returncode']==0 and complete else 'FAIL_OR_INCOMPLETE'
except Exception as error:summary['error']={'type':type(error).__name__,'message':str(error)}
finally:
 if active is not None and active.poll() is None:
  os.killpg(active.pid,signal.SIGTERM)
  try:active.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(active.pid,signal.SIGKILL);active.wait()
 after=snapshot();save('source-after.json',after);summary['source_before_after_equal']=after==before
 if artifact is not None:
  final=identity(artifact);save('test-elf-after.json',final);summary['test_elf_before_after_equal']=final==initial
  if final!=initial:summary['result']='ARTIFACT_CHANGED'
 if after!=before:summary['result']='SOURCE_CHANGED'
 summary['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();summary['elapsed_seconds']=time.monotonic()-started
 save('summary.json',summary);save('FILES.json',{'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.iterdir()) if p.is_file() and p.name!='FILES.json']})
 print(json.dumps(summary,indent=2),flush=True)
sys.exit(0 if summary['result'] in ('PASS','PASS_WITH_IGNORED') else 2)
