/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/trnm_mvcc_fee-e313053110c6ea27.d: crates/trnm-mvcc-fee/src/lib.rs crates/trnm-mvcc-fee/src/checkpoint_tile_material_v1.rs crates/trnm-mvcc-fee/src/checkpoint_tile_policy_v1.rs crates/trnm-mvcc-fee/src/codec.rs crates/trnm-mvcc-fee/src/continuity_v1.rs crates/trnm-mvcc-fee/src/deployment_actors.rs crates/trnm-mvcc-fee/src/deployment_checkpoint_tile_v1.rs crates/trnm-mvcc-fee/src/deterministic_parallel_v1.rs crates/trnm-mvcc-fee/src/engine.rs crates/trnm-mvcc-fee/src/error.rs crates/trnm-mvcc-fee/src/growth_profile_v2.rs crates/trnm-mvcc-fee/src/public_evaluation.rs crates/trnm-mvcc-fee/src/public_evaluation/pq_storage.rs crates/trnm-mvcc-fee/src/public_evaluation/quorum_v2.rs crates/trnm-mvcc-fee/src/qualified_task_lifecycle.rs crates/trnm-mvcc-fee/src/store.rs crates/trnm-mvcc-fee/src/types.rs crates/trnm-mvcc-fee/src/tests.rs crates/trnm-mvcc-fee/src/parallel_execution_tests.rs crates/trnm-mvcc-fee/src/pon_executor.rs crates/trnm-mvcc-fee/src/pon_executor/growth.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/application_v6.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/migration.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/migration_inventory_v1.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/migration_inventory_tests.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/task_migration_v1.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v4.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v5.rs crates/trnm-mvcc-fee/src/pon_executor/../../../trnm-protocol/tests/support/native_pq_task_fixture_v5.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tests.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/../../../../trnm-protocol/tests/support/native_pq_accounts_fixture.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v4_tests.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/../../../../trnm-protocol/tests/support/native_pq_task_fixture.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/application_v6_tests.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/application_v6_scope_tests.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v5_tests.rs crates/trnm-mvcc-fee/src/pon_executor/root_arithmetic_tests.rs crates/trnm-mvcc-fee/src/pon_executor/prefix_scan_tests.rs crates/trnm-mvcc-fee/src/repeated_sender_tests.rs crates/trnm-mvcc-fee/src/pon_commitment.rs crates/trnm-mvcc-fee/src/pon_commitment/full_root_arithmetic_tests.rs crates/trnm-mvcc-fee/src/pon_commitment_binding_tests.rs crates/trnm-mvcc-fee/src/pon_commitment/unchanged_snapshot_tests.rs crates/trnm-mvcc-fee/src/integer_factor_candidate_v2.rs crates/trnm-mvcc-fee/src/model_composition_v4.rs crates/trnm-mvcc-fee/src/model_composition_v4/oracle_observations.rs crates/trnm-mvcc-fee/src/model_evidence_v3.rs crates/trnm-mvcc-fee/src/model_evolution_v5.rs crates/trnm-mvcc-fee/src/model_task_windows_v1.rs crates/trnm-mvcc-fee/src/../../../../config/pon/checkpoint-tile-task-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/ledger-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/work-profile-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/continuity-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-task-lifecycle-v4.json crates/trnm-mvcc-fee/src/../../../../config/pon/operator-actors-dev-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/operator-checkpoint-tile-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/growth-reference-v2.json crates/trnm-mvcc-fee/src/../../../../tests/vectors/pon/native-growth-reference-v2.json crates/trnm-mvcc-fee/src/pon_executor/../../../trnm-protocol/tests/support/../fixtures/pq_transfer/public.der crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/../../../../trnm-protocol/tests/support/../fixtures/pq_transfer/public.der crates/trnm-mvcc-fee/src/../../../../config/pon/devnet-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/evaluation-round-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/public-evaluation-model-evolution-v5.json crates/trnm-mvcc-fee/src/../../../../config/pon/public-evaluation-quorum-v2.json crates/trnm-mvcc-fee/src/../../../../config/pon/public-evaluation-native-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-work-task-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-task-lifecycle-v2.json crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-task-lifecycle-v3.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-evolution-v3.json crates/trnm-mvcc-fee/src/../../../../config/pon/integer-factor-candidate-v2.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-integer-factor-v2.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-smollm2-135m-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-composition-v4.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-evidence-v3.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-evolution-v5.json Cargo.toml

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libtrnm_mvcc_fee-e313053110c6ea27.rmeta: crates/trnm-mvcc-fee/src/lib.rs crates/trnm-mvcc-fee/src/checkpoint_tile_material_v1.rs crates/trnm-mvcc-fee/src/checkpoint_tile_policy_v1.rs crates/trnm-mvcc-fee/src/codec.rs crates/trnm-mvcc-fee/src/continuity_v1.rs crates/trnm-mvcc-fee/src/deployment_actors.rs crates/trnm-mvcc-fee/src/deployment_checkpoint_tile_v1.rs crates/trnm-mvcc-fee/src/deterministic_parallel_v1.rs crates/trnm-mvcc-fee/src/engine.rs crates/trnm-mvcc-fee/src/error.rs crates/trnm-mvcc-fee/src/growth_profile_v2.rs crates/trnm-mvcc-fee/src/public_evaluation.rs crates/trnm-mvcc-fee/src/public_evaluation/pq_storage.rs crates/trnm-mvcc-fee/src/public_evaluation/quorum_v2.rs crates/trnm-mvcc-fee/src/qualified_task_lifecycle.rs crates/trnm-mvcc-fee/src/store.rs crates/trnm-mvcc-fee/src/types.rs crates/trnm-mvcc-fee/src/tests.rs crates/trnm-mvcc-fee/src/parallel_execution_tests.rs crates/trnm-mvcc-fee/src/pon_executor.rs crates/trnm-mvcc-fee/src/pon_executor/growth.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/application_v6.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/migration.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/migration_inventory_v1.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/migration_inventory_tests.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/task_migration_v1.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v4.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v5.rs crates/trnm-mvcc-fee/src/pon_executor/../../../trnm-protocol/tests/support/native_pq_task_fixture_v5.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tests.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/../../../../trnm-protocol/tests/support/native_pq_accounts_fixture.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v4_tests.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/../../../../trnm-protocol/tests/support/native_pq_task_fixture.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/application_v6_tests.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/application_v6_scope_tests.rs crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v5_tests.rs crates/trnm-mvcc-fee/src/pon_executor/root_arithmetic_tests.rs crates/trnm-mvcc-fee/src/pon_executor/prefix_scan_tests.rs crates/trnm-mvcc-fee/src/repeated_sender_tests.rs crates/trnm-mvcc-fee/src/pon_commitment.rs crates/trnm-mvcc-fee/src/pon_commitment/full_root_arithmetic_tests.rs crates/trnm-mvcc-fee/src/pon_commitment_binding_tests.rs crates/trnm-mvcc-fee/src/pon_commitment/unchanged_snapshot_tests.rs crates/trnm-mvcc-fee/src/integer_factor_candidate_v2.rs crates/trnm-mvcc-fee/src/model_composition_v4.rs crates/trnm-mvcc-fee/src/model_composition_v4/oracle_observations.rs crates/trnm-mvcc-fee/src/model_evidence_v3.rs crates/trnm-mvcc-fee/src/model_evolution_v5.rs crates/trnm-mvcc-fee/src/model_task_windows_v1.rs crates/trnm-mvcc-fee/src/../../../../config/pon/checkpoint-tile-task-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/ledger-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/work-profile-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/continuity-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-task-lifecycle-v4.json crates/trnm-mvcc-fee/src/../../../../config/pon/operator-actors-dev-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/operator-checkpoint-tile-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/growth-reference-v2.json crates/trnm-mvcc-fee/src/../../../../tests/vectors/pon/native-growth-reference-v2.json crates/trnm-mvcc-fee/src/pon_executor/../../../trnm-protocol/tests/support/../fixtures/pq_transfer/public.der crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/../../../../trnm-protocol/tests/support/../fixtures/pq_transfer/public.der crates/trnm-mvcc-fee/src/../../../../config/pon/devnet-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/evaluation-round-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/public-evaluation-model-evolution-v5.json crates/trnm-mvcc-fee/src/../../../../config/pon/public-evaluation-quorum-v2.json crates/trnm-mvcc-fee/src/../../../../config/pon/public-evaluation-native-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-work-task-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-task-lifecycle-v2.json crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-task-lifecycle-v3.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-evolution-v3.json crates/trnm-mvcc-fee/src/../../../../config/pon/integer-factor-candidate-v2.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-integer-factor-v2.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-smollm2-135m-v1.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-composition-v4.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-evidence-v3.json crates/trnm-mvcc-fee/src/../../../../config/pon/model-evolution-v5.json Cargo.toml

crates/trnm-mvcc-fee/src/lib.rs:
crates/trnm-mvcc-fee/src/checkpoint_tile_material_v1.rs:
crates/trnm-mvcc-fee/src/checkpoint_tile_policy_v1.rs:
crates/trnm-mvcc-fee/src/codec.rs:
crates/trnm-mvcc-fee/src/continuity_v1.rs:
crates/trnm-mvcc-fee/src/deployment_actors.rs:
crates/trnm-mvcc-fee/src/deployment_checkpoint_tile_v1.rs:
crates/trnm-mvcc-fee/src/deterministic_parallel_v1.rs:
crates/trnm-mvcc-fee/src/engine.rs:
crates/trnm-mvcc-fee/src/error.rs:
crates/trnm-mvcc-fee/src/growth_profile_v2.rs:
crates/trnm-mvcc-fee/src/public_evaluation.rs:
crates/trnm-mvcc-fee/src/public_evaluation/pq_storage.rs:
crates/trnm-mvcc-fee/src/public_evaluation/quorum_v2.rs:
crates/trnm-mvcc-fee/src/qualified_task_lifecycle.rs:
crates/trnm-mvcc-fee/src/store.rs:
crates/trnm-mvcc-fee/src/types.rs:
crates/trnm-mvcc-fee/src/tests.rs:
crates/trnm-mvcc-fee/src/parallel_execution_tests.rs:
crates/trnm-mvcc-fee/src/pon_executor.rs:
crates/trnm-mvcc-fee/src/pon_executor/growth.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/application_v6.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/migration.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/migration_inventory_v1.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/migration_inventory_tests.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/task_migration_v1.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v4.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v5.rs:
crates/trnm-mvcc-fee/src/pon_executor/../../../trnm-protocol/tests/support/native_pq_task_fixture_v5.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tests.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/../../../../trnm-protocol/tests/support/native_pq_accounts_fixture.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v4_tests.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/../../../../trnm-protocol/tests/support/native_pq_task_fixture.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/application_v6_tests.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/application_v6_scope_tests.rs:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/tasks_v5_tests.rs:
crates/trnm-mvcc-fee/src/pon_executor/root_arithmetic_tests.rs:
crates/trnm-mvcc-fee/src/pon_executor/prefix_scan_tests.rs:
crates/trnm-mvcc-fee/src/repeated_sender_tests.rs:
crates/trnm-mvcc-fee/src/pon_commitment.rs:
crates/trnm-mvcc-fee/src/pon_commitment/full_root_arithmetic_tests.rs:
crates/trnm-mvcc-fee/src/pon_commitment_binding_tests.rs:
crates/trnm-mvcc-fee/src/pon_commitment/unchanged_snapshot_tests.rs:
crates/trnm-mvcc-fee/src/integer_factor_candidate_v2.rs:
crates/trnm-mvcc-fee/src/model_composition_v4.rs:
crates/trnm-mvcc-fee/src/model_composition_v4/oracle_observations.rs:
crates/trnm-mvcc-fee/src/model_evidence_v3.rs:
crates/trnm-mvcc-fee/src/model_evolution_v5.rs:
crates/trnm-mvcc-fee/src/model_task_windows_v1.rs:
crates/trnm-mvcc-fee/src/../../../../config/pon/checkpoint-tile-task-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/ledger-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/work-profile-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/continuity-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-task-lifecycle-v4.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/operator-actors-dev-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/operator-checkpoint-tile-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/growth-reference-v2.json:
crates/trnm-mvcc-fee/src/../../../../tests/vectors/pon/native-growth-reference-v2.json:
crates/trnm-mvcc-fee/src/pon_executor/../../../trnm-protocol/tests/support/../fixtures/pq_transfer/public.der:
crates/trnm-mvcc-fee/src/pon_executor/pq_accounts_v2/../../../../trnm-protocol/tests/support/../fixtures/pq_transfer/public.der:
crates/trnm-mvcc-fee/src/../../../../config/pon/devnet-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/evaluation-round-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/public-evaluation-model-evolution-v5.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/public-evaluation-quorum-v2.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/public-evaluation-native-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-work-task-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-task-lifecycle-v2.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/qualified-task-lifecycle-v3.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-evolution-v3.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/integer-factor-candidate-v2.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-integer-factor-v2.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/model-family-smollm2-135m-v1.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/model-composition-v4.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/model-evidence-v3.json:
crates/trnm-mvcc-fee/src/../../../../config/pon/model-evolution-v5.json:
Cargo.toml:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/f4976366a32a/chain/trillionnium/crates/trnm-mvcc-fee
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
