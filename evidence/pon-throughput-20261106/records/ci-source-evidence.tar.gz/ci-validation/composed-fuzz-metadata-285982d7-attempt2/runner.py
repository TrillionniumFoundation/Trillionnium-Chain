#!/usr/bin/env python3
"""One bounded non-offline metadata-only attempt; original offline failure retained."""
from __future__ import annotations
import hashlib,importlib.util,json,os
from pathlib import Path
import shutil,subprocess,sys,traceback
ROOT=Path('/workspace/scratch/1eed767ad985');REPO=ROOT/'chain-throughput';OUT=ROOT/'ci-validation/composed-fuzz-metadata-285982d7-attempt2'
HEAD='285982d78a4f62a064841cb0f106d18c865e19c5';TREE='ce074eb1857a92c9b47ea317b841777fcfc63c04'
HELPER=ROOT/'validation/run_exact_selected_controls.py';HELPER_SHA='a8f8656fe25038fb67939b360b42631b6856dab9bd302365cd53591be2108e55'
RUST_BIN=ROOT/'rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(HELPER)==HELPER_SHA
spec=importlib.util.spec_from_file_location('capture_helper',HELPER);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
OUT.mkdir(exist_ok=False);shutil.copyfile(__file__,OUT/'runner.py')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',RUSTUP_HOME=str(ROOT/'rustup'),CARGO_HOME=str(ROOT/'cargo'),RUSTUP_TOOLCHAIN='1.95.0',CARGO_NET_OFFLINE='false',CARGO_NET_RETRY='0',CARGO_HTTP_TIMEOUT='20')
env['PATH']=str(RUST_BIN)+os.pathsep+env.get('PATH','')
argv=[str(RUST_BIN/'cargo'),'metadata','--locked','--all-features','--format-version','1','--manifest-path','tests/fuzz/Cargo.toml']
command=['/usr/bin/timeout','--signal=TERM','--kill-after=5s','90s',*argv]
original=ROOT/'ci-validation/composed-source-285982d7/summary-corrected.json'
report={'schema':'trnm-bounded-fuzz-metadata-observation-v1','source':HEAD,'tree':TREE,'scope':'dependency graph parsing/downloading only; no Rust build/test/fuzz execution','command':command,'cargo_command':argv,'bounds':{'total_seconds':90,'term_to_kill_seconds':5,'http_timeout_seconds':20,'http_retries':0},'original_offline_attempt':{'summary':str(original),'sha256':sha(original),'record_preserved':True},'before':None,'after':None,'execution':None,'graph':None,'result':'INCOMPLETE'}
def locks():
    result={}
    for name in ['trillionnium/Cargo.lock','tests/fuzz/Cargo.lock']:
        raw=(REPO/name).read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();expected=subprocess.check_output(['git','rev-parse',HEAD+':'+name],cwd=REPO).decode().strip();assert blob==expected
        result[name]={'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob,'bytes':len(raw)}
    return result
try:
    report['before']=helper.source_checkpoint(REPO,HEAD,OUT,'source-before',env)
    assert report['before']['passed'] and report['before']['receipt']['tested_tree']==TREE
    report['locks_before']=locks()
    helper.write_json(OUT/'attempt-context.json',{'environment':{k:env[k] for k in ['CARGO_NET_OFFLINE','CARGO_NET_RETRY','CARGO_HTTP_TIMEOUT','RUSTUP_HOME','CARGO_HOME','RUSTUP_TOOLCHAIN']},'command':command,'helper_sha256':HELPER_SHA,'runner_sha256':sha(Path(__file__))})
    print('START bounded fuzz metadata',flush=True)
    report['execution']=helper.run_capture(command,REPO,env,OUT/'fuzz-metadata-online')
    if helper.capture_passed(report['execution']):
        p=Path(report['execution']['stdout_path']);data=json.loads(p.read_text());members=set(data['workspace_members']);targets=[{'package':x['name'],'name':t['name'],'kind':t['kind'],'test':t['test'],'doctest':t['doctest']} for x in data['packages'] if x['id'] in members for t in x['targets']]
        report['graph']={'packages':len(data['packages']),'workspace_members':len(members),'resolve_nodes':len(data['resolve']['nodes']),'workspace_targets':targets,'raw_metadata_sha256':sha(p),'all_features':True,'platform_filter':None,'native_execution_qualified':False}
        helper.write_json(OUT/'fuzz.graph.json',report['graph'])
    report['locks_after']=locks();report['lockfiles_unchanged']=report['locks_before']==report['locks_after']
except BaseException as error:
    report['collector_error']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
finally:
    try:
        report['after']=helper.source_checkpoint(REPO,HEAD,OUT,'source-after',env)
        report['source_before_equals_after']=bool(report['before'] and report['before']['passed'] and report['after']['passed'] and report['before']['receipt']==report['after']['receipt'])
    except BaseException as error:report['source_after_error']=repr(error);report['source_before_equals_after']=False
    report['original_attempt_unchanged']=sha(original)==report['original_offline_attempt']['sha256']
    passed=bool(report['execution'] and helper.capture_passed(report['execution']) and report['graph'] and report['source_before_equals_after'] and report.get('lockfiles_unchanged') and report['original_attempt_unchanged'] and 'collector_error' not in report)
    report['result']='PASS' if passed else 'FAIL';report['finished_utc']=helper.utc_now();helper.write_json(OUT/'summary.json',report)
    paths=sorted(p for p in OUT.iterdir() if p.is_file());(OUT/'artifacts.sha256').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in paths))
    print(json.dumps({'result':report['result'],'command_exit':None if not report['execution'] else report['execution']['native_exit'],'source_before_equals_after':report['source_before_equals_after'],'graph':None if not report['graph'] else {k:report['graph'][k] for k in ['packages','workspace_members','resolve_nodes']},'summary':str(OUT/'summary.json')}),flush=True)
    raise SystemExit(0 if passed else 1)
