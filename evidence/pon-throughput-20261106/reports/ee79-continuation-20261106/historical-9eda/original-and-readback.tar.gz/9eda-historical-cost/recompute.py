"""Re-read the retained9eda reports; starts no node and overwrites no evidence."""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('new_output_directory', type=Path)
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    for entry in manifest['files']:
        data = (ROOT / entry['file']).read_bytes()
        assert len(data) == entry['bytes'], entry['file']
        assert sha256(data) == entry['sha256'], entry['file']
    receipt = json.loads((ROOT / 'readback-receipt.json').read_text())
    args.new_output_directory.mkdir(parents=True, exist_ok=False)
    results = []
    for report, command in zip(receipt['reports'], receipt['reader_commands']):
        number = report['number']
        assert number == command['number']
        raw = gzip.decompress((ROOT / report['gzip_file']).read_bytes())
        assert len(raw) == report['original_report_bytes']
        assert sha256(raw) == report['original_report_sha256']
        output = args.new_output_directory / f'run-{number}-cost-coverage.json'
        with tempfile.TemporaryDirectory(prefix=f'9eda-reader-{number}-') as directory:
            source = Path(directory) / 'report.json'
            source.write_bytes(raw)
            argv = [
                'python3', '-B', str(ROOT / 'reader-source/scripts/ci/throughput_cost_coverage.py'),
                str(source), '--report-sha256', report['original_report_sha256'],
                '--source', str(ROOT / 'original/source-before-campaigns.json'),
                '--source-after', str(ROOT / f'original/run-{number}-source-after.json'),
                '--expected-head', receipt['original_execution_source_head'],
                '--expected-tree', receipt['original_execution_source_tree'],
                '--output', str(output),
            ]
            result = subprocess.run(argv, capture_output=True)
        (args.new_output_directory / f'run-{number}.stdout.log').write_bytes(result.stdout)
        (args.new_output_directory / f'run-{number}.stderr.log').write_bytes(result.stderr)
        assert result.returncode == 0, result.stderr.decode()
        actual_sha256 = sha256(output.read_bytes())
        assert actual_sha256 == command['output_sha256']
        results.append({'run': number, 'reader_returncode': 0,
                        'output_sha256': actual_sha256, 'matches_retained_output': True,
                        'new_native_execution': False})
    (args.new_output_directory / 'recompute-results.json').write_text(
        json.dumps(results, indent=2, sort_keys=True) + '\n')
    print(json.dumps(results))


if __name__ == '__main__':
    main()
