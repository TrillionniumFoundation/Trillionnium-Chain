#!/usr/bin/env python3
"""Retain exact local observations without claiming unexecuted native tests."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

BASE = Path('/workspace/scratch/bb9b841c1d43')
ROOT = BASE/'pq-task-authority-v4'
LOCAL = BASE/'pq-v4-evidence'
META = BASE/'pq-v4-typecheck'
DEST = ROOT/'evidence/pon-pq-tasks-v4-20261028'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(p, value):
    p.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

def load(name):
    return json.loads((LOCAL/name).read_text())

def inventory():
    return {str(p.relative_to(ROOT)):sha(p)
        for prefix in ('scripts','trillionnium','config','formal/pon-nakamoto-v1','.github')
        for p in sorted((ROOT/prefix).rglob('*'))
        if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}

current = inventory()
reader = load('legacy-reader-final.json')
gate = load('new-gate-readers-02.json')
assert reader['passed'] and reader['source_unchanged']
assert gate['passed'] and gate['source_unchanged'] and gate['source_sha256_after']==current
prior = reader['source_sha256_after']
changed = sorted(n for n in set(prior)|set(current) if prior.get(n)!=current.get(n))
assert changed == ['scripts/ci/test_native_pq_tasks_v4_research.py'], changed
join = {
    'schema':'npq4-local-observation-source-join-v1',
    'source_parent_local':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    'source_parent_remote':'29e1f194742e436b44b4c8758777341e62fe2bd8',
    'source_parent_tree':'40dab4b86e38ee541a93a8e232a2442d3160e8fd',
    'observations_bind_worktree_bytes_not_clean_parent_commit':True,
    'legacy_reader_final_delta':changed,
    'delta_reason':'only synthetic NPQ4 unit-roster positive fixture summary now includes the original ignored count; production reader/runtime/expected roster are unchanged',
    'current_materialized_source_sha256':current,
    'all_readiness_reader_inputs_unchanged':True,
    'full_cargo_graph_build_qualified':False,
    'native_tests_executed':False,
}
targets = [
    ('trnm_protocol-lib-clippy01','trnm-protocol'),
    ('trnm_crypto_primitives-lib-clippy01','trnm-crypto-primitives'),
    ('trnm_mvcc_fee-lib-clippy01','trnm-mvcc-fee'),
    ('trnm_pon_node-lib-clippy02','trnm-pon-node'),
    ('trnm_protocol-lib-clippytests01','trnm-protocol'),
    ('trnm_mvcc_fee-lib-clippytests01','trnm-mvcc-fee'),
    ('trnm_mvcc_fee-pq4_task_authority-clippytests01','trnm-mvcc-fee'),
    ('trnm_pon_node-native_pq_v4-clippytests02','trnm-pon-node'),
]
checks=[]
for label,package in targets:
    record=json.loads((META/(label+'.json')).read_text())
    inputs=json.loads((META/(label+'-inputs.json')).read_text())
    prefix='trillionnium/crates/'+package+'/'
    names=[n for n in inputs['source'] if n.startswith(prefix)]
    # Generated inventory belongs to Node examples, not these lib/test targets.
    assert all(current.get(n)==inputs['source'][n] for n in names), label
    assert record['returncode']==0 and not record['timeout'],label
    checks.append({'target':label,'source_files':len(names),'returncode':record['returncode'],
        'wall_seconds':record['wall_seconds'],'argv':record['argv'],
        'scope':'direct warnings-denied Clippy metadata; no native execution, Cargo build or all-feature claim'})
join['final_component_metadata_checks']=checks
save(DEST/'source-identity-join.json',join)

observations={}
for name in ['legacy-reader-01','legacy-reader-final','new-gate-readers-final','new-gate-readers-02',
             'source-negatives-final','evidence-sources-final','ci-contract-final','inventory-final','fmt-final']:
    r=load(name+'.json')
    if name!='new-gate-readers-final': assert r['passed'] and r['source_unchanged'],name
    observations[name]={k:r[k] for k in ['exit_code','elapsed_ns','timed_out','source_unchanged','passed']}
    observations[name]['stdout_sha256']=r['stdout.log']['sha256']
    observations[name]['stderr_sha256']=r['stderr.log']['sha256']

files=[]
for directory,prefix in [(LOCAL,'local'),(META,'metadata')]:
    for p in sorted(directory.iterdir()):
        if not p.is_file() or p.suffix not in ('.json','.log','.py'): continue
        assert not p.is_symlink() and p.stat().st_size<16*1024*1024,p
        files.append((prefix+'/'+p.name,p))
raw=[]
with (DEST/'observations.tar.gz').open('wb') as output:
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|') as archive:
            for name,path in files:
                data=path.read_bytes()
                raw.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
                item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0
                archive.addfile(item,io.BytesIO(data))
save(DEST/'raw-inventory.json',{'files':raw,'total_bytes':sum(v['bytes'] for v in raw),
    'archive_sha256':sha(DEST/'observations.tar.gz')})
with tarfile.open(DEST/'observations.tar.gz','r:gz') as archive:
    assert archive.getnames()==[v['path'] for v in raw]
    for row in raw:
        data=archive.extractfile(row['path']).read()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
graph=load('full-metadata-final.json')
assert graph['returncode']==0 and graph['lock_and_manifests_unchanged']
summary={'schema':'npq4-task-authority-local-candidate-v1','result':'CANDIDATE_NATIVE_NOT_RUN',
    'native_status':'NOT_RUN_RESOURCE_STOP','actual_new_native_passes':0,'required_hosted_native_passes':180,
    'required_hosted_original_unit_ignores':8,'required_hosted_integration_passes':44,
    'p1_complete':False,'whole_chain_post_quantum':False,'production_activation':False,
    'real_demand_proved':False,'useful_model_work_qualified':False,'sqlite_physical_io_qualified':False,
    'native_red_reproduced_for_detached_packet_gap':False,
    'detached_packet_source_review':'fixed private full transaction-root binding; actual SQL counterexample is compiled metadata but execution NOT_RUN',
    'observations':observations,'component_metadata_targets':len(checks),
    'locked_offline_graph':{k:graph[k] for k in ['packages','workspace_members','resolved_nodes','lock_and_manifests_unchanged','wall_seconds']},
    'raw_files':len(raw),'raw_bytes':sum(v['bytes'] for v in raw),'raw_archive_sha256':sha(DEST/'observations.tar.gz'),
    'source_identity_join_sha256':sha(DEST/'source-identity-join.json'),
    'full_local_checkout_qualification':False}
save(DEST/'summary.json',summary)
print(json.dumps({k:summary[k] for k in ['result','component_metadata_targets','raw_files','raw_bytes','raw_archive_sha256']}))
