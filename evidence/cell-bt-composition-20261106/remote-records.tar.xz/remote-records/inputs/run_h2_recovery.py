#!/usr/bin/env python3
"""Reproduce the frozen H2 gates after the local executor became unavailable."""
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import run_storage_validation as audit

COMMIT = 'c16c7e0e93cf5eb14f6dac140358441a47d82c7e'
TREE = '4aa564ca3eb297f6afa03976f16eacb6ffd7554a'
EXPECTED_FILES = '371234f984d31f28ed2d32487786c2b4915b44cc71218d9ed75932ee0a1fb9d8'

def verify_source(out, label):
    repo = audit.REPO
    assert audit.capture(['git','rev-parse','HEAD']).decode().strip() == COMMIT
    assert audit.capture(['git','rev-parse','HEAD^{tree}']).decode().strip() == TREE
    assert audit.capture(['git','status','--porcelain']) == b'', 'frozen checkout changed'
    manifest = audit.ROOT/'evidence/green-final-combined/before.files.json'
    assert audit.sha256(manifest) == EXPECTED_FILES
    rows = json.loads(manifest.read_text())
    tracked = {os.fsdecode(p) for p in audit.capture(['git','ls-files','-z']).split(b'\0') if p}
    assert tracked == {row['path'] for row in rows}
    for row in rows:
        path = repo/row['path']
        info = path.lstat()
        assert stat.S_IMODE(info.st_mode) == row['mode'], row['path']
        if row['type'] == 'symlink':
            assert path.is_symlink() and os.readlink(path) == row['target'], row['path']
        else:
            assert stat.S_ISREG(info.st_mode) and info.st_size == row['size'], row['path']
            assert audit.sha256(path) == row['sha256'], row['path']
    proof = {'commit':COMMIT,'tree':TREE,'reference_manifest':str(manifest),
             'reference_manifest_sha256':EXPECTED_FILES,'verified_file_count':len(rows),
             'all_working_files_equal_reference':True,'clean_git_status':True}
    audit.save_json(out/(label+'.source.json'),proof)
    return proof

def main():
    mode = sys.argv[1]
    assert mode in ('source-gates','m09'), mode
    out = audit.ROOT/'evidence'/('recovery-'+mode)
    out.mkdir(exist_ok=False)
    env = os.environ.copy()
    assert not [k for k in env if env[k] and (k.startswith('CARGO_PROFILE_') or k in
                ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'))]
    provider_env = json.loads((audit.ROOT/'inputs/provider-env.json').read_text())
    provider_proof = json.loads((audit.ROOT/'evidence/provider-reuse/provider-reuse.json').read_text())
    assert provider_proof['result'] == 'REUSED_EXACT_PROVIDER_AND_FRESH_SMOKE_VERIFIED'
    for item in provider_proof['native_backend_inputs']:
        assert audit.sha256(Path(item['path'])) == item['sha256']
    env.update(provider_env)
    env.update({'PATH':str(audit.TOOLCHAIN)+':'+env['PATH'],
                'RUSTC':str(audit.TOOLCHAIN/'rustc'),'CARGO_HOME':'/home/qq/.cargo',
                'CARGO_TARGET_DIR':str(audit.ROOT/'target'),'CARGO_BUILD_JOBS':'2'})
    audit.save_json(out/'environment.json',{key:env.get(key) for key in
                    ('PATH','RUSTC','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS',*provider_env)})
    audit.save_json(out/'scope.json',{'mode':mode,'commit':COMMIT,'tree':TREE,
                    'reason':'Exact-source recovery verification after local executor loss; does not replace prior failed observations.',
                    'runner_sha256':audit.sha256(Path(__file__)),
                    'helper_sha256':audit.sha256(Path(audit.__file__)),
                    'original_profiles_preserved':True,'test_threads':1,'cargo_jobs':2})
    before = verify_source(out,'before')
    assert audit.run(out,'preflight',['bash','scripts/project-preflight.sh'],env) == 0
    assert audit.run(out,'python-version',['python3','--version'],env) == 0
    results = []
    if mode == 'source-gates':
        commands = [
            ('corpus',['python3','scripts/ci/check_pq_research_integration.py']),
            ('corpus-negative',['python3','scripts/ci/test_pq_research_integration.py']),
            ('repository',['python3','scripts/ci/check_repository.py']),
            ('repository-negative',['python3','scripts/ci/test_repository.py']),
            ('project-boundary-negative',['python3','scripts/ci/test_project_boundary.py']),
            ('ci-source-integrity-negative',['python3','scripts/ci/test_ci_source_integrity.py']),
            ('claim-guard',['python3','scripts/ci/pq_chain_claim_guard.py']),
            ('claim-guard-negative',['python3','scripts/ci/test_pq_chain_claim_guard.py']),
            ('ci-contract-negative',['python3','scripts/ci/test_ci_contract.py']),
            ('inventory',['python3','scripts/refresh_distributed_source_inventory.py','--check']),
            ('format',['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check']),
            ('locked-metadata',['cargo','metadata','--manifest-path','trillionnium/Cargo.toml','--locked','--offline','--format-version','1']),
        ]
        for label,args in commands:
            code = audit.run(out,label,args,env)
            item = {'label':label,'exit_code':code}
            if label == 'locked-metadata' and code == 0:
                metadata = json.loads((out/(label+'.stdout.log')).read_text())
                item.update({'workspace_member_count':len(metadata['workspace_members']),
                             'package_count':len(metadata['packages'])})
            results.append(item)
            audit.save_json(out/'progress.json',results)
    else:
        build = ['cargo','test','--manifest-path','trillionnium/Cargo.toml','--locked','--offline',
                 '-p','trnm-data-availability','--all-targets','--all-features','-j','2',
                 '--no-run','--message-format=json']
        code = audit.run(out,'m09-build',build,env)
        results.append({'label':'m09-build','exit_code':code})
        if code == 0:
            identities = []
            for line in (out/'m09-build.stdout.log').read_text().splitlines():
                try: artifact = json.loads(line)
                except json.JSONDecodeError: continue
                if (artifact.get('reason') == 'compiler-artifact'
                    and artifact.get('profile',{}).get('test') is True
                    and artifact.get('executable')
                    and 'trnm-data-availability' in artifact.get('package_id','')):
                    binary = Path(artifact['executable'])
                    preserved = out/'binaries'/binary.name
                    preserved.parent.mkdir(exist_ok=True)
                    shutil.copyfile(binary,preserved)
                    preserved.chmod(binary.stat().st_mode & 0o777)
                    digest = audit.sha256(binary)
                    assert audit.sha256(preserved) == digest
                    identities.append({'target':artifact['target'],'features':artifact['features'],
                        'profile':artifact['profile'],'built_path':str(binary),'preserved_path':str(preserved),
                        'size':binary.stat().st_size,'sha256':digest})
            assert identities, 'missing M09 test executables'
            audit.save_json(out/'binary-identities.json',identities)
            commands = [
                ('m09-tests',['cargo','test','--manifest-path','trillionnium/Cargo.toml','--locked','--offline',
                    '-p','trnm-data-availability','--all-targets','--all-features','-j','2','--','--test-threads=1'],387),
                ('m09-docs',['cargo','test','--manifest-path','trillionnium/Cargo.toml','--locked','--offline',
                    '-p','trnm-data-availability','--doc','--all-features','-j','2','--','--test-threads=1'],10),
            ]
            for label,args,expected in commands:
                code = audit.run(out,label,args,env)
                text = (out/(label+'.stdout.log')).read_text()
                sums = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
                item = {'label':label,'exit_code':code,'summary_count':len(sums),
                        'passed':sum(int(row[0]) for row in sums),'failed':sum(int(row[1]) for row in sums),
                        'ignored':sum(int(row[2]) for row in sums),'expected_passed':expected}
                item['expected_inventory_matches'] = item['passed'] == expected
                results.append(item)
                audit.save_json(out/'progress.json',results)
                print(text,end='',flush=True)
    after = verify_source(out,'after')
    assert before == after
    passed = all(item['exit_code'] == 0 and item.get('expected_inventory_matches',True) for item in results)
    summary = {'commit':COMMIT,'tree':TREE,'mode':mode,'result':'PASS' if passed else 'FAIL',
               'source_unchanged':True,'source_files_sha256':EXPECTED_FILES,'results':results}
    audit.save_json(out/'summary.json',summary)
    print(json.dumps(summary),flush=True)
    return 0 if passed else 1

if __name__ == '__main__':
    sys.exit(main())
