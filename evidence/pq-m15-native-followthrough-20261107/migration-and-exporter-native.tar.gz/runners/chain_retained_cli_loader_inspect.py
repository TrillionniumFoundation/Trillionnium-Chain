#!/usr/bin/env python3
"""Inspect the retained CLI ELF without executing or altering either binary."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime, timezone

WORK = Path('/home/alex/work')
SUPPORT = WORK / 'chain-m15-regression-1c14fab4-13c7-runner-v2.py'
OUTPUT = WORK / 'chain-npq6-retained-cli-loader-13c7'
PINS = {
    'node-npq6': '4816721ef2ea829f904b6622443e14937fbd679df3ea777b99065f37c492b86f',
    'node-feature-off': '1e2a7b806318470cc37d389d6eb8ec41311aab43cdee2f17535aeaed6704aa68',
}

sys.dont_write_bytecode = True
if hashlib.sha256(SUPPORT.read_bytes()).hexdigest() != '750a23f7665477885627a80399b26bb7e887d2f4cf814e7230314123daa18def':
    raise ValueError('fixed identity helper changed')
spec = importlib.util.spec_from_file_location('fixed_native_support', SUPPORT)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
OUTPUT.mkdir(mode=0o700, exist_ok=False)
readelf = Path(shutil.which('readelf')).resolve(strict=True)
manifest = dict(schema='retained-npq6-cli-elf-loader-inspection-v1', result='RUNNING',
                started_utc=datetime.now(timezone.utc).isoformat(), inputs={}, commands=[],
                inspected_binary_executed=False, provider_runtime_qualified=False,
                clean_environment_loadability_proved=False, runner_sha256=m.sha(__file__),
                readelf_identity=m.file_identity(readelf))

def save():
    (OUTPUT / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')

save()
try:
    for name, expected in PINS.items():
        native = WORK / 'chain-npq6-provider-bound-13c7' / name
        before = m.file_identity(native)
        m.require(before['sha256'] == expected, 'retained CLI differs')
        manifest['inputs'][name] = dict(before=before)
        for label, flags in [('dynamic', ['-dW']), ('program', ['-lW'])]:
            argv = [str(readelf), *flags, str(native)]
            completed = subprocess.run(argv, capture_output=True, check=False)
            log = OUTPUT / (name + '-' + label + '.log')
            with log.open('xb') as stream:
                stream.write(completed.stdout)
                stream.write(completed.stderr)
            manifest['commands'].append(dict(argv=argv, exit_code=completed.returncode,
                                              log_identity=m.file_identity(log)))
            m.require(completed.returncode == 0, 'readelf inspection failed')
        after = m.file_identity(native)
        m.require(before == after, 'retained CLI changed during inspection')
        manifest['inputs'][name]['after'] = after
    version = subprocess.check_output([str(readelf), '--version'], text=True)
    manifest['readelf_version'] = version
    m.require(m.file_identity(readelf) == manifest['readelf_identity'], 'inspection tool changed')
    manifest['result'] = 'PASS'
finally:
    manifest['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
print(json.dumps(dict(result=manifest['result'], output=str(OUTPUT))))
