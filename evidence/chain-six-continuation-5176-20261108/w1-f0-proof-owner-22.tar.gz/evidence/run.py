import pathlib,subprocess,os,json,hashlib,time,re,traceback,datetime,tarfile,collections
root=pathlib.Path('/data/chain-six-5176-20261108/source')
out=pathlib.Path('/data/chain-six-5176-20261108/f0-proof-owner-22');out.mkdir()
target=pathlib.Path('/data/chain-six-5176-20261108/targets/qrom-stark')
expected='4505a598d6ec2644a175e47398d4a5f3f054bc5e'
original='1a446a79700cc093a2b1a7f10367ef4a5ddbd680'
archive=root/'evidence/chain-six-full-20261108/archives/proof-mmcs-f3-originals.tar.xz'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def describe(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
(out/'run.py').write_bytes(pathlib.Path('/proc/self/cmdline').read_bytes().split(b'\0')[2])
tmp=out/'temporary';tmp.mkdir()
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',RUSTFLAGS='-C target-cpu=native',PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(tmp))
env['PATH']='/home/qian-qi/.cargo/bin:'+env.get('PATH','')
os.sched_setaffinity(0,set(range(8)))
cgline=next(x for x in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::'))
cg=pathlib.Path('/sys/fs/cgroup')/cgline[3:].lstrip('/')
resources={'cpu_affinity':sorted(os.sched_getaffinity(0)),'host_exclusive':False,'cpu_limits_are_original_public_profile':False}
for name in ['cpu.max','memory.max','memory.swap.max']:resources[name]=(cg/name).read_text().strip()
manifest=root/'formal/pon-nakamoto-v1/w1_node_adapter_research/Cargo.toml'
command=['/home/qian-qi/.cargo/bin/cargo','+1.95.0','test','--manifest-path',str(manifest),'--release','--locked','--offline','--all-targets']
plan={'schema':'trnm-w1-f0-proof-owner-22-plan-v1','source_head':expected,'historical_reference_source':original,'created_utc':stamp(),
 'test_command':command+['--','--test-threads=1'],'prebuild_command':command+['--no-run','--message-format=json'],
 'compiler_policy':{k:env[k] for k in ['CARGO_BUILD_JOBS','RAYON_NUM_THREADS','RUSTFLAGS','CARGO_TARGET_DIR','TMPDIR']},
 'resources':resources,'expected_roster_count':22,'expected_nonempty_targets':{'node_bridge':12,'proof_start_owner':10},
 'new_complete_proofs_generated':0,'historical_F3_execution_relabelled_as_F0':False,
 'production_activation':False,'qualification':'HOLD_NO_GO'}
save(out/'plan.json',plan)
records=[]
def run(name,args,timeout=900):
 print(json.dumps({'stage':name,'started_utc':stamp()}),flush=True)
 start=time.monotonic()
 with (out/(name+'.stdout')).open('xb') as sout,(out/(name+'.stderr')).open('xb') as serr:
  proc=subprocess.run(args,cwd=root,env=env,stdout=sout,stderr=serr,timeout=timeout)
 rec={'name':name,'arguments':args,'cwd':str(root),'exit_code':proc.returncode,'wall_seconds':time.monotonic()-start,
 'stdout_sha256':sha(out/(name+'.stdout')),'stderr_sha256':sha(out/(name+'.stderr'))}
 save(out/(name+'.result.json'),rec);records.append(rec)
 print(json.dumps({'stage':name,'exit_code':proc.returncode,'wall_seconds':rec['wall_seconds']}),flush=True)
 if proc.returncode:raise RuntimeError(name+' failed')
 return rec
def source(name):
 return run(name,['/usr/bin/python3','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',expected,'--output',str(out/(name+'.json'))],300)
success=False
failure=None
try:
 assert git('rev-parse','HEAD')==expected
 assert sha(archive)=='3a620d4e0fc597913d37bfc3eac7cc1c9cfb90d2ff7c398a535425d9fd7de319'
 with tarfile.open(archive,'r:xz') as t:
  roster_bytes=t.extractfile('proof-final-f3/06-test-roster.json').read()
  old_env=t.extractfile('proof-final-f3/environment.json').read()
 (out/'historical-f3-roster.json').write_bytes(roster_bytes)
 (out/'historical-f3-environment.json').write_bytes(old_env)
 roster=json.loads(roster_bytes)['registered']
 assert len(roster)==22 and len(set(roster))==22
 assert json.loads(old_env)['source']['head']==original
 run('01-preflight-before',['bash','scripts/project-preflight.sh','--audit'],300)
 source('02-source-before')
 run('03-toolchain',['/home/qian-qi/.cargo/bin/rustc','+1.95.0','-Vv'],60)
 build=run('04-test-build',plan['prebuild_command'],1200)
 artifacts=[]
 for line in (out/'04-test-build.stdout').read_text().splitlines():
  try:obj=json.loads(line)
  except json.JSONDecodeError:continue
  if obj.get('reason')=='compiler-artifact' and obj.get('executable') and 'w1-node-adapter-research' in obj.get('package_id',''):
   artifacts.append({'target':obj['target']['name'],'kind':obj['target']['kind'],'test_profile':obj['profile']['test'],'file':describe(pathlib.Path(obj['executable']))})
 tests=[x for x in artifacts if x['test_profile']]
 assert len(tests)==4,(len(tests),artifacts)
 assert {x['target'] for x in tests}=={'w1_node_adapter_research','w1-node-adapter-research','node_bridge','proof_start_owner'},artifacts
 cli=target/'release/w1-node-adapter-research'
 assert cli.is_file()
 before={'test_targets':tests,'all_current_package_executables':artifacts,'actual_cli':describe(cli)}
 save(out/'05-binaries-before.json',before)
 for row in tests:
  run('05-roster-'+row['target'],[row['file']['path'],'--list'],60)
 target_rosters={}
 for row in tests:
  names=re.findall(r'^(.+): test$',(out/('05-roster-'+row['target']+'.stdout')).read_text(),re.M)
  target_rosters[row['target']]=names
 assert len(target_rosters['node_bridge'])==12 and len(target_rosters['proof_start_owner'])==10,target_rosters
 assert not target_rosters['w1_node_adapter_research'] and not target_rosters['w1-node-adapter-research']
 registered=[n for a in target_rosters.values() for n in a]
 assert collections.Counter(registered)==collections.Counter(roster),{'expected':roster,'registered':registered}
 save(out/'05-current-registered-roster.json',{'targets':target_rosters,'registered':sorted(registered),'historical_name_set_exactly_equal':True})
 actual=run('06-tests',plan['test_command'],300)
 text=(out/'06-tests.stdout').read_text()
 passed=re.findall(r'^test (\S+) \.\.\. ok$',text,re.M)
 groups=[[int(x) for x in m] for m in re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M)]
 assert collections.Counter(passed)==collections.Counter(roster),{'actual_passes':passed,'expected':roster}
 assert groups==[[0,0,0,0,0],[0,0,0,0,0],[12,0,0,0,0],[10,0,0,0,0]],groups
 save(out/'07-test-roster.json',{'registered':sorted(registered),'successful':sorted(passed),'unique_passes':len(set(passed)),'results':groups,
 'by_target':target_rosters,'nonempty_required_count':22,'name_set_exact':True,'source_head':expected,'new_complete_proofs_generated':0,'qualification':'HOLD_NO_GO'})
 after={'test_targets':[dict(row,file=describe(pathlib.Path(row['file']['path']))) for row in tests],
 'all_current_package_executables':[dict(row,file=describe(pathlib.Path(row['file']['path']))) for row in artifacts],
 'actual_cli':describe(cli)}
 save(out/'08-binaries-after.json',after)
 assert before==after,'compiled binary content changed during test execution'
 source('09-source-after')
 assert (out/'02-source-before.json').read_bytes()==(out/'09-source-after.json').read_bytes(),'source verifier before/after mismatch'
 run('10-preflight-after',['bash','scripts/project-preflight.sh','--audit'],300)
 assert git('rev-parse','HEAD')==expected
 success=True
except BaseException as exc:
 failure={'exception':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
 save(out/'failure.json',failure)
 print(json.dumps({'status':'FAIL','failure':failure}),flush=True)
 try:source('failure-source-after')
 except BaseException:pass
 try:run('failure-preflight-after',['bash','scripts/project-preflight.sh','--audit'],300)
 except BaseException:pass
summary={'schema':'trnm-w1-f0-proof-owner-22-observation-v1','status':'PASS' if success else 'FAIL','source_head':expected,
 'historical_reference_source':original,'historical_F3_execution_relabelled_as_F0':False,'test_command':plan['test_command'],
 'expected_named_tests':22,'passed_named_tests':22 if success else None,'expected_target_counts':{'node_bridge':12,'proof_start_owner':10},
 'all_tracked_source_verified_before_after':success,'compiled_test_and_cli_binaries_identical_before_after':success,
 'new_complete_proofs_generated':0,'proof_inputs':'two retained complete STARK fixtures read by existing integration tests',
 'fresh_generation_from_prior_archive_claimed_for_this_run':False,'compiler_policy':plan['compiler_policy'],'resources':resources,
 'qualification':'HOLD_NO_GO','production_activation':False,'same_resource_net_benefit_qualified':False,
 'compositional_post_quantum_qualified':False,'unknown_security_bounds':None,'finished_utc':stamp(),
 'stages':records,'failure':failure}
save(out/'summary.json',summary)
print(json.dumps({'status':summary['status'],'source_head':expected,'passed_named_tests':summary['passed_named_tests'],
 'new_complete_proofs_generated':0,'directory':str(out),'summary':describe(out/'summary.json')}),flush=True)
if not success:raise SystemExit(1)
