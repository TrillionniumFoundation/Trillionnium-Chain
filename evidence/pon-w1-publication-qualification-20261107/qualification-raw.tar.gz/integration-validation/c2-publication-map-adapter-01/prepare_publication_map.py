#!/usr/bin/env python3
"""Prepare a publication frozen map from an externally fixed, committed C2.

This does not run CI, build, prove, checkout, commit, fetch, push or change the
repository. It is a future read-only adapter: only its new external out is written.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import time

BASE_HEAD = "0f18f93f2d35b62c6ca6d63faf4f336d55cbf4bf"
BASE_TREE = "94334bb6b52cfd13040059a5e71f47d8cc9603f2"
BASE_FROZEN_SHA = "76191b6db1baeb5eb897f1adfe7eea7bf3a5bb73a2f05ca809f9f74248f9be71"
WRAPPER_SHA = "c6fa6f1d080c1a50424d646670280ed962e0330eef4a410c14fd93ac5c2e4c74"
PLAN = "docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md"
EVIDENCE = "evidence/pon-w1-fresh-runtime-20261107"
CORPUS = "config/pon/pq-cross-branch-corpus-v1.json"


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def git_blob(raw: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def relative_name(value: str) -> str:
    p = PurePosixPath(value)
    require(type(value) is str and value and not p.is_absolute()
            and ".." not in p.parts and "." not in p.parts
            and str(p) == value and "\n" not in value and "\r" not in value,
            "unambiguous repository-relative path required")
    return value


def read_regular(path: Path) -> bytes:
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), "ordinary file required: " + str(path))
    raw = path.read_bytes()
    after = path.lstat()
    require(all(getattr(before, key) == getattr(after, key)
                for key in ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")),
            "file changed during read: " + str(path))
    return raw


def pin(path: Path) -> dict:
    raw = read_regular(path)
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}


def save_new(path: Path, value: dict) -> dict:
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, sort_keys=True, indent=2, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return pin(path)


def tree_entries(raw: bytes) -> dict:
    result = {}
    require(raw.endswith(b"\0"), "nonempty complete Git tree required")
    for item in raw[:-1].split(b"\0"):
        left, name = item.split(b"\t", 1)
        mode, kind, oid = left.decode("ascii").split(" ")
        relative = relative_name(name.decode("utf-8"))
        require(relative not in result and re.fullmatch(r"[0-9a-f]{40}", oid),
                "duplicate path or non-full Git object identity")
        result[relative] = {"mode": mode, "kind": kind, "blob": oid}
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--base-frozen-record", type=Path, required=True)
    parser.add_argument("--exact-ci-wrapper", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--exact-out", type=Path, required=True)
    args = parser.parse_args()
    for value in (args.expected_head, args.expected_tree):
        require(re.fullmatch(r"[0-9a-f]{40}", value) is not None,
                "external full commit and full tree required")
    repo = args.repo.resolve(strict=True)
    require(args.expected_head != BASE_HEAD, "C2 must be a distinct committed publication head")
    for out in (args.out, args.exact_out):
        require(out.is_absolute() and not out.exists() and not out.is_symlink()
                and not out.resolve().is_relative_to(repo),
                "new absolute external output required")
    require(args.out.resolve() != args.exact_out.resolve(), "preparation and exact outputs must differ")
    base_raw = read_regular(args.base_frozen_record)
    require(sha(base_raw) == BASE_FROZEN_SHA, "external original C1b frozen-record SHA differs")
    base = json.loads(base_raw)
    require(type(base.get("paths")) is dict and len(base["paths"]) == 638,
            "original 638-path C1b record required")
    for name in base["paths"]:
        relative_name(name)
    wrapper = pin(args.exact_ci_wrapper)
    require(wrapper["sha256"] == WRAPPER_SHA, "frozen exact CI wrapper v3 differs")
    args.out.mkdir()
    out = args.out
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "GIT_NO_LAZY_FETCH": "1"}
    attempt = {
        "schema": "TRNM-W1-C2-PUBLICATION-MAP-PREPARATION1",
        "source_commit": args.expected_head, "source_tree": args.expected_tree,
        "base_commit": BASE_HEAD, "base_tree": BASE_TREE,
        "base_frozen_record": pin(args.base_frozen_record),
        "wrapper": pin(Path(__file__).resolve()), "exact_ci_wrapper": wrapper,
        "commands": [], "errors": [], "preparation_complete": False,
        "exact_CI_executed": False, "fresh_proof_generations": 0,
        "repository_mutated": False,
    }

    def run(label: str, argv: list[str], timeout: int = 180) -> bytes:
        stdout, stderr = out / (label + ".stdout"), out / (label + ".stderr")
        begin = time.monotonic_ns()
        row = {"label": label, "argv": argv, "cwd": str(repo), "timeout_seconds": timeout}
        with stdout.open("xb") as so, stderr.open("xb") as se:
            try:
                completed = subprocess.run(argv, cwd=repo, env=env, stdin=subprocess.DEVNULL,
                                           stdout=so, stderr=se, timeout=timeout, check=False)
                row.update(exit=completed.returncode, timed_out=False)
            except subprocess.TimeoutExpired:
                row.update(exit=None, timed_out=True)
            so.flush(); os.fsync(so.fileno())
            se.flush(); os.fsync(se.fileno())
        row.update(elapsed_ns=time.monotonic_ns() - begin, stdout=pin(stdout), stderr=pin(stderr))
        attempt["commands"].append(row)
        require(row["exit"] == 0 and not row["timed_out"], "read-only command failed: " + label)
        return read_regular(stdout)

    try:
        run("00-preflight", ["/usr/bin/bash", "scripts/project-preflight.sh", "--dev"])
        identities = run("01-git-identities", [
            "git", "rev-parse", "--verify", "HEAD"]).decode().strip()
        require(identities == args.expected_head, "worktree HEAD is not the external C2")
        actual_tree = run("02-git-tree", [
            "git", "rev-parse", args.expected_head + "^{tree}"]).decode().strip()
        require(actual_tree == args.expected_tree, "external C2 tree differs")
        actual_base_tree = run("03-base-tree", [
            "git", "rev-parse", BASE_HEAD + "^{tree}"]).decode().strip()
        require(actual_base_tree == BASE_TREE, "retained C1b tree differs")
        parents = run("04-publication-parents", [
            "git", "show", "--no-patch", "--format=%P", args.expected_head]).decode().strip().split()
        require(parents == [BASE_HEAD], "C2 must directly append one publication commit to fixed C1b")
        run("05-source-before", [
            "/usr/bin/python3", "scripts/ci/verify_ci_source.py", "--kind", "head",
            "--expected-head", args.expected_head, "--output", str(out / "source-before.json")], 300)
        source_before = json.loads(read_regular(out / "source-before.json"))
        require(source_before.get("tested_commit") == args.expected_head
                and source_before.get("tested_tree") == args.expected_tree
                and source_before.get("tracked_worktree_verified") is True
                and source_before.get("tests_executed_by_identity_check") is False,
                "actual current C2 source guard failed")
        old_tree = tree_entries(run("06-C1b-tree", ["git", "ls-tree", "-r", "-z", "--full-tree", BASE_HEAD]))
        new_tree = tree_entries(run("07-C2-tree", ["git", "ls-tree", "-r", "-z", "--full-tree", args.expected_head]))
        changed = sorted(name for name in set(old_tree) | set(new_tree)
                         if old_tree.get(name) != new_tree.get(name))
        require(PLAN in changed, "publication plan append is required")
        require(not any(name == EVIDENCE or name.startswith(EVIDENCE + "/") for name in old_tree),
                "evidence directory must be newly added after C1b")
        added_evidence = []
        for name in changed:
            if name == PLAN:
                require(name in old_tree and name in new_tree
                        and old_tree[name]["mode"] == new_tree[name]["mode"],
                        "sole plan must remain the same ordinary tracked path")
            else:
                require(name.startswith(EVIDENCE + "/") and name not in old_tree and name in new_tree,
                        "C1b -> C2 must only append sole plan and add the fixed evidence directory: " + name)
                added_evidence.append(name)
            require(new_tree[name]["kind"] == "blob" and new_tree[name]["mode"] in ("100644", "100755"),
                    "publication files must be ordinary tracked blobs")
        require(added_evidence, "actual new evidence files required")
        require(CORPUS not in changed, "C2 cannot modify corpus or source pins")

        def current_identity(name: str) -> dict:
            relative_name(name)
            path = repo / name
            require(not any(parent.is_symlink() for parent in path.parents if parent != repo.parent),
                    "symlink parent is not a repository source")
            raw = read_regular(path)
            blob = git_blob(raw)
            require(new_tree[name]["kind"] == "blob" and new_tree[name]["mode"] in ("100644", "100755")
                    and blob == new_tree[name]["blob"], "current bytes differ from actual committed C2: " + name)
            return {"sha256": sha(raw), "git_blob": blob, "bytes": len(raw)}

        paths = {}
        for name, old in base["paths"].items():
            require(name in old_tree and name in new_tree and old_tree[name]["kind"] == "blob"
                    and old["git_blob"] == old_tree[name]["blob"], "original map is not bound to fixed C1b: " + name)
            identity = current_identity(name)
            if name == PLAN:
                raw = read_regular(repo / name)
                require(len(raw) > old["bytes"] and sha(raw[:old["bytes"]]) == old["sha256"],
                        "C2 sole plan must preserve the complete actual C1b prefix")
            else:
                require(identity == old and old_tree[name] == new_tree[name],
                        "frozen C1b runtime/source/corpus changed: " + name)
            paths[name] = identity
        for name in added_evidence:
            paths[name] = current_identity(name)
        record = {
            "schema": "TRNM-W1-PUBLICATION-FROZEN-SOURCES1",
            "base_commit": BASE_HEAD, "base_tree": BASE_TREE,
            "publication_commit": args.expected_head, "publication_tree": args.expected_tree,
            "previous_frozen_record": pin(args.base_frozen_record),
            "allowed_plan": PLAN, "allowed_new_evidence_root": EVIDENCE,
            "paths": {name: paths[name] for name in sorted(paths)},
        }
        frozen = save_new(out / "frozen-sources.json", record)
        run("08-source-after", [
            "/usr/bin/python3", "scripts/ci/verify_ci_source.py", "--kind", "head",
            "--expected-head", args.expected_head, "--output", str(out / "source-after.json")], 300)
        source_after = json.loads(read_regular(out / "source-after.json"))
        require(source_before == source_after, "publication source changed during preparation")
        require(all(current_identity(name) == identity for name, identity in paths.items()),
                "publication frozen bytes changed during preparation")
        require(sha(read_regular(args.base_frozen_record)) == BASE_FROZEN_SHA,
                "original C1b frozen record changed during preparation")
        require(pin(args.exact_ci_wrapper) == wrapper, "exact wrapper changed")
        exact_argv = [
            "/usr/bin/python3", str(args.exact_ci_wrapper), "--repo", str(repo),
            "--expected-head", args.expected_head, "--expected-tree", args.expected_tree,
            "--qualification-phase", "publication-head",
            "--candidate-source-record", frozen["path"],
            "--candidate-source-record-sha256", frozen["sha256"], "--out", str(args.exact_out),
        ]
        attempt.update(
            preparation_complete=True, source_before=pin(out / "source-before.json"),
            source_after=pin(out / "source-after.json"), source_identity_equal_before_after=True,
            changed_paths=changed, added_evidence_paths=added_evidence,
            frozen_source_record=frozen, frozen_path_count=len(paths),
            old_runtime_and_corpus_unchanged=True, complete_C1b_plan_prefix_retained=True,
            planned_exact_ci_argv=exact_argv, planned_exact_command_count=19,
            planned_selected_test_methods=471, planned_mandatory_test_methods=104,
        )
    except Exception as error:
        attempt["errors"].append({"type": type(error).__name__, "message": str(error)})
    receipt = save_new(out / "manifest.json", attempt)
    print(json.dumps({"preparation_complete": attempt["preparation_complete"],
                      "manifest": receipt, "frozen_source_record": attempt.get("frozen_source_record"),
                      "exact_CI_executed": False, "errors": attempt["errors"]}), flush=True)
    return 0 if attempt["preparation_complete"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

