#!/usr/bin/env python3
"""Report complete default receiver/actual attacker costs for each capture mode."""
import hashlib
import json
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
summary_path = HERE / "summary.json"
summary = json.loads(summary_path.read_text())
assert summary["result"] == "PASS_RETAINED_READER_AND_PROVENANCE_CONSISTENCY"
assert summary["production_and_full_limb_are_same_arithmetic_kernel"] is True
result = {
    "schema": "pon-w1-default-production-rejection-ratios-v1",
    "run_id": summary["run_id"],
    "source_commit": summary["source_binding"]["source_commit"],
    "source_summary_sha256": hashlib.sha256(summary_path.read_bytes()).hexdigest(),
    "default_kernel": "FullLimb",
    "numerator": "sum of production-column complete native receiver rejection CPU for all observed candidates in that capture",
    "denominator": "sum of actual inclusive attacker setup-and-four-search cohort CPU, including every attempt, from the same capture",
    "per_material_ratio_scope": "minimum and maximum across nine material classes after summing all eight samples within each class; each class includes eight actual setups and 32 searches",
    "whole_lane_aggregation_key": ["campaign_mode", "architecture", "source_kind"],
    "per_material_aggregation_key_within_lane": ["class"],
    "per_material_sample_aggregation_key_within_lane": ["class", "sample"],
    "modes_pooled": False,
    "modes_averaged": False,
    "explicit_full_column_added_to_default": False,
    "cheapest_adversary_lower_bound": False,
    "public_network_amplification_measured": False,
    "public_service_accepted": False,
    "modes": {},
}

for mode, label in (("original", "original-4-path-campaign"), ("full-limb", "explicit-5-path-campaign")):
    captures = [lane for lane in summary["false_trace_lanes"] if lane["mode"] == mode]
    assert len(captures) == 4
    assert {(lane["architecture"], lane["source_kind"]) for lane in captures} == {
        ("x64", "head"), ("x64", "prospective-merge"),
        ("arm64", "head"), ("arm64", "prospective-merge"),
    }
    lanes = []
    for capture in captures:
        receiver = capture["actual_receiver_cpu_ns"]["production"]
        attacker = capture["actual_inclusive_attacker_cohort_cpu_ns"]
        assert receiver > 0 and attacker > 0
        ratio = receiver / attacker
        assert ratio == capture["receiver_over_complete_attacker_cpu"]["production"]
        directory = "w1-false-trace-reuse-v1" if mode == "original" else "w1-full-limb-reuse-v1"
        raw_path = HERE.parent / f"ci-captures/run-{summary['run_id']}" / str(capture["artifact_id"]) / directory / "campaign.stdout"
        per_sample = {}
        for line in raw_path.read_text().splitlines():
            row = json.loads(line)
            if row["kind"] == "campaign":
                assert row["samples"] == 8 and row["searches_per_setup"] == 4
            elif row["kind"] == "cohort":
                key = (row["class"], row["sample"])
                assert key not in per_sample
                per_sample[key] = {"class": row["class"], "sample": row["sample"],
                                   "actual_setup_calls": row["setup_calls"], "actual_searches": row["searches"],
                                   "receiver_cpu_ns": 0, "receiver_calls": 0,
                                   "actual_attacker_cohort_cpu_ns": row["total"]["cpu_ns"]}
            elif row["kind"] == "verifier" and row["path"] == "production":
                sample = per_sample[(row["class"], row["sample"])]
                assert row["outcome"] == "Transcript"
                sample["receiver_cpu_ns"] += row["timing"]["cpu_ns"]
                sample["receiver_calls"] += 1
        assert len(per_sample) == 72
        per_material = defaultdict(lambda: {"samples": 0, "actual_setup_calls": 0, "actual_searches": 0,
                                           "receiver_cpu_ns": 0, "receiver_calls": 0,
                                           "actual_attacker_cohort_cpu_ns": 0})
        for (material, _), sample in per_sample.items():
            assert sample["actual_setup_calls"] == 1 and sample["actual_searches"] == sample["receiver_calls"] == 4
            sample["ratio"] = sample["receiver_cpu_ns"] / sample["actual_attacker_cohort_cpu_ns"]
            aggregate = per_material[material]
            aggregate["samples"] += 1
            for key in ("actual_setup_calls", "actual_searches", "receiver_cpu_ns", "receiver_calls", "actual_attacker_cohort_cpu_ns"):
                aggregate[key] += sample[key]
        assert len(per_material) == 9
        assert sum(value["receiver_cpu_ns"] for value in per_material.values()) == receiver
        assert sum(value["actual_attacker_cohort_cpu_ns"] for value in per_material.values()) == attacker
        for material, aggregate in per_material.items():
            aggregate["class"] = material
            aggregate["ratio"] = aggregate["receiver_cpu_ns"] / aggregate["actual_attacker_cohort_cpu_ns"]
            assert aggregate["samples"] == aggregate["actual_setup_calls"] == 8
            assert aggregate["actual_searches"] == aggregate["receiver_calls"] == 32
        per_material_range = {"minimum": min(value["ratio"] for value in per_material.values()),
                              "maximum": max(value["ratio"] for value in per_material.values())}
        assert per_material_range == capture["per_material_receiver_over_attacker_range"]["production"]
        samples_by_ratio = sorted(per_sample.values(), key=lambda value: value["ratio"])
        lanes.append({
            **{key: capture[key] for key in ("artifact_id", "architecture", "source_kind", "source_commit", "reported_cpu_fields", "complete_record_counts", "all_attempts", "exhausted_searches")},
            "receiver_cpu_ns": receiver,
            "actual_attacker_cohort_cpu_ns": attacker,
            "whole_lane_ratio": ratio,
            "raw_campaign_sha256": hashlib.sha256(raw_path.read_bytes()).hexdigest(),
            "per_material_ratio_range": per_material_range,
            "per_material_totals": [per_material[material] for material in sorted(per_material)],
            "per_material_sample_cohort_range": {"count": 72,
                                                 "minimum": samples_by_ratio[0]["ratio"],
                                                 "maximum": samples_by_ratio[-1]["ratio"],
                                                 "minimum_record": samples_by_ratio[0],
                                                 "maximum_record": samples_by_ratio[-1]},
        })
    lanes.sort(key=lambda lane: (lane["architecture"], lane["source_kind"]))
    result["modes"][label] = {
        "lanes": lanes,
        "whole_lane_ratio_range": {
            "minimum": min(lane["whole_lane_ratio"] for lane in lanes),
            "maximum": max(lane["whole_lane_ratio"] for lane in lanes),
        },
        "per_material_ratio_range": {
            "minimum": min(lane["per_material_ratio_range"]["minimum"] for lane in lanes),
            "maximum": max(lane["per_material_ratio_range"]["maximum"] for lane in lanes),
        },
        "per_material_sample_cohort_range": {
            "minimum": min(lane["per_material_sample_cohort_range"]["minimum"] for lane in lanes),
            "maximum": max(lane["per_material_sample_cohort_range"]["maximum"] for lane in lanes),
        },
    }

output = HERE / "default-production-rejection-ratios.json"
output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({"path": str(output), "ranges": {name: {key: value[key] for key in ("whole_lane_ratio_range", "per_material_ratio_range")} for name, value in result["modes"].items()}}), flush=True)
