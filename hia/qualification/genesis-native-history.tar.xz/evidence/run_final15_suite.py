from pathlib import Path
import json,os,subprocess,sys,time,traceback
BASE=Path("/tmp/trnm-genesis-owner-20261116-8ppak97a")
ROOT=BASE/"repo"
kind=sys.argv[1]
if kind not in ("semantic","crash","prefix","namespace","corruption"):raise ValueError("Unknown suite")
output=BASE/("final15-"+kind)
receipt={"schema":"trnm.genesis-suite-execution.v1","suite":kind,"output":str(output),"status":"FAIL"}
start=time.monotonic_ns()
try:
    pre=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (BASE/("final15-"+kind+"-preflight.stdout.raw")).write_bytes(pre.stdout)
    (BASE/("final15-"+kind+"-preflight.stderr.raw")).write_bytes(pre.stderr)
    if pre.returncode:raise RuntimeError("Project preflight failed")
    argv=[sys.executable,"-B","-m","hia.platform.genesis_store.qualify","--suite",kind,"--output",str(output)]
    receipt["command"]=argv
    print(json.dumps({"suite":kind,"phase":"starting-real-native-build-and-controls"}),flush=True)
    run=subprocess.run(argv,cwd=ROOT)
    receipt["exit_code"]=run.returncode
    receipt["status"]="PASS" if run.returncode==0 else "FAIL"
except BaseException as error:
    receipt["failure"]={"error":repr(error),"traceback":traceback.format_exc()}
finally:
    receipt["elapsed_ns"]=time.monotonic_ns()-start
    with (BASE/("final15-"+kind+"-execution.json")).open("x") as stream:
        stream.write(json.dumps(receipt,sort_keys=True,indent=2)+"\n")
    print(json.dumps(receipt),flush=True)
raise SystemExit(0 if receipt["status"]=="PASS" else 1)
