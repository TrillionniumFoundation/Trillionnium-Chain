"""Verify the downloaded CI input artifact and unpack it without links."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import tarfile
import zipfile

root = Path(__file__).resolve().parent
artifact = root / 'ci-artifacts/pon-cloud-model-inputs-920e269a.zip'
expected = '9b3a907fd793ed5178eab6656587e5798efc13b64d715a226b4b85781fc71926'
assert hashlib.file_digest(artifact.open('rb'), 'sha256').hexdigest() == expected
output = root / 'model-inputs-920e269a'
output.mkdir()
with zipfile.ZipFile(artifact) as wrapper:
    names = wrapper.namelist()
    selected = [name for name in names if name.endswith('/pon-cloud-model-inputs.tar.gz') or name == 'pon-cloud-model-inputs.tar.gz']
    assert len(selected) == 1
    with wrapper.open(selected[0]) as stream, tarfile.open(fileobj=stream, mode='r|gz') as bundle:
        total = 0
        for member in bundle:
            name = member.name.removeprefix('./').rstrip('/')
            if not name or name == '.':
                assert member.isdir()
                continue
            path = PurePosixPath(name)
            assert not path.is_absolute() and '..' not in path.parts and str(path) == name
            target = output / name
            if member.isdir():
                target.mkdir(exist_ok=True)
                continue
            assert member.isfile() and member.size <= 300 * 1024**2
            total += member.size
            assert total <= 768 * 1024**2
            target.parent.mkdir(parents=True, exist_ok=True)
            with bundle.extractfile(member) as source, target.open('xb') as destination:
                while data := source.read(1024**2):
                    destination.write(data)
            assert target.stat().st_size == member.size
manifest = json.loads((output / 'input-manifest.json').read_text())
inventory = {p.relative_to(output).as_posix(): p for p in output.rglob('*') if p.is_file() and p.name != 'input-manifest.json'}
assert set(inventory) == set(manifest['files'])
for name, path in inventory.items():
    pin = manifest['files'][name]
    assert path.stat().st_size == pin['size']
    assert hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == pin['sha256'], name
assert sum(p.stat().st_size for p in inventory.values()) == manifest['total_file_bytes']
report = dict(artifact_sha256=expected, input_manifest_sha256=hashlib.file_digest((output/'input-manifest.json').open('rb'),'sha256').hexdigest(),
              model_revision=manifest['revision'], file_count=len(inventory), input_bytes=manifest['total_file_bytes'],
              requirements_sha256=manifest['requirements_sha256'], all_input_hashes_verified=True)
(root / 'evidence/model-input-integrity.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report), flush=True)
