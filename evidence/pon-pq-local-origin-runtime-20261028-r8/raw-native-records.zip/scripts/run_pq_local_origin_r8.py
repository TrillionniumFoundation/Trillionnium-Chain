#!/usr/bin/env python3
"""One bounded, fully retained local PQ repair verification; no deployed state."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/56818e4fba76/chain-recovered')
OUT = Path(__file__).resolve().parent/'pq-local-origin-candidate-attempt1'
GUARD = Path('/tmp/w1-batch-phase0-guard-20261028-r8.py')
GUARD_SHA = '9981c3a138c4aefb6c4662f1e2c4c05cf5ef26e302c46763a42a2366a6334217'
SOURCE = '990aeb651f793ca44bf94b074356be06e58e75c1'

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def identity():
    paths = subprocess.check_output(['git','ls-files','-z','--','trillionnium','formal/pon-nakamoto-v1','config'],cwd=ROOT).decode().split('\0')
    return {'commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
            'files': {p:sha(ROOT/p) for p in sorted(paths) if p and Path(p).suffix in ('.rs','.py','.toml','.lock','.json')}}

def denominator(text):
    match = re.search(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    return None if match is None else {'status':match[1],'passed':int(match[2]),'failed':int(match[3]),'ignored':int(match[4])}

test_base = ['cargo','test','--manifest-path','trillionnium/Cargo.toml','--locked','--offline','-p','trnm-pon-node','--lib','--features','pq-native-openssl']
commands = [
    ('preflight',['bash','scripts/project-preflight.sh'],None),
    ('format',['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'],None),
    ('locked-graph',['cargo','metadata','--manifest-path','trillionnium/Cargo.toml','--locked','--offline','--all-features','--format-version','1'],None),
    ('strict-clippy',['cargo','clippy','--manifest-path','trillionnium/Cargo.toml','--locked','--offline','--workspace','--all-targets','--all-features','--','-D','warnings'],None),
    ('pq-network',test_base+['ingress::pq_network::tests::','--','--nocapture','--test-threads=1'],10),
    ('error-origin',test_base+['error::tests::','--','--nocapture','--test-threads=1'],10),
]

if sys.argv[1:] == ['--inside']:
    records = []
    for label,argv,expected in commands:
        started = time.monotonic()
        row = {'label':label,'argv':argv,'expected_tests':expected,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        (OUT/(label+'.started.json')).write_text(json.dumps(row,indent=2)+'\n')
        with (OUT/(label+'.stdout')).open('wb') as stdout, (OUT/(label+'.stderr')).open('wb') as stderr:
            result = subprocess.run(argv,cwd=ROOT,stdout=stdout,stderr=stderr)
        row.update(returncode=result.returncode,wall_seconds=time.monotonic()-started)
        if expected is not None:
            row['tests'] = denominator((OUT/(label+'.stdout')).read_text())
            row['expected_denominator_observed'] = row['tests'] is not None and sum(row['tests'][k] for k in ('passed','failed','ignored')) == expected
        records.append(row)
        (OUT/'pipeline-results.json').write_text(json.dumps(records,indent=2)+'\n')
        print(json.dumps(row),flush=True)
        if result.returncode and (expected is None or row['tests'] is None):
            break
    passed = len(records)==len(commands) and all(r['returncode']==0 and r.get('expected_denominator_observed',True) for r in records)
    raise SystemExit(0 if passed else 1)

assert not sys.argv[1:]
OUT.mkdir(exist_ok=False)
assert sha(GUARD)==GUARD_SHA
preflight=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=ROOT,capture_output=True)
(OUT/'admission.stdout').write_bytes(preflight.stdout)
(OUT/'admission.stderr').write_bytes(preflight.stderr)
assert preflight.returncode==0
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
before=identity()
assert before['commit']==SOURCE
(OUT/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
prefix=Path('/tmp/pure-pon-openssl-3.5.9')
cli=prefix/'bin/openssl'
assert sha(cli)=='0f9db29e103b1c7da08c7fe45ae47f84a0e9c388775520114598646a9041867f'
env=dict(os.environ,PATH='/tmp/pure-pon-toolchain-20261027/bin:'+os.environ['PATH'],
         CARGO_HOME='/tmp/pure-pon-cargo-20261027',CARGO_TARGET_DIR='/tmp/chain-pq-target-56818e4fba76',
         CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',
         OPENSSL_DIR=str(prefix),OPENSSL_STATIC='1',TRNM_PQ_OPENSSL=str(cli),
         TRNM_PQ_OPENSSL_SHA256=sha(cli),TRNM_PQ_OPENSSL_VERSION='3.5.9',
         OPENSSL_CONF='/dev/null',OPENSSL_MODULES=str(prefix/'lib64/ossl-modules'),PYTHONDONTWRITEBYTECODE='1')
limits={'wall_seconds':800,'cpu_seconds':1000,'rss_bytes':3221225472,'target_growth_bytes':805306368,'min_free_bytes':1073741824}
prior=[]
for name in ('pq-post-intent-baseline','pq-post-intent-baseline-attempt2'):
    p=OUT.parent/name/'result.json';r=json.loads(p.read_text())
    prior.append({'path':str(p),'sha256':sha(p),'status':r['guard']['status'],
                  'wall_seconds':r['guard']['elapsed_seconds'],'cpu_seconds':r['guard']['cpu_peak_seconds'],
                  'tests':r['test_result']})
intent={'schema':'pon-r8-native-pq-local-origin-candidate-v1','source':SOURCE,'runner_sha256':sha(__file__),
        'guard_sha256':GUARD_SHA,'commands':commands,'limits':limits,'prior_baseline_attempts':prior,
        'expected_pq_tests':10,'original_pq_tests_retained':6,'new_pq_tests':4,
        'expected_error_tests':10,'original_error_tests_retained':9,'new_error_tests':1,
        'deadline_calls':5,'deadline_honest_followups':3,'expiry_calls':5,'expiry_honest_followups':3,
        'signed_remote_socket_cases':6,'injected_origin_durable_intents':15,
        'origin_cases_are_actual_time_or_revocation_events':False,
        'budgets_are_sampled_stop_thresholds_not_kernel_hard_caps':True,
        'original_request_deadline_seconds':10,'all_original_signed_wires_retained':True,
        'synthetic_ephemeral_state_only':True,'loopback_only':True,'external_network':False,'deployed_state_or_keys':False,
        'automatic_retry':False,'full_pq_migration_acceptance':False,'paid_host_acceptance':False,'physical_kill_acceptance':False,
        'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'intent.json').write_text(json.dumps(intent,indent=2)+'\n')
guard_argv=['python3',str(GUARD),'--out',str(OUT/'guard'),'--target',env['CARGO_TARGET_DIR']]
for k,v in limits.items():guard_argv+=['--'+k.replace('_','-'),str(v)]
guard_argv+=['--','python3',str(Path(__file__).resolve()),'--inside']
result=subprocess.run(guard_argv,cwd=ROOT,env=env,capture_output=True)
(OUT/'supervisor.stdout').write_bytes(result.stdout)
(OUT/'supervisor.stderr').write_bytes(result.stderr)
after=identity();(OUT/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
guard=json.loads((OUT/'guard/result.json').read_text())
pipeline=json.loads((OUT/'pipeline-results.json').read_text()) if (OUT/'pipeline-results.json').exists() else []
observations=[]
if (OUT/'pq-network.stdout').exists():
    for line in (OUT/'pq-network.stdout').read_text().splitlines():
        start=line.find('{')
        if start<0:continue
        try: row=json.loads(line[start:])
        except json.JSONDecodeError: continue
        if isinstance(row,dict) and row.get('schema') in ('pq-post-intent-native-observation-v1','pq-post-intent-real-expiry-observation-v1','pq-real-signed-remote-control-origin-v1','pq-intent-origin-observation-v1'):
            observations.append(row)
record={'intent':intent,'guard':guard,'pipeline':pipeline,'source_unchanged':before==after,
        'observations':observations,'observation_schemas':[r['schema'] for r in observations],
        'supervisor_returncode':result.returncode,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'logs':{str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.rglob('*')) if p.is_file() and p.suffix in ('.stdout','.stderr','.log')}}
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('intent','observations','logs')},indent=2))
raise SystemExit(result.returncode or (0 if before==after and len(observations)==4 else 1))
