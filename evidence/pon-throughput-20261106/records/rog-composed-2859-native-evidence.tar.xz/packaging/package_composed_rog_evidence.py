#!/usr/bin/env python3
"""Package terminal composed ROG evidence; never execute source or native commands.

Uses only the Python standard library. Run once, after the composed suite has
written its final summary. Failed native outcomes are retained without being
converted to success. Missing final summaries refuse publication of a bundle.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import traceback


HEAD = '285982d78a4f62a064841cb0f106d18c865e19c5'
TREE = 'ce074eb1857a92c9b47ea317b841777fcfc63c04'
SUITE = 'validation/rog-composed-2859-native-suite'
BUILD_PREFIXES = (
    ('rog-composed-2859-workspace-build', True),
    ('rog-composed-2859-workspace-build-attempt2', True),
    ('rog-composed-2859-component-build', False),
    ('rog-composed-2859-component-build-attempt2', False),
)
BUILD_SUFFIXES = ('-source-before.json', '.jsonl', '.stderr', '.json', '-source-after.json')
RECOVERY_FILES = (
    'rog-composed-2859-build-interruption.json',
    'rog-composed-2859-build-scope-recovery.json',
    'rog-composed-2859-component-tmpdir-recovery.json',
    'rog-owned-tmpfs-build-cache-cleanup.json',
)
HELPERS = {
    'run_exact_selected_controls.py': 'a8f8656fe25038fb67939b360b42631b6856dab9bd302365cd53591be2108e55',
    'run_pq_required_controls_v2.py': '94bccecdc9a33ac140633ab677af3b17f600c1483377c5b94083bcbed7bc3680',
    'run_composed_cell_controls.py': '4ed5320de1668893212dde62970a8ed53adb25717237f7cc74b42a3e623f905e',
    'run_composed_native_validation.py': 'f210388a49e176df7beb3935a68c421bab7d345d9cf78422bb55e4c3a027a6fc',
}
PROVIDER = 'validation/rog-provider/pq-provider/provider.json'
GATES = ('controls-80', 'pq-full-and-required', 'cell-controls', 'strict-workspace-clippy')
FORBIDDEN_DIRS = {'.git', '.ssh', '__pycache__', 'target', 'targets', 'cache', 'caches', '.cache', 'keys', 'private-keys', 'provider-temp', 'node_modules'}
FORBIDDEN_SUFFIXES = ('.db', '.db-wal', '.db-shm', '.sqlite', '.sqlite3', '.sqlite-wal', '.sqlite-shm', '.sqlite3-wal', '.sqlite3-shm', '.key', '.pem', '.der', '.p8', '.p12', '.pfx', '.jks', '.keystore', '.pub', '.bin', '.o', '.a', '.so', '.dylib', '.rlib', '.rmeta', '.exe', '.pyc', '.pyo')
FORBIDDEN_NAMES = {'id_rsa', 'id_ed25519', 'id_dsa', 'id_ecdsa', 'credentials', 'credential', '.env'}
PRIVATE_KEY = re.compile(br'-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----')


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encoded(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def fingerprint(info: os.stat_result) -> tuple:
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def safe_member(name: str) -> None:
    path = PurePosixPath(name)
    require(bool(name) and not path.is_absolute() and '..' not in path.parts
            and '.' not in path.parts and path.as_posix() == name
            and not any(c in name for c in ('\\', '\n', '\r', '\0')),
            'unsafe relative archive member: ' + repr(name))


def inside_regular(root: Path, member: str) -> Path:
    safe_member(member)
    path = root
    parts = PurePosixPath(member).parts
    for part in parts[:-1]:
        path /= part
        info = path.lstat()
        require(stat.S_ISDIR(info.st_mode), 'non-directory or symlink ancestor: ' + str(path))
    path /= parts[-1]
    require(stat.S_ISREG(path.lstat().st_mode), 'non-regular or symlink input: ' + str(path))
    return path


def read_regular(path: Path) -> tuple[bytes, tuple]:
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'non-regular or symlink input: ' + str(path))
    expected = fingerprint(before)
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        require(fingerprint(os.fstat(stream.fileno())) == expected, 'input changed before open: ' + str(path))
        data = stream.read()
        require(fingerprint(os.fstat(stream.fileno())) == expected, 'input changed during read: ' + str(path))
    require(fingerprint(path.lstat()) == expected, 'input replaced during read: ' + str(path))
    return data, expected


def path_exclusion(member: str) -> str | None:
    parts = PurePosixPath(member).parts
    if any(p.lower() in FORBIDDEN_DIRS or p.lower().startswith('target-') for p in parts):
        return 'excluded build/cache/key directory'
    name = parts[-1].lower()
    if name in FORBIDDEN_NAMES or name.endswith(FORBIDDEN_SUFFIXES):
        return 'excluded database, binary, cache, or key filename'
    return None


def content_exclusion(data: bytes) -> str | None:
    if data.startswith(b'\x7fELF'):
        return 'ELF magic'
    if data.startswith(b'SQLite format 3\0'):
        return 'SQLite database magic'
    if PRIVATE_KEY.search(data):
        return 'private-key PEM marker; content excluded without recording key bytes'
    return None


def timestamp(value: object, label: str) -> None:
    require(isinstance(value, str) and bool(value), 'missing terminal time: ' + label)
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(parsed.tzinfo is not None, 'terminal time lacks timezone: ' + label)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path('/home/qian-qi/work/chain-throughput-20261106-1eed'))
    parser.add_argument('--expected-head', default=HEAD)
    parser.add_argument('--expected-tree', default=TREE)
    parser.add_argument('--output-prefix', type=Path, required=True)
    args = parser.parse_args()
    require(re.fullmatch(r'[0-9a-f]{40}', args.expected_head) is not None, 'expected head is not a full SHA')
    require(re.fullmatch(r'[0-9a-f]{40}', args.expected_tree) is not None, 'expected tree is not a full SHA')
    root = args.root.resolve(strict=True)
    prefix = args.output_prefix.absolute()
    require(prefix.parent.resolve(strict=True) == root / 'validation', 'output prefix must be directly in task validation directory')
    require(not prefix.name.startswith(tuple(p for p, _ in BUILD_PREFIXES)), 'output collides with a build prefix')
    require(prefix.name != Path(SUITE).name, 'output collides with suite directory')
    paths = {key: Path(str(prefix) + suffix) for key, suffix in {
        'archive': '.tar.xz', 'manifest': '.manifest.json', 'checksums': '.SHA256SUMS',
        'index': '.index.json', 'receipt': '.package-receipt.json', 'failure': '.package-failure.json',
    }.items()}
    require(not any(p.exists() or p.is_symlink() for p in paths.values()), 'immutable output or failure record already exists')
    created = now()
    inputs: dict[str, dict] = {}
    excluded: list[dict] = []
    missing_build_records: list[dict] = []
    phase = 'input selection'

    def add(member: str, required: bool = True) -> bool:
        safe_member(member)
        if member in inputs:
            return True
        reason = path_exclusion(member)
        if reason is not None:
            require(not required, 'required evidence would be excluded: ' + member + ': ' + reason)
            excluded.append({'path': member, 'reason': reason})
            return False
        path = inside_regular(root, member)
        data, ident = read_regular(path)
        reason = content_exclusion(data)
        if reason is not None:
            require(not required, 'required evidence would be excluded: ' + member + ': ' + reason)
            excluded.append({'path': member, 'bytes': len(data), 'reason': reason})
            return False
        inputs[member] = {'data': data, 'fingerprint': ident, 'path': str(path)}
        return True

    def value(member: str) -> dict:
        require(member in inputs, 'required retained JSON missing: ' + member)
        result = json.loads(inputs[member]['data'])
        require(isinstance(result, dict), 'expected JSON object: ' + member)
        return result

    def ref(member: str) -> dict:
        require(member in inputs, 'required artifact is absent or excluded: ' + member)
        data = inputs[member]['data']
        return {'archive_member': member, 'bytes': len(data), 'sha256': digest(data)}

    def bound_source(record: object, label: str) -> dict:
        require(isinstance(record, dict), 'source checkpoint absent: ' + label)
        receipt = record.get('receipt')
        require(isinstance(receipt, dict), 'source receipt absent: ' + label)
        require(receipt.get('tested_commit') == args.expected_head
                and receipt.get('tested_tree') == args.expected_tree,
                'source identity differs: ' + label)
        return receipt

    def identity_matches(identity: object, member: str) -> None:
        require(isinstance(identity, dict), 'missing runtime file identity: ' + member)
        actual = ref(member)
        require(identity.get('sha256') == actual['sha256']
                and identity.get('size', identity.get('bytes')) == actual['bytes'],
                'runtime file identity differs: ' + member)

    def terminal_summary(member: str, schema: str) -> dict:
        result = value(member)
        require(result.get('schema') == schema, 'unexpected summary schema: ' + member)
        timestamp(result.get('finished_utc'), member)
        require(type(result.get('passed')) is bool and isinstance(result.get('errors'), list),
                'summary lacks terminal outcome fields: ' + member)
        before = bound_source(result.get('source_before'), member + ':before')
        after = bound_source(result.get('source_after'), member + ':after')
        require(before == after, 'source receipt changed in completed gate: ' + member)
        return result

    try:
        suite_path = root / SUITE
        require(stat.S_ISDIR(suite_path.lstat().st_mode), 'suite directory missing or symlinked')
        # Refuse a live/incomplete suite before discovering or writing a bundle.
        add(SUITE + '/summary.json')
        top = terminal_summary(SUITE + '/summary.json', 'trnm-composed-native-validation-v1')
        require(top.get('expected_head') == args.expected_head, 'suite expected source differs')
        steps = top.get('steps')
        require(isinstance(steps, list) and [s.get('label') for s in steps] == list(GATES),
                'not all four planned gates have terminal driver entries')

        discovered_suite_names: set[str] = set()
        for current, dirs, names in os.walk(suite_path, followlinks=False):
            dirs.sort()
            for name in list(dirs):
                path = Path(current) / name
                member = path.relative_to(root).as_posix()
                safe_member(member)
                reason = path_exclusion(member)
                if reason is None and not stat.S_ISDIR(path.lstat().st_mode):
                    reason = 'non-directory or symlink tree entry'
                if reason:
                    excluded.append({'path': member, 'reason': reason, 'subtree_not_followed': True})
                    dirs.remove(name)
            for name in sorted(names):
                path = Path(current) / name
                member = path.relative_to(root).as_posix()
                safe_member(member)
                discovered_suite_names.add(member)
                if not stat.S_ISREG(path.lstat().st_mode):
                    excluded.append({'path': member, 'reason': 'non-regular file or symlink; not followed'})
                    continue
                add(member, required=False)

        phase = 'terminal gate and source binding'
        child_schemas = {
            'controls-80': 'trnm-exact-selected-native-controls-v1',
            'pq-full-and-required': 'trnm-pq-actual-elf-required-controls-v1',
            'cell-controls': 'trnm-composed-cell-controls-v1',
        }
        observed = []
        for step in steps:
            label = step['label']
            gate_member = SUITE + '/' + label + '.gate.json'
            require(value(gate_member) == step, 'terminal gate file differs from driver summary: ' + label)
            execution = step.get('execution')
            require(isinstance(execution, dict), 'driver execution record missing: ' + label)
            timestamp(execution.get('finished_utc'), label + ':driver')
            code = execution.get('native_exit')
            require(type(code) is int or bool(execution.get('spawn_error')), 'driver execution not terminal: ' + label)
            row = {'label': label, 'driver_native_exit': code, 'passed_as_reported': step.get('passed'), 'gate': ref(gate_member)}
            if label in child_schemas:
                member = SUITE + '/' + label + '/summary.json'
                child = terminal_summary(member, child_schemas[label])
                identity_matches(step.get('summary_identity'), member)
                row.update(summary=ref(member), finished_utc=child['finished_utc'],
                           child_passed_as_reported=child['passed'], collector_errors_as_reported=child['errors'])
                if label == 'pq-full-and-required':
                    row['full_library_as_reported'] = (child.get('full_library') or {}).get('verdict')
                row['observed_as_reported'] = step.get('observed', {})
            else:
                member = SUITE + '/clippy/strict-workspace-clippy.json'
                clippy = value(member)
                require(clippy.get('status') in {'command_succeeded', 'command_failed', 'record_failed'}
                        and type(clippy.get('elapsed_ns')) is int,
                        'Clippy recorder is not terminal')
                identity_matches(step.get('receipt_identity'), member)
                log_member = SUITE + '/clippy/strict-workspace-clippy.log'
                identity_matches(step.get('log_identity'), log_member)
                row.update(receipt=ref(member), status_as_reported=clippy['status'],
                           native_exit_as_reported=clippy.get('exit_code'))
            observed.append(row)

        phase = 'build history and auxiliary evidence'
        builds = []
        for name, cancelled in BUILD_PREFIXES:
            prefix_member = 'validation/' + name
            records = {}
            for suffix in BUILD_SUFFIXES:
                member = prefix_member + suffix
                path = root / member
                optional_cancelled_final = cancelled and suffix in {'.json', '-source-after.json'}
                if not path.exists() and not path.is_symlink():
                    require(optional_cancelled_final, 'required build evidence missing: ' + member)
                    missing = {'path': member, 'reason': 'cancelled workspace wrapper did not write a terminal receipt; absence preserved, not reconstructed'}
                    missing_build_records.append(missing)
                    records[suffix] = {'present': False, **missing}
                    continue
                add(member)
                records[suffix] = {'present': True, **ref(member)}
            before = value(prefix_member + '-source-before.json')
            require(before.get('tested_commit') == args.expected_head and before.get('tested_tree') == args.expected_tree,
                    'build source-before identity differs: ' + name)
            wrapper = value(prefix_member + '.json') if records['.json']['present'] else None
            builds.append({'prefix': name, 'reported_cancelled_attempt': cancelled, 'records': records,
                           'wrapper_exit_code_as_recorded': None if wrapper is None else wrapper.get('exit_code'),
                           'no_wrapper_exit_inferred_from_partial_cargo_output': True})
        for name in RECOVERY_FILES:
            add('validation/' + name)
            value('validation/' + name)
        for name, expected in HELPERS.items():
            member = 'validation/' + name
            add(member)
            require(ref(member)['sha256'] == expected, 'reviewed helper changed: ' + name)
            identity = top.get('runner') if name == 'run_composed_native_validation.py' else top.get('helpers', {}).get(name)
            identity_matches(identity, member)
        add(PROVIDER)
        provider = value(PROVIDER)

        phase = 'manifest construction'
        files = [{'archive_member': name, 'source_path': item['path'], 'bytes': len(item['data']),
                  'sha256': digest(item['data'])} for name, item in sorted(inputs.items())]
        index = {
            'schema': 'trnm-composed-rog-evidence-index-v1', 'created_utc': created,
            'expected_head': args.expected_head, 'expected_tree': args.expected_tree,
            'suite': ref(SUITE + '/summary.json'), 'suite_passed_as_reported': top['passed'],
            'suite_scope_verbatim': top.get('scope'), 'suite_errors_as_reported': top['errors'],
            'gates': observed, 'build_attempts': builds,
            'missing_cancelled_wrapper_records': missing_build_records,
            'recovery_and_cleanup_receipts': [ref('validation/' + name) for name in RECOVERY_FILES],
            'actual_runner_and_helpers': [ref('validation/' + name) for name in HELPERS],
            'provider_receipt': ref(PROVIDER), 'provider_status_as_reported': provider.get('result'),
            'exclusions': excluded,
            'scope': 'Lossless evidence packaging only. Native failures and cancelled/unknown attempts remain their original results. No native execution, build, source modification, network call, or new performance acceptance.',
        }
        packager_bytes, packager_fingerprint = read_regular(Path(__file__).absolute())
        manifest = {
            'schema': 'trnm-composed-rog-evidence-files-v1', 'created_utc': created,
            'original_regular_files': len(files), 'original_bytes': sum(r['bytes'] for r in files),
            'source': {'expected_head': args.expected_head, 'expected_tree': args.expected_tree,
                       'proof_scope': 'retained original runner source receipts; this packager executes no source checker'},
            'files': files, 'excluded_entries': excluded,
            'missing_cancelled_wrapper_records': missing_build_records,
            'generated_metadata_not_original_records': ['packaging/manifest.json', 'packaging/SHA256SUMS', 'packaging/index.json', 'packaging/package_composed_rog_evidence.py'],
            'container': 'solid XZ, deterministic regular tar members, zero timestamps/uids/gids, no symlink/hardlink/absolute/traversal entries',
        }
        manifest_bytes = encoded(manifest)
        index_bytes = encoded(index)
        checksums = ''.join(r['sha256'] + '  ' + r['archive_member'] + '\n' for r in files).encode()
        generated = {
            'packaging/manifest.json': manifest_bytes,
            'packaging/index.json': index_bytes,
            'packaging/SHA256SUMS': checksums,
            'packaging/package_composed_rog_evidence.py': packager_bytes,
        }
        payload = {name: item['data'] for name, item in inputs.items()}
        require(not (set(payload) & set(generated)), 'generated metadata collides with original evidence')
        payload.update(generated)

        phase = 'solid archive write and complete readback'
        with paths['archive'].open('xb') as raw:
            with lzma.LZMAFile(raw, 'w', format=lzma.FORMAT_XZ, check=lzma.CHECK_CRC64, preset=6) as compressed:
                with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
                    for name, data in sorted(payload.items()):
                        safe_member(name)
                        info = tarfile.TarInfo(name)
                        info.size = len(data)
                        info.mode = 0o644
                        info.uid = info.gid = info.mtime = 0
                        info.uname = info.gname = ''
                        info.type = tarfile.REGTYPE
                        archive.addfile(info, io.BytesIO(data))
        archive_bytes, archive_fingerprint = read_regular(paths['archive'])
        seen = set()
        with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:xz') as archive:
            for item in archive.getmembers():
                safe_member(item.name)
                require(item.isfile() and not item.islnk() and not item.issym(), 'non-regular archive member')
                require(item.name in payload and item.name not in seen, 'unexpected or duplicate archive member')
                require((item.mode, item.uid, item.gid, item.mtime, item.uname, item.gname) == (0o644, 0, 0, 0, '', ''), 'archive metadata changed')
                stream = archive.extractfile(item)
                require(stream is not None and stream.read() == payload[item.name], 'archive byte readback failed: ' + item.name)
                seen.add(item.name)
        require(seen == set(payload), 'archive omits selected evidence')

        phase = 'original input recheck and sidecar publication'
        for member, item in inputs.items():
            path = inside_regular(root, member)
            data, ident = read_regular(path)
            require(ident == item['fingerprint'] and data == item['data'], 'evidence changed while packaging: ' + member)
        require(read_regular(Path(__file__).absolute()) == (packager_bytes, packager_fingerprint), 'packager source changed')
        require(read_regular(paths['archive']) == (archive_bytes, archive_fingerprint), 'archive changed during readback')
        # Re-list the same permitted suite tree to catch late-added evidence.
        after_names = set()
        for current, dirs, names in os.walk(suite_path, followlinks=False):
            dirs[:] = sorted(name for name in dirs
                             if path_exclusion((Path(current) / name).relative_to(root).as_posix()) is None
                             and stat.S_ISDIR((Path(current) / name).lstat().st_mode))
            after_names.update((Path(current) / name).relative_to(root).as_posix() for name in names)
        require(after_names == discovered_suite_names, 'suite membership changed while packaging')
        for key, data in [('manifest', manifest_bytes), ('checksums', checksums), ('index', index_bytes)]:
            with paths[key].open('xb') as stream:
                stream.write(data)
            require(read_regular(paths[key])[0] == data, 'sidecar readback differs: ' + key)
        receipt = {
            'schema': 'trnm-composed-rog-package-receipt-v1', 'created_utc': created, 'finished_utc': now(),
            'expected_head': args.expected_head, 'expected_tree': args.expected_tree,
            'archive': {'path': str(paths['archive']), 'bytes': len(archive_bytes), 'sha256': digest(archive_bytes),
                        'regular_members': len(payload), 'original_regular_files': len(inputs),
                        'all_member_bytes_read_back': True, 'only_safe_regular_members': True},
            'sidecars': {key: {'path': str(paths[key]), 'bytes': len(data), 'sha256': digest(data)}
                         for key, data in [('manifest', manifest_bytes), ('checksums', checksums), ('index', index_bytes)]},
            'packager_sha256': digest(packager_bytes), 'all_selected_inputs_rechecked_unchanged': True,
            'suite_membership_rechecked_unchanged': True, 'suite_passed_as_reported': top['passed'],
            'cancelled_attempt_missing_records': missing_build_records,
            'excluded_entries': excluded, 'no_native_test_build_source_mutation_or_network_api': True,
        }
        with paths['receipt'].open('xb') as stream:
            stream.write(encoded(receipt))
        print(json.dumps(receipt, ensure_ascii=False, indent=2), flush=True)
        return 0
    except Exception:
        failure = {'schema': 'trnm-composed-rog-package-failure-v1', 'created_utc': created,
                   'failed_utc': now(), 'phase': phase, 'traceback': traceback.format_exc(),
                   'native_execution_or_build': False,
                   'partial_outputs_retained': [str(p) for key, p in paths.items() if key != 'failure' and p.exists()],
                   'policy': 'No retry, missing-summary substitution, or successful publication receipt. Preserve this failed packaging attempt.'}
        with paths['failure'].open('xb') as stream:
            stream.write(encoded(failure))
        print(json.dumps(failure, ensure_ascii=False, indent=2), flush=True)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
