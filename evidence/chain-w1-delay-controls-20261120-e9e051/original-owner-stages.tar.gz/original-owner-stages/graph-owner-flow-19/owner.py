from pathlib import Path
import json,sys,hashlib
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'graph-owner-flow-19';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);sections=[]
for name,needles,before,after in [
 ('trillionnium/crates/trnm-pon-node/src/store.rs',['PostWriteReadback::new','verify_state_with_readback','fn admission','fn state_at_with','fn read_active','fn activate'],35,70),
 ('trillionnium/crates/trnm-pon-node/src/store/native_authenticated.rs',['pub(super) fn verify_state_with_readback','pub(super) fn publish_with_readback'],0,155),
 ('trillionnium/crates/trnm-pon-node/src/host_kernel_parent.rs',['fn checked_parent','fn check(&self)','pub fn verify(&self)'],5,95)]:
 raw=(src/name).read_bytes();lines=raw.decode().splitlines();ranges=[]
 for i,line in enumerate(lines):
  if any(n in line for n in needles):
   lo=max(0,i-before);hi=min(len(lines),i+after)
   if ranges and lo<=ranges[-1][1]:ranges[-1][1]=max(hi,ranges[-1][1])
   else:ranges.append([lo,hi])
 for lo,hi in ranges:sections.append({'path':name,'full_sha256':hashlib.sha256(raw).hexdigest(),'line_start':lo+1,'line_end':hi,'text':'\n'.join(lines[lo:hi])+'\n'})
 for index,(lo,hi) in enumerate(ranges):
  (out/(Path(name).stem+'-'+str(index)+'.txt')).write_text('\n'.join(lines[lo:hi])+'\n')
(out/'sections.json').write_text(json.dumps(sections,indent=2)+'\n');print(json.dumps({'sections':[{'path':s['path'],'line_start':s['line_start'],'line_end':s['line_end']} for s in sections]}))
