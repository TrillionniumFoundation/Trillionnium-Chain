#!/usr/bin/env python3
"""Independently replay EVERY retained attempt, including target misses.

The Python oracle is frozen upstream. This checks evidence consistency, not CPU
authenticity, statistical independence, task eligibility or a work lower bound.
"""
from pathlib import Path
import argparse, hashlib, itertools, json, struct, sys
from independent_check import H, w, header_decode

SOURCE='4b6b8a91b6dfe41fbd7f40f40b359d535c2c4251'
METHODS=['scalar-full','prepared','paired','tiled-classical','strassen-one-level',
         'structured','blocked-zero','blocked-zero-paired','blocked-one-zero',
         'maintenance-prefix','maintenance-integer-paired','maintenance-periodic',
         'maintenance-limb','low-rank-prefix-scalar','low-rank-prefix-paired']
CASES=['zero','rank1','rank2','rank4','rank8','one-zero','identity','diagonal',
       'sparse','repeated-rows','maintenance','legacy-periodic','dense']
RECORD_BYTES=318+w.PROOF_BYTES
TARGET=b'\x0f'+b'\xff'*31

def require(condition,message):
    if not condition:raise ValueError(message)

def read_bounded(path,limit):
    with path.open('rb')as f:data=f.read(limit+1)
    require(len(data)<=limit,'SIZE_BOUND')
    return data

def random_words(label,count):
    result=[]
    for counter in itertools.count():
        for (value,)in struct.iter_unpack('<I',H('p0-material-v1',label,counter.to_bytes(8,'little'))):
            if value<w.Q:result.append(value)
            if len(result)==count:return result

def rank_matrix(rank,label):
    return w.mm(random_words(label+b'\0',w.N*rank),random_words(label+b'\1',rank*w.N),w.N,rank,w.N)

def material(case):
    if case=='zero':return [0]*w.CELLS,[0]*w.CELLS
    if case.startswith('rank'):
        rank=int(case[4:]);return rank_matrix(rank,f'a{rank}'.encode()),rank_matrix(rank,f'b{rank}'.encode())
    if case=='one-zero':return rank_matrix(1,b'a1'),[0]*w.CELLS
    if case=='identity':a=[int(i//w.N==i%w.N)for i in range(w.CELLS)];return a,a
    if case=='diagonal':a=[i//w.N+1 if i//w.N==i%w.N else 0 for i in range(w.CELLS)];return a,a
    if case=='sparse':a=[i+1 if (i*31+7)%67==0 else 0 for i in range(w.CELLS)];return a,a
    if case=='repeated-rows':a=random_words(b'repeat',w.N)*w.N;return a,a
    if case=='maintenance':return [(13*i+17)%257 for i in range(w.CELLS)],[(29*i+31)%263 for i in range(w.CELLS)]
    if case=='legacy-periodic':return [i%31 for i in range(w.CELLS)],[(7*i)%37 for i in range(w.CELLS)]
    if case=='dense':return random_words(b'dense-a',w.CELLS),random_words(b'dense-b',w.CELLS)
    raise ValueError('CASE')

def check(directory):
    raw_bytes=read_bounded(directory/'raw.json',64*1024*1024)
    data=json.loads(raw_bytes);intent=json.loads(read_bounded(directory/'intent.json',32768))
    require(data['schema']=='trnm-pure-pon-adversarial-cost-v1','SCHEMA')
    require(data['source_commit']==SOURCE and data['profile']=='pon-matmul-transcript-64-v1','SOURCE_PROFILE')
    for key in ['source_commit','binary_sha256','samples','horizons','cases','target_bits']:
        require(data[key]==intent[key],'INTENT_MISMATCH '+key)
    cases=data['cases'];horizons=data['horizons'];samples=data['samples']
    require(len(set(cases))==len(cases) and all(c in CASES for c in cases),'CASES')
    require(type(samples)is int and 0<samples<=12,'SAMPLES')
    require(len(set(horizons))==len(horizons) and all(type(h)is int and 0<h<=1024 for h in horizons),'HORIZONS')
    require(data['target_bits']==4,'TARGET')
    for key in ['minimal_adversarial_cost','node_task_eligibility_checked','real_model_utility','gpu_measured','network_measured','succinct_proof','production_activation']:
        require(data['qualifications'][key]is False,'UNSUPPORTED_QUALIFICATION '+key)
    reference={};seen_cases=set();relation_count=0;unique_winners=0
    for item in data['proof_streams']:
        case=item['case'];require(case in cases and case not in seen_cases,'STREAM_CASE');seen_cases.add(case)
        require(item['path']==f'proofs-{case}.bin','STREAM_PATH')
        require(item['format']=='fixed-header318-pnw149188-records-v1','STREAM_FORMAT')
        require(item['record_bytes']==RECORD_BYTES and item['records']==max(horizons),'STREAM_RECORDS')
        blob=read_bounded(directory/item['path'],max(horizons)*RECORD_BYTES)
        require(len(blob)==item['bytes']==max(horizons)*RECORD_BYTES,'STREAM_LENGTH')
        require(hashlib.sha256(blob).hexdigest()==item['sha256'],'STREAM_HASH')
        a,b=material(case);operand_bytes=w.field_bytes(a)+w.field_bytes(b)
        task=w.task_id(a,b)
        for index in range(item['records']):
            block=blob[index*RECORD_BYTES:(index+1)*RECORD_BYTES];header=block[:318];proof=block[318:]
            decoded=header_decode(header);challenge=H('challenge',header)
            require(decoded['nonce']==index+1 and decoded['target']==TARGET and decoded['work_task']==task,'HEADER_CONTEXT')
            require(proof[4:4+8*w.CELLS]==operand_bytes,'MATERIAL_BYTES '+case)
            # The original target is checked separately; a miss cannot become a
            # winner merely because full relation replay uses all-ff here.
            ticket,_=w.verify(challenge,task,b'\xff'*32,proof)
            winner=ticket<=TARGET;relation_count+=1;unique_winners+=int(winner)
            reference[case,index+1]=dict(proof_sha256=hashlib.sha256(proof).hexdigest(),ticket=ticket.hex(),winner=winner)
        print(f'Python full replay complete: {case} ({item["records"]} unique attempts)',file=sys.stderr,flush=True)
    require(seen_cases==set(cases),'MISSING_STREAM')
    expected=set(itertools.product(cases,METHODS,horizons,range(samples)))
    attempted=misses=winners=unsupported=0
    for row in data['rows']:
        key=(row['case'],row['method'],row['horizon'],row['sample'])
        require(key in expected,'DUPLICATE_OR_UNKNOWN_ROW');expected.remove(key)
        require(type(row['setup_cpu_ns'])is int and row['setup_cpu_ns']>0,'SETUP_CPU')
        require(type(row['setup_wall_ns'])is int and row['setup_wall_ns']>0,'SETUP_WALL')
        if row['status']=='UNSUPPORTED':unsupported+=1;require('attempts'not in row,'FALLBACK');continue
        require(row['status']=='BYTE_IDENTICAL_FULL_W1','ROW_STATUS')
        require(len(row['attempts'])==row['horizon'],'LOST_ATTEMPTS')
        for index,attempt in enumerate(row['attempts']):
            require(attempt['nonce']==index+1,'NONCE_SEQUENCE')
            for name,value in reference[row['case'],index+1].items():require(attempt[name]==value,'ATTEMPT_'+name)
            for field in ['generate_wall_ns','generate_cpu_ns']:
                require(type(attempt[field])is int and attempt[field]>0,'ATTEMPT_COST')
            for field in ['winner_verify_wall_ns','winner_verify_cpu_ns']:
                require(type(attempt[field])is int and (attempt[field]>0 if attempt['winner']else attempt[field]==0),'WINNER_COST')
            attempted+=1;winners+=int(attempt['winner']);misses+=int(not attempt['winner'])
        for total,part in [('generate_cpu_ns','generate_cpu_ns'),('generate_wall_ns','generate_wall_ns'),('winner_verify_cpu_ns','winner_verify_cpu_ns'),('winner_verify_wall_ns','winner_verify_wall_ns')]:
            require(row[total]==sum(x[part]for x in row['attempts']),'COST_TOTAL '+total)
        wins=sum(int(x['winner'])for x in row['attempts'])
        require(row['winners']==wins,'WINNER_TOTAL')
        total=row['setup_cpu_ns']+row['generate_cpu_ns'];require(row['total_producer_cpu_ns']==total,'OMITTED_SETUP')
        require(row['cpu_ns_per_win']==(total//wins if wins else None),'PER_WIN_DENOMINATOR')
    require(not expected,'MISSING_ROWS')
    for control in data['false_transcript_negative_controls']:
        require(control['cheap_filter_passed']is True and control['full_verifier_result']=='Some(Transcript)','CONTROL_RESULT')
        require(control['independent_security_puzzle']is False,'INDEPENDENT_PUZZLE')
        require(control['case']in cases and control['path']==f'false-trace-{control["case"]}.bin','CONTROL_PATH')
        raw=read_bounded(directory/control['path'],RECORD_BYTES)
        require(len(raw)==control['bytes']==RECORD_BYTES and hashlib.sha256(raw).hexdigest()==control['sha256'],'CONTROL_BYTES')
        header,proof=raw[:318],raw[318:];h=header_decode(header);challenge=H('challenge',header)
        w.precheck(challenge,h['work_task'],h['target'],proof)
        try:w.verify(challenge,h['work_task'],h['target'],proof)
        except ValueError as error:require(str(error)=='TRANSCRIPT','CONTROL_WRONG_REJECTION')
        else:raise ValueError('CONTROL_ACCEPTED')
    require(len(data['false_transcript_negative_controls'])==len(cases),'MISSING_NEGATIVE_CONTROL')
    return dict(result='PASS',schema='trnm-pure-pon-cost-independent-readback-v1',raw_sha256=hashlib.sha256(raw_bytes).hexdigest(),
                unique_full_python_relation_replays=relation_count,unique_winning_tickets=unique_winners,
                measured_attempt_calls=attempted,measured_target_misses=misses,measured_wins=winners,
                unsupported_rows_retained=unsupported,rows=len(data['rows']),all_rows_accounted=True,
                repeated_nonce_paths_are_not_independent_samples=True,timing_authenticity_qualified=False,
                node_task_eligibility_checked=False,global_minimum_cost_proved=False,succinct_proof=False)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('directory',type=Path);args=p.parse_args()
    print(json.dumps(check(args.directory),indent=2))
