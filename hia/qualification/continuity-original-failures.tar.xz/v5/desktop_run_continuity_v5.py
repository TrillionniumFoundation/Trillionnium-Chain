"""Admit an exact native Continuity bundle, then execute retained original Rust."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tarfile
import time
import traceback

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT / "repo"
TARGET = Path("/tmp/trnm-typedstore-rust-20261116-jqi3qetj/isolated-cargo-target")
HEAD = "453326b335af9375f2f6796d4e906cb4cdf2ce4d"
TREE = "fc5a31e67b207078ee1b01ad98e918df11ad8b8f"
HISTORY_BYTES = 1939076
HISTORY_SHA = "1fc35f3b3e81e697a6086c044e5372165957a50ff37e03f8d115ced8d282d34f"
SKIP = {"target", ".git", "__pycache__", ".pytest_cache"}

def need(value, message):
    if not value:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(path):
    need(path.is_file() and not path.is_symlink(), "Nonregular source: " + str(path))
    digest, size = hashlib.sha256(), 0
    with path.open("rb") as stream:
        while block := stream.read(1 << 20):
            digest.update(block)
            size += len(block)
    return {"bytes": size, "sha256": digest.hexdigest()}

def write_json(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, sort_keys=True, indent=2) + "\n")

def unique(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "Duplicate JSON key: " + key)
        result[key] = value
    return result

def object_json(raw):
    result = json.loads(raw, object_pairs_hook=unique)
    need(type(result) is dict, "Object JSON required")
    return result

def canonical(root, relative):
    need(isinstance(relative, str) and relative and "\\" not in relative and "\0" not in relative,
         "Noncanonical relative path")
    name = Path(relative)
    need(not name.is_absolute() and ".." not in name.parts and name.as_posix() == relative,
         "Escaping or noncanonical relative path")
    cursor = root
    for part in name.parts:
        cursor = cursor / part
        need(not cursor.is_symlink(), "Symbolic path: " + relative)
    return cursor

def original_manifest(repository):
    result = {}
    for directory in ("trillionnium", "config", "formal"):
        for path in sorted((repository / directory).rglob("*")):
            relative = path.relative_to(repository)
            if any(part in SKIP for part in relative.parts):
                continue
            need(not path.is_symlink(), "Symbolic original source")
            if path.is_file():
                result[relative.as_posix()] = identity(path)
    need("trillionnium/Cargo.lock" in result, "Missing actual original Cargo graph")
    return result

def decode_bounded(path, maximum):
    decoder = lzma.LZMADecompressor(format=lzma.FORMAT_XZ, memlimit=64 << 20)
    blocks, count = [], 0
    with path.open("rb") as stream:
        while not decoder.eof:
            block = stream.read(65536) if decoder.needs_input else b""
            need(block or not decoder.needs_input, "Truncated XZ")
            raw = decoder.decompress(block, max_length=min(1 << 20, maximum - count + 1))
            count += len(raw)
            need(count <= maximum, "Decoded XZ extent exceeds bound")
            blocks.append(raw)
        need(not decoder.unused_data and not stream.read(1), "Trailing XZ data")
    return b"".join(blocks)

def main():
    need(__debug__, "Optimized Python is not admitted")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-sha256", required=True)
    parser.add_argument("--package-bytes", required=True, type=int)
    parser.add_argument("--comparison-sha256", required=True)
    parser.add_argument("--source-count", required=True, type=int)
    parser.add_argument("--owned-count", type=int, default=18)
    parser.add_argument("--typed-count", type=int, default=13)
    parser.add_argument("--case-count", type=int, default=572)
    args = parser.parse_args()
    for value in (args.package_sha256, args.comparison_sha256):
        need(re.fullmatch("[0-9a-f]{64}", value), "Invalid exact digest argument")
    need(0 < args.package_bytes <= 32 << 20, "Unexpected package extent")
    started = time.monotonic()
    report = {"schema": "trnm.continuity.desktop-execution-wrapper.v1", "status": "RUNNING",
        "started_utc": datetime.now(timezone.utc).isoformat(), "repository_head": HEAD,
        "repository_tree": TREE, "package_sha256": args.package_sha256, "github_write": False,
        "service_provisioned": False, "native_result_computation_in_wrapper": False,
        "large_extent_original_rust_qualified": False, "whole_node_qualified": False}
    comparison = None
    source_inputs = None
    original = None
    output = ROOT / "original-rust-run-v5"
    try:
        ready = object_json((ROOT / "preparation.json").read_bytes())
        need(ready["status"] == "SOURCE_READY_ONLY" and ready["expected_head"] == HEAD and ready["expected_tree"] == TREE
             and any(row["name"] == "preflight" and row["exit_code"] == 0 for row in ready["stages"]),
             "Actual exact-source preparation is not complete")
        for expression, expected in (("HEAD", HEAD), ("HEAD^{tree}", TREE)):
            value = subprocess.run(["git", "rev-parse", expression], cwd=REPOSITORY,
                check=True, capture_output=True, text=True, timeout=20).stdout.strip()
            need(value == expected, "Exact Git source differs")
        clean = subprocess.run(["git", "status", "--porcelain=v1"], cwd=REPOSITORY,
            check=True, capture_output=True, text=True, timeout=30).stdout
        need(not clean, "Private source must be clean before overlay")
        metadata = object_json((ROOT / "chunks/transfer.json").read_bytes())
        need(metadata["head"] == HEAD and metadata["tree"] == TREE
             and metadata["package_sha256"] == args.package_sha256
             and metadata["package_bytes"] == args.package_bytes, "Transfer identity differs")
        parts, offset = [], 0
        for index, part in enumerate(metadata["chunks"]):
            need(part["name"] == f"part-{index:03d}.bin" and part["offset"] == offset,
                 "Noncontiguous or reordered chunks")
            path = canonical(ROOT / "chunks", part["name"])
            raw = path.read_bytes()
            need(0 < len(raw) == part["bytes"] < 65536 and sha(raw) == part["sha256"],
                 "Chunk identity differs")
            offset += len(raw)
            parts.append(raw)
            path.chmod(0o400)
        raw = b"".join(parts)
        need(len(raw) == args.package_bytes and sha(raw) == args.package_sha256,
             "Whole package identity differs")
        archive_path = ROOT / "continuity-native-bundle-v1.tar.xz"
        with archive_path.open("xb") as stream:
            stream.write(raw)
        archive_path.chmod(0o400)
        del raw, parts
        unpacked = ROOT / "unpacked"
        unpacked.mkdir(mode=0o700)
        members, total = [], 0
        with tarfile.open(archive_path, "r:xz") as archive:
            listing = archive.getmembers()
            names = [member.name for member in listing]
            need(len(names) == len(set(names)), "Duplicate archive member")
            for member in listing:
                canonical(unpacked, member.name)
                need(member.isfile() and 0 <= member.size <= 512 << 20,
                     "Nonregular or excessive archive member")
                total += member.size
            need(total <= 1 << 30, "Aggregate archive extent exceeds bound")
            exact = archive.getmember("bundle/native-comparison.json")
            comparison_raw = archive.extractfile(exact).read()
            need(sha(comparison_raw) == args.comparison_sha256, "Native comparison differs")
            comparison = object_json(comparison_raw)
            built = comparison["build"]
            need(comparison["status"] == built["status"] == "PASS", "Full native PASS required")
            source_inputs = built["source_inputs"]
            need(type(source_inputs) is dict and len(source_inputs) == args.source_count,
                 "Complete expected native source count differs")
            need(built["source_set_sha256"] == sha(json.dumps(source_inputs,
                sort_keys=True, separators=(",", ":")).encode()), "Source-set digest differs")
            source_members = {name for name in names if name in source_inputs}
            need(source_members == set(source_inputs), "The package omitted bound source inputs")
            owned = {name for name in source_inputs if name.startswith("hia/platform/continuity_store/")}
            typed = {name for name in source_inputs if name.startswith("hia/platform/typed_store/")}
            need(len(owned) == args.owned_count and len(typed) == args.typed_count,
                 "Owned source set differs")
            for member in listing:
                need(member.name in source_inputs or member.name.startswith(("bundle/", "history/")),
                     "Unexpected archive namespace")
                destination = canonical(unpacked, member.name)
                destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                with destination.open("xb") as sink, archive.extractfile(member) as source:
                    shutil.copyfileobj(source, sink)
                members.append({"path": member.name, **identity(destination)})
                if member.name in source_inputs:
                    need(identity(destination) == source_inputs[member.name], "Archived source differs")
        original = original_manifest(REPOSITORY)
        need(original == built["original_sources"], "Exact original source graph differs before overlay")
        for relative, expected in source_inputs.items():
            source = canonical(unpacked, relative)
            destination = canonical(REPOSITORY, relative)
            need(identity(source) == expected, "Source changed before overlay")
            if relative in original:
                need(identity(destination) == expected == original[relative],
                     "Original production source cannot be changed by overlay")
                continue
            need(relative.startswith("hia/"), "Unexpected non-HIA overlay source")
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
        sys.path.insert(0, str(REPOSITORY))
        from hia.platform.continuity_store.rust_oracle import validate_bundle, complete_source_manifest
        observed, observed_raw, observed_sources, corpus = validate_bundle(REPOSITORY, unpacked / "bundle")
        need(observed == comparison and sha(observed_raw) == args.comparison_sha256
             and observed_sources == source_inputs, "Public bundle gate disagrees with transport")
        history = decode_bounded(unpacked / "history/continuity-536-corpus.jsonl.xz", HISTORY_BYTES)
        need(len(history) == HISTORY_BYTES and sha(history) == HISTORY_SHA,
             "Historical 536 input identity differs")
        prior_lines, current_lines = history.splitlines(), corpus.splitlines()
        need(len(prior_lines) == 536 and len(current_lines) == args.case_count
             and current_lines[:536] == prior_lines, "Historical inputs were changed, removed or reordered")
        names = [json.loads(line)["name"] for line in current_lines]
        need(len(names) == len(set(names)), "Duplicate current corpus name")
        need(len(comparison["cases"]) == args.case_count, "Native result cardinality differs")
        report["source_binding"] = {"original_files": len(original), "native_source_inputs": len(source_inputs),
            "native_source_set_sha256": built["source_set_sha256"],
            "native_comparison_sha256": args.comparison_sha256,
            "owned_sources": sorted(owned), "typed_sources": sorted(typed)}
        report["corpus"] = comparison["corpus"]
        report["preserved_input_prefix"] = {"cases": 536, "bytes": HISTORY_BYTES, "sha256": HISTORY_SHA}
        report["transfer"] = {"chunks": metadata["chunks"], "members": members}
        write_json(ROOT / "verified-setup.json", report)
        print(json.dumps({"stage": "SOURCE_AND_BUNDLE_VERIFIED", **report["source_binding"],
            "cases": args.case_count, "preserved_input_cases": 536}), flush=True)
        del history, prior_lines, current_lines, corpus
        need(not output.exists() and not output.is_symlink(), "Fresh oracle output required")
        command = [sys.executable, "-B", "-m", "hia.platform.continuity_store.rust_oracle",
            "--repository", str(REPOSITORY), "--bundle", str(unpacked / "bundle"),
            "--output", str(output), "--target-dir", str(TARGET)]
        report["oracle_command"] = command
        report["oracle_started_utc"] = datetime.now(timezone.utc).isoformat()
        with (ROOT / "oracle-driver.stdout").open("xb") as stdout, \
                (ROOT / "oracle-driver.stderr").open("xb") as stderr:
            process = subprocess.Popen(command, cwd=REPOSITORY, stdout=stdout, stderr=stderr,
                stdin=subprocess.DEVNULL, start_new_session=True)
            try:
                process.wait(timeout=1120)
            except subprocess.TimeoutExpired:
                report["oracle_timed_out"] = True
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=15)
                raise
        report["oracle_finished_utc"] = datetime.now(timezone.utc).isoformat()
        report["oracle_exit_code"] = process.returncode
        actual = object_json((output / "report.json").read_bytes())
        report["oracle_report"] = identity(output / "report.json")
        report["oracle_status"] = actual["status"]
        need(process.returncode == 0 and actual["status"] == "PASS", actual.get("error", "Original oracle failed"))
        need(actual["controls"] == args.case_count and actual["failed"] == 0
             and len(actual["retained_original_tests"]) == 4, "Actual original result count differs")
        report.update(status="PASS", controls=actual["controls"],
            original_tests=actual["retained_original_tests"], serde_json_artifact=actual["serde_json_artifact"],
            exact_installed_constructor_snapshots=actual["exact_installed_constructor_snapshots"],
            original_production_function_bytes_preserved=actual["original_production_function_bytes_preserved"])
    except BaseException as error:
        report.update(status="FAIL", error=repr(error), traceback=traceback.format_exc())
    finally:
        cleanup_errors = []
        try:
            cargo_output = output / "cargo-original-test-build/stdout.raw"
            if cargo_output.is_file():
                binaries = []
                with cargo_output.open("rb") as stream:
                    for line in stream:
                        if not line.startswith(b"{"):
                            continue
                        event = json.loads(line)
                        if event.get("reason") == "compiler-artifact" and event.get("target", {}).get("name") == "trnm_pon_node" \
                                and event.get("executable") and event.get("profile", {}).get("test"):
                            binaries.append(Path(event["executable"]))
                if binaries:
                    need(len(binaries) == 1, "Ambiguous actual original test executable")
                    binary = binaries[0]
                    before = identity(binary)
                    saved = ROOT / "original-test-binary"
                    with binary.open("rb") as source, saved.open("xb") as sink:
                        shutil.copyfileobj(source, sink)
                    saved.chmod(0o500)
                    need(identity(binary) == identity(saved) == before, "Original binary changed while preserving it")
                    report["independent_original_binary"] = {**before, "path": str(saved)}
        except BaseException as error:
            cleanup_errors.append("PRESERVE_BINARY:" + repr(error))
        try:
            if original is not None:
                need(original_manifest(REPOSITORY) == original, "Original production bytes changed")
            if source_inputs is not None and "complete_source_manifest" in locals():
                need(complete_source_manifest(REPOSITORY) == source_inputs, "Native source closure changed")
        except BaseException as error:
            cleanup_errors.append("SOURCE_AFTER:" + repr(error))
        report["cleanup_errors"] = cleanup_errors
        if cleanup_errors:
            report["status"] = "FAIL"
        report["finished_utc"] = datetime.now(timezone.utc).isoformat()
        report["elapsed_seconds"] = time.monotonic() - started
        write_json(ROOT / "execution-wrapper.json", report)
        print(json.dumps({key: report.get(key) for key in
            ("status", "elapsed_seconds", "oracle_status", "oracle_exit_code", "controls",
             "original_tests", "cleanup_errors", "error")}, sort_keys=True), flush=True)
    return 0 if report["status"] == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
