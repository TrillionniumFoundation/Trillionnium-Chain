#!/usr/bin/env python3
"""Package retained observations only after every check has stopped writing.

No checks, Cargo commands, training, replay or result repairs run here. An unknown
child exit is retained as unknown. The external manifest hashes the archive;
placing that manifest inside the archive would create a self-reference.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import lzma
import os
from pathlib import PurePosixPath
import re
import stat
import subprocess
import sys
import tarfile


WORKSPACE = '/workspace/scratch/51e4e62b58cf'
SOURCE = '873d33aefd33828842c1f1420382b77c15396d74'
OUTPUT = 'chain/evidence/pon-work-knowledge-boundary-20261106'
HISTORICAL_TREES = ('historical-replay', 'historical-replay-final',
                    'historical-replay-published-source')
GRAPH_TREES = ('graphs-final', 'graphs-final-recovered', 'graphs-published-source')
TREES = ('checks', 'review', *HISTORICAL_TREES, 'graphs-final', 'graphs-published-source')
OPTIONAL_TREES = ('graphs-final-recovered',)
TOOLS = {'tools/run_check.py': 'run_check.py',
         'tools/verify_graph.py': 'verify_graph.py',
         'tools/collect_observations.py': 'collect_observations.py'}
EXTRA_FILES = ('cache_recovery.json', 'environment_recovery.json',
               'local-source-history.bundle', 'remote-source-tree.json',
               'remote-publication-source-commit.json', 'remote-publication-source-commit.raw')
DIRECTORY_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
FILE_FLAGS = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK


class EvidenceError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise EvidenceError(message)


def relative_parts(name):
    require(isinstance(name, str) and name and not name.startswith('/') and
            '\\' not in name and not any(ord(c) < 32 or ord(c) == 127 for c in name),
            'UNSAFE_RELATIVE_PATH: ' + repr(name))
    parts = name.split('/')
    require(all(part not in ('', '.', '..', '.git', 'target') for part in parts),
            'FORBIDDEN_PATH_COMPONENT: ' + name)
    return parts


def fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def open_workspace(path):
    require(isinstance(path, str) and path.startswith('/') and os.path.normpath(path) == path,
            'WORKSPACE_MUST_BE_CANONICAL_ABSOLUTE_PATH')
    current = os.open('/', DIRECTORY_FLAGS)
    try:
        for part in path.split('/')[1:]:
            require(part not in ('', '.', '..'), 'UNSAFE_WORKSPACE')
            following = os.open(part, DIRECTORY_FLAGS, dir_fd=current)
            os.close(current)
            current = following
        return current
    except BaseException:
        os.close(current)
        raise


def open_directory(root, relative, *, create=False):
    current = os.dup(root)
    try:
        for part in relative_parts(relative):
            if create:
                try:
                    os.mkdir(part, mode=0o755, dir_fd=current)
                except FileExistsError:
                    pass
            following = os.open(part, DIRECTORY_FLAGS, dir_fd=current)
            os.close(current)
            current = following
        return current
    except BaseException:
        os.close(current)
        raise


def file_info(root, relative):
    parts = relative_parts(relative)
    parent = open_directory(root, '/'.join(parts[:-1])) if len(parts) > 1 else os.dup(root)
    try:
        info = os.stat(parts[-1], dir_fd=parent, follow_symlinks=False)
        require(stat.S_ISREG(info.st_mode), 'NON_REGULAR_SOURCE: ' + relative)
        return fingerprint(info)
    finally:
        os.close(parent)


def read_source(root, relative, expected):
    parts = relative_parts(relative)
    parent = open_directory(root, '/'.join(parts[:-1])) if len(parts) > 1 else os.dup(root)
    descriptor = None
    try:
        descriptor = os.open(parts[-1], FILE_FLAGS, dir_fd=parent)
        before = os.fstat(descriptor)
        require(stat.S_ISREG(before.st_mode), 'NON_REGULAR_SOURCE: ' + relative)
        require(fingerprint(before) == expected, 'SOURCE_CHANGED_BEFORE_READ: ' + relative)
        chunks = []
        while True:
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                break
            chunks.append(chunk)
        raw = b''.join(chunks)
        require(fingerprint(os.fstat(descriptor)) == expected and len(raw) == before.st_size,
                'SOURCE_CHANGED_DURING_READ: ' + relative)
        return raw
    finally:
        if descriptor is not None:
            os.close(descriptor)
        os.close(parent)


def inventory(root):
    files = {}
    included_optional = []

    def add(member, source, info):
        relative_parts(member)
        relative_parts(source)
        require(member not in files, 'DUPLICATE_ARCHIVE_MEMBER: ' + member)
        files[member] = (source, fingerprint(info))

    def walk(directory, prefix):
        for name in sorted(os.listdir(directory)):
            relative_parts(name)
            relative = prefix + '/' + name
            info = os.stat(name, dir_fd=directory, follow_symlinks=False)
            if stat.S_ISDIR(info.st_mode):
                child = os.open(name, DIRECTORY_FLAGS, dir_fd=directory)
                try:
                    require(fingerprint(os.fstat(child)) == fingerprint(info),
                            'DIRECTORY_CHANGED: ' + relative)
                    walk(child, relative)
                finally:
                    os.close(child)
            else:
                require(stat.S_ISREG(info.st_mode), 'SYMLINK_OR_SPECIAL_SOURCE: ' + relative)
                add(relative, relative, info)

    for tree in TREES + OPTIONAL_TREES:
        try:
            directory = open_directory(root, tree)
        except FileNotFoundError:
            require(tree in OPTIONAL_TREES, 'MISSING_REQUIRED_TREE: ' + tree)
            continue
        try:
            walk(directory, tree)
        finally:
            os.close(directory)
        if tree in OPTIONAL_TREES:
            included_optional.append(tree)
    for member, source in {**TOOLS, **{name: name for name in EXTRA_FILES}}.items():
        files[member] = (source, file_info(root, source))
    return dict(sorted(files.items())), included_optional


def no_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'DUPLICATE_JSON_KEY: ' + key)
        result[key] = value
    return result


def parsed(raw):
    def reject_constant(value):
        raise EvidenceError('NONFINITE_JSON: ' + value)
    return json.loads(raw, object_pairs_hook=no_duplicate_keys, parse_constant=reject_constant)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def verify_check_closure(contents):
    logs = sorted(name for name in contents if name.startswith('checks/') and name.endswith('.log'))
    require(logs, 'NO_CHECK_LOGS')
    records = {}
    for log in logs:
        record_name = log[:-4] + '.json'
        require(record_name in contents, 'UNCLOSED_CHECK_LOG: ' + log)
        record = parsed(contents[record_name])
        require(isinstance(record, dict) and record.get('name') == PurePosixPath(log).stem,
                'CHECK_RECORD_IDENTITY: ' + record_name)
        require(record.get('log_sha256') == sha(contents[log]), 'CHECK_LOG_DIGEST: ' + log)
        require('returncode' in record, 'CHECK_EXIT_NOT_RECORDED: ' + record_name)
        code = record['returncode']
        require(code is None or type(code) is int, 'CHECK_EXIT_TYPE: ' + record_name)
        if code is None:
            explicit_interruption = (record.get('schema') == 'work-knowledge-interrupted-check-v1' and
                record.get('successful_check') is False and
                record.get('disposition_recorded_after_recovery') is True and
                isinstance(record.get('result'), str) and record['result'] not in ('', 'PASS', 'OK'))
            require(record.get('timed_out') is True or explicit_interruption,
                    'CHECK_WITHOUT_CLOSED_DISPOSITION: ' + record_name)
        else:
            require(record.get('timed_out') is False, 'CONTRADICTORY_CHECK_DISPOSITION: ' + record_name)
        # Preserve recorded outcomes; do not turn a recorded interruption, a
        # runner exit or the existence of this manifest into a successful check.
        records[record_name] = {key: record[key] for key in (
            'name', 'source_commit', 'source_commit_at_launch', 'source_tree',
            'returncode', 'runner_returncode', 'timed_out', 'result',
            'successful_check', 'disposition_recorded_after_recovery') if key in record}
    for name in contents:
        if name.startswith('checks/') and name.endswith('.json'):
            require(name[:-5] + '.log' in contents, 'CHECK_RECORD_WITHOUT_LOG: ' + name)
    return records


def verify_historical_manifests(contents):
    verified = []
    for tree in HISTORICAL_TREES:
        name = tree + '/manifest.json'
        require(name in contents, 'HISTORICAL_MANIFEST_MISSING: ' + name)
        manifest = parsed(contents[name])
        require(manifest.get('schema') == 'historical-replay-output-manifest-v1' and
                isinstance(manifest.get('files'), dict), 'HISTORICAL_MANIFEST_SCHEMA: ' + name)
        actual = {member[len(tree) + 1:] for member in contents if member.startswith(tree + '/') and member != name}
        require(set(manifest['files']) == actual, 'HISTORICAL_MANIFEST_MEMBER_SET: ' + name)
        for relative, expected in manifest['files'].items():
            relative_parts(relative)
            raw = contents[tree + '/' + relative]
            require(isinstance(expected, dict) and type(expected.get('bytes')) is int and
                    expected['bytes'] == len(raw) and expected.get('sha256') == sha(raw),
                    'HISTORICAL_MANIFEST_DIGEST: ' + tree + '/' + relative)
        verified.append({'manifest': name, 'sha256': sha(contents[name]), 'files': len(actual)})
        prefix = tree + '/settlement/verified-inputs/'
        nested = prefix + 'manifest.json'
        require(nested in contents, 'SNAPSHOT_MANIFEST_MISSING: ' + nested)
        snapshot = parsed(contents[nested])
        require(snapshot.get('schema') == 'pon-settlement-verified-inputs-v1' and
                isinstance(snapshot.get('files_sha256'), dict), 'SNAPSHOT_MANIFEST_SCHEMA: ' + nested)
        names = {member[len(prefix):] for member in contents if member.startswith(prefix) and member != nested}
        require(set(snapshot['files_sha256']) == names, 'SNAPSHOT_MANIFEST_MEMBER_SET: ' + nested)
        for relative, digest in snapshot['files_sha256'].items():
            relative_parts(relative)
            require(digest == sha(contents[prefix + relative]), 'SNAPSHOT_MANIFEST_DIGEST: ' + prefix + relative)
        verified.append({'manifest': nested, 'sha256': sha(contents[nested]), 'files': len(names)})
    return verified


def verify_graph_summaries(contents):
    verified = []
    for tree in GRAPH_TREES:
        names = {name for name in contents if name.startswith(tree + '/')}
        if not names:
            continue
        summary_name = tree + '/summary.json'
        if summary_name not in contents:
            verified.append({'directory': tree, 'scope': 'partial capture retained without a successful graph summary'})
            continue
        summary = parsed(contents[summary_name])
        require(summary.get('schema') == 'work-knowledge-cargo-graphs-v1' and
                isinstance(summary.get('graphs'), dict), 'GRAPH_SUMMARY_SCHEMA: ' + summary_name)
        for label, record in summary['graphs'].items():
            relative_parts(label)
            member = tree + '/' + label + '.json'
            require(member in contents, 'GRAPH_MISSING: ' + member)
            raw, graph = contents[member], parsed(contents[member])
            require(record['metadata_sha256'] == sha(raw) and
                    record['workspace_members'] == len(graph['workspace_members']) and
                    record['packages'] == len(graph['packages']) and
                    record['resolved_nodes'] == len(graph['resolve']['nodes']),
                    'GRAPH_SUMMARY_MISMATCH: ' + member)
        verified.append({'manifest': summary_name, 'sha256': sha(contents[summary_name]),
                         'scope': 'captured metadata hashes and counts checked; no Cargo rerun'})
    return verified


def source_identity(root, expected):
    require(re.fullmatch('[0-9a-f]{40}', expected) is not None, 'SOURCE_COMMIT_FORMAT')
    repository = open_directory(root, 'chain')
    try:
        raw = subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'],
            cwd='/proc/self/fd/' + str(repository), pass_fds=(repository,), text=True)
    finally:
        os.close(repository)
    commit, tree = raw.strip().splitlines()
    require(commit == expected, 'SOURCE_COMMIT_CHANGED: expected ' + expected + ', observed ' + commit)
    require(re.fullmatch('[0-9a-f]{40}', tree) is not None, 'SOURCE_TREE_FORMAT')
    return {'commit': commit, 'tree': tree}


def write_archive(file_object, contents):
    with lzma.LZMAFile(file_object, mode='w', format=lzma.FORMAT_XZ,
                       check=lzma.CHECK_CRC64, preset=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name, raw in sorted(contents.items()):
                member = tarfile.TarInfo(name)
                member.size = len(raw)
                member.mode = 0o644
                member.uid = member.gid = member.mtime = 0
                member.uname = member.gname = ''
                member.type = tarfile.REGTYPE
                member.pax_headers = {}
                archive.addfile(member, io.BytesIO(raw))


def verify_archive(raw, contents, sources, root):
    seen = []
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:xz') as archive:
        for member in archive:
            relative_parts(member.name)
            require(member.name in contents and member.name not in seen and member.isfile(),
                    'UNEXPECTED_ARCHIVE_MEMBER: ' + member.name)
            require(member.uid == member.gid == member.mtime == 0 and member.mode == 0o644 and
                    member.uname == member.gname == '' and member.size == len(contents[member.name]),
                    'ARCHIVE_MEMBER_METADATA: ' + member.name)
            with archive.extractfile(member) as extracted:
                require(extracted.read() == contents[member.name], 'ARCHIVE_MEMBER_BYTES: ' + member.name)
            source, info = sources[member.name]
            require(read_source(root, source, info) == contents[member.name],
                    'ARCHIVE_SOURCE_BYTES_CHANGED: ' + source)
            seen.append(member.name)
    require(seen == sorted(contents), 'ARCHIVE_MEMBER_SET_OR_ORDER')


def save_exclusive(directory, name, raw):
    descriptor = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                         mode=0o644, dir_fd=directory)
    try:
        with os.fdopen(descriptor, 'wb', closefd=False) as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
    except BaseException:
        os.unlink(name, dir_fd=directory)
        raise
    finally:
        os.close(descriptor)


def collect(root, expected, check_only):
    identity = source_identity(root, expected)
    sources, optional = inventory(root)
    contents = {name: read_source(root, source, info) for name, (source, info) in sources.items()}
    checks = verify_check_closure(contents)
    historical = verify_historical_manifests(contents)
    graphs = verify_graph_summaries(contents)
    if check_only:
        require(inventory(root) == (sources, optional), 'SOURCES_CHANGED_DURING_CHECK')
        require(source_identity(root, expected) == identity, 'SOURCE_IDENTITY_CHANGED')
        return {'result': 'READY_TO_PACKAGE_NOT_TEST_PASS', 'members': len(contents),
                'uncompressed_bytes': sum(map(len, contents.values())), 'check_records': len(checks),
                'candidate': identity, 'optional_directories': optional}

    # Work entirely in memory before creating repository artifacts. Source bytes
    # are re-read through no-follow descriptors while checking each tar member.
    buffer = io.BytesIO()
    write_archive(buffer, contents)
    archive_raw = buffer.getvalue()
    verify_archive(archive_raw, contents, sources, root)
    require(inventory(root) == (sources, optional), 'SOURCES_CHANGED_DURING_PACKAGING')
    require(source_identity(root, expected) == identity, 'SOURCE_IDENTITY_CHANGED')
    manifest = {
        'schema': 'pon-work-knowledge-observations-v1', 'candidate': identity,
        'archive': {'file': 'observations.tar.xz', 'bytes': len(archive_raw), 'sha256': sha(archive_raw),
                    'tar_format': 'PAX', 'compression': 'XZ CRC64 preset 6',
                    'member_order': 'lexicographic', 'uid': 0, 'gid': 0, 'mtime': 0, 'mode': '0644'},
        'members': {name: {'bytes': len(raw), 'sha256': sha(raw), 'source': sources[name][0]}
                    for name, raw in sorted(contents.items())},
        'recorded_checks': checks, 'historical_manifests_verified': historical,
        'graph_summaries_verified': graphs, 'optional_directories': optional,
        'archive_members_compared_byte_for_byte_with_sources': True,
        'source_file_set_and_fingerprints_rechecked': True,
        'scope': ('Raw successes, failures, interruptions, red/green probes and historical replay are retained. '
                  'This collection verifies file integrity and closed check records, not a pass of all checks, '
                  'independent model efficacy, work hardness, production safety or activation.')}
    manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=True) + '\n').encode()
    directory = open_directory(root, OUTPUT, create=True)
    published = []
    try:
        # Refuse existing evidence; never replace an earlier package silently.
        for name in ('observations.tar.xz', 'observations-manifest.json'):
            try:
                os.stat(name, dir_fd=directory, follow_symlinks=False)
            except FileNotFoundError:
                continue
            raise EvidenceError('OUTPUT_EXISTS: ' + OUTPUT + '/' + name)
        for name, raw in (('observations.tar.xz', archive_raw), ('observations-manifest.json', manifest_raw)):
            save_exclusive(directory, name, raw)
            published.append(name)
        os.fsync(directory)
        # Check final on-disk bytes too, not just the in-memory compressed stream.
        for name, raw in (('observations.tar.xz', archive_raw), ('observations-manifest.json', manifest_raw)):
            relative = OUTPUT + '/' + name
            require(read_source(root, relative, file_info(root, relative)) == raw,
                    'PUBLISHED_BYTES_MISMATCH: ' + relative)
        # A final per-member source read closes the interval spent writing the
        # archive and manifest. Newly created or removed input files also refuse.
        verify_archive(archive_raw, contents, sources, root)
        require(inventory(root) == (sources, optional), 'SOURCES_CHANGED_DURING_PUBLICATION')
        require(source_identity(root, expected) == identity, 'SOURCE_IDENTITY_CHANGED')
    except BaseException:
        for name in reversed(published):
            os.unlink(name, dir_fd=directory)
        raise
    finally:
        os.close(directory)
    return {'result': 'PACKAGED_AND_BYTE_VERIFIED_NOT_TEST_PASS', 'candidate': identity,
            'members': len(contents), 'archive': OUTPUT + '/observations.tar.xz',
            'archive_bytes': len(archive_raw), 'archive_sha256': sha(archive_raw),
            'manifest': OUTPUT + '/observations-manifest.json', 'manifest_sha256': sha(manifest_raw)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', default=WORKSPACE)
    parser.add_argument('--expected-source', default=SOURCE)
    parser.add_argument('--check-only', action='store_true', help='validate readiness without creating any artifact')
    args = parser.parse_args()
    root = open_workspace(args.workspace)
    try:
        result = collect(root, args.expected_source, args.check_only)
    finally:
        os.close(root)
    print(json.dumps(result, sort_keys=True), flush=True)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, TypeError, AttributeError,
            subprocess.CalledProcessError, tarfile.TarError, lzma.LZMAError) as error:
        print(json.dumps({'result': 'REFUSED', 'error_type': type(error).__name__, 'error': str(error)}), file=sys.stderr)
        raise SystemExit(1)
