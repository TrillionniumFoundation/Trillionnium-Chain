#!/usr/bin/env python3
"""Run the retained 39+3 native controls on one new, exact Hepta source.

This wrapper retains the original commands, names, profile and resource limits.
It does not accept historical test results as evidence for the new source.
The imported source collector is copied unchanged from the paired Chain source.
"""

import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import traceback
import xml.etree.ElementTree as ET

import capture_chain_hepta_identity as identity


HEPTA_SHA = "36d5eff44f4071bb1f250b1c7706dc690cf0a875"
PROFILE_SHA = "63f832eabf890a5f3cd7c0e4ee1856b1ca99d4db8952de71b81282265668dc8c"
ROSTERS = (
    ("learning39", 39, "70c73f29515e30588203a1fba9d78741ba8f27f376a78537485a42d5216c8855", True),
    ("direct3", 3, "a85f94bf141745d1face6fed1f0f66240cbefe9a0322911eb7ff72ce4348c7aa", False),
)
TOOLS = Path("/home/qian-qi/work/chain-hepta-native-1f3ba4601505/tools/bin")
RUST = Path("/home/qian-qi/.rustup/toolchains/1.96.0-x86_64-unknown-linux-gnu/bin")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    path = Path(path)
    before = path.stat()
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    after = path.stat()
    key = lambda info: (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
    require(key(before) == key(after), "artifact changed while hashing: " + str(path))
    return {"path": str(path), "bytes": after.st_size, "sha256": value.hexdigest()}


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def resources():
    cgroups = Path("/proc/self/cgroup").read_text()
    names = [line.split(":", 2)[2] for line in cgroups.splitlines() if line.startswith("0::")]
    require(len(names) == 1, "one actual cgroup v2 membership is required")
    group = Path("/sys/fs/cgroup") / names[0].lstrip("/")
    unit = next((part for part in reversed(group.parts) if part.endswith(".service")), None)
    require(unit is not None, "actual systemd service unit is missing")
    command = ["systemctl", "--user", "show", unit, "-p", "MemoryMax", "-p", "CPUQuotaPerSecUSec",
               "-p", "Nice", "-p", "ControlGroup", "-p", "RuntimeMaxUSec"]
    output = subprocess.check_output(command, text=True)
    values = dict(line.split("=", 1) for line in output.splitlines() if "=" in line)
    require(values.get("ControlGroup") == names[0], "systemd and self cgroup differ")
    values.update(unit=unit, proc_self_cgroup=cgroups)
    for name in ("memory.max", "memory.peak", "memory.swap.max", "memory.swap.peak",
                 "memory.events", "cpu.max", "cpu.stat", "pids.max", "pids.peak"):
        path = group / name
        if path.exists():
            values[name] = path.read_text().strip()
    return values


def check_envelope(value):
    require(value.get("memory.max") == "8589934592" and value.get("MemoryMax") == "8589934592",
            "actual memory envelope differs from original 8 GiB")
    quota, period = value["cpu.max"].split()
    require(quota != "max" and int(quota) == 2 * int(period),
            "actual CPU envelope differs from original 2 CPU quota")


def source(root, destination):
    pair, observation = identity.capture_repository(root, HEPTA_SHA, manifest_path=destination)
    require(observation["source_status"] == "VERIFIED", "full tracked source is not verified")
    return {"source": pair, "observation": observation}


def stable_source(value):
    observation = value["observation"]
    return (value["source"], observation["tracked_manifest_sha256"],
            observation["tracked_entries"], observation["tracked_bytes"],
            observation["untracked_paths_including_ignored"], observation["errors"])


def binaries(target):
    return [digest(path) for pattern in ("codex_hepta_agentd-*", "codex_hepta_learning_artifacts-*")
            for path in sorted((target / "debug/deps").glob(pattern))
            if path.is_file() and os.access(path, os.X_OK)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--target", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--chain-sha", required=True)
    args = parser.parse_args()
    require(re.fullmatch("[0-9a-f]{40}", args.chain_sha), "full paired Chain SHA is required")
    root, target, out = args.source, args.target, args.output
    require(root.resolve(strict=True) == root and target.resolve(strict=True) == target,
            "source and target must be distinct canonical absolute directories")
    require(root not in target.parents and target not in root.parents and root != target,
            "source and target must not overlap")
    out.mkdir(mode=0o700, parents=False, exist_ok=False)
    started_ns = time.time_ns()
    result = {"schema": "hepta-new-pair-native-controls-v1", "started_ns": started_ns,
              "paired_chain_sha": args.chain_sha, "expected_hepta_sha": HEPTA_SHA,
              "engineering_controls_only": True, "actual_model_execution": False,
              "production_final_use_qualified": False, "independent_crypto_review": False,
              "historical_results_reused": False, "cache_is_not_provenance": True,
              "complete_build_load_closure_verified": False, "steps": [], "exit_code": 99}
    before = None
    try:
        result["resources_before"] = resources()
        check_envelope(result["resources_before"])
        result["runner"] = digest(__file__)
        result["source_collector"] = digest(identity.__file__)
        result["machine"] = dict(zip(("sysname", "nodename", "release", "version", "machine"), os.uname()))
        result["configured_host"] = "rog"
        result["original_runner_inputs"] = [digest(Path(__file__).parent / name)
                                            for name in ("original-learning-runner.py", "original-direct-runner.py")]
        result["cache_preparation"] = digest(root.parent / "setup/cache-copy.json")
        before = source(root, out / "source-before.manifest.json.gz")
        result["source_before"] = before
        require(digest(root / "codex-rs/.config/nextest.toml")["sha256"] == PROFILE_SHA,
                "original nextest profile, watchdog, or retry policy changed")
        result["profile"] = digest(root / "codex-rs/.config/nextest.toml")
        result["binary_before"] = binaries(target)
        result["toolchain"] = {}
        for label, path, arguments in (("rustc", RUST / "rustc", ["--version", "--verbose"]),
                                       ("cargo", RUST / "cargo", ["--version"]),
                                       ("just", TOOLS / "just", ["--version"]),
                                       ("nextest", TOOLS / "cargo-nextest", ["--version"])):
            result["toolchain"][label] = {**digest(path), "version": subprocess.check_output([str(path), *arguments], text=True)}
        require(result["toolchain"]["rustc"]["version"].startswith("rustc 1.96.0 "), "Rust compiler differs")
        require(result["toolchain"]["cargo"]["version"].startswith("cargo 1.96.0 "), "Cargo differs")
        require(result["toolchain"]["just"]["version"].strip() == "just 1.51.0", "just differs")
        require(result["toolchain"]["nextest"]["version"].startswith("cargo-nextest 0.9.103 "), "nextest differs")
        env = os.environ.copy()
        env.update(CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS="2", CARGO_INCREMENTAL="0",
                   CARGO_PROFILE_DEV_DEBUG="0", CARGO_PROFILE_TEST_DEBUG="0",
                   LIBCLANG_PATH="/usr/lib/llvm-21/lib", NEXTEST_PROFILE="local",
                   NEXTEST_TEST_THREADS="2", RUSTUP_TOOLCHAIN="1.96.0", RUST_MIN_STACK="8388608",
                   PYTHONDONTWRITEBYTECODE="1",
                   PATH=f"{RUST}:{TOOLS}:/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin")
        result["selected_environment"] = {key: env[key] for key in (
            "CARGO_TARGET_DIR", "CARGO_BUILD_JOBS", "CARGO_INCREMENTAL", "CARGO_PROFILE_DEV_DEBUG",
            "CARGO_PROFILE_TEST_DEBUG", "LIBCLANG_PATH", "NEXTEST_PROFILE", "NEXTEST_TEST_THREADS",
            "RUSTUP_TOOLCHAIN", "RUST_MIN_STACK", "PYTHONDONTWRITEBYTECODE", "PATH")}
        write_new(out / "start.json", result)
        print(json.dumps({"event": "source_and_envelope_verified", "source": before["source"],
                          "tracked_entries": before["observation"]["tracked_entries"],
                          "tracked_bytes": before["observation"]["tracked_bytes"]}), flush=True)
        for name, expected_count, roster_sha, readback in ROSTERS:
            step_dir = out / name
            step_dir.mkdir()
            roster = Path(__file__).parent / (name + ".json")
            require(digest(roster)["sha256"] == roster_sha, "original exact test roster changed")
            names = json.loads(roster.read_text())
            require(len(names) == expected_count and len(set(names)) == expected_count,
                    "expected test denominator differs")
            command = [str(TOOLS / "just"), "test", "--locked", "-p", "codex-hepta-learning-artifacts",
                       "-p", "codex-hepta-agentd", "--lib", "-E",
                       " | ".join("test(=" + test + ")" for test in names),
                       "--success-output", "final", "--failure-output", "final"]
            if readback:
                env["HEPTA_GENERATION_LEARNING_READBACK_STDOUT"] = "1"
            else:
                env.pop("HEPTA_GENERATION_LEARNING_READBACK_STDOUT", None)
            junit_paths = (root / "codex-rs/target/nextest/local/junit.xml", target / "nextest/local/junit.xml")
            for index, path in enumerate(junit_paths):
                if path.exists():
                    shutil.copy2(path, step_dir / f"prior-excluded-{index}-junit.xml")
            step = {"name": name, "command": command, "exact_test_names": names,
                    "roster": digest(roster), "readback_stdout_opt_in": readback,
                    "started_ns": time.time_ns(), "resources_before": resources()}
            check_envelope(step["resources_before"])
            result["steps"].append(step)
            write_new(step_dir / "start.json", step)
            print(json.dumps({"event": "native_command_started", "name": name, "tests": expected_count}), flush=True)
            monotonic = time.monotonic()
            with (step_dir / "native-controls.stdout").open("x") as stream:
                process = subprocess.run(command, cwd=root / "codex-rs", env=env,
                                         stdout=stream, stderr=subprocess.STDOUT)
            step.update(native_exit=process.returncode, wall_seconds=time.monotonic() - monotonic,
                        log=digest(step_dir / "native-controls.stdout"), resources_after=resources(),
                        observed_test_binaries=binaries(target))
            after = source(root, step_dir / "source-after.manifest.json.gz")
            step["source_after"] = after
            step["source_unchanged"] = stable_source(before) == stable_source(after)
            require(step["source_unchanged"], "source changed during native command")
            check_envelope(step["resources_after"])
            if process.returncode:
                result["exit_code"] = process.returncode
                raise RuntimeError("native command failed: " + name)
            text = (step_dir / "native-controls.stdout").read_text()
            run_ids = re.findall(r"Nextest run ID ([0-9a-f-]{36})", text)
            require(len(run_ids) == 1, "expected one original Nextest run identity")
            matches = []
            for path in junit_paths:
                if path.exists():
                    xml = ET.parse(path).getroot()
                    if xml.attrib.get("uuid") == run_ids[0] and path.stat().st_mtime_ns >= step["started_ns"]:
                        matches.append((path, xml))
            require(len(matches) == 1, "missing or ambiguous fresh native JUnit")
            path, xml = matches[0]
            cases = xml.findall(".//testcase")
            actual_names = [case.attrib.get("name") for case in cases]
            require(collections.Counter(actual_names) == collections.Counter(names), "actual native denominator differs")
            require(not any(case.find(tag) is not None for case in cases for tag in ("error", "failure", "skipped")),
                    "native tests report failure, error, or skip")
            shutil.copy2(path, step_dir / "native-controls.junit.xml")
            step["junit"] = {**digest(step_dir / "native-controls.junit.xml"), "attributes": xml.attrib,
                             "run_id": run_ids[0], "testcases": actual_names}
            step["status"] = "PASSED_ENGINEERING_CONTROLS"
            write_new(step_dir / "result.json", step)
            print(json.dumps({"event": "native_command_completed", "name": name,
                              "native_exit": process.returncode, "exact_test_count": len(cases),
                              "run_id": run_ids[0]}), flush=True)
        result["exit_code"] = 0
    except Exception as exc:
        result["error"] = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
    finally:
        result["finished_ns"] = time.time_ns()
        try:
            result["resources_after"] = resources()
        except Exception as exc:
            result["resource_final_error"] = str(exc)
            result["exit_code"] = result["exit_code"] or 99
        try:
            result["source_after"] = source(root, out / "source-final.manifest.json.gz")
            result["source_unchanged"] = before is not None and stable_source(before) == stable_source(result["source_after"])
            if not result["source_unchanged"]:
                result["exit_code"] = result["exit_code"] or 99
        except Exception as exc:
            result["source_final_error"] = str(exc)
            result["source_unchanged"] = False
            result["exit_code"] = result["exit_code"] or 99
        result["status"] = "PASSED_ENGINEERING_CONTROLS" if result["exit_code"] == 0 else "BLOCKED_OR_FAILED"
        write_new(out / "result.json", result)
        print(json.dumps({"event": "finished", "status": result["status"], "exit_code": result["exit_code"],
                          "error": result.get("error"), "source_unchanged": result["source_unchanged"]}), flush=True)
    return result["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
