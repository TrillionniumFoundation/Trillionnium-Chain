#!/usr/bin/env python3
"""Run one command with original full-byte source receipts on fixed 59f75acd."""
from pathlib import Path
import os
import subprocess
import sys

BASE = Path('/workspace/scratch/9d99fced0bf1')
ROOT = BASE / 'chain-current'
OUT = BASE / 'current-validation'
HEAD = '59f75acd1d4261972b8aaa45e0c36259fcafd45c'
if len(sys.argv) < 3:
    raise SystemExit('usage: run_current_exact.py LABEL COMMAND...')
label, *command = sys.argv[1:]
if any(value for key, value in os.environ.items() if
       key.startswith('CARGO_PROFILE_') or key.endswith('RUSTFLAGS')):
    raise SystemExit('compiler/profile overrides are not accepted')
actual = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
if actual != HEAD or subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT):
    raise SystemExit('requires exact clean current source')
OUT.mkdir(exist_ok=True)
if (OUT / (label + '.json')).exists() or (OUT / (label + '.log')).exists():
    raise SystemExit('preserve previous attempt and use a new label')
argv = ['bash', str(BASE / 'run-current-pq.sh'), 'python3',
        'scripts/ci/record_pq_native_command.py', '--kind', 'head',
        '--candidate', HEAD, '--tested', HEAD, '--label', label,
        '--output', str(OUT), '--', *command]
raise SystemExit(subprocess.run(argv, cwd=ROOT).returncode)
