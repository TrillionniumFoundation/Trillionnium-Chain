#!/usr/bin/python3
"""Independent closed-trial audit. SQLite connections target private copies only."""
import ast
import collections
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sqlite3
import struct
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
OUT = ROOT / 'owner-cancel-state-audit-02'
REPO = ROOT / 'integration-repo'
RUN = ROOT / 'owner-cancel-run-02'
NODE = ROOT / 'owner-cancel-research-node-02'
COLD = ROOT / 'owner-cancel-cold-readback-02'
COMMIT = '0f18f93f2d35b62c6ca6d63faf4f336d55cbf4bf'
TREE = '94334bb6b52cfd13040059a5e71f47d8cc9603f2'
OP = 'ebe3c586d634730e7464f2e3661aea37f6ed7402c0d74f1a695224510d2e2f5e'
COLLECTION_SHA = '2fa8084a18e4c720f163c4c195079ebe656e53ad5d58fa435a7428676c1abd8e'
SCOPE_SHA = '9287032cba5f84b9b03af34ac4937f232bfca4731339438bd30c8b3753899f6a'
M12_REL = 'trillionnium/crates/trnm-service-settlement/src/native_generation_budget_v2.rs'
FENCE_REL = 'trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2/task_owner.rs'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    os.umask(0o077)
    spec = importlib.util.spec_from_file_location('retained_helpers', OUT / 'readback_helpers.py')
    h = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(h)
    h.OUT, h.INVENTORY = OUT, {}
    require = h.require
    report = {
        'schema': 'TRNM-W1-OWNER-CANCEL02-INDEPENDENT-STATE-AUDIT1',
        'analysis_complete': False, 'errors': [], 'source_commit': COMMIT, 'source_tree': TREE,
        'original_operation': OP, 'original_database_connections_opened': 0,
        'original_databases_written': False, 'Node_M12_target_calls': 0,
        'new_generation_dispatches': 0, 'new_native_transactions': 0,
        'duplicate_wire_resubmission_executed_by_this_audit': False,
        'fresh_proofs_generated_by_this_audit': 0,
        'all_historical_descendants_wait_reaped': None,
        'private_database_publication_prohibited': True,
        'started_monotonic_ns': time.monotonic_ns(),
    }
    try:
        # Preserve connector content.text verbatim, including large u64 fields.
        # The envelope is JSON; its values are raw strings, never JS-reencoded objects.
        evidence = json.load(sys.stdin)
        require(isinstance(evidence, dict) and all(isinstance(v, str) for v in evidence.values()),
                'raw connector evidence strings')
        for name, raw in evidence.items():
            require(re.fullmatch(r'[a-z0-9_.-]{1,100}', name) is not None, 'ordinary evidence filename')
            h.write(OUT / 'public/audit-execution' / name, raw.encode('utf-8'))
        h.write(OUT / 'public/audit-execution/analyze_state.py', Path(__file__).read_bytes())
        for filename in ('collect_state.py', 'readback_helpers.py'):
            h.write(OUT / 'public/audit-execution' / filename, (OUT / filename).read_bytes())
        collection_raw = h.stable(OUT / 'collection.json')
        require(sha(collection_raw) == COLLECTION_SHA, 'immutable actual collection receipt')
        collection = json.loads(collection_raw)
        require(collection['collection_complete'] is True and collection['errors'] == []
                and collection['source_commit'] == COMMIT and collection['source_tree'] == TREE,
                'completed exact C1b collection')
        h.write(OUT / 'public/collection.json', collection_raw)
        # Hash the originals as ordinary files only. Never connect to original DBs.
        for pin in collection['original_files']:
            raw = h.stable(Path(pin['path']))
            require(len(raw) == pin['bytes'] and sha(raw) == pin['sha256'], 'original changed since closed collection')
        original_pins = {p['path']: p for p in collection['original_files']}
        rawdir = OUT / 'public/raw'
        config = h.obj(rawdir / 'owner-cancel-launch-plans-02/config.json')
        intent = h.obj(rawdir / 'owner-cancel-run-02/native-funded-intent.json')
        declaration = h.obj(rawdir / 'owner-cancel-run-02/owner-declaration.json')
        main_result = h.obj(rawdir / 'owner-cancel-run-02/funded-owner-cancellation-result.json')
        cold = h.obj(rawdir / 'owner-cancel-cold-readback-02/result.json')
        owner_request = h.obj(rawdir / 'owner-cancel-run-02/owner-cancel-requested.json')
        outcome = h.obj(rawdir / 'owner-cancel-run-02/owner-cancel-m12-outcome.json')
        cancel_intent = h.obj(rawdir / 'owner-cancel-run-02/native-cancel-dispatch-intent.json')
        submission = h.obj(rawdir / 'owner-cancel-run-02/native-cancel-submission-observed.json')
        start = h.obj(rawdir / 'owner-cancel-run-02/owner-cancel-start/result.json')
        terminal_observation = h.obj(rawdir / 'owner-cancel-run-02/owner-cancel-reconcile/result.json')
        request_raw = h.stable(rawdir / 'owner-cancel-run-02/target-request.json')
        request = json.loads(request_raw)
        canonical = lambda v: json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False,
                                          allow_nan=False).encode('utf-8')
        request_canonical = canonical(request)
        request_normalized = canonical({k: v for k, v in request.items() if k != 'statement'})
        require(config['expected_commit'] == COMMIT and config['expected_tree'] == TREE
                and config['provider_operation'] == OP and request['operation'] == OP,
                'frozen source and original operation')
        require(len(request_raw) == 68944 and len(request_canonical) == 66585
                and len(request['file_pins']) == 339 and 65536 < len(request_raw) <= 131072,
                'actual larger-than-old-limit complete request')
        require(sha(request_raw) == 'd1cf5f237edb4b2d24cd8136e51064a3fce1493fe186ca7d572814c989f77cf6'
                and sha(request_canonical) == intent['target_request_sha256']
                and sha(request_normalized) == intent['normalized_request_digest'], 'actual raw/canonical/normalized request pins')
        require(start['target_request_raw_sha256'] == sha(request_raw)
                and start['target_request_sha256'] == sha(request_canonical), 'actual started request same bytes')
        complete_pins = {config[name]['path']: config[name]['sha256']
                         for name in ('python', 'target', 'runtime', 'runner', 'r0vm', 'verifier', 'guest')}
        complete_pins.update({str(Path(config['repo']) / name): digest
                              for name, digest in config['source_files'].items()})
        require(request['file_pins'] == complete_pins, 'all configured source and executable pins remain in actual request')
        report['actual_request'] = {
            'raw_bytes': len(request_raw), 'raw_sha256': sha(request_raw),
            'canonical_bytes': len(request_canonical), 'canonical_sha256': sha(request_canonical),
            'normalized_sha256': sha(request_normalized), 'file_pins': len(request['file_pins']),
            'old_64KiB_raw_admission_would_reject': True, 'new_128KiB_raw_admission_satisfied': True,
            'all_configured_source_and_binary_pins_preserved': True,
        }
        source_dir = OUT / 'public/source-originals'
        m12_source = h.stable(source_dir / M12_REL).decode('utf-8')
        require(sha(m12_source.encode()) == 'acf3c206be4d1ffad879dade186cd70fa0cdf5d8c0a8cf821b8bfce086eb6484',
                'M12 exact source bytes')
        tree = subprocess.run(['/usr/bin/git', '-C', str(REPO), 'rev-parse', COMMIT + '^{tree}'],
                              stdin=subprocess.DEVNULL, capture_output=True, timeout=30)
        require(tree.returncode == 0 and tree.stdout.decode().strip() == TREE, 'immutable source tree')
        argv = ['/usr/bin/git', '-C', str(REPO), 'show', COMMIT + ':' + FENCE_REL]
        obj = subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True, timeout=30)
        require(obj.returncode == 0, 'original owner fence source available')
        h.write(source_dir / FENCE_REL, obj.stdout)
        fence_source = obj.stdout.decode('utf-8')
        target_source = h.stable(source_dir / 'scripts/w1_generation_target_v2.py').decode('utf-8')
        target_literals = {}
        max_request_ast = None
        for node in ast.parse(target_source).body:
            if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                if node.targets[0].id == 'MAX_REQUEST':
                    max_request_ast = node.value
                try:
                    target_literals[node.targets[0].id] = ast.literal_eval(node.value)
                except (ValueError, TypeError):
                    pass
        require(max_request_ast is not None and ast.dump(max_request_ast)
                == ast.dump(ast.parse('128 * 1024', mode='eval').body), 'explicit exact current raw admission policy')

        def rust_sql(source, name):
            match = re.search(r'const\s+' + name + r'\s*:\s*&str\s*=\s*("[^\n]*");', source)
            require(match is not None, 'fixed SQL literal present: ' + name)
            return json.loads(match.group(1))

        def private_db(label):
            pin = collection['database_summaries'][label]['original_pin']
            path = OUT / 'private-analysis-only' / (label + '.sqlite')
            data = h.stable(path)
            require(len(data) == pin['bytes'] and sha(data) == pin['sha256'], 'private copy exact original pin')
            c = sqlite3.connect('file:' + str(path) + '?mode=ro&immutable=1', uri=True)
            c.execute('PRAGMA query_only=ON')
            c.row_factory = sqlite3.Row
            return c

        m12 = private_db('m12-generation')
        require(m12.execute('PRAGMA application_id').fetchone()[0] == 0x504e4732
                and m12.execute('PRAGMA user_version').fetchone()[0] == 2, 'original M12 V2 namespace')
        for table, name in (('native_generation_meta_v2', 'META'), ('native_generation_events_v2', 'EVENTS')):
            require(m12.execute('SELECT sql FROM sqlite_master WHERE name=?', [table]).fetchone()[0]
                    == rust_sql(m12_source, name), 'M12 source/schema exact match')
        metas = list(m12.execute('SELECT * FROM native_generation_meta_v2'))
        require(len(metas) == 1, 'one original M12 journal')
        meta = metas[0]
        journal = meta['journal']
        require(journal.hex() == intent['journal_identity'], 'original journal identity')
        events = list(m12.execute('SELECT sequence,payload,root FROM native_generation_events_v2 ORDER BY sequence'))
        m12.close()
        names = ['Prepare', 'Intent', 'BindJob', 'Verified', 'Failure', 'Cancel', 'Settlement', 'Payment']
        rows, previous = [], bytes(32)
        for seq, event in enumerate(events, 1):
            raw = event['payload']
            require(1 <= len(raw) <= 16384 and raw[0] < len(names), 'bounded exact event discriminant')
            root = hashlib.sha256(b'pon-native-owner-w1-generation-budget-v2' + journal + previous
                                  + struct.pack('<QQ', seq, len(raw)) + raw).digest()
            require(event['sequence'] == seq and root == event['root'], 'complete M12 hash chain')
            rows.append({'sequence': seq, 'kind': names[raw[0]], 'payload_bytes': len(raw),
                         'payload_sha256': sha(raw), 'root': root.hex()})
            previous = root
        require(meta['sequence'] == len(events) and meta['root'] == previous, 'actual terminal journal head')
        require([r['kind'] for r in rows] == ['Prepare', 'Intent', 'BindJob', 'Cancel'], 'actual four-event history')
        prep, dispatch = h.prepare(events[0]['payload']), h.intent_event(events[1]['payload'])
        s, sid = prep['statement'], prep['statement_id']
        r = h.Reader(meta['configuration'])
        journal_configuration = {name: r.digest() for name in ('network', 'parameters', 'genesis')}
        journal_configuration['max_records'] = r.u32(); r.end()
        require(journal_configuration['max_records'] > 0
                and all(journal_configuration[name] == prep['anchor'][name]
                        for name in ('network', 'parameters', 'genesis')), 'journal configuration and original funding chain')
        r = h.Reader(events[2]['payload']); require(r.u8() == 2, 'BindJob discriminant')
        bound = {'statement': r.digest(), 'provider_namespace': r.digest(), 'operation': r.digest(),
                 'request_digest': r.digest()}
        length = r.u32(); require(1 <= length <= 512, 'original job length bound')
        bound['job_id'] = r.take(length).decode('utf-8'); r.end()
        require(not any(ord(ch) < 32 or 127 <= ord(ch) <= 159 for ch in bound['job_id']), 'no control job ID')
        r = h.Reader(events[3]['payload']); require(r.u8() == 5, 'Cancel discriminant')
        cancellation = {'statement': r.digest(), 'reason': r.digest()}; r.end()
        require(sid == dispatch['id'] == bound['statement'] == cancellation['statement']
                == intent['statement'] == request['statement'] == cold['original_statement'], 'all original statements')
        require(s['provider_operation'] == bound['operation'] == intent['provider_operation'] == OP
                and s['provider_namespace'] == bound['provider_namespace'] == request['provider_namespace']
                and s['request_digest'] == bound['request_digest'] == sha(request_normalized), 'original operation/request/job binding')
        require(s['execution_source_commitment'] == declaration['config_sha256']
                == sha(h.stable(rawdir / 'owner-cancel-launch-plans-02/config.json'))
                and s['task'] == intent['task'] and s['resource_cap'] == config['resource_cap'],
                'immutable statement/config/resource cap')
        require(prep['funding']['whole_obligation'] == 1000
                and prep['funding']['owner'] == s['owner'] and prep['funding']['provider'] == s['provider'],
                'actual whole NativeTask obligation')
        for value in (prep, dispatch):
            require(value['anchor']['block'] == intent['native_reserve_tip'] and value['anchor']['height'] == 1
                    and value['clock']['clock_domain'] == s['original_deadline']['clock_domain']
                    and s['original_deadline']['winner_ns'] <= value['clock']['now_ns'] < s['original_deadline']['deadline_ns'],
                    'actual funding anchor and original clock')
        original_deadline = s['original_deadline']['deadline_ns']
        require(original_deadline == config['original_deadline_ns'] == cold['original_deadline_ns']
                == main_result['original_deadline_ns'] == request['deadline_monotonic_ns'], 'unchanged original deadline')
        require(cancellation['reason'] == owner_request['reason_sha256'] == outcome['reason_sha256']
                == cold['cancellation'] == main_result['m12_cancellation_reason'], 'actual persistent owner cancellation')
        require(owner_request['state'] == 'REQUESTED' and owner_request['request_is_not_acceptance'] is True
                and owner_request['provider_failure_is_not_owner_authority'] is True
                and owner_request['native_task_action'] == 'cancel-reserved'
                and owner_request['owner'] == s['owner'] and owner_request['statement'] == sid,
                'explicit original owner intent distinct from provider failure')
        require(owner_request['start_observation_sha256'] == sha(h.stable(rawdir / 'owner-cancel-run-02/owner-cancel-start/result.json'))
                and outcome['decision'] == 'CancellationObserved' and outcome['accepted_observed'] is True
                and outcome['new_event_proven'] is False and outcome['journal_event_new'] is None
                and outcome['resource_reservation_released'] is False, 'observed cancellation preserves New/Replay limits')
        report['M12'] = {
            'namespace': 'pon-native-owner-w1-generation-budget-v2', 'journal': journal.hex(),
            'configuration': journal_configuration,
            'sequence': len(events), 'root': previous.hex(), 'events': rows,
            'event_counts': dict(collections.Counter(v['kind'] for v in rows)),
            'complete_hash_chain_and_payloads_verified': True, 'statement': sid,
            'original_statement_decoded': s, 'original_provider_job_decoded': bound,
            'persistent_cancel': cancellation, 'cold_begin_observed': cold['m12_begin'],
            'verified_event_present': False, 'failure_event_present': False,
            'settlement_event_present': False, 'payment_event_present': False,
            'resource_charge_derived_from_unchanged_Record_readback': s['resource_cap'],
            'resource_credit_or_release_authorized': False, 'gpu_usage_ns': None,
            'scope': 'No Verified/Failure consumption exists; unchanged Record::readback retains the original cap. This audit invoked no M12 method.',
        }
        fence = private_db('owner-fence')
        require(fence.execute('PRAGMA application_id').fetchone()[0] == 0x504e4f32
                and fence.execute('PRAGMA user_version').fetchone()[0] == 2, 'original generation owner namespace')
        for table, name in (('w1_generation_owner_meta_v2', 'META'), ('w1_generation_owner_tasks_v2', 'TASKS')):
            require(fence.execute('SELECT sql FROM sqlite_master WHERE name=?', [table]).fetchone()[0]
                    == rust_sql(fence_source, name), 'generation fence original SQL')
        assignments = list(fence.execute('SELECT * FROM w1_generation_owner_tasks_v2')); fence.close()
        require(len(assignments) == 1, 'one persistent assignment only')
        for field, wanted in (('task', s['task']), ('statement', sid), ('journal', journal.hex()),
                              ('operation', OP), ('request', s['request_digest'])):
            require(assignments[0][field].hex() == wanted, 'unchanged cross-journal owner assignment')
        report['generation_owner_fence'] = {k: assignments[0][k].hex() for k in assignments[0].keys()}

        native = private_db('native-node')
        active = list(native.execute('SELECT tip,generation,state_slot FROM active'))
        blocks = list(native.execute('SELECT id,parent,height,packet,state_root FROM blocks ORDER BY height'))
        deltas = list(native.execute('SELECT block,key,before,after FROM deltas'))
        native_events = list(native.execute('SELECT generation,ordinal,kind,block FROM events ORDER BY generation,ordinal'))
        native.close()
        require(len(active) == 1 and len(blocks) == 3 and [b['height'] for b in blocks] == [0, 1, 2],
                'one genesis and exactly two canonical transaction blocks')
        require(blocks[0]['id'].hex() == intent['native_reserve_parent'] and blocks[0]['parent'] is None
                and blocks[0]['packet'] is None and blocks[1]['parent'] == blocks[0]['id']
                and blocks[1]['id'].hex() == intent['native_reserve_tip'] and blocks[2]['parent'] == blocks[1]['id']
                and active[0]['tip'] == blocks[2]['id'] and active[0]['generation'] == 2,
                'actual original Reserve then Cancel ancestry')
        require(blocks[2]['id'].hex() == submission['accepted_block']
                == cold['native_task']['canonical_inclusion'] == main_result['native_task']['canonical_inclusion'],
                'original canonical Cancel inclusion')
        wire = h.stable(rawdir / 'owner-cancel-run-02/native-cancel-wire.bin')
        packet = h.stable(rawdir / 'owner-cancel-run-02/native-cancel-packet.bin')
        require(sha(wire) == cancel_intent['wire_sha256'] and sha(packet) == cancel_intent['packet_sha256']
                and blocks[2]['packet'] == packet and sum(b['packet'] == packet for b in blocks) == 1,
                'exact original signed packet occurs in one canonical stored block')
        require(packet.count(wire) == 1 and cancel_intent['native_task'] == s['task']
                and cancel_intent['owner'] == s['owner'] and cancel_intent['generation_statement'] == sid
                and cancel_intent['original_reserve_tip'] == blocks[1]['id'].hex()
                and cancel_intent['exact_nonce'] == declaration['reserve_nonce'] + 1 == 2,
                'retained original wire/nonce/task/Reserve')
        require(len(deltas) == 8 and all(d['block'] in (blocks[1]['id'], blocks[2]['id']) for d in deltas),
                'all actual post-genesis transitions accounted')

        def delta(block, key):
            matches = [d for d in deltas if d['block'] == block and d['key'] == key]
            require(len(matches) == 1, 'one canonical transition for selected key')
            d = matches[0]
            return {'block': block.hex(), 'key': key,
                    'before': json.loads(d['before']) if d['before'] is not None else None,
                    'after': json.loads(d['after']) if d['after'] is not None else None}

        task_key, owner_key = 'task:' + s['task'], 'account:' + s['owner']
        reserve_task = delta(blocks[1]['id'], task_key); cancel_task = delta(blocks[2]['id'], task_key)
        reserve_owner = delta(blocks[1]['id'], owner_key); cancel_owner = delta(blocks[2]['id'], owner_key)
        require(reserve_task['before'] is None and reserve_task['after'] == cancel_task['before']
                and reserve_task['after']['remaining'] == 1000 and reserve_task['after']['status'] == 'reserved'
                and cancel_task['after']['remaining'] == 0 and cancel_task['after']['status'] == 'cancelled'
                and cancel_task['after'] == cold['native_task']['funding_row'], 'one Reserve then one owner Cancel')
        for row in (reserve_task['after'], cancel_task['after']):
            require(row['owner'] == s['owner'] and row['provider'] == s['provider']
                    and row['deadline'] == s['chain_deadline'] and row['output'] is None, 'same task throughout cancellation')
        require(reserve_owner['after'] == cancel_owner['before']
                and [reserve_owner['before']['nonce'], reserve_owner['after']['nonce'], cancel_owner['after']['nonce']] == [0, 1, 2],
                'exact once nonce progression in canonical history')
        require(not any(d['key'] == 'account:' + s['provider'] for d in deltas),
                'no provider account delta in either actual transaction block')
        require(len(native_events) == 2 and [e['block'] for e in native_events] == [blocks[1]['id'], blocks[2]['id']],
                'two actual canonical activation event rows')
        native_summary = {
            'canonical_blocks': [{
                'id': b['id'].hex(), 'parent': b['parent'].hex() if b['parent'] is not None else None,
                'height': b['height'], 'packet_bytes': len(b['packet']) if b['packet'] is not None else None,
                'packet_sha256': sha(b['packet']) if b['packet'] is not None else None,
            } for b in blocks],
            'current_tip': active[0]['tip'].hex(), 'generation': active[0]['generation'],
            'task_transitions': [reserve_task, cancel_task], 'owner_account_transitions': [reserve_owner, cancel_owner],
            'exact_retained_cancel_packet_canonical_occurrences': 1,
            'retained_wire_byte_occurrences_in_exact_packet': 1,
            'signed_wire_sha256': sha(wire), 'signed_packet_sha256': sha(packet),
            'gross_principal_refund_units': 1000,
            'owner_net_change_in_cancel_block': cancel_owner['after']['balance'] - cancel_owner['before']['balance'],
            'owner_net_change_across_reserve_and_cancel': cancel_owner['after']['balance'] - reserve_owner['before']['balance'],
            'gross_refund_minus_net_cancel_change': 1000 - (cancel_owner['after']['balance'] - cancel_owner['before']['balance']),
            'reserve_net_debit_minus_obligation': reserve_owner['before']['balance'] - reserve_owner['after']['balance'] - 1000,
            'fee_fields_independently_decoded_from_wire': False,
            'provider_account_delta_present': False, 'provider_account_delta_in_these_blocks': 0,
            'provider_full_balance_independently_decoded': False,
            'native_signature_and_Packet_transaction_list_reverification_by_this_audit': False,
            'duplicate_wire_resubmission_executed': False,
            'once_scope': 'One exact canonical packet, one Cancel transition and nonce 1->2. Cold entry did not resubmit. No claim that a live duplicate-wire rejection was exercised.',
            'money_scope': 'Gross NativeTask principal refund is distinct from the actual owner net balance change, provider payment and M12 resource credit. Balance residuals above are arithmetic, not a separate wire-fee decoder.',
        }
        report['native_funding'] = native_summary

        target = private_db('posix-target')
        require(target.execute('PRAGMA application_id').fetchone()[0] == 0x57475432
                and target.execute('PRAGMA user_version').fetchone()[0] == 2, 'original target namespace')
        for table, name in (('target_meta', 'META_SQL'), ('operations', 'OPS_SQL')):
            require(target.execute('SELECT sql FROM sqlite_master WHERE name=?', [table]).fetchone()[0]
                    == target_literals[name], 'target V2 SQL unchanged')
        metas = list(target.execute('SELECT * FROM target_meta'))
        ops = list(target.execute('SELECT * FROM operations')); target.close()
        require(len(metas) == 1 and metas[0]['namespace'] == 'trnm-w1-generation-posix-target-v2'
                and metas[0]['target'] == request['target_instance'] and len(ops) == 1, 'one original target operation')
        op = ops[0]
        require(op['operation'] == OP and op['statement'] == sid and op['task_scope'] == request['task_scope']
                and op['request'] == request_canonical and op['request_sha256'] == sha(request_canonical)
                and op['state'] == 'terminal' and op['cancel'] == 1, 'original request persisted with sticky veto')
        worker, result = json.loads(op['worker']), json.loads(op['result'])
        cold_target = cold['target_observation']['retained_target_readback']
        require(worker == start['original_job'] == owner_request['original_job'] == cold_target['worker']
                and bound['job_id'] == worker['job_id'] and worker['operation'] == OP
                and worker['provider_namespace'] == bound['provider_namespace']
                and worker['request_sha256'] == sha(request_canonical), 'original provider process identity never replaced')
        require(result == cold_target['result'] and result['cause'] == 'cancelled' and result['sticky_cancel'] is True
                and result['command_success'] is False and result['exit_code'] == -9
                and result['may_dispatch_again'] is False and result['can_authorize_payment'] is False,
                'actual terminal cancellation remains nonpayable')
        cgroup = result['child_cgroup_observation']
        require(result['all_owned_processes_terminal'] is True and result['direct_child_reaped'] is True
                and result['all_descendants_reaped'] is None and result['cgroup_members_after_cleanup'] == []
                and cgroup['observation_complete'] is True and cgroup['recursive_empty'] is True
                and cgroup['members'] == [] and cgroup['events']['populated'] == 0
                and result['resources']['gpu_ns'] is None and result['resource_qualification'] == 'unknown',
                'actual empty recursive child scope without inventing historical reap or accounting')
        trigger = start['trigger']
        require(trigger['stage'] == 'prove-batch-0000' and trigger['child_cgroup']['observation_complete'] is True
                and trigger['child_cgroup']['events']['populated'] == 1
                and trigger['stage_runner']['identity']['pid'] in trigger['child_cgroup']['members']
                and trigger['prover_identity']['pid'] in trigger['child_cgroup']['members']
                and trigger['prover_identity']['boot_id'] == worker['identity']['boot_id']
                and trigger['stage_runner']['identity']['boot_id'] == worker['identity']['boot_id']
                and trigger['prover_executable_sha256'] == '2acdf550f9aca4d05b74072463e4ed307c3824309c754a5cb5f93aa84f3390e6'
                and trigger['prover_cmdline'][1] == '--port',
                'retained proving stage observation')
        stage_argv = trigger['stage_runner']['cmdline']
        require(len(stage_argv) == 7 and stage_argv[1] == '--r0vm'
                and stage_argv[2] == trigger['prover_cmdline'][0]
                and request['file_pins'][stage_argv[0]] == trigger['stage_runner']['executable_sha256']
                and request['file_pins'][stage_argv[2]] == trigger['prover_executable_sha256']
                and stage_argv[3:] == ['prove-parallel', str(RUN / 'proof/checkpoint'), '2', '2'],
                'actual complete parallel proving argv for original checkpoint')
        # Exact executable pins/argv are preserved in the primary start record.
        # This retrospective audit never executes the runner or considers a live
        # --port process a completed cryptographic segment.
        require(start['fresh_generation_started'] is True and start['full_proof_verified'] is False
                and start['new_complete_proofs'] == 0 and main_result['real_expensive_generation_started'] is True
                and main_result['fresh_generation_attempts'] == 1 and main_result['new_complete_proofs'] == 0,
                'one started generation, zero new complete proofs')
        require(cold['m12_begin'] == 'Pending' and cold['new_generation_dispatches'] == 0
                and cold['target_cancel_requests_sent'] == 0 and cold['native_transactions_submitted'] == 0
                and cold['deadline_renewed'] is False and cold['original_resource_cap_retained'] is True
                and cold['can_authorize_payment'] is False and main_result['node_positive'] is False
                and main_result['provider_payment_observed'] is False, 'cold terminal facts preserve Pending and no effects')
        scope_path = ROOT / 'owner-cancel-observation-02/scope-after.json'
        scope_raw = h.stable(scope_path); require(sha(scope_raw) == SCOPE_SHA, 'exact separate root closed-scope observation')
        h.write(OUT / 'public/raw/scope-after.json', scope_raw)
        scope = json.loads(scope_raw)
        require(scope['original_operation'] == OP and scope['original_deadline_ns'] == original_deadline
                and scope['all_historical_descendants_reaped'] is None
                and scope['complete_historical_resource_ownership_proved'] is False,
                'scope snapshot keeps historical resource limits')
        report['target'] = {
            'state': op['state'], 'sticky_cancel': True, 'may_dispatch_again': False,
            'original_provider_worker': worker, 'actual_result': result,
            'start_observation_sha256': owner_request['start_observation_sha256'],
            'actual_proving_stage_started': trigger['stage'],
            'new_complete_proofs': 0, 'cold_same_request_worker_result': True,
            'resource_accounting_complete': False, 'gpu_usage_ns': None,
            'scope_after_sha256': SCOPE_SHA,
        }
        report['cold_recovery'] = {
            'source': original_pins[str(COLD / 'result.json')],
            'actual_separate_entry_succeeded': True, 'begin': 'Pending',
            'new_generation_dispatches': 0, 'target_cancel_requests_sent': 0,
            'native_transactions_submitted': 0, 'original_deadline_ns': original_deadline,
            'deadline_renewed': False, 'provider_payment_authorized': False,
            'original_resource_cap_retained': True,
            'scope': 'Actual separate cold entry plus final private-copy journal/assignment/canonical state audit. No pre-cold DB byte snapshot was taken by this audit; no byte-for-byte pre/post-cold DB identity claim.',
        }
        for pin in collection['original_files']:
            path = Path(pin['path']); raw = h.stable(path)
            require(sha(raw) == pin['sha256'] and len(raw) == pin['bytes'], 'original unchanged after audit')
        for summary in collection['database_summaries'].values():
            for suffix in ('-wal', '-shm', '-journal'):
                path = Path(summary['original_pin']['path'] + suffix)
                require(not path.exists() and not path.is_symlink(), 'no original DB sidecar appeared')
        report.update(analysis_complete=True, original_files_unchanged_after=True,
                      original_database_pins={k: v['original_pin'] for k, v in collection['database_summaries'].items()},
                      original_statement=sid, original_deadline_ns=original_deadline,
                      publish_scope='Explicit public allowlist only; private copies and complete DB dumps are excluded.',
                      proof_scope='One real expensive generation started and was cancelled; zero new full proofs in this trial.',
                      production_qualified=False, provider_payment_authorized=False,
                      prelaunch_failure_retained=collection['prelaunch_failure_originals'])
    except BaseException as exc:
        report['errors'].append({'type': type(exc).__name__, 'message': str(exc)})
    report['finished_monotonic_ns'] = time.monotonic_ns()
    h.write(OUT / 'public/state-readback.json', h.encode(report))
    raw = (OUT / 'public/state-readback.json').read_bytes()
    print(json.dumps({'analysis_complete': report['analysis_complete'], 'errors': report['errors'],
                      'report': {'path': str(OUT / 'public/state-readback.json'), 'bytes': len(raw), 'sha256': sha(raw)},
                      'request': report.get('actual_request'), 'event_counts': report.get('M12', {}).get('event_counts'),
                      'native_net_cancel': report.get('native_funding', {}).get('owner_net_change_in_cancel_block')}), flush=True)
    return 0 if report['analysis_complete'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
