#!/usr/bin/env python3
"""Compare complete captured observations; never accepts partial sample sets."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
CASES = [(1024, False), (9216, False), (32768, False), (1024, True), (9216, True)]


def read_arm(name):
    path = BASE / name
    records = [json.loads(line) for line in path.read_text().splitlines()]
    source = [row for row in records if row['kind'] == 'source']
    traversals = [row for row in records if row['kind'] == 'traversal']
    summaries = [row for row in records if row['kind'] == 'summary']
    assert len(source) == 1
    assert len(traversals) == 510
    assert len(summaries) == len(CASES)
    cases = {}
    for accounts, prefill in CASES:
        subset = [r for r in traversals if (r['accounts'], r['unrelated_prefill']) == (accounts, prefill)]
        summary = [r for r in summaries if (r['accounts'], r['unrelated_prefill']) == (accounts, prefill)]
        assert len(summary) == 1
        assert len(subset) == 102
        assert len([r for r in subset if r['temperature'] == 'cold']) == 2
        assert len([r for r in subset if r['temperature'] == 'warm']) == 100
        assert sorted((r['pass'], r['instance']) for r in subset) == [(p, i) for p in range(51) for i in range(2)]
        assert all(r['sql_reads'] == r['progress_checks'] == accounts * 2 - 1 for r in subset)
        assert all(0 <= r['retained_lift_entries'] <= 8192 for r in subset)
        roots = {r['root'] for r in subset}
        assert len(roots) == 1
        samples = sorted(r['elapsed_ns'] for r in subset if r['temperature'] == 'warm')
        s = summary[0]
        assert (s['warm_p50_ns'], s['warm_p99_ns'], s['warm_max_ns']) == (samples[49], samples[98], samples[99])
        cases[(accounts, prefill)] = dict(s, root=next(iter(roots)), traversal_count=len(subset))
    return source[0], cases, {'file': str(path), 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


baseline_source, baseline, baseline_file = read_arm('lift-clear-baseline.jsonl')
candidate_source, candidate, candidate_file = read_arm('lift-replacement-candidate.jsonl')
assert baseline_source['account_archive_sha256'] == candidate_source['account_archive_sha256']
assert baseline_source['native_store_sha256'] != candidate_source['native_store_sha256']
rows = []
for key in CASES:
    old, new = baseline[key], candidate[key]
    assert old['root'] == new['root']
    rows.append({
        'accounts': key[0], 'unrelated_math_prefill': key[1], 'root': old['root'],
        'samples_per_arm': {'cold': 2, 'warm': 100},
        'baseline': old, 'candidate': new,
        'candidate_over_baseline': {metric: new[metric] / old[metric] for metric in ['warm_p50_ns', 'warm_p99_ns', 'warm_max_ns']},
    })
report = {
    'schema': 'pon-native-lift-cache-comparison-v1',
    'scope': 'Same real full-account graph, generic sha2 base6f dependencies, same local host; cache-only delta. This is not original hardware/attack/deadline business qualification or touched-state complexity closure.',
    'limitations': [
        'Baseline then candidate, not randomized crossover; 100 warm traversals are repeated observations, not independent deployment trials.',
        'SQLite is in-memory; cold refers to new arithmetic/decode caches after seeding and an uncached oracle pass. It does not mean cold physical storage or process startup.',
        'Both simultaneously live cache instances use identical graph data and separate exact caches.',
        'Unrelated prefill is synthetic exact mathematical keys at capacity followed by the real complete graph, not an authenticated history campaign.',
        'The bounded eight-way index and deterministic victim sampler can be adversarially collided; correctness falls back to the original lift math and cache speed must not reduce security cost bounds.',
        'Fixed lift slab is allocated lazily on first nonidentity lift and costs more than a partially filled BTreeMap for small graphs.',
        'RSS/HWM are entire process values with allocator retention across cases, not memory charged solely to the caches.',
        'Complete account verification still scans all nodes and state. Host quota checks, PQ, networking, and business confirmation are outside these timings.',
    ],
    'validated': {'source_account_archive_identical': True, 'traversals_per_arm': 510, 'all_roots_identical': True, 'all_sql_reads_equal_nodes': True, 'all_progress_checks_equal_nodes': True, 'all_lift_instances_bounded_8192': True},
    'sources': {'baseline': baseline_source, 'candidate': candidate_source},
    'raw_files': {'baseline': baseline_file, 'candidate': candidate_file},
    'rows': rows,
}
path = BASE / 'lift-cache-comparison.json'
path.write_text(json.dumps(report, indent=2) + '\n')
print('accounts prefill baseline_p50_ms candidate_p50_ms ratio baseline_p99_ms candidate_p99_ms ratio')
for row in rows:
    old, new = row['baseline'], row['candidate']
    print(row['accounts'], row['unrelated_math_prefill'], f"{old['warm_p50_ns']/1e6:.6f}", f"{new['warm_p50_ns']/1e6:.6f}", f"{new['warm_p50_ns']/old['warm_p50_ns']:.4f}", f"{old['warm_p99_ns']/1e6:.6f}", f"{new['warm_p99_ns']/1e6:.6f}", f"{new['warm_p99_ns']/old['warm_p99_ns']:.4f}")
print(path)
