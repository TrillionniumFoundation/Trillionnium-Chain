//! Diagnostic cost of the public negative-cache API on fixed malformed widths.
//! No native ingress, attacker-cost lower bound, or service qualification.
use pn1_w1_source_harness::pon_work::{
    rejection_cache::RejectionCache, VerificationError, WorkError, PROOF_BYTES,
};
use std::{
    hint::black_box,
    time::{Duration, Instant},
};

#[cfg(not(all(target_os = "linux", target_arch = "x86_64")))]
compile_error!("This diagnostic clock adapter is scoped to x86_64 Linux");

#[repr(C)]
struct Timespec {
    seconds: i64,
    nanoseconds: i64,
}
unsafe extern "C" {
    fn clock_gettime(clock: i32, value: *mut Timespec) -> i32;
}
fn process_cpu_ns() -> u128 {
    let mut value = Timespec {
        seconds: 0,
        nanoseconds: 0,
    };
    // Linux CLOCK_PROCESS_CPUTIME_ID. The kernel fills this owned C-ABI object.
    assert_eq!(unsafe { clock_gettime(2, &mut value) }, 0);
    assert!(value.seconds >= 0 && (0..1_000_000_000).contains(&value.nanoseconds));
    value.seconds as u128 * 1_000_000_000 + value.nanoseconds as u128
}
fn main() {
    const REPETITIONS: usize = 256;
    for length in [3, PROOF_BYTES - 1, 1_048_576, 16_777_216] {
        let allocation_start = Instant::now();
        let proof = vec![255u8; length];
        let allocation_ns = allocation_start.elapsed().as_nanos();
        let setup_start = Instant::now();
        let cache = RejectionCache::new(8, Duration::from_secs(2)).unwrap();
        let setup_ns = setup_start.elapsed().as_nanos();
        let mut length_errors = 0usize;
        let mut callbacks = 0usize;
        let wall_start = Instant::now();
        let cpu_start = process_cpu_ns();
        for _ in 0..REPETITIONS {
            let result = black_box(&cache).verify_with_progress(
                black_box([17; 32]),
                black_box([23; 32]),
                black_box([0; 32]),
                black_box(proof.as_slice()),
                &mut |_| {
                    callbacks += 1;
                    Err::<(), _>("unexpected progress")
                },
            );
            assert!(matches!(
                black_box(result),
                Err(VerificationError::Relation(WorkError::Length))
            ));
            length_errors += 1;
        }
        let cpu_ns = process_cpu_ns().checked_sub(cpu_start).unwrap();
        let wall_ns = wall_start.elapsed().as_nanos();
        assert_eq!(length_errors, REPETITIONS);
        assert_eq!(callbacks, 0);
        println!("{{\"length\":{length},\"repetitions\":{REPETITIONS},\"length_errors\":{length_errors},\"progress_callbacks\":{callbacks},\"input_allocation_wall_ns\":{allocation_ns},\"cache_setup_wall_ns\":{setup_ns},\"calls_cpu_ns\":{cpu_ns},\"calls_wall_ns\":{wall_ns},\"allocation_and_cache_setup_in_calls_timing\":false,\"clock_overhead_retained\":true}}");
    }
}
