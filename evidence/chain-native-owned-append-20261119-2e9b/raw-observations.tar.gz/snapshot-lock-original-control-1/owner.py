from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'snapshot-lock-original-control-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);tests=sys.argv[2];res={'schema':'chain-original-snapshot-lock-controls-v1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'stages':[],'complete':False}
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(src.parent/'target');env['PATH']='/home/qq/.cargo/bin:'+env['PATH']
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=src,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['stages'].append(row);save();print(json.dumps(row),flush=True);return rc
try:
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 relative='trillionnium/crates/trnm-pon-node/src/ingress/public_v3/request_observation.rs';p=src/relative;old=p.read_bytes();assert old==subprocess.check_output(['git','show','HEAD:'+relative],cwd=src)
 (out/'original.rs').write_bytes(old);res['original_sha256']=hashlib.sha256(old).hexdigest()
 text=old.decode();needle='                let mut value = row.clone();\n                match cell.task.lock() {';assert text.count(needle)==1
 text=text.replace(needle,'                let mut value = row.clone();\n                #[cfg(test)]\n                snapshot_lock_tests::after_row_copy();\n                match cell.task.lock() {')
 text+='\n#[cfg(test)]\n#[path = "request_observation_snapshot_tests.rs"]\nmod snapshot_lock_tests;\n'
 p.write_text(text);test=p.with_name('request_observation_snapshot_tests.rs')
 with test.open('x') as f:f.write(tests)
 (out/'original-instrumented.rs').write_text(text);(out/'snapshot-tests.rs').write_text(tests)
 res['instrumentation_is_test_only']=True;res['instrumented_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();res['test_sha256']=hashlib.sha256(test.read_bytes()).hexdigest();save()
 fmt=run('format',['/home/qq/.cargo/bin/cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check']);res['format_exit']=fmt;save()
 rc=run('original-lock-controls',['/home/qq/.cargo/bin/cargo','test','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--release','--locked','--offline','--lib','ingress::public_v3::request_observation::snapshot_lock_tests','--','--nocapture','--test-threads=1'])
 res['complete']=True;res['native_exit_code']=rc;save();print((out/'original-lock-controls.stdout').read_text(errors='replace')[-20000:],flush=True);print((out/'original-lock-controls.stderr').read_text(errors='replace')[-6000:],flush=True);sys.exit(rc)
except BaseException as e:
 if isinstance(e,SystemExit):raise
 res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
