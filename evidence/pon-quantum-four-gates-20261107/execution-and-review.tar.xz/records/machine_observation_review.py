"""Read-only, independent rational checks of the actual ec3a939 observation.

This driver does not import the production estimators, rebuild an oracle,
rerun native execution, or reinterpret CPU time as a quantum clock.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import subprocess

BASE = Path('/workspace/scratch/c9b48df754d6/validation-four-gates')
P = BASE / 'rog-native-ec3a939'
N = P / 'native-evidence-ec3a939'
REPO = Path('/workspace/scratch/c9b48df754d6/chain-quantum-next')
EXPECTED_HEAD = 'ec3a939706592c6ec9dd677b70589a7e8860cdfd'
checks = Counter()


def require(value, category, detail=''):
    if not value:
        raise AssertionError(category + ': ' + detail)
    checks[category] += 1


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return json.loads((N / name).read_bytes())


def rat(value):
    return F(value['numerator'], value['denominator'])


def interval(value):
    return rat(value['lower']), rat(value['upper'])


def signed_record(value, key):
    require(sha(canonical({k: v for k, v in value.items() if k != key})) == value[key],
            'canonical_record_hash')


def source_identity():
    return {k: subprocess.check_output(['git', *v], cwd=REPO, text=True).strip()
            for k, v in {'head': ['rev-parse', 'HEAD'], 'tree': ['rev-parse', 'HEAD^{tree}'],
                         'worktree_status': ['status', '--porcelain']}.items()}


before = source_identity()
require(before['head'] == EXPECTED_HEAD and not before['worktree_status'], 'frozen_source')
manifest = json.loads((P / 'native-core-manifest.json').read_bytes())
artifact_before = {name: sha((P / name).read_bytes()) for name in manifest['files']}
for name, metadata in manifest['files'].items():
    require(artifact_before[name] == metadata['sha256'] and (P / name).stat().st_size == metadata['bytes'],
            'artifact_manifest', name)
require(manifest['source_head'] == EXPECTED_HEAD and manifest['pipeline_complete'], 'artifact_manifest')
frontier = json.loads((P / 'machine-frontier.json').read_bytes())
quantum, classical = read('finite-certificate.json'), read('classical-certificate.json')
fixture, samples, replay = read('native-fixture.json'), read('bridge-samples.json'), read('native-replay.json')
pipeline = json.loads((P / 'bridge-pipeline-result.json').read_bytes())

source_map = {}
for mapping in (replay['native_source']['source_sha256'], quantum['source_sha256'],
                classical['source_sha256'], replay['independent_python_verifier']['receipt']['source_snapshot']['source_sha256']):
    for name, digest in mapping.items():
        require(name not in source_map or source_map[name] == digest, 'source_map_consistency')
        source_map[name] = digest
source_before = {name: sha((REPO / name).read_bytes()) for name in source_map}
require(source_before == source_map, 'source_content')


def inspect_machine(record, name):
    signed_record(record, 'record_sha256')
    for path, digest in record['source_sha256'].items():
        require(source_before[path] == digest, 'machine_source')
    prem, env = record['premises'], record['envelope']
    phys, life = prem['physical_model'], prem['lifecycle_model']
    p, k = prem['processors'], prem['reserved_maximum_winners']
    rows, rounds = record['domain_resources'], record['planned_rounds']
    peak, d = max(row['logical_qubits'] for row in rows), env['code_distance_for_whole_schedule']
    require(len(rounds) == len(prem['schedule']), 'planned_inventory')
    events = Counter(proofs_reserved=k, propagations=k, host_calls_including_reserved_proofs=k)
    scaled, fixed_cycles, previous = 0, 0, None
    for i, (domain_index, q) in enumerate(prem['schedule']):
        row, actual, costs = rows[domain_index], rounds[i], prem['classical_costs_ns'][domain_index]
        require((actual['schedule_index'], actual['domain_index'], actual['iterations']) == (i, domain_index, q), 'planned_inventory')
        setup = previous != row['domain_sha256']
        previous = row['domain_sha256']
        require(actual['resident_setup_charged'] == setup, 'residency')
        init_batches = (peak + life['initialization_parallel_patches'] - 1) // life['initialization_parallel_patches']
        read_batches = (row['nonce_bits'] + life['readout_parallel_bits'] - 1) // life['readout_parallel_bits']
        states = row['prepare_units']['t_states'] + q * row['iteration_units']['t_states']
        attempts = states * life['factory_attempts_per_state']
        commands = row['prepare_gate_commands'] + q * row['iteration_gate_commands'] + attempts + init_batches + read_batches + bool(states)
        expected_cycles = {
            'initialize': init_batches * life['initialization_cycles_per_distance'],
            'terminal_readout': read_batches * life['readout_cycles_per_distance'],
            'logical_gates': row['prepare_units']['data_cycles_per_distance'] + q * row['iteration_units']['data_cycles_per_distance'],
            'factory_startup': life['factory_startup_cycles_per_distance'] if states else 0,
            'factory_attempt_service': attempts * phys['factory_t_cycles_per_distance'],
            'factory_discard_reset': attempts * life['factory_discard_reset_cycles_per_distance'],
        }
        require(actual['cycles_per_distance_per_processor'] == expected_cycles, 'phase_cycles')
        fixed = commands * life['controller_cycles_per_command']
        for key, expected in {'controller_commands_per_processor': commands, 'controller_fixed_cycles_per_processor': fixed,
                              't_states_per_processor': states, 'factory_attempt_slots_per_processor': attempts,
                              'initialized_patches_per_processor': peak, 'measured_nonce_bits_per_processor': row['nonce_bits']}.items():
            require(actual[key] == expected, 'phase_events', key)
        input_bytes, output_bytes = p * row['controller_input_bytes'] * setup, p * ((row['nonce_bits'] + 7) // 8)
        for key, value in {'input_bytes_all_processors': input_bytes, 'output_bytes_all_processors': output_bytes,
                           'input_messages_all_processors': p * setup, 'output_messages_all_processors': p}.items():
            require(actual[key] == value, 'shared_bus', key)
        expected_ns = {'task_preprocessing': costs['task_preprocessing_ns'] * setup,
                       'processor_setup': costs['per_search_setup_ns'] * p * setup,
                       'input_transfer': p * setup * life['transfer_fixed_ns'] + input_bytes * life['transfer_ns_per_byte'],
                       'output_transfer': p * life['transfer_fixed_ns'] + output_bytes * life['transfer_ns_per_byte'],
                       'host_readout_turnaround': costs['per_trial_reset_readout_ns'],
                       'candidate_checks': p * costs['per_completed_trial_candidate_check_ns'],
                       'winner_proof': costs['per_winner_proof_ns'], 'winner_propagation': costs['per_winner_propagation_ns']}
        require(actual['classical_nanoseconds'] == expected_ns, 'classical_serial_charge')
        quantum_seconds = {key: value * d * F(phys['cycle_ns']) / 10**9 for key, value in expected_cycles.items()}
        quantum_seconds['controller_waits'] = fixed * F(phys['cycle_ns']) / 10**9
        require({key: rat(value) for key, value in actual['quantum_phase_seconds_exact'].items()} == quantum_seconds, 'exact_quantum_clock')
        require({key: rat(value) for key, value in actual['classical_phase_seconds_exact'].items()} == {key: F(value, 10**9) for key, value in expected_ns.items()}, 'exact_host_clock')
        winner = F(expected_ns['winner_proof'] + expected_ns['winner_propagation'], 10**9)
        require(rat(actual['winner_seconds_exact']) == winner, 'exact_winner_clock')
        require(rat(actual['search_seconds_exact']) == sum(quantum_seconds.values()) + F(sum(expected_ns.values()), 10**9) - winner, 'exact_search_clock')
        host = (1 + p) * setup + 2 * p
        require(actual['host_calls_before_winner'] == host, 'host_call_events')
        events.update(initialization_patches=p*peak, readout_bits=p*row['nonce_bits'], transfer_bytes=input_bytes+output_bytes,
                      controller_commands=p*commands, magic_state_services=p*states, factory_attempt_slots=p*attempts,
                      factory_discard_reset_slots=p*attempts, factory_startups=p*bool(states), host_calls_including_reserved_proofs=host)
        scaled += sum(expected_cycles.values())
        fixed_cycles += fixed
    require(dict(events) == env['events_all_processors'], 'whole_plan_events')
    require(env['maximum_proof_and_propagation_events_reserved'] == k, 'proof_prop_reservation')
    failure = {key: rat(value) for key, value in env['failure_union_components_upper'].items()}
    rejects = F(life['factory_reject_probability_bound']) ** life['factory_attempts_per_state']
    reject_upper = rat(env['factory_service_exhaustion_upper'])
    require(reject_upper >= rejects and reject_upper - rejects < F(1000, 2**384), 'factory_conditional_power_rounding')
    expected_errors = {
        'initialization': events['initialization_patches'] * F(life['initialization_failure_bound']),
        'readout': events['readout_bits'] * F(life['readout_failure_bound']),
        'transfer': events['transfer_bytes'] * F(life['transfer_byte_failure_bound']),
        'controller': events['controller_commands'] * F(life['controller_command_failure_bound']),
        'accepted_magic_state_service': events['magic_state_services'] * F(phys['magic_state_error']),
        'factory_attempts_exhausted': events['magic_state_services'] * reject_upper,
        'host_calls': events['host_calls_including_reserved_proofs'] * F(life['host_call_failure_bound']),
        'propagation': k * F(life['propagation_failure_bound'])}
    locations = p * peak * (scaled * d + fixed_cycles)
    logical_exact = F(phys['logical_error_prefactor']) * (F(phys['physical_error']) / F(phys['threshold'])) ** ((d+1)//2)
    logical_upper = rat(env['logical_patch_cycle_fault_upper'])
    require(logical_upper >= logical_exact and logical_upper-logical_exact < F(1000, 2**384), 'logical_fault_power_rounding')
    require(env['live_data_patch_cycles_all_processors'] == locations, 'all_live_patch_cycles')
    expected_errors['live_data_patch_cycles'] = locations * logical_upper
    require(failure == expected_errors, 'all_failure_components')
    epsilon = rat(env['whole_plan_failure_union_upper'])
    budget = F(phys['total_failure_budget'])
    require(epsilon == sum(failure.values()) and 0 < epsilon <= budget, 'whole_plan_union')
    fixed_error = sum(expected_errors.values()) - expected_errors['live_data_patch_cycles']
    for smaller in range(3, d, 2):
        exact_lower = fixed_error + p * peak * (scaled * smaller + fixed_cycles) * F(phys['logical_error_prefactor']) * (F(phys['physical_error']) / F(phys['threshold'])) ** ((smaller+1)//2)
        require(exact_lower > budget, 'earlier_distance_refusal')
    data = peak * phys['data_physical_qubits_per_d2'] * d*d
    factories = phys['factories_per_instance'] * phys['factory_physical_qubits_per_d2'] * d*d
    require(env['data_physical_qubits_per_processor'] == data and env['factory_physical_qubits_per_processor'] == factories, 'qubit_space')
    require(env['physical_qubits_all_processors'] == p*(data+factories) <= prem['physical_qubit_budget'], 'qubit_budget')
    require(env['logical_patches_reserved_and_initialized_per_processor'] == peak, 'peak_width')
    require(rat(rounds[0]['search_seconds_exact']) > F(prem['horizon_seconds']), 'first_search_censored')
    ideal = record['ideal_schedule_probability']
    require(interval(ideal['delivery_probability']) == (0, 0) and interval(ideal['search_censored_probability']) == (1, 1), 'ideal_deadline_probability')
    require(interval(record['conditional_machine_delivery_probability']) == (0, epsilon), 'conditional_nonzero_risk')
    for flag in ('quantum_hardware_executed', 'physical_parameters_calibrated', 'quantum_mining_qualified', 'production_activation',
                 'fault_tolerant_layout_and_controller_compiled', 'empirical_zero_failures_interpreted_as_zero_risk', 'minimum_attacker_cost_proved'):
        require(record[flag] is False, 'claims_not_promoted', flag)
    return {'name': name, 'code_distance': d, 'processors': p, 'trials_reserved': len(rounds), 'winners_reserved': k,
            'physical_qubits': p*(data+factories), 'epsilon_decimal_for_display': float(epsilon),
            'first_initialization_seconds': float(rat(rounds[0]['quantum_phase_seconds_exact']['initialize'])),
            'first_search_seconds': float(rat(rounds[0]['search_seconds_exact'])), 'all_exact_checks_passed': True}


signed_record(frontier, 'report_sha256')
require(frontier['planned_cells'] == frontier['observed_model_cells'] == len(frontier['cells']) == 18, 'frontier_inventory')
require({(c['predicate'], c['processors'], c['iterations']) for c in frontier['cells']} ==
        {(a, b, q) for a in ('full', 'prefix-restricted') for b in (1,2,4) for q in (0,1,2)}, 'frontier_inventory')
machine_summaries = []
for cell in frontier['cells']:
    require(cell['status'] == 'CONSTRUCTED', 'actual_refusal_inventory')
    machine_summaries.append(inspect_machine(cell['machine_record'], cell['name']))
    env = cell['machine_record']['envelope']; events = env['events_all_processors']
    require(cell['code_distance'] == env['code_distance_for_whole_schedule'] and cell['whole_plan_failure_union_upper'] == env['whole_plan_failure_union_upper'], 'frontier_projection')
    require(cell['ideal_delivery_probability'] == cell['machine_record']['ideal_schedule_probability']['delivery_probability'] and cell['conditional_delivery_probability'] == cell['machine_record']['conditional_machine_delivery_probability'], 'frontier_projection')
    require(cell['resources'] == {'physical_qubits': env['physical_qubits_all_processors'], 'controller_commands': events['controller_commands'],
                                'initialized_patches': events['initialization_patches'], 'planned_t_states': events['magic_state_services'],
                                'planned_input_bytes': sum(r['input_bytes_all_processors'] for r in cell['machine_record']['planned_rounds'])}, 'frontier_resource_projection')
require(all(interval(a['conditional_delivery_probability'])[0] < interval(b['conditional_delivery_probability'])[1]
            for a in frontier['cells'] for b in frontier['cells']), 'no_certified_interval_dominance')
require(frontier['undominated_with_certified_interval_order'] == [c['name'] for c in frontier['cells']], 'frontier_membership')
require(frontier['comparison_source_sha256'] == sha((REPO/'formal/pon-nakamoto-v1/experiments/w1_machine_frontier.py').read_bytes()), 'frontier_source')
machine_summaries.append(inspect_machine(quantum['machine_envelope'], 'finite-whole-plan'))

# Canonical input bytes, full native census, and resource identities.
require(len(fixture['contexts']) == 2, 'literal_context_inventory')
for context, row in zip(fixture['contexts'], quantum['machine_envelope']['domain_resources']):
    packet = canonical(context['template_spec'])
    require(len(packet) == row['controller_input_bytes'] and sha(packet) == row['controller_input_sha256'] == row['template_sha256'], 'actual_template_loading')
    outcomes = context['all_nonce_outcomes']
    require(sorted(x['nonce'] for x in outcomes) == list(range(8)) and len(outcomes) == row['domain_size'] == 8, 'all_native_nonces_retained')
    require(sum(x['native_winner'] for x in outcomes) == row['full_w1_accepted_count'] == row['phase_marked_count'] == 1, 'actual_full_predicate_counts')

# Bellman arithmetic is independently recomputed from every serialized edge;
# semantic transitions were separately checked by the native/finite verifier.
certificate_summary = []
for cert, expected_risk in ((quantum, F(0)), (classical, F(1,64))):
    signed_record(cert, 'certificate_sha256')
    require(cert['status'] == 'COMPLETE' and cert['finite_model_certificate_complete'] and len(cert['nodes']) == cert['state_count'], 'complete_finite_inventory')
    for key, node in cert['nodes'].items():
        require(sha(canonical(node['state'])) == key, 'finite_state_identity')
        values = []
        for action in node['actions']:
            require(sum(rat(edge['probability']) for edge in action['edges']) == 1, 'edge_probability_normalization')
            value = F(0)
            for edge in action['edges']:
                probability = rat(edge['probability'])
                require(0 <= probability <= 1, 'edge_probability_range')
                continuation = F(edge['terminal_risk']) if edge['next_state'] is None else rat(cert['nodes'][sha(canonical(edge['next_state']))]['value'])
                value += probability * continuation
                observation = edge['observation']
                if 'phases' in observation:
                    elapsed = sum(rat(phase['paid']) for phase in observation['phases'])
                    require(elapsed == rat(observation['time']) - rat(node['state']['time']), 'path_paid_clock')
                    for phase in observation['phases']:
                        paid, planned = rat(phase['paid']), rat(phase['planned'])
                        require(0 <= paid <= planned and phase['complete'] == (paid == planned), 'path_phase_completion')
                if action['action']['kind'] == 'search' and observation.get('candidate_check_complete'):
                    require(probability == F(1,8), 'actual_classical_per_nonce_probability')
            require(value == rat(action['value']), 'bellman_action_sum')
            values.append(value)
        require(max(values) == rat(node['value']), 'bellman_maximum')
    require(rat(cert['risk_upper']) == expected_risk and all(rat(x) == expected_risk for x in cert['fixed_policy_risks'].values()), 'finite_risk')
    bounds = cert['conditional_machine_risk_bounds']; epsilon = rat(bounds['failure_union_upper'])
    require(interval(bounds['census_advised_action_envelope']) == (max(0,expected_risk-epsilon),min(1,expected_risk+epsilon)), 'finite_coupled_risk')
    require(bounds['all_paths_covered_by_reserved_events'] and not bounds['hardware_calibration_or_network_security_claimed'], 'finite_risk_scope')
    certificate_summary.append({'execution_kind':cert['parameters']['execution_kind'], 'states':cert['state_count'],
                                'ideal_risk':str(expected_risk), 'epsilon_decimal_for_display':float(epsilon)})

host = classical['classical_host_envelope']; l = classical['parameters']['lifecycle_model']
require(classical['machine_envelope'] is None and host['physical_qubits'] == 0 and host['events']['quantum_events'] == 0, 'no_qpu_baseline')
require(host['events'] == {'host_calls_including_proofs':14,'nonce_generation_and_candidate_check_calls':8,'proofs_reserved':2,
                           'propagations':2,'quantum_events':0,'task_and_template_setup_calls':4}, 'classical_host_events')
require(rat(host['envelope']['whole_plan_failure_union_upper']) == 14*F(l['host_call_failure_bound'])+2*F(l['propagation_failure_bound']) == F(16,10**30), 'classical_host_union')
require(not classical['conditional_machine_risk_bounds']['common_quantum_code_distance_used'] and not host['quantum_parameters_used_for_hardware_cost'], 'no_qpu_baseline')
require(classical['positive_path']['sampled_execution'] is False and rat(classical['positive_path']['probability']) == F(1,64), 'advice_witness_scope')

# Raw-byte verifier, complete failure denominator, and native publication boundary.
verifier = replay['independent_python_verifier']['receipt']
require(verifier['status'] == 'VERIFIED' and verifier['runs'] == 4 and verifier['source_snapshot']['git_head'] == EXPECTED_HEAD, 'verifier_identity')
require(verifier['runtime_identity']['implementation'] == 'cpython' and verifier['runtime_identity']['executable'] == '/usr/bin/python3', 'verifier_runtime')
for name in ('native-fixture.json','bridge-samples.json','finite-certificate.json','classical-certificate.json'):
    require(verifier['verified_inputs'][name] == sha((N/name).read_bytes()), 'verifier_raw_binding')
require(replay['verified_raw_inputs_unchanged_through_native_replay'] is True, 'native_raw_guard')
require(replay['fixture_sha256'] == sha((N/'native-fixture.json').read_bytes()) and replay['samples_sha256'] == sha((N/'bridge-samples.json').read_bytes()), 'native_raw_binding')
require(frontier['native_fixture_sha256'] == samples['fixture_sha256'] == replay['fixture_sha256'], 'fixture_identity')
require(samples['certificate_file_sha256'] == sha((N/'finite-certificate.json').read_bytes()) and samples['classical_certificate_file_sha256'] == sha((N/'classical-certificate.json').read_bytes()), 'certificate_raw_binding')
run_summary = []
for actual, sample in zip(replay['runs'], samples['runs']):
    require(actual['name'] == sample['name'] and actual['sample_sha256'] == sha(canonical(sample)), 'native_sample_identity')
    observations = [entry['edge']['observation'] for entry in sample['raw_observation']['trajectory']]
    completed = [o for o in observations if o.get('candidate_check_complete')]
    proofs = [o for o in completed if o.get('proof_complete')]
    require(len(completed) == len(actual['candidate_probes']) == actual['completed_candidate_checks_replayed'], 'all_completed_candidates_replayed')
    require(len(proofs) == actual['private_proofs_held'], 'private_proof_boundary')
    for probe, observation in zip(actual['candidate_probes'], completed):
        require(probe['nonce'] == observation['nonce'] and probe['native_winner'] == observation['winner'], 'candidate_identity')
        require(probe['native_private_producer_admitted'] == observation['proof_complete'] and not probe['native_receiver_admission_authorized_by_this_probe'], 'producer_receiver_separation')
        require(probe['actual_cpu_proof_used_as_quantum_clock_calibration'] is False, 'cpu_not_qpu')
        if not observation['winner']:
            require(probe['native_verifier_error'] == 'Target', 'miss_denominator')
    require(len(actual['admissions']) == len(sample['packets_to_submit']), 'publication_only_admission')
    require(actual['reorganized'] == sample['expected_reorganization'] and actual['authenticated_reopen_equal'], 'native_outcome')
    if not sample['publication_complete']:
        require(not actual['admissions'] and actual['before'] == actual['after'], 'no_publication_no_state_change')
    require(not actual['real_quantum_machine'], 'cpu_not_qpu')
    run_summary.append({'name':actual['name'],'kind':actual['observation_kind'],'completed_checks':len(completed),
                        'completed_proofs':len(proofs),'receiver_admissions':len(actual['admissions']),'reorganized':actual['reorganized']})
require([(x['completed_checks'],x['completed_proofs'],x['receiver_admissions'],x['reorganized']) for x in run_summary] ==
        [(0,0,0,False),(0,0,0,False),(2,0,0,False),(2,2,2,True)], 'retained_run_denominator')
require(len(replay['runs']) == len(samples['runs']) == 4, 'retained_run_denominator')
command_summary = []
for path in sorted((P/'commands').glob('*.json')):
    command = json.loads(path.read_bytes()); log = P/'commands'/command['log_file']
    require(command['exit_code'] == 0 and command['status'] == 'command_succeeded', 'six_executed_commands')
    require(log.stat().st_size == command['log_bytes'] and sha(log.read_bytes()) == command['log_sha256'], 'command_raw_log')
    command_summary.append(path.name)
require(len(command_summary) == 6 and pipeline['complete'] and pipeline['binary_unchanged'], 'six_executed_commands')
require(pipeline['retained_full_regression']['failed_tests_remain_failures'] and len(pipeline['retained_full_regression']['observed_failed_names_at_start']) == 2, 'original_regression_failures_retained')
require(not pipeline['host_cpu_context']['exclusive_host_cpu_calibration'] and not pipeline['clock_calibrated_from_cpu'], 'cpu_not_qpu')

after = source_identity()
require(before == after, 'frozen_source_after')
require(source_before == {name:sha((REPO/name).read_bytes()) for name in source_map}, 'source_content_after')
require(artifact_before == {name:sha((P/name).read_bytes()) for name in manifest['files']}, 'artifact_content_after')
receipt = {
    'schema':'trnm-w1-actual-machine-observation-independent-review-v1', 'status':'PASS',
    'completed_utc':datetime.now(timezone.utc).isoformat(), 'source_before':before, 'source_after':after,
    'driver_sha256':sha(Path(__file__).read_bytes()), 'independent_method':'standard-library exact Fraction arithmetic; no production estimator imports, oracle rebuild, native execution, or hardware experiment',
    'source_files_checked':len(source_map), 'source_inventory_sha256':sha(canonical(source_map)),
    'artifact_files_checked':len(artifact_before), 'artifact_inventory_sha256':sha(canonical(artifact_before)),
    'manifest_sha256':sha((P/'native-core-manifest.json').read_bytes()),
    'checks':dict(sorted(checks.items())), 'assertions_passed':sum(checks.values()),
    'frontier':{'constructed':18,'refused':0,'all_ideal_delivery_exact_zero':True,'positive_conditional_epsilon_retained':True,
                'undominated':18,'reason':'Every interval has lower endpoint zero and strictly positive upper endpoint; none certifies probability dominance over another.'},
    'machines':machine_summaries, 'finite_certificates':certificate_summary, 'actual_native_runs':run_summary,
    'six_command_receipts':command_summary, 'runtime_identity':verifier['runtime_identity'],
    'remaining_boundaries':[
        'The serial initialization and factory strategy is a declared constructive model, not a minimum attacker cost or calibrated hardware bound.',
        'The 18 cells are alternative model strategies; their separate epsilon budgets are not one joint 18-strategy experimental union.',
        'All zero ideal quantum observations remain bounded above by positive conditional fault-union epsilon; no zero-risk inference is made.',
        'Quantum q=0 still provisions and initializes the constructed machine. The separately observed classical-uniform-q0 baseline uses no QPU.',
        'The full native root and child domains each contain eight declared nonce outcomes and one winner; this tiny fixed input window does not cover arbitrary domains or network strategies.',
        'The classical 1/64 value assumes fresh uniform samples and declared host clocks. Its native reorganization is a census-advised existential witness, distinct from three retained fixed-seed observations.',
        'CPU proof/verification/receiver timings were recorded under overlapping original regression load; they do not calibrate QPU clocks or exclusive-host latency bounds.',
        'The two original full-suite failures remain failures; six bridge commands passing does not promote the full native/service profile.',
        'This review rederives accounting from source-bound serialized constructed circuit counts; it does not independently compile a fault-tolerant layout or reconstruct the complete primitive circuit.'
    ]}
out = BASE/'machine-observation-review.json'
out.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':receipt['status'],'assertions':receipt['assertions_passed'],'artifacts':receipt['artifact_files_checked'],
                  'source_files':receipt['source_files_checked'],'output':str(out)}))
