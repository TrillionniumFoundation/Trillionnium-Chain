import importlib.util,json,os,pathlib,sys,tempfile
sys.dont_write_bytecode=True
path=pathlib.Path("scripts/w1_kaggle_worker_template.py").resolve()
spec=importlib.util.spec_from_file_location("worker_control",path);worker=importlib.util.module_from_spec(spec);spec.loader.exec_module(worker)
observations=[]
with tempfile.TemporaryDirectory(prefix="w1-worker-supervisor-owned-") as temporary:
 root=pathlib.Path(temporary);logs=root/"raw";logs.mkdir()
 supervisor=worker.Commands(logs,worker.Budget(20),dict(os.environ))
 try:
  output=supervisor.run("ordinary",[sys.executable,"-c","print(731)"],root)
  assert output.strip()=="731" and supervisor.rows[-1]["cleanup_complete"]
  observations.append({"case":"real_ordinary_child","passed":True,"row":supervisor.rows[-1]})
  code="import os,time; child=os.fork();\nif child==0:\n os.setsid(); time.sleep(15); os._exit(0)\nprint(child,flush=True)"
  try:supervisor.run("escaped-session-child",[sys.executable,"-c",code],root)
  except ValueError:
   row=supervisor.rows[-1]
   assert row["cleanup_complete"] is True and "OWNED_DESCENDANTS_REQUIRED_CLEANUP" in row["termination_reasons"] and row["adopted_reaped"]
   observations.append({"case":"real_owned_setsid_child_is_killed_and_reaped_without_success","passed":True,"row":row})
  else:raise AssertionError("escaped descendant was accepted as normal completion")
 finally:supervisor.close()
print(json.dumps({"schema":"TRNM-W1-WORKER-SUPERVISOR-CONTROLS1","cases":observations,"gpu":"NOT_RUN","proof":"NOT_RUN"}))
