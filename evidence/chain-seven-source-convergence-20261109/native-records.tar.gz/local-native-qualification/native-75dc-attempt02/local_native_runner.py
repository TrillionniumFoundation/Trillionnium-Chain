#!/usr/bin/env python3
"""Run selected ordinary native controls on one immutable Chain checkout.

This is an evidence runner, not a performance campaign or PQ qualification.
It preserves failed commands and leaves all source and native test logic intact.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/9fe375f34217/chain-convergence')
OUT = Path('/workspace/scratch/9fe375f34217/local-native-qualification/native-75dc-attempt02')
TARGET = Path('/dev/shm/trnm-chain-75dc-native-attempt02-9fe375f34217/target')
TEMP = Path('/dev/shm/trnm-chain-75dc-native-attempt02-9fe375f34217/tmp')
COMMIT = '75dc7ec3973ce3661c27c895418efd5c6cc8b4a8'
TREE = 'a58d215f954c1dee99ab7a031ff496e089499ba0'
RUST = Path('/workspace/scratch/ac851b3fedf0/toolchains/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
PROVIDER = Path('/workspace/scratch/ac851b3fedf0/provider/trnm-pq-provider-3.5.9.srxvzDCv/install')
PINS = {
    'bin/openssl': '2b1c8c97c617f33f76bb38ca6aac088cd9ea41cf07244d755b4a41825d6af05b',
    'include/openssl/opensslv.h': '9647fc99758cf83e3bcf11ae310894fd4911ad62bff22d8213a614df89cfedda',
    'include/openssl/configuration.h': '406c26f93511299b264062f9f3faf0760e7a0506e91a61717c491f3c92e1a996',
    'lib/libcrypto.a': '5095a536bb59b5c8cd3b9f22dfa490bbbbcb70b5482deaf8013819e751f8d05b',
    'lib/libssl.a': 'ce766975e2748030cdcab09302cae4a2e774130dff9376e42e1bef4f9918a490',
}
SELECTED = [
    ('trnm_crypto_primitives', 'pon_routed_int257_grouped::tests::factored_sampled_ranks_and_all_batch_sizes_preserve_statement_and_verifier'),
    ('trnm_crypto_primitives', 'pon_routed_int257_grouped::tests::both_producers_have_identical_statements_for_every_batch_size'),
    ('trnm_pon_node', 'ingress::public_v3::pq_identity_tests::pq_authentication_known_refusal_preserves_clean_listener_close'),
    ('trnm_pon_node', 'ingress::history_import::tests::deadline_controls::history_control_resource_expiry_refuses_late_success'),
    ('trnm_pon_node', 'ingress::history_import::tests::deadline_controls::history_control_resource_expiry_keeps_original_resource_error'),
    ('trnm_pon_node', 'ingress::history_import::tests::deadline_controls::history_owner_resource_expiry_never_invokes_exclusive_or_shared_action'),
    ('trnm_pon_node', 'ingress::history_import::tests::deadline_controls::final_resource_completion_preserves_error_priority_and_original_deadline'),
    ('trnm_pon_node', 'ingress::history_import::tests::deadline_controls::final_resource_expiry_keeps_committed_history_and_settled_cpu'),
    ('trnm_pon_node', 'ingress::history_import::tests::deadline_controls::metered_expiry_preserves_native_errors_and_settles_the_original_account'),
    ('trnm_pon_node', 'ingress::history_import::tests::deadline_controls::scope_expiry_preserves_cleanup_native_error_and_cold_reopen'),
    ('trnm_pon_node', 'ingress::history_import::tests::deadline_controls::late_admission_keeps_committed_identity_paid_cpu_and_exact_retry'),
    ('trnm_pon_node', 'store::growth::tests::header_timestamp::growth_header_timestamp_preserves_classic_outputs_admission_and_retained_replay'),
]


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


for directory in (OUT, TARGET, TEMP):
    directory.mkdir(parents=True, exist_ok=True)
if (OUT / 'summary.json').exists():
    raise SystemExit('existing summary: no replay')

EXPLICIT_ENV = {
    'PATH': str(RUST) + ':/workspace/scratch/ac851b3fedf0/toolchains/cargo/bin:/usr/local/bin:/usr/bin:/bin',
    'RUSTC': str(RUST / 'rustc'), 'RUSTUP_TOOLCHAIN': '1.95.0', 'RUSTUP_HOME': '/workspace/scratch/ac851b3fedf0/toolchains/rustup',
    'CARGO_HOME': '/workspace/scratch/ac851b3fedf0/toolchains/cargo', 'CARGO_TARGET_DIR': str(TARGET),
    'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0',
    'RUST_TEST_THREADS': '1', 'LD_LIBRARY_PATH': os.environ.get('LD_LIBRARY_PATH', ''), 'RUSTFLAGS': '', 'CARGO_ENCODED_RUSTFLAGS': '',
    'RUSTC_WRAPPER': '', 'RUSTC_WORKSPACE_WRAPPER': '',
    'OPENSSL_DIR': str(PROVIDER), 'OPENSSL_STATIC': '1',
    'TRNM_PQ_OPENSSL': str(PROVIDER / 'bin/openssl'),
    'TRNM_PQ_OPENSSL_SHA256': PINS['bin/openssl'], 'TRNM_PQ_OPENSSL_VERSION': '3.5.9',
    'OPENSSL_CONF': '/dev/null', 'OPENSSL_MODULES': str(PROVIDER / 'lib/ossl-modules'),
    'TMPDIR': str(TEMP), 'PYTHONDONTWRITEBYTECODE': '1',
    'GIT_NO_LAZY_FETCH': '1', 'GIT_TERMINAL_PROMPT': '0',
}
ENV = dict(os.environ, **EXPLICIT_ENV)
if ENV['LD_LIBRARY_PATH'] != str(RUST.parent / 'lib'):
    raise SystemExit('normal pinned Rustup loader environment required')
summary = {
    'schema': 'chain-seven-native-controls-v1', 'status': 'running',
    'commit': COMMIT, 'tree': TREE, 'root': str(ROOT),
    'started_utc': datetime.now(timezone.utc).isoformat(),
    'explicit_environment': EXPLICIT_ENV, 'commands': [], 'artifacts': {},
    'selected_tests': [{'target': target, 'test': test} for target, test in SELECTED],
    'whole_chain_quantum_security_qualified': False, 'performance_qualified': False,
    'original_resource_and_confirmation_contract_qualified': False,
    'loaded_memory_or_libraries_verified': False, 'qualification': 'HOLD',
}
save('summary.json', summary)


def provider_observation(label):
    rows = []
    for relative, expected in PINS.items():
        path = PROVIDER / relative
        observed = digest(path)
        rows.append({'path': str(path), 'bytes': path.stat().st_size,
                     'sha256': observed, 'expected_sha256': expected})
        if observed != expected:
            raise ValueError('provider input changed: ' + relative)
    save(label + '.json', rows)


def run(label, argv, limit=1800):
    log_path = OUT / (label + '.driver.log')
    row = {'label': label, 'argv': argv, 'cwd': str(ROOT),
           'started_utc': datetime.now(timezone.utc).isoformat(), 'timed_out': False}
    print(json.dumps({'event': 'command_start', **row}), flush=True)
    started = time.monotonic_ns()
    with log_path.open('xb') as log:
        child = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdout=log,
                                 stderr=subprocess.STDOUT, start_new_session=True)
        row['owned_child_pid'] = child.pid
        save('active-command.json', row)
        while True:
            mem = next(int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
            free = {n: os.statvfs(p).f_bavail*os.statvfs(p).f_frsize for n,p in [('target', TARGET),('scratch', OUT)]}
            with (OUT/'resource-observations.jsonl').open('a') as f:
                f.write(json.dumps({'label':label,'monotonic_ns':time.monotonic_ns(),'mem_available_bytes':mem,'free_bytes':free})+'\n')
            reasons=[]
            if free['target']<384*1024*1024: reasons.append('tmpfs below 384 MiB')
            if free['scratch']<256*1024*1024: reasons.append('scratch below 256 MiB')
            if mem<512*1024*1024: reasons.append('MemAvailable below 512 MiB')
            if (OUT/'cancel-request.json').exists(): reasons.append('explicit cancellation request')
            if time.monotonic_ns()-started>limit*1_000_000_000: row['timed_out']=True
            if reasons or row['timed_out']:
                row['executor_abort_reasons']=reasons
                os.killpg(child.pid,signal.SIGTERM)
                try: code=child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid,signal.SIGKILL)
                    code=child.wait()
                break
            try:
                code=child.wait(timeout=10)
                break
            except subprocess.TimeoutExpired: pass
    row.update(exit_code=code, elapsed_ns=time.monotonic_ns() - started,
               driver_log=str(log_path), driver_log_sha256=digest(log_path))
    summary['commands'].append(row)
    save('summary.json', summary)
    print(json.dumps({'event': 'command_finish', **row}), flush=True)
    if row.get('executor_abort_reasons'):
        raise RuntimeError('executor aborted: '+'; '.join(row['executor_abort_reasons']))
    return code


def record(label, command, pin=None, limit=1800):
    argv = [sys.executable, '-B', 'scripts/ci/record_pq_native_command.py',
            '--kind', 'head', '--candidate', COMMIT, '--tested', COMMIT,
            '--label', label, '--output', str(OUT)]
    if pin:
        argv.extend(['--native-executable-sha256', pin])
    return run(label, argv + ['--'] + command, limit)


try:
    actual = subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'],
                                     cwd=ROOT, env=ENV, text=True).splitlines()
    if actual != [COMMIT, TREE]:
        raise ValueError('fixed source commit/tree mismatch')
    if run('native-preflight', ['bash', 'scripts/project-preflight.sh', '--dev'], 60):
        raise ValueError('native preflight failed')
    provider_observation('provider-before')
    cargo = ['/workspace/scratch/ac851b3fedf0/toolchains/cargo/bin/cargo', '+1.95.0']
    manifest = ['--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml']
    record('strict-clippy', [*cargo, 'clippy', *manifest, '--workspace',
                            '--all-targets', '--all-features', '--', '-D', 'warnings'], limit=2400)
    build = record('native-libtest-build', [*cargo, 'test', *manifest,
                   '-p', 'trnm-crypto-primitives', '-p', 'trnm-pon-node',
                   '--all-features', '--lib', '--no-run',
                   '--message-format=json-render-diagnostics'], limit=2400)
    if build == 0:
        artifacts = {}
        for line in (OUT / 'native-libtest-build.log').read_text().splitlines():
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if (event.get('reason') == 'compiler-artifact' and event.get('executable')
                    and event.get('profile', {}).get('test')
                    and event.get('target', {}).get('name') in {target for target, _ in SELECTED}
                    and event['target']['kind'] == ['lib']):
                name = event['target']['name']
                if name in artifacts:
                    raise ValueError('duplicate native libtest artifact')
                path = Path(event['executable'])
                if not path.is_absolute() or not path.resolve().is_relative_to(TARGET.resolve()):
                    raise ValueError('native artifact outside isolated target')
                artifacts[name] = {'path': str(path), 'sha256': digest(path),
                                   'bytes': path.stat().st_size,
                                   'cargo_compiler_artifact': event}
        if set(artifacts) != {target for target, _ in SELECTED}:
            raise ValueError('native libtest artifact set incomplete')
        summary['artifacts'] = artifacts
        save('summary.json', summary)
        rosters = {}
        for name, artifact in artifacts.items():
            if record('list-' + name, [artifact['path'], '--list', '--format', 'terse'], limit=120):
                raise ValueError('native roster failed')
            names = [line[:-6] for line in (OUT / ('list-' + name + '.log')).read_text().splitlines()
                     if line.endswith(': test')]
            rosters[name] = names
            artifact['discovered_tests'] = len(names)
            artifact['roster_sha256'] = digest(OUT / ('list-' + name + '.log'))
        for index, row in enumerate(summary['selected_tests'], 1):
            row['discovered_matches'] = rosters[row['target']].count(row['test'])
            if row['discovered_matches'] != 1:
                raise ValueError('required native test does not have one discovered match: ' + row['test'])
        save('summary.json', summary)
        for index, row in enumerate(summary['selected_tests'], 1):
            artifact = artifacts[row['target']]
            label = 'native-' + str(index).zfill(2)
            row['command_label'] = label
            row['recorder_exit'] = record(label, [artifact['path'], row['test'],
                '--exact', '--nocapture', '--test-threads=1', '--format=pretty'],
                pin=artifact['sha256'], limit=240)
            receipt = OUT / (label + '.json')
            if receipt.exists():
                row['receipt'] = json.loads(receipt.read_text())
            log = OUT / (label + '.log')
            if log.exists():
                row['named_execution_check_exit'] = run(label + '-named-check',
                    [sys.executable, '-B', 'scripts/ci/check_required_native_test.py',
                     str(log), '--test', row['test']], 60)
            save('summary.json', summary)
    provider_observation('provider-after')
    run('local-source-after', [sys.executable, '-B', 'scripts/ci/verify_ci_source.py',
        '--kind', 'head', '--expected-head', COMMIT,
        '--output', str(OUT / 'local-source-after.json')], 180)
    summary['status'] = ('completed' if all(row['exit_code'] == 0 for row in summary['commands'])
                         else 'completed_with_failures')
except Exception as error:
    summary.update(status='runner_failed', error=repr(error))
    print(json.dumps({'event': 'runner_failed', 'error': repr(error)}), flush=True)
finally:
    summary['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save('summary.json', summary)
    print(json.dumps({'event': 'runner_finished', 'status': summary['status'],
                      'summary': str(OUT / 'summary.json')}), flush=True)

raise SystemExit(0 if summary['status'] == 'completed' else 1)
