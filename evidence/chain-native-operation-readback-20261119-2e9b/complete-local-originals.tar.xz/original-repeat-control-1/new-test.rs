
#[test]
fn completed_different_root_reuses_original_scope_without_new_frontier() {
    let f = two_roots();
    let node = &f.fixture.node;
    node.db.execute_batch("BEGIN IMMEDIATE").unwrap();
    let mut scope = source_scope(&f);
    let original_ids = scope.ids;
    let frontier = scope.frontier.as_ref().unwrap();
    let source = frontier.source_record();
    let slots = frontier.occupied_slots();
    let before_graphs = graphs(node);
    let mut full = 0;
    reference(node, f.parent, &f.before, &mut || {
        full += 1;
        Ok(())
    })
    .unwrap();
    let mut first = 0;
    verify(node, f.parent, &f.before, &mut scope, &mut || {
        first += 1;
        Ok(())
    })
    .unwrap();
    let mut repeated = 0;
    verify(node, f.parent, &f.before, &mut scope, &mut || {
        repeated += 1;
        Ok(())
    })
    .unwrap();
    eprintln!(
        "completed_graph_actual_callbacks full={full} first={first} repeated={repeated} actual_graphs={}",
        graphs(node) - before_graphs
    );
    assert!(first > 5 && first < full);
    assert!(repeated > 0 && repeated < first);
    assert_eq!(scope.ids, original_ids);
    assert_eq!(scope.frontier.as_ref().unwrap().source_record(), source);
    assert_eq!(scope.frontier.as_ref().unwrap().occupied_slots(), slots);
    assert_eq!(scope.graphs.len(), 4);
    scope.require_unchanged_after_last_write(&node.db).unwrap();
    drop(scope);
    node.db.execute_batch("ROLLBACK").unwrap();
}
