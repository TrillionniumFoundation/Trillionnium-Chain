#!/usr/bin/env python3
"""Bounded read-only inventory and managed official-source probes; no installer."""
import concurrent.futures
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/0776da4af99b')
REPO = ROOT / 'repo'
OUT = ROOT / 'cloud-rust-feasibility-6e39f273'
SOURCE = '6e39f27357ce7c030f5662ada3d524fecb58d63e'
TREE = 'f36683afd74fa9811bddf21787ab2386900ea70b'


def digest(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def command(label, argv, timeout=60):
    stdout_path = OUT / (label + '.stdout.log')
    stderr_path = OUT / (label + '.stderr.log')
    begin = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    error = None
    code = None
    timed_out = False
    with stdout_path.open('xb') as out, stderr_path.open('xb') as err:
        try:
            p = subprocess.run(argv, cwd=REPO, stdin=subprocess.DEVNULL,
                               stdout=out, stderr=err, timeout=timeout)
            code = p.returncode
        except subprocess.TimeoutExpired:
            timed_out = True
        except Exception as exc:
            error = {'type': type(exc).__name__, 'message': str(exc)}
    receipt = {'label': label, 'argv': argv, 'cwd': str(REPO),
               'started_utc': started, 'elapsed_seconds': time.monotonic() - begin,
               'exit_code': code, 'timed_out': timed_out, 'exception': error,
               'stdout': digest(stdout_path), 'stderr': digest(stderr_path)}
    with (OUT / (label + '.receipt.json')).open('x') as f:
        json.dump(receipt, f, indent=2, sort_keys=True)
        f.write('\n')
    print(json.dumps({'label': label, 'exit_code': code,
                      'timed_out': timed_out, 'elapsed_seconds': receipt['elapsed_seconds']}), flush=True)
    return receipt


def main():
    OUT.mkdir()
    inventory = """import json,os,shutil,subprocess
from pathlib import Path
out={'architecture':os.uname().machine,'cpu_count':os.cpu_count(),'disk':shutil.disk_usage('/workspace/scratch')._asdict(),'tools':{name:shutil.which(name) for name in ['cargo','rustc','rustup','gcc','g++','cc','make','perl','pkg-config','curl','wget','tar','xz','openssl','git','python3']}}
out['memory']={line.split(':')[0]:line.split(':')[1].strip() for line in Path('/proc/meminfo').read_text().splitlines() if line.split(':')[0] in ['MemTotal','MemAvailable','SwapTotal','SwapFree']}
out['toolchain_paths']={}
for name in ['/opt','/usr/local','/home/agent/.cargo']:
 p=Path(name)
 if not p.exists():out['toolchain_paths'][name]={'exists':False};continue
 r=subprocess.run(['rg','--files','--hidden','--no-ignore',name],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=30)
 out['toolchain_paths'][name]={'exit_code':r.returncode,'paths':[s for s in r.stdout.splitlines() if Path(s).name in ['cargo','rustc','rustup','cargo-clippy','clippy-driver','rustfmt','cargo-fmt']],'stderr':r.stderr}
out['network_policy_snapshot_available']=Path('/etc/codex/network-policy.json').exists()
print(json.dumps(out,indent=2,sort_keys=True))
"""
    source = """import subprocess,json,hashlib
from pathlib import Path
root=Path.cwd()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()
status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],text=True)
items={}
for name in ['rust-toolchain.toml','scripts/ci/prepare_pq_provider.sh']:
 b=(root/name).read_bytes();committed=subprocess.check_output(['git','show',head+':'+name])
 items[name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'matches_head':b==committed,'text':b.decode()}
print(json.dumps({'head':head,'tree':tree,'status':status,'inputs':items},indent=2,sort_keys=True))
assert head=='6e39f27357ce7c030f5662ada3d524fecb58d63e' and tree=='f36683afd74fa9811bddf21787ab2386900ea70b' and status==''
assert all(x['matches_head'] for x in items.values())
"""
    probes = [
        ('rust-manifest', 'https://static.rust-lang.org/dist/channel-rust-1.95.0.toml', False, 2097152),
        ('rust-manifest-sha256', 'https://static.rust-lang.org/dist/channel-rust-1.95.0.toml.sha256', False, 65536),
        ('openssl-archive-head', 'https://github.com/openssl/openssl/releases/download/openssl-3.5.9/openssl-3.5.9.tar.gz', True, 65536),
    ]
    observations = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        jobs = [pool.submit(command, 'inventory', ['/usr/bin/python3', '-c', inventory], 70),
                pool.submit(command, 'source-install-contract', ['/usr/bin/python3', '-c', source], 90)]
        observations.extend(job.result() for job in jobs)
    if any(row['exit_code'] != 0 for row in observations):
        raise RuntimeError('inventory or exact source contract check failed; see retained raw logs')
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        jobs = []
        for label, url, head, maximum in probes:
            argv = ['/usr/bin/curl', '--fail-with-body', '--location', '--proto', '=https',
                    '--tlsv1.2', '--connect-timeout', '8', '--max-time', '20',
                    '--max-redirs', '4', '--max-filesize', str(maximum),
                    '--output', str(OUT / (label + '.response')),
                    '--write-out', '%{http_code}\\n%{size_download}\\n%{content_type}\\n']
            if head:
                argv.append('--head')
            argv.append(url)
            jobs.append(pool.submit(command, label, argv, 30))
        observations.extend(job.result() for job in jobs)
    summary = {'schema': 'trnm-cloud-rust-feasibility-v1',
               'source_commit': SOURCE, 'source_tree': TREE,
               'runner': digest(Path(__file__)),
               'scope': 'read-only inventory, exact install-source comparison, bounded managed HTTPS probes',
               'full_source_guard_executed': False,
               'toolchain_installed': False, 'provider_built': False,
               'cargo_metadata_executed': False, 'cargo_fmt_executed': False,
               'cargo_clippy_executed': False, 'source_modified': False,
               'published': False, 'commands': observations,
               'responses': {label: digest(OUT / (label + '.response'))
                             for label, _, _, _ in probes if (OUT / (label + '.response')).is_file()}}
    with (OUT / 'summary.json').open('x') as f:
        json.dump(summary, f, indent=2, sort_keys=True)
        f.write('\n')
    print(json.dumps({'summary': str(OUT / 'summary.json'),
                      'probe_exit_codes': {row['label']: row['exit_code'] for row in observations}}), flush=True)


if __name__ == '__main__':
    main()
