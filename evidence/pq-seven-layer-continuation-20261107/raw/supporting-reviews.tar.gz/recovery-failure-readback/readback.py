#!/usr/bin/env python3
"""Read existing frozen-source receipts and logs; never execute product tests."""
from __future__ import annotations

import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/scratch/a6448796d7e7')
REPO = ROOT / 'chain-pq'
NATIVE = ROOT / 'validation-e36cfb88/native'
OUT = ROOT / 'recovery-failure-readback'
FROZEN = 'e36cfb88956a0e35e53d74c5ab71c94c628439d9'
TREE = 'b2586f06e82de55484a2e5752563e8b669c3ea17'
REFS = ['1c14fab4cca9c2ad1a48c502f51eb89edeb7df50',
        'b08e4f624c122175583094ea94f5c8c3150cec5d', FROZEN]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fact(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def load(path):
    return json.loads(path.read_text())


def git(*args):
    return subprocess.run(['git', *args], cwd=REPO, capture_output=True, check=True).stdout


def receipt(name, expected_exit):
    doc = load(NATIVE / (name + '.json'))
    raw = (NATIVE / doc['log_file']).read_bytes()
    assert doc['exit_code'] == expected_exit
    assert doc['log_sha256'] == sha(raw)
    assert doc['log_bytes'] == len(raw)
    for phase in ('before', 'after'):
        identity = doc[phase]
        assert identity['tested_commit'] == FROZEN
        assert identity['tested_tree'] == TREE
        assert identity['tracked_worktree_verified'] is True
    return doc


SUMMARY = re.compile(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; '
                     r'(\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s$', re.M)


def summaries(text):
    return [{'status': m[0], 'passed': int(m[1]), 'failed': int(m[2]),
             'ignored': int(m[3]), 'measured': int(m[4]), 'filtered_out': int(m[5]),
             'elapsed_seconds': float(m[6])} for m in SUMMARY.findall(text)]


def blocks(text):
    return {name: body.strip() for name, body in re.findall(
        r'^---- (\S+) stdout ----\n(.*?)(?=^---- |^failures:|\Z)', text, re.M | re.S)}


def final_failures(text):
    tail = text.rsplit('\nfailures:\n', 1)[1]
    return re.findall(r'^    (\S+)$', tail, re.M)


def source_location(location):
    match = re.fullmatch(r'(.+):(\d+):(\d+)', location)
    assert match, location
    relative = 'trillionnium/' + match[1]
    line = int(match[2])
    source = git('show', f'{FROZEN}:{relative}').decode().splitlines()
    return {'repository_path': relative, 'line': line, 'column': int(match[3]),
            'line_text': source[line - 1]}


def failure(name, body, group, cause):
    return {'name': name, 'status': 'FAILED', 'group': group, 'cause_id': cause,
            'errno_values': sorted(set(map(int, re.findall(r'code: (\d+), kind:', body)))),
            'panic_locations': [source_location(loc) for loc in re.findall(
                r'panicked at ([^\n]+):\n', body)],
            'original_stdout_block': body}


def full_group(name):
    if 'recovery_cases::' in name:
        return ('recovery_cases', 'journal_time_namespace_absent')
    if name.startswith('public_submit::pq::journal::tests::'):
        return ('journal', 'journal_time_namespace_absent')
    if name.startswith('release_owner::service_tests::'):
        return ('release_service', 'release_clock_fixture_unix_bind_eperm')
    if 'pq_existing_owner_tests::' in name:
        return ('existing_owner', 'special_file_fixture_unix_bind_eperm')
    if 'pq_rollback_witness::combined_tests::' in name:
        return ('combined_witness', 'independent_witness_child_unix_bind_eperm')
    raise AssertionError('Unclassified original failure: ' + name)


full_receipt = receipt('node-full', 101)
cli_receipt = receipt('tls-cli-and-witness', 101)
cli_registry_receipt = receipt('tls-cli-and-witness-registry', 0)
full_registry_receipt = receipt('node-registry', 0)
full_text = (NATIVE / 'node-full.log').read_text()
cli_text = (NATIVE / 'tls-cli-and-witness.log').read_text()
full_names = final_failures(full_text)
full_blocks = blocks(full_text)
assert len(full_names) == len(set(full_names)) == 35
full_rows = re.findall(r'^test (\S+) \.\.\. FAILED$', full_text, re.M)
assert set(full_rows) == set(full_names) and len(full_rows) == 35
full_failures = [failure(n, full_blocks[n], *full_group(n)) for n in full_names]
full_summary = summaries(full_text)[-1]
assert (full_summary['passed'], full_summary['failed'], full_summary['ignored']) == (1217, 35, 33)
assert full_summary['filtered_out'] == 0
full_registry_names = re.findall(r'^(\S+): test$', (NATIVE / 'node-registry.log').read_text(), re.M)
assert len(full_registry_names) == len(set(full_registry_names)) == 1285
assert set(full_names) <= set(full_registry_names)

cli_sections = re.split(r'^\s+Running tests/(\w+)\.rs \([^\n]+\)\n', cli_text, flags=re.M)
cli_sections = dict(zip(cli_sections[1::2], cli_sections[2::2]))
assert set(cli_sections) == {'pq_tls_cli', 'pq_tls_witness_cli'}
cli_summaries = {name: summaries(body)[-1] for name, body in cli_sections.items()}
assert (cli_summaries['pq_tls_cli']['passed'], cli_summaries['pq_tls_cli']['failed']) == (4, 0)
assert (cli_summaries['pq_tls_witness_cli']['passed'], cli_summaries['pq_tls_witness_cli']['failed']) == (0, 5)
ordinary_names = re.findall(r'^test (\S+) \.\.\. ok$', cli_sections['pq_tls_cli'], re.M)
witness_names = final_failures(cli_sections['pq_tls_witness_cli'])
witness_blocks = blocks(cli_sections['pq_tls_witness_cli'])
assert len(ordinary_names) == 4 and len(witness_names) == 5
cli_registry_text = (NATIVE / 'tls-cli-and-witness-registry.log').read_text()
registry_sections = re.split(r'^\s+Running tests/(\w+)\.rs \([^\n]+\)\n', cli_registry_text, flags=re.M)
registry_sections = dict(zip(registry_sections[1::2], registry_sections[2::2]))
registry_names = {name: re.findall(r'^(\S+): test$', body, re.M)
                  for name, body in registry_sections.items()}
assert set(registry_names['pq_tls_cli']) == set(ordinary_names)
assert set(registry_names['pq_tls_witness_cli']) == set(witness_names)
cli_failures = [failure(n, witness_blocks[n], 'cli_witness', 'cli_witness_fixture_unix_bind_eperm')
                for n in witness_names]
assert all(row['errno_values'] == [1] for row in cli_failures)
assert all(row['panic_locations'][0]['line'] == 71 for row in cli_failures)

relatives = [
    'src/ingress/pq_network/tls/shared_tests/recovery_cases.rs',
    'src/ingress/pq_network/tls/shared_tests/recovery_cases/fixture.rs',
    'src/ingress/pq_network/tls/shared_tests/recovery_cases/proxy.rs',
    'src/public_submit/pq/journal.rs', 'src/public_submit/pq/journal_tests.rs',
    'src/release_owner/service_test_fixture.rs', 'src/release_owner/clock_contract.rs',
    'src/store/pq_existing_owner_tests.rs', 'src/store/pq_rollback_witness/combined_tests.rs',
    'tests/pq_tls_cli.rs', 'tests/pq_tls_witness_cli.rs', 'tests/pq_tls_witness_cli/support.rs',
    'src/ingress/pq_network/tls/fixtures.rs',
]
source_facts = []
for relative in relatives:
    path = 'trillionnium/crates/trnm-pon-node/' + relative
    versions = []
    for ref in REFS:
        raw = git('show', f'{ref}:{path}')
        versions.append({'commit': ref, 'git_blob': git('rev-parse', '--verify', f'{ref}:{path}').decode().strip(),
                         'bytes': len(raw), 'sha256': sha(raw)})
    current = fact(REPO / path)
    assert current['sha256'] == versions[-1]['sha256']
    same = len({v['git_blob'] for v in versions}) == 1
    assert same
    source_facts.append({'repository_path': path, 'versions': versions,
                         'same_blob_across_all_three_commits': same,
                         'current_worktree_file': current,
                         'current_worktree_matches_frozen_git_object': True})

primary_paths = [ROOT / 'self-time-namespace-observation.json', ROOT / 'completed-node-elf-retirement.json']
for name in ['node-full', 'node-registry', 'tls-cli-and-witness', 'tls-cli-and-witness-registry',
             'node-build', 'compiler', 'provider-version']:
    primary_paths += [NATIVE / (name + suffix) for suffix in ('.json', '.log', '.recorder.log')]
primary_paths += [NATIVE / name for name in ['node-elf-before.json', 'node-elf-after.json',
                 'tls-cli-and-witness-elf-before.json', 'tls-cli-and-witness-elf-after.json']]
primary = [fact(path) for path in primary_paths]
node_before = load(NATIVE / 'node-elf-before.json')
node_after = load(NATIVE / 'node-elf-after.json')
retirement = load(ROOT / 'completed-node-elf-retirement.json')
assert node_before == node_after
assert all(retirement['retired'][k] == node_before[k] for k in ('bytes', 'path', 'sha256'))
assert retirement['raw_elf_body_retained'] is False
cli_before = load(NATIVE / 'tls-cli-and-witness-elf-before.json')
cli_after = load(NATIVE / 'tls-cli-and-witness-elf-after.json')
assert cli_before == cli_after
host = load(ROOT / 'self-time-namespace-observation.json')
assert host['paths']['/proc/self/ns/time']['stat']['errno'] == 2

causes = {
    'journal_time_namespace_absent': {
        'count_in_full_node': 23, 'errno': 2,
        'observed': 'Six recovery and seventeen journal tests return ENOENT during journal initialization.',
        'source_path': 'Journal::initialize (journal.rs:390) -> Epoch::new (93) -> stamp (54) -> metadata(/proc/self/ns/time).',
        'host_corroboration': str(ROOT / 'self-time-namespace-observation.json'),
        'stage': 'Before Files::acquire, prepare, or publish; recovery Harness readiness has already succeeded.',
        'inference_scope': 'Source-path attribution supported by the original ENOENT panics and independently observed missing exact namespace path; no backtrace or modified diagnostic test was run.',
    },
    'release_clock_fixture_unix_bind_eperm': {
        'count_in_full_node': 8, 'errno': 1,
        'source_path': 'release_owner/service_test_fixture.rs:70, UnixListener::bind(clock_path).',
        'stage': 'Fixture setup, before any clock-contract stamp; missing time namespace is a separate unmet condition, not the observed panic of these eight cases.',
    },
    'special_file_fixture_unix_bind_eperm': {
        'count_in_full_node': 1, 'errno': 1,
        'source_path': 'store/pq_existing_owner_tests.rs:279, UnixListener::bind(path).',
        'stage': 'Fault-2 Unix socket fixture construction; earlier symlink/hardlink loop iterations precede it, later incompatible-owner assertions are not reached.',
    },
    'independent_witness_child_unix_bind_eperm': {
        'count_in_full_node': 3, 'errno': 1,
        'source_path': 'store/pq_rollback_witness/combined_tests.rs:330 child UnixListener::bind(witness.sock); parent reports early exit at 211.',
        'stage': 'Child spawned and DurableWitness::open_existing returned successfully, then Unix listener creation failed before ready.',
    },
    'cli_witness_fixture_unix_bind_eperm': {
        'count_in_cli_witness': 5, 'errno': 1,
        'source_path': 'tests/pq_tls_witness_cli/support.rs:71, UnixListener::bind(w.sock).',
        'stage': 'All five call Witness::new first; DurableWitness::register_new returned successfully. Listener creation fails before the target CLI is launched and before the intended positive or negative assertions.',
    },
}
ordinary_scope = {
    'ordinary_binary_bad_config_pin_refuses_before_owner_creation': 'Actual config byte mutation after pinning is rejected before owner creation.',
    'ordinary_binary_local_certificate_constraints_refuse_before_owner_creation': 'Actual local certificate constraint cases refuse before owner creation.',
    'ordinary_binary_pq_tls_serve_dispatches_original_node_and_preserves_replay_after_exit': 'Actual bounded loopback pq-tls-serve process: ready profile checked, Head and Submit accepted, exact request replay preserved, normal exit, durable owner reopened and downgrade attempt refused. Service is five seconds; production_activation=false and public_history_tls=false are asserted.',
    'ordinary_binary_tls_nonloopback_refuses_before_config_and_owner': 'Nonloopback listen refuses even with absent config; no owner is created.',
}
report = {
    'schema': 'trnm-pq-frozen-node-failure-independent-readback-v1',
    'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'readback_script': fact(Path(__file__)),
    'scope': {'product_tests_executed_by_readback': False, 'repository_edited': False,
              'live_services_modified': False, 'budget_changes': False,
              'whole_chain_quantum_security_qualified': False, 'guard': 'HOLD',
              'method': 'Read existing terminal logs and receipts, compare their hashes, and inspect immutable Git objects; no product executable is invoked.'},
    'frozen_source': {'commit': FROZEN, 'tree': TREE,
                      'source_identity_check_is_not_a_test_pass': True},
    'primary_artifacts': primary,
    'full_node': {'command_receipt': full_receipt, 'registry_receipt': full_registry_receipt,
                  'registry_count': len(full_registry_names), 'final_summary': full_summary,
                  'failure_group_counts': dict(collections.Counter(f['group'] for f in full_failures)),
                  'failure_errno_counts': {'ENOENT_2': 23, 'EPERM_1': 12},
                  'failures': full_failures, 'failed_rows_and_final_failure_names_agree': True,
                  'nonfailure_stdout_blocks_with_expected_or_handled_panics': len([
                      n for n, b in full_blocks.items() if 'panicked at' in b and n not in full_names]),
                  'embedded_subprocess_summaries_are_not_added_to_outer_counts': True,
                  'timeout_reached': False, 'status_remains': 'FAILED'},
    'cli': {'command_receipt': cli_receipt, 'registry_receipt': cli_registry_receipt,
            'separate_targets': {
                'pq_tls_cli': {'registry_count': len(registry_names['pq_tls_cli']),
                    'registry_names': registry_names['pq_tls_cli'],
                    'actual_summary': cli_summaries['pq_tls_cli'],
                    'actual_tests': [{'name': n, 'status': 'ok', 'scope': ordinary_scope[n]} for n in ordinary_names]},
                'pq_tls_witness_cli': {'registry_count': len(registry_names['pq_tls_witness_cli']),
                    'registry_names': registry_names['pq_tls_witness_cli'],
                    'actual_summary': cli_summaries['pq_tls_witness_cli'], 'failures': cli_failures}},
            'registry_presence_does_not_mean_execution_passed': True,
            'combined_command_status_remains': 'FAILED',
            'cli_counts_are_not_folded_into_full_node_counts': True},
    'causes': causes,
    'host_observation': host,
    'source_comparison': {'refs': REFS,
        'historical_baseline_context': 'Parent identifies 1c14fab4 as the last complete full-pass source. This readback verifies exact source blobs, not a new historical test execution.',
        'files': source_facts, 'all_13_files_identical_across_three_refs': True,
        'conclusion_scope': 'These fixtures and prerequisite checks were not introduced or changed by the current composition; this is not proof that no other regression exists.'},
    'binary_evidence': {
        'node_before': node_before, 'node_after': node_after,
        'node_recorded_before_after_equal': True, 'node_retirement_record': retirement,
        'node_retirement_matches_both_recorded_digests': True,
        'node_raw_elf_exists_at_readback': Path(node_before['path']).exists(),
        'node_raw_elf_body_retained': False,
        'node_raw_body_not_rehashed_by_this_readback': True,
        'cli_before': cli_before, 'cli_after': cli_after, 'cli_recorded_before_after_equal': True,
        'cli_raw_bodies_not_rehashed_by_this_readback': True,
        'retirement_does_not_change_completed_test_outcomes': True,
    },
    'limitations_and_next_step': [
        'Keep original command failures and guard HOLD. Do not reclassify host refusals as product passes.',
        'The 23 ENOENT failures and 12 Unix bind EPERM failures are separate observations. Release-service cases did not reach their time-namespace contract.',
        'The five CLI witness cases failed in fixture setup; their intended target CLI assertions remain unexecuted in this invocation.',
        'Successful four ordinary TLS CLI cases establish only their bounded loopback scope; no public transport, continuous-service, whole-ledger rollback, or whole-chain PQ qualification follows.',
        'No specific seccomp, AppArmor, kernel-config, filesystem-owner, or process-spawn cause is inferred for EPERM without evidence.',
        'Run the unchanged complete workflow on a supported host providing exact time-namespace identity and the required Unix listener operations. Preserve all original budgets and fences.',
        'The retired Node ELF raw body is absent; only its matching before/after digests, retirement record, build/source evidence, and original logs/receipts are retained.',
    ],
}
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'readback.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')

md = f'''# Frozen-source Node and CLI failure readback

This is a readback of existing evidence, not a new test run. Source: `{FROZEN}`, tree `{TREE}`. The original status remains **FAILED** and every qualification guard remains **HOLD**.

## Original full Node invocation

**1217 passed / 35 failed / 33 ignored**, 1285 registry entries, zero filtered; exit 101; libtest elapsed 1405.00 seconds. The original 1500-second cap was not reached. Before/after receipts bind the same verified source tree.

| Original failure group | Count | Exact observed error and stage |
| --- | ---: | --- |
| Shared recovery cases | 6 | ENOENT (2), after Harness readiness, during recovery journal initialization. |
| Journal controls | 17 | ENOENT (2) at initializer or its wrapper. |
| Release service controls | 8 | EPERM (1), `service_test_fixture.rs:70`, `UnixListener::bind(clock_path)` before clock contract. |
| Existing owner control | 1 | EPERM (1), `pq_existing_owner_tests.rs:279`, constructing the socket fault fixture. |
| Independent witness combined controls | 3 | EPERM (1), child `combined_tests.rs:330` binding `witness.sock`; parent reports early child exit at line 211. |

The 23 ENOENT cases share `Journal::initialize:390 -> Epoch::new:93 -> stamp:54 -> metadata(/proc/self/ns/time)`. The stored host observation independently records that exact path returning ENOENT. This occurs before journal file acquisition/publication. The 12 EPERM cases are actual Unix socket bind refusals; the record does not identify a specific sandbox mechanism. In particular, the eight release cases do **not** reach their separate time-namespace contract.

The final failure list and 35 FAILED rows agree. Another 22 stdout blocks contain handled or expected panic output from successful controls; they are not additional failures. Embedded child-process summaries are not added to the outer count.

## Separate CLI invocation

Registry listing succeeded and listed 4 ordinary TLS tests plus 5 witness tests. The execution command exited 101. Its targets have distinct actual outcomes:

| Target | Actual result | Scope |
| --- | --- | --- |
| `pq_tls_cli` | **4 passed / 0 failed**, 5.90 seconds | Actual bounded ordinary CLI and three refusal controls. |
| `pq_tls_witness_cli` | **0 passed / 5 failed**, 0.31 seconds | Every case fails at `support.rs:71:52`, `UnixListener::bind(w.sock)`, EPERM (1). |

The four actual passes are:

'''
for name in ordinary_names:
    md += f'- `{name}` — {ordinary_scope[name]}\n'
md += '''
The five exact witness failures are:

'''
for name in witness_names:
    md += f'- `{name}` — same observed `support.rs:71:52` Unix bind EPERM.\n'
md += f'''
All five call `Witness::new` before starting their target CLI. Durable witness registration has returned, but listener setup fails before the intended dispatch, replay, refusal, endpoint, or binding assertions. These counts are not folded into the full Node count. Four TLS CLI passes do not qualify public transport, continuous service, or whole-chain PQ.

## Source and binary provenance

The JSON contains exact Git blob IDs, content SHA-256 values, and working-file comparisons for 13 relevant files: nine full-run fixture/implementation files plus ordinary TLS CLI, witness CLI/support, and the shared certificate fixture. All 13 have identical blobs at `1c14fab4cca9c2ad1a48c502f51eb89edeb7df50`, `b08e4f624c122175583094ea94f5c8c3150cec5d`, and the frozen source. This verifies preservation of these paths; it does not establish that unexecuted downstream assertions pass or that unrelated changes are regression-free.

The completed Node test ELF was retired after the filesystem exhausted capacity. Its retained before/after records both identify {node_before['bytes']} bytes and SHA-256 `{node_before['sha256']}`; the retirement record matches both. **The raw Node ELF body is not retained.** Original full logs and execution receipts remain intact. CLI before/after binary identity records also match; this readback compares records and does not independently rehash binary bodies.

## Primary evidence hashes

| Evidence | SHA-256 |
| --- | --- |
'''
for path in [NATIVE / 'node-full.log', NATIVE / 'node-full.json',
             NATIVE / 'tls-cli-and-witness.log', NATIVE / 'tls-cli-and-witness.json',
             NATIVE / 'tls-cli-and-witness-registry.log', ROOT / 'self-time-namespace-observation.json',
             ROOT / 'completed-node-elf-retirement.json']:
    item = fact(path)
    md += f"| `{path.name}` | `{item['sha256']}` |\n"
md += '''
The machine JSON hashes all 27 primary log, receipt, recorder, binary-identity, host-observation, and retirement artifacts and includes every original failure block and source line. It retains the two command receipts and both registries separately.

Next step: run the unchanged complete workflow on a supported host with exact time-namespace identity and the required Unix listener operations. Keep the original 5-second recovery readiness, 10-second recovery campaign, 30-second shared service, three-attempt cap, all other original budgets, and all refusal fences. No product test was rerun, no repository file was changed, and no service was modified while producing this readback.
'''
assert len(primary) == 27
(OUT / 'readback.md').write_text(md)
manifest = []
for name in ('readback.py', 'readback.json', 'readback.md'):
    item = fact(OUT / name)
    manifest.append(f"{item['sha256']}  {name}")
(OUT / 'SHA256SUMS.txt').write_text('\n'.join(manifest) + '\n')
print(json.dumps({'output': str(OUT), 'files': [fact(OUT / name) for name in
      ('readback.py', 'readback.json', 'readback.md', 'SHA256SUMS.txt')],
      'full_node': full_summary, 'cli': cli_summaries,
      'primary_artifact_count': len(primary), 'source_comparison_files': len(source_facts)}, indent=2))
