import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path('/tmp/chain-pq-fa62381e')
OUT = Path('/tmp/chain-pq-fa62381e-c4-commit')
S3 = '454ae116159867ff6cddd91b964523df7f7e16f0'
BRANCH = 'fix/chain-pq-live-retry-20261111-fa62381e'
NS = Path('evidence/pq-live-retry-20261111-fa62381e')
ASSEMBLY = Path('/tmp/chain-pq-fa62381e-c4-assembly')
ASSEMBLY_SHA = '819f57f380881ad3189fd90435ef95a85cf33b8f00788efc877e42ea9e4686e1'
PATCH_SHA = '90b0c27362cb37347e9185781f81268daf61afe3f946451fcab537d0584a3fbb'
MANIFEST_SHA = 'eaa12da5ba48d93374dc15f9a05b99122385ddf3c002bdebf7a1525b6f7e45a4'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def raw(path):
    path = Path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'not a regular single-link input')
        data = stream.read()
        after = os.fstat(stream.fileno())
        fields = lambda v: (v.st_dev, v.st_ino, v.st_mode, v.st_nlink, v.st_size, v.st_mtime_ns, v.st_ctime_ns)
        require(len(data) == before.st_size and fields(before) == fields(after) == fields(path.lstat()),
                'input changed during read: ' + str(path))
    return data


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)


def paths(*args):
    return sorted(p.decode() for p in git(*args).split(b'\0') if p)


def write(path, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    with Path(path).open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    require(raw(path) == data, 'written record differs')


require(not OUT.exists(), 'new commit observation directory required')
require(git('rev-parse', 'HEAD').decode().strip() == S3, 'integration parent changed')
require(git('branch', '--show-current').decode().strip() == BRANCH, 'branch changed')
require(not git('diff', '--cached', '--name-only'), 'concurrent staged change')
require(all(row.startswith(b'H ') for row in git('ls-files', '-v').splitlines()), 'unexpected index flags')
subprocess.run(['bash', 'scripts/project-preflight.sh'], cwd=ROOT, check=True)
assembly_bytes = raw(ASSEMBLY / 'assembly.json')
require(sha(assembly_bytes) == ASSEMBLY_SHA, 'reviewed assembly result changed')
assembly = json.loads(assembly_bytes)
require(assembly['status'] == 'assembled-not-committed' and assembly['base_commit'] == S3,
        'assembly scope differs')
require(sha(raw(ASSEMBLY / 'tracked.patch')) == PATCH_SHA
        and sha(git('diff', '--binary')) == PATCH_SHA, 'reviewed tracked diff changed')
tracked = assembly['tracked_changed_paths']
added = sorted(row['path'] for row in assembly['new_corpus_entries'])
require(paths('diff', '--name-only', '-z') == tracked, 'tracked change roster differs')
require(paths('ls-files', '--others', '--exclude-standard', '-z') == added,
        'new evidence roster differs')
manifest_path = ROOT / NS / 'evidence-artifact-manifest.json'
manifest_bytes = raw(manifest_path)
require(sha(manifest_bytes) == MANIFEST_SHA, 'reviewed evidence manifest changed')
manifest = json.loads(manifest_bytes)
require(sorted(p.name for p in (ROOT / NS).iterdir())
        == sorted([row['path'] for row in manifest['files']] + [manifest_path.name]),
        'evidence namespace includes unexpected files')
for row in manifest['files']:
    data = raw(ROOT / NS / row['path'])
    require(len(data) == row['bytes'] and sha(data) == row['sha256'], 'evidence file changed: ' + row['path'])
expected = sorted(tracked + added)
expected_bytes = {path: raw(ROOT / path) for path in expected}
require(len(expected) == 36, 'unexpected commit path count')
subprocess.run(['git', '--no-replace-objects', 'diff', '--exit-code', S3, '--',
                ':(glob)**/*.rs', ':(glob)**/Cargo.toml', ':(glob)**/Cargo.lock'], cwd=ROOT, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
OUT.mkdir()
write(OUT / 'admission.json', {
    'parent': S3, 'branch': BRANCH, 'reviewed_tracked_patch_sha256': PATCH_SHA,
    'reviewed_evidence_manifest_sha256': MANIFEST_SHA,
    'reviewed_assembly_sha256': ASSEMBLY_SHA, 'paths': expected,
    'file_identities': {path: {'bytes': len(data), 'sha256': sha(data)}
                        for path, data in expected_bytes.items()},
    'source_validation_still_required_after_commit': True,
    'whole_chain_quantum_security_qualified': False, 'production_activation': False,
})
subprocess.run(['git', 'add', '--', *expected], cwd=ROOT, check=True)
require(paths('diff', '--cached', '--name-only', '-z') == expected, 'staged roster differs')
require(not git('diff', '--name-only')
        and not git('ls-files', '--others', '--exclude-standard'), 'unstaged or untracked changes remain')
for path, data in expected_bytes.items():
    require(raw(ROOT / path) == data and git('show', ':' + path) == data, 'staged bytes differ: ' + path)
require(sha(git('diff', '--cached', '--binary', '--', *tracked)) == PATCH_SHA,
        'staged tracked bytes differ from the independently reviewed patch')
staged_manifest_bytes = git('show', ':' + str(NS / manifest_path.name))
require(sha(staged_manifest_bytes) == MANIFEST_SHA, 'staged evidence manifest differs from frozen review')
for row in json.loads(staged_manifest_bytes)['files']:
    data = git('show', ':' + str(NS / row['path']))
    require(len(data) == row['bytes'] and sha(data) == row['sha256'],
            'staged evidence bytes differ from frozen manifest: ' + row['path'])
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=ROOT, check=True)
with (OUT / 'commit.log').open('xb') as stream:
    result = subprocess.run(['git', 'commit', '-m',
                             'fix(pq): bind root register and retain source-bound validation evidence'],
                            cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
require(result.returncode == 0, 'actual git commit failed; preserve staged state and log')
source = git('rev-parse', 'HEAD').decode().strip()
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
require(git('rev-list', '--parents', '-n', '1', source).decode().split() == [source, S3],
        'committed parent list differs from the sole reviewed S3 parent')
require(paths('diff', '--name-only', '-z', S3, source) == expected, 'committed path roster differs')
for path, data in expected_bytes.items():
    require(git('show', source + ':' + path) == data and raw(ROOT / path) == data,
            'committed or working bytes differ: ' + path)
require(not git('status', '--porcelain=v1', '--untracked-files=all'), 'postcommit source is not clean')
with (OUT / 'physical-source-check.log').open('xb') as stream:
    check = subprocess.run(['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                            '--expected-head', source, '--output', str(OUT / 'source.json')],
                           cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
require(check.returncode == 0, 'commit exists but full physical-source check failed; preserve record')
physical = json.loads(raw(OUT / 'source.json'))
require(physical['tested_commit'] == source and physical['tested_tree'] == tree,
        'physical-source receipt differs from new commit')
record = {'status': 'committed-locally-not-pushed', 'parent': S3, 'source': source, 'tree': tree,
          'branch': BRANCH, 'changed_path_count': len(expected), 'source_guard': physical,
          'reviewed_tracked_patch_sha256': PATCH_SHA, 'reviewed_evidence_manifest_sha256': MANIFEST_SHA,
          'exact_committed_gates_still_required': True, 'whole_chain_quantum_security_qualified': False,
          'production_activation': False}
write(OUT / 'commit.json', record)
print(json.dumps(record, sort_keys=True), flush=True)
