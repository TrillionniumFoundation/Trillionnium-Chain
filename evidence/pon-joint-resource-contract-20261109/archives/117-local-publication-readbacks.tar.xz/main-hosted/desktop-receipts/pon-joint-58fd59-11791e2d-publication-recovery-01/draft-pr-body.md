## Why

This continuation addresses three concrete gaps on #821 that affect the joint PoN source, clock and resource contract:

1. The W1 cost experiments retained completed-search or completed-cohort receipts only after the work. An interrupted attempt or failed cohort could disappear from the retained lifecycle.
2. A mandatory Host resource callback could finish after the original deadline, allowing the next History owner action to start with an expired budget.
3. Public PGH2 admission checked the target against the current time, but final activation used the unobserved History API. A currently eligible target can retain an ancestor that is ineligible under the fresh clock.

## Changes

- **Stream the W1 lifecycle.** Add the separately named native V4 observer and strict reader. Setup, preparation, search, each attempt and both full verifiers have flushed lifecycle boundaries. Missing completion remains unknown. A canonical digest and count bind all observed trials across producer arms, including losing trials. V2/V3 selectors, signed domains and record meanings remain intact.
- **Keep the original History deadline.** Recheck the same absolute deadline after the mandatory Host callback and before returning authority to the owner action. Preserve the callback's original failure priority, mandatory resource observations and durable-work accounting.
- **Bind public activation to the current clock.** Use the existing observed-history activation API with a fresh current time for both newly admitted and exactly duplicated PGH2 packets. Full verification remains charged, and a duplicate cannot manufacture a second W1 completion.

Focused regressions, CI contract entries, exact-source inventory and PQ source pins accompany these changes. The follow-up commit scopes the intentional retained-wrapper dead-code allowances and uses an equivalent mutable-enumeration loop.

## Exact stacked source

| Identity | Value |
| --- | --- |
| Base | #821 — `fix/chain-six-full-d9fb-20261108` |
| Base commit | `e798d7125724d4b9f98c24d00cc80031f2eab4a9` |
| Implementation | `11791e2da79b69322271be2cffe03725165151d1` |
| Implementation tree | `162552848110fda532504b78865a16930bc6d9bb` |
| Retained implementation parent | `fc5c44ca91c56e77ca2ffc9943e10f0f777a5937` |

The desktop bare repository is an object transport. Preflight, builds and runtime observations use the complete implementation checkout.

## Validation at publication preparation

**Draft / HOLD / NO-GO.** Statuses below belong to the final `11791e2d` source unless explicitly labelled historical.

| Check | Observed status |
| --- | --- |
| Complete source preflight and clean checkout | PASS; 26,124 entries / 2,485,379,627 bytes |
| Source integrity tests | 43 PASS |
| CI contract tests | 165 PASS |
| Retained native example tests | V2: 10 PASS; V3: 9 PASS; V4: 11 PASS |
| Remaining static matrix | Running |
| Native library tests on ai395 | Running |
| Strict Clippy | Running |
| Complete V4 roster and real terminated-process control | Running |
| Hosted original resource campaign | Starts after publication; no new result claimed |

Two local native library test attempts ended via **SIGKILL; the cause is unknown**. Their original failed observations remain retained. Historical `fc5c44ca` strict Clippy reported three failures; the final commit addresses those diagnostics, and final-source revalidation is still running. Passing observations on `fc5c44ca` are not attributed to `11791e2d`.

The original #821 campaign retained **0/3 confirmations**. This continuation has not closed those failures. Exact-source execution receipts and hosted results will be added separately, retaining all original outcomes.

## Resource and qualification boundaries

The original 0.25-core / 2-GiB RAM / zero-swap / 256-PID contract, four-second / 16-hostile service case, three-run campaign, full History, capacity/churn and independent-confirmation criteria remain intact. The additional current-clock walk is O(history depth) and belongs in the original end-to-end budget.

The V4 diagnostic target has ideal terminal-hash density **one half**. It does not fill MU1's **one-sixteenth** experiment or any of its **16 unknown classical/quantum cost points**. Missing finishes remain unknown; timing scopes overlap and are not additive; no observer event adds consensus credit.

These changes do not establish an all-legal-algorithm cost lower bound, joint timestamp/DAA/cumulative-credit security, or a positive honest-service floor under the declared adversary. Qualification and activation remain false or unknown. This draft does not authorize merge or activation.

## Review references

- [Joint source, clock and resource contract](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/11791e2da79b69322271be2cffe03725165151d1/docs/research/PON_JOINT_RESOURCE_CONTRACT_20261108.md)
- [V4 lifecycle observation contract](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/11791e2da79b69322271be2cffe03725165151d1/docs/research/PON_W1_LIFECYCLE_COST_V4.md)