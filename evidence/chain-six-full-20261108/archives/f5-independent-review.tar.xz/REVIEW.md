# F5 independent read-only review

Source: ab610cf95a6ec39b38e20e64e6367f5b529b3633
Tree: abd4442d789b29889960f9b0acc712b9fefed498
Parent: e9b7a60b9519e39b792199dc8756fb9d1245bab8

The reviewed diff is confined to the eleven allowed paths. The ML-DSA reader changes one byte (353 to 359). The CI checker matches the previously reviewed full 23+10 literal patch. The current corpus changes exactly four blob values; all other bytes, 899 entries and 807 required paths are unchanged. All 899 current pins match the committed and actual files.

All 39 QROM selected inputs retain the same Git blobs and locked lengths/hashes. Qualification fields remain false/null. The sole native-source exception is the generated inventory's seven-line addition of the current QROM configuration, from 1484 to 1485 paths. Other native, formal, fuzz and dependency-lock Git entries are unchanged.

The historical work-cost contract and dc662 inventory pin remain unchanged and differ from the current 4220 inventory blob. No old source refusal is relabelled as successful. The original 517-entry export manifest retains its 28523b SHA-256. All 517 original file identities and actual bytes match; exactly one empty logical JSON output is stored through the fixed raw path mapping. The new verifier retains the original manifest/hash checks, rejects duplicate or changed mappings and a coexisting logical file, and restricts the single mapped raw path. This is a consistency review, not independent custody or rollback protection.

The plan and observed-results corrections retain F4 FAIL, unexecuted independent-C scope, original CodeQL deadline refusal and HOLD / NO-GO, and name the generated-inventory exception. No test, verifier, native execution or compilation was run in this review. The earlier read-only probe's unexpected cancelled/exit-15 terminal is retained separately; this scoped review is a distinct operation.
