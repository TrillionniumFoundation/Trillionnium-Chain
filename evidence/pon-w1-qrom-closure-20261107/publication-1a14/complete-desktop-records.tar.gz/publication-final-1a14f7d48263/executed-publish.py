import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
import traceback

PUB = Path('/home/qian-qi/work/chain-qrom-closure-publish-20261107')
NATIVE = Path('/home/qian-qi/work/chain-qrom-local-20261107-7150')
OUT = Path('/home/qian-qi/work/chain-qrom-closure-20261107-evidence/publication-final-1a14f7d48263')
BUNDLE = OUT.parent / 'W1_QROM_closure_1a14f7d48263.bundle'
BASE = '7150d96a2112875b4afcf3023361a5cef4a0e4b1'
HEAD = '1a14f7d4826363daefac9ec10131c66d7e70ece7'
TREE = 'e08b5dcd9ae2e90d0a36cb5d85e6ce1def387e85'
PARENT = '5c3a3c5b54f43dd1c2005c2eb744e9bcbeba6794'
BRANCH = 'fix/chain-w1-qrom-implementation-map-20261107'
TEMP_REF = 'refs/heads/w1-qrom-publish-import-1a14f7d48263'
REPO = 'TrillionniumFoundation/Trillionnium-Chain'
ORIGINS = {'https://github.com/' + REPO, 'https://github.com/' + REPO + '.git',
           'git@github.com:' + REPO + '.git'}
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_TERMINAL_PROMPT='0')
records = []
report = {'schema': 'TRNM-W1-NORMAL-PUBLICATION1', 'target_head': HEAD,
          'target_tree': TREE, 'base': BASE, 'branch': BRANCH,
          'publication_checkout': str(PUB), 'native_checkout': str(NATIVE),
          'commands': records, 'push_verified': False,
          'complete_source_worktree_verified': False,
          'post_quantum_soundness_qualified': False, 'production_qualified': False}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def blob_id(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data,
                        usedforsecurity=False).hexdigest()


def save_report():
    (OUT / 'publication-report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')


def run(label, argv, cwd=PUB, timeout=180, check=True, data=None):
    began = time.monotonic()
    completed = subprocess.run(argv, cwd=cwd, env=ENV, input=data,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    (OUT / (label + '.stdout.log')).write_bytes(completed.stdout)
    (OUT / (label + '.stderr.log')).write_bytes(completed.stderr)
    records.append({'label': label, 'argv': argv, 'cwd': str(cwd),
                    'exit_code': completed.returncode, 'seconds': time.monotonic() - began,
                    'stdout_bytes': len(completed.stdout), 'stderr_bytes': len(completed.stderr),
                    'stdout_sha256': sha256(completed.stdout), 'stderr_sha256': sha256(completed.stderr)})
    print(json.dumps({'stage': label, 'exit_code': completed.returncode}), flush=True)
    save_report()
    if check:
        require(completed.returncode == 0, label + ' failed; retained exact stdout/stderr')
    return completed


def git(*args, cwd=PUB):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=cwd, env=ENV).decode().strip()


def read_entry(path, mode):
    if mode == '120000':
        require(path.is_symlink(), 'expected tracked symlink: ' + str(path))
        return os.fsencode(os.readlink(path))
    require(path.is_file() and not path.is_symlink(), 'expected regular source file: ' + str(path))
    return path.read_bytes()


def safe_parent(path):
    relative = path.relative_to(PUB)
    require(all(part not in ('', '.', '..', '.git') for part in relative.parts), 'noncanonical selected path')
    current = PUB
    for part in relative.parts[:-1]:
        current = current / part
        require(not current.is_symlink(), 'selected ancestor is a symlink')
        current.mkdir(exist_ok=True)


def materialize(name, entry):
    mode, object_id = entry
    destination = PUB / name
    try:
        existing = read_entry(destination, mode)
    except (FileNotFoundError, RuntimeError):
        existing = None
    if existing is not None and blob_id(existing) == object_id:
        data, provider = existing, 'existing-matching-publication-file'
    else:
        fetched = subprocess.run(['git', '--no-replace-objects', 'cat-file', 'blob', object_id],
                                 cwd=PUB, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if fetched.returncode == 0:
            data, provider = fetched.stdout, 'target-git-object'
        else:
            # A read-only source of exact old bytes, never a mutation of NATIVE.
            data, provider = read_entry(NATIVE / name, mode), 'read-only-frozen-native-file'
            require(blob_id(data) == object_id, 'native fallback differs from target blob: ' + name)
            installed = subprocess.run(['git', 'hash-object', '-w', '--stdin'], cwd=PUB, env=ENV,
                                       input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            require(installed.returncode == 0 and installed.stdout.decode().strip() == object_id,
                    'could not install verified missing blob in publication clone')
        require(blob_id(data) == object_id, 'selected bytes do not match target Git blob: ' + name)
        safe_parent(destination)
        if mode == '120000':
            if destination.exists() or destination.is_symlink():
                require(not destination.is_dir(), 'refuse directory replacement')
                destination.unlink()
            os.symlink(os.fsdecode(data), destination)
        else:
            require(not destination.is_symlink(), 'refuse tracked regular destination symlink')
            flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW
            with os.fdopen(os.open(destination, flags, 0o755 if mode == '100755' else 0o644), 'wb') as stream:
                stream.write(data)
            destination.chmod(0o755 if mode == '100755' else 0o644)
    require(blob_id(read_entry(destination, mode)) == object_id, 'selected materialization readback: ' + name)
    if mode != '120000':
        require(bool(destination.stat().st_mode & 0o111) == (mode == '100755'), 'selected executable mode: ' + name)
    return {'path': name, 'git_blob': object_id, 'bytes': len(data), 'sha256': sha256(data), 'provider': provider}


def main():
    payload = json.load(sys.stdin)
    manifest_raw = payload['input_manifest_json'].encode()
    require(sha256(manifest_raw) == 'e5c0874ef830306650c3e05beecd0686b2c487ba87cc0ecc5cf7b88d624983dd',
            'cloud selected manifest digest')
    manifest = json.loads(manifest_raw)
    require((manifest['base'], manifest['head'], manifest['tree']) == (BASE, HEAD, TREE), 'input target identity')
    require(len(manifest['changed_paths']) == 94, '94 changed paths required')
    require(PUB.resolve(strict=True) == PUB and NATIVE.resolve(strict=True) == NATIVE and PUB != NATIVE,
            'publication/native directories are not separate canonical directories')
    require(git('rev-parse', 'HEAD') == BASE, 'initial publication HEAD is not frozen base')
    require(git('branch', '--show-current') == BRANCH, 'initial publication branch differs')
    require(git('remote', 'get-url', 'origin') in ORIGINS, 'noncanonical publication origin')
    require(git('rev-parse', 'HEAD', cwd=NATIVE) == BASE, 'native frozen HEAD differs')
    OUT.mkdir(exist_ok=False)
    (OUT / 'input-manifest.json').write_bytes(manifest_raw)
    (OUT / 'executed-publish.py').write_text(payload['driver_source'])
    report['driver_sha256'] = sha256(payload['driver_source'].encode())
    raw = BUNDLE.read_bytes()
    require(len(raw) == 4778605 and sha256(raw) == '9aa10404c58ba6e053dec7e7724a92861c033e05518c896d82b00a4a3a2f8085',
            'published bundle full size/digest mismatch')
    report['bundle'] = {'path': str(BUNDLE), 'bytes': len(raw), 'sha256': sha256(raw)}
    run('bundle-verify', ['git', 'bundle', 'verify', str(BUNDLE)])
    advertised = run('bundle-heads', ['git', 'bundle', 'list-heads', str(BUNDLE)]).stdout.decode().splitlines()
    require(advertised == [HEAD + ' HEAD'], 'unexpected bundle advertised head')
    run('fetch-bundle', ['git', 'fetch', '--no-tags', str(BUNDLE), 'HEAD:' + TEMP_REF])
    require(git('rev-parse', TEMP_REF) == HEAD and git('rev-parse', TEMP_REF + '^{tree}') == TREE
            and git('rev-parse', TEMP_REF + '^') == PARENT, 'fetched target/head/tree/parent differs')
    run('base-ancestor', ['git', 'merge-base', '--is-ancestor', BASE, HEAD])
    first = run('checkout-complete-attempt', ['git', '-c', 'core.hooksPath=.githooks',
                'checkout', '-B', BRANCH, TEMP_REF], check=False)
    report['complete_checkout_attempt_exit'] = first.returncode
    if first.returncode != 0:
        # Retain the failure, then select the known fast-forward commit without
        # pretending unavailable historical evidence bodies are materialized.
        run('select-reviewed-index', ['git', 'reset', '--mixed', HEAD])
    require(git('rev-parse', 'HEAD') == HEAD and git('branch', '--show-current') == BRANCH,
            'reviewed branch was not selected')
    entries = {}
    tree_bytes = subprocess.check_output(['git', 'ls-tree', '-r', '-z', HEAD], cwd=PUB, env=ENV)
    for item in tree_bytes.split(b'\0'):
        if not item:
            continue
        metadata, path = item.split(b'\t', 1)
        mode, kind, object_id = metadata.decode().split()
        require(kind == 'blob' and mode in ('100644', '100755', '120000'), 'unsupported tracked source type')
        entries[path.decode()] = (mode, object_id)
    changed = {row['path']: row for row in manifest['changed_paths']}
    selected = {name for name in entries if not name.startswith('evidence/')} | set(changed) | set(manifest['required_old_evidence'])
    require(selected <= set(entries), 'selected input is not in the target tree')
    selected_rows = [materialize(name, entries[name]) for name in sorted(selected)]
    observed = {row['path']: row for row in selected_rows}
    for name, expected in changed.items():
        require(all(observed[name][key] == expected[key] for key in ('bytes', 'sha256', 'git_blob')),
                'cloud/desktop changed path identity differs: ' + name)
    (OUT / 'selected-source-manifest.json').write_text(json.dumps(selected_rows, indent=2, sort_keys=True) + '\n')
    report['selected_source'] = {'count': len(selected_rows), 'bytes': sum(row['bytes'] for row in selected_rows),
                               'changed_paths_checked': len(changed), 'full_source_claim': False}
    run('checkout-selected-branch', ['git', '-c', 'core.hooksPath=.githooks', 'checkout', BRANCH])
    run('preflight-dev', ['bash', 'scripts/project-preflight.sh', '--dev'])
    run('preflight-audit', ['bash', 'scripts/project-preflight.sh', '--audit'])
    run('generated-inventory-check', ['python3', 'scripts/refresh_distributed_source_inventory.py', '--check'])
    status = run('actual-worktree-status', ['git', 'status', '--porcelain=v1', '-z', '--untracked-files=all']).stdout
    missing = []
    for item in status.split(b'\0'):
        if not item:
            continue
        require(item[:3] == b' D ', 'unexpected index/worktree status in publication clone')
        name = item[3:].decode()
        require(name.startswith('evidence/') and name not in selected, 'unexpected selected-source deletion')
        missing.append(name)
    (OUT / 'missing-historical-evidence.json').write_text(json.dumps(missing, indent=2) + '\n')
    report['missing_historical_evidence_count'] = len(missing)
    complete = run('complete-source-check', ['python3', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                   '--expected-head', HEAD, '--output', str(OUT / 'complete-source.json')], check=False)
    report['complete_source_worktree_verified'] = complete.returncode == 0
    if complete.returncode:
        require(missing and b'source is not clean' in complete.stderr,
                'complete source failed for a reason other than recorded missing historical evidence')
    else:
        require(not missing, 'successful complete source has missing history')
    for name, expected in changed.items():
        data = read_entry(PUB / name, entries[name][0])
        require(sha256(data) == expected['sha256'] and blob_id(data) == expected['git_blob'],
                'changed source drift before push: ' + name)
    require(git('rev-parse', 'HEAD') == HEAD and git('rev-parse', 'HEAD^{tree}') == TREE,
            'source moved before push')
    require(git('rev-parse', 'HEAD', cwd=NATIVE) == BASE, 'native frozen HEAD moved')
    run('normal-hook-push', ['git', '-c', 'core.hooksPath=.githooks', 'push', 'origin',
                           'HEAD:refs/heads/' + BRANCH], timeout=360)
    remote = run('remote-head-readback', ['git', 'ls-remote', '--heads', 'origin', 'refs/heads/' + BRANCH], timeout=180)
    require(remote.stdout.decode().strip().split() == [HEAD, 'refs/heads/' + BRANCH], 'remote head differs after push')
    report['push_verified'] = True
    report['remote_head'] = HEAD
    save_report()
    print(json.dumps({'push_verified': True, 'remote_head': HEAD, 'tree': TREE,
                      'complete_source_worktree_verified': report['complete_source_worktree_verified'],
                      'missing_historical_evidence_count': len(missing)}), flush=True)
    pr = run('pr-identity-before-body', ['gh', 'pr', 'view', '778', '--repo', REPO, '--json',
             'number,baseRefName,headRefName,headRefOid,isDraft,url'], timeout=180)
    pr_value = json.loads(pr.stdout)
    require(pr_value['headRefOid'] == HEAD and pr_value['headRefName'] == BRANCH and pr_value['isDraft'] is True,
            'PR head/branch/draft identity differs')
    report['pr_before_body'] = pr_value
    runs = run('workflow-runs-after-push', ['gh', 'run', 'list', '--repo', REPO, '--branch', BRANCH,
               '--commit', HEAD, '--limit', '30', '--json', 'databaseId,workflowName,status,conclusion,headSha,url,event'], timeout=180)
    report['workflow_runs_after_push'] = json.loads(runs.stdout)
    require(all(row['headSha'] == HEAD for row in report['workflow_runs_after_push']), 'foreign workflow source')
    save_report()
    print(json.dumps({'publication_report': str(OUT / 'publication-report.json'),
                      'workflow_runs': report['workflow_runs_after_push']}), flush=True)


try:
    main()
except BaseException as error:
    report['error'] = type(error).__name__ + ': ' + str(error)
    if OUT.is_dir():
        save_report()
        (OUT / 'failure-traceback.log').write_text(traceback.format_exc())
    raise
