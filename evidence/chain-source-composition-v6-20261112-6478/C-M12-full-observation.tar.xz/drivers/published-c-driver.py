import hashlib,json,os,pathlib,re,shutil,subprocess,sys,tarfile,time,traceback
source=sys.argv[1]
if not re.fullmatch(r"[0-9a-f]{40}",source):raise SystemExit("exact commit required")
base=pathlib.Path("/home/qian-qi/work/chain-pq-boundary-closure-20261112-4150")
repo=pathlib.Path("/home/qian-qi/work/chain-m12-runtime-c-20261112-6478")
obs=pathlib.Path("/home/qian-qi/work/chain-m12-runtime-c-20261112-6478-observations")
target=pathlib.Path("/home/qian-qi/work/chain-m12-runtime-c-20261112-6478-target")
receipt={"schema":"chain-m12-native-remote-v1","expected_source":source,"qualification":False,"started_unix":time.time(),"commands":[],"original_failure_preserved":"runtime-A cloud settlement 78 passed, 1 Unix socket EPERM"}
def run(argv,cwd=None):
 r=subprocess.run(argv,cwd=cwd,text=True,capture_output=True)
 row={"argv":argv,"cwd":str(cwd) if cwd else None,"exit_code":r.returncode,"stdout":r.stdout,"stderr":r.stderr}
 receipt["commands"].append(row)
 print(json.dumps(row),flush=True)
 if r.returncode:raise RuntimeError("command failed: "+argv[0])
 return r.stdout
def identity(label):
 actual=run(["git","rev-parse","HEAD"],repo).strip()
 tree=run(["git","rev-parse","HEAD^{tree}"],repo).strip()
 status=run(["git","status","--porcelain=v1"],repo)
 rows=subprocess.run(["git","ls-tree","-r","-z","HEAD"],cwd=repo,check=True,capture_output=True).stdout
 manifest={}
 mismatches=[]
 for row in rows.split(b"\0"):
  if not row:continue
  head,path=row.split(b"\t",1);mode,kind,sha=head.split(b" ")
  if kind!=b"blob":raise RuntimeError("non-blob tracked entry")
  p=repo/os.fsdecode(path)
  data=os.fsencode(os.readlink(p)) if mode==b"120000" else p.read_bytes()
  physical_blob=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
  if physical_blob!=sha.decode():mismatches.append(os.fsdecode(path))
  manifest[os.fsdecode(path)]={"git_blob":sha.decode(),"physical_blob":physical_blob,"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data)}
 file=obs/(label+".physical-sources.json")
 file.write_text(json.dumps(manifest,sort_keys=True,indent=2)+"\n")
 result={"source":actual,"tree":tree,"git_status":status,"tracked_files":len(manifest),"mismatches":mismatches,"physical_manifest_sha256":hashlib.sha256(file.read_bytes()).hexdigest()}
 receipt[label]=result
 if actual!=source or status or mismatches:raise RuntimeError("source identity mismatch")
 return manifest
try:
 if repo.exists() or obs.exists() or target.exists():raise RuntimeError("isolated C paths must be absent")
 obs.mkdir()
 receipt["driver_sha256"]=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
 receipt["free_before_bytes"]=shutil.disk_usage(repo.parent).free
 run(["git","clone","--local","--no-checkout",str(base),str(repo)])
 run(["git","remote","set-url","origin","https://github.com/TrillionniumFoundation/Trillionnium-Chain.git"],repo)
 run(["git","fetch","--no-tags","origin",source],repo)
 run(["git","checkout","--detach",source],repo)
 before=identity("before")
 (obs/"AGENTS.reviewed.txt").write_bytes((repo/"AGENTS.md").read_bytes())
 env=dict(os.environ)
 removed={k:env.pop(k) for k in list(env) if k.startswith("CARGO_PROFILE_")}
 for k in ["RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS"]:
  if k in env:removed[k]=env.pop(k)
 env["PATH"]="/home/qian-qi/.cargo/bin:"+env.get("PATH","")
 env["CARGO_TARGET_DIR"]=str(target)
 env["CARGO_BUILD_JOBS"]="2"
 env["CARGO_INCREMENTAL"]="0"
 env["RUST_TEST_THREADS"]="1"
 receipt["environment"]={k:env[k] for k in ["CARGO_TARGET_DIR","CARGO_BUILD_JOBS","CARGO_INCREMENTAL","RUST_TEST_THREADS"]}
 receipt["removed_compilation_override_keys"]=sorted(removed)
 receipt["rustc"]=run(["/home/qian-qi/.cargo/bin/rustup","run","1.95.0","rustc","-vV"],repo)
 receipt["cargo"]=run(["/home/qian-qi/.cargo/bin/rustup","run","1.95.0","cargo","-vV"],repo)
 receipt["uname"]=list(os.uname())
 with (obs/"preflight.stdout.log").open("wb") as out,(obs/"preflight.stderr.log").open("wb") as err:
  result=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=repo,env=env,stdout=out,stderr=err)
 receipt["preflight_exit_code"]=result.returncode
 print(json.dumps({"preflight_exit_code":result.returncode}),flush=True)
 if result.returncode:raise RuntimeError("preflight failed")
 receipt["preflight_source_unchanged"]=(identity("after-preflight")==before)
 if not receipt["preflight_source_unchanged"]:raise RuntimeError("preflight changed physical source")
 command=["/home/qian-qi/.cargo/bin/rustup","run","1.95.0","cargo","test","--locked","--manifest-path","trillionnium/Cargo.toml","-p","trnm-service-settlement","--lib","--","--nocapture","--test-threads=1"]
 receipt["native_command"]=command
 receipt["native_started_unix"]=time.time()
 print(json.dumps({"phase":"native-started","command":command,"source":source}),flush=True)
 with (obs/"settlement-79.stdout.log").open("wb") as out,(obs/"settlement-79.stderr.log").open("wb") as err:
  result=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=err)
 receipt["native_exit_code"]=result.returncode
 receipt["native_ended_unix"]=time.time()
 receipt["runtime_sources_unchanged"]=(identity("after")==before)
 text=(obs/"settlement-79.stdout.log").read_text(errors="strict")
 summaries=[line for line in text.splitlines() if line.startswith("test result:") or line.startswith("running ")]
 receipt["native_summaries"]=summaries
 receipt["complete_79_pass"]=result.returncode==0 and "running 79 tests" in summaries and any(re.fullmatch(r"test result: ok\. 79 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in .+",line) for line in summaries)
 receipt["qualification"]=receipt["complete_79_pass"] and receipt["runtime_sources_unchanged"]
 receipt["exit_code"]=0 if receipt["qualification"] else 1
except BaseException as e:
 receipt["exit_code"]=1;receipt["error"]=str(e);receipt["traceback"]=traceback.format_exc()
 print(receipt["traceback"],file=sys.stderr,flush=True)
finally:
 receipt["ended_unix"]=time.time()
 receipt["free_after_bytes"]=shutil.disk_usage(repo.parent).free
 if obs.exists():
  receipt["files"]={p.name:{"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(obs.iterdir()) if p.is_file() and p.name!="settlement-79.receipt.json"}
  (obs/"settlement-79.receipt.json").write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
  archive=pathlib.Path(str(obs)+".tar.gz")
  with tarfile.open(archive,"w:gz") as tar:
   for p in sorted(obs.iterdir()):tar.add(p,arcname=p.name,recursive=False)
  print(json.dumps({"receipt":str(obs/"settlement-79.receipt.json"),"archive":str(archive),"archive_bytes":archive.stat().st_size,"archive_sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"qualification":receipt["qualification"],"native_summaries":receipt.get("native_summaries"),"exit_code":receipt.get("exit_code")}),flush=True)
 else:print(json.dumps(receipt),flush=True)
sys.exit(receipt["exit_code"])
