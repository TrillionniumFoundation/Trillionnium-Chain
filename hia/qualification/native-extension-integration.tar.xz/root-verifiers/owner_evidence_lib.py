"""Retain actual observations and verify every byte of the resulting archives."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import lzma
import tarfile

BASE = Path('/workspace/scratch/a638c5cc4765')
ROOT = BASE / 'Trillionnium-Chain'
FINAL = BASE / 'owner-extension-final-v2'
FAILED = BASE / 'owner-extension-final'

def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()

def safe(name):
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and str(path) == name and '\\' not in name

class Package:
    def __init__(self, label):
        self.label = label
        self.entries = {}
    def file(self, name, path):
        safe(name)
        assert name not in self.entries and path.is_file() and not path.is_symlink(), (name, path)
        data = path.read_bytes()
        self.entries[name] = {'path': path, 'mode': 0o755 if path.stat().st_mode & 0o111 else 0o644, **identity(data)}
    def data(self, name, data):
        safe(name)
        assert name not in self.entries
        self.entries[name] = {'data': data, 'mode': 0o644, **identity(data)}
    def directory(self, prefix, directory, excluded=()):
        assert directory.is_dir() and not directory.is_symlink()
        count = size = 0
        for path in sorted(directory.rglob('*')):
            relative = path.relative_to(directory)
            if any(part in excluded for part in relative.parts):
                continue
            assert not path.is_symlink(), path
            if path.is_file():
                self.file(prefix + '/' + relative.as_posix(), path)
                count += 1
                size += path.stat().st_size
            else:
                assert path.is_dir(), path
        return {'files': count, 'bytes': size}
    def snapshot(self, prefix, source_map, root, overrides=None):
        overrides = overrides or {}
        for name, info in source_map.items():
            path = overrides.get(name, root / name)
            data = path.read_bytes()
            assert identity(data) == info, (prefix, name)
            self.data(prefix + '/' + name, data)
    def finish(self, metadata, archive_filename=None):
        self.data('PACKAGE.json', encoded(metadata))
        manifest = {'schema': 'trnm.hia.evidence-member-manifest.v1',
            'manifest_not_self_hashed': True,
            'payload_member_count': len(self.entries),
            'payload_total_bytes': sum(row['bytes'] for row in self.entries.values()),
            'members': [{'path': name, 'size': row['bytes'], 'sha256': row['sha256'], 'mode': row['mode']}
                for name, row in sorted(self.entries.items())]}
        manifest_raw = encoded(manifest)
        archive_path = ROOT / 'hia/qualification' / (archive_filename or self.label + '-development.tar.xz')
        assert not archive_path.exists()
        with archive_path.open('xb') as output:
            with tarfile.open(fileobj=output, mode='w:xz', format=tarfile.USTAR_FORMAT, preset=6) as archive:
                for name, row in sorted(self.entries.items()):
                    data = row.get('data') if 'data' in row else row['path'].read_bytes()
                    assert identity(data) == {'bytes': row['bytes'], 'sha256': row['sha256']}, name
                    info = tarfile.TarInfo(name)
                    info.size = len(data); info.mode = row['mode']; info.mtime = 0
                    archive.addfile(info, io.BytesIO(data))
                info = tarfile.TarInfo('MANIFEST.json')
                info.size = len(manifest_raw); info.mode = 0o644; info.mtime = 0
                archive.addfile(info, io.BytesIO(manifest_raw))
        compressed = archive_path.read_bytes()
        decoder = lzma.LZMADecompressor()
        plain = decoder.decompress(compressed)
        assert decoder.eof and not decoder.unused_data
        seen = set(); last_end = 0
        with tarfile.open(fileobj=io.BytesIO(plain), mode='r:') as archive:
            for member in archive:
                safe(member.name)
                assert member.isfile() and member.name not in seen
                seen.add(member.name)
                data = archive.extractfile(member).read()
                assert len(data) == member.size
                if member.name == 'MANIFEST.json':
                    assert data == manifest_raw
                else:
                    row = self.entries[member.name]
                    assert identity(data) == {'bytes': row['bytes'], 'sha256': row['sha256']}, member.name
                    assert member.mode == row['mode']
                last_end = member.offset_data + ((member.size + 511) // 512) * 512
        assert seen == set(self.entries) | {'MANIFEST.json'}
        assert len(plain) - last_end >= 1024 and not any(plain[last_end:])
        for name, row in self.entries.items():
            if 'path' in row:
                assert identity(row['path'].read_bytes()) == {'bytes': row['bytes'], 'sha256': row['sha256']}, name
        result = {'schema': 'trnm.hia.owner-extension-archive-readback.v1', 'result': 'PASS',
            'path': str(archive_path.relative_to(ROOT)), **identity(compressed),
            'regular_members': len(seen), 'logical_bytes': manifest['payload_total_bytes'] + len(manifest_raw),
            'manifest': identity(manifest_raw), 'single_xz_stream': True, 'complete_zero_tar_tail': True,
            'every_regular_member_rehashed': True, 'original_observations_unchanged': True,
            'runtime_reexecuted_by_packager': False}
        (BASE / (self.label + '-archive-readback.json')).write_bytes(encoded(result))
        print(json.dumps(result), flush=True)

def common(package, label, readback):
    included = {'final': package.directory('final', FINAL / label)}
    for suffix in ('.stdout.raw', '.stderr.raw', '.execution.json'):
        package.file('execution' + suffix, FINAL / (label + suffix))
    for name in ('source-before.json', 'source-after.json'):
        package.file('integration-' + name, FINAL / name)
    package.file('independent-readback.json', BASE / readback)
    included['initial-enospc-failure'] = package.directory('historical/enospc', FAILED / label, excluded=('original-target',))
    for suffix in ('.stdout.raw', '.stderr.raw', '.execution.json'):
        package.file('historical/enospc-execution' + suffix, FAILED / (label + suffix))
    return included
