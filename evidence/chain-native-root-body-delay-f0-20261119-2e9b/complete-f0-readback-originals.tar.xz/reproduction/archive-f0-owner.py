import pathlib,shutil,json,hashlib,time,resource,tarfile,stat,sys
base=pathlib.Path.home()/'work/chain-native-root-delay-f0-20261119-2e9b';out=pathlib.Path.home()/'work/chain-native-root-delay-f0-publication-20261119-2e9b';assert not out.exists();out.mkdir()
assert (base/'automatic-ci-snapshot-1/SNAPSHOT.json').is_file()
readback=json.loads((base/'f0-independent-readback.json').read_text());assert readback['manifest_files_checked']==443 and readback['business_pass'] is False and readback['archive_sha256']=='77cc90508efd6fa36829ce4f89b5d740f25a8bd76f3059ce54ed49743d377c7e'
t=time.monotonic();ru=resource.getrusage(resource.RUSAGE_SELF)
repro=base/'reproduction';repro.mkdir();(repro/'archive-f0-owner.py').write_text(sys.argv[1])
copies={'f0-original.zip':'collection/artifact-14491339657.zip','f0-independent-readback.json':'f0-independent-readback.json','f0-readback.py':'pinned-readback-v2.py','cost-profile.json':'current-cost-profile.json','cost-summary.json':'current-cost-summary.json','provider-run.json':'collection/run.stdout','provider-jobs.json':'collection/jobs.stdout','provider-artifacts.json':'collection/artifacts.stdout','provider-timing.json':'automatic-ci-snapshot-1/44441548029-timing.json','automatic-ci-snapshot.json':'automatic-ci-snapshot-1/SNAPSHOT.json'}
for name,rel in copies.items():shutil.copyfile(base/rel,out/name)
members=[];excluded=[]
for p in sorted(base.rglob('*')):
 if p.is_dir():continue
 st=p.lstat();assert stat.S_ISREG(st.st_mode) and not p.is_symlink()
 rel=str(p.relative_to(base))
 if rel=='collection/artifact-14491339657.zip' or rel.startswith('collection/artifact-14491339657/'):
  excluded.append({'path':rel,'reason':'exact original ZIP published separately; extracted member bytes independently verified against original inventory'})
 else:members.append((p,rel))
inventory=[]
for p,rel in members:
 before=p.stat();raw=p.read_bytes();after=p.stat();assert(before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
 inventory.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
index={'schema':'chain-native-root-delay-f0-complete-local-evidence-index-v1','run_id':44441548029,'frozen_head':'333fe8cd89f0ec855e7b856e99e40f48f56c2137','original_zip':{'file':'f0-original.zip','bytes':17579578,'sha256':readback['archive_sha256'],'original_inventory_members':443},'files':inventory,'duplicate_zip_materialization_represented_by_original_zip':excluded,'all_regular_unique_original_bytes_retained':True,'full_physical_cost_closed':False,'business_pass':False}
(out/'readback-archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
archive=out/'complete-f0-readback-originals.tar.xz'
with tarfile.open(archive,'x:xz',preset=6) as tf:
 for p,rel in members:tf.add(p,arcname=rel,recursive=False)
 tf.add(out/'readback-archive-index.json',arcname='readback-archive-index.json',recursive=False)
with tarfile.open(archive,'r:xz') as tf:
 for row in inventory:
  raw=tf.extractfile(row['path']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
r=resource.getrusage(resource.RUSAGE_SELF)
result={'schema':'chain-native-root-delay-f0-archive-receipt-v1','archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(members)+1},'all_members_readback_verified':True,'original_archive_independently_verified':True,'wall_seconds':time.monotonic()-t,'self_user_cpu_seconds':r.ru_utime-ru.ru_utime,'self_system_cpu_seconds':r.ru_stime-ru.ru_stime,'full_physical_cost_closed':False,'files':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(p.stat().st_size).encode()+b'\0'+p.read_bytes()).hexdigest()} for p in out.iterdir() if p.is_file()}}
(out/'PUBLICATION_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
