#!/usr/bin/env python3
import ctypes,hashlib,json,os,pathlib,stat,time
P=pathlib.Path('/tmp/chain-pq-fa62381e-s3-positive')
N=pathlib.Path('/tmp/chain-pq-fa62381e-s3-negative')
C=pathlib.Path('/tmp/chain-pq-fa62381e-s3-coordination')
S='454ae116159867ff6cddd91b964523df7f7e16f0'
T='3117250c4db0f2ae681d51ed6ee5e6a2fa7555a9'
NS='f7c51532cc6657360b97226d9f396158253cea78'
NT='628f0d54ad9127471cc3902b50b915c4df2dcad7'
PR='effa69e49141bc020bfd0b9861218a7da1729d4811ec7c6003a52c72513ff60b'
NR='58e2fa946a7dc34cf58e8b357e04c2789da98f8b6218768d8e29651c6cf6b6f7'
def sha(b):return hashlib.sha256(b).hexdigest()
def fp(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def raw(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
 try:
  a=os.fstat(fd);assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
  chunks=[]
  while True:
   b=os.read(fd,1048576)
   if not b:break
   chunks.append(b)
  b=b''.join(chunks);assert len(b)==a.st_size and fp(a)==fp(os.fstat(fd))==fp(p.stat(follow_symlinks=False))
  return b
 finally:os.close(fd)
def unique(pairs):
 r={}
 for k,v in pairs:
  assert k not in r,'duplicate JSON key';r[k]=v
 return r
def read(p):
 b=raw(p);return json.loads(b,object_pairs_hook=unique),sha(b)
def elf(p,expected):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  a=os.fstat(fd);assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
  assert os.pread(fd,4,0)==b'\x7fELF'
  h=hashlib.sha256()
  while True:
   b=os.read(fd,1048576)
   if not b:break
   h.update(b)
  assert h.hexdigest()==expected
  assert fp(a)==fp(os.fstat(fd))==fp(pathlib.Path(p).stat(follow_symlinks=False))
  return {'sha256':expected,'bytes':a.st_size,'device':a.st_dev,'inode':a.st_ino}
 finally:os.close(fd)
def verify(out,source,tree,runner,positive=False):
 ready,rpin=read(out/'build-ready.json')
 assert ready['native_tests_started'] is False and ready['runner_sha256']==runner
 if positive:
  assert rpin=='a8af1a70192ef8b03781ce10d7c35cdef2004150e795493c5c3a848f3897bef8'
  assert ready['positive_source']==S and ready['status']=='native-build-complete-awaiting-barrier'
 else:
  assert ready['negative_source']==NS and ready['positive_source']==S
  assert ready['status']=='native-build-complete-awaiting-negative-release'
 receipt,cph=read(out/'commands/node-lib-build.json')
 assert cph==ready['build_receipt_sha256']
 assert receipt['status']=='command_succeeded' and receipt['exit_code']==0
 assert receipt['before']==receipt['after']
 ident=receipt['before']
 assert ident['tested_commit']==source and ident['tested_tree']==tree and ident['tracked_worktree_verified'] is True
 assert receipt['argv']==['cargo','+1.95.0','test','--locked','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib','--all-features','--no-run','--message-format=json']
 artifact,aph=read(out/'native-artifact.json')
 assert aph==ready['native_artifact_sha256'] and artifact['source']==source and artifact['runner_sha256']==runner
 assert artifact['build_receipt_sha256']==cph and artifact['executable_sha256']==ready['executable_sha256']
 cargo=artifact['cargo_artifact'];assert cargo['fresh'] is False and cargo['profile']['test'] is True and cargo['target']['kind']==['lib']
 assert sha(raw(out/'commands/node-lib-build.log'))==receipt['log_sha256']==artifact['build_log_sha256']
 if positive:
  assert cph=='96025722e0048134e52b4ad834692b00ac94629340fcbd5deeb0db219c890c80'
  assert aph=='fd771ceffcda88a5b5424a971b677e4c43b874ff0688729babf834381c3b3bae'
  assert ready['executable_sha256']=='081ee2780e100ac74ee57a934edc5ae83dca0eaac2a3c370eb294ec442efe4ef'
 else:
  assert artifact['positive_source']==S
  assert sha(raw(pathlib.Path('/tmp/chain-pq-negative-source-fa62381e-s3/source-lineage.json')))==artifact['source_lineage_sha256']
 return {'source':source,'tree':tree,'ready_sha256':rpin,'build_receipt_sha256':cph,'artifact_sha256':aph,'elf':elf(artifact['executable'],ready['executable_sha256']),'profile':cargo['profile'],'features':cargo['features']}
def publish(value):
 fd=os.open(C,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 tmp='positive-release.tmp';dest='positive-release.json'
 try:
  f=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600,dir_fd=fd)
  b=(json.dumps(value,sort_keys=True)+'\n').encode()
  with os.fdopen(f,'wb') as stream:stream.write(b);stream.flush();os.fsync(stream.fileno())
  libc=ctypes.CDLL(None,use_errno=True)
  rename=libc.renameat2;rename.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint];rename.restype=ctypes.c_int
  assert time.monotonic_ns()<deadline,'original positive coordination deadline elapsed'
  if rename(fd,tmp.encode(),fd,dest.encode(),1)!=0:raise OSError(ctypes.get_errno(),'atomic no-replace release failed')
  os.fsync(fd);return sha(b)
 finally:os.close(fd)
record={'status':'started','native_tests_executed_by_coordinator':False,'negative_release_written':False,'whole_chain_quantum_security_qualified':False}
result=C/'positive-release-decision.json'
try:
 assert not result.exists() and not (C/'positive-release.json').exists() and not (C/'negative-release.json').exists()
 obs,_=read(P/'build-barrier-observation.json')
 assert obs['status']=='WAITING' and obs['positive_source']==S and obs['timeout_seconds']==1800 and obs['native_tests_started'] is False
 assert obs['started_monotonic_ns']==1487788785063435
 deadline=obs['started_monotonic_ns']+1800*1000000000
 while True:
  if time.monotonic_ns()>=deadline:raise TimeoutError('original positive barrier deadline elapsed; no release')
  try:
   probe,_=read(N/'build-ready.json')
   break
  except (FileNotFoundError,json.JSONDecodeError):time.sleep(0.25)
 p=verify(P,S,T,PR,True);n=verify(N,NS,NT,NR)
 assert p['profile']==n['profile'] and p['features']==n['features']
 assert not (C/'negative-release.json').exists()
 release={'status':'all-native-builds-complete','positive_source':S,'negative_source':NS,'positive_build_receipt_sha256':p['build_receipt_sha256'],'negative_build_receipt_sha256':n['build_receipt_sha256'],'positive_elf_sha256':p['elf']['sha256'],'negative_elf_sha256':n['elf']['sha256']}
 record.update(positive=p,negative=n,original_positive_deadline_monotonic_ns=deadline)
 record['release_sha256']=publish(release)
 record.update(status='positive-release-published',released_monotonic_ns=time.monotonic_ns())
except BaseException as e:
 record.update(status='refused',error=repr(e));raise
finally:
 with result.open('x') as f:json.dump(record,f,indent=2,sort_keys=True);f.write('\n')
 print(json.dumps(record,sort_keys=True),flush=True)
