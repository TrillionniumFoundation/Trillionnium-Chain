"""Historical reader reproduction. No native or original program executes."""
from pathlib import Path
import copy,hashlib,json,os,shutil,subprocess,sys,time
BASE=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh")
OLD=BASE/"repo"
CURRENT=Path("/tmp/trnm-root-20261118-77a88234/repo")
SOURCE=BASE/"node-work-integration-v1/focused-controls-v1/node-smoke"
OUT=Path("/tmp/trnm-root-20261118-77a88234/scope-report-mutation-reproduction-v1")
OUT.mkdir(mode=0o700)
sys.path.insert(0,str(CURRENT))
from hia.platform.mempool_node.evidence import native_report_contract
def identity(raw):
 return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def write(path,value):
 path.write_text(json.dumps(value,sort_keys=True,indent=2)+"\n")
native_raw=(SOURCE/"native/report.json").read_bytes()
outer_raw=(SOURCE/"report.json").read_bytes()
build_raw=(SOURCE/"build/build.json").read_bytes()
original_native=json.loads(native_raw)
original_outer=json.loads(outer_raw)
built=json.loads(build_raw)
source_identity={str(p.relative_to(SOURCE)):identity(p.read_bytes()) for p in (SOURCE/"native/report.json",SOURCE/"report.json",SOURCE/"build/build.json")}
copy_root=OUT/"copied-smoke"
shutil.copytree(SOURCE,copy_root,symlinks=True)
rows=[]
mutations=(
 ("baseline",None),
 ("wrong-schema",lambda value:value.update(schema="trnm.complete-node-production.v1")),
 ("granted-node-commit",lambda value:value["scope"].update(node_commit=True)),
 ("extra-complete-node",lambda value:value["scope"].update(complete_node=True)),
 ("extra-top-production-permit",lambda value:value.update(production_permit=True)),
)
for name,mutation in mutations:
 native=copy.deepcopy(original_native);outer=copy.deepcopy(original_outer)
 if mutation is not None:mutation(native)
 write(copy_root/"native/report.json",native)
 outer["native_report"]=identity((copy_root/"native/report.json").read_bytes())
 write(copy_root/"report.json",outer)
 patch_report=OUT/(name+".native-report.json")
 patch_outer=OUT/(name+".outer-report.json")
 shutil.copyfile(copy_root/"native/report.json",patch_report)
 shutil.copyfile(copy_root/"report.json",patch_outer)
 command=[sys.executable,"-B","-m","hia.tools.qualify_node_pool_ci","validate","--kind","smoke","--smoke",str(copy_root),"--report",str(OUT/(name+".old-reader.json"))]
 started=time.monotonic_ns()
 run=subprocess.run(command,cwd=OLD,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 elapsed=time.monotonic_ns()-started
 (OUT/(name+".stdout.raw")).write_bytes(run.stdout)
 (OUT/(name+".stderr.raw")).write_bytes(run.stderr)
 rejected=None;message=None
 try:
  native_report_contract(native,"smoke")
  rejected=False
 except ValueError as exc:
  rejected=True;message=str(exc)
 row={"name":name,"old_reader_exit":run.returncode,"old_reader_report":str(OUT/(name+".old-reader.json")),
      "current_contract_only_rejected":rejected,"current_contract_only_error":message,
      "native_report":identity(patch_report.read_bytes()),"outer_report":identity(patch_outer.read_bytes()),
      "stdout":identity(run.stdout),"stderr":identity(run.stderr),"elapsed_ns":elapsed,"command":command}
 rows.append(row)
 write(OUT/"progress.json",{"observations":rows,"native_execution":False,"original_execution":False})
 print(json.dumps({"name":name,"old_reader_exit":run.returncode,"current_contract_only_rejected":rejected}),flush=True)
 if run.returncode!=0:
  raise RuntimeError("Historical baseline or mutation did not reach successful complete reader: "+name)
 if rejected != (mutation is not None):
  raise RuntimeError("Current schema/scope contract result differs: "+name)
for name,expected in source_identity.items():
 if identity((SOURCE/name).read_bytes())!=expected:raise RuntimeError("Historical artifact was changed")
# Restore copied artifact to its original bytes, retaining each exact mutation separately.
(copy_root/"native/report.json").write_bytes(native_raw)
(copy_root/"report.json").write_bytes(outer_raw)
write(OUT/"report.json",{
 "schema":"trnm.native-report-mutation-reproduction.v1","status":"PASS",
 "finding":"Historical full public reader accepted four schema/scope corruptions after the outer checksum was rebound.",
 "historical_source_set_sha256":built["source_set_sha256"],"historical_artifact":str(SOURCE),
 "historical_artifact_unchanged":True,"historical_report_identities":source_identity,
 "current_contract_source":str(CURRENT/"hia/platform/mempool_node/evidence.py"),
 "current_contract_source_identity":identity((CURRENT/"hia/platform/mempool_node/evidence.py").read_bytes()),
 "current_validation_scope":"schema/scope contract only; not full current-source artifact acceptance",
 "native_execution":False,"original_execution":False,"observations":rows,
})
