//! Header: `pthread.h`
//!
//! * Headers: <https://git.musl-libc.org/cgit/musl/blob/include/pthread.h> (official)
//! * Headers: <https://github.com/kraj/musl/blob/master/include/pthread.h> (mirror)

pub use crate::new::common::linux_like::pthread::{
    pthread_getaffinity_np,
    pthread_getattr_np,
    pthread_getname_np,
    pthread_setaffinity_np,
    pthread_setname_np,
};
pub use crate::new::common::posix::pthread::{
    pthread_atfork,
    pthread_attr_getguardsize,
    pthread_attr_getinheritsched,
    pthread_attr_getschedparam,
    pthread_attr_getschedpolicy,
    pthread_attr_getstack,
    pthread_attr_setguardsize,
    pthread_attr_setinheritsched,
    pthread_attr_setschedparam,
    pthread_attr_setschedpolicy,
    pthread_attr_setstack,
    pthread_barrier_destroy,
    pthread_barrier_init,
    pthread_barrier_wait,
    pthread_barrierattr_destroy,
    pthread_barrierattr_getpshared,
    pthread_barrierattr_init,
    pthread_barrierattr_setpshared,
    pthread_condattr_getclock,
    pthread_condattr_getpshared,
    pthread_condattr_setclock,
    pthread_condattr_setpshared,
    pthread_create,
    pthread_getcpuclockid,
    pthread_getschedparam,
    pthread_kill,
    pthread_mutex_timedlock,
    pthread_mutexattr_getprotocol,
    pthread_mutexattr_getpshared,
    pthread_mutexattr_setprotocol,
    pthread_mutexattr_setpshared,
    pthread_once,
    pthread_rwlockattr_getpshared,
    pthread_rwlockattr_setpshared,
    pthread_setschedparam,
    pthread_setschedprio,
    pthread_sigmask,
    pthread_spin_destroy,
    pthread_spin_init,
    pthread_spin_lock,
    pthread_spin_trylock,
    pthread_spin_unlock,
};
#[cfg(not(target_env = "ohos"))]
pub use crate::new::common::posix::pthread::{
    pthread_cancel,
    pthread_mutex_consistent,
    pthread_mutexattr_getrobust,
    pthread_mutexattr_setrobust,
};
