import os,signal,time
from pathlib import Path
signal.signal(signal.SIGTERM,signal.SIG_IGN)
if os.fork(): os._exit(0)
os.setsid()
if os.fork(): os._exit(0)
os.setsid()
Path('/workspace/scratch/ec265b67753e/collector-controls-local-03/test_actual_cancel_reaps_detached_ignoring_descendant/running').write_text(str(os.getpid()))
time.sleep(3)
