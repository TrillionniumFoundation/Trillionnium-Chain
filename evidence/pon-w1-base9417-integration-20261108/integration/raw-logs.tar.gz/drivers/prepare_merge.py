#!/usr/bin/env python3
"""Fixed C8 integration preparation; preserves both source parents and conflicts."""
from pathlib import Path
import hashlib,json,subprocess

OLD=Path('/home/qian-qi/work/chain-w1-base96-integration-20261108-ec265b')
NEW=Path('/home/qian-qi/work/chain-w1-base9417-integration-20261108-ec265b')
OUT=Path('/home/qian-qi/work/chain-w1-base9417-adversarial-integration-20261108-ec265b-01')
BRANCH='fix/chain-w1-base9417-integration-20261108-ec265b'
C7='40a3a45d6b8afc5c4706c5235fec47634f4aabbe'
BASE='9417e495165865ef6c1288b39084856e31020634'
PREV='91c1b7da0f0b1f41c088d9ac0b2ee160b550b80c'
OUT.mkdir()
rows=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,b):
    with p.open('xb') as f:f.write(b)
def dump(v):return (json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def run(label,argv,cwd=OLD,expected=0):
    result=subprocess.run(argv,cwd=cwd,capture_output=True)
    write(OUT/(label+'.stdout'),result.stdout)
    write(OUT/(label+'.stderr'),result.stderr)
    rows.append({'label':label,'argv':argv,'cwd':str(cwd),'exit':result.returncode,
        'stdout_bytes':len(result.stdout),'stdout_sha256':sha(result.stdout),
        'stderr_bytes':len(result.stderr),'stderr_sha256':sha(result.stderr)})
    print(json.dumps(rows[-1]),flush=True)
    assert result.returncode==expected,(label,result.returncode,result.stderr.decode(errors='replace'))
    return result.stdout
complete=False
try:
    run('00-original-preflight',['bash','scripts/project-preflight.sh'])
    assert run('01-original-head',['git','rev-parse','HEAD']).decode().strip()==C7
    assert run('02-original-clean',['git','status','--porcelain','--untracked-files=all'])==b''
    info=run('03-fixed-base-identity',['git','show','-s','--format=%H%n%T%n%P%n%s',BASE]).decode().splitlines()
    assert info[0]==BASE and info[2]==PREV
    run('04-base96-to-fixed-log',['git','log','--reverse','--format=%H %P %s','96a241bf43f6a46d35dfb3d4ced9594ed8ceca75..'+BASE])
    run('05-parent-delta-name-status',['git','diff','--name-status',PREV,BASE])
    run('06-parent-delta-stat',['git','diff','--stat',PREV,BASE])
    run('07-parent-delta-patch',['git','diff','--binary',PREV,BASE])
    run('08-base96-ancestry',['git','merge-base','--is-ancestor','96a241bf43f6a46d35dfb3d4ced9594ed8ceca75',BASE])
    assert run('09-new-branch-absent',['git','for-each-ref','--format=%(refname)','refs/heads/'+BRANCH])==b''
    assert not NEW.exists()
    run('10-create-worktree',['git','worktree','add','-b',BRANCH,str(NEW),C7])
    run('11-new-worktree-preflight',['bash','scripts/project-preflight.sh'],cwd=NEW)
    run('12-normal-merge',['git','merge','--no-commit','--no-ff',BASE],cwd=NEW,expected=1)
    conflict=run('13-conflict-paths',['git','diff','--name-only','--diff-filter=U'],cwd=NEW).decode().splitlines()
    assert set(conflict)=={'.github/workflows/pon-recent-batch-acceptance.yml','config/pon/pq-cross-branch-corpus-v1.json'},conflict
    run('14-index-unmerged-stages',['git','ls-files','-u'],cwd=NEW)
    run('15-conflict-diff',['git','diff','--cc','--',*conflict],cwd=NEW)
    run('16-new-status',['git','status','--porcelain','--untracked-files=all'],cwd=NEW)
    assert run('17-original-head-after',['git','rev-parse','HEAD']).decode().strip()==C7
    assert run('18-original-clean-after',['git','status','--porcelain','--untracked-files=all'])==b''
    assert run('19-new-head',['git','rev-parse','HEAD'],cwd=NEW).decode().strip()==C7
    assert run('20-new-merge-head',['git','rev-parse','MERGE_HEAD'],cwd=NEW).decode().strip()==BASE
    complete=True
finally:
    write(OUT/'commands.json',dump(rows))
    write(OUT/'preparation.json',dump({'schema':'TRNM-W1-C8-FIXED-MERGE-PREPARATION1',
        'source_parent':C7,'fixed_base':BASE,'new_worktree':str(NEW),'branch':BRANCH,
        'commands':rows,'complete':complete,'tests_executed':0,'commits':0,'pushes':0}))
print(json.dumps({'complete':True,'out':str(OUT),'worktree':str(NEW),'manifest_sha256':sha((OUT/'preparation.json').read_bytes())}),flush=True)
