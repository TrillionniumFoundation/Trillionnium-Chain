# Prepared for the root-coordinated post-native copy window; do not launch early.
from pathlib import Path
import ast
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import time


ROOT = Path('/workspace/scratch/9fe375f34217/chain-convergence')
OUT = Path('/workspace/scratch/9fe375f34217/chain_repository_frontdoor/evidence')
TMP = Path('/dev/shm/trnm-chain-repository-50-9fe375f34217')
HEAD = '75dc7ec3973ce3661c27c895418efd5c6cc8b4a8'
TREE = 'a58d215f954c1dee99ab7a031ff496e089499ba0'
TEST_SHA256 = '95ca70a3491a111ef97b97ce3bfb25324221433ea8fd854e83372b4b6ad0d605'
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(part)
    return digest.hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], env=ENV)


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def snapshot(label):
    records = []
    mismatches = []
    total = 0
    for entry in git('ls-tree', '-rz', '--full-tree', HEAD).split(b'\0'):
        if not entry:
            continue
        meta, raw_path = entry.split(b'\t', 1)
        mode, kind, expected = meta.decode().split()
        relative = os.fsdecode(raw_path)
        path = ROOT / relative
        info = path.lstat()
        if mode == '120000' and stat.S_ISLNK(info.st_mode):
            data = os.fsencode(os.readlink(path))
            actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            size = len(data)
        elif mode in {'100644', '100755'} and stat.S_ISREG(info.st_mode):
            size = info.st_size
            digest = hashlib.sha1(b'blob ' + str(size).encode() + b'\0')
            with path.open('rb') as stream:
                for part in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(part)
            actual = digest.hexdigest()
            if bool(info.st_mode & 0o111) != (mode == '100755'):
                mismatches.append({'path': relative, 'reason': 'executable mode'})
        else:
            raise RuntimeError('unsupported or changed tracked entry: ' + relative)
        total += size
        records.append({'path': relative, 'mode': mode, 'blob': actual, 'bytes': size})
        if kind != 'blob' or actual != expected:
            mismatches.append({'path': relative, 'reason': 'blob', 'expected': expected, 'actual': actual})
    manifest = OUT / (label + '-files.json')
    manifest.write_text(json.dumps(records, separators=(',', ':'), ensure_ascii=True) + '\n')
    result = {
        'observed_utc': utc(),
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
        'status_porcelain': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
        'tracked_files': len(records),
        'tracked_bytes': total,
        'raw_blob_mismatches': mismatches,
        'files_manifest_sha256': sha(manifest),
        'test_script_sha256': sha(ROOT / 'scripts/ci/test_repository.py'),
    }
    save(label + '-source.json', result)
    return result


def clean_source(value):
    return (value['head'] == HEAD and value['tree'] == TREE
            and not value['status_porcelain'] and not value['raw_blob_mismatches']
            and value['test_script_sha256'] == TEST_SHA256)


def command(label, argv):
    started = time.monotonic()
    with (OUT / (label + '.stdout')).open('wb') as stdout, (OUT / (label + '.stderr')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr)
    return {
        'argv': argv, 'cwd': str(ROOT), 'exit_code': result.returncode,
        'wall_seconds': time.monotonic() - started, 'finished_utc': utc(),
        'stdout_sha256': sha(OUT / (label + '.stdout')),
        'stderr_sha256': sha(OUT / (label + '.stderr')),
    }


def main():
    OUT.mkdir(exist_ok=False)
    TMP.mkdir(mode=0o700, exist_ok=False)
    ENV['TMPDIR'] = str(TMP)
    fs = subprocess.check_output(['findmnt', '-n', '-o', 'FSTYPE,SOURCE,TARGET', '-T', str(TMP)], text=True).strip()
    if TMP.resolve() != TMP or fs.split()[0] != 'tmpfs':
        raise RuntimeError('local run requires the explicitly coordinated independent tmpfs path')
    before = snapshot('before')
    if not clean_source(before):
        raise RuntimeError('source is not the exact clean complete fixed commit')
    usage = shutil.disk_usage(TMP)
    if usage.free < before['tracked_bytes'] + 2 * 1024**3:
        raise RuntimeError('insufficient independent copy space')
    shutil.copyfile(ROOT / 'scripts/ci/test_repository.py', OUT / 'original-test_repository.py')
    shutil.copyfile(ROOT / 'scripts/ci/check_repository.py', OUT / 'original-check_repository.py')
    module = ast.parse((ROOT / 'scripts/ci/test_repository.py').read_text())
    tests = [node.name + '.' + child.name for node in module.body if isinstance(node, ast.ClassDef)
             for child in node.body if isinstance(child, ast.FunctionDef) and child.name.startswith('test_')]
    if len(tests) != 50:
        raise RuntimeError('original method inventory is not 50')
    save('method-inventory.json', tests)
    record = {
        'started_utc': utc(), 'source_before': before, 'python_executable': sys.executable,
        'python_version': sys.version, 'tmpdir': str(TMP), 'tmpdir_mount': fs,
        'tmpdir_disk_before': usage._asdict(), 'environment_overrides': {
            key: ENV[key] for key in ['TMPDIR', 'GIT_OPTIONAL_LOCKS', 'PYTHONDONTWRITEBYTECODE']},
        'declared_methods': len(tests), 'qualification': 'HOLD_NO_GO',
        'automatic_retries': 0, 'tests_started': False,
    }
    save('run.json', record)
    record['preflight'] = command('preflight', ['bash', 'scripts/project-preflight.sh', '--audit'])
    save('run.json', record)
    if record['preflight']['exit_code']:
        return record['preflight']['exit_code']
    record['tests_started'] = True
    save('run.json', record)
    print('SOURCE_READY_TEST_REPOSITORY_50 ' + json.dumps({'head': HEAD, 'tree': TREE, 'tmpdir': str(TMP)}), flush=True)
    record['test'] = command('test_repository', [sys.executable, 'scripts/ci/test_repository.py'])
    after = snapshot('after')
    record['source_after'] = after
    record['source_unchanged'] = clean_source(after) and after['files_manifest_sha256'] == before['files_manifest_sha256']
    text = (OUT / 'test_repository.stderr').read_text(errors='replace')
    counts = re.findall(r'Ran (\d+) tests? in', text)
    record['observed_methods'] = int(counts[-1]) if counts else None
    record['count_matches_original'] = record['observed_methods'] == 50
    record['tmpdir_disk_after'] = shutil.disk_usage(TMP)._asdict()
    record['tmpdir_remaining_entries'] = [p.name for p in TMP.iterdir()]
    record['finished_utc'] = utc()
    record['runner_exit'] = record['test']['exit_code'] or (0 if record['source_unchanged'] and record['count_matches_original'] else 86)
    save('run.json', record)
    print(json.dumps(record), flush=True)
    return record['runner_exit']


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        if OUT.is_dir():
            save('runner-failure.json', {'observed_utc': utc(), 'error': repr(error)})
        raise
