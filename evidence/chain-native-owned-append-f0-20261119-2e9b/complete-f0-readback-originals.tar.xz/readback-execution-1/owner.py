from pathlib import Path
import json,subprocess,time,resource,hashlib,sys,traceback,os,re
root=Path('/home/qian-qi/work/chain-native-owned-append-f0-20261119-2e9b');out=root/'readback-execution-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);head='e8b0ec93ab6a6a1ff5e36cfcf9d1179e030a5975';rid=44465153982
res={'schema':'chain-original-f0-readback-execution-v1','business_reexecuted':False,'head':head,'run_id':rid,'invocation_count':0,'reader_semantics_changed':False,'collection_filename_adapter_only':True}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def create(p,raw):
 with p.open('xb') as f:f.write(raw)
save()
try:
 prepared=json.loads((root/'readers-preparation-1/RESULT.json').read_text());assert prepared['finished'] is True
 assert sha((root/'f0-readback.py').read_bytes())==prepared['wrapper_sha256']=='ba0ea6366f038f380609f0ea34902620b0fa5b1b3cc111ef25b4c56e537f4483'
 for attempt in range(360):
  raw=(root/'collection/COLLECTION.json').read_bytes();receipt=json.loads(raw)
  if receipt.get('error'):raise RuntimeError('original collection failed: '+receipt['error'])
  if receipt['complete_download'] is True:break
  if attempt%15==0:print(json.dumps({'waiting_for_original_collection':True,'checks':attempt}),flush=True)
  time.sleep(20)
 else:raise RuntimeError('original artifact not complete; no business run retried')
 assert receipt['head']==head and receipt['run_id']==rid and receipt['run_attempt']==1 and receipt['every_manifest_member_verified'] is True
 collection=root/'collection';create(collection/'native-collection-original.json',raw)
 run_request=[x for x in receipt['requests'] if re.fullmatch(r'run-\d+',x['name'])][-1]
 provider=(collection/(run_request['name']+'.stdout')).read_bytes();p=json.loads(provider)
 assert run_request['exit_code']==0 and sha(provider)==run_request['stdout_sha256'] and p['id']==rid and p['head_sha']==head and p['run_attempt']==1 and p['status']=='completed'
 artifacts=(collection/'artifacts-page-1.stdout').read_bytes();a=json.loads(artifacts)
 assert a['total_count']==len(a['artifacts'])==1 and a['artifacts']==receipt['artifacts']
 create(collection/'run.stdout',provider);create(collection/'artifacts.stdout',artifacts)
 adapted=dict(receipt);adapted['expected_head']=head
 assert set(adapted)-set(receipt)=={'expected_head'}
 temp=collection/'COLLECTION.original-reader-interface.tmp';create(temp,(json.dumps(adapted,indent=2)+'\n').encode());assert sha((collection/'COLLECTION.json').read_bytes())==sha(raw);temp.replace(collection/'COLLECTION.json')
 res['collection_interface']={'native_original_receipt_sha256':sha(raw),'reader_receipt_sha256':sha((collection/'COLLECTION.json').read_bytes()),'only_added_field':'expected_head','value_verified_against_both_native_collector_and_provider':head,'provider_alias_source':run_request['name']+'.stdout','provider_raw_sha256':sha(provider),'artifact_alias_source':'artifacts-page-1.stdout','artifact_raw_sha256':sha(artifacts)}
 command=['/usr/bin/python3',str(root/'f0-readback.py')];start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN);res['invocation_count']=1;res['command']=command;save();env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:
  p=subprocess.Popen(command,cwd=root,env=env,stdout=so,stderr=se);res['pid']=p.pid;save();rc=p.wait()
 after=resource.getrusage(resource.RUSAGE_CHILDREN);res.update(exit_code=rc,wall_seconds=time.monotonic()-start,child_user_cpu_seconds=after.ru_utime-before.ru_utime,child_system_cpu_seconds=after.ru_stime-before.ru_stime,outputs=[])
 for name in ('f0-independent-readback.json','current-cost-profile.json'):
  path=root/name
  if path.exists():res['outputs'].append({'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})
 save();print((out/'stdout').read_text(),flush=True);print(json.dumps(res),flush=True)
 if rc:print((out/'stderr').read_text(),flush=True)
 sys.exit(rc)
except BaseException as e:
 if not isinstance(e,SystemExit):res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc())
 raise
