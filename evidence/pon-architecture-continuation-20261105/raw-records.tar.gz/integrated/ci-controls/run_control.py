import hashlib,json,re,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/scratch/1790ff0f3cc3/chain')
OUT=Path('/workspace/scratch/1790ff0f3cc3/work/integrated/ci-controls')
EXPECTED='d992451cc8bfb3d69a1c9f1906bee6732255fad6'
EXPECTED_TREE='e5bfe7c1dabdae738173e0f6699cfaa3960cbbaf'
INPUTS=('config/pon/pq-cross-branch-corpus-v1.json', 'scripts/ci/check_pq_research_integration.py', 'trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs', '.github/workflows/pon-branch-encoding-acceptance.yml', '.github/workflows/pon-recent-batch-acceptance.yml', 'scripts/ci/check_native_constants_roster.py', 'scripts/ci/test_native_constants_roster.py', 'trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_store.rs', 'scripts/ci/ci_job.sh','scripts/ci/test_ci_contract.py','scripts/ci/check_ci_contract.py',
        'scripts/ci/test_ci_source_integrity.py','scripts/ci/verify_ci_source.py',
        'scripts/ci/test_project_boundary.py','scripts/ci/project_boundary.py',
        'scripts/ci/test_ci_execution.py','docs/protocol/pon-nakamoto-v1/details/ARCHITECTURE_COMPARISON_V1.md',
        'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md',
        'evidence/pon-architecture-continuation-20261105/README.md')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def identity():
 return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),
         'git_status_porcelain':git('status','--porcelain'),
         'reviewed_input_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in INPUTS}}
label=sys.argv[1];command=sys.argv[2:]
if not re.fullmatch('[a-z0-9-]+',label) or not command:raise ValueError('control arguments')
log=OUT/(label+'.log'); receipt=OUT/(label+'.json')
if log.exists() or receipt.exists():raise ValueError('refuse overwrite')
before=identity()
assert before['head']==EXPECTED and before['tree']==EXPECTED_TREE,before
assert before['git_status_porcelain']=='',before
started=time.monotonic();timed_out=False
with log.open('x') as stream:
 try:
  result=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=600)
  exit_code=result.returncode
 except subprocess.TimeoutExpired:
  exit_code=None;timed_out=True
wall=time.monotonic()-started;after=identity();raw=log.read_bytes();text=raw.decode(errors='replace')
counts=re.findall(r'Ran (\d+) tests? in ',text)
record={'label':label,'cwd':str(ROOT),'command':command,'source_before':before,'source_after':after,
        'source_unchanged':before==after,'exit_code':exit_code,'timed_out':timed_out,'wall_seconds':wall,
        'reported_unittest_count':int(counts[-1]) if counts else None,
        'log_sha256':hashlib.sha256(raw).hexdigest(),'log_bytes':len(raw),'log_path':str(log),
        'scope':'Integrated Python CI roster/contract and preflight controls; no native build or business acceptance',
        'passed':exit_code==0 and not timed_out and before==after}
receipt.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('label','command','exit_code','timed_out','reported_unittest_count','source_unchanged','wall_seconds','passed')}))
print('\n'.join(text.splitlines()[-6:]))
raise SystemExit(0 if record['passed'] else 1)
