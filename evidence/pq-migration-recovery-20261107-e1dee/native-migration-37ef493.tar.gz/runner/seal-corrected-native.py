#!/usr/bin/env python3
"""Seal only corrected validation records, scripts and public metadata."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tarfile

TASK = Path('/home/qian-qi/work/chain-pq-migration-recovery-e1dee-20261106')
OUT = TASK / 'records/native-corrected'
HEAD = '37ef49311db7e62df1b152b8a7b0fc9104d56c17'
TREE = '15f31d721e62f0766d0a9b13b42e163c93267d22'
STEM = 'native-corrected-evidence-37ef493'
ENVIRONMENT_SHA256 = '5c9c21a7045e09aca9eab347a222c886dc56e5e10b7935f51b7dfe9f5a4a937a'
RUNNER_SHA256 = 'cc48d7ba9cb6b2fe353d9c909f0c5f7da0c6752d82a5ef264460f9abc8136950'
HELPER_SHA256 = 'fdd330aacfa3ccd65aa5740c433c76a284df8241e14ab80f31e9396fed4ed1b9'
PUBLIC_ENV = {'OPENSSL_DIR', 'OPENSSL_MODULES', 'OPENSSL_STATIC', 'OPENSSL_CONF',
              'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_VERSION', 'TRNM_PQ_OPENSSL_SHA256',
              'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
              'RUSTUP_TOOLCHAIN', 'RUSTC', 'RUSTDOC', 'RUST_TEST_THREADS', 'PATH',
              'PYTHONDONTWRITEBYTECODE'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def stable_read(path):
    path = Path(path)
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('nonregular evidence member: ' + str(path))
    data = path.read_bytes()
    after = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    if any(getattr(before, k) != getattr(after, k) for k in fields) or len(data) != after.st_size:
        raise RuntimeError('evidence changed during read: ' + str(path))
    if data.startswith(b'\x7fELF'):
        raise RuntimeError('ELF bodies are outside this evidence archive')
    return data


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def publish(path, data):
    with Path(path).open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.chmod(path, 0o444)
    with Path(path).open('rb') as stream:
        os.fsync(stream.fileno())


def main():
    runtime = json.load(sys.stdin)
    terminal = json.loads(next(c['text'] for c in runtime['native_terminal']['content'] if c['type'] == 'text'))
    if not (terminal['job_id'] == '1a1b35a2c03-fc05-8257' and terminal['state'] == 'succeeded'
            and terminal['exit_code'] == 0 and terminal['output_complete'] and terminal['output_durable']
            and not terminal['automatic_retry'] and not terminal['timed_out'] and not terminal['cancelled']):
        raise RuntimeError('native job has no successful complete terminal receipt')
    complete = json.loads(stable_read(OUT / 'complete.json'))
    if complete['status'] != 'completed' or complete['corrected_source'] != HEAD or complete['corrected_tree'] != TREE:
        raise RuntimeError('native completion does not name the corrected tested source')
    environment_bytes = stable_read(TASK / 'environment.json')
    if sha(environment_bytes) != ENVIRONMENT_SHA256:
        raise RuntimeError('configured native environment changed')
    extra = json.loads(environment_bytes)
    if set(extra) != PUBLIC_ENV or not all(isinstance(v, str) for v in extra.values()):
        raise RuntimeError('environment is not the exact public selected configuration')
    provider = Path(extra['TRNM_PQ_OPENSSL'])
    before = file_sha(provider)
    if before != extra['TRNM_PQ_OPENSSL_SHA256']:
        raise RuntimeError('provider digest changed')
    environment = os.environ.copy()
    environment.update(extra)
    version = subprocess.run([str(provider), 'version'], env=environment, capture_output=True,
                             text=True, timeout=20, check=False)
    after = file_sha(provider)
    if version.returncode or before != after or 'OpenSSL ' + extra['TRNM_PQ_OPENSSL_VERSION'] not in version.stdout:
        raise RuntimeError('provider version/digest observation failed')
    observation = {'scope': 'public-provider-executable-identity-only', 'host_alias': 'rog',
                   'observed_utc': datetime.now(timezone.utc).isoformat(),
                   'path': str(provider), 'size': provider.stat().st_size,
                   'sha256_before': before, 'sha256_after': after,
                   'argv': [str(provider), 'version'], 'exit_code': version.returncode,
                   'stdout': version.stdout, 'stderr': version.stderr}
    members = {}
    for path in sorted(OUT.rglob('*')):
        if path.is_dir():
            continue
        if path.suffix not in ('.json', '.log'):
            raise RuntimeError('unselected evidence file: ' + str(path))
        data = stable_read(path)
        members['records/native-corrected/' + path.relative_to(OUT).as_posix()] = data
        if path.suffix == '.json':
            receipt = json.loads(data)
            if isinstance(receipt, dict) and receipt.get('schema') == 'trnm-pq-native-command-v1':
                if not (receipt['status'] == 'command_succeeded' and receipt['exit_code'] == 0
                        and receipt['before'] == receipt['after']
                        and receipt['before']['tested_commit'] == HEAD
                        and receipt['before']['tested_tree'] == TREE):
                    raise RuntimeError('unsuccessful/wrong-source command receipt: ' + str(path))
                log_name = receipt['log_file']
                if Path(log_name).name != log_name:
                    raise RuntimeError('unexpected command log path')
                log = stable_read(OUT / log_name)
                if sha(log) != receipt['log_sha256'] or len(log) != receipt['log_bytes']:
                    raise RuntimeError('command log differs from original receipt')
    for name, expected in [('native-corrected-validation-v1.py', RUNNER_SHA256),
                           ('native-validation-v1.py', HELPER_SHA256)]:
        data = stable_read(TASK / name)
        if sha(data) != expected:
            raise RuntimeError('selected runner/helper changed')
        members['runner/' + name] = data
    members['runner/seal-corrected-native.py'] = stable_read(__file__)
    members['environment/configured-environment.json'] = environment_bytes
    members['environment/public-provider-observation.json'] = encoded(observation)
    members['runtime/native-controller-receipts.json'] = encoded(runtime)
    manifest = {'schema': 'trnm-corrected-native-evidence-manifest-v1',
                'tested_source': HEAD, 'tested_tree': TREE, 'native_job_id': terminal['job_id'],
                'native_status': terminal['state'], 'native_exit_code': terminal['exit_code'],
                'elf_bodies_included': False, 'private_environment_dump_included': False,
                'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data)}
                            for name, data in sorted(members.items())]}
    manifest_data = encoded(manifest)
    manifest_path = TASK / 'records' / (STEM + '.manifest.json')
    archive_path = TASK / 'records' / (STEM + '.tar.gz')
    seal_path = TASK / 'records' / (STEM + '.seal.json')
    if any(path.exists() for path in (manifest_path, archive_path, seal_path)):
        raise RuntimeError('sealed evidence path already exists; no overwrite or automatic retry')
    publish(manifest_path, manifest_data)
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for name, data in sorted({**members, 'MANIFEST.json': manifest_data}.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o444
                    info.mtime = 0
                    archive.addfile(info, io.BytesIO(data))
        raw.flush()
        os.fsync(raw.fileno())
    os.chmod(archive_path, 0o444)
    with archive_path.open('rb') as stream:
        os.fsync(stream.fileno())
    seal = {'schema': 'trnm-corrected-native-evidence-seal-v1', 'tested_source': HEAD,
            'tested_tree': TREE, 'native_job_id': terminal['job_id'],
            'archive': str(archive_path), 'archive_bytes': archive_path.stat().st_size,
            'archive_sha256': file_sha(archive_path), 'manifest': str(manifest_path),
            'manifest_bytes': len(manifest_data), 'manifest_sha256': sha(manifest_data),
            'manifest_members': len(members), 'tar_members': len(members) + 1,
            'read_only_mode': '0444', 'automatic_retry': False}
    publish(seal_path, encoded(seal))
    fd = os.open(TASK / 'records', os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    print(json.dumps(seal, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
