import importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('check',Path(__file__).with_name('run_typecheck.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
before=m.source()
try:
    for crate in ['trnm_protocol','trnm_crypto_primitives','trnm_mvcc_fee','trnm_pon_node']:
        m.build(crate,'02',opt=0)
    for crate,target in [('trnm_protocol','lib'),('trnm_mvcc_fee','lib'),('trnm_mvcc_fee','pq5_task_renewal'),('trnm_pon_node','native_pq_v5')]:
        m.build(crate,'tests01',target,opt=0)
finally:
    m.dump(m.OUT/'current-metadata-source-after.json',{'source_before_after_equal':before==m.source(),'source_before':before,'source_after':m.source(),'scope':'metadata-only explicit graph; native tests NOT_RUN; not Cargo qualification'})
