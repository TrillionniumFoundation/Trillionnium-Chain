#!/usr/bin/env bash
set -euo pipefail
ROOT=/workspace/scratch/29755d2a47ef/chain-decode-pages
OUT=/workspace/shared
SOURCE=0083f3c1bfca1e03af63ad3c6f6e11199b7bfbed
exec 9>"$OUT/owner-packet-validation.lock"
flock -n 9 || { echo 'Validation already running; refusing duplicate.'; exit 75; }
cd "$ROOT"
test "$(git rev-parse HEAD)" = "$SOURCE"
test -z "$(git status --porcelain)"
bash scripts/project-preflight.sh
sha256sum -c "$OUT/owner-packet-source.sha256"
export PATH=/workspace/shared/chain-cargo/bin:$PATH
export CARGO_HOME=/workspace/shared/chain-cargo
export RUSTUP_HOME=/workspace/shared/chain-rustup
export CARGO_TARGET_DIR=/workspace/shared/chain-confirmation-target
export CARGO_BUILD_JOBS=1
status() {
  printf '{"source":"%s","phase":"%s","status":"%s","exit_code":%s,"utc":"%s"}\n' "$SOURCE" "$1" "$2" "$3" "$(date -u +%FT%TZ)" > "$OUT/owner-packet-validation-status.json.tmp"
  mv "$OUT/owner-packet-validation-status.json.tmp" "$OUT/owner-packet-validation-status.json"
}
run() {
  local phase=$1 log=$2
  shift 2
  status "$phase" running null
  set +e
  "$@" > "$OUT/$log" 2>&1
  local code=$?
  set -e
  if [ "$code" -ne 0 ]; then status "$phase" failed "$code"; exit "$code"; fi
  status "$phase" completed 0
}
CARGO=(cargo +1.95.0 test --locked --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib)
run build owner-packet-final-build.txt "${CARGO[@]}" --no-run
run digest owner-packet-digest.txt "${CARGO[@]}" stored_packet_digest_borrows_full_blob_and_preserves_conversion_errors -- --nocapture --test-threads=1
run gates owner-packet-gates.txt "${CARGO[@]}" owner_packet_reads_preserve_gates_errors_and_journal -- --nocapture --test-threads=1
run native-owner owner-packet-native.txt "${CARGO[@]}" store::native_authenticated:: -- --nocapture --test-threads=1
run mining owner-packet-mining.txt "${CARGO[@]}" store::operator_mining_owner::tests -- --nocapture --test-threads=1
run continuous owner-packet-continuous.txt "${CARGO[@]}" store::operator_continuous_owner::tests -- --nocapture --test-threads=1
run pq-startup owner-packet-pq-startup.txt "${CARGO[@]}" operator_pq_startup::tests -- --nocapture --test-threads=1
run task-observation owner-packet-task.txt "${CARGO[@]}" store::task_observation::tests -- --nocapture --test-threads=1
run wire owner-packet-wire.txt "${CARGO[@]}" store::admission_wire_tests -- --nocapture --test-threads=1
run request owner-packet-request.txt "${CARGO[@]}" ingress::public_v3::request_observation::tests -- --nocapture --test-threads=1
sha256sum -c "$OUT/owner-packet-source.sha256"
status all completed 0
cat "$OUT/owner-packet-validation-status.json"
