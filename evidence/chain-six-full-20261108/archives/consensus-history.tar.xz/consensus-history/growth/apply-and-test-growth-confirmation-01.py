from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/home/qian-qi/work/chain-six-consensus-d9fb-20261108')
evidence=Path('/home/qian-qi/work/chain-six-consensus-d9fb-evidence')
base='7e044b65454f4c9ea505591727332acffb33e7e5'
deadline=time.monotonic()+1700
redpath=evidence/'red-growth-confirmation.json'
while not redpath.exists():
    if time.monotonic()>deadline:
        raise SystemExit('Original red run has no terminal result; no runtime source changed')
    time.sleep(2)
red=json.loads(redpath.read_text())
assert red['new_test_exposes_unimplemented_growth_confirmation'] is True, red
assert red['source_unchanged_during_run'] is True
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==base
subprocess.run(['bash','scripts/project-preflight.sh'],cwd=root,check=True)
for name,digest in red['source_sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
def replace(name,old,new):
    path=root/name
    text=path.read_text()
    assert text.count(old)==1,(name,old,text.count(old))
    path.write_text(text.replace(old,new))
def create(name,source):
    path=root/name
    assert not path.exists(),name
    path.write_text((evidence/source).read_text())
replace('trillionnium/crates/trnm-pon-node/src/store/growth.rs',
        '#[cfg(test)]\nmod difference_tests;',
        'mod confirmation;\n#[cfg(test)]\nmod difference_tests;')
replace('trillionnium/crates/trnm-pon-node/src/store/growth/recovery.rs',
        '    ObservationDelta,\n',
        '    /// Before each distinct included body and its complete W1/M06 replay.\n'
        '    ConfirmationBody {\n        index: usize,\n    },\n'
        '    /// Before each complete confirmation-ancestry link, then at EOF.\n'
        '    ConfirmationAncestor {\n        index: u64,\n    },\n'
        '    ObservationDelta,\n')
replace('trillionnium/crates/trnm-pon-node/src/store.rs',
'''    fn check_observed_history_with_progress(
        &self,
        tip: Hash,
        observed_now: u64,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<()> {
        progress()?;
        let bound''',
'''    fn check_observed_history_with_progress(
        &self,
        tip: Hash,
        observed_now: u64,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<()> {
        progress()?;
        if self.state_backend == StateBackend::PermanentAccountGrowthV2 {
            return self.growth_check_observed_history_with_progress(tip, observed_now, progress);
        }
        let bound''')
replace('trillionnium/crates/trnm-pon-node/src/store.rs',
'''    pub fn confirmations(
        &self,
        queries: &[(Hash, Hash)],
        observed_now: u64,
    ) -> Result<ConfirmationBatch> {
        self.confirmations_with_progress(queries, observed_now, &mut |_| Ok(()))
    }''',
'''    pub fn confirmations(
        &self,
        queries: &[(Hash, Hash)],
        observed_now: u64,
    ) -> Result<ConfirmationBatch> {
        if self.state_backend == StateBackend::PermanentAccountGrowthV2 {
            return self.growth_confirmations_with_progress(queries, observed_now, &|_| Ok(()));
        }
        self.confirmations_with_progress(queries, observed_now, &mut |_| Ok(()))
    }''')
replace('trillionnium/crates/trnm-pon-node/src/store.rs',
'''        let unique: BTreeSet<_> = queries.iter().copied().collect();
        ensure(unique.len() == queries.len(), "DUPLICATE_QUERY")?;
        progress(0)?;
        self.ready()?;''',
'''        let unique: BTreeSet<_> = queries.iter().copied().collect();
        ensure(unique.len() == queries.len(), "DUPLICATE_QUERY")?;
        progress(0)?;
        // The growth W1/M06 callback is Sync. Never discard it or silently
        // substitute this legacy non-Sync FnMut callback for its checkpoints.
        ensure(
            self.state_backend != StateBackend::PermanentAccountGrowthV2,
            "GROWTH_USE_CONFIRMATION_PROGRESS",
        )?;
        self.ready()?;''')
create('trillionnium/crates/trnm-pon-node/src/store/growth/confirmation.rs',
       'staged-growth-confirmation.rs')
(root/'trillionnium/crates/trnm-pon-node/src/store/growth/tests/confirmation.rs').write_text(
    (evidence/'staged-growth-confirmation-tests.rs').read_text())
create('docs/development/specs/pon/NATIVE_GROWTH_CONFIRMATION_V1.md',
       'staged-growth-confirmation.md')
changed=[
 'trillionnium/crates/trnm-pon-node/src/store.rs',
 'trillionnium/crates/trnm-pon-node/src/store/growth.rs',
 'trillionnium/crates/trnm-pon-node/src/store/growth/recovery.rs',
 'trillionnium/crates/trnm-pon-node/src/store/growth/tests.rs',
 'trillionnium/crates/trnm-pon-node/src/store/growth/confirmation.rs',
 'trillionnium/crates/trnm-pon-node/src/store/growth/tests/confirmation.rs',
]
subprocess.run(['/home/qian-qi/.cargo/bin/rustfmt','--edition','2021','--config','skip_children=true',*changed],cwd=root,check=True)
subprocess.run(['/usr/bin/python3','scripts/refresh_distributed_source_inventory.py'],cwd=root,check=True)
changed += [
 'trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs',
 'docs/development/specs/pon/NATIVE_GROWTH_CONFIRMATION_V1.md',
]
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','add','--',*changed],cwd=root,check=True)
subprocess.run(['bash','scripts/project-preflight.sh','--staged'],cwd=root,check=True)
subprocess.run(['git','commit','-s','-m','Add full native growth confirmation and observed ancestry clocks'],cwd=root,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()
record={'schema':'chain-six-consensus-candidate-v1','base':base,'commit':head,'tree':tree,
 'source_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in changed},
 'red_evidence_sha256':hashlib.sha256(redpath.read_bytes()).hexdigest()}
(evidence/'candidate-source-01.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
env=os.environ.copy()
env.update({'CARGO_TARGET_DIR':'/home/qian-qi/work/chain-six-consensus-d9fb-build',
            'CARGO_BUILD_JOBS':'2','CARGO_TERM_COLOR':'never','PYTHONDONTWRITEBYTECODE':'1'})
cmd=['/home/qian-qi/.cargo/bin/cargo','test','--offline','--locked','--manifest-path','trillionnium/Cargo.toml',
 '-p','trnm-pon-node','--lib','store::growth::tests::confirmation::','--','--nocapture','--test-threads=1']
log=evidence/'native-growth-confirmation-01.log'
assert not log.exists()
start=time.time()
with log.open('xb') as f:
    result=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1500)
text=log.read_text()
tests=re.findall(r'^test (store::growth::tests::confirmation::\w+) \.\.\. ok$',text,re.M)
summary={'schema':'chain-six-consensus-native-tests-v1','source_commit':head,'command':cmd,
 'returncode':result.returncode,'elapsed_seconds':time.time()-start,'passed_names':tests,
 'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
 'source_unchanged_during_run':all(hashlib.sha256((root/p).read_bytes()).hexdigest()==d for p,d in record['source_sha256'].items()),
 'broader_qualification':'HOLD_NO_GO'}
summary['all_eight_passed']=result.returncode==0 and len(tests)==8 and '8 passed; 0 failed; 0 ignored' in text
(evidence/'native-growth-confirmation-01.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
print(text[-10000:],flush=True)
raise SystemExit(0 if summary['all_eight_passed'] and summary['source_unchanged_during_run'] else 1)
