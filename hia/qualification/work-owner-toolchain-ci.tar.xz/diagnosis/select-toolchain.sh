set -euo pipefail
rustup toolchain install 1.95.0 --profile minimal --component rust-src
trnm_work_rustc="$(rustup which --toolchain 1.95.0-x86_64-unknown-linux-gnu rustc)"
test -x "$trnm_work_rustc"
printf '%s\n' "$(dirname "$trnm_work_rustc")" >> "$GITHUB_PATH"
printf 'RUSTUP_TOOLCHAIN=1.95.0-x86_64-unknown-linux-gnu\n' >> "$GITHUB_ENV"
