#!/usr/bin/env python3
"""Package retained W1 observations for one frozen code commit.

This helper is deliberately separate from the repository and from validation.
It runs no tests, downloads, builds, or remote commands. A later reviewed
invocation writes only the three create-only evidence files. Raw failures and
historical observations are retained, while method coverage is counted only
from completed suites on the frozen source. See --help for the final-record
arguments; incomplete final records are an error, not a successful gate.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile
import tempfile
import tomllib

HEAD = "eeeaafbc742d4b384e8e8b0d53c65b7e8b3bf182"
TREE = "3149b20d568422f39fba74197ab9ae5874136834"
BASELINE = "e2a02f9271b49f146e70806c8a66e161b5973971"
HISTORICAL_HEAD = "c561fcb5a1c99d77722bb2f5e85e7b4e61961ce7"
TASK = Path("/workspace/scratch/7e8b6061b88c")
EVIDENCE = "evidence/pon-w1-stark-route-instance-20261109"
MAX_FILE = 32 * 1024 * 1024
MAX_TOTAL = 256 * 1024 * 1024
SUITES = {
    "test_w1_stark_field_certificates": 16,
    "test_w1_stark_route_audit": 22,
    "test_w1_qrom_current_implementation_audit": 14,
    "test_ci_contract": 167,
    "test_ci_source_integrity": 43,
    "test_pq_research_integration": 57,
    "test_pq_chain_claim_guard": 55,
}
TEXT_SUFFIXES = {".json", ".stdout", ".stderr", ".log", ".py", ".sh", ".env",
                 ".md", ".txt", ".patch", ".toml", ".sha256"}
SENSITIVE_OMISSION = "supporting-records/hepta-status-observation.json"
LOCAL = f"validation/{HEAD}"
REMOTE_REPOSITORY = "supporting-records/remote-repository-controls/remote-repository-controls-eeeaafbc"
REMOTE_RISC = "supporting-records/remote-risc-graph/remote-risc-graph-eeeaafbc"


class EvidenceError(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise EvidenceError(reason)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()


def parse_json(data):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key")
            result[key] = value
        return result

    def nonfinite(_):
        raise EvidenceError("nonfinite JSON number")

    return json.loads(data.decode("utf-8"), object_pairs_hook=pairs, parse_constant=nonfinite)


def path_name(name):
    require(type(name) is str, "record path is not text")
    path = PurePosixPath(name)
    require(not path.is_absolute() and path.parts and path.as_posix() == name
            and all(part not in (".", "..") for part in path.parts), "noncanonical record path")
    return name


def excluded_directory(name):
    value = name.lower()
    return (value in {"cargo-home", "cargo_home", "cache", ".cache", "registry", "target",
                      "rust-target", "fixture", "fixtures", ".git", "__pycache__", "node_modules"}
            or value.startswith(("cargo-home-", "target-", "target_", "fixture-", "fixture_"))
            or value.endswith(("-target", "-cache")))


def stable_bytes(path):
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= MAX_FILE,
            "nonregular or oversized retained record: " + str(path))
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        require(os.fstat(descriptor).st_ino == before.st_ino, "record changed before opening")
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            data = stream.read(MAX_FILE + 1)
        after = os.fstat(descriptor)
        visible = path.lstat()
        identity = lambda row: (row.st_dev, row.st_ino, row.st_size, row.st_mtime_ns, row.st_ctime_ns)
        require(identity(before) == identity(after) == identity(visible), "record changed while reading")
        require(len(data) == before.st_size, "record length changed")
        return data
    finally:
        os.close(descriptor)


def check_public_text(name, data):
    require(Path(name).suffix in TEXT_SUFFIXES, "unreviewed record extension: " + name)
    require(b"\0" not in data, "binary payload refused: " + name)
    text = data.decode("utf-8")
    if Path(name).suffix == ".env":
        require(Path(name).name == "provider.env", "unreviewed environment file")
        allowed = {"OPENSSL_DIR", "OPENSSL_STATIC", "TRNM_PQ_OPENSSL",
                   "TRNM_PQ_OPENSSL_SHA256", "TRNM_PQ_OPENSSL_VERSION",
                   "OPENSSL_CONF", "OPENSSL_MODULES"}
        values = {}
        for line in text.splitlines():
            key, separator, value = line.partition("=")
            require(separator == "=" and key in allowed and key not in values,
                    "unreviewed provider environment key")
            values[key] = value
        # The cancelled preparation retained its original empty output file.
        require(not values or set(values) == allowed, "incomplete provider environment")
        if values:
            require(values["OPENSSL_STATIC"] == "1"
                    and values["TRNM_PQ_OPENSSL_VERSION"] == "3.5.9"
                    and values["OPENSSL_CONF"] == "/dev/null"
                    and re.fullmatch(r"[0-9a-f]{64}", values["TRNM_PQ_OPENSSL_SHA256"]),
                    "unexpected fixed provider environment")
            require(all(values[key].startswith("/") for key in
                        ("OPENSSL_DIR", "TRNM_PQ_OPENSSL", "OPENSSL_MODULES")),
                    "nonabsolute provider input path")
    # This is a targeted fail-closed check for the known private status object,
    # not a claim that an automated secret detector replaces publication review.
    if Path(name).suffix == ".json" and text.strip():
        value = parse_json(data)
        def visit(item):
            if isinstance(item, dict):
                require("launch_nonce" not in item, "private runtime status key refused: " + name)
                for child in item.values():
                    visit(child)
            elif isinstance(item, list):
                for child in item:
                    visit(child)
        visit(value)


def inspect_nested_archive(name, data):
    """Record hashes of nested record members; never extract archive contents."""
    require(name.startswith("supporting-records/") and (
            "records" in Path(name).name or Path(name).name.startswith(
                ("remote-repository-controls-", "remote-clippy-", "remote-risc-graph-"))),
            "only supporting record archives are permitted")
    members, seen, total = [], set(), 0
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        for member in archive:
            member_name = path_name(member.name.rstrip("/"))
            require(member_name not in seen, "duplicate nested archive member")
            seen.add(member_name)
            require(not any(excluded_directory(part) for part in PurePosixPath(member_name).parts[:-1]),
                    "cache/target/fixture payload in nested archive")
            if member.isdir():
                continue
            require(member.isfile() and 0 <= member.size <= MAX_FILE,
                    "nonregular or oversized nested archive member")
            require(not member_name.endswith((".tar.gz", ".tgz")), "second-level archive refused")
            content = archive.extractfile(member).read(member.size + 1)
            require(len(content) == member.size, "short nested archive member")
            check_public_text(member_name, content)
            total += len(content)
            require(total <= MAX_TOTAL, "nested record archive exceeds limit")
            members.append({"path": member_name, "bytes": len(content), "sha256": digest(content)})
    return members


def collect_records(task):
    payloads, exclusions, nested = {}, [], {}
    for label in ("validation", "supporting-records"):
        base = task / label
        require(base.is_dir() and not base.is_symlink(), "missing record directory: " + label)
        for directory, dirs, files in os.walk(base, followlinks=False):
            kept = []
            for entry in sorted(dirs):
                path = Path(directory) / entry
                require(not path.is_symlink(), "symlink record directory refused")
                if excluded_directory(entry):
                    exclusions.append({"path": path.relative_to(task).as_posix() + "/",
                                       "reason": "dependency_cache_target_or_fixture_payload_not_evidence"})
                else:
                    kept.append(entry)
            dirs[:] = kept
            for entry in sorted(files):
                path = Path(directory) / entry
                name = path_name(path.relative_to(task).as_posix())
                if name == SENSITIVE_OMISSION:
                    exclusions.append({"path": name,
                        "reason": "raw_host_status_omitted_known_private_runtime_field; not read or packaged"})
                    continue
                data = stable_bytes(path)
                if name.endswith(".tar.gz"):
                    nested[name] = inspect_nested_archive(name, data)
                else:
                    check_public_text(name, data)
                payloads[name] = data
    for name in ("run_validation.py", "retry_clippy.py", "retry_clippy02.py"):
        path = task / name
        if path.exists():
            payloads["runners/" + name] = stable_bytes(path)
    payloads["runners/package_evidence_v2.py"] = stable_bytes(Path(__file__).resolve())
    require(sum(map(len, payloads.values())) <= MAX_TOTAL, "retained records exceed archive size limit")
    return payloads, exclusions, nested


class Records:
    def __init__(self, payloads):
        self.payloads = payloads

    def raw(self, name):
        return self.payloads[path_name(name)]

    def json(self, name):
        return parse_json(self.raw(name))

    def member(self, name):
        data = self.raw(name)
        return {"path": name, "bytes": len(data), "sha256": digest(data)}

    def check_log(self, name, expected):
        actual = self.member(name)
        if expected is not None:
            require(actual["sha256"] == expected["sha256"]
                    and actual["bytes"] == expected["bytes"], "retained log differs: " + name)
        return actual


def exact_source(source):
    require(source["head"] == source["head_after"] == HEAD
            and source["tree"] == source["tree_after"] == TREE
            and source["clean_before"] is True and source["clean_after"] is True,
            "local source identity or clean status differs")


def remote_source(summary):
    require(summary["expected_head"] == HEAD and summary["expected_tree"] == TREE,
            "remote expected source differs")
    for when in ("before", "after"):
        identity = summary[when]
        require(identity["head"] == HEAD and identity["tree"] == TREE
                and identity["status"] == "" and identity["clean"] is True,
                "remote source identity or clean status differs")


def full_source_observation(records, name):
    value = records.json(name)
    require(value["schema"] == "trnm-ci-source-v1"
            and value["tested_commit"] == value["candidate"] == HEAD
            and value["tested_tree"] == TREE and value["tracked_worktree_verified"] is True
            and value["tracked_entries"] == 26171 and value["tracked_bytes"] == 2501252940
            and value["tests_executed_by_identity_check"] is False,
            "complete tracked-source observation differs: " + name)
    return {**records.member(name), "tracked_entries": 26171, "tracked_bytes": 2501252940,
            "tracked_worktree_verified": True, "tests_executed_by_identity_check": False}


def local_group(records, base):
    summary = records.json(base + "/summary.json")
    exact_source(summary["source"])
    rows, names = [], set()
    for row in summary["results"]:
        name = row["name"]
        require(name not in names, "duplicate local command name")
        names.add(name)
        require(type(row["exit_code"]) is int, "unfinished local command")
        logs = {kind: records.check_log(base + "/" + name + "." + kind, row["logs"][kind])
                for kind in ("stdout", "stderr")}
        stderr = records.raw(logs["stderr"]["path"]).decode()
        counts = [int(n) for n in re.findall(r"^Ran ([0-9]+) tests? in ", stderr, re.M)]
        outcomes = re.findall(r"^(?:OK(?: \(.*\))?|FAILED(?: \(.*\))?)$", stderr, re.M)
        require(counts == row["unittest_method_counts"] and outcomes == row["unittest_outcomes"],
                "unit-test summary differs from retained stderr: " + name)
        rows.append({"name": name, "argv": row["argv"], "exit_code": row["exit_code"],
                     "unittest_method_counts": counts, "unittest_outcomes": outcomes,
                     "logs": logs, "record": base + "/" + name + ".json"})
    require(summary["all_commands_exit_zero"] is all(row["exit_code"] == 0 for row in rows),
            "group exit-code summary differs")
    return summary, rows


def remote_commands(records, base, summary):
    rows = []
    for row in summary["commands"]:
        require(type(row["exit_code"]) is int, "unfinished remote command")
        item = {"name": row.get("name", Path(row["stdout"]).stem),
                "argv": row["argv"], "exit_code": row["exit_code"], "logs": {}}
        for kind in ("stdout", "stderr"):
            relative = path_name(row[kind])
            actual = records.check_log(base + "/" + relative, None)
            if kind + "_sha256" in row:
                require(actual["sha256"] == row[kind + "_sha256"], "remote log hash differs")
            if kind + "_bytes" in row:
                require(actual["bytes"] == row[kind + "_bytes"], "remote log size differs")
            item["logs"][kind] = actual
        rows.append(item)
    return rows


def python_observations(records):
    summary, rows = local_group(records, LOCAL + "/python")
    by_name = {row["name"]: row for row in rows}
    for name, count in SUITES.items():
        row = by_name[name]
        require(row["exit_code"] == 0 and row["unittest_method_counts"] == [count]
                and row["unittest_outcomes"] == ["OK"], "completed local suite differs: " + name)
    failed = by_name["test_repository"]
    require(failed["exit_code"] == -9 and failed["unittest_method_counts"] == []
            and failed["unittest_outcomes"] == [], "original interrupted suite observation differs")
    local_source = [full_source_observation(records, LOCAL + "/python/complete-source-" + when + ".stdout")
                    for when in ("before", "after")]
    remote = records.json(REMOTE_REPOSITORY + "/summary.json")
    require(remote["schema"] == "TRNM-W1-REMOTE-REPOSITORY-CONTROLS1", "remote suite schema")
    remote_source(remote)
    require(remote["host_alias"] == "desktop" and remote["complete_suite_passed"] is True
            and remote["test_exit_code"] == 0 and remote["repository_or_test_semantics_modified"] is False,
            "remote repository suite is incomplete or changed")
    commands = remote_commands(records, REMOTE_REPOSITORY, remote)
    tests = [row for row in commands if "scripts/ci/test_repository.py" in row["argv"]]
    require(len(tests) == 1 and tests[0]["exit_code"] == 0, "remote original test command differs")
    stderr = records.raw(tests[0]["logs"]["stderr"]["path"]).decode()
    require(re.findall(r"^Ran ([0-9]+) tests? in ", stderr, re.M) == ["50"]
            and re.findall(r"^(?:OK(?: \(.*\))?|FAILED(?: \(.*\))?)$", stderr, re.M) == ["OK"],
            "remote complete 50-method result not present in stderr")
    remote_sources = [full_source_observation(records, REMOTE_REPOSITORY + "/" + name + ".stdout")
                      for name in ("02-source-before", "04-source-after")]
    return {"local": {"host_alias": "managed_executor", "completed_suite_methods": sum(SUITES.values()),
                      "all_commands_exit_zero": summary["all_commands_exit_zero"], "checks": rows,
                      "complete_source_observations": local_source,
                      "interrupted_suite": {"name": "test_repository", "exit_code": -9,
                                            "completed_method_count": None, "signal": "SIGKILL",
                                            "signal_cause_established": False}},
            "remote_repository_suite": {"host_alias": "desktop", "completed_suite_methods": 50,
                "complete_suite_passed": True, "checks": commands,
                "complete_source_observations": remote_sources,
                "summary_record": REMOTE_REPOSITORY + "/summary.json"},
            "same_source_distinct_completed_method_count": 424,
            "completed_suite_count": 8,
            "coverage_scope": "Eight selected Python suites; not all repository tests or hosted CI.",
            "aggregation": "374 completed local methods plus the original 50-method suite on desktop; different hosts and attempts",
            "single_invocation_all_green": False, "original_failures_preserved": True,
            "new_field_and_route_methods": 38, "new_ci_contract_method": 1,
            "small_field_polynomial_cases_inside_methods": 789,
            "historical_results_added_to_current_method_count": False}


def graph_observations(records, root):
    base = LOCAL + "/graph-recovery"
    p3 = records.json(base + "/plonky3.metadata.retry01.run.json")
    require(p3["exit_code"] == 0 and p3["resolve_present"] is True
            and p3["metadata_package_count"] == p3["resolved_node_count"] == 74
            and p3["registry_package_count"] == 73 and p3["head_tree_locks_tracked_status_unchanged"] is True,
            "complete local P3 graph observation differs")
    for identity in (p3["before"], p3["after"]):
        require(identity["head"] == HEAD and identity["tree"] == TREE
                and identity["tracked_status"] == "", "P3 graph source identity differs")
    for kind in ("stdout", "stderr"):
        name = base + "/" + Path(p3[kind]).name
        require(records.member(name)["sha256"] == p3[kind + "_sha256"], "P3 graph log hash differs")
    metadata = records.json(base + "/plonky3.metadata.retry01.stdout.json")
    require(len(metadata["packages"]) == len(metadata["resolve"]["nodes"]) == 74, "P3 raw resolve graph differs")
    prepared = records.json(base + "/cache-preparation.json")
    post = records.json(base + "/post-metadata-cache-verification.json")
    require(prepared["repo_head"] == HEAD and prepared["archive_content_matches_lock"] is True
            and prepared["source_bytes_compared_to_archive_members"] is True
            and len(prepared["packages"]) == 73 and post["status"] == "UNCHANGED"
            and post["differences"] == [] and post["verified_archive_pairs"] == 73,
            "P3 retained archive/source-byte correspondence differs")
    lock = tomllib.loads((root / "formal/pon-nakamoto-v1/w1_public_stark_research/Cargo.lock").read_text())
    checksums = {row["name"] + "@" + row["version"]: row.get("checksum") for row in lock["package"]}
    require(all(row["archive_sha256"] == checksums[row["package"]] for row in prepared["packages"]),
            "P3 recorded archive checksums do not match frozen lock")
    risc = records.json(REMOTE_RISC + "/summary.json")
    require(risc["status"] == "COMPLETE_LOCKED_OFFLINE_GRAPH_VERIFIED"
            and risc["final_offline_exit_code"] == 0 and risc["resolve_present"] is True
            and risc["metadata_package_count"] == risc["resolved_node_count"] == 193
            and risc["registry_package_count"] == risc["locked_registry_archives_verified"] == 188
            and risc["head_tree_clean_lock_unchanged"] is True, "remote RISC graph observation differs")
    for identity in (risc["before"], risc["after"]):
        require(identity["head"] == HEAD and identity["tree"] == TREE and identity["status"] == "",
                "remote RISC graph source identity differs")
    remote_commands(records, REMOTE_RISC, risc)
    metadata = records.json(REMOTE_RISC + "/metadata-final-offline.stdout")
    require(len(metadata["packages"]) == len(metadata["resolve"]["nodes"]) == 193, "RISC raw resolve graph differs")
    archives = records.json(REMOTE_RISC + "/locked-archive-checksums.json")
    risc_lock = tomllib.loads((root / "formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock").read_text())
    risc_checksums = {(row["name"], row["version"]): row.get("checksum") for row in risc_lock["package"]}
    require(len(archives) == 188 and all(row["matching_archive"] and all(
        item["sha256"] == row["lock_checksum"] == risc_checksums[(row["name"], row["version"])]
        for item in row["matching_archive"]) for row in archives),
        "RISC retained archive checksum observation differs")
    return {"plonky3": {"host_alias": "managed_executor", "resolved_nodes": 74,
                "registry_packages": 73, "archive_and_extracted_source_bytes_verified_in_retained_record": True,
                "record": base + "/plonky3.metadata.retry01.run.json"},
            "risc_zero": {"host_alias": "desktop", "resolved_nodes": 193, "registry_packages": 188,
                "locked_archive_checksums_verified_in_retained_record": True,
                "record": REMOTE_RISC + "/summary.json"},
            "initial_local_missing_cache_failures_preserved": True,
            "archive_payloads_reincluded": False, "new_archive_payload_hashing_claimed": False,
            "metadata_resolution_is_compilation_or_proof_execution": False}


def clippy_observations(records, original, final_path, startup_path):
    attempts = [{"attempt": "local_original", "host_alias": "managed_executor",
                 "exit_code": original["exit_code"], "record": original["record"],
                 "diagnostic": "ENOSPC reported by compiler; original stderr retained"}]
    require(original["exit_code"] == 101, "original Clippy failure differs")
    require(b"No space left on device" in records.raw(original["logs"]["stderr"]["path"])
            or b"no space left on device" in records.raw(original["logs"]["stderr"]["path"]),
            "original ENOSPC diagnostic missing")
    base = LOCAL + "/clippy-retry-01"
    retry = records.json(base + "/summary.json")
    exact_source(retry["source"])
    require(retry["exit_code"] == 101 and retry["argv"] == original["argv"], "first Clippy retry differs")
    for kind in ("stdout", "stderr"):
        records.check_log(base + "/strict-clippy." + kind, retry["logs"][kind])
    require(b"SIGKILL" in records.raw(base + "/strict-clippy.stderr"), "first retry SIGKILL diagnostic missing")
    attempts.append({"attempt": "local_retry_01", "host_alias": "managed_executor", "exit_code": 101,
                     "record": base + "/summary.json", "diagnostic": "compiler SIGKILL; cause not established"})
    startup = records.json(startup_path)
    # Parent records the wrapper failure after it has completed. The build did
    # not start, so neither a compiler result nor successful source checks are inferred.
    require(startup.get("clippy_process_started") is False
            and startup.get("source_head") == HEAD
            and startup.get("status") == "STARTUP_FAILED"
            and startup.get("exception") == "FileNotFoundError",
            "retry02 did not explicitly record the observed source-bound startup failure")
    require(startup.get("exit_code", startup.get("wrapper_exit_code")) == 1,
            "retry02 wrapper exit differs")
    attempts.append({"attempt": "local_retry_02_startup", "host_alias": "managed_executor",
        "wrapper_exit_code": 1, "compiler_exit_code": None, "command_started": False,
        "record": startup_path, "diagnostic": "wrapper input snapshot FileNotFoundError; no Clippy invocation"})
    cancelled_base = "supporting-records/remote-clippy-cancelled/remote-clippy-eeeaafbc"
    cancelled_path = cancelled_base + "/cancellation-receipt.json"
    cancelled = records.json(cancelled_path)
    observation = records.json(cancelled_base + "/cancellation-observation.json")
    require(cancelled["classification"] == "CANCELLED_BEFORE_STRICT_CLIPPY_AFTER_PROVIDER_DOWNLOAD_TIMEOUTS"
            and cancelled["strict_clippy_executed"] is False
            and cancelled["terminal_state"]["state"] == "cancelled"
            and cancelled["terminal_state"]["cancelled"] is True
            and cancelled["terminal_state"]["exit_code"] == -15
            and cancelled["terminal_state"]["output_durable"] is True
            and observation["expected_head"] == HEAD and observation["expected_tree"] == TREE,
            "cancelled remote preparation observation differs")
    attempts.append({"attempt": "remote_provider_preparation_v1", "host_alias": "desktop",
        "state": "cancelled", "wrapper_exit_code": -15, "compiler_exit_code": None,
        "command_started": False, "record": cancelled_path,
        "diagnostic": "Two original download timeouts; owned preparation cancelled before Clippy. Public projection retained."})
    final = records.json(final_path)
    require(final["schema"] == "trnm-remote-strict-clippy-v1", "final remote Clippy schema differs")
    remote_source(final)
    require(final["host_alias"] == "desktop", "unexpected final Clippy host alias")
    base = str(PurePosixPath(final_path).parent)
    commands = remote_commands(records, base, final)
    builds = [row for row in commands if "clippy" in row["argv"] and "--workspace" in row["argv"]]
    require(builds, "no completed final strict Clippy command")
    build = builds[-1]
    reference = original["argv"][original["argv"].index("clippy"):]
    require(build["argv"][build["argv"].index("clippy"):] == reference,
            "final Clippy command weakened or changed flags")
    sources = [row for row in commands if "scripts/ci/verify_ci_source.py" in row["argv"]]
    require(len(sources) == 2 and all(row["exit_code"] == 0 for row in sources),
            "final remote Clippy lacks before/after full source checks")
    source_records = [full_source_observation(records, row["logs"]["stdout"]["path"]) for row in sources]
    for key in ("cargo_version", "rustc_version"):
        require("1.95.0" in final[key], "final Rust toolchain version differs: " + key)
    require(re.search(r"\bclippy 0\.1\.95\b", final["clippy_version"]) is not None
            or "1.95.0" in final["clippy_version"], "final Clippy version differs")
    require(final["provider_version"] == "3.5.9"
            and final["selected_build_inputs_equal_before_after"] is True
            and final["provider_inputs_equal_before_after"] is True,
            "final provider/tooling correspondence not established")
    attempts.append({"attempt": "remote_final", "host_alias": "desktop", "exit_code": build["exit_code"],
                     "record": final_path, "checks": commands, "complete_source_observations": source_records})
    return {"attempts": attempts, "effective_gate_passed": build["exit_code"] == 0,
            "effective_gate_record": final_path, "single_attempt_all_green": False,
            "failures_replaced_or_erased": False,
            "selected_input_identity_is_complete_compiler_closure": False}


def make_manifest(records, root, final_path, startup_path, exclusions, nested):
    python = python_observations(records)
    rust, rows = local_group(records, LOCAL + "/rust")
    by_name = {row["name"]: row for row in rows}
    for name in ("workspace-metadata-default", "workspace-metadata-all", "workspace-format", "p3-format"):
        require(by_name[name]["exit_code"] == 0, "required original observation differs: " + name)
    require(by_name["p3-metadata"]["exit_code"] != 0 and by_name["risc-v2-metadata"]["exit_code"] != 0,
            "original missing-cache failures were lost")
    old_path = f"validation/{HISTORICAL_HEAD}/python/summary.json"
    old = records.json(old_path)
    require(old["source"]["head"] == HISTORICAL_HEAD, "historical result relabelled")
    old_count = sum(sum(row["unittest_method_counts"]) for row in old["results"])
    require(old_count == 424, "historical method observation differs")
    clippy = clippy_observations(records, by_name["strict-clippy"], final_path, startup_path)
    return {"schema": "TRNM-W1-STARK-ROUTE-INSTANCE-EVIDENCE2",
        "created_utc": datetime.now(timezone.utc).isoformat(), "baseline_commit": BASELINE,
        "tested_code_commit": HEAD, "tested_code_tree": TREE,
        "evidence_commit_scope": "Evidence is added after validation; the later evidence commit is not relabelled as the tested source.",
        "python": python,
        "rust": {"original_local_all_commands_exit_zero": rust["all_commands_exit_zero"],
                 "original_local_checks": rows, "graph_recovery": graph_observations(records, root),
                 "strict_clippy": clippy},
        "historical_observations": {"commit": HISTORICAL_HEAD, "record": old_path,
                 "observed_method_count": old_count,
                 "original_summary_all_commands_exit_zero": old["all_commands_exit_zero"],
                 "added_to_current_method_count": False,
                 "scope": "Historical results only; not transferred to the later source."},
        "archive": {"path": "records.tar.gz", "members": [records.member(name) for name in sorted(records.payloads)],
                    "nested_record_archive_members": nested, "excluded_inputs": exclusions,
                    "policy": "Only retained text observations, runners, and inspected record archives; no dependency/cache/target/fixture binary payloads.",
                    "private_host_inventory_collected_by_packager": False},
        "counting_rule": "Distinct completed suites on the frozen source only; retries, historical 424, interrupted partial tests and 789 inner cases are not added.",
        "claim_scope": {"fixed_field_parameter_certificates": True, "source_route_correspondence": True,
            "compiled_field_arithmetic_equivalence_proved": False, "native_proof_execution_claimed": False,
            "complete_stark_soundness_qualified": False, "post_quantum_security_qualified": False,
            "quantum_extractor_qualified": False, "recursive_composition_qualified": False,
            "production_qualified": False, "consensus_admission": False,
            "unconditional_security_bits": None, "whole_lifetime_failure_bound": None},
        "historical_obligations": {"roster_entries": 15, "pinned_version_correspondence_subobligations_closed": 1,
            "other_historical_obligations": 14, "full_security_obligations_discharged": 0,
            "open_implementation_interfaces": 8},
        "hosted_ci_completion_verified": False, "publication_status_at_packaging": "NOT_YET_PUSHED",
        "disposition": "FIXED_ALGEBRA_AND_SOURCE_MAPPING_REPRODUCED_COMPLETE_SECURITY_HOLD"}


def readme(manifest):
    clippy = manifest["rust"]["strict_clippy"]
    final = clippy["attempts"][-1]
    rows = ["| Scope | Host | Observed result |", "|---|---|---|"]
    rows += ["| Seven completed Python suites | Managed executor | 374 methods, OK without skips |",
             "| Original local repository suite | Managed executor | SIGKILL (-9); no completed-suite count |",
             "| Same original repository suite, later run | Desktop | 50 methods, OK without skips |",
             "| Workspace metadata default/all; workspace/P3 formatting | Managed executor | Exit 0 |",
             "| Original P3/RISC metadata attempts | Managed executor | Missing-cache failures retained |",
             "| P3 locked graph recovery | Managed executor | 74 resolved nodes; 73 registry archives and extracted bytes checked in retained records |",
             "| RISC locked graph recovery | Desktop | 193 resolved nodes; 188 registry archive checksums checked in retained records |",
             "| Strict Clippy, original | Managed executor | Exit 101; ENOSPC |",
             "| Strict Clippy, retry 01 | Managed executor | Exit 101; compiler SIGKILL, cause unknown |",
             "| Strict Clippy, retry 02 wrapper | Managed executor | Exit 1 before compiler launch; input snapshot FileNotFoundError |",
             "| Original remote provider preparation | Desktop | Cancelled (-15) after two download timeouts; Clippy had not started |",
             f"| Strict Clippy, final supplementary attempt | Desktop | Exit {final['exit_code']}; effective gate passed: {str(clippy['effective_gate_passed']).lower()} |"]
    return (f"""# W1 fixed field certificates and separate route audit

Status: **complete security HOLD**. Finite algebra and fixed source correspondence
do not supply a complete STARK/QROM theorem, quantum extractor, recursive
composition, lifetime error bound, or production/consensus admission.

## Frozen source and completed coverage

- Baseline: `{BASELINE}`.
- Tested code: `{HEAD}`.
- Tested tree: `{TREE}`.
- The complete tracked-source observations before and after the final local
  Python run each verified **26,171 entries / 2,501,252,940 bytes**, clean.
- The remote original 50-method suite has the same complete before/after source
  checks. These are source-identity checks, not additional tests.
- Completed current-source method coverage is **374 + 50 = 424**, across
  **eight selected Python suites, different hosts and attempts**. This does
  not count every repository test or hosted CI, and is not one all-green invocation. The
  interrupted local suite is retained and contributes no completed-suite count.
- The earlier 424-method run on `{HISTORICAL_HEAD}` remains historical evidence
  and is not added to current coverage. The 789 small-field polynomial cases
  are inside existing methods. New field/route methods are 38, plus one new
  CI-contract method.

""" + "\n".join(rows) + f"""

Successful supplemental runs do not overwrite the original failures. Metadata
resolution, archive checksums, formatting, compiler linting, and native proof
execution are separate observations. The final Clippy record preserves the
original flags, Rust 1.95.0 and selected provider 3.5.9 inputs; selected input
identity is not a complete compiler-closure proof.

## Records and interpretation

The [manifest](manifest.json) indexes every archived record by byte count and
SHA-256, including the individual members of nested record archives. The
[raw records](records.tar.gz) retain runs, stdout/stderr, summaries, available
runners, historical observations, fixture-cleanup records and failures.
Dependency caches, build targets and fixture binary payloads are excluded.
The raw Hepta host-status observation is explicitly omitted because it includes
private runtime metadata; no omitted value is reproduced in this evidence.

Archive SHA-256: `{manifest['archive']['sha256']}`.

The [instance audit](../../docs/security/W1_STARK_ROUTE_INSTANCE_AUDIT_V1.md)
and [literature review](../../docs/protocol/pon-nakamoto-v1/details/STARK_THREE_ROUTE_LITERATURE_20261109.md)
state the exact scope. The historical roster retains 15 IDs: one pinned-version
correspondence sub-obligation closed, 14 other historical obligations, zero
fully discharged security obligations, and eight open implementation interfaces.
All PQ/extraction/recursion/production/admission qualifications remain false;
complete security bits and lifetime budget remain null. Hosted-CI completion and
publication were not established by this packaging operation. The evidence
directory is written after validation and does not relabel its own future
commit as tested code.
""").encode()


def git(root, *args):
    return subprocess.check_output(["git", "--no-optional-locks", *args], cwd=root, text=True).strip()


def clean_frozen_source(root):
    require(git(root, "rev-parse", "HEAD") == HEAD and git(root, "rev-parse", "HEAD^{tree}") == TREE,
            "packaging checkout is not the frozen code")
    require(git(root, "status", "--porcelain=v1", "--untracked-files=all") == "",
            "packaging checkout must be clean before adding evidence")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-root", type=Path, default=TASK)
    parser.add_argument("--repository", type=Path)
    parser.add_argument("--clippy-final-summary", required=True,
                        help="Task-relative public remote Clippy summary; requires completed records.")
    parser.add_argument("--clippy-start-failure", required=True,
                        help="Task-relative retained local retry02 startup-failure JSON.")
    args = parser.parse_args()
    task = args.task_root.resolve(strict=True)
    root = (args.repository or task / "chain-stark-work").resolve(strict=True)
    clean_frozen_source(root)
    output = root / EVIDENCE
    require(not output.exists(), "create-only evidence directory already exists")
    payloads, exclusions, nested = collect_records(task)
    records = Records(payloads)
    manifest = make_manifest(records, root, path_name(args.clippy_final_summary),
                             path_name(args.clippy_start_failure), exclusions, nested)
    # Construct all three files away from the repository. No evidence directory
    # is created unless every source/result/log/record check above succeeds.
    with tempfile.TemporaryDirectory(prefix="w1-evidence-package-", dir=task) as directory:
        archive = Path(directory) / "records.tar.gz"
        with archive.open("xb") as raw:
            with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
                with tarfile.open(fileobj=compressed, mode="w") as tar:
                    for name, data in sorted(payloads.items()):
                        item = tarfile.TarInfo(name)
                        item.size, item.mode, item.mtime = len(data), 0o644, 0
                        tar.addfile(item, io.BytesIO(data))
        archive_bytes = archive.read_bytes()
        manifest["archive"].update(bytes=len(archive_bytes), sha256=digest(archive_bytes))
        deliverables = {"records.tar.gz": archive_bytes, "manifest.json": json_bytes(manifest),
                        "README.md": readme(manifest)}
        clean_frozen_source(root)
        # Re-read every original selected record to catch concurrent completion
        # or log changes after collection; do not silently package an old view.
        for name, data in payloads.items():
            if name.startswith(("validation/", "supporting-records/")):
                require(stable_bytes(task / name) == data, "retained record changed before publication: " + name)
        output.mkdir(exist_ok=False)
        for name, data in deliverables.items():
            with (output / name).open("xb") as stream:
                stream.write(data)
    print(json.dumps({"path": str(output), "tested_code_commit": HEAD, "tested_code_tree": TREE,
                      "archive_bytes": len(archive_bytes), "archive_sha256": digest(archive_bytes),
                      "archive_member_count": len(payloads), "same_source_distinct_completed_methods": 424,
                      "single_invocation_all_green": False,
                      "effective_strict_clippy_gate_passed": manifest["rust"]["strict_clippy"]["effective_gate_passed"],
                      "production_qualified": False}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (EvidenceError, OSError, KeyError, TypeError, UnicodeError, tarfile.TarError,
            json.JSONDecodeError, subprocess.CalledProcessError) as error:
        raise SystemExit("Evidence packaging refused: " + str(error))
