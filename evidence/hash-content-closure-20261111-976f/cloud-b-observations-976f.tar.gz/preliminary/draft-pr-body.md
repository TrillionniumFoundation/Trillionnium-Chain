## Why this change is needed

The existing CCH1, TCM2/TCC2 and CST1/CMG1 adapters already read and bind actual content. Their declared scopes do not cover a recursively typed model dependency graph or every retained State from genesis to a checkpoint. Hashing an old SHA-256 digest again cannot recover distinctions already lost by the old commitment. The current hash-purpose source map also retains a stale selected-proof-profile file pin.

This draft is stacked on **#908**. **Whole-chain qualification remains HOLD_NO_GO; security/lifetime bounds remain unknown and production activation remains false.**

## What changes

- **TCG3 typed declared graph.** Verify each complete CCH1 node before parsing its actual encoded edges, then traverse every reachable payload and dependency. Bind full contexts and claims; reject ambiguous identities, known containers disguised as leaves, missing content, incomplete EOF and shared-subtree depth bypasses. A cumulative caller budget is reserved before resolver/open, including failures. The grammar has explicit structural and byte limits.
- **CMH2 bounded full-state ancestry readback.** Stream actual genesis State/configuration and each complete Header, trace and State through the selected checkpoint. Check the existing root/parent relations and match an independently retained complete CCH1 expectation. The native owner uses one actual SQLite read transaction, preflights source dimensions before State materialization, retains the existing packet/state checks, and verifies zero writes. More than 32 non-genesis blocks or 32 MiB is refused, never silently truncated.
- **Keep security games and ownership separate.** Preserve all original 17 hash-use definitions and add two narrow uses, for 19 uses and 31 source paths. Repair the stale profile pin after reading its actual bytes. Rebind the existing seven-route/44-path authority register to the reviewed runtime checkpoint; only the parent `store.rs` module export changes in that curated roster.
- **Extend the existing gates.** Retain the previous component/vector/native checks, add graph vectors and Node-history tests in default/all-feature configurations, extend strict Clippy to the Node owner, and preserve every previous corpus requirement while adding the new sources.

## Source and validation status

| Source | Commit | Scope |
| --- | --- | --- |
| Parent C5 | `6ac9a79c2fb37d6102c526c354fe2d448a9f4e6d` | Existing #908 candidate; original observations retained. |
| Runtime checkpoint A | `55c0d0ea1330d80120754718f2f47f6a4a709aa3` | New format, owner, tests and reviewed scope additions. |
| Binding checkpoint B | `9fd6ee29a7a663cef547040d9d42cc36a371a17e` | Reviewed authority source bindings; original hash JSON field order restored without changing canonical semantics. |

B tree: `7351f83fa9ac5c0e7540fa64bce06ea6f328602f`.

**Exact committed-source validation is in progress. Native repair validation is pending.** The original command recorder is checking B's complete tracked bytes before and after each recorded gate. Results will retain their actual source, command, exit and log identities.

The preliminary, uncommitted TCG3 run returned **101: 15/16 passed and one failed**. Its new known-container negative control exposed missing legacy container prefixes; the production list is now repaired, with the original failing log/source snapshot retained. This is a real draft implementation defect and failure, not a claimed failure of the existing V2 adapters. The repaired native run has not yet been assigned a passing result.

The reviewed precommit hash-purpose suite passed 33 tests and the retained authority suite passed 18. Independent Python graph framing passed with 9 objects / 3 nodes / 15 edges. The isolated pinned OpenSSL 3.5.9 build completed its actual ML-DSA-65 signing, verification and rejection smoke. These preliminary observations are separate from the pending exact-source native/default/all-feature/Clippy records.

Parent #908 C5 remains **overall FAIL, 62/64 native controls passed**: `pnq2-42` and `cleanup-01` returned 101. This change does not relabel those failures or inherit S3's earlier passing execution.

## Remaining boundaries

TCG3 closes its explicitly declared typed graph; it does not discover arbitrary executable, JSON, plugin or loader references. CMH2 covers a finite complete Header/trace/State/configuration history; it does not include transaction/proof/receipt bodies, external objects referenced by State, or effect/revocation journals. Source-dimension limits, encoded-byte budgets and cooperative deadlines have distinct scopes and do not establish a hard RSS limit.

Historical provenance, independent custody/freshness, current adoption authority, source retirement, complete long-chain migration, W1/DAA quantum security and the lifetime composition bound remain unestablished. The candidate adds no production cutover, finality, CURRENT or FinalUse authority.
