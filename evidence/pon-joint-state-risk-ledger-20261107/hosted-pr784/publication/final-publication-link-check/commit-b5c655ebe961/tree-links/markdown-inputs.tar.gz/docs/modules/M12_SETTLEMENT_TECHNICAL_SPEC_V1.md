# M12 Finite reward, service fees and free-use conservation

Revision: invariant-driven revision3. Selected target: `pon-nakamoto-v1`.
[Sole development plan](../development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md); [exact invariant registry](../../config/pon/invariants-v2.json).

## Scope and ownership

Actual native/Python release and quota accounting, not external monetary value.

The claims below apply to their named component and tests, not to an independently accepted full native node.

## PoN State machine

### M12.ClaimContributionReward

Claims pay once under exact root membership; unclaimed budget refunds at a reserved deadline even if old candidates have retired. Publish reserves due capacity; claim updates balance/nullifier/remaining together; mandatory expiry returns remainder.

**Atomic/commit boundary:** Publish reserves due capacity; claim updates balance/nullifier/remaining together; mandatory expiry returns remainder.

### M12.ConsumeSponsoredQuota

Verify bound provider, deadline, positiveunits, prepaidfunds and consumer signature over provider nonce. Debit prepaid units*1024, pay fee and provider, leave consumer balance untouched. It does not imply learning/export permission.

**Atomic/commit boundary:** Atomic nativecommand transition; effects journal separately records actual delivery.

## M12.FiniteReleaseLiability

**Invariant:** Claims pay once under exact root membership; unclaimed budget refunds at a reserved deadline even if old candidates have retired. Terminal tasks/quotas can retire after deadline without allowing a new nonce to recreate their identity or reuse old consumer consent.

**Scope:** Actual native/Python release and quota accounting, not external monetary value.

**Atomic boundary:** Publish reserves due capacity; claim updates balance/nullifier/remaining together; mandatory expiry returns remainder. Task/quota IDs bind genesis context, creator, creation nonce and the complete reserved parameters; remaining-zero retirement occurs only after deadline.

**Failure schedule:** Maturity and claim deadline; Repeated proof with new nonce; Unclaimed budget; Empty old release retirement.

**Expected result:** Claims pay once under exact root membership; unclaimed budget refunds at a reserved deadline even if old candidates have retired. Terminal tasks/quotas can retire after deadline without allowing a new nonce to recreate their identity or reuse old consumer consent.

**Resource and retention rule:** 20-block maturity plus1000-block claim window;16 due slots per height shared with tasks and quotas.

## Concrete regression selectors

`formal/pon-nakamoto-v1/test_native_execution.py::NativeExecutionTests.test_unclaimed_release_budget_refunds_at_reserved_deadline`

`formal/pon-nakamoto-v1/test_native_execution.py::NativeExecutionTests.test_three_signed_release_generations_preserve_payout_and_retirement`

`formal/pon-nakamoto-v1/test_native_execution.py::NativeExecutionTests.test_terminal_task_retirement_cannot_reopen_same_resource_id`

`formal/pon-nakamoto-v1/test_native_execution.py::NativeExecutionTests.test_spent_quota_retirement_preserves_consent_identity`

These exact functions contain executable assertions. The registry only checks binding; actual outcomes and source/input identities belong to the separate qualification report.

## Module-specific threat and residual work

Replay, uncompensated liabilities, expiry starvation, sponsor self-traffic and orphaned external payouts.

Funded GPU capacity, market sustainability, fee adaptation and independent economic acceptance remain absent.

M09's disposable TCL3 cache allowance is not an M12 funding or paid-retention
reservation. Actual cache row deletion may return that cache's logical allowance
only; it cannot retire an acknowledged duty, clear a retained-byte/byte-block
claim, release an Unknown effect or refund funds. Physical DB/WAL/SHM/temp/output
composition remains an existing PN4 obligation.

The [five-lane PN4 reference](../development/specs/pon/REWARD_BUDGETS_V1.md)
separates existing mining rewards, sponsor-funded contribution, evaluation,
storage/repair and serving budgets, including their distinct resource units.
Its executable conservation and external-intent fork controls do not verify
native funding or add a native settlement/undo adapter.

The same specification now defines a native Node increment using the existing
single-writer metadata store: actual signed-history escrow observation, bounded
local resource obligations and monotonic global operation/effect intent records.
It neither locks on-chain funds nor executes payment or external effects. Resource
measurements and source-local caps remain protected-owner inputs; worker-meter
integration, payment/undo and independent economics are still required.

## Current source and verification

- [`formal/pon-nakamoto-v1/ledger.py`](../../formal/pon-nakamoto-v1/ledger.py).
- [`trillionnium/crates/trnm-mvcc-fee/src/pon_executor.rs`](../../trillionnium/crates/trnm-mvcc-fee/src/pon_executor.rs).

No test binding or local campaign grants independent acceptance, ordinary Hepta execution or production activation. Preserve the exact source, profile and environment of every outcome.

## Executed evidence and scope

[Responsibility-level evidence navigation](README.md#responsibility-and-evidence) reads
measured commits from immutable receipts. The module's entries in
[module-maturity-v1.json](../../config/pon/module-maturity-v1.json) identify actual callable
owners, controlled entrypoints, backends, persistence and exact observed test selectors.
Run `python3 scripts/ci/report_module_evidence.py --module M12` from the repository
root to see subject-byte and complete recorded-runtime matches separately, plus scenarios
not observed in each package. A byte match is not a new test run or product acceptance.
Historical v1/v3/v4 results are never repinned. The sole plan selects further work.

## Frozen evaluation and consent continuation

See [E3](../protocol/pon-nakamoto-v1/details/EVALUATION_BUNDLE.md) for exact bytes,
owner boundaries and failure schedules. No public export or future-window authority
is created by a frozen artifact. The following additional regressions are executable:

- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::SettlementObservationTests.test_mutating_both_summary_and_evaluator_score_does_not_authorize_reward`.
- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::SettlementObservationTests.test_zero_marginal_candidate_creates_no_ledger_or_reward`.
- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::SettlementObservationTests.test_undeclared_bundle_cannot_be_read_from_summary_as_authority`.

## Mandatory expiry receipts through the native cache

Funded task/quota/release expiry emits its canonical receipt before ordinary transaction receipts. The existing native session preserves and verifies this prefix, including empty blocks and mixed 16-expiry/transaction blocks. This does not change subsidy, fees or durable ownership.

- `formal/pon-nakamoto-v1/test_native_session.py::ExpiryAndBudgetTests.test_sixteen_expiry_receipts_precede_same_block_transaction`.
- `formal/pon-nakamoto-v1/test_native_session.py::ExpiryAndBudgetTests.test_empty_expiry_block_runs_through_real_ledger_and_restart`.
- `formal/pon-nakamoto-v1/test_native_session.py::ExpiryAndBudgetTests.test_expiry_receipt_drop_reorder_and_substitution_cannot_be_rehashed`.
- `formal/pon-nakamoto-v1/test_native_session.py::ExpiryAndBudgetTests.test_real_quota_and_release_expiry_share_existing_receipt_semantics`.

## Native development continuation and remaining scope

ECONOMICS now isolates the first-two ordering counterexample and the required versioned complete-set/deadline/dispute contract. Native byte parity preserves existing revision3 accounting rather than silently altering rewards. Independent resource funding and the successor policy remain open.

The current callable mappings remain in `config/pon/module-maturity-v1.json`.
Exact native entry, storage and work behavior is specified by N3 in NETWORK_CLIENT,
the native continuation in STATE_RECOVERY and the prepared-producer section in WORK_PROFILE.
No historical receipt is relabelled as executing this source.

The existing frozen evaluator and settlement producer also bind the versioned empirical
accuracy/marginal-value/bound statement in MODEL_EVALUATION. Its canonical replay rejects
false prospective/general-circuit authority and numeric aliases. A perfect empirical
score proves only that fixed accuracy objective, not public reward eligibility or model
safety. Revision3 first-two attestation arrival semantics remain unchanged and unqualified.

## Complete-evaluator successor and reward conservation

The explicit revision4 policy in [MODEL_EVALUATION](../protocol/pon-nakamoto-v1/details/MODEL_EVALUATION.md)
changes when an attested score is complete, not the release budget, fee, maturity,
claim-nullifier or conservation algorithm. Pending and zero-valued rounds cannot publish
or mint model rewards. Complete positive controlled rounds exercise publish, maturity,
exact claim and duplicate rejection through both existing implementations.

Selector: `formal/pon-nakamoto-v1/test_evaluation_round.py::ClosedRoundTests.test_complete_round_can_publish_mature_and_claim_exactly_once`.
This does not establish real model benefit, functional-copy fairness or funded GPU service.
