# 9eda 原失败 campaign：三个报告的来源绑定成本读取

**原结果仍为 `ORIGINAL_THREE_RUN_CAMPAIGN_FAILED`：三次 native 命令都 exit 101，三个 attempt 的全部九个 phase 均未满足原标准。** 本目录只重读已经完成的历史原报告，没有运行新的 native campaign，也没有把当前源码测试结果归入历史执行。

## 来源与核验

原执行 head：`9eda0ada15be1702269e08e527917568c710f4d3`；tree：`6b2437a1224683464c68a540fc59ff7c8eccdaa3`。GitHub [run 42201852774](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42201852774) 的 job `127838794285` 由 [API jobs](api/api-workflow-run-jobs.json) 核对为 completed/failure。原 artifact `13495362625` 为 65,440,211 bytes，SHA256 `24ba87d4e957a9dc99a64177e4410b5a0da9208a3c00a637b43dc629e5d9a55b` 与 [API artifact digest](api/api-workflow-run-artifacts.json) 一致。

[readback receipt](readback-receipt.json) 保留所有原成员、输入、输出和命令摘要。已逐一检查三个报告的原 `report_sha256`、原 artifact-files manifest 对应摘要、各 before/after source 相等、三次命令 stdout/stderr 的大小与摘要、原 build logs，以及 ZIP 内原 binary 的前后摘要。原 source receipts 与原 command logs 原字节保留；这些检查建立材料一致性，不扩大为独立执行见证。

成本读取器来自 commit `0bca28ebf59058b6aba9db5eb956c4479556e9ee`，tree `06e394f20b8f491c4ea1f91a357e2b6e8a4c0812` 的五个实际 Git blobs，随 [reader-source manifest](reader-source-manifest.json) 和 `reader-source/` 一同保留。三个读取命令都 exit 0；**reader 的成功仅表示可以读取这些失败报告，不能改变原 native failure。**

## 原分母、History 与 Host checkpoint

原输入仍是三种 mode、每 phase 30 秒、每 phase 3 轮确认、business_blocks=21、seed_blocks=4、seed_transfers=1024。外层资源条件和 receiver/verifier 的固定 public parent 限制均见 [原 results](original/results.json)，没有修改原预算、截止时间或成功标准。

下表逐 attempt／phase 保留分母。History CPU 与墙钟为读取器在该 phase 内对已观察 import 调用求和；每个 import 的独立 epoch 和完整 native snapshot 仍保留。Host checkpoint CPU 与 import spans 重叠，不能相加得到总 CPU。

| Attempt | Phase | Attacker ready/requested | 已观察/计划确认轮 | 已确认 | 未观察计划轮 | Imports | Import caller CPU s | Import wall s | Checkpoint 次数 | Checkpoint CPU s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | baseline | 0/0 | 2/3 | 1 | 1 | 10 | 5.608424 | 24.513365 | 108,280 | 4.733887 |
| 1 | from-zero | 24/24 | 1/3 | 0 | 2 | 5 | 2.350091 | 24.772219 | 40,150 | 1.987533 |
| 1 | late-product | 24/24 | 1/3 | 0 | 2 | 5 | 2.270588 | 24.680986 | 38,470 | 1.913207 |
| 2 | baseline | 0/0 | 2/3 | 1 | 1 | 11 | 5.732164 | 24.992497 | 111,294 | 4.834430 |
| 2 | from-zero | 24/24 | 1/3 | 0 | 2 | 5 | 2.371827 | 24.781233 | 40,747 | 2.014220 |
| 2 | late-product | 24/24 | 1/3 | 0 | 2 | 5 | 2.287922 | 24.301943 | 39,070 | 1.935244 |
| 3 | baseline | 0/0 | 2/3 | 1 | 1 | 11 | 5.717683 | 24.980441 | 111,097 | 4.830542 |
| 3 | from-zero | 24/24 | 1/3 | 0 | 2 | 5 | 2.381222 | 24.692869 | 40,873 | 2.017396 |
| 3 | late-product | 24/24 | 1/3 | 0 | 2 | 5 | 2.322260 | 24.806500 | 40,018 | 1.971998 |

对应完整读数：[run 1](coverage/run-1-cost-coverage.json)、[run 2](coverage/run-2-cost-coverage.json)、[run 3](coverage/run-3-cost-coverage.json)。[summary.json](summary.json) 另保留所有确认轮原读数、逐 import 成败与 epoch、receiver/listener 成本和 unknown 字段；没有跨 attempt 或跨 phase 拼接时间轴。

## Baseline 首个 depth 6 确认

三个原 round 的 `observation.confirmed=true`、`depth=6`，且 `confirmed_inside_pressure_window=true`。以下严格使用该 round 的 `ended_ns - started_ns`，不把 phase 起点到结束的偏移当成确认时长。原 observation 的 `finalized=false`、`execution_authority=false` 也在 summary 中保留。

| Attempt | started_ns | ended_ns | 差值 ns | 确认时长 s |
| --- | ---: | ---: | ---: | ---: |
| 1 | 1000180134 | 22386924469 | 21386744335 | 21.386744335 |
| 2 | 1000529151 | 21983710910 | 20983181759 | 20.983181759 |
| 3 | 1001461637 | 21982414832 | 20980953195 | 20.980953195 |

**F0 不在该 artifact 内。** 本归档仅包含原 baseline／from-zero／late-product campaign，不提供或推断 F0 结果，也不与其他 source 的 F0 或后续验收拼接。

## 每个固定 public parent 的 Host 样本

以下仅相减该 phase 自己的 before/after 样本。CPU usage 与 throttling 各有自己的语义；throttled duration 不是可追加的执行 CPU。完整上下文、PID、cgroup 和原样本保留在 coverage；memory/pids 只作为时点样本，不称为峰值。

| Attempt | Phase | CPU usage delta s | Periods delta | Throttled periods delta | Throttled duration delta s |
| --- | --- | ---: | ---: | ---: | ---: |
| 1 | baseline | 8.137381 | 339 | 320 | 37.465491 |
| 1 | from-zero | 8.652507 | 348 | 343 | 87.861625 |
| 1 | late-product | 8.655224 | 350 | 345 | 89.498414 |
| 2 | baseline | 8.225230 | 342 | 326 | 37.939513 |
| 2 | from-zero | 8.657858 | 347 | 346 | 87.891845 |
| 2 | late-product | 8.562165 | 346 | 339 | 88.421813 |
| 3 | baseline | 8.220981 | 339 | 326 | 38.894983 |
| 3 | from-zero | 8.644579 | 346 | 346 | 87.774203 |
| 3 | late-product | 8.633876 | 346 | 345 | 88.155749 |

## PQ 与仍未测量的成本

全部九个 listener epoch 的 PQ attempts、bytes、calling-thread CPU 都是原始明确的 0；`missing_fields=[]`、`pq_authentication_unavailable=false`。这些零值没有覆盖 PQ 认证负载，不能据此声称 PQ 很便宜或已通过完整业务验收。

全部 phase 的完整 pipeline CPU、物理网络字节、磁盘增长、payload transfer CPU、cold recovery CPU、request peak RSS 均仍为 `null`。没有将未知改为零，也没有把嵌套的 phase、receiver、History、Host CPU 相加。不同 source 或不同 epochs 的结果不用于归因性能改善。

## 三份完整原报告与重算

下面 gzip 的 mtime 固定为 0，解压后逐字节匹配原 ZIP member，并匹配原 `results.json` 中每次 report SHA256。完整 65 MB ZIP 另由下载 receipt 定位，不在此 compact carrier 内重复保存。

| Attempt | 无损原报告 | 原 JSON bytes | 原 JSON SHA256 |
| --- | --- | ---: | --- |
| 1 | [original/run-1-report.json.gz](original/run-1-report.json.gz) | 30,978,427 | `4d7aca4b9330138851c3933ec5040850f8082ea57c9f036167b77d8a2f8b4345` |
| 2 | [original/run-2-report.json.gz](original/run-2-report.json.gz) | 31,224,270 | `cb8f24bb13d674debb07982bb7fc02922a4eaf8c019ca0d9d631530eb26fc872` |
| 3 | [original/run-3-report.json.gz](original/run-3-report.json.gz) | 31,217,499 | `73493ff58dcd83bb9c7c66005d401a12c454d48f1b8b6c56bf8dab1d5f25810f` |

可在全新输出目录重算三个成本文件：

```sh
python3 -B recompute.py /tmp/pon-9eda-cost-recompute
```

[recompute.py](recompute.py) 先验证本 carrier manifest，再检查解压后的原报告摘要，运行保留的精确 reader，并要求三个输出 SHA256 与已有读数一致。它不启动 node、不下载依赖、不覆盖既有证据。`prepare_cost_readback.py` 和 `finalize_carrier.py` 仅保留本次组装过程；其原绝对路径由 receipt 记录，迁移后的直接重算入口是上述 `recompute.py`。

本归档不能证明当前 0bca 或后续 source 的 native 性能、生产资格或完整六项改造完成。
