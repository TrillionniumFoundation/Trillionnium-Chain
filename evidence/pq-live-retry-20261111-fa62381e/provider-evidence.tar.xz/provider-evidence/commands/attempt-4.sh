python3 - <<'PY_PREPARE_OFFICIAL_PROVIDER_FA62381E'
from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path('/tmp/chain-pq-fa62381e-s1-check')
os.chdir(root)
subprocess.run(['bash','scripts/project-preflight.sh','--audit'],check=True)
archive=Path('/tmp/chain-pq-fa62381e-provider/source-via-gh/openssl-3.5.9.tar.gz')
if not archive.is_file() or archive.is_symlink():
 raise SystemExit('retained pinned source archive is unavailable')
with archive.open('rb') as stream:
 archive_sha=hashlib.file_digest(stream,'sha256').hexdigest()
if archive_sha!='603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a':
 raise SystemExit('retained source archive digest mismatch')
print(json.dumps({'verified_retained_source_archive':str(archive),'sha256':archive_sha,'bytes':archive.stat().st_size}),flush=True)
helper=root/'scripts/ci/prepare_pq_provider.sh'
expected='ccdcf7e8bb9871607c73adc78624a607b616c227b7fe581b96c48761a3805bfa'
actual=hashlib.sha256(helper.read_bytes()).hexdigest()
if actual!=expected:
 raise SystemExit('official provider helper digest mismatch: '+actual)
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
if not re.fullmatch('[0-9a-f]{40}',source):
 raise SystemExit('noncanonical source')
sys.dont_write_bytecode=True
sys.path.insert(0,str(root/'scripts/ci'))
from verify_ci_source import verify
from ci_observation import run
before=verify('head',source,root=root)
out=Path('/tmp/chain-pq-fa62381e-provider/attempt-4-gh-source')
out.mkdir()
runner=out/'runner'
receipts=out/'receipts'
runner.mkdir()
receipts.mkdir()
env_file=out/'github-env'
env_file.open('x').close()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
os.environ.update(RUNNER_TEMP=str(runner),GITHUB_ENV=str(env_file),
                  TRNM_CI_RECEIPT_DIR=str(receipts),CARGO_BUILD_JOBS='2',
                  PYTHONDONTWRITEBYTECODE='1')
os.environ['TRNM_PQ_SOURCE_ARCHIVE']=str(archive)
observation=run(['bash','scripts/ci/prepare_pq_provider.sh'],
                out/'preparation-owner.log',cwd=root,timeout=2700,
                expected_source=source)
(out/'preparation-execution.json').write_text(json.dumps(observation,indent=2)+'\n')
after=verify('head',source,root=root)
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
print(json.dumps({'source':source,'helper_sha256':actual,'execution':observation,
                  'source_unchanged':before==after,'environment_file':str(env_file)},sort_keys=True))
provider=receipts/'pq-provider/provider.json'
if provider.is_file():
 value=json.loads(provider.read_text())
 print(json.dumps({'provider_receipt':str(provider),'provider':value},sort_keys=True))
if before!=after:
 raise SystemExit(125)
raise SystemExit(observation['exit_code'])
PY_PREPARE_OFFICIAL_PROVIDER_FA62381E