#!/usr/bin/env python3
"""Package already completed static receipts; no tests, builds or source writes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess

ROOT = Path('/workspace/scratch/1eed767ad985')
REPO = ROOT / 'chain-throughput-base-sync-5689'
OUT = ROOT / 'ci-validation/composed-source-7586d3e2'
HEAD = '7586d3e209b38246402e34cf73a27aa9b907bc9c'
TREE = 'fc0e51b1235470b972de41f2d677f6d5948f4868'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')


original_manifest = OUT / 'artifacts.sha256'
manifest_sha = digest(original_manifest)
verified = []
for line in original_manifest.read_text().splitlines():
    expected, relative = line.split('  ', 1)
    path = OUT / relative
    assert not path.is_symlink() and path.is_file()
    assert path.resolve().is_relative_to(OUT.resolve()) and digest(path) == expected
    verified.append(relative)

observed = json.loads((OUT / 'summary.json').read_text())
assert observed['result'] == 'PASS'
assert observed['tested_commit'] == HEAD and observed['tested_tree'] == TREE
assert observed['source_before_equals_after'] and observed['lockfiles_unchanged']
assert observed['prior_summaries_unchanged'] and observed['capture_helper_unchanged']
assert all(row['passed'] for row in observed['checks'].values())
tests = {label: {'tests': row['tests'],
                 'process_exit': row['execution']['native_exit'],
                 'capture_exit': row['execution']['log_exit'],
                 'terminal_stderr_summary': row['terminal_summary']}
         for label, row in observed['checks'].items() if 'tests' in row}
assert len(tests) == 11
assert all(row['process_exit'] == row['capture_exit'] == 0
           and row['terminal_stderr_summary'] == 'OK' for row in tests.values())
count = sum(row['tests'] for row in tests.values())
assert count == observed['unittest_cases_observed']

driver_prefix = ROOT / 'validation/composed-source-7586-driver'
driver = json.loads(Path(str(driver_prefix) + '.result.json').read_text())
assert driver['native_exit'] == driver['log_exit'] == 0 and driver['spawn_error'] is None
driver_out = OUT / 'driver'
driver_out.mkdir()
copied = []
for suffix in ('.stdout', '.stderr', '.log', '.streams.jsonl', '.command.json', '.result.json'):
    source = Path(str(driver_prefix) + suffix)
    target = driver_out / source.name
    data = source.read_bytes()
    with target.open('xb') as stream:
        stream.write(data)
    assert source.read_bytes() == data and target.read_bytes() == data
    copied.append({'source': str(source), 'copy': target.relative_to(OUT).as_posix(),
                   'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
for source in (ROOT / 'validation/launch_composed_source_7586.py', Path(__file__)):
    target = driver_out / source.name
    data = source.read_bytes()
    with target.open('xb') as stream:
        stream.write(data)
    assert source.read_bytes() == data and target.read_bytes() == data
    copied.append({'source': str(source), 'copy': target.relative_to(OUT).as_posix(),
                   'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})

def output_json(label):
    return json.loads((OUT / (label + '.stdout')).read_text())

integration = output_json('pq-source-integration')
assert integration['status'] == 'HOLD_NO_GO' and integration['exact_source_blobs'] == 593
hold = output_json('pq-hold')
assert hold['status'] == 'HOLD' and hold['whole_chain_pq_qualified'] is False
authority = output_json('pq-authority-report')
assert authority['status'] == 'HOLD_INCOMPLETE_AUTHORITY_TRACING'
assert authority['whole_chain_pq_qualified'] is False
repository = output_json('repository-and-markdown-links')
assert repository['result'] == 'PASS' and repository['head'] == HEAD and repository['tree'] == TREE
corpus = json.loads((REPO / 'config/pon/pq-cross-branch-corpus-v1.json').read_text())
assert len(corpus['pinned_blobs']) == 593 and len(set(corpus['required_paths'])) == 512
inventory = (REPO / 'trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs').read_text()
names = re.findall(r'^        "([^"]+)",$', inventory, re.M)
assert len(names) == len(set(names)) == 1271
assert (OUT / 'source-inventory.stdout').read_text().strip() == 'distributed source inventory: PASS'
parents = subprocess.check_output(['git', 'show', '-s', '--format=%P', HEAD], cwd=REPO, text=True).split()
assert parents == ['285982d78a4f62a064841cb0f106d18c865e19c5', '56897f125df27994efa1dda935f2c62eceb36de9']

summary = {
    'schema': 'trnm-composed-source-static-final-v2', 'result': 'PASS',
    'scope': '11 Python source/claim/CI/repository suites, source/inventory/Markdown/format and three offline locked Cargo graphs on one committed source; no Rust build, native test or Clippy',
    'generated_utc': datetime.now(timezone.utc).isoformat(),
    'tested_commit': HEAD, 'tested_tree': TREE, 'ordered_parents': parents,
    'actual_python_cases': count, 'tests': tests,
    'source_before_after_equal': True, 'source_receipt': observed['source_before']['receipt'],
    'lockfiles': observed['locks_after'], 'lockfiles_unchanged': True,
    'metadata': observed['metadata'],
    'format': {'process_exit': observed['checks']['format']['execution']['native_exit'],
               'toolchain_receipt': 'formatter-toolchain.stdout'},
    'repository_and_markdown': repository,
    'pq_source_integration': integration, 'pq_claim_guard': hold,
    'pq_authority_scan': authority, 'required_source_paths': 512,
    'distributed_inventory_entries': 1271,
    'original_summary': {'path': 'summary.json', 'sha256': digest(OUT / 'summary.json')},
    'original_artifact_manifest': {'path': 'artifacts.sha256', 'sha256': manifest_sha,
                                   'verified_files': len(verified)},
    'driver_process_exit': driver['native_exit'], 'driver_capture_exit': driver['log_exit'],
    'driver_snapshots': copied,
    'historical_summaries_unchanged': True,
    'historical_summary_hashes': observed['prior_summary_hashes_after'],
    'prior_results_credited_as_fresh_head': False,
    'full_repository_truth_lane_executed': False,
    'native_build_test_clippy_executed': False,
}
write_json(OUT / 'final-summary.json', summary)
assert digest(original_manifest) == manifest_sha
files = sorted(path for path in OUT.rglob('*') if path.is_file())
assert all(not path.is_symlink() for path in files)
with (OUT / 'artifacts-final.sha256').open('x') as stream:
    stream.write(''.join(digest(path) + '  ' + path.relative_to(OUT).as_posix() + '\n' for path in files))
print(json.dumps({'result': summary['result'], 'actual_python_cases': count,
                  'final_summary_sha256': digest(OUT / 'final-summary.json'),
                  'final_manifest_sha256': digest(OUT / 'artifacts-final.sha256'),
                  'manifest_entries': len(files), 'output': str(OUT)}, sort_keys=True))
