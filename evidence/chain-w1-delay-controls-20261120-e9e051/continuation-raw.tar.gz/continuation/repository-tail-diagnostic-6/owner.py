from pathlib import Path
import os,sys,json,time,resource,subprocess,hashlib,shlex,re
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/resume-20261120-e9e051/source');out=src.parent/'repository-tail-diagnostic-6';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);(out/'temp').mkdir()
env=dict(os.environ,PATH='/home/qq/.cargo/bin:'+os.environ['PATH'],RUST_TEST_THREADS='1',TMPDIR=str(out/'temp'),TRNM_CI_RECEIPT_DIR=str(out/'receipts'))
assert os.stat(out/'temp').st_dev==os.stat(src).st_dev
res={'schema':'chain-original-final-tail-diagnostic-v1','complete':False,'complete_repository_truth_passed':False,'prior_failures_preserved':True,'f0_repeated':False,'commands':[]}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=src,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);text=(out/(name+'.stderr')).read_text(errors='replace')
 row={'name':name,'argv':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime,'python_test_summaries':re.findall(r'Ran [0-9]+ tests in .*|FAILED .*|^OK$',text,re.M)};res['commands'].append(row);save();print(json.dumps(row),flush=True)
 return rc
assert run('preflight',['bash','scripts/project-preflight.sh'])==0
raw=(src.parent.parent/'repository-tail-diagnostic-75/original-tail.sh').read_text();marker='    python3 scripts/ci/pq_lifetime_composition.py\n';assert raw.count(marker)==1
suffix=raw[raw.index(marker):];(out/'original-final-suffix.sh').write_text(suffix);res['suffix_sha256']=hashlib.sha256(suffix.encode()).hexdigest();save()
commands=[line.strip() for line in suffix.splitlines() if line.strip() and not line.lstrip().startswith('#')]
assert all(line.startswith('python3 ') and not line.endswith('\\') for line in commands)
for n,line in enumerate(commands):run(f'{n:02}-'+Path(shlex.split(line)[-1]).name,shlex.split(line))
res['complete']=True;res['remaining_commands_attempted']=len(commands);res['failed_commands']=[r['name'] for r in res['commands'] if r['exit_code']];save();print(json.dumps({'complete':True,'commands':len(commands),'failed':res['failed_commands'],'complete_repository_truth_passed':False}),flush=True)
sys.exit(1 if res['failed_commands'] else 0)
