import hashlib,json,os,shutil,sys,time,traceback
from pathlib import Path
ROOT=Path("/tmp/trnm-resource-current52-original-20261116-c0mq1616")
REPO=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo")
OUT=ROOT/"qualification"
record={"schema":"trnm.hia.resource-current52-original-reconciled-evidence.v1","status":"FAIL","started_unix_ns":time.time_ns(),"prior_wrapper_job":"1a1e4200b8b-392-3638","prior_wrapper_terminal_exit":1,"prior_wrapper_failure":"KeyError('stage') after actual qualifier returned 0","original_execution_rerun":False}
def check(ok,msg):
 if not ok:raise ValueError(msg)
def ident(p):
 h=hashlib.sha256();n=0
 with p.open("rb") as f:
  while raw:=f.read(1048576):h.update(raw);n+=len(raw)
 return {"bytes":n,"sha256":h.hexdigest()}
(ROOT/"reconcile_evidence_v1.py").write_text(sys.orig_argv[sys.orig_argv.index("-c")+1])
try:
 prior=json.loads((ROOT/"execution.json").read_bytes())
 check(prior["failure"]=="KeyError('stage')" and "source_fence_failure" not in prior,"Different first failure")
 stage=next(row for row in prior["stages"] if row["label"]=="actual-resource-qualifier")
 check(stage["exit_code"]==0 and stage["timed_out"] is False,"Actual qualifier did not exit successfully")
 check(ident(ROOT/"actual-resource-qualifier.stdout")==stage["stdout"] and ident(ROOT/"actual-resource-qualifier.stderr")==stage["stderr"],"Qualifier logs changed")
 sys.path.insert(0,str(REPO))
 from hia.platform.host_resource.rust_oracle import complete_source_manifest,original_manifest
 sources=complete_source_manifest();original=original_manifest(REPO)
 check(sources==prior["source_inputs_before"]==prior["source_inputs_after"] and len(sources)==52,"Current52 source identity")
 check(original==prior["original_sources_before"]==prior["original_sources_after"] and len(original)==4361,"Original source identity")
 native=json.loads((OUT/"native/physical/report.json").read_bytes())
 comparison=json.loads((OUT/"native/native-comparison.json").read_bytes())
 actual=json.loads((OUT/"original/report.json").read_bytes())
 check(native["status"]=="PASS" and native["semantic_count"]==172 and native["physical_control_count"]==11 and native["count"]==183,"Native183 not complete")
 check(native["build"]["source_inputs"]==sources==comparison["source_inputs"]==actual["source_inputs"],"Native/original source bindings")
 check(actual["status"]=="PASS" and actual["controls"]==172 and actual["operations"]==180 and actual["failed"]==0 and actual["source_inputs_stable"],"Actual original comparison failure")
 check(actual["original_sources"]==original==comparison["original_sources"],"Actual unchanged original inputs")
 check(any("44 passed; 0 failed" in row for row in actual["retained_original_summary"]),"Missing retained44")
 stages=actual["stages"]
 check(len(stages)==5 and all(row["exit_code"]==0 and not row["timed_out"] for row in stages),"Actual original5 process stages failed")
 for row in stages:
  matches=[]
  for p in (OUT/"original").glob("*/receipt.json"):
   if json.loads(p.read_bytes())==row:matches.append(p)
  check(len(matches)==1,"Original process receipt not unique")
  parent=matches[0].parent
  for stream in ("stdout","stderr"):
   check(ident(parent/(stream+".raw"))=={"bytes":row[stream+"_bytes"],"sha256":row[stream+"_sha256"]},"Original raw process log identity")
 controls=json.loads((OUT/"original/comparison.json").read_bytes())["controls"]
 check(len(controls)==172 and all(row["status"]=="PASS" and row["native"]["name"]==row["original"]["name"] and row["native"]["comparison"]==row["original"]["comparison"] for row in controls),"Actual172 comparison differs")
 raw=(OUT/"original/actual-original-resource-corpus/stdout.raw").read_text()
 emitted=[json.loads(line.split("HIA_HOST_RESOURCE_ORACLE:",1)[1]) for line in raw.splitlines() if "HIA_HOST_RESOURCE_ORACLE:" in line]
 check([r["original"] for r in controls]==emitted,"Original reports do not match actual Rust stdout")
 retained=(OUT/"original/retained-original-host-tests/stdout.raw").read_text()
 for name in actual["required_original_tests"]:check("test "+name+" ... ok" in retained,"Required original test absent "+name)
 list_stage=next(row for row in stages if row["argv"][1:]==["--list"])
 binary=Path(list_stage["argv"][0])
 check(ident(binary)==actual["executable"],"Original Node executable changed")
 dest=ROOT/"original-test-binary"
 with binary.open("rb") as src,dest.open("xb") as dst:shutil.copyfileobj(src,dst,1048576)
 check(ident(dest)==actual["executable"]==ident(binary),"Independent actual binary copy differs")
 check(complete_source_manifest()==sources and original_manifest(REPO)==original,"Source changed during independent capture")
 record.update(status="PASS",original_source_set_sha256=prior["original_source_set_sha256"],source_set_sha256=prior["source_set_sha256"],source_inputs=sources,original_sources=original,actual_qualifier_process=stage,actual_original_process_stages=stages,native_controls=183,native_semantic=172,native_physical=11,native_trace=native["trace"],actual_original_cases=172,actual_original_operations=180,retained_original_summary=actual["retained_original_summary"],actual_rustc=actual["compiler"],independent_binary={"path":str(dest),**ident(dest)},native_report=ident(OUT/"native/physical/report.json"),native_comparison=ident(OUT/"native/native-comparison.json"),original_report=ident(OUT/"original/report.json"),original_comparison=ident(OUT/"original/comparison.json"),exact_corpus=actual["exact_corpus"],prior_wrapper_record=ident(ROOT/"execution.json"),production_fixed_parent_positive_qualified=False,full_node_or_paid_account=False)
except BaseException as e:
 record["failure"]=repr(e);record["traceback"]=traceback.format_exc()
finally:
 record["finished_unix_ns"]=time.time_ns()
 p=ROOT/"reconciled-evidence-v1.json";p.write_text(json.dumps(record,sort_keys=True,indent=2)+"\n")
 print(json.dumps({"status":record["status"],"report":str(p),"identity":ident(p),"failure":record.get("failure"),"independent_binary":record.get("independent_binary")}),flush=True)
sys.exit(0 if record["status"]=="PASS" else 1)
