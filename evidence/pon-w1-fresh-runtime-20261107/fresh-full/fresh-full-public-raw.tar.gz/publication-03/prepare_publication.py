#!/usr/bin/env python3
"""Create an explicit public allowlist; never include private database copies."""
import collections
import hashlib
import json
import os
from pathlib import Path
import stat

ROOT=Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
BASE=ROOT/'full-A-terminal-analysis-01'
OUT=BASE/'publication-03'

def require(ok,message):
    if not ok:raise ValueError(message)

def raw_file(path):
    before=path.lstat();require(stat.S_ISREG(before.st_mode),'ordinary evidence file')
    raw=path.read_bytes();after=path.lstat()
    require(all(getattr(before,k)==getattr(after,k)for k in('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')),'stable evidence bytes')
    return {'path':str(path.relative_to(BASE)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},raw

def write(path,raw):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb')as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())

def save(path,v):write(path,(json.dumps(v,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())

def main(v):
    require(not OUT.exists(),'one new public preparation')
    finalpin,b=raw_file(BASE/'completion-02/manifest.json')
    require(finalpin['sha256']=='fe92bab8243cda81a3070de63b5b96e4a9db145efd34f0d74bafc03a558f103c' and json.loads(b)['analysis_complete']is True,'fixed successful analysis')
    OUT.mkdir();write(OUT/'prepare_publication.py',SCRIPT_TEXT.encode())
    for name,raw in v['connector_raw'].items():
        require(name.endswith('.json')and '/'not in name,'fixed connector name');json.loads(raw)
        write(OUT/'connector'/name,raw.encode())
    old=json.loads((BASE/'original-file-inventory.json').read_bytes())['files']
    inventory=[];excluded=[]
    for row in old:
        path=Path(row['path']);relative=str(path.relative_to(ROOT))
        out={'path_relative_to_experiment_root':relative,'bytes':row['bytes'],'sha256':row['sha256']}
        retained=row.get('retained_copy')
        if retained:
            require('private-analysis-only'not in Path(retained).parts,'no private DB raw retention');out['public_small_raw_copy']=retained
        else:
            if path.suffix=='.sqlite':category='private_database_bytes_excluded'
            elif path.name=='process-samples.jsonl':category='large_raw_process_trace_host_only'
            elif path.suffix=='.bin':category='intermediate_execution_or_seal_bytes_host_only'
            else:category='host_metadata_or_uncopied_raw'
            out['raw_exclusion']=category;excluded.append(out)
        inventory.append(out)
    save(OUT/'relative-original-inventory.json',{'schema':'TRNM-W1-A-RELATIVE-ORIGINAL-INVENTORY1','files':inventory,
        'inventory_is_metadata_not_full_raw':True,'private_database_bytes_published':False})
    save(OUT/'excluded-original-raw.json',{'schema':'TRNM-W1-A-EXCLUDED-RAW1','files':excluded,
        'reason':'Only the selected final proofs, inputs and bounded small raw records are public; large process traces/intermediate seals remain on the original host. Private Node/M12 database copies are excluded entirely.'})
    omitted={BASE/'original-file-inventory.json',BASE/'completion-02/publishable-file-inventory.json'}
    allow=[]
    for p in sorted(BASE.rglob('*')):
        if not p.is_file()or 'private-analysis-only'in p.parts or p in omitted:continue
        require(p.suffix not in('.sqlite','.db')and not p.name.endswith(('-wal','-shm','-journal')),'database bytes forbidden in public selection')
        require('secret'not in p.name.lower()and 'private-key'not in p.name.lower()and 'credentials'not in p.name.lower(),'private credential file forbidden')
        pin,_=raw_file(p);allow.append(pin)
    result={'schema':'TRNM-W1-A-PUBLICATION-MANIFEST1','root':str(BASE),'public_only':True,'analysis_complete':True,
        'analysis_manifest':finalpin,'files':allow,'file_count':len(allow),'total_bytes':sum(x['bytes']for x in allow),
        'full_original_raw_archive':False,'original_inventory_rows':len(inventory),'raw_excluded_files':len(excluded),
        'raw_exclusion_counts':dict(collections.Counter(x['raw_exclusion']for x in excluded)),
        'explicitly_excluded':['private-analysis-only/**','original-file-inventory.json (replaced by relative inventory)',
                               'completion-02/publishable-file-inventory.json (superseded by this explicit allowlist)'],
        'private_node_databases_or_keys_published':False,
        'packaging_rule':'Copy only files[] from this root after matching each size/SHA; add this manifest itself by its separately retained SHA. Never archive the whole directory.',
        'proof_count':{'fresh_full':2,'funded':1,'unfunded':1},
        'raw_scope':'Two final succinct.bin files and fixed inputs; core controller/postwin/native-winner/owner reports, stage declarations/results/logs, checkpoint event journal/manifest, source guards, analysis scripts and public funding rows. Process samples and intermediate execution/seal binaries are represented by relative path and SHA only.'}
    save(OUT/'manifest.json',result)
    p,_=raw_file(OUT/'manifest.json');print(json.dumps({'manifest':p,'file_count':result['file_count'],'total_bytes':result['total_bytes'],
        'raw_exclusion_counts':result['raw_exclusion_counts'],'full_original_raw_archive':False}))

if __name__=='__main__':main(INPUT_PAYLOAD)
