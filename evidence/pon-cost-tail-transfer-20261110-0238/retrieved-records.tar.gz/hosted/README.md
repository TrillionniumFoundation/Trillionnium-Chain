# Recovered exact-source hosted observations

Source 6fac9cddd982ce4e26197ca23e39490604422370; tree c5d38dbd45d13fa0f591cc925076836fd38b84b6. Baseline Actions run 42744740973 completed with failure.

Head repository-truth job 129594036242 and prospective-merge repository-truth job 129594036300 both passed. Each independently records all 18 new tail-transfer methods, 20 retained frontier methods and 16 fixed-probability methods passing once. Their before/after immutable source checks match 26,183 entries and 2,502,732,567 bytes. The prospective merge is 2905e52749253bd50e7ce52f9d75de87fd62944a with the same tree. Separate lanes are not pooled into a larger method count.

Head runtime Rust shard 129594036107 passed. Head quality shard 129594036264 failed during dependency policy checking. The retained 607,219-byte original quality artifact ZIP matches GitHub's SHA256; all declared supply-chain member hashes were verified. Both native workspace and fuzz dependency graphs report RUSTSEC-2026-0459 for libsqlite3-sys. The shard's initial cargo fmt completed; subsequent doctests, Clippy and native release controls were not reached. This does not certify overall Rust quality.

Head protocol-contract job 129594036196 failed after native build preparation succeeded. Its controller reports passed=false, systemd_run_exit=1, failure=null and final_host_errors=[]. A unique phase cause is not established from that controller. The complete protocol campaign artifact was not inspected in this recovery.

Parent run 42629494778 has the same observed failure categories: quality dependency refusal and protocol controller passed=false/systemd_run_exit=1. These observations do not prove a unique inherited cause or exclude another failure. Parent dependency artifact was not inspected.

The baseline job snapshot also retains successful fuzz, external-evidence, all four W1 actual-reuse V3 lanes, and failed protocol/quality/cross-architecture from-zero service/fan-in lanes. The whole baseline is not green. See analysis.json for exact job URLs, complete statuses, focused test identifiers and source observations.

Decoded job logs are exact UTF-8 connector text, not original raw GitHub log ZIP bytes. API snapshots are parsed and normalized JSON. No previously lost local test stream or receipt has been recreated. This packet supplies hosted execution evidence, not an all-legal-W1 cost theorem or production qualification. HOLD_NO_GO remains.
