from owner_evidence_lib import BASE, ROOT, Package, identity
import json, subprocess

work = BASE / 'work-race-next/work'
package = Package('work-handshake')
regression = json.loads((work / 'full-readback/qualification-full/report.json').read_bytes())
race = json.loads((work / 'rog-v1/qualification-v1/report.json').read_bytes())
assert regression['status'] == race['status'] == 'PASS'
for name in ('qualification-rog-v1-complete.tar.xz', 'qualification-full-complete.tar.xz',
             'remote-input-v1.tar.xz', 'remote-input-final.tar.xz'):
    package.file('complete-observations/' + name, work / name)
package.file('original-build.tar.xz', ROOT / 'hia/qualification/work-handshake-original-build.tar.xz')
included = {'first-fixed-build': package.directory('first-fixed-build', work / 'build-fixed/build')}
package.snapshot('source-snapshots/final', regression['source_inputs'], ROOT)
package.snapshot('source-snapshots/integration', regression['final_root_snapshot']['files'], ROOT)
original_sources = race['build_source_inputs']['original']
for name, info in original_sources.items():
    data = subprocess.run(['git','show','88dd3c4afa80fd87284f4a114e3868ee6c5d4ed4:' + name],
                          cwd=ROOT, check=True, stdout=subprocess.PIPE).stdout
    assert identity(data) == info, name
    package.data('source-snapshots/original/' + name, data)
for name in ('frozen-owned-v1.json', 'isa-source-delta.json', 'clock-2199-same-input.json',
             'qualification-rog-v1-readback.json', 'qualification-full-readback.json',
             'handshake-original-build-identity.json', 'final-root-snapshot.json',
             'remote-run-v1-request.json', 'remote-run-v1-start.json',
             'remote-full-request.json', 'remote-full-start.json', 'remote-full-start-retry.json',
             'remote-full-status-and-logs.json', 'remote-full-download.json',
             'remote-input-v1-identity.json', 'remote-input-v1-transfer.json',
             'remote-input-final-identity.json', 'remote-input-final-transfer.json',
             'run-remote-v1.py', 'run-remote-full.py', 'qualify-prebuilt.py', 'readback-full.py',
             'readback-full.stdout.raw', 'readback-full.stderr.raw',
             'build-fixed.stdout.raw', 'build-fixed.stderr.raw', 'build-final.stdout.raw', 'build-final.stderr.raw',
             'final-snapshot-preflight.stdout.raw', 'final-snapshot-preflight.stderr.raw'):
    package.file('provenance/' + name, work / name)
for stem in ('work-handshake-final-readback','work-handshake-race-readback'):
    for suffix in ('.json','.stdout.raw','.stderr.raw','.execution.json'):
        package.file('root/' + stem + suffix, BASE / (stem + suffix))
for name in ('read_work_regression.py','read_work_handshake.py'):
    package.file('root/' + name, BASE / name)
included['root-reader-first-failure'] = package.directory('historical/root-reader-first-failure', BASE / 'work-handshake-reader-first-failure')
included['local-ptrace-denial'] = package.directory('historical/local-ptrace-denial', work / 'qualification-local-v1')
for suffix in ('.stdout.raw','.stderr.raw'):
    package.file('historical/local-ptrace-denial' + suffix, work / ('qualification-local-v1' + suffix))
package.file('historical/github-5a-work-diagnostics.zip', BASE / 'work5a-diagnostics.zip')
package.file('historical/github-5a-work-native.zip', BASE / 'work5a-native.zip')
package.finish({'schema':'trnm.hia.work-handshake.final-evidence-package.v1',
    'qualification':'complete-observations/qualification-rog-v1-complete.tar.xz',
    'native_full_regression':'complete-observations/qualification-full-complete.tar.xz',
    'race_cases':24,'original_races_reproduced':4,'fixed_races':4,'invalid_state_controls':16,
    'regression':{'primitive_controls':175,'primitive_calls':9489,'semantic_histories':61,'semantic_progress_points':27843,
                  'actual_traces':3,'trace_reader_controls':27,'signal_reader_controls':14,'actual_clock_faults':18},
    'executed_host':'rog','source_inputs':135,'included_directories':included,
    'old_build_source_snapshot_from_verified_git_objects':'88dd3c4afa80fd87284f4a114e3868ee6c5d4ed4',
    'actual_original_Rust_reexecuted':False,'instruction_patching_in_qualification':False,
    'private_state_injection':'Only sixteen explicitly named invalid-state refusal controls; none in the eight normal old/new race cases.',
    'historical_limits':['The original 5a hosted CLOCK EIO-2199 failure is preserved as an actual failure with its entire original ZIP.',
                         'Local ptrace refusal is not relabeled as a runtime pass; the configured ROG host executed the complete cases.',
                         'The first root full-archive reader compared its roster against only a subdirectory, omitting three real outer members; corrected complete archive admission reran and passed.',
                         'Initial read-only race-reader import and nested build-path mistakes are retained as source variants; the final actual reader receipt is separate.',
                         'The remote full start RPC timeout and interrupted download retain their actual receipts; reconciliation used the same idempotency key and artifact version.'],
    'production_fixed_parent_authority':False,'whole_Node_or_paid_checkpoint_closed':False,
    'original_4s_16_service_gate_closed':False,'whole_chain_native':False,'old_stack_can_be_removed':False,
    'production_activation':False})
