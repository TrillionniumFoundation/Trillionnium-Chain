#!/usr/bin/env python3
"""Observe one previously cancelled C1 operation from a new process."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
REPO = ROOT / 'integration-repo'
COMMIT = 'cb557c5e59b00ba7c6b1d40f78fbe51031a26f11'
TREE = '7971aca2ff432ec8907bb69545a2c58d70b4a215'
CPUS = [8, 9, 10, 11, 20, 21, 22, 23]
SELECTOR = 'store::async_w1_generation_v2::tests::heavy::funded_w1_owner_cancellation_cold_reconcile'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    path = Path(path)
    require(path.is_absolute() and path.is_file() and not path.is_symlink(), 'original ordinary file required')
    before = path.stat()
    require(before.st_nlink == 1, 'single-link original file required')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    after = path.stat()
    require(all(getattr(before, field) == getattr(after, field)
                for field in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')), 'file changed while hashing')
    return {'path': str(path), 'bytes': after.st_size, 'sha256': digest.hexdigest()}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--qualification', type=Path, required=True)
    parser.add_argument('--qualification-sha256', required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--config-sha256', required=True)
    args = parser.parse_args()
    qpin = pin(args.qualification)
    cpin = pin(args.config)
    require(qpin['sha256'] == args.qualification_sha256 and cpin['sha256'] == args.config_sha256,
            'original qualification/config bytes changed')
    q = json.loads(args.qualification.read_text())
    c = json.loads(args.config.read_text())
    require(q['schema'] == 'TRNM-W1-CLEAN-BUILD-QUALIFICATION1' and q['qualification_complete'] is True
            and q['source_commit'] == COMMIT and q['source_tree'] == TREE and q['repo_path'] == str(REPO),
            'actual C1 qualification required')
    require(c['expected_commit'] == COMMIT and c['expected_tree'] == TREE and c['repo'] == str(REPO)
            and c['clean_build_qualification'] == {'path': str(args.qualification), 'sha256': qpin['sha256']},
            'original config is not bound to this C1 qualification')
    original = Path(c['out'])
    prior_path = original / 'funded-owner-cancellation-result.json'
    prior_pin = pin(prior_path)
    prior = json.loads(prior_path.read_text())
    require(prior['schema'] == 'TRNM-W1-FUNDED-OWNER-CANCEL-RESULT1'
            and prior['explicit_owner_cancel_accepted'] is True and prior['real_expensive_generation_started'] is True
            and prior['new_complete_proofs'] == 0 and prior['original_provider_operation'] == c['provider_operation']
            and prior['original_deadline_ns'] == c['original_deadline_ns'], 'original completed cancellation observation required')
    owner = q['binaries']['owner_test']
    require(owner['kind'] == 'repository_build' and pin(owner['path']) == {k: owner[k] for k in ('path', 'bytes', 'sha256')}
            and owner['sha256'] == c['owner_test_binary_sha256'], 'qualified owner ELF changed')
    with Path(owner['path']).open('rb') as stream:
        require(stream.read(4) == b'\x7fELF', 'actual owner ELF required')
    def git(*argv):
        return subprocess.check_output(['/usr/bin/git', '-C', str(REPO), *argv], text=True).strip()
    require(git('rev-parse', 'HEAD') == COMMIT and git('rev-parse', 'HEAD^{tree}') == TREE
            and git('status', '--porcelain=v1', '--untracked-files=all') == '', 'C1 must remain clean')
    output = ROOT / 'owner-cancel-cold-readback-01'
    require(not output.exists(), 'new cold output required')
    launch = ROOT / 'owner-cancel-cold-launch-01'
    os.umask(0o077)
    launch.mkdir(exist_ok=False)
    with (launch / 'preflight.stdout').open('xb') as so, (launch / 'preflight.stderr').open('xb') as se:
        checked = subprocess.run(['/usr/bin/bash', 'scripts/project-preflight.sh', '--dev'],
                                 cwd=REPO, stdout=so, stderr=se, timeout=60, check=False)
    write(launch / 'preflight-result.json', {'argv': ['/usr/bin/bash', 'scripts/project-preflight.sh', '--dev'],
                                           'exit': checked.returncode, 'stdout': pin(launch / 'preflight.stdout'),
                                           'stderr': pin(launch / 'preflight.stderr')})
    require(checked.returncode == 0, 'cold preflight failed')
    os.sched_setaffinity(0, set(CPUS))
    membership = Path('/proc/self/cgroup').read_text().strip()
    require(membership.startswith('0::/') and '\n' not in membership, 'actual unified cgroup required')
    group = Path('/sys/fs/cgroup') / membership[3:].lstrip('/')
    require(group.name.startswith('hepta-runtime-job-') and group.name.endswith('.service'), 'actual Hepta scope required')
    quota, period = map(int, (group / 'cpu.max').read_text().split())
    require(quota == 8 * period and period > 0 and (group / 'memory.max').read_text().strip() == str(8 * 1024**3),
            'actual declared cold-observer allocation required')
    proc = Path('/proc/self/stat').read_text()
    argv = [owner['path'], SELECTOR, '--exact', '--ignored', '--nocapture', '--test-threads=1']
    write(launch / 'exec-intent.json', {'schema': 'TRNM-W1-OWNER-CANCEL-COLD-LAUNCH1',
        'source_commit': COMMIT, 'source_tree': TREE, 'qualification': qpin, 'config': cpin,
        'prior_cancellation_result': prior_pin, 'owner_binary': owner, 'argv': argv, 'cold_output': str(output),
        'pid': os.getpid(), 'parent_pid': os.getppid(), 'pid_start_ticks': int(proc[proc.rfind(')') + 2:].split()[19]),
        'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(), 'cgroup': str(group),
        'cpu_max': (group / 'cpu.max').read_text().strip(), 'memory_max': (group / 'memory.max').read_text().strip(),
        'affinity': sorted(os.sched_getaffinity(0)), 'observed_monotonic_ns': time.monotonic_ns(),
        'original_deadline_ns': c['original_deadline_ns'], 'original_boot_id': c['original_boot_id'],
        'original_operation': c['provider_operation'], 'proof_deadline_renewed': False,
        'outcome': 'NOT_YET_OBSERVED', 'handoff': 'same-PID os.execve into exact qualified C1 cold selector'})
    require(pin(args.config) == cpin and pin(args.qualification) == qpin, 'original inputs changed before exec')
    env = dict(os.environ, TRNM_W1_FUNDED_CONFIG=str(args.config), TRNM_W1_CANCEL_RECONCILE_OUT=str(output),
               PYTHONDONTWRITEBYTECODE='1')
    os.execve(owner['path'], argv, env)


if __name__ == '__main__':
    main()
