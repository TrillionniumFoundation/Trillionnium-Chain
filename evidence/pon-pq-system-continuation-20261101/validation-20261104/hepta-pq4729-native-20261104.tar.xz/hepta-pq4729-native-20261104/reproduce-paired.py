import pathlib,subprocess,hashlib,json,os,time
base=pathlib.Path('/home/qian-qi/worktrees/hepta-pq4729-validation-20261104');repo=base/'paired-source';identity=json.loads((base/'paired-source-identity.json').read_text());sha=identity['commit'];assert identity['checkout_exit']==0
env={**os.environ,'PATH':'/home/qian-qi/.cargo/bin:'+os.environ.get('PATH',''),'CARGO_TARGET_DIR':str(base/'paired-target'),'CARGO_BUILD_JOBS':'2','GIT_NO_LAZY_FETCH':'1'}
def verify(label):
 assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],env=env).decode().strip()==sha
 rows=subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','-z',sha],env=env).split(b'\0');manifest=[]
 for row in rows:
  if not row:continue
  meta,rawpath=row.split(b'\t',1);mode,kind,oid=meta.split();path=rawpath.decode();p=repo/path;assert kind==b'blob'
  data=os.readlink(p).encode() if mode==b'120000' else p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert actual==oid.decode(),path
  manifest.append({'path':path,'mode':mode.decode(),'git_blob':actual,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 encoded=json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()+b'\n'
 (base/('paired-complete-source-'+label+'.json')).write_bytes(encoded)
 return {**identity,'paths':len(manifest),'bytes':sum(x['bytes'] for x in manifest),'manifest_sha256':hashlib.sha256(encoded).hexdigest()}
source=verify('before');(base/'paired-source-before.json').write_text(json.dumps(source,indent=2)+'\n');print(json.dumps({'phase':'paired-complete-source','source':source}),flush=True)
for label,args in [('paired-contracts-native',['just','test','-p','codex-hepta-contracts','--locked']),('paired-contracts-strict-clippy',['just','clippy','-p','codex-hepta-contracts','--locked','--','-D','warnings'])]:
 log=base/(label+'.log');start=time.monotonic();print(json.dumps({'started':label,'argv':args,'source':sha,'target':env['CARGO_TARGET_DIR']}),flush=True)
 with log.open('wb') as out:
  result=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 data=log.read_bytes();after=verify('after-'+label);unchanged=after['manifest_sha256']==source['manifest_sha256']
 receipt={'label':label,'argv':args,'source':source,'returncode':result.returncode,'seconds':time.monotonic()-start,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'tracked_source_unchanged':unchanged,'native_attempt_not_retry':True,'source_after':after}
 (base/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
 if not unchanged:raise SystemExit(3)
print(json.dumps({'complete':True}),flush=True)