#!/usr/bin/env python3
"""Record actual commands against the complete committed source; never infer passes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/525798dad3c2/Trillionnium-Chain')
OUT = Path('/workspace/scratch/525798dad3c2/validation/frozen')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def snapshot():
    commit = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    status = git('status', '--porcelain=v1', '-z', '--untracked-files=all')
    if status:
        raise RuntimeError('source is not clean: ' + repr(status[:1000]))
    entries = []
    for line in git('ls-tree', '-r', '-z', '--full-tree', 'HEAD').split(b'\0'):
        if not line:
            continue
        meta, rawpath = line.split(b'\t', 1)
        mode, kind, expected = meta.decode().split()
        path = rawpath.decode()
        if kind != 'blob':
            raise RuntimeError('unsupported tracked type: ' + path)
        p = ROOT / path
        data = os.readlink(p).encode() if mode == '120000' else p.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if actual != expected:
            raise RuntimeError('tracked bytes differ: ' + path)
        entries.append(dict(path=path, mode=mode, blob=actual, bytes=len(data),
                            sha256=hashlib.sha256(data).hexdigest()))
    raw = json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()
    identity = hashlib.sha256(raw).hexdigest()
    path = OUT / ('source-' + identity + '.json')
    if not path.exists():
        path.write_bytes(raw + b'\n')
    return dict(commit=commit, tree=tree, entries=len(entries), bytes=sum(e['bytes'] for e in entries),
                source_sha256=identity, source_manifest=path.name)


def main():
    label, *command = sys.argv[1:]
    if not label.replace('-', '').replace('_', '').isalnum() or not command:
        raise SystemExit('label command...')
    OUT.mkdir(exist_ok=True)
    log = OUT / (label + '.log')
    receipt = OUT / (label + '.json')
    if receipt.exists() or log.exists():
        raise SystemExit('create-only receipt already exists')
    before = snapshot()
    start = time.time()
    with log.open('xb') as stream:
        process = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    after = snapshot()
    result = dict(schema='pon-demand-upgrade-command-observation-v1', command=command,
        cwd=str(ROOT), started_unix_seconds=start, elapsed_seconds=time.time() - start,
        exit_code=process.returncode, before=before, after=after,
        source_unchanged=before == after, log=log.name,
        log_bytes=log.stat().st_size, log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
        independent_acceptance=False, production_activation=False)
    receipt.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(label=label, exit_code=process.returncode,
                         elapsed_seconds=result['elapsed_seconds'], source_unchanged=result['source_unchanged'])))
    raise SystemExit(process.returncode if before == after else 3)


if __name__ == '__main__':
    main()
