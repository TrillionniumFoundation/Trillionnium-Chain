from pathlib import Path
import sys,ast,json,time,hashlib,traceback
root=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo")
base=root.parent/"ci-c390-readback-v1/14301371102"
out=base/"independent-readback-v1";out.mkdir(mode=0o700);(out/"driver.py").write_text(sys.argv[1])
raw_root=out/"raw";source=base/"extracted"
sys.path.insert(0,str(root))
from hia.tools import qualify_application_ci as ci
from hia.platform.execution_application import rust_oracle as oracle,source_graph as graph
def need(c,m):
 if not c:raise ValueError(m)
rid=ci.identity
started=time.monotonic_ns();report={"status":"FAIL","actual_runtime_reexecuted":False,"actual_runner_tool_paths_recreated":False,"stages":[]}
def stage(name,f):
 t=time.monotonic_ns()
 try:
  result=f();report["stages"].append({"name":name,"status":"PASS","elapsed_ns":time.monotonic_ns()-t,"result":result});print(json.dumps({"stage":name,"status":"PASS"}),flush=True);return result
 except BaseException as e:
  report["stages"].append({"name":name,"status":"FAIL","error":repr(e),"traceback":traceback.format_exc()});raise
try:
 import subprocess,zipfile,tarfile,shutil
 p=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=root,capture_output=True)
 (out/"preflight.stdout.raw").write_bytes(p.stdout);(out/"preflight.stderr.raw").write_bytes(p.stderr);need(p.returncode==0,"preflight failed")
 need(rid(base/"artifact.zip")=={"bytes":36252504,"sha256":"a6ea2cb45f32edba3a99cbee65a52b3cafd663fd5e5de1de5adca896318852b6"},"complete actual ZIP differs")
 with zipfile.ZipFile(base/"artifact.zip") as z:
  with z.open("complete-evidence.tar.xz") as incoming,open(source/"complete-evidence.tar.xz","xb") as target:shutil.copyfileobj(incoming,target)
 package=ci.read(source/"package-manifest.json");binding=ci.read(source/"binding.json");expected=binding["lineage"]
 need(expected=={"attempt":1,"git_head":"c3901ff19c26815205d9cdd6975fc24ecc51ae88","run_id":"44019939486"},"Unexpected CI lineage")
 need(package["packing_status"]==package["qualification_status"]=="PASS" and package["capture_errors"]==[],"CI package failed")
 stage("binding",lambda:ci.check_binding(binding,expected))
 stage("complete-original-ci-archive",lambda:ci.verify_archive(source/"complete-evidence.tar.xz",package["entries"]))
 need(rid(source/"complete-evidence.tar.xz")==package["archive"] and rid(source/"binding.json")==package["binding"],"artifact metadata binding differs")
 need(package["lineage"]==expected and type(expected["attempt"]) is int and package["special_entries"]=={},"package lineage or special entries differ")
 raw_root.mkdir(mode=0o700)
 with tarfile.open(source/"complete-evidence.tar.xz","r:xz") as archive:
  for member in archive:
   target=raw_root/ci.base.member_path(member.name)
   if member.isdir():
    target.mkdir(parents=True,exist_ok=True);continue
   need(member.isfile() and not target.exists() and not target.is_symlink(),"unexpected extraction member")
   target.parent.mkdir(parents=True,exist_ok=True)
   with archive.extractfile(member) as incoming,open(target,"xb") as output:shutil.copyfileobj(incoming,output)
   need(rid(target)=={k:package["entries"][member.name][k] for k in ("bytes","sha256")},"extracted bytes differ")
 for name,identity in binding["evidence_files"].items():need(rid(raw_root/ci.base.member_path(name))==identity,"Bound evidence changed: "+name)
 need(ci.read(raw_root/"observations/binding.json")==binding,"Embedded binding changed")
 stage("source-observations",lambda:ci.transfer.source_pair(raw_root/"observations",expected))
 sources,_=graph.complete_sources(root);original=graph.original_manifest(root)
 need(sources==binding["source_inputs"] and original==binding["original_sources"],"Exact executed source differs")
 need(all(rid(root/name)==value for name,value in binding["ci_reader_sources"].items()),"Actual CI reader source differs")
 admitted=oracle.validate_bundle(root,raw_root/"native/bundle")
 report["stages"].append({"name":"native-full-raw-replay","status":"PASS","histories":admitted["report"]["histories_total"],"transactions":admitted["report"]["transactions"],"commands":admitted["report"]["state_commands"],"processes":admitted["report"]["actual_processes"]})
 stage("native-entire-elf-compiler-streams",lambda:ci.native_build(raw_root/"native/build",root,admitted))
 stage("physical-entire-raw-replay",lambda:ci.physical(raw_root/"physical",root,admitted))
 helper=root/"hia/tools/qualify_application_ci.py";text=helper.read_text()
 need(rid(helper)=={"bytes":75353,"sha256":"650b1132f48ca6fa02c8d843a9c5a55f8c6eaedf8aa3b332d645bd4e687d55b3"},"Reader differs")
 node=next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=="integrity")
 original_function=ast.get_source_segment(text,node)
 adapted=original_function.replace("def integrity(directory, repository, admitted, bundle):","def integrity_archive(directory, repository, admitted, bundle, original_directory, original_repository, original_bundle):",1)
 old='''        selected = (directory / "unexecuted-empty-bundle" if name.startswith("override-") or name == "optimized-python"
                    else bundle if name == "target-inside-repository" else directory / "mutant-bundle")
        expected_argv = [argv[0], "-B"] + (["-O"] if name == "optimized-python" else []) + [
            "-m", "hia.platform.execution_application.rust_oracle",
            "--repository", str(repository), "--bundle", str(selected), "--output", str(folder / "output")]
        if name == "target-inside-repository":
            expected_argv += ["--target-dir", str(repository / "tria-invalid-application-target")]'''
 new='''        original_folder = original_directory / ("cli-" + name)
        selected = (original_directory / "unexecuted-empty-bundle" if name.startswith("override-") or name == "optimized-python"
                    else original_bundle if name == "target-inside-repository" else original_directory / "mutant-bundle")
        expected_argv = [argv[0], "-B"] + (["-O"] if name == "optimized-python" else []) + [
            "-m", "hia.platform.execution_application.rust_oracle",
            "--repository", str(original_repository), "--bundle", str(selected), "--output", str(original_folder / "output")]
        if name == "target-inside-repository":
            expected_argv += ["--target-dir", str(original_repository / "tria-invalid-application-target")]'''
 need(adapted.count(old)==1,"Portable origin block differs")
 adapted=adapted.replace(old,new)
 (out/"integrity_archive.py").write_text(adapted+"\n")
 scope=vars(ci).copy();exec(compile(adapted,str(out/"integrity_archive.py"),"exec"),scope)
 origin_root=Path("/home/runner/work/Trillionnium-Chain/Trillionnium-Chain/chain")
 origin_temp=Path("/home/runner/work/_temp")
 origin_integrity=origin_temp/"hia-execution-application-integrity"
 origin_bundle=origin_temp/"hia-execution-application-native/bundle"
 report["original_execution_paths"]={"repository":str(origin_root),"integrity":str(origin_integrity),"native_bundle":str(origin_bundle)}
 report["portable_reader"]={"source_reader":rid(helper),"adapted_reader":rid(out/"integrity_archive.py"),"changes":"Only separates the original recorded CLI argv roots from the relocated read-only archive roots. No raw evidence, source map, result, control roster or other invariant is edited."}
 stage("integrity-original-cli-origin-full-raw-replay",lambda:scope["integrity_archive"](raw_root/"integrity",root,admitted,raw_root/"native/bundle",origin_integrity,origin_root,origin_bundle))
 copied=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/ci-876-readback-v2/14292661841/independent-readback-v1/original_raw.py").read_text().removesuffix("\n");(out/"original_raw.py").write_text(copied+"\n")
 scope2={"ci":ci,"oracle":oracle,"json":json,"need":need,"rid":rid}
 exec(compile(copied,str(out/"original_raw.py"),"exec"),scope2)
 stage("actual-original-stdout-differential",lambda:scope2["original_raw"](raw_root/"original",admitted,binding))
 need(graph.complete_sources(root)[0]==sources and graph.original_manifest(root)==original,"Source changed during readback")
 for name,identity in binding["evidence_files"].items():need(rid(raw_root/ci.base.member_path(name))==identity,"Evidence changed during readback")
 report.update(status="PASS",lineage=expected,native_source_set_sha256=ci.object_hash(sources),original_source_set_sha256=ci.object_hash(original),source_after="MATCH",
  evidence_after="MATCH",whole_node_or_commit_authority=False,actual_runner_tool_checks="Original runner tool identities and fences retained in bound evidence; no remote absolute tool/target paths recreated or locally reexecuted",
  portable_reader_predecessor={"head":"876eb577dac61854c535a91ab1480f312d1d6173","reader":rid(Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/ci-876-readback-v2/14292661841/independent-readback-v1/driver.py")),"old_result_relabelled":False})
except BaseException as e:
 report["failure"]={"error":repr(e),"traceback":traceback.format_exc()};raise
finally:
 report["elapsed_ns"]=time.monotonic_ns()-started
 data=(json.dumps(report,sort_keys=True,separators=(",",":"))+"\n").encode();(out/"report.json").write_bytes(data)
 print(json.dumps({"status":report["status"],"elapsed_ns":report["elapsed_ns"],"report_bytes":len(data),"report_sha256":hashlib.sha256(data).hexdigest(),"failure":report.get("failure")}),flush=True)
