#!/usr/bin/env python3
"""Authorized three-file lossless evidence transport; no other unlink target."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import sys
import time

ROOT = Path('/tmp/target-history-56818e4fba76')
OUT = ROOT / 'preserved-r8-elf-gzip-20261028'
RECEIPTS = Path('/workspace/scratch/56818e4fba76/chain-history-next/evidence/pon-history-checkpoint-r8-20261028/commands.json')
APPROVED = [
    ('history-r8-baseline-189ba3-node', 126434568, '74df89fe26a5fee3741bbbc24353570cc63672bc5de438067e8d8e3b8ac8aca2'),
    ('history-r8-candidate-node', 126444880, 'bbc2e67a525c14907f41dfe74e8a0a2d4cb007e2a6178046e450461c366e0d0b'),
    ('history-r8-candidate-corrected-node', 126461128, '3aae89ff283f8329625363bbfa95b366b36492e0be5de07354a6a9b696719db4'),
]
BLOCK = 1024 * 1024
FLOOR = 1024 * BLOCK
START = time.monotonic()

def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)

def free_bytes():
    value = os.statvfs(ROOT)
    return value.f_bavail * value.f_frsize

def identity(value):
    return dict(device=value.st_dev, inode=value.st_ino, bytes=value.st_size,
                mode=stat.S_IMODE(value.st_mode), mtime_ns=value.st_mtime_ns,
                ctime_ns=value.st_ctime_ns, nlink=value.st_nlink)

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(BLOCK), b''):
            value.update(chunk)
    return value.hexdigest()

def fsync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def write_json(name, value):
    with (OUT / name).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
    fsync_dir(OUT)

def event(value):
    row = dict(unix_ns=time.time_ns(), elapsed_seconds=time.monotonic()-START, **value)
    with (OUT / 'events.jsonl').open('a') as handle:
        handle.write(json.dumps(row, sort_keys=True)+'\n')
        handle.flush()
        os.fsync(handle.fileno())
    print(json.dumps(row), flush=True)

def ownership_snapshot():
    observed = 0
    unreadable_cmdline = []
    unreadable_exe_count = 0
    matches = []
    for process in Path('/proc').iterdir():
        if not process.name.isdecimal():
            continue
        try:
            args = (process/'cmdline').read_bytes().split(b'\0')
        except FileNotFoundError:
            continue
        except PermissionError:
            unreadable_cmdline.append(process.name)
            continue
        if not args or not args[0]:
            continue
        observed += 1
        argv = [x.decode(errors='replace') for x in args if x]
        try:
            executable = os.readlink(process/'exe')
        except FileNotFoundError:
            continue
        except PermissionError:
            unreadable_exe_count += 1
            executable = argv[0]
        actual = Path(executable).resolve(strict=False)
        direct_owned = actual == ROOT or ROOT in actual.parents
        compiler_owned = Path(argv[0]).name in ('cargo','rustc','rustfmt','clippy-driver') and any(
            item == str(ROOT) or item.startswith(str(ROOT)+'/') for item in argv[1:])
        if direct_owned or compiler_owned:
            matches.append(dict(observed_proc_id=process.name, executable=executable, argv=argv))
    result = dict(observed_cmdlines=observed, unreadable_cmdline_proc_ids=unreadable_cmdline,
                  unreadable_exe_count=unreadable_exe_count, matching_known_owned_users=matches,
                  basis='Root confirms History native executions terminal; root uses only chain-pq-target and W1 uses trnm-w1-r2-target. This is scoped task ownership, not complete global executable observability.')
    require(not matches, 'known owned History target has an active executable or compiler')
    return result

def interrupted(signum, _frame):
    raise RuntimeError('bounded preservation interrupted by signal '+str(signum))

def main():
    require(ROOT.resolve(strict=True) == ROOT and not ROOT.is_symlink(), 'target root must be exact and non-symlink')
    require(not os.path.lexists(OUT), 'fresh output directory required; no overwrite or retry')
    OUT.mkdir(mode=0o700)
    os.nice(19)
    resource.setrlimit(resource.RLIMIT_CPU, (45, 50))
    resource.setrlimit(resource.RLIMIT_AS, (256 * BLOCK, 256 * BLOCK))
    signal.signal(signal.SIGALRM, interrupted)
    signal.signal(signal.SIGXCPU, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    signal.alarm(120)
    before_free = free_bytes()
    before_usage = resource.getrusage(resource.RUSAGE_SELF)
    complete = []
    result = {}
    try:
        with (OUT/'preserve.py').open('xb') as script_copy:
            script_copy.write(Path(__file__).read_bytes())
            script_copy.flush()
            os.fsync(script_copy.fileno())
        original_receipts = RECEIPTS.read_bytes()
        all_receipts = json.loads(original_receipts)
        require(isinstance(all_receipts, list), 'unexpected source receipt structure')
        selected = []
        for name, size, expected in APPROVED:
            rows = [v for v in all_receipts if v.get('argv', [None])[0] == str(ROOT/name)]
            require(rows and all(v.get('binary_sha256') == expected for v in rows), 'ELF source receipt mismatch: '+name)
            selected.append(dict(path=str(ROOT/name), bytes=size, sha256=expected, original_complete_execution_receipts=rows))
        write_json('plan.json', dict(schema='history-r8-three-elf-lossless-transport-v1', approved=selected,
                    source_receipts_path=str(RECEIPTS), source_receipts_sha256=hashlib.sha256(original_receipts).hexdigest(),
                    all_original_source_logs_and_archives_preserved=True, process_scope=ownership_snapshot(),
                    free_before_bytes=before_free, compression='gzip level 6, empty header filename, mtime 0',
                    budget=dict(wall_seconds=120,cpu_soft_seconds=45,cpu_hard_seconds=50,address_space_bytes=256*BLOCK,free_floor_bytes=FLOOR),
                    native_execution=False, argv=sys.argv, python_executable=sys.executable,
                    script_sha256=digest(Path(__file__))))
        for name, expected_size, expected_hash in APPROVED:
            source = ROOT/name
            original = source.lstat()
            original_id = identity(original)
            require(stat.S_ISREG(original.st_mode) and not source.is_symlink(), 'source is not regular exact ELF')
            require(original.st_size == expected_size, 'source byte count changed')
            require(source.resolve(strict=True) == source and source.parent == ROOT, 'source path escaped owner root')
            require(free_bytes() >= FLOOR+expected_size+4*BLOCK, 'insufficient temporary preservation space')
            partial = OUT/(name+'.gz.partial')
            compressed = OUT/(name+'.gz')
            source_hash = hashlib.sha256()
            source_bytes = 0
            fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(fd, 'rb') as original_handle:
                require(identity(os.fstat(original_handle.fileno())) == original_id, 'source changed at open')
                require(original_handle.read(4) == b'\x7fELF', 'approved source is not ELF')
                original_handle.seek(0)
                with partial.open('xb') as output:
                    with gzip.GzipFile(filename='', mode='wb', compresslevel=6, fileobj=output, mtime=0) as archive:
                        for chunk in iter(lambda: original_handle.read(BLOCK), b''):
                            require(free_bytes() >= FLOOR+2*BLOCK, 'disk floor before compression write')
                            archive.write(chunk)
                            source_hash.update(chunk)
                            source_bytes += len(chunk)
                    output.flush()
                    os.fsync(output.fileno())
                require(identity(os.fstat(original_handle.fileno())) == original_id, 'source fd changed during compression')
            require(source_bytes == expected_size and source_hash.hexdigest() == expected_hash, 'source content no longer matches measured ELF')
            restored = hashlib.sha256()
            restored_bytes = 0
            with gzip.open(partial, 'rb') as archive:
                for chunk in iter(lambda: archive.read(BLOCK), b''):
                    restored.update(chunk)
                    restored_bytes += len(chunk)
                    require(restored_bytes <= expected_size, 'decompression exceeds exact original bytes')
            require(restored_bytes == expected_size and restored.hexdigest() == expected_hash, 'full decompression differs from measured ELF')
            require(identity(source.lstat()) == original_id, 'source inode/mtime/metadata changed before preservation')
            require(not os.path.lexists(compressed), 'refuse compressed evidence overwrite')
            partial.rename(compressed)
            fsync_dir(OUT)
            record = dict(source_path=str(source), source_identity=original_id, source_allocated_bytes=original.st_blocks*512,
                          source_sha256=source_hash.hexdigest(), decompressed_bytes=restored_bytes,
                          decompressed_sha256=restored.hexdigest(), compressed_path=str(compressed),
                          compressed_bytes=compressed.stat().st_size, compressed_allocated_bytes=compressed.stat().st_blocks*512,
                          compressed_sha256=digest(compressed), full_decompression_verified=True,
                          source_identity_unchanged=True, process_scope_before_unlink=ownership_snapshot(),
                          free_before_unlink_bytes=free_bytes(), source_unlinked=False)
            write_json(name+'.verified.json', record)
            require(identity(source.lstat()) == original_id, 'source changed immediately before unlink')
            source.unlink()
            fsync_dir(ROOT)
            record.update(source_unlinked=True, free_after_unlink_bytes=free_bytes())
            complete.append(record)
            event(dict(stage='VERIFIED_REDUNDANT_RAW_UNLINKED', source_path=str(source), compressed_path=str(compressed),
                       original_sha256=expected_hash, compressed_bytes=record['compressed_bytes'], free_bytes=free_bytes()))
        result = dict(outcome='ALL_THREE_VERIFIED_LOSSLESS_TRANSPORT_COMPLETE', completed=complete)
    except BaseException as error:
        result = dict(outcome='FAILED_RETAIN_ALL_COMPLETED_AND_PARTIAL_ARCHIVES', error=repr(error), completed=complete)
        raise
    finally:
        signal.alarm(0)
        usage = resource.getrusage(resource.RUSAGE_SELF)
        result.update(wall_seconds=time.monotonic()-START,
                      user_cpu_seconds=usage.ru_utime-before_usage.ru_utime,
                      system_cpu_seconds=usage.ru_stime-before_usage.ru_stime,
                      peak_rss_bytes=usage.ru_maxrss*1024,
                      free_before_bytes=before_free,free_after_bytes=free_bytes(),
                      free_net_change_bytes=free_bytes()-before_free,
                      concurrent_root_pq_compile=True, native_executed=False,
                      unlink_scope=[str(ROOT/name) for name,_,_ in APPROVED])
        write_json('result.json', result)
        print(json.dumps({k:v for k,v in result.items() if k != 'completed'}), flush=True)

if __name__ == '__main__':
    main()
