#!/usr/bin/env python3
"""Package already completed, explicitly scoped History ELF transport receipts.

This collector never executes or removes a native artifact. It hashes the retained
compressed bytes and copies only small original receipts into the Git evidence.
"""
import hashlib
import json
import os
from pathlib import Path
import stat
import time
import zipfile


REPO = Path('/workspace/scratch/56818e4fba76/chain-history-next')
TARGET = Path('/tmp/target-history-56818e4fba76')
OUT = REPO / 'evidence/pon-history-elf-transport-r8-20261028'
ROOTS = [
    ('top-level', TARGET / 'preserved-r8-elf-gzip-20261028'),
    ('deps', TARGET / 'preserved-r8-deps-elf-gzip-20261028'),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def regular(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink(), str(path)
    return info


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def main():
    started = time.monotonic()
    OUT.mkdir(exist_ok=False)
    results = {tag: json.loads((root / 'result.json').read_text()) for tag, root in ROOTS}
    top_plan = json.loads((ROOTS[0][1] / 'plan.json').read_text())
    bindings_path = ROOTS[1][1] / 'source-bindings.json'
    bindings = json.loads(bindings_path.read_text())
    native_receipts = json.loads((REPO / 'evidence/pon-history-checkpoint-r8-20261028/commands.json').read_text())
    source_rows = []
    raw_files = []
    for tag, root in ROOTS:
        for path in sorted(root.iterdir()):
            if path.suffix == '.gz':
                continue
            regular(path)
            raw_files.append((f'{tag}/{path.name}', path, path.read_bytes()))
    for record in bindings['source_receipts']:
        path = REPO / record['repository_path']
        regular(path)
        contents = path.read_bytes()
        assert len(contents) == record['bytes'] and sha(contents) == record['sha256']
        raw_files.append((f"source-receipts/{record['repository_path']}", path, contents))
        source_rows.append({key: record[key] for key in ('repository_path', 'bytes', 'sha256')})
    self_path = Path(__file__).resolve()
    raw_files.append(('collector.py', self_path, self_path.read_bytes()))

    rows = []
    verified_archives = {}
    for round_name, result in results.items():
        for original in result['completed']:
            source = Path(original['source_path'])
            assert not source.exists(), f'Expected already-unlinked raw file: {source}'
            archive = Path(original['compressed_path'])
            info = regular(archive)
            assert info.st_size == original['compressed_bytes']
            if str(archive) not in verified_archives:
                actual_sha = file_sha(archive)
                assert actual_sha == original['compressed_sha256']
                verified_archives[str(archive)] = {
                    'path': str(archive), 'bytes': info.st_size,
                    'sha256': actual_sha,
                    'archive_hash_rechecked_at_collection': True,
                    'original_full_decompression_receipt_preserved': True,
                }
            original_sha = original['source_sha256']
            expanded_bytes = original.get('decompressed_bytes', original.get('full_decompressed_bytes'))
            expanded_sha = original.get('decompressed_sha256', original.get('full_decompressed_sha256'))
            assert expanded_bytes == original['source_identity']['bytes']
            assert expanded_sha == original_sha
            assert original['source_identity_unchanged'] and original['source_unlinked']
            assert original['process_scope_before_unlink']['matching_known_owned_users'] == []
            receipts = [row for row in native_receipts if row.get('binary_sha256') == original_sha]
            identities = sorted({(row['source_commit'], row['source_tree'], row['source_manifest_sha256'],
                                  row['source_diff_sha256'], row['source_status']) for row in receipts})
            identity_rows = [dict(zip(('base_commit', 'base_tree', 'source_manifest_sha256',
                                       'source_diff_sha256', 'source_status'), identity))
                             for identity in identities]
            if identity_rows:
                source_binding = {
                    'status': 'EXACT_RETAINED_HISTORY_INPUT_MANIFEST',
                    'source_identities': identity_rows,
                    'receipts': [row['name'] for row in receipts],
                    'dirty_build': any(row['source_status'] for row in receipts),
                    'clean_final_commit_build_claimed': False,
                    'current_source_qualification': False,
                }
            elif source.name == 'trnm_pon_node-9e86f7cb7a9d0a67':
                source_binding = {
                    'status': 'EXACT_RETAINED_OLD_BUILD_AND_MEASUREMENT',
                    'original_compilation_commit': '2e5240e62d450f34ee39fb3dec95bb81fd2d8288',
                    'original_compilation_tree': '44b3f9de645a0c6061815c639b57892665d9dfbc',
                    'measurement_commit': '48aa81da0435e55504503b25ccaaf58db013d94f',
                    'measurement_tree': '9b64bb807def976edbe16aa5171492ffdc3bb7fb',
                    'basis': 'Exact ELF SHA in original build.json, nice-build.json and history-original/receipt.json.',
                    'current_source_qualification': False,
                }
            elif source.name == 'public_v3_multiprocess-b925461c415cbaf8':
                source_binding = {
                    'status': 'RETAINED_OLD_DEADLINE_CORRECTION_ARTIFACT',
                    'recorded_final_executable_source': 'fe43f7c7f8971df37cbb7eda7080dac8ae4887aa',
                    'basis': 'Exact ELF SHA in deadline-correction/native-artifacts.json; enclosing artifact-manifest records final executable source.',
                    'distinct_from_original_48aa_multiprocess_elf': True,
                    'current_source_qualification': False,
                }
            else:
                source_binding = {
                    'status': 'UNKNOWN',
                    'source_commit': None,
                    'source_tree': None,
                    'basis': 'No exact source-to-ELF binding found in the retained local receipts searched. Compiler filename/mtime are not source proof.',
                    'bytes_preserved': True,
                    'current_source_qualification': False,
                }
            rows.append({
                'round': round_name,
                'original_path': str(source),
                'original_bytes': original['source_identity']['bytes'],
                'original_sha256': original_sha,
                'original_identity': original['source_identity'],
                'archive': verified_archives[str(archive)],
                'original_full_decompression_verified_bytes': expanded_bytes,
                'original_full_decompression_verified_sha256': expanded_sha,
                'source_binding': source_binding,
                'raw_unlinked_only_after_verification': True,
                'raw_still_absent_at_collection': True,
                'original_hardlink_payload_retained_elsewhere': original.get('remaining_hardlink_payload_is_not_freed', False),
            })
    assert len(rows) == 9 and len(verified_archives) == 8
    assert sum(row['source_binding']['status'] == 'UNKNOWN' for row in rows) == 3
    alias = TARGET / 'debug/trnm-pon-node'
    alias_info = regular(alias)
    assert alias_info.st_ino == 528262 and alias_info.st_size == 76400896

    manifest = []
    archive_path = OUT / 'raw-transport-receipts.zip'
    with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path, contents in raw_files:
            entry = zipfile.ZipInfo(name, date_time=(2026, 10, 28, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = (0o100644 << 16)
            archive.writestr(entry, contents)
            manifest.append({'member': name, 'original_path': str(path), 'bytes': len(contents), 'sha256': sha(contents)})
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == [row['member'] for row in manifest]
        for row in manifest:
            restored = archive.read(row['member'])
            assert len(restored) == row['bytes'] and sha(restored) == row['sha256']
    write_json(OUT / 'raw-files.json', manifest)
    evidence = {
        'schema': 'history-elf-lossless-transport-evidence-v1',
        'collection_source_commit': '7c324398041d05e14c80a7d3a973991de69fbabe',
        'collection_source_tree': 'a320be87ce0d4b1ac62bd2322c07e70273d5a313',
        'scope': 'Receipt-only evidence packaging for two already completed authorized transports. Original eight gzip ELF payloads remain at their recorded paths; they are not embedded in this small Git package.',
        'native_executed_by_transport_or_collection': False,
        'new_compilation_qualification': False,
        'new_pq_qualification': False,
        'new_service_or_wan_qualification': False,
        'original_paths_preserved_as_gzip': len(rows),
        'unique_payload_archives': len(verified_archives),
        'unknown_source_bindings': 3,
        'total_raw_path_bytes': sum(row['original_bytes'] for row in rows),
        'total_unique_gzip_bytes': sum(row['bytes'] for row in verified_archives.values()),
        'rounds': [{
            'round': tag,
            'original_result_path': str(root / 'result.json'),
            'original_result_sha256': file_sha(root / 'result.json'),
            'wall_seconds': results[tag]['wall_seconds'],
            'cpu_seconds': results[tag]['user_cpu_seconds'] + results[tag]['system_cpu_seconds'],
            'peak_rss_bytes': results[tag]['peak_rss_bytes'],
            'free_before_bytes': results[tag]['free_before_bytes'],
            'free_after_bytes': results[tag]['free_after_bytes'],
            'observed_free_net_change_bytes': results[tag]['free_net_change_bytes'],
            'free_is_concurrent_filesystem_observation_not_exclusive_freed_byte_accounting': True,
        } for tag, root in ROOTS],
        'artifacts': rows,
        'original_source_receipt_bindings': source_rows,
        'process_observation_limit': 'Checks are scoped to task ownership and known terminal History users. Other process executable links were unreadable; no complete global-empty-process claim is made.',
        'unapproved_alias_retained': {
            'path': str(alias), 'inode': alias_info.st_ino, 'bytes': alias_info.st_size,
            'nlink_at_collection': alias_info.st_nlink,
            'removed': False,
            'payload_free_claim_for_deps_alias_unlink': False,
        },
        'raw_receipt_archive': {
            'path': archive_path.name, 'bytes': archive_path.stat().st_size,
            'sha256': file_sha(archive_path), 'members': len(manifest),
            'all_members_fully_read_back_and_hash_verified': True,
        },
        'collection_wall_seconds': time.monotonic() - started,
        'collector_did_not_repeat_elf_decompression': True,
        'collection_free_bytes': os.statvfs(TARGET).f_bavail * os.statvfs(TARGET).f_frsize,
    }
    write_json(OUT / 'transport-summary.json', evidence)
    print(json.dumps({key: evidence[key] for key in ('original_paths_preserved_as_gzip', 'unique_payload_archives', 'unknown_source_bindings', 'total_raw_path_bytes', 'total_unique_gzip_bytes', 'raw_receipt_archive', 'collection_wall_seconds', 'collection_free_bytes')}, indent=2))


if __name__ == '__main__':
    main()
