fn main() {
 let arg = std::env::args().nth(1).expect("guest path");
 let bytes = std::fs::read(arg).expect("guest bytes");
 let id = risc0_zkvm::compute_image_id(&bytes).expect("official compute_image_id");
 println!("{}", id);
 println!("{:?}", id.as_words());
}
