#!/usr/bin/env python3
"""Materialize a separate complete B checkout; preserve the old missing-file scene."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess
import traceback

OLD = Path("/home/qq/chain-hash-transitive-976f-20261111")
NEW = Path("/home/qq/chain-hash-transitive-976f-recovered-20261112")
RECOVERY = Path(str(OLD) + "-recovery-cprime")
OUT = RECOVERY / "new-source-setup-01"
B = "9fd6ee29a7a663cef547040d9d42cc36a371a17e"
TREE = "7351f83fa9ac5c0e7540fa64bce06ea6f328602f"
OUT.mkdir(parents=True, exist_ok=False)
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def put(name, raw):
    with (OUT / name).open("xb") as f:
        f.write(raw)
def dump(name, value):
    put(name, (json.dumps(value, sort_keys=True, indent=2) + "\n").encode())
summary = {"schema": "trnm-cprime-complete-checkout-setup-v1", "status": "running",
    "started_utc": datetime.now(timezone.utc).isoformat(), "old_root": str(OLD),
    "new_root": str(NEW), "source": B, "tree": TREE, "commands": [],
    "old_worktree_repaired_or_flags_cleared": False,
    "whole_chain_quantum_security_qualified": False}
def run(label, argv, cwd):
    with (OUT / (label + ".stdout")).open("xb") as stdout, (OUT / (label + ".stderr")).open("xb") as stderr:
        p = subprocess.run(argv, cwd=cwd, stdout=stdout, stderr=stderr)
    row = {"label": label, "argv": argv, "cwd": str(cwd), "exit_code": p.returncode}
    summary["commands"].append(row)
    dump(label + ".json", row)
    print(json.dumps(row, sort_keys=True), flush=True)
    if p.returncode:
        raise RuntimeError("setup command failed: " + label)
    return (OUT / (label + ".stdout")).read_bytes()
try:
    put("setup-driver.py", Path(__file__).read_bytes())
    forensic = json.loads((RECOVERY / "index-forensics-01/summary.json").read_text())
    mismatches = json.loads((RECOVERY / "index-forensics-01/all-mismatches.json").read_text())
    assert forensic["status"] == "REFUSE_PHYSICAL_OR_INDEX_DIFFERENCE"
    assert forensic["index_stage0_exactly_B"] and forensic["head_stable"]
    summary["old_mismatch_count"] = len(mismatches)
    summary["old_all_mismatches_missing_files"] = all(row["error"].startswith("FileNotFoundError:") for row in mismatches)
    summary["old_index_sha256_before"] = sha((OLD / ".git/index").read_bytes())
    assert summary["old_index_sha256_before"] == forensic["index_before"]["sha256"]
    assert not NEW.exists(), "new checkout path must be absent"
    disk = shutil.disk_usage(NEW.parent)
    summary["disk_before"] = {"total": disk.total, "used": disk.used, "free": disk.free}
    assert disk.free >= 4 * 1024 * 1024 * 1024, "insufficient room for complete B"
    heads = run("old-head", ["git", "--no-replace-objects", "rev-parse", "HEAD", "HEAD^{tree}"], OLD).decode().splitlines()
    assert heads == [B, TREE]
    tree_raw = run("old-b-tree", ["git", "--no-replace-objects", "ls-tree", "-r", "-z", "--full-tree", B], OLD)
    tree_entries = []
    for row in tree_raw.split(b"\0"):
        if row:
            info, path = row.split(b"\t", 1)
            mode, kind, oid = info.split(b" ")
            assert kind == b"blob"
            tree_entries.append((path, oid.decode()))
    assert len(tree_entries) == 28334
    needed = {oid for _, oid in tree_entries}
    found = {}
    # Enumerate only existing local objects: this form never requests remote objects.
    # Discard unrelated object metadata; retain only the B tree's required identities.
    argv = ["git", "--no-replace-objects", "cat-file", "--batch-all-objects",
            "--batch-check=%(objectname) %(objecttype) %(objectsize)"]
    with (OUT / "b-object-availability.stderr").open("xb") as err:
        p = subprocess.Popen(argv, cwd=OLD, stdout=subprocess.PIPE, stderr=err)
        for raw in p.stdout:
            fields = raw.decode().split()
            if fields and fields[0] in needed:
                assert len(fields) == 3 and fields[1] == "blob"
                found[fields[0]] = int(fields[2])
        p.stdout.close()
        result = p.wait()
    assert result == 0, "local object metadata inspection failed"
    missing = sorted(needed - set(found))
    dump("b-required-local-objects.json", {"argv": argv, "scope": "filtered to B tree blob identities only",
         "exit_code": result, "unique_required_blobs": len(needed),
         "present_required_blobs": len(found), "missing_required_blobs": missing,
         "present_sizes": found})
    summary["required_blob_objects"] = len(needed)
    summary["missing_blob_objects_before"] = len(missing)
    run("clone-independent-metadata", ["git", "clone", "--shared", "--no-checkout", "--no-tags", str(OLD), str(NEW)], OLD.parent)
    run("canonical-origin", ["git", "remote", "set-url", "origin", "https://github.com/TrillionniumFoundation/Trillionnium-Chain.git"], NEW)
    for offset in range(0, len(missing), 32):
        run("fetch-b-objects-" + str(offset), ["git", "-c", "fetch.negotiationAlgorithm=noop",
            "-c", "protocol.version=2", "fetch", "--no-tags", "--no-write-fetch-head",
            "origin", *missing[offset:offset+32]], NEW)
    if missing:
        p = subprocess.run(["git", "--no-replace-objects", "cat-file", "--batch-check=%(objectname) %(objecttype) %(objectsize)"],
            cwd=NEW, input=("".join(oid + "\n" for oid in missing)).encode(),
            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        put("fetched-object-metadata.stdout", p.stdout)
        put("fetched-object-metadata.stderr", p.stderr)
        assert p.returncode == 0
        for line in p.stdout.decode().splitlines():
            oid, kind, size = line.split()
            assert kind == "blob" and oid in missing
            found[oid] = int(size)
    assert needed == set(found)
    assert sum(found[oid] for _, oid in tree_entries) == 2578874762
    summary["required_blob_objects_complete"] = True
    run("checkout-b-complete", ["git", "--no-replace-objects", "checkout", "--detach", B], NEW)
    new_head = run("new-head", ["git", "--no-replace-objects", "rev-parse", "HEAD", "HEAD^{tree}"], NEW).decode().splitlines()
    assert new_head == [B, TREE]
    run("new-index-flags", ["git", "ls-files", "-v", "-z"], NEW)
    label = "recovery-cprime-b-new-root-preflight"
    run("original-recorder-preflight", ["/usr/bin/python3", "scripts/ci/record_pq_native_command.py",
        "--kind", "head", "--candidate", B, "--tested", B, "--label", label,
        "--output", str(RECOVERY / "setup-records"),
        "--", "bash", "scripts/project-preflight.sh", "--audit"], NEW)
    receipt = json.loads((RECOVERY / "setup-records" / (label + ".json")).read_text())
    assert receipt["status"] == "command_succeeded" and receipt["exit_code"] == 0
    assert receipt["before"] == receipt["after"]
    guard = receipt["before"]
    assert guard["tested_commit"] == B and guard["tested_tree"] == TREE
    assert guard["tracked_entries"] == 28334 and guard["tracked_bytes"] == 2578874762
    assert guard["tracked_worktree_verified"] is True
    summary["preflight_receipt"] = str(RECOVERY / "setup-records" / (label + ".json"))
    summary["original_guards"] = guard
    summary["old_index_sha256_after"] = sha((OLD / ".git/index").read_bytes())
    assert summary["old_index_sha256_before"] == summary["old_index_sha256_after"]
    summary["old_index_bytes_preserved"] = True
    summary["status"] = "COMPLETE_B_CHECKOUT_AND_ORIGINAL_PREFLIGHT_PASSED"
except Exception as exc:
    summary["status"] = "REFUSE_SETUP_OR_ORIGINAL_GUARD_FAILURE"
    summary["error"] = type(exc).__name__ + ": " + str(exc)
    put("exception-traceback.txt", traceback.format_exc().encode())
summary["finished_utc"] = datetime.now(timezone.utc).isoformat()
dump("summary.json", summary)
print(json.dumps(summary, sort_keys=True), flush=True)
raise SystemExit(0 if summary["status"] == "COMPLETE_B_CHECKOUT_AND_ORIGINAL_PREFLIGHT_PASSED" else 1)
