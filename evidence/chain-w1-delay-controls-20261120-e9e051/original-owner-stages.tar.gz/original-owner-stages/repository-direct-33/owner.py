from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'repository-direct-33';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);env=os.environ.copy();env['CARGO_TARGET_DIR']=str(src.parent/'target');env['TRNM_CI_RECEIPT_DIR']=str(out/'receipts');env['PATH']='/home/qq/.cargo/bin:'+env['PATH']
res={'schema':'chain-original-repository-truth-local-v1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'source_diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src)).hexdigest(),'command':['python3','scripts/ci/check_repository.py'],'cwd':str(src),'complete':False,'preflight':None}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
save()
try:
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/'preflight.log').open('xb') as f:preflight=subprocess.call(['bash','scripts/project-preflight.sh'],cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);res['preflight']={'exit_code':preflight,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};save();assert preflight==0
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/'stdout.log').open('xb') as so,(out/'stderr.log').open('xb') as se:rc=subprocess.call(res['command'],cwd=src,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);res.update({'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime,'complete':True});save();print(json.dumps(res,indent=2),flush=True)
 print((out/'stderr.log').read_text(errors='replace')[-16000:],flush=True);sys.exit(rc)
except BaseException as e:
 if isinstance(e,SystemExit):raise
 res['error']=repr(e);save();(out/'owner.error').write_text(traceback.format_exc());raise
