import os, pathlib, subprocess, json, hashlib, time, sys
task=pathlib.Path("/home/qian-qi/work/chain-pq-migration-recovery-e1dee-20261106")
source=task/"publication-source"
out=task/"records/publication-final-v1"; out.mkdir(mode=0o700)
bundle=task/"pq-migration-recovery-publication.bundle"
initial="9fb011c4af1f9f54353207f9ad9fbc54ab6235e3"
initial_tree="5f4f1730e0f5218e4db9706e6daf2c25cde5c182"
head="b0dadfdc0d906d35f19a1ba79df2ddbb8bbfba25"
tree="f05bd4edc080e447e467d9de23d6c36cb42ebb0c"
expected_remote="dfffc5b2447cbf81a8a656ec8e0cdd2e2af6a422"
remote_ref="refs/heads/fix/chain-pq-integrated-20261105-df8969"
origin="https://github.com/TrillionniumFoundation/Trillionnium-Chain.git"
env=os.environ.copy(); env.update(GIT_TERMINAL_PROMPT="0",PYTHONDONTWRITEBYTECODE="1",GIT_NO_REPLACE_OBJECTS="1")
rows=[]
result={"schema":"trnm-pq-publication-v1","initial":initial,"source":head,"tree":tree,"expected_remote":expected_remote,
        "remote_ref":remote_ref,"status":"running","actual_push_attempted":False,"actual_push_observed":False,
        "rows":rows,"started_unix_ns":str(time.time_ns())}
def digest(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open("rb") as f:
  for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
 return h.hexdigest()
def save(p,v):
 with p.open("x") as f: json.dump(v,f,sort_keys=True,indent=2); f.write("\n"); f.flush(); os.fsync(f.fileno())
def checkpoint():
 temp=out/"running.tmp"
 with temp.open("w") as f: json.dump(result,f,sort_keys=True,indent=2); f.write("\n");f.flush();os.fsync(f.fileno())
 os.replace(temp,out/"running.json")
def run(label,args,cwd=source):
 start=time.time_ns();log=out/(label+".log")
 with log.open("xb") as f:
  p=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,check=False)
  f.flush();os.fsync(f.fileno())
 row={"label":label,"argv":args,"cwd":str(cwd),"exit_code":p.returncode,"started_unix_ns":str(start),
      "finished_unix_ns":str(time.time_ns()),"log_bytes":log.stat().st_size,"log_sha256":digest(log)}
 rows.append(row);save(out/(label+".json"),row);checkpoint();print(json.dumps(row),flush=True)
 if p.returncode:raise RuntimeError("command failed: "+label)
 return log.read_text()
def recorded(label,args):
 prefix=["/usr/bin/python3","scripts/ci/record_pq_native_command.py","--kind","head","--candidate",head,
         "--tested",head,"--label",label,"--output",str(out),"--"]
 p=subprocess.run(prefix+args,cwd=source,env=env,check=False)
 record=json.loads((out/(label+".json")).read_text())
 row={"label":label,"argv":args,"exit_code":p.returncode,"record_status":record["status"],
      "log_bytes":record.get("log_bytes"),"log_sha256":record.get("log_sha256")}
 rows.append(row);checkpoint();print(json.dumps(row),flush=True)
 if p.returncode or record["status"]!="command_succeeded" or record["before"]!=record["after"]:
  raise RuntimeError("recorded command refused: "+label)
def remote_read(label,expected):
 got=run(label,["/usr/bin/git","ls-remote","--exit-code","origin",remote_ref]).strip()
 if got!=expected+"\t"+remote_ref: raise RuntimeError("remote advanced at "+label+": "+got)
 return got
try:
 assert bundle.stat().st_size==611843
 assert digest(bundle)=="fe5a44a6e85beb75de270881574b880a35d1e6240b4ed8e91902f5bc64c3a84f"
 result["bundle"]={"size":bundle.stat().st_size,"sha256":digest(bundle)}
 assert run("initial-head",["/usr/bin/git","rev-parse","HEAD"]).strip()==initial
 assert run("initial-tree",["/usr/bin/git","rev-parse","HEAD^{tree}"]).strip()==initial_tree
 assert run("initial-clean",["/usr/bin/git","status","--porcelain=v1"])==""
 assert run("canonical-origin",["/usr/bin/git","remote","get-url","origin"]).strip()==origin
 isolation={}
 for label,directory,expected_head in (("original-source",task/"source","2058225aa0d50ca57b1eb0d5f520d7f4eefae69b"),
                                       ("corrected-source",task/"corrected-source",initial)):
  observed=run(label+"-before",["/usr/bin/git","rev-parse","HEAD","HEAD^{tree}"],directory)
  assert observed.splitlines()[0]==expected_head
  isolation[label]=observed
 result["isolation_before"]=isolation
 assert run("bundle-list-heads",["/usr/bin/git","bundle","list-heads",str(bundle)]).strip()==head+" HEAD"
 run("bundle-verify",["/usr/bin/git","bundle","verify",str(bundle)])
 run("bundle-import",["/usr/bin/git","fetch","--no-tags",str(bundle),"HEAD"])
 assert run("bundle-imported-head",["/usr/bin/git","rev-parse","FETCH_HEAD"]).strip()==head
 run("remote-fetch",["/usr/bin/git","fetch","--no-tags","origin",remote_ref])
 assert run("remote-fetched-head",["/usr/bin/git","rev-parse","FETCH_HEAD"]).strip()==expected_remote
 remote_read("remote-before-integration",expected_remote)
 run("initial-is-ancestor",["/usr/bin/git","merge-base","--is-ancestor",initial,head])
 run("remote-is-ancestor",["/usr/bin/git","merge-base","--is-ancestor",expected_remote,head])
 delta=set(run("native-source-diff",["/usr/bin/git","diff","--name-only",initial,head]).splitlines())
 prefix="evidence/pq-migration-recovery-20261107-e1dee/"
 evidence={"README.md","SHA256SUMS","artifact-index.json","integrated-local-validation.tar.gz","local-validation.tar.gz",
           "native-integrated-9fb011c.tar.gz","native-migration-37ef493.tar.gz","native-recovery-2058225.tar.gz",
           "qualification.json","readbacks-and-controller-records.tar.gz","recovery-red.bundle","source-map.json","two-host-result.json"}
 assert delta=={prefix+n for n in evidence}|{"docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md"}
 result["native_source_delta_paths"]=sorted(delta)
 run("publication-ff",["/usr/bin/git","-c","core.hooksPath=.githooks","merge","--ff-only",head])
 assert run("publication-head",["/usr/bin/git","rev-parse","HEAD"]).strip()==head
 assert run("publication-tree",["/usr/bin/git","rev-parse","HEAD^{tree}"]).strip()==tree
 assert run("publication-clean",["/usr/bin/git","status","--porcelain=v1"])==""
 hook=run("original-prepush-hook",["/usr/bin/git","ls-files","-s",".githooks/pre-push"]).strip()
 assert hook.startswith("100755 fe4beecc9317e3a6e6137b0fabc7803a7de5cfff 0\t")
 result["prepush_hook"]=hook
 recorded("preflight",["/bin/bash","scripts/project-preflight.sh"])
 recorded("push-dry-run",["/usr/bin/git","-c","core.hooksPath=.githooks","push","--dry-run","origin","HEAD:"+remote_ref])
 remote_read("remote-immediately-before-push",expected_remote)
 result["actual_push_attempted"]=True;checkpoint()
 recorded("push",["/usr/bin/git","-c","core.hooksPath=.githooks","push","origin","HEAD:"+remote_ref])
 result["remote_after"]=remote_read("remote-after-push",head)
 result["actual_push_observed"]=True;checkpoint()
 print(json.dumps({"publication_observed":True,"remote_head":head,"remote_ref":remote_ref}),flush=True)
 for label,directory in (("original-source",task/"source"),("corrected-source",task/"corrected-source")):
  assert run(label+"-after",["/usr/bin/git","rev-parse","HEAD","HEAD^{tree}"],directory)==isolation[label]
 assert run("final-clean",["/usr/bin/git","status","--porcelain=v1"])==""
 result["isolation_after_matches_before"]=True
 result["status"]="published_and_verified"
except Exception as error:
 result["status"]="failed";result["error"]=str(error)
result["finished_unix_ns"]=str(time.time_ns());save(out/"result.json",result);checkpoint()
print(json.dumps({"status":result["status"],"head":head,"actual_push_attempted":result["actual_push_attempted"],
                  "actual_push_observed":result["actual_push_observed"],"error":result.get("error")}),flush=True)
sys.exit(0 if result["status"]=="published_and_verified" else 1)
