#!/usr/bin/env python3
"""Retain one small GitHub-plugin download URL, with complete API ZIP identity."""
from pathlib import Path, PurePosixPath
import hashlib, io, json, re, stat, sys, urllib.parse, urllib.request, zipfile

def need(ok,message):
    if not ok: raise ValueError(message)
def unique(pairs):
    out={}
    for k,v in pairs:
        need(k not in out,"Duplicate input field");out[k]=v
    return out
def main():
    raw=sys.stdin.buffer.read(8193);need(len(raw)<=8192,"Bounded input required")
    v=json.loads(raw,object_pairs_hook=unique)
    need(type(v) is dict and set(v)=={"url","output","bytes","sha256"},"Exact download identity required")
    need(type(v["bytes"]) is int and 0<v["bytes"]<=64<<20,"Small-artifact profile exceeded")
    need(type(v["sha256"]) is str and re.fullmatch("[0-9a-f]{64}",v["sha256"]),"Invalid API SHA")
    u=urllib.parse.urlparse(v["url"])
    need(u.scheme=="https" and u.hostname and (
        u.hostname.endswith(".oaiusercontent.com") or u.hostname.endswith(".blob.core.windows.net")),
        "Use the approved GitHub plugin's returned file URL")
    dest=Path(v["output"])
    need(dest.is_absolute() and dest==dest.resolve() and not dest.exists(),"Fresh canonical private output required")
    need(dest.parent.is_dir(),"Output parent must already exist")
    with urllib.request.urlopen(v["url"],timeout=40) as response:
        data=response.read(v["bytes"]+1)
    need(len(data)==v["bytes"] and hashlib.sha256(data).hexdigest()==v["sha256"],"Complete ZIP differs from API digest")
    entries=[]
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names=z.namelist();need(len(names)==len(set(names)),"Duplicate ZIP names")
        need(sum(i.file_size for i in z.infolist())<=512<<20,"Expanded small-artifact bound exceeded")
        for i in z.infolist():
            name=i.filename
            q=PurePosixPath(name)
            need(name and not q.is_absolute() and ".." not in q.parts and "\\" not in name and "\0" not in name,
                 "Unsafe member")
            mode=i.external_attr>>16
            need(stat.S_IFMT(mode) in (0,stat.S_IFREG,stat.S_IFDIR),"Special ZIP member")
            blob=z.read(i)
            entries.append({"path":name,"bytes":len(blob),"sha256":hashlib.sha256(blob).hexdigest(),
                            "directory":i.is_dir(),"mode":mode})
    dest.mkdir(mode=0o700)
    (dest/"original-artifact.zip").write_bytes(data)
    record={"schema":"trnm.github-plugin-full-zip-retention.v1","status":"PASS",
            "archive":{"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()},
            "entries":entries,"source":"GitHub plugin returned temporary file URL",
            "all_member_bytes_read":True,"runtime_or_qualification_reexecuted":False}
    (dest/"index.json").write_text(json.dumps(record,sort_keys=True,indent=2)+"\n")
    print(json.dumps({"status":"PASS","output":str(dest),"archive":record["archive"],"members":len(entries)}))
if __name__=="__main__":main()
