"""Small deterministic regression for a lost adaptive-publication timer.

This uses a caller-conditioned one-item lottery, not a W1 or hardware result.
No network access, real miner, long campaign, or repository writes occur.
"""
from __future__ import annotations

import argparse
from dataclasses import asdict
from fractions import Fraction
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path.cwd(),
                        help='Trillionnium-Chain repository root (default: current directory)')
    parser.add_argument('--model-source', type=Path,
                        help='optional saved quantum_network_sim.py snapshot')
    args = parser.parse_args()
    repo = args.repo.resolve()
    model_dir = repo / 'formal/pon-nakamoto-v1'
    if not (model_dir / 'quantum_network_sim.py').is_file():
        parser.error('--repo must name a Trillionnium-Chain source root')
    sys.path.insert(0, str(model_dir))
    source = args.model_source.resolve() if args.model_source else model_dir / 'quantum_network_sim.py'
    # A unique module name avoids accidentally reusing another test's import.
    spec = importlib.util.spec_from_file_location('network_timeout_review_model', source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)

    case = module.NetworkScenario(
        'timeout_rounding_review',
        duration_seconds=1.0,
        classical_block_rate_at_initial_target=0,
        quantum_strategy='private-branch',
        private_release_policy='observed-work-lead',
        private_release_work_lead=100,
        private_release_max_wait_seconds=0.1,
        quantum_fixed_iterations=0,
        quantum_prepare_seconds=0,
        quantum_measure_seconds=0.25,
        quantum_candidate_check_seconds=0.25,
        quantum_proof_seconds=0,
        quantum_domain_size=1,
        quantum_domain_marked_count=1,
        probe_arrival_seconds=0,
        # First winner is ready at 0.5; only the next search is interrupted.
        shocks=(module.ParticipationShock(0.55, 1, 0),),
    )
    sim = module.Simulator(case)
    summary, trace = sim.run()
    release_checks = [row for row in trace if row['kind'] == 'adaptive-release-check']
    published = [row for row in trace if row['kind'] == 'publish']
    exact_deadline = Fraction(0.5) + Fraction(case.private_release_max_wait_seconds)
    result = {
        'source': str(source),
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'fixture': asdict(case),
        'first_private_block_seconds': next(row['at_seconds'] for row in trace if row['kind'] == 'block'),
        'exact_timeout_deadline': str(exact_deadline),
        'nearest_float_deadline': 0.5 + case.private_release_max_wait_seconds,
        'nearest_float_elapsed': (0.5 + case.private_release_max_wait_seconds) - 0.5,
        'release_count': sim.adaptive_releases,
        'pending_adaptive_timer': sim.adaptive_next_check,
        'release_checks': release_checks,
        'publications': published,
        'search_cancelled_seconds': summary['miners']['q']['wasted_search_seconds'],
        'regression_observed': not published,
        'boundary': 'synthetic conditional lottery; not native W1 or quantum hardware',
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
