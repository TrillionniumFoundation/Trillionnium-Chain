"""Actual bounded interleavings after V5 source changes; not continuous same-UID safety."""
from pathlib import Path
import fcntl,hashlib,json,os,signal,stat,struct,subprocess,sys,time,types
BASE=Path("/tmp/trnm-genesis-owner-20261116-8ppak97a");ROOT=BASE/"repo";BUILD=BASE/"build-v5";OUT=BASE/"interleavings-v5"
sys.path.insert(0,str(ROOT))
IO = "\"\"\"Hosted observation of a real native process; no persistence or State algorithm.\"\"\"\nfrom __future__ import annotations\nimport fcntl,hashlib,json,os,resource,select,signal,stat,struct,subprocess,time\nfrom pathlib import Path\nfrom .build import need\nLIMIT=(1<<64)-1\nCHILD_SECONDS=240\nCLEANUP_SECONDS=3\ndef identity(raw):\n    return {\"bytes\":len(raw),\"sha256\":hashlib.sha256(raw).hexdigest()}\ndef request(op):\n    return b\"NGCMD001\"+struct.pack(\"<Q\",op)\ndef bootstrap(fd,mode=0,timestamp=None,workers=1,gate=(LIMIT,LIMIT)):\n    return b\"NGBOOT01\"+struct.pack(\"<7Q\",fd,mode,int(timestamp is not None),timestamp or 0,workers,*gate)\ndef snapshot(directory):\n    result={}\n    for path in sorted(directory.iterdir()):\n        st=path.lstat()\n        item={\"mode\":st.st_mode,\"uid\":st.st_uid,\"gid\":st.st_gid,\"links\":st.st_nlink,\n              \"dev\":st.st_dev,\"ino\":st.st_ino,\"bytes\":st.st_size}\n        if stat.S_ISREG(st.st_mode):\n            raw=path.read_bytes();item[\"content\"]=identity(raw)\n        elif stat.S_ISLNK(st.st_mode):\n            item[\"target\"]=os.readlink(path)\n        result[path.name]=item\n    return result\ndef parse_record(raw):\n    need(len(raw)>=512 and raw[:8]==b\"NGSTATE1\",\"Native record magic\")\n    q=lambda p:struct.unpack_from(\"<Q\",raw,p)[0]\n    need(q(8)==len(raw) and q(24)==1 and q(384)==7,\"Native record extent/version\")\n    settings=raw[512:]\n    need(settings[:4]==b\"SDO1\" and struct.unpack_from(\"<I\",settings,4)[0]==len(settings),\"Settings record\")\n    params_n,model_n,state_n=struct.unpack_from(\"<III\",settings,456)\n    at=576+params_n+model_n\n    need(q(400)==len(settings) and q(416)==512+at and q(392)==state_n\n         and at+state_n==len(settings),\"Native State offsets\")\n    params=json.loads(settings[576:576+params_n])\n    model=json.loads(settings[576+params_n:at])\n    state=settings[at:]\n    need(state[:4]==b\"SRV1\" and struct.unpack_from(\"<I\",state,4)[0]==7,\"Native State framing\")\n    cursor=8;rows=[]\n    for _ in range(7):\n        need(cursor+8<=len(state),\"State row header truncated\")\n        kn,vn=struct.unpack_from(\"<II\",state,cursor);cursor+=8\n        need(kn<=160 and vn<=4096 and cursor+kn+vn<=len(state),\"State cell extent\")\n        key=state[cursor:cursor+kn].decode();cursor+=kn\n        value=state[cursor:cursor+vn];cursor+=vn\n        json.loads(value)\n        rows.append({\"key\":key,\"value_hex\":value.hex()})\n    need(cursor==len(state) and [r[\"key\"] for r in rows]==sorted({r[\"key\"] for r in rows}),\"State row order\")\n    zero_fields=(16,192,200,216,224,232,304,312,320,328,336,352,360,368,376,408,440,448,456,464,472,480,488,496,504)\n    need(all(q(p)==0 for p in zero_fields) and raw[240:304]==bytes(64),\"Non-genesis catalog fields\")\n    need(q(208)==q(344)==1 and raw[160:192]==raw[96:128] and q(424)==512,\"Genesis catalog cardinality\")\n    need(raw[32:160]==settings[24:88]+settings[152:216] and q(432)==struct.unpack_from(\"<Q\",settings,16)[0],\n         \"Settings/catalog context differs\")\n    return {\"record\":identity(raw),\"network\":raw[32:64].hex(),\"parameters\":raw[64:96].hex(),\n        \"genesis\":raw[96:128].hex(),\"state_root\":raw[128:160].hex(),\n        \"active_tip\":raw[160:192].hex(),\"generation\":q(192),\"slot\":q(200),\n        \"height\":q(216),\"parent\":None,\"packet\":None,\"chainwork\":raw[240:304].hex(),\n        \"rows\":rows,\"snapshot_rows\":rows,\n        \"collections\":{\"blocks\":q(208),\"snapshots\":q(344),\"deltas\":q(304),\"events\":q(312),\n          \"reorg\":q(320),\"steps\":q(328),\"reorg_lifecycle_v1\":q(336),\"ancestry_jump\":q(408),\n          \"local_pool_metadata\":q(352),\"local_pool_groups\":q(352),\"local_pool_rows\":q(352),\n          \"local_pool_removals\":q(352),\"peer_replay\":q(360),\"peer_request_audit\":q(368),\"peer_outbox\":q(376)},\n        \"settings\":{\"params\":params,\"model_registry\":model,\n          \"network\":settings[24:56].hex(),\"parameters\":settings[56:88].hex(),\n          \"family\":settings[88:120].hex(),\"plan\":settings[120:152].hex(),\n          \"genesis_time\":struct.unpack_from(\"<Q\",settings,16)[0],\n          \"task\":settings[216:248].hex(),\"fees\":list(struct.unpack_from(\"<25Q\",settings,248)),\n          \"evaluators\":[settings[480+32*i:512+32*i].hex() for i in range(3)]},\n        \"native_schema\":\"NGSTATE1/version1\",\"schema_bytes_equal_to_sqlite\":False}\ndef parse_success(stdout):\n    need(len(stdout)>=320 and stdout[:8]==b\"NGOPEN01\" and stdout[256:264]==b\"NGREAD01\",\"Native response framing\")\n    size=struct.unpack_from(\"<Q\",stdout,264)[0]\n    need(len(stdout)==320+size,\"Native complete READ response\")\n    data=stdout[320:];observed=parse_record(data)\n    need(stdout[32:160]==data[32:160] and stdout[272:304]==data[128:160],\"Native response identities\")\n    return observed,data\n\nclass Session:\n    def __init__(self,executable:bytes,output:Path,directory:Path,*,mode=0,timestamp=None,workers=1,\n                 gate=False,fd_override=None,boot_override=None,file_limit=None,stdout_closed=False):\n        output.mkdir(mode=0o700);self.output=output;self.start=time.monotonic_ns()\n        self.stdin=bytearray();self.stdout=bytearray();self.events_raw=bytearray();self.events=[];self.extra={};self.stdin_written=0\n        self.gate_reader=None;self.gate_writer=None;self.finished=False\n        self.meta={\"executable\":identity(executable),\"mode\":mode,\"timestamp\":timestamp,\"workers\":workers}\n        image=os.memfd_create(\"native-genesis-owner\",os.MFD_ALLOW_SEALING)\n        cursor=0\n        while cursor<len(executable):\n            count=os.write(image,executable[cursor:]);need(count>0,\"Sealed image short write\");cursor+=count\n        need(os.pread(image,len(executable),0)==executable,\"Sealed executable readback\")\n        os.fchmod(image,0o500);fcntl.fcntl(image,1033,15)\n        directory_fd=os.open(directory,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC) if fd_override is None else os.dup(fd_override)\n        inherited=[image,directory_fd];close_parent=[image,directory_fd]\n        pair=(LIMIT,LIMIT)\n        if gate:\n            event_r,event_w=os.pipe();resume_r,resume_w=os.pipe()\n            pair=(event_w,resume_r);inherited.extend(pair);close_parent.extend(pair)\n            self.gate_reader=event_r;self.gate_writer=resume_w\n        payload=bootstrap(directory_fd,mode,timestamp,workers,pair)\n        if boot_override is not None:payload=boot_override(payload,pair,directory_fd)\n        def limits():\n            resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))\n            if file_limit is not None:\n                signal.signal(signal.SIGXFSZ,signal.SIG_IGN)\n                resource.setrlimit(resource.RLIMIT_FSIZE,(file_limit,file_limit))\n        try:\n            self.process=subprocess.Popen([\"/proc/self/fd/\"+str(image)],stdin=subprocess.PIPE,\n                stdout=subprocess.PIPE,stderr=subprocess.PIPE,pass_fds=tuple(inherited),\n                env={\"PATH\":\"\"},cwd=output,start_new_session=True,umask=0o077,preexec_fn=limits)\n        finally:\n            for fd in close_parent:os.close(fd)\n        if stdout_closed:\n            self.process.stdout.close();self.extra[\"stdout_reader_closed_before_boot\"]=True\n        self.send(payload)\n    def send(self,data):\n        self.stdin.extend(data)\n        try:\n            cursor=0\n            while cursor<len(data):\n                count=os.write(self.process.stdin.fileno(),data[cursor:])\n                need(count>0,\"Controller short stdin write\")\n                cursor+=count;self.stdin_written+=count\n        except BrokenPipeError:\n            self.extra[\"stdin_epipe\"]=True\n    def _read(self,fd,n):\n        result=bytearray();deadline=self.start/1e9+CHILD_SECONDS\n        while len(result)<n:\n            remaining=deadline-time.monotonic()\n            need(remaining>0,\"Native read exceeded unchanged child budget\")\n            ready,_,_=select.select([fd],[],[],remaining)\n            need(bool(ready),\"Native read timed out\")\n            block=os.read(fd,n-len(result))\n            need(bool(block),\"Native response EOF\")\n            result+=block\n            if fd==self.gate_reader:self.events_raw.extend(block)\n            else:self.stdout.extend(block)\n        return bytes(result)\n    def opened(self):\n        raw=self._read(self.process.stdout.fileno(),256)\n        need(raw[:8]==b\"NGOPEN01\",\"Owner did not publish an opened receipt\")\n        return raw\n    def gate_event(self):\n        need(self.gate_reader is not None,\"No diagnostic capability\")\n        raw=self._read(self.gate_reader,32)\n        need(raw[:8]==b\"NGCUT001\",\"Diagnostic event framing\")\n        event={\"sequence\":struct.unpack_from(\"<Q\",raw,8)[0],\"tag\":struct.unpack_from(\"<Q\",raw,16)[0],\n            \"private_published_flag\":struct.unpack_from(\"<Q\",raw,24)[0],\"raw_hex\":raw.hex()}\n        need(event[\"sequence\"]==len(self.events)+1,\"Diagnostic event order\")\n        self.events.append(event);return event\n    def resume(self,byte=b\"\\1\"):\n        need(self.gate_writer is not None,\"Gate already closed\")\n        os.write(self.gate_writer,byte)\n    def advance(self,tag):\n        while True:\n            event=self.gate_event()\n            if event[\"tag\"]==tag:return event\n            self.resume()\n    def gate_eof(self):\n        need(self.gate_writer is not None,\"Gate already closed\")\n        os.close(self.gate_writer);self.gate_writer=None\n    def kill(self):\n        if self.process.poll() is None:\n            try:os.killpg(self.process.pid,signal.SIGKILL)\n            except ProcessLookupError:pass\n    def finish(self,*,close=False,read=False,expect_running=False):\n        if close:self.send((request(1) if read else b\"\")+request(2))\n        timeout=max(0.001,self.start/1e9+CHILD_SECONDS-time.monotonic())\n        timed_out=False\n        try:\n            if self.process.stdout.closed:\n                self.process.stdout=None\n            stdout,stderr=self.process.communicate(timeout=timeout)\n        except subprocess.TimeoutExpired:\n            timed_out=True;self.kill();stdout,stderr=self.process.communicate(timeout=CLEANUP_SECONDS)\n        self.stdout.extend(stdout or b\"\");self.finished=True\n        for name in (\"gate_reader\",\"gate_writer\"):\n            fd=getattr(self,name)\n            if fd is not None:\n                os.close(fd);setattr(self,name,None)\n        for name,raw in ((\"stdin.raw\",bytes(self.stdin)),(\"stdout.raw\",bytes(self.stdout)),(\"stderr.raw\",stderr),(\"events.raw\",bytes(self.events_raw))):\n            (self.output/name).write_bytes(raw)\n        (self.output/\"events.json\").write_text(json.dumps(self.events,sort_keys=True,indent=2)+\"\\n\")\n        diagnostic=list(struct.unpack(\"<7Q\",stderr)) if len(stderr)==56 else None\n        row={\"schema\":\"trnm.native-genesis-process.v1\",**self.meta,\"pid\":self.process.pid,\n            \"exit_code\":self.process.returncode,\"timed_out\":timed_out,\"elapsed_ns\":time.monotonic_ns()-self.start,\n            \"child_budget_seconds\":CHILD_SECONDS,\"cleanup_budget_seconds\":CLEANUP_SECONDS,\n            \"stdin\":identity(bytes(self.stdin)),\"stdin_actual_write_bytes\":self.stdin_written,\"stdout\":identity(bytes(self.stdout)),\"stderr\":identity(stderr),\n            \"stderr_hex\":stderr.hex(),\"diagnostic\":diagnostic,\"events\":self.events,\n            \"path\":str(self.output),**self.extra}\n        (self.output/\"process.json\").write_text(json.dumps(row,sort_keys=True,indent=2)+\"\\n\")\n        return row,bytes(self.stdout)\n    def cleanup(self):\n        if not self.finished:\n            self.kill()\n            return self.finish()\n        return None\n"

module=types.ModuleType("hia.platform.genesis_store.private_v5_probe_io")
module.__package__="hia.platform.genesis_store"
exec(compile(IO,str(BASE/"interleavings-v5-io.py"),"exec"),module.__dict__)
Session=module.Session;need=module.need
from hia.platform.genesis_store.build import source_manifest
OUT.mkdir(mode=0o700)
receipt=json.loads((BUILD/"build.json").read_bytes())
need(source_manifest(ROOT)==receipt["source_inputs"],"Source changed after V5 build")
exe=(BUILD/"genesis-owner.elf").read_bytes()
need(hashlib.sha256(exe).hexdigest()=="4d0529d1e9fd11f84bab4a33b33310ea9421cdd1ca821dae7bc3958c40815a72","V5 ELF changed")
rows=[]
def append(row):
 rows.append(row)
 (OUT/"observations.json").write_text(json.dumps(rows,sort_keys=True,indent=2)+"\n")
 print(json.dumps({"control":row["name"],"status":row["status"],"exit":row.get("process",{}).get("exit_code")}),flush=True)
def simple(directory,label,mode=0):
 session=Session(exe,OUT/(label+"-process"),directory,mode=mode)
 try:
  session.send(module.request(1)+module.request(2));process,stdout=session.finish()
  need(process["exit_code"]==0 and process["stderr"]["bytes"]==0 and not process["timed_out"],label+" actual process")
  observed,data=module.parse_success(stdout)
  return process,observed,data
 finally:session.cleanup()
try:
 directory=OUT/"baseline-namespace";directory.mkdir(mode=0o700)
 process,observed,record=simple(directory,"fresh")
 append({"name":"fresh-full-read-close","status":"PASS","process":process,"record":module.identity(record)})
 (OUT/"native-record.raw").write_bytes(record)
 before=module.snapshot(directory)
 process,again,actual=simple(directory,"cold-reopen",1)
 need(actual==record and module.snapshot(directory)==before,"Actual cold read or namespace differs")
 append({"name":"fresh-process-full-cold-read","status":"PASS","process":process,"record":module.identity(actual)})
 name="ng1."+record[96:128].hex()
 recovery=OUT/"recovery-namespace";recovery.mkdir(mode=0o700)
 (recovery/"ng1.owner.lock").write_bytes(b"");(recovery/"ng1.owner.lock").chmod(0o600)
 (recovery/(name+".pending")).write_bytes(record[:16]);(recovery/(name+".pending")).chmod(0o600)
 process,again,actual=simple(recovery,"valid-prefix-recover",2)
 need(actual==record and not (recovery/(name+".pending")).exists(),"Actual prefix repair differs")
 append({"name":"actual-prefix-recover-full-read","status":"PASS","process":process,"record":module.identity(actual)})
 cases=[
 ("replace-pending-after-validation",13,"replace",0,65),
 ("change-pending-content-after-validation",13,"change",0,66),
 ("replace-held-lock-after-gate",1,"lock",0,65),
 ("replace-held-lock-after-create",10,"lock",0,65),
 ("replace-empty-pending-after-create",10,"replace-equal",0,65),
 ("append-empty-pending-after-create",10,"append",0,65),
 ("change-recovery-prefix-after-validation",12,"change",2,66),
 ("extend-recovery-prefix-after-validation",12,"append",2,65),
 ("replace-recovery-prefix-after-validation",12,"replace-equal",2,65),
 ("replace-held-lock-before-rename",13,"lock",0,65),
 ("change-final-before-directory-sync",14,"change",0,71),
 ("replace-final-after-directory-sync",15,"replace-equal",0,65),
 ("change-final-before-cold-open-read",20,"change",0,66),
 ("change-final-before-explicit-read",30,"change",0,66),
 ("replace-held-lock-before-explicit-read",30,"lock",0,65)]
 for label,tag,action,mode,expected in cases:
  directory=OUT/(label+"-namespace");directory.mkdir(mode=0o700)
  if mode==2:
   (directory/"ng1.owner.lock").write_bytes(b"");(directory/"ng1.owner.lock").chmod(0o600)
   (directory/(name+".pending")).write_bytes(record[:2048]);(directory/(name+".pending")).chmod(0o600)
  session=Session(exe,OUT/(label+"-process"),directory,mode=mode,gate=True)
  session.send((module.request(1) if tag==30 else b"")+module.request(2))
  changed=False;after_action=None;publication_before_action=None
  try:
   while True:
    try:event=session.gate_event()
    except ValueError as error:
     if "EOF" not in str(error):raise
     break
    if event["tag"]==tag and not changed:
     publication_before_action=event["private_published_flag"]
     if action=="lock":
      path=directory/"ng1.owner.lock";replacement=OUT/(label+"-replacement")
      replacement.write_bytes(b"");replacement.chmod(0o600);os.replace(replacement,path)
     else:
      path=next(p for p in directory.iterdir() if p.name.endswith(".pending") or p.name.endswith(".state"))
      prior=path.read_bytes();(OUT/(label+"-prior.raw")).write_bytes(prior)
      bad=bytearray(prior)
      if action in ("replace","change"):
       need(bool(bad),"Mutation requires existing bytes");bad[-1]^=1
      if action in ("replace","replace-equal"):
       replacement=OUT/(label+"-replacement");replacement.write_bytes(bad);replacement.chmod(0o600);os.replace(replacement,path)
      elif action=="append":
       with path.open("ab",buffering=0) as stream:stream.write(b"x")
      else:
       with path.open("r+b",buffering=0) as stream:
        stream.seek(len(bad)-1);stream.write(bad[-1:])
     changed=True;after_action=module.snapshot(directory)
    session.resume()
   process,stdout=session.finish()
   need(changed,label+" did not reach actual cut")
   after=module.snapshot(directory)
   need(process["exit_code"]==expected and not process["timed_out"],label+" incorrect native refusal")
   need(len(stdout)==(256 if tag==30 else 0),label+" unexpected success data")
   need(after==after_action,label+" owner mutated namespace after controlled replacement")
   if tag in (1,10,12,13):
    need(not any(n.endswith(".state") for n in after),label+" wrongly published")
   need(process["diagnostic"][3]==int(tag==14),label+" wrong uncertainty classification")
   append({"name":label,"status":"PASS","process":process,"after_controller_action":after_action,
    "after_native_refusal":after,"publication_preceded_controller_action":bool(publication_before_action),
    "native_post_action_mutation":False,"receipt_bytes":len(stdout)})
  finally:session.cleanup()
 # Actual descriptor substitutions. All must fail silently before reading bootstrap or touching owner files.
 capdir=OUT/"stdio-namespace";capdir.mkdir(mode=0o700)
 image=OUT/"stdio-native.elf";image.write_bytes(exe);image.chmod(0o500)
 for variant in ("stdout-regular","stderr-regular","stdin-regular","stdout-stderr-same-pipe","stdout-rdwr-fifo","stderr-opath-fifo"):
  label="stdio-"+variant;opened=[];before=module.snapshot(capdir)
  fd=os.open(capdir,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC);opened.append(fd)
  std={"stdin":subprocess.PIPE,"stdout":subprocess.PIPE,"stderr":subprocess.PIPE}
  target=OUT/(label+"-target");target.write_bytes(b"UNMODIFIED-DESCRIPTOR-TARGET");target.chmod(0o600)
  target_before=target.read_bytes()
  if variant in ("stdout-regular","stderr-regular"):
   change=os.open(target,os.O_WRONLY|os.O_CLOEXEC);opened.append(change);std[variant.split("-")[0]]=change
  elif variant=="stdin-regular":
   change=os.open(target,os.O_RDONLY|os.O_CLOEXEC);opened.append(change);std["stdin"]=change
  elif variant=="stdout-stderr-same-pipe":
   std["stderr"]=subprocess.STDOUT
  else:
   fifo=OUT/(label+"-fifo");os.mkfifo(fifo,0o600)
   change=os.open(fifo,(os.O_RDWR|os.O_NONBLOCK) if variant=="stdout-rdwr-fifo" else os.O_PATH)
   opened.append(change);std["stdout" if variant.startswith("stdout") else "stderr"]=change
  payload=module.bootstrap(fd)+module.request(2)
  start=time.monotonic_ns()
  process=subprocess.Popen([str(image)],**std,pass_fds=(fd,),env={"PATH":""},cwd=OUT,start_new_session=True,umask=0o077)
  try:
   stdout,stderr=process.communicate(payload if std["stdin"]==subprocess.PIPE else None,timeout=240)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);stdout,stderr=process.communicate(timeout=3)
   raise ValueError(label+" timeout")
  finally:
   for item in opened:os.close(item)
  stdout=stdout or b"";stderr=stderr or b""
  (OUT/(label+".stdout.raw")).write_bytes(stdout);(OUT/(label+".stderr.raw")).write_bytes(stderr)
  need(process.returncode==64 and not stdout and not stderr,label+" was not silently refused")
  need(target.read_bytes()==target_before and module.snapshot(capdir)==before,label+" changed disk")
  append({"name":label,"status":"PASS","exit_code":process.returncode,"stdout":module.identity(stdout),
    "stderr":module.identity(stderr),"target":module.identity(target_before),"owner_namespace_unchanged":True,
    "elapsed_ns":time.monotonic_ns()-start})
 need(source_manifest(ROOT)==receipt["source_inputs"],"Source changed during V5 physical observations")
 report={"schema":"trnm.native-genesis-bounded-gate-stdio-controls.v1","status":"PASS",
  "source_build":str(BUILD/"build.json"),"source_set_sha256":receipt["source_set_sha256"],
  "executable":module.identity(exe),"controls":rows,"controls_total":len(rows),
  "prior_three_actual_failures":str(BASE/"interleavings-v4/report.json"),
  "all_prepublication_controller_replacements_refused_before_publication":True,
  "no_claim_of_continuous_hostile_same_uid_safety":True,"no_claim_of_physical_power_loss":True,
  "original_rust":"NOT_RUN","unit_fully_qualified":False,"complete_node":False}
 (OUT/"report.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
 print(json.dumps({"status":"PASS","controls":len(rows),"executable":module.identity(exe)}))
except BaseException as error:
 (OUT/"failure.json").write_text(json.dumps({"status":"FAIL","error":repr(error),"observations":rows},sort_keys=True,indent=2)+"\n")
 raise
