/* Bounded ML-DSA Pure EVP observer. No protocol/current-authority behavior.
 * Linked to the same pinned static libcrypto as the independently built CLI.
 * A non-NULL message allocation permits length zero without app_malloc(0).
 */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/core_names.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/params.h>
#include <openssl/pem.h>
#include <openssl/provider.h>
#include <openssl/x509.h>

static unsigned char *read_file(const char *path, size_t limit, size_t *len) {
    FILE *f = fopen(path, "rb");
    unsigned char *data = NULL;
    long size;
    if (f == NULL || fseek(f, 0, SEEK_END) != 0)
        goto end;
    size = ftell(f);
    if (size < 0 || (unsigned long)size > limit || fseek(f, 0, SEEK_SET) != 0)
        goto end;
    data = OPENSSL_malloc(size == 0 ? 1 : (size_t)size);
    if (data == NULL)
        goto end;
    if (fread(data, 1, (size_t)size, f) != (size_t)size || fgetc(f) != EOF
        || ferror(f)) {
        OPENSSL_free(data);
        data = NULL;
        goto end;
    }
    *len = (size_t)size;
end:
    if (f != NULL)
        fclose(f);
    return data;
}

static int unhex_context(const char *hex, unsigned char *context, size_t *len) {
    size_t n = strlen(hex);
    if (strcmp(hex, "-") == 0) {
        *len = 0;
        return 1;
    }
    if (n == 0 || n > 510 || n % 2 != 0)
        return 0;
    for (size_t i = 0; i < n; ++i)
        if (!((hex[i] >= '0' && hex[i] <= '9') || (hex[i] >= 'a' && hex[i] <= 'f')))
            return 0;
    for (size_t i = 0; i < n / 2; ++i) {
        unsigned int value;
        if (sscanf(hex + 2 * i, "%2x", &value) != 1)
            return 0;
        context[i] = (unsigned char)value;
    }
    *len = n / 2;
    return 1;
}

int main(int argc, char **argv) {
    const char *algorithm;
    int signing, result = 5, verified;
    size_t message_len = 0, signature_len = 0, key_len = 0, context_len = 0;
    size_t required_signature;
    unsigned char *message = NULL, *signature = NULL, *der = NULL;
    unsigned char context[255] = {0};
    const unsigned char *cursor;
    EVP_PKEY *key = NULL;
    EVP_MD_CTX *ctx = NULL;
    BIO *key_bio = NULL;
    OSSL_PROVIDER *provider = NULL;
    FILE *output = NULL;
    OSSL_PARAM params[2];
    if (argc == 2 && strcmp(argv[1], "version") == 0) {
        puts(OpenSSL_version(OPENSSL_VERSION));
        return 0;
    }
    if (argc != 7 || (strcmp(argv[1], "sign") != 0 && strcmp(argv[1], "verify") != 0)) {
        fputs("usage: sign|verify 65|87 key message signature context-hex-or-dash\n", stderr);
        return 5;
    }
    signing = strcmp(argv[1], "sign") == 0;
    if (strcmp(argv[2], "65") == 0) {
        algorithm = "ML-DSA-65";
        required_signature = 3309;
    } else if (strcmp(argv[2], "87") == 0) {
        algorithm = "ML-DSA-87";
        required_signature = 4627;
    } else {
        fputs("unsupported parameter set\n", stderr);
        return 5;
    }
    if (!unhex_context(argv[6], context, &context_len))
        goto end;
    provider = OSSL_PROVIDER_load(NULL, "default");
    if (provider == NULL)
        goto end;
    if (signing) {
        key_bio = BIO_new_file(argv[3], "rb");
        if (key_bio == NULL)
            goto end;
        key = PEM_read_bio_PrivateKey_ex(key_bio, NULL, NULL, NULL, NULL, "provider=default");
    } else {
        der = read_file(argv[3], 4096, &key_len);
        if (der == NULL)
            goto end;
        cursor = der;
        key = d2i_PUBKEY_ex(NULL, &cursor, (long)key_len, NULL, "provider=default");
        if (cursor != der + key_len)
            goto end;
    }
    if (key == NULL || EVP_PKEY_is_a(key, algorithm) != 1)
        goto end;
    message = read_file(argv[4], 65536, &message_len);
    ctx = EVP_MD_CTX_new();
    if (message == NULL || ctx == NULL)
        goto end;
    params[0] = OSSL_PARAM_construct_octet_string(OSSL_SIGNATURE_PARAM_CONTEXT_STRING,
                                                 context, context_len);
    params[1] = OSSL_PARAM_construct_end();
    if (signing) {
        if (EVP_DigestSignInit_ex(ctx, NULL, NULL, NULL, "provider=default", key, params) != 1
            || EVP_DigestSign(ctx, NULL, &signature_len, message, message_len) != 1
            || signature_len != required_signature)
            goto end;
        signature = OPENSSL_malloc(signature_len);
        if (signature == NULL
            || EVP_DigestSign(ctx, signature, &signature_len, message, message_len) != 1
            || signature_len != required_signature)
            goto end;
        output = fopen(argv[5], "wbx");
        if (output == NULL || fwrite(signature, 1, signature_len, output) != signature_len
            || fflush(output) != 0)
            goto end;
        puts("SIGNATURE_WRITTEN");
        result = 0;
    } else {
        signature = read_file(argv[5], required_signature, &signature_len);
        if (signature == NULL || signature_len != required_signature
            || EVP_DigestVerifyInit_ex(ctx, NULL, NULL, NULL, "provider=default", key, params) != 1)
            goto end;
        verified = EVP_DigestVerify(ctx, signature, signature_len, message, message_len);
        if (verified == 1) {
            puts("ACCEPT");
            result = 0;
        } else if (verified == 0) {
            puts("REJECT_SIGNATURE");
            result = 3;
        }
    }
end:
    if (result == 5) {
        fputs("HARNESS_OR_EVP_ERROR\n", stderr);
        ERR_print_errors_fp(stderr);
    }
    if (output != NULL && fclose(output) != 0)
        result = 5;
    BIO_free(key_bio);
    EVP_MD_CTX_free(ctx);
    EVP_PKEY_free(key);
    OPENSSL_free(message);
    OPENSSL_free(signature);
    OPENSSL_free(der);
    if (provider != NULL)
        OSSL_PROVIDER_unload(provider);
    return result;
}
