#!/usr/bin/env python3
"""Read-only exact-commit desktop validation with retained native evidence.

Run only after the parent imports and selects the reviewed candidate. This script
does not fetch, checkout, reset, publish, install, change profiles, or retry tests.
The output must be a fresh sibling of this task's checkout. An explicit Cargo
target may use this task's unique namespace on the verified /data volume.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import time
from datetime import datetime, timezone

REPO = Path('/home/qian-qi/work/chain-pq-closure-20261111-d4d2')
BRANCH = 'fix/chain-pq-closure-20261111-d4d2'
PROVIDER = Path('/home/qian-qi/chain-stark-route-validation-7e8b/'
                'provider-clippy-eeeaafbc742d-retry01/'
                'trnm-pq-provider-3.5.9.wUXuiklK/install')
PROVIDER_FILES = ('bin/openssl', 'include/openssl/opensslv.h',
                  'include/openssl/configuration.h', 'lib/libcrypto.a', 'lib/libssl.a')
TOOLCHAIN = Path('/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
CARGO = '/home/qian-qi/.cargo/bin/cargo'
GIT = ('/usr/bin/git', '--no-replace-objects', '--no-optional-locks')
LOW_WATER = 10 * 1024**3
ROOT_TARGETS = (
    ('root_recovery_v3_native', 20), ('recovery_floor_v4_native', 9),
    ('root_effect_readback_v4_native', 14), ('root_budget_v4_native', 6),
    ('root_witness_v5_native', 17), ('root_witness_v5_durable_native', 12),
)
TLS_SELECTORS = (
    'ingress::pq_network::canonical_tests::pq_client_requires_complete_key_pin_after_identity_lookup',
    'ingress::pq_network::tls::tests::tls_local_identity_requires_complete_key_pin_for_both_roles',
    'ingress::pq_network::tls::tests::actual_tls_peer_identity_alias_refuses_before_application_dispatch_in_both_directions',
)
ENV_KEYS = ('PATH', 'RUSTUP_TOOLCHAIN', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
            'CARGO_TARGET_DIR', 'CARGO_NET_OFFLINE', 'RUSTC', 'RUSTFLAGS',
            'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER',
            'CARGO_PROFILE_TEST_DEBUG', 'CARGO_PROFILE_TEST_OPT_LEVEL',
            'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_DEV_OPT_LEVEL',
            'RUST_TEST_THREADS', 'OPENSSL_DIR', 'OPENSSL_STATIC', 'OPENSSL_LIB_DIR',
            'OPENSSL_INCLUDE_DIR', 'OPENSSL_NO_VENDOR', 'OPENSSL_CONF',
            'OPENSSL_MODULES', 'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256',
            'TRNM_PQ_OPENSSL_VERSION')


def now():
    return datetime.now(timezone.utc).isoformat()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write_json(path, obj):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(obj, stream, sort_keys=True, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def file_hash(path):
    path = Path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), f'not regular: {path}')
        digest, size = hashlib.sha256(), 0
        for part in iter(lambda: stream.read(1024**2), b''):
            digest.update(part)
            size += len(part)
        require(fingerprint(before) == fingerprint(os.fstat(stream.fileno())),
                f'changed descriptor: {path}')
    require(fingerprint(before) == fingerprint(path.lstat()), f'changed path: {path}')
    require(size == before.st_size, f'changed size: {path}')
    return {'bytes': size, 'sha256': digest.hexdigest(), 'mode': stat.S_IMODE(before.st_mode)}


def git(*args):
    return subprocess.check_output([*GIT, '-C', str(REPO), *args], timeout=120)


def identity(expected):
    head = git('rev-parse', 'HEAD').decode().strip()
    tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
    branch = git('branch', '--show-current').decode().strip()
    status = git('status', '--porcelain=v1', '--untracked-files=normal').decode()
    require(head == expected and branch == BRANCH, 'candidate HEAD/branch changed')
    require(not status, 'candidate worktree/index has changes: ' + status[:3000])
    return {'commit': head, 'tree': tree, 'branch': branch, 'status': status}


def read_exact(stream, size):
    out = bytearray()
    while len(out) < size:
        part = stream.read(size - len(out))
        require(part, 'truncated git blob stream')
        out.extend(part)
    return bytes(out)


def source_snapshot(expected, output):
    """Compare every actual tracked byte with the exact immutable Git blob.

    Git object IDs identify expected blobs, but the comparison itself streams
    original blob bytes and actual filesystem bytes; it does not trust a status
    cache, assume-unchanged flag, sparse checkout or worktree hash alone.
    """
    before = identity(expected)
    entries = git('ls-tree', '-rlz', '--full-tree', expected).split(b'\0')
    rows, total = [], 0
    with subprocess.Popen([*GIT, '-C', str(REPO), 'cat-file', '--batch'],
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE) as reader:
        try:
            for entry in filter(None, entries):
                meta, raw_path = entry.split(b'\t', 1)
                mode, kind, oid, raw_size = meta.split()
                require(kind == b'blob' and mode in (b'100644', b'100755', b'120000'),
                        'unsupported tracked type: ' + repr(entry))
                relative = raw_path.decode('utf-8', errors='strict')
                require(not relative.startswith('/') and '..' not in Path(relative).parts,
                        'unsafe tracked pathname')
                path = REPO / relative
                size = int(raw_size)
                reader.stdin.write(oid + b'\n')
                reader.stdin.flush()
                header = reader.stdout.readline().strip().split()
                require(header == [oid, b'blob', raw_size], 'git blob header mismatch')
                digest = hashlib.sha256()
                if mode == b'120000':
                    info = path.lstat()
                    require(stat.S_ISLNK(info.st_mode), f'tracked symlink changed: {relative}')
                    actual = os.fsencode(os.readlink(path))
                    expected_bytes = read_exact(reader.stdout, size)
                    require(actual == expected_bytes, f'symlink bytes mismatch: {relative}')
                    require(fingerprint(info) == fingerprint(path.lstat()),
                            f'symlink changed during read: {relative}')
                    digest.update(actual)
                else:
                    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
                    with os.fdopen(fd, 'rb') as actual:
                        info = os.fstat(actual.fileno())
                        require(stat.S_ISREG(info.st_mode) and info.st_size == size,
                                f'file type/size mismatch: {relative}')
                        require(bool(info.st_mode & 0o111) == (mode == b'100755'),
                                f'file executable mode mismatch: {relative}')
                        left = size
                        while left:
                            count = min(1024**2, left)
                            data = actual.read(count)
                            blob = read_exact(reader.stdout, count)
                            require(data == blob, f'exact Git blob mismatch: {relative}')
                            digest.update(data)
                            left -= count
                        require(actual.read(1) == b'', f'file grew: {relative}')
                        require(fingerprint(info) == fingerprint(os.fstat(actual.fileno())),
                                f'file changed during read: {relative}')
                    require(fingerprint(info) == fingerprint(path.lstat()),
                            f'file path changed during read: {relative}')
                require(reader.stdout.read(1) == b'\n', 'git blob delimiter mismatch')
                rows.append({'path': relative, 'mode': mode.decode(), 'git_blob': oid.decode(),
                             'bytes': size, 'sha256': digest.hexdigest()})
                total += size
            reader.stdin.close()
            require(reader.wait(timeout=60) == 0, 'git blob reader failed')
        except BaseException:
            reader.kill()
            reader.wait(timeout=30)
            raise
    require(identity(expected) == before, 'source identity changed during full read')
    value = {'schema': 'trnm-desktop-exact-source-v1', **before,
             'tracked_entries': len(rows), 'tracked_bytes': total,
             'all_actual_bytes_compared_with_git_blobs': True, 'files': rows}
    write_json(output, value)
    print(json.dumps({'source_snapshot': Path(output).name, 'files': len(rows),
                      'bytes': total, 'commit': expected}), flush=True)
    return value


def provider_snapshot(output):
    value = {'provider': str(PROVIDER), 'files': {p: file_hash(PROVIDER / p) for p in PROVIDER_FILES}}
    write_json(output, value)
    return value


def source_test_names(path, expected_count, prefix=''):
    source = (REPO / path).read_text()
    names = re.findall(r'^#\[test\]\s*\nfn ([A-Za-z0-9_]+)\(', source, re.M)
    require(len(names) == expected_count and len(set(names)) == expected_count,
            f'exact source test roster mismatch: {path}')
    return [prefix + name for name in names]


def native_result(text, expected, code):
    require(code == 0, 'native command exit was not zero')
    summaries = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; '
                           r'(\d+) measured; (\d+) filtered out; finished in .+$', text, re.M)
    require(len(summaries) == 1, 'exactly one native test summary required')
    outcome, passed, failed, ignored, measured, filtered = summaries[0]
    require((outcome, int(passed), int(failed), int(ignored), int(measured)) ==
            ('ok', len(expected), 0, 0, 0), 'native tests failed, missing, measured or ignored')
    found = re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\. (.+)$', text, re.M)
    require(len(found) == len(expected) and all(status == 'ok' for _, status in found),
            'all native test names must complete with ok')
    names = [name for name, _ in found]
    require(len(set(names)) == len(names) and set(names) == set(expected), 'native name set differs')
    require(re.findall(r'^running (\d+) tests?$', text, re.M) == [str(len(expected))],
            'actual native discovery count differs')
    return {'passed': len(names), 'tests': sorted(names), 'filtered_out': int(filtered)}


def command_plan():
    base = [CARGO, '+1.95.0']
    manifest = ['--manifest-path', 'trillionnium/Cargo.toml']
    plan = [
        ('preflight', ['bash', 'scripts/project-preflight.sh'], 120, None),
        ('rustc-version', [str(TOOLCHAIN / 'rustc'), '-Vv'], 120, None),
        ('cargo-version', base + ['-V'], 120, None),
        ('openssl-version', [str(PROVIDER / 'bin/openssl'), 'version', '-a'], 120, None),
        ('metadata-default', base + ['metadata', '--locked', '--offline', '--format-version', '1'] + manifest, 300, None),
        ('metadata-all-features', base + ['metadata', '--locked', '--offline', '--all-features', '--format-version', '1'] + manifest, 300, None),
        ('metadata-fuzz', base + ['metadata', '--locked', '--offline', '--format-version', '1', '--manifest-path', 'tests/fuzz/Cargo.toml'], 300, None),
        ('fmt', base + ['fmt'] + manifest + ['--all', '--', '--check'], 300, None),
        ('repository-contract', ['/usr/bin/python3', '-B', 'scripts/ci/check_repository.py'], 300, None),
        ('distributed-source-inventory', ['/usr/bin/python3', '-B', 'scripts/refresh_distributed_source_inventory.py', '--check'], 300, None),
        ('pq-research-integration', ['/usr/bin/python3', '-B', 'scripts/ci/check_pq_research_integration.py'], 300, None),
    ]
    suffix = ['--', '--show-output', '--test-threads=1']
    test = base + ['test', '--locked', '--offline'] + manifest
    for target, count in [('account_profile_boundary', 4), ('account_development_scope', 5)]:
        names = source_test_names(f'trillionnium/crates/trnm-mvcc-fee/tests/{target}.rs', count)
        plan.append((target.replace('_', '-'), test + ['-p', 'trnm-mvcc-fee', '--test', target] + suffix, 1200, names))
    for target, count in ROOT_TARGETS:
        names = source_test_names(f'trillionnium/crates/trnm-pon-node/tests/{target}.rs', count)
        plan.append((target.replace('_', '-'), test + ['-p', 'trnm-pon-node', '--features', 'pq-root-v3', '--test', target] + suffix, 1200, names))
    node = test + ['-p', 'trnm-pon-node', '--all-features', '--lib']
    prefix = 'store::account_profile_scope_tests::'
    scope_names = source_test_names('trillionnium/crates/trnm-pon-node/src/store/account_profile_scope_tests.rs', 4, prefix)
    plan.append(('node-account-scope', node + [prefix] + suffix, 1800, scope_names))
    profile = 'store::task_observation::tests::every_native_profile_observes_real_settlement_with_its_exact_wire_id'
    plan.append(('node-all-pq-profile-settlement', node + [profile, '--', '--exact', '--show-output', '--test-threads=1'], 1200, [profile]))
    for i, selector in enumerate(TLS_SELECTORS, 1):
        plan.append((f'tls-full-spki-{i}', node + [selector, '--', '--exact', '--show-output', '--test-threads=1'], 1200, [selector]))
    old = 'real_node_pq_account_packets_work_forks_reorg_and_cold_replay'
    plan.append(('node-qtx1-recovery', test + ['-p', 'trnm-pon-node', '--all-features', '--test', 'pq_account_native', old, '--', '--exact', '--show-output', '--test-threads=1'], 1200, [old]))
    invalid = 'distinct_false_traces_and_cross_listener_retry_pay_one_shared_domain_without_effects'
    plan.append(('distinct-invalid-work', test + ['-p', 'trnm-pon-node', '--all-features', '--test', 'public_v3_distinct_invalid_work', invalid, '--', '--exact', '--show-output', '--test-threads=1'], 1200, [invalid]))
    plan.append(('strict-workspace-clippy', base + ['clippy', '--locked', '--offline'] + manifest + ['--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings'], 3600, None))
    return plan


def stop_group(process, cleanup):
    try:
        os.killpg(process.pid, signal.SIGTERM)
        cleanup.append('owned-group-SIGTERM')
    except ProcessLookupError:
        cleanup.append('owned-group-already-exited')
    try:
        return process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        cleanup.append('owned-group-SIGKILL')
        return process.wait(timeout=30)


def run_command(name, argv, limit, expected, env, out, commit):
    row = {'schema': 'trnm-desktop-command-v1', 'name': name, 'argv': argv, 'cwd': str(REPO),
           'started_utc': now(), 'timeout_seconds': limit,
           'environment': {key: env.get(key) for key in ENV_KEYS}, 'expected_tests': expected,
           'source_before': identity(commit), 'free_bytes_before': shutil.disk_usage(REPO).free,
           'target_free_bytes_before': shutil.disk_usage(env['CARGO_TARGET_DIR']).free}
    require(row['free_bytes_before'] >= LOW_WATER, 'disk below 10 GiB before new command')
    require(row['target_free_bytes_before'] >= LOW_WATER, 'target volume below 10 GiB before new command')
    stdout, stderr = out / f'{name}.stdout.log', out / f'{name}.stderr.log'
    began, process, exception, code, timeout, cleanup = time.monotonic(), None, None, None, False, []
    interrupted = False
    with stdout.open('xb') as normal, stderr.open('xb') as errors:
        try:
            process = subprocess.Popen(argv, cwd=REPO, env=env, stdin=subprocess.DEVNULL,
                                       stdout=normal, stderr=errors, start_new_session=True)
            row['pid'] = process.pid
            code = process.wait(timeout=limit)
        except subprocess.TimeoutExpired:
            timeout = True
            code = stop_group(process, cleanup)
        except BaseException as error:
            exception = {'type': type(error).__name__, 'message': str(error)}
            interrupted = isinstance(error, (KeyboardInterrupt, SystemExit))
            if process is not None and process.poll() is None:
                code = stop_group(process, cleanup)
        normal.flush()
        errors.flush()
        os.fsync(normal.fileno())
        os.fsync(errors.fileno())
    row.update({'finished_utc': now(), 'elapsed_seconds': time.monotonic() - began,
                'exit_code': code, 'timed_out': timeout, 'exception': exception,
                'cleanup': cleanup, 'direct_child_reaped': process is None or process.poll() is not None,
                'stdout': {'name': stdout.name, **file_hash(stdout)},
                'stderr': {'name': stderr.name, **file_hash(stderr)},
                'free_bytes_after': shutil.disk_usage(REPO).free,
                'target_free_bytes_after': shutil.disk_usage(env['CARGO_TARGET_DIR']).free})
    try:
        row['source_after'] = identity(commit)
    except Exception as error:
        row['source_error'] = str(error)
    row['passed'] = code == 0 and not timeout and exception is None and 'source_error' not in row
    expected_versions = {
        'rustc-version': r'^release: 1\.95\.0$',
        'cargo-version': r'^cargo 1\.95\.0 \(',
        'openssl-version': r'^OpenSSL 3\.5\.9\b',
    }
    if name in expected_versions:
        row['expected_version_observed'] = bool(re.search(
            expected_versions[name], stdout.read_text(), re.M))
        row['passed'] = row['passed'] and row['expected_version_observed']
    if expected is not None:
        try:
            row['native_observation'] = native_result(stdout.read_text(), expected, code)
        except Exception as error:
            row['native_result_error'] = str(error)
            row['passed'] = False
    write_json(out / f'{name}.receipt.json', row)
    print(json.dumps({'command': name, 'exit_code': code, 'passed': row['passed'],
                      'timed_out': timeout, 'seconds': row['elapsed_seconds'],
                      'free_bytes': row['free_bytes_after'],
                      'target_free_bytes': row['target_free_bytes_after']}), flush=True)
    return row, interrupted


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--target-dir', type=Path,
                        help='Fresh owned Cargo target under /data, with the task-specific prefix')
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    require(re.fullmatch(r'[0-9a-f]{40}', args.commit), 'full candidate commit required')
    require(REPO.resolve() == REPO, 'unexpected repository symlink')
    require(args.out.parent == REPO.parent and args.out.name.startswith('chain-pq-closure-20261111-d4d2-validation-'),
            'output must be a fresh dedicated sibling')
    target = args.target_dir or (args.out / 'cargo-target')
    if args.target_dir is not None:
        require(target.parent == Path('/data') and target.is_absolute()
                and target.name.startswith('chain-pq-closure-20261111-d4d2-cargo-target-')
                and target.resolve() == target,
                'explicit target must use the verified /data task namespace without symlinks')
        require(not target.exists(), 'target already exists; never reuse another build output')
        require(shutil.disk_usage(target.parent).free >= LOW_WATER,
                'target volume below 10 GiB')
    plan = command_plan()
    if args.plan_only:
        print(json.dumps([dict(name=n, argv=a, timeout_seconds=t, expected_tests=e) for n, a, t, e in plan], indent=2))
        return 0
    require(not args.out.exists(), 'output already exists; inspect retained results, never overwrite')
    identity(args.commit)
    require(shutil.disk_usage(REPO).free >= LOW_WATER, 'disk below 10 GiB')
    env = dict(os.environ)
    forbidden = [k for k in env if k.startswith('CARGO_PROFILE_') or k in
                 ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER',
                  'GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES')]
    require(not any(env[k] for k in forbidden), 'unreviewed inherited build/Git override keys: ' + ','.join(forbidden))
    args.out.mkdir(mode=0o700)
    target.mkdir(mode=0o700)
    target_info = target.lstat()
    require(stat.S_ISDIR(target_info.st_mode) and target_info.st_uid == os.getuid()
            and stat.S_IMODE(target_info.st_mode) == 0o700, 'target is not a private owned directory')
    rows, stopped, fatal = [], None, None
    source_before = source_after = provider_before = provider_after = None
    began = now()
    try:
        source_before = source_snapshot(args.commit, args.out / 'source-before.json')
        provider_before = provider_snapshot(args.out / 'provider-before.json')
        env.update({'PATH': '/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
                    'RUSTUP_TOOLCHAIN': '1.95.0', 'CARGO_BUILD_JOBS': '2',
                    'CARGO_INCREMENTAL': '0', 'CARGO_TARGET_DIR': str(target),
                    'CARGO_NET_OFFLINE': 'true', 'RUSTC': str(TOOLCHAIN / 'rustc'),
                    'OPENSSL_DIR': str(PROVIDER), 'OPENSSL_STATIC': '1',
                    'OPENSSL_LIB_DIR': str(PROVIDER / 'lib'),
                    'OPENSSL_INCLUDE_DIR': str(PROVIDER / 'include'), 'OPENSSL_NO_VENDOR': '1',
                    'OPENSSL_CONF': '/dev/null', 'OPENSSL_MODULES': str(PROVIDER / 'lib/ossl-modules'),
                    'TRNM_PQ_OPENSSL': str(PROVIDER / 'bin/openssl'),
                    'TRNM_PQ_OPENSSL_SHA256': provider_before['files']['bin/openssl']['sha256'],
                    'TRNM_PQ_OPENSSL_VERSION': '3.5.9', 'GIT_NO_REPLACE_OBJECTS': '1'})
        env.pop('OPENSSL_LIBS', None)
        write_json(args.out / 'plan.json', {'commit': args.commit, 'runner': file_hash(Path(__file__)),
                   'source_verification_scope': 'complete tracked bytes before/after this whole command group',
                   'minimum_free_bytes_before_new_command': LOW_WATER,
                   'source_directory': str(REPO), 'output_directory': str(args.out),
                   'target_directory': str(target), 'target_device': target_info.st_dev,
                   'environment': {k: env.get(k) for k in ENV_KEYS},
                   'commands': [dict(name=n, argv=a, timeout_seconds=t, expected_tests=e) for n, a, t, e in plan]})
        for name, argv, timeout, expected in plan:
            if min(shutil.disk_usage(REPO).free, shutil.disk_usage(target).free) < LOW_WATER:
                stopped = 'source or target volume below 10 GiB; remaining commands not started'
                break
            row, interrupted = run_command(name, argv, timeout, expected, env, args.out, args.commit)
            rows.append(row)
            if interrupted or 'source_error' in row:
                stopped = 'interrupted or source identity changed; remaining commands not started'
                break
            if name == 'preflight' and not row['passed']:
                stopped = 'project boundary refused; build commands not started'
                break
            if name.endswith('-version') and not row['passed']:
                stopped = 'expected toolchain/provider version unavailable; build commands not started'
                break
            if name.startswith('metadata-') and not row['passed']:
                stopped = 'locked dependency graph unavailable; build commands not started'
                break
    except BaseException as error:
        fatal = {'type': type(error).__name__, 'message': str(error)}
    finally:
        try:
            source_after = source_snapshot(args.commit, args.out / 'source-after.json')
        except BaseException as error:
            write_json(args.out / 'source-after-error.json', {'type': type(error).__name__, 'message': str(error)})
        try:
            provider_after = provider_snapshot(args.out / 'provider-after.json')
        except BaseException as error:
            write_json(args.out / 'provider-after-error.json', {'type': type(error).__name__, 'message': str(error)})
    source_equal = source_before is not None and source_before == source_after
    provider_equal = provider_before is not None and provider_before == provider_after
    complete = len(rows) == len(plan)
    summary = {'schema': 'trnm-desktop-pq-validation-v1', 'source': args.commit,
               'target_directory': str(target), 'output_directory': str(args.out),
               'started_utc': began, 'finished_utc': now(), 'complete': complete,
               'source_unchanged': source_equal, 'provider_unchanged': provider_equal,
               'all_selected_commands_passed': complete and all(r['passed'] for r in rows)
                    and source_equal and provider_equal and fatal is None,
               'commands': rows, 'not_started': [n for n, _, _, _ in plan[len(rows):]],
               'stopped_reason': stopped, 'fatal': fatal,
               'status': 'HOLD_NO_GO', 'whole_chain_quantum_security_qualified': False,
               'production_activation': False, 'native_run_is_not_hosted_ci': True}
    write_json(args.out / 'summary.json', summary)
    print(json.dumps({k: v for k, v in summary.items() if k != 'commands'}), flush=True)
    return 0 if summary['all_selected_commands_passed'] else 1


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
    raise SystemExit(main())
