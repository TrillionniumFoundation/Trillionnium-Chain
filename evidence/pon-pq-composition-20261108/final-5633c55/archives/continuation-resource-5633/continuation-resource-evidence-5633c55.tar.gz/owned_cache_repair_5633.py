#!/usr/bin/env python3
"""Inspect, then remove only four explicitly authorized derived directories."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time

BASE = Path('/home/qian-qi/work/chain-pq-composition-663507-20261108')
OUT = BASE / 'owned-resource-repair-5633c55'
REPO = BASE / 'repo'
HEAD = '5633c55219c01c689f670c2ca35d122e39f3f791'
TREE = '3baafa8923d1a1e7bfb6f24cff9965a4e82fba4c'
OWNER = BASE / 'owner-guard-counterexamples-5633c55'
BOUNDED = BASE / 'bounded-io-5633'
DA = BASE / 'da-fixture-diagnostics-5633'
WHITE = (OWNER / 'native-target', OWNER / 'isolated-source', BOUNDED / 'native-target', DA / 'target')
PROOF = BASE / 'final-proof-target-5633c55'
JOB_FILE = BASE / 'owned_cleanup_known_jobs_5633.json'
PARENT_JOB = '1a1bc526042-138b0-1aa'
BOUNDED_JOB = '1a1bc6ad0fc-138b0-257'
DA_JOB = '1a1bc9287f7-138b0-354'
DA_UNKNOWN = '1a1bc8399f6-138b0-2f7'
CGROOT = Path('/sys/fs/cgroup/user.slice/user-1000.slice/user@1000.service/app.slice')
PINS = {
    OWNER / 'summary.json': (29240, 'fd7ccf8e65f3e2c999f18133fb14a8b007fa7a9c5a90b1207be20ce0c307c59b'),
    BOUNDED / 'summary.json': (52890, '294842411ea03d0a809fda2142f56be0acbe82fb6043a754e1dfcc3f7efd3cfe'),
    DA / 'output/execution-intent.json': (515, 'bae51865d6cc3dac17f9b8db8658508ca065b023d79357995b3e02859ad4186d'),
    BASE / 'da_fixture_campaign_5633.py': (19380, 'af4b547c2dfb34fba76de9fdbc64b0447db18c5a0949c39521f25ba654586817'),
    BASE / 'da_diagnostics_5633.py': (16426, 'a2403eb189313b50f8292ccb97bd0fb9bfbfd3d518592be0c7702ed14d9c397e'),
    BASE / 'da_fixture_diagnostic_5633.patch': (6973, 'fa029f0542db3024ee4cfdfc6bacbf554af5aa572e8b629c3567e8f316b2a647'),
}
ENV = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
ENV.update(GIT_CONFIG_SYSTEM='/dev/null', GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1',
           GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0',
           PYTHONDONTWRITEBYTECODE='1', LC_ALL='C')

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def write(path, value):
    with path.open('x', encoding='utf-8') as f:
        json.dump(value, f, sort_keys=True, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())

def record(path):
    s = path.lstat()
    require(stat.S_ISREG(s.st_mode), 'not regular: ' + str(path))
    require(path.resolve(strict=True) == path, 'path has symlink components: ' + str(path))
    b = path.read_bytes()
    t = path.lstat()
    require((s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns) ==
            (t.st_dev, t.st_ino, t.st_size, t.st_mtime_ns), 'file changed while reading')
    return {'path': str(path), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def directory(path):
    require(path in (*WHITE, PROOF, BASE, REPO, OWNER, BOUNDED, DA, OUT) or path == OWNER / 'isolated-source/.git', 'non-whitelist directory')
    require(path.resolve(strict=True) == path, 'directory symlink or alias')
    for p in (path, *path.parents):
        require(not stat.S_ISLNK(p.lstat().st_mode), 'symlink component')
    s = path.lstat()
    require(stat.S_ISDIR(s.st_mode) and s.st_uid == os.getuid(), 'not an owned directory')
    return {'path': str(path), 'device': s.st_dev, 'inode': s.st_ino, 'mode': s.st_mode, 'uid': s.st_uid}

def command(label, argv, cwd=BASE, timeout=300):
    start = time.monotonic()
    r = subprocess.run(argv, cwd=cwd, env=ENV, stdin=subprocess.DEVNULL, capture_output=True, timeout=timeout)
    with (OUT / (label + '.stdout.log')).open('xb') as f: f.write(r.stdout)
    with (OUT / (label + '.stderr.log')).open('xb') as f: f.write(r.stderr)
    row = {'argv': argv, 'cwd': str(cwd), 'exit_code': r.returncode, 'elapsed_seconds': time.monotonic()-start,
           'stdout': record(OUT/(label+'.stdout.log')), 'stderr': record(OUT/(label+'.stderr.log'))}
    write(OUT/(label+'.receipt.json'), row)
    require(r.returncode == 0, 'command failed: '+label)
    return r.stdout

def git_identity(repo, label):
    data = command(label, ['/usr/bin/git', '--no-replace-objects', '-C', str(repo), 'rev-parse', 'HEAD', 'HEAD^{tree}']).decode().splitlines()
    require(data == [HEAD, TREE], 'source identity mismatch: '+str(repo))
    return {'head': data[0], 'tree': data[1]}

def no_cgroups(jobs):
    rows = []
    for job in jobs:
        p = CGROOT / ('hepta-runtime-job-'+job+'.service')
        rows.append({'job_id': job, 'cgroup': str(p), 'present': p.exists()})
    require(not any(x['present'] for x in rows), 'known task cgroup still exists')
    return rows

def check_pins(paths):
    result = []
    for p in paths:
        r = record(p)
        require((r['bytes'], r['sha256']) == PINS[p], 'preserved evidence pin changed: '+str(p))
        result.append(r)
    return result

def terminal_evidence(expected_sha):
    r = record(JOB_FILE)
    require(r['sha256'] == expected_sha, 'known terminal evidence changed')
    data = json.loads(JOB_FILE.read_text())
    for key, job, state, exit_code in [('parent', PARENT_JOB, 'failed', 1), ('bounded', BOUNDED_JOB, 'succeeded', 0), ('da_recovery', DA_JOB, 'succeeded', 0)]:
        tool = data[key]
        require(not tool.get('isError'), 'terminal connector error')
        item = json.loads('\n'.join(x['text'] for x in tool['content'] if x['type']=='text'))
        require(item['job_id']==job and item['state']==state and item['exit_code']==exit_code and
                item['output_complete'] and item['output_durable'] and item['terminal_publication_confirmed'], 'not exact terminal')
    require(data['da_original']['termination_confirmed'] is False and data['da_original']['reclassified'] is False, 'unknown was reclassified')
    return r

def allocated(path, label):
    raw = command(label, ['/usr/bin/du','-sx','--block-size=1','--',str(path)]).decode()
    number, name = raw.rstrip('\n').split('\t',1)
    require(name==str(path), 'du changed target')
    return int(number)

def available():
    s = os.statvfs(BASE)
    return {'available_bytes': s.f_bavail*s.f_frsize, 'free_including_reserved_bytes': s.f_bfree*s.f_frsize, 'time_unix': time.time()}

def protected_inventory():
    result = []
    excluded = set(WHITE) | {DA/'source'}
    for root in (OWNER, BOUNDED, DA):
        for here, dirs, files in os.walk(root, followlinks=False):
            p = Path(here)
            dirs[:] = sorted(d for d in dirs if p/d not in excluded)
            for name in sorted(files):
                f = p/name
                if f.is_symlink():
                    result.append({'path':str(f),'symlink':os.readlink(f)})
                elif f.is_file():
                    result.append(record(f))
                else:
                    result.append({'path':str(f),'special_mode':f.lstat().st_mode})
    return result

def guard(path, label):
    row = {'identity':directory(path), 'eligible':False}
    jobs = [PARENT_JOB] if path.parent==OWNER else [BOUNDED_JOB] if path.parent==BOUNDED else [DA_UNKNOWN,DA_JOB]
    row['known_cgroups']=no_cgroups(jobs)
    if path.parent==OWNER:
        row['preserved_pins']=check_pins([OWNER/'summary.json'])
        d=json.loads((OWNER/'summary.json').read_text())
        require(d['result']=='PASS_SCOPED_COUNTEREXAMPLES' and d['isolated_source_restored'] is True, 'owner controls not restored')
        if path.name=='isolated-source':
            row['git']=git_identity(path,label+'-identity')
            require(command(label+'-clean', ['/usr/bin/git','-C',str(path),'status','--porcelain=v1','-z','--untracked-files=all','--ignored=matching'])==b'', 'owner clone contains tracked/untracked/ignored work')
            directory(path/'.git')
            common=command(label+'-common-dir',['/usr/bin/git','-C',str(path),'rev-parse','--path-format=absolute','--git-common-dir']).decode().strip()
            require(common==str(path/'.git'), 'owner clone shares a mutable git directory')
            alternate=record(path/'.git/objects/info/alternates')
            require(alternate['bytes']==74 and alternate['sha256']=='db456a05c3305b3effd845ccbf452d88ee8df35218f979b9ee582830890ef11f', 'unexpected owner alternates')
            raw=command(label+'-raw-source',['/usr/bin/python3.12','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',HEAD,'--output',str(OUT/(label+'.source.json'))],cwd=path,timeout=1800)
            row['raw_source']=json.loads(raw)
            require(row['raw_source']['tracked_worktree_verified'] and row['raw_source']['tested_tree']==TREE, 'owner raw-source mismatch')
    elif path.parent==BOUNDED:
        row['preserved_pins']=check_pins([BOUNDED/'summary.json'])
        require(json.loads((BOUNDED/'summary.json').read_text())['result']=='PASS_SCOPED_NATIVE_IO','bounded run not complete')
    else:
        row['preserved_pins']=check_pins([p for p in PINS if p not in (OWNER/'summary.json',BOUNDED/'summary.json')])
        intent=json.loads((DA/'output/execution-intent.json').read_text())
        require(intent['attempts']==1 and intent['head']=='f0e8dc919f10a5f1e7debca544aed9d14e75d96d', 'DA intent identity changed')
        summary=record(DA/'output/execute-summary.json')
        require(summary['sha256']=='24ec386433bd7fbbd591ad60005879efcf2732a8b487617b8149172c68fcd25c','DA execution summary changed')
        row['execute_summary']=summary
        row['unknown_original_job_remains_unknown']=True
        row['late_execute_refusal']='Pinned runner/helper require create-only existing execution-intent before target.mkdir or any native command.'
    device=row['identity']['device']
    for here, dirs, files in os.walk(path,followlinks=False):
        require(Path(here).lstat().st_dev==device,'nested filesystem/mount')
        for name in dirs:
            require((Path(here)/name).lstat().st_dev==device,'nested filesystem/mount')
    row['allocated_bytes']=allocated(path,label+'-size')
    row['eligible']=True
    return row

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=('inspect','delete'),required=True);p.add_argument('--known-jobs-sha',required=True);a=p.parse_args()
    directory(BASE);directory(REPO)
    if a.mode=='inspect': OUT.mkdir(mode=0o700)
    else: directory(OUT)
    write(OUT/(a.mode+'.intent.json'),{'mode':a.mode,'time_unix':time.time(),'whitelist':[str(x) for x in WHITE],'proof_observation_only':str(PROOF),'attempts':1})
    result={'schema':'trnm-owned-resource-repair-v1','mode':a.mode,'started_unix':time.time(),'free_before':available(),'deletions':[],'skipped':[],
            'unknown_launch_or_cancel_reclassified':False,'global_process_table_enumerated':False,'tmp_enumerated':False,'proof_target_deleted':False}
    try:
        result['known_terminal_input']=terminal_evidence(a.known_jobs_sha)
        result['main_source_before']=git_identity(REPO,a.mode+'-main-before')
        result['protected_before']=protected_inventory()
        require(shutil.rmtree.avoids_symlink_attacks,'descriptor-safe rmtree unavailable')
        if a.mode=='inspect':
            result['targets']=[]
            for i,path in enumerate(WHITE):
                try: row=guard(path,'inspect-'+str(i));row['path']=str(path)
                except Exception as e: row={'path':str(path),'eligible':False,'error':type(e).__name__+': '+str(e)}
                result['targets'].append(row)
            result['proof_observation']={'identity':directory(PROOF),'allocated_bytes':allocated(PROOF,'inspect-proof-size'),'known_cgroups':no_cgroups([PARENT_JOB]),'deletion_authorized':False}
        else:
            before=json.loads((OUT/'inspect.receipt.json').read_text())
            require(not before.get('error') and before['mode']=='inspect','prior read-only inspection incomplete')
            require(before['protected_before']==result['protected_before'],'preserved logs/evidence changed since inspection')
            result['inspection_receipt']=record(OUT/'inspect.receipt.json')
            for i,path in enumerate(WHITE):
                old=next(x for x in before['targets'] if x['path']==str(path))
                if not old['eligible']:
                    result['skipped'].append({'path':str(path),'reason':old['error']});continue
                row=guard(path,'delete-'+str(i))
                require(row['identity']==old['identity'] and row['allocated_bytes']==old['allocated_bytes'],'derived directory changed since inspection')
                row['free_before']=available();row['path']=str(path);row['removal_started_unix']=time.time()
                write(OUT/('delete-'+str(i)+'.intent.json'),row)
                parent=path.parent
                fd=os.open(parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
                try:
                    require(os.stat(path.name,dir_fd=fd,follow_symlinks=False).st_ino==row['identity']['inode'],'directory identity changed')
                    shutil.rmtree(path.name,dir_fd=fd)
                finally: os.close(fd)
                require(not path.exists() and not path.is_symlink(),'directory still present')
                row.update(deleted=True,free_after=available(),removal_finished_unix=time.time())
                result['deletions'].append(row);write(OUT/('delete-'+str(i)+'.receipt.json'),row)
        result['protected_after']=protected_inventory()
        require(result['protected_before']==result['protected_after'],'preserved evidence changed')
        result['main_source_after']=git_identity(REPO,a.mode+'-main-after')
        result['result']='PASS_INSPECTION' if a.mode=='inspect' else 'PASS_WHITELIST_REPAIR'
    except BaseException as e:
        result['result']='FAILED_INCOMPLETE';result['error']=type(e).__name__+': '+str(e)
    finally:
        result['free_after']=available();result['finished_unix']=time.time()
        result['conditional_new_run_entry_16gib_met']=result['free_after']['available_bytes']>=16*1024**3
        write(OUT/(a.mode+'.receipt.json'),result)
        print(json.dumps({'mode':a.mode,'result':result['result'],'deleted':[x['path'] for x in result['deletions']],'free_after':result['free_after'],
                          'entry_16gib_met':result['conditional_new_run_entry_16gib_met'],'receipt':str(OUT/(a.mode+'.receipt.json')),'error':result.get('error')}),flush=True)
    return 0 if result['result'].startswith('PASS_') else 1

if __name__=='__main__': raise SystemExit(main())
