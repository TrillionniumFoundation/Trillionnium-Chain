#!/usr/bin/env python3
"""One diagnostic execution of each original DA failure, without compiling.

The original 412/3 outcome is immutable evidence. Passing this separate diagnostic
does not fix its cause or qualify the complete suite. Only recorded environment
values are reconstructed; unrecorded Cargo-injected variables are not claimed equal.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time


BASE = Path("/home/qian-qi/work/chain-pq-composition-663507-20261108")
REPO = BASE / "repo"
ORIGINAL = BASE / "final-native-5633c55"
OUTPUT = BASE / "da-diagnostics-5633"
HEAD = "5633c55219c01c689f670c2ca35d122e39f3f791"
HARNESS_STEM = "trnm_data_availability-e2df522b48ec374b-487806e9cd87376cacc8"
HARNESS_DIR = ORIGINAL / "data-availability-default-lib-execution-harnesses"
FINISH = HARNESS_DIR / (HARNESS_STEM + ".finish.json")
ELF = ORIGINAL / "native-target-default/x86_64-unknown-linux-gnu/debug/deps/trnm_data_availability-e2df522b48ec374b"
ELF_SHA256 = "54c44c15717a751bb669a28f1065f3f1c948dbc7efdd6f6c009fd39be6d01fd9"
ELF_BYTES = 87187480
PYTHON = Path("/usr/bin/python3.12")
TOOLCHAIN = Path("/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu")
ORIGINAL_RUNNER_SHA256 = "a7733832e8511daa23385c978dae1c63185f9f7f25c6b7eb69691448e5698f8c"
TESTS = (
    "cell::discovery::equivocation_history_tests::tcp_higher_sequence_cannot_hide_observed_earlier_sequence_equivocation",
    "cell::network::serving::tests::transient_chunk_capacity_refusal_uses_one_bounded_retry",
    "cell::release::transport_tests::rarest::v3_release_closure_model_and_tensor_keep_one_pool_and_aggregate_inventory_budget",
)
PINNED_LOGS = {
    ORIGINAL / "data-availability-default-lib-run.stdout.log": "97a5901c154bcff21720fdfe50502fa6cfa39187d4bfef6fcb522896d1d9584e",
    ORIGINAL / "data-availability-default-lib-run.stderr.log": "dddf0058a406c50dd9cec1ccafa4367e1d11d5608a14d826b690592ca92d7637",
    HARNESS_DIR / (HARNESS_STEM + ".libtest.log"): "18d1a606af75e26d0a46404b885c4777cfad30b83429dc0b73839083e89e77ed",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def identity(path: Path) -> dict:
    before = path.stat(follow_symlinks=False)
    require(stat.S_ISREG(before.st_mode), "not a regular file: " + str(path))
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(data)
    after = path.stat(follow_symlinks=False)
    fields = lambda value: (value.st_dev, value.st_ino, value.st_mode, value.st_size,
                            value.st_mtime_ns, value.st_ctime_ns)
    require(fields(before) == fields(after), "file changed while hashing: " + str(path))
    return {"path": str(path), "bytes": after.st_size, "sha256": digest.hexdigest()}


def save(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def expected_base_environment() -> dict:
    return {
        "HOME": "/home/qian-qi", "USER": "qian-qi", "LOGNAME": "qian-qi",
        "PATH": str(TOOLCHAIN / "bin") + ":/usr/bin:/bin",
        "LANG": "C", "LC_ALL": "C", "TZ": "UTC",
        "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_SYSTEM": "/dev/null",
        "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_ATTR_NOSYSTEM": "1",
        "GIT_NO_REPLACE_OBJECTS": "1", "GIT_TERMINAL_PROMPT": "0",
        "GIT_OPTIONAL_LOCKS": "0", "PYTHONDONTWRITEBYTECODE": "1",
        "CARGO_HOME": "/home/qian-qi/.cargo",
        "CARGO_TARGET_DIR": str(ORIGINAL / "native-target-default"),
        "CARGO_NET_OFFLINE": "true", "CARGO_TERM_COLOR": "never",
        "CARGO_BUILD_JOBS": "2", "CARGO_INCREMENTAL": "0",
        "RUSTC": str(TOOLCHAIN / "bin/rustc"),
        "RUSTDOC": str(TOOLCHAIN / "bin/rustdoc"),
        "RUSTC_WRAPPER": "", "RUSTC_WORKSPACE_WRAPPER": "",
        "CARGO_ENCODED_RUSTFLAGS": "", "RUST_BACKTRACE": "0", "RUST_TEST_THREADS": "1",
    }


def expected_runtime_environment() -> dict:
    target = ORIGINAL / "native-target-default/x86_64-unknown-linux-gnu/debug"
    return {
        "CARGO_MANIFEST_DIR": str(REPO / "trillionnium/crates/trnm-data-availability"),
        "CARGO_PKG_NAME": "trnm-data-availability", "RUST_TEST_THREADS": "1",
        "LD_LIBRARY_PATH": ":".join(map(str, (
            target / "build/libsqlite3-sys-59c31ae4994685ef/out",
            target / "build/sha2-asm-9a50e477794b4340/out",
            target, target / "deps", TOOLCHAIN / "lib/rustlib/x86_64-unknown-linux-gnu/lib",
        ))),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-runner-sha256", required=True)
    args = parser.parse_args()
    require(re.fullmatch(r"[0-9a-f]{64}", args.expected_runner_sha256) is not None,
            "noncanonical runner pin")
    runner = Path(__file__).resolve(strict=True)
    runner_before = identity(runner)
    require(runner_before["sha256"] == args.expected_runner_sha256, "diagnostic runner changed")
    require(not runner.is_relative_to(REPO) and not OUTPUT.is_relative_to(REPO),
            "diagnostic artifacts must be outside frozen source")
    require(not OUTPUT.exists(), "diagnostic output already exists; no retry or replacement")
    OUTPUT.mkdir(mode=0o700)
    records, results, errors = [], [], []
    source_before = source_after = None
    elf_before = elf_after = None
    original_before = original_after = None
    runner_after = None
    env = expected_base_environment()

    def run(label: str, argv: list, cwd: Path, *, timeout: int,
            expected_program: dict | None = None) -> dict:
        require(not any(record["label"] == label for record in records), "duplicate command attempt")
        argv = list(map(str, argv))
        record = {"label": label, "argv": argv, "cwd": str(cwd), "attempts": 1,
                  "started_unix_seconds": time.time(), "exit_code": None, "timed_out": False,
                  "timeout_seconds": timeout}
        save(OUTPUT / (label + ".started.json"), record)
        process = None
        started = time.monotonic()
        try:
            program = Path(argv[0]).resolve(strict=True)
            record["program_before"] = identity(program)
            if expected_program is not None:
                require(record["program_before"] == expected_program, "executable identity mismatch")
                record["expected_program_identity"] = expected_program
            with (OUTPUT / (label + ".stdout.log")).open("xb") as stdout, \
                    (OUTPUT / (label + ".stderr.log")).open("xb") as stderr:
                process = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stdout, stderr=stderr,
                                           start_new_session=True)
                try:
                    record["exit_code"] = process.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    record["timed_out"] = True
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    record["exit_code"] = process.wait()
            record["program_after"] = identity(program)
            require(record["program_before"] == record["program_after"], "executable changed during command")
        except (Exception, KeyboardInterrupt) as error:
            record["error"] = type(error).__name__ + ": " + str(error)
        finally:
            if process is not None and process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                record["exit_code"] = process.wait()
            record["elapsed_seconds"] = time.monotonic() - started
            record["logs"] = [identity(path) for suffix in ("stdout", "stderr")
                              if (path := OUTPUT / (label + "." + suffix + ".log")).exists()]
            records.append(record)
            save(OUTPUT / (label + ".receipt.json"), record)
            print(json.dumps({"label": label, "exit_code": record["exit_code"],
                              "timed_out": record["timed_out"], "error": record.get("error")}), flush=True)
        return record

    def checked_command(label: str, argv: list, *, timeout: int) -> dict:
        record = run(label, argv, REPO, timeout=timeout)
        require(not record.get("error") and not record["timed_out"] and record["exit_code"] == 0,
                label + " refused; keep original logs")
        return record

    def source(label: str) -> dict:
        output = OUTPUT / (label + ".source.json")
        checked_command(label, [PYTHON, "-B", REPO / "scripts/ci/verify_ci_source.py",
                               "--kind", "head", "--expected-head", HEAD, "--output", output], timeout=180)
        value = json.loads(output.read_text())
        require(value["tested_commit"] == HEAD and value["tracked_worktree_verified"] is True,
                "source is not the expected verified commit")
        return value

    input_paths = [ORIGINAL / "campaign-start.json", FINISH,
                   ORIGINAL / "data-availability-default-lib-run.receipt.json", *PINNED_LOGS]
    try:
        original_before = {str(path): identity(path) for path in input_paths}
        for path, digest in PINNED_LOGS.items():
            require(original_before[str(path)]["sha256"] == digest, "original failure log changed")
        campaign = json.loads((ORIGINAL / "campaign-start.json").read_text())
        finish = json.loads(FINISH.read_text())
        original_receipt = json.loads((ORIGINAL / "data-availability-default-lib-run.receipt.json").read_text())
        require(campaign["expected_head"] == HEAD and campaign["environment"] == env,
                "original source or base environment differs")
        require(campaign["runner"]["sha256"] == ORIGINAL_RUNNER_SHA256,
                "original campaign runner identity differs")
        require(finish["executable_before"] == finish["executable_after"]
                == {"path": str(ELF), "bytes": ELF_BYTES, "sha256": ELF_SHA256},
                "original ELF pin differs")
        require(finish["runtime_environment"] == expected_runtime_environment(),
                "original recorded runtime environment differs")
        require(finish["cwd"] == str(REPO / "trillionnium/crates/trnm-data-availability")
                and finish["exit_code"] == 101 and finish["attempts"] == 1
                and original_receipt["exit_code"] == 101 and original_receipt["attempts"] == 1
                and original_receipt["timed_out"] is False, "original failed execution identity differs")
        original_log = (HARNESS_DIR / (HARNESS_STEM + ".libtest.log")).read_text().splitlines()
        require({line.removeprefix("failed ") for line in original_log if line.startswith("failed ")}
                == set(TESTS), "original failed-test roster differs")
        env.update(expected_runtime_environment())
        env["RUST_BACKTRACE"] = "full"
        save(OUTPUT / "diagnostic-inputs.json", {
            "schema": "trnm-da-original-elf-diagnostic-v1", "expected_head": HEAD,
            "runner": runner_before, "original_records": original_before,
            "original_result": {"passed": 412, "failed": 3, "ignored": 0, "exit_code": 101},
            "tests": TESTS, "environment": env,
            "recorded_environment_changes": {"RUST_BACKTRACE": {"original": "0", "diagnostic": "full"}},
            "environment_scope": "original recorded base plus recorded Cargo runtime values; unrecorded Cargo/runner keys are not reconstructed or asserted equal",
            "argv_changes": "exact one-test selector added; original formatting/thread flags retained; logfile is fresh per test",
            "one_execution_per_selected_test": True, "compile_commands": [], "retries": 0,
            "original_failure_replaced": False, "root_cause_resolved": False,
            "complete_suite_qualified": False, "whole_chain_pq_qualified": False,
        })
        checked_command("preflight", ["/bin/bash", REPO / "scripts/project-preflight.sh", "--audit"], timeout=120)
        source_before = source("source-before")
        elf_before = identity(ELF)
        require(elf_before == finish["executable_before"], "current ELF differs from original failed ELF")
        for index, name in enumerate(TESTS, 1):
            label = f"diagnostic-{index:02d}"
            logfile = OUTPUT / (label + ".libtest.log")
            argv = [ELF, name, "--exact", "--format=pretty", "--color=never", "--test-threads=1",
                    "--logfile", logfile]
            record = run(label, argv, Path(finish["cwd"]), timeout=120, expected_program=elf_before)
            result = {"name": name, "record": str(OUTPUT / (label + ".receipt.json")),
                      "exit_code": record["exit_code"], "timed_out": record["timed_out"],
                      "outcome": "INCOMPLETE", "attempts": 1}
            if logfile.exists():
                result["libtest_log"] = identity(logfile)
                text = logfile.read_text()
                process_completed = not record["timed_out"] and not record.get("error")
                if process_completed and text == "ok " + name + "\n" and record["exit_code"] == 0:
                    result["outcome"] = "ORIGINAL_FAILURE_NOT_REPRODUCED_ONCE"
                elif process_completed and text == "failed " + name + "\n" and record["exit_code"] == 101:
                    result["outcome"] = "ORIGINAL_FAILURE_REPRODUCED_ONCE"
            results.append(result)
            require(not record.get("error"), label + " process/identity error")
            require(identity(ELF) == elf_before, "ELF changed between diagnostic tests")
    except (Exception, KeyboardInterrupt) as error:
        errors.append(type(error).__name__ + ": " + str(error))
    finally:
        try:
            source_after = source("source-after")
            require(source_before is not None and source_after == source_before, "source pre/post mismatch")
        except (Exception, KeyboardInterrupt) as error:
            errors.append("source-after: " + str(error))
        try:
            elf_after = identity(ELF)
            require(elf_before is not None and elf_after == elf_before, "ELF pre/post mismatch")
            original_after = {str(path): identity(path) for path in input_paths}
            require(original_before == original_after, "original failure evidence changed")
            runner_after = identity(runner)
            require(runner_after == runner_before, "diagnostic runner changed")
        except (Exception, KeyboardInterrupt) as error:
            errors.append("identity-after: " + str(error))
        completed = (not errors and len(results) == 3 and
                     all(row["outcome"] != "INCOMPLETE" for row in results))
        summary = {"schema": "trnm-da-original-elf-diagnostic-v1",
                   "status": "DIAGNOSTIC_OBSERVATIONS_COMPLETE" if completed else "DIAGNOSTIC_INCOMPLETE_OR_BLOCKED",
                   "expected_head": HEAD, "runner_before": runner_before, "runner_after": runner_after,
                   "source_before": source_before, "source_after": source_after,
                   "elf_before": elf_before, "elf_after": elf_after,
                   "original_records_before": original_before, "original_records_after": original_after,
                   "records": records, "results": results, "errors": errors,
                   "original_result": {"passed": 412, "failed": 3, "ignored": 0, "exit_code": 101},
                   "original_failure_replaced": False, "root_cause_resolved": False,
                   "complete_suite_qualified": False, "whole_chain_pq_qualified": False,
                   "diagnostic_observations_complete": completed}
        save(OUTPUT / "diagnostic-summary.json", summary)
        print(json.dumps({"summary": str(OUTPUT / "diagnostic-summary.json"),
                          "status": summary["status"], "errors": errors}), flush=True)
    return 0 if completed else 1


if __name__ == "__main__":
    raise SystemExit(main())
