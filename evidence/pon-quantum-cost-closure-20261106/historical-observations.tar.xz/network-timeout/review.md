# Independent network timeout review

## Finding and resolution

The original adaptive-release timer could be silently lost when a nearest-
rounded addition disagreed with the later subtraction comparison. The supplied
public scenario/run-interface reproducer creates its first private block at
`0.5` seconds, requests a `0.1`-second timeout, and stops later mining through an
explicit shock. It requires timeout release because the work-lead threshold is
not met. The original implementation scheduled `0.6`, then found
`0.6 - 0.5 < 0.1`, and never rearmed the timer.

The preserved pre-fix run published nothing. The post-fix run published exactly
once at `0.6000000000000001`, the first represented time not earlier than the
exact sum of the two represented inputs. Both runs retained the same partial
second-search cost, `0.050000000000000044` seconds.

## Independent regression outcome

Seven controls passed in the recorded run, including adjacent observation
horizons, exactly representable deadlines, partial-prefix publication followed
by a fresh wait, future-time admission on both sides of the timeout, duplicate
timers/messages, and exact zero/full marked-domain probabilities at large
iteration counts. A second private prefix was not published before its future
timestamp became admissible, even after its timeout had expired.

The fixed helper is shared by timeout scheduling and expiry decisions. It is
recomputed after partial-prefix publication resets the waiting period. The
floating-clock comparison is equivalent to comparing the represented current
time against the exact deadline because the helper rounds the deadline upward.

## Scope reviewed

Private-branch mining retains its original branch when the public tip advances.
Honest-tip measurement retains the original candidate identity and completes
only whole Grover iterations before paying readout and candidate checks.
Cancellation and observation-horizon costs remain recorded. These are
conditional arithmetic/event-model properties; they do not demonstrate a
physical quantum miner, same-budget production of W1 work, or a consensus
security theorem.

## Evidence identities

`before-result.json` binds the original model source hash. `after-result.json`
binds the fixed model source hash used for the successful reproduction.
`independent-controls.log` records the seven independent checks.
`driver-lineage.json` binds those historical outputs to their original driver
snapshots. The current `.py` drivers have portable `--repo` arguments; their
final committed-source replay is left to the integrating owner.
