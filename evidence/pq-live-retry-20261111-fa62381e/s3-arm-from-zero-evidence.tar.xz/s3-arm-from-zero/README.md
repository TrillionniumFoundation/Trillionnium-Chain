# S3 ARM original from-zero failure: authenticated artifact readback

This read-only review narrows the failure in job [130596765035](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229558/job/130596765035), ARM head service-model. It reads the original release/Host artifact, not the later default-profile diagnostics. No native test, build, source edit or budget change was performed by this review.

## Original artifact identity

- Artifact ID: 13868186130.
- Name: `priority-ubuntu-24.04-arm-head-service-model-454ae116159867ff6cddd91b964523df7f7e16f0-1`.
- Run: 43042229558; job: 130596765035; attempt: 1.
- Source: `454ae116159867ff6cddd91b964523df7f7e16f0`.
- Tree: `3117250c4db0f2ae681d51ed6ee5e6a2fa7555a9`.
- Complete original ZIP: 8,071,029 bytes, SHA256 `de59665bf652a83ec0484cc275ad4e21b3eef44e331388fca18e4b0c04fb7d4b`.
- The complete downloaded ZIP matches the official artifact API digest. The job log independently names the same artifact ID and upload size.

The full ZIP remains in the local review directory. This small carrier retains selected original receipts, the full original confirmation report in gzip form, public artifact metadata, the original ZIP member roster, exact member hashes and the immutable S3 reader source. It omits the reusable download URL and other private transport metadata.

## Actual first failure

The original `from-zero-native/manifest.json` records:

- `all_named_tests_passed=true`: all five planned named release tests actually executed once, returned exit 0 and did not time out.
- Service-report validation passed.
- Sustained-report validation passed.
- Confirmation-report validation failed with `CONFIRMATION_TARGET`.
- `terminal.native_execution_completed=true` and `terminal.acceptance_passed=false`.
- The legacy `execution_finished=false` describes failure to reach the end of the original validation sequence; the explicit terminal record says all native children returned. It is not evidence of a still-running or timed-out child.

The original confirmation report is 12,482,065 bytes and has SHA256 `2037e4fb55cfdc0e4f571467ac222cd0d584a8b51204c197397344b1fe2a98bb`. The manifest's before-validation and retained-report identities agree, and this review verified those exact bytes from the ZIP.

The immutable S3 [reader](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/454ae116159867ff6cddd91b964523df7f7e16f0/scripts/ci/run_from_zero_native.py) requires `finite_target_met`, `invariant_target_met`, and `same_packet_sequence_in_both_runs` all to be true at the beginning of `validate_confirmation_report`. `ConfirmationReportChecks.flags` emits `CONFIRMATION_TARGET` when a required true flag is false. In the original report, only the first of these three root flags is false. This is the immediate source-defined refusal, not a source-pin mismatch or a failed Rust test assertion.

## Observed confirmation gap

The original workload offered one signed business transaction in each unchanged four-second phase, with the same packet sequence.

| Original observation | No attack workers | 16 from-zero pressure workers |
|---|---:|---:|
| Confirmed business transactions within original window | 1 | 0 |
| Required business transactions | 1 | 1 |
| Observed successful confirmation latency | 1,785,752,275 ns | unknown; unconfirmed |
| Business start after original window began | 136,903 ns | 62,819,089 ns |
| Submit ACKs returned in window | 7 of 7 | 7 of 7 |
| History responses returned in window | 7 of 7 | 7 of 7 |
| Independent page replays accepted in window | 7 of 7 | 6 of 7 |
| Verification errors | none | `PUBLIC_REQUEST_DEADLINE` |

The baseline's independent confirmation had depth six. The pressure phase retained no independent confirmation object. It retained one unconfirmed transaction and an original-window latency lower bound of 3,937,180,911 ns from business start, not a successful latency. Its report still says `invariant_target_met=true` and `receiver_matches_valid_honest_prefix=true`; it does not report full client/receiver state equality after the incomplete replay.

This narrows the failure to the original finite confirmation deadline and the final independent replay/confirmation path. It does not establish which CPU stage, scheduler, lock or I/O subsystem caused that path to miss the window. There is no OOM finding here. One offered transaction per phase is not saturated chain TPS, a p99 estimate, WAN acceptance or whole-chain PQ qualification.

## Retention and verification

`selected-member-manifest.json` binds each retained original member to the full official ZIP hash, member path, ZIP CRC, header offset, uncompressed byte count and SHA256. `from-zero-native/manifest.json` independently pins its own recorded subprocess outputs and confirmation report; all extracted members covered by that map were checked against it. The full confirmation report is preserved without byte edits inside `selected/from-zero-native/confirmation/report.json.gz`.

`source.json`, the manifest's before/after identities, all five original process/stdout/stderr records and the Host child/controller receipts remain original bytes. `failure-summary.json` and `confirmation-original-selected-fields.json` are labelled derived views. Source identities, budgets, original failures and all qualification flags are unchanged.

## Complete original manifest verification

All 50 files declared in the original native manifest, including the original ELF, stored database members and all three large native reports, were read from the complete authenticated ZIP and matched against their original manifest SHA256 values. `manifest-hash-verification.json` retains every expected/observed pair and size. The public carrier retains the requested original receipts, logs and complete confirmation report; other verified artifact members remain available in the full original ZIP and are not substituted with diagnostics.
