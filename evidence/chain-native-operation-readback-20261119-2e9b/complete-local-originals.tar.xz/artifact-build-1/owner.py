from pathlib import Path
import json,subprocess,hashlib,tarfile,io,time,sys
base=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b');src=base/'source';e=base/'artifact-build-1';e.mkdir(exist_ok=False)
(e/'owner.py').write_text(sys.argv[1])
out=src/'evidence/chain-native-operation-readback-20261119-2e9b';assert out.is_dir()
sha=lambda b:hashlib.sha256(b).hexdigest()
latest=json.loads((base/'source-gates-3/RESULT.json').read_text());assert latest['all_passed'] and latest['source_unchanged']
before=subprocess.check_output(['git','diff','--binary'],cwd=src);assert sha(before)==latest['after']['tracked_patch_sha256']
with (e/'preflight.stdout').open('xb') as so,(e/'preflight.stderr').open('xb') as se:r=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=src,stdout=so,stderr=se)
assert r.returncode==0
payload=json.loads((base/'evidence-driver-payload-2.json').read_text());final=json.loads((base/'evidence-final-payload-1.json').read_text())
f0=src/final['original_f0_workflow']['path'];assert sha(f0.read_bytes())==final['original_f0_workflow']['sha256'];assert f0.read_bytes()==subprocess.check_output(['git','show','HEAD:'+final['original_f0_workflow']['path']],cwd=src)
public='trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs';assert (src/public).read_bytes()==subprocess.check_output(['git','show','HEAD:'+public],cwd=src)
driver_dir=base/'archived-drivers-1';driver_dir.mkdir(exist_ok=False)
for name,body in payload['drivers'].items():
 assert body and '/' not in name
 (driver_dir/name).write_text(body)
for key in ['owner_receipts','terminal_receipts','original_f0_workflow']:(driver_dir/(key+'.json')).write_text(json.dumps(payload[key],indent=2)+'\n')
directories=['preparation-1','original-repeat-control-1','completed-graph-edit-1','native-validation-1','completed-graph-edit-2','native-validation-2','completed-graph-edit-3','native-validation-3','native-validation-4','current-source-registration-1','source-gates-1','current-source-registration-2','source-gates-2','current-source-registration-3','source-gates-3','archived-drivers-1']
paths=[]
for name in directories:
 p=base/name;assert p.is_dir(),name
 paths.extend(p.rglob('*'))
paths=[p for p in paths if p.is_file()]
for name in ['completed-graph-edit-payload-1.json','completed-graph-scope-binding-payload-2.json','completed-graph-ci-roster-payload-1.json','evidence-driver-payload-1.json','evidence-driver-payload-2.json','evidence-final-payload-1.json']:
 p=base/name;assert p.is_file(),name;paths.append(p)
paths.extend([e/'owner.py',e/'preflight.stdout',e/'preflight.stderr']);paths=sorted(set(paths))
assert all(not p.is_symlink() and p.is_relative_to(base) for p in paths)
inventory=[{'path':p.relative_to(base).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in paths]
archive=out/'complete-local-originals.tar.xz';started=time.monotonic()
with tarfile.open(archive,'x:xz') as tar:
 for row,p in zip(inventory,paths):
  raw=p.read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
  info=tarfile.TarInfo(row['path']);info.size=len(raw);info.mode=0o644;info.mtime=0;info.uid=0;info.gid=0;tar.addfile(info,io.BytesIO(raw))
with tarfile.open(archive,'r:xz') as tar:
 members=tar.getmembers();assert [m.name for m in members]==[r['path'] for r in inventory]
 for member,row in zip(members,inventory):
  raw=tar.extractfile(member).read();assert member.isfile() and len(raw)==row['bytes'] and sha(raw)==row['sha256']
raw=archive.read_bytes();archive_row={'path':archive.name,'bytes':len(raw),'sha256':sha(raw),'members':len(inventory),'every_member_verified':True,'creation_and_verification_wall_seconds':time.monotonic()-started}
(out/'archive-index.json').write_text(json.dumps({'archive':archive_row,'members':inventory},indent=2)+'\n')
reports={name:json.loads((base/name/'RESULT.json').read_text()) for name in directories if (base/name/'RESULT.json').exists()}
costs=[]
for name,value in reports.items():
 for row in value.get('stages',[]):
  if any('cpu' in key or 'wall' in key for key in row):costs.append({'report':name,'invocation':row})
cost={'schema':'chain-operation-local-cost-observations-v1','reported_child_process_invocations':costs,'scope':'per-process rusage and wall observations; native nested clocks overlap; do not add nested observations to these invocations','full_physical_cost_closed':False,'unknown':['some controller/edit/transfer CPU','whole-host CPU and contention','RSS including compiler and descendants','disk IO/storage byte-seconds','network bytes and retransmissions','energy','provider price and all research cost'],'currency_total':None}
(out/'cost-observations.json').write_text(json.dumps(cost,indent=2)+'\n')
production=base/'completed-graph-edit-3/production.patch';fullrust=subprocess.check_output(['git','diff','--binary','--','trillionnium'],cwd=src)
assert sha(fullrust)=='ea8a73a7311e8183cffc55c9492105ed72f7c1b1ec1e2c4d27debeee5490b766'
(out/'production.patch').write_bytes(production.read_bytes());(out/'candidate-before-archive.patch').write_bytes(before)
construction=[]
for p in sorted((src/'trillionnium/crates/trnm-pon-node/src').rglob('*.rs')):
 for n,line in enumerate(p.read_text().splitlines(),1):
  if any(term in line for term in ['GraphScope(', 'GraphAccess {', 'VerifiedGraph {', 'remember_completed(', '.into_scope()', '.is_for(&self.graph_scope']):
   construction.append({'path':p.relative_to(src).as_posix(),'line':n,'text':line,'test_path':'tests' in p.name})
(out/'scope-construction-and-consumption-inventory.json').write_text(json.dumps(construction,indent=2)+'\n')
readout={'schema':'chain-original-operation-completed-graph-candidate-v1','source_base':'f088f1d4f8a50aff0c5ecd465480b2aeee6e5e94','base_tree':'9181b29ff0a4f90bb7b9ec99c1d79e51c10dd95e','production_patch_sha256':sha(production.read_bytes()),'rust_source_and_controls_patch_sha256':sha(fullrust),'all_tracked_patch_before_archive_sha256':sha(before),'original_repeat_control':{'native_exit_code':101,'full_callbacks':140,'first_partial_callbacks':44,'repeated_callbacks':44},'candidate_repeat_control':{'full_callbacks':140,'first_partial_callbacks':44,'repeated_callbacks':5,'actual_graphs':2},'owner_replay_controls':{'new_scope_same_transaction':'NATIVE_ACCOUNT_FRONTIER','new_scope_after_commit':'NATIVE_ACCOUNT_FRONTIER'},'current_native':{'authenticated':{'passed':127,'failed':0,'ignored':0,'post_write_controls':49},'detached_admission':{'passed':25,'failed':0,'ignored':1},'history_import':{'passed':56,'failed':0,'ignored':1},'strict_clippy_exit':0,'original_locked_linux_tree_exit':0,'broader_offline_metadata_exit':101,'broader_offline_metadata_reason':'socket2 0.6.1 absent from cache'},'current_source_guards':{'native_roster_tests':19,'applicability_tests':42,'pq_current_map_tests':25,'w1_current_map_tests':14,'source_binding_negatives':114,'raw_source_negatives':43,'pinned_blobs':2622,'ci_contract_exit':0},'original_f0_workflow':final['original_f0_workflow'],'original_f0_business':{'previous_source':'333fe8cd89f0ec855e7b856e99e40f48f56c2137','previous_run':44441548029,'30s_confirmations':1,'30s_denominator':6,'scheduled_4s_confirmations':0,'scheduled_4s_denominator':6,'strict_depletion_witness':False,'candidate_new_f0_status':'not yet run at candidate preparation'},'unchanged_original_controls':['public_v3 source and 512-attempt depletion assertion','2-second prepaid burst and refill','all original six 30s and scheduled 4s business targets','queues/workers/physical Host file reads/checkpoints for actual work','4 nominated records/16 source frontier slots/65536 accounts/131071 nodes/64 retained snapshots'],'failed_attempts_retained':['original-repeat-control-1/native exit101 (expected repeated-path defect)','native-validation-2/E0505 compile exit101','native-validation-3/126pass1fail required cost output environment absent','native-validation-4/broader offline metadata exit101','source-gates-1/missing historical manifests and old W1 current SHA','source-gates-2/stale generated applicability table','current-source-registration-3/driver KeyError after exact one-name documentation update; independent byte readback preserved'],'archive':archive_row,'cost_report':'cost-observations.json','all_previous_negative_f0_and_22_ci_workflows_in_base':True,'f0_qualified':False,'all_blockers_closed':False,'full_physical_cost_closed':False,'production_activation':False}
(out/'READOUT.json').write_text(json.dumps(readout,indent=2)+'\n');(out/'README.md').write_text(final['readme'])
result={'archive':archive_row,'readout_sha256':sha((out/'READOUT.json').read_bytes()),'readme_sha256':sha((out/'README.md').read_bytes()),'source_rust_unchanged':True,'f0_qualified':False}
(e/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
