# Independent follow-up review: M06 dcdf0503a

**BLOCKED isolated branch. Integration is not accepted.**

Measured source: `dcdf0503a1c52c4423963e9acba176f13fea2913`; tree `baab59b487ff8833b184a163a11142f78e959927`. Evidence-only successor: `c26e683902c1c1d7b66f6ad8f523a60c827a1e2c`. Previous reviewed source08d and its review are preserved unchanged.

This reviewer read the five-file source delta from08d and the actual stdout/stderr/process receipts. All source-delta bytes match measured dcdf; c26e changes only four evidence files and the worktree is clean. The actual binary was independently SHA256-hashed as `5639c4c749ef8768352cb261acfb9ca3eadf2232d5192ab735b89e8f10f3753c`, matching `compiled-source-dcdf0503a.json`. No implementation edit, build or test was performed by this reviewer.

## R4b is corrected on dcdf, with the actual original deadline exercised

`error.rs` adds explicit `LegacyRequestCancelled` and `LegacyRequestDeadline`, retaining the original wire strings. The actual legacy progress producer constructs those typed errors. Remote signed refusals retain `RemoteRefusal` and no local code; the control test for this boundary passed in the affected suite.

The test-only pause remains immediately after the real original durable intent commit, but now repeatedly invokes the **actual caller progress** until the original10-second deadline returns. It no longer injects `PublicRequestCancelled`. The11-second assertion detects a broken bound; the client's15-second read limit only observes the service result. Neither extends the service deadline or creates credit. The changed-payload negative changes a proof byte while preserving legal packet framing; the previous08d test failure at invalid transaction encoding remains archived.

Actual positive receipt `signed-actual-deadline-recovery-dcdf0503a` passed: the first attempt observed10,002,575,139ns and returned nonterminal `REQUEST_DEADLINE`; the original nonce remained pending. Wrong payload/target/nonce/context controls did not mutate durable state. A new exact signed attempt completed that same pending nonce once, with one W1 and one audit row; the cached response was byte-identical and reopen was correct. This closes the specific08d producer/classification mismatch. It establishes local legacy functional recovery under controlled fault placement, not scalar paidHost or independent recovery.

## R5 remains a reproduced liveness blocker

`withheld-actual-deadline-counterexample-dcdf0503a` used the same actual timer path, observed10,003,487,495ns, and then permanently withheld the original frame. A different honest authenticated native Submit succeeded **0/1**, receiving `REORG_IN_PROGRESS`. Before/after durable state was identical: done0, highest_ack0, pending_nonce1, audit_rows1, unchanged active/target. Work verification count remained1; no recovery CPU domain was invented.

The test exited101 with the original assertion that the honest mutation must succeed. Its failure was not inverted into a passing security test. The durable state and sockets are real; the placement of the deadline is a test-only pause. This is a functional control-path counterexample, not a demonstration that a remote peer can naturally force the pause on this small fixture. The required independent original-owner, original-account bounded reconciler is still absent, so exact-client recovery does not qualify the design.

## R2's scheduling correction did not pass paid large-state acceptance

The source no longer treats the8MiB acceleration cap as an invalid-state rule: a private counted result sends the exact original W1-checked packet to the old held checked-M06 schedule, without alternative work, account or deadline. However, the required real paid-domain gate **failed**.

`detached-tests-dcdf0503a` ran13 tests:11passed,1failed,1ignored. The valid custom-genesis fixture had8,625,548 canonical key/value bytes; its early8,391,103-byte count is only a scanned lower bound. The first legacy-backend paid attempt returned `PUBLIC_MUTATION_CPU_BUDGET` after3,008,232,223ns owner CPU, before any worker started. The second authenticated-backend iteration did not execute. There was no new credit or replacement account.

Thus the source-level branch is present, but full paid acceptance/parity is **not demonstrated**. This result alone does not establish that the old held path under the identical meter would succeed, or isolate the marginal cost of the new preparation; this review does not call it a measured relative regression without that comparison. It remains a failed acceptance gate.

## Other observed results and limits

The actual held-mutex two-second/control-only deadline test passed in the affected suite, closing R1's identified omission at that local scope. Snapshot/foreign-write/reuse/SQL-readback controls also passed in the detached subset. They are not a proof of all concurrency schedules or hard realtime.

The final affected selection had **373passed,1failed,3ignored** out of377. The old signed Head history-cost test failed `REMOTE_RETRYABLE:BUSY:Duplicate` after its64-success checkpoint in a planned256-request sequence. Its exact failed nonce was not printed and cannot be reconstructed from the checkpoint alone. Final256 and cold-reopen assertions were not reached. The cause is unresolved; this is not a clean regression run or an established harmless timing failure.

The final actual1,024-signed-transfer cost fixture passed at1,035keys/98,565canonical bytes: preparation17.112ms, M064.620ms, SQLcommit68.938ms, and a separate deep clone0.406ms. These are one fixture's measured intervals, not throughput or fair-service results. SQL still dominates the observed writer-held work. Materialization, copies and full SQL readback remain; retained capacity is not a process RSS bound.

Strict native all-target/all-feature Clippy and fmt are reported with retained receipts as passing. The repository checker remains failed on the inherited work-cost/DAA lane contract. The earlier complete native attempt was stopped with failures; the affected final selection also failed. No original A03 from-zero campaign on this final source, WAN/Sybil fairness, production activation or complete native PASS is claimed.

## Retained raw evidence

All paths are under `/workspace/scratch/56818e4fba76/history-validation/m06-precommit/`:

- `signed-actual-deadline-recovery-dcdf0503a`:1passed,exit0.
- `withheld-actual-deadline-counterexample-dcdf0503a`:0passed/1failed,exit101.
- `detached-tests-dcdf0503a`:11passed/1failed/1ignored,exit101.
- `affected-regressions-dcdf0503a`:373passed/1failed/3ignored,exit101.
- `full-state-cost-dcdf0503a`:1passed,exit0.

The companion JSON records exact receipt and source hashes. This follow-up is separate from the already-published evidence archive; it does not rewrite08d, prior failures or native measurements. Keep dcdf/c26e isolated until independent recovery, paid large-state acceptance and remaining regression gates are actually resolved.
