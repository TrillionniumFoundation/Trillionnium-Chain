from pathlib import Path
import subprocess,json,hashlib,time,sys,traceback
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');prior=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b/source');out=s.parent/'source-contract-restore-2';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);res={'schema':'chain-retained-test-input-restore-v1','complete':False,'restored':[]};t=time.monotonic()
try:
 p=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=s,capture_output=True);(out/'preflight.stdout').write_bytes(p.stdout);(out/'preflight.stderr').write_bytes(p.stderr);assert p.returncode==0
 rows=subprocess.check_output(['git','ls-tree','-r','--full-tree','HEAD'],cwd=s,text=True).splitlines()
 for row in rows:
  meta,path=row.split('\t',1);mode,kind,blob=meta.split()
  if kind!='blob' or mode not in ['100644','100755'] or (s/path).exists() or not (prior/path).is_file():continue
  data=subprocess.check_output(['git','cat-file','blob',blob],cwd=s);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob
  target=s/path;target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as f:f.write(data)
  if mode=='100755':target.chmod(0o755)
  res['restored'].append({'path':path,'bytes':len(data),'git_blob':blob,'sha256':hashlib.sha256(data).hexdigest()})
 res['complete']=True;res['wall_seconds']=time.monotonic()-t;res['restored_files']=len(res['restored']);res['restored_bytes']=sum(r['bytes'] for r in res['restored']);(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
except BaseException as e:
 res['error']=repr(e);(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');(out/'error.log').write_text(traceback.format_exc());raise
