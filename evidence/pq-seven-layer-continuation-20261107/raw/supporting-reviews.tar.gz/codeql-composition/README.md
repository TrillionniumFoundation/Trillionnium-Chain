# CodeQL workflow composition candidate

This scratch candidate composes the local SARIF retention controls from
`e36cfb88956a0e35e53d74c5ab71c94c628439d9` with the concurrent workflow change in
`271a87f831aa7e08f3c2024f738504c1422122dd`. The concurrent delta from `e70f1344`
changes only the workflow and a SQLite source pin already repaired in e36.
The candidate patch changes only the workflow and its existing test file.
`verify_ci_source.py` is copied unchanged solely to run the scratch controls.

## Proposed behavior

- Keep the pinned official init/analyze actions, real queries, and the three
  languages (`rust`, `python`, `actions`). PRs retain both `head` and
  `prospective-merge`, for six combinations. Pushes retain three head lanes.
- Preserve the concurrent `upload: never` decision. Default setup continues
  to own Code Scanning uploads; no repository security setting is changed.
- Check immutable head or ordered, reproducible prospective-merge source
  before and after analysis using the retained real source verifier.
- Keep the existing SARIF readback negatives and non-rewriting behavior.
  The main `codeql-sarif-*` artifact is eligible only after successful SARIF
  readback and contains both original `*.sarif` files and the identity
  directory. Identity JSON alone cannot satisfy that artifact.
- Retain before/after source JSON when verification succeeds, raw source and
  comparison logs, and actual step outcomes. A source verification or comparison
  failure remains a failed job even when an artifact can be retained.
- When SARIF is absent or invalid, preserve identity/outcome diagnostics under
  the separate `codeql-diagnostics-*` name. It cannot stand in for a SARIF result.

The pinned action's input definition documents `never` as suppressing SARIF
uploads, while query execution remains a separate control:
[pinned analyze action](https://github.com/github/codeql-action/blob/1fc58d04a4d4374f921bdac573c3811c240f9c26/analyze/action.yml).
GitHub documents the default-setup upload conflict and retaining default setup
while disabling competing uploads:
[default-setup upload guidance](https://docs.github.com/en/enterprise-cloud@latest/code-security/reference/code-scanning/sarif-files/troubleshoot-sarif-uploads/default-setup-enabled).

## Why byte comparison is appropriate

`verify_ci_source.py` returns deterministic source fields: kind, exact commit
and tree, candidate/base/merge identities, tracked entry and byte counts, and
fixed verification flags. Its sorted JSON contains no timestamps, temporary
paths, run IDs, or measurement results. An unchanged source with the same
expected identities therefore produces identical receipts. The controls run
both actual shell snippets with the real verifier and real temporary Git
repositories; they also corrupt a receipt to verify that `cmp` remains fatal.
`set -euo pipefail` preserves verifier and comparison failures through `tee`.

The comparison checks two observations. It does not prove uninterrupted
immutability between them, bind every external query pack or extraction
dependency, or prove that a remote CodeQL job executed successfully.

## Validation and application

`validation-summary.json` and `controls.stderr` contain the exact local results,
source hashes and invocation. The control suite retains the four original
SARIF cases and adds seven configuration/source/outcome controls. These tests
use clearly labeled SARIF fixtures; they do not generate substitute scan output
or run CodeQL/GitHub Actions.

Run the candidate controls from this directory:

```bash
python3 -B candidate/scripts/ci/test_codeql_retention.py
```

`combined.patch` is based on the captured e36 versions. Apply or resolve it only
after the frozen native observations finish, then update the two source pins
on the final composed source. The native receipts from e36 retain their exact
e36 identity; a later CI-only composition must describe that source mapping
without relabeling them as fresh native execution on the final commit.
