// Reproduce the original fixture's per-syscall timeout pattern on real TCP.
// A logical 75 ms frame budget is NOT passed to the legacy read_exact call.
use std::{
    io::{Read, Write},
    net::{TcpListener, TcpStream},
    thread,
    time::{Duration, Instant},
};

fn main() {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let mut client = TcpStream::connect(listener.local_addr().unwrap()).unwrap();
    let (mut server, _) = listener.accept().unwrap();
    let sender = thread::spawn(move || {
        for _ in 0..8 {
            server.write_all(b"x").unwrap();
            thread::sleep(Duration::from_millis(25));
        }
    });
    client.set_read_timeout(Some(Duration::from_secs(1))).unwrap();
    let start = Instant::now();
    let mut bytes = [0; 8];
    let result = client.read_exact(&mut bytes);
    let wall = start.elapsed();
    sender.join().unwrap();
    assert!(result.is_ok());
    assert_eq!(&bytes, b"xxxxxxxx");
    assert!(wall > Duration::from_millis(75));
    println!(
        "{{\"schema\":\"legacy-socket-timeout-counterexample-v1\",\"logical_frame_budget_ns\":75000000,\"per_syscall_timeout_ns\":1000000000,\"frame_bytes\":8,\"observed_wall_ns\":{},\"legacy_late_success\":true,\"scope\":\"actual loopback socket pattern, not the original 15-second full campaign\"}}",
        wall.as_nanos()
    );
}
