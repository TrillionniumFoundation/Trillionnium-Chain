#!/usr/bin/env python3
"""Read-only source/provider audit plus fresh, task-local native smoke checks."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import tempfile


WORK = Path('/workspace/scratch/baeed38792e5')
CHAIN = WORK / 'chain'
PQ = WORK / 'pq-work/pq-with-sealed'
BUILD = Path('/workspace/scratch/fee7901564fd-next/provider-native799/trnm-pq-provider-3.5.9.UF6qy3Q5')
PREFIX = BUILD / 'install'
PRIOR = Path('/workspace/scratch/fee7901564fd-next/validation-native799/prepare-provider-attempt1/pq-provider/provider.json')
OUT = WORK / 'liveness-work/provider-review-20261105'


def identity(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), symlink=path.is_symlink())


def main():
    OUT.mkdir()
    report = dict(schema='independent-existing-pq-provider-review-v1',
                  observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  source_tree_modified=False, provider_rebuilt=False,
                  upstream_full_tests_run=False, cargo_clippy_run=False,
                  native_rust_pq_tests_run=False, commands=[], status='IN_PROGRESS')
    try:
        script = CHAIN / 'scripts/ci/prepare_pq_provider.sh'
        source = script.read_text()
        version = re.search(r"readonly openssl_version='([^']+)'", source).group(1)
        archive_sha = re.search(r"readonly openssl_sha256='([^']+)'", source).group(1)
        prior = json.loads(PRIOR.read_text())
        report['current_preparation_script'] = identity(script)
        report['original_provider_receipt'] = identity(PRIOR)
        report['original_provider_receipt_contents'] = prior
        report['pinned_version'] = version
        report['pinned_archive_sha256'] = archive_sha
        report['source_archive'] = identity(BUILD / f'openssl-{version}.tar.gz')
        assert report['source_archive']['sha256'] == archive_sha
        assert prior['version'] == version == '3.5.9'
        assert prior['source_archive_sha256_expected'] == archive_sha
        assert prior['preparation_script_sha256'] == report['current_preparation_script']['sha256']
        assert prior['result'] == 'PREPARED_AND_SMOKE_VERIFIED'
        assert prior['exit_code'] == 0 and prior['last_stage'] == 'complete'
        assert prior['source_digest_verified'] and prior['backend_exported'] and prior['static_build']
        assert prior['install_prefix'] == str(PREFIX)
        assert prior['ml_dsa_65_sign_verify_and_wrong_message_rejection']
        actual_inputs = [identity(Path(item['path'])) for item in prior['native_backend_inputs']]
        for expected, actual in zip(prior['native_backend_inputs'], actual_inputs, strict=True):
            assert actual['sha256'] == expected['sha256'] and actual['bytes'] == expected['bytes']
            assert not actual['symlink']
        report['verified_native_backend_inputs'] = actual_inputs
        assert prior['cli_sha256'] == actual_inputs[0]['sha256']
        pkgconf = WORK / 'host-tools/pkgconf'
        pkg_receipt = WORK / 'verification/host-pkgconf.json'
        pkg_expected = json.loads(pkg_receipt.read_text())
        report['pkgconf'] = identity(pkgconf)
        report['pkgconf_receipt'] = identity(pkg_receipt)
        assert report['pkgconf']['sha256'] == pkg_expected['sha256']
        report['pkgconfig_inputs'] = [identity(PREFIX / 'lib/pkgconfig' / name)
                                     for name in ('openssl.pc', 'libcrypto.pc', 'libssl.pc')]
        fixed_env = {
            'OPENSSL_DIR': str(PREFIX), 'OPENSSL_STATIC': '1',
            'TRNM_PQ_OPENSSL': str(PREFIX / 'bin/openssl'),
            'TRNM_PQ_OPENSSL_SHA256': prior['cli_sha256'], 'TRNM_PQ_OPENSSL_VERSION': version,
            'OPENSSL_CONF': '/dev/null', 'OPENSSL_MODULES': str(PREFIX / 'lib/ossl-modules'),
            'PKG_CONFIG': str(pkgconf), 'PKG_CONFIG_PATH': str(PREFIX / 'lib/pkgconfig'),
        }
        env = dict(os.environ)
        inherited_overrides = {k: v for k, v in env.items()
                               if 'OPENSSL' in k or k.startswith('PKG_CONFIG')}
        report['inherited_provider_discovery_environment'] = inherited_overrides
        assert not inherited_overrides, 'Review inherited overrides before using fixed environment'
        env.update(fixed_env)
        report['fixed_environment'] = fixed_env
        report['environment_contract'] = {
            'original_seven_provider_exports_preserved': True,
            'pkg_config_is_real_verified_binary': True,
            'pkg_config_path_resolves_pinned_openssl_first': True,
            'requires_no_target_prefixed_or_separate_openssl_path_overrides': True,
        }

        def run(argv, expected=0):
            result = subprocess.run([str(x) for x in argv], env=env, text=True, capture_output=True, timeout=30)
            observation = dict(argv=[str(x) for x in argv], exit_code=result.returncode,
                               stdout=result.stdout, stderr=result.stderr)
            report['commands'].append(observation)
            if expected is None:
                assert result.returncode != 0, observation
            else:
                assert result.returncode == expected, observation
            return result.stdout

        cli = PREFIX / 'bin/openssl'
        actual_version = run([cli, 'version'])
        assert actual_version.strip() == prior['cli_version_output']
        providers = run([cli, 'list', '-providers'])
        assert 'version: 3.5.9' in providers
        dynamic = run(['readelf', '-d', cli])
        needed = [line.strip() for line in dynamic.splitlines() if 'NEEDED' in line]
        assert not any('libcrypto' in line or 'libssl' in line for line in needed)
        report['cli_elf_needed'] = needed
        assert run([pkgconf, '--modversion', 'openssl']).strip() == '3.5.9'
        assert run([pkgconf, '--variable=libdir', 'openssl']).strip() == str(PREFIX / 'lib')
        assert run([pkgconf, '--variable=includedir', 'openssl']).strip() == str(PREFIX / 'include')
        run([pkgconf, '--static', '--libs', '--cflags', 'openssl'])

        with tempfile.TemporaryDirectory(prefix='fresh-smoke-', dir=OUT) as temporary:
            smoke = Path(temporary)
            (smoke / 'message').write_bytes(b'Independent reused provider ML-DSA-65 smoke 20261105\n')
            (smoke / 'wrong-message').write_bytes(b'Wrong independent reused provider message\n')
            run([cli, 'genpkey', '-provider', 'default', '-algorithm', 'ML-DSA-65', '-out', smoke / 'private.pem'])
            run([cli, 'pkey', '-provider', 'default', '-in', smoke / 'private.pem', '-pubout', '-out', smoke / 'public.pem'])
            run([cli, 'pkeyutl', '-provider', 'default', '-sign', '-rawin', '-inkey', smoke / 'private.pem',
                 '-in', smoke / 'message', '-out', smoke / 'signature.bin'])
            run([cli, 'pkeyutl', '-provider', 'default', '-verify', '-rawin', '-pubin', '-inkey', smoke / 'public.pem',
                 '-in', smoke / 'message', '-sigfile', smoke / 'signature.bin'])
            run([cli, 'pkeyutl', '-provider', 'default', '-verify', '-rawin', '-pubin', '-inkey', smoke / 'public.pem',
                 '-in', smoke / 'wrong-message', '-sigfile', smoke / 'signature.bin'], expected=None)
            report['fresh_smoke'] = dict(ml_dsa_65_key_generation=True, sign=True,
                                         correct_message_verified=True, wrong_message_rejected=True,
                                         signature_bytes=(smoke / 'signature.bin').stat().st_size,
                                         private_key_retained=False)

        # Verify installed headers and archive link together, without Cargo or rebuilding OpenSSL.
        probe = OUT / 'static-libcrypto-probe.c'
        probe.write_text('''#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/opensslv.h>
#include <stdio.h>
#include <string.h>
#if OPENSSL_VERSION_MAJOR != 3 || OPENSSL_VERSION_MINOR != 5 || OPENSSL_VERSION_PATCH != 9
#error Wrong OpenSSL headers
#endif
int main(void) {
    if (strcmp(OpenSSL_version(OPENSSL_VERSION), OPENSSL_VERSION_TEXT) != 0) return 1;
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_from_name(NULL, "ML-DSA-65", "provider=default");
    if (ctx == NULL) return 2;
    EVP_PKEY_CTX_free(ctx);
    printf("header=%s\\nruntime=%s\\nML-DSA-65=available\\n", OPENSSL_VERSION_TEXT, OpenSSL_version(OPENSSL_VERSION));
    return 0;
}
''')
        report['static_probe_source'] = identity(probe)
        assert os.statvfs(OUT).f_bavail * os.statvfs(OUT).f_frsize > 1024**3 + 32 * 1024**2
        binary = OUT / 'static-libcrypto-probe'
        run(['cc', '-Wall', '-Wextra', '-Werror', '-I' + str(PREFIX / 'include'), probe,
             PREFIX / 'lib/libcrypto.a', '-ldl', '-pthread', '-o', binary])
        run([binary])
        probe_dynamic = run(['readelf', '-d', binary])
        assert not any(('libcrypto' in line or 'libssl' in line) for line in probe_dynamic.splitlines() if 'NEEDED' in line)
        report['static_probe_binary'] = identity(binary)
        report['static_headers_and_archive_link_verified'] = True
        for before in actual_inputs:
            assert identity(Path(before['path'])) == before

        admission = PQ / 'codex-rs/hepta-agentd/src/cognitive_three_generation_admission.rs'
        helper = PQ / 'codex-rs/hepta-agentd/src/cognitive_three_generation_support.rs'
        admission_source = admission.read_text()
        save_position = admission_source.index('    save(\n        &root.join(format!("{name}-evaluation-inputs.json"))')
        controls_position = admission_source.index('    let compatibility = controls::canonical_controls(')
        controls_end = admission_source.index('    )?;', controls_position)
        selection_position = admission_source.index('    let prepared = eval::prepare_self_evolution_product_selection_v1(', controls_end)
        assert save_position < controls_position < controls_end < selection_position
        helper_source = helper.read_text()
        save_start = helper_source.index('pub(super) fn save(')
        save_end = helper_source.index('\n}', save_start) + 2
        save_helper = helper_source[save_start:save_end]
        assert '.create_new(true)' in save_helper and save_helper.count('.sync_all()') == 2
        report['no_update_review'] = {
            'admission_source': identity(admission), 'save_helper_source': identity(helper),
            'full_input_save_line': admission_source[:save_position].count('\n') + 1,
            'canonical_controls_call_line': admission_source[:controls_position].count('\n') + 1,
            'product_prepare_line': admission_source[:selection_position].count('\n') + 1,
            'full_input_save_precedes_fallible_controls': True,
            'save_is_create_new_file_sync_and_parent_directory_sync': True,
            'save_helper': save_helper, 'runtime_no_update_reexecuted': False,
            'review_scope': 'source order and durable save helper; not full three-generation execution',
            'git_status': subprocess.check_output(['git', 'status', '--short', '--', str(admission)], cwd=PQ, text=True).strip(),
        }
        (OUT / 'provider-fixed.env').write_text(''.join(f'export {name}={shlex.quote(value)}\n' for name, value in fixed_env.items()))
        report['environment_file'] = identity(OUT / 'provider-fixed.env')
        report['status'] = 'PASS_WITH_RECORDED_SCOPE'
    except Exception as error:
        report['status'] = 'FAIL'
        report['error'] = repr(error)
        raise
    finally:
        report['completed_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (OUT / 'review.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
        print(json.dumps({'status': report['status'], 'report': str(OUT / 'review.json')}, indent=2))


if __name__ == '__main__':
    main()
