from pathlib import Path
import subprocess,resource,hashlib,time,json,os,traceback
base=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b');src=base/'source';e=base/'native-validation-4';e.mkdir(exist_ok=False)
res={'schema':'chain-completed-graph-native-validation-v4','base':'f088f1d4f8a50aff0c5ecd465480b2aeee6e5e94','stages':[],'full_physical_cost_closed':False,'f0_qualified':False,'business_requests':0}
def save():(e/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(n,cmd,env=None):
 t=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':n,'command':cmd,'cwd':str(src)};res['stages'].append(row);save()
 with (e/(n+'.stdout')).open('xb') as out,(e/(n+'.stderr')).open('xb') as err:
  p=subprocess.Popen(cmd,cwd=src,stdout=out,stderr=err,env=env);row['pid']=p.pid;save();rc=p.wait()
 after=resource.getrusage(resource.RUSAGE_CHILDREN);row.update(exit_code=rc,wall_seconds=time.monotonic()-t,child_user_cpu_seconds=after.ru_utime-before.ru_utime,child_system_cpu_seconds=after.ru_stime-before.ru_stime);save();print(json.dumps(row),flush=True);return rc
try:
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 before=subprocess.check_output(['git','diff','--binary'],cwd=src);(e/'source-before.patch').write_bytes(before)
 env=os.environ.copy();env.update(PATH='/home/qq/.cargo/bin:'+env['PATH'],CARGO_TARGET_DIR=str(base/'target'),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true')
 env['TRNM_RETAINED_DELTA_COST_PATH']=str(e/'retained-delta-cost.jsonl')
 res['retained_delta_cost_path']=env['TRNM_RETAINED_DELTA_COST_PATH']
 assert not Path(env['TRNM_RETAINED_DELTA_COST_PATH']).exists()
 res['retained_prior_failure']='native-validation-3: 126 passed / 1 failed because required create-new retained cost path was absent'
 assert run('fmt-check',['/home/qq/.cargo/bin/cargo','+1.95.0','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'],env)==0
 native=['/home/qq/.cargo/bin/cargo','+1.95.0','test','--offline','--locked','--release','--jobs','2','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib']
 rc=run('native-authenticated',native+['store::native_authenticated::','--','--include-ignored','--show-output','--test-threads=1'],env)
 res['native_authenticated_passed']=rc==0
 if rc==0:
  rc2=run('detached-admission',native+['store::detached_admission::','--','--nocapture','--test-threads=1'],env)
  res['detached_admission_passed']=rc2==0
  if rc2==0:
   rc3=run('history-import',native+['ingress::history_import::','--','--nocapture','--test-threads=1'],env)
   res['history_import_passed']=rc3==0
   if rc3==0:
    res['clippy_passed']=run('strict-clippy',['/home/qq/.cargo/bin/cargo','+1.95.0','clippy','--offline','--locked','--release','--jobs','2','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--all-targets','--','-D','warnings'],env)==0
 if res.get('clippy_passed'):
  res['locked_linux_graph_passed']=run('locked-linux-graph',['/home/qq/.cargo/bin/cargo','+1.95.0','metadata','--offline','--locked','--format-version','1','--manifest-path','trillionnium/Cargo.toml','--filter-platform','x86_64-unknown-linux-gnu'],env)==0
  res['native_registry_passed']=run('native-registry',native+['--','--list'],env)==0
 after=subprocess.check_output(['git','diff','--binary'],cwd=src);(e/'source-after.patch').write_bytes(after)
 res['source_unchanged']=before==after;assert res['source_unchanged']
 res['source_patch_sha256']=hashlib.sha256(after).hexdigest()
except BaseException as ex:
 res['error']=repr(ex);(e/'driver-error.log').write_text(traceback.format_exc())
finally:
 save();print(json.dumps(res),flush=True)
