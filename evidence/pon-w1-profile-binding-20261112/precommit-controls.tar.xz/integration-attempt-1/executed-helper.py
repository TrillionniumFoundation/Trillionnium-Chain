#!/usr/bin/env python3
"""Integrate already-verified evidence and commit a source-bound candidate."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/home/qian-qi/work/chain-w1-profile-binding-20261112-b34d')
WORK = ROOT.parent
BASE = '229b14c2d366a257f51f287d502a550df2332338'
OUT = WORK / 'w1-integrated-candidate-20261112-b34d'
CORPUS = 'config/pon/pq-cross-branch-corpus-v1.json'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT).decode().strip()


def record(label, command, expected=0):
    proc = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=600)
    (OUT / (label + '.stdout')).write_bytes(proc.stdout)
    (OUT / (label + '.stderr')).write_bytes(proc.stderr)
    (OUT / (label + '.json')).write_text(json.dumps({'command': command, 'exit_code': proc.returncode,
         'stdout_sha256': digest(proc.stdout), 'stderr_sha256': digest(proc.stderr)}, indent=2) + '\n')
    require(proc.returncode == expected, label + ': failed')


def copy_packet(source, dest, expected):
    files = {str(p.relative_to(source)): p for p in source.rglob('*') if p.is_file()}
    require(set(files) == set(expected), 'packet roster differs')
    require(all(not p.is_symlink() and p.stat().st_size <= 4194304 for p in files.values()), 'unsafe or oversized packet')
    for name, path in files.items():
        raw = path.read_bytes()
        require(digest(raw) == expected[name], 'packet digest differs: ' + name)
    shutil.copytree(source, dest)
    for name, path in files.items():
        require(path.read_bytes() == (dest / name).read_bytes(), 'copied packet differs')


def main():
    OUT.mkdir(exist_ok=False)
    require(git('rev-parse', 'HEAD') == BASE, 'source head advanced')
    require(set(git('diff', '--name-only').splitlines()) == {
        CORPUS, 'config/pon/pq-proof-profile-binding-v1.json',
        '.github/workflows/chain-hepta-closure-candidate.yml', 'scripts/ci/test_pq_proof_profile_binding.py'},
        'unexpected source changes')
    record('preflight-before', ['bash', 'scripts/project-preflight.sh'])
    source = WORK / 'w1-v5-packet-20261112-b34d'
    manifest = (source / 'packet-manifest.json').read_bytes()
    require(digest(manifest) == 'c50b3757d4178e505a4ccae1de4cc00d90157b8547e44141a700bf5de92bfbe8', 'V5 packet changed')
    expected = {name: value['sha256'] for name, value in json.loads(manifest)['files'].items()}
    expected['packet-manifest.json'] = digest(manifest)
    v5 = ROOT / 'evidence/pon-w1-v5-twoarch-readback-20261112'
    copy_packet(source, v5, expected)
    source = WORK / 'w1-service-packet-20261112-b34d'
    sums = (source / 'SHA256SUMS').read_bytes()
    require(digest(sums) == 'b0e823b4a47296466d7586ceded14613817d73c4afd471e971d99713808a1b78', 'service packet changed')
    expected = dict((line.split('  ', 1)[1], line.split('  ', 1)[0]) for line in sums.decode().splitlines())
    expected['SHA256SUMS'] = digest(sums)
    service = ROOT / 'evidence/pon-w1-service-readback-20261112'
    copy_packet(source, service, expected)
    repair = ROOT / 'evidence/pon-w1-profile-binding-20261112'
    repair.mkdir(exist_ok=False)
    shutil.copyfile(WORK / 'pr935-before-b34d.json', repair / 'predecessor-pr935.json')
    controls = WORK / 'w1-binding-controls-20261112-b34d'
    selected = []
    for path in sorted(controls.rglob('*')):
        if path.is_file() and (path.suffix in ('.json', '.stdout', '.stderr', '.log', '.patch', '.py') or path.name.endswith('.jsonl')):
            require(not path.is_symlink() and path.stat().st_size <= 4194304, 'oversized control observation')
            target = repair / 'precommit-controls' / path.relative_to(controls)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(path.read_bytes())
            selected.append({'path': str(target.relative_to(repair)), 'sha256': digest(target.read_bytes()), 'bytes': target.stat().st_size})
    require((repair / 'precommit-controls/summary.json').is_file(), 'precommit summary missing')
    (repair / 'control-observation-manifest.json').write_text(json.dumps(selected, sort_keys=True, indent=2) + '\n')
    shutil.copyfile(WORK / 'validate-w1-binding-candidate-b34d.py', repair / 'validate-candidate.py')
    (repair / 'README.md').write_text('''# Current W1 selected-profile binding repair

The original exact-head closure job 130949243361 in run 43147686515 refused the
current mapping before selected-profile inspection. The binding retained the
former 43,170-byte mapping SHA256 `ee41a559c91b613be46a80081dd45d87130d83d95e2d068352ea03a85240c93f`.
The unchanged current mapping has 44,427 bytes and SHA256
`8e4508d132ae2103f086025b7614a19ef30bae04a7fec17f5834897fa1c83d36`.

Review found only the source checkpoint, local closure and its zero-paired note
changed: 138 to 139 local Rust paths, with no deletion. The 16 selected project
files, 15 proof obligations, lifetime register and qualification flags remain
unchanged. This repair updates the exact mapping pin and the workflow descriptor
to `0d47e23d395d6332a0bdf1c9093cf5b19816aad9841e3db6e8cb24f53e0f18b3`.
It preserves the reader, its exact byte bound and all security obligations.

Three added controls reject growth, shrinkage and equal-length substitution.
The original 26-test failure and repaired 29-test observations are separate.
Precommit observations retain their own source state; they do not qualify a
future committed candidate. The first local corpus-control observation reached
its stricter 300-second caller timeout after 36 methods reported success. That
timeout is not an assertion failure or a result under the original 600-second
budget. The later candidate must run the original budget independently.

The [control manifest](control-observation-manifest.json) binds retained raw
records, including failures. `validate-candidate.py` records a fresh committed
candidate's original source guards, provider pins, locked graphs, retained
controls, formatting and strict Clippy into a new external directory. Its
receipt is separate from the earlier measurements and is never inherited.
The [predecessor PR description](predecessor-pr935.json) retains its original
native/evidence sources, publication failures and recovery observations.

The [V5 artifact readback](../pon-w1-v5-twoarch-readback-20261112/README.md)
and [original failed service](../pon-w1-service-readback-20261112/README.md)
remain executions of source `229b14c2d366a257f51f287d502a550df2332338`.
This repair changes no Rust, formal guest, target, reward, chainwork, resource
limit or production authority. Whole-chain qualification remains HOLD.
''')
    plan = ROOT / 'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
    intro = '''**W1 current-source strategy evidence and profile repair, 2026-11-12 America/New_York — HOLD:**

The [two-architecture V5 readback](../../evidence/pon-w1-v5-twoarch-readback-20261112/README.md)
independently reproduces all 66 original shards on each of x64 and ARM64 at
`229b14c2d366a257f51f287d502a550df2332338`. It preserves both complete ZIPs,
440 file identities, all 17 arms in each of 44 cost cells per architecture and
22 controls per architecture. Eleven synthetic materials include nonzero
low-rank, full-rank, sparse diagonal and maintenance cases. Matched streams and
correlated horizons are not independent extra samples. These are existing
native executions, not executions of the later binding/evidence candidate.

Use complete paid producer costs and separate CPU/wall resource axes. At T1/H8,
batch4 has the lowest observed aggregate wall cost in all eleven materials on
both hosts, but increases CPU relative to the fixed rank8-lazy arm: ARM64
21.6302–25.0970 percent; x64 74.1873–80.6710 percent. The full fixed-arm tables
retain all comparisons; post-sample minima and cross-host differences do not
prove stable advantages or an adversarial lower bound. No earlier zero-only
timing is relabelled or used as a paired speedup baseline.

The [profile repair](../../evidence/pon-w1-profile-binding-20261112/README.md)
updates stale exact mapping/descriptor pins after adding the zero-paired
observer. It preserves the original reader and adds three substitution
negatives. Original profile failures and the stricter local 300-second corpus
timeout remain separate; the committed candidate requires its own original
600-second controls and exact-source checks.

The [failed native service readback](../../evidence/pon-w1-service-readback-20261112/README.md)
retains original/fresh pressure confirmation counts of 0/0 despite 7/7 accepted
submissions in each phase. The independent client replayed only 4/7 and 2/7
History pages before PUBLIC_REQUEST_DEADLINE. Preserve the four-second/six-depth
target, complete W1 verification and original CPU/worker limits. Full-controller
throttling counters do not establish per-request causality.

Next engineering work must close V5 pre-emission interruption accounting and
dual full replay for exhausted misses under a new schema. Actual short-column
provenance, GPU/ASIC/energy, cross-miner/epoch reuse and ownership, shared caches,
early screening, independent task demand, self-traffic/reward uniqueness and
complete maintenance economics remain distinct obligations. Uniform independent
tickets, all-algorithm minimum cost and joint DAA/chainwork security remain
unproved. No production activation or security lower bound is granted.

'''
    plan.write_text(intro + plan.read_text())
    corpus_path = ROOT / CORPUS
    corpus = json.loads(corpus_path.read_text())
    old_required, old_pins = set(corpus['required_paths']), dict(corpus['pinned_blobs'])
    added = sorted(str(p.relative_to(ROOT)) for folder in (v5, service, repair) for p in folder.rglob('*') if p.is_file())
    corpus['required_paths'] = sorted(old_required | set(added))
    changed = git('diff', '--name-only').splitlines()
    for name in set(added) | set(changed):
        if name == CORPUS:
            continue
        if name in corpus['pinned_blobs'] or name in added:
            raw = (ROOT / name).read_bytes()
            corpus['pinned_blobs'][name] = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    require(set(old_pins) <= set(corpus['pinned_blobs']) and old_required <= set(corpus['required_paths']), 'original corpus roster removed')
    corpus_path.write_text(json.dumps(corpus, sort_keys=True, indent=2) + '\n')
    record('inventory', ['/usr/bin/python3', '-B', 'scripts/refresh_distributed_source_inventory.py', '--check'])
    record('corpus-guard', ['/usr/bin/python3', '-B', 'scripts/ci/check_pq_research_integration.py'])
    record('repository', ['/usr/bin/python3', '-B', 'scripts/ci/check_repository.py'])
    record('stage', ['git', 'add', CORPUS, 'config/pon/pq-proof-profile-binding-v1.json',
         '.github/workflows/chain-hepta-closure-candidate.yml', 'scripts/ci/test_pq_proof_profile_binding.py',
         str(plan.relative_to(ROOT)), str(v5.relative_to(ROOT)), str(service.relative_to(ROOT)), str(repair.relative_to(ROOT))])
    record('staged-whitespace', ['git', 'diff', '--cached', '--check'])
    record('staged-preflight', ['bash', 'scripts/project-preflight.sh', '--staged'])
    record('commit', ['git', 'commit', '-s', '-m', 'fix(pon): bind current profile and retain paid W1 baselines'])
    require(git('rev-parse', 'HEAD^') == BASE, 'candidate parent differs')
    require(not git('status', '--porcelain'), 'candidate not clean')
    receipt = {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
               'parent': BASE, 'paths': git('diff', '--name-only', BASE, 'HEAD').splitlines(),
               'added_corpus_paths': added, 'production_activation': False, 'native_results_reassigned': False}
    (OUT / 'candidate.json').write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
