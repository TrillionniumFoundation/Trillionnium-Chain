# Current source identity maintenance at 66b7064

This preparation contains a three-file candidate patch only. It does not edit the canonical checkout or run Cargo/model/native workloads.

## Reviewed current inputs
The 20-entry SOURCE_PINS map in scripts/w1_lifetime_ledger.py has two mismatches: Cargo.lock was changed in this PR by adding getrandom 0.2.17 to the DA dependency list; store.rs already differed from the old pin at the PR base. The other 18 entries match. Only the two SHA-256 literals change.

The 15-event-path PQ source lock is review material, not a signed historical proof or immutable Git snapshot. scripts/ci/pq_lifetime_budget.py::inspect explicitly binds only declared event paths. Both budget and lock declare source revision 66b7064be597039ce871b5b12ad5568850a2dd46. Only cell/pq.rs changes its content hash: five module/export lines were added, and the old release compile_fail fence moves from line359 to364 without changing that API or example. Exact 15/20 path mappings, regular Git mode/blob checks, current-source equality and original bytes are retained.

The budget differs only at experiment.source_revision. All numerical budgets, assumptions, eight unknown event terms, four unknown shared-primitive budgets, protocol domains, caps, null actual lifetime bound and qualification=false semantics remain unchanged. No runtime checker regenerates its own lock. Generation occurred in this isolated, explicitly reviewed preparation.

## Historical W1 QROM mapping preserved
config/pon/w1-qrom-implementation-v1.json stays byte-for-byte unchanged (SHA2567761787fca9ea92c7b678186ccb302900bfabc974460b7f6793c7a0aabb6cf22). Its source_base_commit is cb114b13bf848a77634e40a08b31b30c7c758e7b. It pins w1_v2_verifier/src/main.rs to9233bytes/SHA07415e8e3bb53f3e81dd489e4ebda63368170efbe4a217ae6b0dd6cc0af14128. Both PRbase e798d712 and head66 actually contain the same11172bytes/SHA5e102fcbe4881e3d163c7a8b65364304b14d080ae64f23b0d5032daa84208aa7. Base CI job128889036817 already fails this exact input bound. Neither old proof files nor bounds/hashes are rebound by this patch.

Base closure job128889036456 already fails the old store.rs pin. Head jobs first fail Cargo.lock, hiding that second stale pin. Raw original logs are included.

## Actual original Python controls
The original source-bound test files ran in a separate copied validation tree, with /usr/bin/python3 -I -S -B. W1 lifetime:19/19; PQ lifetime:58/58. Full verbose names, exact count and single OK were checked against the original class/method roster. All copied inputs were unchanged before/after. Controls do not execute native programs; their subprocess calls are only the original Python CLIs. This is not final-head whole-suite evidence.

## Real remaining CI failure
The original fresh-service artifact13659531524 proves original service finite_target_met=false despite its native test exit0, causing CONFIRMATION_TARGET. The fresh ignored test exits101 at fresh_challenge.rs244 because the original4second/six-depth business target is unmet. It retains16workers, the original window, and no post-window success. Host preparation and release build passed; sources and binary were unchanged. This remains an actual failed qualification, not an unexecuted check, and no bound is changed.

## Integration dependencies owned by root
The current config/pon/pq-cross-branch-corpus-v1.json pins the budget/lock Git blobs and must be maintained through its reviewed current-corpus workflow. docs/security/PQ128_LIFETIME_BUDGET_V1.md current-mapping paragraph should identify this new review; its original generation record and prior PQ_COMPOSITION_SOURCE_LOCK_REVIEW_20261108.md remain historical. Those shared files are not in this patch.

The evidence archive deliberately omits the downloaded ZIP's native executable and databases, and the large service reports. Their public artifact identity, original manifest and report hashes are retained; full originals remain in the external audit directory. No credentials, private model payloads or runtime snapshots are included.
