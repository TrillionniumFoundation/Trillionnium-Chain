#!/usr/bin/env python3
"""Create only the authorized isolated B checkout and native-validation paths."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

SOURCE = Path('/home/qq/trnm-v4-e12ecc-recovery/repo')
REPO = Path('/home/qq/chain-hash-transitive-976f-20261111')
OUT = Path('/home/qq/chain-hash-transitive-976f-20261111-native-b')
BUNDLE = Path('/tmp/chain-hash-source-b-976f-9fd6ee29.bundle')
BUNDLE_SHA = 'db5efc64269d1cc15ad0681fc5185832be1db0879791aae16d279497d28a1fa5'
B = '9fd6ee29a7a663cef547040d9d42cc36a371a17e'
TREE = '7351f83fa9ac5c0e7540fa64bce06ea6f328602f'
BASE = '6ac9a79c2fb37d6102c526c354fe2d448a9f4e6d'
BRANCH = 'fix/chain-hash-transitive-20261111-976f'
PROVIDER = Path('/home/qq/trnm-v4-e12ecc-recovery/tmp/trnm-pq-provider-3.5.9.EuFYF5vc/install')
ORIGINAL_CARGO_HOME = Path('/home/qq/trnm-v4-e12ecc-recovery/cargo-home')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def capture(argv, cwd=SOURCE):
    return subprocess.check_output(argv, cwd=cwd, env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'), text=True).strip()


def main():
    if os.path.lexists(REPO) or os.path.lexists(OUT):
        raise RuntimeError('isolated destination already exists; inspect, never overwrite')
    if BUNDLE.stat().st_size != 59720 or digest(BUNDLE) != BUNDLE_SHA:
        raise RuntimeError('bundle bytes differ from root pin')
    common = Path(capture(['git', 'rev-parse', '--path-format=absolute', '--git-common-dir'])).resolve(strict=True)
    objects = (common / 'objects').resolve(strict=True)
    if not objects.is_dir() or '\n' in str(objects):
        raise RuntimeError('noncanonical common object directory')
    if capture(['git', 'cat-file', '-t', BASE]) != 'commit':
        raise RuntimeError('required base unavailable')
    OUT.mkdir(mode=0o700)
    (OUT / 'records').mkdir()
    (OUT / 'setup').mkdir()
    (OUT / 'target').mkdir()
    (OUT / 'cargo-home').mkdir()
    details = {'started_utc': datetime.now(timezone.utc).isoformat(), 'candidate': B, 'tree': TREE,
               'base': BASE, 'original_repository_read_only': str(SOURCE), 'alternate_objects': str(objects),
               'checkout': str(REPO), 'output': str(OUT), 'commands': [], 'status': 'running'}
    (OUT / 'setup-summary.json').write_text(json.dumps(details, indent=2) + '\n')

    def run(label, argv, cwd=SOURCE, env=None):
        log = OUT / 'setup' / (label + '.log')
        with log.open('xb') as stream:
            code = subprocess.run(argv, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT).returncode
        details['commands'].append({'label': label, 'argv': argv, 'cwd': str(cwd), 'exit_code': code,
                                    'log': str(log), 'bytes': log.stat().st_size, 'sha256': digest(log)})
        (OUT / 'setup-summary.json').write_text(json.dumps(details, indent=2) + '\n')
        print(json.dumps({'setup': label, 'exit_code': code}), flush=True)
        if code != 0:
            raise RuntimeError('setup command failed: ' + label)

    try:
        run('git-init', ['git', 'init', '--quiet', '--object-format=sha1', '--template=', '--initial-branch=' + BRANCH, str(REPO)])
        (REPO / '.git/objects/info/alternates').write_text(str(objects) + '\n')
        run('origin', ['git', 'remote', 'add', 'origin', 'https://github.com/TrillionniumFoundation/Trillionnium-Chain.git'], REPO)
        run('bundle-verify', ['git', 'bundle', 'verify', str(BUNDLE)], REPO)
        run('bundle-unbundle', ['git', 'bundle', 'unbundle', str(BUNDLE)], REPO)
        run('checkout-b', ['git', 'reset', '--hard', B], REPO)
        if capture(['git', 'rev-parse', 'HEAD'], REPO) != B or capture(['git', 'rev-parse', 'HEAD^{tree}'], REPO) != TREE:
            raise RuntimeError('checkout commit/tree mismatch')
        run('preflight', ['bash', 'scripts/project-preflight.sh'], REPO)
        run('source-before', [sys.executable, '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', B,
                              '--output', str(OUT / 'source-before.json')], REPO,
            dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        print('CMH2_B_CHECKOUT_READY ' + str(REPO), flush=True)
        # Copy only dependency caches into the new task-owned Cargo home. No
        # source worktree, original target, global setting or cache is mutated.
        if (ORIGINAL_CARGO_HOME / 'registry').is_dir():
            run('copy-cargo-registry', ['cp', '-a', '--reflink=auto', str(ORIGINAL_CARGO_HOME / 'registry'), str(OUT / 'cargo-home/registry')])
        if (ORIGINAL_CARGO_HOME / 'git').is_dir():
            run('copy-cargo-git-cache', ['cp', '-a', '--reflink=auto', str(ORIGINAL_CARGO_HOME / 'git'), str(OUT / 'cargo-home/git')])
        provider_values = {}
        allowed = {'OPENSSL_DIR', 'OPENSSL_STATIC', 'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256',
                   'TRNM_PQ_OPENSSL_VERSION', 'OPENSSL_CONF', 'OPENSSL_MODULES'}
        for line in Path('/home/qq/trnm-v4-e12ecc-recovery/provider.env').read_text().splitlines():
            if '=' in line:
                key, value = line.split('=', 1)
                if key in allowed:
                    provider_values[key] = value
        if set(provider_values) != allowed or provider_values['OPENSSL_DIR'] != str(PROVIDER):
            raise RuntimeError('unexpected provider environment')
        if provider_values['TRNM_PQ_OPENSSL_VERSION'] != '3.5.9' or provider_values['OPENSSL_STATIC'] != '1':
            raise RuntimeError('provider version/static contract')
        if provider_values['TRNM_PQ_OPENSSL'] != str(PROVIDER / 'bin/openssl'):
            raise RuntimeError('provider executable path')
        identities = []
        for name in ['bin/openssl', 'lib/libcrypto.a', 'lib/libssl.a', 'include/openssl/opensslv.h']:
            path = PROVIDER / name
            identities.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)})
        if identities[0]['sha256'] != provider_values['TRNM_PQ_OPENSSL_SHA256']:
            raise RuntimeError('provider executable changed from its existing pin')
        environment = dict(provider_values, CARGO_HOME=str(OUT / 'cargo-home'), CARGO_TARGET_DIR=str(OUT / 'target'),
                           CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', RUST_TEST_THREADS='1', RUSTUP_TOOLCHAIN='1.95.0',
                           PYTHONDONTWRITEBYTECODE='1', PATH='/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:/home/qq/.cargo/bin:/usr/local/bin:/usr/bin:/bin')
        (OUT / 'environment.json').write_text(json.dumps(environment, indent=2, sort_keys=True) + '\n')
        (OUT / 'provider-identities.json').write_text(json.dumps(identities, indent=2, sort_keys=True) + '\n')
        child_env = dict(os.environ, **environment)
        for key in list(child_env):
            if key in {'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'} or key.startswith('CARGO_PROFILE_'):
                child_env.pop(key)
        run('rust-195', ['rustc', '--version', '--verbose'], REPO, child_env)
        run('cargo-195', ['cargo', '--version'], REPO, child_env)
        run('openssl-359', [str(PROVIDER / 'bin/openssl'), 'version', '-a'], REPO, child_env)
        details['status'] = 'ready'
        details['provider_identities'] = identities
        details['environment_file'] = str(OUT / 'environment.json')
        print('CMH2_NATIVE_B_READY ' + str(OUT), flush=True)
    except Exception as error:
        details.update(status='failed', error=str(error))
        raise
    finally:
        details['finished_utc'] = datetime.now(timezone.utc).isoformat()
        (OUT / 'setup-summary.json').write_text(json.dumps(details, indent=2) + '\n')


if __name__ == '__main__':
    main()
