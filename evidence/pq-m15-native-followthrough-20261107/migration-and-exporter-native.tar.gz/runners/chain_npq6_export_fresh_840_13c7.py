#!/usr/bin/env python3
"""One fresh export from the sealed840 harness; synchronous paired-job preparation."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

WORK = Path('/home/alex/work')
SOURCE = WORK / 'chain-npq6-export-13c7-v3'
BUILD = WORK / 'chain-npq6-export-13c7-evidence-v3'
SUPPORT = WORK / 'chain-m15-regression-1c14fab4-13c7-runner-v2.py'
COMMIT = '840522d0b65b4989f1a2a1d09c0ad51af1a1956d'
TREE = '70377cc0a9c8d029907f6c49bbb8dee1435a6cd1'
SELECTOR = 'export::export_ordinary_npq6_task_and_evaluator_control_material'
PINS = {
    SUPPORT: '750a23f7665477885627a80399b26bb7e887d2f4cf814e7230314123daa18def',
    BUILD / 'manifest.json': '51e8f83d871b677b4ce67df46a360804d90f57e9ed5018097f7f047e53264d30',
    BUILD / 'artifact-binding.json': 'daa42667b9ceb5462740d33ca1144965427b76083c1df236353c0f801def6cc9',
    BUILD / 'pq_application_local_cli-harness': '348694830230c0e300316e33e74be73a8e1e40e3c2022bf5e8aa84b973965e49',
    WORK / 'chain-npq6-provider-bound-13c7/node-npq6': '4816721ef2ea829f904b6622443e14937fbd679df3ea777b99065f37c492b86f',
    WORK / 'chain-npq6-provider-bound-13c7/node-feature-off': '1e2a7b806318470cc37d389d6eb8ec41311aab43cdee2f17535aeaed6704aa68',
    WORK / 'chain-npq6-retained-cli-loader-13c7/manifest.json': '44769e78ddad45852ac99ad5d922673707b8b1ce5a37ab5084d987d652c51350',
}


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def fresh_path(raw):
    path = Path(raw)
    if not path.is_absolute() or not path.is_relative_to(WORK) or path.exists():
        raise ValueError('fresh output must be an absent absolute path beneath /home/alex/work')
    if path.parent.resolve(strict=True) != path.parent or path.name in ('', '.', '..'):
        raise ValueError('fresh output parent must already exist without path aliases')
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixture', required=True)
    parser.add_argument('--evidence', required=True)
    args = parser.parse_args()
    fixture, output = fresh_path(args.fixture), fresh_path(args.evidence)
    if fixture == output or fixture.is_relative_to(output) or output.is_relative_to(fixture):
        raise ValueError('material and evidence outputs must be disjoint')
    if hashlib.sha256(SUPPORT.read_bytes()).hexdigest() != PINS[SUPPORT]:
        raise ValueError('fixed identity helper changed')
    m = module('fixed_native_support', SUPPORT)
    output.mkdir(mode=0o700)
    manifest = dict(schema='chain-exact840-fresh-npq6-material-execution-v1', result='RUNNING',
                    commit=COMMIT, tree=TREE, fixture=str(fixture), commands=[],
                    started_utc=datetime.now(timezone.utc).isoformat(), runner_sha256=m.sha(__file__),
                    original_signature_expiry_seconds=300, expiry_changed=False,
                    automatic_retry_added=False, material_preparation_only=True,
                    paired_consumer_executed=False, production_activation=False,
                    whole_chain_quantum_security_qualified=False)

    def save():
        (output / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')

    save()
    verifier = env = None
    code = 1
    try:
        inputs = [m.file_identity(path) for path in PINS]
        m.require(all(row['sha256'] == PINS[Path(row['path'])] for row in inputs), 'bound exporter/CLI input changed')
        manifest['inputs_before'] = inputs
        build = json.loads((BUILD / 'manifest.json').read_text())
        m.require(build['result'] == 'PASS' and build['commit'] == COMMIT and build['tree'] == TREE,
                  'wrong exporter build receipt')
        binding = json.loads((BUILD / 'artifact-binding.json').read_text())
        harness = Path(binding['retained']['path'])
        m.require(harness == BUILD / 'pq_application_local_cli-harness'
                  and m.file_identity(harness) == binding['retained'], 'retained exporter identity changed')
        verifier = module('verify_ci_source', SOURCE / 'scripts/ci/verify_ci_source.py')
        manifest['source_before'] = verifier.verify('head', COMMIT, root=SOURCE)
        m.require(manifest['source_before']['tested_tree'] == TREE, 'wrong exporter source tree')
        m.SOURCE = SOURCE
        env, manifest['provider_inputs_before'] = m.prepared_environment()
        env.update(CARGO_TARGET_DIR=str(WORK / 'chain-npq6-export-13c7-target-v3'),
                   HEPTA_PON_CHAIN_SOURCE=COMMIT, HEPTA_PON_NPQ6_FIXTURE_OUT=str(fixture))
        manifest['environment'] = {key: env.get(key) for key in [
            'RUST_TEST_THREADS', 'OPENSSL_DIR', 'OPENSSL_STATIC', 'TRNM_PQ_OPENSSL',
            'TRNM_PQ_OPENSSL_SHA256', 'TRNM_PQ_OPENSSL_VERSION', 'OPENSSL_CONF', 'OPENSSL_MODULES',
            'HEPTA_PON_CHAIN_SOURCE', 'HEPTA_PON_NPQ6_FIXTURE_OUT']}
        save()

        def run(label, argv):
            command = ['python3', 'scripts/ci/record_pq_native_command.py', '--kind', 'head',
                       '--candidate', COMMIT, '--tested', COMMIT, '--label', label,
                       '--output', str(output), '--'] + argv
            print(json.dumps(dict(event='start', label=label, argv=argv)), flush=True)
            status = subprocess.run(command, cwd=SOURCE, env=env, check=False).returncode
            manifest['commands'].append(dict(label=label, exit_code=status))
            save()
            m.require(status == 0, label + ' failed: ' + str(status))

        manifest['export_wall_started_seconds'] = time.time()
        run('fresh-export', [str(harness), SELECTOR, '--ignored', '--exact', '--nocapture', '--test-threads=1'])
        manifest['export_wall_finished_seconds'] = time.time()
        run('fresh-export-execution', ['python3', 'scripts/ci/check_required_native_test.py',
                                      str(output / 'fresh-export.log'), '--test', SELECTOR])
        material = json.loads((fixture / 'manifest.json').read_text())
        m.require(material['schema'] == 'ordinary-pon-npq6-paired-material-v1'
                  and material['chain_source'] == COMMIT
                  and material['application_profile'] == 'pon-native-pq-application-v6'
                  and material['public_test_material'] is True and material['target_admitted'] is False
                  and material['production_activation'] is False, 'wrong exported material scope')
        m.require(m.sha(fixture / 'application.json') == material['configuration_sha256'], 'exported config hash differs')
        names = [row['name'] for row in material['cases']]
        m.require(names == ['task', 'evaluator', 'owner-mismatch', 'provider-loader'], 'exported case set differs')
        for row in material['cases']:
            packet = fixture / row['name'] / 'packet.bin'
            m.require(m.sha(packet) == row['packet_sha256'], 'exported packet hash differs')
            with packet.open('rb') as stream:
                m.require(stream.read(4) == b'PQP6', 'exported packet is not the full NPQ6 wire packet')
            m.require(row['expected_success'] == (row['name'] != 'owner-mismatch'), 'exported owner control differs')
        manifest['material_files_before_consumer'] = [m.file_identity(path) for path in sorted(fixture.rglob('*')) if path.is_file()]
        manifest['material_manifest_sha256'] = m.sha(fixture / 'manifest.json')
        consumer = dict(HEPTA_PON_CHAIN_SOURCE=COMMIT, HEPTA_PON_CHAIN_TREE=TREE,
                        HEPTA_PON_CHAIN_BINARY=str(WORK / 'chain-npq6-provider-bound-13c7/node-npq6'),
                        HEPTA_PON_CHAIN_SHA256=PINS[WORK / 'chain-npq6-provider-bound-13c7/node-npq6'],
                        HEPTA_PON_NPQ6_FIXTURE_OUT=str(fixture),
                        HEPTA_PON_NPQ6_MANIFEST_SHA256=manifest['material_manifest_sha256'],
                        HEPTA_PON_NPQ6_UNSUPPORTED_BINARY=str(WORK / 'chain-npq6-provider-bound-13c7/node-feature-off'),
                        HEPTA_PON_NPQ6_UNSUPPORTED_SHA256=PINS[WORK / 'chain-npq6-provider-bound-13c7/node-feature-off'])
        m.write_json(output / 'consumer-environment.json', consumer)
        manifest['consumer_environment'] = m.file_identity(output / 'consumer-environment.json')
        code = 0
    except Exception as error:
        manifest['error'] = str(error)
        print(json.dumps(dict(event='failed', error=str(error))), flush=True)
    finally:
        try:
            manifest['inputs_after'] = [m.file_identity(path) for path in PINS]
            m.require(manifest['inputs_before'] == manifest['inputs_after'], 'bound inputs changed during export')
            if verifier is not None:
                manifest['source_after'] = verifier.verify('head', COMMIT, root=SOURCE)
                m.require(manifest['source_before'] == manifest['source_after'], 'exporter source changed')
            if env is not None:
                _, manifest['provider_inputs_after'] = m.prepared_environment()
                m.require(manifest['provider_inputs_before'] == manifest['provider_inputs_after'], 'provider changed')
        except Exception as error:
            manifest['final_identity_error'] = str(error)
            code = 1
        manifest.update(result='PASS' if code == 0 else 'FAIL', exit_code=code,
                        finished_utc=datetime.now(timezone.utc).isoformat())
        save()
    print(json.dumps(dict(result=manifest['result'], output=str(output), material_preparation_only=True)), flush=True)
    return code


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    raise SystemExit(main())
