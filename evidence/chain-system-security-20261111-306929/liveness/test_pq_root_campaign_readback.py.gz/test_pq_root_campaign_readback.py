"""Small synthetic negative controls for the original campaign ZIP reader.

Not an independent external operation, security proof or performance test.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import io
import json
import unittest
import zipfile

import pq_root_campaign_readback as reader

TX = 'tx-constant-fixture-not-production-effect'


def synthetic():
    result = {
        'original_inputs': deepcopy(reader.EXPECTED_INPUTS),
        'public_phase_placement': {
            'receiver_and_verifier_cpu_max': '25000 100000',
            'receiver_and_verifier_memory_max': '2147483648',
            'fixed_parent': reader.FIXED_PARENT,
            'original_3x3_workload_and_depletion_predicates_changed': False,
        },
        'attempts': [{'number': i, 'original_criteria_met': False,
                      'complete_success': False, 'step': {'returncode': 101}}
                     for i in (1, 2, 3)],
    }
    host = {'limits': deepcopy(reader.FIXED_LIMITS),
            'parent_path': reader.FIXED_PARENT,
            'parent': {'canonical_path': reader.FIXED_PARENT, 'uid': 0,
                       'directory': True, 'symlink': False}, 'read_errors': {}}
    def phase(mode, attackers):
        c = {'round': 0, 'confirmed_inside_pressure_window': mode == 'baseline',
             'ended_ns': 28_000_000_000, 'transaction': TX,
             'included_block': 'block-fixture',
             'observation': {'confirmed': mode == 'baseline', 'transaction': TX,
                             'finalized': False, 'execution_authority': False}}
        return {'mode': mode, 'duration_seconds': 30,
                'attacker_processes_requested': attackers,
                'finite_phase_criteria_met': False, 'receiver_client_state_equal': False,
                'genuine_budget_depletion_observed': False,
                'confirmations': [c], 'history': [{
                    'status': 'ok', 'response': {'ok': True},
                    'client_import': {'succeeded': True},
                }]}
    reports = [{'phases': [phase(mode, count) for mode, count in
                           zip(reader.EXPECTED_INPUTS['modes'], [0, 24, 24])]}
               for _ in range(3)]
    return result, reports, [deepcopy(host) for _ in range(9)]


class EvidenceReaderTests(unittest.TestCase):
    def assert_refused(self, data, label):
        with self.assertRaises(reader.EvidenceError, msg=label):
            reader.summarize(*data)

    def test_three_repeated_confirmations_are_one_fixture_identity_not_paid_effects(self):
        report = reader.summarize(*synthetic())
        self.assertEqual(report['window_confirmations'], 3)
        self.assertEqual(report['distinct_fixture_transactions'], 1)
        self.assertEqual(report['complete_original_campaigns'], 0)
        self.assertFalse(report['all_observed_window_confirmations_have_finality'])
        self.assertFalse(report['all_observed_window_confirmations_have_execution_authority'])
        self.assertIsNone(report['actual_lifetime_failure_bound'])
        self.assertEqual(report['status'], 'HOLD_NO_GO')

    def test_tampered_workload_is_refused(self):
        data = synthetic(); data[0]['original_inputs']['phase_seconds'] = 31
        self.assert_refused(data, 'must keep 30s')

    def test_tampered_attacker_denominator_is_refused(self):
        data = synthetic(); data[1][0]['phases'][1]['attacker_processes_requested'] = 0
        self.assert_refused(data, 'must keep 24 hostile')

    def test_tampered_cpu_and_memory_are_refused(self):
        for key, value in [('cpu.max', '50000 100000'), ('memory.max', '4294967296')]:
            data = synthetic(); data[2][0]['limits'][key] = value
            self.assert_refused(data, key)

    def test_untrusted_parent_is_refused(self):
        data = synthetic(); data[2][4]['parent']['uid'] = 1000
        self.assert_refused(data, 'root-owned parent')

    def test_missing_one_original_campaign_is_refused(self):
        data = synthetic(); data[0]['attempts'].pop()
        self.assert_refused(data, 'three campaigns')

    def test_false_in_window_confirmation_is_refused(self):
        data = synthetic()
        data[1][0]['phases'][0]['confirmations'][0]['observation']['confirmed'] = False
        self.assert_refused(data, 'forged confirmation')

    def test_late_confirmation_cannot_be_relabelled_in_window(self):
        data = synthetic()
        data[1][0]['phases'][0]['confirmations'][0]['ended_ns'] = 30_000_000_001
        self.assert_refused(data, 'deadline')

    def test_import_success_without_rpc_is_refused(self):
        data = synthetic()
        data[1][0]['phases'][0]['history'][0]['status'] = 'timeout'
        self.assert_refused(data, 'rpc vs native import')

    def test_forged_phase_success_without_three_confirmations_is_refused(self):
        data = synthetic()
        data[1][0]['phases'][0]['finite_phase_criteria_met'] = True
        self.assert_refused(data, 'forged phase success')

    def test_forged_campaign_success_without_three_phases_is_refused(self):
        data = synthetic()
        data[0]['attempts'][0]['complete_success'] = True
        data[0]['attempts'][0]['original_criteria_met'] = True
        data[0]['attempts'][0]['step']['returncode'] = 0
        self.assert_refused(data, 'forged campaign success')

    def test_zip_manifest_integrity_and_mutated_member(self):
        def make_archive(manifest_digest=None, path='body.txt'):
            raw = b'test payload'
            m = {'files': [{'path': path, 'bytes': len(raw),
                            'sha256': manifest_digest or hashlib.sha256(raw).hexdigest()}]}
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
                z.writestr(path, raw)
                z.writestr('artifact-files.json', json.dumps(m))
            buf.seek(0)
            return buf
        with zipfile.ZipFile(make_archive()) as z:
            self.assertEqual(reader.verify_zip(z)['manifest_payload_entries'], 1)
        with zipfile.ZipFile(make_archive(manifest_digest='0' * 64)) as z:
            with self.assertRaises(reader.EvidenceError): reader.verify_zip(z)
        with zipfile.ZipFile(make_archive(path='../escape.txt')) as z:
            with self.assertRaises(reader.EvidenceError): reader.verify_zip(z)

    def test_zip_member_not_listed_in_manifest_is_refused(self):
        m = {'files': [{'path': 'a.txt', 'bytes': 1,
                        'sha256': hashlib.sha256(b'a').hexdigest()}]}
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as z:
            z.writestr('a.txt', b'a')
            z.writestr('extra.txt', b'x')
            z.writestr('artifact-files.json', json.dumps(m))
        buf.seek(0)
        with zipfile.ZipFile(buf) as z:
            with self.assertRaises(reader.EvidenceError): reader.verify_zip(z)


if __name__ == '__main__':
    unittest.main()

