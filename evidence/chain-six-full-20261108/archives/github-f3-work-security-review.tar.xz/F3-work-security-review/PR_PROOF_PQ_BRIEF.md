### Proof integration and PQ scope

The proof-to-Node research CLI now requires an explicit, policy-bound durable proof-start owner. Independent processes and cold reopen share a fixed nonrefundable quota; interrupted reservations remain spent. This is local accounting under protected directory/ancestor assumptions, without backup-rollback protection or a complete lifetime quantum budget.

On frozen F3 commit `1a446a79700cc093a2b1a7f10367ef4a5ddbd680`, all 22 native adapter controls, strict release Clippy, and five exercise/four cold-reopen CLI cases passed. The CLI consumed one nine-slot owner and actually verified retained complete STARK inputs through native admission and recovery. No new complete proof was generated. All 24,851 tracked files matched Git before and after.

The original 25-gate MMCS campaign completed with 178 Python and 79 Rust controls. Its original unchanged-runtime guard still exited 1; the full diff and `original_unchanged_runtime_scope_passed=false` are retained. Five cryptographic source pins and seven dependency-source checks remain intact. The result is `COMPOSITION_OBSERVATION_COMPLETE_HOLD`.

PQ source-lock updates retain all unknown budgets, null complete bounds and false activation claims. The additive current-source observer preserves the two original QROM scope refusals. The candidate CI reader repair preserves the historical version-2 API and 23 controls, explicitly selects current stage version 3, and adds ten cancellation/deadline/version controls. It validated all 58 records from the actual F3 artifact without new cryptographic execution.

Original failures remain visible: both historical QROM lanes reject changed scope; the old candidate reader rejects the current schema; F3 fresh-service observations fail the original four-second/six-depth business target. Complete CI success, full quantum reliability, equal-resource net benefit, independent public-network confirmation and production activation remain unqualified.
