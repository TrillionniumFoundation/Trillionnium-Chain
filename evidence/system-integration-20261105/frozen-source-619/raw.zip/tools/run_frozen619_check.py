#!/usr/bin/env python3
"""Record an original Python gate on the exact clean frozen Chain commit."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/baeed38792e5/chain')
OUT = Path('/workspace/scratch/baeed38792e5/liveness-work/frozen-619-materialization-20261105')
EXPECTED_HEAD = '619c5f80856fb15bb6896d8008df91f58c215229'
EXPECTED_TREE = '501607a6f76d4e5fc4e31a79bfdbff00c4bb007f'
name, *argv = sys.argv[1:]
assert re.fullmatch(r'[a-z0-9-]+', name) and argv
assert not (OUT / (name + '.json')).exists()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0',
           GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(ROOT), *args], env=env)


def source():
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'index_entries_sha256': hashlib.sha256(git('ls-files', '--stage', '-z')).hexdigest(),
            'status': git('status', '--porcelain', '--untracked-files=all', '--ignore-submodules=none').decode()}


before = source()
assert before['head'] == EXPECTED_HEAD and before['tree'] == EXPECTED_TREE
assert not before['status']
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic_ns()
log = OUT / (name + '.log')
with log.open('wb') as stream:
    result = subprocess.run(argv, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
elapsed = time.monotonic_ns() - start
after = source()
output = log.read_text(errors='replace')
receipt = {
    'schema': 'chain-frozen-python-gate-v1', 'command_name': name,
    'argv': argv, 'cwd': str(ROOT), 'started_utc': started,
    'elapsed_ns': elapsed, 'exit_code': result.returncode,
    'tested_commit': EXPECTED_HEAD, 'tested_tree': EXPECTED_TREE,
    'source_before': before, 'source_after': after,
    'source_fence_stable': before == after,
    'log_file': log.name, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
    'source_kind': 'committed-clean-head', 'cargo_executed': False,
    'production_or_business_acceptance_granted': False,
}
match = re.search(r'Ran (\d+) tests? in ([0-9.]+)s', output)
if match:
    receipt['unittest_count'] = int(match[1])
    receipt['unittest_reported_seconds'] = float(match[2])
    receipt['unittest_ok'] = re.search(r'^OK(?: \([^\n]*\))?$', output, re.M) is not None
    skipped = re.search(r'skipped=(\d+)', output)
    receipt['unittest_skipped'] = int(skipped[1]) if skipped else 0
if name in ('clean-source', 'complete-source-checker', 'repository-check') and result.returncode == 0:
    receipt['gate_result'] = json.loads(output)
(OUT / (name + '.json')).write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps(receipt, indent=2, sort_keys=True))
print(output[-1500:])
assert receipt['source_fence_stable'], 'source changed during original command'
raise SystemExit(result.returncode)
