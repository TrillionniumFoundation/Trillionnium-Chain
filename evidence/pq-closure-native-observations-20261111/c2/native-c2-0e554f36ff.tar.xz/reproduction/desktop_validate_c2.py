#!/usr/bin/env python3
"""Exact C2 embedded-corpus recheck, after C1 original and subset are closed."""
from __future__ import annotations
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import stat

C1 = 'c09dbbe9921da12db8bf7240a8a95a0e9a789e50'
C2 = '0e554f36ffdde3053a5eb1756eb5e526b1935032'
TREE = '753cdbad6714f00d8ccb9ddbb47f0fd71280ee62'
BASE = Path('/home/qian-qi/work')
RUNNER = BASE / 'chain-pq-closure-20261111-d4d2-validate-c09dbbe9921d-data.py'
RUNNER_SHA = 'e5a378b43130e888d58b021ed58dc28f4c560c1075d8e08b7db79313765bc45e'
ORIGINAL = BASE / 'chain-pq-closure-20261111-d4d2-validation-c09dbbe9921d-01'
SUBSET = Path('/data/chain-pq-closure-20261111-d4d2-readback-subset-c09dbbe9921d-01')
V5_SUBSET = Path('/data/chain-pq-closure-20261111-d4d2-witness-v5-subset-c09dbbe9921d-01')
TARGET = Path('/data/chain-pq-closure-20261111-d4d2-cargo-target-c09dbbe9921d-01')
OUT = Path('/data/chain-pq-closure-20261111-d4d2-validation-0e554f36ffdd-01')
NAMES = (
    'preflight', 'rustc-version', 'cargo-version', 'openssl-version',
    'metadata-default', 'metadata-all-features', 'metadata-fuzz', 'fmt',
    'node-account-scope', 'node-all-pq-profile-settlement',
    'tls-full-spki-1', 'tls-full-spki-2', 'tls-full-spki-3',
    'strict-workspace-clippy',
)


def read_json(path):
    return json.loads(path.read_text())


def main():
    assert hashlib.sha256(RUNNER.read_bytes()).hexdigest() == RUNNER_SHA
    spec = importlib.util.spec_from_file_location('frozen_c1_runner', RUNNER)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    original = read_json(ORIGINAL / 'summary.json')
    subset = read_json(SUBSET / 'summary.json')
    v5_subset = read_json(V5_SUBSET / 'summary.json')
    original_plan = read_json(ORIGINAL / 'plan.json')
    m.require(original['source'] == C1 and original['complete']
              and len(original['commands']) == 27
              and original['source_unchanged'] and original['provider_unchanged'],
              'all original C1 commands and final source/provider checks must close first')
    m.require(subset['source'] == C1 and subset['source_unchanged']
              and subset['provider_unchanged'] and subset['original_group_failed']
              and not subset['aggregate_budget_qualified'],
              'C1 subset must be closed without promoting the original failed group')
    m.require(v5_subset['source'] == C1 and v5_subset['source_unchanged']
              and v5_subset['provider_unchanged'] and v5_subset['original_group_failed']
              and not v5_subset['aggregate_budget_qualified'],
              'C1 witness V5 subset must close before C2 source changes')
    identity = m.identity(C2)
    m.require(identity['tree'] == TREE, 'unexpected C2 source tree')
    m.require(OUT.parent == Path('/data') and OUT.resolve() == OUT and not OUT.exists(),
              'fresh owned C2 output required')
    target_info = TARGET.lstat()
    m.require(TARGET.resolve() == TARGET and stat.S_ISDIR(target_info.st_mode)
              and target_info.st_uid == os.getuid() and stat.S_IMODE(target_info.st_mode) == 0o700
              and original_plan['target_directory'] == str(TARGET),
              'C2 may reuse only this task original private Cargo target')
    m.require(min(shutil.disk_usage(m.REPO).free, shutil.disk_usage(TARGET).free) >= m.LOW_WATER,
              'source or target volume below 10 GiB')
    env = dict(os.environ)
    forbidden = [k for k in env if k.startswith('CARGO_PROFILE_') or k in
                 ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER',
                  'GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY',
                  'GIT_ALTERNATE_OBJECT_DIRECTORIES')]
    m.require(not any(env[k] for k in forbidden), 'inherited build/Git override refused')
    for key, value in original_plan['environment'].items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    env.pop('OPENSSL_LIBS', None)
    env['GIT_NO_REPLACE_OBJECTS'] = '1'
    m.require(env['CARGO_TARGET_DIR'] == str(TARGET), 'C2 target differs')
    selected = {name: (name, argv, timeout, expected)
                for name, argv, timeout, expected in m.command_plan() if name in NAMES}
    plan = [selected[name] for name in NAMES]
    m.require(len(plan) == 14 and sum(len(row[3] or []) for row in plan) == 8,
              'C2 selected command/test roster differs')
    OUT.mkdir(mode=0o700)
    rows, fatal, stopped = [], None, None
    source_before = source_after = provider_before = provider_after = None
    began = m.now()
    try:
        source_before = m.source_snapshot(C2, OUT / 'source-before.json')
        provider_before = m.provider_snapshot(OUT / 'provider-before.json')
        m.require(provider_before == read_json(SUBSET / 'provider-after.json')
                  == read_json(V5_SUBSET / 'provider-after.json'),
                  'provider changed after the C1 subsets')
        m.write_json(OUT / 'plan.json', {
            'schema': 'trnm-c2-native-recheck-plan-v1', 'commit': C2, 'tree': TREE,
            'runner': m.file_hash(Path(__file__)), 'original_runner': m.file_hash(RUNNER),
            'scope': 'eight Node library cases affected by embedded corpus plus strict Clippy',
            'target_directory': str(TARGET), 'target_reused_from_closed_C1_group': True,
            'source_directory': str(m.REPO), 'output_directory': str(OUT),
            'original_C1_summary': m.file_hash(ORIGINAL / 'summary.json'),
            'C1_subset_summary': m.file_hash(SUBSET / 'summary.json'),
            'C1_witness_v5_subset_summary': m.file_hash(V5_SUBSET / 'summary.json'),
            'environment': {key: env.get(key) for key in m.ENV_KEYS},
            'commands': [dict(name=n, argv=a, timeout_seconds=t, expected_tests=e)
                         for n, a, t, e in plan],
            'C1_original_failures_retained': True,
            'whole_chain_quantum_security_qualified': False,
        })
        for name, argv, timeout, expected in plan:
            if min(shutil.disk_usage(m.REPO).free, shutil.disk_usage(TARGET).free) < m.LOW_WATER:
                stopped = 'source or target volume below 10 GiB; later commands not started'
                break
            row, interrupted = m.run_command(name, argv, timeout, expected, env, OUT, C2)
            rows.append(row)
            if interrupted or 'source_error' in row:
                stopped = 'interrupted or C2 source identity changed'
                break
            if (name == 'preflight' or name.endswith('-version') or name.startswith('metadata-')) and not row['passed']:
                stopped = 'project/toolchain/locked metadata gate refused'
                break
    except BaseException as error:
        fatal = {'type': type(error).__name__, 'message': str(error)}
    finally:
        for name, function in (('source-after', lambda: m.source_snapshot(C2, OUT / 'source-after.json')),
                               ('provider-after', lambda: m.provider_snapshot(OUT / 'provider-after.json'))):
            try:
                value = function()
                if name == 'source-after':
                    source_after = value
                else:
                    provider_after = value
            except BaseException as error:
                m.write_json(OUT / (name + '-error.json'),
                             {'type': type(error).__name__, 'message': str(error)})
    source_equal = source_before is not None and source_before == source_after
    provider_equal = provider_before is not None and provider_before == provider_after
    complete = len(rows) == len(plan)
    summary = {'schema': 'trnm-c2-native-recheck-v1', 'source': C2, 'tree': TREE,
               'started_utc': began, 'finished_utc': m.now(), 'commands': rows,
               'complete': complete, 'source_unchanged': source_equal,
               'provider_unchanged': provider_equal, 'fatal': fatal, 'stopped_reason': stopped,
               'not_started': [name for name, _, _, _ in plan[len(rows):]],
               'all_selected_commands_passed': complete and all(row['passed'] for row in rows)
                    and source_equal and provider_equal and fatal is None,
               'C1_original_failures_retained': True, 'whole_chain_quantum_security_qualified': False,
               'production_activation': False, 'native_run_is_not_hosted_ci': True}
    m.write_json(OUT / 'summary.json', summary)
    print(json.dumps({key: value for key, value in summary.items() if key != 'commands'}), flush=True)
    return 0 if summary['all_selected_commands_passed'] else 1


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
    raise SystemExit(main())
