from pathlib import Path
from urllib.parse import unquote,urlsplit
import json,subprocess,re,sys,time,resource,hashlib,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'source-link-input-restore-27';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);(out/'preparation-errors.json').write_text(json.dumps([{'stage':'controller JavaScript compilation before any native tool invocation','error':'SyntaxError: Unexpected string','cause':'Markdown fence literal in JavaScript raw template','native_process_started':False,'native_cost':None}])+'\n');head='e8b0ec93ab6a6a1ff5e36cfcf9d1179e030a5975';res={'schema':'chain-original-git-markdown-link-input-restore-v1','head':head,'restored':[],'waves':[],'complete':False};start=time.monotonic();c0=resource.getrusage(resource.RUSAGE_CHILDREN)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()==head
 rawdiff=subprocess.check_output(['git','diff','HEAD'],cwd=src);original=(src.parent/'joint-source-lock-18/source.patch').read_bytes();assert sha(original)=='3bab32ed102d5a0eee58c01b8a0fb692033f4f696d568036fd0ce359dbe8eca2'
 old_lines=original.splitlines(keepends=True);new_lines=rawdiff.splitlines(keepends=True);assert len(old_lines)==len(new_lines);extensions=[]
 for old_line,new_line in zip(old_lines,new_lines):
  if old_line==new_line:continue
  a=re.fullmatch(rb'index ([0-9a-f]+)\.\.([0-9a-f]+)( [0-7]+)?\n',old_line);b=re.fullmatch(rb'index ([0-9a-f]+)\.\.([0-9a-f]+)( [0-7]+)?\n',new_line);assert a and b and b[1].startswith(a[1]) and b[2].startswith(a[2]) and a[3]==b[3];extensions.append({'old':old_line.decode().strip(),'new':new_line.decode().strip()})
 diff=subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src);res['unchanged_working_diff_sha256']=sha(diff);res['git_abbreviation_only_changes']=extensions;res['original_patch_sha256']=sha(original);res['raw_diff_sha256']=sha(rawdiff);(out/'frozen-full-index.patch').write_bytes(diff);res['predecessor']={'path':'source-link-input-restore-20','exit_code':-2,'reason':'operator interrupted own slow serial Git fetch after discovering second wave of 2067 missing inputs','aggregate_child_cpu_unknown':True};res['fetches']=[]
 with (out/'preflight.log').open('xb') as f:assert subprocess.call(['bash','scripts/project-preflight.sh'],cwd=src,stdout=f,stderr=subprocess.STDOUT)==0
 entries=subprocess.check_output(['git','ls-tree','-rz',head],cwd=src).split(b'\0');tracked={}
 for entry in entries:
  if entry:
   meta,path=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();tracked[path.decode()]={'mode':mode,'kind':kind,'oid':oid}
 for wave in range(40):
  missing={}
  for path in src.rglob('*.md'):
   if any(x in {'.git','target','__pycache__','.pytest_cache','node_modules'} for x in path.relative_to(src).parts):continue
   assert not path.is_symlink()
   text=re.sub(r'^'+chr(96)*3+r'[^\n]*\n.*?^'+chr(96)*3+r'[^\n]*$', '',path.read_text(),flags=re.M|re.S)
   for target in re.findall(r'\[[^\]]*\]\(([^\s)]+)\)',text):
    u=urlsplit(target.strip('<>'))
    if u.scheme or u.netloc or not u.path:continue
    resolved=(path.parent/unquote(u.path)).resolve();assert resolved.is_relative_to(src),str(path)+target
    if not resolved.exists():missing.setdefault(str(resolved.relative_to(src)),[]).append({'source':str(path.relative_to(src)),'target':target})
  res['waves'].append({'wave':wave,'missing':missing});save()
  if not missing:break
  requested=set()
  for name in missing:
   if name in tracked:requested.add(name)
   else:
    children=[p for p in tracked if p.startswith(name+'/')]
    assert children,'missing in frozen Git: '+name
    preferred=[p for p in children if Path(p).name=='README.md'];requested.add(sorted(preferred or children)[0])
  needed=sorted({tracked[name]['oid'] for name in requested if not (src/name).exists()})
  for at in range(0,len(needed),256):
   wanted=needed[at:at+256];tag='wave-'+str(wave)+'-fetch-'+str(at//256);(out/(tag+'.input')).write_text('\n'.join(wanted)+'\n');begin=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
   with (out/(tag+'.stdout')).open('xb') as so,(out/(tag+'.stderr')).open('xb') as se:
    p=subprocess.run(['git','-c','maintenance.auto=false','-c','fetch.writeCommitGraph=false','fetch','--no-tags','--no-write-fetch-head','--recurse-submodules=no','--filter=blob:none','origin','--stdin'],input=('\n'.join(wanted)+'\n').encode(),cwd=src,stdout=so,stderr=se)
   after=resource.getrusage(resource.RUSAGE_CHILDREN);res['fetches'].append({'name':tag,'object_count':len(wanted),'exit_code':p.returncode,'wall_seconds':time.monotonic()-begin,'child_user_cpu_seconds':after.ru_utime-before.ru_utime,'child_system_cpu_seconds':after.ru_stime-before.ru_stime,'stdout_bytes':(out/(tag+'.stdout')).stat().st_size,'stdout_sha256':sha((out/(tag+'.stdout')).read_bytes()),'stderr_bytes':(out/(tag+'.stderr')).stat().st_size,'stderr_sha256':sha((out/(tag+'.stderr')).read_bytes())});save();assert p.returncode==0
   print(json.dumps({'wave':wave,'fetched_objects':min(at+256,len(needed)),'total':len(needed)}),flush=True)
  for name in sorted(requested):
   entry=tracked[name];assert entry['mode'] in ('100644','100755') and entry['kind']=='blob'
   path=src/name
   if path.exists():continue
   raw=subprocess.check_output(['git','show',head+':'+name],cwd=src);assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==entry['oid']
   path.parent.mkdir(parents=True,exist_ok=True)
   with path.open('xb') as f:f.write(raw)
   path.chmod(0o755 if entry['mode']=='100755' else 0o644)
   res['restored'].append({'path':name,'bytes':len(raw),'sha256':sha(raw),'git_blob':entry['oid']});save()
   if len(res['restored'])%20==0:print(json.dumps({'wave':wave,'exact_original_git_files_restored':len(res['restored'])}),flush=True)
 else:raise RuntimeError('dependency observation wave bound reached')
 assert subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src)==diff
 c=resource.getrusage(resource.RUSAGE_CHILDREN);res.update(complete=True,wall_seconds=time.monotonic()-start,child_user_cpu_seconds=c.ru_utime-c0.ru_utime,child_system_cpu_seconds=c.ru_stime-c0.ru_stime);save();print(json.dumps({'complete':True,'restored':len(res['restored']),'bytes':sum(x['bytes'] for x in res['restored']),'wall_seconds':res['wall_seconds']}),flush=True)
except BaseException as e:res['error']=repr(e);c=resource.getrusage(resource.RUSAGE_CHILDREN);res.update(wall_seconds=time.monotonic()-start,child_user_cpu_seconds=c.ru_utime-c0.ru_utime,child_system_cpu_seconds=c.ru_stime-c0.ru_stime);save();(out/'error.log').write_text(traceback.format_exc());raise
