/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/examples/borrowed_non_account_allocations-4f7a6df1ee695a8d.d: crates/trnm-mvcc-fee/examples/borrowed_non_account_allocations.rs crates/trnm-mvcc-fee/examples/support/borrowed_non_account_cost.rs Cargo.toml

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/examples/libborrowed_non_account_allocations-4f7a6df1ee695a8d.rmeta: crates/trnm-mvcc-fee/examples/borrowed_non_account_allocations.rs crates/trnm-mvcc-fee/examples/support/borrowed_non_account_cost.rs Cargo.toml

crates/trnm-mvcc-fee/examples/borrowed_non_account_allocations.rs:
crates/trnm-mvcc-fee/examples/support/borrowed_non_account_cost.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
