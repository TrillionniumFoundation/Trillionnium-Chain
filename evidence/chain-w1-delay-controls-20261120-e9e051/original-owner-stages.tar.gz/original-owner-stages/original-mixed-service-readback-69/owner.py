from pathlib import Path
import json,sys,time,resource,hashlib,collections
root=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');out=root/'original-mixed-service-readback-69';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);t=time.monotonic();b=resource.getrusage(resource.RUSAGE_SELF);p=root/'original-mixed-service-diagnostic-67/mixed-service-campaign/report.json';raw=p.read_bytes();report=json.loads(raw);rows=[]
for phase in report['phases']:
 group=collections.Counter()
 attempts=[]
 for x in report['attempts']:
  if x['phase']!=phase['phase']:continue
  response=x['response'];error=response['value'].get('error') if isinstance(response,dict) and isinstance(response.get('value'),dict) else None
  group[(x['lane'],x['status'],str(error),str(x['error']))]+=1
  attempts.append({'ordinal':x['ordinal'],'lane':x['lane'],'started_ns':x['started_ns'],'ended_ns':x['ended_ns'],'status':x['status'],'response_error':error,'client_error':x['error'],'request_kind':list(x['request'])[0] if isinstance(x['request'],dict) else x['request']})
 rows.append({'phase':phase['phase'],'targets':{k:v for k,v in phase.items() if k not in ('false_transcript_fixture','owner','producer','server_metrics')},'metrics':phase['server_metrics'],'attempt_count':len(attempts),'outcomes':[{'lane':k[0],'status':k[1],'response_error':k[2],'client_error':k[3],'count':v} for k,v in group.items()],'attempts':attempts})
r={'source_report_sha256':hashlib.sha256(raw).hexdigest(),'source_test_sha256':'0e2e0792a2ab95d1098787496de2ea13c2dad7f73154ac8b7abe0445bd06067f','attempts':len(report['attempts']),'finite_target_met':report['finite_target_met'],'gap_with_restart_ns':report['honest_probe_max_gap_including_restart_ns'],'restart':report['restart'],'rows':rows,'original_ci_reports_recovered':False,'qualified':False};data=(json.dumps(r,indent=2)+'\n').encode();(out/'READOUT.json').write_bytes(data);a=resource.getrusage(resource.RUSAGE_SELF);result={'wall_seconds':time.monotonic()-t,'self_user_cpu_seconds':a.ru_utime-b.ru_utime,'self_system_cpu_seconds':a.ru_stime-b.ru_stime,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'result':result,'gap_with_restart_ns':r['gap_with_restart_ns'],'restart_same_active_state':r['restart']['same_active_state'],'rows':[{'phase':x['phase'],'targets':x['targets'],'outcomes':x['outcomes'],'work':{k:v for k,v in x['metrics'].items() if k.startswith('work_')}} for x in rows]}),flush=True)
