/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/pkg_config-0fbd3bebb9c32def.d: /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pkg-config-0.3.32/src/lib.rs

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libpkg_config-0fbd3bebb9c32def.rlib: /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pkg-config-0.3.32/src/lib.rs

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libpkg_config-0fbd3bebb9c32def.rmeta: /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pkg-config-0.3.32/src/lib.rs

/workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pkg-config-0.3.32/src/lib.rs:
