#!/usr/bin/env python3
"""Reproduce three retained Cell/M12 command selections on one exact source.

Preparation does not run this script. At execution, the original repository
recorder binds every command to raw tracked source before and after it. Cargo's
original target-level fail-fast remains; a normal native failure does not stop
the other planned commands. No retry, skip, profile override or timing claim.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tarfile
import traceback

import run_exact_selected_controls as common


REVIEWED_SOURCE = '285982d78a4f62a064841cb0f106d18c865e19c5'
COMMON_SHA256 = 'a8f8656fe25038fb67939b360b42631b6856dab9bd302365cd53591be2108e55'
RECORDER = 'scripts/ci/record_pq_native_command.py'
RECORDER_SHA256 = '3cf16e76cae957cb34226a0d2118ac15bbe2d1946d3758efc9426c25612cdc39'
ARCHIVE = 'evidence/cell-bt-composition-20261106/remote-records.tar.xz'
ARCHIVE_SHA256 = 'c48bfdc989f552c39195094a9fe86634262b27fa3c89e3b06a9e7e775b075fa5'
ORIGINALS = {
    'm09-all-targets': (
        'remote-records/evidence/recovery-m09/m09-tests.command.json',
        '2459ed94025dbf7461bf5e248bf15d4e7c4c14dbb07a77c93bb592fed62d7cf9'),
    'm09-doc': (
        'remote-records/evidence/recovery-m09/m09-docs.command.json',
        '59f00d7b5fb2a07136f85c4ae4a53afc2093f5f9fcac3f1e36c80a2bd4818e76'),
    'm12-build': (
        'remote-records/evidence/green-final-combined/native-budget-build.command.json',
        '35da44dd12cab8acf03715fcaedf3dacce5b7fcfe29d42fcc6e6e9b657b4c20e'),
    'm12-test': (
        'remote-records/evidence/green-final-combined/native-budget-test.command.json',
        '75a191dde220579402cd2c247d4940cf84c50bcff60cbd69a5c575a87c96c8c4'),
}


def command_plan(repo: Path, cargo_proxy: str, originals_out: Path | None = None) -> dict:
    """Read reviewed raw command JSON, never execute an archived runner."""
    archive = repo / ARCHIVE
    common.require(common.sha256_file(archive) == ARCHIVE_SHA256,
                   'retained original command archive changed')
    sources = {}
    with tarfile.open(archive, 'r:xz') as stream:
        members = stream.getmembers()
        for label, (name, digest) in ORIGINALS.items():
            selected = [member for member in members if member.name == name]
            common.require(len(selected) == 1 and selected[0].isfile()
                           and selected[0].size <= 16384,
                           'missing or ambiguous retained command: ' + name)
            raw = stream.extractfile(selected[0]).read()
            common.require(hashlib.sha256(raw).hexdigest() == digest,
                           'retained command bytes changed: ' + name)
            value = json.loads(raw)
            common.require(isinstance(value.get('argv'), list)
                           and all(isinstance(arg, str) for arg in value['argv']),
                           'retained command has no argument array')
            sources[label] = {'archive_member': name, 'sha256': digest, 'record': value}
            if originals_out is not None:
                with (originals_out / (label + '.original-command.json')).open('xb') as output:
                    output.write(raw)
    commands = []
    for label in ('m09-all-targets', 'm09-doc'):
        original = sources[label]['record']['argv']
        common.require(original[0:2] == ['cargo', 'test'], 'original M09 driver changed')
        commands.append({'label': label, 'argv': [cargo_proxy, '+1.95.0', *original[1:]],
                         'original_records': [label]})
    build = sources['m12-build']['record']['argv']
    test = sources['m12-test']['record']['argv']
    common.require(build[:2] == ['cargo', 'test']
                   and build.count('--no-run') == 1
                   and build.count('--message-format=json') == 1
                   and test[1:] == ['native_budget', '--test-threads=1', '--nocapture'],
                   'retained M12 build/test composition changed')
    selection = [arg for arg in build[1:] if arg not in ('--no-run', '--message-format=json')]
    commands.append({
        'label': 'm12-native-budget',
        'argv': [cargo_proxy, '+1.95.0', *selection, test[1], '--', *test[2:]],
        'original_records': ['m12-build', 'm12-test'],
        'composition': 'original Cargo library/features/jobs selection plus original actual-ELF filter/capture/thread arguments',
    })
    return {
        'schema': 'trnm-composed-cell-command-plan-v1', 'reviewed_source': REVIEWED_SOURCE,
        'archive': ARCHIVE, 'archive_sha256': ARCHIVE_SHA256,
        'original_records': sources, 'commands': commands,
        'driver_adaptation': 'normal Cargo rustup proxy with explicit +1.95.0; original selections and -j 2 retained',
        'source_recorder': RECORDER,
        'recorder_workflow_reference': '.github/workflows/pon-pq-system-continuation.yml:264-278',
        'command_provenance': 'retained Cell raw command JSON; not a dedicated M09 workflow step',
        'scope': 'three component commands; no full Node/52/80/Clippy duplication, no performance or production qualification',
        'retry_policy': 'none', 'skip_policy': 'none',
        'failure_policy': 'continue other planned commands after source-bound native failure; preserve original Cargo target fail-fast',
    }


ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
TARGET = re.compile(r'^\s*(Running .+|Doc-tests .+)\s*$')
SUMMARY = re.compile(
    r'^test result: (ok|FAILED)\. ([0-9]+) passed; ([0-9]+) failed; '
    r'([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out; '
    r'finished in ([0-9]+(?:\.[0-9]+)?)s$')
RUNNING = re.compile(r'^running ([0-9]+) tests?$')


def harness_observations(log: Path) -> dict:
    """Use actual Cargo target boundaries; child harness text is not added twice.

    Preserve every summary as an observation, but use the final summary in each
    Cargo target section, checked against its initial outer running count. A
    missing or ambiguous outer count fails collection instead of inventing it.
    """
    sections = []
    unassigned = []
    current = None
    for number, raw in enumerate(log.read_text(errors='replace').splitlines(), 1):
        line = ANSI.sub('', raw)
        if match := TARGET.fullmatch(line):
            current = {'cargo_target': match[1], 'announcement_line': number,
                       'running_observations': [], 'summary_observations': []}
            sections.append(current)
        elif match := RUNNING.fullmatch(line):
            row = {'line': number, 'count': int(match[1])}
            (current['running_observations'] if current is not None else unassigned).append(row)
        elif match := SUMMARY.fullmatch(line):
            row = {'line': number, 'status': match[1], 'seconds': match[7],
                   'counts': dict(zip(('passed', 'failed', 'ignored', 'measured', 'filtered'),
                                      map(int, match.group(2, 3, 4, 5, 6))))}
            (current['summary_observations'] if current is not None else unassigned).append(row)
    totals = dict.fromkeys(('passed', 'failed', 'ignored', 'measured', 'filtered'), 0)
    for section in sections:
        runs = section['running_observations']
        summaries = section['summary_observations']
        final = summaries[-1] if summaries else None
        section['outer_final_summary'] = final
        section['outer_running_count'] = runs[0]['count'] if runs else None
        section['counts_closed'] = bool(final and runs and runs[0]['count'] == sum(
            final['counts'][key] for key in ('passed', 'failed', 'ignored', 'measured')))
        if final is not None:
            for key, value in final['counts'].items():
                totals[key] += value
    complete = bool(sections) and not unassigned and all(row['counts_closed'] for row in sections)
    return {'cargo_harnesses': sections, 'unassigned_observations': unassigned,
            'observed_outer_harness_count': len(sections), 'observed_outer_totals': totals,
            'collection_complete': complete,
            'all_observed_harnesses_passed': complete and totals['passed'] > 0
            and totals['failed'] == 0 and totals['measured'] == 0
            and all(row['outer_final_summary']['status'] == 'ok' for row in sections),
            'scope': 'actually reached Cargo harnesses only; original Cargo fail-fast can leave later targets unexecuted',
            'timing_scope': 'raw libtest elapsed fields retained without performance conclusions'}


def record_command(repo: Path, expected: str, out: Path, env: dict,
                   label: str, argv: list[str], source: dict) -> dict:
    execution = common.run_capture([
        sys.executable, str(repo / RECORDER), '--kind', 'head',
        '--candidate', expected, '--tested', expected,
        '--label', label, '--output', str(out / 'native'), '--', *argv,
    ], repo, env, out / 'recorder' / label)
    result = {'label': label, 'argv': argv, 'recorder_execution': execution,
              'source_bound': False, 'native_exit': None, 'passed': False}
    receipt_path = out / 'native' / (label + '.json')
    if not receipt_path.is_file():
        result['error'] = 'original recorder produced no terminal receipt'
        return result
    value = json.loads(receipt_path.read_text())
    result['receipt'] = value
    result['receipt_identity'] = common.file_receipt(receipt_path)
    result['native_exit'] = value.get('exit_code')
    result['source_bound'] = (value.get('status') in ('command_succeeded', 'command_failed')
                              and value.get('before') == value.get('after') == source
                              and value.get('argv') == argv)
    log = out / 'native' / (label + '.log')
    if log.is_file():
        result['log_identity'] = common.file_receipt(log)
        result['log_verified'] = (value.get('log_file') == log.name
                                  and value.get('log_sha256') == result['log_identity']['sha256']
                                  and value.get('log_bytes') == result['log_identity']['size'])
    else:
        result['log_verified'] = False
    result['passed'] = (result['source_bound'] and result['log_verified']
                        and value.get('exit_code') == 0 and common.capture_passed(execution))
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo-root', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cargo-proxy', type=Path)
    parser.add_argument('--provider-receipt', type=Path)
    parser.add_argument('--build-receipt', type=Path)
    args = parser.parse_args()
    common.require(re.fullmatch(r'[0-9a-f]{40}', args.expected_head) is not None,
                   'expected head must be an exact commit')
    repo = args.repo_root.resolve(strict=True)
    out = args.output.resolve()
    common.require(not out.is_relative_to(repo), 'records must remain outside source')
    out.mkdir(parents=True, exist_ok=False)
    for name in ('native', 'recorder', 'originals', 'inputs'):
        (out / name).mkdir()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    report = {'schema': 'trnm-composed-cell-controls-v1', 'started_utc': common.utc_now(),
              'expected_head': args.expected_head, 'repo': str(repo),
              'runner': common.file_receipt(Path(__file__).resolve()),
              'shared_helper': common.file_receipt(Path(common.__file__).resolve()),
              'plan': None, 'source_before': None, 'source_after': None,
              'metadata_commands': [], 'commands': [], 'errors': [],
              'planned_component_commands': 3, 'retry_policy': 'none',
              'scope': 'original Cell/M12 component commands on exact source; no performance, whole-chain PQ, SLO or production qualification'}
    try:
        common.require(report['shared_helper']['sha256'] == COMMON_SHA256, 'shared helper changed')
        common.require(common.sha256_file(repo / RECORDER) == RECORDER_SHA256, 'original recorder changed')
        report['source_before'] = common.source_checkpoint(repo, args.expected_head, out, 'source-before', env)
        common.require(report['source_before']['passed'], 'original source-before checker failed')
        source = report['source_before']['receipt']
        report['environment'] = {key: env.get(key) for key in (*common.ENV_KEYS, 'RUSTUP_HOME', 'RUSTUP_TOOLCHAIN')}
        overrides = {key: value for key, value in env.items() if value and (
            key.startswith('CARGO_PROFILE_') or key in (
                'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'))}
        common.require(not overrides, 'profile/compiler overrides conflict with unchanged-profile execution')
        for key in ('RUSTC', 'RUSTDOC', 'CARGO_TARGET_DIR', 'OPENSSL_DIR', 'TRNM_PQ_OPENSSL'):
            common.require(env.get(key) is not None and Path(env[key]).is_absolute()
                           and Path(env[key]).exists(), 'missing actual absolute build/provider path: ' + key)
        common.require(env.get('OPENSSL_STATIC') == '1' and bool(env.get('TRNM_PQ_OPENSSL_VERSION')),
                       'original static native PQ provider environment is not prepared')
        provider = common.file_receipt(Path(env['TRNM_PQ_OPENSSL']).resolve(strict=True))
        common.require(provider['sha256'] == env.get('TRNM_PQ_OPENSSL_SHA256'), 'provider bytes differ from supplied hash')
        report['provider_binary'] = provider
        for kind, path in (('provider', args.provider_receipt), ('build', args.build_receipt)):
            if path is not None:
                report[kind + '_external_receipt'] = common.snapshot_file(
                    path.resolve(strict=True), out / 'inputs' / (kind + '-external-receipt.json'))
        report['external_receipt_scope'] = 'verbatim supplied historical records; no historical source checkpoint is manufactured'
        located = str(args.cargo_proxy) if args.cargo_proxy is not None else shutil.which('cargo')
        common.require(bool(located), 'normal Cargo rustup proxy is unavailable')
        # Preserve the cargo launcher name: resolving its symlink for invocation
        # would invoke rustup itself and change its argv[0] dispatch behavior.
        cargo = str(Path(located).absolute())
        report['cargo_proxy'] = {'invoked_path': cargo,
                                 'target_identity': common.file_receipt(Path(cargo).resolve(strict=True))}
        report['plan'] = command_plan(repo, cargo, out / 'originals')
        common.write_json(out / 'command-plan.json', report['plan'])
        setup = [
            ('preflight', ['bash', 'scripts/project-preflight.sh'], None),
            ('cargo-version', [cargo, '+1.95.0', '--version'], 'cargo 1.95.0 '),
            ('rustc-version', [env['RUSTC'], '-Vv'], 'rustc 1.95.0 '),
            ('rustdoc-version', [env['RUSTDOC'], '--version'], 'rustdoc 1.95.0 '),
        ]
        for label, argv, version_prefix in setup:
            result = record_command(repo, args.expected_head, out, env, label, argv, source)
            report['metadata_commands'].append(result)
            common.require(result['passed'], 'source-bound setup command failed: ' + label)
            if version_prefix is not None:
                common.require((out / 'native' / (label + '.log')).read_text().startswith(version_prefix),
                               'actual toolchain version changed: ' + label)
        for selection in report['plan']['commands']:
            label = selection['label']
            print(json.dumps({'event': 'component-start', 'label': label, 'argv': selection['argv']}), flush=True)
            result = record_command(repo, args.expected_head, out, env, label, selection['argv'], source)
            report['commands'].append(result)
            if result.get('log_verified'):
                result['harnesses'] = harness_observations(out / 'native' / (label + '.log'))
                result['passed'] = result['passed'] and result['harnesses']['all_observed_harnesses_passed']
            else:
                result['passed'] = False
            common.write_json(out / (label + '.observation.json'), result)
            print(json.dumps({'event': 'component-finish', 'label': label,
                              'native_exit': result['native_exit'], 'passed': result['passed'],
                              'harnesses': result.get('harnesses', {}).get('observed_outer_totals')}), flush=True)
            # A normal native failure is evidence and does not stop the plan.
            # A changed source or incomplete recorder is not native test failure.
            common.require(result['source_bound'] and result.get('log_verified'),
                           'source/record integrity failed; remaining commands are not executed')
    except Exception:
        report['errors'].append(traceback.format_exc())
    finally:
        try:
            report['source_after'] = common.source_checkpoint(repo, args.expected_head, out, 'source-after', env)
            common.require(report['source_after']['passed'], 'original source-after checker failed')
            common.require(report['source_before'] is not None
                           and report['source_before']['receipt'] == report['source_after']['receipt'],
                           'source-before and source-after differ')
        except Exception:
            report['errors'].append(traceback.format_exc())
        report['executed_component_commands'] = len(report['commands'])
        report['native_failed_component_commands'] = sum(
            row['native_exit'] is not None and row['native_exit'] != 0 for row in report['commands'])
        report['passed_component_commands'] = sum(row['passed'] for row in report['commands'])
        report['finished_utc'] = common.utc_now()
        report['passed'] = (not report['errors'] and len(report['commands']) == 3
                            and all(row['passed'] for row in report['commands']))
        common.write_json(out / 'summary.json', report)
        (out / 'composed-cell.exit').write_text('0\n' if report['passed'] else '1\n')
        common.write_json(out / 'receipt-sha256.json', [common.file_receipt(path)
                          for path in sorted(out.rglob('*')) if path.is_file()])
    print(json.dumps({'passed': report['passed'], 'output': str(out),
                      'executed': report['executed_component_commands'],
                      'native_failed': report['native_failed_component_commands'],
                      'passed_commands': report['passed_component_commands']}), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
