#!/usr/bin/env python3
"""Independent immutable-source readback of downloaded run 41299973417 captures."""
import hashlib
import json
from pathlib import Path
from collections import Counter, defaultdict
import statistics
import re
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CAPTURE = ROOT / 'ci-captures/run-41299973417'
sys.path.insert(0, str(HERE / 'reader-source/scripts'))
import pon_w1_false_trace_reuse_reader_v1 as false_reader
import pon_w1_legal_strategy_reader_v1 as legal_reader

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        while block := source.read(1024 * 1024): digest.update(block)
    return digest.hexdigest()

def ratios(paths):
    full = paths['full-limb-experimental']
    return {baseline: {axis: {
        'baseline_ns': paths[baseline][axis], 'full_limb_ns': full[axis],
        'baseline_over_full_limb': paths[baseline][axis] / full[axis],
        'full_limb_over_baseline': full[axis] / paths[baseline][axis],
        'full_limb_saved_fraction': 1 - full[axis] / paths[baseline][axis],
    } for axis in ('cpu_ns','wall_ns')} for baseline in ('production','limb')}

def dist(cohorts):
    result = {}
    for baseline in ('production','limb'):
        result[baseline] = {}
        for axis in ('cpu_ns','wall_ns'):
            values = [r['ratios'][baseline][axis]['baseline_over_full_limb'] for r in cohorts]
            result[baseline][axis] = dict(cohort_count=len(values), full_limb_faster=sum(v>1 for v in values),
                full_limb_slower=sum(v<1 for v in values), ties=sum(v==1 for v in values),
                minimum=min(values), median=statistics.median(values), maximum=max(values))
    return result

def validate_manifest(directory, artifact):
    path = directory / 'manifest.json'
    m = json.loads(path.read_text())
    mismatches = []
    for name, expected in m['artifact_sha256'].items():
        child = directory / name
        assert child.is_file() and not child.is_symlink(), (directory,name)
        if sha(child) != expected: mismatches.append(name)
    assert not mismatches, (path,mismatches)
    assert m['result']=='PASS' and m['source_before']==m['source_after']
    assert m['source_before']['commit']==m['expected_source_commit']
    assert m['source_before']['source_state']=='committed-clean' and m['source_before']['tracked_worktree_verified'] is True
    assert m['compiler_channel']=='1.95.0' and m['build_profile']=='release'
    assert m['cargo_configuration_before']==m['cargo_configuration_after'] and not m['cargo_configuration_changed']
    assert not m['source_changed'] and m['build_environment_overrides']=={}
    for observation in m['observations']:
        assert observation['exit_code']==0 and observation['timed_out'] is False, observation
        if observation['stdout'].startswith('campaign'): assert observation['timeout_seconds']==300
    names = ['binary_sha256_before','binary_sha256_after','retained_binary_sha256_before','retained_binary_sha256_after']
    assert len({m[name] for name in names})==1
    binary_name = 'pon_w1_legal_strategy_v1' if 'legal' in directory.name else 'pon_w1_false_trace_reuse_v1'
    assert sha(directory / binary_name)==m[names[0]]
    header = (directory / binary_name).read_bytes()[:20]
    assert header[:4]==b'\x7fELF' and int.from_bytes(header[18:20],'little')==m['binary_elf_machine']
    assert m['binary_elf_machine']==(62 if m['architecture']=='x64' else 183)
    cpuinfo = (directory/'cpuinfo.txt').read_text()
    reported_cpu_fields = {name:list(dict.fromkeys(re.findall('^'+re.escape(name)+r'\s*:\s*(.*)$',cpuinfo,re.M)))
        for name in ('model name','CPU implementer','CPU architecture','CPU part')}
    return m, dict(artifact_id=artifact['id'], artifact_name=artifact['name'],reported_cpu_fields=reported_cpu_fields,
        manifest_sha256=sha(path), artifact_member_count=len(m['artifact_sha256']),
        artifact_member_bytes=sum((directory/name).stat().st_size for name in m['artifact_sha256']),
        all_member_sha256_match=True, native_command_results_match=True, binary_identity_match=True,
        source_commit=m['expected_source_commit'],source_tree=m['source_before']['tree'],
        architecture=m['architecture'], binary_sha256=m[names[0]],binary_elf_machine=m['binary_elf_machine'],
        manifest_readback_identical=None)

def raw_summary(paths, family):
    counts, verdicts = Counter(),Counter()
    sums = defaultdict(lambda:defaultdict(lambda:Counter()))
    cohort_sums = defaultdict(lambda:defaultdict(lambda:Counter()))
    winners, attempts, exhausted, source = set(),0,0,None
    for path in paths:
        with path.open() as stream:
            for line in stream:
                r=json.loads(line);kind=r['kind'];counts[kind]+=1
                if kind=='campaign': source=r
                if kind=='search':
                    attempts+=len(r['attempts']);exhausted+=r['status']=='exhausted'
                if kind=='candidate': winners.add(r['proof_sha256'])
                if kind!='verifier':continue
                case = r.get('case','Transcript')
                verdicts[case+'/'+r['path']+'/'+r['outcome']]+=1
                if family=='legal': key=(case,source['class'],source['target_index'],source['reuse_winners'],r['sample'],r['strategy'])
                else:key=(case,r['class'],r['sample'])
                for axis,value in r['timing'].items():
                    sums[case][r['path']][axis]+=value
                    cohort_sums[key][r['path']][axis]+=value
    cohorts=[]
    for key,paths in sorted(cohort_sums.items()):
        cohorts.append(dict(key=list(key), sums_ns=paths, ratios=ratios(paths)))
    cases={case: dict(sums_ns=paths,ratios=ratios(paths),cohort_distribution=dist([c for c in cohorts if c['key'][0]==case])) for case,paths in sums.items()}
    return dict(record_counts=dict(counts),attempts_across_all_measured_strategy_invocations=attempts,
        exhausted_searches=exhausted,distinct_candidate_proof_sha256_count=len(winners),
        outcome_counts=dict(verdicts),cases=cases,cohorts=cohorts)

artifacts=json.loads((ROOT/'ci-monitor/run-41299973417-artifacts.json').read_text())['artifacts']
metadata={str(a['id']):a for a in artifacts}
result=dict(schema='pon-w1-independent-ci-performance-readback-v1',run_id=41299973417,
    reader_source=json.loads((HERE/'reader-source/SOURCE.json').read_text()),false_trace=[],legal_strategy=[],
    limitations=['No new native execution was performed by this readback.',
        'Reported ratios are ratios of complete sums, not pooled independent samples or universal speed bounds.',
        'Legal data have two samples per class, below unchanged eight-sample qualification policy.',
        'Cross-horizon search prefixes and cross-source/cross-host proof identities repeat intentionally.',
        'Primitive timings do not establish service acceptance; service evidence is assessed separately.',
        'Member hashes and immutable-source reader equality authenticate consistency, not host independence or honest clock measurement.'])

fingerprints={}
for artifact_id in sorted(metadata):
    directory=CAPTURE/artifact_id
    if not directory.is_dir():continue
    for kind in ('w1-false-trace-reuse-v1','w1-full-limb-reuse-v1','w1-legal-strategy-v1'):
        folder=directory/kind
        if not (folder/'manifest.json').is_file():continue
        m,validation=validate_manifest(folder,metadata[artifact_id])
        if kind=='w1-legal-strategy-v1':
            paths=[folder/f'campaign-{i:02d}.stdout' for i in range(30)]
            replay=legal_reader.analyze(paths)
            assert replay==m['reader'], ('legal readback differs',artifact_id)
            for index,shard in enumerate(m['shards']):
                assert replay['shards'][index]==shard['reader']
                assert replay['shards'][index]['selection']==shard['configuration']
            for shard in replay['shards']:
                choice=shard['selection']
                for searched in shard['search_fingerprints']:
                    identity=choice['class'],choice['target_index'],choice['reuse_winners'],searched['sample'],searched['search_index']
                    assert identity not in fingerprints or fingerprints[identity]==searched, ('cross-host strategy mismatch',identity)
                    fingerprints[identity]=searched
            validation['manifest_readback_identical']=True
            raw=raw_summary(paths,'legal')
            total_costs=defaultdict(lambda:Counter());dispatch=[];by_class=defaultdict(lambda:defaultdict(lambda:Counter()))
            for shard in replay['shards']:
                costs=shard['strategy_costs'];pair={c['strategy']:c for c in costs}
                baseline=pair['prepared-generic']['inclusive_cohort_total'];candidate=pair['frozen-public-dispatch-v1']['inclusive_cohort_total']
                dispatch.append(dict(selection=shard['selection'], costs=costs,
                    generic_over_dispatch={axis:baseline[axis]/candidate[axis] for axis in baseline}))
                for c in costs:
                    for axis,value in c['inclusive_cohort_total'].items():
                        total_costs[c['strategy']][axis]+=value
                        by_class[shard['selection']['class']][c['strategy']][axis]+=value
            summary_costs={name:dict(totals) for name,totals in total_costs.items()}
            class_costs={name:dict(sums_ns=sums,generic_over_dispatch={axis:sums['prepared-generic'][axis]/sums['frozen-public-dispatch-v1'][axis] for axis in ('cpu_ns','wall_ns')}) for name,sums in by_class.items()}
            item=dict(validation=validation, raw=raw, dispatch_shards=dispatch,
                total_strategy_costs_ns=summary_costs,
                generic_over_dispatch={axis:summary_costs['prepared-generic'][axis]/summary_costs['frozen-public-dispatch-v1'][axis] for axis in ('cpu_ns','wall_ns')},
                class_costs=class_costs, semantic_alerts=replay['semantic_alerts'],
                unique_search_streams=replay['unique_search_streams'],
                qualification_flags={key:replay[key] for key in legal_reader.FALSE_FLAGS})
            result['legal_strategy'].append(item)
            print(json.dumps({'validated_legal':artifact_id,'arch':m['architecture'],'counts':raw['record_counts'],
                'attempts':raw['attempts_across_all_measured_strategy_invocations'],'exhausted':raw['exhausted_searches'],
                'ratios':{case:r['ratios'] for case,r in raw['cases'].items()}}),flush=True)
        else:
            full=kind=='w1-full-limb-reuse-v1'
            replay=false_reader.analyze(folder/'campaign.stdout',full_limb=full)
            assert replay==m['reader'],('false readback differs',artifact_id,kind)
            validation['manifest_readback_identical']=True
            raw=raw_summary([folder/'campaign.stdout'],'false') if full else dict(record_counts=replay['record_counts'])
            item=dict(validation=validation,mode='full-limb' if full else 'original',raw=raw,
                actual_reuse_cohorts=replay['actual_reuse_cohorts'],semantic_alerts=replay['semantic_alerts'])
            result['false_trace'].append(item)
            print(json.dumps({'validated_false':artifact_id,'mode':item['mode'],'counts':raw['record_counts']}),flush=True)

result['capture_count']=len(result['false_trace'])+len(result['legal_strategy'])
result['all_requested_lanes_present']=len(result['false_trace'])==8 and len(result['legal_strategy'])==4
result['cross_host_legal_search_fingerprints_match']=True
(HERE/'performance-report.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'report':str(HERE/'performance-report.json'),'capture_count':result['capture_count'],
    'all_requested_lanes_present':result['all_requested_lanes_present']}),flush=True)
