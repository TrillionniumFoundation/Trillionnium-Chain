"""Read-only source review controls; writes evidence outside the repository only."""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from fractions import Fraction
from io import BytesIO, StringIO
from itertools import product
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
from types import SimpleNamespace
import unittest

REPO = Path('/workspace/scratch/c9b48df754d6/chain-quantum-next')
OUT = Path('/workspace/scratch/c9b48df754d6/validation-four-gates')
FORMAL = REPO / 'formal/pon-nakamoto-v1'
sys.dont_write_bytecode = True
sys.path[:0] = [str(REPO/'scripts/ci'), str(REPO/'scripts'), str(FORMAL/'experiments'), str(FORMAL)]
import pon_w1_observed_economics_v1 as economics
import w1_machine_frontier as frontier
from w1_machine_envelope import SOURCES

FILES = tuple(sorted(set(SOURCES) | {
    'scripts/pon_w1_observed_economics_v1.py',
    'scripts/ci/test_pon_w1_observed_economics_v1.py',
    'scripts/pon_w1_preparation_strategy_reader_v4.py',
    'scripts/pon_w1_cost_matrix_reader.py',
    'formal/pon-nakamoto-v1/experiments/w1_machine_frontier.py',
    'formal/pon-nakamoto-v1/experiments/test_w1_machine_frontier.py',
    'formal/pon-nakamoto-v1/experiments/w1_native_bridge.py',
    'formal/pon-nakamoto-v1/test_w1_machine_envelope.py',
    'formal/pon-nakamoto-v1/test_w1_search_probability.py',
}))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def sources():
    return {name: sha((REPO/name).read_bytes()) for name in FILES}


def rational(value):
    return {'numerator': value.numerator, 'denominator': value.denominator}


def expected_refusal(call, expected):
    try:
        call()
    except ValueError as error:
        assert str(error) == expected, (expected, str(error))
        return expected
    raise AssertionError('unexpected acceptance: ' + expected)


def assembly_inputs():
    """Synthetic parsed-shard stand-ins; no timing or native execution claim."""
    shards, commands = [], []
    for material in economics.v4.CLASSES:
        for target in range(4):
            for horizon in economics.v4.HORIZONS if target < 2 else (1,):
                purpose = economics.v4.PURPOSES[target]
                raw = repr((material, target, horizon)).encode()
                digest = sha(raw)
                selected = {'class': material, 'target_index': target,
                            'reuse_winners': horizon, 'purpose': purpose}
                shards.append({'selection': selected, 'matched_streams': [],
                               'raw_observation': {'sha256': digest, 'bytes': len(raw)}})
                name = (f'{material}-t{target}-h{horizon}' if target < 2
                        else f'{material}-control-t{target}')
                commands.append({'name': name, 'purpose': purpose,
                    'process': {'stdout_sha256': digest, 'process_complete': True,
                                'returncode': 0, 'timed_out': False,
                                'observer_interrupted': False, 'resource_failure': None,
                                'argv': ['/synthetic/not-executed', economics.v4.SELECTOR,
                                         '--class', material, '--target-index', str(target),
                                         '--reuse-winners', str(horizon)]},
                    'archives': {'stdout.jsonl': {'raw_sha256': digest, 'raw_bytes': len(raw)}}})
    metadata = {'manifest': {'planned': 48, 'observed_commands': 48,
                            'commands': commands, 'unobserved_planned_commands': []},
                'declaration': {'source_sha256': {}, 'base_commit': 'synthetic-no-native-execution',
                                'tracked_or_untracked_working_changes': True,
                                'binary_sha256': '0'*64}}
    return shards, metadata


def metadata_controls():
    shards, metadata = assembly_inputs()
    original = deepcopy((shards, metadata))
    baseline = economics.assemble_report(shards, metadata)
    assert (shards, metadata) == original, 'assembly mutated its input'
    assert len(baseline['cost_grid']) == 36 and len(baseline['controls']) == 12
    refusals = []
    for change, expected in (
        ('duplicate_stdout', 'DUPLICATE_PROCESS_STDOUT'),
        ('swap_receipts', 'PROCESS_SELECTION_BINDING'),
        ('wrong_purpose', 'PROCESS_SELECTION_BINDING'),
        ('wrong_argument', 'PROCESS_ARGUMENT_BINDING'),
        ('missing_process', 'PROCESS_INVENTORY'),
        ('failure', 'FAILED_PROCESS_REMAINS_UNQUALIFIED'),
    ):
        observations, meta = assembly_inputs()
        commands = meta['manifest']['commands']
        if change == 'duplicate_stdout':
            commands[1]['process']['stdout_sha256'] = commands[0]['process']['stdout_sha256']
            commands[1]['archives'] = deepcopy(commands[0]['archives'])
        elif change == 'swap_receipts':
            for key in ('process', 'archives'):
                commands[0][key], commands[1][key] = commands[1][key], commands[0][key]
        elif change == 'wrong_purpose':
            commands[0]['purpose'] = 'first-hit-control'
        elif change == 'wrong_argument':
            commands[0]['process']['argv'][-1] = '64'
        elif change == 'missing_process':
            commands.pop()
        else:
            commands[0]['process']['timed_out'] = True
        refusals.append(expected_refusal(lambda: economics.assemble_report(observations, meta), expected))
    refusals.append(expected_refusal(
        lambda: economics.summarize_records(SimpleNamespace(ended=True), {}, budgets=(7,)),
        'BUDGET_INVENTORY'))
    return {'synthetic_parsed_metadata_only': True, 'baseline_shards': 48,
            'successful_refusal_controls': refusals, 'input_mutation_observed': False}


def decompression_controls():
    cases = 0
    for length, limit, chunk in product((0, 1, 5, 6, 100), (0, 1, 5, 6, 20), (1, 2, 10**6, -1)):
        reader = economics.BoundedDecompression(BytesIO(bytes(length)), limit)
        assert reader.read(0) == b'' and reader.consumed == 0
        refused = False
        try:
            while reader.read(chunk):
                pass
        except ValueError as error:
            assert str(error) == 'TOTAL_DECOMPRESSED_STREAM_BOUND'
            refused = True
        assert refused == (length > limit)
        assert reader.consumed == min(length, limit + 1)
        cases += 1
    archive = BytesIO()
    with tarfile.open(fileobj=archive, mode='w', format=tarfile.USTAR_FORMAT) as writer:
        member = tarfile.TarInfo('control.txt')
        member.size = 1
        writer.addfile(member, BytesIO(b'x'))
    payload = archive.getvalue()
    limit = 1 + 1024 + 10240
    for trailing, should_refuse in ((b'', False), (bytes(limit), True)):
        reader = economics.BoundedDecompression(BytesIO(payload + trailing), limit)
        refused = False
        try:
            with tarfile.open(fileobj=reader, mode='r|') as parsed:
                members = []
                for member in parsed:
                    members.append(member.name)
                    assert parsed.extractfile(member).read() == b'x'
            assert members == ['control.txt']
            while reader.read(1024 * 1024):
                pass
        except ValueError as error:
            assert str(error) == 'TOTAL_DECOMPRESSED_STREAM_BOUND'
            refused = True
        assert refused == should_refuse
    return {'bounded_read_cases': cases, 'real_in_memory_ustar_plus_trailing_controls': 2,
            'maximum_overread_to_detect_violation_bytes': 1,
            'subprocess_or_external_archive_executed': False}


def dominance_controls():
    cells, intervals = [], []
    patterns = ((1, 1, 1, 1, 1), (2, 1, 1, 1, 1), (1, 2, 1, 1, 1), (2, 2, 2, 2, 2))
    for low in range(5):
        for high in range(low, 5):
            for costs in patterns:
                lo, hi = Fraction(low, 4), Fraction(high, 4)
                cells.append({'status': 'CONSTRUCTED',
                              'resources': dict(zip(frontier.RESOURCE_FIELDS, costs)),
                              'conditional_delivery_probability': {'lower': rational(lo), 'upper': rational(hi)}})
                intervals.append((lo, (lo+hi)/2, hi))
    graph = []
    for i, left in enumerate(cells):
        neighbors = set()
        for j, right in enumerate(cells):
            # Independently interpret each possible endpoint/midpoint as a
            # deterministic objective vector: five minimized costs, then -p.
            # Affinity in p makes the endpoints sufficient for the interval.
            verdicts = []
            for lp, rp in product(intervals[i], intervals[j]):
                a = tuple(left['resources'][key] for key in frontier.RESOURCE_FIELDS) + (-lp,)
                b = tuple(right['resources'][key] for key in frontier.RESOURCE_FIELDS) + (-rp,)
                verdicts.append(all(x <= y for x, y in zip(a, b)) and any(x < y for x, y in zip(a, b)))
            expected = all(verdicts)
            observed = frontier.dominates(left, right)
            assert observed == expected, (i, j, expected, observed)
            if observed:
                neighbors.add(j)
        graph.append(neighbors)
    for i, neighbors in enumerate(graph):
        assert i not in neighbors
        for j in neighbors:
            assert i not in graph[j]
            assert graph[j] <= neighbors, 'dominance is not transitive'
    refused = {'status': 'REFUSED', 'reason': 'synthetic control'}
    assert all(not frontier.dominates(refused, cell) and not frontier.dominates(cell, refused) for cell in cells)
    return {'valid_interval_resource_cells': len(cells), 'ordered_pair_comparisons': len(cells)**2,
            'independent_deterministic_objective_vector_checks': len(cells)**2*9,
            'certified_dominance_edges': sum(map(len, graph)),
            'irreflexive_asymmetric_transitive': True, 'refused_cells_never_dominate': True,
            'global_optimality_or_complete_economic_cost_claimed': False}


started = datetime.now(timezone.utc).isoformat()
before = sources()
raw_tests = StringIO()
suite = unittest.defaultTestLoader.loadTestsFromNames([
    'test_pon_w1_observed_economics_v1', 'test_w1_machine_frontier'])
tests = unittest.TextTestRunner(stream=raw_tests, verbosity=2).run(suite)
checks = {'metadata': metadata_controls(), 'decompression': decompression_controls(),
          'interval_dominance': dominance_controls()}
after = sources()
assert tests.wasSuccessful() and before == after
raw = raw_tests.getvalue().encode()
raw_path = OUT / 'oracle-independent-review-tests.log'
with raw_path.open('xb') as stream:
    stream.write(raw)
prior = OUT/'finite-independent/probability_crosscheck.stdout.json'
prior_record = json.loads(prior.read_bytes())
assert prior_record['status'] == 'PASS' and prior_record['source_unchanged'] is True
report = {
    'schema': 'trnm-oracle-independent-readonly-review-v1', 'status': 'PASS',
    'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
    'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
    'git_branch': subprocess.check_output(['git', 'branch', '--show-current'], cwd=REPO, text=True).strip(),
    'scope': 'development working-source review, not a frozen-commit or hardware qualification',
    'reviewed_source_before': before, 'reviewed_source_after': after, 'reviewed_source_unchanged': True,
    'repository_source_written_by_this_driver': False,
    'retained_test_suites': {'tests_run': tests.testsRun, 'failures': len(tests.failures),
        'errors': len(tests.errors), 'skipped': len(tests.skipped),
        'raw_log': str(raw_path), 'raw_log_sha256': sha(raw)},
    'independent_executable_checks': checks,
    'review_findings': [
        {'item': 'process identity', 'status': 'RESOLVED',
         'basis': 'unique stdout bijection, complete inventory, names/purpose/argv tied to parsed raw selection; independent duplicate, swap and mismatch controls refuse'},
        {'item': 'budget inventory', 'status': 'RESOLVED',
         'basis': 'custom budgets refused before summary; fixed policy labels agree with actual recorded replays'},
        {'item': 'decompressed stream cap', 'status': 'RESOLVED',
         'basis': 'reader counts metadata/header/body/trailing bytes; one extra byte detects overrun; parser/consumer exception reaches subprocess kill/wait finally; parsed nonempty PAX attributes refused'},
        {'item': 'frontier domain scope', 'status': 'RESOLVED_DURING_REVIEW',
         'basis': 'compare now replays census, records native_shape and comparison source digest, validates common models, and distinguishes reduced controls'},
        {'item': 'frontier mathematical meaning', 'status': 'PASS',
         'basis': 'finite 18-cell family; listed five planned-resource dimensions only; interval ordering cannot claim dominance from overlap; unconstructed cells remain in inventory'},
    ],
    'separate_probability_crosscheck': {'path': str(prior), 'sha256': sha(prior.read_bytes()),
        'reported_exact_fraction_comparisons': prior_record['finite_fraction_interval_comparisons'],
        'reported_large_q_period_controls': prior_record['large_q_exact_period_controls'],
        'current_probability_source_matches': before['formal/pon-nakamoto-v1/w1_search_probability.py'] == prior_record['source_after']['w1_search_probability.py'],
        'source_scope': 'retained independent earlier development receipt; no claim its entire finite-consensus source is the final freeze'},
    'limitations': ['CPU accounting excludes separately identified verification, propagation and evidence costs; no complete economic comparison',
        'frontier dominance is over explicitly listed dimensions and declared finite algorithms only',
        'histories, fault bounds, architecture latencies and classical clocks remain premises unless separately evidenced',
        'no external hardware experiment, no GPU/QPU execution, no qualification or production activation'],
    'driver_path': str(Path(__file__).resolve()), 'driver_sha256': sha(Path(__file__).read_bytes()),
    'command': f'PYTHONDONTWRITEBYTECODE=1 python3 {Path(__file__).resolve()}',
    'quantum_hardware_executed': False, 'physical_parameters_calibrated': False,
    'quantum_mining_qualified': False, 'production_activation': False,
}
with (OUT/'oracle-independent-review.json').open('x') as stream:
    json.dump(report, stream, sort_keys=True, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps({'status': report['status'], 'tests_run': tests.testsRun,
                  'checks': checks, 'receipt': str(OUT/'oracle-independent-review.json')}, sort_keys=True))
