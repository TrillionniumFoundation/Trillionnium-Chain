#!/usr/bin/env python3
"""Run the reviewed composed-source controls once, preserving every result."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import traceback

import run_exact_selected_controls as common

HELPERS = {
    "run_exact_selected_controls.py": "a8f8656fe25038fb67939b360b42631b6856dab9bd302365cd53591be2108e55",
    "run_pq_required_controls_v2.py": "94bccecdc9a33ac140633ab677af3b17f600c1483377c5b94083bcbed7bc3680",
    "run_composed_cell_controls.py": "4ed5320de1668893212dde62970a8ed53adb25717237f7cc74b42a3e623f905e",
}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--build-prefix", type=Path, required=True)
    parser.add_argument("--target-dir", type=Path, required=True)
    parser.add_argument("--provider-receipt", type=Path, required=True)
    parser.add_argument("--cargo-proxy", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo_root.resolve(strict=True)
    out = args.output.resolve()
    common.require(not out.is_relative_to(repo), "evidence must be outside source")
    out.mkdir(parents=True, exist_ok=False)
    here = Path(__file__).resolve().parent
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    report = {
        "schema": "trnm-composed-native-validation-v1",
        "started_utc": common.utc_now(), "expected_head": args.expected_head,
        "runner": common.file_receipt(Path(__file__).resolve()),
        "environment": {key: env.get(key) for key in (*common.ENV_KEYS, "TMPDIR")},
        "source_before": None, "source_after": None, "steps": [],
        "errors": [], "passed": False,
        "scope": "80 exact semantic controls; full Node plus original PQ52; original Cell/M12 selections; strict workspace Clippy. Not the complete workspace native test suite, business SLO, public throughput or production qualification.",
        "retry_policy": "none; continue independent planned gates after native failure while source remains identical",
    }
    try:
        report["helpers"] = {}
        for name, digest in HELPERS.items():
            identity = common.file_receipt(here / name)
            common.require(identity["sha256"] == digest, "reviewed helper changed: " + name)
            report["helpers"][name] = identity
        report["source_before"] = common.source_checkpoint(
            repo, args.expected_head, out, "source-before", env)
        common.require(report["source_before"]["passed"], "source-before failed")
        source = report["source_before"]["receipt"]
        build_flags = [
            "--repo-root", str(repo), "--expected-head", args.expected_head,
            "--build-jsonl", str(args.build_prefix) + ".jsonl",
            "--build-stderr", str(args.build_prefix) + ".stderr",
            "--build-receipt", str(args.build_prefix) + ".json",
        ]
        plans = [
            ("controls-80", [sys.executable, str(here / "run_exact_selected_controls.py"),
                             *build_flags, "--output", str(out / "controls-80")]),
            ("pq-full-and-required", [sys.executable, str(here / "run_pq_required_controls_v2.py"),
                                      *build_flags, "--target-dir", str(args.target_dir),
                                      "--output", str(out / "pq-full-and-required")]),
            ("cell-controls", [sys.executable, str(here / "run_composed_cell_controls.py"),
                               "--repo-root", str(repo), "--expected-head", args.expected_head,
                               "--cargo-proxy", str(args.cargo_proxy),
                               "--provider-receipt", str(args.provider_receipt),
                               "--build-receipt", str(args.build_prefix) + ".json",
                               "--output", str(out / "cell-controls")]),
        ]
        common.write_json(out / "command-plan.json", {"plans": plans})
        for label, argv in plans:
            print(json.dumps({"event": "gate-start", "label": label}), flush=True)
            result = common.run_capture(argv, repo, env, out / "driver" / label)
            summary = out / label / "summary.json"
            row = {"label": label, "execution": result, "passed": False}
            if summary.is_file():
                value = json.loads(summary.read_text())
                row["summary_identity"] = common.file_receipt(summary)
                row["child_passed"] = value.get("passed")
                row["source_bound"] = (
                    (value.get("source_before") or {}).get("receipt") == source
                    and (value.get("source_after") or {}).get("receipt") == source)
                row["passed"] = (row["source_bound"] and value.get("passed") is True
                                 and common.capture_passed(result))
                row["observed"] = {key: value[key] for key in (
                    "dispatched_selector_count", "confirmed_named_execution_count",
                    "passed_selector_count", "executed_component_commands",
                    "passed_component_commands", "native_failed_component_commands") if key in value}
                if value.get("full_library"):
                    row["full_library"] = value["full_library"].get("verdict")
                row["collector_errors"] = value.get("errors", [])
            else:
                row["error"] = "child produced no terminal summary"
            report["steps"].append(row)
            common.write_json(out / (label + ".gate.json"), row)
            print(json.dumps({"event": "gate-finish", "label": label,
                              "native_exit": result["native_exit"], "passed": row["passed"]}), flush=True)
            checkpoint = common.source_checkpoint(repo, args.expected_head, out, "after-" + label, env)
            common.require(checkpoint["passed"] and checkpoint["receipt"] == source,
                           "source changed; stop subsequent gates")

        label = "strict-workspace-clippy"
        clippy = [str(args.cargo_proxy), "+1.95.0", "clippy", "--locked", "--offline",
                  "--manifest-path", "trillionnium/Cargo.toml", "--workspace",
                  "--all-targets", "--all-features", "--", "-D", "warnings"]
        argv = [sys.executable, str(repo / "scripts/ci/record_pq_native_command.py"),
                "--kind", "head", "--candidate", args.expected_head,
                "--tested", args.expected_head, "--label", label,
                "--output", str(out / "clippy"), "--", *clippy]
        print(json.dumps({"event": "gate-start", "label": label}), flush=True)
        result = common.run_capture(argv, repo, env, out / "driver" / label)
        receipt = out / "clippy" / (label + ".json")
        row = {"label": label, "execution": result, "passed": False}
        if receipt.is_file():
            value = json.loads(receipt.read_text())
            log = out / "clippy" / (label + ".log")
            identity = common.file_receipt(log)
            row["receipt"] = value
            row["receipt_identity"] = common.file_receipt(receipt)
            row["log_identity"] = identity
            row["passed"] = (
                common.capture_passed(result) and value.get("status") == "command_succeeded"
                and value.get("exit_code") == 0 and value.get("before") == value.get("after") == source
                and value.get("argv") == clippy and value.get("log_file") == log.name
                and value.get("log_sha256") == identity["sha256"]
                and value.get("log_bytes") == identity["size"])
        report["steps"].append(row)
        common.write_json(out / (label + ".gate.json"), row)
        print(json.dumps({"event": "gate-finish", "label": label,
                          "native_exit": result["native_exit"], "passed": row["passed"]}), flush=True)
    except Exception:
        report["errors"].append(traceback.format_exc())
    finally:
        try:
            report["source_after"] = common.source_checkpoint(
                repo, args.expected_head, out, "source-after", env)
            common.require(report["source_after"]["passed"]
                           and report["source_before"] is not None
                           and report["source_before"]["receipt"] == report["source_after"]["receipt"],
                           "final source identity differs")
        except Exception:
            report["errors"].append(traceback.format_exc())
        report["finished_utc"] = common.utc_now()
        report["passed"] = (not report["errors"] and len(report["steps"]) == 4
                            and all(row["passed"] for row in report["steps"]))
        common.write_json(out / "summary.json", report)
    print(json.dumps({"passed": report["passed"], "steps": [
        {"label": row["label"], "passed": row["passed"]} for row in report["steps"]],
        "errors": report["errors"]}), flush=True)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
