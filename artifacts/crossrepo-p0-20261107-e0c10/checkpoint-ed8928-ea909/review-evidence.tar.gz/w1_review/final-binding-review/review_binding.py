#!/usr/bin/env python3
"""Check retained source/reference binding evidence, without running product code.

Requires the locally retained source receipts. The public whitelist deliberately
omits duplicate source bodies and archives; exact upstream paths/pins are emitted.
"""
import copy
import hashlib
import json
from pathlib import Path
import tomllib

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
CHECKS = []


def read(path):
    return json.loads((ROOT / path).read_bytes())


def pin(path):
    p = ROOT / path
    data = p.read_bytes()
    return {"path": str(p.relative_to(ROOT)), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def require(value, label):
    if not value:
        raise AssertionError(label)
    CHECKS.append(label)


def content_pin(data, path):
    return {"path": path, "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "git_blob_sha": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def canonical_hash(value):
    other = copy.deepcopy(value)
    del other["binding_sha256"]
    return hashlib.sha256(json.dumps(other, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def json_changes(old, new, path=""):
    if isinstance(old, dict) and isinstance(new, dict):
        rows = []
        for key in sorted(set(old) | set(new)):
            here = f"{path}/{key}"
            if key not in old or key not in new:
                rows.append({"path": here, "old": old.get(key), "new": new.get(key)})
            else:
                rows.extend(json_changes(old[key], new[key], here))
        return rows
    return [] if old == new else [{"path": path, "old": old, "new": new}]


BIND_PATH = "candidate-evidence/CANDIDATE_SOURCE_BINDING.json"
V1_PATH = "candidate-evidence/CANDIDATE_SOURCE_BINDING_V1.json"
GRAPH_PATH = "pq-recovery/evidence/CANDIDATE_GRAPH_ED8928DB7428_EA909.json"
FREEZE_PATH = "pq-recovery/hepta/v4-freeze-evidence/frozen-source.json"
SELECTED_PATH = "pq-recovery/hepta/v4-freeze-evidence/selected-source-blobs.json"
MATERIALS_PATH = "storage-review/evidence/MATERIALS_MANIFEST.json"
MIGRATION_PATH = "storage-review/evidence/SOURCE_REVIEW_MIGRATION_ED8928_EA909.json"
MODEL_PATH = "storage-review/evidence/MODEL_LOOP_REVIEW.json"
MAP_PATH = "w1_review/gate-map-ea909/mapping.json"
NATIVE_PATH = "w1_review/native-ea909-42329179267/analysis.json"
binding, v1, graph, freeze = map(read, [BIND_PATH, V1_PATH, GRAPH_PATH, FREEZE_PATH])
chain = binding["source_pair"]["chain"]
hepta = binding["source_pair"]["hepta"]
require(pin(BIND_PATH)["sha256"] == "c0d71a2232da962ade261b82abb86b220dc5af560d6c21ea1eea930c2d30a0b6", "binding V2 exact bytes")
require(pin(V1_PATH)["sha256"] == "c373ec183dbe028daead262e7e98cdb381757f7ef0eba1c604e2641c25c00782", "preserved V1 exact bytes")
require(canonical_hash(binding) == binding["binding_sha256"], "V2 canonical binding hash")
require(canonical_hash(v1) == v1["binding_sha256"], "V1 canonical binding hash")
require(pin(GRAPH_PATH)["sha256"] == "1e1be7f6ef963a8ffff551931455b674d614fe424d3817dc03d06e80140898d7", "immutable source graph unchanged")
changes = json_changes(v1, binding)
allowed_changes = {
    "/schema", "/binding_sha256", "/description_revision",
    "/cryptographic_material/hepta_authority_profile/both_actual_signatures_checked_every_call",
    "/cryptographic_material/hepta_authority_profile/both_actual_signatures_checked_on_every_successful_validation",
    "/cryptographic_material/hepta_authority_profile/signature_failure_short_circuit_preserved",
    "/cryptographic_material/hepta_authority_profile/failure_path_scope",
}
require({r["path"] for r in changes} == allowed_changes, "only the seven description/hash/schema changes from V1")
for area in ("source_pair", "dependencies", "reference_model_material", "required_execution_evidence", "scope"):
    require(binding[area] == v1[area], f"V1/V2 {area} unchanged")
merges = read("w1_review/final-binding-review/merge-readback.json")
for name, source in (("chain", chain), ("hepta", hepta)):
    actual = merges[name]
    require(actual["sha"] == source["prospective_merge"] and actual["tree"] == source["tree"], f"{name} direct merge SHA/tree")
    require(actual["ordered_parents"] == source["ordered_parents"] == [source["base"], source["head"]], f"{name} direct ordered merge parents")
require(graph["pair"] == freeze, "immutable graph pair equals actual frozen-source receipt")
require(freeze["chain_sha"] == chain["head"] and freeze["chain_tree"] == chain["tree"] and freeze["hepta_sha"] == hepta["head"] and freeze["hepta_tree"] == hepta["tree"], "graph/freeze exact cross-repository pair")
require(graph["generators"]["manual_lock_edits"] is False and all(r["command_exit"] == 0 for r in graph["generators"]["records"].values()), "actual generator receipts succeeded, no claimed manual lock edit")
selected_rows = read(SELECTED_PATH)["selected"]
selected = {r["path"]: r for r in selected_rows if not r.get("missing")}
missing_selected = [r["path"] for r in selected_rows if r.get("missing")]
require(len(selected_rows) == 86 and len(selected) == 79 and len(missing_selected) == 7, "selected inventory explicitly has 79 present plus seven missing paths; 86 records")
require(pin(SELECTED_PATH)["sha256"] == freeze["selected_source_blobs_sha256"], "selected blob inventory bound to freeze")

source_files = []
local_locks = {"MODULE.bazel.lock": "MODULE.bazel.lock", "codex-rs/Cargo.lock": "Cargo.lock", "codex-rs/hepta-fleet/Cargo.toml": "hepta-fleet-Cargo.toml"}
for path, local in local_locks.items():
    data = (OUT / "private-inputs" / local).read_bytes()
    observed = content_pin(data, path)
    wanted = binding["dependencies"]["hepta_lock_and_pin_files"][path]
    require(all(observed[k] == wanted[k] for k in ("bytes", "sha256")), f"fresh committed Hepta bytes: {path}")
    require(observed["git_blob_sha"] == selected[path]["git_blob"] == freeze["source_files"][path]["blob"], f"fresh Hepta blob: {path}")
    source_files.append({**observed, "repository": hepta["repository"], "head": hepta["head"], "observation": "direct GitHub committed source bytes"})
hepta_lock = tomllib.loads((OUT / "private-inputs/Cargo.lock").read_text())
fleet = tomllib.loads((OUT / "private-inputs/hepta-fleet-Cargo.toml").read_text())
require(fleet["dependencies"]["trnm-release-bundle"]["rev"] == chain["head"], "fleet direct dependency exact revision")
facts = json.loads((OUT / "private-inputs/MODULE.bazel.lock").read_bytes())["facts"]["@@rules_rs+//rs:extensions.bzl%crate"]
bazel_chain = {key: json.loads(value) for key, value in facts.items() if "Trillionnium-Chain" in key}
cargo_chain = {r["name"]: r for r in hepta_lock["package"] if "Trillionnium-Chain" in r.get("source", "")}
require(len(bazel_chain) == len(cargo_chain) == len(graph["dependency_edges"]) == 3, "exactly three actual Cargo/Bazel Chain edges")
for edge in graph["dependency_edges"]:
    require(cargo_chain[edge["name"]]["source"] == edge["Cargo_source"], f"Cargo edge source: {edge['name']}")
    require(bazel_chain[edge["Bazel_metadata_key"]]["strip_prefix"] == edge["Bazel_strip_prefix"], f"Bazel edge strip prefix: {edge['name']}")
    require(edge["commit"] == chain["head"] and edge["tree"] == chain["tree"], f"graph actual checkout identity: {edge['name']}")
require(binding["dependencies"]["hepta_actual_chain_checkouts"] == graph["pair"]["actual_chain_checkouts"], "binding actual checkout records match graph")
require(binding["dependencies"]["hepta_MODULE_bazel"] == freeze["MODULE_bazel"], "MODULE.bazel unchanged receipt identity")

chain_cargo = read("candidate-evidence/chain-ea909-cargo-source.json")
require(chain_cargo["head"] == chain["head"], "Chain dependency source receipt exact head")
for requested, key in zip(binding["dependencies"]["chain_lock_and_workspace"], ("lock", "cargo")):
    observed = content_pin(chain_cargo[key]["content"].encode(), requested["path"])
    require(observed == requested, f"Chain actual source bytes: {requested['path']}")
    source_files.append({**observed, "repository": chain["repository"], "head": chain["head"], "observation": "retained exact GitHub source content"})
chain_lock = tomllib.loads(chain_cargo["lock"]["content"])
for item in binding["cryptographic_material"]["chain_selected_locked_libraries"]:
    require([p for p in chain_lock["package"] if (p["name"], p["version"]) == (item["name"], item["version"])] == [item], f"actual Chain selected lock entry {item['name']} {item['version']}")
authority = binding["cryptographic_material"]["hepta_authority_profile"]
require([p for p in hepta_lock["package"] if p["name"] == "ml-dsa"] == authority["ml_dsa_lock_entries"], "actual Hepta ML-DSA lock entry")
profile_source = read("candidate-evidence/chain-ea909-profile-source.json")
require(profile_source["head"] == chain["head"], "Chain profile source exact head")
profiles = {p["path"]: p for p in profile_source["entries"]}
for requested in binding["cryptographic_material"]["chain_profile_source_files"]:
    observed = content_pin(profiles[requested["path"]]["content"].encode(), requested["path"])
    require(observed == requested, f"actual Chain profile bytes/blob: {requested['path']}")
    source_files.append({**observed, "repository": chain["repository"], "head": chain["head"], "observation": "retained exact GitHub source content"})
ancillary = ROOT / "pq-recovery/hepta/prepared-reuse-review/ancillary-current"
current = ROOT / "pq-recovery/coverage_sources/hepta-private-ci" / hepta["head"]
formatted = ROOT / "w1_review/hepta-prepared-3bc/formatted"
for requested in authority["actual_profile_source_pins"]:
    candidates = [current / requested["path"], formatted / requested["path"], ancillary / requested["path"]]
    data = next(p for p in candidates if p.exists()).read_bytes()
    observed = content_pin(data, requested["path"])
    require(observed["sha256"] == requested["sha256"] and observed["git_blob_sha"] == requested["blob"] == selected[requested["path"]]["git_blob"], f"actual Hepta authority bytes/blob: {requested['path']}")
    source_files.append({**observed, "repository": hepta["repository"], "head": hepta["head"], "observation": "retained source bytes matched to actual frozen selected blob"})
for name, path, blob in [
    ("tls-context.rs", "trillionnium/crates/trnm-pon-node/src/ingress/pq_network/tls/context.rs", "5e881c29511a7cadc52fd9ba592f6fd4f4a3cd7e"),
    ("chain-pq-auth.rs", "trillionnium/crates/trnm-crypto-primitives/src/pq_auth.rs", "1af30c047ce4a3420d5929ad8bf59f7fe7d9ca7f"),
]:
    observed = content_pin((OUT / "private-inputs" / name).read_bytes(), path)
    require(observed["git_blob_sha"] == blob, f"direct additional profile source blob: {path}")
    source_files.append({**observed, "repository": chain["repository"], "head": chain["head"], "observation": "direct GitHub committed source bytes"})
provider = read("candidate-evidence/v3-native-preparation.json")
require(provider["receipt"]["source"] == chain["head"] and provider["receipt"]["tree"] == chain["tree"], "provider preparation receipt source pair")
require(provider["receipt"]["provider"] == binding["cryptographic_material"]["desktop_provider_actual_files"], "provider file hashes/sizes match actual preparation receipt")

materials, migration, model, mapping, native = map(read, [MATERIALS_PATH, MIGRATION_PATH, MODEL_PATH, MAP_PATH, NATIVE_PATH])
require(pin(MATERIALS_PATH) == binding["reference_model_material"]["manifest"], "exact reference material manifest")
require(materials["file_count"] == len(materials["files"]) == binding["reference_model_material"]["files"] == 16, "all 16 material files retained")
require(sum(r["bytes"] for r in materials["files"]) == sum(r["observed_bytes"] for r in materials["files"]) == materials["unique_payload_file_bytes"] == binding["reference_model_material"]["bytes"], "all 91512155 material bytes accounted")
require(all(r["regular_file"] and r["sha256"] == r["observed_sha256"] for r in materials["files"]), "material descriptor observations match declared identities")
require(materials["authority"] == model["authority"] == binding["reference_model_material"]["authority"] == "DENY_ALL", "model material remains DENY_ALL")
require(all(materials[k] is False for k in ("adoption_performed", "model_execution_performed", "training_performed")), "no material adoption/execution/training claimed")
require(all(v is False for v in model["actions_performed"].values()), "model review authorizes no actions")
require(migration["pair"] == {"chain_commit": chain["head"], "chain_tree": chain["tree"], "hepta_commit": hepta["head"], "hepta_tree": hepta["tree"]}, "model source review migration exact final pair")
require(migration["model_source_subset"]["records"] == len(migration["model_source_subset"]["unchanged_reviewed_sources"]) == 14, "14 model/artifact source observations mapped to final source")
require(binding["reference_model_material"]["loaded_by_current_ordinary_entry"] is False and binding["scope"]["ordinary_current_model_runtime_bound"] is False, "source/reference binding does not claim ordinary runtime")
require(binding["reference_model_material"]["source_owner_grant"] is None and binding["reference_model_material"]["training_or_execution_authorized_by_this_binding"] is False, "binding grants no model authorization")

budget = binding["required_execution_evidence"]
original = mapping["original_budget_lineage"]
require(budget == v1["required_execution_evidence"] and budget["old_passes_inherited"] is False, "original denominators unchanged and no historical pass transfer")
require(len(original["rows"]) == 15 and all(r["nine_f_to_ea909_same_blob"] for r in original["rows"]), "all 15 retained original-budget source files same as 9f")
require(len(original["differences_9f_to_ea909_in_original_attack_resource_time_denominator_declarations"]) == 0, "no changed attack/resource/time/denominator declaration")
f0 = original["original_f0"]
require(budget["public_F0_confirmation_rounds"] == f0["planned_confirmations"] == 6 and budget["public_F0_packet_exposures"] == f0["planned_business_packet_exposures"] == 42 and budget["public_F0_confirmation_slo_seconds"] * 10**9 == f0["four_second_slo_ns"], "original F0 six/42/four-second denominator")
require(native["candidate"] == chain["head"] and native["tree"] == chain["tree"] and native["planned_confirmations"] == budget["public_native_campaign_confirmation_rounds"] == 27 and len(native["reports"]) == budget["public_native_campaign_complete_runs"] == 3, "current actual native three-campaign/27 denominator")
require(native["exact_source_schedule"]["window_seconds"] == budget["public_native_campaign_phase_seconds"] == 30 and native["four_second_f0_or_from_zero_gate_replaced"] is False, "native 30-second phase does not replace four-second F0/from-zero")
require(native["confirmed_before_original_30s_end"] + native["observed_not_confirmed"] + native["unobserved_planned_rounds"] == 27, "all current native success/failure/unobserved outcomes included")
daemon = graph["original_budget_binding"]
require((budget["hepta_original_daemon_recoveries"], budget["hepta_original_daemon_timeout_seconds"], budget["hepta_original_daemon_retry_count"]) == (daemon["daemon_real_sequential_recoveries"], daemon["case_timeout_seconds"], daemon["configured_retries"]) == (31, 60, 1), "original Hepta 31 recoveries/60-second/retry-one budget")
require(daemon["daemon_unknown_records"] == 32 and daemon["build_jobs"] == 2, "32 UNKNOWN records and two build jobs retained")
runner_path = "candidate-evidence/v2-completed-native/runner-controlled-v3.py"
runner = (ROOT / runner_path).read_text()
require("len(native_rows) == 89" in runner and "len(set(expected)) == 25" in runner, "original harness enforces 89 native selectors and 25 packaging controls")
require(budget["chain_original_native_selectors"] == 89 and budget["chain_packaging_controls"] == 25, "native/packaging declared denominator matches retained harness")
require(all(p["only_task_path_changed"] for p in provider["receipt"]["path_only_runner_copies"]), "v3 runner preparation reports task-path-only copy")
require(budget["chain_sqlite_original_commands"] == mapping["roster_and_harness_changes"]["sqlite_original_phase_count"] == 4 and budget["chain_sqlite_additional_foreign_loader_controls"] == mapping["roster_and_harness_changes"]["sqlite_extra_loader_phase_count"] == 2, "four original SQLite commands plus two separately counted additions")
require(binding["scope"]["acceptance"] == "HOLD" and binding["scope"]["external_W1_quantum_acceptance"] is False and binding["scope"]["production_activation"] is False and binding["scope"]["complete_production_candidate_qualified"] is False, "binding keeps HOLD and all production/external claims false")

report = {
    "schema": "independent-internal-crossrepo-source-reference-binding-review-v2",
    "reviewer": "w1_quantum_review internal parallel source reviewer; not external certification",
    "verdict": "CONSISTENT_WITH_STATED_SOURCE_AND_REFERENCE_MATERIAL_SCOPE",
    "source_pair": binding["source_pair"],
    "binding_v2": {**pin(BIND_PATH), "binding_sha256": binding["binding_sha256"]},
    "preserved_binding_v1": {**pin(V1_PATH), "binding_sha256": v1["binding_sha256"]},
    "v1_to_v2_exact_changes": changes,
    "resolved_description_issue": {
        "status": "RESOLVED_BY_DESCRIPTION_ONLY_V2",
        "successful_validation": "Both the grant and H7 artifact undergo actual PQ signature verification on every successful validation.",
        "rejected_validation": "Original validate_for/shape or first-signature failure short-circuits; a rejected call is not claimed to execute both signatures.",
        "frozen_graph_and_source_unchanged": True,
        "original_graph_shorthand": "The immutable graph/source comment every_call shorthand is scoped to successful validation by the V2 description; it is not literal unconditional execution.",
        "authorization_not_cached": "Exact complete raw policy byte equality permits borrowing immutable public-key preparation only; different policy/classical hint reconstructs original verifier; current owner/clock/role/revocation/root/nonce/effect decisions remain separate.",
    },
    "direct_merge_readback": merges,
    "graph": {**pin(GRAPH_PATH), "dependency_edges": graph["dependency_edges"], "fresh_committed_lock_byte_check": True, "actual_checkout_identity_receipt": pin(FREEZE_PATH), "selected_source_blob_receipt": pin(SELECTED_PATH), "selected_inventory": {"records": len(selected_rows), "present_blobs": len(selected), "missing_paths": missing_selected}, "manual_lock_edits": graph["generators"]["manual_lock_edits"]},
    "source_files_independently_byte_checked": source_files,
    "crypto_profile": {
        "TLS_transport": binding["cryptographic_material"]["TLS_transport"],
        "TLS_group_observation_scope": "Single X25519MLKEM768 group is configured in the private immutable TLS1.3 context. safe rust-openssl 0.10.81 has no negotiated-group getter: successful-context reasoning is configuration inference, not a separate observed negotiated-group value.",
        "TPQ1": binding["cryptographic_material"]["native_TPQ1_verification"],
        "provider_scope": "Hashes/sizes match actual desktop preparation receipt. This source descriptor does not itself prove every eventual process loaded these provider bytes.",
        "provider_receipt": pin("candidate-evidence/v3-native-preparation.json"),
        "chain_locked_libraries": binding["cryptographic_material"]["chain_selected_locked_libraries"],
        "hepta_ml_dsa_lock_entries": authority["ml_dsa_lock_entries"],
        "external_independent_cryptographic_certification": "NOT_EVIDENCED",
    },
    "reference_model": {
        **binding["reference_model_material"],
        "material_status": materials["status"],
        "source_migration_receipt": pin(MIGRATION_PATH),
        "model_and_artifact_source_files_unchanged": 14,
        "ordinary_entry": model["ordinary_entry"],
        "net_benefit_status": model["independent_unseen_net_benefit"]["status"],
        "runtime_binding_missing": "No ordinary authorized V13 selection, CURRENT/FinalUse, adoption, restart, next-task use or independently unseen net benefit is established. Frozen source and reference material identities are not that runtime loop.",
    },
    "original_denominators": {
        **budget, "hepta_unknown_records": 32, "hepta_build_jobs": 2,
        "original_public_limits": original["original_four_second"]["host_limits"],
        "original_four_second_pressure_workers": original["original_four_second"]["pressure_workers"],
        "F0_phase_seconds": f0["phase_seconds"], "F0_attackers": f0["attackers"],
        "F0_slo_starts_at_scheduled_offset": f0["slo_starts_at_scheduled_offset"],
        "budget_source_mapping": pin(MAP_PATH),
        "historical_origin_comparison": pin("w1_review/original-630-vs-9f77-budget-comparison.json"),
        "native_and_packaging_harness": pin(runner_path),
        "observation_scope": "Declaration/retained evidence consistency only. No native or source-gate result is created or inherited by this review.",
    },
    "current_native_outcome_separate_from_source_binding": {
        "analysis": pin(NATIVE_PATH), "run_id": native["run_id"], "run_attempt": native["run_attempt"],
        "job_id": native["job_id"], "artifact_id": native["artifact_id"],
        "planned": native["planned_confirmations"], "confirmed": native["confirmed_before_original_30s_end"],
        "observed_failed": native["observed_not_confirmed"], "unobserved": native["unobserved_planned_rounds"],
        "complete_success": native["complete_success"], "binary": native["original_campaign_result"]["binary"],
        "external_acceptance": False, "old_results_inherited": False,
    },
    "qualification": {"source_reference_identity_consistent": True, "ordinary_model_runtime_bound": False,
                      "whole_system_qualified": False, "external_W1_quantum_acceptance": False,
                      "production_activation": False, "independent_custody_qualified": False,
                      "original_service_failure_closed": False},
    "verification": {"kind": "LOCAL_RETAINED_EVIDENCE_CONSISTENCY_CHECKS_ONLY", "assertions": CHECKS,
                     "workflows_started": 0, "native_runs_started": 0, "builds_started": 0,
                     "frozen_source_edits": 0},
}
(OUT / "review.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"review": pin("w1_review/final-binding-review/review.json"), "consistency_assertions": len(CHECKS), "verdict": report["verdict"]}))
