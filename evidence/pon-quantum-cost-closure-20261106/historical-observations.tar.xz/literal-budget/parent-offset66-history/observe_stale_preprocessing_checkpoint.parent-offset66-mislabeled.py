"""Intentionally reuse a stale five-block checkpoint, before adding a guard."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    repo = parser.parse_args().repo.resolve()
    sys.path.insert(0, str(repo / "formal/pon-nakamoto-v1"))
    from test_w1_quantum_oracle import fixture
    from w1_quantum_oracle import FixedTemplate, h_bytes
    from w1_quantum_primitives import INITIAL_STATE, digest_bytes, message_value, sha_compress

    def padded(frame):
        return frame + b"\x80" + bytes((55 - len(frame)) % 64) + (8 * len(frame)).to_bytes(8, "big")

    def compress(data, state=INITIAL_STATE):
        for offset in range(0, len(data), 64):
            state = sha_compress(message_value(data[offset:offset + 64]), state)
        return state

    plain, growth = fixture(nonce_bits=2), fixture(profile="PGH2", nonce_bits=2)
    cases = []
    for name, offset in (("parent", 66), ("target", 118), ("timestamp", 110)):
        header = bytearray(plain.header)
        header[offset] ^= 1
        cases.append((name, FixedTemplate.from_header(bytes(header), plain.a, plain.b,
                                                      plain.nonce_bits, plain.shape)))
    cases.append(("profile", growth))
    b = ((plain.b[0] + 1) % plain.shape.q,)
    field = lambda values: struct.pack("<" + "I" * len(values), *values)
    header = bytearray(plain.header)
    header[278:310] = hashlib.sha256(h_bytes(b"task", field(plain.a), field(b))).digest()
    cases.append(("task_PNH1", FixedTemplate.from_header(bytes(header), plain.a, b,
                                                        plain.nonce_bits, plain.shape)))
    left = h_bytes(plain.challenge_tag, plain.header_for(0))
    checkpoint = compress(left[:320])
    rows = []
    for name, changed in cases:
        frame = h_bytes(changed.challenge_tag, changed.header_for(0))
        expected = hashlib.sha256(frame).hexdigest()
        stale = digest_bytes(compress(padded(frame)[320:], checkpoint)).hex()
        if stale == expected:
            raise AssertionError("negative control unexpectedly passed: " + name)
        rows.append({"case": name, "expected_challenge_sha256": expected,
                     "stale_checkpoint_challenge_sha256": stale,
                     "unguarded_reuse_observation": "FAIL_HASHLIB_EQUALITY_EXPECTED"})
    print(json.dumps({"control": "deliberately invalid blanket five-block reuse",
                      "existing_repository_bug_claim": False, "negative_controls": rows,
                      "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
                     indent=2))


if __name__ == "__main__":
    main()
