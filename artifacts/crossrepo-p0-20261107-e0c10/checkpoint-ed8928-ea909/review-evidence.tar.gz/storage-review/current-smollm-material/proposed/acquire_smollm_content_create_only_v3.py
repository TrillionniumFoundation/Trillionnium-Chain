#!/usr/bin/env python3
"""Acquire only the locked public SmolLM bytes; never execute or authorize them.

PROPOSAL: launch only after the coordinator has recorded that both native timing
critical stages have ended. This program performs one new content acquisition,
not a replay of any historical or UNKNOWN invocation. The external launcher must
also enforce this new acquisition's 35-second total deadline and preserve every
outcome. Historical cold-start CPU/memory/owner constraints are unrecovered;
only actually observed current launch limits may be bound to this new attempt.
"""
import time
ENTRY_NS = time.monotonic_ns()

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import resource
import signal
import stat
import struct
import sys
import urllib.error
import urllib.parse
import urllib.request

BUDGET_NS = 35_000_000_000
LOCK_SHA256 = "775328b22b06fc23077a89e61bda646a6de612b3e352d0c915a5d6c00384908e"
CHAIN = "ea909124cc460f364bd17b009073306014133f48"
HEPTA = "ed8928db742825716791d45dca1158385c55737d"
REVISION = "12fd25f77366fa6b3b4b768ec3050bf629380bac"
MODEL = "HuggingFaceTB/SmolLM2-135M-Instruct"
CHUNK = 1_048_576
ROOT_FD = None
ROOT_PATH = None
PLANNED_MEMBER_NAMES = (
    "adapter/artifact.safetensors", "adapter/target-contract.json",
    "adapter/wrapped-adapter.json", "base/README.md", "base/config.json",
    "base/generation_config.json", "base/material-manifest.json",
    "base/model.safetensors", "base/special_tokens_map.json",
    "base/tokenizer.json", "base/tokenizer_config.json",
)
ROWS = [dict(name=name, status="LOCK_NOT_YET_VERIFIED", written_bytes=0,
             response_body_bytes_returned_to_reader=0) for name in PLANNED_MEMBER_NAMES]
LOCK_VERIFIED = False
ACTIVE = None
EVENT_FD = None
MEMBER_FETCH_ATTEMPTS = 0
HTTPS_REQUESTS = []
RECEIVED_BYTES = 0
READBACK_BYTES = 0
READBACK_BYTES_ATTEMPTED = 0
ACQUISITION_FINISHED_NS = None
REDIRECTS = []
IO_START = None
FLAGS = os.O_RDONLY | os.O_CLOEXEC | os.O_NONBLOCK | os.O_NOFOLLOW


class AcquisitionDeadline(Exception):
    pass


def deadline(_signal=None, _frame=None):
    raise AcquisitionDeadline("35-second total acquisition deadline")


def check_deadline():
    remaining = (ENTRY_NS + BUDGET_NS - time.monotonic_ns()) / 1_000_000_000
    if remaining <= 0:
        deadline()
    return remaining


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode()


def sha256(value):
    return hashlib.sha256(value).hexdigest()


def domain_hash(tag, value):
    tag = tag.encode()
    return sha256(b"TRNM-PON1\0" + struct.pack("<H", len(tag)) + tag +
                  struct.pack("<I", len(value)) + value)


def identity(st):
    return [st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns,
            st.st_ctime_ns, st.st_nlink]


def relative_parts(value):
    path = PurePosixPath(value)
    if path.is_absolute() or not path.parts or any(p in ("", ".", "..") for p in path.parts):
        raise ValueError("unsafe relative path")
    if str(path) != value:
        raise ValueError("noncanonical relative path")
    return path.parts


def directory_at(parent_fd, name):
    return os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC |
                   os.O_NOFOLLOW, dir_fd=parent_fd)


def directory_absolute(value):
    path = Path(value)
    if not path.is_absolute() or ".." in path.parts:
        raise ValueError("absolute, non-parent-traversing path required")
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        for part in path.parts[1:]:
            next_fd = directory_at(fd, part)
            os.close(fd)
            fd = next_fd
        return fd
    except BaseException:
        os.close(fd)
        raise


def parent_at(root_fd, value):
    parts = relative_parts(value)
    fd = os.dup(root_fd)
    try:
        for part in parts[:-1]:
            next_fd = directory_at(fd, part)
            os.close(fd)
            fd = next_fd
        return fd, parts[-1]
    except BaseException:
        os.close(fd)
        raise


def read_regular(root_fd, name, expected_bytes, expected_sha=None):
    parent_fd, leaf = parent_at(root_fd, name)
    fd = None
    try:
        fd = os.open(leaf, FLAGS, dir_fd=parent_fd)
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size != expected_bytes:
            raise ValueError("regular single-link file size required: " + name)
        data = bytearray()
        while len(data) <= expected_bytes:
            check_deadline()
            piece = os.read(fd, min(CHUNK, expected_bytes + 1 - len(data)))
            if not piece:
                break
            data.extend(piece)
        after = os.fstat(fd)
        if identity(before) != identity(after) or len(data) != expected_bytes:
            raise ValueError("source changed or length differs: " + name)
        value = bytes(data)
        if expected_sha is not None and sha256(value) != expected_sha:
            raise ValueError("SHA256 differs: " + name)
        return value, identity(after)
    finally:
        if fd is not None:
            os.close(fd)
        os.close(parent_fd)


def write_all(fd, raw):
    view = memoryview(raw)
    while view:
        check_deadline()
        count = os.write(fd, view[:CHUNK])
        if count <= 0:
            raise OSError("short write")
        view = view[count:]


def measure_regular(root_fd, name, expected_bytes, expected_sha):
    """Hash the complete output through one descriptor, bounded to one chunk."""
    global READBACK_BYTES_ATTEMPTED
    parent_fd, leaf = parent_at(root_fd, name)
    fd = None
    try:
        fd = os.open(leaf, FLAGS, dir_fd=parent_fd)
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size != expected_bytes:
            raise ValueError("readback regular file size differs: " + name)
        count = 0
        digest = hashlib.sha256()
        while count <= expected_bytes:
            check_deadline()
            piece = os.read(fd, min(CHUNK, expected_bytes + 1 - count))
            if not piece:
                break
            count += len(piece)
            READBACK_BYTES_ATTEMPTED += len(piece)
            digest.update(piece)
        after = os.fstat(fd)
        measured_sha = digest.hexdigest()
        if (identity(before) != identity(after) or count != expected_bytes or
                measured_sha != expected_sha):
            raise ValueError("complete readback differs: " + name)
        return count, measured_sha, identity(after)
    finally:
        if fd is not None:
            os.close(fd)
        os.close(parent_fd)


def new_file(root_fd, name):
    parent_fd, leaf = parent_at(root_fd, name)
    try:
        return os.open(leaf, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                       os.O_CLOEXEC | os.O_NOFOLLOW, 0o600, dir_fd=parent_fd)
    finally:
        os.close(parent_fd)


def emit_event(kind, **values):
    record = dict(kind=kind, elapsed_ns=time.monotonic_ns()-ENTRY_NS, **values)
    if EVENT_FD is not None:
        write_all(EVENT_FD, canonical(record) + b"\n")
        os.fsync(EVENT_FD)


def io_counters():
    try:
        return {key: int(value) for key, value in
                (line.split(": ") for line in Path("/proc/self/io").read_text().splitlines())}
    except (OSError, ValueError):
        return None


def allowed_https(url):
    parsed = urllib.parse.urlsplit(url)
    host = (parsed.hostname or "").lower()
    if parsed.scheme != "https" or parsed.username or parsed.password or parsed.port not in (None, 443):
        raise ValueError("HTTPS public source required")
    if not (host == "huggingface.co" or host.endswith(".huggingface.co")
            or host == "hf.co" or host.endswith(".hf.co")):
        raise ValueError("unexpected public download redirect host: " + host)
    return parsed


class LockedRedirects(urllib.request.HTTPRedirectHandler):
    max_redirections = 10
    max_repeats = 4

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        row = dict(member=ACTIVE, status=int(code), hostname=None,
                   decision="BEFORE_PUBLIC_HTTPS_POLICY")
        REDIRECTS.append(row)
        try:
            emit_event("REDIRECT_POLICY_ATTEMPT", member=ACTIVE, status=int(code))
            parsed = allowed_https(newurl)
            row["hostname"] = parsed.hostname
            check_deadline()
            result = super().redirect_request(req, fp, code, msg, headers, newurl)
        except BaseException as error:
            row["decision"] = "REFUSED_OR_INTERRUPTED"
            row["error_type"] = type(error).__name__
            raise
        row["decision"] = "REQUEST_CONSTRUCTED" if result is not None else "NOT_FOLLOWED"
        emit_event("REDIRECT_POLICY_DECISION", **row)
        return result


class ObservedHTTPS(urllib.request.HTTPSHandler):
    def https_open(self, req):
        parsed = allowed_https(req.full_url)
        check_deadline()
        row = dict(index=len(HTTPS_REQUESTS) + 1, member=ACTIVE,
                   hostname=parsed.hostname, path=parsed.path,
                   started_ns=time.monotonic_ns() - ENTRY_NS,
                   status="HANDLER_ENTERED_BEFORE_DURABLE_ADMISSION")
        HTTPS_REQUESTS.append(row)
        try:
            # No transport call precedes this persisted admission event. If the
            # process later dies, it remains an admitted/unfinished attempt, not
            # proof of a completed transfer or of zero network bytes.
            emit_event("HTTPS_ATTEMPT_ADMITTED", **row)
            row["status"] = "DURABLE_ADMISSION_TRANSPORT_PENDING"
            response = super().https_open(req)
        except BaseException as error:
            row["status"] = "TRANSPORT_FAILED_OR_INTERRUPTED"
            row["error_type"] = type(error).__name__
            raise
        row["status"] = "RESPONSE_HEADERS_RECEIVED"
        row["response_status"] = response.status
        row["headers_received_ns"] = time.monotonic_ns() - ENTRY_NS
        emit_event("HTTPS_RESPONSE_HEADERS", **row)
        return response


def derive(lock, inputs):
    family = json.loads(inputs["family"])
    target_raw = inputs["publicTarget"]
    target = json.loads(target_raw)
    header = inputs["initialHeader"]
    header_json = json.loads(header)
    plan = json.loads(inputs["plan"])
    cid = domain_hash("target-decoder-adapter-contract-v1", target_raw)
    if cid != lock["public_initial_contract_digest"] or canonical(target) != target_raw:
        raise ValueError("public target domain identity")
    if sha256(inputs["publicProfile"]) != lock["public_initial_compatibility_sha256"]:
        raise ValueError("public initial compatibility profile")
    factors = {key: value for key, value in header_json.items() if key != "__metadata__"}
    ranges = sorted(value["data_offsets"] for value in factors.values())
    if len(factors) != 120 or ranges[0][0] != 0 or ranges[-1][1] != 921600 or any(
            a[1] != b[0] for a, b in zip(ranges, ranges[1:])):
        raise ValueError("fixed factor offsets")
    parameters = len(header).to_bytes(8, "little") + header + bytes(921600)
    modules = {}
    for target_item in target["targets"]:
        module = {}
        for factor, shape in (("A", [4, target_item["in_features"]]),
                              ("B", [target_item["out_features"], 4])):
            desc = factors[target_item["module"] + "." + factor]
            size = shape[0] * shape[1] * 4
            if desc["dtype"] != "F32" or desc["shape"] != shape or desc["data_offsets"][1] - desc["data_offsets"][0] != size:
                raise ValueError("fixed factor shape")
            module[factor] = dict(dtype="float32", shape=shape, byte_length=size,
                                  sha256=sha256(bytes(size)))
        modules[target_item["module"]] = dict(**module, rank=4, alpha=[8, 1], dropout=False)
    wrapped = canonical(dict(schema="pon-wrapped-decoder-lora-material-v1",
                             contract=cid, modules=modules,
                             material_scope="factor-bytes-and-insertion-interface-not-functional-equivalence"))
    if domain_hash("wrapped-decoder-lora-material-v1", wrapped) != lock["wrapped_adapter_digest"]:
        raise ValueError("wrapped adapter domain identity")
    manifest = canonical(dict(model=MODEL, revision=REVISION,
                              files=family["material_pins"]["files"]))
    if sha256(manifest) != plan["snapshot"] or sha256(manifest) != lock["material_manifest_semantic_sha256"]:
        raise ValueError("public plan material snapshot")
    return {"adapter/artifact.safetensors": parameters,
            "adapter/target-contract.json": target_raw,
            "adapter/wrapped-adapter.json": wrapped,
            "base/material-manifest.json": manifest + b"\n"}


def acquire_member(row, generated, opener):
    global MEMBER_FETCH_ATTEMPTS, RECEIVED_BYTES
    fd = None
    digest = hashlib.sha256()
    row["status"] = "STARTING"
    row["started_ns"] = time.monotonic_ns() - ENTRY_NS
    try:
        fd = new_file(ROOT_FD, row["name"])
        row["status"] = "STARTED"
        emit_event("MEMBER_STARTED", name=row["name"], acquisition_kind=row["acquisition_kind"])
        if row["name"] in generated:
            data = generated[row["name"]]
            if len(data) != row["bytes"] or sha256(data) != row["sha256"]:
                raise ValueError("deterministic member identity differs")
            write_all(fd, data)
            digest.update(data)
            row["written_bytes"] = len(data)
        else:
            expected_url = "https://huggingface.co/" + MODEL + "/resolve/" + REVISION + "/" + row["name"][5:]
            if row["url"] != expected_url or row["revision"] != REVISION:
                raise ValueError("public URL/revision differs")
            allowed_https(expected_url)
            MEMBER_FETCH_ATTEMPTS += 1
            row["top_level_member_fetch_attempt"] = MEMBER_FETCH_ATTEMPTS
            if MEMBER_FETCH_ATTEMPTS > 7:
                raise ValueError("top-level member-fetch attempt limit")
            request = urllib.request.Request(expected_url, headers={
                "Accept-Encoding": "identity", "User-Agent": "Hepta-content-only-locked-acquisition-v1"})
            with opener.open(request, timeout=check_deadline()) as response:
                allowed_https(response.geturl())
                row["http_status"] = response.status
                if response.status != 200:
                    raise ValueError("HTTP status differs")
                declared = response.headers.get("Content-Length")
                row["declared_content_length"] = declared
                if declared is not None and int(declared) != row["bytes"]:
                    raise ValueError("HTTP content length differs")
                while row["written_bytes"] <= row["bytes"]:
                    check_deadline()
                    piece = response.read(min(CHUNK, row["bytes"] + 1 - row["written_bytes"]))
                    if not piece:
                        break
                    RECEIVED_BYTES += len(piece)
                    row["response_body_bytes_returned_to_reader"] += len(piece)
                    if row["written_bytes"] + len(piece) > row["bytes"]:
                        raise ValueError("HTTP response exceeds pinned size")
                    write_all(fd, piece)
                    digest.update(piece)
                    row["written_bytes"] += len(piece)
        row["written_sha256"] = digest.hexdigest()
        if row["written_bytes"] != row["bytes"] or row["written_sha256"] != row["sha256"]:
            raise ValueError("member full SHA256/size differs")
        os.fsync(fd)
        row["write_identity"] = identity(os.fstat(fd))
        row["status"] = "WRITTEN_AND_HASHED"
        emit_event("MEMBER_WRITTEN", name=row["name"], bytes=row["written_bytes"],
                   sha256=row["written_sha256"])
    except BaseException:
        row["partial_completed_chunks_sha256"] = digest.hexdigest()
        if fd is not None:
            row["partial_file_bytes"] = os.fstat(fd).st_size
        row["partial_hash_covers_completed_chunks_only"] = True
        row["status"] = "FAILED_OR_INTERRUPTED"
        raise
    finally:
        if fd is not None:
            os.close(fd)


def run(args):
    global ROOT_FD, ROOT_PATH, ROWS, ACTIVE, EVENT_FD, READBACK_BYTES, IO_START, LOCK_VERIFIED
    IO_START = io_counters()
    lock_path = Path(args.lock)
    input_root_fd = directory_absolute(args.input_root)
    lock_parent_fd = directory_absolute(str(lock_path.parent))
    try:
        lock_raw, _ = read_regular(lock_parent_fd, lock_path.name, 10963, LOCK_SHA256)
        lock = json.loads(lock_raw)
        if (lock["authority"] != "DENY_ALL" or lock["chain_commit"] != CHAIN or
                lock["hepta_commit"] != HEPTA or lock["revision"] != REVISION or
                lock["model"] != MODEL or lock["expected_member_count"] != 11 or
                lock["expected_payload_bytes"] != 272189990 or
                lock["budget"]["total_acquisition_wall_seconds"] != 35):
            raise ValueError("locked candidate/profile/budget differs")
        if [row["name"] for row in lock["members"]] != list(PLANNED_MEMBER_NAMES):
            raise ValueError("exact eleven-member roster")
        LOCK_VERIFIED = True
        ROWS = [dict(row, status="NOT_STARTED", written_bytes=0,
                     response_body_bytes_returned_to_reader=0) for row in lock["members"]]
        inputs = {}
        for key, pin in lock["required_inputs"].items():
            inputs[key], _ = read_regular(input_root_fd, pin["relative_path"],
                                          pin["bytes"], pin["sha256"])
        generated = derive(lock, inputs)
    finally:
        os.close(input_root_fd)
        os.close(lock_parent_fd)
    output = Path(args.output)
    output_parent_fd = directory_absolute(str(output.parent))
    try:
        os.mkdir(output.name, 0o700, dir_fd=output_parent_fd)
        ROOT_FD = directory_at(output_parent_fd, output.name)
        ROOT_PATH = str(output)
        check_deadline()
        os.fsync(output_parent_fd)
        check_deadline()
    finally:
        os.close(output_parent_fd)
    root_identity = identity(os.fstat(ROOT_FD))[:2]
    for name in ("adapter", "base"):
        os.mkdir(name, 0o700, dir_fd=ROOT_FD)
    EVENT_FD = new_file(ROOT_FD, "events.jsonl")
    # Persist the event-journal name before relying on fsynced attempt events.
    os.fsync(ROOT_FD)
    check_deadline()
    emit_event("ATTEMPT_STARTED", source_pair=[CHAIN, HEPTA],
               authority="DENY_ALL", original_invocation_replayed=False)
    opener = urllib.request.build_opener(LockedRedirects(), ObservedHTTPS())
    for row in ROWS:
        ACTIVE = row["name"]
        acquire_member(row, generated, opener)
    for name in ("adapter", "base"):
        fd = directory_at(ROOT_FD, name)
        try:
            expected = {row["name"].split("/", 1)[1] for row in ROWS if row["name"].startswith(name + "/")}
            if set(os.listdir(fd)) != expected:
                raise ValueError("unexpected member directory entries")
            os.fsync(fd)
        finally:
            os.close(fd)
    for row in ROWS:
        ACTIVE = row["name"]
        row["status"] = "READBACK_STARTED"
        try:
            measured_bytes, measured_sha, read_identity = measure_regular(
                ROOT_FD, row["name"], row["bytes"], row["sha256"])
        except BaseException:
            row["status"] = "READBACK_FAILED_OR_INTERRUPTED"
            raise
        READBACK_BYTES += measured_bytes
        row["readback_identity"] = read_identity
        if read_identity != row["write_identity"]:
            raise ValueError("member changed since durable write")
        row["status"] = "READBACK_VERIFIED"
        row["readback_sha256"] = measured_sha
        emit_event("MEMBER_READBACK", name=row["name"], bytes=row["bytes"], sha256=row["sha256"])
    fresh_output_fd = directory_absolute(str(output))
    try:
        if identity(os.fstat(fresh_output_fd))[:2] != root_identity:
            raise ValueError("output path rebound")
    finally:
        os.close(fresh_output_fd)
    if READBACK_BYTES != 272189990 or RECEIVED_BYTES != 271177292:
        raise ValueError("complete payload denominator differs")
    evidence = dict(schema="hepta-smollm-content-readback-v1", authority="DENY_ALL",
                    content_members=ROWS, exact_payload_bytes=READBACK_BYTES,
                    source_pair=[CHAIN, HEPTA], lock_sha256=LOCK_SHA256,
                    runtime_execution=False, training=False, adoption=False,
                    authorization=False, original_cold_invocation_recovered=False,
                    budget_qualification="REQUIRES_TERMINAL_EXIT_AND_EXTERNAL_35_SECOND_RECEIPT")
    fd = new_file(ROOT_FD, "READBACK.json")
    try:
        write_all(fd, canonical(evidence) + b"\n")
        os.fsync(fd)
    finally:
        os.close(fd)
    os.fsync(ROOT_FD)
    check_deadline()
    ACTIVE = None


def terminal(status, error):
    global ACQUISITION_FINISHED_NS
    # On failure the budget timer is stopped only to preserve its failed receipt;
    # no more acquisition, hashing, copying or retry is allowed.
    signal.setitimer(signal.ITIMER_REAL, 0)
    now = time.monotonic_ns()
    cost = resource.getrusage(resource.RUSAGE_SELF)
    end_io = io_counters()
    report = dict(
        schema="hepta-smollm-content-acquisition-terminal-v1",
        acquisition_status=status, authority="DENY_ALL",
        error=error, active_member=ACTIVE, planned_members=ROWS,
        planned_member_count=11, immutable_planned_names=list(PLANNED_MEMBER_NAMES),
        lock_verified=LOCK_VERIFIED,
        acquisition_elapsed_ns=(ACQUISITION_FINISHED_NS or now)-ENTRY_NS,
        terminal_observation_elapsed_ns=now-ENTRY_NS,
        budget_ns=BUDGET_NS, top_level_member_fetch_attempts=MEMBER_FETCH_ATTEMPTS,
        https_handler_attempts_started=len(HTTPS_REQUESTS), https_attempts=HTTPS_REQUESTS,
        response_body_bytes_returned_to_reader=RECEIVED_BYTES,
        application_byte_counter_scope=("COMPLETED_ATTEMPT_RECORDED_APPLICATION_RETURNS"
            if status == "COMPLETE_CONTENT_ONLY" else "RECORDED_LOWER_BOUND_FAILED_OR_INTERRUPTED"),
        zero_recorded_bytes_does_not_prove_zero_transfer=True,
        total_transport_body_bytes=None,
        output_readback_bytes=READBACK_BYTES,
        output_readback_bytes_attempted=READBACK_BYTES_ATTEMPTED,
        redirect_policy_attempts=REDIRECTS,
        observed_redirect_response_headers=[
            dict(https_request_index=row["index"], member=row["member"],
                 response_status=row["response_status"])
            for row in HTTPS_REQUESTS
            if row.get("response_status") in (301, 302, 303, 307, 308)],
        absent_terminal_or_hard_kill_counter_rule="Only persisted admission/headers/policy events are known; nonpersisted responses and total transfer bytes remain UNKNOWN, never zero.",
        output_path=ROOT_PATH,
        worker_cpu_seconds=cost.ru_utime+cost.ru_stime,
        worker_peak_rss_kib=cost.ru_maxrss,
        worker_io_at_acquisition_entry=IO_START,
        worker_io_at_terminal=end_io,
        worker_io_delta=None if IO_START is None or end_io is None else
            {key: end_io[key]-IO_START[key] for key in end_io},
        unmeasured_costs=["external queue/launcher/RPC overhead", "TLS/TCP/header wire bytes",
                          "HTTP/TLS buffered or prefetched body bytes beyond application reads",
                          "whole-machine energy", "independent-domain storage/payment"],
        model_execution=False, training=False, adoption=False, release_authorization=False,
        acquisition_scope="NEW_CURRENT_CONTENT_ONLY",
        historical_cold_start_resource_profile_recovered=False,
        current_resource_limits_binding="REQUIRES_SEPARATE_ACTUAL_LAUNCH_OBSERVATION",
        closes_historical_cold_start_gate=False,
        original_35s_invocation_replayed=False, old_failure_denominators_unchanged=True,
        whole_system_qualified=False)
    raw = canonical(report) + b"\n"
    if ROOT_FD is not None:
        try:
            fd = new_file(ROOT_FD, "TERMINAL.json")
            try:
                view = memoryview(raw)
                while view:
                    n = os.write(fd, view)
                    if n <= 0:
                        raise OSError("terminal short write")
                    view = view[n:]
                os.fsync(fd)
            finally:
                os.close(fd)
            os.fsync(ROOT_FD)
        except BaseException as receipt_error:
            report["terminal_file_error"] = type(receipt_error).__name__
            raw = canonical(report) + b"\n"
    sys.stdout.buffer.write(raw)
    sys.stdout.buffer.flush()
    return report


def main():
    global ACQUISITION_FINISHED_NS
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lock", required=True)
    parser.add_argument("--input-root", required=True)
    parser.add_argument("--output", required=True)
    signal.signal(signal.SIGALRM, deadline)
    try:
        signal.setitimer(signal.ITIMER_REAL, check_deadline())
        args = parser.parse_args()
        run(args)
        check_deadline()
        ACQUISITION_FINISHED_NS = time.monotonic_ns()
        terminal("COMPLETE_CONTENT_ONLY", None)
        # Terminal I/O is included in this return-code gate. The external launcher
        # remains the hard total deadline and must not reinterpret a killed or
        # UNKNOWN attempt using a completed-looking intermediate file.
        if time.monotonic_ns() - ENTRY_NS > BUDGET_NS:
            sys.stderr.write("FAILED: terminal publication exceeded total 35-second bound\n")
            return 124
        return 0
    except BaseException as error:
        terminal("FAILED_OR_UNKNOWN_REQUIRES_ORIGINAL_RECEIPT",
                 type(error).__name__ + ": " + str(error)[:1200])
        return 124 if isinstance(error, AcquisitionDeadline) else 1
    finally:
        if EVENT_FD is not None:
            os.close(EVENT_FD)
        if ROOT_FD is not None:
            os.close(ROOT_FD)


if __name__ == "__main__":
    raise SystemExit(main())
