#!/usr/bin/env python3
"""Package immutable observations; never infer pass from an absent result."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

ROOT = Path('/workspace/scratch/add353b13222')
RAW = ROOT / 'validation'
OUT = ROOT / 'staged-evidence'
SOURCE = '657bf2a462ff13a6101ebcb4fbe0fb91c515c972'
TREE = '7ce7ac50f788dd421e7cc0c9ddb957ade3e8df73'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

receipts = []
for path in sorted(RAW.glob('*.json')):
    value = read(path)
    if not isinstance(value, dict) or value.get('schema') != 'trnm-pq-native-command-v1':
        continue
    assert value['status'] != 'running', path
    if value.get('log_sha256') is not None:
        log = RAW / value['log_file']
        assert log.stat().st_size == value['log_bytes'] and sha(log) == value['log_sha256'], path
    if value.get('after') is not None:
        assert value['before'] == value['after'], path
    receipts.append({
        'path': 'records/' + path.name,
        'sha256': sha(path), 'status': value['status'],
        'exit_code': value.get('exit_code'),
        'tested_commit': value.get('before', {}).get('tested_commit'),
        'tested_tree': value.get('before', {}).get('tested_tree'),
        'raw_source_unchanged_before_after': value.get('after') is not None,
        'elapsed_ns': value.get('elapsed_ns'),
        'log_path': 'records/' + value['log_file'] if value.get('log_sha256') else None,
        'log_sha256': value.get('log_sha256')})

node_binding = read(RAW / 'node-binary.json')
f0_binding = read(RAW / 'from-zero-prepared-binary.json')
for value in (node_binding, f0_binding):
    binary = Path(value['executable'])
    assert sha(binary) == value['sha256'] and binary.stat().st_size == value['bytes']
    assert value['source_commit'] == SOURCE

node_log = (RAW / 'node-all-lib-final.log').read_text()
assert '1083 passed; 5 failed; 28 ignored' in node_log
failure_text = node_log[node_log.rfind('failures:'):]
failed_tests = re.findall(r'^    (store::\S+)$', failure_text, re.MULTILINE)
assert len(failed_tests) == 5
scale = read(RAW / 'growth-scale-retry-reader.log')
assert scale['result'] == 'COMPLETE_LOCAL_OBSERVATION'
assert (scale['completed_cohorts'], scale['measured_native_blocks'],
        scale['returned_native_stages'], scale['cancelled_admissions'],
        scale['cold_reopens']) == (9, 72, 153, 9, 9)
for row in scale['files']:
    path = RAW / 'growth-scale-retry-657bf2a' / row['file']
    assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
original_reader = read(RAW / 'growth-scale-original-reader.log')
assert original_reader['result'] == 'REFUSED'

excluded = []
paths = []
for path in sorted(RAW.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(RAW).as_posix()
    if relative == 'from-zero-native-final/public_v3_from_zero':
        excluded.append({'original_path': relative, 'bytes': path.stat().st_size,
                         'sha256': sha(path),
                         'reason': 'Reproducible release executable; actual build binding and all reports are retained.'})
    else:
        paths.append((path, 'records/' + relative))
paths.extend([
    (ROOT / 'monitor_growth_scale.py', 'diagnostic-tools/monitor_growth_scale.py'),
    (Path(__file__), 'diagnostic-tools/assemble_ordered_evidence.py')])

archive = OUT / 'raw-records.tar.gz'
index = []
with archive.open('xb') as target:
    with gzip.GzipFile(filename='', mode='wb', fileobj=target, mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for path, name in paths:
                before = path.stat()
                data = path.read_bytes()
                after = path.stat()
                assert (before.st_size, before.st_mtime_ns, before.st_ino) == (after.st_size, after.st_mtime_ns, after.st_ino)
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
                index.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})

archive_info = {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive)}
index_doc = {
    'schema': 'pon-ordered-request-raw-records-v1',
    'tested_commit': SOURCE, 'tested_tree': TREE,
    'archive': archive_info, 'file_count': len(index),
    'uncompressed_bytes': sum(x['bytes'] for x in index),
    'files': index, 'excluded_executables': excluded,
    'other_not_archived_executables': [node_binding],
    'original_failed_and_incomplete_records_retained': True,
    'no_archived_native_executable': True}
(OUT / 'records-index.json').write_text(json.dumps(index_doc, indent=2, sort_keys=True) + '\n')

verification = {
    'schema': 'pon-ordered-request-cost-evidence-v1',
    'status': 'HOLD',
    'source': {'repository': 'TrillionniumFoundation/Trillionnium-Chain',
               'commit': SOURCE, 'tree': TREE,
               'branch': 'fix/chain-six-axis-performance-20261103', 'pull_request': 688,
               'cargo_lock_sha256': '39ab5baeecb55c5445e6bbbbb359cb4ddcddd75a237e19ec243dc2f0f92849be',
               'workspace_packages': 26, 'resolved_packages': 175},
    'publication': {'parent': 'cbead1508ce8b6d9deb2a86b4bc3181da09694e7',
                    'parent_tree': '624c8aad419ee05dc71a4aac507abea429018289',
                    'scope': 'Evidence and existing plan only; later production changes do not inherit these native results.'},
    'functional_node_binary': node_binding,
    'original_release_f0_binary': f0_binding,
    'counts_must_not_be_summed_across_overlapping_suites': True,
    'tests': {
        'new_feature_functions': {'rust_passed': 13, 'python_passed': 7, 'total': 20},
        'node_complete_lib': {'passed': 1083, 'failed': 5, 'ignored': 28, 'exit_code': 101, 'failed_tests': failed_tests},
        'isolated_diagnostics': {'owner_epoch': {'passed': 1}, 'witness_deadline': {'passed': 1}, 'replace_original_failures': False},
        'm06_all_targets_features': {'passed': 253, 'failed': 0, 'ignored': 8, 'targets_with_tests': 18},
        'request_reader': {'passed': 51}, 'source_integrity': {'passed': 43},
        'from_zero_readers': {'passed': 140}, 'native_roster': {'passed': 9},
        'strict_workspace_all_targets_all_features_clippy': 'PASS',
        'graph_format_inventory_repository': {'result': 'PASS', 'local_links': 3022}},
    'failed_builds': {
        'node-build-exact.json': {'source': '59546d6ccc6525daec5881a0364b5e95254939d5', 'result': 'SIGKILL', 'original_profile_passed': False},
        'node-build.json': {'result': 'record_failed_before_native_execution', 'native_test_result': None}},
    'growth_scale': {'original': {'exit_code': 101, 'completed_cohorts': 2, 'planned_cohorts': 9,
                                  'measured_blocks': 16, 'returned_native_stages': 34,
                                  'cancelled_admissions': 2, 'cold_reopens': 2,
                                  'last_event': 'a64-h128 warmup_started index 104',
                                  'reader_result': original_reader,
                                  'suspected_failure_boundary': 'stderr mirror during append',
                                  'root_cause': None, 'native_failure_code': None},
                     'diagnostic_retry': scale, 'retry_replaces_original': False,
                     'paired_performance_control': False},
    'original_f0': {'host_readiness': 'HOSTED_CI_ONLY_NO_LOCAL_PROVISION',
                    'planned_named_invocations': 5, 'returned_passed_invocations': 5,
                    'acceptance_stages_entered': 3, 'acceptance_passed': False,
                    'failure': 'CONFIRMATION_TARGET', 'raw_reports_present': 3,
                    'requests': {'total': 644, 'baseline': 95, 'pressure': 549,
                                 'omitted': 0, 'unfinished_owners': 0,
                                 'pressure_accepted': 99, 'pressure_rejected': 435, 'pressure_unknown_outcome': 15},
                    'baseline': {'submit_ack': {'count': 7, 'denominator': 7},
                                 'history_responses': {'count': 16, 'denominator': 16},
                                 'accepted_independent_replays': {'count': 0, 'denominator': 16},
                                 'independent_confirmations': {'count': 0, 'denominator': 1},
                                 'execution_count': None, 'inclusion_count': None,
                                 'successful_confirmation_latency_ns': None, 'confirmation_tps': None},
                    'pressure': {'submit_ack': {'count': 7, 'denominator': 7},
                                 'history_responses': {'count': 16, 'denominator': 16},
                                 'accepted_independent_replays': {'count': 0, 'denominator': 16},
                                 'independent_confirmations': {'count': 0, 'denominator': 1},
                                 'execution_count': None, 'inclusion_count': None,
                                 'successful_confirmation_latency_ns': None, 'confirmation_tps': None},
                    'independent_replay_error': 'PUBLIC_HOST_KERNEL_PARENT',
                    'actual_resolve_syscall_errno': None,
                    'cpu': {'known_records': 449, 'unknown_missing_extension_records': 195,
                            'known_total_cpu_ns': 1015974161,
                            'rejected_pressure_known_records': 435,
                            'rejected_pressure_known_total_cpu_ns': 854722222,
                            'whole_request_cpu_measured': False,
                            'positive_post_disconnect_wall_tail_cohort': 0}},
    'runtime': {'repository': 'TrillionniumFoundation/hepta-private-ci', 'pull_request': 4812,
                'observed_commit': '7530e4bc7aa61a0c23a5933fef4a65d86a586cf8',
                'observed_tree': '253d7584783cf658b9d5192d1106aa4c08fe031f',
                'executed_in_this_continuation': False,
                'historical_v10_acceptance_transferred': False},
    'whole_request_p99_ns': None, 'independent_confirmation_tps': None,
    'common_pq_growth_public_recovery_qualified': False,
    'host_wide_capacity_isolation_qualified': False,
    'original_four_second_sixteen_worker_gate_passed': False,
    'history_4105_gate_passed_in_this_continuation': False,
    'production_activation': False,
    'receipts': receipts, 'raw_archive': archive_info}
(OUT / 'verification.json').write_text(json.dumps(verification, indent=2, sort_keys=True) + '\n')
print(json.dumps({'archive': archive_info, 'files': len(index),
                  'uncompressed_bytes': index_doc['uncompressed_bytes'],
                  'receipts': len(receipts), 'excluded_executables': excluded}, indent=2))
