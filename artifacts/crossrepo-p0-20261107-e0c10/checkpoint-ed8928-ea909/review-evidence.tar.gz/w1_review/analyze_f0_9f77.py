#!/usr/bin/env python3
"""Read only the retained F0 run. No execution, campaign or gate mutation."""
from __future__ import annotations

import ast
import collections
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "f0-9f77-42323271496"
RAW = OUT / "raw"
SOURCE = ROOT / "gate-map-source-9f77f433/scripts/run_fixed_host_root_f0.py"
ZIP_SHA = "c396369487eb99c63d94d373eb779439aa2a0fda145228cadc3082845342769e"
HEAD = "9f77f4334a365387d7389735d5b67c37f12a02a0"
TREE = "d7803f073a81e17ce4b79efca748645e12d3adff"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads((RAW / path).read_text())


def histogram(values):
    return [{"value": value, "count": count}
            for value, count in collections.Counter(values).items()]


def numeric_summary(values):
    known = [value for value in values if type(value) is int]
    return {"observations": len(values), "known": len(known),
            "unknown": len(values) - len(known),
            "known_sum": sum(known), "min": min(known, default=None),
            "max": max(known, default=None),
            "complete_sum": sum(known) if len(known) == len(values) else None}


def digest(value):
    return bytes(value).hex() if isinstance(value, list) else value


def active_phases(phases):
    return [row for row in phases if row["started"]]


def receiver_row(row):
    result = {key: row.get(key) for key in (
        "connection_id", "lifecycle", "dispatch_started", "dispatch_accepted",
        "dispatch_error_code", "dispatch_thread_cpu_ns", "error_diagnostics",
        "full_work_started", "full_work_accepted", "full_work_thread_cpu_ns",
        "terminal_error_code", "terminal_phase", "response_frame_complete",
        "challenge_wait", "grant_wait", "paid_task_queue_wait", "response_write",
        "cpu_settlement", "observation_failed")}
    result["body_digest"] = digest(row["body_digest"])
    result["active_submit_phases"] = active_phases(row["submit_phases"])
    return result


def stage_delta(before, after):
    left = {row["stage"]: row["totals"] for row in before["stages"]}
    right = {row["stage"]: row["totals"] for row in after["stages"]}
    assert left.keys() == right.keys()
    result = {}
    for name in right:
        result[name] = {key: (right[name][key] - left[name][key]
                             if type(right[name][key]) is int
                             and type(left[name][key]) is int else None)
                        for key in right[name]}
    return result


def aggregate_receiver(rows):
    return {
        "records": len(rows),
        "dispatch_started": sum(row["dispatch_started"] is True for row in rows),
        "dispatch_accepted": sum(row["dispatch_accepted"] is True for row in rows),
        "dispatch_errors": histogram(row["dispatch_error_code"] for row in rows),
        "dispatch_diagnostic_prefixes": histogram(
            (row["error_diagnostics"]["dispatch"] or {}).get("message_prefix")
            for row in rows),
        "terminal_errors": histogram(row["terminal_error_code"] for row in rows),
        "full_work_accepted": sum(row["full_work_accepted"] is True for row in rows),
        "full_work_failed": sum(row["full_work_accepted"] is False for row in rows),
        "dispatch_thread_cpu_ns": numeric_summary(
            [row["dispatch_thread_cpu_ns"] for row in rows]),
        "full_work_thread_cpu_ns_nested": numeric_summary(
            [row["full_work_thread_cpu_ns"] for row in rows]),
        "waits_wall_ns": {key: numeric_summary([row[key]["wall_ns"] for row in rows])
                          for key in ("challenge_wait", "grant_wait",
                                      "paid_task_queue_wait", "response_write")},
        "submit_phases_nested": {
            phase: {
                "entered": len(points),
                "accepted": sum(row["accepted"] is True for row in points),
                "rejected": sum(row["accepted"] is False for row in points),
                "wall_ns": numeric_summary([row["wall_ns"] for row in points]),
                "thread_cpu_ns": numeric_summary([row["thread_cpu_ns"] for row in points]),
                "errors": histogram(row["error_code"] for row in points),
            }
            for phase in sorted({point["phase"] for row in rows
                                 for point in row["submit_phases"] if point["started"]})
            for points in [[point for row in rows for point in row["submit_phases"]
                            if point["started"] and point["phase"] == phase]]
        },
    }


def main():
    archive = OUT / "artifact-13554327789.zip"
    original = archive.read_bytes()
    assert len(original) == 16_035_997 and sha(original) == ZIP_SHA
    execution = read("execution/results.json")
    report = read("execution/raw/report.json")
    finalization = read("finalization/result.json")
    before, after = read("source-before.json"), read("source-after.json")
    assert before == after and before["tested_commit"] == HEAD
    assert before["tested_tree"] == TREE and before["tracked_worktree_verified"] is True
    assert execution["head"] == HEAD and execution["tree"] == TREE
    assert sha((RAW / "execution/raw/report.json").read_bytes()) == execution["report_sha256"]

    with ZipFile(archive) as z:
        inventory = json.loads(z.read("artifact-files.json"))
        assert inventory["all_files_retained"] is True and inventory["errors"] == []
        checked_bytes = 0
        for entry in inventory["files"]:
            data = z.read(entry["path"])
            assert len(data) == entry["bytes"] and sha(data) == entry["sha256"], entry["path"]
            checked_bytes += len(data)
        binary = z.read("prepared/public_v3_multiprocess.bin")
        assert len(binary) == execution["binary"]["bytes"]
        assert sha(binary) == execution["binary"]["sha256"]

    # Execute only the two actual, pure source report readers. Dependencies,
    # preparation, native selectors and workflow runners are never imported/run.
    tree = ast.parse(SOURCE.read_text())
    readers = ast.Module(body=[node for node in tree.body
                              if isinstance(node, ast.FunctionDef)
                              and node.name in {"f0_rounds", "f0_packets"}],
                         type_ignores=[])
    assert len(readers.body) == 2
    namespace = {}
    exec(compile(readers, str(SOURCE), "exec"), namespace)
    rounds = namespace["f0_rounds"](report)
    packets = namespace["f0_packets"](report)
    assert len(rounds) == 6 and len(packets) == 42
    assert rounds == execution["all_planned_rounds"]
    assert packets == execution["all_planned_business_packets"]
    for derived, retained in zip(rounds, report["all_planned_rounds"]):
        assert all(retained[key] == value for key, value in derived.items())
    assert packets == report["all_planned_business_packets"]

    phases = []
    exposures = []
    for phase in report["phases"]:
        name = phase["mode"]
        submissions = phase["submissions"]
        records = phase["receiver_observation"]["records"]
        honest_digests = {row["public_request_body_digest"] for row in submissions}
        hostile_digests = {row["public_request_body_digest"]
                           for row in phase.get("root_supplement", {}).get("acquisitions", [])}
        assert not honest_digests.intersection(hostile_digests)
        honest_records = [row for row in records if digest(row["body_digest"]) in honest_digests]
        hostile_records = [row for row in records if digest(row["body_digest"]) in hostile_digests]
        history_records = [row for row in records if row["operation"] == 3]
        assert len(honest_records) == len(submissions)
        assert len(records) == len(honest_records) + len(hostile_records) + len(history_records)
        for packet in (row for row in packets if row["phase"] == name):
            index = packet["packet_index"]
            slot = index // 7
            scheduled = (1 + 4 * slot) * 1_000_000_000
            attempts = [row for row in submissions if row["packet_index"] == index]
            bodies = {row["public_request_body_digest"] for row in attempts}
            matching = [row for row in records if digest(row["body_digest"]) in bodies]
            prepared = bytes.fromhex(report["preparation"]["business_packets"][index])
            acks = [row for row in attempts if row["status"] == "ok"
                    and row["returned_after_window"] is False]
            exposure = dict(packet)
            exposure.update({
                "round": slot, "scheduled_round_offset_ns": scheduled,
                "round_four_second_deadline_ns": scheduled + 4_000_000_000,
                "prepared_packet_bytes": len(prepared), "prepared_packet_sha256": sha(prepared),
                "first_started_ns": min((row["started_ns"] for row in attempts), default=None),
                "last_ended_ns": max((row["ended_ns"] for row in attempts), default=None),
                "first_ack_ns": min((row["ended_ns"] for row in acks), default=None),
                "ack_before_round_four_second_deadline": any(
                    scheduled <= row["ended_ns"] < scheduled + 4_000_000_000 for row in acks),
                "native_timely_ack_scope": "before original 30-second phase end; not 4-second confirmation",
                "classification": ("no_attempt_retained" if not attempts else
                                   "ack_retained_not_confirmation" if acks else
                                   "attempted_without_timely_ack"),
                "attempts": [{key: row[key] for key in (
                    "packet_index", "height", "started_ns", "ended_ns", "elapsed_wall_ns",
                    "calling_process_cpu_ns", "status", "error", "returned_after_window",
                    "metrics", "public_request_body_digest", "recorded_request_bytes",
                    "recorded_request_digest", "response")} for row in attempts],
                "receiver_records_matched_by_exact_body_digest": [receiver_row(row) for row in matching],
                "receiver_clock_scope": "observer-local; do not subtract from client/phase timestamps",
                "retry_mapping_scope": "all receiver records for this exact logical packet; no invented request-ID join",
                "confirmed_in_scheduled_round": rounds[(0 if name == "baseline" else 3) + slot]["four_second_slo_met"],
            })
            exposures.append(exposure)

        history = []
        for index, row in enumerate(phase["history"]):
            ci = row.get("client_import")
            native = ci["native_import_observation"] if ci else None
            hs = native["host_checks"] if native else []
            history.append({
                "page_ordinal": index,
                "network": {key: row[key] for key in (
                    "started_ns", "ended_ns", "elapsed_wall_ns", "calling_process_cpu_ns",
                    "status", "error", "returned_after_window", "request")},
                "client_import": {key: ci[key] for key in ci if key != "native_import_observation"} if ci else None,
                "host_checks": hs,
                "host_totals_nested": {key: sum(row[key] or 0 for row in hs)
                                       for key in ("calls_started", "calls_completed", "calls_accepted",
                                                   "calls_rejected", "calls_unfinished", "thread_cpu_ns",
                                                   "wall_ns", "cpu_clock_unknown_calls", "wall_clock_unknown_calls")},
                "native_import_metadata": {key: native[key] for key in (
                    "clock_scope", "cpu_intervals_are_nested_not_additive",
                    "host_checks_are_nested_not_additive", "host_cpu_includes_each_calling_thread",
                    "host_cpu_is_full_worker_cpu", "measurement_failures", "phase_cpu_excludes_scoped_workers",
                    "schema", "supplied_packets")} if native else None,
                "active_page_phases": active_phases(native["phases"]) if native else [],
                "packets": [{"packet_id": digest(packet["packet_id"]),
                             "packet_index": packet["packet_index"],
                             "active_phases": active_phases(packet["phases"])}
                            for packet in native["packets"]] if native else [],
            })
        actual_credits = [row["meter"]["Ok"]["actual_flow"]["remaining_paid_credit_ns"]
                          for row in phase["budget_samples"] if "Ok" in row["meter"]]
        kernel_before = phase["phase_process_context"]["host_before"]
        kernel_after = phase["phase_process_context"]["host_after"]
        phase_exposures = [row for row in exposures if row["phase"] == name]
        calls = [row for child in phase["children"] for row in child["report"]["result"]["calls"]]
        root_calls = [row for row in calls if row["status"] == "refused"
                      and row["error"] is None and row["response"]["ok"] is False
                      and row["response"]["value"].get("error") == "ROOT"]
        acquisitions = phase.get("root_supplement", {}).get("acquisitions", [])
        host_boundaries = {}
        for boundary in ("inside-before", "inside-after", "outside-before", "outside-after"):
            path = f"execution/raw/{name}-fixed-root-host-control/host/{boundary}.json"
            value = read(path)
            host_boundaries[boundary] = {
                "raw_path": path, "raw_sha256": sha((RAW / path).read_bytes()),
                "limits": value["limits"], "read_errors": value["read_errors"],
                "counters": value["counters"], "parent": value["parent"],
            }
        phases.append({
            "phase": name,
            "confirmation_rows": phase["confirmations"],
            "verifier_errors": phase["verifier_errors"],
            "all_signed_rounds_confirmed_in_window": phase["all_signed_rounds_confirmed_in_window"],
            "finite_phase_criteria_met": phase["finite_phase_criteria_met"],
            "final_receiver_tip": phase["final_receiver_tip"],
            "initial_tip": phase["initial_tip"], "final_client_tip": phase["final_client_tip"],
            "receiver_client_state_equal": phase["receiver_client_state_equal"],
            "public_resource_policy": phase["public_resource_policy"],
            "setup_cpu_ns": phase["receiver_and_verifier_setup_cpu_ns"],
            "setup_wall_ns": phase["receiver_and_verifier_setup_wall_ns"],
            "whole_parent_phase_cpu_ns": phase["whole_parent_phase_cpu_ns"],
            "whole_parent_phase_wall_ns": phase["whole_parent_phase_wall_ns"],
            "kernel_before": kernel_before, "kernel_after": kernel_after,
            "kernel_delta": {key: kernel_after[key] - kernel_before[key]
                             for key in ("cpu_usage_usec", "cpu_nr_periods", "cpu_nr_throttled", "cpu_throttled_usec")},
            "kernel_scope": "whole public parent sample interval; includes setup and shutdown; throttle time is not additional CPU",
            "host_boundary_observations": host_boundaries,
            "initial_meter": phase["initial_meter"], "final_meter": phase["final_meter"],
            "final_actual_flow": phase["final_actual_flow"],
            "budget_samples": len(phase["budget_samples"]),
            "sampled_actual_paid_credit_ns": numeric_summary(actual_credits),
            "sampled_budget_depleted": sum(row["meter"].get("Ok", {}).get("depleted") is True
                                           for row in phase["budget_samples"]),
            "genuine_budget_depletion_observed": phase["genuine_budget_depletion_observed"],
            "business_packet_counts": {
                "planned": 21,
                "with_attempts": sum(row["observed_attempts"] > 0 for row in phase_exposures),
                "attempts": len(submissions),
                "acks_before_phase_end": sum(row["timely_network_ack"] for row in phase_exposures),
                "acks_before_round_four_second_deadline": sum(row["ack_before_round_four_second_deadline"] for row in phase_exposures),
                "no_attempts": sum(row["observed_attempts"] == 0 for row in phase_exposures),
            },
            "receiver_observer_metadata": {key: value for key, value in phase["receiver_observation"].items()
                                           if key != "records"},
            "receiver_honest": aggregate_receiver(honest_records),
            "receiver_hostile": aggregate_receiver(hostile_records),
            "receiver_history": aggregate_receiver(history_records),
            "history_pages": history,
            "history_totals": {
                "network_wall_ns": sum(row["network"]["elapsed_wall_ns"] for row in history),
                "client_import_wall_ns": sum(row["client_import"]["wall_ns"] for row in history),
                "client_import_thread_cpu_ns": sum(row["client_import"]["thread_cpu_ns"] for row in history),
                "host_nested": {key: sum(row["host_totals_nested"][key] for row in history)
                                for key in ("calls_started", "calls_completed", "calls_accepted", "calls_rejected",
                                            "thread_cpu_ns", "wall_ns", "cpu_clock_unknown_calls", "wall_clock_unknown_calls")},
            },
            "native_stage_deltas_nested": {
                who: stage_delta(phase[who + "_before"], phase[who + "_after"])
                for who in ("client_native_history_arithmetic", "native_history_arithmetic")
            },
            "controller_resources": phase["external_controller_resources"],
            "attack": {
                "actors_requested": phase["attacker_processes_requested"],
                "actors_ready": phase["attacker_processes_ready"],
                "actor_reports_successful_without_cap_or_kill": phase["actor_reports_successful_without_cap_or_kill"],
                "calls": len(calls), "statuses": histogram(row["status"] for row in calls),
                "errors": histogram(row["error"] for row in calls),
                "signed_root_refusals": len(root_calls),
                "signed_root_refusals_before_phase_end": sum(row["returned_after_window"] is False for row in root_calls),
                "calls_overlapping_each_observed_round": phase["attack_calls_overlapping_each_signed_round"],
                "all_acquisition_cpu_ns": sum(row["acquisition_cpu_ns"] for row in acquisitions),
                "all_acquisition_wall_ns_nonadditive_concurrent": sum(row["acquisition_wall_ns"] for row in acquisitions),
                "all_diagnostic_cpu_ns": sum(row["diagnostic_cpu_ns"] for row in acquisitions),
                "acquisition_setup_calls": sum(row["setup_calls"] for row in acquisitions),
                "acquisition_attempt_records": sum(len(row["attempts"]) for row in acquisitions),
                "root_supplement": {key: value for key, value in phase.get("root_supplement", {}).items()
                                    if key not in ("acquisitions", "actor_readiness", "final_state_rows", "final_stats", "hostile_packet_ids")},
            },
        })

    result = {
        "schema": "independent-internal-f0-retained-failure-analysis-v1",
        "source_review_scope": "internal original-artifact analysis; no independent external acceptance",
        "external_acceptance": False,
        "candidate": HEAD, "tree": TREE, "run_id": 42323271496,
        "run_attempt": 1, "pr": 752, "job_id": 128252585690, "artifact_id": 13554327789,
        "source_identity": before,
        "archive": {"path": str(archive), "bytes": len(original), "sha256": sha(original),
                    "all_inventory_files_verified": len(inventory["files"]),
                    "all_inventory_bytes_verified": checked_bytes},
        "report_sha256": execution["report_sha256"],
        "binary": execution["binary"], "retained_binary_bytes_and_sha_verified": True,
        "post_binary_observation": execution["post_observations"]["binary"],
        "inputs": execution["inputs"],
        "source_reader_sha256": sha(SOURCE.read_bytes()),
        "exact_source_readers_reproduced_execution_denominators": True,
        "planned_confirmations": 6, "planned_business_packet_exposures": 42,
        "four_second_slo_successes": execution["four_second_slo_successes"],
        "complete_success": execution["complete_success"],
        "report_validation_failure": execution["report_validation_failure"],
        "execution_failure": execution["failure"],
        "finalization_all_services_known_empty": finalization["all_services_known_empty"],
        "controller_resources_complete": execution["controller_resources_complete"],
        "preparation": {"cpu_ns": report["preparation"]["cpu_ns"],
                        "wall_ns": report["preparation"]["wall_ns"],
                        "scope": report["preparation"]["scope"],
                        "business_packets": len(report["preparation"]["business_packets"]),
                        "seed_packets": len(report["preparation"]["seed_packets"])},
        "clock_and_cost_rules": [
            "Four-second success is strict elapsed < 4e9 ns from scheduled phase offset 1/5/9 seconds, including queue and observer; never reset at actual start.",
            "Missing rounds/exposures remain in six/42 denominator; no-attempt and failed-attempt are distinct.",
            "timely_network_ack in original source means before 30-second phase end; it is not confirmation or an ACK within four seconds.",
            "Receiver lifecycle timestamps use observer-local epoch; client timestamps use phase epoch; compare durations, not cross-epoch subtraction.",
            "Calling-process CPU in network calls includes concurrent receiver and observer process activity; it is not isolated client CPU.",
            "Client-import CPU is importer thread only; Host CPU sums invoking-thread Host intervals and is nested, not additive or full worker CPU.",
            "State/account-graph, admission, commit, activation, work, Host and dispatch spans overlap/nest; do not add them into a total.",
            "Public cgroup CPU delta includes setup/shutdown; controller CPU is separately placed; cgroup throttled_usec is not consumed CPU or a direct single-thread latency measurement.",
            "Recorded zero entered history/phase CPU is absence of execution, not a successful zero-cost confirmation.",
        ],
        "rounds": rounds, "exposures": exposures, "phases": phases,
    }
    target = OUT / "analysis.json"
    target.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    receipt = {"analysis_path": str(target), "analysis_bytes": target.stat().st_size,
               "analysis_sha256": sha(target.read_bytes()),
               "script_sha256": sha(Path(__file__).read_bytes()),
               "archive_sha256": sha(original), "verified_inventory_files": len(inventory["files"]),
               "denominator_readback": {"rounds": len(rounds), "exposures": len(exposures),
                                         "successes": sum(row["four_second_slo_met"] for row in rounds)},
               "native_or_workflow_execution_started": False}
    (OUT / "analysis-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
