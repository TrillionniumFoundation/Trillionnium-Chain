#!/usr/bin/env python3
"""Fresh scalar specification check; not a tile, GPU, or Chain execution."""
from datetime import datetime, timezone
from fractions import Fraction
import json


def floor_fraction(value):
    return value.numerator // value.denominator


def estimate_at_exponent_zero(x, sigma):
    assert Fraction(1) <= max(abs(x), sigma) < Fraction(2)
    kappa = (
        floor_fraction((1 << 30) * x * x)
        + floor_fraction((1 << 30) * sigma * sigma)
    ) // (1 << 17)
    # floor(64*log2(kappa)) = floor(log2(kappa**64)), exactly.
    log64_floor = (kappa**64).bit_length() - 1
    return kappa, Fraction(log64_floor, 64) - 13


def main():
    a = Fraction(129, 128)
    b = Fraction(45, 32)
    ka, la = estimate_at_exponent_zero(a, a)
    kb, lb = estimate_at_exponent_zero(b, b)
    variance = (a * a + a * a) * (b * b + b * b) / (1 << 21)
    estimate = la + lb - 21
    ulp_squared = Fraction(1, 512) ** 2
    log2_ulp_squared = -18
    assert (ka, kb) == (16641, 32400)
    assert (la, lb) == (Fraction(65, 64), Fraction(63, 32))
    assert variance == Fraction(33698025, 8796093022208)
    assert estimate == Fraction(-1153, 64)
    assert variance > ulp_squared
    assert estimate < log2_ulp_squared
    print(json.dumps({
        "schema": "pearl-c5-fresh-exact-scalar-observation-v1",
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "source": "https://pearlresearch.ai/Pearl_Whitepaper.pdf",
        "source_edition": "September 2026, Appendix C.5, printed pages 20-21",
        "xA_equals_sigmaA": str(a), "xB_equals_sigmaB": str(b),
        "ulp": "1/512", "ulp_squared": str(ulp_squared),
        "kappaA": ka, "kappaB": kb,
        "lambdaA": str(la), "lambdaB": str(lb),
        "variance": str(variance), "lambda_combined": str(estimate),
        "in_S": variance < ulp_squared,
        "in_Shat": estimate < log2_ulp_squared,
        "logical_inclusion_from_lower_bound": "S is a subset of Shat",
        "printed_inclusion_refuted_by_scalar": True,
        "upper_cap_counting_Shat_is_conservative": True,
        "integer_and_rational_arithmetic_only": True,
        "full_admissible_tile_constructed": False,
        "gpu_or_native_verifier_executed": False,
        "chain_exploit_claim": False,
        "old_lost_observation_reconstructed": False,
    }, indent=2))


if __name__ == "__main__":
    main()
