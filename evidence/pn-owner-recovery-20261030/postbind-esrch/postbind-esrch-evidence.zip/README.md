# PN3 bound-worker ESRCH component evidence

This is a narrow source continuation from Chain
`89218d818a1766c5610b64f09d75fc3d2ff6007d`. It does not qualify a model run,
installation, production runtime or release. The only development plan is the
[existing Chain plan](../../../docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md).

## Source and authority boundary

The [four-path patch](frozen-code.patch) changes the V4 worker observer, adds one
test module, imports that class through the existing pilot test entrypoint, and
adds that test path to the existing M14 ownership inventory. The original pilot
production, V2/V3 observers and existing observer controls are byte-identical to
the baseline. [Protected-source and skip checks](protected-source-and-skip-check.json)
retain those hashes. The native include inventory needs no new entry: it
already includes the existing ownership JSON, and its original `--check` passes.

The new path is limited to ESRCH from the held original nonleader task directory
in `post-bind-double-frontier` or `worker-pidfd-recheck`. Every original worker
must already have a complete pidfd binding. All held signatures, original
namespace and starttime must agree. The exact same retained worker pidfd must
report POLLIN with no event outside POLLIN/POLLHUP. The remaining roster and
count must equal the original set minus this one worker, both around retention
and on later pending rechecks. The original group may contain more than two
threads; losing another worker does not extend this one worker's proof.

The new `llm-owned-postbinding-terminal-pending-v1` record retains the original
complete prebinding classification. It does not set `baseline_qualified`,
complete the interrupted postbinding frontier, report zero RSS or release a
reservation. Exact owned wait4, its actual CPU/RSS receipt, the original 100 ms
deadline, the enclosing wall/RSS budget and successful exit remain necessary.
Earlier binding ESRCH, pidfd-open/fdinfo failures, leader/group loss, invalid or
missing events, changed identities, changed rosters and observed invalid fields
still refuse. The original ENOENT and initial-pending paths are unchanged.

## Native fixture: what is real and what is controlled

The new native test actually opens the original worker's proc status FD before
exit. A scheduling hook releases that owned worker only after open succeeds.
The original read then receives kernel `ProcessLookupError` / ESRCH from that
same FD. The real PIDFD_THREAD descriptor reports POLLIN/POLLHUP, its signature
is unchanged, and the actual original proc roster loses the worker. No error or
successful wait4 receipt is fabricated. The real supervisor owns the actual
child and executes the original wait4, cleanup and resource checks.

To enter this short stage deterministically, the test controls only the
exit-only State/PF_EXITING/no-mm field view. The second, missing-RSS view is a
fixture. The first RSS sample and the final wait4 high-water/CPU are real.
PID, PPid, Tgid, namespaces, starttime, Threads and held FD identities are not
replaced. Every successful raw and transformed proc field is retained in the
native JSON records. This is not a reproduction of a natural model exit-only
window, nor proof that the original historical failure was this exact worker.

The component child uses an explicit two-second budget and 128 MiB cap; the
overcap negative uses 32 MiB. These tiny fixture budgets do not substitute for
the model's original 600-second/8-GiB inference budget. Both use the unchanged
100,000,000 ns observer bound. No model materials were downloaded or executed.

## Original RED and final GREEN

The final test source is identical between [frozen RED](frozen-red.json) and
[frozen GREEN](frozen-green.json). The RED temporarily selects the exact original
worker source in this isolated worktree; the candidate is restored in a
`finally` block. Each receipt checks source hashes before and after execution.

| Observation | Original command or scope | Result |
|---|---|---|
| Preflight | `bash scripts/project-preflight.sh` | PASS, 26 packages; original no-argument default `--dev` |
| Original full pilot | `python3 scripts/test_llm_runtime_pilot.py -v` | 301 discovered; 190 pass, 111 original skips |
| Final native/component RED | `python3 -B scripts/test_llm_runtime_exit_post_binding_retirement.py -v` on original worker | Exit 1; 12 methods; unittest reports 4 subtest failures and 10 subtest errors |
| Final native/component GREEN | Same command and test bytes on candidate worker | 12 pass, no skips |
| Final complete pilot | `python3 -B scripts/test_llm_runtime_pilot.py -v` | 313 discovered; 202 pass, 111 original skips |
| Existing source-boundary negatives | `python3 -B scripts/ci/test_project_boundary.py -v` | 16 pass |
| Existing CI-contract negatives | `python3 -B scripts/ci/test_ci_contract.py -v` | 96 pass |
| Existing inventory/projection checks | `refresh_distributed_source_inventory.py --check`; `report_current_implementation.py --check` | Both pass |

The 111 original skips are unchanged: 104 require the exact controlled CPython
3.12.3 ABI, and seven require the explicit CPU tensor opt-in. This environment
uses CPython 3.12.14 and Linux 6.18.55. Skipped tests are not passing executions.
The full pilot result does not add 313 independent passes to the selected 12.

The [final four native cases](frozen-green-native/) retain these actual results:

| Case | Child exit | Final outcome | Original drain interval | wait4 high-water |
|---|---:|---|---:|---:|
| Valid | 0 | Success only after exact owned wait4 | 17,293,442 ns | 76,021,760 bytes |
| Nonzero | 7 | Failed by exit status | 15,987,445 ns | 76,021,760 bytes |
| Overcap | 0 | `rss-budget-exceeded` under 32 MiB cap | 16,811,013 ns | 76,021,760 bytes |
| Group held live | -15 after original cleanup | `rss-exit-cleanup-observation-unavailable` | 100,455,327 ns | 76,021,760 bytes |

The late case's original recheck reports `exit-worker-deadline`; the full pilot
execution reaches the other original `exit-cleanup-deadline` branch. Both reject
closure after the same 100 ms bound. The test checks the exact original branch
code and time, not just an arbitrary failure. These times are component
observations, not model latency or throughput measurements.

All prior attempts remain retained. The first no-checkout preflight failed
because source files were not yet materialized; it is preparation failure,
not security RED. An early test overconstrained the deadline's error spelling;
the unchanged guard had correctly rejected it. That failed log is retained.
An additional [three-thread RED](later-roster-red.json) on the earlier candidate
showed why the new schema's one-loss constraint must persist during later
rechecks. It did not demonstrate resource release without wait4. The subsequent
source adds the narrow guard and retains its positive and negative controls.

## Historical model failure stays failed

Original Hepta D run `41030856547`, job `123979976198`, artifact `12969458028`
used Chain `89218d8`. Its first-round `evaluate-fresh-budget-matched-lora` child
exited zero, but supervision failed with
`rss-exit-cleanup-observation-unavailable`. The original constructor diagnostic
reports ESRCH during `post-bind-double-frontier`; it does not retain the exact
failed worker or that worker's positive terminal-event proof. Its later
leader-only snapshot cannot fill that original observation gap.

The original [supervisor](historical-d/supervisor.json),
[actual receipt](historical-d/actual-receipt.json) and
[abort record](historical-d/abort.json) are copied byte-for-byte with hashes and
original provenance in [the manifest](evidence.json). Nothing in this package
retroactively changes their outcome.

## Remaining gates

The sparse isolated development worktree excludes old historical evidence.
Preflight `--dev`, these component controls and read-only integrity checks do
not replace full committed-source repository checks, native campaigns or
natural-model hosted execution. No Cargo/native build is claimed for this
Python-only slice. The parent integration must publish a real immutable Chain
source/merge and a new paired Hepta selection while keeping old manifests
unchanged. The original host and model budgets, three actual ordinary rounds,
valid hold/no-update handling, subsequent ordinary readback and all prior
system, security and release gates still apply.
