#!/usr/bin/env bash
set -euo pipefail
ROOT=/workspace/scratch/29755d2a47ef/chain-decode-pages
OUT=/workspace/shared
SOURCE=6665c7a923a5401b67bd663869b6b95765a735c2
exec 9>"$OUT/init-marker-validation.lock"
flock -n 9 || { echo 'Validation already running; refusing duplicate.'; exit 75; }
cd "$ROOT"
test "$(git rev-parse HEAD)" = "$SOURCE"
test -z "$(git status --porcelain)"
bash scripts/project-preflight.sh
sha256sum -c "$OUT/init-marker-source.sha256"
export PATH=/workspace/shared/chain-cargo/bin:$PATH
export CARGO_HOME=/workspace/shared/chain-cargo
export RUSTUP_HOME=/workspace/shared/chain-rustup
export CARGO_TARGET_DIR=/workspace/shared/chain-confirmation-target
export CARGO_BUILD_JOBS=1
status() {
  printf '{"source":"%s","phase":"%s","status":"%s","exit_code":%s,"utc":"%s"}\n' "$SOURCE" "$1" "$2" "$3" "$(date -u +%FT%TZ)" > "$OUT/init-marker-validation-status.json.tmp"
  mv "$OUT/init-marker-validation-status.json.tmp" "$OUT/init-marker-validation-status.json"
}
run() {
  local phase=$1 log=$2
  shift 2
  status "$phase" running null
  set +e
  "$@" > "$OUT/$log" 2>&1
  local code=$?
  set -e
  if [ "$code" -ne 0 ]; then status "$phase" failed "$code"; exit "$code"; fi
  status "$phase" completed 0
}
CARGO=(cargo +1.95.0 test --locked --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib)
run build init-marker-final-build.txt "${CARGO[@]}" --no-run
run initialization init-marker-tests.txt "${CARGO[@]}" store::init_marker_tests -- --nocapture --test-threads=1
run native-owner init-marker-native.txt "${CARGO[@]}" store::native_authenticated:: -- --nocapture --test-threads=1
run mining init-marker-mining.txt "${CARGO[@]}" store::operator_mining_owner::tests -- --nocapture --test-threads=1
run continuous init-marker-continuous.txt "${CARGO[@]}" store::operator_continuous_owner::tests -- --nocapture --test-threads=1
run pq-startup init-marker-pq-startup.txt "${CARGO[@]}" operator_pq_startup::tests -- --nocapture --test-threads=1
run task-observation init-marker-task.txt "${CARGO[@]}" store::task_observation::tests -- --nocapture --test-threads=1
run wire init-marker-wire.txt "${CARGO[@]}" store::admission_wire_tests -- --nocapture --test-threads=1
run request init-marker-request.txt "${CARGO[@]}" ingress::public_v3::request_observation::tests -- --nocapture --test-threads=1
sha256sum -c "$OUT/init-marker-source.sha256"
status all completed 0
cat "$OUT/init-marker-validation-status.json"
