#!/usr/bin/env python3
"""Bind, then explicitly run one UNFUNDED sequential full-W1 experiment.

Preparing this file/configuration does not search for a winner or start a proof.
Only the separate ``run`` command dispatches work. Its caller supplies the one
original Linux CLOCK_MONOTONIC deadline and boot ID; no deadline is created here.
All evidence is written outside the source repository, exclusively to new paths.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import sys
import time
import uuid


TASK_ROOT = Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
REPO = TASK_ROOT / "repo"
INPUTS = TASK_ROOT / "experiment-inputs-01"
SCHEMA = "TRNM-W1-UNFUNDED-SEQUENTIAL-HARNESS1"
PREPARED_SCHEMA = "TRNM-W1-UNFUNDED-SEQUENTIAL-PREPARED1"
QUALIFICATION_SCHEMA = "TRNM-W1-CLEAN-BUILD-QUALIFICATION1"
MAX_BUDGET_NS = 7_200_000_000_000
PLAN = {"segment_workers": 1, "compression_mode": "sequential",
        "compression_workers": 1, "rayon_threads": 8, "comparison_repeats": 10,
        "native_max_attempts": 10000}
GRACE = {"outer_seconds": 30, "postwin_controller_seconds": 12,
         "inner_seconds": 5, "cleanup_extends_execution_deadline": False}
INPUT_PINS = {
    "material.bin": (32768, "6a0400bbe34f342e7fc2f89221884482f5e7ec0743745ed0916053ab97a22ce3"),
    "header-template-search0.bin": (318, "7b96038f228a1eedccf7b29ffc54802aba691be7259e33937846c6bf6126d78f"),
    "expected-artifacts.bin": (64, "802adcdd951cfb4cd7271df22c3bca6af66fee9f40454c74f8b5ff2c98a1b683"),
    "guest.bin": (375928, "25718312ec3c6f5219d832e3516adfb5f82983156f669c5e7daa15bd22d1798f"),
}
INPUT_MANIFEST_SHA = "0f2aacaf579f37d9b21bdf5f8e1df5d018b77ff032554d0758a8b16397af3a8d"
R0VM_SHA = "2acdf550f9aca4d05b74072463e4ed307c3824309c754a5cb5f93aa84f3390e6"
BINARY_NAMES = ("native_winner", "runner", "verifier", "owner_test", "r0vm")
SOURCE_PATHS = (
    "scripts/ci/verify_ci_source.py",
    "scripts/run_w1_postwin_proof.py",
    "scripts/run_w1_deployment_comparison.py",
    "scripts/run_w1_receiver.py",
    "formal/pon-nakamoto-v1/experiments/w1_stage_measure.py",
    "formal/pon-nakamoto-v1/experiments/w1_full_staged_run.py",
    "trillionnium/crates/trnm-crypto-primitives/examples/pon_w1_native_winner_v2.rs",
)


def fail(message):
    raise ValueError(message)


def strict_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            fail("duplicate JSON key: " + key)
        value[key] = item
    return value


def json_object(raw):
    value = json.loads(raw, object_pairs_hook=strict_object,
                       parse_constant=lambda _: fail("nonfinite JSON"))
    if type(value) is not dict:
        fail("JSON object required")
    return value


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def write_new(path, raw):
    path = Path(path)
    with path.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_json(path, value):
    write_new(path, canonical(value))


def stamp(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_size,
            value.st_mtime_ns, value.st_ctime_ns)


def file_record(path, *, maximum=None, collect=False):
    """Read a regular, non-symlink file; reject concurrent content/identity changes."""
    path = Path(path)
    if not path.is_absolute():
        fail("absolute file path required")
    original = path.lstat()
    if not stat.S_ISREG(original.st_mode):
        fail("regular file required: " + str(path))
    if maximum is not None and original.st_size > maximum:
        fail("file exceeds explicit bound: " + str(path))
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    digest = hashlib.sha256()
    chunks, length = [], 0
    try:
        initial = os.fstat(fd)
        if stamp(initial) != stamp(original):
            fail("file changed before read: " + str(path))
        while True:
            block = os.read(fd, 1024 * 1024)
            if not block:
                break
            length += len(block)
            if maximum is not None and length > maximum:
                fail("file grew beyond explicit bound: " + str(path))
            digest.update(block)
            if collect:
                chunks.append(block)
        if stamp(initial) != stamp(os.fstat(fd)) or stamp(initial) != stamp(path.lstat()):
            fail("file changed while read: " + str(path))
    finally:
        os.close(fd)
    if length != initial.st_size:
        fail("file length changed while read")
    value = {"path": str(path), "bytes": length, "sha256": digest.hexdigest(),
             "mode": stat.S_IMODE(initial.st_mode), "device": initial.st_dev,
             "inode": initial.st_ino, "mtime_ns": initial.st_mtime_ns,
             "ctime_ns": initial.st_ctime_ns}
    return (value, b"".join(chunks)) if collect else value


def read_json(path, maximum=16 * 1024 * 1024):
    record, raw = file_record(path, maximum=maximum, collect=True)
    return json_object(raw), record, raw


def require_hex(value, length):
    if type(value) is not str or re.fullmatch("[0-9a-f]{%d}" % length, value) is None:
        fail("canonical hexadecimal identity required")


def require_binding(actual, expected):
    if any(actual.get(key) != expected.get(key) for key in ("path", "bytes", "sha256")):
        fail("file identity differs from selected bytes: " + str(expected.get("path")))


def parse_qualification(value):
    if (value.get("schema") != QUALIFICATION_SCHEMA
            or value.get("qualification_complete") is not True
            or value.get("repo_path") != str(REPO)):
        fail("complete, explicit clean-A build qualification for the canonical repo required")
    for key in ("source_commit", "source_tree"):
        require_hex(value.get(key), 40)
    binaries = value.get("binaries")
    if type(binaries) is not dict or any(name not in binaries for name in BINARY_NAMES):
        fail("all five qualified binary records required")
    for name in BINARY_NAMES:
        item = binaries[name]
        if (type(item) is not dict or type(item.get("path")) is not str
                or not Path(item["path"]).is_absolute()
                or type(item.get("bytes")) is not int or item["bytes"] <= 0
                or type(item.get("kind")) is not str or not item["kind"]):
            fail("explicit qualified executable record required: " + name)
        require_hex(item.get("sha256"), 64)
    if binaries["r0vm"]["sha256"] != R0VM_SHA:
        fail("the original fixed CPU r0vm pin must not change")
    return value


def new_directory(path, forbidden):
    path = Path(path)
    if not path.is_absolute() or path.name in ("", ".", ".."):
        fail("absolute, new output directory required")
    actual = path.parent.resolve(strict=True) / path.name
    if actual != path or any(actual == root or root in actual.parents for root in forbidden):
        fail("output must be outside the source, inputs, and prepared evidence")
    actual.mkdir(mode=0o700, exist_ok=False)
    return actual


def constant(path, name):
    _, raw = file_record(path, maximum=256 * 1024, collect=True)
    values = [ast.literal_eval(node.value) for node in ast.parse(raw).body
              if isinstance(node, ast.Assign)
              and any(isinstance(target, ast.Name) and target.id == name for target in node.targets)]
    if len(values) != 1:
        fail("one explicit source constant required: " + name)
    return values[0]


def capture_bound_files(config):
    records = {}
    for label, selected in config["bound_files"].items():
        actual = file_record(Path(selected["path"]))
        require_binding(actual, selected)
        if label.startswith("binary/") and not os.access(actual["path"], os.X_OK):
            fail("qualified binary is not executable: " + label)
        records[label] = actual
    return records


def prepare(args):
    qualification, qrecord, qraw = read_json(args.qualification)
    parse_qualification(qualification)
    bound = {"qualification": qrecord, "harness": file_record(Path(__file__).resolve()),
             "python": file_record(Path(sys.executable).resolve(strict=True))}
    for name in BINARY_NAMES:
        selected = qualification["binaries"][name]
        actual = file_record(Path(selected["path"]))
        require_binding(actual, selected)
        if not os.access(actual["path"], os.X_OK):
            fail("qualified executable is not executable: " + name)
        bound["binary/" + name] = actual
    for name, (size, digest) in INPUT_PINS.items():
        actual = file_record(INPUTS / name)
        if actual["bytes"] != size or actual["sha256"] != digest:
            fail("actual new experiment input differs from fixed selection: " + name)
        bound["input/" + name] = actual
    actual = file_record(INPUTS / "manifest.json")
    if actual["sha256"] != INPUT_MANIFEST_SHA:
        fail("new input manifest differs from independently retained generation manifest")
    bound["input/manifest.json"] = actual
    for relative in SOURCE_PATHS:
        bound["source/" + relative] = file_record(REPO / relative)
    postwin = REPO / "scripts/run_w1_postwin_proof.py"
    observer = REPO / "formal/pon-nakamoto-v1/experiments/w1_stage_measure.py"
    if (constant(postwin, "CONTROLLER_TERMINATION_GRACE_SECONDS") != 12
            or constant(observer, "TERMINATION_GRACE_SECONDS") != 5
            or constant(observer, "MAX_TERMINATION_GRACE_SECONDS") != 30):
        fail("reviewed 30 > 12 > 5 cleanup hierarchy required")
    config = {"schema": PREPARED_SCHEMA, "status": "PREPARED_NOT_RUN",
              "source_commit": qualification["source_commit"],
              "source_tree": qualification["source_tree"], "repo_path": str(REPO),
              "qualification": qrecord, "binaries": qualification["binaries"],
              "bound_files": bound, "plan": PLAN, "termination_grace": GRACE,
              "required_cpu_affinity": list(range(12, 20)),
              "hepta_requested_cpu_quota_percent": 800,
              "hepta_requested_memory_max_bytes": 8 * 1024 ** 3,
              "funding_status": "UNFUNDED", "funding_qualified": False,
              "node_admission_qualified": False, "security_qualified": False,
              "resource_completeness_established": False,
              "deadline_selected_by_prepare": False, "proof_execution_performed": False,
              "fresh_native_input_required": True, "historical_receipt_import_permitted": False,
              "header_search0_note": "Actual existing template nonce was already zero; no new random seed is claimed."}
    out = new_directory(args.prepared, (REPO, INPUTS))
    write_new(out / "qualification.raw.json", qraw)
    write_json(out / "prepared.json", config)
    record = file_record(out / "prepared.json")
    result = {"schema": SCHEMA, "status": "PREPARED_NOT_RUN",
              "prepared": record, "proof_execution_performed": False,
              "native_winner_execution_performed": False, "funding_status": "UNFUNDED"}
    write_json(out / "preparation-result.json", result)
    print(json.dumps(result, sort_keys=True))
    return 0


def validate_deadline(deadline, supplied_boot, actual_boot, now):
    if type(deadline) is not int or not 0 < deadline - now <= MAX_BUDGET_NS:
        fail("original remaining deadline must be within (0,7200] seconds")
    if str(uuid.UUID(supplied_boot)) != supplied_boot or supplied_boot != actual_boot:
        fail("original deadline must belong to this actual local boot")


def deadline_seconds(deadline):
    # Never round an integer deadline upward when calling the seconds API.
    result = deadline / 1e9
    numerator, denominator = result.as_integer_ratio()
    if numerator * 1_000_000_000 > deadline * denominator:
        result = math.nextafter(result, -math.inf)
    return result


def resource_snapshot(out):
    out.mkdir(mode=0o700, exist_ok=False)
    result = {"schema": "TRNM-W1-UNFUNDED-RESOURCE-OBSERVATION1",
              "started_monotonic_ns": time.monotonic_ns(), "unix_ns": time.time_ns(),
              "pid": os.getpid(), "ppid": os.getppid(), "pgid": os.getpgrp(),
              "sid": os.getsid(0), "cwd": str(Path.cwd()),
              "affinity": sorted(os.sched_getaffinity(0)), "files": [], "namespaces": {},
              "process_tree_billing_complete": False, "aggregate_process_tree_peak_rss_bytes": None,
              "gpu_ns": None, "resource_completeness_established": False,
              "scope": "Raw observer proc/cgroup observations and sampled owned-session stage observations; no complete descendant meter."}
    paths = ["/proc/self/stat", "/proc/self/status", "/proc/self/statm", "/proc/self/limits",
             "/proc/self/io", "/proc/self/cgroup", "/proc/self/mountinfo", "/proc/uptime",
             "/proc/sys/kernel/random/boot_id"]
    cgroup_names = ("cpu.max", "cpu.stat", "memory.max", "memory.current", "memory.peak",
                    "memory.events", "cgroup.events", "cpuset.cpus.effective", "pids.current", "pids.max")
    cgroup_roots = {Path("/sys/fs/cgroup")}
    membership_roots = set()
    try:
        membership = Path("/proc/self/cgroup").read_text()
        mountinfo = Path("/proc/self/mountinfo").read_text()
        member = next(line.split(":", 2)[2] for line in membership.splitlines() if line.startswith("0::"))
        for line in mountinfo.splitlines():
            left, right = line.split(" - ", 1)
            if right.split()[0] != "cgroup2":
                continue
            columns = left.split()
            mount_root = Path(columns[3].replace("\\040", " "))
            mount_point = Path(columns[4].replace("\\040", " "))
            try:
                relative = Path(member).relative_to(mount_root)
            except ValueError:
                continue
            membership_roots.add(mount_point / relative)
            cgroup_roots.add(mount_point / relative)
        result["cgroup_membership_resolution"] = "OBSERVED_PATHS_ONLY"
    except (OSError, ValueError, StopIteration) as caught:
        result["cgroup_membership_resolution"] = {"status": "UNKNOWN", "type": type(caught).__name__, "message": str(caught)}
    result["membership_cgroup_paths"] = [str(path) for path in sorted(membership_roots)]
    paths.extend(str(root / name) for root in sorted(cgroup_roots) for name in cgroup_names)
    for index, path in enumerate(dict.fromkeys(paths)):
        row = {"path": path}
        try:
            with open(path, "rb") as stream:
                raw = stream.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                fail("bounded proc/cgroup observation exceeded")
            name = "%02d-%s.raw" % (index, Path(path).name)
            write_new(out / name, raw)
            row.update({"status": "OBSERVED", "raw_file": name, "bytes": len(raw),
                        "sha256": hashlib.sha256(raw).hexdigest()})
        except (OSError, ValueError) as caught:
            row.update({"status": "UNKNOWN", "error": {"type": type(caught).__name__, "errno": getattr(caught, "errno", None), "message": str(caught)}})
        result["files"].append(row)
    for name in ("pid", "mnt", "user", "net", "cgroup"):
        try:
            result["namespaces"][name] = {"status": "OBSERVED", "target": os.readlink("/proc/self/ns/" + name)}
        except OSError as caught:
            result["namespaces"][name] = {"status": "UNKNOWN", "message": str(caught)}
    result["finished_monotonic_ns"] = time.monotonic_ns()
    write_json(out / "observation.json", result)
    return result


def require_resource_sample(observation, directory):
    """Check the actually visible membership limits, without claiming a full meter."""
    if observation.get("affinity") != list(range(12, 20)):
        fail("actual affinity differs from the declared eight CPUs")
    roots = observation.get("membership_cgroup_paths")
    if type(roots) is not list or not roots or any(type(root) is not str for root in roots):
        fail("actual membership cgroup path is UNKNOWN")
    rows = {row["path"]: row for row in observation["files"]}

    def raw(path):
        row = rows.get(path)
        if type(row) is not dict or row.get("status") != "OBSERVED":
            fail("actual membership cgroup limit is UNKNOWN: " + path)
        record, data = file_record(directory / row["raw_file"], maximum=1024 * 1024, collect=True)
        if record["sha256"] != row["sha256"] or record["bytes"] != row["bytes"]:
            fail("raw membership limit observation changed")
        return data.decode("ascii").strip()

    matched = []
    for root in roots:
        cpu, memory = raw(root + "/cpu.max"), raw(root + "/memory.max")
        fields = cpu.split()
        if (len(fields) != 2 or not all(field.isdecimal() for field in fields)
                or int(fields[1]) <= 0 or int(fields[0]) != 8 * int(fields[1])
                or not memory.isdecimal() or int(memory) != 8 * 1024 ** 3):
            fail("observed membership quota/memory is not exactly 8 CPUs / 8 GiB")
        matched.append({"path": root, "cpu.max": cpu, "memory.max": memory})
    return {"status": "OBSERVED_SAMPLE_MATCHES", "limits": matched,
            "continuous_limit_enforcement_proven": False, "complete_process_tree_billing": False}


def strict_stage(value):
    if (value.get("schema") != "TRNM-W1-STAGE-MEASUREMENT3"
            or value.get("stage_process_complete") is not True
            or type(value.get("returncode")) is not int or value["returncode"] != 0
            or value.get("timed_out") is not False
            or value.get("completion_observed_before_deadline") is not True
            or value.get("owned_session_observation_complete") is not True
            or value.get("deadline_exhausted_at_snapshot") is not False
            or value.get("process_group_remaining_after_child_exit") is not False
            or any(value.get(key) is not None for key in ("error", "canceled_signal", "cancellation_event"))
            or any(value.get(key) != [] for key in ("termination_reasons", "cleanup_errors", "proc_scan_errors", "group_probe_errors", "members_after_child_exit", "final_owned_session_members"))):
        fail("owned observed process did not complete with a known clean handoff")
    probes, groups = value.get("final_known_group_probes"), value.get("known_owned_groups")
    if (type(probes) is not list or type(groups) is not list or not groups
            or any(type(group) is not int or group <= 0 for group in groups)
            or any(type(row) is not dict or row.get("state") != "ABSENT"
                   or type(row.get("group")) is not int for row in probes)
            or sorted(row["group"] for row in probes) != sorted(groups)):
        fail("every known owned process group must have an explicit ABSENT final probe")


def source_result(path, config):
    value, record, _ = read_json(path)
    if (value.get("schema") != "trnm-ci-source-v1" or value.get("kind") != "head"
            or value.get("tested_commit") != config["source_commit"]
            or value.get("tested_tree") != config["source_tree"]
            or value.get("candidate") != config["source_commit"]
            or value.get("tracked_worktree_verified") is not True
            or value.get("tests_executed_by_identity_check") is not False):
        fail("full exact-source check did not bind the selected commit and tree")
    return record


def load_measure(config):
    path = REPO / "formal/pon-nakamoto-v1/experiments/w1_stage_measure.py"
    require_binding(file_record(path), config["bound_files"]["source/" + str(path.relative_to(REPO))])
    spec = importlib.util.spec_from_file_location("unfunded_fixed_w1_stage_measure", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if module.TERMINATION_GRACE_SECONDS != 5 or module.MAX_TERMINATION_GRACE_SECONDS != 30:
        fail("fixed inner/outer grace contract changed")
    return module


def error_record(failure):
    return {"type": type(failure).__name__, "message": str(failure),
            "errno": getattr(failure, "errno", None)}


def execute_run(args, config, measure):
    deadline_ns = args.original_deadline_monotonic_ns
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    validate_deadline(deadline_ns, args.original_deadline_boot_id, boot, time.monotonic_ns())
    if sorted(os.sched_getaffinity(0)) != list(range(12, 20)):
        fail("the caller must actually set CPU affinity 12..19 before launch")
    deadline = deadline_seconds(deadline_ns)
    launch_cwd = str(Path.cwd())
    out = new_directory(args.out, (REPO, INPUTS, args.prepared.resolve()))
    os.chdir(REPO)
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ["RAYON_NUM_THREADS"] = "8"
    python = config["bound_files"]["python"]["path"]
    binaries = config["binaries"]
    winner_out, postwin_out = out / "native-winner", out / "postwin"
    winner_argv = [binaries["native_winner"]["path"], str(INPUTS / "material.bin"),
        str(INPUTS / "expected-artifacts.bin"), str(INPUTS / "header-template-search0.bin"),
        str(winner_out), str(deadline_ns), boot, str(PLAN["native_max_attempts"])]
    postwin_argv = [python, str(REPO / "scripts/run_w1_postwin_proof.py"),
        "--winner-dir", str(winner_out), "--out", str(postwin_out)]
    for name in ("runner", "r0vm", "verifier"):
        postwin_argv.extend(["--" + name, binaries[name]["path"], "--" + name + "-sha256", binaries[name]["sha256"]])
    postwin_argv.extend(["--segment-workers", "1", "--compression-mode", "sequential",
        "--compression-workers", "1", "--rayon-threads", "8", "--comparison-repeats", "10"])
    intent = {"schema": SCHEMA, "status": "DISPATCH_INTENT_ONLY", "funding_status": "UNFUNDED",
        "funding_qualified": False, "node_admission_qualified": False, "security_qualified": False,
        "original_business_budget_reproduced": False, "resource_completeness_established": False,
        "source_commit": config["source_commit"], "source_tree": config["source_tree"],
        "prepared_sha256": args.prepared_sha256, "qualification": config["qualification"],
        "entered_monotonic_ns": args.harness_entered_monotonic_ns,
        "intent_monotonic_ns": time.monotonic_ns(), "original_deadline_monotonic_ns": deadline_ns,
        "original_deadline_boot_id": boot, "launch_cwd": launch_cwd, "execution_cwd": str(Path.cwd()),
        "plan": PLAN, "termination_grace": GRACE, "native_winner_argv": winner_argv,
        "postwin_argv": postwin_argv, "fresh_checkpoint": str(postwin_out / "checkpoint"),
        "checkpoint_preexists": (postwin_out / "checkpoint").exists(),
        "historical_receipt_imported": False,
        "read_only_source_after_audit_budget_seconds": 60,
        "source_after_audit_is_proof_work": False,
        "source_after_audit_can_extend_original_execution_deadline": False,
        "requested_resources": {"cpu_quota_percent": 800, "memory_max_bytes": 8 * 1024 ** 3,
                                "affinity": list(range(12, 20))}}
    write_json(out / "intent.json", intent)
    rows, errors, source_checks, terminal_bindings, resource_samples = [], [], {}, {}, {}
    failure = None
    first_cancellation = None

    def observed_stage(label, argv, *, audit_after=False, grace=30):
        if not audit_after and time.monotonic_ns() >= deadline_ns:
            raise TimeoutError("original deadline exhausted before " + label)
        row = {"label": label, "argv": argv, "dispatch_recorded": True,
               "result": None, "status": "UNKNOWN", "read_only_post_execution_audit": audit_after}
        rows.append(row)
        try:
            result = measure.measure(argv, out / ("measure-" + label),
                60.0 if label.startswith("source-") else 7200.0,
                deadline=None if audit_after else deadline,
                environment_overrides={"RAYON_NUM_THREADS": "8", "PYTHONDONTWRITEBYTECODE": "1"},
                termination_grace_seconds=grace)
            row["result"] = file_record(out / ("measure-" + label) / "result.json")
            strict_stage(result)
            row["status"] = "OBSERVED_COMPLETE"
            return result
        except BaseException as caught:
            row["error"] = error_record(caught)
            raw_result = out / ("measure-" + label) / "result.json"
            if raw_result.is_file() and row["result"] is None:
                try:
                    row["result"] = file_record(raw_result)
                except (OSError, ValueError) as observation_error:
                    row["result_read_error"] = error_record(observation_error)
            raise

    def exact_source(which, audit_after=False):
        destination = out / ("exact-source-" + which + ".json")
        checker = REPO / "scripts/ci/verify_ci_source.py"
        require_binding(file_record(checker), config["bound_files"]["source/scripts/ci/verify_ci_source.py"])
        argv = [python, str(REPO / "scripts/ci/verify_ci_source.py"), "--kind", "head",
                "--expected-head", config["source_commit"], "--output", str(destination)]
        observed_stage("source-" + which, argv, audit_after=audit_after, grace=5)
        source_checks[which] = source_result(destination, config)

    try:
        before = capture_bound_files(config)
        write_json(out / "files-before.json", before)
        resource_before = resource_snapshot(out / "resources-before")
        resource_samples["before"] = require_resource_sample(resource_before, out / "resources-before")
        exact_source("before")
        if winner_out.exists() or postwin_out.exists():
            fail("fresh native winner and fresh postwin output paths required")
        observed_stage("native-winner", winner_argv)
        winner, winner_record, _ = read_json(winner_out / "result.json")
        terminal_bindings["winner"] = winner_record
        winner_intent, _, _ = read_json(winner_out / "intent.json")
        if (winner.get("schema") != "TRNM-W1-NATIVE-WINNER2"
                or winner.get("winner_observed") is not True
                or winner.get("native_replay_verified") is not True
                or winner.get("native_ticket_before_deadline") is not True
                or winner.get("winner_saved_before_deadline") is not True
                or winner.get("original_deadline_monotonic_ns") != deadline_ns
                or winner.get("original_deadline_boot_id") != boot
                or winner_intent.get("material_sha256") != INPUT_PINS["material.bin"][1]
                or winner_intent.get("header_template_sha256") != INPUT_PINS["header-template-search0.bin"][1]
                or winner.get("expected_artifacts_sha256") != INPUT_PINS["expected-artifacts.bin"][1]):
            fail("actual new winner does not bind original deadline and independent raw inputs")
        observed_stage("postwin", postwin_argv)
        postwin, postwin_record, _ = read_json(postwin_out / "result.json")
        terminal_bindings["postwin"] = postwin_record
        if (postwin.get("schema") != "TRNM-W1-POSTWIN-PROOF2"
                or postwin.get("operation_complete") is not True
                or postwin.get("full_proof_verified_observed") is not True
                or postwin.get("error") is not None or postwin.get("cancellation_event") is not None
                or postwin.get("deadline_exhausted_at_snapshot") is not False
                or (postwin_out / "operation-cancellation.json").exists()):
            fail("postwin raw observation is not a complete eligible operation")
    except BaseException as caught:
        failure = caught
        errors.append({"phase": "execution", **error_record(caught)})
        if isinstance(caught, (measure.Canceled, KeyboardInterrupt)):
            first_cancellation = caught

    # All dispatch below is bounded, read-only evidence finalization. No proof,
    # retry, winner, receiver, or comparison can be dispatched after this point.
    with measure.DeferredCancellation(first_cancellation, phase="unfunded-final-evidence",
                                      live_deadline=(deadline, boot)) as handoff:
        try:
            exact_source("after", audit_after=True)
        except BaseException as caught:
            errors.append({"phase": "source-after", **error_record(caught)})
            if failure is None:
                failure = caught
            if isinstance(caught, (measure.Canceled, KeyboardInterrupt)) and first_cancellation is None:
                first_cancellation = caught
        try:
            write_json(out / "files-after.json", capture_bound_files(config))
        except (OSError, ValueError) as caught:
            errors.append({"phase": "files-after", **error_record(caught)})
        try:
            resource_after = resource_snapshot(out / "resources-after")
            resource_samples["after"] = require_resource_sample(resource_after, out / "resources-after")
        except (OSError, ValueError) as caught:
            errors.append({"phase": "resources-after", **error_record(caught)})
        raw_results, reported_proof, postwin_clock = {}, None, None
        for label, path in (("winner", winner_out / "result.json"),
                            ("postwin", postwin_out / "result.json"),
                            ("controller", postwin_out / "controller/result.json"),
                            ("receiver_ack", postwin_out / "receiver/ack.json")):
            try:
                value, record, _ = read_json(path)
                if label in terminal_bindings:
                    require_binding(record, terminal_bindings[label])
                raw_results[label] = record
                if label == "controller" and value.get("schema") == "TRNM-W1-COMPLETE-STAGED-RUN3":
                    reported_proof = value.get("complete_proof_claim")
                if label == "postwin":
                    postwin_clock = {key: value.get(key) for key in ("native_event_provenance_authority",
                        "parent_observed_receiver_ack_monotonic_ns", "winner_to_receiver_seconds", "winner_latency_scope")}
            except (OSError, ValueError) as caught:
                raw_results[label] = {"status": "UNKNOWN_OR_ABSENT", "error": error_record(caught)}
                errors.append({"phase": "raw-" + label, **error_record(caught)})
        receipt_path = postwin_out / "checkpoint/succinct.bin"
        try:
            receipt = file_record(receipt_path, maximum=16 * 1024 * 1024)
        except (OSError, ValueError) as caught:
            receipt = {"status": "UNKNOWN_OR_ABSENT", "error": error_record(caught)}
            errors.append({"phase": "raw-receipt", **error_record(caught)})
        now = time.monotonic_ns()
        eligible = (not errors and failure is None and first_cancellation is None
                    and handoff.canceled_signal is None and now < deadline_ns
                    and reported_proof is True and set(source_checks) == {"before", "after"}
                    and set(resource_samples) == {"before", "after"})
        report = {**intent, "status": "PRE_HANDOFF_OBSERVATION",
            "result_is_pre_handoff_snapshot": True, "eligible_at_snapshot": eligible,
            "actual_harness_exit_zero_required_for_completion": True,
            "operation_cancellation_sidecar_always_vetoes": True,
            "original_deadline_exhausted_at_snapshot": now >= deadline_ns,
            "snapshot_monotonic_ns": now, "source_checks": source_checks,
            "resource_limit_samples": resource_samples,
            "stages": rows, "errors": errors, "raw_results": raw_results, "receipt": receipt,
            "controller_complete_proof_claim_reported": reported_proof,
            "postwin_clock_observation": postwin_clock,
            "cancellation_event": handoff.pending_event(),
            "caught_cancellation": (measure.cancellation_details(first_cancellation, "unfunded-harness")
                                    if first_cancellation is not None else None),
            "prover_population_p99_established": False, "deployment_benefit_qualified": False,
            "process_tree_billing_complete": False, "aggregate_process_tree_peak_rss_bytes": None,
            "gpu_ns": None, "security_qualified": False,
            "no_funding_or_consensus_effect_dispatched": True}
        write_json(out / "result.json", report)
        handoff.published_snapshot("unfunded-harness", out / "result.json")
        if first_cancellation is not None:
            raise first_cancellation
    # A result file alone never proves timely final publication. A late final
    # fsync/print cannot upgrade the operation; caller retains this process exit.
    print(json.dumps({"schema": SCHEMA, "eligible_at_snapshot": report["eligible_at_snapshot"],
                      "funding_status": "UNFUNDED", "result": str(out / "result.json")}), flush=True)
    if time.monotonic_ns() >= deadline_ns:
        return 124
    return 0 if report["eligible_at_snapshot"] else 1


def run(args):
    args.harness_entered_monotonic_ns = time.monotonic_ns()
    actual_boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    validate_deadline(args.original_deadline_monotonic_ns, args.original_deadline_boot_id,
                      actual_boot, args.harness_entered_monotonic_ns)
    config, record, _ = read_json(args.prepared.resolve() / "prepared.json")
    require_hex(args.prepared_sha256, 64)
    if record["sha256"] != args.prepared_sha256:
        fail("prepared original bytes changed")
    if (config.get("schema") != PREPARED_SCHEMA or config.get("status") != "PREPARED_NOT_RUN"
            or config.get("plan") != PLAN or config.get("termination_grace") != GRACE
            or config.get("repo_path") != str(REPO) or config.get("funding_status") != "UNFUNDED"):
        fail("fixed UNFUNDED sequential prepared contract required")
    capture_bound_files(config)
    qualification, _, _ = read_json(Path(config["qualification"]["path"]))
    parse_qualification(qualification)
    if any(qualification[key] != config[key] for key in ("source_commit", "source_tree", "binaries")):
        fail("prepared qualification identity changed")
    sys.dont_write_bytecode = True
    measure = load_measure(config)

    def owned_run():
        with measure.cancel_on_signals():
            try:
                return execute_run(args, config, measure)
            except (measure.Canceled, KeyboardInterrupt) as caught:
                if args.out.is_dir():
                    measure.publish_cancellation(args.out / "operation-cancellation.json", caught, "unfunded-harness")
                raise

    return measure.run_cli(owned_run)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare", help="bind qualified inputs only; no winner/proof execution")
    prep.add_argument("--qualification", type=Path, required=True)
    prep.add_argument("--prepared", type=Path, required=True)
    launch = sub.add_parser("run", help="explicit owner launch; uses only caller's original deadline")
    launch.add_argument("--prepared", type=Path, required=True)
    launch.add_argument("--prepared-sha256", required=True)
    launch.add_argument("--out", type=Path, required=True)
    launch.add_argument("--original-deadline-monotonic-ns", type=int, required=True)
    launch.add_argument("--original-deadline-boot-id", required=True)
    args = parser.parse_args(argv)
    return prepare(args) if args.command == "prepare" else run(args)


if __name__ == "__main__":
    raise SystemExit(main())
