#!/usr/bin/env python3
"""Import one pinned Chain bundle into a new worktree and retain validation.

This task runner is intended for desktop's HeptaRuntime operator PTY. It never
publishes, resets an existing checkout, installs dependencies, runs cargo fetch,
or changes the existing provider/target. Failed observations remain on disk.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone


BASE_COMMIT = "e4abb172147e941b62483652b0ceabaae4317624"
BRANCH = "fix/chain-w1-oracle-evidence-20261110-0776"
COMMON_REPO = Path("/home/qian-qi/worktrees/trnm-encoding-precheck-20261018")
WORKTREE_PARENT = Path("/home/qian-qi/worktrees")
WORKTREE_NAME = "chain-w1-oracle-evidence-0776"
PROVIDER = Path(
    "/home/qian-qi/chain-stark-route-validation-7e8b/"
    "provider-clippy-eeeaafbc742d-retry01/"
    "trnm-pq-provider-3.5.9.wUXuiklK/install"
)
PROVIDER_FILES = (
    "bin/openssl", "include/openssl/opensslv.h",
    "include/openssl/configuration.h", "lib/libcrypto.a", "lib/libssl.a",
)
GIT = "/usr/bin/git"
GH = "/usr/bin/gh"
CARGO = "/home/qian-qi/.cargo/bin/cargo"
RUSTC = "/home/qian-qi/.cargo/bin/rustc"
TOOLCHAIN_BIN = Path("/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin")
PYTHON = "/usr/bin/python3"
GIT_OPTIONS = (
    "--no-replace-objects", "--no-optional-locks",
    "-c", "credential.helper=",
    "-c", "credential.helper=!/usr/bin/gh auth git-credential",
)
ALLOWED_ORIGINS = (
    "https://github.com/TrillionniumFoundation/Trillionnium-Chain",
    "https://github.com/TrillionniumFoundation/Trillionnium-Chain.git",
    "git@github.com:TrillionniumFoundation/Trillionnium-Chain.git",
)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def fingerprint(info: os.stat_result) -> tuple:
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def hash_regular(path: Path) -> dict:
    """Read a stable regular file without following its final symlink."""
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), f"not a regular file: {path}")
        digest = hashlib.sha256()
        total = 0
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
            total += len(chunk)
        require(fingerprint(before) == fingerprint(os.fstat(stream.fileno())),
                f"file changed while reading: {path}")
    require(fingerprint(before) == fingerprint(path.lstat()),
            f"file path changed while reading: {path}")
    require(total == before.st_size, f"file length changed: {path}")
    return {"path": str(path), "bytes": total, "sha256": digest.hexdigest(),
            "mode": stat.S_IMODE(before.st_mode)}


def write_json(path: Path, value: object) -> None:
    """All record names are unique inside a newly created private directory."""
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


class Recorder:
    def __init__(self, root: Path, environment: dict[str, str]):
        self.root = root
        self.environment = environment
        self.steps: list[dict] = []

    def command(self, name: str, argv: list[str], *, cwd: Path,
                timeout: int = 600, allowed_exit_codes: tuple[int, ...] = (0,),
                environment: dict[str, str] | None = None) -> dict:
        require(re.fullmatch(r"[a-z0-9-]+", name) is not None, "bad step name")
        require(not any(s["name"] == name for s in self.steps), "duplicate step")
        stdout_path = self.root / (name + ".stdout.log")
        stderr_path = self.root / (name + ".stderr.log")
        started = now()
        begin = time.monotonic()
        process = None
        exception = None
        timed_out = False
        cleanup = []
        returncode = None
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            try:
                process = subprocess.Popen(
                    argv, cwd=cwd, env=environment or self.environment,
                    stdout=stdout, stderr=stderr, stdin=subprocess.DEVNULL,
                    start_new_session=True,
                )
                try:
                    returncode = process.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    timed_out = True
                    # This process group was created by this exact invocation.
                    try:
                        os.killpg(process.pid, signal.SIGTERM)
                        cleanup.append("owned-group-SIGTERM")
                    except ProcessLookupError:
                        cleanup.append("owned-group-already-exited")
                    try:
                        returncode = process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        cleanup.append("owned-group-SIGKILL")
                        returncode = process.wait()
            except Exception as error:
                exception = {"type": type(error).__name__, "message": str(error)}
            stdout.flush()
            stderr.flush()
            os.fsync(stdout.fileno())
            os.fsync(stderr.fileno())
        step = {
            "name": name, "argv": argv, "cwd": str(cwd),
            "started_utc": started, "finished_utc": now(),
            "elapsed_seconds": time.monotonic() - begin,
            "timeout_seconds": timeout, "timed_out": timed_out,
            "exit_code": returncode, "exception": exception, "cleanup": cleanup,
            "expected_exit_codes": list(allowed_exit_codes),
            "passed": (exception is None and not timed_out
                       and returncode in allowed_exit_codes),
            "stdout": hash_regular(stdout_path), "stderr": hash_regular(stderr_path),
        }
        self.steps.append(step)
        write_json(self.root / (name + ".receipt.json"), step)
        print(json.dumps({"step": name, "exit_code": returncode,
                          "passed": step["passed"], "timed_out": timed_out,
                          "elapsed_seconds": step["elapsed_seconds"]}), flush=True)
        return step

    def stdout(self, name: str) -> str:
        return (self.root / (name + ".stdout.log")).read_text(encoding="utf-8")


def provider_snapshot() -> dict:
    return {name: hash_regular(PROVIDER / name) for name in PROVIDER_FILES}


def copy_bundle(source: Path, target: Path, expected_sha256: str) -> dict:
    before = hash_regular(source)
    require(before["bytes"] <= 128 * 1024 * 1024, "bundle exceeds task size bound")
    require(before["sha256"] == expected_sha256, "input bundle SHA-256 mismatch")
    # The copied private input, not the caller's replaceable path, is consumed.
    fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as original, target.open("xb") as copied:
        require(stat.S_ISREG(os.fstat(original.fileno()).st_mode), "bundle type changed")
        shutil.copyfileobj(original, copied, 1024 * 1024)
        copied.flush()
        os.fsync(copied.fileno())
    result = hash_regular(target)
    require(result["sha256"] == expected_sha256 and result["bytes"] == before["bytes"],
            "private bundle copy differs from pinned bytes")
    return {"input": before, "private_copy": result}


def git(root: Path, *args: str) -> list[str]:
    return [GIT, *GIT_OPTIONS, "-C", str(root), *args]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", required=True, type=Path)
    parser.add_argument("--bundle-sha256", required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--worktree", required=True, type=Path)
    args = parser.parse_args()
    require(re.fullmatch(r"[0-9a-f]{40}", args.commit) is not None, "commit must be a full SHA-1")
    require(re.fullmatch(r"[0-9a-f]{64}", args.bundle_sha256) is not None, "bad bundle SHA-256")
    worktree = args.worktree
    require(worktree.is_absolute() and worktree.name == WORKTREE_NAME,
            "worktree must use this task's dedicated absolute path")
    require(worktree.parent == WORKTREE_PARENT and worktree.parent.resolve() == WORKTREE_PARENT,
            "worktree parent differs from the reviewed directory")
    require(not os.path.lexists(worktree), "worktree already exists; inspect it, never overwrite")
    require(COMMON_REPO.is_dir(), "reviewed object repository is missing")
    require(args.bundle.is_absolute(), "bundle path must be absolute")
    routing = [key for key in ("GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE",
                              "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES")
               if os.environ.get(key)]
    require(not routing, "Git routing overrides are present: " + ",".join(routing))

    records = Path(tempfile.mkdtemp(
        prefix=f"{WORKTREE_NAME}-validation-{args.commit[:12]}-", dir=WORKTREE_PARENT))
    target = records / "cargo-target"
    target.mkdir()
    environment = dict(os.environ)
    environment.update({
        "PATH": "/home/qian-qi/.cargo/bin:/usr/local/bin:/usr/bin:/bin",
        "GIT_TERMINAL_PROMPT": "0", "GIT_NO_REPLACE_OBJECTS": "1",
        "CARGO_BUILD_JOBS": "2", "CARGO_INCREMENTAL": "0",
        "CARGO_TARGET_DIR": str(target), "CARGO_HOME": "/home/qian-qi/.cargo",
        "RUSTUP_TOOLCHAIN": "1.95.0", "RUSTUP_HOME": "/home/qian-qi/.rustup",
        "RUSTC": str(TOOLCHAIN_BIN / "rustc"), "RUSTDOC": str(TOOLCHAIN_BIN / "rustdoc"),
        "CARGO_TERM_COLOR": "never",
        "RUST_TEST_THREADS": "1", "PYTHONDONTWRITEBYTECODE": "1",
        "RUSTFLAGS": "", "RUSTDOCFLAGS": "",
    })
    # No inherited wrapper or encoded flag may silently cap strict Clippy lints.
    for key in ("CARGO_ENCODED_RUSTFLAGS", "CARGO_ENCODED_RUSTDOCFLAGS",
                "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "GIT_NO_LAZY_FETCH",
                "CARGO_BUILD_TARGET"):
        environment.pop(key, None)
    recorder = Recorder(records, environment)
    summary = {
        "schema": "trnm-w1-oracle-desktop-validation-v1", "started_utc": now(),
        "source_commit": args.commit, "expected_base": BASE_COMMIT,
        "branch": BRANCH, "worktree": str(worktree), "records": str(records),
        "cargo_target_dir": str(target), "runner": hash_regular(Path(__file__).resolve()),
        "published": False, "production_activation": False,
        "security_qualified": False, "native_tests_executed": False,
        "status": "RUNNING", "source_unchanged": None,
        "provider_unchanged": None, "skipped": [], "errors": [],
        "build_policy": {"cargo_build_jobs": 2, "cargo_incremental": 0,
                         "toolchain": "1.95.0", "offline": True,
                         "automatic_dependency_fetch": False,
                         "rustflags": "", "rustdocflags": "",
                         "encoded_flags_and_wrappers_removed": True},
    }
    print(json.dumps({"records": str(records), "worktree": str(worktree),
                      "source_commit": args.commit}), flush=True)
    write_json(records / "invocation.json", {**summary, "argv": sys.argv})

    def must(name: str, argv: list[str], cwd: Path, timeout: int = 600,
             allowed_exit_codes: tuple[int, ...] = (0,)) -> dict:
        step = recorder.command(name, argv, cwd=cwd, timeout=timeout,
                                allowed_exit_codes=allowed_exit_codes)
        require(step["passed"], "required setup step failed: " + name)
        return step

    source_before = None
    provider_before = None
    source_guard_ready = False
    try:
        summary["bundle"] = copy_bundle(args.bundle, records / "input.bundle", args.bundle_sha256)
        must("github-login", [GH, "api", "user", "--jq", ".login"], COMMON_REPO, 60)
        require(recorder.stdout("github-login").strip() == "ProfHepta", "GitHub login differs")

        # Avoid emitting any credential-bearing origin if an old local config is wrong.
        origin_code = (
            "import json,subprocess,sys; "
            f"r=subprocess.run({git(COMMON_REPO, 'remote', 'get-url', 'origin')!r},"
            "stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True); "
            f"ok=r.returncode==0 and r.stdout.strip() in {ALLOWED_ORIGINS!r}; "
            "print(json.dumps({'origin_canonical':ok,'origin_read_exit':r.returncode})); "
            "sys.exit(0 if ok else 1)"
        )
        must("canonical-origin", [PYTHON, "-c", origin_code], COMMON_REPO, 30)
        must("branch-absent", git(COMMON_REPO, "show-ref", "--verify", "--quiet",
                                  "refs/heads/" + BRANCH), COMMON_REPO, 30, (1,))
        bundle = str(records / "input.bundle")
        must("bundle-verify", git(COMMON_REPO, "bundle", "verify", bundle), COMMON_REPO, 600)
        must("bundle-heads", git(COMMON_REPO, "bundle", "list-heads", bundle), COMMON_REPO, 60)
        heads = [line.split() for line in recorder.stdout("bundle-heads").splitlines()]
        require(any(len(row) == 2 and row[0] == args.commit for row in heads),
                "requested commit is not a bundle head")
        must("bundle-unbundle", git(COMMON_REPO, "bundle", "unbundle", bundle), COMMON_REPO, 600)
        must("base-ancestry", git(COMMON_REPO, "merge-base", "--is-ancestor",
                                  BASE_COMMIT, args.commit), COMMON_REPO, 600)
        must("create-worktree", git(COMMON_REPO, "worktree", "add", "-b", BRANCH,
                                    str(worktree), args.commit), COMMON_REPO, 1800)
        must("project-preflight", ["/bin/bash", "scripts/project-preflight.sh", "--dev"], worktree, 600)
        guard = [PYTHON, "scripts/ci/verify_ci_source.py", "--kind", "head",
                 "--expected-head", args.commit]
        must("source-before", guard + ["--output", str(records / "source-before.json")],
             worktree, 1800)
        source_before = json.loads((records / "source-before.json").read_text())
        require(source_before.get("tested_commit") == args.commit
                and source_before.get("tracked_worktree_verified") is True,
                "source guard did not confirm exact tracked bytes")
        summary["source_before"] = source_before
        source_guard_ready = True
        must("rustc-version", [RUSTC, "--version"], worktree, 30)
        require(recorder.stdout("rustc-version").startswith("rustc 1.95.0 "),
                "rustc is not 1.95.0")
        must("cargo-version", [CARGO, "--version"], worktree, 30)
        require(recorder.stdout("cargo-version").startswith("cargo 1.95.0 "),
                "cargo is not 1.95.0")

        # Provider qualification here binds these actual bytes/version only;
        # it does not claim a new provider build or hardware/security result.
        try:
            provider_before = provider_snapshot()
            write_json(records / "provider-before.json", provider_before)
            # openssl-sys accepts target-prefixed overrides before generic ones.
            # Remove those inherited path/library choices, then bind this prefix.
            for key in list(environment):
                if key.endswith(("_OPENSSL_DIR", "_OPENSSL_LIB_DIR", "_OPENSSL_INCLUDE_DIR",
                                 "_OPENSSL_STATIC", "_OPENSSL_LIBS", "_OPENSSL_NO_VENDOR")):
                    environment.pop(key, None)
            environment.pop("OPENSSL_LIBS", None)
            environment.update({
                "OPENSSL_DIR": str(PROVIDER), "OPENSSL_STATIC": "1",
                "OPENSSL_LIB_DIR": str(PROVIDER / "lib"),
                "OPENSSL_INCLUDE_DIR": str(PROVIDER / "include"), "OPENSSL_NO_VENDOR": "1",
                "OPENSSL_CONF": "/dev/null", "OPENSSL_MODULES": str(PROVIDER / "lib/ossl-modules"),
                "TRNM_PQ_OPENSSL": str(PROVIDER / "bin/openssl"),
                "TRNM_PQ_OPENSSL_SHA256": provider_before["bin/openssl"]["sha256"],
                "TRNM_PQ_OPENSSL_VERSION": "3.5.9",
                "LD_LIBRARY_PATH": str(PROVIDER / "lib") + ":" + str(PROVIDER / "lib64"),
            })
            version = recorder.command("provider-version", [str(PROVIDER / "bin/openssl"), "version"],
                                       cwd=worktree, timeout=30)
            require(version["passed"] and recorder.stdout("provider-version").startswith("OpenSSL 3.5.9 "),
                    "selected provider version was not observed")
            summary["provider"] = {"prefix": str(PROVIDER), "files": provider_before,
                                   "scope": "existing installed bytes/version; no new build",
                                   "build_environment": {key: environment[key] for key in
                                       ("OPENSSL_DIR", "OPENSSL_LIB_DIR", "OPENSSL_INCLUDE_DIR",
                                        "OPENSSL_STATIC", "OPENSSL_NO_VENDOR", "OPENSSL_CONF",
                                        "OPENSSL_MODULES", "TRNM_PQ_OPENSSL", "TRNM_PQ_OPENSSL_SHA256",
                                        "TRNM_PQ_OPENSSL_VERSION", "LD_LIBRARY_PATH")}}
        except Exception as error:
            summary["errors"].append({"stage": "provider", "error": str(error)})
            provider_before = None

        checks = [
            ("metadata-default", [CARGO, "metadata", "--locked", "--offline", "--format-version", "1",
                                  "--manifest-path", "trillionnium/Cargo.toml"], 600),
            ("metadata-all-features", [CARGO, "metadata", "--locked", "--offline", "--all-features",
                                       "--format-version", "1", "--manifest-path", "trillionnium/Cargo.toml"], 600),
            ("metadata-fuzz", [CARGO, "metadata", "--locked", "--offline", "--format-version", "1",
                               "--manifest-path", "tests/fuzz/Cargo.toml"], 600),
            ("format", [CARGO, "fmt", "--manifest-path", "trillionnium/Cargo.toml", "--all", "--", "--check"], 600),
        ]
        for name, argv, timeout in checks:
            recorder.command(name, argv, cwd=worktree, timeout=timeout)
        if provider_before is not None:
            recorder.command(
                "strict-clippy", [CARGO, "clippy", "--locked", "--offline", "--manifest-path",
                                  "trillionnium/Cargo.toml", "--workspace", "--all-targets",
                                  "--all-features", "--", "-D", "warnings"],
                cwd=worktree, timeout=7200,
            )
        else:
            summary["skipped"].append({"step": "strict-clippy", "reason": "provider input binding failed"})
    except Exception as error:
        summary["errors"].append({"stage": "setup-or-source", "type": type(error).__name__, "error": str(error)})
    finally:
        if source_guard_ready:
            try:
                recorder.command("project-preflight-after",
                                 ["/bin/bash", "scripts/project-preflight.sh", "--dev"],
                                 cwd=worktree, timeout=600)
                after_step = recorder.command(
                    "source-after", [PYTHON, "scripts/ci/verify_ci_source.py", "--kind", "head",
                                     "--expected-head", args.commit, "--output", str(records / "source-after.json")],
                    cwd=worktree, timeout=1800,
                )
                if after_step["passed"]:
                    source_after = json.loads((records / "source-after.json").read_text())
                    summary["source_after"] = source_after
                    summary["source_unchanged"] = source_before == source_after
                else:
                    summary["source_unchanged"] = False
            except Exception as error:
                summary["source_unchanged"] = False
                summary["errors"].append({"stage": "source-after", "error": str(error)})
        if provider_before is not None:
            try:
                provider_after = provider_snapshot()
                write_json(records / "provider-after.json", provider_after)
                summary["provider_unchanged"] = provider_after == provider_before
            except Exception as error:
                summary["provider_unchanged"] = False
                summary["errors"].append({"stage": "provider-after", "error": str(error)})
        summary["finished_utc"] = now()
        summary["steps"] = [{key: step[key] for key in
                              ("name", "exit_code", "passed", "timed_out", "elapsed_seconds")}
                             for step in recorder.steps]
        required_checks = {"metadata-default", "metadata-all-features", "metadata-fuzz", "format", "strict-clippy"}
        observed_passes = {step["name"] for step in recorder.steps if step["passed"]}
        passed = (not summary["errors"] and not summary["skipped"]
                  and all(step["passed"] for step in recorder.steps)
                  and required_checks <= observed_passes
                  and summary["source_unchanged"] is True
                  and summary["provider_unchanged"] is True)
        summary["status"] = "VALIDATION_PASSED" if passed else "VALIDATION_INCOMPLETE_OR_FAILED"
        write_json(records / "summary.json", summary)
        print(json.dumps({"summary_path": str(records / "summary.json"), **summary}, sort_keys=True), flush=True)
    return 0 if summary["status"] == "VALIDATION_PASSED" else 1


if __name__ == "__main__":
    sys.exit(main())
