#!/usr/bin/env python3
"""Finalize only explicitly reviewed Root V6 source pins after formatting."""
from pathlib import Path
import argparse, copy, hashlib, json, os, re, subprocess, sys, time
parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, required=True)
parser.add_argument("--plan-sha256", required=True)
parser.add_argument("--out", type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
base = "8970e2c81abbf48e2a4d3f0802d79624ab20fadd"
checkpoint = Path("/workspace/scratch/df05fc75c9e2/chain-root-gates-df05-checkpoint.json")
candidate = Path("/workspace/scratch/df05fc75c9e2/chain-root-gates-recovery/CANDIDATE_MANIFEST.json")
c = json.loads(checkpoint.read_text())
cm = json.loads(candidate.read_text())
config = "config/pon/pq-root-dependency-register-v3.json"
corpus_path = "config/pon/pq-cross-branch-corpus-v1.json"
inventory = "trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs"
checker = "scripts/ci/pq_root_dependency_register.py"
plan = "docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md"
contract = "docs/security/ROOT_EXECUTION_CONTINUATION_V6.md"
durable = "trillionnium/crates/trnm-pon-node/src/root_recovery_v3/witnessed_v5/durable.rs"
provider = "trillionnium/crates/trnm-pon-node/src/root_recovery_v3/effect_readback_v4.rs"
provider_test = "trillionnium/crates/trnm-pon-node/tests/root_witness_provider_v5_native.rs"
helper = "trillionnium/crates/trnm-pon-node/src/root_recovery_v3/witnessed_v5/durable/receipts.rs"
receipt_test = "trillionnium/crates/trnm-pon-node/tests/root_witness_v6_receipts_native.rs"
reviewed = {
    durable: "3b52cfe561ef2fba926ca5ffba111d2f555883c33dc1ae8f38d5d9fa687583e3",
    provider: "95e56a2e3ef3b9906bc1dc59e79533af64b910c0ebf8bfad9041ee84ab824c93",
    provider_test: "7e44ff2ce367583a4e2aacbc741556d195440f7024ad910dcd79b7d33b837d7c",
    helper: "9cc60b9f9ca2cddae696defc65b7946193cfb4c6f08a6ff5d2f3e986511d9831",
    receipt_test: "28527efd9d0e7f82992736b7ed5041fd0afb0b82853103f4789c8bef5a3d078e",
}
assert re.fullmatch(r"[0-9a-f]{64}", args.plan_sha256)
assert not args.out.exists(), "observation path must be fresh; preserve all previous failures"
args.out.mkdir(parents=True)
env = os.environ.copy()
env["PYTHONPYCACHEPREFIX"] = str(args.out / "fresh-pycache")
env["PYTHONDONTWRITEBYTECODE"] = "1"
sys.pycache_prefix = env["PYTHONPYCACHEPREFIX"]
sys.dont_write_bytecode = True
def run(command, name, cwd=root):
    value = subprocess.run(command, cwd=cwd, env=env, text=True, capture_output=True)
    (args.out / (name + ".stdout")).write_text(value.stdout)
    (args.out / (name + ".stderr")).write_text(value.stderr)
    print(json.dumps({"name":name,"exit":value.returncode,"stdout_tail":value.stdout[-500:],"stderr_tail":value.stderr[-2000:]}), flush=True)
    value.check_returncode()
    return value.stdout
def raw(path):
    return subprocess.check_output(["git","show",base+":"+path], cwd=root)
def sha(path):
    return hashlib.sha256((root/path).read_bytes()).hexdigest()
def write(path, text):
    p = root/path
    with p.open("w", encoding="utf-8", newline="") as f:
        f.write(text); f.flush(); os.fsync(f.fileno())
run(["bash","scripts/project-preflight.sh"],"preflight-before")
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()==base
for path, expected in reviewed.items():
    assert sha(path)==expected, "format/source differs from explicitly reviewed SHA: "+path
for path in c["new_gate_file_candidates"]:
    assert (root/path).read_text()==c["new_gate_file_candidates"][path], "gate preimage drift: "+path
assert sha(inventory)==cm["files"][inventory]["sha256"], "inventory preimage drift"
assert sha(contract)==c["reviewed_external_sha256"][contract], "contract preimage drift"
assert sha(plan)==args.plan_sha256, "sole plan preimage drift"
for path in (config, corpus_path):
    assert (root/path).read_bytes()==raw(path), "already changed config; reconcile instead of overwrite: "+path
sys.path.insert(0,str(root/"scripts/ci"))
namespace = {"__name__":"reviewed_gate_maintenance", "__file__":str(root/checker)}
exec(compile((root/checker).read_text(),str(root/checker),"exec"),namespace)
old_manifest = json.loads(raw(config))
old_corpus = json.loads(raw(corpus_path))
new_map = dict(old_manifest["source_files_sha256"])
changes = []
for path, old in list(new_map.items()):
    current = sha(path)
    if current!=old:
        assert path in {durable,provider,provider_test}, "unreviewed old source drift: "+path
        assert current==reviewed[path]
        new_map[path]=current
        changes.append({"path":path,"previous":old,"current":current,"kind":"reviewed-change"})
for path in (helper,receipt_test):
    assert path not in new_map
    new_map[path]=reviewed[path]
    changes.append({"path":path,"previous":None,"current":reviewed[path],"kind":"reviewed-addition"})
assert len(old_manifest["source_files_sha256"])==43 and len(new_map)==45
assert set(new_map)==set(namespace["SOURCE_PATHS"])
new_manifest = copy.deepcopy(namespace["FROZEN"])
new_manifest["source_files_sha256"]=new_map
def preserve(old,new,path=""):
    if path=="/source_files_sha256": return
    if path=="/primitives/sha512/use_ids":
        assert sorted(new)==sorted(old+["native-retained-witness-receipts-v6"]); return
    if isinstance(old,dict):
        assert isinstance(new,dict)
        for key,value in old.items():
            assert key in new
            preserve(value,new[key],path+"/"+key)
    else: assert type(old) is type(new) and old==new, "old frozen field changed: "+path
preserve(old_manifest,new_manifest)
new_snapshot=namespace["source_snapshot_digest"](new_map)
assert new_snapshot=="844d27717babb9b3a286cd28915a06b0cd1152ffcf151ffdf6c30a01708bd9fe"
pattern=r"REVIEWED_SOURCE_SNAPSHOT_SHA256 = '[0-9a-f]{64}'"
checker_text=(root/checker).read_text()
assert len(re.findall(pattern,checker_text))==1
write(checker,re.sub(pattern,"REVIEWED_SOURCE_SNAPSHOT_SHA256 = '"+new_snapshot+"'",checker_text,count=1))
write(config,json.dumps(new_manifest,indent=2,sort_keys=True)+"\n")
owned=[*c["new_gate_file_candidates"],config,inventory,durable,provider,provider_test,helper,receipt_test,plan,contract]
corpus=copy.deepcopy(old_corpus)
pin_changes=[]
for path in owned:
    blob=subprocess.check_output(["git","hash-object",path],cwd=root,text=True).strip()
    previous=corpus["pinned_blobs"].get(path)
    if previous!=blob:
        corpus["pinned_blobs"][path]=blob
        pin_changes.append({"path":path,"previous":previous,"current":blob})
    if path not in corpus["required_paths"]:
        assert path in {helper,receipt_test,contract}
        corpus["required_paths"].append(path)
for key,value in old_corpus.items():
    if key not in {"pinned_blobs","required_paths"}: assert corpus[key]==value
for path,blob in old_corpus["pinned_blobs"].items():
    if path not in owned: assert corpus["pinned_blobs"][path]==blob
assert corpus["required_paths"][:len(old_corpus["required_paths"])]==old_corpus["required_paths"]
write(corpus_path,json.dumps(corpus,indent=2,sort_keys=True)+"\n")
before={path:sha(path) for path in owned+[corpus_path]}
run(["python3","-B","-m","unittest","-v","test_run_pq_root_witness_v5","test_pq_root_dependency_register"],
    "root-register-and-roster-controls",root/"scripts/ci")
run(["python3","-B",checker],"root-register-current")
run(["python3","-B","scripts/refresh_distributed_source_inventory.py","--check"],"inventory-check")
run(["git","diff","--check"],"diff-check")
run(["bash","scripts/project-preflight.sh"],"preflight-after")
after={path:sha(path) for path in owned+[corpus_path]}
assert before==after,"source changed during validation"
report={
    "base":base,"worktree":str(root),"source_map_changes":changes,
    "old_source_count":43,"new_source_count":45,"reviewed_source_snapshot_sha256":new_snapshot,
    "corpus_pin_changes":pin_changes,"old_corpus_metadata_preserved":True,
    "old_frozen_fields_preserved_except_shared_sha512_use_addition":True,
    "source_before_equals_after":True,"modified_files_sha256":after,
    "actual_lifetime_failure_bound":None,"whole_chain_pq_qualified":False,
    "production_activation":False,"native_component_tests":"NOT_RUN_BY_THIS_JOB",
    "prior_native_failed_gate_observation":"retained in original checkpoint and native job 1a1ceb49821-2564-17e6",
    "prior_native_fresh_job":"1a1ceb5dc89-2564-17f6: UNKNOWN; these results are separate cloud-source observations",
    "python_bytecode_policy":"new unique PYTHONPYCACHEPREFIX and no bytecode writes"}
with (args.out/"GATES_REVIEW.json").open("x") as f:
    json.dump(report,f,indent=2); f.write("\n"); f.flush(); os.fsync(f.fileno())
print(json.dumps(report),flush=True)
