# Trillionnium-Chain

Trillionnium-Chain develops the protocol, execution, state and operator components
for Trillionnium. The HIA migration implements and tests native machine-code
components against the retained original Rust behavior.

## Current development

The [HIA implementation guide](hia/README.md) describes the implemented kernels,
native owners, build commands and exact qualification scope. The current HIA
candidate contains 41 kernels, 21 native foundations and 129 HIA source files.
The held-disk Node/M05 owner connects native State, transaction verification,
nonce admission, Ready consumption and Parent/Prefix execution.

The complete project remains in migration. All 26 original Rust packages remain
part of the implementation and differential tests. The nine whole-project gates
in the [migration inventory](config/hia-migration-v1.json) govern full replacement
and retirement.

## Repository guide

| Area | Entry point |
| --- | --- |
| Development sequence and ownership | [Sole development plan](docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md) and [M00-M17 inventory](config/portability-inventory-v1.json) |
| HIA code, build and validation | [HIA guide](hia/README.md) and [source audit](hia/AUDIT.md) |
| Original packages | [Rust workspace](trillionnium/Cargo.toml) |
| Source and execution observations | [Qualification archive guide](hia/qualification/ARCHIVES.md) |
| Contribution boundary | [AGENTS.md](AGENTS.md) |
| Operational and release status | [Operations](OPERATIONS.md) and [readiness](RELEASE_READINESS.md) |

Before modifying or building this repository, run `bash scripts/project-preflight.sh`
and follow the development branch and source-ownership rules in AGENTS.md.
