import pathlib,subprocess,re,hashlib,json,shutil,time,resource
s=pathlib.Path('/home/qq/chain-host-stat-20261118-2e9b-source');out=pathlib.Path('/home/qq/chain-native-root-body-delay-20261118-2e9b-validation/write-complete-v4/inline-pins-1');assert not out.exists();out.mkdir()
def run(name,args):
 start=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:p=subprocess.Popen(args,cwd=s,stdout=so,stderr=se);rc=p.wait(timeout=1800)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);v={'name':name,'command':args,'returncode':rc,'wall_seconds':time.monotonic()-start,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};print(json.dumps(v),flush=True);return v
pre=run('preflight',['bash','scripts/project-preflight.sh']);assert pre['returncode']==0
wf=s/'.github/workflows/pon-recent-batch-acceptance.yml';cor=s/'config/pon/pq-cross-branch-corpus-v1.json'
blob=lambda raw:hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
assert blob(wf.read_bytes())=='8ea263306c96daae7c0f3759b466218a5994d945'
for p in (wf,cor):
 d=out/'before'/p.relative_to(s);d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
text=wf.read_text();changes=[]
for path,old,new in [('trillionnium/crates/trnm-pon-node/src/store.rs','7942a89b4395834183741df95a43872fa4db002c','feb66e96059121ee71b4e4951547ec58f9707a56'),('trillionnium/crates/trnm-pon-node/src/store/native_authenticated.rs','babaade9c1b7d7e8fceac68655f99efc8bd78cc4','4a17366fee9591e3229b44617064e2d13af2df33')]:
 assert blob((s/path).read_bytes())==new
 oldline='test "$(git hash-object '+path+')" = '+old;assert text.count(oldline)==1;text=text.replace(oldline,oldline[:-40]+new);changes.append({'path':path,'old_literal':old,'actual_blob':new,'d952_blob':subprocess.check_output(['git','rev-parse','d95239eda6a666458aa264ddeaf993d6d9fbf37d:'+path],cwd=s,text=True).strip()})
wf.write_text(text)
c=json.loads(cor.read_text());key=str(wf.relative_to(s));assert c['pinned_blobs'][key]=='8ea263306c96daae7c0f3759b466218a5994d945';c['pinned_blobs'][key]=blob(wf.read_bytes());cor.write_text(json.dumps(c,indent=2,sort_keys=True)+'\n')
receipt={'schema':'chain-inline-guard-refresh-v1','changes':changes,'workflow_logic_changed':False,'original_gate_preserved':True,'pinned_count':len(c['pinned_blobs']),'qualification_changed':False,'f0_qualified':False,'stages':[pre],'files':{str(p.relative_to(s)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'git_blob':blob(p.read_bytes())} for p in (wf,cor)}}
(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name,args in [('ci-contract',['python3','-B','scripts/ci/check_ci_contract.py']),('pq-exact-source',['python3','-B','scripts/ci/check_pq_research_integration.py'])]:
 receipt['stages'].append(run(name,args));(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
receipt['finished_ns']=str(time.time_ns());receipt['original_files']={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in out.rglob('*') if p.is_file() and p.name!='RESULT.json'};(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
