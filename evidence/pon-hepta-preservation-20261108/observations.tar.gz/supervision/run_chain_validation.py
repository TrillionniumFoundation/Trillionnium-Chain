from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/workspace/scratch/ac851b3fedf0/chain-integrated')
workspace = root.parent
out = workspace / 'chain-validation-runtime-91dd3082'
out.mkdir(exist_ok=False)
head = '91dd3082633ea0b3a5ec9b0ed91f28603229be01'
env = os.environ.copy()
env.update({
    'RUSTUP_HOME': str(workspace / 'toolchains/rustup'),
    'CARGO_HOME': str(workspace / 'toolchains/cargo'),
    'CARGO_TARGET_DIR': str(workspace / 'target-chain-integrated'),
    'CARGO_BUILD_JOBS': '1',
    'CARGO_INCREMENTAL': '0',
    'RUST_TEST_THREADS': '1',
    'CARGO_TERM_COLOR': 'never',
    'PYTHONDONTWRITEBYTECODE': '1',
})
env['PATH'] = str(workspace / 'toolchains/cargo/bin') + os.pathsep + env['PATH']
for line in (workspace / 'provider/provider.env').read_text().splitlines():
    key, value = line.split('=', 1)
    env[key] = value
env['TRNM_GROUPED_NATIVE'] = str(workspace / 'target-chain-integrated/debug/examples/pon_routed_int257_grouped')

cargo = ['cargo', '+1.95.0']
manifest = ['--manifest-path', 'trillionnium/Cargo.toml', '--locked', '--offline']
commands = [
    ('preflight', ['bash', 'scripts/project-preflight.sh']),
    ('graph-default', cargo + ['metadata'] + manifest + ['--format-version', '1']),
    ('graph-all-features', cargo + ['metadata'] + manifest + ['--all-features', '--format-version', '1']),
    ('service-settlement', cargo + ['test'] + manifest + ['-p', 'trnm-service-settlement', '--all-features']),
    ('crypto-library', cargo + ['test'] + manifest + ['-p', 'trnm-crypto-primitives', '--lib', '--all-features']),
    ('grouped-session', cargo + ['test'] + manifest + ['-p', 'trnm-crypto-primitives', '--example', 'pon_routed_int257_grouped', '--all-features']),
    ('grouped-cli-build', cargo + ['build'] + manifest + ['-p', 'trnm-crypto-primitives', '--example', 'pon_routed_int257_grouped', '--all-features']),
    ('grouped-cross-language', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'formal/pon-nakamoto-v1', '-p', 'test_grouped_cell_operator_v0.py', '-v']),
    ('legal-optimizations', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'formal/pon-nakamoto-v1', '-p', 'test_grouped_legal_strategy_v0.py', '-v']),
    ('factor-reference', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'formal/pon-nakamoto-v1', '-p', 'test_grouped_low_rank_v0.py', '-v']),
    ('service-no-update-reference', ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'formal/pon-nakamoto-v1', '-p', 'test_service_work_settlement_v1.py', '-v']),
    ('node-payment-integration', cargo + ['test'] + manifest + ['-p', 'trnm-pon-node', '--test', 'native_task_operation_v2', '--test', 'no_gain_fees', '--all-features', '--', '--test-threads=1']),
    ('strict-workspace-clippy', cargo + ['clippy'] + manifest + ['--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings']),
    ('workspace-format', cargo + ['fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check']),
    ('source-integrity-controls', ['python3', '-u', '-B', 'scripts/ci/test_ci_source_integrity.py']),
    ('ci-contract-controls', ['python3', '-u', '-B', 'scripts/ci/test_ci_contract.py']),
    ('corpus-controls', ['python3', '-u', '-B', 'scripts/ci/test_pq_research_integration.py']),
    ('ci-contract', ['python3', '-B', 'scripts/ci/check_ci_contract.py']),
    ('source-inventory', ['python3', '-B', 'scripts/refresh_distributed_source_inventory.py', '--check']),
    ('corpus-identity', ['python3', '-B', 'scripts/ci/check_pq_research_integration.py']),
    ('repository-links', ['python3', '-B', 'scripts/ci/check_repository.py']),
    ('repository-controls', ['python3', '-u', '-B', 'scripts/ci/test_repository.py']),
]

tools = {}
for name, command in [('rustc', ['rustc', '+1.95.0', '--version', '--verbose']), ('cargo', cargo + ['--version']), ('python', ['python3', '--version']), ('openssl', [env['TRNM_PQ_OPENSSL'], 'version']), ('git', ['git', '--version'])]:
    result = subprocess.run(command, cwd=root, env=env, text=True, capture_output=True)
    tools[name] = {'argv': command, 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
(out / 'toolchain.json').write_text(json.dumps(tools, indent=2) + '\n')
(out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
results = []
for label, command in commands:
    print('RUN', label, flush=True)
    if command[0] == 'cargo':
        check = subprocess.run(['bash', 'scripts/project-preflight.sh'], cwd=root, env=env, capture_output=True)
        if check.returncode:
            raise RuntimeError('preflight failed before ' + label)
    argv = ['python3', '-u', '-B', 'scripts/ci/record_pq_native_command.py', '--kind', 'head', '--candidate', head, '--tested', head, '--label', label, '--output', str(out), '--'] + command
    result = subprocess.run(argv, cwd=root, env=env, text=True, capture_output=True)
    (out / (label + '.recorder.log')).write_text(result.stdout + result.stderr)
    receipt = json.loads((out / (label + '.json')).read_text())
    results.append({'label': label, 'recorder_exit_code': result.returncode, 'status': receipt['status'], 'exit_code': receipt['exit_code'], 'receipt': label + '.json', 'elapsed_ns': receipt['elapsed_ns']})
    (out / 'summary.json').write_text(json.dumps({'tested_commit': head, 'results': results, 'complete': len(results) == len(commands), 'all_commands_succeeded': len(results) == len(commands) and all(x['status'] == 'command_succeeded' and x['recorder_exit_code'] == 0 for x in results), 'production_activation': False}, indent=2) + '\n')
    print('RESULT', label, receipt['status'], receipt['exit_code'], flush=True)
    if receipt['status'] == 'record_failed':
        raise RuntimeError('Source-bound recording failed; refusing to continue: ' + label)
print('COMPLETE', len(results), flush=True)
sys.exit(0 if all(x['recorder_exit_code'] == 0 for x in results) else 1)
