"""Independent reduced-input review; no physical calibration or native admission."""
from pathlib import Path
import sys, hashlib, json, struct
from copy import deepcopy
from dataclasses import replace
from fractions import Fraction as F

ROOT = Path('/workspace/scratch/c9b48df754d6/chain-quantum-next')
FORMAL = ROOT / 'formal/pon-nakamoto-v1'
sys.path.insert(0, str(FORMAL))
from test_w1_quantum_oracle import fixture
from quantum_oracle_resources import ClassicalCosts, example
from w1_quantum_oracle import Shape, FixedTemplate
from w1_marked_domain import enumerate_domain
from w1_machine_envelope import LifecycleModel, NOISE_CONTRACT
from w1_machine_architecture import (ServiceArchitecture, build_service_architecture,
    CALIBRATION_SCHEMA, CALIBRATION_REQUIREMENTS, validate_calibration_manifest)
from w1_preprocessing_cache import PayloadLRU, produce

reviewed = [FORMAL / name for name in ('w1_machine_architecture.py', 'w1_machine_envelope.py',
    'w1_preprocessing_cache.py', 'w1_preprocessing_reuse.py',
    'experiments/w1_preprocessing_cache_campaign.py', 'experiments/w1_service_architecture_frontier.py')]
def source_map():
    return {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in reviewed}
source_before_review = source_map()
checks = 0

def eq(left, right, label):
    global checks
    checks += 1
    assert left == right, (label, left, right)

def ok(value, label):
    global checks
    checks += 1
    assert value, label

def frac(record):
    return F(record['numerator'], record['denominator'])

def frame(tag, *parts):
    return b'TRNM-PON1\0' + len(tag).to_bytes(2, 'little') + tag + b''.join(
        len(part).to_bytes(4, 'little') + part for part in parts)

def field(values):
    return b''.join(x.to_bytes(4, 'little') for x in values)

# Inputs are explicitly hypothetical reduced fixtures. Expected events/times are
# derived below without calling the machine planner, event aggregator or checker.
base = fixture(nonce_bits=3)
domain = enumerate_domain(base)
physical = replace(example(True).physical_models[0], magic_state_error='1e-50', cycle_ns='1')
life = LifecycleModel('independent-hypothetical-review', NOISE_CONTRACT,
    2, 7, 3, 2, 2, 5, 3, 11, 16, 13, '0.01', '1e-40', '1e-40', '1e-40', '1e-50', '1e-30', '1e-30')
cost = ClassicalCosts(11, 13, 17, 19, 23, 29)
service_cases = []
for processors in (1, 3):
    for ports in (1, 17):
        arch = ServiceArchitecture('independent-service-cell', ports, 2, 3, 5, 11, 2, 4096)
        report = build_service_architecture((domain,), ((0, 0), (0, 1)), processors, (cost,),
            physical, life, arch, 10**16, '4', reserved_maximum_winners=2)
        machine = report['machine_record']; envelope = machine['envelope']; units = machine['domain_resources'][0]
        d = envelope['code_distance_for_whole_schedule']
        auxiliary = 3 * ports + 2 * 5 + 11
        width = units['logical_qubits'] + auxiliary
        eq(envelope['logical_patches_reserved_and_initialized_per_processor'], width, 'total width')
        init_batches = (width + ports - 1) // ports
        read_batches = (base.nonce_bits + 1) // 2
        expected_events = dict(initialization_patches=2 * processors * width,
            readout_bits=2 * processors * base.nonce_bits, transfer_bytes=0, controller_commands=0,
            magic_state_services=0, factory_attempt_slots=0, factory_discard_reset_slots=0,
            factory_startups=0, host_calls_including_reserved_proofs=2, proofs_reserved=2, propagations=2)
        total_scaled = total_fixed = 0
        expected_search = F(0)
        for trial, q in enumerate((0, 1)):
            row = machine['planned_rounds'][trial]
            states = units['prepare_units']['t_states'] + q * units['iteration_units']['t_states']
            gates = units['prepare_gate_commands'] + q * units['iteration_gate_commands']
            attempts = states * 16
            controller = gates + attempts + init_batches + read_batches + int(states > 0)
            scaled = dict(initialize=2 * init_batches, factory_startup=11 if states else 0,
                logical_gates=units['prepare_units']['data_cycles_per_distance'] + q * units['iteration_units']['data_cycles_per_distance'],
                factory_attempt_service=attempts * physical.factory_t_cycles_per_distance,
                factory_discard_reset=13 * attempts, terminal_readout=3 * read_batches)
            eq(row['cycles_per_distance_per_processor'], scaled, 'all quantum phases')
            eq(row['controller_fixed_cycles_per_processor'], 2 * controller, 'controller waits')
            total_scaled += sum(scaled.values()); total_fixed += 2 * controller
            entering = int(trial == 0)
            input_size = processors * units['controller_input_bytes'] * entering
            output_size = processors * ((base.nonce_bits + 7) // 8)
            messages = processors * (entering + 1)
            classical = dict(task_preprocessing=11 * entering, processor_setup=13 * processors * entering,
                input_transfer=5 * processors * entering + 3 * input_size,
                host_readout_turnaround=17, output_transfer=5 * processors + 3 * output_size,
                candidate_checks=19 * processors, winner_proof=23, winner_propagation=29)
            eq(row['classical_nanoseconds'], classical, 'all host/shared-bus phases')
            expected_events['transfer_bytes'] += input_size + output_size
            expected_events['controller_commands'] += processors * controller
            expected_events['magic_state_services'] += processors * states
            expected_events['factory_attempt_slots'] += processors * attempts
            expected_events['factory_discard_reset_slots'] += processors * attempts
            expected_events['factory_startups'] += processors * int(states > 0)
            expected_events['host_calls_including_reserved_proofs'] += (1 + processors) * entering + 2 * processors
            search = F((sum(scaled.values()) * d + 2 * controller), 10**9) + F(sum(classical.values()) - 52, 10**9)
            eq(frac(row['search_seconds_exact']), search, 'search exact clock')
            expected_search += search
        eq(envelope['events_all_processors'], expected_events, 'all P event vector')
        locations = processors * width * (total_scaled * d + total_fixed)
        eq(envelope['live_data_patch_cycles_all_processors'], locations, 'all P live-patch cycles')
        exact_fixed = (F('1e-40') * (expected_events['initialization_patches'] + expected_events['readout_bits'] + expected_events['transfer_bytes'])
            + F('1e-50') * (expected_events['controller_commands'] + expected_events['magic_state_services'])
            + expected_events['magic_state_services'] * F('0.01')**16
            + F('1e-30') * (expected_events['host_calls_including_reserved_proofs'] + 2))
        def exact_union(distance):
            live = processors * width * (total_scaled * distance + total_fixed)
            return exact_fixed + live * F(physical.logical_error_prefactor) * (F(physical.physical_error) / F(physical.threshold))**((distance + 1) // 2)
        ok(exact_union(d) <= frac(envelope['whole_plan_failure_union_upper']) <= F(physical.total_failure_budget), 'outward whole-plan fault union')
        ok(all(exact_union(smaller) > F(physical.total_failure_budget) for smaller in range(3, d, 2)), 'common minimal odd distance')
        physical_qubits = processors * (width * physical.data_physical_qubits_per_d2 + physical.factories_per_instance * physical.factory_physical_qubits_per_d2) * d*d
        eq(envelope['physical_qubits_all_processors'], physical_qubits, 'all P physical allocation')
        reserved = expected_search + F(104, 10**9)
        resources = report['resources']
        eq(frac(resources['complete_plan_seconds_reserved']), reserved, 'two reserved winner services')
        eq(frac(resources['physical_qubit_seconds_reserved']), physical_qubits * reserved, 'full allocation through plan')
        for key, count in (('initialization_port', processors * ports), ('readout_port', processors * 2),
                           ('controller_core', processors * 2), ('controller_memory_byte', processors * 4096)):
            eq(frac(resources[key + '_seconds_reserved']), count * reserved, 'reserved service-time product')
        eq(resources['initialization_port_code_cycles_reserved'], processors * ports * d * 4 * init_batches, 'all port initialization cycles')
        eq(resources['readout_port_code_cycles_reserved'], processors * 2 * d * 6 * read_batches, 'all port readout cycles')
        ok(all(value is False for value in report['claims'].values()), 'no service qualification')
        service_cases.append(dict(processors=processors, initialization_ports=ports, distance=d,
            physical_qubits=physical_qubits, reserved_seconds=str(reserved)))

# A fabricated but well-formed declaration may pass document checks only.
raw = b'Independent review deliberately supplies no real calibration evidence.'
sha = hashlib.sha256(raw).hexdigest()
manifest = dict(schema=CALIBRATION_SCHEMA, target_binding_sha256=report['calibration_binding_sha256'],
    hardware_id='unverified-independent-review', recorded_at_unix_seconds=1000,
    valid_until_unix_seconds=2000, artifacts=[dict(sha256=sha, bytes=len(raw), provenance='unverified review fixture')],
    coverage=[dict(requirement=x, artifact_sha256=sha, statement='Unverified coverage assertion.') for x in CALIBRATION_REQUIREMENTS])
def check_manifest(value, payloads=None, now=1500):
    return validate_calibration_manifest(report, value, {sha: raw} if payloads is None else payloads,
        now_unix_seconds=now, maximum_age_seconds=1000)
result = check_manifest(manifest)
eq(result['status'], 'PROVENANCE_AND_COVERAGE_ONLY', 'cannot self-qualify')
for flag in ('artifact_authenticity_or_claim_truth_verified', 'conditional_error_bounds_established',
             'calibrated_complete_machine_cost_closed', 'quantum_hardware_executed_by_reader', 'quantum_mining_qualified'):
    eq(result[flag], False, flag)
for case in ('missing', 'changed_bytes', 'future', 'new_qualification'):
    changed = deepcopy(manifest); payloads = None; now = 1500
    if case == 'missing': changed['coverage'].pop()
    if case == 'changed_bytes': payloads = {sha: raw + b'!'}
    if case == 'future': now = 999
    if case == 'new_qualification': changed['quantum_mining_qualified'] = True
    try: check_manifest(changed, payloads, now)
    except ValueError: checks += 1
    else: raise AssertionError(('calibration mutation accepted', case))

# Independent direct-byte scalar proof relation, avoiding the cache producer and
# its relation checker for the expected result.
def reference(template, nonce):
    n, r, modulus = template.shape.n, template.shape.r, template.shape.q
    header = bytearray(template.header)
    header[template.nonce_offset:template.nonce_offset+8] = nonce.to_bytes(8, 'little')
    challenge = hashlib.sha256(frame(template.challenge_tag, bytes(header))).digest()
    factors = []
    for label in range(4):
        accepted = []
        for counter in range(template.shape.noise_counters):
            digest = hashlib.sha256(frame(b'noise', challenge, bytes([label]), counter.to_bytes(4, 'little'))).digest()
            accepted.extend(value for offset in range(0, 32, 4)
                if (value := (int.from_bytes(digest[offset:offset+4], 'little') & ((1 << template.shape.field_bits) - 1))) < modulus)
            if len(accepted) >= n*r: break
        if len(accepted) < n*r: return challenge, None, None, None
        factors.append(accepted[:n*r])
    def mm(left, right, rows, inner, cols):
        result = []
        for row in range(rows):
            for col in range(cols):
                acc = 0
                for k in range(inner): acc = (acc + left[row*inner+k] * right[k*cols+col]) % modulus
                result.append(acc)
        return result
    noise_a = mm(factors[0], factors[1], n, r, n); noise_b = mm(factors[2], factors[3], n, r, n)
    aa = [(a+e) % modulus for a,e in zip(template.a, noise_a)]
    bb = [(b+f) % modulus for b,f in zip(template.b, noise_b)]
    current = [0] * (n*n); transcript = b'TRNM-PON-TRACE1\0' + challenge
    for rowtile in range(n // r):
        for coltile in range(n // r):
            for ktile in range(n // r):
                block = []
                for i in range(rowtile*r, (rowtile+1)*r):
                    for j in range(coltile*r, (coltile+1)*r):
                        for k in range(ktile*r, (ktile+1)*r):
                            current[i*n+j] = (current[i*n+j] + aa[i*n+k]*bb[k*n+j]) % modulus
                        block.append(current[i*n+j])
                transcript += field(block)
    trace = hashlib.sha256(transcript).digest()
    ticket = hashlib.sha256(frame(b'ticket', challenge, trace)).digest()
    proof = b'PNW1' + field(template.a) + field(template.b) + field(mm(template.a, template.b, n, n, n)) + trace
    return challenge, proof, trace, ticket

base = fixture(shape=Shape(2, 1, 4, 2), nonce_bits=3)
def header_change(template, index, value=None):
    header = bytearray(template.header)
    if value is None: header[index] ^= 1
    else: header[index:index+len(value)] = value
    return FixedTemplate.from_header(bytes(header), template.a, template.b, template.nonce_bits, template.shape)
parent = header_change(base, 70)
hard = header_change(base, 118, (1).to_bytes(32, 'big'))
b = ((base.b[0]+1) % base.shape.q,) + base.b[1:]
header = bytearray(base.header); header[278:310] = hashlib.sha256(frame(b'task', field(base.a), field(b))).digest()
task = FixedTemplate.from_header(bytes(header), base.a, b, base.nonce_bits, base.shape)
growth = fixture(shape=base.shape, profile='PGH2', nonce_bits=3)
templates = (base, parent, hard, task, growth)
schedule = [(index, nonce) for nonce in (0, 1) for index in range(len(templates))]
cache_cases = []; reference_proofs = {}
for capacity in (0, 262144):
    cache = PayloadLRU(capacity); computed = reused = misses = 0; cold_noise = cold_trace = 0
    for context, nonce in schedule:
        template = templates[context]
        record, proof = produce(template, nonce, cache)
        challenge, expected, trace, ticket = reference(template, nonce)
        eq(proof, expected, 'entire independently generated proof')
        ok(proof is not None, 'complete reduced attempt')
        eq(record['challenge'], challenge.hex(), 'challenge identity')
        eq(record['trace'], trace.hex(), 'full ordered trace identity')
        eq(record['ticket'], ticket.hex(), 'ticket identity')
        eq(record['proof_sha256'], hashlib.sha256(expected).hexdigest(), 'full proof digest')
        eq(record['outcome'], 'TARGET_HIT' if int.from_bytes(ticket, 'big') <= template.target else 'TARGET_MISS', 'target result including misses')
        eq(record['work_units']['trace_field_multiply_add_pairs'], template.shape.n**3, 'fresh complete trace cost')
        eq(record['work_units']['proof_bytes_materialized'], len(expected), 'complete proof serialized on misses')
        computed += record['work_units']['ab_products_computed']; reused += record['work_units']['ab_products_reused']
        misses += record['outcome'] == 'TARGET_MISS'
        cold_noise += record['work_units']['noise_raw_words_checked']; cold_trace += record['work_units']['trace_prefix_words']
        if capacity == 0: reference_proofs[(context, nonce)] = proof
        else: eq(proof, reference_proofs[(context, nonce)], 'same attempts at every capacity')
    eq((computed, reused), (10, 0) if capacity == 0 else (2, 8), 'cache dependency equivalence classes')
    eq(misses, 2, 'both harder-target failed attempts retained')
    if capacity == 0:
        baseline_fresh = (cold_noise, cold_trace)
        ok(cache.counters['insertion_refusals'] > 0 and cache.resident_bytes == 0, 'refused cache insertions paid')
    else: eq((cold_noise, cold_trace), baseline_fresh, 'no cached trace/noise work')
    cache_cases.append(dict(capacity=capacity, attempts=len(schedule), ab_products=computed, ab_reuses=reused,
        target_misses=misses, peak_payload_bytes=cache.peak_resident_bytes))

# Full native dimensions checked directly too; this is scalar CPU, not Node admission.
native = fixture(shape=Shape(), nonce_bits=3)
native_cache = PayloadLRU(262144)
for nonce in (0, 1):
    record, proof = produce(native, nonce, native_cache)
    challenge, expected, trace, ticket = reference(native, nonce)
    eq(proof, expected, 'full native dimension exact proof')
    eq(len(proof), 49188, 'native complete proof byte count')
    eq(record['ticket'], ticket.hex(), 'native ticket')
    eq(record['work_units']['ab_products_computed'], int(nonce == 0), 'native cold/warm AB')

# Manual LRU capacity/eviction/refusal control, separate from proof generation.
cache = PayloadLRU(9)
cache.put_new(b'a', b'123'); cache.put_new(b'bb', b'456')
eq(cache.get(b'a'), b'123', 'manual LRU hit')
cache.put_new(b'c', b'789')
eq(cache.entries, [(b'a', b'123'), (b'c', b'789')], 'oldest eviction after hit promotion')
cache.put_new(b'too-large', b'entry')
eq(cache.resident_bytes, 8, 'refusal preserves paid entries')
eq(cache.counters['evictions'], 1, 'one eviction')
eq(cache.counters['key_and_value_bytes_evicted'], 5, 'evicted key/value charged')
eq(cache.counters['insertion_refusals'], 1, 'one refusal retained')

source_after_review = source_map()
eq(source_after_review, source_before_review, 'reviewed sources stable')
output = dict(schema='independent-machine-cache-review-v1', status='PASS', assertions=checks,
    source_sha256=source_after_review, service_cases=service_cases,
    calibration_positive=1, calibration_rejections=4, reduced_cache_cases=cache_cases,
    full_native_shape_scalar_attempts=2, manual_lru=True,
    limitations=['hypothetical reduced-machine coefficients, no hardware calibration',
        'source resource construction is an input to independent event accounting',
        'full native dimensions checked by CPU scalar reference, not native Node admission',
        'ordered cache CPU campaign timings remain descriptive; no unbiased equal-resource speed claim'])
out = Path('/dev/shm/c9b4_machine_cache_independent_review.json')
out.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
print(json.dumps(dict(status='PASS', assertions=checks, service_cells=len(service_cases),
    reduced_proof_comparisons=20, full_native_dimension_proof_comparisons=2, output=str(out))))
