fn main() {
 let ctx=trnm_w1_hardened_verifier::profile::context().expect("frozen context");
 assert!(ctx.segment_verifier_parameters.is_none());
 assert!(ctx.groth16_verifier_parameters.is_none());
 assert!(!ctx.dev_mode());
 assert_eq!(ctx.suites.len(),1);
 assert!(ctx.suites.contains_key("poseidon2"));
 assert!(ctx.succinct_verifier_parameters.is_some());
 println!("context_has_only_pinned_succinct_poseidon2; no_segment_groth16_or_dev_mode");
}
