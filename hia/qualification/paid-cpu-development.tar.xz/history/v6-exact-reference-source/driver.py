"""Source-fenced development comparison of the finite actual PaidCPU owner.
No files in the original repository or shared target are changed during prepare.
Only --execute may compile the isolated original copy, under an exclusive Cargo
slot assigned by the collaborating original-code operator.
"""
from pathlib import Path
import sys,os,json,hashlib,shutil,subprocess,importlib.util,traceback,re,struct
ROOT=Path('/tmp/trnm-threadcpu-native-20261116-qvgbgeb_')
REPO=ROOT/'repo'
SOURCE=ROOT/'recovery/paid_cpu_candidate/account-original-v6'
OUT=ROOT/'paid-cpu-account-original-v6'
NATIVE=ROOT/'paid-cpu-owner-candidate-v3'
AUDIT=ROOT/'paid-cpu-owner-trace-v3-audit2'
AUDITOR=ROOT/'recovery/paid_cpu_candidate/account_v3_trace_audit_v2.py'
TARGET=Path('/tmp/trnm-typedstore-rust-20261116-jqi3qetj/isolated-cargo-target')
ORIGINAL='trillionnium/crates/trnm-pon-node/src/ingress/public_v3/scalar_cpu.rs'
ORIGINAL_SHA='799cfe0fab3fb8e0b3796eee7748cb63a98c02b74d3083af98b4368c5895e384'
HOOK='hia_paid_cpu_account_oracle.rs'
DECLARATION=b'\n#[cfg(all(test, target_os = "linux"))]\nmod hia_paid_cpu_account_oracle {\n    include!("hia_paid_cpu_account_oracle.rs");\n}\n'
PREFIX='ingress::public_v3::scalar_cpu::hia_paid_cpu_account_oracle::'
MARKER='HIA_PAID_CPU_ORACLE:'
os.environ.update(PYTHONDONTWRITEBYTECODE='1',RUSTUP_TOOLCHAIN='1.95.0-x86_64-unknown-linux-gnu')
os.environ['PATH']='/home/qian-qi/.cargo/bin:/usr/bin:/bin'
os.environ.pop('PYTHONOPTIMIZE',None)
sys.path.insert(0,str(REPO))
from hia.platform.thread_cpu.rust_oracle import original_manifest,complete_source_manifest,locked_clock_dependency,identity
from hia.platform.transport_request.rust_oracle import command
def need(ok,message):
 if not ok:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write_json(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def unique(pairs):
 result={}
 for key,value in pairs:
  need(key not in result,'Duplicate JSON key');result[key]=value
 return result
def read_json(path):return json.loads(path.read_bytes(),object_pairs_hook=unique)
def mapped(paths):return {str(p):identity(p) for p in sorted(set(paths))}
def signed(low,high):
 v=low+(high<<64);return v-(1<<128) if high>>63 else v
def decode_boundary(raw):
 need(len(raw)==376,'Complete boundary receipt missing')
 w=struct.unpack('<47Q',raw);need(w[0]==0x313030554f464350,'Boundary output magic differs')
 state=w[2:22];flow=w[22:38];fresh=w[38:47]
 need(state[0]==0x3130303055504350 and state[1] in (0,1) and state[9] in (0,1),'Boundary state identity differs')
 value={'result':w[1],'credit_ns':str(signed(state[2],state[3])),'unavailable':bool(state[1]),
   'updated_seconds_bits':state[4],'updated_nanos':state[5],'in_flight':state[6],
   'termination_reserved_ns':state[7],'verified_completions':state[8],'flow':None,
   'flow_snapshot':None,'freshness':None}
 if state[9]:
  value['flow']={'initial_credit_ns':str(signed(state[10],state[11])),
   'credited_refill_ns':state[12],'discarded_refill_ns':state[13],
   'booked_reservation_ns':state[14],'live_debited_cpu_ns':state[15],
   'settlement_residual_cpu_ns':state[16],'settled_full_cpu_ns':state[17],
   'settlement_discard_ns':state[18]}
 need(flow[0] in (0,1) and fresh[0] in (0,1),'Invalid optional diagnostic discriminant')
 if flow[0]:
  value['flow_snapshot']={'paid_cpu_debit_ns':flow[1],'remaining_paid_credit_ns':str(signed(flow[2],flow[3])),
   'unsettled_known_live_cpu_ns':flow[4],'initial_credit_ns':str(signed(flow[5],flow[6])),
   'credited_refill_ns':flow[7],'discarded_refill_ns':flow[8],'booked_reservation_ns':flow[9],
   'live_debited_cpu_ns':flow[10],'settlement_residual_cpu_ns':flow[11],'settled_full_cpu_ns':flow[12],
   'settlement_discard_ns':flow[13],'termination_reserved_ns':flow[14],'live_owners':flow[15],
   'stored_credit_ns':str(signed(state[2],state[3])),'balance_identity_verified':True}
 if fresh[0]:
  need(fresh[8] in (0,1),'Invalid projection eligibility')
  value['freshness']={'watermark_age_ns':fresh[1],'projected_credited_refill_ns':fresh[2],
   'projected_discarded_refill_ns':fresh[3],'projected_stored_credit_ns':str(signed(fresh[4],fresh[5])),
   'projected_paid_credit_ns':str(signed(fresh[6],fresh[7])),'projected_scalar_start_eligible':bool(fresh[8])}
 return value


BOUNDARY=ROOT/'paid-cpu-account-boundary-v1'
BOUNDARY_SOURCE=ROOT/'recovery/paid_cpu_candidate/account-boundary-v1'
def boundary_sources():
 native=read_json(BOUNDARY/'report.json')
 need(native['status']=='ALL_PRIVATE_NATIVE_BOUNDARIES_EXECUTED_ORIGINAL_PENDING' and native['native_cases']==67
      and native['source_before']==native['source_after'],'Native private arithmetic qualification failed')
 expected={'fixture_author.pyfrag','budget_math.pyfrag','fixture_adapter.S','cases.py','before_compaction.hepta',
           'fixture_policy.hepta','emitter_author.pyfrag','fixture_emitter.hepta'}
 need(set(native['source_before'])==expected,'Native boundary source roster incomplete')
 result={}
 for name in expected:
  row=native['source_before'][name];p=BOUNDARY_SOURCE/name
  need(identity(p)=={k:row[k] for k in ('bytes','sha256')},'Native private arithmetic source changed')
  result[str(p)]=identity(p)
 for p in (ROOT/'recovery/paid_cpu_candidate/account_boundary_v1_runner.py',
           ROOT/'recovery/paid_cpu_candidate/account_boundary_v1_payload.json'):
  result[str(p)]=identity(p)
 return result
def boundary_evidence():
 native=read_json(BOUNDARY/'report.json')
 paths=[BOUNDARY/'report.json',BOUNDARY/'corpus.json',BOUNDARY/'fixture.elf']
 need(identity(BOUNDARY/'fixture.elf')['sha256']=='53ae41d90c033c2ba46c81c920f3c787c66615ae5373582f6aa1fbfcddfcd65f','Native private arithmetic image differs')
 for row in native['cases']:
  need(row['status']=='NATIVE_EXECUTED_ORIGINAL_PENDING','Native boundary case not executed')
  for name in ('stdin.raw','stdout.raw','stderr.raw','receipt.json'):paths.append(BOUNDARY/row['name']/name)
  receipt=read_json(BOUNDARY/row['name']/'receipt.json')
  raw=(BOUNDARY/row['name']/'stdout.raw').read_bytes()
  need(receipt==row['receipt'] and receipt['exit_code']==0 and not receipt['timed_out']
       and receipt['stderr_hex']=='' and sha(raw)==receipt['output_sha256'],'Native boundary receipt changed')
  need(decode_boundary(raw)==row['comparison'],'Native boundary reduced result differs from raw bytes')
 for row in native['authority_controls']:
  need(row['status']=='PASS','Private counter rejection missing')
  for name in ('stdin.raw','stdout.raw','stderr.raw','receipt.json'):paths.append(BOUNDARY/row['name']/name)
 return mapped(paths)

def original_roster():
 value=original_manifest(REPO)
 prior=read_json(ROOT/'thread-cpu-v7-original/original/report.json')
 need(prior['status']=='PASS' and value==prior['original_sources'],'Original full graph differs from the retained V7 original execution graph')
 need(value[ORIGINAL]['sha256']==ORIGINAL_SHA,'Original PaidMutationCpuBudget source differs')
 return value
def fixed_sources():
 private=read_json(NATIVE/'report.json')
 need(private['source_before']==private['source_after']==private['sources'],'Native candidate source was not stable')
 expected={'budget_math.pyfrag','linux_owner_adapter_v3.S','owner_before_compaction_v3.hepta','owner_candidate_v3.hepta','owner_emitter_author_v3.pyfrag','owner_emitter_v3.hepta','owner_policy.pyfrag','private_layout.json'}
 need(set(private['sources'])==expected,'Incomplete native source roster')
 paths=[SOURCE/HOOK,SOURCE/'driver.py',SOURCE/'std-contract.json',AUDITOR,
  SOURCE/'owned_ptrace.py',SOURCE/'fault_runner.py',SOURCE/'fault-cases.json',
  ROOT/'recovery/paid_cpu_candidate/account_v3_fault_captures.py',
  ROOT/'recovery/paid_cpu_candidate/account_v3_compound_fault.py',
  ROOT/'recovery/paid_cpu_candidate/account_v3_fault_audit_v1.py']
 paths.extend(REPO/key for key in complete_source_manifest())
 paths.extend(ROOT/'recovery/paid_cpu_candidate/account-v3'/name for name in expected)
 paths.append(REPO/'hia/platform/transport_request/rust_oracle.py')
 paths.extend([ROOT/'recovery/paid_cpu_candidate/account_v3_runner.py',ROOT/'recovery/paid_cpu_candidate/account_v3_payload.json'])
 for name,row in private['sources'].items():
  need(identity(ROOT/'recovery/paid_cpu_candidate/account-v3'/name)=={k:row[k] for k in ('bytes','sha256')},'Actual native-bound source changed')
 return {**mapped(paths),**boundary_sources()}
def std_sources():
 contract=read_json(SOURCE/'std-contract.json')
 review=Path(contract['review_path'])
 need(identity(review)==contract['review_identity'],'Original std source review changed')
 raw=read_json(review)
 need(raw['stdlib_commit']=='59807616e1fa2540724bfbac14d7976d7e4a3860','Original std compiler commit differs')
 sysroot=Path(raw['actual_toolchain']['sysroot'])
 result={}
 for relative,value in raw['installed_std_sources_before_after'].items():
  p=sysroot/'lib/rustlib/src/rust'/relative
  need(identity(p)==value,'Original installed std source changed: '+relative)
  result[str(p)]=value
 for row in raw['actual_toolchain']['libstd_rlibs']+raw['actual_toolchain']['libstd_dynamic']+[raw['libc']]:
  p=Path(row['path']);expected={k:row[k] for k in ('bytes','sha256')}
  need(identity(p)==expected,'Original standard library or libc changed')
  result[str(p)]=expected
 result[str(review)]=identity(review)
 return result
def raw_evidence():
 physical=read_json(NATIVE/'report.json');trace=read_json(AUDIT/'report.json')
 need(physical['status']=='SIX_PHYSICAL_ACCOUNT_CONTROLS_PASS_TRACE_AND_ORIGINAL_PENDING','Native finite owner qualification failed')
 need(trace['status']=='SIX_ACTUAL_NATIVE_TRACES_AND_TEN_ADVERSARIAL_CONTROLS_PASS_ORIGINAL_PENDING'
      and len(trace['cases'])==6 and len(trace['negative_controls'])==10,'Native whole-trace qualification failed')
 paths=[NATIVE/'report.json',NATIVE/'owner.elf',AUDIT/'report.json']
 for case in physical['cases']:
  paths.extend(NATIVE/case['label']/name for name in ('stdin.raw','stdout.raw','stderr.raw','syscalls.raw','physical.json'))
  paths.extend(AUDIT/case['label']/name for name in ('trace-audit.json','original-budget-replay.json'))
 for row in trace['negative_controls']:
  p=Path(row['trace']['path'])
  need(identity(p)=={key:row['trace'][key] for key in ('bytes','sha256')},'Adversarial trace changed')
  paths.append(p)
 for base in (ROOT/'paid-cpu-owner-fault-captures-v3',ROOT/'paid-cpu-owner-compound-fault-v3'):
  evidence=read_json(base/'report.json')
  paths.append(base/'report.json')
  for row in evidence['cases']:
   paths.extend(base/row['name']/n for n in ('stdin.raw','stdout.raw','stderr.raw','syscalls.raw','physical.json'))
 paths.append(ROOT/'paid-cpu-owner-fault-audit-v3/report.json')
 return {**mapped(paths),**boundary_evidence()}

def prepare():
 OUT.mkdir(mode=0o700)
 report={'schema':'trnm.hia.paid-cpu-original-preparation.v1','status':'FAIL','actual_cargo_started':False}
 try:
  native=read_json(NATIVE/'report.json')
  spec=importlib.util.spec_from_file_location('private_paid_actual_trace_audit',AUDITOR)
  audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
  cases=[]
  for row in native['cases']:
   case=NATIVE/row['label'];traced=audit.audit((case/'syscalls.raw').read_text(),
     (case/'stdin.raw').read_bytes(),(case/'stdout.raw').read_bytes(),row['plan'])
   captured=read_json(AUDIT/row['label']/'original-budget-replay.json')
   need(captured=={'label':row['label'],**traced['replay']},'Recorded original replay differs from complete raw native trace')
   cases.append({**captured,'plan':row['plan']})
  need(len(cases)==6 and sum(len(c['operations']) for c in cases)==83,'Incomplete actual account method replay')
  original=original_roster();sources=fixed_sources();standard=std_sources();evidence=raw_evidence()
  input={'schema':'trnm.hia.paid-cpu-original-replay.v1','cases':cases,'boundaries':read_json(BOUNDARY/'corpus.json'),
   'scope':'original budget methods on real native trace coordinates; separate actual original same-thread owner and scoped worker controls',
   'native_public_abi_accepts_counters':False,'full_node_or_public_intake_closed':False}
  write_json(OUT/'inputs.json',input)
  isolated=OUT/'isolated-source';isolated.mkdir(mode=0o700)
  for relative,value in original.items():
   p=REPO/relative;need(identity(p)==value,'Original changed before copy: '+relative)
   dest=isolated/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
  include=isolated/ORIGINAL;prefix=include.read_bytes()
  need(sha(prefix)==ORIGINAL_SHA and b'mod hia_paid_cpu_account_oracle' not in prefix,'Original already changed')
  need(not (include.parent/HOOK).exists(),'Private child would replace original source')
  (include.parent/HOOK).write_bytes((SOURCE/HOOK).read_bytes())
  include.write_bytes(prefix+DECLARATION)
  manifest={'schema':'trnm.hia.paid-cpu-original-source-closure.v1',
   'sources':sources,'original_sources':original,'standard_library':standard,'native_evidence':evidence,
   'input':identity(OUT/'inputs.json'),'isolated_original_hook':identity(include.parent/HOOK),
   'original_production_prefix':original[ORIGINAL],'appended_private_declaration_hex':DECLARATION.hex(),
   'frozen_thread_sources':complete_source_manifest(),
   'original_hook_changes_only_isolated_copy':True}
  write_json(OUT/'source-before.json',manifest)
  check(manifest)
  report.update(status='READY_FOR_EXCLUSIVE_ACTUAL_ORIGINAL_EXECUTION',cases=6,
   actual_native_budget_operations=83,original_graph_files=len(original),source_inputs=len(sources),
   full_std_sources_and_binaries=len(standard),actual_cargo_started=False,
   source_before=identity(OUT/'source-before.json'),inputs=identity(OUT/'inputs.json'))
 except BaseException as error:report.update(failure=repr(error),traceback=traceback.format_exc())
 finally:
  write_json(OUT/'prepare-report.json',report);print(json.dumps(report,sort_keys=True))
 if report['status']=='FAIL':raise SystemExit(1)

def check(manifest,binary=None,expected_binary=None,dependency=None,events=None):
 need(fixed_sources()==manifest['sources'],'Complete candidate/source adapter closure changed')
 need(original_roster()==manifest['original_sources'],'Original full source graph changed')
 need(std_sources()==manifest['standard_library'],'Original exact standard-library dependency changed')
 need(raw_evidence()==manifest['native_evidence'],'Captured native evidence changed')
 need(identity(OUT/'inputs.json')==manifest['input'],'Original comparison input changed')
 need(complete_source_manifest()==manifest['frozen_thread_sources'],'Frozen Thread source changed')
 isolated=OUT/'isolated-source'
 for relative,value in manifest['original_sources'].items():
  p=isolated/relative
  if relative==ORIGINAL:
   raw=p.read_bytes();need(raw.endswith(DECLARATION) and sha(raw[:-len(DECLARATION)])==ORIGINAL_SHA,'Isolated complete production prefix changed')
  else:need(identity(p)==value,'Isolated original graph changed: '+relative)
 include=isolated/ORIGINAL
 need(identity(include.parent/HOOK)==manifest['isolated_original_hook']
      and (include.parent/HOOK).read_bytes()==(SOURCE/HOOK).read_bytes(),'Compiled private child differs')
 if binary is not None:need(identity(binary)==expected_binary,'Retained actual original executable changed')
 if dependency is not None:need(locked_clock_dependency(isolated,events)==dependency,'Actual compiled rustix dependency changed')
 return True

def records(raw):
 return [json.loads(line.split(MARKER,1)[1],object_pairs_hook=unique) for line in raw.decode().splitlines() if MARKER in line]
def expected_operation(event,index):
 result={'settled':event['expected_settled']} if event['kind']=='settle_observed' else {'error':event['expected_error']}
 return {'index':index,'kind':event['kind'],'result':result}
def compare_real(value,case):
 need(value['kind']=='domain-positive' and value['label']==case['label']
      and value['actual_original_domain_and_scoped_intervals'] is True
      and value['complete_original_block_executor'] is False,'Original real fixture identity differs')
 plan=case['plan'];owners=value['owners']
 need([o['request'] for o in owners]==list(range(plan['requests'])),'Original actual owner roster differs')
 comparisons=[]
 for owner in owners:
  request=owner['request'];p=plan['profiles'][request];receipt=owner['receipt']
  count=min(p['workers'],p['txs']);count=count if count>1 else 0
  need(all(receipt[k]==count for k in ('spawned_workers','started_workers','finished_workers','known_workers')),'Original real worker lifecycle count differs')
  need(receipt['accounting_unavailable'] is False and receipt['live_refused'] is False,'Original real positive accounting unknown')
  cpu=receipt['owner_cpu_ns'];workers=receipt['scoped_worker_cpu_ns'];full=receipt['total_cpu_ns'];live=receipt['live_paid_cpu_ns'];residual=receipt['residual_cpu_ns']
  need(all(type(x) is int and 0<=x<(1<<64) for x in (cpu,workers,full,live,residual)) and cpu>0,'Original actual CPU unavailable')
  need((workers>0)==(count>0) and full==cpu+workers and residual==full-live,'Original unique residual accounting differs')
  native=struct.unpack('<192Q',(NATIVE/case['label']/'stdout.raw').read_bytes())[(request+1)*64:(request+2)*64]
  need(owner['work_rows']==[[i,native[24+i]] for i in range(p['txs'])],'Original and actual HIA body work differs')
  comparisons.append({'request':request,'status':'PASS','actual_original_cpu_ns':cpu,
    'actual_original_worker_cpu_ns':workers,'actual_original_total_ns':full,'actual_original_live_ns':live,
    'actual_original_residual_ns':residual,'scoped_workers':count,
    'same_work_bytes_and_accounting_invariants':True,'exact_ns_equal_to_independent_native':False})
 flow=value['flow']
 need(flow['balance_identity_verified'] is True and flow['live_owners']==0
      and flow['booked_reservation_ns']==0 and flow['unsettled_known_live_cpu_ns']==0,'Original real shared account did not settle')
 need(flow['paid_cpu_debit_ns']==sum(r['actual_original_total_ns'] for r in comparisons)
      and flow['settled_full_cpu_ns']==flow['paid_cpu_debit_ns'],'Original actual shared debit differs')
 return {'label':case['label'],'status':'PASS','owners':comparisons,'actual_original_flow':flow}

def execute():
 manifest=read_json(OUT/'source-before.json');input=read_json(OUT/'inputs.json')
 run=OUT/'execution';run.mkdir(mode=0o700)
 report={'schema':'trnm.hia.paid-cpu-first-original-differential.v1','status':'FAIL',
   'whole_paid_account_closed':False,'production_node_embedding_closed':False,
   'full_original_block_executor_executed':False,'stages':[],'comparisons':[]}
 binary=None;binary_identity=None;dependency=None;events=None
 def call(argv,label,timeout=180,env=None):
  try:
   raw,row=command(argv,REPO if label=='preflight' else OUT/'isolated-source',run,label,env=env,timeout=timeout)
   report['stages'].append(row);return raw
  except BaseException:
   path=run/label/'receipt.json'
   if path.exists():report['stages'].append(read_json(path))
   raise
 try:
  need(read_json(OUT/'prepare-report.json')['status']=='READY_FOR_EXCLUSIVE_ACTUAL_ORIGINAL_EXECUTION','Preparation failed')
  check(manifest)
  pre=call(['bash',str(REPO/'scripts/project-preflight.sh'),'--dev'],'preflight',60)
  version=call(['rustc','-Vv'],'rustc-version',10)
  need(sha(version)=='4fdff2578428e9c5c08ddd7a0d3079c1a106b1cdaa46e73e46f7cd32b0fb9cad','Actual compiler differs from pinned original std review')
  need(TARGET!=REPO and TARGET not in REPO.parents and REPO not in TARGET.parents,'Cargo target overlaps original repository')
  raw=call(['cargo','test','--locked','--manifest-path',str(OUT/'isolated-source/trillionnium/Cargo.toml'),
   '-p','trnm-pon-node','--lib','--no-run','--message-format=json','--target-dir',str(TARGET)],
   'cargo-original-test-build',900)
  events=[json.loads(line) for line in raw.splitlines() if line.startswith(b'{')]
  artifacts=[event for event in events if event.get('reason')=='compiler-artifact'
   and event.get('target',{}).get('name')=='trnm_pon_node' and event.get('executable') and event['profile'].get('test')]
  need(len(artifacts)==1,'No unique compiled original Node test binary')
  compiled=Path(artifacts[0]['executable']);binary_identity=identity(compiled)
  binary=run/'original-test-binary';shutil.copyfile(compiled,binary);binary.chmod(0o500)
  need(identity(binary)==binary_identity,'Independent actual binary copy differs')
  with binary.open('rb') as stream:elf=stream.read(20)
  need(elf[:7]==b'\x7fELF\x02\x01\x01' and elf[18:20]==b'\x3e\x00','Actual original binary is not native x86-64 ELF64')
  report['executable']={'path':str(binary),**binary_identity}
  report['compiled_executable']={'path':str(compiled),**binary_identity}
  dependency=locked_clock_dependency(OUT/'isolated-source',events)
  report['locked_clock_dependency']=dependency
  check(manifest,binary,binary_identity,dependency,events)
  listed=call([str(binary),'--list'],'list-original-tests',30)
  tests={line.removesuffix(': test') for line in listed.decode().splitlines() if line.endswith(': test')}
  required={PREFIX+suffix for suffix in ('original_budget_trace_replays','original_real_scoped_profiles','linux_clocks_are_mandatory','original_private_arithmetic_boundaries')}
  need(required<=tests,'Required actual original oracle tests not linked')
  retained=[]
  for prefix,label in [('ingress::public_v3::scalar_cpu::tests::','retained-original-scalar-tests'),
                       ('ingress::public_v3::scalar_cpu::flow_tests::','retained-original-flow-tests')]:
   names=sorted(name for name in tests if name.startswith(prefix))
   need(names,'Original retained test group missing')
   result=call([str(binary),prefix,'--nocapture','--test-threads=1'],label,240)
   summary=re.search(r'test result: ok\. (\d+) passed; 0 failed;',result.decode())
   need(summary is not None and int(summary[1])==len(names),'Retained original group did not run every test')
   retained.append({'prefix':prefix,'passed':len(names),'names':names})
  runtime={'PATH':os.environ['PATH'],'TRNM_HIA_PAID_CPU_REPLAYS':str(OUT/'inputs.json')}
  raw=call([str(binary),'--exact',PREFIX+'linux_clocks_are_mandatory','--nocapture','--test-threads=1'],
      'mandatory-original-linux-clocks',30,runtime)
  available=records(raw);need(len(available)==1 and available[0]['kind']=='linux-positive' and available[0]['clock_failure_cannot_skip'] is True,'Mandatory original Linux clocks did not execute')
  report['mandatory_linux_positive']=available[0]
  raw=call([str(binary),'--exact',PREFIX+'original_budget_trace_replays','--nocapture','--test-threads=1'],
      'actual-original-budget-replays',60,runtime)
  observed=records(raw)
  need([r['label'] for r in observed]==[r['label'] for r in input['cases']],'Actual original replay corpus missing or reordered')
  comparisons=[]
  for actual,case in zip(observed,input['cases'],strict=True):
   expected_ops=[expected_operation(event,index) for index,event in enumerate(case['operations'])]
   same=actual['kind']=='budget-replay' and actual['operations']==expected_ops and actual['final']==case['expected_final']
   comparisons.append({'label':case['label'],'status':'PASS' if same else 'FAIL',
      'actual_original':actual,'expected_native_final':case['expected_final'],
      'expected_native_operation_results':expected_ops})
  write_json(run/'budget-comparison.json',{'cases':comparisons})
  report['comparisons']=comparisons
  need(all(r['status']=='PASS' for r in comparisons),'Actual original budget method differential failed')
  raw=call([str(binary),'--exact',PREFIX+'original_private_arithmetic_boundaries','--nocapture','--test-threads=1'],
      'actual-original-private-arithmetic-boundaries',90,runtime)
  observed_boundaries=records(raw);native_boundaries=read_json(BOUNDARY/'report.json')['cases']
  need([r['name'] for r in observed_boundaries]==[r['name'] for r in native_boundaries],
       'Actual original private arithmetic corpus missing or reordered')
  boundary_comparisons=[]
  for actual,native_boundary in zip(observed_boundaries,native_boundaries,strict=True):
   need(actual['kind']=='private-boundary' and actual['original_complete_methods_executed'] is True
        and actual['production_runtime_counter_abi'] is False,'Private reference mislabeled runtime authority')
   same=actual['comparison']==native_boundary['comparison']
   boundary_comparisons.append({'name':actual['name'],'status':'PASS' if same else 'FAIL',
      'actual_original':actual,'actual_native':native_boundary['comparison']})
  write_json(run/'boundary-comparison.json',{'cases':boundary_comparisons})
  report['boundary_comparisons']=boundary_comparisons
  need(all(r['status']=='PASS' for r in boundary_comparisons),'Actual original private arithmetic differential failed')
  trace=run/'actual-original-scoped-clocks.trace'
  raw=call(['/usr/bin/strace','-f','-qq','-v','-s','65536','-o',str(trace),'--',str(binary),
      '--exact',PREFIX+'original_real_scoped_profiles','--nocapture','--test-threads=1'],
      'actual-original-real-owner-scoped-profiles',240,runtime)
  real=records(raw);warm=[c for c in input['cases'] if not c['cold']]
  need([r['label'] for r in real]==[r['label'] for r in warm],'Original actual scope profiles missing or reordered')
  real_comparisons=[compare_real(r,c) for r,c in zip(real,warm,strict=True)]
  write_json(run/'real-scope-comparison.json',{'cases':real_comparisons})
  report['actual_original_real_profiles']=real_comparisons
  # The Rust runtime uses libc/vDSO for CLOCK_MONOTONIC; no fake syscall claim.
  # Its clock calls are bound by exact linked std/libc source and mandatory
  # execution. Raw CLOCK3 syscall observations remain separately retained.
  text=trace.read_text()
  clock_rows=re.findall(r'^(\d+)[ \t]+clock_gettime\(CLOCK_THREAD_CPUTIME_ID,',text,re.M)
  need(bool(clock_rows) and len(set(clock_rows))>=8,'Original real scoped CPU clocks not observed in multiple working threads')
  report['actual_original_trace']={'path':str(trace),**identity(trace),
     'direct_clock3_call_starts':len(clock_rows),'clock3_tids':sorted(set(map(int,clock_rows))),
     'clock1_vdso_may_not_emit_syscall':True,'complete_original_runtime_syscall_whitelist_claimed':False}
  raw=call(['python3','-B',str(SOURCE/'fault_runner.py'),'--binary',str(binary),'--output',str(run/'fault-differential')],
       'actual-original-fault-comparison',300,runtime)
  fault_report=read_json(run/'fault-differential/report.json')
  need(fault_report['status']=='PASS' and len(fault_report['cases'])==13,'Actual original negative differential failed')
  report['actual_original_fault_comparison']={'path':str(run/'fault-differential/report.json'),**identity(run/'fault-differential/report.json'),
    'cases':13,'status':'PASS','private_no_vdso_platform_fixture':True,'ordinary_vdso_negative_claimed':False}
  check(manifest,binary,binary_identity,dependency,events)
  report.update(status='PASS',native_histories=6,actual_original_budget_calls=83,actual_original_boundary_cases=67,
    actual_original_real_owner_profiles=5,actual_original_owner_threads=sum(c['plan']['requests'] for c in warm),
    retained_tests=retained,retained_passed=sum(r['passed'] for r in retained),
    source_before=identity(OUT/'source-before.json'),input=identity(OUT/'inputs.json'),
    original_production_prefix=manifest['original_production_prefix'],
    original_repository_modified=False,private_relative_clock_replay_separated_from_original_real_clocks=True,
    private_hook=identity(SOURCE/HOOK),compiler=version.decode())
 except BaseException as error:report.update(failure=repr(error),traceback=traceback.format_exc())
 finally:
  try:
   check(manifest,binary,binary_identity,dependency,events)
   report['source_after']='MATCH';report['binary_after']='MATCH' if binary else 'NOT_BUILT'
   report['dependency_after']='MATCH' if dependency else 'NOT_BUILT'
  except BaseException as error:
   report.update(status='FAIL',source_after='FAIL',source_after_failure=repr(error))
  write_json(run/'report.json',report)
  print(json.dumps({'status':report['status'],'failure':report.get('failure'),'traceback':report.get('traceback'),
   'actual_original_budget_calls':report.get('actual_original_budget_calls'),
   'budget_results':[{'label':r['label'],'status':r['status']} for r in report['comparisons']],
   'boundary_results':[{'name':r['name'],'status':r['status']} for r in report.get('boundary_comparisons',[])],
   'actual_original_profiles':report.get('actual_original_real_owner_profiles'),'retained_passed':report.get('retained_passed'),
   'source_after':report.get('source_after'),'binary_after':report.get('binary_after'),'executable':report.get('executable')},sort_keys=True))
 if report['status']=='FAIL':raise SystemExit(1)
if __name__=='__main__':
 if '--execute' in sys.argv:execute()
 else:prepare()
