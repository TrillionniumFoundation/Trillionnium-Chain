# Root V6 prior evidence: retained originals and explicit gaps

This recovery package is incomplete. It preserves original native process stream bytes recovered from a tool-result cache, exact admission identities, and timeout originals. It does not replace missing observations with re-executed or synthetic logs.

The cloud filesystem was replaced during the session. The original 9-command source-only directory, corrected report, and local gate observation directory are unavailable. Their previously reported hashes and results are labeled historical observations, not original files. Full source postimages are excluded.

## Original native failure

The initial dirty candidate was based on `8970e2c81abbf48e2a4d3f0802d79624ab20fadd`. The observed unittest result was 52 tests, 4 failures and 3 errors; source snapshot validation failed. The full parent process stdout/stderr are preserved exactly and were checked against the original bytes_hex. The parent stdout includes only the nested unittest stderr tail. The full nested unittest stdout/stderr have now been copied unchanged from their original native observation paths. A separate provenance document records their original SHA256 and independently checks 52 tests, 4 failures, 3 errors.

## Fresh native validation

The original admission was acknowledged for job `1a1ceb5dc89-2564-17f6`, key `chain-root-v6-df05-gate-fresh-import-v1`. Its terminal result was UNKNOWN at the source handoff because reads timed out. Later cloud success is not evidence about this job's outcome. No fresh execution is presented as its original result.

## Cloud reporting failure

All 9 underlying source-only commands had observed exit code 0. The scratch aggregator exited 1 due to its count regex. The original report was retained and a separate corrected report was built from the original logs at that time. Those report and log bytes were subsequently lost with the cloud filesystem; this package preserves the surviving original orchestration source and explicit historical metadata only.

This package provides no native Rust-test acceptance, independent custody proof, whole-chain PQ qualification, or production activation.
