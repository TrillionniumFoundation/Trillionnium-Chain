ROOT_PATH="/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo"
from pathlib import Path
import sys,json,hashlib,zipfile,shutil,time,subprocess,traceback
root=Path(ROOT_PATH);base=root.parent/"ci-c390-readback-v1";producer=base/"14300299588";consumer=base/"14302696232";out=producer/"independent-readback-v1";out.mkdir(mode=0o700)
(out/"driver.py").write_text(sys.argv[1]);sys.path.insert(0,str(root));from hia.tools import qualify_work_owner_ci as q
expected={"git_head":"c3901ff19c26815205d9cdd6975fc24ecc51ae88","run_id":"44019939486","attempt":1}
started=time.monotonic_ns();record={"schema":"trnm.c390-work-owner-independent-readback.v1","status":"FAIL","expected_lineage":expected,"actual_runtime_reexecuted":False,"original_runner_tool_paths_recreated":False,"stages":[]}
def need(v,m):
 if not v:raise ValueError(m)
def stage(name,fn):
 t=time.monotonic_ns();result=fn();record["stages"].append({"name":name,"elapsed_ns":time.monotonic_ns()-t,"status":"PASS"});print(json.dumps({"stage":name,"status":"PASS"}),flush=True);return result
try:
 p=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=root,capture_output=True);(out/"preflight.stdout.raw").write_bytes(p.stdout);(out/"preflight.stderr.raw").write_bytes(p.stderr);need(p.returncode==0,"Preflight failed")
 need(subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()==expected["git_head"],"Canonical source head differs")
 need(subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True)=="","Canonical source dirty")
 api=q.read(base/"batch-and-host-job-observation-v1.json");jobs=api["source"]["jobs"]
 for name in ("native-work-owner","native-work-owner-readback"):
  rows=[j for j in jobs if j["name"]==name];need(len(rows)==1 and rows[0]["conclusion"]=="success" and rows[0]["head_sha"]==expected["git_head"],"Actual producer/consumer job did not succeed")
 package_dir=out/"package";package_dir.mkdir(mode=0o700);consumer_dir=out/"hosted-consumer";consumer_dir.mkdir(mode=0o700)
 for folder,target,wanted in ((producer,package_dir,{"bytes":247580815,"sha256":"b3f49fd5d165048362a544f9a83508850dfaa23cb0668d82c0fde38170ad7ca3"}),(consumer,consumer_dir,{"bytes":3994,"sha256":"92b57d2637d13c388ee99d06b2c7e4cd42f4375d8ead8971d888fde9924fc87b"})):
  need(q.identity(folder/"artifact.zip")==wanted,"Complete actual ZIP changed")
  members=q.read(folder/"members.json")
  with zipfile.ZipFile(folder/"artifact.zip") as z:
   for item in z.infolist():
    path=q.member_name(item.filename);need(len(path.parts)==1,"Unexpected outer ZIP hierarchy")
    with z.open(item) as source,(target/path).open("xb") as dest:shutil.copyfileobj(source,dest,1<<20)
    need(q.identity(target/path)=={k:members[item.filename][k] for k in ("bytes","sha256")},"ZIP member differs")
 package=q.read(package_dir/"package-manifest.json");binding=q.read(package_dir/"binding.json")
 need(package.get("schema")==q.PACKAGE and package.get("stage")==q.STAGE and package.get("packing_status")=="PASS" and package.get("capture_errors")==[] and package.get("special_entries")=={} and package.get("complete_original_test_binary_is_not_excluded") is True and package.get("complete_isolated_original_source_is_not_excluded") is True and package.get("qualification_status_not_changed_by_packaging") is True and package.get("qualification_status")=="PASS","Incomplete actual hosted package")
 need(q.same(package["lineage"],expected),"Actual hosted package lineage differs")
 q.check_binding(binding,expected)
 archive=package_dir/"complete-evidence.tar.xz";need(q.identity(archive)==package["archive"],"Inner archive changed")
 dest=out/"unpacked"
 verification=stage("all-canonical-archive-and-complete-regular-member-bytes",lambda:q.verify_archive(archive,package["entries"],destination=dest))
 need(q.same(verification,package["archive_verification"]),"Canonical archive verification differs")
 current=stage("complete-native-and-original-raw-semantic-readback",lambda:q.assess(root,dest/"native",dest/"original",capture=dest/"capture",live=False))
 need(q.identity(package_dir/"binding.json")==package["binding"] and (package_dir/"binding.json").read_bytes()==(dest/"observations/binding.json").read_bytes(),"Inner/outer binding differs")
 need(all(q.same(binding.get(key),value) for key,value in current.items()),"Complete raw replay differs from actual hosted binding")
 need(set(package["entries"])==set(binding["evidence_files"])|{"observations/binding.json"} and all(q.same(package["entries"].get(name),row) for name,row in binding["evidence_files"].items()),"Missing/extra/changed bound original evidence")
 need(q.same(binding["ci_reader_sources"],{name:q.identity(root/name) for name in q.READERS}),"Current exact CI reader differs")
 for name,wanted in binding["ci_reader_sources"].items():need(q.identity(dest/"capture/ci-readers"/q.member_name(name))==wanted,"Complete captured reader differs")
 sources=stage("exact-committed-source-observations",lambda:q.source_pair(dest/"observations",expected))
 need(q.same(sources,binding["source_observations"]),"Actual source-before/after binding differs")
 q.base.check_committed_sources({**binding["source_inputs"],**binding["original_sources"],**binding["ci_reader_sources"]},root)
 controls=stage("complete-mandatory-source-control-raw-readback",lambda:q.validate_controls(dest/"observations/source-controls"))
 hosted=q.read(consumer_dir/"readback-result.json");hosted_sources=q.source_pair(consumer_dir,expected)
 wanted={"status":"QUALIFIED_COMPLETE_READBACK","archive":verification["archive"],"original_binary":current["original_binary"],**q.COUNTS,"qualification_status_not_changed_by_readback":True,"original_controlled_CLOCK1_fault_comparison":"OPEN"}
 need(q.same(hosted,wanted),"Actual hosted consumer result differs from independent complete replay")
 need(q.same(q.build.source_manifest(),binding["source_inputs"]) and q.same(q.bundle.original_manifest(root),binding["original_sources"]),"Sources changed during independent readback")
 record.update(status="PASS",complete_replayed_binding=current,source_controls=controls,hosted_readback=hosted,hosted_source_observations=hosted_sources,package=q.identity(package_dir/"package-manifest.json"),binding=q.identity(package_dir/"binding.json"),archive=verification,source_after="MATCH",whole_node_or_commit_authority=False,original_controlled_CLOCK1_fault_comparison="OPEN",primitive_raw_guard_arenas_retained=False)
except BaseException as e:record["failure"]={"error":repr(e),"traceback":traceback.format_exc()};raise
finally:
 record["elapsed_ns"]=time.monotonic_ns()-started;raw=(json.dumps(record,sort_keys=True,indent=2)+"\n").encode();(out/"report.json").write_bytes(raw)
 print(json.dumps({"status":record["status"],"report_bytes":len(raw),"report_sha256":hashlib.sha256(raw).hexdigest(),"elapsed_ns":record["elapsed_ns"],"failure":record.get("failure")}),flush=True)
