from pathlib import Path, PurePosixPath
import ast, hashlib, json, re, stat, subprocess, textwrap
import yaml

BASE = Path('/workspace/scratch/a638c5cc4765')
ROOT = BASE / 'Trillionnium-Chain'
OUT = BASE / 'oracle-integration-controls'

def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def run(argv, **kw):
    return subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True, **kw)

def prior(path):
    return json.loads(run(['git', 'show', 'HEAD:' + path]).stdout)

workflow = ROOT / '.github/workflows/hia-native-migration.yml'
wf = yaml.safe_load(workflow.read_text()); jobs = wf['jobs']; assert len(jobs) == 54
shells = python_blocks = 0
for name, job in jobs.items():
    assert job['timeout-minutes'] == 20
    assert 'runner.' not in json.dumps(job.get('env', {}))
    for index, step in enumerate(job['steps']):
        if 'run' not in step: continue
        assert step.get('shell', 'bash') in ('bash', 'sh')
        command = re.sub(r'\$\{\{.*?\}\}', 'REVIEWED_EXPRESSION', step['run'], flags=re.S)
        run(['bash', '-n'], input=command.encode()); shells += 1
        pattern = r'''(?ms)^[^\n]*\bpython3?\b[^\n]*<<['"](?P<tag>[A-Za-z_][A-Za-z_0-9]*)['"]\n(?P<body>.*?)^\s*(?P=tag)\s*$'''
        for match in re.finditer(pattern, command):
            ast.parse(textwrap.dedent(match['body']), filename=f'{name}:{index}'); python_blocks += 1
bootstrap = len(re.findall(r'^ {10}python3 - "\$RUNNER_TEMP/hia-bootstrap/bootstrap\.json"', workflow.read_text(), re.M))
assert bootstrap == 42
steps = jobs['native-components']['steps']
dependency = [s for s in steps if s.get('name') == 'Compile both exact original Oracle dependency profiles']
assert len(dependency) == 1 and dependency[0]['run'].count('cargo test --locked') == 2
assert '--features serde_json/arbitrary_precision' in dependency[0]['run']
execute = next(s for s in steps if s.get('name') == 'Execute every assigned native HIA and independent reference case')
assert execute['env']['HIA_ORACLE_DEPS'] == '${{ runner.temp }}/oracle-default-deps/debug/deps'
assert execute['env']['HIA_ORACLE_WORKSPACE_DEPS'] == '${{ runner.temp }}/oracle-workspace-deps/debug/deps'
assert execute['env']['HIA_ORACLE_OUTPUT'] == '${{ runner.temp }}/hia-oracle-original'
assert steps.index(dependency[0]) < steps.index(execute)
oracle_upload = [s for s in steps if s.get('name') == 'Retain complete original and HIA Oracle observations']
assert len(oracle_upload) == 1 and oracle_upload[0]['if'] == 'always()'
assert len(oracle_upload[0]['with']['path'].splitlines()) == 5
old_workflow = yaml.safe_load(run(['git', 'show', 'HEAD:.github/workflows/hia-native-migration.yml']).stdout)
for name in jobs:
    if name != 'native-components': assert jobs[name] == old_workflow['jobs'][name], name
for s in steps:
    if s.get('name') == 'Retain success and failure observations':
        assert s == next(x for x in old_workflow['jobs']['native-components']['steps'] if x.get('name') == s['name'])

inventory = json.loads((ROOT / 'config/hia-migration-v1.json').read_bytes())
old_inventory = prior('config/hia-migration-v1.json')
assert len(inventory['components']) == 50 and len(inventory['native_foundations']) == 22
assert len(inventory['legacy_packages']) == 26
assert sum(p['state'] == 'partially-ported' for p in inventory['legacy_packages']) == 16
assert len(inventory['blocking_gates']) == 9 and not any(p['retirement_accepted'] for p in inventory['legacy_packages'])
assert all(inventory[k] is False for k in ('whole_chain_native', 'old_stack_can_be_removed', 'production_activation'))
for key in inventory:
    if key not in ('components', 'legacy_packages'): assert inventory[key] == old_inventory[key], key
for package in old_inventory['legacy_packages']:
    current = next(p for p in inventory['legacy_packages'] if p['package'] == package['package'])
    if package['package'] != 'trnm-oracle': assert current == package, package['package']
old_components = prior('hia/components.json')
components = json.loads((ROOT / 'hia/components.json').read_bytes())
new_includes = set(components['includes']) - set(old_components['includes'])
assert new_includes == {'src/oracle/values.hepta', 'src/oracle/serde_json.hepta'}
assert {k:v for k,v in components['includes'].items() if k not in new_includes} == old_components['includes']
assert components['schema'] == old_components['schema']
sources = sorted((ROOT / 'hia').rglob('*.hepta')); assert len(sources) == 139
hashes = {}
for path in sources: hashes.setdefault(identity(path)['sha256'], []).append(path.relative_to(ROOT).as_posix())
assert not any(len(v) > 1 for v in hashes.values())
record = json.loads((ROOT / 'hia/qualification/oracle-development.json').read_bytes())
for name, expected in record['final_execution']['source_inputs'].items():
    assert identity(ROOT / name) == expected, name
assert record['final_execution']['status'] == 'PASS' and record['hosted_execution'].startswith('NOT_RUN')
directory = ROOT / 'hia/qualification/oracle-development.parts'
manifest = json.loads((directory / 'manifest.json').read_bytes())
total = 0; digest = hashlib.sha256()
assert {p.name for p in directory.iterdir()} == {'manifest.json'} | {r['path'] for r in manifest['parts']}
for index, row in enumerate(manifest['parts']):
    path = directory / row['path']; st = path.lstat()
    assert row['path'] == f'part-{index:03d}' and row['offset'] == total
    assert stat.S_ISREG(st.st_mode) and st.st_nlink == 1 and 0 < row['bytes'] <= 6 * 1024 * 1024
    data = path.read_bytes(); assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    digest.update(data); total += len(data)
assert {'bytes': total, 'sha256': digest.hexdigest()} == manifest['archive']
assert identity(BASE / 'owner-extension-full-archives' / manifest['logical_name']) == manifest['archive']
changed = run(['git', 'diff', '--name-only']).stdout.decode().splitlines()
changed += run(['git', 'diff', '--cached', '--name-only']).stdout.decode().splitlines()
untracked = run(['git', 'ls-files', '--others', '--exclude-standard']).stdout.decode().splitlines()
paths = sorted(set(changed + untracked)); python_files = 0
for name in paths:
    path = ROOT / name
    if path.suffix == '.py': ast.parse(path.read_text(), filename=name); python_files += 1
    if path.suffix in ('.py', '.rs', '.c', '.hepta', '.md', '.json', '.yml'):
        assert all(line == line.rstrip() for line in path.read_text().splitlines()), name
run(['git', 'diff', '--check'])
corpus_path = 'config/pon/pq-cross-branch-corpus-v1.json'
new = json.loads((ROOT / corpus_path).read_bytes()); old = prior(corpus_path)
plan = 'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
assert new['pinned_blobs'][plan] == run(['git', 'hash-object', plan]).stdout.decode().strip()
copy = json.loads(json.dumps(new)); copy['pinned_blobs'][plan] = old['pinned_blobs'][plan]; assert copy == old
assert len(new['pinned_blobs']) == 2613 and len(new['required_paths']) == 2517
correction = json.loads((BASE / 'oracle-documentation-correction/correction.json').read_bytes())
assert identity(ROOT / correction['path']) == correction['new']
assert hashlib.sha256(run(['git', 'show', 'HEAD:' + correction['path']]).stdout).hexdigest() == correction['old']['sha256']
assert identity(ROOT / correction['actual_original_source'])['sha256'] == correction['actual_original_source_sha256']
discovery = json.loads((OUT / 'component-discovery.json').read_text())
assert discovery['total'] == 476
for label in ('preflight', 'migration', 'migration-composition-partition', 'bootstrap'):
    execution = json.loads((OUT / (label + '.execution.json')).read_text())
    assert execution['exit_code'] == 0
    for stream in ('stdout', 'stderr'):
        assert identity(OUT / (label + '.' + stream + '.raw')) == execution[stream]
result = {'schema': 'trnm.hia.oracle-integration-static.v1', 'status': 'PASS',
    'workflow': identity(workflow), 'jobs': 54, 'bootstrap_gates': 42, 'all_timeout_minutes': 20,
    'bash_steps_checked': shells, 'python_heredocs_checked': python_blocks,
    'changed_python_files_parsed': python_files, 'unique_hia_sources': 139,
    'kernels': 50, 'foundations': 22, 'retained_packages': 26,
    'partially_ported_packages': 16, 'not_ported_packages': 10, 'retired_packages': 0, 'open_gates': 9,
    'new_include_keys': sorted(new_includes), 'existing_include_semantics_unchanged': True,
    'original_package_entries_unchanged_except_oracle': True,
    'final_oracle_source_fence': 'PASS', 'complete_archive': manifest['archive'],
    'parts': len(manifest['parts']), 'corpus_pins_changed': [plan],
    'pinned_count': 2613, 'required_paths_count': 2517,
    'peer_direction_documentation_correction': correction,
    'git_diff_whitespace': 'PASS', 'runtime_executed': False}
(OUT / 'static-checks.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(result))
