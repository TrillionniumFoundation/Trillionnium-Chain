## Why

The controlled Cell/model experiment successfully moved and loaded the real candidate, but it did not exercise Hepta's original FinalUse and future-holdout owners. Those claims need actual native source-head and real base-merge CI receipts. The old pair workflow also named an earlier Chain candidate.

This draft is stacked on the existing Hepta integration PR #3293 and pins the verified actual Chain draft PR #506 pair. It preserves the existing integration lineage and original test/profile budgets.

## Changes

- Prepare the pinned SmolLM2-135M-Instruct material and three real parent-linked 10-step training generations in the existing x64 source-head and base-merge lanes.
- Execute the two original ignored native owner tests through the existing `hepta_ci_exec` and nextest path, with zero retries. Keep the existing ARM lanes and all older profiles intact.
- Add complete source/model/command/resource receipts and readback for original FinalUse, terminal unload and parent/candidate holdout consumption. Missing, failed or incomplete owner evidence cannot become accepted product authority.
- Retain the original 60-minute job limit and declare model preparation requirements before execution. The initial harness resource provision is not a guarantee of available host memory.
- Pin reviewed Chain source `ac469237422d43805845e8b9a6839ad14e1028e7`, stacked base `57c1ed545d067937cbd7aaa7570d5f22123265e6`, actual GitHub merge `47727c4f8335427710b4f3608768b4e9cc7c2a64`. Ordered parents and native canonical merge-tree equality were checked before/after API reads.
- Preserve the four original measured source commits, their same-tree remote mapping and actual Git readbacks in a finite publication archive. The final pin/metadata commit is explicitly outside that archive.

## Validation and acceptance

Nine pure-Python reader controls, YAML/TOML/AST checks, formatting, archive/source hashes and `git diff --check` pass. No Hepta Rust, Cargo or Bazel execution occurred locally. The two native owner tests and final hosted source-head/base-merge lanes need their actual results; source wiring and static tests are not execution evidence.

The separate controlled model experiment remains **NO_UPDATE**: parent 16/32 versus candidate 16/32, with no changed selected action. This PR does not claim an improved model, product installation, independent efficacy, production self-upgrade, whole-chain PQ or independent WAN acceptance.

**Draft / HOLD / NO_GO.** No gate, deadline, retry policy, production authority or automatic acceptance is weakened.

## Actual original failure and reviewed successor

Original run 40491440610 at Hepta `2bfceaa3226611a72f43d24e67d13e30091c7449` / Chain `0c804e9f5bcf6e972bbb4524c744d4b3c8801c34` completed with four failed Linux lanes and two successful Windows ledger jobs. Each Linux lane reached the original 86-test reader suite: 83 passed and three fixed mock expectations still counted four executions while the unchanged native runner had five. Model steps 49-52 were skipped. The successful Windows jobs do not establish a Linux model result.

The paired Chain successor preserves the original three failures, fixes only those fixed expectations, retains all five native selectors and supplies the reviewed Host wrapper. This Hepta successor changes only two Chain pin lines and prefixes the one original from-zero subprocess with that wrapper. Original `cd ../chain`, `RUSTUP_TOOLCHAIN=1.95.0`, argv, output path, 60-minute job limit, native deadlines and zero retries remain unchanged. Only that subprocess enters the original 25%-CPU / 2-GiB fixed public parent. No other protocol or model step is moved into it.

Nine existing pure-Python wiring/refusal tests pass on this exact workflow delta. No local Hepta Rust, Cargo, Bazel, FinalUse or model execution occurred. See `qualification/learning-generations/smollm-pair-host-20261027/` for the complete delta, log and Chain pair receipt.

Current published source: `1d9f262f9965d30105ee58d4218cd6e27ef7a431`, tree `3c8a7f5f18325de728b2fc08d5b7bac2e499bfae`; original same-tree local commit `4fa84b3d2e4796ab576ca4ee462a0fe6bee33667`. This commit is directly based on the prior published `2bfceaa...`, preserving linear publication history. Stacked target #3293 remains `3e9efb15faa261a4dc3ffc3205cd259aaee41a3f`. Actual GitHub merge `7cdbb08558b899e23fe029423ef9a762d424e95e` was fetched and checked for exact ordered parents and native canonical merge-tree equality.

At the 2026-10-27 11:29:56 UTC list snapshot, the four new-source workflows were queued/pending; seven registered checks were six queued and one in progress. There is no new-source model acceptance result. **Draft / HOLD / NO_GO.**
