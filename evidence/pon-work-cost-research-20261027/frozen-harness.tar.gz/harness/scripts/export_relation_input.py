#!/usr/bin/env python3
"""Bridge verified research bytes to existing PWG1; no proof or authority."""
from pathlib import Path
import argparse, hashlib, json
from independent_check import verify_export, H, w

RELATION_SOURCE = '5e797326b9c7635e43b93f97c65a309e51eafb46'
PROFILE = b'pon-complete-w1-relation-v1'

def export(directory, output):
    verified = verify_export(directory)
    header = (directory / 'header.bin').read_bytes()
    proof = (directory / 'pnw1.bin').read_bytes()
    task, target = header[278:310], header[118:150]
    statement = (b'PWG1\1\0' + H('w1-complete-profile-v1', PROFILE)
                 + header + task + target + H('w1-complete-witness-v1', proof))
    assert len(statement) == 452
    challenge, trace = H('challenge', header), proof[-32:]
    journal = b'PWJ1' + b''.join([
        H('w1-complete-statement-v1', statement), challenge, task,
        H('ticket', challenge, trace), trace, H('block', header, trace),
        H('w1-complete-product-v1', proof[4 + 8*w.CELLS:4 + 12*w.CELLS]),
    ])
    blob = statement + proof
    with output.open('xb') as f:
        f.write(blob)
    receipt = dict(schema='trnm-w1-pwg1-interop-v1', relation_source=RELATION_SOURCE,
                   input_bytes=len(blob), input_sha256=hashlib.sha256(blob).hexdigest(),
                   expected_native_journal_hex=journal.hex(),
                   expected_block_id=verified['semantic_block_id'],
                   expected_output_is_not_authenticated=True,
                   native_relation_interoperability_executed=False,
                   succinct_proof=False, node_task_eligibility_checked=False)
    with output.with_suffix(output.suffix + '.json').open('x') as f:
        json.dump(receipt, f, indent=2); f.write('\n')
    return receipt

if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('directory',type=Path); p.add_argument('output',type=Path)
    args=p.parse_args(); print(json.dumps(export(args.directory,args.output),indent=2))
