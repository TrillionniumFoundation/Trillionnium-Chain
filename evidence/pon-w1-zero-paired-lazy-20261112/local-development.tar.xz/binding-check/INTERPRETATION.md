# Scope correction for retained development refusals

The original pre-refresh files are preserved unchanged. Despite the earlier
`retained-pin-refusal-before-reviewed-refresh` label, the actual failure is
missing physical `evidence/` content in this sparse development worktree.
Neither invocation reached a complete physical closure verdict; these outputs
do not demonstrate that the old hash pin rejected the changed native source.
The subsequent reviewed pin update compares immutable Git blob identities and
changes only the native kernel among the prior 138 selected closure inputs,
adding one native example. Complete physical verification belongs to the
separate full-worktree execution receipts. No refusal here is relabeled PASS.
