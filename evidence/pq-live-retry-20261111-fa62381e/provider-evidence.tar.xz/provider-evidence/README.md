# Provider evidence for fa62381e

This archive records dependency preparation only. It contains no native Rust test result and makes no whole-chain qualification claim.

| Stage | Actual exit | Result |
|---|---:|---|
| attempt-1 | 124 | outer 60-second owner timeout; completion not established; no provider environment exported |
| attempt-2 | 28 | original helper direct archive download failed; source digest and smoke not verified |
| attempt-3 | 1 | retained archive candidate missing; refused before creating preparation directory |
| source-download | 0 | exact official release asset complete; 53,279,637 bytes match unchanged source SHA256 |
| attempt-4 | 0 | fresh original-helper static build and real ML-DSA65 smoke verified; complete source before/after unchanged |

The successful artifact is the fresh attempt-4 OpenSSL 3.5.9 installation. The official source asset was downloaded separately with gh and checked against the unchanged helper SHA256 pin before the original helper copied, rechecked, built and exercised it. The helper was not edited. Earlier failures are retained.

The original helper performed real ML-DSA-65 key generation, signing, correct-message verification and wrong-message rejection before exporting its seven environment keys. It did not execute upstream full tests or native Rust tests. Its source commit was 7f83ea843d6d1578a475a7a0c4dc026da564a795.

All five current provider inputs match the successful helper receipt. Executables, static libraries, headers, source tarballs and generated private/public key files are not packed; only their identities and the retained logs/receipts are included. Log paths may name temporary test-key files, but no private-key material is included.

FILES.json lists SHA256, bytes and provenance for every evidence payload. SHA256SUMS also covers FILES.json. The external archive-files.json lists every regular tar entry, including these two index files. The final tar checksum is external in archive.json, avoiding self-referential hashes.
