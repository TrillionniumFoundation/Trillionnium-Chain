#!/usr/bin/env python3
"""Retain exact preliminary logs and interrupted native fixture bytes."""
import collections
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path('/home/qian-qi/work/chain-native-profile-closure-20261107-89df')
REPO = ROOT / 'repo'
EVIDENCE = REPO / 'evidence/pon-native-profile-closure-20261107'
STAGE = ROOT / 'preliminary-history-v1'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def save_json(path, value):
    save(path, (json.dumps(value, sort_keys=True, indent=2) + '\n').encode())


def copy_tree(source, dest):
    for item in sorted(source.rglob('*')):
        if item.is_symlink():
            raise ValueError('SYMLINK:' + str(item))
        if item.is_file():
            save(dest / item.relative_to(source), item.read_bytes())


def log_json(path):
    decoder = json.JSONDecoder()
    rows = []
    for number, line in enumerate(path.read_text().splitlines(), 1):
        position = line.find('{')
        if position < 0:
            continue
        try:
            item, end = decoder.raw_decode(line[position:])
        except ValueError:
            continue
        if isinstance(item, dict):
            rows.append((number, item))
    return rows


subprocess.run(['bash', 'scripts/project-preflight.sh'], cwd=REPO, check=True)
STAGE.mkdir(exist_ok=False)
for name in ('preliminary-native-v3-v1', 'preliminary-native-observation-v2'):
    copy_tree(ROOT / name, STAGE / name)
for number in (1, 2, 3):
    name = 'source-part' + str(number) + '.tar.xz'
    choices = [directory / name for directory in (ROOT, ROOT / 'inputs')
               if (directory / name).is_file()]
    if len(choices) != 1:
        raise ValueError('TRANSFER_ARCHIVE_NOT_UNIQUE:' + name)
    save(STAGE / 'source-transfers' / name, choices[0].read_bytes())

initial_scope = json.loads((ROOT / 'preliminary-native-v3-v1/source-scope.json').read_text())
rustfmt = subprocess.check_output([
    '/home/qian-qi/.cargo/bin/rustup', 'which', '--toolchain', '1.95.0', 'rustfmt'], text=True).strip()
with tarfile.open(STAGE / 'source-transfers/source-part2.tar.xz') as archive:
    members = {member.name: member for member in archive.getmembers() if member.isfile()}
    for relative, expected in initial_scope['formatted_native_sources'].items():
        choices = [member for name, member in members.items()
                   if name == relative or name.endswith('/' + relative)]
        if len(choices) != 1:
            raise ValueError('INITIAL_SOURCE_NOT_UNIQUE:' + relative)
        target = STAGE / 'initial-formatted-native-source' / relative
        save(target, archive.extractfile(choices[0]).read())
        subprocess.run([rustfmt, '--edition', '2021', str(target)], check=True)
        if sha(target.read_bytes()) != expected:
            raise ValueError('INITIAL_SOURCE_RECONSTRUCTION_MISMATCH:' + relative)

query_log = ROOT / 'preliminary-native-observation-v2/native-query-observation-controls.log'
records = log_json(query_log)
retentions = [row['manifest'] for _, row in records
              if row.get('manifest', {}).get('schema') == 'pon-grouped-query-retained-native-failure-v1']
directories = set()
for retained in retentions:
    source = Path(retained['retained_directory']).resolve()
    if source.parent != ROOT / 'tmp':
        raise ValueError('UNEXPECTED_RETAINED_DIRECTORY:' + str(source))
    actual_manifest = json.loads((source / 'RETENTION_MANIFEST.json').read_text())
    if actual_manifest != retained:
        raise ValueError('RETENTION_MANIFEST_DIFFERS')
    for row in retained['files']:
        target = source / row['path']
        if source not in target.resolve().parents or target.is_symlink():
            raise ValueError('RETAINED_PATH_ESCAPE')
        raw = target.read_bytes()
        if len(raw) != row['bytes'] or sha(raw) != row['sha256']:
            raise ValueError('RETAINED_BYTES_DIFFER:' + str(target))
    directories.add(source)
    original = Path(retained['original_directory']).resolve()
    if original.parent != ROOT / 'tmp':
        raise ValueError('UNEXPECTED_ORIGINAL_DIRECTORY')
    directories.add(original)
for directory in sorted(directories):
    copy_tree(directory, STAGE / 'original-fixtures' / directory.name)
if len(retentions) != 2 or len(directories) != 4:
    raise ValueError('PRELIMINARY_RETENTION_DENOMINATOR')

captures = [(line, row) for line, row in records
            if row.get('schema') == 'pon-grouped-query-native-capture-test-v1']
readers = [(line, row) for line, row in records
           if row.get('schema') == 'pon-grouped-query-native-reader-test-v1']
native_log = ROOT / 'preliminary-native-observation-v2/native-task-operation-v2.log'
native = [(line, row) for line, row in log_json(native_log)
          if row.get('schema') == 'pon-native-task-current-fixture-observation-v1']
if len(native) != 12:
    raise ValueError('NATIVE_CURRENT_OBSERVATION_DENOMINATOR:' + str(len(native)))
save_json(STAGE / 'derived-readback.json', {
    'schema': 'pon-native-profile-preliminary-evidence-readback-v1',
    'qualification_run': False,
    'evidence_kind': 'CONTROLLED_FIXTURE',
    'native_current_log_sha256': sha(native_log.read_bytes()),
    'native_current_observation_count': len(native),
    'native_current_phases': dict(collections.Counter(row['phase'] for _, row in native)),
    'native_current_observations': [{'original_log_line': line, 'observation': row} for line, row in native],
    'native_query_log_sha256': sha(query_log.read_bytes()),
    'native_query_capture_count': len(captures),
    'native_query_captures': [{
        'original_log_line': line, 'case': row['case'], 'label': row['label'],
        'process_returncode': row['process_returncode'],
        'observed_seed_queries': sum(item['kind'] == 'seed' for item in row['durable_prefix']),
        'observed_step_queries': sum(item['kind'] == 'step' for item in row['durable_prefix']),
        'durable_prefix_sha256': row['durable_prefix_sha256'],
        'native_response_sha256': row['native_response_sha256']
    } for line, row in captures],
    'reader_captures': [{'original_log_line': line, 'case': row['case'],
                         'qualification': row['assessment']['qualification'],
                         'actual_chainwork': row['assessment']['actual_chainwork']} for line, row in readers],
    'retained_manifests': retentions,
    'retained_fixture_directories': [str(directory) for directory in sorted(directories)],
    'original_failure_superseded': False,
    'public_coverage_established': False,
    'independent_demand_established': False,
    'complete_physical_cost_established': False,
    'native_profile_registered': False,
    'actual_chainwork': 0,
})
save(STAGE / Path(__file__).name, Path(__file__).read_bytes())
rows = []
for item in sorted(STAGE.rglob('*')):
    if item.is_file():
        raw = item.read_bytes()
        rows.append({'path': str(item.relative_to(STAGE)), 'bytes': len(raw), 'sha256': sha(raw)})
save_json(STAGE / 'MANIFEST.json', {'schema': 'pon-native-profile-preliminary-archive-manifest-v1', 'files': rows})
archive_path = EVIDENCE / 'preliminary-history-v1.tar.gz'
with archive_path.open('xb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(mode='w', fileobj=compressed) as archive:
            for item in sorted(STAGE.rglob('*')):
                if not item.is_file():
                    continue
                raw = item.read_bytes()
                entry = tarfile.TarInfo(str(item.relative_to(STAGE)))
                entry.size = len(raw)
                entry.mode = 0o644
                entry.mtime = 0
                archive.addfile(entry, io.BytesIO(raw))
with tarfile.open(archive_path) as archive:
    expected = {row['path']: row for row in rows}
    for member in archive.getmembers():
        if not member.isfile() or '..' in Path(member.name).parts or Path(member.name).is_absolute():
            raise ValueError('UNSAFE_ARCHIVE_MEMBER')
        raw = archive.extractfile(member).read()
        source = STAGE / member.name
        if raw != source.read_bytes():
            raise ValueError('ARCHIVE_READBACK_DIFFERS')
    if set(archive.getnames()) != set(expected) | {'MANIFEST.json'}:
        raise ValueError('ARCHIVE_MEMBER_DENOMINATOR')
receipt = {'schema': 'pon-native-profile-preliminary-archive-receipt-v1',
           'path': archive_path.name, 'bytes': archive_path.stat().st_size,
           'sha256': sha(archive_path.read_bytes()), 'member_count': len(rows) + 1,
           'file_bytes': sum(row['bytes'] for row in rows), 'readback_verified': True,
           'original_native_failure_retained': True, 'original_journal_bytes_retained': True,
           'qualification_run': False}
save_json(EVIDENCE / 'preliminary-history-v1.json', receipt)
save(EVIDENCE / 'preliminary-readback-v1.json', (STAGE / 'derived-readback.json').read_bytes())
print(json.dumps(receipt), flush=True)
