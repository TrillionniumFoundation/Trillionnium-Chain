#!/usr/bin/env python3
"""Verify final witness artifacts, including retained failures, without running native tests."""
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile
import time
import zipfile

ROOT = Path(__file__).resolve().parent
PREFIX = 'hosted-final-payloads-41628135456/'
HEAD = '12fe5f2c1f19704fe7eb635dede6839ed8b1e91e'
TREE = 'c44112da731e3f958e55eb024e5762d6723ea2c9'
BASE = '2e72a989d001cf51bd0aed0e1401526e45db31f1'
MERGE = '0357031364787574cb7058b05329aa2e2730f947'
RUN = 41628135456
JOBS = {('X64', 'head'): 125890591823, ('X64', 'prospective-merge'): 125890592046,
        ('ARM64', 'head'): 125890592233, ('ARM64', 'prospective-merge'): 125890592092}
EXPECTED_FAILURES = {
    'store::detached_admission::tests::admitted_custom_genesis_over_eight_mib_keeps_original_held_schedule_and_cpu_owner',
    'store::detached_admission::tests::authenticated_large_parent_original_schedule_supplementary_denominator',
}
ARCHIVE_DATA = None
if len(sys.argv) == 2:
    ARCHIVE_DATA = {}
    with tarfile.open(sys.argv[1], 'r:xz') as archive:
        for member in archive:
            if not member.isfile() or not member.name.startswith(PREFIX):
                raise AssertionError('unexpected archive entry ' + member.name)
            name = member.name.removeprefix(PREFIX)
            if name in ARCHIVE_DATA:
                raise AssertionError('duplicate archive entry ' + name)
            ARCHIVE_DATA[name] = archive.extractfile(member).read()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(name):
    return ARCHIVE_DATA[name] if ARCHIVE_DATA is not None else (ROOT / name).read_bytes()


def load(name):
    return json.loads(read(name))


def require(value, message):
    if not value:
        raise AssertionError(message)


def payload_or_zip(artifact):
    aid = str(artifact['id'])
    original_hash = artifact['digest'].removeprefix('sha256:')
    if ARCHIVE_DATA is None and (ROOT / (aid + '.zip')).exists():
        raw = (ROOT / (aid + '.zip')).read_bytes()
        require(sha(raw) == original_hash and len(raw) == artifact['size_in_bytes'], 'original ZIP digest/size')
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            require(len(z.namelist()) == len(set(z.namelist())), 'duplicate ZIP members')
            files = {name: z.read(name) for name in z.namelist()}
        return files, True
    previous = next(row for row in load('original-container-verification.json') if row['artifact_id'] == artifact['id'])
    require(previous['sha256'] == original_hash and previous['bytes'] == artifact['size_in_bytes']
            and previous['github_digest_matches'] is True, 'retained original ZIP verification')
    manifest = load('raw-member-manifests.json')[aid]
    prefix = 'payloads/' + aid + '/'
    if ARCHIVE_DATA is not None:
        actual_names = {name.removeprefix(prefix) for name in ARCHIVE_DATA if name.startswith(prefix)}
    else:
        base = ROOT / prefix
        actual_names = {str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    require(actual_names == {item['name'] for item in manifest}, 'payload member set')
    files = {}
    for item in manifest:
        data = read(prefix + item['name'])
        require(len(data) == item['bytes'] and sha(data) == item['sha256'], 'payload member bytes')
        files[item['name']] = data
    return files, False


def failure_details(log, names):
    details = []
    for match in re.finditer(r'^---- (.+) stdout ----\n', log, re.M):
        if match[1] not in names:
            continue
        end = log.find('\n---- ', match.end())
        block = log[match.end():end if end >= 0 else len(log)]
        panic_marker = "thread '" + match[1] + "'"
        start = block.rfind(panic_marker)
        require(start >= 0, 'missing matching failed-test panic')
        panic = block[start:].split('\n\n', 1)[0]
        require('detached_admission/tests.rs:724:31' in panic and
                'PublicMutationCpuBudget' in panic and 'PUBLIC_MUTATION_CPU_BUDGET' in panic,
                'unexpected failed-test assertion')
        values = []
        for line in block.splitlines():
            if not line.startswith('{'):
                continue
            try:
                obj = json.loads(line)
            except ValueError:
                continue
            if obj.get('schema') == 'native-large-parent-schedule-parity-v1':
                keys = ('schema', 'authenticated_backend', 'native_result', 'original_cpu_receipt',
                        'host_qualified', 'all_honest_service_qualified',
                        'complete_key_utf8_and_canonical_value_bytes', 'early_capacity_observed_lower_bound_bytes')
                values.append({key: obj[key] for key in keys if key in obj})
            elif obj.get('schema') == 'native-large-parent-original-dispatch-diagnostic-v1':
                keys = ('schema', 'authenticated_backend', 'original_dispatch_result', 'dispatch_elapsed_ns',
                        'cpu_budget_before', 'cpu_budget_after', 'actual_cpu_flow_after',
                        'complete_key_utf8_and_canonical_value_bytes', 'observed_held_capacity_lower_bound_bytes')
                values.append({key: obj[key] for key in keys if key in obj})
        rejected = [item for item in values if item.get('native_result') == {'Err': 'PUBLIC_MUTATION_CPU_BUDGET'}]
        require(len(rejected) == 1 and rejected[0]['authenticated_backend'] is True and
                rejected[0]['original_cpu_receipt']['live_refused'] is True, 'missing actual budget refusal receipt')
        details.append({'test': match[1], 'panic': panic, 'original_measurements': values,
                        'failure_block_sha256': sha(block.encode())})
    require(len(details) == len(names) and {item['test'] for item in details} == set(names), 'failure detail coverage')
    return details


def main():
    artifacts = load('api-final-artifacts.json')
    run = load('api-final-run.json')
    jobs = {job['id']: job for job in load('api-final-jobs.json')['jobs']}
    head = load('api-head-commit.json')
    merge = load('api-merge-commit.json')
    require(len(artifacts) == 4 and run['id'] == RUN and run['run_attempt'] == 1 and
            run['head_sha'] == HEAD and run['status'] == 'completed' and run['conclusion'] == 'failure', 'run binding')
    require(head['sha'] == HEAD and head['commit']['tree']['sha'] == TREE, 'head tree')
    require(merge['sha'] == MERGE and merge['tree']['sha'] == TREE and
            [p['sha'] for p in merge['parents']] == [BASE, HEAD], 'merge parents/tree')
    required = load('required-tests-source.json')
    selectors = required['tests']
    require(len(selectors) == len(set(selectors)) == required['expected_meaningful_controls'] == 45 and
            required['whole_chain_quantum_security_qualified'] is False and
            required['original_business_budgets_changed'] is False, 'required controls scope')
    ns = {'__name__': 'retained_required_test_validator'}
    checker = read('check_required_native_test.py')
    require(hashlib.sha1(b'blob ' + str(len(checker)).encode() + b'\0' + checker).hexdigest() ==
            load('source-files-metadata.json')['native_checker']['blob_sha'], 'checker source')
    exec(compile(checker, 'check_required_native_test.py', 'exec'), ns)
    early = load('early-controls-readback.json')
    output = {'schema': 'trnm-pq-final-witness-artifact-readback-v1', 'run_id': RUN,
              'readback_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
              'candidate': HEAD, 'base': BASE, 'prospective_merge': MERGE, 'tested_tree': TREE,
              'workflow_conclusion': 'failure', 'all_native_lanes_passed': False,
              'whole_chain_quantum_security_qualified': False, 'original_business_budgets_changed': False,
              'source_verification_scope': 'Producer before/after tracked-byte identity checked against GitHub immutable commits/trees; local readback does not reconstruct the complete 782174381-byte source tree.',
              'failure_cause_attribution': 'None beyond the observed PublicMutationCpuBudget errors and original numeric receipts; no environment attribution.',
              'lanes': []}
    all_members = {}
    container_records = []
    ignored_reference = None
    for artifact in sorted(artifacts, key=lambda a: a['id']):
        files, zip_checked_now = payload_or_zip(artifact)
        source = json.loads(files['source.json'])
        first = json.loads(files['native-00.json'])
        arch = first['environment']['RUNNER_ARCH']
        key = (arch, source['kind'])
        require(key in JOBS and source['candidate'] == HEAD and source['tested_tree'] == TREE and
                source['tracked_worktree_verified'] is True and source['tests_executed_by_identity_check'] is False,
                'source/architecture scope')
        old = next(lane for lane in early['lanes'] if (lane['arch'], lane['source']['kind']) == key)
        require(source == old['source'], 'early/final source identity')
        require(artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD,
                'artifact run/head')
        for item in old['zip_manifest']:
            data = files[item['name']]
            require(len(data) == item['bytes'] and sha(data) == item['sha256'], 'early/final raw member changed: ' + item['name'])
        added = set(files) - {item['name'] for item in old['zip_manifest']}
        require(added == {'node-lib.json', 'node-lib.log', 'clippy.json', 'clippy.log'}, 'unexpected final additions')
        require(files['required-tests.tsv'].decode() == ''.join(f'native-{i:02d}\t{s}\n' for i, s in enumerate(selectors)), 'selector ordering')
        commands = []
        for name, raw in files.items():
            if not name.endswith('.json'):
                continue
            record = json.loads(raw)
            if not isinstance(record, dict) or record.get('schema') != 'trnm-pq-native-command-v1':
                continue
            expected_exit = 101 if name == 'node-lib.json' and arch == 'ARM64' else 0
            require(record['before'] == record['after'] == source, name + ' source changed')
            require(record['exit_code'] == expected_exit and record['status'] ==
                    ('command_succeeded' if expected_exit == 0 else 'command_failed'), name + ' result')
            require(record['whole_chain_quantum_security_qualified'] is False, name + ' qualification')
            log = files[record['log_file']]
            require(sha(log) == record['log_sha256'] and len(log) == record['log_bytes'], name + ' raw log mismatch')
            require(record['environment']['GITHUB_RUN_ID'] == str(RUN) and record['environment']['GITHUB_RUN_ATTEMPT'] == '1', name + ' run')
            commands.append({'file': name, 'sha256': sha(raw), 'exit_code': expected_exit,
                             'log_file': record['log_file'], 'log_sha256': sha(log), 'log_bytes': len(log)})
        controls = []
        for index, selector in enumerate(selectors):
            label = f'native-{index:02d}'
            execution = ns['validate'](files[label + '.log'].decode().splitlines(keepends=True), selector)
            require(execution == json.loads(files[label + '-execution.json']), label + ' actual execution')
            require(sha(files[label + '.log']) == old['all_controls'][index]['log_sha256'], label + ' early log identity')
            controls.append({'selector': selector, 'result': 'PASS', 'executed_tests': 1,
                             'log_sha256': sha(files[label + '.log'])})
        node = json.loads(files['node-lib.json'])
        clippy = json.loads(files['clippy.json'])
        require(node['argv'] == ['cargo', '+1.95.0', 'test', '--locked', '--manifest-path', 'trillionnium/Cargo.toml',
                '-p', 'trnm-pon-node', '--lib', '--all-features', '--', '--show-output', '--test-threads=1'], 'full Node command')
        require(clippy['argv'] == ['cargo', '+1.95.0', 'clippy', '--locked', '--manifest-path', 'trillionnium/Cargo.toml',
                '-p', 'trnm-pon-node', '--lib', '--tests', '--all-features', '--', '-D', 'warnings'], 'strict Clippy command')
        provider = json.loads(files['pq-provider/provider.json'])
        for record in (node, clippy):
            env = record['environment']
            require(env['RUNNER_ARCH'] == arch and env['TRNM_PQ_OPENSSL_SHA256'] == provider['cli_sha256']
                    and env['TRNM_PQ_OPENSSL_VERSION'] == provider['version'] == '3.5.9', 'provider/environment binding')
        log = files['node-lib.log'].decode()
        summaries = re.findall(r'^test result: (ok|FAILED)\. ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; '
                               r'([0-9]+) measured; ([0-9]+) filtered out; finished in ([0-9.]+)s$', log, re.M)
        require(bool(summaries), 'full Node outer summary missing')
        result, passed, failed, ignored, measured, filtered, seconds = summaries[-1]
        totals = {'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored),
                  'measured': int(measured), 'filtered_out': int(filtered), 'elapsed_test_seconds': float(seconds)}
        require((totals['passed'], totals['failed'], totals['ignored']) ==
                ((895, 2, 22) if arch == 'ARM64' else (897, 0, 22)), 'actual full suite totals')
        require(int(measured) == int(filtered) == 0 and re.findall(r'^running ([0-9]+) tests?$', log, re.M)[0] == '919', 'full suite scope')
        prefix = log.split('\nsuccesses:\n', 1)[0]
        ignored_names = sorted(set(re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\. ignored[^\n]*$', prefix, re.M)))
        failed_names = sorted(set(re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\. FAILED$', prefix, re.M)))
        require(len(ignored_names) == 22 and set(failed_names) == (EXPECTED_FAILURES if arch == 'ARM64' else set()), 'ignored/failed identities')
        require(not set(failed_names) & set(selectors), 'full failures overlap required controls')
        if ignored_reference is None:
            ignored_reference = ignored_names
        require(ignored_names == ignored_reference, 'ignored set differs across lanes')
        failure_rows = failure_details(log, failed_names)
        if failed_names:
            tail = log.rsplit('\nfailures:\n', 1)[1].split('\ntest result:', 1)[0]
            require(sorted(re.findall(r'^    ([A-Za-z0-9_:]+)$', tail, re.M)) == failed_names, 'final failed-test list')
        job = jobs[JOBS[key]]
        require(job['head_sha'] == HEAD and job['run_id'] == RUN and job['status'] == 'completed' and
                job['conclusion'] == ('failure' if arch == 'ARM64' else 'success'), 'terminal job binding')
        failed_steps = [step['name'] for step in job['steps'] if step['conclusion'] == 'failure']
        require(failed_steps == (['Preserve the complete original Node library regression suite'] if arch == 'ARM64' else []), 'job failed steps')
        clippy_text = files['clippy.log'].decode()
        require('Finished `dev` profile ' in clippy_text and not re.search(r'^error(?:\[|:)', clippy_text, re.M), 'Clippy actual completion')
        manifest = [{'name': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in files.items()]
        all_members[str(artifact['id'])] = manifest
        container_records.append({'artifact_id': artifact['id'], 'bytes': artifact['size_in_bytes'],
                                  'sha256': artifact['digest'].removeprefix('sha256:'), 'github_digest_matches': True})
        output['lanes'].append({'artifact_id': artifact['id'], 'artifact_name': artifact['name'],
            'artifact_bytes': artifact['size_in_bytes'], 'artifact_sha256': artifact['digest'].removeprefix('sha256:'),
            'original_zip_digest_recomputed_this_run': zip_checked_now, 'arch': arch, 'source': source,
            'job_id': JOBS[key], 'job_conclusion': job['conclusion'], 'early_artifact_id': old['artifact_id'],
            'early_members_byte_identical': len(old['zip_manifest']), 'new_final_members': sorted(added),
            'required_controls': {'passed': 45, 'failed': 0, 'ignored': 0, 'records': controls},
            'node_suite': {'exit_code': node['exit_code'], 'status': result, 'totals': totals,
                           'ignored_names': ignored_names, 'failed_names': failed_names, 'failure_details': failure_rows,
                           'log_sha256': node['log_sha256'], 'log_bytes': node['log_bytes'],
                           'summary_selection': 'Final outer libtest summary; nested child-process summaries are not added to totals.'},
            'clippy': {'exit_code': clippy['exit_code'], 'argv': clippy['argv'], 'log_sha256': clippy['log_sha256'],
                       'log_bytes': clippy['log_bytes'], 'completion_line': clippy_text.splitlines()[-1]},
            'all_command_records_checked': commands})
    require({(lane['arch'], lane['source']['kind']) for lane in output['lanes']} == set(JOBS), 'four-lane coverage')
    output['readback_validation_passed'] = True
    output['native_regression_gate'] = 'FAIL: two retained full Node failures in each ARM lane'
    output['early_controls_total_preserved_passes'] = 180
    output['clippy_successful_lanes'] = 4
    output['original_zip_digests_recomputed_this_run'] = all(lane['original_zip_digest_recomputed_this_run'] for lane in output['lanes'])
    out_name = 'final-readback.json' if output['original_zip_digests_recomputed_this_run'] else 'payload-readback.json'
    (ROOT / out_name).write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    if output['original_zip_digests_recomputed_this_run']:
        (ROOT / 'raw-member-manifests.json').write_text(json.dumps(all_members, indent=2, sort_keys=True) + '\n')
        (ROOT / 'original-container-verification.json').write_text(json.dumps(container_records, indent=2) + '\n')
    print(json.dumps({'readback_validated': True, 'native_regression_gate': output['native_regression_gate'],
                      'lanes': [{'artifact_id': row['artifact_id'], 'arch': row['arch'], 'kind': row['source']['kind'],
                                 'node': row['node_suite']['totals'], 'clippy_exit': row['clippy']['exit_code'],
                                 'early_identical_members': row['early_members_byte_identical']} for row in output['lanes']]}))


if __name__ == '__main__':
    main()
