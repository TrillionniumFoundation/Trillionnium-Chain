import hashlib,json,os,subprocess,sys,time
from pathlib import Path
repo=Path('/home/qian-qi/worktrees/trnm-pq-frozen-verifier-20261103')
out=Path('/home/qian-qi/qualification/pq-frozen-verifier-20261103-4502')
out.mkdir(parents=True,exist_ok=False)
paths=['formal/pon-nakamoto-v1/w1_hardened_verifier/'+x for x in ['src/main.rs','README.md','Cargo.toml','Cargo.lock']]
manifest='formal/pon-nakamoto-v1/w1_hardened_verifier/Cargo.toml'
cargo='/home/qian-qi/.cargo/bin/cargo'
env=os.environ.copy()
env.update(CARGO_TARGET_DIR=str(out/'target'),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',RUSTC='/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc')
for k in ['RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RISC0_DEV_MODE','BONSAI_API_URL','BONSAI_API_KEY','RISC0_PROVER']:
    if env.get(k): raise RuntimeError('unexpected override '+k)
def hashes():
    return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
def run(label,argv,frozen=True):
    start=time.monotonic_ns()
    before=hashes() if frozen else None
    rec={'label':label,'argv':argv,'cwd':str(repo),'status':'running','source_before':before,'base_commit':'1c7e8ab7cd6a321cad4e6c7f7e8a197d7b3be14c','whole_chain_quantum_security_qualified':False}
    rp=out/(label+'.json'); lp=out/(label+'.log')
    rp.write_text(json.dumps(rec,indent=2)+'\n')
    with lp.open('xb') as f:
        result=subprocess.run(argv,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
    after=hashes() if frozen else None
    rec.update(status='command_succeeded' if result.returncode==0 else 'command_failed',exit_code=result.returncode,elapsed_ns=time.monotonic_ns()-start,log_sha256=hashlib.sha256(lp.read_bytes()).hexdigest(),log_bytes=lp.stat().st_size,source_after=after)
    rp.write_text(json.dumps(rec,indent=2)+'\n')
    print(json.dumps({'label':label,'exit_code':result.returncode,'source_unchanged':before==after,'log':str(lp)}),flush=True)
    if frozen and before!=after: raise RuntimeError('source changed during '+label)
    if result.returncode: print(lp.read_text(errors='replace')[-6000:],flush=True); sys.exit(result.returncode)
run('preflight',['bash','scripts/project-preflight.sh'])
run('format',[cargo,'+1.95.0','fmt','--manifest-path',manifest],False)
run('diff-check',['git','diff','--check'])
(out/'source.json').write_text(json.dumps({'base_commit':'1c7e8ab7cd6a321cad4e6c7f7e8a197d7b3be14c','worktree_modified':True,'source':hashes(),'scope':'isolated verification-only crate, not full source corpus'},indent=2)+'\n')
proof=out/'retained-proof';proof.mkdir()
prefix='evidence/pon-w1-complete-succinct-20261028/full-proof/'
assets=[('header.bin',prefix+'header.bin','7b96038f228a1eedccf7b29ffc54802aba691be7259e33937846c6bf6126d78f'),('succinct.bin',prefix+'succinct.bin','ca4d3c9f5159b7001abae7491604cadbbbfa97c0f93d90d5943e48936813ca2b'),('real-lift.bin','evidence/pon-w1-verifier-hardening-20261028/real-lift-0000.bin','d2b06a1feca2d15e8dc5741b43f481a82c32d7d3dab01e413d357012467093d3')]
for name,source_path,expected in assets:
    blob=subprocess.check_output(['git','show','HEAD:'+source_path],cwd=repo)
    assert hashlib.sha256(blob).hexdigest()==expected,name
    (proof/name).write_bytes(blob)
(out/'asset-identities.json').write_text(json.dumps(assets,indent=2)+'\n')
run('toolchain',[env['RUSTC'],'--version','--verbose'])
run('tests',[cargo,'+1.95.0','test','--locked','--release','--manifest-path',manifest])
run('build',[cargo,'+1.95.0','build','--locked','--release','--manifest-path',manifest])
run('clippy',[cargo,'+1.95.0','clippy','--locked','--release','--all-targets','--manifest-path',manifest,'--','-D','warnings'])
run('fmt-check',[cargo,'+1.95.0','fmt','--manifest-path',manifest,'--','--check'])
binary=out/'target/release/trnm-w1-hardened-verifier'
(out/'binary.json').write_text(json.dumps({'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},indent=2)+'\n')
run('full-receipt',[str(binary),'verify',str(proof/'header.bin'),str(proof/'succinct.bin')])
run('full-controls',[str(binary),'controls',str(proof/'header.bin'),str(proof/'succinct.bin'),str(out/'controls')])
run('recursion-diagnostic',[str(binary),'verify-recursion',str(proof/'real-lift.bin')])
(out/'final-source.json').write_text(json.dumps(hashes(),indent=2)+'\n')
subprocess.run(['git','diff','--stat'],cwd=repo,check=True)
print('COMPLETE '+str(out),flush=True)
