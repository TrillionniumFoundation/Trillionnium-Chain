import pathlib,subprocess,json,os,hashlib,time,sys,traceback
root=pathlib.Path('/home/qian-qi/chain-stark-challenge-20261109-886f')
repo=root/'repo'
p=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=repo,capture_output=True)
assert p.returncode==0,(p.stdout,p.stderr)
out=root/'validation-recovery'/'provider-3.5.9-v1'
out.mkdir(parents=True,exist_ok=False)
(out/'controller.py').write_text(sys.orig_argv[-1])
(out/'preflight.stdout.log').write_bytes(p.stdout);(out/'preflight.stderr.log').write_bytes(p.stderr)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo).decode().strip()
base_commit='858393d9c49e90a9c5ab948b2cfa6bca860c2198'
base_tree='3ff56675cee2a4103e8e2d7742e6ec10c9e9a16c'
assert git('rev-parse','HEAD')==base_commit
assert git('rev-parse','HEAD^{tree}')==base_tree
assert git('status','--porcelain')==''
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def source_snapshot():
 rows=[]
 for rel in subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split(chr(0)):
  if not rel:continue
  path=repo/rel
  assert path.is_file() and not path.is_symlink(),rel
  rows.append({'path':rel,'bytes':path.stat().st_size,'sha256':sha(path)})
 return rows
try:
 before=source_snapshot()
 (out/'source-before.json').write_text(json.dumps({'commit':base_commit,'tree':base_tree,'tracked_files':before},indent=2)+'\n')
 print('SOURCE_BEFORE '+json.dumps({'files':len(before),'bytes':sum(r['bytes'] for r in before)}),flush=True)
 prefix=pathlib.Path('/tmp/chain-pq-independent-desktop-20261106-quantum-work-v1/runner-temp/trnm-pq-provider-3.5.9.Bq3EfDKT/install')
 receipt_path=pathlib.Path('/tmp/chain-pq-independent-desktop-20261106-quantum-work-v1/receipts/provider-local-source-v2/pq-provider/provider.json')
 receipt=json.loads(receipt_path.read_text())
 expected_archive='603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a'
 assert receipt['install_prefix']==str(prefix) and receipt['version']=='3.5.9'
 assert receipt['result']=='PREPARED_AND_SMOKE_VERIFIED' and receipt['source_digest_verified'] is True
 assert receipt['source_archive_sha256_expected']==expected_archive
 script=repo/'scripts/ci/prepare_pq_provider.sh';script_text=script.read_text()
 assert "readonly openssl_version='3.5.9'" in script_text and "readonly openssl_sha256='"+expected_archive+"'" in script_text
 identities=[]
 for row in receipt['native_backend_inputs']:
  path=pathlib.Path(row['path'])
  assert path.is_file() and not path.is_symlink()
  actual={'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)}
  assert actual==row,(row,actual)
  identities.append(actual)
 assert '# define OPENSSL_VERSION_STR "3.5.9"' in (prefix/'include/openssl/opensslv.h').read_text()
 assert (prefix/'lib/libcrypto.a').is_file() and (prefix/'lib/libssl.a').is_file()
 env=os.environ.copy()
 selected={'OPENSSL_DIR':str(prefix),'OPENSSL_LIB_DIR':str(prefix/'lib'),'OPENSSL_INCLUDE_DIR':str(prefix/'include'),'OPENSSL_STATIC':'1','OPENSSL_CONF':'/dev/null','OPENSSL_MODULES':str(prefix/'lib/ossl-modules'),'TRNM_PQ_OPENSSL':str(prefix/'bin/openssl'),'TRNM_PQ_OPENSSL_SHA256':receipt['cli_sha256'],'TRNM_PQ_OPENSSL_VERSION':'3.5.9','LD_LIBRARY_PATH':str(prefix/'lib'),'CARGO_TARGET_DIR':str(root/'cargo-target'),'PYTHONDONTWRITEBYTECODE':'1'}
 env.update(selected);env['PATH']='/home/qian-qi/.cargo/bin:'+env.get('PATH','')
 version=subprocess.run([str(prefix/'bin/openssl'),'version','-a'],env=env,capture_output=True)
 assert version.returncode==0 and version.stdout.startswith(b'OpenSSL 3.5.9 ')
 (out/'provider-version.stdout.log').write_bytes(version.stdout);(out/'provider-version.stderr.log').write_bytes(version.stderr)
 (out/'provider-historical-receipt.json').write_bytes(receipt_path.read_bytes())
 (out/'provider-verification.json').write_text(json.dumps({'preparation_script_sha256_now':sha(script),'historical_preparation_script_sha256':receipt['preparation_script_sha256'],'current_contract_source_archive_sha256':expected_archive,'source_archive_digest_scope':'historical successful preparation receipt; original compressed archive was not retrieved or rehashed in this recovery','historical_receipt_path':str(receipt_path),'historical_receipt_sha256':sha(receipt_path),'all_five_installed_inputs_match_historical_receipt':True,'installed_inputs':identities,'selected_environment':selected,'new_provider_build_performed':False,'new_provider_smoke_performed':False},indent=2)+'\n')
 old_stderr=root/'validation/cargo-clippy.stderr.log'
 old_hash=sha(old_stderr)
 cmd=['/home/qian-qi/.cargo/bin/cargo','clippy','--manifest-path','trillionnium/Cargo.toml','--locked','--offline','--workspace','--all-targets','--all-features','--','-D','warnings']
 print('CLIPPY_START '+json.dumps({'args':cmd,'provider_version':'3.5.9','original_stderr_sha256':old_hash}),flush=True)
 started=time.time()
 try:
  run=subprocess.run(cmd,cwd=repo,env=env,capture_output=True,timeout=900)
  code=run.returncode;stdout=run.stdout;stderr=run.stderr
 except subprocess.TimeoutExpired as e:
  code=124;stdout=e.stdout or b'';stderr=(e.stderr or b'')+b'\noriginal_900_second_controller_limit\n'
 (out/'cargo-clippy.stdout.log').write_bytes(stdout);(out/'cargo-clippy.stderr.log').write_bytes(stderr)
 after=source_snapshot()
 provider_after=[{'path':row['path'],'bytes':pathlib.Path(row['path']).stat().st_size,'sha256':sha(pathlib.Path(row['path']))} for row in identities]
 final={'commit':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'source_guard_count':len(before),'source_guard_bytes':sum(r['bytes'] for r in before),'all_tracked_source_bytes_unchanged':before==after,'clean_after':git('status','--porcelain')=='','provider_bytes_unchanged':identities==provider_after,'original_failure_stderr_unchanged':sha(old_stderr)==old_hash,'command':cmd,'exit_code':code,'wall_seconds':time.time()-started,'provider_version':'3.5.9','provider_source_archive_sha256':expected_archive,'full_security_qualified':False,'production_activation':False}
 (out/'source-after.json').write_text(json.dumps({'commit':final['commit'],'tree':final['tree'],'tracked_files':after},indent=2)+'\n')
 (out/'result.json').write_text(json.dumps(final,indent=2)+'\n')
 print('RECOVERY_RESULT '+json.dumps(final),flush=True)
 assert final['commit']==base_commit and final['tree']==base_tree and all(final[k] for k in ['all_tracked_source_bytes_unchanged','clean_after','provider_bytes_unchanged','original_failure_stderr_unchanged'])
 sys.exit(0 if code==0 else 1)
except Exception:
 (out/'controller-error.txt').write_text(traceback.format_exc());raise
