from pathlib import Path
import hashlib,importlib.util,os,sys
root=Path('/workspace/scratch/1eed767ad985')
p=root/'validation/run_exact_selected_controls.py'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='a8f8656fe25038fb67939b360b42631b6856dab9bd302365cd53591be2108e55'
spec=importlib.util.spec_from_file_location('capture',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=m.run_capture([sys.executable,'-B',str(root/'validation/run_composed_source_7586.py')],root,dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),root/'validation/composed-source-7586-driver')
print(r)
raise SystemExit(0 if m.capture_passed(r) else 1)
