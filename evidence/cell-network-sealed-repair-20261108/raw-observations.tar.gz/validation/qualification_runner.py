#!/usr/bin/env python3
"""Exact committed Cell component qualification; raw attempts never overwrite."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, required=True)
parser.add_argument("--out", type=Path, required=True)
parser.add_argument("--source", required=True)
args = parser.parse_args()
root = args.root.resolve(strict=True)
out = args.out.resolve()
out.mkdir(parents=True, exist_ok=False)

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")

provider = Path("/workspace/scratch/2b54b253422c/validation/provider-setup/trnm-pq-provider-3.5.9.05OylHhu/install")
provider_sha = "37643ac258f86785cdd3577b691bb785338379491a4983f697670df6ac746f69"
environment = {
    "PATH": "/workspace/scratch/5faaca703596/toolchain/cargo/bin:" + os.environ["PATH"],
    "RUSTUP_HOME": "/workspace/scratch/5faaca703596/toolchain/rustup",
    "RUSTUP_TOOLCHAIN": "1.95.0",
    "CARGO_HOME": "/workspace/scratch/277c778f9cb0/cargo-home",
    "CARGO_TARGET_DIR": "/workspace/scratch/277c778f9cb0/target",
    "CARGO_BUILD_JOBS": "2",
    "CARGO_INCREMENTAL": "0",
    "RUST_TEST_THREADS": "1",
    "OPENSSL_DIR": str(provider),
    "OPENSSL_STATIC": "1",
    "OPENSSL_CONF": "/dev/null",
    "OPENSSL_MODULES": str(provider / "lib/ossl-modules"),
    "TRNM_PQ_OPENSSL": str(provider / "bin/openssl"),
    "TRNM_PQ_OPENSSL_SHA256": provider_sha,
    "TRNM_PQ_OPENSSL_VERSION": "3.5.9",
}
env = os.environ.copy()
env.update(environment)
locks = ["trillionnium/Cargo.lock", "tests/fuzz/Cargo.lock"]
lock_before = {p: sha(root / p) for p in locks}
provider_files = ["bin/openssl", "include/openssl/opensslv.h", "include/openssl/configuration.h", "lib/libcrypto.a", "lib/libssl.a"]
preparation_path = Path("/workspace/scratch/2b54b253422c/validation/provider-setup/observations/pq-provider/provider.json")
preparation_sha = "95fcac5d3dc90356185f2183eec2cf720ae829ef60fcd098434f7eabe9831b80"
preparation = json.loads(preparation_path.read_text())
prepared_inputs = {row["path"]: row for row in preparation["native_backend_inputs"]}
def provider_inputs():
    return {p: {"bytes": (provider / p).stat().st_size, "sha256": sha(provider / p)} for p in provider_files}

provider_receipt = {
    "mode": "reuse-existing-local-provider-read-only",
    "rebuilt_in_this_run": False,
    "earlier_preparation_receipt": str(preparation_path),
    "earlier_preparation_receipt_sha256": sha(preparation_path),
    "expected_preparation_receipt_sha256": preparation_sha,
    "source_archive_sha256_expected": "603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a",
    "files": provider_inputs(),
    "cli_matches_expected": sha(provider / "bin/openssl") == provider_sha,
}
provider_receipt["all_inputs_match_preparation"] = (
    sha(preparation_path) == preparation_sha
    and preparation["source_digest_verified"] is True
    and preparation["result"] == "PREPARED_AND_SMOKE_VERIFIED"
    and set(prepared_inputs) == {str(provider / p) for p in provider_files}
    and all(row == {k: prepared_inputs[str(provider / p)][k] for k in ["bytes", "sha256"]}
            for p, row in provider_receipt["files"].items())
)
save(out / "provider-reuse.json", provider_receipt)
(out / "provider-preparation-receipt.json").write_bytes(preparation_path.read_bytes())
runner_before = sha(__file__)
save(out / "environment.json", {"recorded_environment": environment, "uname": list(os.uname()), "runner_sha256": runner_before, "source": args.source, "lock_before": lock_before, "provider": "provider-reuse.json", "scope": "local exact-source component qualification; no production activation or WAN/device qualification"})
rows = []

def run(name, argv, timeout=900, json_stdout=False):
    stdout = out / (name + (".json" if json_stdout else ".stdout.log"))
    stderr = out / (name + ".stderr.log")
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    begin = time.monotonic()
    timed_out = False
    print(json.dumps({"started": name, "utc": started}), flush=True)
    with stdout.open("xb") as so, stderr.open("xb") as se:
        process = subprocess.Popen(argv, cwd=root, env=env, stdout=so, stderr=se, start_new_session=True)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            code = 124
    row = {"name": name, "argv": argv, "cwd": str(root), "source": args.source, "started_utc": started, "elapsed_seconds": round(time.monotonic() - begin, 6), "timeout_seconds": timeout, "timed_out": timed_out, "exit_code": code, "stdout": stdout.name, "stderr": stderr.name, "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr)}
    rows.append(row)
    save(out / (name + ".command.json"), row)
    print(json.dumps({"finished": name, "exit_code": code, "elapsed_seconds": row["elapsed_seconds"]}), flush=True)
    return code == 0

source_args = ["python3", "-B", "scripts/ci/verify_ci_source.py", "--kind", "head", "--expected-head", args.source]
if not run("source-before", source_args + ["--output", str(out / "source-before.receipt.json")]):
    save(out / "summary.json", {"result": "FAIL_SOURCE", "commands": rows})
    sys.exit(1)
if not run("preflight", ["bash", "scripts/project-preflight.sh"]):
    save(out / "summary.json", {"result": "FAIL_PREFLIGHT", "commands": rows})
    sys.exit(1)
if not provider_receipt["all_inputs_match_preparation"] or not provider_receipt["cli_matches_expected"]:
    save(out / "summary.json", {"result": "FAIL_PROVIDER_INPUTS", "commands": rows})
    sys.exit(1)

run("rustc-identity", ["rustc", "-Vv"])
run("cargo-identity", ["cargo", "-Vv"])
run("provider-version", [str(provider / "bin/openssl"), "version", "-a"])
for name, command in [
    ("repository-and-links", ["python3", "-B", "scripts/ci/check_repository.py"]),
    ("canonical-plan", ["bash", "scripts/ci/check_canonical_development_plan.sh"]),
    ("pq-source-pins", ["python3", "-B", "scripts/ci/check_pq_research_integration.py"]),
    ("source-negative-controls", ["python3", "-B", "scripts/ci/test_ci_source_integrity.py"]),
    ("pq-source-negative-controls", ["python3", "-B", "scripts/ci/test_pq_research_integration.py"]),
    ("ci-contract-negative-controls", ["python3", "-B", "scripts/ci/test_ci_contract.py"]),
    ("distributed-source-inventory", ["python3", "-B", "scripts/refresh_distributed_source_inventory.py", "--check"]),
    ("complete-version-vector", ["python3", "-B", "scripts/cell_complete_version_vector.py", "--check"]),
    ("complete-content-vector", ["python3", "-B", "scripts/cell_version_content_vector.py", "--check"]),
]:
    run(name, command)

workspace = ["--manifest-path", "trillionnium/Cargo.toml"]
for name, manifest, extra in [
    ("locked-default-graph", "trillionnium/Cargo.toml", []),
    ("locked-all-features-graph", "trillionnium/Cargo.toml", ["--all-features"]),
    ("locked-fuzz-graph", "tests/fuzz/Cargo.toml", []),
]:
    run(name, ["cargo", "metadata", "--manifest-path", manifest, "--format-version", "1", "--locked", "--offline"] + extra, json_stdout=True)
run("all-source-format", ["cargo", "fmt"] + workspace + ["--all", "--", "--check"])
run("complete-da-native-and-doc-tests", ["cargo", "test"] + workspace + ["-p", "trnm-data-availability", "--locked", "--offline", "--", "--test-threads=1"], timeout=1200)
run("strict-workspace-all-features-clippy", ["cargo", "clippy"] + workspace + ["--workspace", "--all-targets", "--all-features", "--locked", "--offline", "--", "-D", "warnings"], timeout=1200)
for example in ["cell_bep52_cost_v1", "cell_rs46_cost_v1", "cell_signed_sealed_pipeline_v1"]:
    run(example, ["cargo", "run"] + workspace + ["-p", "trnm-data-availability", "--example", example, "--release", "--locked", "--offline"], timeout=900, json_stdout=True)
run("source-after", source_args + ["--output", str(out / "source-after.receipt.json")])

same_source = (out / "source-before.receipt.json").is_file() and (out / "source-after.receipt.json").is_file() and (out / "source-before.receipt.json").read_bytes() == (out / "source-after.receipt.json").read_bytes()
lock_after = {p: sha(root / p) for p in locks}
provider_after = provider_inputs()
provider_same = provider_after == provider_receipt["files"] and sha(preparation_path) == preparation_sha
save(out / "provider-after.json", {"files": provider_after, "unchanged": provider_same, "preparation_receipt_sha256": sha(preparation_path)})
runner_same = runner_before == sha(__file__)
all_pass = all(row["exit_code"] == 0 for row in rows) and same_source and lock_before == lock_after and provider_receipt["all_inputs_match_preparation"] and provider_same and runner_same
summary = {"schema": "trnm-cell-six-followthrough-local-qualification-v1", "result": "PASS_LOCAL_COMPONENT_CHECKS" if all_pass else "FAIL", "source": args.source, "source_before_after_identical": same_source, "lock_before": lock_before, "lock_after": lock_after, "locks_unchanged": lock_before == lock_after, "provider_inputs_unchanged": provider_same, "runner_unchanged": runner_same, "command_count": len(rows), "commands": rows, "production_activation": False, "public_independent_custody_accepted": False, "actual_payment_accepted": False, "wan_sla_observed": False, "ordinary_hepta_final_use_accepted": False, "nvme_vram_qualified": False, "whole_chain_pq_accepted": False}
save(out / "summary.json", summary)
print(json.dumps({k: summary[k] for k in ["result", "source", "source_before_after_identical", "locks_unchanged", "command_count"]}), flush=True)
sys.exit(0 if all_pass else 1)
