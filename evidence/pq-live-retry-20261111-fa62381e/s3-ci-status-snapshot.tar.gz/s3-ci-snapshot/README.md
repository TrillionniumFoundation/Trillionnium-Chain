# S3 hosted CI observation snapshot

Source commit: `454ae116159867ff6cddd91b964523df7f7e16f0`. Tree: `3117250c4db0f2ae681d51ed6ee5e6a2fa7555a9`.

This archive preserves official GitHub responses and complete retrieved logs. It makes no claim about C4 or a later commit. Run metadata, job metadata and annotations were read at different recorded times; this is not an atomic snapshot.

At 2026-11-11 16:18:15 UTC, all 24 workflow records named S3, attempt 1: **18 success, 5 failure, 1 in progress**. The sole still-running workflow was `trnm-required-baseline`. A successful workflow is an observation of that workflow, not whole-chain PQ or native business qualification.

PR #908 remained open and draft, with head `454ae116159867ff6cddd91b964523df7f7e16f0` and base `6c35f94d9387fac41c1547f05742d70150320b2e` on `fix/chain-pq-closure-20261111-d4d2`. Main remained `dd6e1c3cbeacbdc532b0679297835b3a0aac78f0`.

## Workflow snapshot

| Workflow | Run | Observed conclusion |
|---|---:|---|
| PoN work and time contract V1 | [43042229924](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229924) | success |
| PoN native full relation and path controls | [43042229519](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229519) | success |
| PoN isolated cloud build inputs | [43042230355](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042230355) | success |
| PoN W1 QROM closure observations | [43042229658](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229658) | success |
| PoN W1 QROM implementation observations | [43042229838](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229838) | success |
| W1 QROM proof-chain observations | [43042229815](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229815) | success |
| Chain Hepta closure evidence contracts | [43042229430](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229430) | success |
| Release finality reference and native baseline | [43042229744](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229744) | success |
| PoN original large-state CPU acceptance | [43042229804](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229804) | success |
| PoN four-axis throughput evidence controls | [43042229620](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229620) | success |
| PoN classical and quantum credit contract | [43042229661](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229661) | success |
| PoN W1 transparent candidate observations | [43042229778](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229778) | success |
| PoN baseline diagnostic readback | [43042229812](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229812) | success |
| PoN original workspace test-profile CPU acceptance | [43042229651](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229651) | success |
| PoN W1 work security observations | [43042229751](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229751) | failure |
| trnm-required-baseline | [43042229392](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229392) | in_progress |
| CodeQL exact-source analysis and SARIF retention | [43042229470](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229470) | success |
| CPQ1 complete content bindings | [43042229483](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229483) | success |
| PoN next architecture exact-source observations | [43042229364](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229364) | success |
| PoN original native campaign | [43042229773](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229773) | failure |
| PoN owned process cleanup | [43042229587](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229587) | failure |
| CodeQL exact-source analysis export | [43042229522](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229522) | failure |
| PoN priority acceptance | [43042229558](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229558) | failure |
| PoN PQ network and rollback witness | [43042229792](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/43042229792) | success |

## Concrete adverse observations

- **Repository truth, head job 130613468571:** original 43 root dependency register controls ran and returned four failures plus one error. The first exception was `RegisterError: source hash mismatch: trillionnium/Cargo.lock`. The current manifest also retained the old crypto-primitives and pon-node Cargo.toml pins. A separately reviewed four-file maintenance patch exists; this snapshot retains the original failed S3 observation. Merge job 130613468622 also failed the repository-truth step; its full inner log was not retrieved in this archive.
- **Original native campaign, head job 130596764483:** three original release test attempts returned 101, with `original_criteria_met=false`, no phase startup errors, and no report-validation error. The aggregate failure was `ORIGINAL_THREE_RUN_CAMPAIGN_FAILED`; systemd exited with code 1. The visible summary does not expose the failed native business assertion. The reported 2.0G memory peak is not evidence of OOM.
- **W1 fresh service, head job 130596765045:** the original host controller recorded `passed=false`, `systemd_run_exit=1`, `failure=null`, and `final_host_errors=[]`. The native build preparation completed with exit 0. The inner failed control is not present in the retrieved visible log. The merge counterpart also failed the same job step; it is not substituted for head evidence.
- **Priority service model, ARM head job 130596765035:** the original release/Host step returned controller exit 1 after successful preparation. Its inner receipt or assertion is not embedded. Later default-profile diagnostics and test-only panics belong to separate controls; they do not establish the initial failure cause. The three other service-model matrix jobs also failed that original step.
- **Priority history:** x64 head 130596765271 and x64 merge 130596764961 failed the 4105-block paid public full-sync step. ARM head and ARM merge history succeeded. This archive contains the exact job steps and generic exit-1 annotations; it does not invent an inner cause for x64.
- **Retained-pressure retrieval, job 130596764361:** the original action requested artifact 11531476198 from historical run 37730166589, observed zero artifacts, and failed the download. The observation establishes absence from that API response; it does not establish whether deletion or expiry caused it.
- **CodeQL export, job 130596762612:** the exporter reported `GitHub GET /pulls/908: HTTP 503; no fallback`, then exited 1. The separate exact-source CodeQL/SARIF retention workflow succeeded.
- **Owned cleanup macOS jobs 130596763175 and 130596763218:** both official annotations explicitly say a hosted runner did not acquire the job after multiple attempts. Capacity notices name macOS arm64 constraints. These jobs did not execute and are not PASS.
- **Baseline protocol-contract jobs 130613467779 and 130613468850:** both official annotations explicitly say the job exceeded its original 45m0s execution limit, then was cancelled. This differs from unallocated-runner cancellation. No deadline is changed by this observation.
- **Baseline cross-architecture native from-zero controls:** ARM 130613468335 and x64 130613469277 failed the native execution step with exit-1 annotations. No more specific inner cause is asserted here.

## Successful selected jobs and remaining work

The PQ network / rollback witness workflow completed with all 16 jobs successful, including head and prospective-merge x64/ARM native suites and its interoperability controls. CPQ1 complete content bindings had both native-component jobs successful. Chain Hepta had all six jobs successful; the original workspace test-profile CPU acceptance had all four jobs successful. These are API job observations; this archive does not infer the details of every embedded test from a job conclusion.

At the latest captured baseline job observation, runtime and quality Rust shards for head and prospective merge were still in progress. The baseline had 9 successful jobs, 4 failures, 2 cancellations, and 4 running jobs. Subsequent completions are outside this snapshot.

## Archive contents and retrieval integrity

`raw-response-manifest.json` lists every exact API payload or decoded complete workflow log, URL, observation time, byte count and SHA256. Large complete logs are retained as deterministic gzip files; the manifest records both decoded and gzip hashes. `summary.json` is derived from those exact payloads. Original early snapshots remain alongside the latest snapshots.

All 19 failed/cancelled jobs in the selected adverse workflows have complete official annotations: 19 pages, 44 annotations, all actual GET exit codes zero. The connector rejected the annotations endpoint, so the authorized read-only desktop batch used `gh api --hostname github.com --method GET` after the original preflight. The exact original collector stdin is retained as `annotations-collector.py`, with exact public GET/preflight arguments and original private-record SHA256 values in `annotations-collector-provenance.json`. The complete private transport request and launch nonce remain only in local v1 and are omitted here. The actual preflight record, individual raw API stdout/stderr and complete official-response wrappers are retained. The public terminal record copies the actual successful exit, timeout and durable-output facts without their private transport metadata. No rerun, cancellation, settings update or source edit was performed by this observation batch.

No failed or incomplete observation has been reclassified as successful. Whole-chain PQ, quantum PoN hardness, lifecycle failure bounds and production activation remain unqualified.

## Public carrier revision

This is pub-v2. Local v1 is preserved unchanged. Publication omits private H request/launch metadata and replaces the terminal wrapper with an explicit allowlist. All 46 declared official raw responses and all complete workflow-log bytes are unchanged; source identities and outcomes are unchanged. The package manifest and compressed readback are regenerated for this public carrier.
