from pathlib import Path
import subprocess,importlib.util,hashlib,json,difflib,sys
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/resume-20261120-e9e051/source');out=src.parent/'legacy-guard-diagnosis';out.mkdir(exist_ok=False)
(out/'owner.py').write_text(sys.argv[1]);path='trillionnium/crates/trnm-pon-node/src/store.rs'
spec=importlib.util.spec_from_file_location('legacy_controls',src/'scripts/ci/test_legacy_activation_tail_diagnostic.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
current=(src/path).read_text();p=subprocess.run(['git','show','333fe8cd89f0ec855e7b856e99e40f48f56c2137^:'+path],cwd=src,capture_output=True);(out/'parent-read.stderr').write_bytes(p.stderr);assert p.returncode==0
old=p.stdout.decode();(out/'current-store.rs').write_text(current);(out/'prior-store.rs').write_bytes(p.stdout)
diff=''.join(difflib.unified_diff(old.splitlines(True),current.splitlines(True),fromfile='333fe8-parent/store.rs',tofile='candidate/store.rs'));(out/'actual-store-change.patch').write_text(diff)
real=hashlib.sha256;captured=[]
def capture(data):captured.append(real(data).hexdigest());return real(data)
m.hashlib.sha256=capture
r={'schema':'legacy-control-source-identity-diagnosis-v1','original_guard_unchanged':True,'historical_base_digest':m.BASE[path],'current_source_sha256':real(current.encode()).hexdigest(),'prior_source_sha256':real(p.stdout).hexdigest(),'prior_original_control_passes':m.original(path,old),'current_original_control_passes':m.original(path,current),'erased_digests_in_call_order':captured,'source_revision':'333fe8cd89f0ec855e7b856e99e40f48f56c2137','qualification':False}
(out/'READOUT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True);print(diff,flush=True)
