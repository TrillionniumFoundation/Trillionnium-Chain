#!/usr/bin/env python3
"""Rebuild G0 production + identical v2 History controls and pool test hooks.

Read immutable Git blobs only. No worktree, compiler, native execution, policy
override, API stand-in or production budget modification is constructed here.
"""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import subprocess

G0 = 'd6bbac6baf9e5356721ab56f7432058d07b6b49b'
PARENT = 'db93026b9314bfd8bc4350945036998f1b7d34aa'
SRC = 'trillionnium/crates/trnm-pon-node/src/'
TEST = SRC + 'ingress/history_import_detached_budget_tests.rs'
PRODUCTION = ('ingress.rs', 'ingress/history_import.rs', 'mining.rs', 'store.rs')
COMPATIBLE_OLD_TEST = 'ingress/history_import_tests.rs'
PACKAGE = Path(__file__).resolve().parent
CUT = '''    // Test-only observation after all native CPU scopes have settled, before
    // an unclean last-epoch close deliberately fences this original account.
    #[cfg(all(test, target_os = "linux"))]
    cut("before_epoch_close");
'''
ANCHOR = '    let result = native(owner, &guard.cpu);\n'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    args = parser.parse_args()

    def git(*argv):
        return subprocess.check_output(['git', *argv], cwd=args.repo)

    hooks = json.loads((PACKAGE / 'pool-hooks.json').read_text())
    pin = json.loads((PACKAGE / 'test-pin.json').read_text())
    assert git('rev-parse', G0 + '^{tree}').decode().strip() == '653b1a8b483ccdbf69b272255ec0369d98296302'
    assert git('rev-parse', PARENT + '^{tree}').decode().strip() == '379f05bda52b20130e5d895788f0613aa680472c'
    rows = []
    patch = []
    for relative in (*PRODUCTION, COMPATIBLE_OLD_TEST):
        path = SRC + relative
        old = git('show', G0 + ':' + path)
        parent = git('show', PARENT + ':' + path)
        source = old.decode()
        edits = []
        if relative == 'ingress/history_import.rs':
            edits.append((ANCHOR, ANCHOR + CUT))
        edits.extend(tuple(pair) for pair in hooks.get(relative, []))
        for before, after in edits:
            assert source.count(before) == 1, (path, 'nonunique original hook anchor')
            source = source.replace(before, after)
        restored = source
        for before, after in reversed(edits):
            assert restored.count(after) == 1
            restored = restored.replace(after, before)
        assert restored.encode() == old, (path, 'production changed beyond test hooks')
        for directory, raw in (('g0-source', old), ('replacement-source', source.encode())):
            destination = PACKAGE / directory / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(raw)
        patch.append(f'diff --git a/{path} b/{path}\n')
        patch.extend(difflib.unified_diff(parent.decode().splitlines(True), source.splitlines(True),
                                         fromfile='a/' + path, tofile='b/' + path))
        rows.append(dict(path=path, g0_sha256=sha(old), parent_sha256=sha(parent),
                         replacement_sha256=sha(source.encode()), test_only_insertions=len(edits),
                         strip_test_insertions_restores_g0=True,
                         kind='production' if relative in PRODUCTION else 'old_api_compatible_existing_tests'))
    test = (PACKAGE / 'same-test' / TEST).read_bytes()
    assert sha(test) == pin['sha256']
    parent = git('show', PARENT + ':' + TEST)
    target = PACKAGE / 'replacement-source' / TEST
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(test)
    patch.append(f'diff --git a/{TEST} b/{TEST}\n')
    patch.extend(difflib.unified_diff(parent.decode().splitlines(True), test.decode().splitlines(True),
                                     fromfile='a/' + TEST, tofile='b/' + TEST))
    unchanged = []
    for relative in ('store/mempool.rs', 'error.rs', 'ingress/public_v3/scalar_cpu.rs',
                     'mining_prepare_control_tests.rs'):
        path = SRC + relative
        expected = git('show', G0 + ':' + path).decode()
        for before, after in hooks.get(relative, []):
            assert expected.count(before) == 1
            expected = expected.replace(before, after)
        parent = git('show', PARENT + ':' + path)
        assert expected.encode() == parent, (path, 'unexpected inherited production')
        unchanged.append(dict(path=path, parent_sha256=sha(parent),
                              g0_equivalent_after_original_pool_test_hooks=True))
    pool_test = SRC + 'pool_run_control_tests.rs'
    pool_raw = git('show', PARENT + ':' + pool_test)
    assert sha(pool_raw) == 'b87c45c0844e1788bb4683fe1a7f59e0c627bf88bfb3f12b61e92ece656ffb93'
    raw_patch = ''.join(patch).encode()
    (PACKAGE / 'from-pool-h0.patch').write_bytes(raw_patch)
    manifest = dict(schema='history-budget-before-v2-source-binding-v1',
                    g0=G0, parent_pool_h0=PARENT, replacement_files=rows,
                    common_history_test_sha256=sha(test),
                    inherited_pool_test_sha256=sha(pool_raw),
                    inherited_paths=unchanged,
                    patch_sha256=sha(raw_patch),
                    native_execution='NOT_RUN',
                    scopes=dict(budget_before='3 identical History + 4 identical mining tests',
                                pool_tests='inherited compile input only; not a budget-arm outcome',
                                scalar_handoff='new private API controls run on fixed source only'))
    (PACKAGE / 'binding.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
