from pathlib import Path
import hashlib,json,re,os,subprocess
out=Path("/workspace/scratch/df05fc75c9e2/chain-root-source-only-87bf6bb0-20261112")
original=out/"SOURCE_ONLY_REPORT.json"
report=json.loads(original.read_text())
original_sha=hashlib.sha256(original.read_bytes()).hexdigest()
for name,expected in [("source-integrity-negatives",43),("root-register-and-runner-controls",52)]:
    command=report["commands"][name]
    stdout=(out/(name+".stdout")).read_bytes()
    stderr=(out/(name+".stderr")).read_bytes()
    assert hashlib.sha256(stdout).hexdigest()==command["stdout_sha256"]
    assert hashlib.sha256(stderr).hexdigest()==command["stderr_sha256"]
    text=stderr.decode()
    totals=re.findall(r"^Ran ([0-9]+) tests? in [0-9.]+s$",text,re.M)
    methods=re.findall(r"^(test_[^\n]+) \.\.\. ok$",text,re.M)
    assert totals==[str(expected)],totals
    assert len(methods)==expected,(name,len(methods),expected)
    assert len(set(methods))==expected
    assert re.findall(r"^OK$",text,re.M)==["OK"]
    assert not re.search(r"^(FAIL|ERROR|FAILED|OK \(skipped=)",text,re.M)
    assert command["exit_code"]==0
    report["test_counts"][name]={"observed_counts":[expected],"expected":expected,"method_lines_passed":len(methods),"failures":0,"errors":0,"skipped":0,"summary_ok":True}
report["test_counts_exact"]=True
report["report_parser_correction"]={
    "original_report":str(original),
    "original_report_sha256":original_sha,
    "original_orchestrator_exit_code":1,
    "original_issue":"Scratch reporting harness escaped the digit regex twice; it returned no totals despite all underlying commands exiting zero.",
    "correction":"Independently re-read immutable original stderr, checked numeric totals with [0-9], exact successful unique method lines, OK summary, zero failure/error/skip, and original per-command SHA256.",
    "repository_source_changed":False,
    "tests_replayed":False,
}
assert report["source_identity_and_all_tracked_bytes_unchanged"] is True
assert report["all_exit_codes_zero"] is True
assert report["source_verification_before"]==report["source_verification_after"]
assert report["identity_after"]["porcelain"]==""
report["status"]="PASS_SOURCE_ONLY"
corrected=out/"SOURCE_ONLY_REPORT_CORRECTED.json"
with corrected.open("x") as f:
    json.dump(report,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
manifest=[]
for path in sorted(out.iterdir()):
    if path.is_file():
        b=path.read_bytes();manifest.append({"path":path.name,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()})
with (out/"ARTIFACT_MANIFEST.json").open("x") as f:
    json.dump({"files":manifest,"repository_source_mutated":False,"native_tests_executed":False},f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
print(json.dumps({"report":str(corrected),"sha256":hashlib.sha256(corrected.read_bytes()).hexdigest(),"original_report_sha256":original_sha,"command_count":len(report["commands"]),"test_counts":report["test_counts"],"source_identity_equal":report["source_identity_and_all_tracked_bytes_unchanged"],"identity":report["identity_after"],"repository":report["json_reports"]["repository-with-markdown-links"],"corpus":report["json_reports"]["pq-research-corpus"],"source_count":report["json_reports"]["root-dependency-register"]["source_file_count"]},indent=2))
