#!/usr/bin/env python3
"""Read retained public CI evidence; never execute artifacts or modify repository."""
import collections, datetime, hashlib, json, pathlib, re, subprocess, zipfile
ROOT=pathlib.Path('/workspace/scratch/pon-joint-58fd59-build/chain')
OUT=pathlib.Path(__file__).parent
BASE='e798d7125724d4b9f98c24d00cc80031f2eab4a9'
HEAD='11791e2da79b69322271be2cffe03725165151d1'
MERGE='b472c21f7b14ba27bb87d9d2f52d299365ed3145'
TREE='162552848110fda532504b78865a16930bc6d9bb'
ROSTER=[
(128954796906,13646503409,'head-protocol-contract-117-run42553751938.zip'),
(128954797047,13646038975,'merge-protocol-contract-b472-run42553751938.zip'),
(128954796911,13647015505,'head-external-evidence-117-run42553751938.zip'),
(128954797024,13646452916,'merge-external-evidence-b472-run42553751938.zip'),
(128954796813,13647040442,'cross-arch-cost-x64-117-run42553751938.zip'),
(128954796735,13646613359,'cross-arch-cost-arm64-117-run42553751938.zip')]
def dump(name,data):
 with (OUT/name).open('x',encoding='utf8') as f:json.dump(data,f,ensure_ascii=False,indent=2,sort_keys=True);f.write('\n')
def ident(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def load(name):return json.loads((OUT/name).read_bytes())
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def strip_log(text):
 text=re.sub(r'(?m)^\d{4}-\d\d-\d\dT\S+Z ','',text)
 return re.sub(r'\x1b\[[0-9;]*m','',text)
def source_receipts(text):
 decoder=json.JSONDecoder();found=[]
 for m in re.finditer(r'(?m)^\{',text):
  try:doc,_=decoder.raw_decode(text[m.start():])
  except ValueError:continue
  if isinstance(doc,dict) and doc.get('schema')=='trnm-ci-source-v1':found.append({'decoded_log_line':text.count('\n',0,m.start())+1,'identity':doc})
 return found
jobs_doc=load('jobs-api-initial.json');jobs={j['id']:j for j in jobs_doc['jobs']}
artifacts_doc=load('artifacts-api-initial.json');artifacts={a['id']:a for a in artifacts_doc['artifacts']}
run=load('run-api-initial.json')
summary={
'schema':'trnm-readonly-required-baseline-failure-readback-v1',
'written_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'repository':'TrillionniumFoundation/Trillionnium-Chain','pull_request':827,'run_id':42553751938,'run_attempt':1,
'implementation':HEAD,'base':BASE,'prospective_merge':MERGE,'tested_tree':TREE,
'method':'Read-only interpretation of complete retained connector-decoded job logs, exact original artifact ZIPs, and immutable local git blobs. No artifact commands or repository tests executed by this readback.',
'run_snapshot':{k:run.get(k) for k in ['id','name','status','conclusion','head_sha','created_at','updated_at','html_url']},
'snapshot_limits':{'overall_run_completion_claimed':False,'api_snapshots_are_atomic':False,'jobs_total_at_snapshot':jobs_doc['total_count'],'jobs_returned':len(jobs_doc['jobs']),'artifacts_total_at_snapshot':artifacts_doc['total_count'],'artifacts_returned':len(artifacts_doc['artifacts']),'selected_failed_jobs_retained':6,'complete_job_logs_retained':6,'selected_original_zips_retained':6,'other_artifacts_metadata_only':[a['id'] for a in artifacts_doc['artifacts'] if a['id'] not in {a for _,a,_ in ROSTER}],'note':'Selected jobs completed/failure; workflow metadata queued/null at this snapshot. Other jobs and later artifacts are outside this readback. Full run monitoring is separate.'},
'actions':{'repository_modified':False,'historical_pins_or_gates_changed':False,'ci_rerun_or_cancel_requested':False,'failure_reclassified_as_pass':False},'jobs':[]}
contexts=[]
for jid,aid,filename in ROSTER:
 job=jobs[jid];meta=artifacts[aid];data=(OUT/filename).read_bytes();h=ident(data)
 assert h['bytes']==meta['size_in_bytes'] and 'sha256:'+h['sha256']==meta['digest']
 logname=f'job-{jid}.decoded.log';logbytes=(OUT/logname).read_bytes();rawtext=logbytes.decode('utf8');text=strip_log(rawtext)
 item={'job':{k:job.get(k) for k in ['id','name','status','conclusion','started_at','completed_at','html_url','labels','runner_name']},'failed_steps':[s for s in job['steps'] if s['conclusion']=='failure'],'complete_decoded_log':{'file':logname,**ident(logbytes),'lines':len(rawtext.splitlines()),'scope':'Complete UTF-8 log string returned by GitHub connector; not original compressed log archive bytes.'},'original_artifact_zip':{'file':filename,'artifact_id':aid,'artifact_name':meta['name'],**h,'api_bytes_and_digest_match':True,'api_created_at':meta['created_at'],'api_expired':meta['expired']}}
 receipts=source_receipts(text);item['standalone_source_receipts_from_log']=receipts;item['standalone_source_before_after_match']=len(receipts)==2 and receipts[0]['identity']==receipts[1]['identity']
 with zipfile.ZipFile(OUT/filename) as z:
  item['original_artifact_zip']['entry_count']=len(z.infolist());item['original_artifact_zip']['uncompressed_bytes']=sum(i.file_size for i in z.infolist())
  source=json.loads(z.read('source.json'));item['artifact_source']=source
  assert source['tested_tree']==TREE and source['tested_commit'] in (HEAD,MERGE)
  if 'external-evidence' in filename:
   blocks=re.split(r'(?m)^(?=(?:FAIL|ERROR): )',text)[1:];rows=[]
   for b in blocks:
    detail=b.split('\n======================================================================')[0]
    rows.append({'kind':b.split(':',1)[0],'header':b.splitlines()[0],'contains_selected_modes_error':'durable backend selected modes' in detail,'contains_missing_source_needle':'source control must target exactly one occurrence' in detail})
   assert collections.Counter(r['kind'] for r in rows)=={'ERROR':22,'FAIL':84}
   assert sum(r['contains_selected_modes_error'] for r in rows)==101
   assert all(r['contains_selected_modes_error'] or r['contains_missing_source_needle'] for r in rows)
   item['failure_analysis']={'class':'inherited static source-contract and test-fixture mismatch','suite':'scripts/ci/test_public_readiness_evidence.py','reported_named_tests':71,'reported_failures':84,'reported_errors':22,'denominator_note':'Failures/errors include subtests; not 106 distinct named tests.','failure_or_error_blocks_with_selected_modes_error':101,'failure_blocks_with_missing_old_source_replacement_needle':5,'first_error':'ValueError: durable backend selected modes','expected_enum_field':'InitializeOrRecover { growth_observation_only: bool }','actual_enum_field':'InitializeOrRecover { observation_only: bool }','cause_boundary':'The exact-layout checker, its test fixtures, and the entire input store.rs have identical blobs in e798 and 117. This establishes an inherited static mismatch, not a fresh V4/History/Growth regression. The lane remains FAIL.','suite_summary_lines':[s for s in text.splitlines() if re.search(r'Ran \d+ tests|FAILED \(',s)],'failure_headers':rows,'artifact_limit':'External ZIP contains source.json only. Independent after-source identity is retained in the complete job log; before and after receipts match.'}
   lines=rawtext.splitlines();start=next(i for i,s in enumerate(lines) if 'ValueError: durable backend selected modes' in s)
   contexts.append({'job_id':jid,'start_line':max(0,start-15)+1,'end_line':start+1,'lines':lines[max(0,start-15):start+1]})
  else:
   m=json.loads(z.read('from-zero-native/manifest.json'));raw=z.read('from-zero-native/confirmation/report.json');report=json.loads(raw)
   controller=json.loads(z.read('from-zero-native-host/controller-result.json'));before=json.loads(z.read('from-zero-native-host/inside-before.json'));after=json.loads(z.read('from-zero-native-host/inside-after.json'))
   assert m['source_before']==m['source_after'] and m['failures']==['CONFIRMATION_TARGET'] and m['passed'] is False
   assert m['terminal']['native_execution_completed'] is True
   assert len(m['terminal']['native_invocations'])==5 and all(r['exit_code']==0 and r['timed_out'] is False for r in m['terminal']['native_invocations'])
   assert m['binary_sha256_before']==m['binary_sha256_after']
   observed=m['confirmation_observation'];assert ident(raw)['sha256']==observed['sha256'] and report['finite_target_met'] is False
   phases=[]
   for ph,rph in zip(observed['phases'],report['phases'],strict=True):
    b=ph['business'];keep=['required_signed_transactions','business_start_delay_ns','business_started_before_original_window_end','reported_independently_confirmed_in_window','unconfirmed','unknown','independent_confirmed_transactions_per_window_second','observed_success_latency_ns','unconfirmed_latency_lower_bound_ns','lower_bound_reaches_original_window_end','reported_finite_business_target_met']
    row={'mode':ph['mode'],'window_ns':ph['window_ns'],'business':{k:b[k] for k in keep},'signed_submit_ack':{k:ph['signed_submit_ack'][k] for k in ['attempts','successful_in_original_window','failed_or_late']},'history_response':{k:ph['history_response'][k] for k in ['attempts','successful_in_original_window','failed_or_late']},'independent_page_replay':{k:ph['independent_page_replay'][k] for k in ['attempts','accepted_in_original_window','failed_or_late']},'verification_errors':ph['verification_errors'],'independent_final_confirmation_stage':rph.get('independent_final_confirmation_stage')}
    final=rph['independent_history_page_replay'][-1];row['last_independent_replay']={k:final[k] for k in ['history_call_index','replay_started_ns','replay_ended_ns','replay_wall_ns','replay_thread_cpu_ns','replay_accepted','replay_error']}
    if final.get('native_import_observation'):row['last_native_import_phase']=[p for p in final['native_import_observation']['phases'] if p['phase']=='history_import']
    phases.append(row)
   assert [(p['business']['reported_independently_confirmed_in_window'],p['business']['required_signed_transactions']) for p in phases]==[(1,1),(0,1)]
   retained=[]
   for name,stage in m['terminal']['acceptance_stages'].items():
    entry='from-zero-native/'+stage['path'];actual=ident(z.read(entry))
    assert actual['bytes']==stage['retained_report']['bytes'] and actual['sha256']==stage['retained_report']['sha256']
    retained.append({'stage':name,'zip_entry':entry,**actual,'matches_manifest_retained_and_before_validation':stage['retained_matches_before_validation']})
   item['failure_analysis']={'class':'actual original-resource finite-business acceptance failure','manifest_entry':'from-zero-native/manifest.json','source_before':m['source_before'],'source_after':m['source_after'],'full_source_before_after_match':True,'source_recompiled':m['source_recompiled'],'format_passed':m['format_passed'],'all_named_tests_passed':m['all_named_tests_passed'],'passed':m['passed'],'execution_finished':m['execution_finished'],'failures':m['failures'],'terminal':m['terminal'],'binary_sha256_before':m['binary_sha256_before'],'binary_sha256_after':m['binary_sha256_after'],'binary_before_after_match':True,'report_entry_identities':retained,'build':m['build'],'native_build_preparation_completed':controller['preparation']['completed'],'native_build_preparation_process':controller['preparation']['process'],'systemd_run_exit':controller['systemd_run_exit'],'controller_failure':controller['failure'],'final_host_errors':controller['final_host_errors'],'original_host_limits':controller['parent_lease']['parent_identity']['limits'],'inside_before_counters':before['counters'],'inside_after_counters':after['counters'],'confirmation_observation':{k:observed[k] for k in ['schema','original_gate_validated','original_gate_validation_error','simulated_control','scope','network_capacity_qualified','tail_latency_qualified','production_activation']},'raw_report_flags':{k:report[k] for k in ['finite_target_met','invariant_target_met','same_packet_sequence_in_both_runs','public_network_ready','work_profile_qualified','production_activation','strongest_honest_producer_used']},'raw_report_scope':report['scope'],'phases':phases,'qualification_flags':{k:m[k] for k in ['independent_wan_accepted','work_hardness_accepted','production_activation']},'cause_boundary':'117 fails the original four-second business gate under the original Host contract. Native process completion, invariant test success, successful Submit ACKs, and prior service reports do not grant confirmation credit. This readback establishes neither old/new performance equivalence nor causal attribution to one source change.','observation_boundary':'Phase values come from retained native reports and existing diagnostic observation. The original confirmation validator rejects at CONFIRMATION_TARGET. No independent validation of every downstream confirmation condition is claimed.'}
   contexts.append({'job_id':jid,'retained_failure_manifest':filename+'!from-zero-native/manifest.json','failure':'CONFIRMATION_TARGET'})
 summary['jobs'].append(item)
comparisons=[]
for path in ['scripts/ci/check_public_readiness_evidence.py','scripts/ci/test_public_readiness_evidence.py','trillionnium/crates/trnm-pon-node/src/store.rs','scripts/ci/run_from_zero_native.py','scripts/ci/run_from_zero_host.py','trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero.rs']:
 versions=[]
 for ref in [BASE,HEAD]:versions.append({'commit':ref,'blob':git('rev-parse',ref+':'+path).decode().strip(),**ident(git('show',ref+':'+path))})
 comparisons.append({'path':path,'versions':versions,'same_bytes':versions[0]['sha256']==versions[1]['sha256']})
summary['immutable_blob_comparisons']=comparisons
summary['current_diff_paths']=git('diff','--name-only',BASE,HEAD).decode().splitlines()
summary['source_readback']={'public_growth':'Actual fixture constructs ordinary Node::open receivers and submits Request::Submit; public_v3 dispatch routes only GrowthSubmitV1/GrowthPacketStatusV1/GrowthHeadV1 to growth::dispatch. Changed Growth submit_result is not exercised by this confirmation fixture.','v4_example':'ci_job.sh uses set -euo pipefail. New pon_w1_lifecycle_cost_v4 example test is immediately after run_from_zero_host.py in the protocol lane. The earlier command fails, so V4 execution is not reached in these protocol jobs.','history':'Fixture calls receive_public_page_from_before_observed with original absolute deadline. ingress.rs supplies history_import::Control with a real Host verify resource callback. Modified Control::check is on the actual replay path; this readback cannot exclude its effect on deadline outcome or timing.','static_vs_dynamic':'Identical static checker/input blobs establish inherited source-layout mismatch. Identical native fixture/driver blobs do not establish runtime equivalence or inherited deadline results.','error_interpretation':'PUBLIC_REQUEST_DEADLINE in three replay outcomes is a local deadline return, not evidence of invalid proof or state corruption. Arm64 has no replay verification error; final History request failed or returned late before full independent confirmation.'}
summary['source_locations_at_implementation']={'external_guard':'scripts/ci/check_public_readiness_evidence.py:427','actual_enum':'trillionnium/crates/trnm-pon-node/src/store.rs:1375','external_fixture_setup':'scripts/ci/test_public_readiness_evidence.py:538','protocol_lane_sequence':'scripts/ci/ci_job.sh:147-155','original_confirmation_guard':'scripts/ci/run_from_zero_native.py:759','ordinary_native_fixture':'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero.rs:1285-1286','fixture_import':'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero.rs:1447-1461','history_resource_callback':'trillionnium/crates/trnm-pon-node/src/ingress.rs:2597-2614','history_recheck':'trillionnium/crates/trnm-pon-node/src/ingress/history_import.rs:30-36','growth_dispatch_selection':'trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs:1952-1969'}
dump('failed-step-contexts.json',contexts);dump('failure-readback-summary.json',summary)
manifest=[{'file':p.name,**ident(p.read_bytes())} for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='retained-file-manifest.json']
dump('retained-file-manifest.json',{'schema':'retained-ci-readback-file-manifest-v1','excludes_self':True,'files':manifest})
print(json.dumps({'summary':str(OUT/'failure-readback-summary.json'),'summary_identity':ident((OUT/'failure-readback-summary.json').read_bytes()),'manifest_file_count':len(manifest),'selected_jobs':len(summary['jobs']),'all_api_zip_digests_match':all(j['original_artifact_zip']['api_bytes_and_digest_match'] for j in summary['jobs'])},indent=2))
