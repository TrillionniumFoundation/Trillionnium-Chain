#!/usr/bin/env python3
"""Archive fixed, closed C3 qualification observations; never execute experiments."""
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import time

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
OUT = Path(__file__).resolve().parent
HEAD = 'abab79dac0cb89eb2753d3f579119ac135650eb5'
TREE = '194808f4a0db5d642aa746beb251ca9e9532cebb'
QSHA = '2fbd82253b5610cf08afeaa3dfb6e36cbb2d183f8b6c5b564baba655e365d99f'
DIRECTORIES = [
    'backend-validation/exact-source-abab79dac0cb-02',
    'clean-exact-native-verifier-abab79dac0cb-02',
    'clean-C3-build-qualification-01',
    'integration-validation/exact-c3-publication-01',
    'exact-source-cache-setups/backend-abab79dac0cb-01',
    'exact-source-cache-setups/native-abab79dac0cb-01',
    'exact-source-cache-setups/backend-abab79dac0cb-02',
    'exact-source-cache-setups/native-abab79dac0cb-02',
    'exact-C2-cache-qualification-tools-abab79dac0cb-02',
    'exact-source-qualification-tools-0f18f93f2d35-01',
    'integration-validation/c3-publication-freeze-01',
    'integration-validation/c3-map-f37-set-diagnosis-01',
    'integration-validation/c3-publication-freeze-02',
    'integration-validation/c3-publication-map-adapter-01',
    'integration-validation/c3-publication-map-adapter-02',
    'c3-aggregate-timeout-diagnosis-01',
    'c3-aggregate-timeout-diagnosis-02',
    'c3-aggregate-timeout-diagnosis-03',
]


SKIP_DIRECTORY_NAMES = {'__pycache__', 'target', '.git', '.ssh', '.aws', '.config', 'node_modules', 'private-analysis-only'}
SKIP_SUFFIXES = ('.pyc', '.pyo', '.db', '.sqlite', '.sqlite3', '.db-wal', '.db-shm',
                 '.sqlite-wal', '.sqlite-shm', '.sqlite3-wal', '.sqlite3-shm', '.pem', '.key', '.p12', '.pfx')
SKIP_NAMES = {'credentials', 'credentials.json', 'kaggle.json', 'id_rsa', 'id_ed25519', 'id_ecdsa', '.env'}
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_TOTAL_BYTES = 256 * 1024 * 1024


def require(ok, message):
    if not ok:
        raise ValueError(message)


def stamp(st):
    return (st.st_dev, st.st_ino, st.st_size, st.st_mode, st.st_mtime_ns, st.st_ctime_ns)


def pin(path):
    p = Path(path)
    before = p.lstat()
    require(stat.S_ISREG(before.st_mode), 'ordinary file required: ' + str(p))
    digest = hashlib.sha256()
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        require(stamp(os.fstat(stream.fileno())) == stamp(before), 'file replaced before reading')
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
        require(stamp(os.fstat(stream.fileno())) == stamp(before), 'file changed during reading')
    require(stamp(p.lstat()) == stamp(before), 'file replaced after reading')
    return {'path': str(p), 'bytes': before.st_size, 'sha256': digest.hexdigest()}


def check(record):
    observed = pin(record['path'])
    require(observed['sha256'] == record['sha256'] and
            ('bytes' not in record or observed['bytes'] == record['bytes']), 'original retained pin changed')
    return observed


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    return pin(path)


def check_ancestors(path):
    p = Path(path)
    require(p.is_absolute() and ROOT == p or ROOT in p.parents, 'input outside task ROOT')
    for directory in [ROOT, *reversed(p.parents[:len(p.parents) - len(ROOT.parents) - 1])]:
        require(not directory.is_symlink(), 'symlink input ancestor')
    require(not p.is_symlink(), 'symlink input root')


class HashReader:
    def __init__(self, stream):
        self.stream = stream
        self.digest = hashlib.sha256()
        self.count = 0

    def read(self, size=-1):
        data = self.stream.read(size)
        self.digest.update(data)
        self.count += len(data)
        return data


def main():
    os.sched_setaffinity(0, {12, 13})
    result = {'schema': 'TRNM-W1-C3-QUALIFICATION-ARCHIVE-READBACK1',
              'source_commit': HEAD, 'source_tree': TREE, 'completed': False,
              'fresh_proof_generations': 0, 'errors': [], 'started_monotonic_ns': time.monotonic_ns()}
    try:
        qpath = ROOT / 'clean-C3-build-qualification-01/qualification.json'
        qpin = check({'path': str(qpath), 'sha256': QSHA})
        q = json.loads(qpath.read_bytes())
        require(q['source_commit'] == HEAD and q['source_tree'] == TREE and q['qualification_complete'] is True,
                'exact completed qualification required')
        require(q['native_current_roster']['native_wrapper_passed'] is True
                and q['original_C2_binaries_preservation']['all_five_pins_unchanged'] is True
                and q['historical_C1_C1b_current_binary_reverification']['all_five_pins_unchanged'] is None,
                'current C3 success and C2 preservation must not imply old C1/C1b current availability')
        roots = [(relative, ROOT / relative) for relative in DIRECTORIES]
        roots += [('transport-originals', OUT / 'transport-originals'),
                  ('packaging/archive_closed_c3.py', Path(__file__).resolve())]
        def add_root(alias, path):
            if not any(path == existing or existing in path.parents for _, existing in roots):
                roots.append((alias, path))
        owner = json.loads(Path(q['gate_manifests']['owner']['path']).read_bytes())
        ci = json.loads(Path(q['gate_manifests']['ci']['path']).read_bytes())
        backend = json.loads(Path(q['gate_manifests']['backend']['path']).read_bytes())
        native = json.loads(Path(q['gate_manifests']['native']['path']).read_bytes())
        owner_cache = q['target_observations']['owner']['copied_cache_setup']['observation']
        for record, alias in ((owner['wrapper'], 'wrappers/owner.py'),
                              (owner_cache['adapter'], 'wrappers/owner-cache-adapter.py'),
                              (ci['runner'], 'wrappers/ci.py'),
                              (ci['declaration'], 'wrappers/ci-declaration.json'),
                              (q['native_current_roster']['roster'], 'historical-C1/fixed-expected-native-roster.json'),
                              (q['historical_qualification_records']['C1'], 'historical-C1/qualification.json'),
                              (q['historical_qualification_records']['C1b'], 'historical-C1b/qualification.json'),
                              (q['original_C2_binaries_preservation']['raw_original_qualification'], 'historical-C2/qualification.json')):
            check(record)
            add_root(alias, Path(record['path']))
        previous_archive = check({'path': str(ROOT / 'publication-evidence-C2-01/qualification-raw.tar.gz'),
            'bytes': 3495706, 'sha256': 'c0cbda739add31b6bc887887833990038bcf0414c4e6bf93dc79f0cfdb38113c'})
        for filename, digest, alias in (
            ('qualification-raw-index.json', '0cde93ffc1832e73ac4ef8070273128e7c8e2cc0ade43cf670f4ad850ead4b91', 'historical-C2/archive-index.json'),
            ('archive-readback.json', '188b36708746f01c783291b74026f579fae4d28832d7458b5f191edefeef3963', 'historical-C2/archive-readback.json')):
            source = ROOT / 'publication-evidence-C2-01' / filename
            check({'path': str(source), 'sha256': digest})
            add_root(alias, source)
        for name in ('backend', 'native', 'owner', 'ci', 'publication_map'):
            check(q['gate_manifests'][name])
        env_path = ROOT / 'setup-evidence/native-openssl-provider-01/exported.env'
        check({'path': str(env_path), 'sha256': '378c4c53a9442613075fde8c5750166d13e1699777cc222128354efcb6b9ff86'})
        add_root('openssl-provider/exported.env', env_path)
        archive_path = OUT / 'qualification-raw.tar.gz'
        index_path = OUT / 'qualification-raw-index.json'
        require(not archive_path.exists() and not index_path.exists(), 'refuse overwrite')
        entries, excluded, aliases, originals, directories = [], [], set(), set(), []

        def visit(path, alias):
            require(str(PurePosixPath(alias)) == alias and not alias.startswith('/') and
                    '..' not in PurePosixPath(alias).parts, 'unsafe logical member')
            st = path.lstat()
            require(not stat.S_ISLNK(st.st_mode), 'symlink rejected: ' + str(path))
            if stat.S_ISDIR(st.st_mode):
                if path.name in SKIP_DIRECTORY_NAMES or path.name.startswith('target-'):
                    excluded.append({'path': str(path), 'reason': 'explicit cache/target/account directory exclusion'})
                    return
                directories.append((path, stamp(st)))
                with os.scandir(path) as scan:
                    children = sorted(scan, key=lambda row: row.name)
                for child in children:
                    visit(Path(child.path), alias + '/' + child.name)
                return
            require(stat.S_ISREG(st.st_mode), 'non-ordinary member rejected: ' + str(path))
            if path.name in SKIP_NAMES or path.name.endswith(SKIP_SUFFIXES):
                excluded.append({'path': str(path), 'reason': 'explicit DB/key/credential/cache filename exclusion'})
                return
            require(st.st_size <= MAX_FILE_BYTES, 'unexpected large member requires explicit review: ' + str(path))
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(fd, 'rb') as stream:
                prefix = stream.read(4096)
            if prefix[:4] == b'\x7fELF':
                excluded.append({'path': str(path), 'reason': 'executable ELF excluded; only its pin is published'})
                return
            require(re.search(rb'-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----', prefix) is None,
                    'private-key material rejected')
            require(alias not in aliases and str(path) not in originals, 'duplicate member or raw input')
            aliases.add(alias); originals.add(str(path))
            raw = pin(path)
            require(stamp(path.lstat()) == stamp(st), 'file changed during inventory')
            entries.append({'member': alias, 'original_absolute_path': str(path), 'size': raw['bytes'],
                            'sha256': raw['sha256'], 'original_mode': stat.S_IMODE(st.st_mode),
                            'archive_mode': stat.S_IMODE(st.st_mode),
                            'observed_stat': {'device': st.st_dev, 'inode': st.st_ino,
                                              'mtime_ns': st.st_mtime_ns, 'ctime_ns': st.st_ctime_ns},
                            '_stamp': stamp(st)})

        for alias, path in roots:
            check_ancestors(path)
            if path.is_dir():
                require(path != OUT and path not in archive_path.parents and path not in index_path.parents,
                        'archive output is inside an input root')
            else:
                require(path not in (archive_path, index_path), 'archive self-input rejected')
            visit(path, alias)
        entries.sort(key=lambda row: row['member'])
        total = sum(row['size'] for row in entries)
        require(total <= MAX_TOTAL_BYTES, 'unexpected total archive size requires review')
        inventory = {'schema': 'TRNM-W1-C3-CLOSED-RAW-INVENTORY1', 'source_commit': HEAD, 'source_tree': TREE,
                     'qualification': qpin, 'inputs': [{'logical_prefix': alias, 'path': str(path)} for alias, path in roots],
                     'members': [{k: v for k, v in row.items() if k != '_stamp'} for row in entries],
                     'excluded': excluded, 'uncompressed_bytes': total, 'member_count': len(entries),
                     'no_active_experiment_or_target_tree_selected': True,
                     'historical_C2_archive': previous_archive,
                     'historical_C1_failed_native_and_inspection01_remain_in_prior_archives': True,
                     'current_C3_four_wrappers_all_succeeded': True,
                     'current_failed_cache_and_map_preparation_roots_retained': True,
                     'missing_C1_C1b_current_binary_preservation_not_claimed': True,
                     'root_separately_archived_merge_materialization_not_duplicated': True}

        inventory_pin = save(OUT / 'inventory.json', inventory)
        with archive_path.open('xb') as raw_out:
            with gzip.GzipFile(filename='', fileobj=raw_out, mode='wb', compresslevel=6, mtime=0) as zipped:
                with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                    for row in entries:
                        path = Path(row['original_absolute_path'])
                        require(stamp(path.lstat()) == tuple(row['_stamp']), 'input changed before archive read')
                        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
                        with os.fdopen(fd, 'rb') as stream:
                            require(stamp(os.fstat(stream.fileno())) == tuple(row['_stamp']), 'input replaced')
                            reader = HashReader(stream)
                            info = tarfile.TarInfo(row['member'])
                            info.size = row['size']; info.mode = row['archive_mode']
                            info.uid = info.gid = info.mtime = 0
                            info.uname = info.gname = ''
                            info.type = tarfile.REGTYPE
                            tar.addfile(info, reader)
                            require(reader.count == row['size'] and reader.digest.hexdigest() == row['sha256'],
                                    'member bytes changed while archiving')
                            require(stamp(os.fstat(stream.fileno())) == tuple(row['_stamp']), 'input changed during tar read')
                        require(stamp(path.lstat()) == tuple(row['_stamp']), 'input changed after tar read')
            raw_out.flush(); os.fsync(raw_out.fileno())
        archive_pin = pin(archive_path)
        expected = {row['member']: row for row in entries}
        actual_names = []
        with tarfile.open(archive_path, 'r:gz') as tar:
            for member in tar:
                require(member.isfile() and member.name in expected and member.name not in actual_names,
                        'unexpected, duplicate or non-ordinary archive member')
                row = expected[member.name]
                require(member.size == row['size'] and member.mode == row['archive_mode'] and
                        member.uid == member.gid == member.mtime == 0 and member.uname == member.gname == '',
                        'archive member metadata mismatch')
                digest = hashlib.sha256()
                with tar.extractfile(member) as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b''):
                        digest.update(block)
                require(digest.hexdigest() == row['sha256'], 'archive member hash mismatch')
                actual_names.append(member.name)
        require(actual_names == [row['member'] for row in entries], 'member set or order mismatch')
        for row in entries:
            path = Path(row['original_absolute_path'])
            require(stamp(path.lstat()) == tuple(row['_stamp']) and pin(path)['sha256'] == row['sha256'],
                    'original changed after archive completion')
        for path, before in directories:
            require(stamp(path.lstat()) == before, 'input directory entries changed while archiving')
        index = {'schema': 'TRNM-W1-C3-RAW-ARCHIVE-INDEX1', 'source_commit': HEAD, 'source_tree': TREE,
                 'archive': archive_pin, 'inventory': inventory_pin, 'member_count': len(entries),
                 'uncompressed_bytes': total, 'members': inventory['members'], 'excluded': excluded,
                 'compression': {'format': 'gzip', 'mtime': 0, 'filename': '', 'level': 6},
                 'tar': {'format': 'PAX', 'uid': 0, 'gid': 0, 'mtime': 0},
                 'all_members_read_back_and_hashed': True, 'all_originals_unchanged_after': True,
                 'historical_C2_archive': previous_archive}
        index_pin = save(index_path, index)
        fd = os.open(OUT, os.O_RDONLY | os.O_DIRECTORY)
        os.fsync(fd); os.close(fd)
        result.update(completed=True, archive=archive_pin, index=index_pin, inventory=inventory_pin,
                      member_count=len(entries), uncompressed_bytes=total, excluded_count=len(excluded),
                      all_members_read_back_and_hashed=True, all_originals_unchanged_after=True,
                      historical_C2_archive=previous_archive)
    except BaseException as exc:
        result['errors'].append({'type': type(exc).__name__, 'message': str(exc)})
    result['finished_monotonic_ns'] = time.monotonic_ns()
    receipt = save(OUT / 'archive-readback.json', result)
    print(json.dumps({'completed': result['completed'], 'result': receipt,
                      'archive': result.get('archive'), 'index': result.get('index'),
                      'member_count': result.get('member_count'), 'uncompressed_bytes': result.get('uncompressed_bytes'),
                      'errors': result['errors']}), flush=True)
    return 0 if result['completed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
