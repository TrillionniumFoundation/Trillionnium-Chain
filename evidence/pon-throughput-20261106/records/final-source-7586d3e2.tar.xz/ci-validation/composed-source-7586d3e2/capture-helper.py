#!/usr/bin/env python3
"""Run the existing 80 semantic selectors from real Node/M06 library ELFs.

This file performs no build. It extracts the repository workflow's original
registry builder, runs each selected libtest name once, and uses the original
check_required_native_test.py. Actual build profiles/features are recorded;
release/default-feature results do not qualify the original test-profile CPU
lane, PQ, public Host service, or production throughput.

Public helpers are also used by the separate PQ runner. All paths passed to
run_capture are explicit; no shell, filter retry, timeout, or ignored-test flag
is added. Combined logs retain collector-observed chunk order; separate stdout
and stderr plus stream offsets retain the exact bytes of each original stream.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import stat
import subprocess
import sys
import time
import traceback

DEFAULT_REMOTE_ROOT = Path('/home/qian-qi/work/chain-throughput-20261106-1eed')
WORKFLOW = '.github/workflows/pon-original-workspace-large-state-cpu.yml'
EXPECTED_BUILDER_SHA256 = 'bcf96e670c5e642eed70bd5a7431348a2623a19a8a810c647a3f32dea8ed20b2'
EXPECTED_SELECTOR_COUNT = 80
SQLITE_FENCE = 'sqlite-3.51.3-normal-native-linux-layout-v3'
SQLITE_AMALGAMATION_SHA256 = '9512509b1bccb7461f79bea8aad6280ae4699e925fa4804381b71f59e7efb0c5'
TARGETS = {
    'node': ('trnm-pon-node', 'trnm_pon_node'),
    'm06': ('trnm-mvcc-fee', 'trnm_mvcc_fee'),
}
ENV_KEYS = (
    'CI', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_INCREMENTAL',
    'CARGO_BUILD_JOBS', 'RUST_TEST_THREADS', 'RUSTFLAGS',
    'CARGO_ENCODED_RUSTFLAGS', 'RUSTC', 'RUSTDOC', 'RUSTC_WRAPPER',
    'RUSTC_WORKSPACE_WRAPPER', 'LD_LIBRARY_PATH', 'OPENSSL_DIR',
    'OPENSSL_STATIC', 'OPENSSL_CONF', 'OPENSSL_MODULES',
    'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256', 'TRNM_PQ_OPENSSL_VERSION',
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, value: object) -> None:
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2)
        stream.write('\n')


def fingerprint(info: os.stat_result) -> tuple[int, ...]:
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def sha256_file(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def file_receipt(path: Path) -> dict:
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), f'not a regular non-symlink file: {path}')
    with path.open('rb') as stream:
        require(fingerprint(os.fstat(stream.fileno())) == fingerprint(before),
                f'file replaced before hashing: {path}')
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        require(fingerprint(os.fstat(stream.fileno())) == fingerprint(before),
                f'file changed while hashing: {path}')
    require(fingerprint(path.lstat()) == fingerprint(before),
            f'file path changed while hashing: {path}')
    return {'path': str(path), 'sha256': digest, 'size': before.st_size,
            'fingerprint': list(fingerprint(before))}


def snapshot_file(source: Path, destination: Path) -> dict:
    before = file_receipt(source)
    require(not destination.exists(), f'receipt already exists: {destination}')
    shutil.copyfile(source, destination)
    after = file_receipt(source)
    copied = file_receipt(destination)
    require(before == after and copied['sha256'] == before['sha256'],
            f'input changed while copying: {source}')
    return {'input': before, 'copy': copied}


def run_capture(argv: list[str], cwd: Path, env: dict[str, str], prefix: Path,
                time_output: Path | None = None) -> dict:
    """Execute one command once, preserving both streams and collector errors.

    native_exit is subprocess's terminal status (GNU time forwards the child
    status when time_output is used). A spawn failure has native_exit=None,
    never an invented success. No source file or test result is rewritten.
    """
    prefix.parent.mkdir(parents=True, exist_ok=True)
    paths = {key: Path(str(prefix) + suffix) for key, suffix in (
        ('stdout', '.stdout'), ('stderr', '.stderr'), ('log', '.log'),
        ('events', '.streams.jsonl'), ('command', '.command.json'),
        ('result', '.result.json'),
    )}
    command = list(map(str, argv))
    if time_output is not None:
        require(not time_output.exists(), f'resource receipt already exists: {time_output}')
        command = ['/usr/bin/time', '-v', '-o', str(time_output), *command]
    started = utc_now()
    started_ns = time.monotonic_ns()
    write_json(paths['command'], {
        'argv': command, 'native_argv': list(map(str, argv)), 'cwd': str(cwd),
        'started_utc': started, 'stdin': '/dev/null',
        'environment': {key: env.get(key) for key in ENV_KEYS},
        'combined_log_order': 'collector-observed chunk order; per-stream raw bytes retained',
    })
    handles = {key: paths[key].open('xb') for key in ('stdout', 'stderr', 'log', 'events')}
    errors: dict[str, str] = {}
    offsets = {'stdout': 0, 'stderr': 0, 'log': 0}
    native_exit = None
    spawn_error = None
    pid = None

    def write(key: str, data: bytes) -> None:
        if key not in errors:
            try:
                handles[key].write(data)
                handles[key].flush()
            except OSError as error:
                errors[key] = repr(error)

    try:
        try:
            process = subprocess.Popen(command, cwd=cwd, env=env,
                                       stdin=subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except OSError as error:
            spawn_error = repr(error)
        else:
            pid = process.pid
            with selectors.DefaultSelector() as observed:
                for name, pipe in (('stdout', process.stdout), ('stderr', process.stderr)):
                    assert pipe is not None
                    os.set_blocking(pipe.fileno(), False)
                    observed.register(pipe, selectors.EVENT_READ, name)
                while observed.get_map():
                    for key, _event in observed.select():
                        try:
                            data = os.read(key.fileobj.fileno(), 65536)
                        except BlockingIOError:
                            continue
                        if not data:
                            observed.unregister(key.fileobj)
                            key.fileobj.close()
                            continue
                        name = key.data
                        event = {'stream': name, 'stream_offset': offsets[name],
                                 'combined_offset': offsets['log'], 'bytes': len(data),
                                 'monotonic_ns': time.monotonic_ns()}
                        write(name, data)
                        write('log', data)
                        write('events', (json.dumps(event, sort_keys=True) + '\n').encode())
                        offsets[name] += len(data)
                        offsets['log'] += len(data)
            native_exit = process.wait()
    finally:
        for name, handle in handles.items():
            try:
                handle.close()
            except OSError as error:
                errors[name] = repr(error)
    result = {
        'argv': command, 'native_argv': list(map(str, argv)), 'cwd': str(cwd),
        'started_utc': started, 'finished_utc': utc_now(),
        'wall_ns': time.monotonic_ns() - started_ns, 'pid': pid,
        'native_exit': native_exit, 'log_exit': int(bool(errors)),
        'spawn_error': spawn_error, 'capture_errors': errors,
        'observed_stream_bytes': offsets,
        'stdout_path': str(paths['stdout']), 'stderr_path': str(paths['stderr']),
        'log_path': str(paths['log']), 'events_path': str(paths['events']),
        'command_path': str(paths['command']),
        'resources_path': str(time_output) if time_output else None,
    }
    write_json(paths['result'], result)
    return result


def capture_passed(result: dict) -> bool:
    return result['native_exit'] == 0 and result['log_exit'] == 0 and result['spawn_error'] is None


def extract_heredoc(workflow: Path, delimiter: str, marker: str | None = None) -> str:
    """Extract literal Python from one actual workflow step without YAML rewriting."""
    lines = workflow.read_text(encoding='utf-8').splitlines()
    if marker is not None:
        located = [index for index, line in enumerate(lines) if marker in line]
        require(len(located) == 1, f'workflow marker not unique: {marker}')
        first = located[0]
        indent = re.match(r'^( *)- name:', lines[first])
        require(indent is not None, 'marker must identify one workflow step name')
        boundary = re.compile(r'^' + re.escape(indent[1]) + r'- (?:name|id):')
        last = next((index for index in range(first + 1, len(lines))
                     if boundary.match(lines[index])), len(lines))
        lines = lines[first:last]
    token = "<<'" + delimiter + "'"
    starts = [index for index, line in enumerate(lines) if token in line]
    require(len(starts) == 1, f'workflow heredoc not unique: {delimiter}')
    start = starts[0]
    indentation = re.match(r'^ *', lines[start])[0]
    end = next((index for index in range(start + 1, len(lines))
                if lines[index] == indentation + delimiter), None)
    require(end is not None, f'unterminated workflow heredoc: {delimiter}')
    body = []
    for line in lines[start + 1:end]:
        require(not line or line.startswith(indentation), 'unexpected heredoc indentation')
        body.append(line[len(indentation):] if line else '')
    return '\n'.join(body) + '\n'


def source_checkpoint(repo: Path, expected_head: str, out: Path, label: str,
                      env: dict[str, str]) -> dict:
    receipt = out / f'{label}.json'
    execution = run_capture([
        sys.executable, str(repo / 'scripts/ci/verify_ci_source.py'),
        '--kind', 'head', '--expected-head', expected_head, '--output', str(receipt),
    ], repo, env, out / label)
    result = {'execution': execution, 'receipt': None, 'passed': False}
    if capture_passed(execution):
        value = json.loads(receipt.read_text())
        result['receipt'] = value
        result['passed'] = (value.get('tested_commit') == expected_head
                            and value.get('tracked_worktree_verified') is True)
    return result


def load_build_artifacts(repo: Path, build_jsonl: Path, build_stderr: Path,
                         out: Path, targets: dict[str, tuple[str, str]], *,
                         build_receipt: Path | None = None) -> dict:
    """Bind unique actual library test ELFs and the same build's SQLite witness."""
    inputs = out / 'build-inputs'
    inputs.mkdir()
    build_log = snapshot_file(build_jsonl, inputs / 'build.jsonl')
    stderr_log = snapshot_file(build_stderr, inputs / 'build.stderr')
    external_build = None
    if build_receipt is not None:
        copied = snapshot_file(build_receipt, inputs / 'build-process-receipt.json')
        external_build = {
            'files': copied,
            'receipt': json.loads((inputs / 'build-process-receipt.json').read_text()),
            'scope': 'retained external build command/exit/source binding; not an '
                     'independently reconstructed historical source verification',
        }
    rows = [json.loads(line) for line in (inputs / 'build.jsonl').read_text().splitlines()
            if line.strip()]
    finished = [row for row in rows if row.get('reason') == 'build-finished']
    require(len(finished) == 1 and finished[0].get('success') is True,
            'build JSONL must contain exactly one successful build-finished')
    require('UNQUALIFIED' not in (inputs / 'build.stderr').read_text(errors='replace'),
            'build stderr contains UNQUALIFIED; do not execute qualified controls')
    artifacts = {}
    for key, (crate, target) in targets.items():
        selected = [row for row in rows if row.get('reason') == 'compiler-artifact'
                    and row.get('target', {}).get('name') == target
                    and row.get('target', {}).get('kind') == ['lib']
                    and row.get('profile', {}).get('test') is True
                    and row.get('executable')]
        require(len(selected) == 1, f'expected one actual {crate} library test ELF')
        artifact = selected[0]
        cwd = repo / 'trillionnium/crates' / crate
        require(Path(artifact['target']['src_path']).resolve(strict=True) == cwd / 'src/lib.rs',
                f'{crate} build src_path does not belong to this exact checkout')
        binary = Path(artifact['executable'])
        require(binary.is_absolute(), f'ELF path must be absolute: {binary}')
        identity = file_receipt(binary)
        with binary.open('rb') as stream:
            require(stream.read(4) == b'\x7fELF', f'not an actual ELF: {binary}')
        require(os.access(binary, os.X_OK), f'ELF is not executable: {binary}')
        artifacts[key] = {'crate': crate, 'binary': str(binary), 'cwd': str(cwd),
                          'artifact': artifact, 'identity': identity}
    require(len({value['binary'] for value in artifacts.values()}) == len(artifacts),
            'different crates must have distinct test executables')

    boundary_src = repo / 'trillionnium/crates/trnm-sqlite-io-boundary/src/lib.rs'
    boundary_ids = {row['package_id'] for row in rows
                    if row.get('reason') == 'compiler-artifact'
                    and row.get('target', {}).get('kind') == ['lib']
                    and Path(row.get('target', {}).get('src_path', '')).resolve() == boundary_src}
    require(len(boundary_ids) == 1, 'missing or ambiguous actual SQLite boundary package')
    witnesses = [row for row in rows if row.get('reason') == 'build-script-executed'
                 and row.get('package_id') in boundary_ids]
    require(len(witnesses) == 1, 'expected one actual SQLite witness build-script output')
    witness = witnesses[0]
    pairs = witness.get('env', [])
    witness_env = dict(pairs)
    require(len(pairs) == len(witness_env), 'duplicate SQLite witness environment entries')
    require(witness.get('cfgs', []).count('trnm_sqlite_layout_witness') == 1,
            'SQLite build did not enable the actual layout witness')
    require(witness_env.get('TRNM_SQLITE3_BUILD_FENCE') == SQLITE_FENCE,
            'wrong or missing SQLite build fence')
    require(witness_env.get('TRNM_SQLITE3_AMALGAMATION_SHA256') == SQLITE_AMALGAMATION_SHA256,
            'wrong SQLite amalgamation pin')
    require(not any('UNQUALIFIED' in key or 'UNQUALIFIED' in value for key, value in pairs),
            'SQLite build-script environment is unqualified')
    require('static=trnm_sqlite_layout_witness' in witness.get('linked_libs', []),
            'qualified witness archive is not linked')
    witness_dir = Path(witness['out_dir'])
    require(witness_dir.is_absolute() and witness_dir.is_dir(), 'missing SQLite witness OUT_DIR')
    preserved = {}
    for label, source in (
        ('cargo-output', witness_dir.parent / 'output'),
        ('symbols-stdout', witness_dir / 'trnm-witness-symbols.stdout'),
        ('symbols-stderr', witness_dir / 'trnm-witness-symbols.stderr'),
    ):
        preserved[label] = snapshot_file(source, inputs / f'sqlite-{label}.txt')
    output_text = (inputs / 'sqlite-cargo-output.txt').read_text()
    require('UNQUALIFIED' not in output_text, 'actual SQLite unit output contains UNQUALIFIED')
    for line in (
        'cargo:rustc-cfg=trnm_sqlite_layout_witness',
        'cargo:rustc-env=TRNM_SQLITE3_BUILD_FENCE=' + SQLITE_FENCE,
        'cargo:rustc-env=TRNM_SQLITE3_AMALGAMATION_SHA256=' + SQLITE_AMALGAMATION_SHA256,
    ):
        require(output_text.splitlines().count(line) == 1,
                'missing or duplicate qualified SQLite unit output: ' + line)
    require(not (inputs / 'sqlite-symbols-stderr.txt').read_bytes(),
            'SQLite witness symbol verification retained stderr')
    archive = file_receipt(witness_dir / 'libtrnm_sqlite_layout_witness.a')
    require(archive['size'] > 0, 'empty SQLite witness archive')
    result = {'artifacts': artifacts, 'build_jsonl': build_log, 'build_stderr': stderr_log,
              'external_build_receipt': external_build,
              'sqlite_witness': {'build_script': witness, 'files': preserved, 'archive': archive},
              'scope': 'recorded actual build profiles/features; no additional native qualification run'}
    write_json(out / 'build-artifacts.json', result)
    return result


def run_required_selector(artifact: dict, group: str, selector: str, index: int,
                          repo: Path, controls: Path, env: dict[str, str], *,
                          capture_flag: str = '--nocapture') -> dict:
    require(re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*', selector)
            is not None, 'invalid exact libtest selector')
    require(capture_flag in ('--nocapture', '--show-output'),
            'only the existing workflow capture policies are supported')
    binary = Path(artifact['binary'])
    require(list(fingerprint(binary.lstat())) == artifact['identity']['fingerprint'],
            f'ELF changed before selector {index}: {binary}')
    name = f'{index:02d}-{artifact["crate"]}-{selector.rsplit("::", 1)[-1]}'
    prefix = controls / name
    native = run_capture([str(binary), selector, '--exact', capture_flag, '--test-threads=1'],
                         Path(artifact['cwd']), env, prefix,
                         time_output=controls / f'{name}.resources.txt')
    reader = run_capture([
        sys.executable, str(repo / 'scripts/ci/check_required_native_test.py'),
        native['log_path'], '--test', selector,
    ], repo, env, controls / f'{name}.execution')
    verdict = None
    reader_json_error = None
    if capture_passed(reader):
        try:
            verdict = json.loads(Path(reader['stdout_path']).read_text())
        except (OSError, UnicodeError, ValueError) as error:
            reader_json_error = repr(error)
    confirmed = (capture_passed(reader) and verdict is not None
                 and verdict.get('result') == 'PASS' and verdict.get('test') == selector
                 and verdict.get('executed_tests') == 1)
    result = {'index': index, 'crate': artifact['crate'], 'group': group, 'selector': selector,
              'native': native, 'reader': reader, 'reader_exit': reader['native_exit'],
              'reader_verdict': verdict, 'reader_json_error': reader_json_error,
              'confirmed_named_execution': bool(confirmed),
              'passed': bool(capture_passed(native) and confirmed)}
    write_json(controls / f'{name}.receipt.json', result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--remote-root', type=Path, default=DEFAULT_REMOTE_ROOT)
    parser.add_argument('--repo-root', type=Path, help='default: REMOTE_ROOT/repo')
    parser.add_argument('--build-jsonl', type=Path, required=True)
    parser.add_argument('--build-stderr', type=Path, required=True)
    parser.add_argument('--build-receipt', type=Path, required=True,
                        help='retain the actual external build command/exit/source receipt')
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--output', type=Path, required=True,
                        help='new create-only directory outside the source checkout')
    args = parser.parse_args()
    require(re.fullmatch(r'[0-9a-f]{40}', args.expected_head) is not None,
            '--expected-head must be an exact canonical Git commit')
    remote = args.remote_root.resolve(strict=True)
    repo = (args.repo_root or remote / 'repo').resolve(strict=True)
    out = args.output.resolve()
    require(not out.is_relative_to(repo), 'receipts must remain outside the source checkout')
    out.mkdir(parents=True, exist_ok=False)
    controls = out / 'semantic-controls'
    controls.mkdir()
    env = dict(os.environ)
    env.update(PYTHONDONTWRITEBYTECODE='1', RUST_TEST_THREADS='1',
               GITHUB_WORKSPACE=str(repo), TRNM_CI_RECEIPT_DIR=str(out))
    report = {'schema': 'trnm-exact-selected-native-controls-v1', 'started_utc': utc_now(),
              'repo': str(repo), 'expected_head': args.expected_head,
              'runner': file_receipt(Path(__file__).resolve()),
              'expected_selectors': EXPECTED_SELECTOR_COUNT,
              'scope': '80 existing semantic controls from supplied actual library ELFs; '
                       'not original test-profile CPU, PQ/full-suite, Host service or TPS acceptance',
              'source_before': None, 'source_after': None, 'build': None,
              'registry': {}, 'builder': None, 'selectors': [], 'errors': []}
    artifacts = {}
    try:
        report['source_before'] = source_checkpoint(repo, args.expected_head, out, 'source-before', env)
        require(report['source_before']['passed'], 'original source-before checker failed')
        report['build'] = load_build_artifacts(repo, args.build_jsonl.resolve(strict=True),
                                              args.build_stderr.resolve(strict=True), out, TARGETS,
                                              build_receipt=args.build_receipt.resolve(strict=True))
        artifacts = report['build']['artifacts']
        for key in ('m06', 'node'):
            artifact = artifacts[key]
            result = run_capture([artifact['binary'], '--list', '--format', 'terse'],
                                 Path(artifact['cwd']), env, controls / f'{key}-registry')
            report['registry'][key] = result
            require(capture_passed(result), f'actual {key} registry process failed')
        workflow = repo / WORKFLOW
        builder = extract_heredoc(workflow, 'PYREGISTRY',
                                 'Execute selected arithmetic canonical and reorg semantic controls')
        builder_sha = hashlib.sha256(builder.encode()).hexdigest()
        require(builder_sha == EXPECTED_BUILDER_SHA256,
                'workflow registry builder changed from this reviewed runner')
        builder_path = controls / 'original-registry-builder.py'
        with builder_path.open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(builder)
        report['workflow'] = file_receipt(workflow)
        report['builder_source'] = file_receipt(builder_path)
        report['builder'] = run_capture([sys.executable, str(builder_path)], repo, env,
                                        controls / 'registry-check')
        require(capture_passed(report['builder']), 'original registry builder failed')
        builder_result = json.loads(Path(report['builder']['stdout_path']).read_text())
        require(builder_result.get('result') == 'PASS'
                and builder_result.get('selected_count') == EXPECTED_SELECTOR_COUNT,
                'original builder did not select exactly 80 controls')
        selected = [line.split('\t') for line in (controls / 'selected-tests.tsv').read_text().splitlines()]
        require(len(selected) == EXPECTED_SELECTOR_COUNT
                and all(len(row) == 3 and row[0] in artifacts for row in selected),
                'invalid selected-tests.tsv shape/count')
        require(len({(crate, selector) for crate, _group, selector in selected}) == len(selected),
                'duplicate selected native test')
        write_json(controls / 'selected-plan.json', {'builder_result': builder_result,
                                                    'selected': selected, 'retry_policy': 'none'})
        with (controls / 'test-exits.tsv').open('x', encoding='utf-8') as exits:
            exits.write('crate\tgroup\tselector\tnative_exit\tlog_exit\treader_exit\tconfirmed\n')
            exits.flush()
            for index, (crate, group, selector) in enumerate(selected, 1):
                print(json.dumps({'event': 'start', 'index': index, 'total': len(selected),
                                  'crate': crate, 'selector': selector}), flush=True)
                result = run_required_selector(artifacts[crate], group, selector, index,
                                               repo, controls, env)
                report['selectors'].append(result)
                exits.write(f'{crate}\t{group}\t{selector}\t{result["native"]["native_exit"]}\t'
                            f'{result["native"]["log_exit"]}\t{result["reader_exit"]}\t'
                            f'{int(result["confirmed_named_execution"])}\n')
                exits.flush()
                print(json.dumps({'event': 'finish', 'index': index, 'selector': selector,
                                  'passed': result['passed'],
                                  'native_exit': result['native']['native_exit'],
                                  'reader_exit': result['reader_exit']}), flush=True)
    except Exception:
        report['errors'].append(traceback.format_exc())
    finally:
        report['artifact_after'] = {}
        for key, artifact in artifacts.items():
            try:
                after = file_receipt(Path(artifact['binary']))
                unchanged = after == artifact['identity']
                report['artifact_after'][key] = {'identity': after, 'unchanged': unchanged}
                if not unchanged:
                    report['errors'].append(f'{key} ELF changed during this run')
            except Exception:
                report['errors'].append(traceback.format_exc())
        try:
            report['source_after'] = source_checkpoint(repo, args.expected_head, out, 'source-after', env)
            require(report['source_after']['passed'], 'original source-after checker failed')
            require(report['source_before'] is not None
                    and report['source_before']['receipt'] == report['source_after']['receipt'],
                    'source-before/after receipts differ')
        except Exception:
            report['errors'].append(traceback.format_exc())
        report['attempted_selector_count'] = len(report['selectors'])
        report['confirmed_named_execution_count'] = sum(
            row['confirmed_named_execution'] for row in report['selectors'])
        report['passed_selector_count'] = sum(row['passed'] for row in report['selectors'])
        report['finished_utc'] = utc_now()
        report['passed'] = (not report['errors']
                            and report['attempted_selector_count'] == EXPECTED_SELECTOR_COUNT
                            and report['confirmed_named_execution_count'] == EXPECTED_SELECTOR_COUNT
                            and report['passed_selector_count'] == EXPECTED_SELECTOR_COUNT)
        (controls / 'executed-selector-count.txt').write_text(
            str(report['attempted_selector_count']) + '\n')
        (controls / 'semantic-step.exit').write_text('0\n' if report['passed'] else '1\n')
        write_json(out / 'summary.json', report)
        manifest = [file_receipt(path) for path in sorted(out.rglob('*')) if path.is_file()]
        write_json(out / 'receipt-sha256.json', manifest)
    print(json.dumps({'passed': report['passed'], 'output': str(out),
                      'attempted': report['attempted_selector_count'],
                      'confirmed': report['confirmed_named_execution_count'],
                      'passed_selectors': report['passed_selector_count']}), flush=True)
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
