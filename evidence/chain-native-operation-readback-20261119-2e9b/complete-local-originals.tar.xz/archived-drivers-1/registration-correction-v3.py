from pathlib import Path
import json,subprocess,hashlib,time,resource,sys
base=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b');src=base/'source';e=base/'current-source-registration-3';e.mkdir(exist_ok=False)
before=subprocess.check_output(['git','diff','--binary'],cwd=src);prev=json.loads((base/'source-gates-2/RESULT.json').read_text());assert prev['source_unchanged'] and hashlib.sha256(before).hexdigest()==prev['after']['tracked_patch_sha256']
with (e/'preflight.stdout').open('xb') as so,(e/'preflight.stderr').open('xb') as se:r=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=src,stdout=so,stderr=se)
assert r.returncode==0
p=src/'docs/architecture/TRNM_DOCUMENTATION_AUTHORITY_V1.md';text=p.read_text();old='resource_revision_r21_rejects_signed_old_cookies_and_preserves_control_output_reserve';new=old.replace('_r21_','_r22_');assert text.count(old)==1;text=text.replace(old,new)
sys.path.insert(0,str(src/'scripts/ci'));sys.dont_write_bytecode=True
from check_applicability import profile_table
profiles=json.loads((src/'config/pon/applicability-v1.json').read_text())['profiles'];assert profile_table(profiles) in text
p.write_text(text)
corpus=src/'config/pon/pq-cross-branch-corpus-v1.json';value=json.loads(corpus.read_text());raw=p.read_bytes();rel=p.relative_to(src).as_posix();oldpin=value['pinned_blobs'][rel];newpin=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();value['pinned_blobs'][rel]=newpin;corpus.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
after=subprocess.check_output(['git','diff','--binary'],cwd=src);(e/'candidate.patch').write_bytes(after)
res={'schema':'chain-operation-applicability-navigation-correction-v1','path':rel,'sole_change':'existing native r21 callable name to actual r22 callable','old_blob':oldpin,'new_blob':newpin,'tracked_patch_sha256':hashlib.sha256(after).hexdigest(),'qualification_changed':False}
(e/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res),flush=True)
