#!/usr/bin/env python3
"""Export only the prepared test-only child; never compile or execute Rust tests."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import time

BASE = Path('/home/qian-qi/work/chain-pq-composition-663507-20261108')
ROOT = BASE / 'da-fixture-diagnostics-5633'
SOURCE = ROOT / 'source'
OUTPUT = ROOT / 'output'
TRANSFER = ROOT / 'transfer'
HEAD = 'f0e8dc919f10a5f1e7debca544aed9d14e75d96d'
PARENT = '5633c55219c01c689f670c2ca35d122e39f3f791'
TREE = '040f0bb032607fbb5c2a1d81207d4a55ffd13e72'
FILES = sorted([
    'trillionnium/crates/trnm-data-availability/src/cell/network/serving/tests.rs',
    'trillionnium/crates/trnm-data-availability/src/cell/discovery/equivocation_history_tests.rs',
    'trillionnium/crates/trnm-data-availability/src/cell/release/transport_tests/rarest.rs',
])


def identity(path):
    if not stat.S_ISREG(path.lstat().st_mode):
        raise RuntimeError(f'not a regular file: {path}')
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(path, data):
    with path.open('x') as handle:
        json.dump(data, handle, sort_keys=True, indent=2)
        handle.write('\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-runner-sha256', required=True)
    args = parser.parse_args()
    runner = Path(__file__).absolute()
    runner_before = identity(runner)
    if runner_before['sha256'] != args.expected_runner_sha256:
        raise RuntimeError('bundle runner identity changed')
    for directory in [BASE, ROOT, SOURCE, OUTPUT]:
        if not stat.S_ISDIR(directory.lstat().st_mode) or directory.resolve() != directory:
            raise RuntimeError(f'unsafe directory: {directory}')
    summary_path = OUTPUT / 'execute-summary.json'
    summary_before = identity(summary_path)
    summary = json.loads(summary_path.read_bytes())
    if summary.get('mode') != 'execute' or summary.get('parent') != PARENT or summary.get('new_head') != HEAD:
        raise RuntimeError('missing or mismatched terminal execution summary')
    if summary.get('status') not in {'COMPLETE', 'INCOMPLETE_OR_BLOCKED'}:
        raise RuntimeError('execution summary has no terminal classification')
    if summary.get('original_result_replaced') is not False or summary.get('whole_chain_pq_qualified') is not False:
        raise RuntimeError('unexpected qualification flags')
    TRANSFER.mkdir(mode=0o700)
    records = []
    git_before = identity(Path('/usr/bin/git'))
    bundle = TRANSFER / 'da-fixture-f0e8dc9-parent-5633.bundle'

    def run(argv):
        argv = [str(item) for item in argv]
        started = time.monotonic()
        process = subprocess.Popen(argv, cwd=SOURCE, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True)
        timed_out = False
        try:
            stdout, stderr = process.communicate(timeout=120)
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = process.communicate()
        record = {'argv': argv, 'cwd': str(SOURCE), 'exit_code': process.returncode,
                  'elapsed_seconds': time.monotonic() - started, 'timed_out': timed_out,
                  'stdout': stdout.decode('utf-8', errors='replace'),
                  'stderr': stderr.decode('utf-8', errors='replace')}
        records.append(record)
        save(TRANSFER / f'command-{len(records):02d}.json', record)
        if timed_out or process.returncode != 0:
            raise RuntimeError(f'failed bundle command {len(records)}')
        return stdout.decode('utf-8')

    run(['/bin/bash', 'scripts/project-preflight.sh', '--audit'])
    if run(['/usr/bin/git', 'rev-parse', 'HEAD', 'HEAD^', 'HEAD^{tree}']).splitlines() != [HEAD, PARENT, TREE]:
        raise RuntimeError('source commit/parent/tree differs')
    if run(['/usr/bin/git', 'rev-list', '--count', HEAD, '^' + PARENT]).strip() != '1':
        raise RuntimeError('bundle would include more than one commit')
    if sorted(run(['/usr/bin/git', 'diff-tree', '--no-commit-id', '--name-only', '-r', HEAD]).splitlines()) != FILES:
        raise RuntimeError('child contains unexpected changed paths')
    if bundle.exists():
        raise RuntimeError('bundle path already exists')
    run(['/usr/bin/git', 'bundle', 'create', '--version=2', bundle, 'HEAD', '^' + PARENT])
    bundle_before = identity(bundle)
    run(['/usr/bin/git', 'bundle', 'verify', bundle])
    if run(['/usr/bin/git', 'bundle', 'list-heads', bundle]).splitlines() != [HEAD + ' HEAD']:
        raise RuntimeError('bundle advertises an unexpected head')
    header = bundle.read_bytes().split(b'\n\n', 1)[0].decode('utf-8').splitlines()
    if len(header) != 3 or header[0] != '# v2 git bundle' or not header[1].startswith('-' + PARENT + ' ') or header[2] != HEAD + ' HEAD':
        raise RuntimeError('bundle prerequisite/header differs')
    if run(['/usr/bin/git', 'rev-parse', 'HEAD', 'HEAD^', 'HEAD^{tree}']).splitlines() != [HEAD, PARENT, TREE]:
        raise RuntimeError('source identity changed during export')
    if identity(bundle) != bundle_before or identity(runner) != runner_before or identity(Path('/usr/bin/git')) != git_before or identity(summary_path) != summary_before:
        raise RuntimeError('artifact or tool identity changed during export')
    report = {'status': 'EXPORTED_ONE_CHILD_COMMIT', 'head': HEAD, 'parent_prerequisite': PARENT,
              'tree': TREE, 'changed_paths': FILES, 'bundle': bundle_before, 'header': header,
              'runner': runner_before, 'git': git_before, 'execution_summary': summary_before,
              'commands': records, 'native_tests_executed_by_export': False,
              'original_result_replaced': False, 'source_modified': False,
              'whole_chain_pq_qualified': False}
    save(TRANSFER / 'transfer-report.json', report)
    print(json.dumps({'status': report['status'], 'bundle': bundle_before,
                      'report': identity(TRANSFER / 'transfer-report.json')}, sort_keys=True))


if __name__ == '__main__':
    main()
