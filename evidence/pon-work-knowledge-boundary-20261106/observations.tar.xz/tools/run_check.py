import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/51e4e62b58cf/chain')
OUT = Path('/workspace/scratch/51e4e62b58cf/checks')
OUT.mkdir(exist_ok=True)
name, seconds, *command = sys.argv[1:]
record = {'name': name, 'command': command, 'timeout_seconds': int(seconds)}
record['source_commit'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
record['source_tree'] = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
record['status_before'] = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
record['environment'] = {key: os.environ[key] for key in ('CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'RUST_TEST_THREADS', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'PYTHONPATH', 'PYTHONDONTWRITEBYTECODE') if key in os.environ}
record['started_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
start = time.monotonic()
with (OUT / (name + '.log')).open('xb') as log:
    try:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=int(seconds))
        record['returncode'] = result.returncode
        record['timed_out'] = False
    except subprocess.TimeoutExpired:
        record['returncode'] = None
        record['timed_out'] = True
record['wall_seconds'] = time.monotonic() - start
record['status_after'] = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
record['log_sha256'] = hashlib.sha256((OUT / (name + '.log')).read_bytes()).hexdigest()
(OUT / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
sys.exit(record['returncode'] if record['returncode'] is not None else 124)
