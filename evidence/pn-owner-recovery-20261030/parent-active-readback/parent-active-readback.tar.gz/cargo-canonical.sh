#!/usr/bin/env bash
set -euo pipefail
export PATH=/tmp/pn-installed-toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:/workspace/scratch/cedd7bc74ace/pn-toolchain/cargo/bin:$PATH
export CARGO_HOME=/workspace/scratch/cedd7bc74ace/pn-toolchain/cargo
export RUSTUP_HOME=/workspace/scratch/cedd7bc74ace/pn-toolchain/rustup
export RUSTC=/tmp/pn-installed-toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc
export RUSTDOC=/tmp/pn-installed-toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustdoc
export LD_LIBRARY_PATH=/tmp/pn-installed-toolchains/1.95.0-x86_64-unknown-linux-gnu/lib
export CARGO_TARGET_DIR=/tmp/pn-chain-target
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
exec /tmp/pn-installed-toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/cargo "$@"
