import os,sys
sys.path.insert(0,'/workspace/scratch/ec265b67753e/resource-experiment-proposal/scripts')
import w1_owned_process_collector_v1 as c
original=c.process_identity
failed=False
def fail_once(pid,boot):
 global failed
 if pid not in (os.getpid(),os.getppid()) and not failed:
  failed=True
  raise OSError('actual post-fork proc read fault control')
 return original(pid,boot)
c.process_identity=fail_once
sys.exit(c.main(['--out', '/workspace/scratch/ec265b67753e/collector-controls-local-03/test_actual_post_fork_identity_failure_reaps_gated_root_without_exec/collector', '--deadline-monotonic-ns', '45494770540141', '--deadline-boot-id', '673cfd48-3d8e-45de-8933-8ed1b12c2604', '--cleanup-grace-seconds', '2', '--cwd', '/workspace/scratch/ec265b67753e/collector-controls-local-03/test_actual_post_fork_identity_failure_reaps_gated_root_without_exec', '--executable-sha256', 'fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7', '--', '/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12', '/workspace/scratch/ec265b67753e/collector-controls-local-03/test_actual_post_fork_identity_failure_reaps_gated_root_without_exec/payload.py']))
