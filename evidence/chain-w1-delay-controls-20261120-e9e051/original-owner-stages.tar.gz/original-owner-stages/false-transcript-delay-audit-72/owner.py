from pathlib import Path
import json,sys,time,resource,hashlib,re
root=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');src=root/'source';out=root/'false-transcript-delay-audit-72';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);t=time.monotonic();b=resource.getrusage(resource.RUSAGE_SELF);raw=(root/'original-mixed-service-diagnostic-67/mixed-service-campaign/report.json').read_bytes();r=json.loads(raw);rows=[]
for x in r['attempts']:
 if x['lane']=='paid_false_transcript':
  rows.append({'ordinal':x['ordinal'],'phase':x['phase'],'started_ns':x['started_ns'],'ended_ns':x['ended_ns'],'duration_ns':x['ended_ns']-x['started_ns'],'status':x['status'],'response':x['response'],'metrics':x['metrics']})
hits=[]
for path in (src/'trillionnium/crates/trnm-pon-node/src/ingress/public_v3').rglob('*.rs'):
 if path.name.endswith('_tests.rs') or '/tests/' in str(path):continue
 lines=path.read_text().splitlines()
 for i,line in enumerate(lines):
  if re.search(r'delay|sleep|refus|deadline|WORK:',line,re.I):
   if re.search(r'delay|sleep|WORK:',line,re.I):
    hits.append({'path':str(path.relative_to(src)),'line':i+1,'text':line})
result={'source_report_sha256':hashlib.sha256(raw).hexdigest(),'attempts':rows,'source_hits':hits,'phases_metrics':[x['server_metrics'] for x in r['phases']]};data=(json.dumps(result,indent=2)+'\n').encode();(out/'READOUT.json').write_bytes(data);a=resource.getrusage(resource.RUSAGE_SELF);cost={'wall_seconds':time.monotonic()-t,'self_user_cpu_seconds':a.ru_utime-b.ru_utime,'self_system_cpu_seconds':a.ru_stime-b.ru_stime,'readout_bytes':len(data),'readout_sha256':hashlib.sha256(data).hexdigest()};(out/'RESULT.json').write_text(json.dumps(cost,indent=2)+'\n');print(json.dumps({'cost':cost,'first_attempt':rows[0],'all_attempts':[{k:v for k,v in x.items() if k not in ('metrics','response')} for x in rows],'source_hits':hits}),flush=True)
