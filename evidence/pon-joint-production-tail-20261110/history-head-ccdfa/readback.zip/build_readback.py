"""Read-only ZIP member recovery; never loads native code or databases."""
import gzip
import hashlib
import json
import pathlib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / 'packet'
OUT.mkdir(exist_ok=True)
ARCHIVE = ROOT / '13800576703.zip'
sha = lambda b: hashlib.sha256(b).hexdigest()
assert ARCHIVE.stat().st_size == 57365734
assert sha(ARCHIVE.read_bytes()) == '08eafb84781c35966a320824c7d60a5eca16540056bb928c2d8c9fd1d331f033'
records = []
with zipfile.ZipFile(ARCHIVE) as z:
    infos = z.infolist()
    assert len(infos) == 4140
    assert len({i.filename for i in infos}) == len(infos)
    assert sum(i.file_size for i in infos) == 609881087
    for i in infos:
        assert not pathlib.PurePosixPath(i.filename).is_absolute()
        assert '..' not in pathlib.PurePosixPath(i.filename).parts
        assert i.file_size <= 250_000_000
        h = hashlib.sha256()
        with z.open(i) as r:
            while b := r.read(1_048_576):
                h.update(b)
        rec = {'name': i.filename, 'bytes': i.file_size, 'sha256': h.hexdigest(), 'crc32': f'{i.CRC:08x}', 'retained': False}
        if i.filename.endswith(('.json', '.jsonl', '.log', '.txt')):
            assert i.file_size <= 2_000_000
            raw = z.read(i)
            stored = gzip.compress(raw, mtime=0)
            rel = 'raw/' + i.filename + '.gz'
            p = OUT / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(stored)
            rec.update(retained=True, stored=rel, stored_bytes=len(stored), stored_sha256=sha(stored))
        records.append(rec)
(OUT / 'archive-members.json').write_text(json.dumps(records, indent=2) + '\n')
manifest = {'schema': 'trnm-joint-history-current-readback-v1', 'artifact_id': 13800576703, 'run_id': 42875013833, 'job_id': 130067895846, 'attempt': 1, 'archive_bytes': ARCHIVE.stat().st_size, 'archive_sha256': sha(ARCHIVE.read_bytes()), 'archive_members': len(records), 'expanded_bytes': sum(r['bytes'] for r in records), 'retained_members': sum(r['retained'] for r in records), 'source': 'ccdfa205880399d8a281a09914df0ab9f16f580d', 'tree': '9053ea46b29109240f0ce207c814fa783e99a0ea', 'native_execution_by_this_readback': False, 'archive_binary_present': False, 'archive_and_unretained_members_persisted_in_packet': False, 'qualification': 'HOLD_NO_GO', 'actual_joint_obligations_open': 13}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest))
