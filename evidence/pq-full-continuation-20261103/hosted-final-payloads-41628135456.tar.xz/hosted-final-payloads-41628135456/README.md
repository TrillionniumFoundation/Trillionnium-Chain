# Final hosted PQ witness regression — run 41628135456

The final native regression gate is **FAIL**. Both X64 lanes completed the full Node library suite with 897 passed, 0 failed and 22 ignored. Both ARM64 lanes completed with 895 passed, 2 failed and 22 ignored. Strict Clippy completed successfully in all four lanes. These are final raw-log and command-receipt observations, not conclusions inferred from job step names.

All four final ZIPs were downloaded and their exact byte sizes and SHA-256 values matched GitHub metadata. Every final command/log record was checked, including source identity before and after the command.

## Exact source and lane results

- Candidate: `12fe5f2c1f19704fe7eb635dede6839ed8b1e91e`.
- Base: `2e72a989d001cf51bd0aed0e1401526e45db31f1`.
- Prospective merge: `0357031364787574cb7058b05329aa2e2730f947`, with GitHub parents exactly base then candidate.
- Both source variants have tree `c44112da731e3f958e55eb024e5762d6723ea2c9`.
- The retained CI source guard records 6,831 tracked entries and 782,174,381 tracked bytes verified before and after every command. This readback validates those records and GitHub identities; it does not reconstruct that entire source tree locally.

| Architecture | Source | Final artifact | Node passed | Failed | Ignored | Node exit | Clippy exit |
|---|---|---:|---:|---:|---:|---:|---:|
| X64 | prospective-merge | 13228644018 | 897 | 0 | 22 | 0 | 0 |
| ARM64 | prospective-merge | 13228884298 | 895 | 2 | 22 | 101 | 0 |
| ARM64 | head | 13229307819 | 895 | 2 | 22 | 101 | 0 |
| X64 | head | 13229900050 | 897 | 0 | 22 | 0 | 0 |

Each outer suite enumerates 919 tests. The 22 ignored tests are not counted as executed passes; their exact names are retained per lane in `final-readback.json`. Nested child-process libtest summaries appear in the raw logs and are not added to the outer totals.

## Retained ARM failures

Both ARM lanes fail the same two tests:

1. `store::detached_admission::tests::admitted_custom_genesis_over_eight_mib_keeps_original_held_schedule_and_cpu_owner`.
2. `store::detached_admission::tests::authenticated_large_parent_original_schedule_supplementary_denominator`.

Both fail at `crates/trnm-pon-node/src/store/detached_admission/tests.rs:724:31`: `Result::unwrap()` receives an error with code `PublicMutationCpuBudget`, kind `Capacity`, message `PUBLIC_MUTATION_CPU_BUDGET`, and `request_history_budget: false`. These are actual failed tests, distinguished from expected or injected panics printed by other successful tests.

For each failing authenticated-backend execution, the original receipt has `live_refused=true` and final `native_result={"Err":"PUBLIC_MUTATION_CPU_BUDGET"}`. Exact original numeric values follow; all units are nanoseconds.

| Source | Failed test | total_cpu_ns | live_paid_cpu_ns | remaining/stored_credit_ns | credited_refill_ns |
|---|---|---:|---:|---:|---:|
| prospective-merge | 1 | 2691608328 | 2691605384 | -8132888 | 683475440 |
| prospective-merge | 2 | 2686729680 | 2686726160 | -4927962 | 681801718 |
| head | 1 | 2765746800 | 2765743320 | -54352177 | 711394623 |
| head | 2 | 2765182320 | 2765179248 | -38860982 | 726321338 |

The original CPU settings in those diagnostics remain `burst_ns=2000000000`, `refill_ns_per_second=250000000`, `start_reserve_ns=100000000`, and `worker_limit=2`. Full original CPU receipts, balance observations, and raw JSON lines remain in the unmodified Node logs. The preliminary `original_dispatch_result` is `Ok` in these diagnostics, while the final outer `native_result` is the budget error; the inner result is not reported as completed business success.

No environmental explanation or causal attribution is inferred from the architecture difference. The observed errors, receipts and negative remaining credits are retained as failures under the original settings. No native test was rerun, no budget was raised, and no source or target was changed while collecting these artifacts.

## Comparison with the early 180 controls

Each final artifact contains all 166 members of its corresponding early controls artifact byte-for-byte unchanged. The only four additions are `node-lib.json`, `node-lib.log`, `clippy.json`, and `clippy.log`. All 45 exact controls per lane still verify as one actual pass each, with zero ignored controls: 180/180 across the matrix, including the two new witness admission controls.

The two failing full-suite test names are outside the required45 selector set. The early-control successes therefore remain valid component evidence, while the complete native regression gate fails. Whole-chain quantum security, full rollback-state coverage, WAN, migration and independent system qualification remain unqualified.

## Execution and artifact integrity

Full Node used `cargo +1.95.0 test --locked --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib --all-features -- --show-output --test-threads=1`. Clippy used the same locked manifest/package with `--lib --tests --all-features -- -D warnings`. All retained before/after source identities match. Provider environment hashes bind to the prepared OpenSSL 3.5.9 receipt.

| Artifact | Original ZIP bytes | Original GitHub-matched SHA-256 |
|---|---:|---|
| 13228644018 | 959126 | `bf6466d9e0e086be612ff6f2f3b1ed07718ae4d234f6678835d9ebe921e2ce15` |
| 13228884298 | 958561 | `47d2646c52d1b3803487b10a1f40a0b1a837f6a065a60ffa350f7cac74f064d5` |
| 13229307819 | 955110 | `55036d88b378771fe1f4a46f9115bd688c661c7fac62241c74126b09a6c50286` |
| 13229900050 | 955304 | `bcc493423bbab7e146bc781c51f3c99fb0f3ef832be43eaf41cc1700359271e7` |

This payload package preserves all 680 original member files under `payloads/<artifact-id>/` and omits duplicate ZIP containers. Original ZIP hash/size checks are retained in `original-container-verification.json`; member hashes are in `raw-member-manifests.json`. Original ZIPs remain separately retained for this session. Rechecking extracted bytes cannot reconstruct or rehash an omitted ZIP container.

Run `python3 verify-final-witness.py` after unpacking, or `python3 verify-final-witness.py /path/to/hosted-final-payloads-41628135456.tar.xz`. It independently checks member hashes, all command/log receipts, the exact controls, final suite totals, ignored and failed identities, failure receipts, Clippy completion and early/final byte equality. The payload mode explicitly records that the original ZIP digests were previously verified rather than recomputed. A validated readback does not turn the retained native failures into passes.

Two initial artifact downloads encountered the storage service `Ingress is over the account limit / ServerBusy`; those tool errors are retained separately. One short-lived ARM-head download URL expired during local retrieval and was refreshed through the GitHub connector. These were artifact retrieval events; no workflow or native test was rerun.
