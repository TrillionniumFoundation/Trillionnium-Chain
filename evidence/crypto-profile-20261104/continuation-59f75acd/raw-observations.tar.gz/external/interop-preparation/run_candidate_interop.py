#!/usr/bin/env python3
"""Finite real ML-DSA-65/87 interoperability observations; no activation.

The Rust observer links a successful exact-source Cargo library artifact.
OpenSSL uses the verified 3.5.9 installation and its own independent algorithm.
Empty messages use EVP, since this CLI refuses app_malloc(0) before crypto.
Temporary generated private keys are never included in the public observations.
"""
from __future__ import annotations

import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time

ARCHIVE_SHA256 = "603f5602e2eef00d77fbd429d34dcd5822bb301757a1bc9cdb24c670f1eb859a"
MESSAGE_LENGTHS = (0, 176, 4096, 65536)
PARAMETERS = {65: (1952, 3309, "308207b2300b0609608648016503040312038207a100"),
              87: (2592, 4627, "30820a32300b060960864801650304031303820a2100")}
CONTEXT = bytes.fromhex("435051312d696e7465726f702d6e6f6e656d707479")


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha256(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def identity(path):
    p = Path(path).resolve(strict=True)
    return {"path": str(p), "bytes": p.stat().st_size, "sha256": sha256(p)}


def write_json(path, value):
    Path(path).write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def source_identity(repo, commit):
    result = subprocess.run([sys.executable, "scripts/ci/verify_ci_source.py", "--kind", "head",
                             "--expected-head", commit], cwd=repo, capture_output=True, text=True)
    require(result.returncode == 0, "exact source verification failed: " + result.stderr)
    observed = json.loads(result.stdout)
    require(observed.get("tested_commit") == commit and observed.get("tracked_worktree_verified") is True,
            "source verifier did not establish the declared exact source")
    return observed


def built_libraries(receipt_path, repo, commit):
    receipt_path = Path(receipt_path).resolve(strict=True)
    receipt = json.loads(receipt_path.read_text())
    require(receipt.get("schema") == "trnm-pq-native-command-v1"
            and receipt.get("status") == "command_succeeded" and receipt.get("exit_code") == 0,
            "a successful original command receipt is required")
    before = receipt.get("before", {})
    require(before == receipt.get("after") and before.get("tested_commit") == commit
            and before.get("tracked_worktree_verified") is True
            and receipt.get("cwd") == str(repo), "library build receipt does not bind this source")
    argv = receipt.get("argv", [])
    require(argv and Path(argv[0]).name == "cargo" and "--locked" in argv
            and "--message-format=json" in argv, "need locked Cargo artifact JSON for the library")
    log = receipt_path.parent / receipt["log_file"]
    require(log.stat().st_size == receipt["log_bytes"] and sha256(log) == receipt["log_sha256"],
            "library build log differs from its receipt")
    found = {"trnm_crypto_primitives": [], "zeroize": []}
    finished = []
    for line in log.read_text().splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if not isinstance(row, dict):
            continue
        if row.get("reason") == "build-finished":
            finished.append(row.get("success"))
        name = row.get("target", {}).get("name")
        if row.get("reason") == "compiler-artifact" and name in found and not row.get("profile", {}).get("test"):
            for filename in row.get("filenames", []):
                if filename.endswith(".rlib"):
                    found[name].append((Path(filename).resolve(strict=True), row))
    require(finished == [True], "Cargo build did not report one complete successful finish")
    for name, rows in found.items():
        require(len(rows) == 1, "ambiguous or missing compiled library: " + name)
    crypto, crypto_artifact = found["trnm_crypto_primitives"][0]
    zeroize, zeroize_artifact = found["zeroize"][0]
    require(crypto.parent == zeroize.parent, "library dependency directories differ")
    return crypto, zeroize, {
        "receipt": identity(receipt_path), "argv": argv, "source": before,
        "crypto_library": identity(crypto), "crypto_cargo_artifact": crypto_artifact,
        "zeroize_library": identity(zeroize), "zeroize_cargo_artifact": zeroize_artifact,
    }


class Observer:
    def __init__(self, output, env):
        self.output, self.env, self.commands, self.checks = output, env, [], []
        self.labels = set()
        (output / "commands.jsonl").open("x").close()

    def command(self, label, argv, expected=0, token=None, cwd=None):
        require(label not in self.labels and re.fullmatch(r"[a-z0-9-]+", label), "invalid/duplicate label")
        self.labels.add(label)
        argv = [str(x) for x in argv]
        started = datetime.now(timezone.utc).isoformat()
        clock = time.monotonic_ns()
        launch_error, timed_out, result = None, False, None
        try:
            result = subprocess.run(argv, cwd=cwd, env=self.env, capture_output=True, timeout=120)
            raw_stdout, raw_stderr = result.stdout, result.stderr
            exit_code = result.returncode
        except subprocess.TimeoutExpired as caught:
            timed_out = True
            raw_stdout, raw_stderr = caught.stdout or b"", caught.stderr or b""
            exit_code = None
        except OSError as caught:
            launch_error = {"type": type(caught).__name__, "message": str(caught)}
            raw_stdout, raw_stderr = b"", b""
            exit_code = None
        elapsed = time.monotonic_ns() - clock
        stdout, stderr = self.output / (label + ".stdout.txt"), self.output / (label + ".stderr.txt")
        stdout.write_bytes(raw_stdout)
        stderr.write_bytes(raw_stderr)
        row = {"label": label, "argv": argv, "cwd": str(cwd) if cwd else None,
               "started_utc": started, "elapsed_ns": elapsed, "exit_code": exit_code,
               "timed_out": timed_out, "timeout_seconds": 120, "launch_error": launch_error,
               "expected_exit_code": expected, "expected_output_token": token,
               "stdout": identity(stdout), "stderr": identity(stderr)}
        row["expectation_met"] = (not timed_out and launch_error is None and exit_code == expected
                                  and (token is None or token.encode() in raw_stdout + raw_stderr))
        self.commands.append(row)
        with (self.output / "commands.jsonl").open("a") as stream:
            stream.write(json.dumps(row, sort_keys=True, allow_nan=False) + "\n")
        require(row["expectation_met"], "unexpected actual command outcome: " + label)
        return result

    def check(self, label, argv, *, suite, length, direction, kind, interface):
        expected = 0 if kind == "valid" else (1 if interface == "openssl-cli" else 3)
        token = ("Signature Verified Successfully" if kind == "valid" else "Signature Verification Failure") \
            if interface == "openssl-cli" else ("ACCEPT" if kind == "valid" else "REJECT_SIGNATURE")
        self.command(label, argv, expected=expected, token=token)
        row = {"label": label, "parameter": suite, "case_signed_message_bytes": length, "direction": direction,
               "kind": kind, "interface": interface, "outcome": "accepted" if kind == "valid" else "rejected",
               "signature_arithmetic_observed": True}
        self.checks.append(row)
        write_json(self.output / "completed-checks.json", self.checks)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--library-build-receipt", type=Path, required=True)
    parser.add_argument("--provider-receipt", type=Path, required=True)
    parser.add_argument("--rustc", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--work", type=Path, required=True)
    args = parser.parse_args()
    require(re.fullmatch(r"[0-9a-f]{40}", args.commit), "need exact source commit")
    repo = args.repo.resolve(strict=True)
    work, output = args.work.absolute(), args.output.absolute()
    require(not work.exists() and not output.exists(), "fresh work and observation directories are required")
    require(not output.is_relative_to(repo) and not work.is_relative_to(repo), "keep observation work outside repository")
    require(not output.is_relative_to(work) and not work.is_relative_to(output), "separate public observations and private work")
    output.mkdir(parents=True)
    work.mkdir(parents=True, mode=0o700)
    prep = Path(__file__).resolve().parent
    for filename in ("candidate_driver.rs", "empty_message_evp.c", "run_candidate_interop.py"):
        shutil.copyfile(prep / filename, output / filename)
    summary = {"schema": "trnm-independent-candidate-interop-v1", "status": "RUNNING",
               "source_commit": args.commit, "parameters": [65, 87], "message_lengths": list(MESSAGE_LENGTHS),
               "planned_valid_checks": 16, "planned_invalid_signature_checks": 64,
               "planned_cli_zero_message_observations": 4, "whole_chain_quantum_security_qualified": False,
               "production_activation": False, "fips_conformance_certified": False,
               "fips_validated_module_claim": False, "side_channel_review_performed": False,
               "scope": "finite cross-implementation Pure/empty-context mathematical observations only",
               "case_message_length_semantics": "valid signed message size; wrong-message replaces the first byte, or replaces empty with one zero byte",
               "rust_signing_seed_hex": (bytes([0x42]) * 32).hex(),
               "rust_wrong_key_seed_hex": (bytes([0x43]) * 32).hex(),
               "openssl_signing_and_keygen_randomness": "OpenSSL default provider OS-backed randomness; public fixtures retained",
               "private_test_keys_archived": False}
    write_json(output / "manifest.json", summary)
    observer, public_files, cli_limits, error = None, [], [], None
    private_root = None
    public = None
    try:
        summary["source_before"] = source_identity(repo, args.commit)
        crypto, zeroize, build = built_libraries(args.library_build_receipt, repo, args.commit)
        require(build["source"] == summary["source_before"], "library build source differs from actual current source")
        summary["candidate_library_build"] = build
        provider = json.loads(args.provider_receipt.read_text())
        require(provider.get("result") == "PREPARED_AND_SMOKE_VERIFIED" and provider.get("exit_code") == 0
                and provider.get("version") == "3.5.9" and provider.get("source_digest_verified") is True
                and provider.get("source_archive_sha256_expected") == ARCHIVE_SHA256
                and provider.get("backend_exported") is True, "provider preparation is not the exact completed pinned build")
        prefix = Path(provider["install_prefix"]).resolve(strict=True)
        openssl, libcrypto = prefix / "bin/openssl", prefix / "lib/libcrypto.a"
        archive = Path(provider["build_directory"]) / "openssl-3.5.9.tar.gz"
        require(sha256(archive) == ARCHIVE_SHA256, "provider source archive no longer matches the fixed pin")
        require(sha256(openssl) == provider["cli_sha256"], "OpenSSL executable changed after preparation")
        declared_libcrypto = [x for x in provider["native_backend_inputs"] if x.get("path") == str(libcrypto)]
        require(len(declared_libcrypto) == 1 and sha256(libcrypto) == declared_libcrypto[0]["sha256"],
                "static OpenSSL library differs from preparation receipt")
        summary["provider"] = {"receipt": identity(args.provider_receipt), "openssl": identity(openssl),
                               "libcrypto": identity(libcrypto), "source_archive": identity(archive),
                               "source_archive_sha256": ARCHIVE_SHA256}
        shutil.copyfile(args.provider_receipt, output / "provider-preparation-receipt.json")
        env = {**os.environ, "OPENSSL_CONF": "/dev/null", "OPENSSL_MODULES": str(prefix / "lib/ossl-modules")}
        observer = Observer(output, env)
        rustc = args.rustc.resolve(strict=True)
        require(rustc == args.rustc.absolute(), "rustc must be the canonical real compiler binary")
        version = observer.command("rustc-version", [rustc, "-Vv"], token="rustc 1.95.0")
        summary["rustc"] = {**identity(rustc), "version_output": version.stdout.decode()}
        observer.command("openssl-version", [openssl, "version"], token="OpenSSL 3.5.9 ")
        observer.command("openssl-signature-list", [openssl, "list", "-signature-algorithms", "-provider", "default"], token="ML-DSA-87")
        cc_path = shutil.which("cc")
        require(cc_path is not None, "C compiler is unavailable")
        cc = Path(cc_path).resolve(strict=True)
        version = observer.command("cc-version", [cc, "--version"])
        summary["cc"] = {**identity(cc), "version_output": version.stdout.decode()}
        summary["observation_sources"] = {filename: identity(output / filename) for filename in
                                           ("candidate_driver.rs", "empty_message_evp.c", "run_candidate_interop.py")}
        driver, evp = work / "candidate-driver", work / "empty-message-evp"
        observer.command("compile-rust-observer", [rustc, "--edition=2021", "-D", "warnings",
                         output / "candidate_driver.rs", "--extern", "trnm_crypto_primitives=" + str(crypto),
                         "--extern", "zeroize=" + str(zeroize), "-L", "dependency=" + str(crypto.parent), "-o", driver])
        observer.command("compile-evp-observer", [cc, "-std=c11", "-Wall", "-Wextra", "-Werror",
                         "-I" + str(prefix / "include"), output / "empty_message_evp.c", libcrypto,
                         "-pthread", "-ldl", "-o", evp])
        observer.command("evp-linked-version", [evp, "version"], token="OpenSSL 3.5.9 ")
        summary["observers"] = {"rust": identity(driver), "evp": identity(evp)}
        temporary = tempfile.TemporaryDirectory(prefix="private-test-keys-", dir=work)
        private_root = Path(temporary.name)
        try:
            public = work / "public-fixtures"
            public.mkdir()
            messages = {}
            for length in MESSAGE_LENGTHS:
                msg = public / ("message-" + str(length) + ".bin")
                raw = bytes((i * 29 + 17) % 256 for i in range(length))
                msg.write_bytes(raw)
                changed = public / ("wrong-message-" + str(length) + ".bin")
                changed.write_bytes(bytes([raw[0] ^ 1]) + raw[1:] if raw else b"\x00")
                public_files.extend((msg, changed))
                messages[length] = (msg, changed)
            for suite, (pk_bytes, sig_bytes, der_hex) in PARAMETERS.items():
                prefix_der = bytes.fromhex(der_hex)
                private_key = private_root / (str(suite) + ".pem")
                openssl_der = public / (str(suite) + "-openssl-public.der")
                openssl_raw = public / (str(suite) + "-openssl-public.raw")
                observer.command(f"keygen-{suite}", [openssl, "genpkey", "-provider", "default", "-algorithm", f"ML-DSA-{suite}", "-out", private_key])
                observer.command(f"public-key-{suite}", [openssl, "pkey", "-provider", "default", "-in", private_key,
                                 "-pubout", "-outform", "DER", "-out", openssl_der])
                der = openssl_der.read_bytes()
                require(len(der) == len(prefix_der) + pk_bytes and der.startswith(prefix_der), "noncanonical generated SPKI")
                openssl_raw.write_bytes(der[len(prefix_der):])
                public_files.extend((openssl_der, openssl_raw))
                wrong_key = public / (str(suite) + "-wrong-public.raw")
                wrong_sig = public / (str(suite) + "-wrong-key-empty.sig")
                wrong_der = public / (str(suite) + "-wrong-public.der")
                observer.command(f"alternate-public-key-{suite}", [driver, "emit", suite, 67, messages[0][0], wrong_key, wrong_sig, "public-fixture-only"])
                wrong_der.write_bytes(prefix_der + wrong_key.read_bytes())
                public_files.extend((wrong_key, wrong_der, wrong_sig))
                require(wrong_key.read_bytes() != openssl_raw.read_bytes(), "wrong-key fixture unexpectedly aliases the signer")
                for length in MESSAGE_LENGTHS:
                    tag = f"{suite}-{length}"
                    msg, wrong_msg = messages[length]
                    rust_key = public / (tag + "-rust-public.raw")
                    rust_der = public / (tag + "-rust-public.der")
                    rust_sig = public / (tag + "-rust.sig")
                    observer.command("rust-sign-" + tag, [driver, "emit", suite, 66, msg, rust_key, rust_sig, "public-fixture-only"])
                    require(rust_key.stat().st_size == pk_bytes and rust_sig.stat().st_size == sig_bytes, "Rust output length mismatch")
                    require(wrong_key.read_bytes() != rust_key.read_bytes(), "wrong key aliases Rust signer")
                    rust_der.write_bytes(prefix_der + rust_key.read_bytes())
                    late_rust = public / (tag + "-rust-late-invalid.sig")
                    signature = rust_sig.read_bytes()
                    late_rust.write_bytes(bytes([signature[0] ^ 1]) + signature[1:])
                    public_files.extend((rust_key, rust_der, rust_sig, late_rust))
                    interface = "openssl-evp" if length == 0 else "openssl-cli"
                    def verify_openssl(key, message, signature, context=b""):
                        if length == 0:
                            return [evp, "verify", suite, key, message, signature, context.hex() or "-"]
                        return [openssl, "pkeyutl", "-provider", "default", "-verify", "-rawin", "-pubin",
                                "-keyform", "DER", "-inkey", key, "-in", message, "-sigfile", signature] \
                            + (["-pkeyopt", "hexcontext-string:" + context.hex()] if context else [])
                    for kind, key, message, signature, context in [
                        ("valid", rust_der, msg, rust_sig, b""),
                        ("wrong-message", rust_der, wrong_msg, rust_sig, b""),
                        ("wrong-key", wrong_der, msg, rust_sig, b""),
                        ("late-invalid-signature", rust_der, msg, late_rust, b""),
                        ("nonempty-context", rust_der, msg, rust_sig, CONTEXT),
                    ]:
                        observer.check(f"rust-to-openssl-{kind}-{tag}", verify_openssl(key, message, signature, context),
                                       suite=suite, length=length, direction="rust-to-openssl", kind=kind, interface=interface)
                    def sign_openssl(destination, context=b""):
                        if length == 0:
                            return [evp, "sign", suite, private_key, msg, destination, context.hex() or "-"]
                        return [openssl, "pkeyutl", "-provider", "default", "-sign", "-rawin", "-inkey", private_key,
                                "-in", msg, "-out", destination] \
                            + (["-pkeyopt", "hexcontext-string:" + context.hex()] if context else [])
                    openssl_sig = public / (tag + "-openssl.sig")
                    context_sig = public / (tag + "-openssl-context.sig")
                    observer.command("openssl-sign-" + tag, sign_openssl(openssl_sig))
                    observer.command("openssl-context-sign-" + tag, sign_openssl(context_sig, CONTEXT))
                    require(openssl_sig.stat().st_size == context_sig.stat().st_size == sig_bytes, "OpenSSL signature length mismatch")
                    late_openssl = public / (tag + "-openssl-late-invalid.sig")
                    signature = openssl_sig.read_bytes()
                    late_openssl.write_bytes(bytes([signature[0] ^ 1]) + signature[1:])
                    public_files.extend((openssl_sig, context_sig, late_openssl))
                    for kind, key, message, signature in [
                        ("valid", openssl_raw, msg, openssl_sig),
                        ("wrong-message", openssl_raw, wrong_msg, openssl_sig),
                        ("wrong-key", wrong_key, msg, openssl_sig),
                        ("late-invalid-signature", openssl_raw, msg, late_openssl),
                        ("nonempty-context", openssl_raw, msg, context_sig),
                    ]:
                        observer.check(f"openssl-to-rust-{kind}-{tag}", [driver, "verify", suite, message, key, signature],
                                       suite=suite, length=length, direction="openssl-to-rust", kind=kind, interface="rust-candidate")
                    if length == 0:
                        for operation, command in [
                            ("verify", [openssl, "pkeyutl", "-provider", "default", "-verify", "-rawin", "-pubin", "-keyform", "DER", "-inkey", rust_der, "-in", msg, "-sigfile", rust_sig]),
                            ("sign", [openssl, "pkeyutl", "-provider", "default", "-sign", "-rawin", "-inkey", private_key, "-in", msg, "-out", private_root / (str(suite) + "-cli-empty.sig")]),
                        ]:
                            label = f"cli-empty-{operation}-{suite}"
                            observer.command(label, command, expected=1, token="Could not allocate 0 bytes for oneshot sign/verify buffer")
                            cli_limits.append({"label": label, "parameter": suite, "operation": operation,
                                               "outcome": "frontend_refused_before_signature_operation",
                                               "counted_as_cryptographic_rejection": False})
            fixtures = [{"name": p.name, "bytes": p.stat().st_size, "sha256": sha256(p),
                         "base64": base64.b64encode(p.read_bytes()).decode()} for p in public_files]
            write_json(output / "public-fixtures.json", fixtures)
            require(len(observer.checks) == 80 and sum(x["kind"] == "valid" for x in observer.checks) == 16
                    and len(cli_limits) == 4, "incomplete finite interoperability matrix")
            require(identity(driver) == summary["observers"]["rust"] and identity(evp) == summary["observers"]["evp"], "observer binary changed")
            require(identity(crypto) == build["crypto_library"] and identity(zeroize) == build["zeroize_library"], "built candidate library changed")
            require(identity(openssl) == summary["provider"]["openssl"] and identity(libcrypto) == summary["provider"]["libcrypto"], "provider changed")
            require(all(identity(output / name) == observed for name, observed in summary["observation_sources"].items()), "observer source snapshot changed")
            summary["source_after"] = source_identity(repo, args.commit)
            require(summary["source_after"] == summary["source_before"], "source identity changed during observations")
            summary["public_fixtures"] = identity(output / "public-fixtures.json")
            summary["status"] = "FINITE_INTEROPERABILITY_OBSERVED_HOLD"
        finally:
            temporary.cleanup()
            summary["private_test_key_directory_removed"] = not private_root.exists()
    except (Exception, KeyboardInterrupt) as caught:
        error = caught
        summary["status"] = "FAILED_OR_INCOMPLETE_HOLD"
        summary["failure"] = {"type": type(caught).__name__, "message": str(caught)}
    finally:
        if public is not None and public.exists():
            fixtures = []
            for p in sorted(public.iterdir()):
                require(p.is_file() and not p.is_symlink() and p.suffix in (".bin", ".der", ".raw", ".sig"),
                        "unexpected material in public fixture directory")
                fixtures.append({"name": p.name, "bytes": p.stat().st_size, "sha256": sha256(p),
                                 "base64": base64.b64encode(p.read_bytes()).decode()})
            write_json(output / "public-fixtures.json", fixtures)
            summary["public_fixtures"] = identity(output / "public-fixtures.json")
            summary["public_fixtures_retained_on_partial_failure"] = True
        summary["commands_recorded"] = len(observer.commands) if observer else 0
        summary["completed_checks"] = observer.checks if observer else []
        summary["cli_empty_message_limitations"] = cli_limits
        summary["valid_checks_observed"] = sum(x["kind"] == "valid" for x in summary["completed_checks"])
        summary["invalid_signature_checks_observed"] = sum(x["kind"] != "valid" for x in summary["completed_checks"])
        summary["finished_utc"] = datetime.now(timezone.utc).isoformat()
        write_json(output / "manifest.json", summary)
    print(json.dumps({k: summary[k] for k in ("status", "source_commit", "commands_recorded", "valid_checks_observed", "invalid_signature_checks_observed")}, sort_keys=True))
    if error is not None:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
