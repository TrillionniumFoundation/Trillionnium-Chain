//! Actual native provenance, original settlement failure controls and TCP replay.
//! These component controls do not claim the fixed Host F0 service target.
use super::*;

fn identity(n: u8) -> DevelopmentIdentity {
    DevelopmentIdentity::from_secret_hex(&hex::encode([n; 32])).unwrap()
}
fn fixture() -> (
    tempfile::TempDir,
    Settings,
    Node,
    crate::Packet,
    crate::Packet,
    crate::Error,
) {
    let directory = tempfile::tempdir().unwrap();
    let now = super::super::now().unwrap();
    let settings = Settings::development(Some(now - 100)).unwrap();
    let mut node =
        Node::open_with_authenticated_state(directory.path(), settings.clone(), 2).unwrap();
    node.enable_pool(crate::PoolLimits::default()).unwrap();
    let valid = node
        .make(
            settings.genesis(),
            vec![],
            crate::development_public(0).unwrap(),
            now - 90,
            4096,
        )
        .unwrap();
    let mut invalid = valid.clone();
    invalid.header.state[0] ^= 1;
    let (a, b) = crate::maintenance();
    let prover = trnm_crypto_primitives::pon_work::PreparedTask::new(&a, &b).unwrap();
    let mut found = false;
    for nonce in 0..4096 {
        invalid.header.nonce = nonce;
        invalid.proof = prover.prove(invalid.header.challenge()).unwrap();
        if WorkCheckedPacket::verify(invalid.clone()).is_ok() {
            found = true;
            break;
        }
    }
    assert!(found);
    let error = node
        .admit_work_checked(WorkCheckedPacket::verify(invalid.clone()).unwrap(), now)
        .err()
        .unwrap();
    assert_eq!(error.to_string(), "ROOT");
    (directory, settings, node, valid, invalid, error)
}
fn body(packet: &crate::Packet) -> String {
    let bytes = serde_json::to_vec(&Request::Submit {
        packet: hex::encode(packet.encode().unwrap()),
    })
    .unwrap();
    hex::encode(Sha256::digest(bytes))
}
fn server() -> PublicServer {
    PublicServer::new(
        identity(71),
        PublicPolicy::new(8, Duration::from_secs(2)).unwrap(),
    )
    .unwrap()
}
fn pending(digest: Hash) -> PendingNativeRootBodyDelay {
    PendingNativeRootBodyDelay {
        digest,
        deadline: Instant::now() + Duration::from_secs(10),
        stop: Arc::new(AtomicBool::new(false)),
        cancelled: Arc::new(AtomicBool::new(false)),
    }
}

#[test]
fn actual_native_provenance_requires_complete_known_original_cpu_settlement() {
    // Native provenance is produced by a real checked execution above. This
    // isolated settlement test makes no claim to charge that earlier execution
    // to the separately acquired original CPU permit below.
    let (_directory, settings, _node, _valid, invalid, error) = fixture();
    let text = body(&invalid);
    let digest = error.completed_native_root_body(&settings, &text).unwrap();
    for failure in 0..6 {
        let server = server();
        let metrics = Mutex::new(PublicMetrics::default());
        let permit = PaidMutationCpuPermit::acquire(&server, &metrics).unwrap();
        let measurement = MutationCpuMeasurement::for_permit(Some(&permit));
        match failure {
            0 => {}
            1 => measurement.unavailable.set(true),
            2 => server.fail_next_cpu_finish.store(true, Ordering::Release),
            3 => server
                .fail_next_live_cpu_finish
                .store(true, Ordering::Release),
            4 => measurement.workers.unknown(),
            5 => {
                let _ = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                    let _guard = server.mutation_cpu.lock().unwrap();
                    panic!("intentional original budget lock poison");
                }));
            }
            _ => unreachable!(),
        }
        permit.finish_observed_with_root_delay(
            &measurement,
            &server,
            &metrics,
            None,
            Some(pending(digest)),
        );
        let hint = server.body_refusals.retry_at(&text, Instant::now());
        assert_eq!(hint.is_some(), failure == 0, "failure={failure}");
        if failure != 0 {
            assert!(metrics.lock().unwrap().mutation_cpu_clock_failures > 0);
        }
    }
}

#[test]
fn final_cancel_stop_and_expiry_cannot_publish_completed_native_body_delay() {
    let (_directory, settings, _node, _valid, invalid, error) = fixture();
    let text = body(&invalid);
    let digest = error.completed_native_root_body(&settings, &text).unwrap();
    for refusal in 0..3 {
        let server = server();
        let metrics = Mutex::new(PublicMetrics::default());
        let permit = PaidMutationCpuPermit::acquire(&server, &metrics).unwrap();
        let measurement = MutationCpuMeasurement::for_permit(Some(&permit));
        let mut hint = pending(digest);
        match refusal {
            0 => hint.cancelled.store(true, Ordering::Release),
            1 => hint.stop.store(true, Ordering::Release),
            2 => hint.deadline = Instant::now(),
            _ => unreachable!(),
        }
        permit.finish_observed_with_root_delay(&measurement, &server, &metrics, None, Some(hint));
        assert_eq!(metrics.lock().unwrap().mutation_cpu_clock_failures, 0);
        assert_eq!(server.body_refusals.retry_at(&text, Instant::now()), None);
    }
}

#[test]
fn real_tcp_root_retry_reexecutes_and_failed_output_never_creates_delay() {
    for fault in 0..3 {
        let fail_output = fault == 1;
        let fail_write = fault == 2;
        let (_directory, settings, node, valid, invalid, _error) = fixture();
        let owner = Arc::new(Mutex::new(node));
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let address = listener.local_addr().unwrap();
        let stop = Arc::new(AtomicBool::new(false));
        let server = server();
        server
            .fail_next_output
            .store(fail_output, Ordering::Release);
        server
            .fail_next_output_write
            .store(fail_write, Ordering::Release);
        let policy = server.policy;
        let observed = Arc::new(Mutex::new(PublicMetrics::default()));
        let serving_owner = Arc::clone(&owner);
        let serving_stop = Arc::clone(&stop);
        let serving_metrics = Arc::clone(&observed);
        let worker = thread::spawn(move || {
            serve_public_protected_v3_with_metrics(
                listener,
                serving_owner,
                Duration::from_secs(10),
                serving_stop,
                server,
                serving_metrics,
            )
            .unwrap()
        });
        let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            let call = |packet: &crate::Packet| {
                call_public_protected_v3(
                    address,
                    &Request::Submit {
                        packet: hex::encode(packet.encode().unwrap()),
                    },
                    &settings,
                    identity(71).public_key(),
                    &identity(80),
                    policy,
                )
            };
            let first = call(&invalid);
            if fail_output || fail_write {
                assert!(first.is_err());
            } else {
                let first = first.unwrap();
                assert!(!first.ok);
                assert_eq!(first.value["error"], "ROOT");
            }
            let wait_before = observed.lock().unwrap().pending_grant_wait_ns;
            let repeated = call(&invalid).unwrap();
            assert!(!repeated.ok);
            assert_eq!(repeated.value["error"], "ROOT");
            let waited = observed.lock().unwrap().pending_grant_wait_ns - wait_before;
            // This is the actual local grant stage with no competing client,
            // not a fixed-Host performance qualification.
            if fail_output || fail_write {
                assert!(
                    waited < 200_000_000,
                    "failed output fault={fault} wait={waited}"
                );
            } else {
                assert!(
                    waited >= 300_000_000,
                    "original bounded delay wait={waited}"
                );
            }
            assert_eq!(
                owner.lock().unwrap().read_active().unwrap().0,
                settings.genesis()
            );
            assert!(call(&valid).unwrap().ok);
        }));
        stop.store(true, Ordering::Release);
        let metrics = worker.join().unwrap();
        outcome.unwrap();
        assert_eq!(metrics.work_started, 3);
        assert_eq!(metrics.work_finished, 3);
        assert_eq!(metrics.work_failed, 0);
        assert_eq!(metrics.completed_submit, 1);
        assert_eq!(metrics.executor_refusals, 2);
        assert_eq!(metrics.mutation_cpu_reservations, 3);
        assert_eq!(metrics.mutation_cpu_clock_failures, 0);
        assert!(metrics.mutation_cpu_charged_ns > 0);
        assert_eq!(
            metrics.mutation_full_work_cpu_ns + metrics.mutation_dispatch_excluding_work_cpu_ns,
            metrics.mutation_cpu_charged_ns
        );
        assert_eq!(metrics.paid_body_reserved_bytes_after_shutdown, 0);
    }
}
