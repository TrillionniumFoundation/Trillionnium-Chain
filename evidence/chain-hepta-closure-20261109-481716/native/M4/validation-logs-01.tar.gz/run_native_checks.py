"""Record one fixed-source library check and conditional strict Clippy run."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import shutil
import signal
import subprocess
import sys
import time

REPO = Path('/home/qian-qi/chain-hepta-481716-native-check/source')
BASE = Path('/home/qian-qi/chain-hepta-481716-native-check')
TARGET = BASE / 'target'
RECEIPTS = BASE / 'native-checks'
EXPECTED_HEAD = 'e4e4a8e049915ba09d9e97444b4709ce8769ce81'
CARGO = '/home/qian-qi/.cargo/bin/cargo'
MIN_START_FREE = 2_000_000_000
STOP_FREE = 256 * 1024 * 1024
ownership = json.loads((BASE / 'ownership.json').read_text())
assert ownership['directory_created_from_absent'] and ownership['expected_head'] == EXPECTED_HEAD
BASE.mkdir(exist_ok=True)
RECEIPTS.mkdir(exist_ok=True)
number = 1
while (RECEIPTS / f'attempt-{number:03d}').exists():
    number += 1
OUT = RECEIPTS / f'attempt-{number:03d}'
OUT.mkdir()
environment = dict(os.environ)
environment['CARGO_TARGET_DIR'] = str(TARGET)
environment['PYTHONDONTWRITEBYTECODE'] = '1'
commands = []
capacity_problem = False
target_created_here = False


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def source():
    paths = ['trillionnium/Cargo.toml', 'trillionnium/Cargo.lock',
             'config/portability-inventory-v1.json', 'scripts/project-preflight.sh']
    paths += [str(p.relative_to(REPO)) for p in sorted((REPO / 'trillionnium/crates').glob('*/Cargo.toml'))]
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status_porcelain': git('status', '--porcelain=v1', '--untracked-files=all').splitlines(),
            'source_and_lock_files': {name: {'bytes': (REPO / name).stat().st_size,
                                            'sha256': hashlib.sha256((REPO / name).read_bytes()).hexdigest()}
                                      for name in paths}}


def hardware():
    mem = Path('/proc/meminfo').read_text().splitlines()
    cpu = Path('/proc/cpuinfo').read_text().splitlines()
    cg = {}
    for name in ('cpu.max', 'cpuset.cpus.effective', 'memory.max', 'memory.current', 'pids.max'):
        p = Path('/sys/fs/cgroup') / name
        if p.is_file():
            cg[name] = p.read_text().strip()
    return {'observed_utc': now(), 'uname': list(os.uname()), 'platform': platform.platform(),
            'logical_cpu_count': os.cpu_count(), 'cpu_affinity': sorted(os.sched_getaffinity(0)),
            'cpu_models': sorted({row.split(':', 1)[1].strip() for row in cpu if row.startswith('model name')}),
            'memory': [row for row in mem if row.startswith(('MemTotal:', 'MemAvailable:', 'SwapTotal:', 'SwapFree:'))],
            'cgroup': cg, 'filesystem_bytes': dict(zip(('total', 'used', 'free'), shutil.disk_usage(BASE)))}


def run(name, argv, watch_disk=False):
    global capacity_problem
    stdout_path = OUT / (name + '.stdout.log')
    stderr_path = OUT / (name + '.stderr.log')
    row = {'name': name, 'argv': argv, 'cwd': str(REPO), 'started_utc': now(),
           'environment_overrides': {'CARGO_TARGET_DIR': str(TARGET), 'PYTHONDONTWRITEBYTECODE': '1'},
           'stdout': stdout_path.name, 'stderr': stderr_path.name,
           'disk_before': dict(zip(('total', 'used', 'free'), shutil.disk_usage(BASE)))}
    commands.append(row)
    save('commands.json', commands)
    start = time.monotonic_ns()
    samples = []
    termination = None
    print(json.dumps({'stage': name, 'status': 'STARTED', 'out': str(OUT), 'free_bytes': row['disk_before']['free']}), flush=True)
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=REPO, env=environment, stdout=stdout, stderr=stderr,
                                   start_new_session=True)
        while process.poll() is None:
            free = shutil.disk_usage(BASE).free
            samples.append({'elapsed_ns': time.monotonic_ns() - start, 'free_bytes': free})
            limit_seconds = 1200 if name in ('cargo-check', 'cargo-clippy') else 60
            if time.monotonic_ns() - start > limit_seconds * 1_000_000_000:
                termination = {'reason': 'compilation-stage-timeout', 'seconds': limit_seconds, 'native_service_deadline': False}
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                break
            if watch_disk and free < STOP_FREE:
                capacity_problem = True
                termination = {'reason': 'disk-free-operational-floor', 'free_bytes': free,
                               'floor_bytes': STOP_FREE, 'native_service_deadline': False}
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                break
            time.sleep(1)
        returncode = process.wait()
    stderr_bytes = stderr_path.read_bytes()
    if b'No space left on device' in stderr_bytes or b'os error 28' in stderr_bytes:
        capacity_problem = True
    row.update(returncode=returncode, completed_utc=now(), elapsed_ns=time.monotonic_ns() - start,
               termination=termination, stdout_bytes=stdout_path.stat().st_size,
               stderr_bytes=stderr_path.stat().st_size,
               stdout_sha256=hashlib.sha256(stdout_path.read_bytes()).hexdigest(),
               stderr_sha256=hashlib.sha256(stderr_bytes).hexdigest(),
               disk_after=dict(zip(('total', 'used', 'free'), shutil.disk_usage(BASE))))
    save(name + '.resource-samples.json', samples)
    save('commands.json', commands)
    print(json.dumps({'stage': name, 'status': 'COMPLETED', 'returncode': returncode,
                      'free_bytes': row['disk_after']['free'], 'termination': termination}), flush=True)
    return row


started = now()
summary = {'schema': 'fixed-m4-native-library-validation-v1', 'started_utc': started,
           'expected_head': EXPECTED_HEAD, 'target_directory': str(TARGET),
           'minimum_start_free_bytes': MIN_START_FREE, 'capacity_stop_free_bytes': STOP_FREE,
           'scope': 'cargo check/clippy only; workspace all-features libraries; offline locked; two jobs',
           'native_daemon_executed': False, 'host_four_second_service_executed': False,
           'thirty_second_campaign_executed': False, 'workspace_tests_executed': False,
           'proof_generation_or_verification_executed': False, 'source_edited': False,
           'check_status': 'NOT_STARTED', 'clippy_status': 'NOT_STARTED'}
try:
    before = source()
    save('source-before.json', before)
    save('hardware-before.json', hardware())
    save('environment.json', {'python': sys.version, 'cargo': CARGO, 'requested_toolchain': '1.95.0',
                              'CARGO_TARGET_DIR': str(TARGET), 'jobs': 2,
                              'inherited_build_settings': {name: environment.get(name) for name in
                                  ('RUSTC', 'RUSTC_WRAPPER', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS',
                                   'CARGO_INCREMENTAL', 'RISC0_SKIP_BUILD', 'RISC0_USE_DOCKER')}})
    assert before['head'] == EXPECTED_HEAD, 'fixed M4 HEAD changed'
    assert not before['status_porcelain'], 'fixed source working tree is not clean'
    assert not TARGET.exists(), 'exclusive target must not preexist on this first attempt'
    preflight = run('preflight', ['bash', 'scripts/project-preflight.sh'])
    assert preflight['returncode'] == 0, 'preflight failed'
    cargo_version = run('cargo-version', [CARGO, '+1.95.0', '--version', '--verbose'])
    assert cargo_version['returncode'] == 0, 'requested Cargo toolchain unavailable'
    rustc_version = run('rustc-version', ['/home/qian-qi/.cargo/bin/rustc', '+1.95.0', '--version', '--verbose'])
    assert rustc_version['returncode'] == 0, 'requested rustc toolchain unavailable'
    initial_free = shutil.disk_usage(BASE).free
    summary['check_start_free_bytes'] = initial_free
    if initial_free < MIN_START_FREE:
        summary['check_status'] = 'NOT_STARTED_INSUFFICIENT_DISK'
        summary['clippy_status'] = 'NOT_STARTED_CHECK_NOT_RUN'
    else:
        TARGET.mkdir()
        target_created_here = True
        save('target-ownership.json', {'created_by_this_attempt': True, 'path': str(TARGET),
                                       'expected_head': EXPECTED_HEAD, 'created_utc': now()})
        args = ['--offline', '--locked', '--workspace', '--all-features', '--lib',
                '--manifest-path', 'trillionnium/Cargo.toml', '-j2']
        checked = run('cargo-check', [CARGO, '+1.95.0', 'check', *args], watch_disk=True)
        summary['check_status'] = 'PASS' if checked['returncode'] == 0 else 'FAIL'
        if capacity_problem:
            summary['check_status'] = 'INCOMPLETE_CAPACITY_LIMIT'
        if checked['returncode'] == 0 and not capacity_problem:
            clippy_free = shutil.disk_usage(BASE).free
            summary['clippy_start_free_bytes'] = clippy_free
            if clippy_free < MIN_START_FREE:
                summary['clippy_status'] = 'NOT_STARTED_INSUFFICIENT_DISK'
            else:
                lint = run('cargo-clippy', [CARGO, '+1.95.0', 'clippy', *args, '--', '-D', 'warnings'], watch_disk=True)
                summary['clippy_status'] = 'PASS' if lint['returncode'] == 0 else 'FAIL'
                if capacity_problem:
                    summary['clippy_status'] = 'INCOMPLETE_CAPACITY_LIMIT'
        else:
            summary['clippy_status'] = 'NOT_STARTED_CHECK_NOT_PASSED'
except Exception as error:
    summary['runner_error'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    if capacity_problem and target_created_here and TARGET.exists():
        assert not TARGET.is_symlink() and TARGET.resolve() == BASE.resolve() / 'target'
        before_cleanup = shutil.disk_usage(BASE).free
        shutil.rmtree(TARGET)
        summary['capacity_cleanup'] = {'removed_only_owned_target': str(TARGET),
                                       'free_before': before_cleanup, 'free_after': shutil.disk_usage(BASE).free,
                                       'logs_preserved': True}
    after = source()
    save('source-after.json', after)
    save('hardware-after.json', hardware())
    summary['source_before_after_equal'] = after == before
    summary['completed_utc'] = now()
    summary['commands'] = [{key: row.get(key) for key in ('name', 'returncode', 'elapsed_ns', 'stdout', 'stderr')}
                           for row in commands]
    summary['native_library_check_and_clippy_passed'] = (
        summary['check_status'] == 'PASS' and summary['clippy_status'] == 'PASS'
        and summary['source_before_after_equal'] and 'runner_error' not in summary)
    save('summary.json', summary)
    files = [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
             for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'FILES.json']
    save('FILES.json', {'files': files, 'excludes_self': True})
    print(json.dumps({'out': str(OUT), 'summary': summary}, indent=2), flush=True)
sys.exit(0 if summary['native_library_check_and_clippy_passed'] else 2)
