#!/usr/bin/env python3
"""External runner; repository recorder owns source checks. No repository writes."""
import hashlib,json,os,re,shutil,subprocess,sys,time,traceback
from pathlib import Path
ROOT=Path("/home/qq/work/chain-pon-joint-58fd59-20261109")
TARGET=Path("/home/qq/work/chain-pon-joint-58fd59-target-20261109")
TC=Path("/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu")
HEAD,TREE,out_arg=sys.argv[1:]
assert re.fullmatch("[0-9a-f]{40}",HEAD) and re.fullmatch("[0-9a-f]{40}",TREE)
OUT=Path(out_arg)
assert OUT.is_absolute() and OUT.parent==Path("/home/qq/work") and OUT.name.startswith("chain-pon-joint-58fd59-native-")
OUT.mkdir(exist_ok=False)
shutil.copyfile(__file__,OUT/"runner.py")
ENV=dict(os.environ)
STEPS=[]
ERROR=None
SQLITE={"qualified":False,"outputs":[],"scope":"observed-build-output-only"}
def write(name,value):
    (OUT/name).write_text(json.dumps(value,sort_keys=True,indent=2)+"\n")
def digest(path):
    with path.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def capture(argv):
    p=subprocess.run(argv,cwd=ROOT,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
    return {"argv":argv,"exit_code":p.returncode,"stdout":p.stdout.decode(errors="replace"),"stderr":p.stderr.decode(errors="replace")}
def identity():
    r={n:capture(["git",*a]) for n,a in [("head",["rev-parse","HEAD"]),("tree",["rev-parse","HEAD^{tree}"]),("status",["status","--porcelain=v1"])]}
    assert all(x["exit_code"]==0 for x in r.values())
    assert r["head"]["stdout"].strip()==HEAD and r["tree"]["stdout"].strip()==TREE and r["status"]["stdout"]==""
    return r
def run(label,cmd,extra=None):
    argv=["/usr/bin/python3","scripts/ci/record_pq_native_command.py","--kind","head","--candidate",HEAD,"--tested",HEAD,"--label",label,"--output",str(OUT),"--",*cmd]
    env=dict(ENV);env.update(extra or {})
    start=time.monotonic_ns()
    print(json.dumps({"event":"start","label":label,"argv":cmd}),flush=True)
    with (OUT/(label+".recorder.stdout")).open("xb") as so,(OUT/(label+".recorder.stderr")).open("xb") as se:
        p=subprocess.run(argv,cwd=ROOT,env=env,stdout=so,stderr=se,check=False)
    rp=OUT/(label+".json");lp=OUT/(label+".log")
    receipt=json.loads(rp.read_text()) if rp.exists() else {}
    log=lp.read_text(errors="replace") if lp.exists() else ""
    before,after=receipt.get("before"),receipt.get("after")
    passed=(p.returncode==0 and receipt.get("status")=="command_succeeded" and receipt.get("exit_code")==0
        and before is not None and before==after and before.get("tested_commit")==HEAD and before.get("tested_tree")==TREE
        and lp.exists() and receipt.get("log_sha256")==digest(lp))
    binaries=[]
    for name in re.findall(r"(?:Executable|Running)[^\n]*?\(([^)]+)\)",log):
        path=Path(name)
        if not path.is_absolute():path=ROOT/path
        path=path.resolve()
        if path.is_relative_to(TARGET) and path.is_file():
            item={"path":str(path),"size":path.stat().st_size,"sha256":digest(path)}
            if item not in binaries:binaries.append(item)
    result={"label":label,"argv":cmd,"recorder_argv":argv,"recorder_exit_code":p.returncode,"elapsed_ns":time.monotonic_ns()-start,
        "receipt_status":receipt.get("status"),"receipt_exit_code":receipt.get("exit_code"),"source_and_command_pass":passed,
        "native_executables":binaries,"extra_environment":extra or {}}
    STEPS.append(result);write(label+".observation.json",result);write("progress.json",{"head":HEAD,"steps":STEPS})
    print(json.dumps({"event":"complete",**result}),flush=True)
    return result,log
def roster_check(result,log,expected,ignored):
    names=re.findall(r"^test ([A-Za-z0-9_:]+) \.\.\.(?:[^\n]*)$",log,re.M)
    summaries=re.findall(r"^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;",log,re.M)
    s=summaries[0] if len(summaries)==1 else None
    passed=(s is not None and s[0]=="ok" and int(s[1])==len(expected)-ignored and int(s[2])==0 and int(s[3])==ignored
        and int(s[4])==0 and sorted(names)==sorted(expected) and len(set(names))==len(names))
    result["roster"]={"pass":passed,"expected_names":sorted(expected),"expected_ignored":ignored,"observed_names":names,"summaries":summaries,
        "scope":"named-harness-transcript-and-summary-only"}
    write(result["label"]+".observation.json",result);write("progress.json",{"head":HEAD,"steps":STEPS})
    print(json.dumps({"event":"roster","label":result["label"],"pass":passed,"total":len(expected),"ignored":ignored}),flush=True)
try:
    keys=["RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUST_TEST_THREADS"]
    keys += [k for k in ENV if k.startswith("CARGO_PROFILE_RELEASE_")]
    forbidden={k:ENV[k] for k in keys if ENV.get(k)}
    write("inherited-flag-check.json",{"unexpected":forbidden})
    if forbidden:raise RuntimeError("unexpected inherited compiler or test overrides")
    ENV.update(CARGO_HOME="/home/qq/.cargo",RUSTUP_HOME="/home/qq/.rustup",CARGO_TARGET_DIR=str(TARGET),CARGO_BUILD_JOBS="1",
        RUSTC=str(TC/"bin/rustc"),RUSTDOC=str(TC/"bin/rustdoc"),LD_LIBRARY_PATH=str(TC/"lib"),
        OPENSSL_LIB_DIR="/usr/lib/x86_64-linux-gnu",OPENSSL_INCLUDE_DIR="/usr/include",PATH=str(TC/"bin")+":"+ENV.get("PATH",""))
    allowed=["PATH","CARGO_HOME","RUSTUP_HOME","CARGO_TARGET_DIR","CARGO_BUILD_JOBS","CARGO_INCREMENTAL","RUSTC","RUSTDOC","RUSTFLAGS",
        "CARGO_ENCODED_RUSTFLAGS","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUST_TEST_THREADS","LD_LIBRARY_PATH","LD_PRELOAD",
        "OPENSSL_DIR","OPENSSL_LIB_DIR","OPENSSL_INCLUDE_DIR","OPENSSL_STATIC","CC","CFLAGS","CPPFLAGS","CXX","CXXFLAGS","AR","ARFLAGS",
        "LIBRARY_PATH","CPATH","C_INCLUDE_PATH","LIBSQLITE3_FLAGS","LIBSQLITE3_SYS_USE_PKG_CONFIG"]
    inventory={"source":identity(),"environment":{k:ENV.get(k) for k in allowed},"rustc":capture([ENV["RUSTC"],"-vV"]),
        "cargo":capture([str(TC/"bin/cargo"),"-Vv"]),"openssl_inventory":capture(["/usr/bin/openssl","version","-a"]),
        "rustc_sha256":digest(TC/"bin/rustc"),"cargo_sha256":digest(TC/"bin/cargo"),"kernel":list(os.uname()),"cpu_count":os.cpu_count(),
        "uid":os.getuid(),"gid":os.getgid(),"pid":os.getpid(),"proc_self_stat":Path("/proc/self/stat").read_text(),
        "boot_id_sha256":digest(Path("/proc/sys/kernel/random/boot_id")),"public_resource_contract_executed":False,
        "openssl_inventory_does_not_assert_active_default_backend":True}
    write("environment.json",inventory)
    if "rustc 1.95.0 " not in inventory["rustc"]["stdout"]:raise RuntimeError("wrong rustc version")
    cargo=str(TC/"bin/cargo")
    prefix=[cargo,"test","--manifest-path","trillionnium/Cargo.toml","--release","--locked","--offline","--jobs","1","-p","trnm-pon-node"]
    r,_=run("preflight",["bash","scripts/project-preflight.sh"])
    if not r["source_and_command_pass"]:raise RuntimeError("preflight failed")
    r,_=run("default-cargo-metadata",[cargo,"metadata","--manifest-path","trillionnium/Cargo.toml","--format-version","1","--locked","--offline"])
    if not r["source_and_command_pass"]:raise RuntimeError("default metadata failed")
    r,_=run("native-lib-build",prefix+["--lib","--no-run"])
    for p in sorted((TARGET/"release/build").glob("trnm-sqlite-io-boundary-*/output")):
        body=p.read_text(errors="replace");name="sqlite-build-"+p.parent.name+".log"
        shutil.copyfile(p,OUT/name)
        SQLITE["outputs"].append({"path":str(p),"copy":name,"sha256":digest(p),"unqualified":"UNQUALIFIED" in body,
            "layout_cfg":"cargo:rustc-cfg=trnm_sqlite_layout_witness\n" in body,
            "build_fence":re.findall(r"^cargo:rustc-env=TRNM_SQLITE3_BUILD_FENCE=(.+)$",body,re.M)})
    SQLITE["qualified"]=(len(SQLITE["outputs"])==1 and all(not p["unqualified"] and p["layout_cfg"] and len(p["build_fence"])==1 for p in SQLITE["outputs"]))
    write("sqlite-build-observation.json",SQLITE)
    if not r["source_and_command_pass"]:raise RuntimeError("native lib build failed; no fallback executable permitted")
    if not r["native_executables"]:raise RuntimeError("native build executable identity missing")
    if not SQLITE["qualified"]:raise RuntimeError("original SQLite build fence not observed qualified")
    r,log=run("native-lib-roster",prefix+["--lib","--","--list","--format","terse"])
    if not r["source_and_command_pass"]:raise RuntimeError("native roster listing failed")
    roster=re.findall(r"^([A-Za-z0-9_:]+): test$",log,re.M)
    if not roster or len(set(roster))!=len(roster):raise RuntimeError("missing or duplicate compiled test roster")
    write("compiled-lib-roster.json",roster)
    suites=[("history-deadline","ingress::history_import::tests::deadline_controls::",10,0),
        ("public-growth","ingress::public_v3::growth::tests::",7,0),("store-growth","store::growth::tests::",79,2),
        ("consensus","consensus::tests::",10,0)]
    for label,filt,total,ignored in suites:
        names=[n for n in roster if n.startswith(filt)]
        if len(names)!=total:raise RuntimeError(label+": compiled roster count differs: "+str(len(names)))
        r,log=run(label,prefix+["--lib",filt,"--","--nocapture"])
        roster_check(r,log,names,ignored)
    r,log=run("daa-joint-consensus",prefix+["--test","daa_joint_consensus","--","--nocapture"],
        {"TRNM_JOINT_DAA_EVIDENCE_DIR":str(OUT/"joint-daa-originals")})
    roster_check(r,log,["pnh1_three_negative_endpoint_periods_keep_real_w1_and_select_higher_work",
        "pgh2_three_negative_endpoint_periods_keep_real_w1_and_select_higher_work"],0)
    write("source-final-git.json",identity())
except BaseException as exc:
    ERROR=repr(exc);(OUT/"runner-error.txt").write_text(traceback.format_exc());traceback.print_exc()
finally:
    wanted={"history-deadline","public-growth","store-growth","consensus","daa-joint-consensus"}
    observed={s["label"] for s in STEPS}
    passed=(ERROR is None and wanted.issubset(observed) and SQLITE["qualified"] and
        all(s["source_and_command_pass"] and s.get("roster",{"pass":True})["pass"] for s in STEPS))
    summary={"head":HEAD,"tree":TREE,"steps":STEPS,"error":ERROR,"all_requested_suites_recorded":wanted.issubset(observed),
        "sqlite_build_fence_observed_qualified":SQLITE["qualified"],"requested_native_regressions_pass":passed,
        "public_resource_contract_executed":False,"whole_system_qualified":False,"production_activation":False}
    write("summary.json",summary)
    manifest=[{"path":str(p.relative_to(OUT)),"size":p.stat().st_size,"sha256":digest(p)} for p in sorted(OUT.rglob("*"))
        if p.is_file() and p.name!="manifest.json"]
    write("manifest.json",manifest)
    print(json.dumps({"event":"finished","summary":str(OUT/"summary.json"),"requested_native_regressions_pass":passed,"error":ERROR}),flush=True)
sys.exit(0 if passed else 1)

