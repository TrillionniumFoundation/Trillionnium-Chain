#!/usr/bin/env python3
"""Build a bounded lossless docs evidence append without repository mutations."""
from __future__ import annotations
import collections
import datetime
import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile

from source_publication_plan import Git, canonical, commit_header, digest, require, sha256
from tree_request_plan import PART_BYTES, TreeReplay
from build_from_zero_original_ci_package import COMPILED, SECRET_PATH

ROOT = Path('/workspace/scratch/56818e4fba76')
PUB = ROOT / 'publication'
OUT = PUB / 'successor-final-readback-package'
PREFIX = 'evidence/pon-pure-workpackages-20261027/successor-readback-20261027'
REPO = 'TrillionniumFoundation/Trillionnium-Chain'
BASE = '163832173a36ceae3f6d8ffd29c1c7ac0ea92c76'
BASE_TREE = 'b0b13a564778f80dde42c5c5d413d5a6c1873ccb'
CHAIN = 'ac469237422d43805845e8b9a6839ad14e1028e7'
CHAIN_TREE = 'aa000d8883cbffdf0ac4fbfb57b63394693c99c6'
HEPTA = '1d9f262f9965d30105ee58d4218cd6e27ef7a431'
HEPTA_TREE = '3c8a7f5f18325de728b2fc08d5b7bac2e499bfae'
MAX_BLOB_BYTES = 6 * 1024 * 1024


def body(result):
    require(not result.get('isError'), 'required API snapshot is an error')
    return json.loads(result['structuredContent']['content'])


def file_digest(path):
    h = hashlib.sha256()
    size = 0
    with path.open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
            size += len(chunk)
    return size, h.hexdigest()


def main():
    require(not OUT.exists(), 'fresh final snapshot directory required')
    OUT.mkdir()
    generated = OUT / 'generated'
    payload = OUT / 'payload'
    generated.mkdir()
    payload.mkdir()
    inputs = {}

    def add(path, member, scope):
        path = Path(path).resolve(strict=True)
        require(path.is_file() and not path.is_symlink(), 'regular input required')
        require(member not in inputs and not member.startswith('/') and '..' not in member.split('/'), 'duplicate/unsafe archive member')
        size, hash_value = file_digest(path)
        inputs[member] = {'path': member, 'source_file': str(path), 'bytes': size, 'sha256': hash_value, 'scope': scope}

    def generated_json(name, value, member=None):
        path = generated / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(canonical(value))
        add(path, member or 'verification/' + name, 'packaging verification; no native or CI execution')

    chain_git = Git(ROOT / 'chain-work')
    hepta_git = Git(ROOT / 'hepta-pair-work')
    base_raw = chain_git.raw('commit', BASE)
    require(commit_header(base_raw) == (BASE_TREE, ['36cf6cc7a0ac3cfd9ace44d254bee0c266d3e7eb']), 'docs parent identity mismatch')
    replay = TreeReplay(chain_git)
    base_node = replay.load(BASE_TREE)
    require(replay.hash(base_node) == BASE_TREE, 'native docs tree mismatch')
    generated_json('docs-base-native-check.json', {'base_commit': BASE, 'base_tree': BASE_TREE,
        'ordered_parents': commit_header(base_raw)[1], 'raw_commit_sha256': sha256(base_raw),
        'git_object_sha_verified': True, 'native_tree_replay': 'PASS',
        'prior_missing_object_probe_retained': 'publication/docs-base-final-readback-initial-probe.json',
        'resolution': 'Parent fetched the published docs branch; this packager then read and rehashed the actual local commit/tree objects. No virtual parent or new Git objects created.'})

    pub_names = [
        'ci-corrections-publication-receipt.json', 'ci-host-immutable-publication-receipt.json',
        'chain506-ci-repaired-native-pair.json', 'chain506-ci-repaired-api-bracket.json',
        'hepta-host-corrected-publication-receipt.json', 'hepta4080-host-corrected-native-pair.json',
        'readback-docs-branch-receipt.json', 'from-zero-original-ci-publication-receipt.json',
        'docs-base-final-readback-initial-probe.json',
        'chain506-final-body.md', 'hepta4080-final-body.md',
    ]
    for name in pub_names:
        add(PUB / name, 'publication/' + name, 'exact original publication or identity readback; no CI acceptance')
    pair = json.loads((PUB / 'chain506-ci-repaired-native-pair.json').read_bytes())
    hpair = json.loads((PUB / 'hepta4080-host-corrected-native-pair.json').read_bytes())
    require((pair['head'], pair['head_tree']) == (CHAIN, CHAIN_TREE), 'Chain pair mismatch')
    require((hpair['head'], hpair['head_tree'], hpair['chain_source']) == (HEPTA, HEPTA_TREE, CHAIN), 'Hepta pair mismatch')
    for git, p in ((chain_git, pair), (hepta_git, hpair)):
        require(commit_header(git.raw('commit', p['head']))[0] == p['head_tree'], 'native head object mismatch')
        merge_tree, parents = commit_header(git.raw('commit', p['actual_github_merge']))
        require(parents == p['ordered_merge_parents'] == [p['base'], p['head']], 'actual merge parent order mismatch')
        require(merge_tree == p['actual_merge_tree'] == p['canonical_merge_tree'], 'actual merge tree mismatch')

    corrections = json.loads((PUB / 'ci-corrections-publication-receipt.json').read_bytes())
    host = json.loads((PUB / 'ci-host-immutable-publication-receipt.json').read_bytes())
    hp = json.loads((PUB / 'hepta-host-corrected-publication-receipt.json').read_bytes())
    commit_pairs = [
        ('chain', host['guard_source']['original_commit'], host['guard_source']['remote_commit']),
        ('chain', host['schedule']['source_original_commit'], '62bcab588b06b2410147361f4dcf744dd1769c32'),
        *[('chain', c['original_commit'], c['remote_commit']) for c in corrections['commits']],
        ('hepta', hp['original_commit'], hp['remote_commit']),
    ]
    mappings = []
    for name, original, remote in commit_pairs:
        git = chain_git if name == 'chain' else hepta_git
        a, b = git.raw('commit', original), git.raw('commit', remote)
        at, ap = commit_header(a)
        bt, bp = commit_header(b)
        require(at == bt, 'mapped source tree differs from original')
        for role, oid, raw in (('original', original, a), ('mapped-remote', remote, b)):
            path = generated / 'raw-commits' / name / role / oid
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
            add(path, f'raw-commits/{name}/{role}/{oid}', 'exact Git commit payload; SHA-1 object framing verified')
        mappings.append({'repository': name, 'original_commit': original, 'mapped_remote_commit': remote,
                         'exact_same_tree': at, 'original_parents': ap, 'mapped_remote_parents': bp,
                         'original_raw_sha256': sha256(a), 'mapped_remote_raw_sha256': sha256(b),
                         'original_id_not_rewritten_as_remote_id': True})
    generated_json('limited-new-commit-mapping.json', {'count': len(mappings), 'commits': mappings,
        'scope': 'Only six new source/CI correction commits and their mapped remote payloads; no full repository/source bundle or old history copied.'})
    for directory in ('ci-host-176822ae', 'ci-corrections-through-516d077e'):
        add(PUB / directory / 'original-commits.json', 'publication/' + directory + '-original-commits.json', 'original finite source publication archive metadata')

    snapshot_path = PUB / 'successor-ci-snapshot-20261027.json'
    snapshot = json.loads(snapshot_path.read_bytes())
    require(snapshot['sources'] == {'chain': CHAIN, 'hepta': HEPTA}, 'successor snapshot source mismatch')
    counts = {}
    runs_by_id = {}
    for name, lists in snapshot['lists'].items():
        counts[name] = {}
        for kind, response in lists.items():
            data = body(response)
            rows = data['workflow_runs' if kind == 'runs' else 'check_runs']
            require(len(rows) == data['total_count'], 'snapshot collection denominator incomplete')
            require(all(r['head_sha'] == snapshot['sources'][name] for r in rows), 'snapshot head mismatch')
            counts[name][kind] = {'total_count': data['total_count'], 'collected': len(rows),
                                 'states': dict(collections.Counter(r['conclusion'] or r['status'] for r in rows))}
            if kind == 'runs':
                runs_by_id.update({str(r['id']): name for r in rows})
    require(counts['chain']['runs']['states'] == {'pending':2,'queued':10}, 'frozen Chain runs changed')
    require(counts['chain']['checks']['states'] == {'queued':35}, 'frozen Chain checks changed')
    require(counts['hepta']['runs']['states'] == {'pending':2,'queued':2}, 'frozen Hepta runs changed')
    require(counts['hepta']['checks']['states'] == {'queued':6,'in_progress':1}, 'frozen Hepta checks changed')
    require(len(snapshot['jobs']) == 16, 'run jobs readback denominator changed')
    for run, response in snapshot['jobs'].items():
        data = body(response)
        require(run in runs_by_id and len(data['jobs']) == data['total_count'], 'job collection incomplete')
        require(all(str(j['run_id']) == run and j['head_sha'] == snapshot['sources'][runs_by_id[run]] for j in data['jobs']), 'job source mismatch')
    add(snapshot_path, 'successor-ci/successor-ci-snapshot-20261027.json', 'frozen 4 list +16 job API responses and clock/summary records; no new CI polling')
    generated_json('successor-ci-counts.json', {'sources':snapshot['sources'], 'list_observed_utc':snapshot['list_observed_utc'],
        'jobs_acquisition_completed':snapshot['jobs_acquisition_completed'], 'counts':counts,
        'api_collection_responses':20,'job_collections':16,'passing_credit_for_unregistered_or_pending_work':False,
        'model_gate_pass_observed':False,'overall_acceptance':'HOLD'})

    for f in sorted((PUB / 'hepta-original-pair-ci-20261027').iterdir()):
        if f.is_file(): add(f, 'original-hepta-ci/raw/' + f.name, 'original decoded connector log or exact API envelope; not a GitHub native ZIP claim')
    for name in ('coverage.json','credential-screen.json','input-manifest.json'):
        add(PUB / 'hepta-original-pair-readback-preparation' / name, 'original-hepta-ci/verification/' + name, 'prior raw-byte preservation and scope verification')
    for f in sorted((PUB / 'chain-original-late-ci-20261027').iterdir()):
        if f.is_file(): add(f, 'original-chain-late-ci/' + f.name, 'original 64-check snapshot and five representative decoded logs; failures unchanged')
    local_static = ROOT / 'hepta-pair-work/qualification/learning-generations/smollm-pair-host-20261027'
    for f in sorted(local_static.iterdir()):
        if f.is_file():
            expected = hepta_git.run('show', hp['original_commit'] + ':' + str(f.relative_to(ROOT / 'hepta-pair-work')))
            require(expected == f.read_bytes(), 'Hepta local-static record differs from committed source')
            add(f, 'hepta-local-static/' + f.name, 'nine local static checks only; no Hepta Rust/Cargo/Bazel or model execution claim')

    native = PUB / 'chain506-native-host-diagnosis'
    for entry in json.loads((native / 'selected-member-manifest.json').read_bytes())['files']:
        file = Path(entry['file'])
        require(file_digest(file) == (entry['bytes'], entry['sha256']), 'selected original member changed')
        add(file, 'native-host/selected/' + entry['archive'] + '/' + entry['member'], 'exact selected original ZIP member; complete top report retained, original ZIP not embedded')
    for name in ('campaign-members.json','history-members.json','diagnosis.json','campaign-phase-summary.json',
                 'exact-source-excerpts.json','selected-member-manifest.json','selected-credential-screen.json',
                 'campaign-artifacts-readback.json','history-artifacts-readback.json','history-job-readback.json',
                 'campaign-download-receipt.json','history-download-receipt.json','diagnosis-preparation-attempt1.json'):
        add(native / name, 'native-host/' + name, 'raw original lookup, full member digest manifest, or source-bound diagnosis; explicit excluded-byte scope')
    for f in sorted((native / 'wrapper-reference').rglob('*')):
        if f.is_file(): add(f, 'native-host/wrapper-reference/' + str(f.relative_to(native / 'wrapper-reference')), 'exact local8148 wrapper reference used in diagnosis; no runtime source mutation')
    native_diagnosis = json.loads((native / 'diagnosis.json').read_bytes())

    codeql = PUB / 'codeql-triage-0c804-20261027'
    review_size, review_hash = file_digest(codeql / 'review.tar.gz')
    require((review_size, review_hash) == (722798, 'f5a980c68af9173c5b4162ed2e257be1ca5957e7c5a1316670cc4e54d2226637'), 'frozen CodeQL review archive changed')
    for name in ('triage.json','review-manifest.json','review.tar.gz'):
        add(codeql / name, 'codeql/' + name, 'same-operator exact-source nine-alert read-only review; original failed security gate remains failed')
    for name, expected_sha in (
        ('additional-scope-inventory.json', 'c5ddf156b2a5747abdba7f15ddbd5cc94a3131393a808c9a618cf5a16f707501'),
        ('additional-scope-inventory.md', 'e439182bcc2e914704a1f8733bb1477cb8132c49d0b56e646abfd134dda7b301'),
    ):
        require(file_digest(codeql / name)[1] == expected_sha, 'additional CodeQL inventory changed')
        add(codeql / name, 'codeql/' + name, 'finite 316-result scope inventory and bounded production-risk screen; not 307 additional per-alert audits or alert clearance')
    additional_scope = json.loads((codeql / 'additional-scope-inventory.json').read_bytes())
    require(additional_scope['source'] == '0c804e9f5bcf6e972bbb4524c744d4b3c8801c34' and len(additional_scope['results']) == 316, 'additional CodeQL scope mismatch')
    triage = json.loads((codeql / 'triage.json').read_bytes())
    require(triage['source'] == '0c804e9f5bcf6e972bbb4524c744d4b3c8801c34' and len(triage['rows']) == 9, 'CodeQL review scope mismatch')
    (payload / 'codeql-review.md').write_bytes((codeql / 'README.md').read_bytes())
    (payload / 'codeql-additional-scope.md').write_bytes((codeql / 'additional-scope-inventory.md').read_bytes())
    (payload / 'A03-history-diagnosis.md').write_bytes((native / 'diagnosis.md').read_bytes())

    # The two previously content-screened large sets are reused only after
    # exact input hashes were rechecked. New small inputs and nested CodeQL
    # review members are screened here; no matched contents are printed.
    already_screened_prefixes = ('native-host/selected/', 'original-hepta-ci/raw/')
    screen_findings = []
    screen_bytes = 0
    screen_files = 0

    def screen(name, data):
        nonlocal screen_bytes, screen_files
        screen_bytes += len(data)
        screen_files += 1
        for rule_name, pattern in COMPILED.items():
            count = len(list(pattern.finditer(data)))
            if count: screen_findings.append({'path':name,'rule':rule_name,'count':count})
        if SECRET_PATH.search(name): screen_findings.append({'path':name,'rule':'credential_named_path','count':1})

    reused = []
    for name, record in inputs.items():
        if name.startswith(already_screened_prefixes):
            reused.append({'path':name,'bytes':record['bytes'],'sha256':record['sha256']})
        elif name != 'codeql/review.tar.gz':
            screen(name, Path(record['source_file']).read_bytes())
    for name in ('codeql-review.md','codeql-additional-scope.md','A03-history-diagnosis.md'):
        screen(name, (payload / name).read_bytes())
    with tarfile.open(codeql / 'review.tar.gz','r:gz') as archive:
        for member in archive.getmembers():
            require(member.isfile(), 'unexpected nested review member type')
            screen('codeql/review.tar.gz:' + member.name, archive.extractfile(member).read())
    require(not screen_findings, 'credential candidates require review; no values printed')
    generated_json('credential-screen-final-append.json', {'schema':'final-successor-append-credential-screen-v1',
        'new_or_nested_files_scanned':screen_files,'new_or_nested_bytes_scanned':screen_bytes,
        'recognized_credentials_detected':False,'findings':screen_findings,'rules':list(COMPILED),
        'prior_scanned_exact_byte_inputs_reused':reused,
        'prior_scope_receipts':['native-host/selected-credential-screen.json','original-hepta-ci/verification/credential-screen.json'],
        'original_full_zips_not_included_or_claimed_as_content_screened_here':True,
        'scope_limit':'Recognized format screen and explicit prior exact-byte verification; not semantic decompilation or a proof for unknown encodings.'})

    generated_json('archive-inputs.json', {'schema':'final-successor-archive-input-files-v1',
        'members_excluding_this_inventory_itself':list(inputs.values()),'all_original_bytes_preserved':True,
        'complete_repository_or_original_artifact_zip_included':False,
        'frozen_successor_snapshot_sha256':sha256(snapshot_path.read_bytes()),'overall_acceptance':'HOLD'})
    initial_inputs = list(inputs.values())
    (OUT / 'input-sources-initial.json').write_bytes(canonical(initial_inputs))

    archive_path = OUT / 'readbacks.tar.xz'
    with lzma.open(archive_path,'wb',format=lzma.FORMAT_XZ,preset=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
            for name, entry in sorted(inputs.items()):
                info = tarfile.TarInfo(name)
                info.size,info.mode,info.mtime,info.uid,info.gid = entry['bytes'],0o644,0,0,0
                info.uname = info.gname = ''
                with Path(entry['source_file']).open('rb') as stream: tar.addfile(info,stream)
    archive_size, archive_sha = file_digest(archive_path)
    require(archive_size < 64 * 1024 * 1024, 'unexpected compressed archive growth')
    with tarfile.open(archive_path,'r:xz') as tar:
        require(tar.getnames() == sorted(inputs), 'archive member set/order mismatch')
        for member in tar.getmembers():
            expected = inputs[member.name]
            h = hashlib.sha256()
            count = 0
            with tar.extractfile(member) as stream:
                while chunk := stream.read(1024 * 1024):
                    count += len(chunk)
                    h.update(chunk)
            require(count == expected['bytes'] and h.hexdigest() == expected['sha256'], 'final archive member changed')

    chunk_records = []
    if archive_size <= MAX_BLOB_BYTES:
        names = ['readbacks.tar.xz']
    else:
        names = [f'readbacks.tar.xz.part{n:03d}' for n in range((archive_size + MAX_BLOB_BYTES - 1)//MAX_BLOB_BYTES)]
    with archive_path.open('rb') as stream:
        offset = 0
        for ordinal,name in enumerate(names):
            data = stream.read(MAX_BLOB_BYTES)
            file = payload / name
            file.write_bytes(data)
            chunk_records.append({'ordinal':ordinal,'file':name,'offset':offset,'bytes':len(data),'sha256':sha256(data),'git_blob':digest('blob',data)})
            offset += len(data)
        require(not stream.read(1) and offset == archive_size, 'archive split length mismatch')
    assembled = hashlib.sha256()
    for entry in chunk_records: assembled.update((payload / entry['file']).read_bytes())
    require(assembled.hexdigest() == archive_sha, 'lossless split reassembly mismatch')

    if len(names) == 1:
        assembly = 'The archive is a single file; no reassembly is required.\n\n```sh\n' + f"printf '%s  %s\\n' '{archive_sha}' 'readbacks.tar.xz' | sha256sum -c -\n" + 'tar -xJf readbacks.tar.xz\n```'
    else:
        assembly = 'Concatenate every part in the exact order below, then verify the full archive before extraction.\n\n```sh\ncat ' + ' '.join(names) + ' > readbacks.tar.xz\n' + f"printf '%s  %s\\n' '{archive_sha}' 'readbacks.tar.xz' | sha256sum -c -\n" + 'tar -xJf readbacks.tar.xz\n```'
    readme = f'''# Final source-bound readbacks, 2026-10-27 — all acceptance HOLD

This is a **time-bound evidence snapshot**, appended only to `docs/chain-pure-pon-readback-20261027`. It records exact published successors and their pending CI, and preserves newly retrieved original failures. It does not change runtime files, workflows, branch heads, PR pins, model adoption, or M06 integration.

## Exact successor identities

| Repository / PR | Published head | Tree | Actual GitHub prospective merge | Original base |
| --- | --- | --- | --- | --- |
| Chain / [#506](https://github.com/TrillionniumFoundation/Trillionnium-Chain/pull/506) | `{CHAIN}` | `{CHAIN_TREE}` | `{pair['actual_github_merge']}` | `{pair['base']}` |
| Hepta / [#4080](https://github.com/TrillionniumFoundation/hepta-private-ci/pull/4080) | `{HEPTA}` | `{HEPTA_TREE}` | `{hpair['actual_github_merge']}` | `{hpair['base']}` |

Both actual merge objects have the original ordered `[base, head]` parents and the canonical merge tree recorded by the native pair checks. The new Hepta commit retains original parent `2bfceaa3226611a72f43d24e67d13e30091c7449` and pins the Chain head and actual merge above. The initial Chain PR GET that briefly returned the previous source after ref update is retained unchanged; the later API bracket and native tuple checks are separate records. Six limited original correction commits and their mapped remote raw commit payloads are included without rewriting original IDs. No full source bundle or old Git history is duplicated.

The docs parent is `{BASE}`, tree `{BASE_TREE}`, parent `36cf6cc7a0ac3cfd9ace44d254bee0c266d3e7eb`. An initial missing local tree/lazy-fetch failure is retained. The parent subsequently fetched the published docs branch, and this packager verified the actual local commit and tree; no virtual parent is claimed.

## Frozen successor CI, not a pass

Run/check lists were read at **{snapshot['list_observed_utc']}**. The 16 run-job collections were acquired by **{snapshot['jobs_acquisition_completed']['current_time']}**. The snapshot retains all four list responses, all 16 job responses, the clock record and summaries. These are different read times, not an assertion of one atomic live state.

| Exact head | Workflow run denominator | Registered check denominator at list time | Acceptance |
| --- | --- | --- | --- |
| Chain `{CHAIN[:7]}` | 12: 10 queued, 2 pending | 35: all queued | HOLD |
| Hepta `{HEPTA[:7]}` | 4: 2 queued, 2 pending | 7: 6 queued, 1 in progress | HOLD |

Queued, pending, running, skipped, and not-yet-registered work receives no passing credit. No successful model/training/FinalUse/adoption gate is observed in this successor snapshot. The retained nine local Hepta static checks are **static checks only**; Hepta Rust, Cargo, Bazel, the original training generations and the model gates were not executed locally. Publication identity and native merge pairing are not CI acceptance.

## Original failures remain separate evidence

### Hepta original pair

Original run [40491440610](https://github.com/TrillionniumFoundation/hepta-private-ci/actions/runs/40491440610) uses Hepta `2bfceaa3226611a72f43d24e67d13e30091c7449` and Chain `0c804e9f5bcf6e972bbb4524c744d4b3c8801c34`. All four Linux jobs failed step 28: 86 tests, 83 passed and three failed fixture expectations after the named-test list grew from four to five. Model steps 49–52 were skipped in all four jobs. Two Windows ledger jobs succeeded according to the retained jobs API; their complete logs were not collected in this set. All four complete decoded Linux logs and original runs/jobs envelopes are retained byte-for-byte. They are connector-decoded UTF-8 records, not native GitHub ZIP bytes. The seven original files do not record a separate acquisition timestamp; their job/log times are preserved and packaging time is not substituted.

The successor fixture correction is a different source and cannot rewrite that failure. Its original before/after evidence lives at the immutable successor source; this package preserves the limited raw commit mapping, publication receipt, and new pending CI.

### Original Chain late CI and A03 / History

The retained later original `0c804` check list has 64 checks: 37 successes, 21 failures and six in progress; it does not describe the new `ac46923` head. Five representative decoded job logs retain the original History, service-model, protocol-contract, repository-truth and campaign failures. A rejected annotation lookup is also retained.

Read [A03-history-diagnosis.md](A03-history-diagnosis.md) for the full source-bound diagnosis. Original hosted A03 ran three real attempts, all failing within the unchanged 600-second outer limits: **0/3 runs, 0/9 phases, 0/27 planned confirmation rounds**. Nine first rounds were observed and 18 later rounds were not. **63/189 planned business blocks** were attempted and ACKed; 126 were not attempted. **576/576 History network responses succeeded but all 576 native imports failed `PUBLIC_HOST_KERNEL_PARENT`**. All 144 pressure actor instances completed normally. Of 22,881 attack calls, 22,737 were refused and 144 errored; none succeeded. There were 5,337 valid budget samples, zero observed genuine depletion and zero mutation CPU refusals. This hosted evidence is distinct from the earlier local profile-precheck refusal of 0/3.

The representative History artifact contains 4,105 original packet files; its last periodic progress log is 4,000. The test failed after 378.88 seconds at strict public import. Only one of the four failed History lanes' artifacts was downloaded here. Its before-binary hash is retained; the executable bytes are absent from that original History artifact, and the workflow's after-hash check was not reached.

The in-process A03 verifier cannot simultaneously satisfy the original 400% CPU / 16 GiB current-and-ancestor contract and membership in the fixed public parent capped at 25% CPU / 2 GiB. The new from-zero-only wrapper does not automatically solve this conflict. No limits, deadlines or native predicates were weakened. A different importer-process topology requires its own explicit resource/accounting proof and versioned experiment; it cannot be relabeled as the old A03 passing. Priority History has a narrower exact-binary Host wiring option. The broad protocol command names `ancestry_long_sync` without `--ignored`, so it does not itself execute the 4,105-block ignored test; the entire protocol script must not be moved into the smaller resource domain.

All **three complete original campaign total reports** are included in the archive, with their original attempt stdout/stderr, source/resource/binary metadata, selected History records and complete member-hash manifests. The selected original records are 66 files / 144,165,873 bytes. The original campaign ZIP (64,330,038 bytes) and History ZIP (38,101,611 bytes) are **not** embedded here. Their exact original GitHub digests and all 5,034 member hashes are included; all member CRC/size/SHA checks and 913/913 original campaign manifest hashes were verified. The large campaign executable, History SQLite/packet bytes and separately duplicated phase/actor sidecars remain in the original artifacts/local byte-preserved ZIPs, not in this selected-records archive. The manifest enumerates exactly what is present.

### CodeQL: nine reviewed, original gate still failure

Read [codeql-review.md](codeql-review.md), copied byte-for-byte from the completed same-operator review. The original `0c804` check `122144152932` remains **failure**, with nine reported critical/high annotations (five critical, four high). The review uniquely maps 9/9 original annotations to the API-exposed Rust SARIF subset and examines their real code/type/fixture semantics. It does not establish a production secret leak or signing/cipher-nonce misuse at those nine selected sinks; it also does not dismiss alerts or clear the gate. Eight selected sink lines predate the PR; the additional selected literal is a new regression-test fixture.

The exposed Rust analysis contains 316 results. **The other 307 have not received individual semantic audits in the nine-alert review.** The separate [additional scope inventory](codeql-additional-scope.md) enumerates all 316 by source context: 279 unit-test, 23 integration-test, eight fuzz-target, five example, and one production-or-unknown result. These classifications do not clear the alerts. The production candidate, alert 1024 at `main.rs:2641`, remains **OPEN**: its 12 reported source relations include three real `secret_identity` calls, but only four complete API flow paths were available. The bounded inspection did not establish actual private-key disclosure and did not resolve the unavailable relations; the `DevelopmentIdentity` type name is not evidence that an owner-controlled secret file is a public fixture. The additional JSON and Markdown are preserved separately, without rewriting the frozen nine-alert review.

API-provided SARIF is not claimed to be the original full upload or complete historical branch alerts; the prospective merge was not scanned by that head analysis. The original CodeQL review archive is preserved as the exact 722,798-byte `codeql/review.tar.gz` member, SHA-256 `{review_hash}`; it is not reconstructed. No new CodeQL execution was performed by this packager.

## Preservation, layout and extraction

The archive uses **one tar.xz encoding with Python lzma preset 6**; raw members are unchanged. Existing compressed review evidence is itself retained as original bytes. The archive has **{len(inputs)} members**, **{sum(x['bytes'] for x in inputs.values()):,} raw member bytes**, and **{archive_size:,} compressed bytes**. It is distributed as **{len(names)} blob(s)**, each at most 6 MiB. `manifest.json` binds member hashes, part order/offsets, every part hash and the complete reconstructed archive hash.

Full archive SHA-256:

```text
{archive_sha}
```

{assembly}

Key archive paths: `successor-ci/`, `publication/`, `raw-commits/`, `hepta-local-static/`, `original-hepta-ci/`, `original-chain-late-ci/`, `native-host/selected/`, `native-host/diagnosis.json`, and `codeql/`. Every input was rehashed before and after packaging. Previously content-screened large original records were reused only with identical hashes; new inputs and nested CodeQL review members were screened without printing potential values. No recognized non-test credentials were found. Scope and limitations are retained in `verification/credential-screen-final-append.json`.

Previous immutable evidence remains at [docs commit 36cf6cc](https://github.com/TrillionniumFoundation/Trillionnium-Chain/commit/36cf6cc7a0ac3cfd9ace44d254bee0c266d3e7eb) and [docs commit 1638321](https://github.com/TrillionniumFoundation/Trillionnium-Chain/commit/{BASE}). The earlier complete x64/arm64 from-zero ZIPs are already preserved there and are not duplicated. Historical M06 source/evidence and same-operator review remain on their isolated branch and prior evidence paths; no M06 implementation is added or merged here.

**All overall acceptance remains HOLD:** full successor CI, original public service/depletion/confirmation gates, independent WAN qualification, whole-chain post-quantum security, work hardness, model improvement/adoption and production readiness are not established. This metadata append performs no source edits, native build/test, CI rerun/dispatch/cancel, commit, ref update or remote write.
'''
    (payload / 'README.md').write_text(readme)
    public_texts = {name:{'bytes':(payload/name).stat().st_size,'sha256':sha256((payload/name).read_bytes()),'git_blob':digest('blob',(payload/name).read_bytes())} for name in ('README.md','codeql-review.md','codeql-additional-scope.md','A03-history-diagnosis.md')}
    manifest = {
        'schema':'final-source-bound-successor-readback-package-v1','repository':REPO,'docs_parent_commit':BASE,'docs_parent_tree':BASE_TREE,
        'successor_sources':{'chain':pair,'hepta':hpair},'frozen_ci_snapshot':{'sha256':sha256(snapshot_path.read_bytes()),'list_observed_utc':snapshot['list_observed_utc'],'jobs_completed':snapshot['jobs_acquisition_completed'],'counts':counts},
        'public_readable_files':public_texts,
        'archive':{'logical_filename':'readbacks.tar.xz','encoding':'tar + xz / Python lzma preset6','bytes':archive_size,'sha256':archive_sha,'chunk_limit_bytes':MAX_BLOB_BYTES,'parts':chunk_records,'member_count':len(inputs),'raw_member_bytes':sum(x['bytes'] for x in inputs.values())},
        'archive_members':list(inputs.values()),'limited_raw_commit_mappings':mappings,
        'original_a03_denominators':native_diagnosis['campaign']['totals'],'original_full_artifact_zip_bytes_included':False,
        'original_zip_digests_and_full_member_manifests_retained':True,'complete_original_campaign_total_reports_retained':3,
        'codeql_original_gate_conclusion':'failure','codeql_reviewed_annotations':9,'codeql_other_exposed_rust_results_without_individual_semantic_audit':307,
        'codeql_additional_scope_inventory_count':316,'codeql_additional_scope_counts':additional_scope['counts'],'codeql_production_candidate_1024':'OPEN; full source relations not available, no actual disclosure established by bounded inspection',
        'all_acceptance':'HOLD','ci_accepted':False,'whole_chain_post_quantum_accepted':False,'independent_wan_accepted':False,'production_activation':False,'model_adoption':'no-update','m06_integrated':False,
        'runtime_source_changed':False,'network_mutations_performed':False,'manifest_self_hash_location':'external publication-plan.json; excluded from self to avoid recursion',
    }
    (payload / 'manifest.json').write_bytes(canonical(manifest))

    node = replay.load(BASE_TREE)
    elements = []
    blobs = []
    binaries = []
    def exists(parts):
        cur = node
        for n, part in enumerate(parts):
            if part not in cur: return False
            mode, child = cur[part]
            if n+1 == len(parts): return True
            require(mode == '040000','non-directory evidence parent')
            cur = replay.load(child) if isinstance(child,str) else child
        return False
    for name in ['README.md','manifest.json','codeql-review.md','codeql-additional-scope.md','A03-history-diagnosis.md',*names]:
        file = payload / name
        data = file.read_bytes()
        path = PREFIX + '/' + name
        parts = path.encode().split(b'/')
        require(not exists(parts),'only new evidence paths allowed')
        blob = {'path':path,'mode':'100644','type':'blob','sha':digest('blob',data),'sha256':sha256(data),'bytes':len(data),'raw_file':str(file)}
        blobs.append(blob)
        element = {k:blob[k] for k in ('path','mode','type')}
        if name.endswith(('.md','.json')): element['content'] = data.decode('utf-8')
        else:
            element['sha'] = blob['sha']
            binaries.append({k:blob[k] for k in ('sha','sha256','bytes','raw_file')} | {'paths':[{'path':path,'mode':'100644'}]})
        elements.append(element)
        replay.apply(node,parts,'100644',blob['sha'])
    expected_tree = replay.hash(node)
    request = {'repository_full_name':REPO,'base_tree_sha':BASE_TREE,'tree_elements':elements}
    request_raw = (json.dumps(request,ensure_ascii=True,separators=(',',':'))+'\n').encode('ascii')
    require(json.loads(request_raw) == request,'request JSON roundtrip mismatch')
    for element, blob in zip(json.loads(request_raw)['tree_elements'],blobs,strict=True):
        if 'content' in element: require(digest('blob',element['content'].encode()) == blob['sha'],'inline UTF8 mismatch')
    request_path = OUT / 'create-tree-request.json'
    request_path.write_bytes(request_raw)
    partdir = OUT / 'request-parts'
    partdir.mkdir()
    request_parts = []
    for offset in range(0,len(request_raw),PART_BYTES):
        data = request_raw[offset:offset+PART_BYTES]
        file = partdir / f'{offset//PART_BYTES:04d}.ascii'
        file.write_bytes(data)
        request_parts.append({'path':str(file),'offset':offset,'bytes':len(data),'sha256':sha256(data)})
    require(b''.join(Path(p['path']).read_bytes() for p in request_parts) == request_raw,'request chunk reconstruction mismatch')
    binary_path = OUT / 'binary-blobs.json'
    binary_path.write_bytes(canonical({'schema':'chain-source-publication-binary-blobs-v1','count':len(binaries),'bytes':sum(b['bytes'] for b in binaries),'max_blob_bytes':MAX_BLOB_BYTES,'blobs':binaries,'network_mutations_performed':False}))
    for entry in inputs.values():
        require(file_digest(Path(entry['source_file'])) == (entry['bytes'],entry['sha256']),'input changed during freeze')
    plan = {'schema':'final-successor-readback-docs-tree-request-v1','repository':REPO,
        'base_published_head':BASE,'base_tree_sha':BASE_TREE,'expected_tree_sha':expected_tree,
        'publication_role':'metadata-only append to existing docs branch; no runtime/source/PR-pin changes',
        'only_added_paths':[b['path'] for b in blobs],'blobs':blobs,'archive_bytes':archive_size,'archive_sha256':archive_sha,
        'archive_member_count':len(inputs),'archive_raw_member_bytes':sum(i['bytes'] for i in inputs.values()),'archive_chunks':chunk_records,
        'request':{'file':str(request_path),'bytes':len(request_raw),'sha256':sha256(request_raw),'parts':request_parts},
        'binary_blob_list':str(binary_path),'native_tree_replay':'PASS','source_repositories_modified':False,
        'commits_or_refs_created':False,'network_mutations_performed':False,'all_original_inputs_unchanged':True,
        'complete_original_artifact_zips_included':False,'ci_accepted':False,'all_acceptance':'HOLD','m06_integrated':False}
    (OUT / 'publication-plan.json').write_bytes(canonical(plan))
    (OUT / 'compact-schedule.json').write_bytes(canonical([{
        'base_published_head':BASE,'base_tree':BASE_TREE,'expected_tree':expected_tree,
        'file':str(request_path),'bytes':len(request_raw),'sha256':sha256(request_raw),'parts':len(request_parts),
        'binary_dependencies':[b['sha'] for b in binaries],'publication_role':plan['publication_role']}]))
    print(json.dumps({'output':str(OUT),'expected_tree':expected_tree,'files':len(blobs),
        'archive_bytes':archive_size,'archive_sha256':archive_sha,'binary_blobs':len(binaries),'binary_sizes':[b['bytes'] for b in binaries],
        'archive_members':len(inputs),'request_bytes':len(request_raw),'request_sha256':sha256(request_raw),'request_parts':len(request_parts),'acceptance':'HOLD'},indent=2))


if __name__ == '__main__':
    main()
