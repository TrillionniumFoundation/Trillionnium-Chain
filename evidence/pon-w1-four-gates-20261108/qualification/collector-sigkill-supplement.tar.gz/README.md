# Natural root SIGKILL exit preservation

This is an additional actual finite-process observation of the already frozen collector bytes, not a source change. The implementation SHA-256 remains `e250f1a75794c35d9583e55e56f159366b5d15fa13118d7a142d10a38fd6394f`.

The root deliberately sends SIGKILL to itself. Its wait4 returncode is -9, the retained wrapper returncode is -9, and the caller actually observes -9 with empty stderr. The frozen source already excludes SIGKILL/SIGSTOP from signal-handler reset before mirroring the signal. The suspected handler-reset failure did not reproduce; there was no source patch and no additional mandatory test method.

This checks exit-signal preservation only. It does not claim command success, deadline eligibility, a proof, payment or resource qualification. The primary 291-file evidence bundle and its existing checksum remain unchanged; this supplement has its own allowlist.
