from pathlib import Path
import json,hashlib,difflib,sys
base=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');src=base/'source';out=base/'leaf-membership-proposal-31';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
rel='trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_scoped_readback.rs';p=src/rel;old=p.read_text();assert hashlib.sha256(p.read_bytes()).hexdigest()=='0f4c425d32b0a1c0ef6bed9a1a1638b7b12f94daed75a1e68b898c0d1ec28dc3'
new=old.replace('use std::collections::{BTreeMap, BTreeSet};','use std::collections::BTreeSet;')
new=new.replace('    let mut retained = BTreeMap::new();','    // Keep an explicit duplicate-owner set. The current State is immutable;\n    // compare each observed value now, but defer mismatch to the ORIGINAL final\n    // state fence so later SQL, cancellation and balance errors keep priority.\n    let mut retained = BTreeSet::new();\n    let mut same_exposed_accounts = true;')
new=new.replace('retained.insert(owner, value).is_none()','retained.insert(owner)')
new=new.replace('                balance = balance\n                    .checked_add(value.balance)','                same_exposed_accounts &= actual.get(&owner) == Some(&value);\n                balance = balance\n                    .checked_add(value.balance)')
new=new.replace('        // The first graph and every no-hit traversal retain the original full\n        // map comparison. No partial result is promoted to a source frontier.\n        retained == *actual && retained.len() as u64 == root.count','        // Exact membership and value equality for every unique observed owner,\n        // plus equal cardinality, is the original COMPLETE map equality. This\n        // uses no owner/path ordering assumption and hides no unobserved leaf.\n        same_exposed_accounts\n            && retained.len() == actual.len()\n            && retained.len() as u64 == root.count')
new=new.replace('        retained\n            .iter()\n            .all(|(owner, value)| actual.get(owner) == Some(value))','        same_exposed_accounts')
assert new!=old and 'BTreeMap' not in new
(out/'native_scoped_readback.original.rs').write_text(old);(out/'native_scoped_readback.production.rs').write_text(new)
(out/'production.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
oracle=old[old.index('pub(crate) fn verify('):].replace('pub(crate) fn verify(','pub(crate) fn frozen_retained_map_verify(',1).replace('BTreeMap::new()','std::collections::BTreeMap::new()')
oracle='\n// Test-only frozen full traversal from #970, SHA256 0f4c425d32b0a1c0ef6bed9a1a1638b7b12f94daed75a1e68b898c0d1ec28dc3.\n// Its retained-map comparison is independent of the candidate membership logic.\n#[cfg(all(test, target_os = "linux"))]\n'+oracle
(out/'native_scoped_readback.candidate.rs').write_text(new+oracle)
frontier=src/'trillionnium/crates/trnm-pon-node/src/store/native_authenticated/post_write_readback/frontier_tests.rs'
tests=r'''
#[cfg(target_os = "linux")]
fn membership_fixture(count: u64) -> TwoRoots {
    let mut f = fixture();
    let transactions = (1..=count)
        .map(|nonce| transfer(&f.node.settings, nonce, hash(
            b"frontier-real-funded-account", &[&nonce.to_le_bytes()],
        )))
        .collect();
    let packet = f.node.make_consensus_maintenance(
        f.node.settings.genesis(), transactions,
        crate::development_public(0).unwrap(), 11, 4096,
    ).unwrap();
    let parent = f.node.admit(&packet, 100_000).unwrap();
    let packet = f.node.make_consensus_maintenance(
        parent, vec![transfer(&f.node.settings, count + 1,
            crate::development_public(1).unwrap())],
        crate::development_public(0).unwrap(), 21, 4096,
    ).unwrap();
    let child = f.node.admit(&packet, 100_000).unwrap();
    let before = f.node.state_at(parent).unwrap();
    let after = f.node.state_at(child).unwrap();
    assert_eq!(load_observed(&f.node.db, child, None).unwrap().accounts.count, count + 4);
    TwoRoots { fixture: f, parent, child, before, after }
}

#[cfg(target_os = "linux")]
fn membership_thread_cpu() -> u64 {
    use rustix::time::{clock_gettime_dynamic, ClockId, DynamicClockId};
    let value = clock_gettime_dynamic(DynamicClockId::Known(ClockId::ThreadCPUTime)).unwrap();
    u64::try_from(value.tv_sec).unwrap().checked_mul(1_000_000_000).unwrap()
        .checked_add(u64::try_from(value.tv_nsec).unwrap()).unwrap()
}

#[cfg(target_os = "linux")]
fn membership_graph(
    f: &TwoRoots,
    state: &State,
    frozen: bool,
    cancel: Option<usize>,
    delete_on_first: bool,
) -> (std::result::Result<(), String>, usize, u128, u64) {
    use crate::account_archive_prototype::native_store::scoped_readback;
    let node = &f.fixture.node;
    node.db.execute_batch("BEGIN IMMEDIATE").unwrap();
    let record = load_observed(&node.db, f.child, None).unwrap();
    let mut scope = capture(node, f.child);
    assert!(scope.frontier.is_none());
    let access = scope.graph_access(
        &node.db, &node.settings, CurrentAccountGraph { record: &record, state },
    ).unwrap().unwrap();
    let mut calls = 0;
    let mut progress = || {
        calls += 1;
        if cancel == Some(calls) {
            return Err("MEMBERSHIP_TEST_CANCELLED".into());
        }
        if delete_on_first && calls == 1 {
            node.db.execute_batch("DELETE FROM archive_nodes").unwrap();
        }
        Ok(())
    };
    let start = std::time::Instant::now();
    let cpu_start = membership_thread_cpu();
    let result = if frozen {
        scoped_readback::frozen_retained_map_verify(
            access, &mut progress, Some(&node.authenticated_arithmetic.lifts), None,
        )
    } else {
        scoped_readback::verify(
            access, &mut progress, Some(&node.authenticated_arithmetic.lifts), None,
        )
    };
    let cpu_ns = membership_thread_cpu().checked_sub(cpu_start).unwrap();
    let wall_ns = start.elapsed().as_nanos();
    let result = result.map(drop).map_err(|error| error.to_string());
    drop(scope);
    node.db.execute_batch("ROLLBACK").unwrap();
    (result, calls, wall_ns, cpu_ns)
}

#[cfg(target_os = "linux")]
#[test]
fn first_full_leaf_membership_preserves_frozen_errors_and_every_cancel_boundary() {
    let f = membership_fixture(64);
    let nodes = (load_observed(&f.fixture.node.db, f.child, None)
        .unwrap().accounts.count * 2 - 1) as usize;
    for cancel in std::iter::once(None).chain((1..=nodes).map(Some)) {
        let a = membership_graph(&f, &f.after, true, cancel, false);
        let b = membership_graph(&f, &f.after, false, cancel, false);
        assert_eq!((&a.0, a.1), (&b.0, b.1), "cancel={cancel:?}");
        assert_eq!(a.1, cancel.unwrap_or(nodes));
        if cancel.is_none() { assert!(a.0.is_ok()); }
        else { assert_eq!(a.0.unwrap_err(), "MEMBERSHIP_TEST_CANCELLED"); }
    }
    // These are deliberately forged private graph inputs, never complete-State
    // admission capabilities. The actual public/native caller refuses them
    // before this private helper; comparison still must fail at its old fence.
    let key = f.after.keys().find(|key| key.starts_with("account:")).unwrap().clone();
    for fault in ["nonce", "balance", "missing", "extra"] {
        let mut state = f.after.clone();
        match fault {
            "nonce" => {
                let value = state[&key]["nonce"].as_u64().unwrap();
                state.get_mut(&key).unwrap()["nonce"] = serde_json::json!(value + 1);
            }
            "balance" => {
                let value = state[&key]["balance"].as_u64().unwrap();
                state.get_mut(&key).unwrap()["balance"] = serde_json::json!(value + 1);
            }
            "missing" => { state.remove(&key); }
            "extra" => {
                let key = format!("account:{}", hex::encode(hash(b"membership-extra", &[])));
                assert!(state.insert(key, serde_json::json!({"balance":0,"nonce":0})).is_none());
            }
            _ => unreachable!(),
        }
        for cancel in [None, Some(1), Some(nodes), Some(nodes + 1)] {
            let a = membership_graph(&f, &state, true, cancel, false);
            let b = membership_graph(&f, &state, false, cancel, false);
            assert_eq!((&a.0, a.1), (&b.0, b.1), "{fault} cancel={cancel:?}");
            let expected = if cancel.is_some_and(|at| at <= nodes) {
                "MEMBERSHIP_TEST_CANCELLED"
            } else { "NATIVE_ACCOUNT_STATE" };
            assert_eq!(a.0.unwrap_err(), expected);
        }
    }
    let a = membership_graph(&f, &f.after, true, None, true);
    let b = membership_graph(&f, &f.after, false, None, true);
    assert!(a.0.is_err());
    assert_eq!((&a.0, a.1), (&b.0, b.1));
    reference(&f.fixture.node, f.child, &f.after, &mut || Ok(())).unwrap();
}

#[cfg(target_os = "linux")]
#[test]
#[ignore = "explicit paired actual SQL first-graph cost; excludes Host and business SLO"]
fn first_full_leaf_membership_paired_actual_sql_cost() {
    use std::io::Write;
    let path = std::env::var("TRNM_LEAF_MEMBERSHIP_COST_OUTPUT").unwrap();
    let mut out = std::fs::File::create_new(path).unwrap();
    writeln!(out, "{}", serde_json::json!({
        "schema":"pon-first-full-leaf-membership-paired-cost-v1",
        "source":"#970 full scoped traversal versus explicit-owner-set/current-value comparison",
        "rounds_per_size":8,
        "sizes_are_actual_signed_transfer_counts":[64,1024],
        "order":"frozen/candidate then candidate/frozen, alternating each round",
        "scope":"same compiled binary, actual signed native graphs and fresh original SQLite transaction for each traversal; every original graph SQL/checkpoint remains",
        "excluded":"Host, public CPU domain, full business admission latency, network, monetary cost",
        "business_qualified":false
    })).unwrap();
    out.flush().unwrap();
    for count in [64, 1024] {
        let f = membership_fixture(count);
        let nodes = (load_observed(&f.fixture.node.db, f.child, None)
            .unwrap().accounts.count * 2 - 1) as usize;
        for round in 0..8 {
            for frozen in if round % 2 == 0 { [true, false] } else { [false, true] } {
                let row = membership_graph(&f, &f.after, frozen, None, false);
                assert!(row.0.is_ok());
                assert_eq!(row.1, nodes);
                writeln!(out, "{}", serde_json::json!({
                    "count":count, "accounts":count+4, "nodes":nodes,
                    "round":round, "frozen_map":frozen, "wall_ns":row.2, "thread_cpu_ns":row.3,
                    "callbacks":row.1,
                })).unwrap();
                out.flush().unwrap();
            }
        }
    }
}
'''
(out/'frontier_tests.original.rs').write_bytes(frontier.read_bytes())
(out/'frontier_tests.candidate.rs').write_text(frontier.read_text()+tests)
report={'production_changed':False,'working_source_edited':False,'proposal_only':True,'forbidden_owner_order_scheme_rejected':True,'explicit_duplicate_owner_set':True,'final_mismatch_priority_preserved':True,'all_real_node_reads_and_callbacks_unchanged':True,'files':[]}
for name in ['production.patch','native_scoped_readback.original.rs','native_scoped_readback.production.rs','native_scoped_readback.candidate.rs','frontier_tests.original.rs','frontier_tests.candidate.rs']:
 p=out/name;report['files'].append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
