# Funded balanced experiment configuration

This external tool prepares configuration only. It never starts a native winner,
Node owner, prover, verifier, provider request, or payment. The repository source
remains unchanged. Root alone launches the actual operation.

## Required real build qualification

`prepare_funded_config.py prepare` reads the root-produced
`TRNM-W1-CLEAN-BUILD-QUALIFICATION1` at the caller's explicit path. It requires
`qualification_complete: true`, `repo_path` equal to the canonical desktop repo,
the actual current clean commit/tree, two retained raw-source reports and their
SHA256/commit/tree bindings, successful retained commands including a real
locked/offline Cargo invocation, all three native/host/verifier lock files, and
the real ELF bytes for `owner_test`, `native_winner`, `runner`, `verifier`, `r0vm`.
The first four roles must have `kind: repository_build`. The fixed r0vm must have
`kind: fixed_upstream_release`, exact path `ROOT/fixed-backend-01/r0vm`, size
108764424, and SHA256
`2acdf550f9aca4d05b74072463e4ed307c3824309c754a5cb5f93aa84f3390e6`.

The original root build record is caller authority backed by its retained raw
records. This reader does not independently rebuild binaries or infer compiler
provenance from an ELF filename. It preserves `fresh_cargo_target: false` and
`independent_reproducible_build_established: false`.

The guest remains the actual retained v2 ELF, SHA256
`25718312ec3c6f5219d832e3516adfb5f82983156f669c5e7daa15bd22d1798f`.
`guest_compilation_performed` is false. Its exact JSON image ID is the integer
array below, checked against both qualification and actual verifier source:

```json
[1958252411,3287394615,1805488136,1516578702,78549041,790278610,301018785,4279049364]
```

## Prepare after the real commit A build

Invoke the actual resolved desktop Python, `/usr/bin/python3.12`, with these
arguments, using real absolute paths and the actual 40-character commit A:

```text
prepare_funded_config.py prepare
  --qualification ROOT/clean-A-build-qualification-01/qualification.json
  --expected-commit ACTUAL_COMMIT_A
  --plan ABS_NEW_PLAN_JSON
  --out ABS_NEW_TRIAL_DIRECTORY
  --target-root ABS_PERSISTENT_TARGET_DIRECTORY
  --target-instance ORIGINAL_STABLE_TARGET_ID
  --research-node ABS_PERSISTENT_RESEARCH_NODE
  --operation ORIGINAL_DECLARED_64_HEX_OPERATION
  --reserve-nonce 1
```

`ROOT` means
`/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery`.
The command syntax above documents arguments; these capitalized values are not
written into an executable configuration. All output file parents must already
exist. The proof output directory itself must not exist. Prepare validates and
hashes actual files and writes a new immutable launch plan, with no clock fields
and no invented deadline. It never runs the four repository executables.

The fixed plan is segment workers 2, balanced compression workers 2, Rayon 4,
CPUs 0 through 7. It binds the exact original target operation, full statement
materials, current clean source, raw runtime source pins, binary hashes, actual
resolved Python, and root qualification. It also hashes the generator itself;
editing the generator after prepare invalidates finalization.

## Finalize inside the root's final bounded launch unit

The caller must use the **same actual Hepta unit that will run the owner**, with
CPUQuota 800 percent, memory.max exactly 8589934592 bytes, and actual process
affinity exactly CPUs 0..7. Root selects one Linux CLOCK_MONOTONIC deadline no
more than 7200 seconds ahead and reads the actual Linux boot ID immediately
before finalization. Selection and final checks are part of the original budget.
The generator never adds time or rebases an old deadline.

```text
prepare_funded_config.py finalize
  --plan ABS_ORIGINAL_PLAN_JSON
  --config ABS_NEW_CONFIG_JSON
  --deadline-monotonic-ns ORIGINAL_SELECTED_INTEGER
  --boot-id ACTUAL_OWNER_BOOT_UUID
```

Finalize first durably records the caller's selected deadline and original plan,
operation and destination in `PLAN_JSON.deadline.json`. Any later call changing
these values is refused; exact same-identity observation never replaces the
original selection time. It rechecks the actual current cgroup limits/affinity,
clean source and root build record, all binary/material pins, and remaining
original time. It writes the new heavy configuration and
`CONFIG_JSON.finalized.json`, both with create-new semantics. A nonzero exit is
never launch authorization. A late or partial publication stays retained and
does not receive a new budget.

After **successful finalization**, root may invoke the exact `owner_test` ELF
recorded in the plan under the same unit and affinity:

```text
TRNM_W1_FUNDED_CONFIG=ABS_NEW_CONFIG_JSON
OWNER_ELF store::async_w1_generation_v2::tests::heavy::funded_fresh_full_w1_generation --exact --ignored --test-threads=1 --nocapture
```

The generator does not perform this invocation. The ELF's own source/material,
original-clock and real runtime gates remain authoritative.

## Material and settlement limits

Materials are fixed by `ROOT/experiment-inputs-01/manifest.json`, SHA256
`0f2aacaf579f37d9b21bdf5f8e1df5d018b77ff032554d0758a8b16397af3a8d`.
It independently recomputes A/B work-task and model/input commitments. Only the
new native winner output may become the fresh pipeline input; historical full
input is never dispatched by this generator.

The historical header already has nonce zero. The separately retained search0
header consequently has exactly the same bytes and SHA256. This is fixed
historical material and a declared search start, not independent random sampling.
Actual native search and full replay have not been performed by preparation.

The configured resource caps are ceilings, not measured usage. In particular,
the GPU cap is not a claim that GPU time is known. The current trusted runtime
still reports GPU accounting unknown, so a real complete proof can leave funded
Pending with its full reservation; no configuration flag makes it payable.
Shared research Node use is one sequential writer per complete operation. The
heavy entry's native nonce, unchanged-Reserve-tip, sticky cancellation, provider
identity and existing task fences continue to apply.

## Short controls

`test_prepare_funded_config.py` runs four configuration controls only. They cover
exact JSON image format, immutable deadline identity, create-new output, duplicate
JSON and changed file pins. They are not a proof, live provider run, or funding
sample. Preparation and finalization under the real future clean-A qualification
remain separate actual operations.
