#!/usr/bin/env python3
"""Rerun the unchanged retained experiment with explicit paths and Rust 1.95."""
import argparse
import hashlib
import importlib.util
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rustc', required=True, type=Path,
                        help='Actual pinned Rust 1.95.0 rustc executable')
    parser.add_argument('--out', required=True, type=Path,
                        help='New output directory outside this retained bundle')
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parent
    source = bundle / 'source/host_kernel_parent.rs'
    if hashlib.sha256(source.read_bytes()).hexdigest() != '6f4cf524831e8af8e23c954764e388d6d167f125c3de0dd19ce235630ce7df7d':
        raise ValueError('retained original source differs')
    out = args.out.expanduser().resolve()
    if out.is_relative_to(bundle) or out.exists():
        raise ValueError('a fresh output directory outside this bundle is required')
    rustc = args.rustc.expanduser().resolve(strict=True)
    out.mkdir()
    spec = importlib.util.spec_from_file_location('retained_component_measurement', bundle / 'measure-original.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # The original measurement body, source extraction, compile flags, variants
    # and timing loops are unchanged. Only host-specific paths are supplied.
    module.HERE = out
    module.SOURCE = source
    module.RUSTC = rustc
    module.main()


if __name__ == '__main__':
    main()
