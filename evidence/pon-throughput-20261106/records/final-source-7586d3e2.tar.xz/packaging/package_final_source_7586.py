#!/usr/bin/env python3
"""Create one lossless evidence carrier and six new staging paths; no tests/API."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import lzma
import os
import stat
import tarfile

ROOT = Path('/workspace/scratch/1eed767ad985')
STAGING = ROOT / 'validation/throughput-publication-evidence'
ARCHIVE = ROOT / 'validation/final-source-7586d3e2.tar.xz'
INPUTS = (
    'ci-validation/composed-source-7586d3e2',
    'ci-validation/base-sync-5689-roster-compat',
    'validation/base-sync-2859-5689',
    'validation/base-sync-5689-storage-review',
    'validation/base-sync-5689-publish-manifest.json',
)
DESTINATIONS = (
    'records/final-source-7586d3e2.tar.xz',
    'reports/static-7586d3e2/final-summary.json',
    'reports/static-7586d3e2/index.json',
    'reports/static-7586d3e2/package-receipt.json',
    'reports/base-sync-7586/summary.json',
    'reports/base-sync-7586/source-review.json',
)
HEAD = '7586d3e209b38246402e34cf73a27aa9b907bc9c'
TREE = 'fc0e51b1235470b972de41f2d677f6d5948f4868'
PARENTS = ['285982d78a4f62a064841cb0f106d18c865e19c5',
           '56897f125df27994efa1dda935f2c62eceb36de9']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe(name):
    path = PurePosixPath(name)
    assert name and not path.is_absolute() and '\\' not in name
    assert all(part not in ('', '.', '..') for part in name.split('/'))
    assert str(path) == name
    return name


def fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and not path.is_symlink(), str(path)
    with path.open('rb') as stream:
        assert fingerprint(os.fstat(stream.fileno())) == fingerprint(before)
        data = stream.read()
        assert fingerprint(os.fstat(stream.fileno())) == fingerprint(before)
    assert fingerprint(path.lstat()) == fingerprint(before)
    assert len(data) == before.st_size
    return data


def enumerate_inputs():
    paths = {}
    for relative in INPUTS:
        root = ROOT / safe(relative)
        assert not root.is_symlink()
        candidates = [root] if root.is_file() else sorted(root.rglob('*'))
        assert root.exists()
        for path in candidates:
            info = path.lstat()
            assert not stat.S_ISLNK(info.st_mode), str(path)
            if stat.S_ISDIR(info.st_mode):
                continue
            assert stat.S_ISREG(info.st_mode), str(path)
            assert not path.name.endswith(('.tar.xz', '.tar.gz', '.tgz', '.zip')), str(path)
            name = safe(path.relative_to(ROOT).as_posix())
            assert name not in paths
            paths[name] = path
    return paths


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    assert read(path) == data


def metadata(name, data, origin):
    return {'path': safe(name), 'bytes': len(data), 'sha256': sha(data), 'origin': origin}


assert not ARCHIVE.exists()
assert all(not (STAGING / name).exists() for name in DESTINATIONS)
frozen = {}
plans = []
for filename in ('throughput-immutable-blob-upload-plan.json',
                 'throughput-immutable-blob-upload-plan-2.json'):
    path = ROOT / 'validation' / filename
    data = read(path)
    plan = json.loads(data)
    plans.append({'path': 'validation/' + filename, 'sha256': sha(data),
                  'file_count': len(plan['files'])})
    for row in plan['files']:
        path = Path(row['local_path'])
        relative = safe(path.relative_to(STAGING).as_posix())
        assert row['repo_path'] == 'evidence/pon-throughput-20261106/' + relative
        assert relative not in frozen
        data = read(path)
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['git_blob_sha']
        frozen[relative] = row
assert len(frozen) == 87 and not set(DESTINATIONS).intersection(frozen)

paths = enumerate_inputs()
payload = {name: read(path) for name, path in sorted(paths.items())}
assert len(payload) == 225
existing_manifests = []
for relative in ('ci-validation/composed-source-7586d3e2/artifacts.sha256',
                 'ci-validation/composed-source-7586d3e2/artifacts-final.sha256'):
    base = PurePosixPath(relative).parent
    rows = []
    for line in payload[relative].decode().splitlines():
        expected, name = line.split('  ', 1)
        full = safe((base / safe(name)).as_posix())
        assert full in payload and sha(payload[full]) == expected, full
        rows.append(full)
    assert len(rows) == len(set(rows))
    existing_manifests.append({'path': relative, 'sha256': sha(payload[relative]),
                               'verified_entries': len(rows), 'result': 'PASS'})
relative = 'validation/base-sync-5689-storage-review/SHA256SUMS.json'
base = PurePosixPath(relative).parent
rows = json.loads(payload[relative])
assert len({row['path'] for row in rows}) == len(rows)
for row in rows:
    full = safe((base / safe(row['path'])).as_posix())
    assert len(payload[full]) == row['bytes'] and sha(payload[full]) == row['sha256']
existing_manifests.append({'path': relative, 'sha256': sha(payload[relative]),
                           'verified_entries': len(rows), 'result': 'PASS'})

def value(name):
    return json.loads(payload[name])


final_path = 'ci-validation/composed-source-7586d3e2/final-summary.json'
final = value(final_path)
assert final['result'] == 'PASS' and final['tested_commit'] == HEAD and final['tested_tree'] == TREE
assert final['ordered_parents'] == PARENTS and final['actual_python_cases'] == 334
assert final['source_before_after_equal'] and final['lockfiles_unchanged']
compat = value('ci-validation/base-sync-5689-roster-compat/summary.json')
assert compat['status'] == 'PASS' and [row['unittest_summary']['count'] for row in compat['results']] == [6, 106]
assert compat['target']['head'] == PARENTS[0] and compat['target']['merge_head'] == PARENTS[1]
publication = value('validation/base-sync-5689-publish-manifest.json')
api = value('validation/base-sync-2859-5689/api-commit-verified.json')
assert publication['tree'] == api['tree']['sha'] == TREE and api['sha'] == HEAD
assert publication['parents'] == [row['sha'] for row in api['parents']] == PARENTS
assert len(publication['new_blobs']) == 6
review_path = 'validation/base-sync-5689-storage-review/rust-source-review.json'
review = value(review_path)
assert review['worktree_head_before'] == review['worktree_head_after'] == publication['local_commit']
assert review['comparison_parents'] == PARENTS
sampler = value('validation/base-sync-5689-storage-review/sampler-original-command.json')
resolution = value('validation/base-sync-2859-5689/resolution-working.json')
assert resolution['pinned_blobs'] == 593 and resolution['required_paths'] == 512
assert resolution['all_non_source_corpus_fields_unchanged'] is True

generated_utc = datetime.now(timezone.utc).isoformat()
input_groups = []
for relative in INPUTS:
    selected = [name for name in payload if name == relative or name.startswith(relative + '/')]
    input_groups.append({'path': relative, 'regular_files': len(selected),
                         'bytes': sum(len(payload[name]) for name in selected)})
members = dict(payload)
members['packaging/existing-manifests.json'] = encoded(existing_manifests)
members['packaging/package_final_source_7586.py'] = read(Path(__file__))
manifest = {
    'schema': 'trnm-final-source-7586-archive-manifest-v1',
    'generated_utc': generated_utc, 'source_payload_files': len(payload),
    'source_payload_bytes': sum(map(len, payload.values())), 'input_groups': input_groups,
    'scope': 'Exact retained inputs at their original relative paths, including working-merge and separately committed-source receipts; packaging is not a new test or observation',
    'records': [metadata(name, data, 'retained-input' if name in payload else 'packaging-generated')
                for name, data in sorted(members.items())],
    'self_exclusion': 'packaging/manifest.json is the only member not listed in records; its SHA is bound by the external package receipt',
}
members['packaging/manifest.json'] = encoded(manifest)
with ARCHIVE.open('xb') as raw:
    with lzma.LZMAFile(raw, 'w', format=lzma.FORMAT_XZ,
                       check=lzma.CHECK_CRC64, preset=9 | lzma.PRESET_EXTREME) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
            for name, data in sorted(members.items()):
                entry = tarfile.TarInfo(safe(name))
                entry.size = len(data)
                entry.mode = 0o644
                entry.uid = entry.gid = entry.mtime = 0
                entry.uname = entry.gname = ''
                archive.addfile(entry, io.BytesIO(data))
    raw.flush()
    os.fsync(raw.fileno())
archive_bytes = read(ARCHIVE)
decompressor = lzma.LZMADecompressor(format=lzma.FORMAT_XZ)
tar_bytes = decompressor.decompress(archive_bytes)
assert decompressor.eof and not decompressor.unused_data
with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode='r:') as archive:
    entries = archive.getmembers()
    assert len(entries) == len(members) == len({entry.name for entry in entries})
    for entry in entries:
        assert entry.isfile() and safe(entry.name) in members
        assert entry.mode == 0o644 and entry.uid == entry.gid == entry.mtime == 0
        assert archive.extractfile(entry).read() == members[entry.name]
assert enumerate_inputs() == paths
assert all(read(paths[name]) == data for name, data in payload.items())
assert all(sha(read(STAGING / name)) == row['sha256']
           for name, row in frozen.items())

archive_receipt = {'path': DESTINATIONS[0], 'bytes': len(archive_bytes),
                   'sha256': sha(archive_bytes), 'tar_stream_bytes': len(tar_bytes),
                   'tar_stream_sha256': sha(tar_bytes), 'regular_members': len(members),
                   'manifest_member': 'packaging/manifest.json',
                   'manifest_sha256': sha(members['packaging/manifest.json'])}
index = {
    'schema': 'trnm-final-source-7586-compact-index-v1', 'generated_utc': generated_utc,
    'archive': archive_receipt, 'tested_commit': HEAD, 'tested_tree': TREE,
    'actual_committed_source_python_cases': 334,
    'committed_source_summary_member': final_path,
    'working_roster_compatibility_member': 'ci-validation/base-sync-5689-roster-compat/summary.json',
    'working_roster_cases_separately_recorded': [6, 106],
    'working_roster_counts_not_added_to_334': True,
    'local_composed_commit': publication['local_commit'],
    'api_commit_response_member': 'validation/base-sync-2859-5689/api-commit-verified.json',
    'six_blob_publication_manifest_member': 'validation/base-sync-5689-publish-manifest.json',
    'source_review_member': review_path, 'input_groups': input_groups,
    'metadata_graphs': final['metadata'],
    'fresh_native_build_test_or_clippy_qualification': False,
    'new_test_or_measurement_performed_by_packaging': False,
}
base_summary = {
    'schema': 'trnm-base-sync-7586-derived-summary-v1', 'generated_utc': generated_utc,
    'provenance': 'Derived during packaging from retained JSON receipts; not historical tool stdout or a new independent source review',
    'archive': archive_receipt, 'ordered_parents': PARENTS,
    'working_merge': {'record_member': 'validation/base-sync-2859-5689/resolution-working.json',
                      'recorded_status_preserved': resolution['status'],
                      'pinned_blobs': 593, 'required_paths': 512,
                      'all_non_source_corpus_fields_unchanged': True},
    'uncommitted_roster_compatibility': {'head': compat['target']['head'],
        'merge_head': compat['target']['merge_head'], 'target_git_blob_sha': compat['target']['target_git_blob_sha'],
        'python_suites': [{'label': row['label'], 'cases': row['unittest_summary']['count'],
                          'exit_code': row['exit_code']} for row in compat['results']],
        'scope': compat['scope'], 'credited_as_committed_7586_execution': False},
    'local_composed_source_review': {'commit': publication['local_commit'], 'tree': publication['tree'],
        'report_member': review_path, 'report_sha256': sha(payload[review_path]),
        'scope': review['review_scope'], 'result': review['result'],
        'native_execution': review['native_build_or_test_executed'],
        'inventory': review['inventory'], 'storage_service': review['storage_service']},
    'api_source_identity': {'commit': api['sha'], 'tree': api['tree']['sha'],
        'parents': [row['sha'] for row in api['parents']], 'same_tree_as_local_composed_commit': True,
        'response_member': 'validation/base-sync-2859-5689/api-commit-verified.json',
        'commit_signature_verification': api['verification'], 'branch_update_inferred': False},
    'committed_static_validation': {'commit': HEAD, 'tree': TREE, 'result': final['result'],
        'actual_python_cases': 334, 'source_before_after_equal': True,
        'summary_member': final_path, 'summary_sha256': sha(payload[final_path])},
    'historical_sampler_readback': {'measured_source': sampler['original_measured_source'],
        'counts': sampler['original_counts'], 'qualification': sampler['qualification_disposition'],
        'sqlite_warning_preserved': sampler['retained_sqlite_qualification_warning'],
        'record_member': 'validation/base-sync-5689-storage-review/sampler-original-command.json',
        'credited_as_7586_native_execution': False},
    'ci_review_stdout_fabricated': False, 'cross_source_case_counts_aggregated': False,
    'source_modified_or_tests_reexecuted_by_packaging': False,
}
staged = {
    DESTINATIONS[0]: archive_bytes,
    DESTINATIONS[1]: payload[final_path],
    DESTINATIONS[2]: encoded(index),
    DESTINATIONS[4]: encoded(base_summary),
    DESTINATIONS[5]: payload[review_path],
}
for relative, data in staged.items():
    write(STAGING / relative, data)
assert enumerate_inputs() == paths
assert all(read(paths[name]) == data for name, data in payload.items())
for relative, row in frozen.items():
    data = read(STAGING / relative)
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
receipt = {
    'schema': 'trnm-final-source-7586-package-receipt-v1', 'result': 'PASS',
    'generated_utc': generated_utc, 'completed_utc': datetime.now(timezone.utc).isoformat(),
    'archive': archive_receipt, 'compression': 'single solid XZ stream, CRC64, preset 9 extreme',
    'tar_metadata': {'format': 'USTAR', 'mode': '0644', 'uid': 0, 'gid': 0, 'mtime': 0},
    'source_payload_files': len(payload), 'source_payload_bytes': sum(map(len, payload.values())),
    'manifest_records_excluding_self': len(manifest['records']),
    'readback': {'all_members_regular_safe_unique': True,
                 'all_member_bytes_equal_inputs_or_declared_packaging_metadata': True,
                 'single_xz_stream_without_trailing_data': True},
    'existing_input_manifests': existing_manifests,
    'input_file_set_and_bytes_unchanged_after_packaging': True,
    'frozen_staging_plans': plans, 'existing_immutable_staging_paths_verified': 87,
    'existing_immutable_staging_paths_unchanged': True,
    'new_staging_paths_except_this_receipt': [metadata(name, data, 'new-staging-output')
                                             for name, data in sorted(staged.items())],
    'receipt_self_hash_is_external': True, 'root_readme_and_manifests_modified': False,
    'tests_builds_source_mutations_or_api_calls': False,
}
write(STAGING / DESTINATIONS[3], encoded(receipt))
assert all(sha(read(STAGING / name)) == row['sha256'] for name, row in frozen.items())
outputs = [metadata(name, read(STAGING / name), 'new-staging-output') for name in DESTINATIONS]
print(json.dumps({'result': 'PASS', 'archive': archive_receipt, 'source_payload_files': len(payload),
                  'new_staging_paths': outputs, 'existing_87_unchanged': True}, sort_keys=True))
