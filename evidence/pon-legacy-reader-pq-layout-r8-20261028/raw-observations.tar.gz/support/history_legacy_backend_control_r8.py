import hashlib,json,subprocess,sys,tempfile
from pathlib import Path
root=Path("/workspace/scratch/56818e4fba76/chain-history-next")
sys.path.insert(0,str(root/"scripts/ci"))
import check_public_readiness_evidence as check
commit="fc23fa6de10380dd9ce9cae6cddd1db4d87551ce"
files={}
with tempfile.TemporaryDirectory() as temporary:
 target=Path(temporary)
 for name in ("store.rs","ancestry_index.rs"):
  relative="trillionnium/crates/trnm-pon-node/src/"+name
  raw=subprocess.check_output(["git","show",commit+":"+relative],cwd=root)
  path=target/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
  files[name]={"sha256":hashlib.sha256(raw).hexdigest(),"bytes":len(raw),"git_blob":subprocess.check_output(["git","rev-parse",commit+":"+relative],cwd=root,text=True).strip()}
 print(json.dumps({"schema":"historical-full-source-backend-control-v1","commit":commit,"source_files":files,"checker_sha256":hashlib.sha256((root/"scripts/ci/check_public_readiness_evidence.py").read_bytes()).hexdigest()}),flush=True)
 ddl,domain=check.native_durable_schema(target)
 assert len(ddl.encode())==4775
 assert domain=="native-branch-schema-v2"
 print(json.dumps({"result":"PASS","ddl_bytes":len(ddl.encode()),"ddl_sha256":hashlib.sha256(ddl.encode()).hexdigest(),"domain":domain}),flush=True)
