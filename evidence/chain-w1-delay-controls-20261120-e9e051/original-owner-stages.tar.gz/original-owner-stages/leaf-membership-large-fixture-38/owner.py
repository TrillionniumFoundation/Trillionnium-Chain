from pathlib import Path
import subprocess,sys,json,hashlib,time,resource,traceback
base=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');src=base/'source';out=base/'leaf-membership-large-fixture-38';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);res={'commands':[],'business_limits_changed':False,'prior_exit101_retained':True};start=time.monotonic()
def sha(x):return hashlib.sha256(x).hexdigest()
try:
 with (out/'preflight.log').open('xb') as f:assert subprocess.call(['bash','scripts/project-preflight.sh'],cwd=src,stdout=f,stderr=subprocess.STDOUT)==0
 p=src/'trillionnium/crates/trnm-pon-node/src/store/native_authenticated/post_write_readback/frontier_tests.rs';old=p.read_text();assert sha(old.encode())=='c10c03d9b307d5fb495f8010e76770e178665e6f53d2c82569a6f88b37800b82';(out/'original.rs').write_text(old)
 start_at=old.index('fn membership_fixture(count: u64) -> TwoRoots {');end_at=old.index('\n#[cfg(target_os = "linux")]\nfn membership_thread_cpu()',start_at)
 replacement=r'''fn membership_fixture(count: u64) -> TwoRoots {
    let mut f = fixture();
    let mut parent = f.node.settings.genesis();
    let mut timestamp = 11;
    // The original 1024-transaction single packet was refused by LIMIT.
    // Build the same size only through real ordinary blocks with at most
    // the already admitted 64 signed transfers. No native limit changes.
    for first in (1..=count).step_by(64) {
        let last = (first + 63).min(count);
        let transactions = (first..=last)
            .map(|nonce| transfer(&f.node.settings, nonce, hash(
                b"frontier-real-funded-account", &[&nonce.to_le_bytes()],
            )))
            .collect();
        let packet = f.node.make_consensus_maintenance(
            parent, transactions, crate::development_public(0).unwrap(),
            timestamp, 4096,
        ).unwrap();
        parent = f.node.admit(&packet, 100_000).unwrap();
        timestamp += 10;
    }
    let packet = f.node.make_consensus_maintenance(
        parent, vec![transfer(&f.node.settings, count + 1,
            crate::development_public(1).unwrap())],
        crate::development_public(0).unwrap(), timestamp, 4096,
    ).unwrap();
    let child = f.node.admit(&packet, 100_000).unwrap();
    let before = f.node.state_at(parent).unwrap();
    let after = f.node.state_at(child).unwrap();
    assert_eq!(load_observed(&f.node.db, child, None).unwrap().accounts.count, count + 4);
    TwoRoots { fixture: f, parent, child, before, after }
}
'''
 new=old[:start_at]+replacement+old[end_at:];assert new.count('for count in [64, 1024]')==1;new=new.replace('for count in [64, 1024]','for count in [1024]').replace('"sizes_are_actual_signed_transfer_counts":[64,1024]','"sizes_are_actual_signed_transfer_counts":[1024],\n        "prior_64_transfer_observations":"leaf-membership-execution-34/paired-actual-sql.jsonl",\n        "large_fixture_repair":"16 actual ordinary blocks, each 64 signed transfers; original LIMIT unchanged"')
 p.write_text(new)
 r=subprocess.run(['/home/qq/.cargo/bin/rustfmt','--edition','2021',str(p)],capture_output=True);(out/'rustfmt.stdout').write_bytes(r.stdout);(out/'rustfmt.stderr').write_bytes(r.stderr);assert r.returncode==0
 (out/'candidate.rs').write_bytes(p.read_bytes());(out/'change.patch').write_bytes(subprocess.check_output(['git','diff','--full-index','HEAD','--',str(p.relative_to(src))],cwd=src))
 res.update(complete=True,source_sha256=sha(p.read_bytes()),source_bytes=p.stat().st_size,wall_seconds=time.monotonic()-start);(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res),flush=True)
except BaseException as e:res['error']=repr(e);(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');(out/'error.log').write_text(traceback.format_exc());raise
