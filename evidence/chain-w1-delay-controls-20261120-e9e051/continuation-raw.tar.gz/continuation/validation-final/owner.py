from pathlib import Path
import os,sys,json,time,resource,subprocess,hashlib,re,traceback,shutil
base=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b')
src=base/'resume-20261120-e9e051/source';out=src.parent/'validation-final';out.mkdir(exist_ok=False)
(out/'owner.py').write_text(sys.argv[1])
env=os.environ.copy();env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];env['CARGO_TARGET_DIR']=str(src.parent/'target')
env['RUST_TEST_THREADS']='1';env['TRNM_CI_RECEIPT_DIR']=str(out/'receipts')
res={'schema':'chain-w1-delay-final-source-validation-v1','source':str(src),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'complete':False,'commands':[],'original_f0_repeated':False,'full_physical_cost':None,'monetary_cost':None}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args,expected=0,test_summary=None,required=True):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=src,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);log=(out/(name+'.stdout')).read_text(errors='replace')
 r={'name':name,'argv':args,'exit_code':rc,'expected_exit_code':expected,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime,'libtest_summaries':re.findall(r'test result: .*',log)}
 r['accepted_result']=rc==expected and (test_summary is None or test_summary in log)
 res['commands'].append(r);save();print(json.dumps(r),flush=True)
 if not r['accepted_result']:
  print((out/(name+'.stderr')).read_text(errors='replace')[-6000:],flush=True)
  if required:raise AssertionError(r)
 return r
p=src/'trillionnium/crates/trnm-pon-node/src/ingress/public_v3/work_rejection.rs'
candidate=p.read_bytes();candidate_sha=hashlib.sha256(candidate).hexdigest()
try:
 run('preflight',['bash','scripts/project-preflight.sh'])
 restored=[]
 for row in subprocess.check_output(['git','ls-files','-s','-z'],cwd=src).split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,expected,stage=meta.decode().split();rel=path.decode();a=base/'source'/rel;b=src/rel
  if not b.exists() and a.is_file():
   data=a.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   assert actual==expected,(rel,actual,expected)
   b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b);restored.append({'path':rel,'bytes':len(data),'blob':actual})
 (out/'restored-inputs.json').write_text(json.dumps(restored,indent=2)+'\n');print(json.dumps({'restored_exact_inputs':len(restored),'bytes':sum(x['bytes'] for x in restored)}),flush=True)
 diff=subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src);(out/'source.patch').write_bytes(diff);res['source_diff_sha256']=hashlib.sha256(diff).hexdigest();res['lock_sha256']=hashlib.sha256((src/'trillionnium/Cargo.lock').read_bytes()).hexdigest();save()
 args=['cargo','test','--release','--locked','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node']
 old=subprocess.check_output(['git','show','HEAD:'+p.relative_to(src).as_posix()],cwd=src)
 (out/'work_rejection.original.rs').write_bytes(old);(out/'work_rejection.candidate.rs').write_bytes(candidate)
 res['candidate_work_rejection_sha256']=candidate_sha;res['negative_original_work_rejection_sha256']=hashlib.sha256(old).hexdigest();save()
 try:
  p.write_bytes(old)
  run('old-production-negative',args+['--lib','ingress::public_v3::work_rejection::tests::only_new_native_math_refusal_arms_another_body_delay','--','--exact','--test-threads=1','--nocapture'],expected=101,test_summary='test result: FAILED. 0 passed; 1 failed; 0 ignored;')
 finally:
  p.write_bytes(candidate);assert hashlib.sha256(p.read_bytes()).hexdigest()==candidate_sha
  res['candidate_restored']=True;save()
 for name,selector,count in [('w1-rejection','ingress::public_v3::work_rejection::tests::',6),('body-refusal','ingress::public_v3::body_refusal::tests::',3),('native-root-delay','ingress::public_v3::native_root_delay_tests::',4)]:
  run(name,args+['--lib',selector,'--','--test-threads=1','--nocapture'],test_summary=f'test result: ok. {count} passed; 0 failed; 0 ignored;')
 run('clippy',['cargo','clippy','--release','--locked','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--all-targets','--','-D','warnings'],required=False)
 run('fmt',['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'],required=False)
 run('cargo-tree-linux',['cargo','tree','--locked','--manifest-path','trillionnium/Cargo.toml','--target','x86_64-unknown-linux-gnu','-p','trnm-pon-node'],required=False)
 run('cargo-metadata-linux',['cargo','metadata','--locked','--manifest-path','trillionnium/Cargo.toml','--filter-platform','x86_64-unknown-linux-gnu','--format-version','1'],required=False)
 run('inventory-check',['python3','scripts/refresh_distributed_source_inventory.py','--check'],required=False)
 run('roster-controls',['python3','scripts/ci/test_six_workpackage_native_rosters.py','-v'],required=False)
 run('joint-hold-check',['python3','formal/pon-nakamoto-v1/joint_consensus_qualification.py','--check'],required=False)
 run('joint-negative-controls',['python3','formal/pon-nakamoto-v1/test_joint_consensus_qualification.py'],required=False)
 run('joint-require-qualified',['python3','formal/pon-nakamoto-v1/joint_consensus_qualification.py','--require-qualified'],expected=3,required=False)
 run('source-integrity',['python3','scripts/ci/test_ci_source_integrity.py'],required=False)
 run('ci-contract-controls',['python3','scripts/ci/test_ci_contract.py'],required=False)
 run('ci-contract',['python3','scripts/ci/check_ci_contract.py'],required=False)
 run('original-repository-truth',['bash','scripts/ci/ci_job.sh','repository-truth'],required=False)
 res['lock_unchanged']=res['lock_sha256']==hashlib.sha256((src/'trillionnium/Cargo.lock').read_bytes()).hexdigest()
 res['candidate_source_unchanged']=hashlib.sha256(p.read_bytes()).hexdigest()==candidate_sha
 res['complete']=True;res['all_expected_checks_passed']=all(r['accepted_result'] for r in res['commands']) and res['lock_unchanged'] and res['candidate_source_unchanged'];save()
 print(json.dumps({'complete':True,'all_expected_checks_passed':res['all_expected_checks_passed'],'lock_unchanged':res['lock_unchanged'],'candidate_source_unchanged':res['candidate_source_unchanged']}),flush=True)
 sys.exit(0 if res['all_expected_checks_passed'] else 1)
except BaseException as e:
 if not res.get('complete'):
  res['error']=repr(e);res['complete']=True;save();(out/'owner.error').write_text(traceback.format_exc())
 raise
