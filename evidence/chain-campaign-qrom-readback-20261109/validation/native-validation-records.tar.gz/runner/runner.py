#!/usr/bin/env python3
"""Exact-source local controls and static checks; no campaign or qualification."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import time

COMMIT = "8f4d69a594dfe78541ce8afaba55c1fe2f623322"
TREE = "a7d820d364f926784c28732107de1f7bb28306bd"
HOSTED_PROVIDER = "3.5.9"
PINNED_PROVIDER = Path("/home/qq/work/chain-cell-discovery-provider-f2568-20261108/runner/trnm-pq-provider-3.5.9.ReYCJ9gV/install")
PINNED_PROVIDER_FILES = {
    "bin/openssl": "ed29dfe14c0686c876833e39fbeedb277846987f3728acc279c256b32259cf62",
    "include/openssl/opensslv.h": "9647fc99758cf83e3bcf11ae310894fd4911ad62bff22d8213a614df89cfedda",
    "include/openssl/configuration.h": "406c26f93511299b264062f9f3faf0760e7a0506e91a61717c491f3c92e1a996",
    "lib/libcrypto.a": "17042eb9e4235d2b7051c7253add6f3fda619a324c6d6e3e3b35c46157196b0e",
    "lib/libssl.a": "d7cddef12614789118f792fb4b07748c9a413d241895c1501fe12e3998658d90",
}
FOCUSED = (
    ("history-host-observation", "ingress::history_import::observation::tests", (
        "a_missing_host_cpu_sample_keeps_the_aggregate_unknown_after_known_returns",
        "checkpoint_attribution_keeps_errors_unwind_and_missing_clocks",
        "host_aggregate_retains_returns_unwind_and_unentered_unknowns",
        "host_capture_contention_never_changes_original_error_or_calls_action_twice",
        "host_checkpoints_follow_existing_native_spans_without_new_callbacks",
        "unattributed_and_ambiguous_contexts_never_guess_or_change_original_action",
        "worker_checkpoint_uses_owner_phase_without_relabeling_worker_cpu",
    )),
    ("active-phase-context", "ingress::public_v3::request_observation::tests", (
        "active_phase_context_is_lock_free_and_uses_declared_nested_spans",
        "active_phase_context_keeps_sibling_overlap_and_unwind_explicit",
    )),
    ("execution-observation", "ingress::execution_observation::tests", (
        "rejection_and_cancellation_keep_original_hook_and_failed_root_span",
        "worker_cancellation_keeps_caller_span_open_through_the_actual_join",
    )),
)


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            value.update(block)
    return value.hexdigest()


def pinned_provider_readback():
    result = {"prefix": str(PINNED_PROVIDER), "files": [], "errors": [],
              "scope": "five selected existing installed files, read again in this invocation; no provider rebuild or runtime qualification"}
    try:
        if PINNED_PROVIDER.resolve(strict=True) != PINNED_PROVIDER:
            raise ValueError("pinned provider prefix is an alias")
        for relative, expected in PINNED_PROVIDER_FILES.items():
            path = PINNED_PROVIDER / relative
            before = path.lstat()
            if not stat.S_ISREG(before.st_mode):
                raise ValueError("pinned provider input is not a regular file: " + relative)
            actual = digest(path)
            after = path.lstat()
            fingerprint = lambda value: (value.st_dev, value.st_ino, value.st_mode,
                                         value.st_size, value.st_mtime_ns, value.st_ctime_ns)
            if fingerprint(before) != fingerprint(after):
                raise ValueError("provider input changed during read: " + relative)
            row = {"relative_path": relative, "path": str(path), "bytes": after.st_size,
                   "sha256": actual, "expected_sha256": expected,
                   "matches_expected": actual == expected, "identity": fingerprint(after)}
            result["files"].append(row)
        result["matches_expected"] = all(row["matches_expected"] for row in result["files"])
    except Exception as error:
        result["errors"].append(repr(error))
        result["matches_expected"] = False
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--target", required=True, type=Path)
    parser.add_argument("--cargo", default="cargo")
    args = parser.parse_args()
    root = args.repo_root.resolve(strict=True)
    out = args.out.absolute()
    target = args.target.absolute()
    if root == out or root in out.resolve().parents or root == target or root in target.resolve().parents:
        raise ValueError("logs and build target must stay outside the source checkout")
    out.mkdir(parents=True, exist_ok=False)
    cargo = shutil.which(args.cargo)
    if cargo is None:
        raise ValueError("requested cargo is unavailable")
    env = os.environ.copy()
    overrides = {key: value for key, value in env.items() if value and (
        key.startswith("CARGO_PROFILE_") or key in ("RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS"))}
    env.update(CARGO_BUILD_JOBS="1", CARGO_INCREMENTAL="0", CARGO_TARGET_DIR=str(target))
    stages = []
    report = {
        "schema": "history-observer-remote-validation-v1",
        "execution_source_scope": "code commit 8f4d69a; evidence child 48441d09 is not the native execution source",
        "expected_commit": COMMIT, "expected_tree": TREE, "source_root": str(root),
        "runner_sha256": digest(Path(__file__)), "stages": stages,
        "explicit_environment": {key: env[key] for key in (
            "CARGO_BUILD_JOBS", "CARGO_INCREMENTAL", "CARGO_TARGET_DIR")},
        "inherited_compiler_profile_overrides": overrides,
        "profile": "unchanged repository test profile",
        "observer_test_features": "default",
        "all_features_scope": "dependency graph and strict Clippy compilation only",
        "native_campaign_executed": False, "qualification_granted": False,
        "same_environment_as_original_campaign_claimed": False,
        "hosted_ci_executed": False, "state": "RUNNING",
    }

    def save():
        (out / "validation.json").write_text(json.dumps(report, indent=2) + "\n")

    def run(name, argv, quiet=False):
        row = {"name": name, "argv": argv, "cwd": str(root),
               "started_unix_ns": time.time_ns(), "state": "RUNNING"}
        stages.append(row)
        save()
        print("Running stage: " + name, flush=True)
        with (out / (name + ".log")).open("xb") as log:
            errors = (out / (name + ".stderr.log")).open("xb") if quiet else None
            try:
                process = subprocess.Popen(argv, cwd=root, env=env,
                    stdout=subprocess.PIPE, stderr=errors if quiet else subprocess.STDOUT)
                for line in process.stdout:
                    log.write(line)
                    log.flush()
                    if not quiet:
                        sys.stdout.buffer.write(line)
                        sys.stdout.buffer.flush()
                code = process.wait()
            finally:
                if errors is not None:
                    errors.close()
        row.update(exit_code=code, finished_unix_ns=time.time_ns(),
                   state="PASS" if code == 0 else "FAILED")
        save()
        print(json.dumps({"stage": name, "exit_code": code}), flush=True)
        return row

    def blocked(name, reason):
        row = {"name": name, "state": "BLOCKED", "reason": reason}
        stages.append(row)
        save()
        return row

    def provider():
        rustc = shutil.which("rustc")
        rustc_text = subprocess.check_output([rustc, "-vV"], cwd=root, env=env, text=True)
        host = re.search(r"^host: (.+)$", rustc_text, re.M).group(1)
        prefix = host.upper().replace("-", "_") + "_"
        provider_keys = ("OPENSSL_DIR", "OPENSSL_INCLUDE_DIR", "OPENSSL_LIB_DIR",
                         "OPENSSL_STATIC", "OPENSSL_NO_VENDOR", "OPENSSL_NO_PKG_CONFIG",
                         "OPENSSL_CONF", "OPENSSL_MODULES")
        retained_keys = {*provider_keys, *(prefix + key for key in provider_keys),
                         "PKG_CONFIG_PATH", "PKG_CONFIG_LIBDIR", "CARGO_BUILD_TARGET"}
        values = {key: env[key] for key in retained_keys if key in env}
        include = env.get(prefix + "OPENSSL_INCLUDE_DIR") or env.get("OPENSSL_INCLUDE_DIR")
        directory = env.get(prefix + "OPENSSL_DIR") or env.get("OPENSSL_DIR")
        if include or directory:
            header = Path(include) / "openssl/opensslv.h" if include else Path(directory) / "include/openssl/opensslv.h"
            source = header.read_text()
            numbers = dict(re.findall(r"^\s*#\s*define\s+OPENSSL_VERSION_(MAJOR|MINOR|PATCH)\s+(\d+)\b", source, re.M))
            version = ".".join(numbers[key] for key in ("MAJOR", "MINOR", "PATCH"))
            selected = {"header": str(header), "header_sha256": digest(header)}
        else:
            version = subprocess.check_output(["pkg-config", "--modversion", "openssl"],
                cwd=root, env=env, text=True).strip()
            selected = {"probe": ["pkg-config", "--modversion", "openssl"]}
        match = re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:[-+].*)?", version)
        return {"version": version, "selected_source": selected, "environment": values,
            "meets_declared_minimum": match is not None and tuple(map(int, match.groups())) >= (3, 5, 0),
            "hosted_provider_pin": HOSTED_PROVIDER, "matches_hosted_provider_pin": version == HOSTED_PROVIDER,
            "provider_build_identity_verified": False, "pq_runtime_qualification_granted": False,
            "rustc_verbose_version": rustc_text}

    source_started = False
    try:
        save()
        if overrides:
            raise RuntimeError("compiler/profile overrides retained; no altered-profile execution")
        run("cargo-version", [cargo, "--version"])
        if run("preflight", ["bash", "scripts/project-preflight.sh", "--audit"])["exit_code"]:
            raise RuntimeError("project preflight failed")
        identity = [sys.executable, "scripts/ci/verify_ci_source.py", "--kind", "head", "--expected-head", COMMIT]
        if run("source-before", identity + ["--output", str(out / "source-before.json")])["exit_code"]:
            raise RuntimeError("complete source-before check failed")
        before = json.loads((out / "source-before.json").read_text())
        if before["tested_tree"] != TREE:
            raise RuntimeError("source tree differs")
        source_started = True
        report["pinned_provider_before"] = pinned_provider_readback()
        required_provider_environment = {
            "OPENSSL_DIR": str(PINNED_PROVIDER),
            "OPENSSL_INCLUDE_DIR": str(PINNED_PROVIDER / "include"),
            "OPENSSL_LIB_DIR": str(PINNED_PROVIDER / "lib"),
            "OPENSSL_STATIC": "1", "OPENSSL_CONF": "/dev/null",
            "OPENSSL_MODULES": str(PINNED_PROVIDER / "lib/ossl-modules"),
        }
        mismatches = {key: {"expected": value, "actual": env.get(key)}
                      for key, value in required_provider_environment.items() if env.get(key) != value}
        for suffix, expected in required_provider_environment.items():
            key = "X86_64_UNKNOWN_LINUX_GNU_" + suffix
            if key in env and env[key] != expected:
                mismatches[key] = {"expected": expected, "actual": env[key]}
        report["provider_environment_mismatches"] = mismatches
        save()
        base = [cargo, "test", "--manifest-path", "trillionnium/Cargo.toml", "--locked", "--offline", "-p", "trnm-pon-node", "--lib"]
        previous_failed = False
        for name, module, names in FOCUSED:
            if previous_failed:
                blocked(name, "prior focused command failed; no repeated failing compilation")
                continue
            selector = module + ("::active_phase_context" if name == "active-phase-context" else "")
            row = run(name, base + [selector, "--", "--test-threads=1"])
            text = (out / (name + ".log")).read_text(errors="replace")
            expected = [module + "::" + item for item in names]
            passed = re.findall(r"^test ([A-Za-z_][A-Za-z0-9_:]*) \.\.\. ok$", text, re.M)
            summary = re.findall(r"^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; \d+ filtered out;", text, re.M)
            row.update(expected_test_ids=expected, observed_success_ids=passed,
                exact_test_completion=row["exit_code"] == 0 and Counter(expected) == Counter(passed)
                and summary == [(str(len(expected)), "0", "0", "0")])
            if not row["exact_test_completion"]:
                row["state"] = "FAILED"
                previous_failed = True
            save()
        run("workspace-fmt-check", [cargo, "fmt", "--manifest-path", "trillionnium/Cargo.toml", "--all", "--", "--check"])
        for name, flags in (("metadata-default", []), ("metadata-all-features", ["--all-features"])):
            row = run(name, [cargo, "metadata", "--manifest-path", "trillionnium/Cargo.toml", "--locked", "--offline", "--format-version", "1"] + flags, quiet=True)
            if row["exit_code"] == 0:
                graph = json.loads((out / (name + ".log")).read_text())
                row.update(workspace_members=len(graph["workspace_members"]), resolved_nodes=len(graph["resolve"]["nodes"]))
                save()
        try:
            report["provider"] = provider()
        except Exception as error:
            report["provider"] = {"meets_declared_minimum": False, "error": repr(error),
                                  "pq_runtime_qualification_granted": False}
        save()
        if report["provider"]["meets_declared_minimum"] and report["pinned_provider_before"]["matches_expected"] and not report["provider_environment_mismatches"]:
            run("strict-workspace-clippy", [cargo, "clippy", "--locked", "--offline", "--manifest-path", "trillionnium/Cargo.toml", "--workspace", "--all-targets", "--all-features", "--", "-D", "warnings"])
        else:
            blocked("strict-workspace-clippy", "selected pinned OpenSSL files, environment or minimum unavailable or mismatched")
    except BaseException as error:
        report["error"] = repr(error)
    finally:
        if source_started:
            report["pinned_provider_after"] = pinned_provider_readback()
            report["pinned_provider_before_after_equal"] = report["pinned_provider_before"] == report["pinned_provider_after"] and report["pinned_provider_after"]["matches_expected"]
            row = run("source-after", [sys.executable, "scripts/ci/verify_ci_source.py", "--kind", "head", "--expected-head", COMMIT, "--output", str(out / "source-after.json")])
            report["source_before_after_equal"] = row["exit_code"] == 0 and (out / "source-before.json").read_bytes() == (out / "source-after.json").read_bytes()
        required = {"preflight", "source-before", "source-after", "workspace-fmt-check", "metadata-default", "metadata-all-features", "strict-workspace-clippy", *(name for name, _, _ in FOCUSED)}
        complete = {row["name"] for row in stages if row["state"] == "PASS"}
        report["all_requested_local_checks_passed"] = not report.get("error") and required <= complete and report.get("source_before_after_equal") is True and report.get("pinned_provider_before_after_equal") is True
        report["state"] = "PASS" if report["all_requested_local_checks_passed"] else "FAILED_OR_BLOCKED"
        report["finished_unix_ns"] = time.time_ns()
        save()
    print(json.dumps({"state": report["state"], "out": str(out)}), flush=True)
    return 0 if report["all_requested_local_checks_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
