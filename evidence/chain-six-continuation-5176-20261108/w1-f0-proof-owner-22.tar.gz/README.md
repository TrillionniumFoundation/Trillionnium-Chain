# F0 proof owner: 22 native regression controls

## Observation

All 22 named Rust controls passed at source 4505a598d6ec2644a175e47398d4a5f3f054bc5e (tree e99b0968bbe3e3e3441e7cf843f832cd52e173d9): 12 node_bridge and 10 proof_start_owner. The library and binary harnesses each registered 0 tests and are not counted. All four harness results reported 0 failed, ignored, measured or filtered tests. Current --list registration and actual successful names exactly matched the fixed 22-name historical roster.

This is a new F0 execution. Its historical expected-name reference belongs to F3 1a446a79700cc093a2b1a7f10367ef4a5ddbd680. That F3 observation is not relabelled as F0. The retained SHA and arithmetic complete STARK fixture components were verified by the tests; this run generated **0 new complete proofs**. The separate true-generation 6f archive and previous F0 CLI supplement retain their original identities.

## Exact command and compiler policy

~~~
/home/qian-qi/.cargo/bin/cargo +1.95.0 test --manifest-path /data/chain-six-5176-20261108/source/formal/pon-nakamoto-v1/w1_node_adapter_research/Cargo.toml --release --locked --offline --all-targets -- --test-threads=1
~~~

RAYON_NUM_THREADS=2, CARGO_BUILD_JOBS=2, RUSTFLAGS=-C target-cpu=native, Rust/Cargo +1.95.0, locked and offline. Prebuilding used the same release/all-targets selection with --no-run --message-format=json. This records actual test artifacts before executing the original command.

Build wall time: 92.475308 seconds. Test command wall time: 33.801434 seconds.

The managed process had affinity CPUs 0–7, cpu.max=800000 100000, memory.max=8589934592, memory.swap.max=max. These are recorded research settings, not an original public resource qualification. The host was shared with other independent test jobs.

## Source and executable stability

Before and after audits passed. verify_ci_source.py verified all 26129 tracked entries / 2495254410 bytes against F0. Before/after JSON files are byte-identical. Four compiled test executable records and the actual integration-test CLI executable record were byte-identical before/after test execution.

| Test target | Bytes | SHA-256 |
| --- | ---: | --- |
| w1_node_adapter_research | 1054880 | ad379a91bce13b217a94bd63c7e980d9e297e559366a5cc2c7bfccfa9fdd9301 |
| w1-node-adapter-research | 1054952 | f264707b695d1f1b1a61de6f94e92f5e0823ee8d74d7564e80e533bbd7fe8606 |
| proof_start_owner | 2251440 | deb350c249ff14431d3be6f9940c178acbcf6bc3d75f141f9055146aa29c8624 |
| node_bridge | 8765872 | 76a9cbbb3316c7c694ca9f2dca30f7841e3013d2e567412e142aa28022067905 |

Actual CLI: 8166888 bytes, SHA-256 632d09527c5571a2448579fc6d4419ae04ef2392fdb1da35ff8e4d3bf41dda4b.

## Contents and exclusions

The archive contains the exact runner, full build/test stdout and stderr, the original F3 expected roster/environment, current binary/fixture digest records, current registered/observed test rosters, before/after full-source verifier outputs, preflight outputs, and four selected current Cargo/test source files. It preserves the SQLite I/O boundary UNQUALIFIED native-override warning emitted by the build.

This small report archive **does not include executable bytes, retained proof fixture bytes, all transitive source bytes, external Cargo sources, or the toolchain**. Their recorded hashes are not claims that those bytes are packaged here. Reexecution requires the F0 repository and the recorded native build environment.

## Qualification boundaries

qualification=HOLD_NO_GO, production_activation=false, same_resource_net_benefit_qualified=false, compositional_post_quantum_qualified=false, and unknown_security_bounds=null. This report adds named native regression evidence only. It does not claim new proof generation, a new statement, formal whole-chain composition, original public budget feasibility, or production admission.

The previously assembled original generation archive and F0 CLI supplement were rehashed unchanged during packaging:
- w1-fresh-stark-native-5176-20261109.tar.gz: 5c42a370d3c39c0d144047f0c2308c5b113a1e752e51fb90061643aa699f68f8
- w1-f0-native-proof-supplement-5176-20261109.tar.gz: 87ac846318dc90375b72cdd14e2a1447c962ef256705bfe9aa65ea2d520c554b
