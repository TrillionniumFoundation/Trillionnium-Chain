/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/foreign_types_shared-4f6210631986175b.d: /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign-types-shared-0.1.1/src/lib.rs

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libforeign_types_shared-4f6210631986175b.rmeta: /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign-types-shared-0.1.1/src/lib.rs

/workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign-types-shared-0.1.1/src/lib.rs:
