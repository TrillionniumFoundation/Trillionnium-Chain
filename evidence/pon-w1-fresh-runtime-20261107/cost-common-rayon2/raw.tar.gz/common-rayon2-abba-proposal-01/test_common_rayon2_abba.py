#!/usr/bin/env python3
"""Pure proposal guards; no native/receipt verifier, provider or proof dispatch."""
import importlib.util
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("common2", HERE / "run_common_rayon2_abba.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class Common2ProposalTests(unittest.TestCase):
    def test_unbound_receipt_template_is_rejected(self):
        with self.assertRaises(ValueError):
            m.binding_shape({"schema": m.BINDING_SCHEMA, "state": "WAITING_FOR_ACTUAL_GENERATION_TERMINALS"})

    def test_both_planned_denominators_exist_before_dispatch(self):
        rows = m.planned_ledger()
        self.assertEqual(len(rows), 80)
        for arm in m.ARM_IDS:
            selected = [row for row in rows if row["arm"] == arm]
            self.assertEqual([row["index"] for row in selected], list(range(40)))
            self.assertEqual([row["kind"] for row in selected], ["native", "proof", "proof", "native"] * 10)
            self.assertTrue(all(row["dispatched"] is False and row["accepted"] is False for row in selected))

    def test_wrong_quota_memory_and_affinity_are_rejected(self):
        actual = {"cpu_max": "200000 100000", "memory_max": str(8 * 1024**3)}
        m.resource_guard(actual, [8, 9])
        for changed in ({**actual, "cpu_max": "400000 100000"},
                        {**actual, "cpu_max": "25000 100000"},
                        {**actual, "memory_max": str(2 * 1024**3)}):
            with self.assertRaises(ValueError):
                m.resource_guard(changed, [8, 9])
        with self.assertRaises(ValueError):
            m.resource_guard(actual, [0, 1])

    def test_each_comparator_receives_the_same_new_cost_deadline(self):
        binding = {"statement": {key: {"path": "/unobserved/" + key}
                                for key in ("input", "header", "expected_artifacts")}}
        arm = {"receipt": {"path": "/unobserved/receipt"}}
        command = m.comparison_argv(binding, arm, Path("/unobserved/out"), 1234567890123, "cost-boot")
        self.assertEqual(command[command.index("--repeats") + 1], "10")
        self.assertEqual(command[command.index("--wall-seconds") + 1], "600")
        self.assertEqual(command[command.index("--deadline-monotonic") + 1], repr(1234567890123 / 1e9))
        self.assertEqual(command[command.index("--deadline-boot-id") + 1], "cost-boot")
        self.assertNotIn("7200", command)

    def test_claimed_rows_cannot_override_nonzero_exit_or_cancellation(self):
        claims = {"operation_complete": True, "error": None, "rows": [{"accepted": True}] * 40,
                  "cost_comparison": {"untrusted_claim": True}, "fresh_proof_generations": 0}
        self.assertFalse(m.complete_report(claims, {"stage_process_complete": False, "returncode": 15}, False))
        self.assertFalse(m.complete_report(claims, {"stage_process_complete": True, "returncode": 0}, True))
        claims["cancellation_event"] = {"signum": 15}
        self.assertFalse(m.complete_report(claims, {"stage_process_complete": True, "returncode": 0}, False))

    def test_declaration_keeps_prior_confounds_and_zero_generation_scope(self):
        declaration = m.declaration(HERE / "run_common_rayon2_abba.py", "a" * 64)
        self.assertEqual(declaration["prior_internal_rayon_threads"], [4, 8])
        self.assertEqual(declaration["common_conditions"]["rayon_threads"], 2)
        self.assertEqual(declaration["fresh_proof_generations"], 0)
        self.assertFalse(declaration["main_generation_deadline_extended"])
        changed = dict(declaration)
        changed["main_generation_deadline_extended"] = True
        with self.assertRaises(ValueError):
            m.validate_declaration(changed, HERE / "run_common_rayon2_abba.py")


    def test_actual_row_environment_cannot_silently_mix_prior_rayons(self):
        binding = {"statement": {k: {"sha256": "a" * 64} for k in ("input", "header", "expected_artifacts")}}
        arm = {"receipt": {"sha256": "b" * 64}}
        ids = {k + "_sha256": "a" * 64 for k in ("input", "header", "expected_artifacts")}
        ids.update(receipt_sha256="b" * 64, verifier_sha256=m.VERIFY_SHA)
        for threads in ("4", "8", None):
            value = {"schema": "TRNM-W1-DEPLOYMENT-COMPARISON2", "planned_order": m.ORDER,
                     "identities": ids,
                     "rows": [{"index": 0, "kind": "native", "dispatched": True, "accepted": False,
                               "stage": {"environment": {"RAYON_NUM_THREADS": threads}}}]}
            with self.assertRaises(ValueError):
                m.validate_rows(value, arm, binding)


if __name__ == "__main__":
    unittest.main(verbosity=2)
