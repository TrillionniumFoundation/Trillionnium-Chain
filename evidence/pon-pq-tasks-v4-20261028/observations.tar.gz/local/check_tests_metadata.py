import importlib.util, os, json, tomllib
from pathlib import Path
spec=importlib.util.spec_from_file_location('check',Path(__file__).with_name('run_typecheck.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
before=m.source()
try:
    for crate,test in [('trnm_protocol','lib'),('trnm_mvcc_fee','lib'),('trnm_mvcc_fee','pq4_task_authority'),('trnm_pon_node','native_pq_v4')]:
        m.build(crate,'tests02',test,opt=0)
finally:
    m.dump(m.OUT/'tests02-source-after.json',{'source_before_after_equal':before==m.source(),'source_before':before,'source_after':m.source(),'scope':'metadata-only tests; NOT_RUN; not Cargo qualification'})
