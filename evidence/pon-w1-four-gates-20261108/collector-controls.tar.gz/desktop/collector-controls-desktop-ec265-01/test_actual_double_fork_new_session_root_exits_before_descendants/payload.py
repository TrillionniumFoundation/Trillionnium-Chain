import os,time
from pathlib import Path
if os.fork(): os._exit(0)
os.setsid()
if os.fork(): os._exit(0)
os.setsid()
time.sleep(.20)
Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/collector-controls-desktop-ec265-01/test_actual_double_fork_new_session_root_exits_before_descendants/grandchild-finished').write_text('actual grandchild finished')
os._exit(0)
