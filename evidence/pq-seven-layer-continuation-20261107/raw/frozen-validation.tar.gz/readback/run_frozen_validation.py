"""Task-local orchestration; every command uses the repository's original recorder."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('phase', choices=('source', 'quantum', 'native'))
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve(strict=True)
out = args.output.absolute()
out.mkdir(parents=True, exist_ok=False)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip()
records = []
planned = {
    'source': ['test_ci_source_integrity', 'test_record_pq_native_command',
               'test_pq_research_integration', 'test_pq_chain_claim_guard',
               'test_pq_authority_surface_scan', 'test_ci_contract', 'test_codeql_retention',
               'pq-source', 'pq-hold', 'repository', 'inventory', 'locked-graph', 'format'],
    'quantum': ['test_quantum_oracle_resources', 'test_quantum_network_sim',
                'test_quantum_candidate_check_clock', 'test_quantum_adversarial_search',
                'test_quantum_resource_clock', 'test_quantum_daa_model',
                'test_w1_quantum_oracle', 'test_w1_marked_domain',
                'test_w1_quantum_restricted_oracle', 'constructive-observe',
                'constructive-replay', 'restricted-observe', 'restricted-replay'],
    'native': ['compiler', 'provider-version', 'node-build', 'node-registry', 'node-full',
               'tls-cli-and-witness-registry', 'tls-cli-and-witness',
               'migration-v6-and-feature-off-registry', 'migration-v6-and-feature-off',
               'checkpoint-release-registry', 'checkpoint-release',
               'sqlite-build-requalification', 'strict-clippy'],
}[args.phase]

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def registry_binaries(label, ordinary_node=False):
    log = (out / (label + '.log')).read_text()
    paths = [Path(value) for value in re.findall(r'^\s+Running .* \(([^)\n]+)\)$', log, re.MULTILINE)]
    if ordinary_node:
        paths.append(Path(os.environ['CARGO_TARGET_DIR']) / 'debug/trnm-pon-node')
    return {str(path): {'sha256': digest(path), 'bytes': path.stat().st_size}
            for path in sorted(set(paths))}

def registered_suite(label, command, ordinary_node=False):
    if run(label + '-registry', [*command, '--', '--list']):
        before = registry_binaries(label + '-registry', ordinary_node)
        save(out / (label + '-elf-before.json'), before)
        run(label, [*command, '--', '--show-output', '--test-threads=1'])
        after = registry_binaries(label + '-registry', ordinary_node)
        save(out / (label + '-elf-after.json'), after)
        if not before or before != after:
            raise RuntimeError('native harness identity changed: ' + label)

def run(label, command, cap=1500):
    argv = [sys.executable, 'scripts/ci/record_pq_native_command.py',
            '--kind', 'head', '--candidate', head, '--tested', head,
            '--label', label, '--output', str(out), '--', 'timeout', str(cap), *command]
    start = time.monotonic()
    print(json.dumps({'phase': args.phase, 'label': label, 'status': 'started'}), flush=True)
    with (out / (label + '.recorder.log')).open('x') as stream:
        code = subprocess.run(argv, cwd=root, stdout=stream, stderr=subprocess.STDOUT).returncode
    record = {'label': label, 'command': command, 'cap_seconds': cap,
              'recorder_exit': code, 'wall_seconds': time.monotonic() - start}
    receipt = out / (label + '.json')
    if receipt.exists():
        value = json.loads(receipt.read_text())
        record['status'] = value['status']
        record['command_exit'] = value['exit_code']
        record['receipt_sha256'] = digest(receipt)
    record['execution_readback_ok'] = True
    if command[:4] == ['python3', '-m', 'unittest', 'discover']:
        log = out / (label + '.log')
        counts = re.findall(r'^Ran ([0-9]+) tests? in ', log.read_text(), re.MULTILINE) if log.exists() else []
        record['unittest_parent_count'] = int(counts[-1]) if counts else None
        record['execution_readback_ok'] = bool(counts) and int(counts[-1]) > 0
    records.append(record)
    save(out / 'progress.json', records)
    print(json.dumps(record), flush=True)
    return code == 0 and record.get('status') == 'command_succeeded' and record['execution_readback_ok']

manifest = ['--offline', '--locked', '--manifest-path', 'trillionnium/Cargo.toml']
cargo = lambda *rest: ['cargo', *rest[:1], *manifest, *rest[1:]]
save(out / 'runner.json', {'phase': args.phase, 'head': head, 'tree': tree,
    'runner_sha256': digest(Path(__file__)), 'original_profiles_unchanged': True,
    'planned_commands': planned,
    'production_qualified': False, 'whole_chain_pq_qualified': False})

if args.phase == 'source':
    for filename in ('test_ci_source_integrity.py', 'test_record_pq_native_command.py',
                     'test_pq_research_integration.py', 'test_pq_chain_claim_guard.py',
                     'test_pq_authority_surface_scan.py', 'test_ci_contract.py',
                     'test_codeql_retention.py'):
        run(filename.removesuffix('.py'), ['python3', '-m', 'unittest', 'discover',
            '-s', 'scripts/ci', '-p', filename, '-v'])
    for label, command in (
        ('pq-source', ['python3', 'scripts/ci/check_pq_research_integration.py']),
        ('pq-hold', ['python3', 'scripts/ci/pq_chain_claim_guard.py']),
        ('repository', ['python3', 'scripts/ci/check_repository.py']),
        ('inventory', ['python3', 'scripts/refresh_distributed_source_inventory.py', '--check']),
        ('locked-graph', cargo('metadata', '--format-version=1')),
        ('format', ['cargo', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--check']),
    ):
        run(label, command)

elif args.phase == 'quantum':
    names = ('test_quantum_oracle_resources.py', 'test_quantum_network_sim.py',
             'test_quantum_candidate_check_clock.py', 'test_quantum_adversarial_search.py',
             'test_quantum_resource_clock.py', 'test_quantum_daa_model.py',
             'test_w1_quantum_oracle.py', 'test_w1_marked_domain.py',
             'test_w1_quantum_restricted_oracle.py')
    for name in names:
        run(name.removesuffix('.py'), ['python3', '-m', 'unittest', 'discover',
            '-s', 'formal/pon-nakamoto-v1', '-p', name, '-v'])
    for label, program in (
        ('constructive', 'w1_quantum_oracle_campaign.py'),
        ('restricted', 'w1_restricted_oracle_campaign.py'),
    ):
        artifact = out / (label + '-campaign')
        script = 'formal/pon-nakamoto-v1/experiments/' + program
        if run(label + '-observe', ['python3', script, '--out', str(artifact)]):
            run(label + '-replay', ['python3', script, '--verify', str(artifact)])

elif args.phase == 'native':
    run('compiler', ['rustc', '-Vv'])
    run('provider-version', [os.environ['TRNM_PQ_OPENSSL'], 'version'])
    build = cargo('test', '-p', 'trnm-pon-node', '--lib', '--all-features',
                  '--no-run', '--message-format=json')
    if run('node-build', build):
        artifacts = []
        for line in (out / 'node-build.log').read_text().splitlines():
            if not line.startswith('{'):
                continue
            value = json.loads(line)
            if (value.get('reason') == 'compiler-artifact'
                    and value['target']['name'] == 'trnm_pon_node'
                    and value['target']['kind'] == ['lib'] and value.get('executable')):
                artifacts.append(value)
        if len(artifacts) != 1:
            raise RuntimeError('actual library ELF identity is not unique')
        binary = Path(artifacts[0]['executable'])
        before = {'path': str(binary), 'sha256': digest(binary), 'bytes': binary.stat().st_size,
                  'target': artifacts[0]['target'], 'profile': artifacts[0]['profile']}
        save(out / 'node-elf-before.json', before)
        run('node-registry', [str(binary), '--list'])
        run('node-full', cargo('test', '-p', 'trnm-pon-node', '--lib', '--all-features',
            '--', '--show-output', '--test-threads=1'))
        after = {**before, 'sha256': digest(binary), 'bytes': binary.stat().st_size}
        save(out / 'node-elf-after.json', after)
        if before != after:
            raise RuntimeError('native library ELF changed during execution')
        # These separate ordinary-binary harnesses are not covered by a libtest result.
        registered_suite('tls-cli-and-witness', cargo('test', '-p', 'trnm-pon-node', '--all-features',
            '--test', 'pq_tls_cli', '--test', 'pq_tls_witness_cli'), ordinary_node=True)
        registered_suite('migration-v6-and-feature-off', cargo('test', '-p', 'trnm-pon-node',
            '--test', 'pq_application_migration_v6', '--test', 'pq_tls_feature_gate',
            ), ordinary_node=True)
    registered_suite('checkpoint-release', cargo('test', '-p', 'trnm-checkpoint-store', '-p',
        'trnm-release-bundle', '--all-targets', '--no-fail-fast'))
    rustc = Path(os.environ['RUSTC']).resolve()
    run('sqlite-build-requalification', ['python3', 'scripts/ci/check_sqlite_build_requalification.py',
        '--output', str(out / 'sqlite-requalification'), '--target', str(out / 'sqlite-target'),
        '--rustc', str(rustc), '--cargo', str(rustc.with_name('cargo'))])
    run('strict-clippy', cargo('clippy', '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings'))

not_executed = sorted(set(planned) - {r['label'] for r in records})
complete = (not not_executed and len(records) == len(planned)
            and all(r.get('status') == 'command_succeeded' and r['recorder_exit'] == 0
                    and r['execution_readback_ok'] for r in records))
save(out / 'result.json', {'head': head, 'tree': tree, 'phase': args.phase, 'commands': records,
    'planned_commands': planned, 'not_executed': not_executed,
    'all_commands_succeeded': complete,
    'native_execution_readback_required': args.phase == 'native',
    'whole_chain_pq_qualified': False, 'public_wan_qualified': False, 'production_activation': False})
print(json.dumps({'phase': args.phase, 'commands': len(records),
                  'not_executed': not_executed, 'all_commands_succeeded': complete}), flush=True)
raise SystemExit(0 if complete else 1)
