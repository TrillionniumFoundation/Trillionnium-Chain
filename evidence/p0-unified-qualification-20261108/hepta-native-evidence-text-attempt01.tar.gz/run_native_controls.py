#!/usr/bin/env python3
"""Observe explicitly selected native engineering controls; never grant qualification.

The source tree is read-only to this script. All build/evidence writes use OUT.
An O_EXCL campaign marker prevents an uncertain transport reply from rerunning tests.
Native command exits and collection failures are independent. Original raw logs,
JUnit, test registry, tools/configuration digests, and executed ELF observations
are retained. This is not a real training, independent evaluation, or payment run.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
import traceback

SRC = Path('/home/qian-qi/work/hepta-p0-source-f178-20261108-99b5')
OUT = Path('/home/qian-qi/work/hepta-p0-native-controls-20261108-99b5-hepta-audit')
OLD = Path('/home/qian-qi/work/chain-hepta-native-1f3ba4601505')
EXPECTED = 'f1785ca15e41e4e49509a5b211a659e3cbdbf60e'
EV = OUT / 'evidence'
TARGET = OUT / 'target'
TOOLS = OUT / 'tools'
SCOPES = [
    ('readback5', 'codex-hepta-agentd', [
        'neuron_generation_runtime::tests::update::adopted_learning::updated_candidate_uses_original_actor_and_recovers_without_another_reset',
        'neuron_generation_runtime::tests::update::adopted_learning::updated_actor_rechecks_current_withdrawal_and_revocation',
        'neuron_generation_runtime::tests::update::learning::ordinary_actor_reads_actual_use_and_cold_recovery_without_reexecution',
        'neuron_generation_runtime::tests::update::learning::running_actor_refuses_current_withdrawal_and_revocation',
        'neuron_generation_runtime::tests::update::learning::unpublished_actor_refuses_learning_readback_and_keeps_transport_errors',
    ]),
    ('unknown_restart3', 'codex-hepta-agentd', [
        'neuron_generation_runtime::tests::control::uncertain_dispatch_cancels_and_reads_original_without_second_execution',
        'neuron_generation_runtime::tests::both_drain_paths_retain_unknown_work_and_unacknowledged_output',
        'neuron_generation_runtime::tests::ordinary_shutdown_reopens_original_pending_and_exact_committed_outbox',
    ]),
    ('durable_effects4', 'codex-hepta-operations', [
        'durable_store::tests::crash_after_dispatch_admission_recovers_as_indeterminate_not_retryable',
        'durable_store::tests::acknowledgement_loss_stays_indeterminate_until_terminal_observer',
        'durable_store::tests::retirement_never_discards_an_unreconciled_external_effect',
        'fault_tests::child_process_kill_matrix_preserves_durable_effect_semantics',
    ]),
]
PROFILES = ['AGENTS.md', 'justfile', 'scripts/run-nextest.py', 'scripts/just-shell.py',
            'codex-rs/.config/nextest.toml', 'codex-rs/rust-toolchain.toml',
            'codex-rs/.cargo/config.toml', 'codex-rs/Cargo.lock']
state = {'schema': 'hepta-native-engineering-controls-v1', 'source_sha': EXPECTED,
         'chain_sha': None, 'engineering_controls_only': True,
         'production_final_use_qualified': False, 'attempts': [], 'collector_errors': []}
env = dict(os.environ)


def sha(path):
    with open(path, 'rb') as f:
        h = hashlib.sha256()
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def save(name, obj):
    p = EV / name
    t = p.with_suffix(p.suffix + '.tmp')
    t.write_text(json.dumps(obj, sort_keys=True, indent=2) + '\n')
    t.replace(p)


def status(stage):
    state['stage'] = stage
    state['updated_unix_ns'] = time.time_ns()
    save('status.json', state)
    print(json.dumps({'stage': stage, 'attempts': len(state['attempts'])}), flush=True)


def quick(argv, cwd=SRC):
    p = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True)
    return {'argv': argv, 'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}


def snapshot(label):
    head = quick(['git', 'rev-parse', 'HEAD'])
    tree = quick(['git', 'rev-parse', 'HEAD^{tree}'])
    diff = quick(['git', 'diff', '--name-status', 'HEAD'])
    untracked = quick(['git', 'ls-files', '--others', '--exclude-standard'])
    profiles = {}
    (EV / 'original-config').mkdir(exist_ok=True)
    for rel in PROFILES:
        p = SRC / rel
        if p.is_file():
            profiles[rel] = {'sha256': sha(p), 'bytes': p.stat().st_size}
            dst = EV / 'original-config' / rel.replace('/', '__')
            if not dst.exists():
                shutil.copy2(p, dst)
    user_config = Path(env.get('XDG_CONFIG_HOME', str(Path.home() / '.config'))) / 'nextest/config.toml'
    r = {'head': head, 'tree': tree, 'tracked_diff': diff, 'untracked': untracked,
         'profiles': profiles, 'nextest_user_config': {'path': str(user_config),
         'exists': user_config.exists(), 'sha256': sha(user_config) if user_config.is_file() else None}}
    save(label + '-source.json', r)
    if head['exit_code'] or head['stdout'].strip() != EXPECTED or diff['exit_code'] or diff['stdout']:
        raise RuntimeError('source HEAD or tracked contents differs from expected f178')
    return r


def resources():
    r = {'pid': os.getpid(), 'nice': os.nice(0), 'cgroup': Path('/proc/self/cgroup').read_text()}
    for line in r['cgroup'].splitlines():
        if line.startswith('0::'):
            cg = Path('/sys/fs/cgroup') / line[3:].lstrip('/')
            r['effective_limits'] = {name: (cg / name).read_text().strip() for name in
                ['cpu.max', 'memory.max', 'memory.swap.max', 'pids.max'] if (cg / name).is_file()}
    r['disk'] = shutil.disk_usage(OUT)._asdict()
    return r


def descendants(pid):
    todo, found = [pid], set()
    while todo:
        n = todo.pop()
        if n in found:
            continue
        found.add(n)
        try:
            todo.extend(int(s) for s in Path(f'/proc/{n}/task/{n}/children').read_text().split())
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    return found


def observe_exec(pid, stop, records, errors):
    seen = set()
    while not stop.is_set():
        for n in descendants(pid):
            try:
                p = Path(f'/proc/{n}/exe')
                exe = os.readlink(p)
                if not exe.startswith(str(TARGET)) or not Path(exe).name.startswith(('codex_hepta_agentd-', 'codex_hepta_operations-')):
                    continue
                stat = Path(f'/proc/{n}/stat').read_text().split(') ', 1)[1].split()
                key = (n, stat[19])
                if key in seen:
                    continue
                seen.add(key)
                records.append({'pid': n, 'start_ticks': stat[19], 'exe': exe,
                                'observed_unix_ns': time.time_ns(), 'sha256': sha(p),
                                'argv': Path(f'/proc/{n}/cmdline').read_bytes().decode().split('\0')[:-1]})
            except (FileNotFoundError, ProcessLookupError):
                # A short-lived process can disappear before a complete observation.
                continue
            except Exception as e:
                errors.append(type(e).__name__ + ': ' + str(e))
        stop.wait(0.02)


def command(label, argv, cwd=SRC, observe=False):
    a = {'id': label, 'argv': argv, 'cwd': str(cwd), 'start_unix_ns': time.time_ns(),
         'native_exit': None, 'collector_exit': None, 'attempt': 1,
         'stdout': label + '.stdout.log', 'stderr': label + '.stderr.log'}
    state['attempts'].append(a)
    status('running:' + label)
    records, errors = [], []
    with (EV / a['stdout']).open('wb') as o, (EV / a['stderr']).open('wb') as e:
        proc = subprocess.Popen(argv, cwd=cwd, env=env, stdout=o, stderr=e)
        a['pid'] = proc.pid
        stop = threading.Event()
        thread = threading.Thread(target=observe_exec, args=(proc.pid, stop, records, errors), daemon=True) if observe else None
        if thread:
            thread.start()
        save('status.json', state)
        a['native_exit'] = proc.wait()
        stop.set()
        if thread:
            thread.join(timeout=10)
            if thread.is_alive():
                errors.append('ELF observer did not complete before 10s collection deadline')
    a.update({'end_unix_ns': time.time_ns(), 'collector_exit': 0 if not errors else 1,
              'stdout_sha256': sha(EV / a['stdout']), 'stderr_sha256': sha(EV / a['stderr']),
              'elf_observations': records, 'collector_errors': errors})
    save(label + '-receipt.json', a)
    status('completed:' + label)
    return a


def binary_paths(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k == 'binary-path' and isinstance(v, str):
                yield Path(v)
            else:
                yield from binary_paths(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from binary_paths(v)


def main():
    EV.mkdir(parents=True, exist_ok=True)
    marker = EV / 'campaign-started.json'
    with marker.open('x') as f:
        json.dump({'pid': os.getpid(), 'unix_ns': time.time_ns(), 'source': EXPECTED}, f)
    status('source-preflight')
    before = snapshot('before')
    state['resources'] = resources()
    state['runner_sha256'] = sha(__file__)
    TOOLS.mkdir(exist_ok=True)
    original_nextest = OLD / 'tools/bin/cargo-nextest'
    shutil.copy2(original_nextest, TOOLS / 'cargo-nextest')
    state['nextest_tool'] = {'source': str(original_nextest), 'sha256': sha(TOOLS / 'cargo-nextest')}
    env.update({'PATH': str(TOOLS) + ':/home/qian-qi/.cargo/bin:' + env['PATH'],
                'CARGO_TARGET_DIR': str(TARGET), 'CARGO_BUILD_JOBS': '2',
                'RUSTUP_TOOLCHAIN': '1.96.0', 'NEXTEST_PROFILE': 'local',
                'RUST_MIN_STACK': '8388608', 'HEPTA_GENERATION_LEARNING_READBACK_STDOUT': '1'})
    state['environment'] = {k: env[k] for k in ['PATH', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
        'RUSTUP_TOOLCHAIN', 'NEXTEST_PROFILE', 'RUST_MIN_STACK', 'HEPTA_GENERATION_LEARNING_READBACK_STDOUT']}
    state['tool_versions'] = {name: quick(argv) for name, argv in [
        ('rustc', ['rustc', '-vV']), ('cargo', ['cargo', '--version']),
        ('nextest', ['cargo', 'nextest', '--version']), ('just', ['just', '--version'])]}
    if any(r['exit_code'] for r in state['tool_versions'].values()):
        raise RuntimeError('required tool version check failed')
    if TARGET.exists():
        raise RuntimeError('target already exists; refusing ambiguous cache reuse')
    a = command('cache_copy', ['/bin/cp', '-a', '--reflink=auto', str(OLD / 'target'), str(TARGET)])
    if a['native_exit']:
        raise RuntimeError('cache copy failed')
    # Remove only private-copy outputs of the tested packages. Dependencies may
    # be reused, but both selected test binaries must be built for this source.
    removed = []
    patterns = {'debug/deps': ['codex_hepta_agentd-*', 'codex_hepta_operations-*', 'libcodex_hepta_agentd-*', 'libcodex_hepta_operations-*'],
                'debug/.fingerprint': ['codex-hepta-agentd-*', 'codex-hepta-operations-*'],
                'debug/incremental': ['codex_hepta_agentd-*', 'codex_hepta_operations-*']}
    for rel, globs in patterns.items():
        for pattern in globs:
            for p in (TARGET / rel).glob(pattern):
                removed.append(str(p.relative_to(TARGET)))
                if p.is_dir() and not p.is_symlink():
                    shutil.rmtree(p)
                else:
                    p.unlink()
    # Prior JUnit cannot be confused with this attempt.
    for p in (TARGET / 'nextest').glob('*/junit.xml'):
        removed.append(str(p.relative_to(TARGET)))
        p.unlink()
    save('excluded-cache-outputs.json', removed)
    metadata = command('cargo_metadata', ['cargo', 'metadata', '--no-deps', '--locked', '--format-version=1'], SRC / 'codex-rs')
    if metadata['native_exit']:
        raise RuntimeError('locked metadata failed')
    listing = command('native_registry_build', ['cargo', 'nextest', 'list', '--locked',
        '--cargo-metadata', str(EV / metadata['stdout']), '-p', 'codex-hepta-agentd',
        '-p', 'codex-hepta-operations', '--lib', '--message-format', 'json'], SRC / 'codex-rs')
    if listing['native_exit']:
        raise RuntimeError('native registry build failed; no selected tests executed')
    registry = json.loads((EV / listing['stdout']).read_text())
    binaries = sorted(set(binary_paths(registry)))
    if len(binaries) != 2 or any(not p.is_relative_to(TARGET) for p in binaries):
        raise RuntimeError('unexpected compiled test binary registry')
    state['binaries_before'] = {str(p): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in binaries}
    (EV / 'binaries').mkdir(exist_ok=True)
    for p in binaries:
        shutil.copy2(p, EV / 'binaries' / p.name)
    save('binaries-before.json', state['binaries_before'])
    for label, package, names in SCOPES:
        expression = ' | '.join('test(=' + n + ')' for n in names)
        argv = ['just', 'test', '--locked', '-p', package, '--lib', '-E', expression,
                '--success-output', 'final', '--failure-output', 'final']
        junit = TARGET / 'nextest/local/junit.xml'
        if junit.exists():
            raise RuntimeError('stale JUnit before scope ' + label)
        a = command(label, argv, observe=True)
        a['selected_tests'] = names
        a['junit'] = None
        if junit.is_file():
            dst = EV / (label + '-junit.xml')
            shutil.copy2(junit, dst)
            a['junit'] = {'path': str(dst), 'sha256': sha(dst)}
            junit.unlink()
        a['binaries_after'] = {str(p): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in binaries}
        a['binary_changed'] = a['binaries_after'] != state['binaries_before']
        save(label + '-receipt.json', a)
        snapshot(label + '-after')
    after = snapshot('after')
    state['source_profiles_unchanged'] = before['profiles'] == after['profiles']
    state['control_commands_successful'] = all(a['native_exit'] == 0 for a in state['attempts'])
    state['status'] = 'ENGINEERING_CONTROLS_RECORDED_HOLD'
    status('complete')
    return 0 if state['control_commands_successful'] else 2


if __name__ == '__main__':
    try:
        exit_code = main()
    except Exception as e:
        state['collector_errors'].append({'type': type(e).__name__, 'message': str(e), 'traceback': traceback.format_exc()})
        state['status'] = 'INCOMPLETE_HOLD'
        EV.mkdir(parents=True, exist_ok=True)
        status('failed')
        exit_code = 1
    state['collector_exit'] = exit_code
    save('result.json', state)
    status(state['stage'])
    raise SystemExit(exit_code)
