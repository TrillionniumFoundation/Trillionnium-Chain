#!/usr/bin/env python3
"""Exact byte comparison to a previously replayed corpus; does not replay it.

The earlier local readback receipt is evidence, not authenticated remote proof.
This command deliberately reports only equality and row-cost reconciliation.
"""
from pathlib import Path
import argparse,hashlib,json,itertools
from check_cost_evidence import METHODS,RECORD_BYTES,require,read_bounded

def compare(previous,current,receipt):
    old_raw=read_bounded(previous/'raw.json',64*1024*1024)
    new_raw=read_bounded(current/'raw.json',64*1024*1024)
    old=json.loads(old_raw);new=json.loads(new_raw);replay=json.loads(receipt.read_text())
    require(replay['result']=='PASS'and replay['raw_sha256']==hashlib.sha256(old_raw).hexdigest(),'PRIOR_RECEIPT_BINDING')
    old_streams={s['case']:s for s in old['proof_streams']}
    reference={};records=0
    for stream in new['proof_streams']:
        case=stream['case'];require(stream['path']==f'proofs-{case}.bin','PATH')
        baseline=old_streams[case]
        require(stream['format']==baseline['format']and stream['records']==baseline['records'],'FORMAT')
        left=read_bounded(previous/baseline['path'],1024*RECORD_BYTES)
        right=read_bounded(current/stream['path'],1024*RECORD_BYTES)
        require(left==right,'OUTPUT_BYTES_CHANGED')
        require(hashlib.sha256(right).hexdigest()==stream['sha256']==baseline['sha256'],'OUTPUT_HASH_CHANGED')
        records+=stream['records']
    for row in old['rows']:
        for attempt in row.get('attempts',[]):reference[row['case'],attempt['nonce']]=attempt
    expected=set(itertools.product(new['cases'],METHODS,new['horizons'],range(new['samples'])))
    calls=wins=unsupported=0
    for row in new['rows']:
        key=(row['case'],row['method'],row['horizon'],row['sample']);require(key in expected,'ROW_KEY');expected.remove(key)
        if row['status']=='UNSUPPORTED':unsupported+=1;continue
        require(row['status']=='BYTE_IDENTICAL_FULL_W1'and len(row['attempts'])==row['horizon'],'ATTEMPT_COUNT')
        for index,attempt in enumerate(row['attempts']):
            require(attempt['nonce']==index+1,'NONCE')
            original=reference[row['case'],index+1]
            for field in ['proof_sha256','ticket','winner']:require(attempt[field]==original[field],'PRIOR_ATTEMPT '+field)
            calls+=1;wins+=int(attempt['winner'])
        for total in ['generate_cpu_ns','generate_wall_ns','winner_verify_cpu_ns','winner_verify_wall_ns']:
            require(row[total]==sum(a[total]for a in row['attempts']),'COST_TOTAL')
        require(row['total_producer_cpu_ns']==row['setup_cpu_ns']+row['generate_cpu_ns'],'SETUP_COST')
        require(row['winners']==sum(int(a['winner'])for a in row['attempts']),'WIN_COUNT')
        require(row['cpu_ns_per_win']==(row['total_producer_cpu_ns']//row['winners']if row['winners']else None),'WIN_DENOMINATOR')
    require(not expected,'MISSING_ROWS')
    return dict(result='PASS',scope='exact retained-byte equality to earlier local Python-replayed corpus; no new Python relation execution',
                old_raw_sha256=hashlib.sha256(old_raw).hexdigest(),new_raw_sha256=hashlib.sha256(new_raw).hexdigest(),
                prior_readback_sha256=hashlib.sha256(receipt.read_bytes()).hexdigest(),identical_unique_records=records,
                new_timed_attempt_calls=calls,new_wins=wins,new_target_misses=calls-wins,unsupported_rows=unsupported,
                node_task_eligibility_checked=False,global_minimum_cost_proved=False)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('previous',type=Path);p.add_argument('current',type=Path);p.add_argument('receipt',type=Path)
    args=p.parse_args();print(json.dumps(compare(args.previous,args.current,args.receipt),indent=2))
