import datetime, hashlib, json, os, pathlib, re, subprocess, sys, time
root=pathlib.Path('/workspace/scratch/d95a703b8dd6/chain-six-capabilities')
out=pathlib.Path(sys.argv[1]); out.mkdir(parents=True,exist_ok=False)
env=os.environ.copy()
env.update(RUSTUP_HOME='/workspace/scratch/d95a703b8dd6/toolchain/rustup',CARGO_HOME='/workspace/scratch/d95a703b8dd6/toolchain/cargo',CARGO_TARGET_DIR='/workspace/scratch/d95a703b8dd6/target-six-capabilities',CARGO_BUILD_JOBS='2',RUST_TEST_THREADS='1',CARGO_TERM_COLOR='never',PYTHONDONTWRITEBYTECODE='1')
env['PATH']='/workspace/scratch/d95a703b8dd6/toolchain/cargo/bin:'+env['PATH']
for line in pathlib.Path('/workspace/scratch/d95a703b8dd6/provider-setup/provider.env').read_text().splitlines():
 k,v=line.split('=',1); assert k in {'OPENSSL_DIR','OPENSSL_STATIC','TRNM_PQ_OPENSSL','TRNM_PQ_OPENSSL_SHA256','TRNM_PQ_OPENSSL_VERSION','OPENSSL_CONF','OPENSSL_MODULES'};env[k]=v
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
base='9f54b05c643185a5041fc1f78cef77e95877f52a'
pattern=re.compile(r'#\[test\]\s*(?:#\[[^\]]*\]\s*)*fn\s+(\w+)')
newtests=set()
for filename in subprocess.check_output(['git','diff','--name-only',base,head],cwd=root,text=True).splitlines():
 p=root/filename
 if p.suffix!='.rs':continue
 before=subprocess.run(['git','show',base+':'+filename],cwd=root,capture_output=True,text=True).stdout
 newtests.update(set(pattern.findall(p.read_text()))-set(pattern.findall(before)))
(out/'required-new-tests.json').write_text(json.dumps(sorted(newtests),indent=2)+'\n')
meta=['cargo','metadata','--locked','--offline','--format-version','1']
cargo=['cargo','test','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','-p','trnm-data-availability']
commands=[
 ('preflight',['bash','scripts/project-preflight.sh','--audit'],60),
 ('source-before',['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',head,'--output',str(out/'source-before.json')],120),
 ('graph-default',meta+['--manifest-path','trillionnium/Cargo.toml'],120),
 ('graph-all-features',meta+['--manifest-path','trillionnium/Cargo.toml','--all-features'],120),
 ('graph-fuzz',meta+['--manifest-path','tests/fuzz/Cargo.toml'],120),
 ('format',['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'],120),
 ('version-vector',['python3','-B','scripts/cell_complete_version_vector.py','--check'],30),
 ('p2p-complete',cargo+['--','--test-threads=1'],900),
 ('clippy-workspace',['cargo','clippy','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','--workspace','--all-targets','--all-features','--','-D','warnings'],1200),
 ('source-negative',['python3','-B','scripts/ci/test_ci_source_integrity.py'],180),
 ('pq-source-negative',['python3','-B','scripts/ci/test_pq_research_integration.py'],180),
 ('ci-contract',['python3','-B','scripts/ci/test_ci_contract.py'],180),
 ('repository',['python3','-B','scripts/ci/check_repository.py'],240),
 ('pq-source-pins',['python3','-B','scripts/ci/check_pq_research_integration.py'],60),
 ('inventory',['python3','-B','scripts/refresh_distributed_source_inventory.py','--check'],60),
 ('source-after',['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',head,'--output',str(out/'source-after.json')],120),
 ('diff',['git','diff','--exit-code'],30),
]
summary={'schema':'trnm-cell-six-capabilities-validation-v1','source':head,'base':base,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'shared Linux x86_64 component validation; not fixed-resource Host/WAN/GPU/Hepta FinalUse acceptance','new_native_test_names':len(newtests),'commands':[],'production_qualified':False}
for label,argv,limit in commands:
 path=out/(label+'.log'); started=time.monotonic(); timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  with path.open('wb') as f:result=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=limit)
  code=result.returncode; timed_out=False
 except subprocess.TimeoutExpired:code=124;timed_out=True
 raw=path.read_bytes();text=raw.decode(errors='replace'); passed=code==0; missing=[]
 if label=='p2p-complete':
  missing=[name for name in sorted(newtests) if not re.search(r'test\s+[^\n ]*::'+re.escape(name)+r'\s+\.\.\.\s+ok',text)]
  passed=passed and not missing and 'running 423 tests' in text
  (out/'native-results.json').write_text(json.dumps({'required_new_tests':len(newtests),'missing_successful_new_tests':missing,'result_lines':re.findall(r'test result: [^\n]+',text),'passed':passed},indent=2)+'\n')
 row={'label':label,'argv':argv,'started_at':timestamp,'elapsed_seconds':time.monotonic()-started,'exit_code':code,'timeout':timed_out,'passed':passed,'log':path.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 if missing:row['missing_successful_new_tests']=missing
 summary['commands'].append(row)
 summary['passed']=all(x['passed'] for x in summary['commands'])
 (out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'label':label,'exit_code':code,'passed':passed,'elapsed_seconds':row['elapsed_seconds']}),flush=True)
 if label in {'preflight','source-before'} and not passed: break
summary['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
summary['complete']=len(summary['commands'])==len(commands)
summary['passed']=summary['complete'] and all(x['passed'] for x in summary['commands'])
(out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({'source':head,'complete':summary['complete'],'passed':summary['passed'],'commands':len(summary['commands'])}),flush=True)
sys.exit(0 if summary['passed'] else 1)
