#!/usr/bin/env python3
"""Retain one unchanged strict workspace Clippy command with a pinned provider.

Importing this module has no environment, filesystem-write or process effects.
provider_identity() reads only the five named provider inputs. The environment
helpers are pure computations; callers retain control over applying their result.
The 165d supplement runs only through main(). It never rebuilds the provider,
changes repository source, reduces features, or replaces the original failure.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

ROOT = Path('/home/qian-qi/work/chain-w1-baseline-20261111-9082')
WORK = ROOT.parent
HEAD = '165d286b687e0a73d7fe68148d2179274fc0c0b8'
VALIDATION = WORK / 'w1-baseline-9082-validation-165d'
OUT = VALIDATION / 'supplemental-provider-clippy'
TARGET = WORK / 'w1-baseline-9082-target-165d'
PREFIX = Path('/tmp/chain-pq-fa62381e-provider/attempt-4-gh-source/runner/trnm-pq-provider-3.5.9.lcOEkd1h/install')
PROVIDER_PINS = (
    ('bin/openssl', 8933408, '9c55ae4a8820dd89dcd57359579e15b92a6e827eb5d4be8b07d9dc211c7b4fed'),
    ('include/openssl/opensslv.h', 3449, '9647fc99758cf83e3bcf11ae310894fd4911ad62bff22d8213a614df89cfedda'),
    ('include/openssl/configuration.h', 4729, '406c26f93511299b264062f9f3faf0760e7a0506e91a61717c491f3c92e1a996'),
    ('lib/libcrypto.a', 12381456, '053ccb2992b187a71af3389204e87c86d2e15597fa29c00eef16c5b24a9c6675'),
    ('lib/libssl.a', 2123138, 'f355167951857505b5b0305fd2e8ea8f224fa29d780211175d32767b07234727'),
)
CLIPPY = ['cargo', 'clippy', '--locked', '--offline', '--manifest-path',
          'trillionnium/Cargo.toml', '--workspace', '--all-targets', '--all-features',
          '--', '-D', 'warnings']
CLIPPY_TIMEOUT_SECONDS = 3600
SOURCE_TIMEOUT_SECONDS = 600
PREFLIGHT_TIMEOUT_SECONDS = 120
IDENTITY_TIMEOUT_SECONDS = 30
REFERENCE_VALIDATOR_SHA256 = 'c5ac638fdcac32bc3285a164b0b83ed1c7cc3e54dfd6b27e016eed4da1bab588'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def _fingerprint(info):
    return [info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns]


def regular_identity(path):
    """Hash a named regular file without modifying it or following symlinks."""
    path = Path(path)
    for item in (path, *path.parents):
        require(not item.is_symlink(), 'linked input: ' + str(item))
    descriptor = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW)
    with os.fdopen(descriptor, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), 'nonregular input: ' + str(path))
        digest = hashlib.sha256()
        size = 0
        while data := stream.read(1024 * 1024):
            digest.update(data)
            size += len(data)
        after = os.fstat(stream.fileno())
    require(size == before.st_size and _fingerprint(before) == _fingerprint(after)
            == _fingerprint(path.stat(follow_symlinks=False)), 'input changed during hash: ' + str(path))
    return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest(),
            'fingerprint': _fingerprint(before)}


def provider_identity():
    """Read exactly the five historical pinned inputs; never run the provider."""
    rows = []
    for relative, size, sha256 in PROVIDER_PINS:
        row = {'relative': relative, 'expected_bytes': size, 'expected_sha256': sha256}
        try:
            row['actual'] = regular_identity(PREFIX / relative)
            row['matches'] = row['actual']['bytes'] == size and row['actual']['sha256'] == sha256
        except (OSError, ValueError) as error:
            row.update(matches=False, error=type(error).__name__ + ': ' + str(error))
        rows.append(row)
    return {'schema': 'TRNM-W1-PINNED-PROVIDER-IDENTITY1', 'prefix': str(PREFIX),
            'version': '3.5.9', 'files': rows, 'all_five_match': all(row['matches'] for row in rows),
            'historical_evidence_blob': 'db1adccc8acdc946942a2f6f0659b8b8e33a3e24',
            'historical_archive_sha256': '7245fa35c28c6e071f557446c6b8d5f0679156866a2b2f3e64f41f2a22cac1fb',
            'historical_provider_receipt_sha256': '11385cc846676d18e392d46055e9a946bc027c55c2d487e01fe289a220c21d03'}


def expected_environment():
    """Return the original seven exported keys, without applying them."""
    return {'OPENSSL_DIR': str(PREFIX), 'OPENSSL_STATIC': '1',
            'TRNM_PQ_OPENSSL': str(PREFIX / 'bin/openssl'),
            'TRNM_PQ_OPENSSL_SHA256': PROVIDER_PINS[0][2], 'TRNM_PQ_OPENSSL_VERSION': '3.5.9',
            'OPENSSL_CONF': '/dev/null', 'OPENSSL_MODULES': str(PREFIX / 'lib/ossl-modules')}


def check_inherited_environment(environment):
    """Report conflicts without changing environment or disclosing unknown values."""
    expected = expected_environment()
    consistent_optional = {'OPENSSL_INCLUDE_DIR': str(PREFIX / 'include'),
                           'OPENSSL_LIB_DIR': str(PREFIX / 'lib')}
    for name in ('OPENSSL_DIR', 'OPENSSL_STATIC', 'OPENSSL_INCLUDE_DIR', 'OPENSSL_LIB_DIR'):
        consistent_optional['X86_64_UNKNOWN_LINUX_GNU_' + name] = (
            expected[name] if name in expected else consistent_optional[name])
    permitted = {**expected, **consistent_optional}
    selected = {name: value for name, value in environment.items()
                if 'OPENSSL' in name and value}
    conflicts = []
    inherited = {}
    for name, value in sorted(selected.items()):
        if name not in permitted:
            inherited[name] = {'present': True, 'value_recorded': False}
            conflicts.append({'key': name, 'reason': 'unreviewed OpenSSL selection; not removed or overwritten'})
        else:
            inherited[name] = value
            if value != permitted[name]:
                conflicts.append({'key': name, 'reason': 'conflicts with the historical pinned selection; not overwritten'})
    return {'inherited_selection': inherited, 'expected_seven_key_export': expected,
            'consistent_optional_selection': {key: selected[key] for key in consistent_optional if key in selected},
            'conflicts': conflicts, 'compatible': not conflicts}


def _write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def _copy_small_regular(source, destination, limit=32 * 1024 * 1024):
    before = regular_identity(source)
    require(before['bytes'] <= limit, 'retained control file exceeds bound')
    descriptor = os.open(source, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW)
    with os.fdopen(descriptor, 'rb') as stream:
        data = stream.read(limit + 1)
    require(len(data) == before['bytes'] and hashlib.sha256(data).hexdigest() == before['sha256'],
            'retained control bytes changed before copy')
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    require(regular_identity(source) == before, 'original control file changed during retention')
    copied = regular_identity(destination)
    require((copied['bytes'], copied['sha256']) == (before['bytes'], before['sha256']), 'copied control bytes differ')
    return {'source': before, 'retained': copied}, data


def main():
    require(VALIDATION.is_dir() and not VALIDATION.is_symlink(), 'original validation directory is missing or linked')
    require(not OUT.exists() and not OUT.is_symlink(), 'supplement output is create-only')
    OUT.mkdir()
    os.chdir(ROOT)
    os.environ['PATH'] = '/home/qian-qi/.cargo/bin:' + os.environ['PATH']
    os.environ['CARGO_TARGET_DIR'] = str(TARGET)
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT / 'scripts/ci'))
    from run_w1_rank_batch_v5 import (capture, discover_tool, digest,
                                    cargo_configuration_snapshot, require_cargo_configuration,
                                    build_environment_overrides)
    report = {'schema': 'TRNM-W1-PROVIDER-STRICT-CLIPPY-SUPPLEMENT1', 'result': 'HOLD',
              'head': HEAD, 'command': CLIPPY, 'timeout_seconds': CLIPPY_TIMEOUT_SECONDS,
              'original_failure_replaced': False, 'provider_rebuilt': False,
              'source_modified': False, 'features_reduced': False, 'original_timeout_increased': False,
              'main_campaign_rerun': False, 'production_activation': False, 'security_qualified': False,
              'process_usage_scope': 'wait4; unreaped-descendant costs may be missing',
              'rss_scope': 'kernel ru_maxrss; not sum or global simultaneous peak',
              'commands': [], 'original_files': [], 'final_errors': [], 'started_unix': time.time()}

    def run(command, stem, timeout):
        print(json.dumps({'command_started': stem, 'command': command,
                          'timeout_seconds': timeout, 'started_unix': time.time()}), flush=True)
        observed = capture(command, OUT, stem, timeout=timeout)
        observed['finished_unix'] = time.time()
        report['commands'].append(observed)
        _write_json(OUT / (stem + '.json'), observed)
        with (OUT / 'commands.jsonl').open('a') as stream:
            stream.write(json.dumps(observed, sort_keys=True) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
        print(json.dumps({'command_finished': stem, 'exit_code': observed['exit_code'],
                          'timed_out': observed['timed_out'], 'elapsed_ns': observed['elapsed_ns'],
                          'wait4_cpu_ns': observed['wait4_cpu_ns']}), flush=True)
        return observed

    def checked(command, stem, timeout):
        observed = run(command, stem, timeout)
        require(observed['exit_code'] == 0 and not observed['timed_out'], 'command failed: ' + stem)
        return observed

    def source(stem):
        identity = OUT / (stem + '-identity.json')
        require(not identity.exists() and not identity.is_symlink(), 'source receipt already exists')
        checked(['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head',
                 '--expected-head', HEAD, '--output', str(identity)], stem, SOURCE_TIMEOUT_SECONDS)
        return json.loads(identity.read_text())

    try:
        helper, _ = _copy_small_regular(Path(__file__).absolute(), OUT / 'helpers/supplemental-provider-clippy-165d.py')
        report['executed_helper'] = helper
        reference, _ = _copy_small_regular(WORK / 'w1-baseline-9082-validate-frozen165d.py',
                                           OUT / 'helpers/reference-validator.py')
        require(reference['source']['sha256'] == REFERENCE_VALIDATOR_SHA256, 'original validator helper changed')
        report['reference_validator'] = reference
        originals = {}
        for name in ('workspace-strict-clippy.json', 'workspace-strict-clippy.stdout',
                     'workspace-strict-clippy.stderr', 'checks-phase.json'):
            retained, data = _copy_small_regular(VALIDATION / name, OUT / 'original-failure' / name)
            report['original_files'].append(retained)
            originals[name] = data
        failed = json.loads(originals['workspace-strict-clippy.json'])
        phase = json.loads(originals['checks-phase.json'])
        require(failed['command'] == CLIPPY and failed['timeout_seconds'] == CLIPPY_TIMEOUT_SECONDS
                and failed['exit_code'] == 101 and failed['timed_out'] is False
                and failed['executed'] is True, 'original failed command differs from the reviewed observation')
        require(phase['head'] == HEAD and phase['phase'] == 'checks' and phase['success'] is False,
                'original phase identity or failure status differs')
        matches = [row for row in phase['commands'] if row.get('stdout') == 'workspace-strict-clippy.stdout']
        require(matches == [failed], 'original phase does not contain exactly the retained failed command')
        stderr = originals['workspace-strict-clippy.stderr'].decode('utf-8', errors='replace')
        require(all(marker in stderr for marker in ('E0599', 'private_key_from_seed', 'pq_openssl_native.rs')),
                'the retained compiler diagnostic differs from the reviewed failure')
        report['original_failure'] = {'exit_code': 101, 'timed_out': False,
                                      'diagnostic': 'E0599 private_key_from_seed in pq_openssl_native.rs',
                                      'record_sha256': report['original_files'][0]['source']['sha256'],
                                      'retained_original_status_unchanged': True}
        report['source_before'] = source('source-before')
        checked(['bash', 'scripts/project-preflight.sh', '--dev'], 'preflight', PREFLIGHT_TIMEOUT_SECONDS)
        report['provider_before'] = provider_identity()
        _write_json(OUT / 'provider-before.json', report['provider_before'])
        require(report['provider_before']['all_five_match'], 'current provider inputs do not match all five historical pins')
        selection = check_inherited_environment(dict(os.environ))
        _write_json(OUT / 'provider-environment-selection.json', selection)
        report['provider_environment_selection'] = selection
        require(selection['compatible'], 'inherited provider selection conflicts; no environment override performed')
        os.environ.update(expected_environment())
        report['effective_seven_key_environment'] = {key: os.environ[key] for key in expected_environment()}
        report['build_environment_overrides'] = build_environment_overrides(dict(os.environ))
        require(not report['build_environment_overrides'], 'unreviewed Cargo/compiler environment override')
        report['cargo_configuration_before'] = cargo_configuration_snapshot(ROOT, dict(os.environ))
        require_cargo_configuration(report['cargo_configuration_before'])
        tools = {name: discover_tool(name) for name in ('rustc', 'cargo')}
        report['toolchain'] = {name: {'path': str(path), 'resolved_launcher': str(path.resolve(strict=True)),
                                    'launcher_sha256': digest(path)} for name, path in tools.items()}
        checked([str(tools['rustc']), '-vV'], 'rustc', IDENTITY_TIMEOUT_SECONDS)
        checked([str(tools['cargo']), '--version'], 'cargo', IDENTITY_TIMEOUT_SECONDS)
        compiler = (OUT / 'rustc.stdout').read_text()
        require('\nrelease: 1.95.0\n' in compiler and '\nhost: x86_64-unknown-linux-gnu\n' in compiler,
                'original Rust 1.95.0 x86_64 contract differs')
        require((OUT / 'cargo.stdout').read_text().startswith('cargo 1.95.0 '), 'original Cargo 1.95.0 contract differs')
        checked([str(PREFIX / 'bin/openssl'), 'version', '-a'], 'provider-version', IDENTITY_TIMEOUT_SECONDS)
        version = (OUT / 'provider-version.stdout').read_text().splitlines()[0]
        require(version == 'OpenSSL 3.5.9 29 Sep 2026 (Library: OpenSSL 3.5.9 29 Sep 2026)',
                'pinned provider version output differs')
        report['provider_version_output'] = version
        report['clippy_observation'] = run(CLIPPY, 'workspace-strict-clippy-pinned-provider', CLIPPY_TIMEOUT_SECONDS)
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        report['error'] = type(error).__name__ + ': ' + str(error)
    finally:
        try:
            report['provider_after'] = provider_identity()
            _write_json(OUT / 'provider-after.json', report['provider_after'])
            require(report['provider_after']['all_five_match']
                    and report.get('provider_before') == report['provider_after'], 'provider identity absent, changed or mismatched')
        except (OSError, ValueError, KeyError, TypeError) as error:
            report['final_errors'].append(type(error).__name__ + ': ' + str(error))
        try:
            report['source_after'] = source('source-after')
            require(report.get('source_before') == report['source_after'], 'full-source identities differ or initial identity is absent')
            report['cargo_configuration_after'] = cargo_configuration_snapshot(ROOT, dict(os.environ))
            require_cargo_configuration(report['cargo_configuration_after'])
            require(report.get('cargo_configuration_before') == report['cargo_configuration_after'],
                    'Cargo configuration changed or initial snapshot is absent')
            if 'effective_seven_key_environment' in report:
                require(report['effective_seven_key_environment'] == expected_environment()
                        == {key: os.environ.get(key) for key in expected_environment()}, 'effective provider selection changed')
            for item in report['original_files']:
                require(regular_identity(Path(item['source']['path'])) == item['source'],
                        'an original failed observation changed')
        except (OSError, ValueError, KeyError, TypeError) as error:
            report['final_errors'].append(type(error).__name__ + ': ' + str(error))
        observed = report.get('clippy_observation', {})
        if not report.get('error') and not report['final_errors'] and observed.get('exit_code') == 0 and observed.get('timed_out') is False:
            report['result'] = 'SUPPLEMENTAL_WORKSPACE_CLIPPY_PASSED'
        report['finished_unix'] = time.time()
        report['failed_commands'] = sum(row['exit_code'] != 0 or row['timed_out'] for row in report['commands'])
        report['artifact_files'] = [regular_identity(path) for path in sorted(OUT.rglob('*')) if path.is_file()]
        _write_json(OUT / 'supplement.json', report)
    print(json.dumps({'result': report['result'], 'receipt': str(OUT / 'supplement.json'),
                      'original_failed_attempt_retained': True}), flush=True)
    return 0 if report['result'] == 'SUPPLEMENTAL_WORKSPACE_CLIPPY_PASSED' else 1


if __name__ == '__main__':
    raise SystemExit(main())
