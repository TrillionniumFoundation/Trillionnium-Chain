"""Independent finite-schedule resource and literal-predicate controls.

Run from the repository root. These are conditional model checks, not QPU
execution, independently measured classical clocks, or a security theorem.
"""
from pathlib import Path
import copy
from dataclasses import asdict, replace
from decimal import Decimal
from fractions import Fraction
import hashlib
import json
import math
import sys

formal = Path('formal/pon-nakamoto-v1')
sys.path.insert(0, str(formal))
sys.path.insert(0, str(formal / 'experiments'))
from quantum_oracle_resources import ClassicalCosts, example
from w1_constructed_search import (
    SOURCES, bind_constructed_search, run_constructed_search,
    verify_constructed_binding,
)
from w1_marked_domain import enumerate_domain
from w1_marked_domain_campaign import with_parameters
from w1_quantum_oracle_campaign import reduced_template


def source_hashes():
    return {name: hashlib.sha256(Path(name).read_bytes()).hexdigest()
            for name in SOURCES}


def ratio(record):
    return Fraction(record['numerator'], record['denominator'])


def decimal_exact(number):
    # All represented TrialCosts values are exact dyadic rationals.
    denominator = number.denominator
    assert denominator & (denominator - 1) == 0
    places = denominator.bit_length() - 1
    if not places:
        return str(number.numerator)
    digits = str(number.numerator * 5**places).rjust(places + 1, '0')
    return digits[:-places] + '.' + digits[-places:]


before = source_hashes()
checks = []
template = reduced_template()
domains = (
    enumerate_domain(with_parameters(template, 1)),
    enumerate_domain(with_parameters(template, 1, target=1, profile='PGH2')),
)
schedule = ((0, 0), (1, 37), (0, 5))
processors = 3
classical = (ClassicalCosts(11, 17, 13, 19, 23, 29),
             ClassicalCosts(31, 37, 41, 43, 47, 53))
model = replace(example(True).physical_models[0], magic_state_error='1e-30')
budget = 10**20
binding = bind_constructed_search(domains, schedule, processors, classical,
                                  model, budget, predicate='prefix-restricted')
certificate = binding.certificate
verify_constructed_binding(binding, domains, schedule, processors, classical,
                           model, budget, predicate='prefix-restricted')
assert certificate['domain_resources'][0]['phase_marked_count'] == 0
assert certificate['domain_resources'][0]['full_w1_accepted_count'] == 2
assert certificate['domain_resources'][1]['phase_marked_count'] == 0
assert certificate['domain_resources'][1]['full_w1_accepted_count'] == 0
checks.append('literal phase and final acceptance predicates remain distinct')

rows = certificate['domain_resources']
cycles = sum(rows[index]['stage_cycle_units']['prepare']['serial_cycles_per_distance']
             + count * rows[index]['iteration_cycle_units']['serial_cycles_per_distance']
             for index, count in schedule)
states = sum(rows[index]['stage_cycle_units']['prepare']['t_states']
             + count * rows[index]['iteration_cycle_units']['t_states']
             for index, count in schedule)
distance = certificate['code_distance_for_whole_schedule']
peak = max(row['logical_qubits'] for row in rows)
assert certificate['envelope']['planned_trials_per_processor'] == 3
assert certificate['envelope']['planned_iterations_per_processor'] == 42
assert certificate['envelope']['serial_cycles_per_processor'] == cycles * distance
assert certificate['envelope']['t_states_all_processors'] == states * processors
magic = states * processors * Fraction(Decimal(model.magic_state_error))
assert ratio(certificate['whole_schedule_magic_error_exact']) == magic
error_ratio = Fraction(Decimal(model.physical_error)) / Fraction(Decimal(model.threshold))
prefactor = Fraction(Decimal(model.logical_error_prefactor))
failure_budget = Fraction(Decimal(model.total_failure_budget))
def failure(d):
    return peak * cycles * d * processors * prefactor * error_ratio**((d + 1) // 2) + magic
assert ratio(certificate['whole_schedule_failure_union_exact']) == failure(distance)
assert failure(distance) <= failure_budget
assert all(failure(d) > failure_budget for d in range(3, distance, 2))
checks.append('common distance is first allowed odd value for entire planned schedule and all P')

data = model.data_physical_qubits_per_d2 * distance**2 * peak
factories = (model.factory_physical_qubits_per_d2 * distance**2
             * model.factories_per_instance)
assert certificate['data_physical_qubits_per_processor'] == data
assert certificate['factory_physical_qubits_per_processor'] == factories
assert certificate['physical_qubits_all_processors'] == processors * (data + factories)
checks.append('peak persistent data and factory footprint paid for every processor')

for row, cost, source in zip(rows, binding.costs, classical):
    exact = row['clock_seconds_exact']
    assert ratio(exact['domain_setup_seconds']) == Fraction(
        source.task_preprocessing_ns + processors * source.per_search_setup_ns, 10**9)
    assert ratio(exact['candidate_check_seconds']) == Fraction(
        source.per_completed_trial_candidate_check_ns, 10**9)
    for name, value in row['clock_seconds_float_upper'].items():
        actual = Fraction(value)
        expected = ratio(exact[name])
        assert actual >= expected
        if value:
            assert Fraction(math.nextafter(value, -math.inf)) < expected
    assert all(asdict(cost)[name] == value
               for name, value in row['clock_seconds_float_upper'].items()
               if name != 'propagation_seconds')
checks.append('exact serialized setup and all clocks round upward once')

try:
    bind_constructed_search(domains, schedule, processors, classical, model,
                            certificate['physical_qubits_all_processors'] - 1,
                            predicate='prefix-restricted')
except ValueError as error:
    assert str(error) == 'INSUFFICIENT_PHYSICAL_QUBITS'
else:
    raise AssertionError('one-qubit-short budget accepted')
checks.append('one-qubit-short whole-fleet budget refused')

for altered in (
    replace(binding, costs=(replace(binding.costs[0],
                                   iteration_seconds=binding.costs[0].iteration_seconds / 2),
                            binding.costs[1])),
    replace(binding, propagation_seconds=(0.0, binding.propagation_seconds[1])),
):
    try:
        verify_constructed_binding(altered, domains, schedule, processors,
                                   classical, model, budget, predicate='prefix-restricted')
    except ValueError as error:
        assert str(error) == 'CONSTRUCTED_BINDING_MISMATCH'
    else:
        raise AssertionError('modified cheaper clock accepted')
checks.append('mutated iteration and propagation clocks refused by reconstruction')

changed = copy.deepcopy(binding)
changed.certificate['domain_resources'][0]['full_w1_accepted_count'] = 0
try:
    verify_constructed_binding(changed, domains, schedule, processors, classical,
                               model, budget, predicate='prefix-restricted')
except ValueError as error:
    assert str(error) == 'CONSTRUCTED_BINDING_MISMATCH'
else:
    raise AssertionError('modified legal acceptance count accepted')
checks.append('mutated legal acceptance count refused by literal reconstruction')

more_factories = bind_constructed_search(
    domains, schedule, processors, classical,
    replace(model, factories_per_instance=2 * model.factories_per_instance),
    budget, predicate='prefix-restricted')
assert more_factories.costs == binding.costs
assert more_factories.certificate['physical_qubits_all_processors'] > certificate['physical_qubits_all_processors']
checks.append('extra idle factories cost qubits but do not invent speed in serial strategy')

cost = binding.costs[0]
end_checks = sum((Fraction(cost.domain_setup_seconds), Fraction(cost.prepare_seconds),
                  Fraction(cost.measurement_seconds), processors * Fraction(cost.candidate_check_seconds)))
end_proof = end_checks + Fraction(cost.proof_seconds)
end_delivery = end_proof + Fraction(binding.propagation_seconds[0])
for deadline, success, proof in (
    (Fraction(0), False, False),
    (end_checks + Fraction(cost.proof_seconds) / 2, False, False),
    (end_proof + Fraction(binding.propagation_seconds[0]) / 2, False, True),
    (end_delivery, True, True),
):
    result = run_constructed_search(domains, schedule, processors, 17, classical,
                                    model, budget, decimal_exact(deadline),
                                    predicate='prefix-restricted')
    assert result['binding'] == certificate
    observation = result['observation']
    assert observation['success'] is success
    assert ratio(observation['elapsed_seconds_exact']) == deadline
    assert ratio(observation['unused_horizon_seconds_exact']) == 0
    if deadline:
        trial = observation['trials'][0]
        assert trial['verified_winner_observed']
        assert trial['proof_complete'] is proof
        assert trial['conditional_batch_phase_mark_probability'] == 0
        assert trial['conditional_batch_valid_candidate_probability'] == 1
        assert observation['unstarted_predeclared_trials'] == 2
        assert observation['grover_iterations_completed_all_processors'] == 0
    else:
        assert observation['trials_started'] == 0
    assert not result['quantum_mining_qualified']
checks.append('zero, partial proof, partial propagation and exact delivery preserve entire envelope')

assert certificate['fault_tolerant_schedule_verified'] is False
assert certificate['end_to_end_machine_failure_bound'] is False
assert certificate['physical_model_is_calibration'] is False
assert certificate['attacker_minimum_cost_proved'] is False
assert certificate['native_node_admission_checked'] is False
assert certificate['quantum_mining_qualified'] is False
assert certificate['production_activation'] is False
checks.append('no machine, lower-bound, admission or activation qualification')
after = source_hashes()
assert before == after
print(json.dumps({'independent_control_groups': len(checks), 'checks': checks,
                  'source_before': before, 'source_after': after,
                  'source_stable': before == after,
                  'distance': distance, 'physical_qubits': certificate['physical_qubits_all_processors'],
                  'binding_sha256': certificate['binding_sha256'],
                  'scope': 'independent conditional-model arithmetic and composition checks only'},
                 sort_keys=True))
