# Hepta #4729 native package qualification receipts — 2026-11-04

This archive records two distinct native executions of the original Hepta `codex-hepta-contracts` package. It does not qualify the whole Chain, all Hepta authority paths, a deployed service, or a later publication's complete source tree.

## Executed identities and results

| Execution | Commit | Tree | Original package test | Strict scoped Clippy |
| --- | --- | --- | --- | --- |
| Original #4729 | `5fa90c21dbcd642ff9101951531c5758c683fdac` | `c7af3b5564cff487975cabd4ae0161340e864d3e` | Exit 0; 198 passed, 0 skipped, across 4 binaries | Exit 0 |
| Pinned owner a6 + #4729 | `2f04ecfde90a92b9c779540a2c1aa39f584d3e41` | `ee77993e4e94b4faf54d661653527605b222b77e` | Exit 0; 198 passed, 0 skipped, across 4 binaries | Exit 0 |

Both executions used these unchanged commands from separate full source checkouts and fresh target directories:

```sh
just test -p codex-hepta-contracts --locked
just clippy -p codex-hepta-contracts --locked -- -D warnings
```

The original just recipe sets its working directory to `codex-rs`. Its pinned Rust/Cargo/Clippy toolchain is 1.96.0; Nextest is 0.9.137. The host root directory's default Rust 1.95.0 is recorded separately and is not the recipe's effective toolchain. `CARGO_BUILD_JOBS=2` was used to limit contention. No test filters, dependency substitutions, threshold changes, harness stubs, source modifications, or package-test retries were introduced.

Both newly added entry tests were executed successfully in both runs:

- `pq_final_use_all_entries_keep_explicit_revocation_precedence`
- `pq_final_use_all_entries_require_the_exact_claimed_head`

The original Nextest command emitted 14 scoped-metadata warnings. Both Clippy commands retained three warnings from the unchanged `clippy.toml` disallowed-type entries: `tokio::sync::MutexGuard`, `RwLockReadGuard`, and `RwLockWriteGuard` are not reachable in this package configuration. The commands exited 0 under the original `-D warnings` invocation. This evidence must not be described as warning-free.

## Source integrity and retained failure

Every tracked file in each checkout was checked against its Git blob identity. The original source has 11,221 paths, 142,454,826 bytes, and manifest SHA256 `b0c3c6244c433b96dfac0cad331c5d7a35bedcc6bb1facd5ac954066eb591063`. A complete after-run recheck matched all original paths.

The paired source has 11,249 paths, 142,686,694 bytes, and manifest SHA256 `9ee371904b0a252c2299a5823458597379316a2b3306f48c84878ee16f81106a`. Its before and both after-command full manifests are byte-identical.

An earlier paired preflight stopped before running package commands because the local promisor cache lacked exactly one upstream blob, `f85ca57fec2901540cd16d8b772dd450a133df65`, for `codex-rs/exec-server/tests/common/mod.rs`. The exact a6 source was fetched through the GitHub connector, its content-addressed identity was verified, and only the isolated checkout was completed. The failed preflight and acquisition receipt are retained. It was not a package-test failure and no test was retried.

The native evidence was produced on the configured `main` host, Linux GNU x86_64, under `/home/qian-qi/worktrees/hepta-pq4729-validation-20261104`. No deployed data, keys, services, or shared source directories were changed.

## Pinned local merge and later publication

The executed local merge has ordered parents `a6d8ce20bf8f5b6991d2dc5ef7313812944db060` and `5fa90c21dbcd642ff9101951531c5758c683fdac`. Its exact commit object and four-file delta are in `paired_commit.txt` and `paired_delta.txt`.

While validation ran, the owner branch advanced from a6 to `383a8c4150f4d620570a138b817f21960370e43f`. The complete GitHub compare receipt records four macOS-only test-fixture edits in `hepta-agentd` and `tui`. There were no changes to `hepta-contracts`, Cargo manifests/lock, the just recipe, `run-nextest.py`, Clippy configuration, or actual FinalUse production consumers.

The parent task subsequently published existing PR #4729 as commit `ef5723af6a04c7c74fa8a32ab34acdfd49913233`, tree `40ab7c559dc651a1ff3bd8f849a8fcbd6ec03925`, with ordered parents `[383a8c4150f4d620570a138b817f21960370e43f, 5fa90c21dbcd642ff9101951531c5758c683fdac]`. An independent GitHub readback confirms that the publication delta against 383 contains only the four original #4729 paths and their exact tested blobs.

That publication is an explicit identity mapping to unchanged scoped package inputs. Neither native run executed the complete published ef572 tree. The macOS fixture changes and all other packages are outside this native qualification. No third execution is implied.

## Reproduction and archive verification

`reproduce-original.py` and `reproduce-paired.py` retain the exact historical wrappers outside the source trees. They refer to the dedicated remote checkout directories and write receipts there. To repeat qualification, prepare new isolated complete checkouts at the recorded identities, use new target and receipt directories, and retain the original command arguments. Do not overwrite these historical receipts.

`environment.json`, full raw logs, per-command receipts, durable process receipts, full source manifests, GitHub comparison receipts, and `SHA256SUMS` are included. `verify-receipts.py` verifies archive file hashes, recorded source identities, native totals, the newly added test results, full manifest equality, and the exact publication mapping. It performs no builds or runtime operations.

This archive contains evidence and reproduction scripts. It excludes source checkouts, build artifacts, credentials, and key material. These package controls close the earlier native execution blocker for #4729; they do not establish independent deployment/WAN/migration acceptance or whole-chain PQ-128 security.
