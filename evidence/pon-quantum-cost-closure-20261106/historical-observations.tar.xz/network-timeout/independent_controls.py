"""Independent boundary controls for the release-timer and endpoint fixes.

These controls build arithmetic-only prefixes. They do not attest W1 work,
production node execution, or physical quantum hardware.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import math
from pathlib import Path
import sys
import unittest

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, default=Path.cwd(),
                    help='Trillionnium-Chain repository root (default: current directory)')
args, unittest_args = parser.parse_known_args()
model_dir = args.repo.resolve() / 'formal/pon-nakamoto-v1'
if not (model_dir / 'quantum_network_sim.py').is_file():
    parser.error('--repo must name a Trillionnium-Chain source root')
sys.path.insert(0, str(model_dir))
from quantum_network_sim import Block, NetworkScenario, ParticipationShock, Simulator, grover_success
from reference import work


def independent_deadline(start, wait):
    exact = Fraction(start) + Fraction(wait)
    represented = float(exact)
    return math.nextafter(represented, math.inf) if Fraction(represented) < exact else represented


def real_event_case(horizon=1.0):
    return NetworkScenario(
        'review_real_events', duration_seconds=horizon,
        classical_block_rate_at_initial_target=0,
        quantum_strategy='private-branch', private_release_policy='observed-work-lead',
        private_release_work_lead=100, private_release_max_wait_seconds=0.1,
        quantum_fixed_iterations=0, quantum_prepare_seconds=0,
        quantum_measure_seconds=0.25, quantum_candidate_check_seconds=0.25,
        quantum_proof_seconds=0, quantum_domain_size=1, quantum_domain_marked_count=1,
        probe_arrival_seconds=0, shocks=(ParticipationShock(0.55, 1, 0),),
    )


def controlled(wait=0.1, horizon=2.0):
    sim = Simulator(NetworkScenario(
        'review_controlled', duration_seconds=horizon,
        classical_block_rate_at_initial_target=0, quantum_initial_factor=0,
        quantum_strategy='private-branch', private_release_policy='observed-work-lead',
        private_release_work_lead=100, private_release_max_wait_seconds=wait,
        probe_arrival_seconds=0, propagation_seconds=0,
    ))
    sim.start()
    # Drain the time-zero probe so controlled advances never rewind the clock.
    while sim.events and sim.events[0][0] == 0:
        sim.step()
    sim.now = 0.5
    return sim


def append(sim, label, parent='prefix', stamp=None):
    old = sim.blocks[parent]
    target = sim.target_for(parent)
    if stamp is None:
        stamp = old.timestamp + 1
    item = Block(label, parent, old.height + 1, stamp, target,
                 old.chainwork + work(target), sim.profile, 'q')
    sim.register_block(item)
    return item


def advance(sim, at):
    while sim.events and sim.events[0][0] <= at:
        if not sim.step():
            break
    sim.now = at


class IndependentReleaseControls(unittest.TestCase):
    def test_original_failure_is_fixed_without_manually_injected_time(self):
        sim = Simulator(real_event_case())
        summary, rows = sim.run()
        deadline = independent_deadline(0.5, 0.1)
        published = [r for r in rows if r['kind'] == 'publish']
        self.assertEqual([(r['at_seconds'], r['tip']) for r in published], [(deadline, 'b000001')])
        self.assertEqual(sim.adaptive_releases, 1)
        self.assertAlmostEqual(summary['miners']['q']['wasted_search_seconds'], 0.05)

    def test_adjacent_horizons_straddle_exact_deadline(self):
        deadline = independent_deadline(0.5, 0.1)
        for horizon, expected in ((math.nextafter(deadline, -math.inf), 0), (deadline, 1)):
            with self.subTest(horizon=horizon):
                sim = Simulator(real_event_case(horizon))
                sim.run()
                self.assertEqual(sim.adaptive_releases, expected)

    def test_exactly_representable_deadline_gets_no_extra_ulp(self):
        sim = controlled(wait=0.25)
        private = append(sim, 'a')
        sim.private_tip, sim.private_wait_started = private.block_id, sim.now
        sim._maybe_adaptive_release('private-block')
        self.assertEqual(sim.adaptive_next_check, 0.75)
        advance(sim, 0.75)
        self.assertEqual(sim.adaptive_releases, 1)

    def test_partial_prefix_release_restarts_wait_but_does_not_bypass_future_gate(self):
        sim = controlled()
        first = append(sim, 'a')
        future = append(sim, 'b', parent='a', stamp=sim.start_timestamp + 121)
        sim.private_tip, sim.private_wait_started = future.block_id, sim.now
        # Both own deferred delivery and adaptive publication will wake at 1s.
        sim.receive('q', future.block_id, from_network=False)
        sim._maybe_adaptive_release('private-block')
        deadline = independent_deadline(0.5, 0.1)
        advance(sim, deadline)
        self.assertEqual(sim.last_published_private_tip, first.block_id)
        self.assertEqual(sim.private_wait_started, deadline)
        second_deadline = independent_deadline(deadline, 0.1)
        self.assertEqual(sim.adaptive_next_check, second_deadline)
        advance(sim, second_deadline)
        self.assertEqual(sim.adaptive_releases, 1)
        self.assertEqual(sim.adaptive_next_check, 1.0)
        advance(sim, math.nextafter(1.0, -math.inf))
        self.assertEqual(sim.adaptive_releases, 1)
        advance(sim, 1.0)
        publications = [r for r in sim.trace if r['kind'] == 'publish']
        self.assertEqual([(r['tip'], r['at_seconds']) for r in publications], [('a', deadline), ('b', 1.0)])
        self.assertIsNone(sim.private_wait_started)
        self.assertIsNone(sim.adaptive_next_check)

    def test_earlier_future_admission_does_not_publish_before_timeout(self):
        sim = controlled(wait=0.75)
        future = append(sim, 'future', stamp=sim.start_timestamp + 121)
        sim.private_tip, sim.private_wait_started = future.block_id, sim.now
        sim._maybe_adaptive_release('private-block')
        self.assertEqual(sim.adaptive_next_check, 1.0)
        advance(sim, 1.0)
        self.assertEqual(sim.adaptive_releases, 0)
        self.assertEqual(sim.adaptive_next_check, 1.25)
        advance(sim, 1.25)
        self.assertEqual(sim.adaptive_releases, 1)

    def test_duplicate_timer_and_messages_never_republish_completed_prefix(self):
        sim = controlled()
        item = append(sim, 'private')
        sim.private_tip, sim.private_wait_started = item.block_id, sim.now
        sim._maybe_adaptive_release('private-block')
        deadline = independent_deadline(0.5, 0.1)
        sim._schedule(deadline, 'adaptive-check', None)
        sim._schedule(deadline, 'delivery', ('q', item.block_id))
        advance(sim, deadline)
        self.assertEqual(sim.adaptive_releases, 1)
        self.assertEqual(sum(r['kind'] == 'publish' for r in sim.trace), 1)

    def test_zero_and_full_domains_at_large_iterations_are_literal(self):
        for iterations in (87_366_946, 100_000_000):
            for processors in (1, 3, 1024):
                for p in (0, 1):
                    with self.subTest(iterations=iterations, processors=processors, p=p):
                        self.assertEqual(grover_success(p, iterations, processors), float(p))


if __name__ == '__main__':
    unittest.main(argv=[sys.argv[0], *unittest_args], verbosity=2)
