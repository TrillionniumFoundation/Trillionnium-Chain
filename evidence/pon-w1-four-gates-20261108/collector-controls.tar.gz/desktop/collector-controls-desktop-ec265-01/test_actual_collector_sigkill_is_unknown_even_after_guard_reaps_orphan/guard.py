import ctypes,json,os,signal,subprocess,sys,time
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import w1_owned_process_collector_v1 as c
c.enable_subreaper()
mode=sys.argv[2];argv=json.loads(sys.argv[3]);marker=Path(sys.argv[4]);output=Path(sys.argv[5])
def wait_marker():
 until=time.monotonic()+3
 while not marker.exists():
  if time.monotonic()>=until:raise RuntimeError('guard marker timeout')
  time.sleep(.01)
if mode=='kill':
 p=subprocess.Popen(argv,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 wait_marker();p.kill();code=p.wait(timeout=3)
 who=json.loads(marker.read_text());fd=c.stable_pidfd(who,c.boot_id())
 try:signal.pidfd_send_signal(fd,signal.SIGKILL)
 finally:os.close(fd)
 waited,status,usage=os.wait4(who['pid'],0)
 output.write_text(json.dumps({'collector_returncode':code,'completed_monotonic_ns':time.monotonic_ns(),
                              'orphan_reaped_by_guard':waited,'orphan_status':status}))
else:
 launch=Path(sys.argv[6]);pidpath=output.with_suffix('.pid')
 launch.write_text('import subprocess,os,time\nfrom pathlib import Path\n'
                  +'p=subprocess.Popen('+repr(argv)+',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)\n'
                  +'Path('+repr(str(pidpath))+').write_text(str(p.pid))\n'
                  +'end=time.monotonic()+3\n'
                  +'while not Path('+repr(str(marker))+').exists() and time.monotonic()<end: time.sleep(.01)\n'
                  +'os._exit(0)\n')
 owner=subprocess.Popen([sys.executable,str(launch)])
 wait_marker();owner_code=owner.wait(timeout=3)
 pid=int(pidpath.read_text());waited,status,usage=os.wait4(pid,0)
 output.write_text(json.dumps({'owner_returncode':owner_code,'collector_returncode':os.waitstatus_to_exitcode(status),
                              'completed_monotonic_ns':time.monotonic_ns(),'collector_reaped_by_guard':waited}))
