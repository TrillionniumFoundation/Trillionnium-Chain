#!/usr/bin/env python3
"""Preserve exact source/build/test evidence for one isolated storage validation."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time

ROOT = Path('/home/qq/work/chain-cell-bt-20261106-r1')
REPO = ROOT / 'repo'
TOOLCHAIN = Path('/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
BASE = 'b173c1f52d927522af67df30dd08ecfb2e3a1bb0'
PRODUCTION = 'trillionnium/crates/trnm-pon-node/src/store/storage_service.rs'
PRODUCTION_SHA = {
    'red-storage-only': '78c02d204889625c7bc8d76a99f377d6f16f3bbecacedcb95c87ab97c01ed997',
    'green-storage-only': 'f6afb07b4549342cd150db6283c4f380cf6980d61dbd25d6c0dc2f8740bc4871',
}
TESTS = {
    'trillionnium/crates/trnm-pon-node/src/store/storage_service/tests.rs':
        '7e76f71b1669a8a5e58d9bc569c43c8c5937156eb20a936fe0e52c48e96590e0',
    'trillionnium/crates/trnm-pon-node/src/store/storage_service/height_window_tests.rs':
        '0024d618e98db072b566a3a2921d891ed933d5d82e3e502d2fc4ec8dc21ce574',
}


def sha256(path):
    value = hashlib.sha256()
    with open(path, 'rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def capture(args):
    return subprocess.check_output(args, cwd=REPO)


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def snapshot(out, label):
    files = set(capture(['git', 'ls-files', '-z']).split(b'\0'))
    files.update(capture(['git', 'ls-files', '--others', '--exclude-standard', '-z']).split(b'\0'))
    rows = []
    for raw in sorted(files):
        if not raw:
            continue
        name = os.fsdecode(raw)
        path = REPO / name
        if not os.path.lexists(path):
            rows.append({'path': name, 'type': 'missing'})
            continue
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode):
            row = {'path': name, 'type': 'symlink', 'target': os.readlink(path)}
        elif stat.S_ISREG(info.st_mode):
            row = {'path': name, 'type': 'file', 'size': info.st_size, 'sha256': sha256(path)}
        else:
            raise RuntimeError('Unexpected tracked file type: ' + name)
        row['mode'] = stat.S_IMODE(info.st_mode)
        rows.append(row)
    data = (json.dumps(rows, separators=(',', ':'), sort_keys=True) + '\n').encode()
    (out / (label + '.files.json')).write_bytes(data)
    identity = {
        'scope': 'full checkout file identities, excluding ignored files and .git internals',
        'head': capture(['git', 'rev-parse', 'HEAD']).decode().strip(),
        'base_tree': capture(['git', 'rev-parse', 'HEAD^{tree}']).decode().strip(),
        'file_count': len(rows),
        'files_manifest_sha256': hashlib.sha256(data).hexdigest(),
        'cargo_lock_sha256': sha256(REPO / 'trillionnium/Cargo.lock'),
        'cargo_manifest_sha256': sha256(REPO / 'trillionnium/Cargo.toml'),
        'production_sha256': sha256(REPO / PRODUCTION),
    }
    save_json(out / (label + '.identity.json'), identity)
    (out / (label + '.status.txt')).write_bytes(capture(['git', 'status', '--short']))
    (out / (label + '.patch')).write_bytes(capture(['git', 'diff', '--binary', 'HEAD']))
    return identity


def run(out, label, args, env):
    started = time.time()
    save_json(out / (label + '.command.json'), {'argv': args, 'cwd': str(REPO), 'started_unix': started})
    print(json.dumps({'phase': label, 'state': 'starting', 'argv': args}), flush=True)
    with open(out / (label + '.stdout.log'), 'wb') as stdout, open(out / (label + '.stderr.log'), 'wb') as stderr:
        proc = subprocess.Popen(args, cwd=REPO, env=env, stdout=stdout, stderr=stderr)
        save_json(out / (label + '.process.json'), {'pid': proc.pid, 'started_unix': started})
        code = proc.wait()
    (out / (label + '.exit-code')).write_text(str(code) + '\n')
    result = {'exit_code': code, 'elapsed_seconds': time.time() - started,
              'stdout_bytes': (out / (label + '.stdout.log')).stat().st_size,
              'stderr_bytes': (out / (label + '.stderr.log')).stat().st_size,
              'stdout_sha256': sha256(out / (label + '.stdout.log')),
              'stderr_sha256': sha256(out / (label + '.stderr.log'))}
    save_json(out / (label + '.result.json'), result)
    print(json.dumps({'phase': label, 'state': 'finished', **result}), flush=True)
    return code


def main():
    stage = sys.argv[1]
    assert stage in ('red-storage-only', 'green-storage-only', 'green-final-combined'), stage
    out = ROOT / 'evidence' / stage
    out.mkdir(exist_ok=False)
    env = os.environ.copy()
    forbidden = {key: env[key] for key in env
                 if (key.startswith('CARGO_PROFILE_') or key in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS'))
                 and env[key]}
    assert not forbidden, 'Unexpected build profile override keys: ' + ','.join(forbidden)
    env.update({'PATH': str(TOOLCHAIN) + ':' + env['PATH'],
                'CARGO_HOME': '/home/qq/.cargo',
                'CARGO_TARGET_DIR': str(ROOT / 'target'),
                'CARGO_BUILD_JOBS': '2'})
    save_json(out / 'environment.json', {key: env.get(key) for key in
              ('PATH', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
               'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'OPENSSL_DIR', 'OPENSSL_LIB_DIR',
               'OPENSSL_INCLUDE_DIR', 'PKG_CONFIG_PATH', 'LD_LIBRARY_PATH')})
    assert capture(['git', 'rev-parse', 'HEAD']).decode().strip() == BASE
    if stage in PRODUCTION_SHA:
        assert sha256(REPO / PRODUCTION) == PRODUCTION_SHA[stage], 'production source differs'
    for name, expected in TESTS.items():
        assert sha256(REPO / name) == expected, name
    for name in (PRODUCTION, *TESTS, 'trillionnium/Cargo.toml', 'trillionnium/Cargo.lock'):
        target = out / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO / name, target)
    before = snapshot(out, 'before')
    if stage in PRODUCTION_SHA:
        changed = set(capture(['git', 'diff', '--name-only', 'HEAD']).decode().splitlines())
        expected_changes = {next(iter(TESTS))}
        if stage == 'green-storage-only':
            expected_changes.add(PRODUCTION)
        assert changed == expected_changes, repr(changed)
        untracked = capture(['git', 'ls-files', '--others', '--exclude-standard']).decode().splitlines()
        assert untracked == [list(TESTS)[1]], repr(untracked)
    preflight = run(out, 'preflight', ['bash', 'scripts/project-preflight.sh'], env)
    assert preflight == 0, 'preflight failed'
    for label, command in [('rustc', ['rustc', '--version', '--verbose']),
                           ('cargo', ['cargo', '--version', '--verbose'])]:
        assert run(out, label, command, env) == 0
    build = ['cargo', 'test', '--manifest-path', 'trillionnium/Cargo.toml',
             '--locked', '--offline', '-p', 'trnm-pon-node', '--lib', '--no-run',
             '--message-format=json', '-j', '2']
    built = run(out, 'build', build, env)
    if built != 0:
        after = snapshot(out, 'after')
        save_json(out / 'summary.json', {'stage': stage, 'build_exit_code': built,
                  'test_started': False, 'source_unchanged': before == after})
        return built
    executables = set()
    for line in (out / 'build.stdout.log').read_text().splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if (value.get('reason') == 'compiler-artifact'
                and value.get('target', {}).get('name') == 'trnm_pon_node'
                and value.get('profile', {}).get('test') is True and value.get('executable')):
            executables.add(value['executable'])
    assert len(executables) == 1, repr(executables)
    binary = Path(executables.pop())
    preserved = out / 'trnm-pon-node-test-binary'
    shutil.copyfile(binary, preserved)
    preserved.chmod(binary.stat().st_mode & 0o777)
    binary_sha = sha256(binary)
    assert sha256(preserved) == binary_sha
    save_json(out / 'binary.identity.json', {'built_path': str(binary),
              'preserved_path': str(preserved), 'size': binary.stat().st_size,
              'sha256': binary_sha})
    selector = 'storage_service::tests::height_window' if stage == 'red-storage-only' else 'storage_service::tests'
    test = run(out, 'test', [str(binary), selector, '--test-threads=1', '--nocapture'], env)
    after = snapshot(out, 'after')
    stdout = (out / 'test.stdout.log').read_text()
    stderr = (out / 'test.stderr.log').read_text()
    print(stdout, end='', flush=True)
    if stderr:
        print(stderr, end='', file=sys.stderr, flush=True)
    summary = {'stage': stage, 'source_unchanged': before == after, 'build_exit_code': built,
               'test_exit_code': test, 'binary_sha256': binary_sha,
               'source_files_sha256': before['files_manifest_sha256'],
               'production_sha256': before['production_sha256'],
               'expected_test_exit_code': 101 if stage == 'red-storage-only' else 0}
    save_json(out / 'summary.json', summary)
    print(json.dumps(summary), flush=True)
    assert before == after, 'validation modified source checkout'
    return test


if __name__ == '__main__':
    sys.exit(main())
