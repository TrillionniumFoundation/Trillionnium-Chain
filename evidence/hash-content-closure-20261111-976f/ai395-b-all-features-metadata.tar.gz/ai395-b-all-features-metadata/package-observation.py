#!/usr/bin/env python3
"""Package one already-completed B metadata observation; execute no Cargo."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

B = "9fd6ee29a7a663cef547040d9d42cc36a371a17e"
TREE = "7351f83fa9ac5c0e7540fa64bce06ea6f328602f"
ROOT = Path("/home/qq/chain-hash-transitive-976f-20261111")
OUT = Path(str(ROOT) + "-controls-b")
STEM = Path(str(ROOT) + "-all-features-metadata")
LABEL = "b-ai395-workspace-all-features-metadata"
PREFIX = "ai395-b-all-features-metadata"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()

receipt_bytes = (OUT / (LABEL + ".json")).read_bytes()
receipt = json.loads(receipt_bytes)
log_bytes = (OUT / (LABEL + ".log")).read_bytes()
assert receipt["schema"] == "trnm-pq-native-command-v1"
assert receipt["status"] == "command_succeeded" and receipt["exit_code"] == 0
assert receipt["whole_chain_quantum_security_qualified"] is False
assert receipt["cwd"] == str(ROOT)
assert receipt["before"] == receipt["after"]
for key in ("before", "after"):
    source = receipt[key]
    assert source["kind"] == "head" and source["candidate"] == B
    assert source["tested_commit"] == B and source["tested_tree"] == TREE
    assert source["tracked_entries"] == 28334
    assert source["tracked_bytes"] == 2578874762
    assert source["tracked_worktree_verified"] is True
    assert source["tests_executed_by_identity_check"] is False
assert receipt["argv"] == [
    "cargo", "metadata", "--locked", "--offline", "--all-features",
    "--manifest-path", "trillionnium/Cargo.toml", "--format-version", "1",
]
assert receipt["log_file"] == LABEL + ".log"
assert receipt["log_bytes"] == len(log_bytes)
assert receipt["log_sha256"] == sha(log_bytes)
metadata = json.loads(log_bytes)
summary = {
    "schema": "trnm-b-all-features-metadata-observation-v1",
    "execution_host": "ai395",
    "candidate": B,
    "tree": TREE,
    "status": "command_succeeded",
    "exit_code": 0,
    "label": LABEL,
    "argv": receipt["argv"],
    "cwd": str(ROOT),
    "started_utc": receipt["started_utc"],
    "elapsed_ns": receipt["elapsed_ns"],
    "source_guards": receipt["before"],
    "before_after_equal": True,
    "receipt_bytes": len(receipt_bytes),
    "receipt_sha256": sha(receipt_bytes),
    "log_bytes": len(log_bytes),
    "log_sha256": sha(log_bytes),
    "metadata_counts": {
        "packages": len(metadata["packages"]),
        "resolve_nodes": len(metadata["resolve"]["nodes"]),
        "workspace_members": len(metadata["workspace_members"]),
    },
    "launch_environment_recorded_by_controller": {
        "RUSTUP_HOME": "/home/qq/.rustup",
        "CARGO_HOME": "/home/qq/.cargo",
        "RUSTUP_TOOLCHAIN": "1.95.0",
        "rust_bin_prepend": "/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin",
    },
    "scope": "Read-only Cargo metadata; not native tests or compiler/provider attestation.",
    "retained_cloud_observation": {
        "label": "b-cloud-workspace-all-features-metadata",
        "status": "command_failed",
        "exit_code": 101,
        "reason": "foreign-types 0.3.2 absent from the cloud offline cache",
        "preserved_in": "cloud-b-observations-976f.tar.gz",
        "replaced_or_relabelled": False,
    },
    "whole_chain_quantum_security_qualified": False,
    "production_activation_authorized": False,
}
members = {
    PREFIX + "/records/" + LABEL + ".json": receipt_bytes,
    PREFIX + "/records/" + LABEL + ".log": log_bytes,
    PREFIX + "/compact-summary.json": encoded(summary),
    PREFIX + "/package-observation.py": Path(__file__).read_bytes(),
}
member_manifest = {
    "schema": "trnm-evidence-member-sha256-v1",
    "execution_host": "ai395",
    "candidate": B,
    "tree": TREE,
    "members": [{"path": name, "bytes": len(data), "sha256": sha(data)}
                for name, data in sorted(members.items())],
}
member_bytes = encoded(member_manifest)
members[PREFIX + "/members.json"] = member_bytes
archive_path = Path(str(STEM) + ".tar.gz")
summary_path = Path(str(STEM) + "-compact.json")
members_path = Path(str(STEM) + "-members.json")
for path in (archive_path, summary_path, members_path):
    if path.exists():
        raise FileExistsError(path)
with archive_path.open("xb") as raw:
    with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.USTAR_FORMAT) as archive:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o600
                archive.addfile(info, io.BytesIO(data))
with tarfile.open(archive_path, "r:gz") as archive:
    assert set(archive.getnames()) == set(members)
    for name, expected in members.items():
        assert archive.extractfile(name).read() == expected
with summary_path.open("xb") as f:
    f.write(encoded(summary))
with members_path.open("xb") as f:
    f.write(member_bytes)
print(json.dumps({
    "status": "packaged_verified",
    "archive": str(archive_path),
    "archive_bytes": archive_path.stat().st_size,
    "archive_sha256": sha(archive_path.read_bytes()),
    "archive_members": len(members),
    "compact": str(summary_path),
    "compact_sha256": sha(summary_path.read_bytes()),
    "members": str(members_path),
    "members_sha256": sha(member_bytes),
    "metadata_counts": summary["metadata_counts"],
    "whole_chain_quantum_security_qualified": False,
}, sort_keys=True), flush=True)
