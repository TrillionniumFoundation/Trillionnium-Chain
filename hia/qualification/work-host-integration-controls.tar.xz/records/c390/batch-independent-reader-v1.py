ROOT_PATH="/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo"
from pathlib import Path
import sys,os,json,hashlib,zipfile,shutil,time,subprocess,traceback,stat
root=Path(ROOT_PATH);base=root.parent/"ci-c390-readback-v1";driver=base/"batch-independent-reader-v1.py"
with driver.open("x") as f:f.write(sys.argv[1])
sys.path.insert(0,str(root));from hia.tools import qualify_batch_ci as q
expected={"git_head":"c3901ff19c26815205d9cdd6975fc24ecc51ae88","run_id":"44019939486","attempt":1}
api=q.safe.json_load((base/"batch-and-host-job-observation-v1.json").read_bytes())
artifacts={a["id"]:a for a in api["artifacts"]["artifacts"]};jobs=api["source"]["jobs"]
requests=[(14300313900,"batch","native-batch-semantic"),(14300313335,"physical","native-batch-physical"),(14300787115,"prefix","native-prefix-0"),(14300602740,"prefix","native-prefix-1"),(14300299370,"prefix","native-prefix-2"),(14300298642,"prefix","native-prefix-3"),(14301465206,"scoped","native-prefix-scoped"),(14302600832,"original-batch","native-batch-original"),(14302198574,"original-prefix","native-prefix-original")]
parent_ids={"original-batch":[14300313900],"original-prefix":[14300787115,14300602740,14300299370,14300298642]}
def need(value,message):
 if not value:raise ValueError(message)
def ident(path):
 st=path.lstat();need(stat.S_ISREG(st.st_mode) and st.st_nlink==1,"Nonregular linked artifact")
 h=hashlib.sha256()
 with path.open("rb") as f:
  for b in iter(lambda:f.read(1<<20),b""):h.update(b)
 return {"bytes":st.st_size,"sha256":h.hexdigest()}
def outer_manifest(aid):
 with zipfile.ZipFile(base/str(aid)/"artifact.zip") as z:
  raw=z.read("artifact/manifest.json");return q.safe.json_load(raw),{"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
all_results=[];start=time.monotonic_ns()
pre=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=root,capture_output=True)
(base/"batch-readback-preflight.stdout.raw").write_bytes(pre.stdout);(base/"batch-readback-preflight.stderr.raw").write_bytes(pre.stderr)
need(pre.returncode==0,"Project preflight failed")
need(subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()==expected["git_head"],"Canonical head differs")
need(subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True)=="","Canonical c390 source dirty")
for aid,kind,job_name in requests:
 folder=base/str(aid);out=folder/"independent-batch-readback-v1";out.mkdir(mode=0o700);begin=time.monotonic_ns()
 report={"schema":"trnm.c390-independent-batch-readback.v1","status":"FAIL","artifact_id":aid,"kind":kind,"expected_lineage":expected,"actual_runtime_reexecuted":False,"original_runner_paths_recreated":False,"stages":[]}
 try:
  a=artifacts[aid];matches=[j for j in jobs if j["name"]==job_name]
  need(len(matches)==1,"Exactly one actual CI producer job required");job=matches[0]
  need(job["status"]=="completed" and job["conclusion"]=="success" and job["head_sha"]==expected["git_head"],"Actual producer job did not succeed for exact head")
  report["actual_job"]={k:job[k] for k in ("id","name","status","conclusion","head_sha","started_at","completed_at")}
  need(a["workflow_run"]["id"]==44019939486 and a["workflow_run"]["head_sha"]==expected["git_head"] and a["name"].endswith("-44019939486-1"),"Wrong artifact lineage")
  need(ident(folder/"artifact.zip")=={"bytes":a["size_in_bytes"],"sha256":a["digest"].removeprefix("sha256:")},"Complete actual ZIP changed")
  preview,preview_id=outer_manifest(aid);q.validate_manifest(preview)
  need(preview["kind"]==kind and preview["stage_status"]=="success" and q.same(preview["lineage"],expected),"Wrong archived stage identity")
  total=sum(r["bytes"] for r in preview["entries"].values() if r["type"]=="file")
  need(shutil.disk_usage(base).free>=preview["tar"]["bytes"]+total+preview["archive"]["bytes"]+1500000000,"Complete archive/extraction disk reserve unavailable")
  container=out/"container";container.mkdir(mode=0o700)
  with zipfile.ZipFile(folder/"artifact.zip") as z:
   for name in ("evidence.tar.xz","manifest.json"):
    with z.open("artifact/"+name) as incoming,(container/name).open("xb") as target:shutil.copyfileobj(incoming,target,1<<20)
  need(ident(container/"evidence.tar.xz")==preview["archive"] and ident(container/"manifest.json")==preview_id,"Transferred outer container differs")
  dest=out/"unpacked";manifest=q.verify_archive(container,dest)
  need(q.same(manifest,preview),"Verified manifest differs");report["stages"].append("complete-canonical-archive-and-all-regular-bytes")
  binding=manifest["binding"]
  need(binding["lineage"]==expected and type(binding["lineage"]["attempt"]) is int,"Binding lineage differs")
  need(q.same(q.safe.load(dest/"observations","binding.json"),binding),"Embedded actual binding differs")
  source_pair=q.source_pair(root,dest/"observations",expected)
  need(q.same(source_pair,binding["source_observations"]),"Complete actual source observations differ")
  prior_results=[]
  if kind.startswith("original-"):
   profile=kind.removeprefix("original-");bundles=[];receipts=[]
   for i,parent_id in enumerate(parent_ids[kind]):
    prior=dest/("prior-"+str(i));download=dest/("download-"+str(i));prior_binding=q.safe.load(prior,"native-binding.json");transfer=q.safe.load(prior,"transfer-receipt.json")
    parent_manifest,parent_manifest_id=outer_manifest(parent_id)
    q.validate_manifest(parent_manifest)
    need(q.same(parent_manifest["binding"],prior_binding) and q.same(prior_binding["lineage"],expected),"Original predecessor differs from actual independently downloaded producer")
    need(ident(download/"artifact/manifest.json")==parent_manifest_id and ident(download/"artifact/evidence.tar.xz")==parent_manifest["archive"],"Original did not retain complete exact producer archive")
    with zipfile.ZipFile(base/str(parent_id)/"artifact.zip") as parent_zip:
     package=parent_zip.read("package.log")
     need((download/"package.log").read_bytes()==package,"Original predecessor package log differs")
    need(set(transfer)=={"schema","status","lineage","binding","manifest","archive"} and transfer["schema"]=="trnm.execution-batch-ci-transfer.v1" and transfer["status"]=="VERIFIED_COMPLETE_REGULAR_BYTES_TRANSFERRED" and q.same(transfer["lineage"],expected) and q.same(transfer["binding"],ident(prior/"native-binding.json")) and q.same(transfer["manifest"],parent_manifest_id) and q.same(transfer["archive"],parent_manifest["archive"]),"Actual predecessor transfer receipt differs")
    admitted=q.validate(root,profile,native=prior/"native")
    need(all(q.same(value,prior_binding.get(key)) for key,value in admitted.items()),"Prior complete semantic observations differ")
    index=admitted["actual"]["partition"]["index"];need(type(index)is int and index==i,"Prior partition index differs")
    need(q.same(q.source_pair(root,prior/"observations",expected),prior_binding["source_observations"]),"Prior full committed source observation differs")
    need(q.same(q.safe.load(prior/"observations","binding.json"),prior_binding),"Prior inner binding differs")
    receipts.append({"index":i,"binding":ident(prior/"native-binding.json"),"receipt":ident(prior/"transfer-receipt.json")})
    bundles.append(prior/"native/bundle")
    prior_results.append({"artifact_id":parent_id,"partition":i,"archive":parent_manifest["archive"],"manifest":parent_manifest_id,"semantic_status":admitted["status"]})
   need(q.same(receipts,binding["predecessors"]),"Complete original predecessor receipt roster differs")
   actual=q.validate(root,kind,original=dest/"original",bundles=bundles,capture=False)
  else:
   need(binding["predecessors"]==[],"Unexpected native predecessor")
   actual=q.validate(root,kind,native=dest/"native")
  need(all(q.same(value,binding.get(key)) for key,value in actual.items()),"Complete independent semantic readback differs from actual binding")
  originals=q.graph.original_manifest(root);committed=q.committed_sources(root,{**originals,**actual["source_inputs"]})
  need(ident(folder/"artifact.zip")=={"bytes":a["size_in_bytes"],"sha256":a["digest"].removeprefix("sha256:")},"Retained original ZIP changed")
  need(q.same(q.source_pair(root,dest/"observations",expected),source_pair),"Source observations changed during readback")
  report.update(status="PASS",actual=actual,complete_original_source_files=len(originals),committed_source_result=committed,original_predecessors=prior_results,source_after="MATCH",regular_files=sum(r["type"]=="file" for r in manifest["entries"].values()),regular_bytes=total,archive=manifest["archive"],tar=manifest["tar"],manifest=preview_id)
  report["stages"].append("complete-native-and-original-raw-semantic-readback")
 except BaseException as e:
  report["failure"]={"error":repr(e),"traceback":traceback.format_exc()}
 finally:
  report["elapsed_ns"]=time.monotonic_ns()-begin;raw=(json.dumps(report,sort_keys=True,indent=2)+"\n").encode();(out/"report.json").write_bytes(raw)
  all_results.append({"artifact_id":aid,"kind":kind,"status":report["status"],"report":{"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()},"elapsed_ns":report["elapsed_ns"]})
  actual=report.get("actual",{}).get("actual",{});brief={k:v for k,v in actual.items() if k in ("profile","partition","histories_total","histories_executed","histories","commands_planned","commands_actual","skipped_commands","progress_records","controls","processes","commands","full_base_reads","original_test_binary")}
  print(json.dumps({**all_results[-1],"actual_summary":brief,"failure":report.get("failure")}),flush=True)
status="PASS" if all(r["status"]=="PASS" for r in all_results) else "FAIL"
index={"schema":"trnm.c390-independent-batch-readbacks.v1","status":status,"actual_runtime_reexecuted":False,"lineage":expected,"results":all_results,"elapsed_ns":time.monotonic_ns()-start}
(base/"batch-independent-readback-index-v1.json").write_text(json.dumps(index,sort_keys=True,indent=2)+"\n")
print(json.dumps({"status":status,"artifacts":len(all_results),"elapsed_ns":index["elapsed_ns"]}),flush=True)
if status!="PASS":raise SystemExit(1)
