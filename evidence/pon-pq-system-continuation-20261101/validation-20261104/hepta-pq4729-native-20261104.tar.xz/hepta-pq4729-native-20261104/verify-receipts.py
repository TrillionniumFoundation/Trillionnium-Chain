#!/usr/bin/env python3
"""Verify the retained evidence only; no builds, network, or runtime actions."""
import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parent


def read_json(name):
    return json.loads((ROOT / name).read_text())


for line in (ROOT / "SHA256SUMS").read_text().splitlines():
    expected, name = line.split("  ", 1)
    path = ROOT / name
    assert path.is_file() and not path.is_symlink(), name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name

expected_sources = {
    "original/contracts-native": "5fa90c21dbcd642ff9101951531c5758c683fdac",
    "original/contracts-strict-clippy": "5fa90c21dbcd642ff9101951531c5758c683fdac",
    "paired-contracts-native": "2f04ecfde90a92b9c779540a2c1aa39f584d3e41",
    "paired-contracts-strict-clippy": "2f04ecfde90a92b9c779540a2c1aa39f584d3e41",
}
for stem, source in expected_sources.items():
    receipt = read_json(stem + ".json")
    assert receipt["returncode"] == 0 and receipt["source"]["commit"] == source
    assert receipt["tracked_source_unchanged"]
    raw = (ROOT / (stem + ".log")).read_bytes()
    assert len(raw) == receipt["bytes"]
    assert hashlib.sha256(raw).hexdigest() == receipt["sha256"]
    text = raw.decode()
    if stem.endswith("native"):
        assert "Starting 198 tests across 4 binaries" in text
        assert "198 tests run: 198 passed, 0 skipped" in text
        assert not re.search(r"^\s*(FAIL|RETRY|TRY|SKIP)\s", text, re.M)
        for name in (
            "pq_final_use_all_entries_keep_explicit_revocation_precedence",
            "pq_final_use_all_entries_require_the_exact_claimed_head",
        ):
            assert any("PASS" in line and line.endswith(name) for line in text.splitlines())

assert read_json("source-after.json")["full_tracked_source_unchanged"]
original = ROOT / "manifests/complete-source-manifest.json"
assert hashlib.sha256(original.read_bytes()).hexdigest() == "b0c3c6244c433b96dfac0cad331c5d7a35bedcc6bb1facd5ac954066eb591063"
assert len(json.loads(original.read_bytes())) == 11221
for name in (
    "paired-complete-source-before.json",
    "paired-complete-source-after-paired-contracts-native.json",
    "paired-complete-source-after-paired-contracts-strict-clippy.json",
):
    raw = (ROOT / "manifests" / name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == "9ee371904b0a252c2299a5823458597379316a2b3306f48c84878ee16f81106a"
    assert len(json.loads(raw)) == 11249

commit_raw = (ROOT / "paired_commit.txt").read_bytes()
assert hashlib.sha1(b"commit " + str(len(commit_raw)).encode() + b"\0" + commit_raw).hexdigest() == "2f04ecfde90a92b9c779540a2c1aa39f584d3e41"

publication = read_json("publication-ef572-commit.json")
assert publication["sha"] == "ef5723af6a04c7c74fa8a32ab34acdfd49913233"
assert publication["tree"]["sha"] == "40ab7c559dc651a1ff3bd8f849a8fcbd6ec03925"
assert [p["sha"] for p in publication["parents"]] == [
    "383a8c4150f4d620570a138b817f21960370e43f",
    "5fa90c21dbcd642ff9101951531c5758c683fdac",
]
expected_delta = {
    "codex-rs/hepta-contracts/FINAL_USE.md": "da82dc6990054cac5a35deaa0653f9dfef875e8d",
    "codex-rs/hepta-contracts/src/final_use.rs": "245fc77cd81736012afc3696582e472438d0f741",
    "codex-rs/hepta-contracts/src/final_use_pq_entry_tests.rs": "05a91337a3071dae4bdfa1be5f83adb12d94f35e",
    "codex-rs/hepta-contracts/src/final_use_pq_tests.rs": "1f58e4ebd81e787944d24b360ec5e428bf819484",
}
assert {f["filename"]: f["sha"] for f in read_json("publication-383-to-ef572-compare.json")["files"]} == expected_delta
assert {f["filename"] for f in read_json("owner-a6-to-383-compare.json")["files"]} == {
    "codex-rs/hepta-agentd/src/cognitive_ranker_tests.rs",
    "codex-rs/hepta-agentd/src/state_isolation_tests.rs",
    "codex-rs/hepta-agentd/tests/support/fleet.rs",
    "codex-rs/tui/src/lib.rs",
}
print(json.dumps({"evidence_verified": True, "native_executions": 2, "tests_per_execution": 198, "published_exact_tree_executed": False}))
