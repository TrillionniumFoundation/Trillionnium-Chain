import hashlib,json,os,shutil,stat,subprocess,sys
from pathlib import Path
repo=Path('/home/qian-qi/work/chain-throughput-20261106-ee79/repo')
provider=Path('/home/qian-qi/work/chain-throughput-20261106-1eed/provider-temp/trnm-pq-provider-3.5.9.8DrdJ490/install')
cargo_home=Path('/home/qian-qi/work/chain-throughput-20261106-ee79/cargo')
root=Path('/home/qian-qi/chain-ee79-release516-v1')
toolchain=Path('/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
result={'schema':'trnm-rog-release118-readonly-feasibility-v1','repo':str(repo),'head_expected':'516382d87bbfdba85fbf34b6aa7b62edbc5759bb','tree_expected':'473434f61c82d9b8daa76dff98ab3bdedbba13ca','uid':os.getuid(),'gid':os.getgid(),'checks':{},'read_only':True}
def check(name,value):
 result['checks'][name]=bool(value)
def facts(path,digest=False):
 info=path.lstat()
 record={'path':str(path),'mode':oct(stat.S_IMODE(info.st_mode)),'uid':info.st_uid,'gid':info.st_gid,'device':info.st_dev,'inode':info.st_ino,'bytes':info.st_size,'symlink':stat.S_ISLNK(info.st_mode)}
 if digest and stat.S_ISREG(info.st_mode):
  with path.open('rb') as stream:record['sha256']=hashlib.file_digest(stream,'sha256').hexdigest()
 return record
def command(argv,cwd=None,env=None):
 p=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,text=True,timeout=90)
 return {'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
try:
 result['python']=command([sys.executable,'--version'])
 check('python_311_or_newer',sys.version_info>=(3,11))
 result['source']=command(['git','rev-parse','HEAD','HEAD^{tree}'],repo)
 check('exact_source',result['source']['exit_code']==0 and result['source']['stdout'].splitlines()==[result['head_expected'],result['tree_expected']])
 result['branch']=command(['git','symbolic-ref','--quiet','HEAD'],repo)
 check('exact_branch',result['branch']['stdout'].strip()=='refs/heads/fix/chain-throughput-publish-20261106-1eed')
 result['status']=command(['git','status','--porcelain=v1','--untracked-files=all'],repo)
 check('clean_source',result['status']['exit_code']==0 and result['status']['stdout']=='')
 result['preflight']=command(['bash','scripts/project-preflight.sh'],repo)
 check('original_preflight',result['preflight']['exit_code']==0)
 result['rustc']=facts(toolchain/'rustc',True)
 result['cargo']=facts(toolchain/'cargo',True)
 result['rust_version']=command([str(toolchain/'rustc'),'--version'])
 result['cargo_version']=command([str(toolchain/'cargo'),'--version'])
 check('rust_195_installed',result['rust_version']['stdout'].startswith('rustc 1.95.0 ') and result['cargo_version']['stdout'].startswith('cargo 1.95.0 '))
 result['cargo_proxy']=facts(Path('/home/qian-qi/.cargo/bin/cargo'))
 result['toolchain_list']=command(['/home/qian-qi/.cargo/bin/rustup','toolchain','list'])
 check('rustup_195_known','1.95.0-x86_64-unknown-linux-gnu' in result['toolchain_list']['stdout'])
 result['cargo_home']=facts(cargo_home)
 result['cargo_cache']=[]
 for directory in ['registry/cache','registry/src','registry/index']:
  p=cargo_home/directory
  names=sorted(child.name for child in p.iterdir()) if p.is_dir() else []
  result['cargo_cache'].append({'path':str(p),'exists':p.is_dir(),'entries':names})
 check('existing_cargo_cache',all(row['exists'] and row['entries'] for row in result['cargo_cache']))
 result['provider_executable']=facts(provider/'bin/openssl',True)
 check('original_provider_hash',result['provider_executable'].get('sha256')=='253724b900b96c194ce4da7c59b158ea477eba0be651df8c72ab899c65cca93d')
 env=dict(os.environ,OPENSSL_CONF='/dev/null',OPENSSL_MODULES=str(provider/'lib/ossl-modules'))
 result['provider_version']=command([str(provider/'bin/openssl'),'version'],env=env)
 check('openssl_359',result['provider_version']['exit_code']==0 and result['provider_version']['stdout'].startswith('OpenSSL 3.5.9 '))
 result['provider_material']=[]
 for rel in ['include/openssl/opensslv.h','lib/libcrypto.a','lib/libssl.a','lib64/libcrypto.a','lib64/libssl.a']:
  p=provider/rel
  if p.exists():result['provider_material'].append(facts(p,True))
 check('openssl_static_libraries',any(Path(row['path']).name=='libcrypto.a' for row in result['provider_material']) and any(Path(row['path']).name=='libssl.a' for row in result['provider_material']))
 result['new_root']=str(root)
 result['root_exists']=root.exists() or root.is_symlink()
 check('new_root_absent',not result['root_exists'])
 result['temporary_ancestors']=[facts(path) for path in reversed(root.parent.parents)] + [facts(root.parent)]
 check('safe_temporary_ancestors',all(not row['symlink'] and row['uid'] in (0,os.getuid()) and int(row['mode'],8)&0o022==0 for row in result['temporary_ancestors']))
 disk=os.statvfs(root.parent)
 result['disk']={'available_bytes':disk.f_bavail*disk.f_frsize,'total_bytes':disk.f_blocks*disk.f_frsize,'device':root.parent.stat().st_dev,'floor_bytes':8589934592}
 check('disk_above_original_floor',result['disk']['available_bytes']>result['disk']['floor_bytes'])
 result['memory']={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemTotal:','MemAvailable:','SwapTotal:','SwapFree:'))}
 result['cpu_count']=os.cpu_count()
 result['existing_configuration_files']=[]
 for p in [cargo_home/'config',cargo_home/'config.toml',repo/'.cargo/config',repo/'.cargo/config.toml',repo/'trillionnium/.cargo/config',repo/'trillionnium/.cargo/config.toml']:
  if p.exists():result['existing_configuration_files'].append(facts(p,True))
 result['source_after']=command(['git','rev-parse','HEAD','HEAD^{tree}'],repo)
 result['status_after']=command(['git','status','--porcelain=v1','--untracked-files=all'],repo)
 check('source_unchanged',result['source_after']==result['source'] and result['status_after']==result['status'])
except Exception as error:
 result['error']=str(error)
 result['checks']['completed_readonly_probe']=False
result['feasible']=bool(result['checks']) and all(result['checks'].values()) and 'error' not in result
print(json.dumps(result,sort_keys=True),flush=True)
raise SystemExit(0 if result['feasible'] else 1)
