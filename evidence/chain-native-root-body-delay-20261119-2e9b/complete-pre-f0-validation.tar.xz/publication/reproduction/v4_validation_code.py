import pathlib,json,subprocess,hashlib,time,os,resource,traceback
s=pathlib.Path('/home/qq/chain-host-stat-20261118-2e9b-source');v=pathlib.Path('/home/qq/chain-native-root-body-delay-20261118-2e9b-validation');out=v/'write-complete-v4';assert (out/'GOLDEN_DERIVATION.json').exists();assert not (out/'VALIDATION.json').exists();env=os.environ.copy();env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];env['CARGO_TARGET_DIR']='/home/qq/chain-host-stat-20261118-2e9b-target';env['CARGO_INCREMENTAL']='0';env['CARGO_NET_OFFLINE']='true';result={'schema':'chain-root-delay-r22-v4-local-validation.v1','status':'preparing','automatic_retry':False,'f0_qualified':False,'full_physical_cost_closed':False,'retained_prepaid_assertion':True,'stages':[]}
def save(): (out/'VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
def run(name,args):
 start=time.monotonic();usage=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args};result['stages'].append(row);save()
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:
  p=subprocess.Popen(args,cwd=s,stdout=so,stderr=se,env=env);row['pid']=p.pid;save();rc=p.wait(timeout=3600)
 end=resource.getrusage(resource.RUSAGE_CHILDREN);row.update(returncode=rc,elapsed_seconds=time.monotonic()-start,child_user_cpu_seconds=end.ru_utime-usage.ru_utime,child_system_cpu_seconds=end.ru_stime-usage.ru_stime);save();return rc
try:
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 changed=['trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs','trillionnium/crates/trnm-pon-node/src/ingress/public_v3/work_arithmetic/tests.rs']
 assert run('format',['rustup','run','1.95.0','rustfmt','--edition','2021','--config','skip_children=true']+changed)==0
 c=s/'config/pon/pq-cross-branch-corpus-v1.json';obj=json.loads(c.read_text());assert len(obj['pinned_blobs'])==2619
 old=json.loads((out/'before/config/pon/pq-cross-branch-corpus-v1.json').read_text());pins=[]
 for name in changed:
  before=obj['pinned_blobs'][name];after=subprocess.check_output(['git','hash-object',name],cwd=s,text=True).strip();obj['pinned_blobs'][name]=after;pins.append({'path':name,'before':before,'after':after})
 c.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n');old['pinned_blobs'].update({x['path']:x['after'] for x in pins});assert obj==old
 result['changed_pins']=pins;result['all_qualification_flags_unchanged']=True
 descriptor=json.loads((v/'write-complete-v3-source-before.json').read_text());result['original_inventory_shape']=type(descriptor).__name__
 # Actual execution inputs include every source/manifest/lock under the retained Rust workspace.
 paths=sorted(p for p in (s/'trillionnium').rglob('*') if p.is_file() and p.suffix in ['.rs','.toml','.lock'])
 paths+=sorted(p for p in [s/'rust-toolchain.toml',s/'config/pon/pq-cross-branch-corpus-v1.json'] if p.exists())
 def snapshot():return {str(p.relative_to(s)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths}
 before=snapshot();(out/'SOURCE_BEFORE.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n');result['actual_source_input_count']=len(before);result['status']='native';save();print(json.dumps({'prepared':True,'source_inputs':len(before),'pins':pins}),flush=True)
 common=['cargo','+1.95.0','test','--offline','--locked','--release','--jobs','2','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib']
 run('complete-public-v3',common+['ingress::public_v3::','--','--nocapture','--test-threads=1'])
 run('strict-clippy',['cargo','+1.95.0','clippy','--offline','--locked','--release','--jobs','2','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib','--','-D','warnings'])
 run('format-check',['rustup','run','1.95.0','rustfmt','--edition','2021','--config','skip_children=true','--check']+changed)
 after=snapshot();(out/'SOURCE_AFTER.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n');result['source_unchanged']=before==after;result['status']='completed'
except BaseException as e:
 result['status']='driver_failed';result['error']=repr(e);(out/'driver-error.log').write_text(traceback.format_exc())
finally:
 result['finished_at_ns']=str(time.time_ns());save();print(json.dumps(result,indent=2),flush=True)