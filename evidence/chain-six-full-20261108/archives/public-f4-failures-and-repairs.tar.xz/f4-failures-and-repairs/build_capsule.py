#!/usr/bin/env python3
"""Build a closed public evidence capsule without executing or editing source."""
import argparse
import hashlib
import io
import json
import lzma
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import zipfile

PREFIX = "f4-failures-and-repairs"
F3 = "1a446a79700cc093a2b1a7f10367ef4a5ddbd680"
F4 = "e9b7a60b9519e39b792199dc8756fb9d1245bab8"
MERGE = "24350527a77a3caee6f1e7a21973874664ab603f"
F3_TREE = "928b180bf769a813e5643827329667cb11f2a3a5"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()


def unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON field")
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=unique_pairs)


def safe_name(name):
    require(isinstance(name, str) and name and "\\" not in name and "\0" not in name,
            "invalid member name")
    path = PurePosixPath(name)
    require(not path.is_absolute() and ".." not in path.parts and "." not in path.parts
            and path.as_posix() == name, "noncanonical or escaping member name")
    return name


def public_bytes(raw):
    require(not re.search(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----", raw),
            "private-key material is outside public scope")
    require(not re.search(rb"(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})", raw),
            "credential-shaped material is outside public scope")
    require((b"api.github.com/repos/" + b"TrillionniumFoundation/" + b"hepta-private-ci") not in raw,
            "private repository API metadata is outside public scope")


def exact_file(path, size, digest):
    path = Path(path)
    require(path.is_absolute() and path.resolve() == path and not path.is_symlink(),
            "aliased input path: " + str(path))
    require(type(size) is int and size >= 0 and re.fullmatch(r"[0-9a-f]{64}", digest),
            "invalid exact-file specification")
    before = path.stat()
    require(stat.S_ISREG(before.st_mode) and before.st_size == size, "input size/type drift")
    with path.open("rb") as source:
        opened = os.fstat(source.fileno())
        require((opened.st_dev, opened.st_ino) == (before.st_dev, before.st_ino),
                "input changed while opening")
        raw = source.read()
        after = os.fstat(source.fileno())
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
            "input changed while reading")
    require(len(raw) == size and sha(raw) == digest, "input digest drift: " + str(path))
    public_bytes(raw)
    return raw


def index_rows(document, kind):
    if kind == "list":
        return document
    if kind == "files_list":
        return document["files"]
    require(kind == "files_dict", "unknown index schema")
    return [dict(path=name, **value) for name, value in document["files"].items()]


def verify_rows(data, rows, prefix, expected_complete=False, manifest_name=None):
    require(isinstance(rows, list), "index is not a list")
    names = set()
    for row in rows:
        require(set(row) == {"path", "bytes", "sha256"}, "index row schema drift")
        name = prefix + safe_name(row["path"])
        require(name not in names, "duplicate indexed member")
        names.add(name)
        require(name in data and type(row["bytes"]) is int and len(data[name]) == row["bytes"]
                and sha(data[name]) == row["sha256"], "nested indexed member drift")
    if expected_complete:
        require(set(data) == names | {manifest_name}, "nested manifest membership drift")


def tar_contents(raw, expected_count):
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:*") as archive:
        members = archive.getmembers()
        require(len(members) == expected_count, "nested tar count drift")
        require(len({m.name for m in members}) == len(members), "duplicate nested tar member")
        require(all(m.isfile() and m.size >= 0 for m in members), "nonregular nested tar member")
        require(sum(m.size for m in members) < 32 * 1024 * 1024, "unexpected nested tar size")
        data = {}
        for member in members:
            name = safe_name(member.name)
            content = archive.extractfile(member).read()
            require(len(content) == member.size, "short nested tar member")
            public_bytes(content)
            data[name] = content
        return data


def zip_contents(raw, expected_count):
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = archive.infolist()
        require(len(entries) == expected_count and len({e.filename for e in entries}) == len(entries),
                "ZIP member count/uniqueness drift")
        require(sum(e.file_size for e in entries) < 32 * 1024 * 1024, "unexpected ZIP size")
        data = {}
        for entry in entries:
            name = safe_name(entry.filename)
            require(not entry.is_dir() and not stat.S_ISLNK(entry.external_attr >> 16)
                    and not (entry.flag_bits & 1), "invalid ZIP member type")
            content = archive.read(entry)
            require(len(content) == entry.file_size, "short ZIP member")
            public_bytes(content)
            data[name] = content
        return data


def nested_review(content):
    json_package = tar_contents(content["repair-packages/repository-json-storage-proposal-d9fb.tar.gz"], 120)
    original_index = "proposal/MANIFEST.json"
    require(sha(json_package[original_index]) == "9d278280964cbbcf969911c62d9ea9af101a8512e71fa45bcef9d05e44bbc879",
            "raw-storage package index drift")
    verify_rows(json_package, parse(json_package[original_index])["members"], "proposal/", True, original_index)
    inventory = tar_contents(content["repair-packages/distributed-inventory-f4-diagnosis.tar.xz"], 51)
    original_index = "distributed-inventory-f4-diagnosis/MANIFEST.json"
    require(sha(inventory[original_index]) == "b9a243cfbd8e6270a94b38e739d6e12a4df3691c8ecdd5ad835bd03976741e4f",
            "inventory package index drift")
    verify_rows(inventory, parse(inventory[original_index])["files"], "distributed-inventory-f4-diagnosis/", True, original_index)
    mldsa = tar_contents(content["repair-packages/mldsa-readback-proposal-d9fb.tar.gz"], 123)
    prefix = "chain-f3-mldsa-readback-proposal-d9fb/"
    require(sha(mldsa[prefix + "input-manifest.json"]) == "aa30ca520c6e68c511725471498f82393d24aee095c4dea7d08664984796793d",
            "ML-DSA input index drift")
    verify_rows(mldsa, parse(mldsa[prefix + "input-manifest.json"])["files"], prefix)
    hosted = []
    for artifact, job, tested in [(13632955616, 128845753787, MERGE),
                                  (13633206199, 128845753838, F3),
                                  (13632997057, 128845753932, F3),
                                  (13632369322, 128845753947, MERGE)]:
        stem = "mldsa-hosted-originals/mldsa-" + str(artifact)
        raw = content[stem + ".original.zip"]
        metadata = parse(content[stem + ".metadata.json"])
        review = parse(content[stem + ".member-review.json"])
        url = "https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain/actions/artifacts/" + str(artifact)
        require(metadata["id"] == artifact and metadata["url"] == url
                and metadata["archive_download_url"] == url + "/zip"
                and metadata["size_in_bytes"] == len(raw)
                and metadata["digest"] == "sha256:" + sha(raw)
                and metadata["workflow_run"]["id"] == 42518203722
                and metadata["workflow_run"]["head_sha"] == F3, "public artifact identity drift")
        require(review["artifact_id"] == artifact and review["job"] == job
                and review["original_run"] == 42518203722
                and review["zip_bytes"] == len(raw) and review["zip_sha256"] == sha(raw)
                and review["metadata_digest_verified"] is True and review["tests_rerun"] is False,
                "original artifact review identity drift")
        data = zip_contents(raw, 12)
        require(len(review["members"]) == 12 and {m["name"] for m in review["members"]} == set(data),
                "original ZIP review roster drift")
        for row in review["members"]:
            body = data[row["name"]]
            require(type(row["bytes"]) is int and len(body) == row["bytes"]
                    and sha(body) == row["sha256"], "original ZIP member drift")
            if "text" in row:
                require(body == row["text"].encode(), "original review text drift")
        for name in ["cell-current-api.json", "cell-current-api.log", "cell-current-api-readback.json", "cell-current-api-readback.log"]:
            require(data[name] == mldsa[prefix + str(job) + "/" + name], "ZIP/proposal original mismatch")
        api = parse(data["cell-current-api.json"])
        readback = parse(data["cell-current-api-readback.json"])
        for record in [api, readback]:
            require(record["before"] == record["after"] and record["before"]["candidate"] == F3
                    and record["before"]["tested_commit"] == tested
                    and record["before"]["tested_tree"] == F3_TREE
                    and record["environment"]["GITHUB_RUN_ID"] == "42518203722"
                    and record["whole_chain_quantum_security_qualified"] is False, "original command/source drift")
        require(api["exit_code"] == 0 and readback["exit_code"] == 1, "original hosted failure was changed")
        hosted.append(dict(artifact_id=artifact, job=job, run=42518203722,
                           zip_sha256=sha(raw), verified_members=12,
                           tested_commit=tested, original_api_exit=0, original_readback_exit=1,
                           independent_c_executed=False))
    codeql_prefix = "codeql-export-f3-analysis-consensus/"
    codeql = zip_contents(content[codeql_prefix + "artifact-13633451849.zip"], 205)
    index = parse(content[codeql_prefix + "zip-member-index.json"])
    require(len(index) == 205 and {r["path"] for r in index} == set(codeql), "CodeQL ZIP roster drift")
    require(all(len(codeql[row["path"]]) == row["bytes"] for row in index), "CodeQL ZIP size drift")
    require(sum(map(len, codeql.values())) == 997726, "CodeQL ZIP total drift")
    return dict(repair_package_members=[120, 51, 123], hosted_mldsa=hosted,
                codeql_zip_members=205, codeql_zip_bytes=997726,
                nested_archive_bytes_read_back=True, tests_or_workflows_executed=False)


def archive_bytes(content):
    target = io.BytesIO()
    with tarfile.open(fileobj=target, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name, raw in sorted(content.items()):
            info = tarfile.TarInfo(PREFIX + "/" + safe_name(name))
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            archive.addfile(info, io.BytesIO(raw))
    return lzma.compress(target.getvalue(), format=lzma.FORMAT_XZ, check=lzma.CHECK_CRC64, preset=6)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--spec", type=Path, required=True)
    parser.add_argument("--readme", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output_dir.exists(), "output directory must be new")
    spec_raw, readme_raw = args.spec.read_bytes(), args.readme.read_bytes()
    spec = parse(spec_raw)
    require(spec["f4_commit"] == F4 and spec["f3_commit"] == F3, "capsule source scope drift")
    content, provenance, original_specs, groups = {}, {}, [], []

    def add(destination, source, size, digest, scope):
        destination = safe_name(destination)
        require(destination not in content and "isolated-fixture" not in PurePosixPath(destination).parts,
                "duplicate or excluded destination")
        content[destination] = exact_file(source, size, digest)
        provenance[destination] = dict(source_path=str(source), scope=scope)
        original_specs.append((source, size, digest))

    for group in spec["index_groups"]:
        raw = exact_file(group["index_path"], group["index_bytes"], group["index_sha256"])
        document = parse(raw)
        rows = index_rows(document, group["kind"])
        require(len(rows) == group["expected_count"], "original index count drift")
        names = set()
        for row in rows:
            require(set(row) == {"path", "bytes", "sha256"}, "original index row schema drift")
            relative = safe_name(row["path"])
            require(relative not in names, "duplicate original indexed path")
            names.add(relative)
            add(group["destination"] + "/" + relative, Path(group["root"]) / relative,
                row["bytes"], row["sha256"], group["name"])
        if group.get("enforce_closed_directory"):
            excluded = document["exact_excluded_operator_files"]
            require(all("/" not in row["path"] and row["bytes"] == 0 for row in excluded),
                    "unexpected closed-directory exclusion")
            for row in excluded:
                exact_file(Path(group["root"]) / safe_name(row["path"]), row["bytes"], row["sha256"])
            require({p.name for p in Path(group["root"]).iterdir()}
                    == names | {row["path"] for row in excluded}, "unknown closed-directory entry")
        destination = group.get("index_destination", group["destination"] + "/" + Path(group["index_path"]).name)
        add(destination, group["index_path"], group["index_bytes"], group["index_sha256"], "original-index")
        groups.append(dict(name=group["name"], original_index=group["index_path"],
                           index_sha256=group["index_sha256"], members=len(rows),
                           original_member_bytes=sum(r["bytes"] for r in rows)))
    for row in spec["individual_files"]:
        add(row["path"], row["source_path"], row["bytes"], row["sha256"], row["scope"])

    nested = nested_review(content)
    f4 = parse(content["proof-pq-f4-validation/summary.json"])
    require(f4["commit"] == F4 and f4["scoped_validation_completed"] is False
            and f4["security_disposition"] == "HOLD_NO_GO", "original F4 failure changed")
    ci = parse(content["ci-literal-repair-review-v2/summary.json"])
    require(ci["original_f4_errors"] == 3 and ci["original_f4_complete_164_passed"] is False
            and ci["repaired_fixture_complete_164_passed"] is True, "CI original/repair boundary changed")
    codeql = parse(content["codeql-export-f3-analysis-consensus/MANIFEST.json"])
    require(codeql["original_export_result"] == "FAIL_INCOMPLETE"
            and codeql["workflow_rerun"] is False, "original CodeQL failure changed")
    consensus = parse(content["consensus-f4-evidence-validation/validation.json"])
    require(consensus["all_passed"] is True, "original bounded evidence validation drift")
    review = dict(schema="public-f4-failure-repair-capsule-scope-review-v1",
                  result="PASS_ARCHIVE_INTEGRITY_ONLY", original_file_count=len(content),
                  index_groups=groups, nested_archives=nested,
                  original_f4_scoped_validation_completed=False,
                  original_f4_failed_stages=f4["failed_stages"],
                  original_ci_contract_errors=3, isolated_ci_repair_pass=True,
                  original_codeql_export="FAIL_INCOMPLETE",
                  original_bounded_evidence_validation_pass=True,
                  source_checkout_modified=False, private_hepta_source_or_api_metadata_included=False,
                  broad_directory_recursion=False, new_execution_or_qualification_claimed=False)
    generated = {"README.md": readme_raw, "build_capsule.py": Path(__file__).read_bytes(),
                 "input-spec.json": spec_raw, "SCOPE_REVIEW.json": json_bytes(review)}
    require(not set(generated) & set(content), "generated member collision")
    content.update(generated)
    for name in generated:
        provenance[name] = dict(scope="capsule-description-and-integrity-tool")
    files = [dict(path=name, bytes=len(raw), sha256=sha(raw), **provenance[name])
             for name, raw in sorted(content.items())]
    manifest = dict(schema="public-f4-failure-and-repair-capsule-v1", source_f4=F4,
                    source_f3=F3, files=files, file_count=len(files),
                    member_bytes=sum(row["bytes"] for row in files),
                    manifest_self_excluded=True, deterministic_tar_headers=True,
                    original_failures_preserved=True, qualification="HOLD_NO_GO")
    content["MANIFEST.json"] = json_bytes(manifest)
    packed = archive_bytes(content)
    require(packed == archive_bytes(content), "deterministic serializations differ")
    restored = tar_contents(packed, len(content))
    require(restored == {PREFIX + "/" + name: raw for name, raw in content.items()},
            "complete archive member readback differs")
    for source, size, digest in original_specs:
        exact_file(source, size, digest)
    args.output_dir.mkdir(parents=True)
    for name, raw in content.items():
        path = args.output_dir / "members" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as destination:
            destination.write(raw)
    archive_path = args.output_dir / "public-f4-failures-and-repairs.tar.xz"
    with archive_path.open("xb") as destination:
        destination.write(packed)
    receipt = dict(schema="public-f4-failure-repair-capsule-build-receipt-v1",
                   result="PASS_ARCHIVE_INTEGRITY_ONLY", archive=str(archive_path),
                   archive_bytes=len(packed), archive_sha256=sha(packed),
                   archive_regular_members=len(content),
                   uncompressed_member_bytes=sum(map(len, content.values())),
                   original_input_files=len(original_specs),
                   manifest=str(args.output_dir / "members/MANIFEST.json"),
                   manifest_bytes=len(content["MANIFEST.json"]), manifest_sha256=sha(content["MANIFEST.json"]),
                   original_inputs_reverified_after_packaging=True,
                   full_member_readback_passed=True, deterministic_two_builds_equal=True,
                   source_checkout_modified=False, tests_or_workflows_executed=False,
                   qualification="HOLD_NO_GO")
    (args.output_dir / "build-receipt.json").write_bytes(json_bytes(receipt))
    print(json.dumps(receipt, sort_keys=True))


if __name__ == "__main__":
    main()
