### 2026-11-10 — Join STARK instance audits and bind executed field helpers

Reconcile the three-route/field work from #849 and the conditional sampler
continuation from #857 with the fixed joint candidate
`da1374a200022bc14dc2bd325cc9ba29dbcd24ab`. Retain the literature manifest's
historical `e2a02f9271b49f146e70806c8a66e161b5973971` baseline and the field
helper's unchanged five-input source basis. Keep the existing RISC Zero,
Poseidon2-P3 and tagged-SHA3-R1 proof domains and all open obligations.

A selected-source reproduction exposed a helper-provenance defect: an ordinary
Python import could use a cached or earlier search-path module. A fabricated
helper result and matching input registry could report a certified reducible
`X^2` extension without changing the 18 frozen source inputs. Production flags
remained false; this was not a W1 forgery or a whole-chain security escalation.
Preserve that original successful spoof observation.

Include the field helper itself in the 19-entry frozen roster, execute exactly
its checked immutable source bytes, and retain import-cache, search-path and
source-plus-JSON-pin substitution refusals. The report records the executed
helper digest separately from field algebra, historical literature and the
current route-mapping basis. Do not restore the older current-QROM map: its
reviewed Root V3 closure and SQLite dependency bindings remain.

Place field, route and conditional-sampler controls exactly once in the
existing mandatory repository-truth lane; extend the independent CI contract
and mutation controls, corpus required paths/pins and distributed config
inventory. Existing shared commands and failure propagation remain.
Selected-fixture local checks passed route 32/32, field 16/16, conditional
sampler 7/7 and retained replay 13/13. These are not complete joint-source
validation or new native STARK execution; obtain final committed-source
observations after integration. All complete security/lifetime bounds remain
null; all 15 security obligations and production/consensus qualifications
remain open.

