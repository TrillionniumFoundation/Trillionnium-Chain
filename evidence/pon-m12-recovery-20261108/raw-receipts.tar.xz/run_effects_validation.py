import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/10366560c781/chain-effects')
OUT = Path('/workspace/scratch/10366560c781/effects-validation')
TOOLCHAIN = Path('/workspace/scratch/d95a703b8dd6/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')

def source():
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).split(b'\0')
    extra = subprocess.check_output(['git', 'ls-files', '-z', '--others', '--exclude-standard'], cwd=ROOT).split(b'\0')
    paths = sorted({p.decode() for p in tracked + extra if p and not p.decode().startswith('evidence/')})
    rows = []
    for path in paths:
        p = ROOT / path
        if p.is_file():
            rows.append([path, p.stat().st_size, hashlib.sha256(p.read_bytes()).hexdigest()])
        elif p.is_symlink():
            rows.append([path, 'symlink', os.readlink(p)])
        else:
            rows.append([path, 'missing'])
    raw = json.dumps(rows, ensure_ascii=False, separators=(',', ':')).encode()
    return {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'content_sha256': hashlib.sha256(raw).hexdigest(), 'files': len(rows), 'rows': rows}

name, *argv = sys.argv[1:]
dest = OUT / name
dest.mkdir(parents=True, exist_ok=False)
env = dict(os.environ)
env.update(PATH=str(TOOLCHAIN) + ':' + env['PATH'],
           RUSTC=str(TOOLCHAIN / 'rustc'), RUSTDOC=str(TOOLCHAIN / 'rustdoc'),
           LD_LIBRARY_PATH=str(TOOLCHAIN.parent / 'lib'),
           CARGO_HOME='/workspace/scratch/10366560c781/toolchain-effects',
           CARGO_TARGET_DIR='/workspace/scratch/10366560c781/target-effects',
           CARGO_BUILD_JOBS='1')
before = source()
(dest / 'source-before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2)+'\n')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (dest / 'stdout.txt').open('wb') as out, (dest / 'stderr.txt').open('wb') as err:
    run = subprocess.run(argv, cwd=ROOT, env=env, stdout=out, stderr=err)
after = source()
(dest / 'source-after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2)+'\n')
result = {'argv': argv, 'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'returncode': run.returncode, 'source_unchanged': before == after,
          'source_content_sha256': before['content_sha256'], 'head': before['head'],
          'scope': 'local component, no independent deployment or provider qualification',
          'build_environment': {k:env[k] for k in ('RUSTC','RUSTDOC','LD_LIBRARY_PATH','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS')},
          'stdout_sha256': hashlib.sha256((dest / 'stdout.txt').read_bytes()).hexdigest(),
          'stderr_sha256': hashlib.sha256((dest / 'stderr.txt').read_bytes()).hexdigest()}
(dest / 'result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
print((dest / 'stdout.txt').read_text(errors='replace')[-16000:])
print((dest / 'stderr.txt').read_text(errors='replace')[-12000:])
sys.exit(run.returncode if before == after else 97)
