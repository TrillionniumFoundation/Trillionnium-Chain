# PR 785 prospective-merge source-pin failure
These are original public GitHub Actions records for run 42431784279, attempt 1.
Both x64 and ARM64 prospective-merge jobs failed at "Require retained source and claim controls".
The exact failing command was python3 scripts/ci/check_pq_research_integration.py, exit 1:
HOLD_NO_GO: changed source: scripts/ci/check_ci_contract.py.

Five preceding control commands succeeded in each job. Compiler/provider installation and the later native gates were skipped. Their behavior was not tested by these failed jobs.

The base checker blob matched the corpus pin. The candidate checker changed, while the corpus, guard and workflow were unchanged from the base. This is a new source-pin integration regression. This package diagnoses the first observed mismatch, not an exhaustive inventory of all changed pinned source. The strict guard correctly rejected the mismatch; these records do not authorize a pin update or qualify cryptographic/security work.

The github directory retains full job logs and API metadata. original-artifact-zips retains both complete downloaded workflow artifacts. artifacts contains their exact extracted members, including original command logs, receipts and source guards. source-comparison retains exact base/head repository bytes and complete diffs. event.json identifies head, base, merge, tree, URLs and relevant hashes. MANIFEST.json hashes every other package file.

This package preserves the original FAIL. It performs no CI rerun, cancellation, source modification, comment or gate waiver. It includes public CI/repository records, not local credentials or private host configuration.
