#!/usr/bin/env python3
"""Prepare a reviewed source-gate continuation OUTSIDE the repository.

This program never edits the checkout. It requires an immutable runtime commit,
checks all 44 original reviewed blobs, records the old gate's real refusal,
and emits reviewable files plus a patch and proposed Git blob pins. The caller
must stop concurrent source changes before running it and separately apply the
reviewed result.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re
import runpy
import stat
import subprocess
import sys

BASE = "4a59131acdf9b8c3210c9b6cd728aeb6c48291fc"
PRIOR = "813620f387199bef3eae2493e2af07c70444db58"
PRIOR_LOCK = "3eef9a9a1431914cae0f25f49a009a6103cf30caf0bc5f189918ad71fe91b71d"
EXECUTOR = "trillionnium/crates/trnm-mvcc-fee/src/pon_executor.rs"
MANIFEST = "config/pon/pq-authority-effects-v1.json"
READER = "scripts/ci/pq_authority_effect_register.py"
TEST = "scripts/ci/test_pq_authority_effect_register.py"
DOC = "docs/security/PQ_AUTHORITY_EFFECT_REGISTER_V1.md"
INVENTORY = "trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs"
REFRESH = "scripts/refresh_distributed_source_inventory.py"
METADATA = (MANIFEST, READER, TEST, DOC)
FALSE_FIELDS = ("coverage_complete", "whole_chain_pq_qualified", "production_activation")


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def git(root, *args):
    return subprocess.check_output(["git", *args], cwd=root)


def blob(root, commit, path):
    return git(root, "show", commit + ":" + path)


def read_regular(root, path):
    selected = root / path
    need(not selected.is_symlink(), "symlink input: " + path)
    info = selected.stat()
    need(stat.S_ISREG(info.st_mode), "nonregular input: " + path)
    raw = selected.read_bytes()
    need(len(raw) == info.st_size, "changed input: " + path)
    return raw


def replace_one(text, old, new, label):
    need(text.count(old) == 1, "expected one reviewed anchor: " + label)
    return text.replace(old, new, 1)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    need(root == args.root.absolute(), "repository root must have no symlink alias")
    need(re.fullmatch("[0-9a-f]{40}", args.source) is not None, "exact commit required")
    source = git(root, "rev-parse", args.source + "^{commit}").decode().strip()
    need(source == args.source and source != PRIOR, "unexpected source commit")
    tree = git(root, "rev-parse", source + "^{tree}").decode().strip()
    head_before = git(root, "rev-parse", "HEAD").decode().strip()
    need(subprocess.run(["git", "merge-base", "--is-ancestor", source, head_before],
                        cwd=root, capture_output=True).returncode == 0,
         "source checkpoint must be reachable from current HEAD")
    out = args.out.absolute()
    need(not out.exists(), "staging output already exists")
    need(not out.is_relative_to(root), "output must be outside repository")
    need(out.parent.resolve(strict=True) == out.parent, "staging parent must be regular")

    before = {path: read_regular(root, path) for path in METADATA}
    for path in METADATA:
        need(before[path] == blob(root, BASE, path),
             "metadata changed since reviewed baseline: " + path)
    manifest = json.loads(before[MANIFEST])
    need(manifest["source_revision"] == PRIOR, "prior revision differs")
    need(all(manifest[name] is False for name in FALSE_FIELDS), "qualification drift")
    need(len(manifest["routes"]) == 7, "route set changed")
    old_files = manifest["source_files_sha256"]
    need(len(old_files) == 44, "curated path set changed")
    need(sha(canonical({"source_revision": PRIOR, "files": old_files})) == PRIOR_LOCK,
         "prior reviewed lock differs")
    new_files = {}
    reviewed_bytes = {}
    for path, expected in old_files.items():
        need(sha(blob(root, PRIOR, path)) == expected,
             "retained prior Git blob does not match lock: " + path)
        raw = blob(root, source, path)
        need(raw == read_regular(root, path),
             "checkout differs from immutable source: " + path)
        reviewed_bytes[path] = raw
        new_files[path] = sha(raw)
    changed = sorted(path for path in old_files if old_files[path] != new_files[path])
    need(changed == [EXECUTOR], "unexpected curated changes: " + repr(changed))
    lock = sha(canonical({"source_revision": source, "files": new_files}))

    prior_result = subprocess.run([sys.executable, READER, "--root", str(root)],
                                  cwd=root, text=True, capture_output=True)
    need(prior_result.returncode == 2
         and "source lock hash mismatch: " + EXECUTOR in
             (prior_result.stdout + prior_result.stderr),
         "old gate did not produce the expected real source mismatch")

    new_manifest = dict(manifest)
    new_manifest["source_revision"] = source
    new_manifest["source_files_sha256"] = new_files
    after = {
        MANIFEST: (json.dumps(new_manifest, indent=2, ensure_ascii=False) + "\n").encode()
    }
    text = before[READER].decode()
    text = replace_one(text, "SOURCE_REVISION = '" + PRIOR + "'",
                       "SOURCE_REVISION = '" + source + "'", "reader source")
    text = replace_one(text, "REVIEWED_SOURCE_LOCK_SHA256 = '" + PRIOR_LOCK + "'",
                       "REVIEWED_SOURCE_LOCK_SHA256 = '" + lock + "'", "reader lock")
    after[READER] = text.encode()

    text = before[TEST].decode()
    text = replace_one(text,
        "self.assertEqual(result['source_revision'],\n                         '" + PRIOR + "')",
        "self.assertEqual(result['source_revision'],\n                         '" + source + "')",
        "positive source assertion")
    anchor = "for field, value in (('source_revision', '0' * 40),\n"
    text = replace_one(text, anchor,
        anchor + "                             ('source_revision', '" + PRIOR + "'),\n",
        "stale source negative")
    after[TEST] = text.encode()

    text = before[DOC].decode()
    heading = "## Current combined candidate binding, 2026-11-12\n"
    need(text.count(heading) == 1, "review heading changed")
    preface, retained = text.split(heading, 1)
    need(preface.count(PRIOR) == 1, "top reviewed revision changed")
    preface = preface.replace(PRIOR, source, 1)
    current = f"""## Current source-composition continuation, 2026-11-12

The reviewed runtime checkpoint is `{source}`, tree
`{tree}`. All 44 regular-file blobs were read with
`git show` at that immutable checkpoint and compared with the actual checkout.
The canonical lock SHA-256, including that checkpoint, is
`{lock}`.

Forty-three curated pins retain the prior `{PRIOR}` bytes.
Only `trillionnium/crates/trnm-mvcc-fee/src/pon_executor.rs` changes, from
`{old_files[EXECUTOR]}` to
`{new_files[EXECUTOR]}`. This dispatch change adds the separately named
source-composition V6 configuration, complete-source release validation and
the new allocation-leaf/release domains. Its claims read the frozen source
payment record. Original PNX1 authentication, sender/nonce checks and
transaction publication remain prerequisites; a record digest is not an
independent grant of payment authority.

The unchanged prior reader was executed against the changed checkout and
returned `source lock hash mismatch` for that executor. The staged continuation
retains this refusal, fixes the reviewed checkpoint and lock explicitly, and
adds the prior `813620f` revision to the stale-context negative control. It
retains all seven route definitions, the 44-path roster, account/network
profile separation and all false qualification fields. New V6 implementation,
policy and native-test files have separate source inventory/corpus coverage;
this partial register does not become their transitive authority proof.

This byte review supplies no native execution, public activation or PQ
qualification. Earlier checkpoint identities and failed observations remain
historical records.

## Retained combined candidate binding, 2026-11-12
"""
    after[DOC] = (preface + current + retained).encode()

    before[INVENTORY] = read_regular(root, INVENTORY)
    module = runpy.run_path(str(root / REFRESH), run_name="_source_gate_inventory_review")
    rendered = module["render"]().encode()
    after[INVENTORY] = rendered
    for path, raw in reviewed_bytes.items():
        need(raw == read_regular(root, path), "source changed during preparation: " + path)
    need(git(root, "rev-parse", "HEAD").decode().strip() == head_before,
         "HEAD changed during preparation")
    for path in METADATA:
        need(before[path] == read_regular(root, path), "metadata changed during preparation")

    out.mkdir(mode=0o700)
    files = []
    patches = []
    for path, raw in after.items():
        target = out / "files" / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        files.append({"path": path, "bytes": len(raw), "old_sha256": sha(before[path]),
                      "sha256": sha(raw),
                      "git_blob_sha1": hashlib.sha1(
                          b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()})
        patches.extend(difflib.unified_diff(before[path].decode().splitlines(True),
                                           raw.decode().splitlines(True),
                                           fromfile="a/" + path, tofile="b/" + path))
    (out / "source-gate-continuation.patch").write_text("".join(patches))
    (out / "prior-reader.stdout").write_text(prior_result.stdout)
    (out / "prior-reader.stderr").write_text(prior_result.stderr)
    original = blob(root, PRIOR, EXECUTOR).decode().splitlines(True)
    new = reviewed_bytes[EXECUTOR].decode().splitlines(True)
    (out / "reviewed-executor.patch").write_text("".join(difflib.unified_diff(
        original, new, fromfile=PRIOR + ":" + EXECUTOR, tofile=source + ":" + EXECUTOR)))
    report = {
        "schema": "source-gate-continuation-preparation-v1",
        "status": "STAGED_REVIEW_REQUIRED_NO_REPOSITORY_WRITES",
        "source_checkpoint": source, "source_tree": tree, "repository_head": head_before,
        "prior_source": PRIOR, "prior_lock": PRIOR_LOCK, "new_lock": lock,
        "curated_paths": 44, "changed_curated_paths": changed,
        "prior_reader_exit_code": prior_result.returncode,
        "route_definitions_changed": False, "native_tests_executed": False,
        "production_activation": False, "whole_chain_pq_qualified": False,
        "staged_files": files,
        "corpus_pin_updates": {row["path"]: row["git_blob_sha1"] for row in files},
        "checks_after_reviewed_application": [
            "python3 scripts/refresh_distributed_source_inventory.py --check",
            "python3 scripts/ci/test_pq_authority_effect_register.py",
            "python3 scripts/ci/pq_authority_effect_register.py",
            "python3 scripts/ci/check_pq_research_integration.py",
            "python3 scripts/ci/check_repository.py",
        ],
    }
    (out / "preparation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
