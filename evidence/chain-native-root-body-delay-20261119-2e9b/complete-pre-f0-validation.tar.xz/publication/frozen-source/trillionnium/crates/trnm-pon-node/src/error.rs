//! Internal failure identity. Display and existing wire error strings stay unchanged.
use std::{error, fmt};

/// An observation category, not blanket permission to retry or restart an owner.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
#[non_exhaustive]
pub enum ErrorKind {
    ProtocolInvalid,
    Capacity,
    Cancelled,
    StaleContext,
    IdentityConflict,
    PolicyRefusal,
    LocalStructure,
    DependencyUnavailable,
    Transport,
    Serialization,
    RemoteRefusal,
    /// Legacy formatted failures remain explicit until their producer is migrated.
    Unclassified,
}

macro_rules! error_codes {
    (
        $($variant:ident => ($wire:literal, $kind:ident)),+ $(,)?
        ; local_only { $($local:ident => ($local_wire:literal, $local_kind:ident)),+ $(,)? }
    ) => {
        /// Exact identities needed by current admission, accounting and recovery paths.
        /// Unknown strings are never recognized by a prefix or by an OS error message.
        #[derive(Clone, Copy, Debug, Eq, PartialEq)]
        #[non_exhaustive]
        pub enum ErrorCode { $($variant,)+ $($local),+ }
        impl ErrorCode {
            pub fn as_str(self) -> &'static str {
                match self { $(Self::$variant => $wire,)+ $(Self::$local => $local_wire),+ }
            }
            fn kind(self) -> ErrorKind {
                match self { $(Self::$variant => ErrorKind::$kind,)+ $(Self::$local => ErrorKind::$local_kind),+ }
            }
            pub(crate) fn parse(message: &str) -> Option<Self> {
                // The local_only group deliberately has no string-parser arm.
                // Quoting its diagnostic cannot grant local cleanup authority.
                match message { $($wire => Some(Self::$variant)),+, _ => None }
            }
        }
    };
}

error_codes! {
    GrowthProfile => ("GROWTH_PROFILE", PolicyRefusal),
    GrowthModelProfile => ("GROWTH_MODEL_PROFILE", PolicyRefusal),
    GrowthAccount => ("GROWTH_ACCOUNT", ProtocolInvalid),
    GrowthCapacity => ("GROWTH_CAPACITY", Capacity),
    GrowthReferenceBackend => ("GROWTH_REFERENCE_BACKEND", PolicyRefusal),
    GrowthReferenceOwner => ("GROWTH_REFERENCE_OWNER", PolicyRefusal),
    GrowthReferenceBindingRequired => ("GROWTH_REFERENCE_BINDING_REQUIRED", PolicyRefusal),
    GrowthReferencePoolUnsupported => ("GROWTH_REFERENCE_POOL_UNSUPPORTED", PolicyRefusal),
    GrowthReferenceMigrationUnsupported => ("GROWTH_REFERENCE_MIGRATION_UNSUPPORTED", PolicyRefusal),
    GrowthReferenceReaderUnsupported => ("GROWTH_REFERENCE_LEGACY_READER_UNSUPPORTED", PolicyRefusal),
    GrowthReferenceSessionUnsupported => ("GROWTH_REFERENCE_SESSION_UNSUPPORTED", PolicyRefusal),
    Hash => ("HASH", ProtocolInvalid),
    HeaderCodec => ("HEADER_CODEC", ProtocolInvalid),
    TransactionCodec => ("TRANSACTION_CODEC", ProtocolInvalid),
    TaskObservationState => ("TASK_OBSERVATION_STATE", LocalStructure),
    NativePaymentNotConfirmed => ("NATIVE_PAYMENT_NOT_CONFIRMED", PolicyRefusal),
    NativeActiveAnchorHistory => ("NATIVE_ACTIVE_ANCHOR_HISTORY", PolicyRefusal),
    PacketLimit => ("PACKET_LIMIT", ProtocolInvalid),
    TransactionLimit => ("TRANSACTION_LIMIT", ProtocolInvalid),
    DuplicateContent => ("DUPLICATE_CONTENT", IdentityConflict),
    StateCapacity => ("STATE_CAPACITY", Capacity),
    ContinuityProfile => ("CONTINUITY_PROFILE", ProtocolInvalid),
    ContinuityState => ("CONTINUITY_STATE", ProtocolInvalid),
    ContinuityRewardQueue => ("CONTINUITY_REWARD_QUEUE", ProtocolInvalid),
    ContinuityMaintenance => ("CONTINUITY_MAINTENANCE", ProtocolInvalid),
    ContinuityMaterial => ("CONTINUITY_MATERIAL", ProtocolInvalid),
    ContinuityTaskReserved => ("CONTINUITY_TASK_RESERVED", ProtocolInvalid),
    ModelEvidenceState => ("MODEL_EVIDENCE_STATE", ProtocolInvalid),
    ModelEvidenceHash => ("MODEL_EVIDENCE_HASH", ProtocolInvalid),
    ModelEvidenceConfig => ("MODEL_EVIDENCE_CONFIG", StaleContext),
    ModelEvidenceProfile => ("MODEL_EVIDENCE_PROFILE", StaleContext),
    ModelEvidenceTaskAlias => ("MODEL_EVIDENCE_TASK_ALIAS", IdentityConflict),
    ModelEvidenceTask => ("MODEL_EVIDENCE_TASK", ProtocolInvalid),
    ModelEvidenceControl => ("MODEL_EVIDENCE_CONTROL", ProtocolInvalid),
    ModelEvidenceSource => ("MODEL_EVIDENCE_SOURCE", PolicyRefusal),
    ModelEvidenceArithmetic => ("MODEL_EVIDENCE_ARITHMETIC", ProtocolInvalid),
    ModelEvidenceMissing => ("MODEL_EVIDENCE_MISSING", PolicyRefusal),
    ModelEvidenceSourceLimit => ("MODEL_EVIDENCE_SOURCE_LIMIT", Capacity),
    ModelEvidenceSourceBudget => ("MODEL_EVIDENCE_SOURCE_BUDGET", Capacity),
    ModelEvidenceDuplicate => ("MODEL_EVIDENCE_DUPLICATE", IdentityConflict),
    ModelEvidenceReveal => ("MODEL_EVIDENCE_REVEAL", ProtocolInvalid),
    ModelEvidenceBinding => ("MODEL_EVIDENCE_BINDING", IdentityConflict),
    ModelEvidenceGain => ("MODEL_EVIDENCE_GAIN", PolicyRefusal),
    ModelEvidenceReviewHold => ("MODEL_EVIDENCE_REVIEW_HOLD", PolicyRefusal),
    ModelCompositionConfig => ("MODEL_COMPOSITION_CONFIG", StaleContext),
    ModelCompositionCount => ("MODEL_COMPOSITION_COUNT", ProtocolInvalid),
    ModelCompositionDerivation => ("MODEL_COMPOSITION_DERIVATION", ProtocolInvalid),
    ModelCompositionGain => ("MODEL_COMPOSITION_GAIN", PolicyRefusal),
    ModelCompositionMarginal => ("MODEL_COMPOSITION_MARGINAL", PolicyRefusal),
    ModelCompositionOrder => ("MODEL_COMPOSITION_ORDER", ProtocolInvalid),
    ModelCompositionParent => ("MODEL_COMPOSITION_PARENT", StaleContext),
    ModelCompositionProfile => ("MODEL_COMPOSITION_PROFILE", StaleContext),
    ModelCompositionRange => ("MODEL_COMPOSITION_RANGE", ProtocolInvalid),
    ModelCompositionSlot => ("MODEL_COMPOSITION_SLOT", ProtocolInvalid),
    ModelCompositionState => ("MODEL_COMPOSITION_STATE", ProtocolInvalid),
    ModelCompositionWeight => ("MODEL_COMPOSITION_WEIGHT", ProtocolInvalid),
    ModelCompositionRedundantSubset => ("MODEL_COMPOSITION_REDUNDANT_SUBSET", PolicyRefusal),
    ModelSourceArithmetic => ("MODEL_SOURCE_ARITHMETIC", ProtocolInvalid),
    ModelSourceBudget => ("MODEL_SOURCE_BUDGET", Capacity),
    ModelSourceCap => ("MODEL_SOURCE_CAP", ProtocolInvalid),
    ModelSourceClaim => ("MODEL_SOURCE_CLAIM", ProtocolInvalid),
    ModelSourceConfig => ("MODEL_SOURCE_CONFIG", StaleContext),
    ModelSourceCount => ("MODEL_SOURCE_COUNT", ProtocolInvalid),
    ModelSourceDerivation => ("MODEL_SOURCE_DERIVATION", ProtocolInvalid),
    ModelSourceEvidence => ("MODEL_SOURCE_EVIDENCE", ProtocolInvalid),
    ModelSourceGain => ("MODEL_SOURCE_GAIN", PolicyRefusal),
    ModelSourceIdentity => ("MODEL_SOURCE_IDENTITY", IdentityConflict),
    ModelSourceInsufficientEvidence => ("MODEL_SOURCE_INSUFFICIENT_EVIDENCE", PolicyRefusal),
    ModelSourceMarker => ("MODEL_SOURCE_MARKER", ProtocolInvalid),
    ModelSourceOrder => ("MODEL_SOURCE_ORDER", ProtocolInvalid),
    ModelSourceParent => ("MODEL_SOURCE_PARENT", StaleContext),
    ModelSourceProfile => ("MODEL_SOURCE_PROFILE", StaleContext),
    ModelSourceRecord => ("MODEL_SOURCE_RECORD", ProtocolInvalid),
    ModelSourceRecordSize => ("MODEL_SOURCE_RECORD_SIZE", Capacity),
    ModelSourceState => ("MODEL_SOURCE_STATE", ProtocolInvalid),
    FrameEof => ("FRAME_EOF", Transport),
    FrameDeadline => ("FRAME_DEADLINE", Cancelled),
    PublicEof => ("PUBLIC_EOF", Transport),
    PublicTrailingInput => ("PUBLIC_TRAILING_INPUT", Transport),
    PublicClientDeadline => ("PUBLIC_CLIENT_DEADLINE", Cancelled),
    PeerPollCancelled => ("PEER_POLL_CANCELLED", Cancelled),
    LegacyRequestCancelled => ("CANCELLED", Cancelled),
    LegacyRequestDeadline => ("REQUEST_DEADLINE", Cancelled),
    PublicRequestCancelled => ("PUBLIC_REQUEST_CANCELLED", Cancelled),
    PublicRequestDeadline => ("PUBLIC_REQUEST_DEADLINE", Cancelled),
    SubmitRecoveryDeadline => ("SUBMIT_RECOVERY_DEADLINE", Cancelled),
    PublicMutationCpuBudget => ("PUBLIC_MUTATION_CPU_BUDGET", Capacity),
    PublicMutationCpuUnavailable => ("PUBLIC_MUTATION_CPU_UNAVAILABLE", DependencyUnavailable),
    PublicSpentCapacity => ("PUBLIC_SPENT_CAPACITY", Capacity),
    PublicBufferCapacity => ("PUBLIC_BUFFER_CAPACITY", Capacity),
    PublicCallerMutationCapacity => ("PUBLIC_CALLER_MUTATION_CAPACITY", Capacity),
    PublicCallerMutationUnavailable => ("PUBLIC_CALLER_MUTATION_UNAVAILABLE", DependencyUnavailable),
    PublicQueueBusy => ("PUBLIC_QUEUE_BUSY", Capacity),
    PublicExecutionSnapshotCapacity => ("PUBLIC_EXECUTION_SNAPSHOT_CAPACITY", Capacity),
    AdmissionHeaderEpochChanged => ("ADMISSION_HEADER_EPOCH_CHANGED", StaleContext),
    OwnerDetachedExecutionContext => ("OWNER_DETACHED_EXECUTION_CONTEXT", LocalStructure),
    OwnerDetachedExecutionUnsupported => ("OWNER_DETACHED_EXECUTION_UNSUPPORTED", DependencyUnavailable),
    // Local service/Node budget binding, never invalid consensus Work.
    OwnerPublicServiceCpuDomain => ("OWNER_PUBLIC_SERVICE_CPU_DOMAIN", PolicyRefusal),
    OwnerPublicServiceDomainUnbound => ("OWNER_PUBLIC_SERVICE_DOMAIN_UNBOUND", DependencyUnavailable),
    OwnerReorgTerminationCpuRequired => ("OWNER_REORG_TERMINATION_CPU_REQUIRED", DependencyUnavailable),
    ReorgLifecycle => ("REORG_LIFECYCLE", LocalStructure),
    OwnerPublicServiceUncleanEpoch => ("OWNER_PUBLIC_SERVICE_UNCLEAN_EPOCH", DependencyUnavailable),
    OwnerContinuousHistoryDurableRequired => ("OWNER_CONTINUOUS_HISTORY_DURABLE_REQUIRED", DependencyUnavailable),
    OwnerContinuousCpuBudget => ("OWNER_CONTINUOUS_CPU_BUDGET", Capacity),
    OwnerPublicServiceEpochCorrupt => ("OWNER_PUBLIC_SERVICE_EPOCH_CORRUPT", LocalStructure),
    PublicListenerDomainCapacity => ("PUBLIC_LISTENER_DOMAIN_CAPACITY", Capacity),
    PublicHostProcessCapacity => ("PUBLIC_HOST_PROCESS_CAPACITY", Capacity),
    PublicHostProcessUnavailable => ("PUBLIC_HOST_PROCESS_UNAVAILABLE", DependencyUnavailable),
    PublicHostSlotAddress => ("PUBLIC_HOST_SLOT_ADDRESS", LocalStructure),
    PublicHostProcessGuardUnsupported => ("PUBLIC_HOST_PROCESS_GUARD_UNSUPPORTED", DependencyUnavailable),
    ReservedReadOnlyBusy => ("ADMISSION_BUSY_READ_ONLY_RESERVED", Capacity),
    PublicTicketReplay => ("PUBLIC_TICKET_REPLAY", IdentityConflict),
    PublicCookieExpired => ("PUBLIC_COOKIE_EXPIRED", StaleContext),
    PublicCookieContext => ("PUBLIC_COOKIE_CONTEXT", StaleContext),
    PublicChallengeContext => ("PUBLIC_CHALLENGE_CONTEXT", StaleContext),
    PublicResponseContext => ("PUBLIC_RESPONSE_CONTEXT", StaleContext),
    PublicChallengeSignature => ("PUBLIC_CHALLENGE_SIGNATURE", ProtocolInvalid),
    PublicResponseSignature => ("PUBLIC_RESPONSE_SIGNATURE", ProtocolInvalid),
    UnknownParent => ("UNKNOWN_PARENT", StaleContext),
    TimeDeferred => ("TIME_DEFERRED", StaleContext),
    Cursor => ("CURSOR", StaleContext),
    SubmitRecoveryStaleHead => ("SUBMIT_RECOVERY_STALE_HEAD", StaleContext),
    SubmitRecoveryStaleBranch => ("SUBMIT_RECOVERY_STALE_BRANCH", StaleContext),
    OwnerPoisoned => ("OWNER_POISONED", LocalStructure),
    NamespaceChanged => ("NAMESPACE_CHANGED", IdentityConflict),
    DatabaseReplaced => ("DATABASE_REPLACED", IdentityConflict),
    OwnerReplaced => ("OWNER_REPLACED", IdentityConflict),
    ReorgInProgress => ("REORG_IN_PROGRESS", LocalStructure),
    StorageContext => ("STORAGE_CONTEXT", LocalStructure),
    StorageHash => ("STORAGE_HASH", LocalStructure),
    StoragePacket => ("STORAGE_PACKET", LocalStructure),
    StorageWork => ("STORAGE_WORK", LocalStructure),
    AncestryIndexBudget => ("ANCESTRY_INDEX_BUDGET", Capacity),
    AncestryIndexGenesis => ("ANCESTRY_INDEX_GENESIS", LocalStructure),
    AncestryIndexHash => ("ANCESTRY_INDEX_HASH", LocalStructure),
    AncestryIndexHeader => ("ANCESTRY_INDEX_HEADER", LocalStructure),
    AncestryIndexLevel => ("ANCESTRY_INDEX_LEVEL", LocalStructure),
    AncestryIndexMetadata => ("ANCESTRY_INDEX_METADATA", LocalStructure),
    AncestryIndexMissing => ("ANCESTRY_INDEX_MISSING", LocalStructure),
    AncestryIndexPacketBytes => ("ANCESTRY_INDEX_PACKET_BYTES", LocalStructure),
    AncestryIndexParent => ("ANCESTRY_INDEX_PARENT", LocalStructure),
    AncestryIndexSeal => ("ANCESTRY_INDEX_SEAL", LocalStructure),
    AncestryIndexStructure => ("ANCESTRY_INDEX_STRUCTURE", LocalStructure),
    AncestryIndexUnknownBlock => ("ANCESTRY_INDEX_UNKNOWN_BLOCK", StaleContext),
    AuthSessionCollision => ("AUTH_SESSION_COLLISION", IdentityConflict),
    AuthOutboxSessionCollision => ("AUTH_OUTBOX_SESSION_COLLISION", IdentityConflict),
    AuthReplayContext => ("AUTH_REPLAY_CONTEXT", StaleContext),
    AuthOutboxContext => ("AUTH_OUTBOX_CONTEXT", StaleContext),
    AuthReplayState => ("AUTH_REPLAY_STATE", StaleContext),
    AuthOutboxState => ("AUTH_OUTBOX_STATE", StaleContext),
    AuthReplayRetired => ("AUTH_REPLAY_RETIRED", StaleContext),
    AuthOutboxOverflow => ("AUTH_OUTBOX_OVERFLOW", Capacity),
    AuthConflictingReplay => ("AUTH_CONFLICTING_REPLAY", IdentityConflict),
    AuthResponseConflict => ("AUTH_RESPONSE_CONFLICT", IdentityConflict),
    AuthOutboxConflict => ("AUTH_OUTBOX_CONFLICT", IdentityConflict),
    AuthPayload => ("AUTH_PAYLOAD", ProtocolInvalid),
    AuthResponse => ("AUTH_RESPONSE", ProtocolInvalid),
    AuthOutboxWire => ("AUTH_OUTBOX_WIRE", ProtocolInvalid),
    AuthReplayGap => ("AUTH_REPLAY_GAP", ProtocolInvalid),
    AuthReplayAudit => ("AUTH_REPLAY_AUDIT", ProtocolInvalid),
    RemoteTerminal => ("REMOTE_TERMINAL", RemoteRefusal),
    RemoteRetryable => ("REMOTE_RETRYABLE", RemoteRefusal),
    ; local_only {
        MiningRunStopped => ("MINING_RUN_STOPPED", Cancelled),
        PqNetworkDeadline => ("PQ_NETWORK_DEADLINE", Cancelled),
        PqNetworkExpired => ("PQ_NETWORK_EXPIRED", Cancelled),
        PqNetworkRevoked => ("PQ_NETWORK_REVOKED", Cancelled),
    }
}

#[derive(Debug)]
pub struct Error {
    code: Option<ErrorCode>,
    kind: ErrorKind,
    message: String,
    source: Option<Box<dyn error::Error + Send + Sync>>,
    /// Only the controlled public-history operation can select this origin.
    /// Parsing a string or an authenticated remote reply never selects it.
    request_history_budget: bool,
    // A private completed native comparison, never reconstructed from text.
    native_root_refusal: Option<Box<crate::store::NativeRootRefusal>>,
}
impl Error {
    pub fn new(code: ErrorCode) -> Self {
        Self {
            code: Some(code),
            kind: code.kind(),
            message: code.as_str().into(),
            source: None,
            request_history_budget: false,
            native_root_refusal: None,
        }
    }
    /// Only the native held/detached final-output comparison can construct
    /// this provenance. It is not a cached verdict or admission capability.
    pub(crate) fn native_output_root_refusal(proof: crate::store::NativeRootRefusal) -> Self {
        let mut error = Self::from("ROOT");
        error.native_root_refusal = Some(Box::new(proof));
        error
    }
    pub(crate) fn completed_native_root_body(
        &self,
        settings: &crate::Settings,
        body_digest: &str,
    ) -> Option<trnm_protocol::pon_wire::Hash> {
        if self.kind != ErrorKind::Unclassified || self.code.is_some() {
            return None;
        }
        self.native_root_refusal
            .as_ref()?
            .matches(settings, body_digest)
    }
    pub fn code(&self) -> Option<ErrorCode> {
        self.code
    }
    pub fn kind(&self) -> ErrorKind {
        self.kind
    }
    pub fn is(&self, code: ErrorCode) -> bool {
        self.code == Some(code)
    }
    /// Only local owner/DB/history failures stop pinned polling. A peer's signed
    /// refusal is still a remote observation, even if it names a structural code.
    /// Original owner ancestry budgets retain their fatal policy. The specific
    /// cumulative public History request budget has a private nonfatal origin;
    /// a later local-integrity classification still overrides that origin.
    /// Capacity alone never authorizes a retry.
    pub fn requires_owner_stop(&self) -> bool {
        if self.request_history_budget && self.kind == ErrorKind::Capacity {
            return false;
        }
        if self.kind == ErrorKind::RemoteRefusal {
            return false;
        }
        self.kind == ErrorKind::LocalStructure
            || matches!(
                self.code,
                Some(
                    ErrorCode::NamespaceChanged
                        | ErrorCode::DatabaseReplaced
                        | ErrorCode::OwnerReplaced
                        | ErrorCode::AncestryIndexBudget
                        // The original paid CPU owner becoming unavailable is
                        // NOT a transient remote peer refusal or budget debit.
                        // A pinned poller must stop instead of silently trying
                        // fresh unowned work in its next cycle.
                        | ErrorCode::PublicMutationCpuUnavailable
                        | ErrorCode::OwnerPublicServiceCpuDomain
                        | ErrorCode::OwnerPublicServiceDomainUnbound
                        | ErrorCode::OwnerReorgTerminationCpuRequired
                        | ErrorCode::OwnerPublicServiceUncleanEpoch
                        | ErrorCode::OwnerDetachedExecutionUnsupported
                        | ErrorCode::OwnerContinuousHistoryDurableRequired
                )
            )
    }
    /// A local request's cumulative SQL allowance ended, without any completed
    /// integrity verdict. Retain the existing wire code/category while keeping
    /// a healthy owner available. This is neither remote parsing nor permission
    /// to downgrade a corrupt ancestry/schema failure.
    pub(crate) fn public_history_budget() -> Self {
        let mut error = Self::new(ErrorCode::AncestryIndexBudget);
        error.request_history_budget = true;
        error
    }
    /// Use only for a failed invariant of bytes/links already held by the local
    /// store. The same diagnostic from a new packet or an unknown caller locator
    /// has no authority to stop the owner. Do not wrap a progress callback or a
    /// complete request: those can carry cancellation and peer-controlled input.
    pub(crate) fn local_integrity(mut self) -> Self {
        self.kind = ErrorKind::LocalStructure;
        self.native_root_refusal = None;
        self
    }
    /// A failed reconstruction/recovery of the local replay journal. Preserve
    /// its exact legacy diagnostic and the typed source; never infer this origin
    /// by parsing an AUTH_* prefix received from the network.
    pub(crate) fn local_replay_source(
        prefix: &'static str,
        source: impl error::Error + Send + Sync + 'static,
    ) -> Self {
        Self::prefixed_source(ErrorKind::LocalStructure, prefix, source)
    }
    /// Admission/ACK identity comes from the transport boundary's enum, never
    /// its human description. A caller-supplied frame cannot establish that a
    /// local journal is damaged; retained reconstruction has a separate origin.
    pub(crate) fn peer_admission_source(
        prefix: &'static str,
        source: trnm_transport::PeerAdmissionErrorV0,
    ) -> Self {
        Self::prefixed_source(Self::peer_admission_kind(source), prefix, source)
    }
    /// Used by the store's exact payload verifier, whose Source error describes
    /// caller frame/payload bytes. This boundary cannot grant owner-stop authority.
    pub(crate) fn peer_frame_source(
        prefix: &'static str,
        source: trnm_transport::PeerFrameVerificationErrorV0<Self>,
    ) -> Self {
        let kind = match &source {
            trnm_transport::PeerFrameVerificationErrorV0::Boundary(error) => {
                Self::peer_admission_kind(*error)
            }
            trnm_transport::PeerFrameVerificationErrorV0::Source(_) => ErrorKind::ProtocolInvalid,
        };
        Self::prefixed_source(kind, prefix, source)
    }
    fn peer_admission_kind(source: trnm_transport::PeerAdmissionErrorV0) -> ErrorKind {
        use trnm_transport::PeerAdmissionErrorV0 as Peer;
        match source {
            Peer::ZeroDigest
            | Peer::InvalidSession
            | Peer::InvalidFrame
            | Peer::InvalidRecoveryState
            | Peer::NonContiguousNonce => ErrorKind::ProtocolInvalid,
            Peer::WrongSession | Peer::ConflictingReplay | Peer::UnexpectedAcknowledgement => {
                ErrorKind::IdentityConflict
            }
            Peer::StaleNonce | Peer::StaleToken => ErrorKind::StaleContext,
            Peer::ReplayOverflow | Peer::PendingFrame => ErrorKind::Capacity,
        }
    }
    fn prefixed_source(
        kind: ErrorKind,
        prefix: &'static str,
        source: impl error::Error + Send + Sync + 'static,
    ) -> Self {
        Self {
            code: None,
            kind,
            message: format!("{prefix}:{source}"),
            source: Some(Box::new(source)),
            request_history_budget: false,
            native_root_refusal: None,
        }
    }
    /// Parse only after the caller has established its required reply authentication.
    /// Construction itself authenticates nothing and gives no local failure authority.
    pub(crate) fn remote(message: impl Into<String>) -> Self {
        // A peer can quote every local diagnostic. Keep that text for the
        // caller, but never manufacture a typed local code from it. Controlled
        // authenticated terminal/retryable status has its own constructor.
        Self {
            code: None,
            kind: ErrorKind::RemoteRefusal,
            message: message.into(),
            source: None,
            request_history_budget: false,
            native_root_refusal: None,
        }
    }
    pub(crate) fn authenticated_remote(terminal: bool, message: &str) -> Self {
        let code = if terminal {
            ErrorCode::RemoteTerminal
        } else {
            ErrorCode::RemoteRetryable
        };
        let mut error = Self::new(code);
        error.message = format!("{}:{message}", code.as_str());
        error
    }
    fn caused_by(
        kind: ErrorKind,
        prefix: &str,
        source: impl error::Error + Send + Sync + 'static,
    ) -> Self {
        Self {
            code: None,
            kind,
            message: format!("{prefix}: {source}"),
            source: Some(Box::new(source)),
            request_history_budget: false,
            native_root_refusal: None,
        }
    }
}
impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.message)
    }
}
impl error::Error for Error {
    fn source(&self) -> Option<&(dyn error::Error + 'static)> {
        self.source
            .as_deref()
            .map(|source| source as &(dyn error::Error + 'static))
    }
}
impl From<&str> for Error {
    fn from(message: &str) -> Self {
        Self::from(message.to_owned())
    }
}
impl From<String> for Error {
    fn from(message: String) -> Self {
        let code = ErrorCode::parse(&message);
        Self {
            code,
            kind: code.map_or(ErrorKind::Unclassified, ErrorCode::kind),
            message,
            source: None,
            request_history_budget: false,
            native_root_refusal: None,
        }
    }
}
impl From<std::io::Error> for Error {
    fn from(source: std::io::Error) -> Self {
        Self::caused_by(ErrorKind::Transport, "IO", source)
    }
}
impl From<rusqlite::Error> for Error {
    fn from(source: rusqlite::Error) -> Self {
        Self::caused_by(ErrorKind::LocalStructure, "STORAGE", source)
    }
}
impl From<serde_json::Error> for Error {
    fn from(source: serde_json::Error) -> Self {
        Self::caused_by(ErrorKind::Serialization, "JSON", source)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::error::Error as _;

    #[test]
    fn pq_control_codes_require_explicit_local_origin() {
        for (code, wire) in [
            (ErrorCode::PqNetworkDeadline, "PQ_NETWORK_DEADLINE"),
            (ErrorCode::PqNetworkExpired, "PQ_NETWORK_EXPIRED"),
            (ErrorCode::PqNetworkRevoked, "PQ_NETWORK_REVOKED"),
        ] {
            let local = Error::new(code);
            assert_eq!(local.to_string(), wire);
            assert_eq!(local.kind(), ErrorKind::Cancelled);
            assert!(local.is(code));
            assert!(!local.requires_owner_stop());
            assert_eq!(ErrorCode::parse(wire), None);
            for quoted in [
                Error::from(wire),
                Error::from(wire.to_owned()),
                Error::from(format!(" {wire}")),
                Error::from(format!("{wire}: quoted remote diagnostic")),
            ] {
                assert_eq!(quoted.kind(), ErrorKind::Unclassified);
                assert_eq!(quoted.code(), None);
                assert!(!quoted.requires_owner_stop());
            }
            let transport = Error::from(std::io::Error::other(wire));
            assert_eq!(transport.kind(), ErrorKind::Transport);
            assert_eq!(transport.code(), None);
            let remote = Error::remote(wire);
            assert_eq!(remote.to_string(), wire);
            assert_eq!(remote.kind(), ErrorKind::RemoteRefusal);
            assert_eq!(remote.code(), None);
            for terminal in [false, true] {
                let remote = Error::authenticated_remote(terminal, wire);
                let expected = if terminal {
                    ErrorCode::RemoteTerminal
                } else {
                    ErrorCode::RemoteRetryable
                };
                assert_eq!(remote.kind(), ErrorKind::RemoteRefusal);
                assert!(remote.is(expected));
                assert!(!remote.is(code));
                assert!(!remote.requires_owner_stop());
                assert_eq!(remote.to_string(), format!("{}:{wire}", expected.as_str()));
            }
        }
    }

    #[test]
    fn legacy_request_controls_keep_original_wire_and_typed_local_cancellation() {
        for (code, wire) in [
            (ErrorCode::LegacyRequestCancelled, "CANCELLED"),
            (ErrorCode::LegacyRequestDeadline, "REQUEST_DEADLINE"),
        ] {
            let local = Error::new(code);
            assert_eq!(local.to_string(), wire);
            assert_eq!(local.kind(), ErrorKind::Cancelled);
            assert!(!local.requires_owner_stop());
            assert!(Error::from(wire).is(code));
            let remote = Error::remote(wire);
            assert_eq!(remote.kind(), ErrorKind::RemoteRefusal);
            assert_eq!(remote.code(), None);
            assert!(!remote.is(code));
        }
    }

    #[test]
    fn continuous_history_without_a_durable_claim_is_a_local_owner_stop() {
        let message = "OWNER_CONTINUOUS_HISTORY_DURABLE_REQUIRED";
        let local = Error::from(message);
        assert!(local.is(ErrorCode::OwnerContinuousHistoryDurableRequired));
        assert_eq!(local.kind(), ErrorKind::DependencyUnavailable);
        assert!(local.requires_owner_stop());
        // A remote peer's arbitrary string is not local resource authority.
        let remote = Error::remote(message);
        assert!(!remote.requires_owner_stop());
        assert!(!remote.is(ErrorCode::OwnerContinuousHistoryDurableRequired));
    }

    #[test]
    fn display_changes_cannot_change_typed_retry_or_owner_stop_identity() {
        let mut budget = Error::new(ErrorCode::PublicMutationCpuBudget);
        assert_eq!(budget.to_string(), "PUBLIC_MUTATION_CPU_BUDGET");
        budget.message = "receiver CPU reservation temporarily unavailable".into();
        assert!(budget.is(ErrorCode::PublicMutationCpuBudget));
        assert_eq!(budget.kind(), ErrorKind::Capacity);
        assert!(!budget.requires_owner_stop());
        let mut storage = Error::new(ErrorCode::StoragePacket);
        storage.message = "invalid retained packet bytes".into();
        assert!(storage.requires_owner_stop());
        let mut eof = Error::new(ErrorCode::FrameEof);
        eof.message = "peer closed the socket".into();
        assert!(eof.is(ErrorCode::FrameEof));
    }

    #[test]
    fn unavailable_original_cpu_owner_is_fatal_but_budget_and_remote_refusals_are_not() {
        for code in [
            ErrorCode::PublicMutationCpuUnavailable,
            ErrorCode::OwnerPublicServiceCpuDomain,
            ErrorCode::OwnerPublicServiceDomainUnbound,
            ErrorCode::OwnerReorgTerminationCpuRequired,
            ErrorCode::OwnerPublicServiceUncleanEpoch,
        ] {
            let local = Error::new(code);
            assert!(local.requires_owner_stop(), "{code:?}");
            // Never allow an attacker-controlled remote error string to
            // disable a healthy local receiver, even if its wire text
            // matches a local CPU owner diagnostic.
            let remote = Error::remote(local.to_string());
            assert!(!remote.requires_owner_stop(), "{code:?}");
            assert!(!remote.is(code), "{code:?}");
            assert_eq!(remote.code(), None);
        }
        assert!(!Error::new(ErrorCode::PublicMutationCpuBudget).requires_owner_stop());
    }

    #[test]
    fn local_integrity_origin_preserves_diagnostic_code_and_typed_cause() {
        for message in ["HEADER_CODEC", "UNKNOWN_PARENT", "ANCESTRY_HEIGHT", "ROOT"] {
            let untrusted = Error::from(message);
            assert!(!untrusted.requires_owner_stop());
            let mut stored = Error::from(message).local_integrity();
            assert_eq!(stored.to_string(), message);
            assert_eq!(stored.code(), untrusted.code());
            assert_eq!(stored.kind(), ErrorKind::LocalStructure);
            assert!(stored.requires_owner_stop());
            stored.message = "changed diagnostic for the same local invariant".into();
            assert!(stored.requires_owner_stop());
            assert!(!Error::remote(message).requires_owner_stop());
        }
        let source = trnm_transport::PeerAdmissionErrorV0::InvalidRecoveryState;
        let mut stored = Error::local_replay_source("AUTH_REPLAY", source);
        let expected = format!("AUTH_REPLAY:{source}");
        assert_eq!(stored.to_string(), expected);
        assert_eq!(stored.code(), None);
        assert_eq!(stored.kind(), ErrorKind::LocalStructure);
        assert_eq!(
            stored
                .source()
                .unwrap()
                .downcast_ref::<trnm_transport::PeerAdmissionErrorV0>(),
            Some(&source)
        );
        assert!(!Error::from(expected.clone()).requires_owner_stop());
        assert!(!Error::remote(expected).requires_owner_stop());
        stored.message = "changed local replay diagnostic".into();
        assert!(stored.requires_owner_stop());
    }

    #[test]
    fn replay_boundary_identity_and_retained_origin_do_not_depend_on_source_words() {
        use trnm_transport::{PeerAdmissionErrorV0 as Peer, PeerFrameVerificationErrorV0};

        let cause = Peer::InvalidRecoveryState;
        let mut input = Error::peer_admission_source("AUTH_REPLAY", cause);
        let mut retained = Error::local_replay_source("AUTH_REPLAY", cause);
        assert_eq!(input.to_string(), retained.to_string());
        assert_eq!(input.kind(), ErrorKind::ProtocolInvalid);
        assert!(!input.requires_owner_stop());
        assert!(retained.requires_owner_stop());
        for error in [&input, &retained] {
            assert_eq!(error.code(), None);
            assert_eq!(error.source().unwrap().downcast_ref::<Peer>(), Some(&cause));
            assert!(!Error::from(error.to_string()).requires_owner_stop());
            assert!(!Error::remote(error.to_string()).requires_owner_stop());
        }
        input.message = "OWNER_REPLACED".into();
        retained.message = "an incoming frame would normally be retried".into();
        assert!(!input.requires_owner_stop());
        assert!(retained.requires_owner_stop());

        let mut pending = Error::peer_frame_source(
            "AUTH_FRAME",
            PeerFrameVerificationErrorV0::Boundary(Peer::PendingFrame),
        );
        assert_eq!(pending.kind(), ErrorKind::Capacity);
        pending.message = "STORAGE: peer chose structural-looking prose".into();
        assert!(!pending.requires_owner_stop());
        assert_eq!(pending.kind(), ErrorKind::Capacity);
        let lookalike = Error::peer_frame_source(
            "AUTH_FRAME",
            PeerFrameVerificationErrorV0::Source(Error::from("OWNER_REPLACED")),
        );
        assert_eq!(
            lookalike.to_string(),
            "AUTH_FRAME:peer frame source rejected: OWNER_REPLACED"
        );
        assert_eq!(lookalike.kind(), ErrorKind::ProtocolInvalid);
        assert!(!lookalike.requires_owner_stop());

        for code in [
            ErrorCode::AuthReplayAudit,
            ErrorCode::AuthReplayState,
            ErrorCode::AuthOutboxState,
        ] {
            let mut stored = Error::new(code).local_integrity();
            assert!(stored.requires_owner_stop());
            assert!(!Error::remote(stored.to_string()).requires_owner_stop());
            assert!(!Error::from(stored.to_string()).requires_owner_stop());
            stored.message = "changed retained journal invariant text".into();
            assert!(stored.is(code));
            assert!(stored.requires_owner_stop());
        }
    }

    #[test]
    fn prefix_lookalikes_and_remote_failures_cannot_stop_local_owner() {
        for message in [
            "STORAGE_REPORTED_BY_PEER",
            "ANCESTRY_INDEX_REPORTED_BY_PEER",
            "STORAGE: remote text",
            "FRAME_EOF: remote text",
        ] {
            let error = Error::from(message);
            assert_eq!(error.code(), None);
            assert_eq!(error.kind(), ErrorKind::Unclassified);
            assert!(!error.requires_owner_stop());
            assert_eq!(error.to_string(), message);
        }
        for message in ["STORAGE_PACKET", "OWNER_REPLACED", "ANCESTRY_INDEX_SEAL"] {
            let local = Error::from(message);
            assert!(local.requires_owner_stop());
            let remote = Error::remote(message);
            assert_eq!(remote.code(), None);
            assert!(!remote.is(local.code().unwrap()));
            assert_eq!(remote.kind(), ErrorKind::RemoteRefusal);
            assert!(!remote.requires_owner_stop());
            assert_eq!(remote.to_string(), message);
        }
        assert!(!Error::from("ANCESTRY_INDEX_UNKNOWN_BLOCK").requires_owner_stop());
        let budget = Error::from("ANCESTRY_INDEX_BUDGET");
        assert_eq!(budget.kind(), ErrorKind::Capacity);
        assert!(budget.requires_owner_stop());
    }

    #[test]
    fn typed_causes_preserve_source_and_display_without_parsing_source_text() {
        let io = std::io::Error::other("FRAME_EOF");
        let error = Error::from(io);
        assert_eq!(error.to_string(), "IO: FRAME_EOF");
        assert_eq!(error.kind(), ErrorKind::Transport);
        assert_eq!(error.code(), None);
        assert!(error.source().unwrap().is::<std::io::Error>());
        assert!(!error.requires_owner_stop());
        let sqlite = rusqlite::Error::InvalidQuery;
        let expected = format!("STORAGE: {sqlite}");
        let error = Error::from(sqlite);
        assert_eq!(error.to_string(), expected);
        assert!(error.source().unwrap().is::<rusqlite::Error>());
        assert!(error.requires_owner_stop());
        let json = serde_json::from_str::<bool>("[").unwrap_err();
        let expected = format!("JSON: {json}");
        let error = Error::from(json);
        assert_eq!(error.to_string(), expected);
        assert_eq!(error.kind(), ErrorKind::Serialization);
        assert!(error.source().unwrap().is::<serde_json::Error>());
    }

    #[test]
    fn authenticated_reply_terminality_controls_remote_retry_identity() {
        let retry = Error::authenticated_remote(false, "REMOTE_TERMINAL: misleading text");
        assert!(retry.is(ErrorCode::RemoteRetryable));
        assert_eq!(
            retry.to_string(),
            "REMOTE_RETRYABLE:REMOTE_TERMINAL: misleading text"
        );
        let terminal = Error::authenticated_remote(true, "REMOTE_RETRYABLE: misleading text");
        assert!(terminal.is(ErrorCode::RemoteTerminal));
        assert_eq!(
            terminal.to_string(),
            "REMOTE_TERMINAL:REMOTE_RETRYABLE: misleading text"
        );
        assert!(!terminal.requires_owner_stop());
    }
    #[test]
    fn source_composition_errors_keep_exact_identity_without_owner_stop() {
        for (wire, expected_kind) in [
            ("MODEL_SOURCE_ARITHMETIC", ErrorKind::ProtocolInvalid),
            ("MODEL_SOURCE_BUDGET", ErrorKind::Capacity),
            ("MODEL_SOURCE_CAP", ErrorKind::ProtocolInvalid),
            ("MODEL_SOURCE_CLAIM", ErrorKind::ProtocolInvalid),
            ("MODEL_SOURCE_CONFIG", ErrorKind::StaleContext),
            ("MODEL_SOURCE_COUNT", ErrorKind::ProtocolInvalid),
            ("MODEL_SOURCE_DERIVATION", ErrorKind::ProtocolInvalid),
            ("MODEL_SOURCE_EVIDENCE", ErrorKind::ProtocolInvalid),
            ("MODEL_SOURCE_GAIN", ErrorKind::PolicyRefusal),
            ("MODEL_SOURCE_IDENTITY", ErrorKind::IdentityConflict),
            (
                "MODEL_SOURCE_INSUFFICIENT_EVIDENCE",
                ErrorKind::PolicyRefusal,
            ),
            ("MODEL_SOURCE_MARKER", ErrorKind::ProtocolInvalid),
            ("MODEL_SOURCE_ORDER", ErrorKind::ProtocolInvalid),
            ("MODEL_SOURCE_PARENT", ErrorKind::StaleContext),
            ("MODEL_SOURCE_PROFILE", ErrorKind::StaleContext),
            ("MODEL_SOURCE_RECORD", ErrorKind::ProtocolInvalid),
            ("MODEL_SOURCE_RECORD_SIZE", ErrorKind::Capacity),
            ("MODEL_SOURCE_STATE", ErrorKind::ProtocolInvalid),
        ] {
            let code = ErrorCode::parse(wire).expect("registered source-composition error");
            let error = Error::from(wire);
            assert_eq!(error.code(), Some(code), "{wire}");
            assert_eq!(error.kind(), expected_kind, "{wire}");
            assert_eq!(error.to_string(), wire);
            assert!(!error.requires_owner_stop(), "{wire}");
            let quoted = Error::from(format!("{wire}: quoted diagnostic"));
            assert_eq!(quoted.code(), None);
            assert_eq!(quoted.kind(), ErrorKind::Unclassified);
            assert!(!quoted.requires_owner_stop());
        }
    }
}
