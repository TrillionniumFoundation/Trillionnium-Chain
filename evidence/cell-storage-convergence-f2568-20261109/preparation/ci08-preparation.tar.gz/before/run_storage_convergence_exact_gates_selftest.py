#!/usr/bin/env python3
"""Fabricated parser inputs only: never execute Runner, Cargo, or Rust."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNNER = ROOT / "run_storage_convergence_exact_gates.py"
spec = importlib.util.spec_from_file_location("storage_exact", RUNNER)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
checks = []


def check(name, fn):
    fn()
    checks.append(name)


def refused(fn):
    try:
        fn()
    except m.GateError:
        return
    raise AssertionError("invalid synthetic input accepted")


def fixture():
    result = {}
    for label, groups in m.REQUIRED_NEW_TESTS.items():
        names = sorted(n for group in groups.values() for n in group)
        names.append("cell::retained::synthetic_prior_case" if label == "complete-da-native"
                     else "store::storage_service::tests::synthetic_prior_case")
        harnesses = [{"passed": len(names), "filtered_out": 0 if label == "complete-da-native" else 137,
                      "test_names": names}]
        if label == "complete-da-native":
            harnesses[0]["test_names"].append(m.PROCESS_DEATH_PARENT)
            harnesses[0]["passed"] += 1
            harnesses += [{"passed": 0, "filtered_out": 0, "test_names": []},
                          {"passed": 2, "filtered_out": 0,
                           "test_names": ["src/cell.rs - cell::Fixture (line 4)",
                                          "src/cell.rs - cell::Fixture (line 9) - compile fail"]}]
        result[label] = {"total_passed": sum(h["passed"] for h in harnesses),
                         "harnesses": harnesses, "new_test_roster": copy.deepcopy(groups)}
    return result


def render(rows):
    lines = []
    for h in rows:
        lines.append(f"running {len(h['test_names'])} tests")
        lines.extend(f"test {name} ... ok" for name in h["test_names"])
        lines.append(f"test result: ok. {h['passed']} passed; 0 failed; 0 ignored; 0 measured; "
                     f"{h['filtered_out']} filtered out; finished in 0.01s")
    return "\n".join(lines) + "\n"


def bad_config(change):
    e = fixture()
    change(e)
    refused(lambda: m.validate_native_expectations(e))


def bad_output(change, label="complete-da-native"):
    e = fixture()[label]
    refused(lambda: m.exact_native_execution(change(render(e["harnesses"])), e, label))


def valid():
    for label, e in m.validate_native_expectations(fixture()).items():
        actual = m.exact_native_execution(render(e["harnesses"]), e, label)
        assert actual["total_passed"] == e["total_passed"]
        assert actual["harnesses"] == e["harnesses"]
    assert sum(map(len, m.REQUIRED_NEW_TESTS["complete-da-native"].values())) == 65
    assert sum(map(len, m.REQUIRED_NEW_TESTS["node-storage-owner-native"].values())) == 9


def absent_new_case():
    def change(e):
        x = e["complete-da-native"]
        x["harnesses"][0]["test_names"].pop(0)
        x["harnesses"][0]["passed"] -= 1
        x["total_passed"] -= 1
    bad_config(change)


def duplicate_residency():
    def change(e):
        roster = e["complete-da-native"]["new_test_roster"]
        names = [n for n in roster["version_retention"] if "::residency::" in n]
        assert len(names) == 3
        roster["duplicate_residency"] = names
    bad_config(change)


check("valid complete DA/Node fixtures, empty binary and spaced doc names", valid)
check("missing mandatory group rejects", lambda: bad_config(lambda e: e["complete-da-native"]["new_test_roster"].pop("snapshot")))
check("missing new name rejects even if harness contains it", lambda: bad_config(lambda e: e["complete-da-native"]["new_test_roster"]["snapshot"].pop()))
check("new name absent from full frozen roster rejects", absent_new_case)
check("TCA3 residency cannot be counted twice", duplicate_residency)
check("zero expected total rejects", lambda: bad_config(lambda e: e["complete-da-native"].update(total_passed=0)))
check("DA cannot expect a filtered harness", lambda: bad_config(lambda e: e["complete-da-native"]["harnesses"][0].update(filtered_out=1)))
check("frozen count must equal full roster length", lambda: bad_config(lambda e: e["complete-da-native"]["harnesses"][0].update(passed=999)))
check("frozen total must equal harness counts", lambda: bad_config(lambda e: e["complete-da-native"].update(total_passed=999)))
check("Node cannot omit a new funding case", lambda: bad_config(lambda e: e["node-storage-owner-native"]["new_test_roster"]["shard"].pop()))
check("empty compile-only output is not runtime", lambda: bad_output(lambda _: ""))
empty = "running 0 tests\ntest result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s\n"
check("zero actual native execution rejects", lambda: bad_output(lambda _: empty))
check("missing case with unchanged summary rejects", lambda: bad_output(lambda t: t.replace("test cell::retained::synthetic_prior_case ... ok\n", "")))
check("same count with substituted retained name rejects", lambda: bad_output(lambda t: t.replace("cell::retained::synthetic_prior_case", "cell::retained::different_case")))
check("same count with substituted new name rejects", lambda: bad_output(lambda t: t.replace(m.REQUIRED_NEW_TESTS["complete-da-native"]["snapshot"][0], "cell::snapshot_schedule::tests::substitute")))
check("ignored case is not pass", lambda: bad_output(lambda t: t.replace(" ... ok", " ... ignored", 1)))
check("ignored summary is not pass", lambda: bad_output(lambda t: t.replace("0 ignored", "1 ignored", 1)))
check("failed case is not pass", lambda: bad_output(lambda t: t.replace(" ... ok", " ... FAILED", 1)))
check("missing harness rejects", lambda: bad_output(lambda t: t.replace(empty, "")))
check("extra empty harness rejects", lambda: bad_output(lambda t: t + empty))
check("unfinished harness rejects", lambda: bad_output(lambda t: t + "running 1 test\n"))
check("unexpected Node filtered count rejects", lambda: bad_output(lambda t: t.replace("137 filtered out", "136 filtered out"), "node-storage-owner-native"))
check("duplicate JSON configuration keys reject", lambda: refused(lambda: m.json_load(b'{"sha":"a","sha":"b"}')))

def actual_child_form():
    original = json.loads((ROOT / "storage-convergence-process-death-observation.json").read_bytes())
    at = original["lines"].index(m.PROCESS_DEATH_LINES[0])
    assert tuple(original["lines"][at:at + 3]) == m.PROCESS_DEATH_LINES
    e = fixture()["complete-da-native"]
    normal = "test " + m.PROCESS_DEATH_PARENT + " ... ok\n"
    observed = "\n".join(m.PROCESS_DEATH_LINES) + "\n"
    text = render(e["harnesses"]).replace(normal, observed)
    result = m.exact_native_execution(text, e, "complete-da-native")
    assert result["total_passed"] == e["total_passed"]
    assert len(result["nested_child_observations"]) == 1
    assert result["nested_child_observations"][0]["child_independent_results_counted"] == 0
    assert result["harnesses"][0]["test_names"].count(m.PROCESS_DEATH_PARENT) == 1
    for name, bad in (
        ("nested child under wrong parent rejects", observed.replace(m.PROCESS_DEATH_PARENT, "cell::retention::tests::wrong_parent")),
        ("duplicate nested child observation rejects", observed + observed),
        ("missing parent completion ok rejects", observed.replace("\nok\n", "\n")),
        ("unobserved blank-line variant rejects", observed.replace("\nrunning 1 test", "\n\nrunning 1 test")),
        ("different child test-count banner rejects", observed.replace("running 1 test", "running 2 tests")),
    ):
        refused(lambda bad=bad: m.exact_native_execution(text.replace(observed, bad), e, "complete-da-native"))
        checks.append(name)

check("actual retained process-death form counts parent once and child zero", actual_child_form)
check("standalone ok outside the exact retained form rejects", lambda: bad_output(lambda t: t + "ok\n"))

print(json.dumps({"schema": "storage-convergence-exact-runner-synthetic-selftest-v1", "passed": True,
                  "runner_executed": False, "native_commands_executed": 0,
                  "fabricated_harness_text_is_native_evidence": False,
                  "runner_sha256": hashlib.sha256(RUNNER.read_bytes()).hexdigest(),
                  "observed_process_death_excerpt_sha256": hashlib.sha256((ROOT / "storage-convergence-process-death-observation.json").read_bytes()).hexdigest(),
                  "previous_runner_sha256_unchanged": hashlib.sha256((ROOT / "run_exact_gates_previous.py").read_bytes()).hexdigest(),
                  "checks": checks}, indent=2))
