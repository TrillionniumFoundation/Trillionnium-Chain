"""Capture the requested committed-source checks without editing source bytes."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path("/workspace/scratch/1790ff0f3cc3/chain")
OUT = Path(__file__).resolve().parent
HEAD = "d992451cc8bfb3d69a1c9f1906bee6732255fad6"
TREE = "e5bfe7c1dabdae738173e0f6699cfaa3960cbbaf"
FILES = {
    "formal/pon-nakamoto-v1/ghostdag_order_reference.py": "63f4ae8fcb6916c440e11eb883af1f14f2dab35939d0821d3ecc0c0953e1e1a7",
    "formal/pon-nakamoto-v1/test_ghostdag_order_reference.py": "0545c1d2be0e0a1855d947b58131de8e81524ca45ed9097eabc0406c9d331156",
    "formal/pon-nakamoto-v1/experiments/ghostdag_order_campaign.py": "dde0099a14f5c9c477575bc68b7e8ba9a485c9ce9c7246bab3cbd5937851ed17",
}


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT).strip()


def snapshot():
    hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in FILES}
    committed_hashes = {name: hashlib.sha256(subprocess.check_output(
        ["git", "show", HEAD + ":" + name], cwd=ROOT)).hexdigest() for name in FILES}
    return {"observed_at_utc": timestamp(), "head": git("rev-parse", "HEAD").decode(),
            "tree": git("rev-parse", "HEAD^{tree}").decode(),
            "source_sha256": hashes, "committed_source_sha256": committed_hashes}


def validate_snapshot(value):
    if (value["head"] != HEAD or value["tree"] != TREE or value["source_sha256"] != FILES
            or value["committed_source_sha256"] != FILES):
        raise ValueError("FROZEN_SOURCE_MISMATCH")


def run_step(name, command, timeout=300):
    start, clock = timestamp(), time.monotonic()
    stdout_path, stderr_path = OUT / (name + ".stdout.log"), OUT / (name + ".stderr.log")
    error = None
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        try:
            completed = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr,
                                       timeout=timeout, check=False)
            code = completed.returncode
        except subprocess.TimeoutExpired:
            code, error = 124, "TIMEOUT"
    result = {"name": name, "command": command, "cwd": str(ROOT), "started_at_utc": start,
              "ended_at_utc": timestamp(), "wall_seconds": time.monotonic() - clock,
              "exit_code": code, "error": error, "stdout_path": str(stdout_path),
              "stderr_path": str(stderr_path),
              "stdout_sha256": hashlib.sha256(stdout_path.read_bytes()).hexdigest(),
              "stderr_sha256": hashlib.sha256(stderr_path.read_bytes()).hexdigest()}
    with (OUT / (name + ".result.json")).open("x") as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"step": name, "exit_code": code, "wall_seconds": result["wall_seconds"]}), flush=True)
    return result


def main():
    before = snapshot()
    validate_snapshot(before)
    steps = [run_step("preflight", ["bash", "scripts/project-preflight.sh"])]
    if steps[-1]["exit_code"]:
        raise RuntimeError("PREFLIGHT_FAILED")
    steps.append(run_step("tests", ["python3", "formal/pon-nakamoto-v1/test_ghostdag_order_reference.py"]))
    receipt = OUT / "ghostdag-order-max6.json"
    steps.append(run_step("campaign", ["python3", "formal/pon-nakamoto-v1/experiments/ghostdag_order_campaign.py",
                                       "--max-blocks", "6", "--output", str(receipt)]))
    if steps[-1]["exit_code"] == 0:
        report = json.loads(receipt.read_bytes())
        if report["source"]["git_head"] != HEAD or report["source"]["source_sha256"] != FILES:
            raise ValueError("RECEIPT_SOURCE_MISMATCH")
        if report["source"]["all_source_files_committed_at_head"] is not True:
            raise ValueError("RECEIPT_SOURCE_UNCOMMITTED")
        steps.append(run_step("replay", ["python3", "formal/pon-nakamoto-v1/experiments/ghostdag_order_campaign.py",
                                         "--replay", str(receipt)]))
    after = snapshot()
    validate_snapshot(after)
    passed = len(steps) == 4 and all(step["exit_code"] == 0 for step in steps)
    result = {"schema": "trnm-ghostdag-integrated-command-evidence-v1", "result": "PASS" if passed else "FAIL",
              "before": before, "after": after, "steps": steps,
              "environment": {"python": sys.version, "platform": platform.platform()},
              "receipt_path": str(receipt),
              "scope": "committed-source finite ordering equivalence and exact replay; command timing is not a throughput benchmark",
              "security_theorem": False, "production_activation": False}
    with (OUT / "run-summary.json").open("x") as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write("\n")
    print(json.dumps({"result": result["result"], "summary": str(OUT / "run-summary.json")}), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
