#!/usr/bin/env python3
"""Small owned-process probes; never start a provider or Clippy build."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time

ROOT = Path('/workspace/scratch/0776da4af99b')
OUT = ROOT / 'cloud-clippy-bounded-6e39f273'
PREFIX = ROOT / 'cloud-rust-validation-6e39f273/toolchain'


def sha(path):
    b = path.read_bytes()
    return {'path': str(path), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def members(group):
    rows = []
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit():
            continue
        try:
            text = (directory / 'stat').read_text()
            fields = text[text.rfind(')') + 2:].split()
            if int(fields[2]) != group:
                continue
            status = (directory / 'status').read_text().splitlines()
            rss = next((int(line.split()[1]) * 1024 for line in status if line.startswith('VmRSS:')), 0)
            rows.append({'pid': int(directory.name), 'group': int(fields[2]),
                         'session': int(fields[3]), 'state': fields[0], 'rss_bytes': rss})
        except FileNotFoundError:
            pass
    return rows


def command(label, argv, as_limit, monitor_threshold=None):
    started = datetime.now(timezone.utc).isoformat()
    begin = time.monotonic()
    output = OUT / (label + '.stdout.log')
    error = OUT / (label + '.stderr.log')
    rows = []
    reason = None
    def cap():
        resource.setrlimit(resource.RLIMIT_AS, (as_limit, as_limit))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_FSIZE, (1024**2, 1024**2))
    with output.open('xb') as stdout, error.open('xb') as stderr:
        p = subprocess.Popen(argv, stdout=stdout, stderr=stderr, stdin=subprocess.DEVNULL,
                             start_new_session=True, preexec_fn=cap)
        while p.poll() is None:
            group = members(p.pid)
            rows.append({'elapsed_seconds': time.monotonic() - begin, 'members': group,
                         'rss_bytes': sum(row['rss_bytes'] for row in group)})
            if monitor_threshold is not None and rows[-1]['rss_bytes'] > monitor_threshold:
                reason = 'owned_process_group_rss_limit'
                os.killpg(p.pid, signal.SIGKILL)
                break
            if time.monotonic() - begin > 10:
                reason = 'probe_wall_timeout'
                os.killpg(p.pid, signal.SIGKILL)
                break
            time.sleep(0.02)
        code = p.wait(timeout=5)
    remaining = [row for row in members(p.pid) if row['state'] != 'Z']
    receipt = {'label': label, 'argv': argv, 'started_utc': started,
               'elapsed_seconds': time.monotonic() - begin, 'exit_code': code,
               'hard_per_process_virtual_address_bytes': as_limit,
               'group_rss_monitor_limit_bytes': monitor_threshold,
               'hard_group_physical_memory_limit': False,
               'stop_reason': reason, 'samples': rows,
               'remaining_live_group_members': remaining,
               'stdout': sha(output), 'stderr': sha(error)}
    with (OUT / (label + '.receipt.json')).open('x') as f:
        json.dump(receipt, f, indent=2, sort_keys=True)
        f.write('\n')
    print(json.dumps({key: receipt[key] for key in ['label', 'exit_code', 'stop_reason',
                                                   'remaining_live_group_members']}), flush=True)
    return receipt


def main():
    OUT.mkdir()
    virtual = command('virtual-limit-probe', ['/usr/bin/python3', '-c',
        "import json,resource\ntry:\n b=bytearray(128*1024*1024)\n print(json.dumps({'allocation_refused':False}))\nexcept MemoryError:\n print(json.dumps({'allocation_refused':True,'rlimit_as':resource.getrlimit(resource.RLIMIT_AS)}))"], 96 * 1024**2)
    observed = json.loads((OUT / 'virtual-limit-probe.stdout.log').read_text())
    virtual_verified = virtual['exit_code'] == 0 and observed.get('allocation_refused') is True
    monitored = command('group-rss-probe', ['/usr/bin/python3', '-c',
        "import subprocess,time,os,json\np=subprocess.Popen(['/usr/bin/python3','-c','import time; b=bytearray(16*1024*1024); time.sleep(5)'])\nprint(json.dumps({'leader':os.getpid(),'child':p.pid,'group':os.getpgrp()}),flush=True)\ntime.sleep(5)"],
        96 * 1024**2, 24 * 1024**2)
    monitor_verified = (monitored['stop_reason'] == 'owned_process_group_rss_limit'
                        and monitored['exit_code'] == -signal.SIGKILL
                        and not monitored['remaining_live_group_members']
                        and any(len(row['members']) >= 2 for row in monitored['samples']))
    startups = []
    if virtual_verified and monitor_verified:
        for label, program in [('rustc-startup', 'rustc'), ('clippy-startup', 'cargo-clippy')]:
            startups.append(command(label, [str(PREFIX / 'bin' / program), '--version'],
                                    1536 * 1024**2, 1536 * 1024**2))
    mem = {line.split(':')[0]: line.split(':')[1].strip()
           for line in Path('/proc/meminfo').read_text().splitlines()
           if line.split(':')[0] in ['MemAvailable', 'SwapTotal', 'SwapFree']}
    report = {'schema': 'trnm-cloud-resource-capabilities-v1',
              'cgroup_memory_max_available': False,
              'hard_per_process_virtual_address_limit_verified': virtual_verified,
              'owned_group_rss_monitor_and_kill_verified': monitor_verified,
              'same_budget_compiler_startup_succeeded': len(startups) == 2
                  and all(item['exit_code'] == 0 for item in startups),
              'hard_group_physical_memory_limit': False,
              'memory': mem, 'native_build_executed': False,
              'provider_executed': False, 'strict_clippy_gate_executed': False,
              'runner': sha(Path(__file__)),
              'boundary': 'Per-process address limits are kernel-enforced; group RSS is a measured watchdog, not a kernel aggregate-memory guarantee.'}
    with (OUT / 'capabilities.json').open('x') as f:
        json.dump(report, f, indent=2, sort_keys=True)
        f.write('\n')
    print(json.dumps(report, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
