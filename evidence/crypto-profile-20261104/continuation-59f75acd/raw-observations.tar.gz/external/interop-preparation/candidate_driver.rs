//! Bounded external observation driver; links the exact built candidate library.
//! The fixed seeds below are public test material, never production identities.
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::Path;
use std::process::ExitCode;
use trnm_crypto_primitives::pq_candidate::{
    CandidateAlgorithm, CandidateError, CandidateSigningKey, CandidateVerifier,
};
use zeroize::Zeroizing;

fn algorithm(name: &str) -> Result<CandidateAlgorithm, String> {
    match name {
        "65" => Ok(CandidateAlgorithm::MlDsa65),
        "87" => Ok(CandidateAlgorithm::MlDsa87),
        _ => Err("only explicit candidate 65 or 87 is accepted".into()),
    }
}

fn read(path: &str, max: usize) -> Result<Vec<u8>, String> {
    let p = Path::new(path);
    let metadata = fs::metadata(p).map_err(|e| e.to_string())?;
    if !metadata.is_file() || metadata.len() > max as u64 {
        return Err("fixture file is not bounded regular input".into());
    }
    let bytes = fs::read(p).map_err(|e| e.to_string())?;
    if bytes.len() > max {
        return Err("fixture size changed beyond bound".into());
    }
    Ok(bytes)
}

fn write_new(path: &str, bytes: &[u8]) -> Result<(), String> {
    OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .and_then(|mut file| file.write_all(bytes))
        .map_err(|e| e.to_string())
}

fn run(args: &[String]) -> Result<u8, String> {
    match args.get(1).map(String::as_str) {
        Some("emit") if args.len() == 8 => {
            if args[7] != "public-fixture-only" {
                return Err("missing fixture-only declaration".into());
            }
            let algorithm = algorithm(&args[2])?;
            let seed_tag: u8 = args[3].parse().map_err(|_| "invalid public fixture tag")?;
            if !matches!(seed_tag, 66 | 67) {
                return Err("only documented public test seeds 0x42 and 0x43 are allowed".into());
            }
            let message = read(&args[4], 65_536)?;
            let signer = CandidateSigningKey::from_owned_seed(
                algorithm,
                Zeroizing::new([seed_tag; 32]),
            )
            .map_err(|e| e.to_string())?;
            let signature = signer.sign(&message).map_err(|e| e.to_string())?;
            write_new(&args[5], signer.public_key())?;
            write_new(&args[6], &signature)?;
            println!(
                "EMIT {} message={} public_key={} signature={}",
                algorithm.name(),
                message.len(),
                signer.public_key().len(),
                signature.len()
            );
            Ok(0)
        }
        Some("verify") if args.len() == 6 => {
            let algorithm = algorithm(&args[2])?;
            let message = read(&args[3], 65_536)?;
            let key = read(&args[4], algorithm.public_key_bytes())?;
            let signature = read(&args[5], algorithm.signature_bytes())?;
            let verifier = CandidateVerifier::from_pinned_raw(algorithm, &key)
                .map_err(|e| format!("key setup failed: {e:?}"))?;
            match verifier.verify(&message, &signature) {
                Ok(()) => {
                    println!("ACCEPT");
                    Ok(0)
                }
                Err(CandidateError::SignatureRejected) => {
                    println!("REJECT_SIGNATURE");
                    Ok(3)
                }
                Err(error) => {
                    eprintln!("NON_MATHEMATICAL_REJECTION: {error:?}");
                    Ok(4)
                }
            }
        }
        _ => Err("usage: emit 65|87 66|67 message public-key signature public-fixture-only; verify 65|87 message public-key signature".into()),
    }
}

fn main() -> ExitCode {
    match run(&std::env::args().collect::<Vec<_>>()) {
        Ok(code) => ExitCode::from(code),
        Err(error) => {
            eprintln!("HARNESS_ERROR: {error}");
            ExitCode::from(5)
        }
    }
}
