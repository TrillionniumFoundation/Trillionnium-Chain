from pathlib import Path
import json,hashlib,re,subprocess,sys,difflib
base=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');src=base/'source';out=base/'ci-inline-pin-audit-36';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip();assert head=='e8b0ec93ab6a6a1ff5e36cfcf9d1179e030a5975'
entries=subprocess.check_output(['git','ls-tree','-rz',head],cwd=src).split(b'\0');tracked={}
for entry in entries:
 if entry:
  a,b=entry.split(b'\t',1);mode,kind,oid=a.decode().split();tracked[b.decode()]={'mode':mode,'kind':kind,'oid':oid}
pattern=re.compile(r'test "\$\(git hash-object ([A-Za-z0-9_./-]+)\)" = ([0-9a-f]{40})')
rows=[];patches=[];changed=[]
for workflow in sorted((src/'.github/workflows').glob('*.yml')):
 old=workflow.read_text();new=old
 for n,line in enumerate(old.splitlines(),1):
  line=line.strip()
  if line.startswith('#') or 'git hash-object' not in line:continue
  match=pattern.fullmatch(line);assert match
  path,expected=match.groups();p=src/path;assert p.is_file() and not p.is_symlink();raw=p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();entry=tracked[path]
  row={'workflow':str(workflow.relative_to(src)),'line':n,'source':path,'expected':expected,'current_blob':actual,'frozen_head_blob':entry['oid'],'source_sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'mode':entry['mode']};rows.append(row)
  if expected!=actual:
   assert actual==entry['oid'],'defer experimental source pin until decision: '+path
   row['repair_scope']='same current path, literal updated to independently verified frozen #970 Git blob'
   assert old.count(line)==1;new=new.replace(line,line[:-40]+actual)
 if new!=old:
  name=workflow.name;(out/(name+'.original')).write_text(old);(out/(name+'.candidate')).write_text(new)
  changed.append({'path':str(workflow.relative_to(src)),'original_sha256':hashlib.sha256(old.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(new.encode()).hexdigest()})
  patches.append(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+str(workflow.relative_to(src)),tofile='b/'+str(workflow.relative_to(src)))))
(out/'all-current-inline-pins.json').write_text(json.dumps({'head':head,'original_reader_sha256':hashlib.sha256((src/'scripts/ci/check_ci_contract.py').read_bytes()).hexdigest(),'rows':rows,'scope_changed':False,'reader_changed':False,'qualification_granted':False},indent=2)+'\n');(out/'source.patch').write_text(''.join(patches));result={'count':len(rows),'mismatches':[r for r in rows if r['expected']!=r['current_blob']],'changed_workflows':changed,'patch_sha256':hashlib.sha256((out/'source.patch').read_bytes()).hexdigest(),'patch_bytes':(out/'source.patch').stat().st_size,'working_source_edited':False};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
