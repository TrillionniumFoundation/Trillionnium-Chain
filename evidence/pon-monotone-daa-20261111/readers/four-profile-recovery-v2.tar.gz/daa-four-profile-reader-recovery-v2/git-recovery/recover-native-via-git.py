#!/usr/bin/env python3
"""Read one already-published evidence commit; preserve the frozen checkout."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
import traceback

ROOT = Path('/workspace/scratch/7f73fe002713')
SOURCE = ROOT / 'chain-daa'
OUT = ROOT / 'daa-native-git-recovery-v1'
DEST = ROOT / 'daa-native-archive-recovery-v1/native-run-d23488c5-v1.tar.gz'
BASE = 'd23488c5f9b4a6696c3799b12f14b8af0a1b81fc'
BRANCH = 'fix/chain-daa-monotone-witness-20261111-7f73'
PREFIX = 'evidence/pon-monotone-daa-20261111/'
EXPECTED_SHA = '6c33da56842862608e365acb7c69d72175538556a2a76b74254f7b0357de9c81'
COMMANDS = []


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def run(label, argv, binary=False):
    start = time.monotonic()
    result = subprocess.run(argv, cwd=SOURCE, capture_output=True, timeout=300, check=False)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    row = {'label': label, 'argv': argv, 'cwd': str(SOURCE), 'returncode': result.returncode,
           'elapsed_seconds': time.monotonic() - start,
           'stdout_bytes': len(result.stdout), 'stderr_bytes': len(result.stderr),
           'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
           'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
    COMMANDS.append(row)
    write(OUT / 'commands.json', COMMANDS)
    assert result.returncode == 0, label
    return result.stdout if binary else result.stdout.decode().strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--publication-commit', required=True)
    args = parser.parse_args()
    assert re.fullmatch('[0-9a-f]{40}', args.publication_commit)
    OUT.mkdir(mode=0o700, exist_ok=False)
    record = {'schema': 'pon-native-archive-git-readback-v1', 'result': 'FAIL',
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'publication_commit': args.publication_commit, 'frozen_source_commit': BASE,
              'checkout_performed': False, 'native_or_reader_execution_performed': False}
    try:
        assert run('head-before', ['git', 'rev-parse', 'HEAD']) == BASE
        assert run('status-before', ['git', 'status', '--porcelain', '--untracked-files=no']) == ''
        run('fetch', ['git', 'fetch', '--no-tags', 'origin', 'refs/heads/' + BRANCH])
        assert run('fetched-head', ['git', 'rev-parse', 'FETCH_HEAD']) == args.publication_commit
        run('ancestry', ['git', 'merge-base', '--is-ancestor', BASE, args.publication_commit])
        paths = run('changed-paths', ['git', 'diff', '--name-only', BASE, args.publication_commit]).splitlines()
        assert paths and all(path.startswith(PREFIX) for path in paths), paths
        record['evidence_only_changed_paths'] = paths
        record['native_archive_git_blob'] = run('native-blob-id', ['git', 'rev-parse', args.publication_commit + ':' + PREFIX + 'native/native-run-d23488c5-v1.tar.gz'])
        record['native_archive_git_path'] = PREFIX + 'native/native-run-d23488c5-v1.tar.gz'
        data = run('native-archive', ['git', 'show', args.publication_commit + ':' + PREFIX + 'native/native-run-d23488c5-v1.tar.gz'], binary=True)
        assert len(data) == 4657951
        assert hashlib.sha256(data).hexdigest() == EXPECTED_SHA
        descriptor_bytes = run('native-descriptor', ['git', 'show', args.publication_commit + ':' + PREFIX + 'native/native-run-d23488c5-v1-archive.json'], binary=True)
        assert len(descriptor_bytes) == 193
        assert hashlib.sha256(descriptor_bytes).hexdigest() == '74dbde813897144c0d220584eb1731c72ccd5f8ff597c0de85924b9eb7939a15'
        descriptor = json.loads(descriptor_bytes)
        assert descriptor['bytes'] == len(data) and descriptor['sha256'] == EXPECTED_SHA
        record['published_descriptor'] = descriptor
        chunk_dir = DEST.parent / 'chunks'
        receipts = json.loads((DEST.parent / 'transfer.json').read_text())
        record['partial_rpc_transfer_status'] = receipts.get('status')
        verified = []
        for path in sorted(chunk_dir.glob('*')):
            if not path.is_file():
                continue
            assert re.fullmatch(r'\d{10}', path.stem), path
            offset = int(path.stem)
            raw = path.read_bytes()
            # The transfer receipt, rather than a guessed filename convention,
            # identifies the exact byte range for every retained partial chunk.
            rows = receipts['chunks'].values() if isinstance(receipts['chunks'], dict) else receipts['chunks']
            candidates = [row for row in rows if row['offset'] == offset]
            assert len(candidates) == 1, str(path)
            row = candidates[0]
            assert row['bytes'] == len(raw) and row['sha256'] == hashlib.sha256(raw).hexdigest()
            assert data[offset:offset + len(raw)] == raw, str(path)
            verified.append({'offset': offset, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
        record['retained_rpc_chunks_match_git_bytes'] = verified
        record['retained_rpc_chunk_count'] = len(verified)
        if DEST.exists():
            assert DEST.read_bytes() == data
            record['destination_already_identical'] = True
        else:
            with DEST.open('xb') as handle:
                handle.write(data)
            record['destination_created'] = True
        assert run('head-after', ['git', 'rev-parse', 'HEAD']) == BASE
        assert run('status-after', ['git', 'status', '--porcelain', '--untracked-files=no']) == ''
        record.update(result='PASS', archive_path=str(DEST), archive_bytes=len(data), archive_sha256=EXPECTED_SHA)
    except BaseException:
        record['error'] = traceback.format_exc()
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write(OUT / 'result.json', record)
    print(json.dumps(record, indent=2))
    return 0 if record['result'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
