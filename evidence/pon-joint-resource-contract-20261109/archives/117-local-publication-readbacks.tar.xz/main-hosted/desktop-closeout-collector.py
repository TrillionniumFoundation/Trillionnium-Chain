
import hashlib,io,json,os,pathlib,stat,subprocess,tarfile,time
ROOT=pathlib.Path("/home/qian-qi/work")
OUT=ROOT/"pon-joint-58fd59-11791e2d-closeout"
COLL=ROOT/"pon-joint-58fd59-11791e2d-main-hosted-collection"
ARCHIVE=ROOT/"pon-joint-58fd59-11791e2d-publication-main-receipts.tar.xz"
HEAD="11791e2da79b69322271be2cffe03725165151d1"
REPO="TrillionniumFoundation/Trillionnium-Chain"
if OUT.exists() or ARCHIVE.exists(): raise SystemExit("closeout exists; reconcile original durable job")
OUT.mkdir(mode=0o700)
ENV=dict(os.environ);ENV["GH_PROMPT_DISABLED"]="1"
MONITOR=json.loads("{\"job_id\":\"1a1be416f60-514c-6\",\"host\":\"desktop\",\"scope\":\"Only our read-only monitoring process was stopped; no GitHub workflow was cancelled or retried.\",\"pre_status\":{\"audit_recorded\":true,\"backend\":\"systemd\",\"job_id\":\"1a1be416f60-514c-6\",\"state\":\"running\",\"systemd\":{\"ActiveState\":\"active\",\"Description\":\"Hepta Runtime job 1a1be416f60-514c-6 9f13251f17e49858433da8a015bd56ec\",\"ExecMainCode\":\"0\",\"ExecMainPID\":\"3221843\",\"ExecMainStatus\":\"0\",\"InvocationID\":\"90675bc57b714a929e4fe0d72812b39a\",\"LoadState\":\"loaded\",\"Result\":\"success\",\"SubState\":\"running\"}},\"cancel_request\":{\"atomic_identity\":true,\"audit_recorded\":true,\"automatic_retry\":false,\"job_id\":\"1a1be416f60-514c-6\",\"reconcile_via\":\"process_status\",\"result\":\"stop_requested\",\"supervisor_pid\":3221843,\"termination_confirmed\":false},\"post_status\":{\"at_unix_ms\":1794196488140,\"audit_recorded\":true,\"automatic_retry\":false,\"cancelled\":true,\"exit_code\":-15,\"job_id\":\"1a1be416f60-514c-6\",\"launch_nonce\":\"9f13251f17e49858433da8a015bd56ec\",\"log_bytes\":{\"stderr\":{\"seen\":0,\"stored\":0},\"stdout\":{\"seen\":47773,\"stored\":47773}},\"log_errors\":{\"stderr\":null,\"stdout\":null},\"log_synced\":{\"stderr\":true,\"stdout\":true},\"log_truncated\":{\"stderr\":false,\"stdout\":false},\"output_complete\":true,\"output_durable\":true,\"state\":\"cancelled\",\"terminal_publication_confirmed\":true,\"terminal_publication_protocol\":1,\"timed_out\":false}}")
(OUT/"monitor-stop-receipt.json").write_text(json.dumps(MONITOR,indent=2)+"\n")
def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for data in iter(lambda:f.read(1048576),b""):h.update(data)
    return h.hexdigest()
def get(label,path):
    argv=["/usr/bin/gh","api","--hostname","github.com",path]
    rec={"argv":argv,"started_unix_ns":time.time_ns(),"github_method":"GET"}
    p=subprocess.run(argv,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
    rec["exit_code"]=p.returncode;rec["finished_unix_ns"]=time.time_ns()
    for key,data in [("stdout",p.stdout),("stderr",p.stderr)]:
        f=OUT/(label+"."+key);f.write_bytes(data)
        rec[key]={"path":str(f),"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}
    (OUT/(label+".command.json")).write_text(json.dumps(rec,indent=2)+"\n")
    if p.returncode:raise RuntimeError(label+" read failed")
    return json.loads(p.stdout)
login=get("authenticated-user","user")
if login.get("login")!="ProfHepta":raise RuntimeError("unexpected authenticated identity")
pr=get("pr827","repos/"+REPO+"/pulls/827")
if pr["head"]["sha"]!=HEAD or pr.get("draft") is not True:raise RuntimeError("implementation PR identity changed")
runs=[]
for page in range(1,11):
    batch=get("head-workflows-"+str(page),"repos/"+REPO+"/actions/runs?head_sha="+HEAD+"&per_page=100&page="+str(page))
    runs.extend(batch["workflow_runs"])
    if len(batch["workflow_runs"])<100:break
else:raise RuntimeError("head run pagination incomplete")
selected=[]
for run_id in [42553751914,42553751985,42553751938,42553751987]:
    value=get("run-"+str(run_id),"repos/"+REPO+"/actions/runs/"+str(run_id))
    if value.get("head_sha")!=HEAD:raise RuntimeError("run identity changed")
    jobs=[]
    for page in range(1,11):
        batch=get("run-"+str(run_id)+"-jobs-"+str(page),"repos/"+REPO+"/actions/runs/"+str(run_id)+"/attempts/"+str(value["run_attempt"])+"/jobs?per_page=100&page="+str(page))
        jobs.extend(batch["jobs"])
        if len(batch["jobs"])<100:break
    else:raise RuntimeError("job pagination incomplete")
    entry={k:value.get(k) for k in ["id","name","path","head_sha","head_branch","event","status","conclusion","run_attempt","html_url","created_at","updated_at"]}
    entry["jobs"]=[{k:j.get(k) for k in ["id","name","status","conclusion","html_url","started_at","completed_at","runner_name","labels"]} for j in jobs]
    entry["jobs_reported"]=len(jobs)
    selected.append(entry)
snapshot={"schema":"pon-final-readonly-hosted-snapshot-v1","observed_unix_ns":time.time_ns(),"head":HEAD,"pr":827,"pr_draft":pr["draft"],"provider_actions_written":False,"monitor_stopped_only":MONITOR["post_status"].get("state")=="cancelled","all_head_workflows":[{k:r.get(k) for k in ["id","name","path","event","status","conclusion","head_sha","run_attempt","html_url"]} for r in runs],"selected_workflows":selected,"verdict":"HOLD_NO_GO"}
(OUT/"latest-hosted-ci-snapshot.json").write_text(json.dumps(snapshot,indent=2)+"\n")
publication=[
"pon-joint-58fd59-fc5c44ca-publication-preparation",
"pon-joint-58fd59-11791e2d-publication-preparation",
"pon-joint-58fd59-11791e2d-publication",
"pon-joint-58fd59-11791e2d-publication-recovery-01",
"pon-joint-58fd59-11791e2d-publication-update-01",
"pon-joint-58fd59-11791e2d-publication-update-rest-01"]
files=[];excluded=[]
def retain(path):
    if path.is_symlink() or not stat.S_ISREG(path.stat().st_mode):raise RuntimeError("nonregular receipt")
    files.append(path)
for name in publication:
    base=ROOT/name
    if not base.is_dir():raise RuntimeError("missing publication directory "+name)
    for path in sorted(base.rglob("*")):
        if not path.is_file():continue
        if path.suffix in [".bundle",".pack"]:excluded.append({"path":str(path),"reason":"duplicate Git object transport bytes"});continue
        retain(path)
for path in sorted(COLL.iterdir()):
    if path.is_file():retain(path)
for label in ["original-campaign","work-time-contract"]:
    base=COLL/label
    for path in sorted(base.iterdir()):
        if not path.is_file():continue
        if path.name=="complete-workflow-logs.zip" or path.suffix==".log":retain(path)
        else:excluded.append({"path":str(path),"reason":"full original artifact ZIP already independently retained locally and in evidence"})
MON=ROOT/"pon-joint-58fd59-11791e2d-hosted-observations"
for name in ["state.json","calls.jsonl"]:
    p=MON/name
    if p.is_file():retain(p)
snaps=sorted(MON.glob("snapshot-*.json"))
if snaps:retain(snaps[-1])
failed=ROOT/"pon-joint-58fd59-11791e2d-main-hosted-readback"
if failed.is_dir():
    for path in sorted(failed.iterdir()):
        if path.is_file() and path.stat().st_size<1048576:retain(path)
for path in sorted(OUT.iterdir()):
    if path.is_file():retain(path)
if len(files)!=len(set(files)):raise RuntimeError("duplicate file inventory")
rows=[{"member":str(path.relative_to(ROOT)),"desktop_path":str(path),"bytes":path.stat().st_size,"sha256":sha(path)} for path in files]
manifest={"schema":"pon-publication-main-readback-receipts-v1","created_unix_ns":time.time_ns(),"head":HEAD,"files":rows,"file_count":len(rows),"uncompressed_bytes":sum(x["bytes"] for x in rows),"exclusions":excluded,"scope":"Original ZIPs and their complete uncompressed members are retained separately. This package contains terminal publication successes and failures, complete original/work-time job and workflow logs, API metadata and a final hosted status snapshot. Source was not executed or modified."}
mp=OUT/"receipt-file-manifest.json";mp.write_text(json.dumps(manifest,indent=2)+"\n")
with tarfile.open(ARCHIVE,"x:xz",preset=6) as tar:
    for path in files+[mp]:tar.add(path,arcname=str(path.relative_to(ROOT)),recursive=False)
with tarfile.open(ARCHIVE,"r:xz") as tar:
    members=tar.getmembers()
    if len(members)!=len(files)+1:raise RuntimeError("archive member count mismatch")
    for row in rows:
        info=tar.getmember(row["member"]);f=tar.extractfile(info);h=hashlib.sha256();size=0
        while True:
            data=f.read(1048576)
            if not data:break
            size+=len(data);h.update(data)
        if size!=row["bytes"] or h.hexdigest()!=row["sha256"]:raise RuntimeError("archive member mismatch")
result={"complete":True,"archive":str(ARCHIVE),"bytes":ARCHIVE.stat().st_size,"sha256":sha(ARCHIVE),"members":len(files)+1,"manifest":str(mp),"snapshot":str(OUT/"latest-hosted-ci-snapshot.json"),"monitor_state":MONITOR["post_status"].get("state"),"monitor_exit":MONITOR["post_status"].get("exit_code"),"runs":[{"id":r["id"],"name":r["name"],"status":r["status"],"conclusion":r["conclusion"],"jobs":r["jobs_reported"]} for r in selected]}
(OUT/"archive-result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result),flush=True)
