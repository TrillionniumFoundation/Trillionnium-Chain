#!/usr/bin/env bash
set -euo pipefail
export RUST_TEST_THREADS="${RUST_TEST_THREADS:-1}"
# Exact original suffix; not a complete repository qualification.
    python3 scripts/ci/test_run_legacy_reorg_root_abba.py
    python3 -B scripts/ci/test_w1_factorial_native_gate.py
    python3 -B scripts/ci/test_prepare_artifact_upload.py
    python3 -B scripts/ci/test_cell_storage_convergence_ci.py
    python3 -B scripts/ci/test_fresh_rejection_report.py
    # These in-memory counterexamples use unchanged retained inputs, not a new hardware observation.
    python3 scripts/ci/test_pon_w1_budget_readers.py --raw-dir evidence/pon-upgrade-implementation-20261018/native-rounds/chain-p0-native-54
    python3 scripts/ci/test_pon_public_v3_phase_read.py
    python3 scripts/ci/test_pon_public_v3_policy_read.py
    python3 scripts/ci/test_pon_v3_cookie_cpu_study.py
    python3 scripts/ci/test_run_pon_w1_native_campaign.py
    python3 scripts/ci/test_read_validated_business_goodput.py
    python3 scripts/ci/test_read_failed_native_campaign_zip.py
    python3 scripts/ci/test_read_native_campaign_attempt.py
    python3 scripts/ci/test_pon_w1_cost_matrix_reader.py
    python3 scripts/ci/test_throughput_cost_coverage.py
    python3 scripts/ci/test_rust_source_tokens.py
    python3 scripts/ci/test_collected_unit_empty_v1.py
    python3 scripts/ci/test_collect_pinned_codeql_metadata_v1.py
    python3 scripts/ci/test_codeql_semantic_observations_v1.py
    python3 scripts/ci/test_pon_w1_reused_cost_reader_v3.py
    python3 scripts/ci/test_run_w1_reused_cost_v3.py
    python3 scripts/ci/test_w1_lifecycle_cost_v4.py
    python3 scripts/ci/test_llm_cell_handoff_deadline.py
    python3 scripts/test_llm_cell_release.py
    python3 scripts/ci/test_read_original_native_campaign.py \
      --artifact-dir evidence/pon-upgrade-implementation-20261018/native-rounds/chain-pr327-original-campaign-39694587963 \
      --expected-manifest-sha256 12406cc156e57c130fa14af2b50b386031ec3640ce7f0234ed5bc9f0a700aac3 \
      --expected-head 9e705ccf75b7318dcc4bda4815956f58beb10e72 \
      --expected-tree 521ae87a28060d545979069b189eebbc74a71fd8 --retained-subset
    python3 scripts/ci/test_account_archive_conformance.py
    python3 scripts/ci/test_run_account_execution_conformance.py
    python3 scripts/ci/report_current_implementation.py --check
    python3 scripts/ci/test_work_cost_report.py
    # Retained source and arithmetic controls remain mandatory research-only gates.
    python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_w1_quantum_evidence_scope.py' -v
    python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_w1_quantum_native_bridge.py' -v
    python3 scripts/ci/test_w1_risc0_deep_event_audit.py
    python3 scripts/w1_risc0_deep_event_audit.py --repo-root .
    python3 scripts/ci/test_w1_p3_sampling_audit.py
    python3 scripts/w1_p3_sampling_audit.py
    python3 scripts/ci/test_pq_lifetime_composition.py
    python3 scripts/ci/pq_lifetime_composition.py
    python3 scripts/ci/test_pq_content_chain_review.py
    python3 scripts/ci/pq_content_chain_review.py
    python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_fixed_success_query_frontier.py' -v
    python3 formal/pon-nakamoto-v1/fixed_success_query_frontier.py --check
    python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_cost_tail_transfer.py' -v
    python3 formal/pon-nakamoto-v1/cost_tail_transfer.py --check
    python3 formal/pon-nakamoto-v1/test_quantum_bernoulli_source_audit.py -v
    python3 scripts/ci/test_retained_research_ci.py
    python3 scripts/test_qualification_runtime.py
