## Why

The W1 continuation needed an observed, complete statement on a real
AIR/STARK backend and a same-host cost comparison. The selected-event
query argument also needed the actual hash dependency chain and legal
reuse costs before it could inform a qualification decision.

This draft is a research component for the existing C4 integration
candidate, based on `8df4b21d893906570d48f5beafabb3b31e0aefbc` and targeting
`fix/chain-joint-v12-c4-20261105-93bfc-frozen`. **Qualification remains
`HOLD_NO_GO`.** The sole development plan records the new observations and
preserves all eight open system gates.

## Changes and observed behavior

- Add an isolated, locked Plonky3 0.8.0 crate that proves the complete
  original W1 SHA relation and all arithmetic relations with two actual
  PCS/FRI proofs. The verifier derives both preprocessing keys from the
  public statement and independently supplied expected header/artifacts.
- Retain full proof bytes, exact statement/source/binary fingerprints,
  fresh-process clocks, resource receipts, 11 original negative controls
  and four typed late-FRI controls. Preserve earlier failures and source
  identities, including the corrected `CapMismatch` test-oracle label.
- Add the selected-event classical full-message-ROM composition theorem,
  including reverse digest-pointer hazards, lifetime row/query accounting,
  exact SHA prefix reuse, useful-product precomputation and a priced
  finite set of achievable strategies.

The final-source run generated both full proofs in **21.196110 s** outer
wall time. Three fresh full verifications had median **0.948204 s**. The
same-fixture frozen FullLimb comparator had warm-call median **1.913279 ms**;
these boundaries and the one-thread/eight-thread difference are explicit.
Statement plus both proof envelopes is **5,264,276 bytes**, **106.336121x**
the original 49,506-byte input. The current implementation shows **no
end-to-end benefit** on this measured path. The largest sampled ordinary
negative took **2.238433 s**; the largest typed late control **1.043657 s**.
Neither is a global adversarial cost bound.

The native baseline is a fresh execution of the frozen `e70f134...`
harness, not a current production-Node build. Its core FullLimb source
matches C4, while the complete 41-file comparison has 39 equal files, one
different file and one absent file. The original target-CPU logger caveat
and the actual native-flags build receipt are retained.

## Validation

- Final isolated crate: locked/offline metadata and build, formatting,
  strict all-target/all-feature Clippy (`-D warnings`), **18 library + 3
  actual small-proof integration tests**. The doc-test command passed with
  zero doc tests.
- Final complete W1 pair: **3 independent verifier processes**, **11
  original negatives** and **4 transcript-preserving late controls**,
  each requiring its specific outcome.
- Frozen native comparator: **143 library tests**, fixture conformance,
  and **9,900 measured calls** across three processes. Calls are not
  counted as additional test cases.
- Selected composition/cost model: **21 checks** with exact retained
  source/fixture hashes and a frozen manifest.

Repository structure, Markdown, source-integrity negatives and the final
commit's before/after identity fences are recorded in the delivery receipt
below. These focused checks are distinct from the complete repository CI
lanes and from production acceptance.

## Security and qualification limits

The concrete noninteractive security proof, PCS/hash/Fiat–Shamir lifetime
budgets, quantum security, global malicious receiver bound, universally
cheapest legal physical-work bound and production Node admission remain
open. The conditional per-component RBR estimate near 63.95 bits is not a
PQ128 or complete NIZK claim. Successful proof execution and the conditional
selected-event theorem do not relax the original service or independent
WAN requirements.

## Review artifacts

- [Measured report](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/3bbd072e4983eceee4531d7576d329da5b0d0900/formal/pon-nakamoto-v1/w1_public_stark_research/ROUND_REPORT.md)
- [Retained full proofs](https://github.com/TrillionniumFoundation/Trillionnium-Chain/tree/3bbd072e4983eceee4531d7576d329da5b0d0900/formal/pon-nakamoto-v1/w1_public_stark_research/results/retained-native-02)
- [Selected-event theorem](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/3bbd072e4983eceee4531d7576d329da5b0d0900/formal/pon-nakamoto-v1/selected_event_composition_research/THEOREM.md)
- [Priced legal strategies](https://github.com/TrillionniumFoundation/Trillionnium-Chain/blob/3bbd072e4983eceee4531d7576d329da5b0d0900/formal/pon-nakamoto-v1/selected_event_composition_research/PRICING.md)

## Delivery receipt

- Exact tested commit: `3bbd072e4983eceee4531d7576d329da5b0d0900`.
- Exact Git tree: `b36ce5dcc02c420addd41f10976b19a5f149b370`.
- Raw tracked-source identity verified before and after all final-commit checks; both receipts are byte-identical, SHA-256 `d5cc54ebf1c8eaff356f6b185e16dc3aec04c6883482d6968b9542087a82b16c`.
- The identity checks verified 10711 tracked entries and 999841023 bytes; identity checks themselves execute no tests.
- Final-commit focused checks: repository structure/Markdown passed, repository negatives 50/50, source-integrity negatives 43/43, selected checks 21/21 plus the original SHA256SUMS, and locked/offline native Cargo metadata, formatting, strict Clippy, 18+3 small tests, doc-test command, and all-target build passed.
- Main native binary remains `7700eff6ea4a3ff1f8f6551c323ac5b90b2bb5a96d1eaeca41e108bc54a7e3fc`. Full-proof and native-comparator timings are the retained independently identified campaigns; they were not rerun during delivery checks.
- Normal non-force push verified the remote research head at the exact commit above. C4 base remains `8df4b21d893906570d48f5beafabb3b31e0aefbc`.
- Durable Hepta operation key: `w1r2-final-commit-gates-push-pr-20261108-89f4dd-v1`. The preceding staged-gate job was `1a1b880937a-12894-fd3` (succeeded, exit 0, complete and durable).
- Qualification stays **HOLD_NO_GO**. This draft does not claim the complete repository CI lanes, merge approval, or production activation.



### 2026-11-08 structural admission continuation

Exact checked commit: `cae1e3657b0913991d9465995e709a544218a27c`; tree `49d3aeb781a6a791985b7df07513617d1e8ec896`.

Added allocation-free fixed-shape admission before either proof decode and preprocessing. 13 new native wire tests, 3 positive + 96 structural-negative comparison processes, and an explicit successor replay with 1 positive + 11 ordinary + 4 typed late controls passed. The pair plus public input is capped at 5,705,940 encoded bytes. See `formal/pon-nakamoto-v1/w1_public_stark_research/WIRE_ADMISSION.md` and its retained evidence.

Exact-commit locked/offline metadata, formatting, strict all-target Clippy, native tests/build, repository checks and source-integrity negatives passed; before/after source receipts matched. This remains a focused check set, not the complete repository CI lane. **HOLD_NO_GO**; the five substantive production gates remain open.
