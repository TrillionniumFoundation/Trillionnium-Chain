#!/usr/bin/env bash
set -euo pipefail
export RUST_TEST_THREADS="${RUST_TEST_THREADS:-1}"
# Exact original suffix; not a complete repository qualification.
    python3 scripts/ci/test_w1_full_v2_disposition.py
    # Historical clocks and finite screening do not qualify a proof for block admission.
    python3 scripts/ci/test_pon_proof_latency.py
    python3 scripts/ci/test_w1_proof_latency_readback.py
    # Real signal/deadline controls and provider contracts do not generate a proof.
    (
      w1_contract_out="${TRNM_CI_RECEIPT_DIR:-${RUNNER_TEMP:-/tmp}/trnm-ci-$$}/w1-postwin-contracts"
      test ! -e "$w1_contract_out"
      test ! -L "$w1_contract_out"
      mkdir -p "$(dirname "$w1_contract_out")"
      mkdir "$w1_contract_out"
      w1_contract_tmp="$(mktemp -d /dev/shm/trnm-w1-contract-XXXXXXXX)"
      trap 'rm -rf -- "$w1_contract_tmp"' EXIT
      export TMPDIR="$w1_contract_tmp"
      export PYTHONDONTWRITEBYTECODE=1
      python3 -m unittest discover -s scripts/ci -p test_w1_cancellation_handoff.py -v 2>&1 | tee "$w1_contract_out/cancellation-handoff.log"
      python3 -m unittest discover -s scripts/ci -p test_w1_coordinator_contract.py -v 2>&1 | tee "$w1_contract_out/coordinator-contract.log"
      python3 -m unittest discover -s scripts -p test_kaggle_generation_contract_v2.py -v 2>&1 | tee "$w1_contract_out/provider-contract.log"
      python3 -m unittest discover -s scripts -p test_w1_generation_target_v2.py -v 2>&1 | tee "$w1_contract_out/generation-target.log"
      python3 -m unittest discover -s scripts -p test_w1_owner_cancellation_v1.py -v 2>&1 | tee "$w1_contract_out/owner-cancellation.log"
      python3 -m unittest discover -s scripts/ci -p test_w1_kaggle_source_builder.py -v 2>&1 | tee "$w1_contract_out/source-builder.log"
      python3 -m unittest discover -s scripts -p test_w1_owned_generation_runtime_v2.py -v 2>&1 | tee "$w1_contract_out/owned-runtime-reader.log"
      python3 -m unittest discover -s scripts/ci -p test_w1_kaggle_worker_contract.py -v 2>&1 | tee "$w1_contract_out/kaggle-worker-contract.log"
      python3 -m unittest discover -s scripts/ci -p test_w1_postwin_identity.py -v 2>&1 | tee "$w1_contract_out/winner-identity.log"
      python3 -m unittest discover -s scripts/ci -p test_w1_deployment_evidence_binding.py -v 2>&1 | tee "$w1_contract_out/deployment-evidence-binding.log"
      python3 -m unittest discover -s scripts/ci -p test_w1_deployment_comparison_audit.py -v 2>&1 | tee "$w1_contract_out/deployment-comparison-audit.log"
      python3 scripts/test_w1_owned_process_collector_v1.py -v 2>&1 | tee "$w1_contract_out/owned-process-collector.log"
      python3 - "$w1_contract_out" <<'PY'
from pathlib import Path
import re, sys
root = Path(sys.argv[1])
expected = (("cancellation-handoff", 22), ("coordinator-contract", 20),
            ("provider-contract", 11), ("generation-target", 13), ("owner-cancellation", 8),
            ("source-builder", 8),
            ("owned-runtime-reader", 7), ("kaggle-worker-contract", 12), ("winner-identity", 4),
            ("deployment-evidence-binding", 12), ("deployment-comparison-audit", 20),
            ("owned-process-collector", 16))
for name, count in expected:
    text = (root / (name + ".log")).read_text()
    if (re.findall(r"^Ran ([0-9]+) tests in ", text, re.M) != [str(count)]
            or not re.search(r"^OK$", text, re.M) or "skipped=" in text):
        raise SystemExit(f"{name}: all {count} controls must execute without skips")
PY
    )
    python3 scripts/ci/test_pon_w1_preparation_strategy_reader_v4.py
    python3 scripts/ci/test_pon_w1_rank_batch_reader_v5.py
    python3 scripts/ci/test_run_w1_rank_batch_v5.py
    python3 scripts/ci/test_pon_w1_zero_paired_lazy_v1.py
    python3 scripts/ci/test_legacy_activation_tail_diagnostic.py
    python3 scripts/ci/test_run_legacy_reorg_root_abba.py
    python3 -B scripts/ci/test_w1_factorial_native_gate.py
    python3 -B scripts/ci/test_prepare_artifact_upload.py
    python3 -B scripts/ci/test_cell_storage_convergence_ci.py
    python3 -B scripts/ci/test_fresh_rejection_report.py
    # These in-memory counterexamples use unchanged retained inputs, not a new hardware observation.
    python3 scripts/ci/test_pon_w1_budget_readers.py --raw-dir evidence/pon-upgrade-implementation-20261018/native-rounds/chain-p0-native-54
    python3 scripts/ci/test_pon_public_v3_phase_read.py
    python3 scripts/ci/test_pon_public_v3_policy_read.py
    python3 scripts/ci/test_pon_v3_cookie_cpu_study.py
    python3 scripts/ci/test_run_pon_w1_native_campaign.py
    python3 scripts/ci/test_read_validated_business_goodput.py
    python3 scripts/ci/test_read_failed_native_campaign_zip.py
    python3 scripts/ci/test_read_native_campaign_attempt.py
    python3 scripts/ci/test_pon_w1_cost_matrix_reader.py
    python3 scripts/ci/test_throughput_cost_coverage.py
    python3 scripts/ci/test_rust_source_tokens.py
    python3 scripts/ci/test_collected_unit_empty_v1.py
    python3 scripts/ci/test_collect_pinned_codeql_metadata_v1.py
    python3 scripts/ci/test_codeql_semantic_observations_v1.py
    python3 scripts/ci/test_pon_w1_reused_cost_reader_v3.py
    python3 scripts/ci/test_run_w1_reused_cost_v3.py
    python3 scripts/ci/test_w1_lifecycle_cost_v4.py
    python3 scripts/ci/test_llm_cell_handoff_deadline.py
    python3 scripts/test_llm_cell_release.py
    python3 scripts/ci/test_read_original_native_campaign.py \
      --artifact-dir evidence/pon-upgrade-implementation-20261018/native-rounds/chain-pr327-original-campaign-39694587963 \
      --expected-manifest-sha256 12406cc156e57c130fa14af2b50b386031ec3640ce7f0234ed5bc9f0a700aac3 \
      --expected-head 9e705ccf75b7318dcc4bda4815956f58beb10e72 \
      --expected-tree 521ae87a28060d545979069b189eebbc74a71fd8 --retained-subset
    python3 scripts/ci/test_account_archive_conformance.py
    python3 scripts/ci/test_run_account_execution_conformance.py
    python3 scripts/ci/report_current_implementation.py --check
    python3 scripts/ci/test_work_cost_report.py
    # Retained source and arithmetic controls remain mandatory research-only gates.
    python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_w1_quantum_evidence_scope.py' -v
    python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_w1_quantum_native_bridge.py' -v
    python3 scripts/ci/test_w1_risc0_deep_event_audit.py
    python3 scripts/w1_risc0_deep_event_audit.py --repo-root .
    python3 scripts/ci/test_w1_p3_sampling_audit.py
    python3 scripts/w1_p3_sampling_audit.py
    python3 scripts/ci/test_pq_lifetime_composition.py
    python3 scripts/ci/pq_lifetime_composition.py
    python3 scripts/ci/test_pq_content_chain_review.py
    python3 scripts/ci/pq_content_chain_review.py
    python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_fixed_success_query_frontier.py' -v
    python3 formal/pon-nakamoto-v1/fixed_success_query_frontier.py --check
    python3 -m unittest discover -s formal/pon-nakamoto-v1 -p 'test_cost_tail_transfer.py' -v
    python3 formal/pon-nakamoto-v1/cost_tail_transfer.py --check
    python3 formal/pon-nakamoto-v1/test_quantum_bernoulli_source_audit.py -v
    python3 scripts/ci/test_retained_research_ci.py
    python3 scripts/test_qualification_runtime.py
