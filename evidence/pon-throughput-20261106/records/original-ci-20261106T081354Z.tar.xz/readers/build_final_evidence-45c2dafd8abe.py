#!/usr/bin/env python3
"""Assemble small primary evidence and immutable status snapshots; no CI execution."""
import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
OUT = BASE / "final-evidence"
REPO = BASE.parent / "chain-throughput"
REPO_URL = "https://github.com/TrillionniumFoundation/Trillionnium-Chain"
API = "https://api.github.com/repos/TrillionniumFoundation/Trillionnium-Chain"
HEAD = "9e50ca8e1ce655ef2f4686bd0ab58120b30c4632"
OLD = "b173c1f52d927522af67df30dd08ecfb2e3a1bb0"
TREE = "8d67d4812661393cfc9dba2474c279d8285d6dee"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def put(relative, data):
    path = OUT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, f"Immutable evidence changed: {path}"
    else:
        path.write_bytes(data)
    return str(path.relative_to(OUT))


def put_json(relative, data):
    return put(relative, (json.dumps(data, indent=2, ensure_ascii=False) + "\n").encode())


polls = [json.loads(p.read_text()) for p in sorted(HERE.glob("poll-[0-9]*.json"))]
latest = polls[-1]
stamp = latest["observed_at_utc"].replace("-", "").replace(":", "").replace(" ", "T", 1).replace(" UTC", "Z")
primary = {}
for poll in polls:
    for record in poll.get("records", []):
        if "data" in record:
            primary[(record["key"], record["kind"])] = {"observed_at_utc": poll["observed_at_utc"], **record}
assert len(primary) == 10, "Need original run and job primary records for all five workflows"
status_path = put_json(f"original-9e50/snapshots/{stamp}/status-and-primary-api.json", {
    "schema": "original-9e50-immutable-status-v1", "snapshot_utc": latest["observed_at_utc"],
    "head": HEAD, "tree": TREE, "summary": latest["summary"], "latest_primary_records": list(primary.values()),
    "scope": "API calls are non-atomic. Each record retains its own actual retrieval UTC. No reruns/cancels; all runs are original attempt 1. An in-progress/queued run has no acceptance conclusion.",
})

summaries = {}
for name in ["original-business-results-summary.json", "campaign-business-readback.json", "f0-business-readback.json", "workspace-original-artifact-summary.json", "large-cpu-all-matrices-summary.json", "pq-system-original-artifact-summary.json", "artifact-rollup-latest.json"]:
    data = (HERE / name).read_bytes()
    summaries[name] = put(f"original-9e50/summaries/{Path(name).stem}-{sha(data)[:16]}.json", data)
for name in ["baseline-campaign-business-readback.json", "baseline-f0-business-readback.json", "baseline-ci-disambiguation-summary.json"]:
    data = (HERE / name).read_bytes()
    summaries[name] = put(f"baseline-b173/summaries/{name}", data)
summaries["host-check-cost-summary.json"] = put("baseline-b173/summaries/host-check-cost-summary.json", (BASE / "host-check-cost-summary.json").read_bytes())
for name in ["hardware-comparison.json", "business-summary-baseline-reproduction.json"]:
    summaries[name] = put(f"comparisons/{name}", (HERE / name).read_bytes())

for path in sorted(HERE.glob("baseline-run-*.json")):
    put(f"baseline-b173/primary-api/{path.name}", path.read_bytes())
for path in sorted(HERE.glob("job-[0-9]*.log")):
    put(f"original-9e50/job-logs/{path.name}", path.read_bytes())
for path in sorted(HERE.glob("baseline-job-[0-9]*.log")):
    put(f"baseline-b173/job-logs/{path.name}", path.read_bytes())
for path in sorted(HERE.glob("corrected-head-discovery-*.json")):
    put(f"separate-1986-discovery/{path.name}", path.read_bytes())

metadata = {}
for path in sorted(HERE.glob("artifact-[0-9]*.json")):
    value = json.loads(path.read_text())
    metadata[value["id"]] = value
for path in sorted((HERE / "baseline-artifacts").glob("artifact-[0-9]*.json")):
    value = json.loads(path.read_text())
    metadata[value["id"]] = value
for path in sorted(HERE.glob("baseline-run-*.json")):
    value = json.loads(path.read_text())
    artifacts = value.get("artifacts", {}).get("artifacts", [])
    if value.get("kind") == "artifacts":
        artifacts = value["data"]["artifacts"]
    for item in artifacts:
        metadata.setdefault(item["id"], item)
metadata[13480500531]["local_path"] = str(BASE / "native-campaign-b173.zip")
metadata[13479739583]["local_path"] = str(BASE / "fixed-host-f0-b173.zip")

artifact_manifest = []
budget_observations = []
for aid, meta in sorted(metadata.items()):
    old = meta["workflow_run"]["head_sha"] == OLD
    assert meta["workflow_run"]["head_sha"] in [OLD, HEAD]
    group = "baseline-b173" if old else "original-9e50"
    clean = {k: v for k, v in meta.items() if k not in ["download_url", "file_id", "local_path", "zip_entries"]}
    clean["artifact_browser_url"] = f"{REPO_URL}/actions/runs/{meta['workflow_run']['id']}/artifacts/{aid}"
    clean["archive_download_api"] = f"{API}/actions/artifacts/{aid}/zip"
    clean["archive_included_in_compact_bundle"] = False
    local = Path(meta.get("local_path", "/__not_downloaded__"))
    clean["downloaded_bytes_sha256_verified"] = local.is_file()
    if local.is_file():
        raw = local.read_bytes()
        assert meta["digest"] == "sha256:" + sha(raw) and meta["size_in_bytes"] == len(raw)
        clean["actual_bytes"] = len(raw)
        clean["actual_sha256"] = sha(raw)
        extracted = []
        with zipfile.ZipFile(local) as z:
            for info in z.infolist():
                name = info.filename
                if info.is_dir():
                    continue
                leaf = Path(name).name
                small = info.file_size <= 262144
                business = meta["workflow_run"]["id"] in [42179336010, 42179336118, 42165737862, 42165737677]
                if business:
                    wanted = leaf in {"hardware.json", "results.json", "result.json", "source-before.json", "source-after.json", "source-before-campaigns.json", "inside-before.json", "inside-after.json", "outside-before.json", "outside-after.json", "child-result.json", "controller-result.json", "binary.json"} or bool(re.fullmatch(r"run-[123]-(result|source-after|resource-before|resource-after)\.json", leaf)) or ("resource" in leaf and leaf.endswith(".json"))
                else:
                    wanted = name.endswith((".json", ".tsv", ".execution.stderr", ".exit")) or (name.startswith("semantic-controls/") and name.endswith(".log")) or leaf in {"independent-readback.log", "cell-current-api-readback.log", "growth-scale.exits.txt", "registry-check.stderr"} or (meta["name"].startswith("original-large-state-") and name.endswith(".log"))
                if small and wanted:
                    data = z.read(name)
                    dest = put(f"{group}/artifact-reports/{aid}/{name}", data)
                    extracted.append({"zip_entry": name, "uncompressed_bytes": len(data), "sha256": sha(data), "bundle_path": dest})
                    if leaf in {"inside-before.json", "inside-after.json", "outside-before.json", "outside-after.json"}:
                        observation = json.loads(data)
                        limits = observation.get("limits")
                        expected = {"cpu.max": "25000 100000", "cpu.max.burst": "0", "memory.max": "2147483648", "memory.swap.max": "0", "pids.max": "256"}
                        assert limits == expected, (aid, name, limits)
                        budget_observations.append({"source_head": OLD if old else HEAD, "artifact_id": aid, "zip_entry": name, "bundle_path": dest, "limits": limits, "parent_path": observation.get("parent_path"), "observed_utc": observation.get("observed_utc")})
        clean["extracted_entry_manifest"] = put_json(f"{group}/artifact-reports/{aid}/extracted-entry-manifest.json", {"artifact_id": aid, "archive_sha256": sha(raw), "selection": "Small source, control, result, resource and failure records only. No ELF/archive or oversized raw telemetry. Omitted original entries remain available from the artifact ID while retained by GitHub.", "entries": extracted})
    put_json(f"{group}/artifact-reports/{aid}/primary-artifact-metadata.json", clean)
    artifact_manifest.append(clean)
artifact_path = put_json(f"manifests/artifacts-{stamp}.json", {"schema": "all-original-artifact-provenance-v1", "snapshot_utc": latest["observed_at_utc"], "artifacts": artifact_manifest})

budget = {
    "schema": "fixed-original-public-host-budget-v1",
    "fixed_parent": "/sys/fs/cgroup/trnmponpublic.slice",
    "host_limits": {"cpu.max": "25000 100000", "cpu.max.burst": "0", "memory.max": "2147483648", "memory.swap.max": "0", "pids.max": "256"},
    "interpretation": "0.25 CPU aggregate receiver/verifier parent, 2 GiB memory, zero CPU burst and swap, 256 tasks; not a per-worker budget.",
    "controller_limits": {"cpu.max": "400000 100000", "memory.max": "17179869184", "nice": 10},
    "controller_scope": "Original controller, broker, launcher and external producer/attacker actors; separate systemd-owned public Host parent. 4 CPUs/16 GiB does not enlarge the public Host budget.",
    "workload": {"campaign_attempts": 3, "campaign_phase_modes": ["baseline", "from-zero", "late-product"], "attacker_processes": [0, 24, 24], "phase_seconds": 30, "seed_transfers": 1024, "seed_blocks": 4, "business_blocks": 21, "f0_planned_slots": 6, "f0_slo_seconds": 4},
    "budget_limits_verified_observation_count": len(budget_observations), "observations": budget_observations,
    "cpu_accounting": "Host checkpoint CPU is nested within caller CPU; sums of nested telemetry categories are not additive. Unknown CPU is not zero.",
    "hardware_comparison": "Old campaign Intel Xeon Platinum 8370C versus new campaign AMD EPYC 9V74; identical cgroup limits are not identical physical hardware. F0 hardware records do not provide CPU model.",
}
budget_path = put_json("comparisons/fixed-parent-and-controller-budgets.json", budget)

source_files = []
for commit in [OLD, HEAD]:
    for path in ["config/pon/pq-system-required-tests-v1.json", ".github/workflows/pon-pq-system-continuation.yml", ".github/workflows/pon-original-workspace-large-state-cpu.yml"]:
        data = subprocess.check_output(["git", "show", commit + ":" + path], cwd=REPO)
        dest = put(f"source-records/{commit[:8]}/{path}", data)
        source_files.append({"commit": commit, "path": path, "source_url": f"{REPO_URL}/blob/{commit}/{path}", "git_blob_sha1": hashlib.sha1(b"blob " + str(len(data)).encode() + bytes([0]) + data).hexdigest(), "sha256": sha(data), "bundle_path": dest})
source_path = put_json("source-records/source-manifest.json", source_files)

for name in ["summarize_business_artifact.py", "summarize_workspace_artifacts.py", "summarize_pq_system_artifacts.py", "analyze_finished_artifacts.py", "build_final_evidence.py"]:
    data = (HERE / name).read_bytes()
    put(f"readers/{Path(name).stem}-{sha(data)[:12]}.py", data)

states = {r["key"]: r for r in latest["summary"]}
pq = states["pq"]
readme = f"""# Original throughput evidence — 9e50 versus b173

Snapshot: **{latest['observed_at_utc']}**. Original candidate: `{HEAD}`, tree `{TREE}`. Baseline: `{OLD}`. [PR #736]({REPO_URL}/pull/736).

This bundle retains original attempt-1 outcomes. It contains no rerun, relaxed threshold, production TPS claim, or replacement of a failed original result. The later test-only source `1986fa080b69bbab3a44f270ab8477adc5a01ea4` is recorded only in a separate discovery directory; its statuses cannot validate the original candidate.

## Five original runs

| Acceptance | Run | Observed conclusion | Meaning |
| --- | --- | --- | --- |
| Three native campaigns | [42179336010]({REPO_URL}/actions/runs/42179336010) | failure | All three campaigns failed original criteria. Baseline first confirmation 21.592711199 / 21.412403030 / 21.705995884 s; attack phases had no confirmation. |
| F0 | [42179336118]({REPO_URL}/actions/runs/42179336118) | failure | 0/6 planned slots met the four-second SLO. Baseline confirmations were late: 14.306255781 and 24.407486459 s from their scheduled slots. ROOT had none. `BASELINE_MUST_PASS` means baseline service criteria failed; verified cleanup reported all services known empty. |
| Large-state CPU | [42179335866]({REPO_URL}/actions/runs/42179335866) | success, four matrices | Four exact controls per matrix passed. Explicit 8,625,548-byte seeded fixture and original CPU settlement do not establish public-network throughput. |
| Workspace | [42179336034]({REPO_URL}/actions/runs/42179336034) | failure, four matrices | Registry selected 80 actual controls; each matrix 79 passed, 1 failed. The original `reversed-ddl` VM counter assertion expected [2,2,0,2,1] and observed [3,3,0,3,2]. All original logs remain unchanged. |
| PQ | [42179335849]({REPO_URL}/actions/runs/42179335849) | {pq['run_status']} / {pq['run_conclusion']} | See immutable status and PQ summaries for actual terminal counts. Four pre-regression archives each contain 52 native + 14 TLS/ordinary binary + 13 original scope controls passed; twelve ancillary jobs passed. Pre-regression artifacts do not prove whole-workflow success. |

## Baseline classification and comparison limits

The b173 campaign first confirmations were 14.585549165 / 14.998208439 / 14.811700851 s, with no attack-phase confirmations. Its F0 first late confirmation was approximately 27.3 s and the four-second SLO was 0/6. These observations came from different runner hardware: campaign Intel Xeon Platinum 8370C then AMD EPYC 9V74. They are not an isolated A/B measurement of either code change. F0 CPU model is absent from the retained hardware record.

Old Workspace failed registry synchronization (25 actual, 23 expected), before the selected-test TSV existed. Old PQ required-control construction failed on manifest 52 versus hardcoded 49. Its separate complete Node library result was **1,136 passed, 0 failed, 31 ignored**; its dedicated required-control records were absent. Large-state CPU's original four matrix jobs succeeded. Primary API, representative head logs, source files and archive hashes are retained for each classification.

## Exact budget and recovery scope

The shared public parent is `/sys/fs/cgroup/trnmponpublic.slice`: CPU `25000 100000` (0.25 CPU), CPU burst 0, memory 2,147,483,648 bytes, swap 0, tasks 256. The original external controller uses CPU `400000 100000` (4 CPUs), memory 17,179,869,184 bytes, nice 10. Receiver/verifier work stays under the fixed public parent; external attackers remain in the controller domain. Original campaign 3×3 workloads, 30-second phases, 1,024 seed transfers/four seed blocks, 21 business blocks, and F0 six planned/four-second slots remain intact.

Workspace Growth observations contain nine N×H cohorts (N 64/1,024/16,384; H 0/16/128), eight measured blocks each, fixed three witness owners. On x64/head, query point reads were 16/30/37 by N and did not grow with H in these samples; witness sizes were 917/1,841/2,303 bytes. Admission medians were roughly 5.21–9.74 ms, while cold reopen ranged 32.2 ms–1.674 s. All raw readbacks explicitly retain `native_stage_cpu_measurements_available=false`, `p99_ns=null`, `throughput_qualified=false`, `public_network_ready=false`, and `production_activation=false`. These are finite local observations, not production TPS, fairness under arbitrary malicious load, or elimination of cold replay cost. Development depth-6 confirmation is not real-difficulty WAN confirmation.

Host checkpoint CPU is nested inside caller CPU and must not be added to it. Control counts overlap with full regression suites and must not be summed as unique tests. Successful primitive interop/CPQ/TAP21 subjobs do not grant whole-chain quantum-security acceptance.

## Contents and replay

`{status_path}` holds immutable statuses plus complete latest primary run/job API records, each with its own actual retrieval UTC. `{artifact_path}` lists original artifact IDs, source identities, original byte sizes/full SHA-256, download endpoints and whether the ZIP was actually downloaded and verified. Large ZIPs, ELF files and oversized raw telemetry are intentionally omitted; selected byte-exact entries retain their original archive paths and SHA-256. GitHub artifact retention still applies. `{budget_path}` records all {len(budget_observations)} retained Host limit observations. Source provenance is in `{source_path}`.

Machine summaries and readers accompany raw small reports and decoded complete terminal-job logs. Hash-named summaries and timestamped snapshots remain immutable; a later snapshot adds new observations without erasing this one. Nothing in this bundle changes repository code, source pins, workflows or branches.
"""
readme_path = put(f"reports/README-{stamp}.md", readme.encode())
index = {"schema": "original-throughput-evidence-bundle-index-v1", "snapshot_utc": latest["observed_at_utc"], "source_head": HEAD, "source_tree": TREE, "baseline_head": OLD, "status_path": status_path, "artifact_manifest_path": artifact_path, "budget_path": budget_path, "source_path": source_path, "readme_path": readme_path, "summaries": summaries}
index_path = put_json(f"manifests/index-{stamp}.json", index)
files = [{"path": str(p.relative_to(OUT)), "bytes": p.stat().st_size, "sha256": sha(p.read_bytes())} for p in sorted(OUT.rglob("*")) if p.is_file() and not p.name.startswith("file-hashes-")]
hash_path = put_json(f"manifests/file-hashes-{stamp}.json", {"schema": "evidence-bundle-file-digests-v1", "snapshot_utc": latest["observed_at_utc"], "files": files})
archive = BASE / f"final-evidence-{stamp}.zip"
assert not archive.exists(), f"Archive already exists: {archive}"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in sorted(OUT.rglob("*")):
        if path.is_file():
            z.write(path, str(path.relative_to(OUT)))
print(json.dumps({"directory": str(OUT), "snapshot_utc": latest["observed_at_utc"], "index": index_path, "hash_manifest": hash_path, "artifact_count": len(artifact_manifest), "copied_file_count": sum(p.is_file() for p in OUT.rglob("*")), "uncompressed_file_bytes": sum(p.stat().st_size for p in OUT.rglob("*") if p.is_file()), "archive": str(archive), "archive_bytes": archive.stat().st_size, "archive_sha256": sha(archive.read_bytes())}))
