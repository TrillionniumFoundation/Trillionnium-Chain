from owner_evidence_lib import BASE, ROOT, FINAL, FAILED, Package, identity
import json

work = BASE / 'peer-lease-next/work'
package = Package('peer-lease')
report = json.loads((FINAL / 'peer-lease/report.json').read_bytes())
included = {'final': package.directory('final', FINAL / 'peer-lease', excluded=('original-target',))}
for suffix in ('.stdout.raw', '.stderr.raw', '.execution.json'):
    package.file('execution' + suffix, FINAL / ('peer-lease' + suffix))
for name in ('source-before.json', 'source-after.json'):
    package.file('integration-' + name, FINAL / name)
package.snapshot('source-snapshots/final', report['source_inputs'], ROOT)
package.file('independent-readback.json', BASE / 'peer-lease-final-readback.json')
package.file('independent-reader.py', BASE / 'read_peer_lease.py')

included['initial-enospc-failure'] = package.directory('historical/enospc', FAILED / 'peer-lease', excluded=('original-target',))
for suffix in ('.stdout.raw', '.stderr.raw', '.execution.json'):
    package.file('historical/enospc-execution' + suffix, FAILED / ('peer-lease' + suffix))
for label in ('qualification-v1', 'qualification-partial', 'qualification-failure'):
    included[label] = package.directory('historical/' + label, work / label, excluded=('original-target',))
    for suffix in ('.stdout.raw', '.stderr.raw'):
        path = work / (label + suffix)
        if path.is_file():
            package.file('historical/' + label + suffix, path)
controls = json.loads((work / 'qualification-partial/report.json').read_bytes())
package.snapshot('source-snapshots/reporter-controls', controls['source_inputs'], BASE / 'peer-lease-next/Trillionnium-Chain')

for name in ('original-retained-evidence.tar.xz', 'original-remote-source.tar.xz',
             'original-remote-source-manifest.json', 'remote-physical-readback.json'):
    package.file('remote-original/' + name, work / name)
included['remote-original-provenance'] = package.directory('remote-original/provenance', work / 'remote-original-baseline')
for path in sorted(work.glob('remote-host-probe.*')):
    if path.is_file():
        package.file('remote-original/host-probe/' + path.name, path)
for path in sorted(work.glob('report-*.py')):
    package.file('historical/' + path.name, path)

package.finish({'schema': 'trnm.hia.peer-lease.final-evidence-package.v1',
    'final_qualification': 'final/report.json', 'final_status': report['status'],
    'tests': 13, 'actual_original_comparisons': 53, 'public_operations': 8095,
    'original_retained_host': 'rog', 'original_retained_job': '1a1eec4371f-ffbe-2c3',
    'original_unfiltered_outer_tests': 121, 'original_nested_child_tests_not_added_to_outer_count': 2,
    'remote_original_binary_count': 16, 'remote_original_binary_bytes': 231382068,
    'remote_original_complete_source_files': 1700,
    'local_original_build_role': 'Complete unchanged crate rebuilt with --no-run only for the independent API adapter; it does not replace the ROG execution.',
    'remote_archive_full_bytes_and_every_binary_verified': True,
    'included_directories': included,
    'excluded_reproducible_cargo_targets': ['original-target'],
    'historical_limits': ['The original local unfiltered test run failed with denied Unix socket operations; qualification-v1 remains FAIL despite passing native value comparisons.',
        'The first merged root run failed during Cargo setup with ENOSPC and remains incomplete/FAIL.',
        'Partial one-of-thirteen execution remains INCOMPLETE; the actual assertion failure remains FAIL.',
        'Older v1 source hashes are preserved as observed; it does not inherit the final source snapshot.'],
    'whole_chain_native': False, 'whole_package_retired': False, 'old_stack_can_be_removed': False,
    'durable_journal_owner_implemented': False, 'unix_authority_implemented': False,
    'native_core_authentication_implemented': False, 'production_activation': False})
