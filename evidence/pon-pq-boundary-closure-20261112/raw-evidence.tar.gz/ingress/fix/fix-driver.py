import hashlib,importlib.util,json,os,re,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/qian-qi/work/chain-pq-boundary-closure-20261112-4150')
OUT=Path('/home/qian-qi/work/pq-boundary-ingress-20261112-4150/fix')
HELPER=Path('/home/qian-qi/work/w1-baseline-9082-validation-165d/supplemental-provider-clippy/helpers/supplemental-provider-clippy-165d.py')
BASELINE='05f75684b1ef4d60a36cfcda7a84b6f32542ca0c'
CHANGED=['trillionnium/crates/trnm-pon-node/src/ingress/pq_network.rs','trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs']
os.chdir(ROOT)
OUT.mkdir(exist_ok=False)
(OUT/'fix-driver.py').write_text(sys.orig_argv[sys.orig_argv.index('-c')+1])
def save(name,data):
 with (OUT/name).open('x') as f:
  json.dump(data,f,indent=2,sort_keys=True,allow_nan=False); f.write('\n')
def run(name,args,env=None,timeout=300,required=True):
 start=time.time()
 with (OUT/(name+'.stdout')).open('xb') as out, (OUT/(name+'.stderr')).open('xb') as err:
  p=subprocess.Popen(args,stdout=out,stderr=err,env=env,start_new_session=True)
  timed_out=False
  try: code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(p.pid,signal.SIGTERM)
   try: code=p.wait(timeout=10)
   except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL);code=p.wait(timeout=10)
 data={'argv':args,'exit_code':code,'timed_out':timed_out,'elapsed_seconds':round(time.time()-start,3),'source_cwd':str(ROOT)}
 save(name+'.json',data);print(name,json.dumps(data),flush=True)
 if required and (code!=0 or timed_out):raise RuntimeError(name+' failed')
 return data
assert hashlib.sha256(HELPER.read_bytes()).hexdigest()=='363fa66725ddedf2a6fa1e34b785b31c2e8ddeaa767f058766b2037c0f4ea492'
spec=importlib.util.spec_from_file_location('provider_helper',HELPER);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
provider_before=helper.provider_identity();save('provider-before.json',provider_before);assert provider_before['all_five_match']
selection=helper.check_inherited_environment(dict(os.environ));save('provider-selection.json',selection);assert selection['compatible']
env=dict(os.environ);env.update(helper.expected_environment())
env.update(PATH='/home/qian-qi/.cargo/bin:'+env['PATH'],CARGO_TARGET_DIR='/home/qian-qi/work/w1-baseline-9082-target-165d',CARGO_BUILD_JOBS='2',PYTHONDONTWRITEBYTECODE='1')
save('build-environment.json',{k:env[k] for k in helper.expected_environment()}|{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR'],'CARGO_BUILD_JOBS':env['CARGO_BUILD_JOBS']})
run('preflight-before-fix-checkpoint',['bash','scripts/project-preflight.sh'],env)
run('format',['cargo','fmt','--all','--check','--manifest-path','trillionnium/Cargo.toml'],env)
run('diff-check',['git','diff','--check'],env)
head_before=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head_before==BASELINE,head_before
dirty=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
assert sorted(dirty)==sorted(CHANGED),dirty
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
run('preflight-before-commit',['bash','scripts/project-preflight.sh'],env)
run('stage-fix',['git','add','--']+CHANGED,env)
run('commit-fix',['git','commit','-s','-m','fix(pq): validate account configuration before network entry'],env)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()
save('fixed-source.json',{'head':head,'tree':tree,'baseline':BASELINE,'changed':CHANGED})
print('FIX_COMMIT '+head,flush=True)
test_path=ROOT/'trillionnium/crates/trnm-pon-node/src/ingress/account_scope_tests.rs'
test_names=re.findall(r'#\[test\]\s*fn\s+(\w+)\(',test_path.read_text())
assert len(test_names)==9,test_names
expected={'ingress::account_scope_tests::'+n for n in test_names}
rows=[]
try:
 run('source-before',['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',head,'--output',str(OUT/'source-before-identity.json')],env)
 for lane,features in [('default',[]),('all-features',['--all-features'])]:
  run('metadata-'+lane,['cargo','metadata','--locked','--offline','--format-version','1','--manifest-path','trillionnium/Cargo.toml']+features,env)
  row=run('fixed-'+lane,['cargo','test','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib']+features+['ingress::account_scope_tests::','--','--test-threads=1'],env,1200,False)
  output=(OUT/('fixed-'+lane+'.stdout')).read_text()
  observed=re.findall(r'^test (ingress::account_scope_tests::\w+) \.\.\. (\w+)\s*$',output,re.MULTILINE)
  row.update(lane=lane,methods=observed,expected_methods=sorted(expected))
  rows.append(row)
  assert row['exit_code']==0 and not row['timed_out'],row
  assert len(observed)==9 and {name for name,status in observed}==expected and all(status=='ok' for name,status in observed),observed
finally:
 provider_after=helper.provider_identity();save('provider-after.json',provider_after)
 after=run('source-after',['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',head,'--output',str(OUT/'source-after-identity.json')],env,required=False)
 source_same=(OUT/'source-before-identity.json').exists() and (OUT/'source-after-identity.json').exists() and json.loads((OUT/'source-before-identity.json').read_text())==json.loads((OUT/'source-after-identity.json').read_text())
 results={'source':head,'tests':rows,'provider_unchanged':provider_before==provider_after,'provider_all_five_match':provider_after['all_five_match'],'source_unchanged':source_same,'source_after_exit_code':after['exit_code']}
 save('fixed-results.json',results);print('FIX_FINISHED '+json.dumps(results),flush=True)
 assert results['provider_unchanged'] and results['provider_all_five_match'] and results['source_unchanged'] and after['exit_code']==0,results
