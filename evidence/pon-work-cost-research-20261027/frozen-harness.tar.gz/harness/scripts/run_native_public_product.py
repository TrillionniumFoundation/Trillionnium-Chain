#!/usr/bin/env python3
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
from independent_check import ROOT
from verify_research_sources import blob

def run(rustc,deps,native_source,corpus,out):
    out.mkdir();driver=ROOT/'src/native_public_product_controls.rs';binary=out/'native-public-product-controls'
    native=native_source/'trillionnium/crates/trnm-crypto-primitives/src/pon_work/public_product.rs'
    expected='cb8b97f6b200f9e863ac23e0f2255cd3a39dedc8'
    if blob(native.read_bytes())!=expected:raise ValueError('PUBLIC_PRODUCT_SOURCE_CHANGED')
    command=[str(rustc),'--edition=2021','--crate-name','native_public_product_controls',str(driver),'-L','dependency='+str(deps),'-o',str(binary)]
    libraries=[]
    for name in ['trnm_crypto_primitives','trnm_protocol']:
        choices=list(deps.glob('lib'+name+'-*.rlib'))
        if len(choices)!=1:raise ValueError('AMBIGUOUS_RLIB '+name)
        lib=choices[0];command+=['--extern',name+'='+str(lib)]
        libraries.append(dict(path=str(lib),sha256=hashlib.sha256(lib.read_bytes()).hexdigest()))
    result=dict(schema='trnm-native-public-product-controls-v1',scope='actual public-product API plus full W1 primitive; supplemental linked driver, not Node',driver_sha256=hashlib.sha256(driver.read_bytes()).hexdigest(),native_public_product_git_blob=expected,libraries=libraries,compile_exit=None,execution_exit=None)
    compiled=subprocess.run(command,capture_output=True,text=True);result['compile_exit']=compiled.returncode
    (out/'compile.log').write_text(compiled.stdout+compiled.stderr)
    if compiled.returncode==0:
        raw=(corpus/'raw.json').read_bytes();data=json.loads(raw);paths=[]
        for row in data['rows']:
            path=row['path']
            if Path(path).name!=path:raise ValueError('CONTROL_PATH')
            actual=corpus/path
            if hashlib.sha256(actual.read_bytes()).hexdigest()!=row['sha256']:raise ValueError('CONTROL_BYTES')
            paths.append(str(actual))
        executed=subprocess.run([str(binary),*paths],capture_output=True,text=True)
        result['execution_exit']=executed.returncode;(out/'execute.log').write_text(executed.stdout+executed.stderr)
        result['raw_sha256']=hashlib.sha256(raw).hexdigest();result['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
        if executed.returncode==0:result['native_observation']=json.loads(executed.stdout)
    result['result']='PASS'if result['compile_exit']==result['execution_exit']==0 else 'FAIL'
    result['node_entry_executed']=False;result['succinct_proof']=False
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');return result

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for name in ['rustc','deps','native_source','corpus','out']:p.add_argument(name,type=Path)
    a=p.parse_args();r=run(a.rustc,a.deps,a.native_source,a.corpus,a.out);print(json.dumps(r,indent=2));sys.exit(0 if r['result']=='PASS'else 1)
