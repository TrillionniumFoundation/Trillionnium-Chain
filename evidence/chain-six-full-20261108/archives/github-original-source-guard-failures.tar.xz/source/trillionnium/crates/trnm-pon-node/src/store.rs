//! M07/M08 native branch persistence and recovery using the existing M06 executor.
#[cfg(test)]
mod admission_header_tests;
#[cfg(test)]
mod append_readback_tests;
pub mod async_w1_generation_v2;
pub mod authenticated_migration;
pub(crate) mod authenticated_state;
#[cfg(test)]
mod canonical_row_reuse_tests;
pub mod capacity_observation;
pub mod demand_evidence;
pub mod evaluation_observation;
pub mod evaluation_round_observation;
mod funding;
pub(crate) mod growth;
pub mod growth_reference;
mod historical_commitment;
#[cfg(test)]
mod historical_commitment_tests;
mod history_page;
mod legacy_admission_readback;
#[cfg(test)]
mod legacy_admission_root_tests;
#[cfg(test)]
mod legacy_reorg_observation_tests;
#[cfg(test)]
mod legacy_reorg_root_tests;
pub mod mempool;
pub(crate) mod native_authenticated;
pub mod native_budget;
pub mod native_owner_observation;
mod operator_continuous_owner;
mod operator_mining_owner;
pub mod packet_observation;
pub mod pinned_account_query;
#[cfg(all(test, feature = "pq-native-openssl"))]
mod pq_existing_owner_tests;
mod pq_migration_inventory;
pub(crate) mod pq_network;
pub(crate) mod pq_rollback_witness;
#[cfg(test)]
pub(crate) mod public_reader;
#[cfg(test)]
mod read_query_cache_tests;
mod reorg_cancellation;
#[cfg(test)]
mod reorg_readback_tests;
mod reverse_path;
mod root_rejection_cache;
#[cfg(test)]
mod root_rejection_cache_tests;
mod state_merge;
pub mod storage_service;
mod task_observation;
pub mod task_operation_v2;
use crate::{
    consensus::{self, Work},
    development_public, ensure, maintenance, sequence_root, Error, Packet, Result, Settings,
};
use fs2::FileExt;
pub use history_page::HistoryPageReadCounters;
pub(crate) use operator_continuous_owner::PublicContinuousScope;
pub use operator_continuous_owner::{
    ContinuousSearchRequest, OwnedContinuousLeaseResult, OwnedContinuousPoolResult,
};
pub use operator_mining_owner::{MiningEpochCancellation, OwnedMutationResult, OwnedSearchResult};
use rusqlite::{params, Connection, OpenFlags, OptionalExtension};
use serde::Serialize;
use serde_json::Value;
use std::os::unix::fs::{MetadataExt, OpenOptionsExt, PermissionsExt};
use std::{
    cell::{Cell, RefCell},
    collections::BTreeMap,
    fs::{self, File, OpenOptions},
    io::{Read, Write},
    path::{Path, PathBuf},
    time::Duration,
};
use trnm_crypto_primitives::pon_work;
use trnm_crypto_primitives::qualified_work_task::{
    derive_matrices, verify_development_statement, DevelopmentTaskAdmission, TaskMaterial,
};
use trnm_mvcc_fee::checkpoint_tile_policy_v1::PROFILE as CHECKPOINT_TASK_PROFILE;
use trnm_mvcc_fee::continuity_v1::{self, PROFILE as CONTINUITY_TASK_PROFILE};
use trnm_mvcc_fee::growth_profile_v2::{self, PROFILE as GROWTH_TASK_PROFILE};
use trnm_mvcc_fee::pon_commitment::{
    self, CacheLimits, CheckedCommitment, CommitmentObservation, ExecutionRequest,
    PreparedCommitment,
};
#[cfg(test)]
use trnm_mvcc_fee::pon_executor::root;
use trnm_mvcc_fee::pon_executor::SIGNED_TASK_PROFILE;
use trnm_mvcc_fee::pon_executor::{
    pq_accounts_v2, ExecutionControl, ExecutionError, ExecutionProgress, State,
};
use trnm_mvcc_fee::qualified_task_lifecycle;
use trnm_protocol::pon_wire::{hash, Hash, Header};
use trnm_protocol::qualified_work_task::lifecycle_v2::PROFILE as LIFECYCLE_TASK_PROFILE;
use trnm_protocol::qualified_work_task::lifecycle_v3::PROFILE as ATOMIC_TASK_PROFILE;
use trnm_protocol::qualified_work_task::lifecycle_v4::PROFILE as OVERLAP_TASK_PROFILE;
use trnm_protocol::qualified_work_task::{
    QualifiedWorkTask, SignedQualifiedWorkTask, TaskPurpose, SIGNED_TASK_BYTES,
};
use trnm_transport::{
    AuthenticatedPeerFrameV0, CandidateP2pAdmissionV0, IoDigest32V0, PeerFrameSourceV0,
    PeerReplayRecoverySourceV0, PeerReplayStateV0, PeerSessionIdentityV0,
};
const BASE_DDL:&str="CREATE TABLE metadata(key TEXT PRIMARY KEY,value BLOB NOT NULL);
CREATE TABLE blocks(id BLOB PRIMARY KEY,parent BLOB,height INTEGER NOT NULL,chainwork BLOB NOT NULL,packet BLOB,state_root BLOB NOT NULL);
CREATE INDEX work_order ON blocks(chainwork DESC,height,id);
CREATE TABLE deltas(block BLOB NOT NULL,key TEXT NOT NULL,before BLOB,after BLOB,PRIMARY KEY(block,key));
CREATE TABLE active(singleton INTEGER PRIMARY KEY CHECK(singleton=1),tip BLOB NOT NULL,generation INTEGER NOT NULL,state_slot INTEGER NOT NULL);
CREATE TABLE kv(slot INTEGER NOT NULL,key TEXT NOT NULL,value BLOB NOT NULL,PRIMARY KEY(slot,key));
CREATE TABLE reorg(singleton INTEGER PRIMARY KEY CHECK(singleton=1),old_tip BLOB NOT NULL,new_tip BLOB NOT NULL,generation INTEGER NOT NULL,cursor INTEGER NOT NULL,done INTEGER NOT NULL);
CREATE TABLE reorg_lifecycle_v1(operation INTEGER PRIMARY KEY AUTOINCREMENT,old_tip BLOB NOT NULL CHECK(length(old_tip)=32),new_tip BLOB NOT NULL CHECK(length(new_tip)=32),generation INTEGER NOT NULL CHECK(generation>0),old_slot INTEGER NOT NULL CHECK(old_slot>=0),old_root BLOB NOT NULL CHECK(length(old_root)=32),owner_context BLOB NOT NULL CHECK(length(owner_context)=32),outcome INTEGER NOT NULL CHECK(outcome IN (0,1,2)),cancelled_cursor INTEGER,reason TEXT NOT NULL CHECK(length(reason)<=96),CHECK((outcome IN (0,1) AND cancelled_cursor IS NULL AND reason='') OR (outcome=2 AND cancelled_cursor>=0 AND length(reason)>0)));
CREATE TABLE steps(ordinal INTEGER PRIMARY KEY,kind INTEGER NOT NULL,block BLOB NOT NULL);
CREATE TABLE events(generation INTEGER NOT NULL,ordinal INTEGER NOT NULL,kind INTEGER NOT NULL,block BLOB NOT NULL,PRIMARY KEY(generation,ordinal));
CREATE TABLE snapshots(block BLOB PRIMARY KEY,state BLOB NOT NULL);
CREATE TABLE local_pool_metadata(singleton INTEGER PRIMARY KEY CHECK(singleton=1),context BLOB NOT NULL CHECK(length(context)=32),limits BLOB NOT NULL,gc_groups BLOB NOT NULL DEFAULT X'0000000000000000' CHECK(length(gc_groups)=8),gc_records BLOB NOT NULL DEFAULT X'0000000000000000' CHECK(length(gc_records)=8),gc_bytes BLOB NOT NULL DEFAULT X'0000000000000000' CHECK(length(gc_bytes)=8),gc_head BLOB NOT NULL DEFAULT X'0000000000000000000000000000000000000000000000000000000000000000' CHECK(length(gc_head)=32),checked_parent BLOB,checked_generation INTEGER,CHECK((checked_parent IS NULL AND checked_generation IS NULL) OR (length(checked_parent)=32 AND checked_generation>=0)));
CREATE TABLE local_pool_groups(ordinal INTEGER PRIMARY KEY AUTOINCREMENT,id BLOB UNIQUE NOT NULL CHECK(length(id)=32),status INTEGER NOT NULL CHECK(status IN (0,1,2,3)),reason TEXT NOT NULL);
CREATE TABLE local_pool_rows(group_id BLOB NOT NULL,position INTEGER NOT NULL CHECK(position>=0 AND position<16),digest BLOB UNIQUE NOT NULL CHECK(length(digest)=32),sender BLOB NOT NULL CHECK(length(sender)=32),nonce BLOB NOT NULL CHECK(length(nonce)=8),expiry BLOB NOT NULL CHECK(length(expiry)=8),fee_limit BLOB NOT NULL CHECK(length(fee_limit)=8),raw BLOB NOT NULL CHECK(length(raw)>0 AND length(raw)<=2048),PRIMARY KEY(group_id,position),FOREIGN KEY(group_id) REFERENCES local_pool_groups(id) ON DELETE CASCADE);
CREATE TABLE local_pool_removals(ordinal INTEGER PRIMARY KEY AUTOINCREMENT,id BLOB UNIQUE NOT NULL CHECK(length(id)=32),group_id BLOB NOT NULL CHECK(length(group_id)=32),reason TEXT NOT NULL);
CREATE TABLE peer_replay(session_id BLOB PRIMARY KEY,chain_id BLOB NOT NULL,protocol_digest BLOB NOT NULL,peer_id BLOB NOT NULL,profile_digest BLOB NOT NULL,generation INTEGER NOT NULL CHECK(generation>0),highest_ack INTEGER NOT NULL CHECK(highest_ack>=0),pending_nonce INTEGER,pending_digest BLOB,pending_bytes INTEGER, CHECK((pending_nonce IS NULL AND pending_digest IS NULL AND pending_bytes IS NULL) OR (pending_nonce IS NOT NULL AND pending_nonce>0 AND pending_digest IS NOT NULL AND pending_bytes>0)));
CREATE TABLE peer_request_audit(session_id BLOB NOT NULL,nonce INTEGER NOT NULL CHECK(nonce>0),payload_digest BLOB NOT NULL,payload BLOB,response_digest BLOB,response BLOB,status INTEGER NOT NULL CHECK(status IN (0,1,2)),PRIMARY KEY(session_id,nonce),FOREIGN KEY(session_id) REFERENCES peer_replay(session_id));
CREATE TABLE peer_outbox(session_id BLOB PRIMARY KEY,chain_id BLOB NOT NULL,protocol_digest BLOB NOT NULL,peer_id BLOB NOT NULL,profile_digest BLOB NOT NULL,generation INTEGER NOT NULL CHECK(generation>0),highest_ack INTEGER NOT NULL CHECK(highest_ack>=0),pending_nonce INTEGER,pending_digest BLOB,pending_bytes INTEGER,pending_payload BLOB,pending_wire BLOB,pending_wire_digest BLOB,CHECK((pending_nonce IS NULL AND pending_digest IS NULL AND pending_bytes IS NULL AND pending_payload IS NULL AND pending_wire IS NULL AND pending_wire_digest IS NULL) OR (pending_nonce IS NOT NULL AND pending_nonce>0 AND pending_digest IS NOT NULL AND pending_bytes>0 AND pending_payload IS NOT NULL AND pending_wire IS NOT NULL AND pending_wire_digest IS NOT NULL)));";
fn ddl() -> String {
    format!("{}{}", BASE_DDL, crate::ancestry_index::DDL)
}
// The guarded namespace compares cold-open pins inside SQLite. Unknown stored
// BLOB widths are never materialized into an unbounded Rust Vec for this check;
// this is not a bound on SQLite's internal page/schema memory.
fn witness_metadata_matches(db: &Connection, key: &str, expected: Option<&[u8]>) -> Result<bool> {
    let actual: Option<bool> =
        if let Some(value) = expected {
            db.query_row(
            "SELECT typeof(value)='blob' AND length(value)=? AND value=? FROM metadata WHERE key=?",
            params![value.len(), value, key], |row| row.get(0),
        ).optional()?
        } else {
            db.query_row("SELECT 0 FROM metadata WHERE key=?", [key], |row| {
                row.get(0)
            })
            .optional()?
        };
    Ok(actual == expected.map(|_| true))
}
fn bytes32(bytes: Vec<u8>) -> Result<Hash> {
    bytes.try_into().map_err(|_| "STORAGE_HASH".into())
}
fn bytes64(bytes: Vec<u8>) -> Result<[u8; 64]> {
    bytes.try_into().map_err(|_| "STORAGE_WORK".into())
}
// Packet::encode/decode and every settings-selected PQ account packet codec
// enforce this ceiling, including the PQ prefix. GrowthPacket is separate.
// Keep one excess byte so the original decoder/duplicate checks still reject
// oversized local rows; this bounds Rust-owned copies, not SQLite cell memory.
// Preserve empty BLOB and every non-BLOB value, including SQL NULL, so original
// rusqlite conversions and subsequent validation retain their exact ordering.
const STORED_PACKET_SQL: &str = "SELECT
 CASE WHEN typeof(packet)='blob' AND length(packet)>1048576 THEN substr(packet,1,1048577) ELSE packet END AS packet
 FROM blocks WHERE id=?";
// Digest-only owner gates must hash the complete stored packet, including any
// oversized tail. Borrow SQLite's BLOB while hashing rather than copying it into
// a Rust Vec. Using FromSql via row.get preserves the original required-BLOB
// conversion errors, including the column index/name/type for SQL NULL.
// The pure SHA-256 helper runs while the row/statement is alive, rather than
// after query_row has returned an owned copy; it does not reenter SQLite. The
// statement is released normally when query_row returns. This is not a shorter
// lock-lifetime, SQLite-memory or full-hash CPU bound.
struct SqlPacketDigest(String);
impl rusqlite::types::FromSql for SqlPacketDigest {
    fn column_result(value: rusqlite::types::ValueRef<'_>) -> rusqlite::types::FromSqlResult<Self> {
        Ok(Self(crate::operator_task_policy::digest_bytes(
            value.as_blob()?,
        )))
    }
}
// Retain at most one byte beyond a fixed field's expected width. This is a
// copy bound, not validation authority: the original shape check still runs in
// its original order after all SQL conversions. Empty BLOB and SQL NULL remain
// distinct, and non-BLOB values keep rusqlite's original InvalidColumnType.
// SQLite may already have materialized the cell; no page/RSS bound is claimed.
struct FixedSqlBlob<const WIDTH: usize>(Vec<u8>);
impl<const WIDTH: usize> rusqlite::types::FromSql for FixedSqlBlob<WIDTH> {
    fn column_result(value: rusqlite::types::ValueRef<'_>) -> rusqlite::types::FromSqlResult<Self> {
        let bytes = value.as_blob()?;
        let retained = bytes.len().min(WIDTH.saturating_add(1));
        Ok(Self(bytes[..retained].to_vec()))
    }
}
fn fixed_blob<const WIDTH: usize>(
    row: &rusqlite::Row<'_>,
    column: usize,
) -> rusqlite::Result<Vec<u8>> {
    row.get::<_, FixedSqlBlob<WIDTH>>(column)
        .map(|value| value.0)
}
fn optional_fixed_blob<const WIDTH: usize>(
    row: &rusqlite::Row<'_>,
    column: usize,
) -> rusqlite::Result<Option<Vec<u8>>> {
    row.get::<_, Option<FixedSqlBlob<WIDTH>>>(column)
        .map(|value| value.map(|value| value.0))
}

fn canonical<T: Serialize>(value: &T) -> Result<Vec<u8>> {
    Ok(serde_json::to_vec(value)?)
}
pub(crate) type Delta = (String, Option<Vec<u8>>, Option<Vec<u8>>);
type ReorgRow = (Vec<u8>, Vec<u8>, u64, u64, u64);
type Hook<'a> = dyn FnMut(&str) -> Result<()> + 'a;
type ReplayRow = (
    Vec<u8>,
    Vec<u8>,
    Vec<u8>,
    Vec<u8>,
    Vec<u8>,
    u64,
    u64,
    Option<u64>,
    Option<Vec<u8>>,
    Option<u64>,
);
const AUTH_RESPONSE_RETENTION: u64 = 16;
#[cfg(test)]
mod admission_parent_tests;
#[cfg(test)]
mod admission_wire_tests;
mod authenticated_pending_activation;
mod detached_admission;
pub(crate) use detached_admission::{DetachedExecutionLease, PreparedSharedAdmission};
#[cfg(test)]
mod authenticated_replay_tests;

/// Parent authority for one owner operation only. Never retained by Node or proof
/// search; the successor is separately checked by M06 and consume_output.
pub(crate) enum ParentTaskEligibility {
    Legacy,
    ConsensusMaintenance,
    Signed(Box<QualifiedWorkTask>),
    Lifecycle(Box<qualified_task_lifecycle::EligibleLifecycleTask>),
    PqTasksV5(Box<pq_accounts_v2::tasks_v5::EligibleTaskV5>),
}
impl ParentTaskEligibility {
    fn manifest(&self) -> Option<&QualifiedWorkTask> {
        match self {
            Self::Legacy | Self::ConsensusMaintenance => None,
            Self::Signed(manifest) => Some(manifest),
            Self::Lifecycle(eligible) => Some(eligible.manifest()),
            Self::PqTasksV5(eligible) => Some(eligible.manifest()),
        }
    }
}

/// Private result of this admission's complete current-parent validation. It
/// never crosses an owner release, enters a Node cache or grants work/commit
/// authority. The epoch only permits omitting a duplicate read in this call.
struct CheckedAdmissionParent {
    state: State,
    eligibility: ParentTaskEligibility,
    epoch: Option<AdmissionStateEpoch>,
}
#[derive(Clone, Copy, PartialEq, Eq)]
struct AdmissionStateEpoch {
    data_version: u64,
    total_changes: u64,
}
enum CheckedAdmissionContext {
    Existing(Hash),
    Parent(CheckedAdmissionParent),
}
impl CheckedAdmissionContext {
    fn existing(self) -> Option<Hash> {
        match self {
            Self::Existing(id) => Some(id),
            Self::Parent(_) => None,
        }
    }
}

fn json_value(value: String) -> Value {
    Value::String(value)
}
fn record_task_output(
    state: &mut State,
    manifest: &QualifiedWorkTask,
    product: &[u8],
) -> Result<bool> {
    if manifest.purpose == TaskPurpose::Maintenance {
        return Ok(false);
    }
    ensure(product.len() == pon_work::CELLS * 4, "TASK_OUTPUT")?;
    let key = format!("work-output:{}", hex::encode(manifest.output_meter));
    let digest = hex::encode(hash(b"qualified-task-product-v1", &[product]));
    if let Some(prior) = state.get(&key) {
        ensure(
            prior["product"] == digest && prior["arithmetic_output_count"] == 1,
            "TASK_OUTPUT",
        )?;
        Ok(false)
    } else {
        state.insert(key,serde_json::json!({"product":digest,"arithmetic_output_count":1,"matrix_task":hex::encode(manifest.matrix_task),"scope":"source-attested-fixed-contraction-not-model-value"}));
        Ok(true)
    }
}

fn record_eligible_output(
    height: u64,
    state: &mut State,
    eligible: &ParentTaskEligibility,
    product: &[u8],
    cfg: &trnm_mvcc_fee::pon_executor::Config,
) -> Result<bool> {
    match eligible {
        ParentTaskEligibility::PqTasksV5(task) => {
            ensure(product.len() == pon_work::CELLS * 4, "TASK_OUTPUT")?;
            Ok(pq_accounts_v2::tasks_v5::consume_output(
                state,
                task,
                hash(b"qualified-task-product-v1", &[product]),
                height,
                cfg,
            )?)
        }
        ParentTaskEligibility::Lifecycle(task) => {
            ensure(product.len() == pon_work::CELLS * 4, "TASK_OUTPUT")?;
            Ok(qualified_task_lifecycle::consume_output(
                state,
                task,
                hash(b"qualified-task-product-v1", &[product]),
                height,
            )?)
        }
        ParentTaskEligibility::Signed(manifest) => record_task_output(state, manifest, product),
        ParentTaskEligibility::Legacy | ParentTaskEligibility::ConsensusMaintenance => Ok(false),
    }
}

#[derive(Debug)]
pub(crate) enum AuthenticatedReplayDecision {
    Execute,
    Cached(Vec<u8>),
}

struct ReplayRecovery<'a> {
    db: &'a Connection,
}
#[cfg(test)]
thread_local! {
    // Counts real full recovery calls on this test's thread, never retained by
    // the Node and never used as a validity verdict or across a request boundary.
    static REPLAY_RECOVERY_CHECKS: Cell<u64> = const { Cell::new(0) };
}
impl PeerReplayRecoverySourceV0 for ReplayRecovery<'_> {
    type Error = Error;

    fn verify_recovery(&mut self, state: &PeerReplayStateV0) -> Result<()> {
        #[cfg(test)]
        REPLAY_RECOVERY_CHECKS.with(|checks| checks.set(checks.get() + 1));
        let session = state.session().session_id().bytes();
        let completed: u64 = self.db.query_row(
            "SELECT COUNT(*) FROM peer_request_audit WHERE session_id=? AND nonce<=? AND status IN (1,2)",
            params![session.as_slice(), state.highest_acknowledged_nonce()],
            |row| row.get(0),
        )?;
        ensure(
            completed == state.highest_acknowledged_nonce(),
            "AUTH_REPLAY_GAP",
        )?;
        match state.pending() {
            Some(frame) => {
                let row: Option<(Vec<u8>, Option<Vec<u8>>, u64)> = self
                    .db
                    .query_row(
                        "SELECT payload_digest,payload,status FROM peer_request_audit WHERE session_id=? AND nonce=?",
                        params![session.as_slice(), frame.replay_nonce()],
                        |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)),
                    )
                    .optional()?;
                let (digest, payload, status) = row.ok_or("AUTH_PENDING_AUDIT")?;
                ensure(
                    status == 0
                        && bytes32(digest)? == frame.payload_digest().bytes()
                        && payload.as_ref().is_some_and(|v| {
                            v.len() == frame.payload_bytes()
                                && crate::authenticated_payload_digest(v)
                                    == frame.payload_digest().bytes()
                        }),
                    "AUTH_PENDING_AUDIT",
                )?;
            }
            None => {
                let pending: u64 = self.db.query_row(
                    "SELECT COUNT(*) FROM peer_request_audit WHERE session_id=? AND status=0",
                    [session.as_slice()],
                    |row| row.get(0),
                )?;
                ensure(pending == 0, "AUTH_PENDING_AUDIT")?;
            }
        }
        let future: u64 = self.db.query_row(
            "SELECT COUNT(*) FROM peer_request_audit WHERE session_id=? AND nonce>?",
            params![
                session.as_slice(),
                state
                    .pending()
                    .map_or(state.highest_acknowledged_nonce(), |v| v.replay_nonce())
            ],
            |row| row.get(0),
        )?;
        ensure(future == 0, "AUTH_REPLAY_FUTURE")
    }
}

struct ExactFrameSource<'a> {
    payload: &'a [u8],
}
impl PeerFrameSourceV0 for ExactFrameSource<'_> {
    type Error = Error;

    fn verify_frame(
        &mut self,
        _state: PeerReplayStateV0,
        frame: &AuthenticatedPeerFrameV0,
    ) -> Result<()> {
        ensure(
            frame.payload_bytes() == self.payload.len()
                && frame.payload_digest().bytes()
                    == crate::authenticated_payload_digest(self.payload),
            "AUTH_PAYLOAD",
        )
    }
}

struct OutboxRecovery<'a> {
    db: &'a Connection,
}
impl PeerReplayRecoverySourceV0 for OutboxRecovery<'_> {
    type Error = Error;

    fn verify_recovery(&mut self, state: &PeerReplayStateV0) -> Result<()> {
        let session = state.session().session_id().bytes();
        match state.pending() {
            Some(frame) => {
                let row: Option<(Vec<u8>, Vec<u8>, Vec<u8>)> = self
                    .db
                    .query_row(
                        "SELECT pending_payload,pending_wire,pending_wire_digest FROM peer_outbox WHERE session_id=?",
                        [session.as_slice()],
                        |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)),
                    )
                    .optional()?;
                let (payload, wire, wire_digest) = row.ok_or("AUTH_OUTBOX_PENDING")?;
                ensure(
                    payload.len() == frame.payload_bytes()
                        && crate::authenticated_payload_digest(&payload)
                            == frame.payload_digest().bytes()
                        && !wire.is_empty()
                        && wire.len() <= 2 * 1024 * 1024
                        && bytes32(wire_digest)? == hash(b"native-authenticated-wire-v1", &[&wire]),
                    "AUTH_OUTBOX_PENDING",
                )
            }
            None => Ok(()),
        }
    }
}

fn cut(hook: &mut Option<&mut Hook<'_>>, name: &str) -> Result<()> {
    if let Some(h) = hook.as_mut() {
        h(name)?;
    }
    Ok(())
}
fn schema(db: &Connection) -> Result<BTreeMap<String, String>> {
    let mut stmt =
        db.prepare("SELECT type||':'||name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'")?;
    let pairs = stmt.query_map([], |r| Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?)))?;
    let mut out = BTreeMap::new();
    for pair in pairs {
        let (key, text) = pair?;
        out.insert(key, text.split_whitespace().collect::<Vec<_>>().join(" "));
    }
    Ok(out)
}
// Only the new existing-owner path uses this additional constructor boundary.
// It grants no authority and cannot repair or enroll an incomplete namespace.
fn existing_owner_boundary(directory: &Path, identity: (u64, u64), owner: &File) -> Result<()> {
    let current = fs::symlink_metadata(directory)?;
    ensure(
        current.is_dir() && (current.dev(), current.ino()) == identity,
        "NAMESPACE_CHANGED",
    )?;
    let lock = directory.join("owner.lock");
    plain(&lock)?;
    let named = fs::metadata(&lock)?;
    let held = owner.metadata()?;
    ensure(
        (named.dev(), named.ino()) == (held.dev(), held.ino()),
        "OWNER_REPLACED",
    )?;
    match fs::symlink_metadata(directory.join("initializing.json")) {
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error.into()),
        Ok(_) => Err("PQ_EXISTING_OWNER_INITIALIZATION".into()),
    }
}

fn plain(path: &Path) -> Result<()> {
    match fs::symlink_metadata(path) {
        Ok(m) => ensure(
            m.is_file() && !m.file_type().is_symlink() && m.nlink() == 1,
            "NAMESPACE",
        ),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(e) => Err(e.into()),
    }
}
fn read_initialization_marker(path: &Path, expected_len: usize) -> Result<Vec<u8>> {
    // The earlier pathname check is not authority for the descriptor opened
    // here. Refuse symlink substitution and avoid blocking on a replaced FIFO
    // before rechecking the regular-file/single-link requirement on that fd.
    let file = OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK | libc::O_CLOEXEC)
        .open(path)?;
    let metadata = file.metadata()?;
    ensure(metadata.is_file() && metadata.nlink() == 1, "NAMESPACE")?;
    Ok(bounded_initialization_marker_bytes(file, expected_len)?)
}
fn bounded_initialization_marker_bytes(
    reader: impl Read,
    expected_len: usize,
) -> std::io::Result<Vec<u8>> {
    // One excess byte rejects every oversized prefix alias without reading or
    // retaining its tail. Exact canonical equality remains the caller's check;
    // no length metadata, parsed JSON or cached verdict can authorize recovery.
    let mut bytes = Vec::new();
    reader
        .take(expected_len as u64 + 1)
        .read_to_end(&mut bytes)?;
    Ok(bytes)
}

#[cfg(test)]
mod init_marker_tests {
    use super::*;
    use std::io::{self, Cursor};
    use std::process::{Command, Stdio};
    use std::time::Instant;

    fn open(
        directory: &Path,
        settings: &Settings,
        authenticated: bool,
        hook: Option<&mut Hook<'_>>,
    ) -> Result<Node> {
        if authenticated {
            Node::open_with_authenticated_state_and_fault(directory, settings.clone(), 1, hook)
        } else {
            Node::open_with_fault(directory, settings.clone(), 1, hook)
        }
    }

    fn expected_marker(settings: &Settings, authenticated: bool) -> Vec<u8> {
        let backend = if authenticated {
            StateBackend::AuthenticatedV1
        } else {
            StateBackend::Legacy
        };
        canonical(&serde_json::json!({
            "schema": hex::encode(backend.selected_schema_id(settings)),
            "parameters": hex::encode(settings.parameters()),
            "genesis": hex::encode(settings.genesis()),
        }))
        .unwrap()
    }

    struct CountedReader<R> {
        inner: R,
        consumed: usize,
        largest_request: usize,
        interrupt_once: bool,
    }

    impl<R: Read> Read for CountedReader<R> {
        fn read(&mut self, bytes: &mut [u8]) -> io::Result<usize> {
            self.largest_request = self.largest_request.max(bytes.len());
            if std::mem::take(&mut self.interrupt_once) {
                return Err(io::ErrorKind::Interrupted.into());
            }
            let count = self.inner.read(bytes)?;
            self.consumed += count;
            Ok(count)
        }
    }

    struct FailingReader;

    impl Read for FailingReader {
        fn read(&mut self, _: &mut [u8]) -> io::Result<usize> {
            Err(io::Error::new(
                io::ErrorKind::PermissionDenied,
                "initialization marker test read failure",
            ))
        }
    }

    #[test]
    fn initialization_marker_read_is_bounded_and_propagates_io_errors() {
        let expected = b"{\"genesis\":\"fixed\"}";
        // Count actual Read consumption, rather than inferring a bound from
        // refusal. A finite excess tail makes a missing cap fail promptly too.
        let mut reader = CountedReader {
            inner: Cursor::new(expected).chain(io::repeat(0).take(4096)),
            consumed: 0,
            largest_request: 0,
            interrupt_once: false,
        };
        let retained = bounded_initialization_marker_bytes(&mut reader, expected.len()).unwrap();
        assert_eq!(retained.len(), expected.len() + 1);
        assert_eq!(&retained[..expected.len()], expected);
        assert_eq!(reader.consumed, expected.len() + 1);
        assert!(reader.largest_request <= expected.len() + 1);

        let mut interrupted = CountedReader {
            inner: Cursor::new(expected),
            consumed: 0,
            largest_request: 0,
            interrupt_once: true,
        };
        assert_eq!(
            bounded_initialization_marker_bytes(&mut interrupted, expected.len()).unwrap(),
            expected
        );
        assert_eq!(interrupted.consumed, expected.len());
        // A complete-looking prefix does not hide a read error while checking
        // for its excess byte. IO errors are not context mismatches or success.
        let error = bounded_initialization_marker_bytes(
            Cursor::new(expected).chain(FailingReader),
            expected.len(),
        )
        .unwrap_err();
        assert_eq!(error.kind(), io::ErrorKind::PermissionDenied);
        let directory = tempfile::tempdir().unwrap();
        let error = read_initialization_marker(&directory.path().join("missing"), expected.len())
            .unwrap_err();
        assert_eq!(error.kind(), crate::ErrorKind::Transport);
        assert_eq!(
            std::error::Error::source(&error)
                .unwrap()
                .downcast_ref::<io::Error>()
                .unwrap()
                .kind(),
            io::ErrorKind::NotFound
        );
    }

    #[test]
    fn initialization_marker_preserves_exact_context_errors() {
        let settings = Settings::development(Some(1)).unwrap();
        for authenticated in [false, true] {
            let expected = expected_marker(&settings, authenticated);
            for initialized in [false, true] {
                for damage in ["empty", "truncated", "different", "trailing", "oversized"] {
                    let directory = tempfile::tempdir().unwrap();
                    if initialized {
                        drop(open(directory.path(), &settings, authenticated, None).unwrap());
                    } else {
                        let mut stop = |point: &str| {
                            assert_eq!(point, "init-intent");
                            Err("TEST_INIT_INTERRUPTED".into())
                        };
                        let error =
                            open(directory.path(), &settings, authenticated, Some(&mut stop))
                                .err()
                                .expect("the real initialization cut must fail");
                        assert_eq!(error.to_string(), "TEST_INIT_INTERRUPTED");
                    }
                    let marker = directory.path().join("initializing.json");
                    let mut bytes = expected.clone();
                    match damage {
                        "empty" => bytes.clear(),
                        "truncated" => {
                            bytes.pop();
                        }
                        "different" => bytes[0] ^= 1,
                        "trailing" => bytes.push(b'\n'),
                        "oversized" => bytes.push(0),
                        _ => unreachable!(),
                    }
                    fs::write(&marker, &bytes).unwrap();
                    if damage == "oversized" {
                        // A sparse canonical-prefix fixture avoids allocating
                        // the untrusted 64 MiB tail in the test itself.
                        OpenOptions::new()
                            .write(true)
                            .open(&marker)
                            .unwrap()
                            .set_len(64 * 1024 * 1024)
                            .unwrap();
                    }
                    let before = fs::metadata(&marker).unwrap();
                    assert_eq!(
                        read_initialization_marker(&marker, expected.len()).unwrap(),
                        bytes
                    );
                    let dbpath = directory.path().join("native.sqlite");
                    let database_before = initialized.then(|| fs::read(&dbpath).unwrap());
                    let mut cuts = Vec::new();
                    let mut record = |point: &str| {
                        cuts.push(point.to_owned());
                        Ok(())
                    };
                    let error = open(
                        directory.path(),
                        &settings,
                        authenticated,
                        Some(&mut record),
                    )
                    .err()
                    .expect("unequal regular marker bytes must not authorize startup");
                    assert_eq!(error.to_string(), "INITIALIZATION_CONTEXT", "{damage}");
                    assert!(cuts.is_empty());
                    let after = fs::metadata(&marker).unwrap();
                    assert_eq!((before.ino(), before.len()), (after.ino(), after.len()));
                    assert_eq!(
                        database_before,
                        dbpath.exists().then(|| fs::read(&dbpath).unwrap())
                    );
                }
            }
        }
    }

    #[test]
    fn initialization_marker_recovery_and_cold_reopen_preserve_state() {
        let settings = Settings::development(Some(1)).unwrap();
        let other_settings = Settings::development(Some(2)).unwrap();
        let cuts = [
            "init-intent",
            "init-schema",
            "init-before-commit",
            "init-committed",
        ];
        for authenticated in [false, true] {
            for (index, target) in cuts.iter().enumerate() {
                let directory = tempfile::tempdir().unwrap();
                let mut visited = Vec::new();
                let mut stop = |point: &str| {
                    visited.push(point.to_owned());
                    if point == *target {
                        Err("TEST_INIT_INTERRUPTED".into())
                    } else {
                        Ok(())
                    }
                };
                let error = open(directory.path(), &settings, authenticated, Some(&mut stop))
                    .err()
                    .expect("the selected initialization cut must fail");
                assert_eq!(error.to_string(), "TEST_INIT_INTERRUPTED");
                assert_eq!(visited, cuts[..=index]);
                let marker = directory.path().join("initializing.json");
                let expected = expected_marker(&settings, authenticated);
                assert_eq!(fs::read(&marker).unwrap(), expected);
                assert_eq!(
                    read_initialization_marker(&marker, expected.len()).unwrap(),
                    expected
                );
                assert_eq!(
                    open(directory.path(), &other_settings, authenticated, None)
                        .err()
                        .expect("a different context must not recover")
                        .to_string(),
                    "INITIALIZATION_CONTEXT"
                );
                assert_eq!(fs::read(&marker).unwrap(), expected);
                let node = open(directory.path(), &settings, authenticated, None).unwrap();
                let active = node.read_active().unwrap();
                assert_eq!(active, (settings.genesis(), 0, settings.initial.clone()));
                assert_eq!(node.stats().unwrap()["height"], 0);
                assert!(!marker.exists());
                drop(node);
                let mut visited = Vec::new();
                let mut record = |point: &str| {
                    visited.push(point.to_owned());
                    Ok(())
                };
                let node = open(
                    directory.path(),
                    &settings,
                    authenticated,
                    Some(&mut record),
                )
                .unwrap();
                assert_eq!(node.read_active().unwrap(), active);
                assert!(visited.is_empty());
                assert!(!marker.exists());
            }
        }
    }

    fn replace_marker(marker: &Path, retained: &Path, kind: &str) {
        fs::rename(marker, retained).unwrap();
        match kind {
            "fifo" => rustix::fs::mknodat(
                File::open(marker.parent().unwrap()).unwrap(),
                marker.file_name().unwrap(),
                rustix::fs::FileType::Fifo,
                rustix::fs::Mode::RUSR | rustix::fs::Mode::WUSR,
                0,
            )
            .unwrap(),
            "directory" => fs::create_dir(marker).unwrap(),
            "hardlink" => fs::hard_link(retained, marker).unwrap(),
            "symlink" => std::os::unix::fs::symlink(retained, marker).unwrap(),
            _ => unreachable!(),
        }
    }

    fn assert_substitution_error(error: Error, kind: &str) {
        if kind == "symlink" {
            assert_eq!(error.kind(), crate::ErrorKind::Transport);
            assert_eq!(
                std::error::Error::source(&error)
                    .unwrap()
                    .downcast_ref::<io::Error>()
                    .unwrap()
                    .raw_os_error(),
                Some(libc::ELOOP)
            );
        } else {
            assert_eq!(error.to_string(), "NAMESPACE");
        }
    }

    #[test]
    #[ignore = "run only by the bounded subprocess regression"]
    fn initialization_marker_special_file_child() {
        // The parent supplies a private cwd, not global environment variables.
        // All child files remain removable by the parent even after timeout.
        let work = std::env::current_dir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        for authenticated in [false, true] {
            let expected = expected_marker(&settings, authenticated);
            for kind in ["fifo", "directory", "hardlink", "symlink"] {
                for during_startup in [false, true] {
                    println!("special marker: {kind}, authenticated={authenticated}, startup={during_startup}");
                    let fixture = tempfile::tempdir_in(&work).unwrap();
                    let directory = fixture.path().join("store");
                    let marker = directory.join("initializing.json");
                    let retained = fixture.path().join("retained.json");
                    if during_startup {
                        let mut cuts = Vec::new();
                        let mut replace = |point: &str| {
                            cuts.push(point.to_owned());
                            assert_eq!(point, "init-intent");
                            assert_eq!(fs::read(&marker).unwrap(), expected);
                            replace_marker(&marker, &retained, kind);
                            Ok(())
                        };
                        let error = open(&directory, &settings, authenticated, Some(&mut replace))
                            .err()
                            .expect("post-precheck substitution must not authorize startup");
                        assert_substitution_error(error, kind);
                        assert_eq!(cuts, ["init-intent"]);
                    } else {
                        fs::create_dir(&directory).unwrap();
                        fs::write(&marker, &expected).unwrap();
                        plain(&marker).unwrap();
                        replace_marker(&marker, &retained, kind);
                        assert_substitution_error(
                            read_initialization_marker(&marker, expected.len()).unwrap_err(),
                            kind,
                        );
                        // Already-present special files still fail at the
                        // original precheck, before owner locking or SQLite.
                        assert_eq!(
                            open(&directory, &settings, authenticated, None)
                                .err()
                                .expect("a special marker must fail the startup precheck")
                                .to_string(),
                            "NAMESPACE"
                        );
                        assert!(!directory.join("owner.lock").exists());
                    }
                    assert_eq!(fs::read(&retained).unwrap(), expected);
                    assert!(!directory.join("native.sqlite").exists());
                    if kind == "directory" {
                        fs::remove_dir(&marker).unwrap();
                    } else {
                        fs::remove_file(&marker).unwrap();
                    }
                    fs::rename(&retained, &marker).unwrap();
                    let node = open(&directory, &settings, authenticated, None).unwrap();
                    assert_eq!(
                        node.read_active().unwrap(),
                        (settings.genesis(), 0, settings.initial.clone())
                    );
                    assert!(!marker.exists());
                }
            }
        }
        fs::write(
            work.join("child-complete"),
            b"all special-file cases passed",
        )
        .unwrap();
    }

    #[test]
    fn initialization_marker_rejects_special_files_and_post_precheck_substitution() {
        let directory = tempfile::tempdir().unwrap();
        let log_path = directory.path().join("child.log");
        let log = File::create(&log_path).unwrap();
        let mut child = Command::new(std::env::current_exe().unwrap())
            .args([
                "--ignored",
                "--exact",
                "store::init_marker_tests::initialization_marker_special_file_child",
                "--nocapture",
                "--test-threads=1",
            ])
            .current_dir(directory.path())
            .stdout(Stdio::from(log.try_clone().unwrap()))
            .stderr(Stdio::from(log))
            .spawn()
            .unwrap();
        let deadline = Instant::now() + Duration::from_secs(30);
        let status = loop {
            if let Some(status) = child.try_wait().unwrap() {
                break status;
            }
            if Instant::now() >= deadline {
                child.kill().unwrap();
                child.wait().unwrap();
                panic!(
                    "special-file initialization reader timed out: {}",
                    fs::read_to_string(&log_path).unwrap()
                );
            }
            std::thread::sleep(Duration::from_millis(10));
        };
        assert!(
            status.success(),
            "special-file child failed: {}",
            fs::read_to_string(&log_path).unwrap()
        );
        // A zero-test subprocess exit must never masquerade as test success.
        assert_eq!(
            fs::read(directory.path().join("child-complete")).unwrap(),
            b"all special-file cases passed"
        );
    }
}

fn sync_dir(path: &Path) -> Result<()> {
    File::open(path)?.sync_all()?;
    Ok(())
}
#[derive(Clone)]
struct Record {
    parent: Option<Hash>,
    height: u64,
    work: Work,
    root: Hash,
}
// Private native output parts. External callers cannot submit this structure;
// detached callers must return the opaque, single-use execution artifact.
struct AdmissionPersistence {
    packet: Packet,
    bytes: Vec<u8>,
    parent: Record,
    prior: State,
    output: trnm_mvcc_fee::pon_executor::Output,
    commitment: PreparedCommitment,
}
struct StoredHeaderLink {
    header: Header,
    record: Record,
    parent_work: Work,
}
struct HeaderProjection {
    parent: Option<Vec<u8>>,
    height: u64,
    work: Vec<u8>,
    root: Vec<u8>,
    prefix: Option<Vec<u8>>,
    trace: Option<Vec<u8>>,
    length: Option<usize>,
    parent_height: Option<u64>,
    parent_work: Option<Vec<u8>>,
    parent_parent: Option<Vec<u8>>,
    parent_root: Option<Vec<u8>>,
}
impl HeaderProjection {
    fn read(row: &rusqlite::Row<'_>) -> rusqlite::Result<Self> {
        Ok(Self {
            parent: optional_fixed_blob::<32>(row, 0)?,
            height: row.get(1)?,
            work: fixed_blob::<64>(row, 2)?,
            root: fixed_blob::<32>(row, 3)?,
            prefix: row.get(4)?,
            trace: row.get(5)?,
            length: row.get(6)?,
            parent_height: row.get(7)?,
            parent_work: optional_fixed_blob::<64>(row, 8)?,
            parent_parent: optional_fixed_blob::<32>(row, 9)?,
            parent_root: optional_fixed_blob::<32>(row, 10)?,
        })
    }
}
const HISTORY_HEADER_BATCH: u64 = 64;

/// Local SQL projection counters, not a work, state or confirmation certificate.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct HistoryReadCounters {
    pub header_link_queries: u64,
    /// Header and trace bytes returned to Rust; excludes SQLite page reads.
    pub header_trace_bytes: u64,
}
/// Owns the exact packet whose work was actually verified. Not state or clock authority.
/// Private fields prevent replacing the header/body/proof after verification.
pub(crate) struct WorkCheckedPacket {
    packet: Packet,
    work: pon_work::VerifiedWork,
    owner_permit: Option<OwnerPacketPermit>,
}
impl WorkCheckedPacket {
    pub(crate) fn verify_with_facts(
        packet: Packet,
        facts: &pon_work::facts::WorkFactCache,
        progress: &mut impl FnMut(pon_work::VerificationProgress) -> Result<()>,
    ) -> Result<Self> {
        let h = &packet.header;
        let work = facts
            .verify_with_progress(
                h.challenge(),
                h.work_task,
                h.target,
                &packet.proof,
                progress,
            )
            .map_err(|error| match error {
                pon_work::facts::FactError::Relation(error) => {
                    Error::from(format!("WORK:{error:?}"))
                }
                pon_work::facts::FactError::Cancelled(error) => error,
                pon_work::facts::FactError::Unavailable => Error::from("WORK_FACTS_UNAVAILABLE"),
            })?;
        Ok(Self {
            packet,
            work,
            owner_permit: None,
        })
    }
    /// The opt-in arithmetic owner supplies only exact mathematical facts.
    /// Current proof claims are verified before this private packet is created.
    /// No owner permit, task or execution authority is retained in that cache.
    pub(crate) fn verify_with_arithmetic_facts(
        packet: Packet,
        facts: &pon_work::arithmetic_facts::ArithmeticFactCache,
        progress: &mut impl FnMut(pon_work::VerificationProgress) -> Result<()>,
        observation: &mut pon_work::arithmetic_facts::ArithmeticObservation,
    ) -> Result<Self> {
        let h = &packet.header;
        let work = facts
            .verify_with_observation(
                h.challenge(),
                h.work_task,
                h.target,
                &packet.proof,
                progress,
                observation,
            )
            .map_err(|error| match error {
                pon_work::arithmetic_facts::FactError::Relation(error) => {
                    Error::from(format!("WORK:{error:?}"))
                }
                pon_work::arithmetic_facts::FactError::Cancelled(error) => error,
                pon_work::arithmetic_facts::FactError::Unavailable => {
                    Error::from("WORK_ARITHMETIC_FACTS_UNAVAILABLE")
                }
            })?;
        Ok(Self {
            packet,
            work,
            owner_permit: None,
        })
    }
    /// Exact, domain-separated identity of the private fully verified packet.
    /// This is only a local scheduling key; it confers no admission, task or
    /// payment authority. Canonical transaction/proof bytes are all committed.
    pub(crate) fn completion_identity(&self) -> Result<Hash> {
        Ok(hash(
            b"public-v3-complete-work-identity-v1",
            &[&self.packet.encode()?],
        ))
    }
    /// The original History owner supplies its immutable ledger settings after
    /// checking the actual parent. Input bytes cannot select a weaker codec.
    pub(crate) fn completion_identity_for_context(
        &self,
        context: &crate::pq_application_v6::PacketCodecContext,
    ) -> Result<Hash> {
        ensure(
            self.packet.header.network == context.network()
                && self.packet.header.parameters == context.parameters(),
            "CONTEXT",
        )?;
        if !context.is_pq() {
            return self.completion_identity();
        }
        Ok(hash(
            b"public-pq-history-complete-work-identity-v1",
            &[&context.encode(&self.packet)?],
        ))
    }
    pub(crate) fn verify(packet: Packet) -> Result<Self> {
        let h = &packet.header;
        let work = pon_work::verify(h.challenge(), h.work_task, h.target, &packet.proof)
            .map_err(|e| Error::from(format!("WORK:{e:?}")))?;
        Ok(Self {
            packet,
            work,
            owner_permit: None,
        })
    }
    /// Optional exact invalid-mathematics cache. The current Node still
    /// checks context, task, source, clock and owner before this verifier is
    /// selected. Only previously fully verified Transcript/Product failures
    /// can return early; never a VerifiedWork or a consensus-invalidity veto.
    pub(crate) fn verify_with_rejection_cache(
        packet: Packet,
        cache: &pon_work::rejection_cache::RejectionCache,
        progress: &mut impl FnMut(pon_work::VerificationProgress) -> Result<()>,
    ) -> Result<Self> {
        Self::verify_with_rejection_cache_observed(
            packet,
            cache,
            progress,
            &mut pon_work::rejection_cache::RejectionObservation::default(),
        )
    }

    pub(crate) fn verify_with_rejection_cache_observed(
        packet: Packet,
        cache: &pon_work::rejection_cache::RejectionCache,
        progress: &mut impl FnMut(pon_work::VerificationProgress) -> Result<()>,
        observation: &mut pon_work::rejection_cache::RejectionObservation,
    ) -> Result<Self> {
        let h = &packet.header;
        let work = cache
            .verify_with_observation(
                h.challenge(),
                h.work_task,
                h.target,
                &packet.proof,
                progress,
                observation,
            )
            .map_err(|error| match error {
                pon_work::VerificationError::Relation(error) => {
                    Error::from(format!("WORK:{error:?}"))
                }
                pon_work::VerificationError::Cancelled(error) => error,
            })?;
        Ok(Self {
            packet,
            work,
            owner_permit: None,
        })
    }

    pub(crate) fn verify_with_progress(
        packet: Packet,
        progress: &mut impl FnMut(pon_work::VerificationProgress) -> Result<()>,
    ) -> Result<Self> {
        let h = &packet.header;
        let work = pon_work::verify_with_progress(
            h.challenge(),
            h.work_task,
            h.target,
            &packet.proof,
            progress,
        )
        .map_err(|error| match error {
            pon_work::VerificationError::Relation(error) => Error::from(format!("WORK:{error:?}")),
            pon_work::VerificationError::Cancelled(error) => error,
        })?;
        Ok(Self {
            packet,
            work,
            owner_permit: None,
        })
    }
}

fn local_execution_error(error: ExecutionError<Error>) -> Error {
    match error {
        ExecutionError::Relation(error) => error.into(),
        ExecutionError::Cancelled(error) => error,
    }
}

/// Cancellation stages for the complete checked native account proof query.
/// Individual State commitment/hash primitives remain bounded single stages.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NativeAccountProofProgress {
    BeforeRead,
    StateReplay,
    StateVerification,
    Proof(crate::account_archive_prototype::multiproof::MultiproofProgress),
    BeforeOutput,
}

enum NativeAccountProofFailure {
    Archive(crate::account_archive_prototype::ArchiveError),
    Control(Error),
}
impl From<crate::account_archive_prototype::ArchiveError> for NativeAccountProofFailure {
    fn from(error: crate::account_archive_prototype::ArchiveError) -> Self {
        Self::Archive(error)
    }
}
impl NativeAccountProofFailure {
    fn into_error(self) -> Error {
        use crate::account_archive_prototype::ArchiveError;
        match self {
            Self::Control(error) => error,
            Self::Archive(error) => {
                let is_local = matches!(
                    error,
                    ArchiveError::DataUnavailable
                        | ArchiveError::CorruptRecord
                        | ArchiveError::Storage(_)
                );
                let error = Error::from(format!("NATIVE_ACCOUNT_PROOF:{error:?}"));
                if is_local {
                    error.local_integrity()
                } else {
                    error
                }
            }
        }
    }
}

// The same checked successor arithmetic serves singleton and batched reads.
fn next_nonce_from_state(state: &State, sender: Hash) -> Result<u64> {
    let key = format!("account:{}", hex::encode(sender));
    let current = match state.get(&key) {
        None => 0,
        Some(account) => account
            .get("nonce")
            .and_then(serde_json::Value::as_u64)
            .ok_or("STATE_NONCE")?,
    };
    current
        .checked_add(1)
        .ok_or_else(|| "NONCE_OVERFLOW".into())
}

/// One private native namespace; no reference subprocess or remote state setter exists.
pub struct Node {
    db: Connection,
    owner: File,
    // Declared after db/owner so SQLite closes before private files are removed.
    // The guard also retains the existing source namespace's exclusive lock.
    growth_observer_snapshot: Option<growth::observer::Snapshot>,
    directory: PathBuf,
    directory_id: (u64, u64),
    database_id: (u64, u64),
    settings: Settings,
    workers: usize,
    state_backend: StateBackend,
    growth_epoch: Option<growth::Epoch>,
    #[cfg(test)]
    // Research reader's immutable source DDL, never a cached on-disk verdict.
    expected_schema: BTreeMap<String, String>,
    // Immutable source DDL for the existing ordinary authenticated writer.
    // No SQL/schema observation from a prior operation is an authority here.
    post_write_schema: Option<BTreeMap<String, String>>,
    // Separate from authenticated/reorganization graph reuse. This source DDL
    // only nominates ordinary Legacy admission for a fresh same-writer scope.
    legacy_admission_schema: Option<BTreeMap<String, String>>,
    #[cfg(test)]
    // Fault injection only; the production public endpoint always uses1024.
    public_history_test_sql_limit: Option<u64>,
    #[cfg(test)]
    // Explicit per-owner research selection; never a production option.
    pub(crate) public_history_test_snapshot: bool,
    // One derived snapshot only; State always comes from actual KV/snapshot/deltas.
    commitment_cache: RefCell<Option<ActiveCommitment>>,
    // Bounded tree material only. Historical State still comes from all original SQL reads.
    historical_commitment_cache: RefCell<historical_commitment::HistoricalCommitments>,
    // Fixed-size original hash/partition material for full-root fallbacks. Every
    // State and SQL/root check remains fresh, including parents over 8 MiB.
    commitment_root_arithmetic: pon_commitment::FullRootArithmetic,
    // Explicit opt-in only. Never persisted, exported or shared across Node owners.
    root_rejection_cache: RefCell<Option<Box<root_rejection_cache::Cache>>>,
    // Exact-input arithmetic only; never replaces an actual State/node/history
    // read or its comparison. Volatile and bounded within this existing owner.
    authenticated_arithmetic: native_authenticated::ArithmeticCache,
    commitment_observation: RefCell<Option<CommitmentObservation>>,
    history_read_counters: Cell<HistoryReadCounters>,
    history_page_read_counters: Cell<HistoryPageReadCounters>,
    // Opt-in, process-local observation identity/clock. It grants no write,
    // consensus, remote coverage or physical-clock attestation authority.
    native_owner_observer: RefCell<Option<native_owner_observation::OwnerObserver>>,
    owner_policy: Option<OwnerPolicy>,
    mining_owner: Option<operator_mining_owner::MiningOwner>,
    continuous_owner: Option<operator_continuous_owner::ContinuousOwner>,
    // One volatile budget domain per actual open Node owner (continuous uses its
    // already persistent owner CPU). A listener or local work caller may bind
    // exactly once; a different domain cannot replace or reset that binding.
    public_service_cpu: Option<crate::ingress::public_v3::ServiceMutationCpuDomain>,
    // One local active-scope marker in the EXISTING SQLite metadata table.
    // The volatile refcount only tracks concurrently open listeners of this
    // already owner-locked Node; the durable marker survives process exit.
    public_service_epoch_listeners: usize,
    public_service_epoch_unknown: bool,
    // A capacity/identity guard, never a second CPU account or work authority.
    // One detached complete-State execution per original Node incarnation.
    detached_execution: std::sync::Arc<std::sync::atomic::AtomicBool>,
    #[cfg(test)]
    cancel_next_activation_intent: bool,
    pq_network_epoch: std::sync::Arc<std::sync::atomic::AtomicU64>,
    pq_witness: Option<RefCell<crate::pq_rollback_witness::WitnessClient>>,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum StateBackend {
    Legacy,
    AuthenticatedV1,
    PermanentAccountGrowthV2,
    PqNetworkV2,
    PqContinuousV3,
    PqWitnessV4,
}
impl StateBackend {
    fn ddl(self) -> String {
        match self {
            Self::Legacy => ddl(),
            Self::AuthenticatedV1 => format!("{}{}", ddl(), native_authenticated::DDL),
            Self::PermanentAccountGrowthV2 => format!("{}{}", ddl(), growth::DDL),
            Self::PqNetworkV2 | Self::PqContinuousV3 => format!("{}{}", ddl(), pq_network::DDL),
            Self::PqWitnessV4 => {
                format!("{}{}{}", ddl(), pq_network::DDL, pq_rollback_witness::DDL)
            }
        }
    }
    fn selected_schema_id(self, settings: &Settings) -> Hash {
        if growth_profile_v2::enabled(&settings.app) {
            hash(
                b"native-growth-reference-branch-schema-v2",
                &[self.ddl().as_bytes()],
            )
        } else {
            self.schema_id()
        }
    }
    fn schema_id(self) -> Hash {
        let domain: &[u8] = match self {
            Self::Legacy => b"native-branch-schema-v2",
            Self::AuthenticatedV1 => b"native-authenticated-branch-schema-v1",
            Self::PermanentAccountGrowthV2 => b"native-permanent-account-growth-schema-v2",
            Self::PqNetworkV2 => b"native-pq-network-owner-schema-v2",
            Self::PqContinuousV3 => b"native-pq-continuous-owner-schema-v3",
            Self::PqWitnessV4 => b"native-pq-network-witness-schema-v4",
        };
        hash(domain, &[self.ddl().as_bytes()])
    }
}
enum SelectedOpen {
    InitializeOrRecover { observation_only: bool },
    ExistingPqOwner,
}

struct NativeOwners {
    policy: Option<OwnerPolicy>,
    mining: Option<operator_mining_owner::MiningOwner>,
    continuous: Option<operator_continuous_owner::ContinuousOwner>,
    pq_network: Option<Vec<u8>>,
    pq_witness: Option<crate::pq_rollback_witness::WitnessClient>,
}
struct OwnerPolicy {
    pool_policies: Vec<std::sync::Arc<crate::operator_task_policy::pool::VerifiedPoolPolicy>>,
    epoch: std::sync::Arc<std::sync::atomic::AtomicU64>,
    outside_keys: (String, String),
    policy: std::sync::Arc<crate::operator_task_policy::VerifiedPolicy>,
    required_marker: Vec<u8>,
    journal: RefCell<crate::operator_task_policy::Journal>,
    unavailable: std::sync::Arc<std::sync::atomic::AtomicBool>,
}
pub(crate) struct OwnerPacketPermit {
    epoch: std::sync::Arc<std::sync::atomic::AtomicU64>,
    expected_epoch: u64,
    policy: std::sync::Arc<crate::operator_task_policy::VerifiedPolicy>,
    unavailable: std::sync::Arc<std::sync::atomic::AtomicBool>,
    facts: crate::operator_task_policy::NativeFacts,
    reservation: crate::operator_task_policy::Reservation,
}
pub(crate) struct OwnerPoolPermit {
    facts: crate::operator_task_policy::pool::PoolFacts,
    authentication: OwnerPoolAuthentication,
}
enum OwnerPoolAuthentication {
    Legacy {
        policy: std::sync::Arc<crate::operator_task_policy::pool::VerifiedPoolPolicy>,
        unavailable: std::sync::Arc<std::sync::atomic::AtomicBool>,
        epoch: std::sync::Arc<std::sync::atomic::AtomicU64>,
        expected_epoch: u64,
        reservation: crate::operator_task_policy::pool::PoolReservation,
    },
    Continuous(operator_continuous_owner::ContinuousPoolCheckpoint),
}
impl OwnerPoolPermit {
    fn progress(&self) -> Result<()> {
        match &self.authentication {
            OwnerPoolAuthentication::Legacy {
                policy,
                unavailable,
                epoch,
                expected_epoch,
                ..
            } => {
                ensure(
                    !unavailable.load(std::sync::atomic::Ordering::Acquire),
                    "OWNER_TASK_UNAVAILABLE",
                )?;
                ensure(
                    epoch.load(std::sync::atomic::Ordering::Acquire) == *expected_epoch,
                    "OWNER_TASK_VIEW_CHANGED",
                )?;
                policy
                    .check(
                        &self.facts,
                        crate::operator_task_policy::now_ns().map_err(owner_error)?,
                    )
                    .map_err(owner_error)
            }
            OwnerPoolAuthentication::Continuous(checkpoint) => checkpoint.check(),
        }
    }
    fn check_prefix(&self, raws: &[Vec<u8>]) -> Result<()> {
        self.progress()?;
        match &self.authentication {
            OwnerPoolAuthentication::Legacy { policy, .. } => {
                policy.check_prefix_commands(raws).map_err(owner_error)
            }
            OwnerPoolAuthentication::Continuous(checkpoint) => checkpoint.check_prefix(raws),
        }
    }
}
fn owner_marker_present(path: &Path) -> Result<bool> {
    match fs::symlink_metadata(path.join("owner-task-policy.required")) {
        Ok(_) => Ok(true),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(error.into()),
    }
}
fn authenticated_migration_pending(path: &Path) -> Result<bool> {
    match fs::symlink_metadata(path.join("authenticated-migration.pending")) {
        Ok(_) => Ok(true),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(error) => Err(error.into()),
    }
}
fn owner_error(error: crate::operator_task_policy::PolicyError) -> Error {
    Error::from(format!("OWNER_TASK_POLICY:{error:?}"))
}
impl OwnerPacketPermit {
    fn progress(&self) -> Result<()> {
        ensure(
            self.epoch.load(std::sync::atomic::Ordering::Acquire) == self.expected_epoch,
            "OWNER_TASK_VIEW_CHANGED",
        )?;
        ensure(
            !self.unavailable.load(std::sync::atomic::Ordering::Acquire),
            "OWNER_TASK_UNAVAILABLE",
        )?;
        self.policy
            .check(
                &self.facts,
                crate::operator_task_policy::now_ns().map_err(owner_error)?,
            )
            .map_err(owner_error)
    }
}
struct ActiveCommitment {
    tip: Hash,
    generation: u64,
    slot: u64,
    snapshot: CheckedCommitment,
}
#[derive(Clone, Debug)]
pub struct DerivedCommitmentStatus {
    pub cache_root: Option<Hash>,
    pub cache_keys: usize,
    /// Conservative software charge, not process RSS.
    pub software_charge_bytes: usize,
    pub last: Option<CommitmentObservation>,
}
#[derive(Debug, Serialize)]
pub struct Observation {
    pub transaction: String,
    pub genesis: String,
    pub policy: String,
    pub required_work_delta: String,
    pub network: String,
    pub parameters: String,
    pub included_block: String,
    pub observed_tip: String,
    pub included_height: u64,
    pub observed_height: u64,
    pub depth: Option<u64>,
    pub work_delta: Option<String>,
    pub active_generation: u64,
    pub observed_now: u64,
    pub confirmed: bool,
    pub reorged: bool,
    pub finalized: bool,
    pub execution_authority: bool,
}
/// Bounded results under one locally reobserved generation, not a finality certificate.
#[derive(Debug, Serialize)]
pub struct ConfirmationBatch {
    pub observations: Vec<Observation>,
    pub ancestry_checked: u64,
    pub distinct_bodies_checked: usize,
}
impl Node {
    /// An explicitly PQ-only native namespace never serves through a classical
    /// or unauthenticated listener. A build without the optional PQ provider
    /// cannot open its different exact SQLite schema at all.
    pub(crate) fn require_pq_history_transport(&self) -> Result<()> {
        self.namespace()?;
        self.storage_context()?;
        if trnm_mvcc_fee::pon_executor::pq_accounts_v2::enabled(&self.settings.app) {
            ensure(
                matches!(
                    self.state_backend,
                    StateBackend::PqNetworkV2
                        | StateBackend::PqContinuousV3
                        | StateBackend::PqWitnessV4
                ),
                "PQ_NETWORK_BACKEND",
            )?;
        }
        Ok(())
    }
    pub(crate) fn require_classical_network_profile(&self) -> Result<()> {
        ensure(
            !matches!(
                self.state_backend,
                StateBackend::PqNetworkV2
                    | StateBackend::PqContinuousV3
                    | StateBackend::PqWitnessV4
            ),
            "PQ_NETWORK_REQUIRED",
        )?;
        Ok(())
    }
    /// Enable bounded volatile final-ROOT rejection reuse for this Node owner.
    /// Default is off; no CLI/profile/consensus or CPU-budget change is implied.
    /// Repeated calls cannot reset entries, TTL or a failed monotonic clock.
    pub fn enable_local_root_rejection_cache(&mut self) -> Result<()> {
        self.ready()?;
        ensure(
            !growth_profile_v2::enabled(&self.settings.app),
            "GROWTH_REFERENCE_OWNER",
        )?;
        let mut cache = self.root_rejection_cache.borrow_mut();
        if cache.is_none() {
            *cache = Some(Box::default());
        }
        Ok(())
    }
    fn root_rejection_scope(&self, parent: Hash, root: Hash) -> root_rejection_cache::Scope {
        root_rejection_cache::Scope {
            context: hash(
                b"local-m06-final-root-rejection-v1",
                &[
                    &self.settings.network(),
                    &self.settings.parameters(),
                    &self.settings.genesis(),
                    &self.state_backend.selected_schema_id(&self.settings),
                    self.settings.task_profile().as_bytes(),
                ],
            ),
            parent,
            root,
        }
    }
    pub fn open(path: &Path, settings: Settings, workers: usize) -> Result<Self> {
        Self::open_with_fault(path, settings, workers, None)
    }
    pub fn open_with_fault(
        path: &Path,
        settings: Settings,
        workers: usize,
        hook: Option<&mut Hook<'_>>,
    ) -> Result<Self> {
        // The legacy opener is never a fallback for a required-policy namespace.
        ensure(!owner_marker_present(path)?, "OWNER_TASK_POLICY_REQUIRED")?;
        Self::open_inner(path, settings, workers, hook, None, None, None)
    }
    /// Explicit fresh storage namespace. Consensus profiles and header root bytes
    /// are unchanged; complete native state and authenticated account nodes are
    /// now mandatory components of the same persistent Node transaction.
    pub fn open_with_authenticated_state(
        path: &Path,
        settings: Settings,
        workers: usize,
    ) -> Result<Self> {
        Self::open_with_authenticated_state_and_fault(path, settings, workers, None)
    }
    pub fn open_with_authenticated_state_and_fault(
        path: &Path,
        settings: Settings,
        workers: usize,
        hook: Option<&mut Hook<'_>>,
    ) -> Result<Self> {
        ensure(!owner_marker_present(path)?, "OWNER_TASK_POLICY_REQUIRED")?;
        Self::open_selected(
            path,
            settings,
            workers,
            hook,
            NativeOwners {
                policy: None,
                mining: None,
                continuous: None,
                pq_network: None,
                pq_witness: None,
            },
            StateBackend::AuthenticatedV1,
            false,
        )
    }
    /// Explicit local operator policy; neither permissionless nor consensus authority.
    /// Inputs must be supplied from protected operator configuration, not a Request.
    pub fn open_with_operator_task_policy(
        path: &Path,
        settings: Settings,
        workers: usize,
        inputs: crate::operator_task_policy::RestrictedNodeInputs,
    ) -> Result<Self> {
        let policy = crate::operator_task_policy::authenticate(
            &inputs.raw_policy,
            &inputs.authority,
            crate::operator_task_policy::now_ns().map_err(owner_error)?,
        )
        .map_err(owner_error)?;
        ensure(
            policy.context().network == hex::encode(settings.network())
                && policy.context().parameters == hex::encode(settings.parameters()),
            "OWNER_TASK_CONTEXT",
        )?;
        ensure(
            inputs.pool_permissions.len() <= 64,
            "OWNER_POOL_PERMISSION_LIMIT",
        )?;
        let mut pool_policies = Vec::new();
        for permission in &inputs.pool_permissions {
            let verified = crate::operator_task_policy::pool::authenticate_pool(
                permission,
                &inputs.authority,
                &policy,
                crate::operator_task_policy::now_ns().map_err(owner_error)?,
            )
            .map_err(owner_error)?;
            ensure(
                !pool_policies.iter().any(
                    |p: &std::sync::Arc<crate::operator_task_policy::pool::VerifiedPoolPolicy>| {
                        p.same_operation(&verified)
                    },
                ),
                "OWNER_POOL_DUPLICATE_PERMISSION",
            )?;
            pool_policies.push(std::sync::Arc::new(verified));
        }
        crate::operator_task_policy::verify_catalog(&inputs, &policy).map_err(owner_error)?;
        let expected_marker = policy.marker(&inputs.journal_path).map_err(owner_error)?;
        let journal = crate::operator_task_policy::Journal::open(
            &inputs.journal_path,
            inputs.expected_uid,
            &policy,
        )
        .map_err(owner_error)?;
        if !path.try_exists()? {
            fs::create_dir(path)?;
            fs::set_permissions(path, fs::Permissions::from_mode(0o700))?;
        }
        let meta = fs::symlink_metadata(path)?;
        ensure(
            meta.is_dir()
                && !meta.file_type().is_symlink()
                && meta.uid() == inputs.expected_uid
                && meta.mode() & 0o7777 == 0o700,
            "OWNER_TASK_NAMESPACE",
        )?;
        let marker = path.join("owner-task-policy.required");
        if marker.try_exists()? {
            plain(&marker)?;
            let file = OpenOptions::new()
                .read(true)
                .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
                .open(&marker)?;
            let m = file.metadata()?;
            ensure(
                m.is_file()
                    && m.nlink() == 1
                    && m.uid() == inputs.expected_uid
                    && m.mode() & 0o7777 == 0o600
                    && m.len() == expected_marker.len() as u64,
                "OWNER_TASK_NAMESPACE",
            )?;
            let mut bytes = Vec::new();
            std::io::Read::take(file, expected_marker.len() as u64 + 1).read_to_end(&mut bytes)?;
            ensure(bytes == expected_marker, "OWNER_TASK_NAMESPACE")?;
        } else {
            // No silent migration of an already unrestricted or partially initialized store.
            ensure(
                fs::read_dir(path)?.next().is_none(),
                "OWNER_TASK_FRESH_NAMESPACE_REQUIRED",
            )?;
            let mut file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .mode(0o600)
                .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
                .open(&marker)?;
            file.write_all(&expected_marker)?;
            file.sync_all()?;
            sync_dir(path)?;
        }
        let owner = OwnerPolicy {
            pool_policies,
            epoch: std::sync::Arc::new(std::sync::atomic::AtomicU64::new(1)),
            outside_keys: (
                inputs.authority.registry_key.clone(),
                inputs.authority.task_key.clone(),
            ),
            policy: std::sync::Arc::new(policy),
            required_marker: expected_marker,
            journal: RefCell::new(journal),
            unavailable: std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false)),
        };
        Self::open_inner(path, settings, workers, None, Some(owner), None, None)
    }
    fn open_inner(
        path: &Path,
        settings: Settings,
        workers: usize,
        hook: Option<&mut Hook<'_>>,
        owner_policy: Option<OwnerPolicy>,
        mining_owner: Option<operator_mining_owner::MiningOwner>,
        continuous_owner: Option<operator_continuous_owner::ContinuousOwner>,
    ) -> Result<Self> {
        Self::open_selected(
            path,
            settings,
            workers,
            hook,
            NativeOwners {
                policy: owner_policy,
                mining: mining_owner,
                continuous: continuous_owner,
                pq_network: None,
                pq_witness: None,
            },
            StateBackend::Legacy,
            false,
        )
    }
    fn open_selected(
        path: &Path,
        settings: Settings,
        workers: usize,
        hook: Option<&mut Hook<'_>>,
        owners: NativeOwners,
        state_backend: StateBackend,
        observation_only: bool,
    ) -> Result<Self> {
        Self::open_selected_mode(
            path,
            settings,
            workers,
            hook,
            owners,
            state_backend,
            SelectedOpen::InitializeOrRecover { observation_only },
        )
    }

    fn open_selected_mode(
        path: &Path,
        settings: Settings,
        workers: usize,
        mut hook: Option<&mut Hook<'_>>,
        owners: NativeOwners,
        state_backend: StateBackend,
        selection: SelectedOpen,
    ) -> Result<Self> {
        let (observation_only, existing_owner_only) = match selection {
            SelectedOpen::InitializeOrRecover { observation_only } => (observation_only, false),
            SelectedOpen::ExistingPqOwner => (false, true),
        };
        ensure(
            !existing_owner_only
                || matches!(
                    state_backend,
                    StateBackend::PqNetworkV2 | StateBackend::PqWitnessV4
                ),
            "PQ_EXISTING_OWNER_BACKEND",
        )?;
        ensure(
            !authenticated_migration_pending(path)?,
            "NATIVE_STATE_MIGRATION_PENDING",
        )?;
        ensure(
            settings.is_permanent_account_growth_v2()
                == (state_backend == StateBackend::PermanentAccountGrowthV2),
            "GROWTH_PROFILE_BACKEND",
        )?;
        if observation_only {
            ensure(
                matches!(
                    state_backend,
                    StateBackend::Legacy
                        | StateBackend::AuthenticatedV1
                        | StateBackend::PermanentAccountGrowthV2
                ) && path.join("native.sqlite").is_file(),
                "GROWTH_PACKET_STATUS_EXISTING_STORE_REQUIRED",
            )?;
        }
        let NativeOwners {
            policy: owner_policy,
            mining: mining_owner,
            continuous: continuous_owner,
            pq_network,
            pq_witness,
        } = owners;
        if growth_profile_v2::enabled(&settings.app) {
            ensure(
                state_backend == StateBackend::Legacy,
                "GROWTH_REFERENCE_BACKEND",
            )?;
            ensure(
                owner_policy.is_none() && mining_owner.is_none() && continuous_owner.is_none(),
                "GROWTH_REFERENCE_OWNER",
            )?;
        }

        let pq_selected = matches!(
            state_backend,
            StateBackend::PqNetworkV2 | StateBackend::PqContinuousV3 | StateBackend::PqWitnessV4
        );

        ensure(pq_selected == pq_network.is_some(), "PQ_NETWORK_BACKEND")?;
        ensure(
            (state_backend == StateBackend::PqWitnessV4) == pq_witness.is_some(),
            "PQ_WITNESS_BACKEND",
        )?;
        if let Some(client) = pq_witness.as_ref() {
            ensure(
                pq_network
                    .as_deref()
                    .is_some_and(|policy| client.binding().matches_policy(policy)),
                "PQ_WITNESS_POLICY",
            )?;
        }
        ensure(
            !settings.app.is_pq_account_profile() || pq_selected,
            "PQ_ACCOUNT_REQUIRES_PQ_NETWORK_OWNER",
        )?;
        ensure(
            !pq_selected
                || (owner_policy.is_none()
                    && mining_owner.is_none()
                    && match state_backend {
                        StateBackend::PqNetworkV2 | StateBackend::PqWitnessV4 => {
                            continuous_owner.is_none()
                        }
                        StateBackend::PqContinuousV3 => {
                            continuous_owner
                                .as_ref()
                                .is_some_and(|owner| owner.is_pq_startup_owner())
                                && settings.is_native_pq_application_v6()
                        }
                        _ => false,
                    }),
            "PQ_NETWORK_OWNER_COMBINATION",
        )?;

        ensure(
            usize::from(owner_policy.is_some())
                + usize::from(mining_owner.is_some())
                + usize::from(continuous_owner.is_some())
                <= 1,
            "OWNER_MODE_AMBIGUOUS",
        )?;
        let required_owner_marker = owner_policy
            .as_ref()
            .map(|p| p.required_marker.as_slice())
            .or_else(|| mining_owner.as_ref().map(|p| p.marker.as_slice()))
            .or_else(|| continuous_owner.as_ref().map(|p| p.marker.as_slice()));
        ensure([1, 2, 4, 8].contains(&workers), "WORKERS")?;
        settings.replay_checkpoint_tile_material()?;
        if !path.exists() {
            ensure(!existing_owner_only, "PQ_EXISTING_OWNER_REQUIRED")?;
            fs::create_dir_all(path)?;
            fs::set_permissions(path, fs::Permissions::from_mode(0o700))?;
        }
        let metadata = fs::symlink_metadata(path)?;
        ensure(
            metadata.is_dir() && !metadata.file_type().is_symlink(),
            "NAMESPACE",
        )?;
        let directory = path.canonicalize()?;
        let dbpath = directory.join("native.sqlite");
        let marker = directory.join("initializing.json");
        ensure(
            !observation_only || !marker.exists(),
            "GROWTH_OBSERVATION_RECOVERY_REQUIRED",
        )?;
        let lock = directory.join("owner.lock");
        for p in [
            &dbpath,
            &marker,
            &lock,
            &directory.join("native.sqlite-wal"),
            &directory.join("native.sqlite-shm"),
        ] {
            plain(p)?;
        }
        let owner = OpenOptions::new()
            .create(!existing_owner_only)
            .truncate(false)
            .read(true)
            .write(true)
            .mode(0o600)
            .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
            .open(&lock)?;
        owner
            .try_lock_exclusive()
            .map_err(|_| Error::from("WRITER_BUSY"))?;
        if existing_owner_only {
            existing_owner_boundary(&directory, (metadata.dev(), metadata.ino()), &owner)?;
            let current = fs::symlink_metadata(&dbpath)?;
            ensure(
                current.is_file() && !current.file_type().is_symlink() && current.nlink() == 1,
                "PQ_EXISTING_OWNER_REQUIRED",
            )?;
        }
        let ddl = state_backend.ddl();
        let schema_id = state_backend.selected_schema_id(&settings);
        let expected = canonical(
            &serde_json::json!({"schema":hex::encode(schema_id),"parameters":hex::encode(settings.parameters()),"genesis":hex::encode(settings.genesis())}),
        )?;
        if !existing_owner_only && !dbpath.exists() && !marker.exists() {
            for entry in fs::read_dir(&directory)? {
                let name = entry?.file_name();
                ensure(
                    name == "owner.lock"
                        || (required_owner_marker.is_some()
                            && name == "owner-task-policy.required"),
                    "NAMESPACE_NOT_EMPTY",
                )?;
            }
            let mut intent = OpenOptions::new()
                .write(true)
                .create_new(true)
                .mode(0o600)
                .custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC)
                .open(&marker)?;
            intent.write_all(&expected)?;
            intent.sync_all()?;
            sync_dir(&directory)?;
            cut(&mut hook, "init-intent")?;
        }
        let intent = marker.exists();
        ensure(
            !existing_owner_only || !intent,
            "PQ_EXISTING_OWNER_INITIALIZATION",
        )?;
        if intent {
            ensure(
                read_initialization_marker(&marker, expected.len())? == expected,
                "INITIALIZATION_CONTEXT",
            )?;
        }
        let expected_db = Connection::open_in_memory()?;
        expected_db.execute_batch(&ddl)?;
        let expected_schema = schema(&expected_db)?;
        let mut initialized = false;
        let mut prior_inode = None;
        let mut retained_existing = None;
        if dbpath.exists() {
            let m = fs::metadata(&dbpath)?;
            prior_inode = Some((m.dev(), m.ino()));
            if existing_owner_only {
                cut(&mut hook, "existing-owner-before-open")?;
                existing_owner_boundary(&directory, (metadata.dev(), metadata.ino()), &owner)?;
                plain(&dbpath)?;
            }
            // Existing-only validates this very RW connection and retains it;
            // it never probes one connection and later reopens with CREATE.
            let probe = Connection::open_with_flags(
                &dbpath,
                (if existing_owner_only {
                    OpenFlags::SQLITE_OPEN_READ_WRITE
                } else {
                    OpenFlags::SQLITE_OPEN_READ_ONLY
                }) | OpenFlags::SQLITE_OPEN_NO_MUTEX,
            )?;
            let current = schema(&probe)?;
            if current.is_empty() {
                ensure(!existing_owner_only, "PQ_EXISTING_OWNER_INITIALIZED")?;
                ensure(intent, "INITIALIZATION_INTENT_REQUIRED")?;
            } else {
                ensure(current == expected_schema, "SCHEMA")?;
                if state_backend == StateBackend::PqWitnessV4 {
                    ensure(
                        witness_metadata_matches(
                            &probe,
                            "operator_task_policy",
                            required_owner_marker,
                        )?,
                        "OWNER_TASK_POLICY_REQUIRED",
                    )?;
                    ensure(
                        witness_metadata_matches(
                            &probe,
                            "pq_network_owner_v2",
                            pq_network.as_deref(),
                        )?,
                        "PQ_NETWORK_POLICY_REQUIRED",
                    )?;
                } else {
                    let required: Option<Vec<u8>> = probe
                        .query_row(
                            "SELECT value FROM metadata WHERE key='operator_task_policy'",
                            [],
                            |r| r.get(0),
                        )
                        .optional()?;
                    ensure(
                        required.as_deref() == required_owner_marker,
                        "OWNER_TASK_POLICY_REQUIRED",
                    )?;
                    let recorded_pq: Option<Vec<u8>> = probe
                        .query_row(
                            "SELECT value FROM metadata WHERE key='pq_network_owner_v2'",
                            [],
                            |row| row.get(0),
                        )
                        .optional()?;
                    ensure(recorded_pq == pq_network, "PQ_NETWORK_POLICY_REQUIRED")?;
                }
                ensure(
                    witness_metadata_matches(
                        &probe,
                        pq_rollback_witness::KEY,
                        pq_witness
                            .as_ref()
                            .map(|client| client.binding().canonical()),
                    )?,
                    "PQ_WITNESS_BINDING_REQUIRED",
                )?;
                for (key, value) in [
                    ("schema", schema_id),
                    ("parameters", settings.parameters()),
                    ("genesis", settings.genesis()),
                ] {
                    if state_backend == StateBackend::PqWitnessV4 {
                        ensure(
                            witness_metadata_matches(&probe, key, Some(value.as_slice()))?,
                            "STORAGE_CONTEXT",
                        )?;
                    } else {
                        let recorded: Option<Vec<u8>> = probe
                            .query_row("SELECT value FROM metadata WHERE key=?", [key], |r| {
                                r.get(0)
                            })
                            .optional()?;
                        ensure(
                            recorded.as_deref() == Some(value.as_slice()),
                            "STORAGE_CONTEXT",
                        )?;
                    }
                }
                initialized = true;
            }
            if existing_owner_only {
                retained_existing = Some(probe);
                cut(&mut hook, "existing-owner-validated")?;
            }
        }
        if existing_owner_only {
            ensure(
                initialized && retained_existing.is_some(),
                "PQ_EXISTING_OWNER_INITIALIZED",
            )?;
            existing_owner_boundary(&directory, (metadata.dev(), metadata.ino()), &owner)?;
        }
        for p in [
            &dbpath,
            &directory.join("native.sqlite-wal"),
            &directory.join("native.sqlite-shm"),
        ] {
            plain(p)?;
        }
        ensure(
            !observation_only || initialized,
            "GROWTH_PACKET_STATUS_EXISTING_STORE_REQUIRED",
        )?;
        let mut db = if let Some(db) = retained_existing {
            db
        } else if observation_only {
            Connection::open_with_flags(
                &dbpath,
                OpenFlags::SQLITE_OPEN_READ_ONLY | OpenFlags::SQLITE_OPEN_NO_MUTEX,
            )?
        } else {
            Connection::open(&dbpath)?
        };
        let dm = fs::metadata(&dbpath)?;
        if let Some(previous) = prior_inode {
            ensure(previous == (dm.dev(), dm.ino()), "NAMESPACE_CHANGED")?;
        }
        db.busy_timeout(Duration::from_secs(5))?;
        if observation_only {
            db.execute_batch(
                "PRAGMA trusted_schema=OFF; PRAGMA foreign_keys=ON; PRAGMA query_only=ON;",
            )?;
        } else {
            db.execute_batch(
                "PRAGMA trusted_schema=OFF; PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;",
            )?;
        }
        if !initialized {
            ensure(intent, "INITIALIZATION_INTENT_REQUIRED")?;
            let tx = db.transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)?;
            tx.execute_batch(&ddl)?;
            cut(&mut hook, "init-schema")?;
            for (key, value) in [
                ("schema", schema_id),
                ("parameters", settings.parameters()),
                ("genesis", settings.genesis()),
            ] {
                tx.execute(
                    "INSERT INTO metadata VALUES(?,?)",
                    params![key, value.as_slice()],
                )?;
            }
            if let Some(policy) = pq_network.as_deref() {
                tx.execute(
                    "INSERT INTO metadata VALUES('pq_network_owner_v2',?)",
                    [policy],
                )?;
                pq_network::seed(&tx, policy)?;
            }
            if let Some(client) = pq_witness.as_ref() {
                pq_rollback_witness::seed(&tx, client.binding())?;
            }
            if let Some(marker) = required_owner_marker {
                tx.execute(
                    "INSERT INTO metadata VALUES('operator_task_policy',?)",
                    [marker],
                )?;
            }
            tx.execute(
                "INSERT INTO blocks VALUES(?,NULL,0,?,NULL,?)",
                params![
                    settings.genesis.as_slice(),
                    [0u8; 64].as_slice(),
                    if state_backend == StateBackend::PermanentAccountGrowthV2 {
                        growth::initial_root(&settings)?
                    } else {
                        settings.state_root(&settings.initial)?
                    }
                    .as_slice()
                ],
            )?;
            tx.execute(
                "INSERT INTO active VALUES(1,?,0,0)",
                [settings.genesis.as_slice()],
            )?;
            if state_backend != StateBackend::PermanentAccountGrowthV2 {
                for (key, value) in &settings.initial {
                    tx.execute(
                        "INSERT INTO kv VALUES(0,?,?)",
                        params![key, canonical(value)?],
                    )?;
                }
                tx.execute(
                    "INSERT INTO snapshots VALUES(?,?)",
                    params![settings.genesis.as_slice(), canonical(&settings.initial)?],
                )?;
            } else {
                growth::seed(&tx, &settings)?;
            }
            if state_backend == StateBackend::AuthenticatedV1 {
                native_authenticated::seed(&tx, &settings)?;
            }
            cut(&mut hook, "init-before-commit")?;
            tx.commit()?;
            cut(&mut hook, "init-committed")?;
        }
        if intent {
            fs::remove_file(marker)?;
            sync_dir(&directory)?;
        }
        let legacy_admission_schema = (state_backend == StateBackend::Legacy
            && !pq_accounts_v2::enabled(&settings.app)
            && !growth_profile_v2::enabled(&settings.app))
        .then(|| expected_schema.clone());
        let mut node = Self {
            db,
            owner,
            growth_observer_snapshot: None,
            directory,
            directory_id: (metadata.dev(), metadata.ino()),
            database_id: (dm.dev(), dm.ino()),
            settings,
            workers,
            state_backend,
            growth_epoch: None,
            #[cfg(test)]
            expected_schema: expected_schema.clone(),
            post_write_schema: (state_backend == StateBackend::AuthenticatedV1)
                .then_some(expected_schema),
            legacy_admission_schema,
            #[cfg(test)]
            public_history_test_sql_limit: None,
            #[cfg(test)]
            public_history_test_snapshot: false,
            commitment_cache: RefCell::new(None),
            historical_commitment_cache: RefCell::default(),
            commitment_root_arithmetic: pon_commitment::FullRootArithmetic::default(),
            root_rejection_cache: RefCell::new(None),
            authenticated_arithmetic: native_authenticated::ArithmeticCache::default(),
            commitment_observation: RefCell::new(None),
            history_read_counters: Cell::new(HistoryReadCounters::default()),
            history_page_read_counters: Cell::new(HistoryPageReadCounters::default()),
            native_owner_observer: RefCell::new(None),
            owner_policy,
            mining_owner,
            continuous_owner,
            public_service_cpu: None,
            public_service_epoch_listeners: 0,
            public_service_epoch_unknown: false,
            detached_execution: std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false)),
            #[cfg(test)]
            cancel_next_activation_intent: false,
            pq_network_epoch: std::sync::Arc::new(std::sync::atomic::AtomicU64::new(1)),
            pq_witness: pq_witness.map(RefCell::new),
        };
        node.check_pq_witness_open()?;
        if node.state_backend == StateBackend::PermanentAccountGrowthV2 {
            // Complete-State reference budget records cannot be silently ignored
            // by this backend. Validate/refuse them before any growth recovery.
            node.validate_native_budget_records_v1()?;
            node.growth_cold_open(!observation_only)?;
            node.validate_native_task_operation_pins_v1()?;
            node.validate_native_demand_evidence_v1()?;
            // Settings retain the immutable genesis input for exact reopen. Hot
            // execution never clones this bootstrap State or the full account set.
            return Ok(node);
        }
        if observation_only {
            // Cold reconciliation must not finish an owner's unpublished reorg.
            node.ready()?;
        }
        node.read_active()?;
        if node.state_backend == StateBackend::AuthenticatedV1 {
            native_authenticated::verify_history_with_cache(
                &node.db,
                &node.settings,
                node.active()?.0,
                &mut || Ok(()),
                Some(&node.authenticated_arithmetic),
            )?;
        }
        node.validate_authenticated_replay()?;
        node.validate_authenticated_outbox()?;
        node.validate_native_budget_records_v1()?;
        node.validate_native_task_operation_pins_v1()?;
        node.validate_native_demand_evidence_v1()?;
        if observation_only {
            node.check_packet_observation_recovery()?;
        } else {
            node.recover()?;
        }
        node.read_active()?;
        crate::ancestry_index::validate_tip(&node.db, node.ancestry_context()?, node.active()?.0)?;
        Ok(node)
    }
    fn ancestry_context(&self) -> Result<crate::ancestry_index::Context> {
        Ok(crate::ancestry_index::Context {
            packet_profile: if pq_accounts_v2::enabled(&self.settings.app) {
                Some(pq_accounts_v2::account_profile(&self.settings.app)?)
            } else {
                None
            },
            network: self.settings.network(),
            parameters: self.settings.parameters(),
            genesis: self.settings.genesis(),
        })
    }
    pub fn settings(&self) -> &Settings {
        &self.settings
    }
    /// Export a compact point proof from the actual integrated native tree in
    /// one SQLite read snapshot. Supplied reports cannot choose its root or
    /// account bytes. The complete State is still checked before this query.
    pub fn authenticated_account_multiproof(
        &self,
        block: Hash,
        owners: &[Hash],
    ) -> Result<(
        crate::account_archive_prototype::Checkpoint,
        crate::account_archive_prototype::multiproof::Multiproof,
        crate::account_archive_prototype::multiproof::ConstructionObservation,
    )> {
        self.authenticated_account_multiproof_with_progress(block, owners, &|_| Ok(()))
    }
    /// Reject oversized/duplicate requests before storage access, then retain a
    /// single read transaction through full-State replay and proof construction.
    /// Cancellation returns the caller's original error and releases the snapshot.
    pub fn authenticated_account_multiproof_with_progress(
        &self,
        block: Hash,
        owners: &[Hash],
        progress: &(impl Fn(NativeAccountProofProgress) -> Result<()> + ?Sized),
    ) -> Result<(
        crate::account_archive_prototype::Checkpoint,
        crate::account_archive_prototype::multiproof::Multiproof,
        crate::account_archive_prototype::multiproof::ConstructionObservation,
    )> {
        use crate::account_archive_prototype::{multiproof, ArchiveError};
        ensure(
            self.state_backend == StateBackend::AuthenticatedV1,
            "NATIVE_STATE_BACKEND_REQUIRED",
        )?;
        if owners.len() > multiproof::MAX_ACCOUNTS {
            return Err(NativeAccountProofFailure::Archive(ArchiveError::Budget).into_error());
        }
        if owners
            .iter()
            .collect::<std::collections::BTreeSet<_>>()
            .len()
            != owners.len()
        {
            return Err(
                NativeAccountProofFailure::Archive(ArchiveError::InvalidWitness).into_error(),
            );
        }
        progress(NativeAccountProofProgress::BeforeRead)?;
        self.namespace()?;
        let tx = self.db.unchecked_transaction()?;
        let read_changes = tx.total_changes();
        self.storage_context()?;
        let (checkpoint, _) = self.checked_account_query_checkpoint(&tx, block, progress)?;
        let (proof, observation) =
            multiproof::from_native_database(&tx, &checkpoint, owners, &|point| {
                progress(NativeAccountProofProgress::Proof(point))
                    .map_err(NativeAccountProofFailure::Control)
            })
            .map_err(NativeAccountProofFailure::into_error)?;
        progress(NativeAccountProofProgress::BeforeOutput)?;
        // A completed read has no write authority. Count same-connection row
        // writes, including a write that a callback subsequently restores.
        // This is a local ownership fence, not an external-writer attestation.
        if tx.total_changes() != read_changes {
            self.invalidate_commitment();
            return Err(Error::from("NATIVE_ACCOUNT_PROOF_WRITE").local_integrity());
        }
        // Never commit a query transaction (including uncounted schema changes).
        tx.rollback()?;
        Ok((checkpoint, proof, observation))
    }
    fn decode_replay_row(row: ReplayRow) -> Result<PeerReplayStateV0> {
        let chain = IoDigest32V0::new(bytes32(row.0)?)
            .map_err(|e| Error::local_replay_source("AUTH_REPLAY", e))?;
        let protocol = IoDigest32V0::new(bytes32(row.1)?)
            .map_err(|e| Error::local_replay_source("AUTH_REPLAY", e))?;
        let peer = IoDigest32V0::new(bytes32(row.2)?)
            .map_err(|e| Error::local_replay_source("AUTH_REPLAY", e))?;
        let session_id = IoDigest32V0::new(bytes32(row.3)?)
            .map_err(|e| Error::local_replay_source("AUTH_REPLAY", e))?;
        let profile = IoDigest32V0::new(bytes32(row.4)?)
            .map_err(|e| Error::local_replay_source("AUTH_REPLAY", e))?;
        let session = PeerSessionIdentityV0::new(chain, protocol, peer, session_id, profile, row.5)
            .map_err(|e| Error::local_replay_source("AUTH_REPLAY", e))?;
        let pending = match (row.7, row.8, row.9) {
            (None, None, None) => None,
            (Some(nonce), Some(digest), Some(bytes)) => Some(
                AuthenticatedPeerFrameV0::new(
                    session,
                    nonce,
                    IoDigest32V0::new(bytes32(digest)?)
                        .map_err(|e| Error::local_replay_source("AUTH_REPLAY", e))?,
                    usize::try_from(bytes)
                        .map_err(|_| Error::from("AUTH_REPLAY_SIZE").local_integrity())?,
                )
                .map_err(|e| Error::local_replay_source("AUTH_REPLAY", e))?,
            ),
            _ => return Err(Error::from("AUTH_PENDING_AUDIT").local_integrity()),
        };
        PeerReplayStateV0::new(session, row.6, pending)
            .map_err(|e| Error::local_replay_source("AUTH_REPLAY", e))
    }

    fn authenticated_replay_state(
        &self,
        session: PeerSessionIdentityV0,
    ) -> Result<Option<PeerReplayStateV0>> {
        let id = session.session_id().bytes();
        let row = self
            .db
            .query_row(
                "SELECT chain_id,protocol_digest,peer_id,session_id,profile_digest,generation,highest_ack,pending_nonce,pending_digest,pending_bytes FROM peer_replay WHERE session_id=?",
                [id.as_slice()],
                |row| {
                    Ok((
                        row.get(0)?,
                        row.get(1)?,
                        row.get(2)?,
                        row.get(3)?,
                        row.get(4)?,
                        row.get(5)?,
                        row.get(6)?,
                        row.get(7)?,
                        row.get(8)?,
                        row.get(9)?,
                    ))
                },
            )
            .optional()?;
        row.map(Self::decode_replay_row)
            .transpose()
            .and_then(|state| {
                if state.as_ref().is_some_and(|v| v.session() != session) {
                    Err("AUTH_SESSION_COLLISION".into())
                } else {
                    Ok(state)
                }
            })
    }

    fn validate_authenticated_replay(&self) -> Result<()> {
        let mut stmt = self.db.prepare(
            "SELECT chain_id,protocol_digest,peer_id,session_id,profile_digest,generation,highest_ack,pending_nonce,pending_digest,pending_bytes FROM peer_replay ORDER BY session_id",
        )?;
        let rows = stmt
            .query_map([], |row| {
                Ok((
                    row.get(0)?,
                    row.get(1)?,
                    row.get(2)?,
                    row.get(3)?,
                    row.get(4)?,
                    row.get(5)?,
                    row.get(6)?,
                    row.get(7)?,
                    row.get(8)?,
                    row.get(9)?,
                ))
            })?
            .collect::<std::result::Result<Vec<_>, _>>()?;
        drop(stmt);
        for row in rows {
            let state = Self::decode_replay_row(row)?;
            ensure(
                state.session().chain_id().bytes() == self.settings.genesis()
                    && state.session().protocol_digest().bytes() == self.settings.parameters()
                    && state.session().profile_digest().bytes()
                        == crate::authenticated_profile_digest(),
                "AUTH_REPLAY_CONTEXT",
            )
            .map_err(Error::local_integrity)?;
            CandidateP2pAdmissionV0::recover_verified(state, &mut ReplayRecovery { db: &self.db })
                .map_err(|e| Error::local_replay_source("AUTH_RECOVERY", e))?;
        }
        Ok(())
    }

    fn authenticated_outbox_state(
        &self,
        session: PeerSessionIdentityV0,
    ) -> Result<Option<PeerReplayStateV0>> {
        let id = session.session_id().bytes();
        let row = self
            .db
            .query_row(
                "SELECT chain_id,protocol_digest,peer_id,session_id,profile_digest,generation,highest_ack,pending_nonce,pending_digest,pending_bytes FROM peer_outbox WHERE session_id=?",
                [id.as_slice()],
                |row| {
                    Ok((
                        row.get(0)?,
                        row.get(1)?,
                        row.get(2)?,
                        row.get(3)?,
                        row.get(4)?,
                        row.get(5)?,
                        row.get(6)?,
                        row.get(7)?,
                        row.get(8)?,
                        row.get(9)?,
                    ))
                },
            )
            .optional()?;
        row.map(Self::decode_replay_row)
            .transpose()
            .and_then(|state| {
                if state
                    .as_ref()
                    .is_some_and(|value| value.session() != session)
                {
                    Err("AUTH_OUTBOX_SESSION_COLLISION".into())
                } else {
                    Ok(state)
                }
            })
    }

    fn validate_authenticated_outbox(&self) -> Result<()> {
        let mut stmt = self.db.prepare(
            "SELECT chain_id,protocol_digest,peer_id,session_id,profile_digest,generation,highest_ack,pending_nonce,pending_digest,pending_bytes FROM peer_outbox ORDER BY session_id",
        )?;
        let rows = stmt
            .query_map([], |row| {
                Ok((
                    row.get(0)?,
                    row.get(1)?,
                    row.get(2)?,
                    row.get(3)?,
                    row.get(4)?,
                    row.get(5)?,
                    row.get(6)?,
                    row.get(7)?,
                    row.get(8)?,
                    row.get(9)?,
                ))
            })?
            .collect::<std::result::Result<Vec<_>, _>>()?;
        drop(stmt);
        for row in rows {
            let state = Self::decode_replay_row(row)?;
            ensure(
                state.session().chain_id().bytes() == self.settings.genesis()
                    && state.session().protocol_digest().bytes() == self.settings.parameters()
                    && state.session().profile_digest().bytes()
                        == crate::authenticated_profile_digest(),
                "AUTH_OUTBOX_CONTEXT",
            )
            .map_err(Error::local_integrity)?;
            CandidateP2pAdmissionV0::recover_verified(state, &mut OutboxRecovery { db: &self.db })
                .map_err(|error| Error::local_replay_source("AUTH_OUTBOX_RECOVERY", error))?;
        }
        Ok(())
    }

    pub(crate) fn authenticated_outbound_reservation(
        &self,
        session: PeerSessionIdentityV0,
    ) -> Result<(u64, Option<Vec<u8>>)> {
        ensure(
            session.chain_id().bytes() == self.settings.genesis()
                && session.protocol_digest().bytes() == self.settings.parameters()
                && session.profile_digest().bytes() == crate::authenticated_profile_digest(),
            "AUTH_OUTBOX_CONTEXT",
        )?;
        let state = self.authenticated_outbox_state(session)?.unwrap_or(
            PeerReplayStateV0::new(session, 0, None)
                .map_err(|error| Error::peer_admission_source("AUTH_OUTBOX", error))?,
        );
        CandidateP2pAdmissionV0::recover_verified(state, &mut OutboxRecovery { db: &self.db })
            .map_err(|error| Error::local_replay_source("AUTH_OUTBOX_RECOVERY", error))?;
        if let Some(frame) = state.pending() {
            let wire: Vec<u8> = self.db.query_row(
                "SELECT pending_wire FROM peer_outbox WHERE session_id=?",
                [session.session_id().bytes().as_slice()],
                |row| row.get(0),
            )?;
            return Ok((frame.replay_nonce(), Some(wire)));
        }
        Ok((
            state
                .highest_acknowledged_nonce()
                .checked_add(1)
                .ok_or("AUTH_OUTBOX_OVERFLOW")?,
            None,
        ))
    }

    pub(crate) fn reserve_authenticated_outbound(
        &mut self,
        frame: AuthenticatedPeerFrameV0,
        payload: &[u8],
        wire: &[u8],
    ) -> Result<Vec<u8>> {
        self.ready()?;
        self.namespace()?;
        ensure(
            !wire.is_empty() && wire.len() <= 2 * 1024 * 1024,
            "AUTH_OUTBOX_WIRE",
        )?;
        let session = frame.session();
        ensure(
            session.chain_id().bytes() == self.settings.genesis()
                && session.protocol_digest().bytes() == self.settings.parameters()
                && session.profile_digest().bytes() == crate::authenticated_profile_digest(),
            "AUTH_OUTBOX_CONTEXT",
        )?;
        let state = self.authenticated_outbox_state(session)?.unwrap_or(
            PeerReplayStateV0::new(session, 0, None)
                .map_err(|error| Error::peer_admission_source("AUTH_OUTBOX", error))?,
        );
        let mut admission =
            CandidateP2pAdmissionV0::recover_verified(state, &mut OutboxRecovery { db: &self.db })
                .map_err(|error| Error::local_replay_source("AUTH_OUTBOX_RECOVERY", error))?;
        let verified = admission
            .verify_frame(frame, &mut ExactFrameSource { payload })
            .map_err(|error| Error::peer_frame_source("AUTH_OUTBOX_FRAME", error))?;
        admission
            .admit_verified(verified)
            .map_err(|error| Error::peer_admission_source("AUTH_OUTBOX", error))?;
        if state.pending().is_some() {
            let stored: Vec<u8> = self.db.query_row(
                "SELECT pending_wire FROM peer_outbox WHERE session_id=?",
                [session.session_id().bytes().as_slice()],
                |row| row.get(0),
            )?;
            ensure(stored == wire, "AUTH_OUTBOX_CONFLICT")?;
            return Ok(stored);
        }
        let tx = self
            .db
            .transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)?;
        let changed = tx.execute(
            "INSERT INTO peer_outbox(session_id,chain_id,protocol_digest,peer_id,profile_digest,generation,highest_ack,pending_nonce,pending_digest,pending_bytes,pending_payload,pending_wire,pending_wire_digest) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(session_id) DO UPDATE SET pending_nonce=excluded.pending_nonce,pending_digest=excluded.pending_digest,pending_bytes=excluded.pending_bytes,pending_payload=excluded.pending_payload,pending_wire=excluded.pending_wire,pending_wire_digest=excluded.pending_wire_digest",
            params![
                session.session_id().bytes().as_slice(),
                session.chain_id().bytes().as_slice(),
                session.protocol_digest().bytes().as_slice(),
                session.peer_id().bytes().as_slice(),
                session.profile_digest().bytes().as_slice(),
                session.generation(),
                state.highest_acknowledged_nonce(),
                frame.replay_nonce(),
                frame.payload_digest().bytes().as_slice(),
                frame.payload_bytes() as u64,
                payload,
                wire,
                hash(b"native-authenticated-wire-v1", &[wire]).as_slice(),
            ],
        )?;
        ensure(changed == 1, "AUTH_OUTBOX_STATE").map_err(Error::local_integrity)?;
        tx.commit()?;
        Ok(wire.to_vec())
    }

    pub(crate) fn finish_authenticated_outbound(
        &mut self,
        frame: AuthenticatedPeerFrameV0,
    ) -> Result<()> {
        let state = self
            .authenticated_outbox_state(frame.session())?
            .ok_or("AUTH_OUTBOX_STATE")?;
        if state.highest_acknowledged_nonce() >= frame.replay_nonce() {
            return Ok(());
        }
        let mut admission =
            CandidateP2pAdmissionV0::recover_verified(state, &mut OutboxRecovery { db: &self.db })
                .map_err(|error| Error::local_replay_source("AUTH_OUTBOX_RECOVERY", error))?;
        let next = admission
            .acknowledge(frame)
            .map_err(|error| Error::peer_admission_source("AUTH_OUTBOX", error))?;
        let tx = self
            .db
            .transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)?;
        let changed = tx.execute(
            "UPDATE peer_outbox SET highest_ack=?,pending_nonce=NULL,pending_digest=NULL,pending_bytes=NULL,pending_payload=NULL,pending_wire=NULL,pending_wire_digest=NULL WHERE session_id=? AND pending_nonce=? AND pending_digest=?",
            params![
                next.highest_acknowledged_nonce(),
                frame.session().session_id().bytes().as_slice(),
                frame.replay_nonce(),
                frame.payload_digest().bytes().as_slice(),
            ],
        )?;
        ensure(changed == 1, "AUTH_OUTBOX_STATE").map_err(Error::local_integrity)?;
        tx.commit()?;
        Ok(())
    }

    pub(crate) fn begin_authenticated_request(
        &mut self,
        frame: AuthenticatedPeerFrameV0,
        payload: &[u8],
    ) -> Result<AuthenticatedReplayDecision> {
        self.ready()?;
        self.namespace()?;
        let session = frame.session();
        ensure(
            session.chain_id().bytes() == self.settings.genesis()
                && session.protocol_digest().bytes() == self.settings.parameters()
                && session.profile_digest().bytes() == crate::authenticated_profile_digest()
                && session.generation() <= i64::MAX as u64
                && frame.replay_nonce() <= i64::MAX as u64,
            "AUTH_REPLAY_CONTEXT",
        )?;
        let existing = self.authenticated_replay_state(session)?;
        let state = existing.unwrap_or(
            PeerReplayStateV0::new(session, 0, None)
                .map_err(|e| Error::peer_admission_source("AUTH_REPLAY", e))?,
        );
        // Keep this checked admission only within this &mut Node operation.
        // No intervening write or dispatch changes its recovered SQL facts.
        // finish_authenticated_request independently recovers after dispatch.
        let mut admission =
            CandidateP2pAdmissionV0::recover_verified(state, &mut ReplayRecovery { db: &self.db })
                .map_err(|e| Error::local_replay_source("AUTH_RECOVERY", e))?;
        let session_id = session.session_id().bytes();
        if frame.replay_nonce() <= state.highest_acknowledged_nonce() {
            let audit: Option<(Vec<u8>, u64, Option<Vec<u8>>)> = self
                .db
                .query_row(
                    "SELECT payload_digest,status,response FROM peer_request_audit WHERE session_id=? AND nonce=?",
                    params![session_id.as_slice(), frame.replay_nonce()],
                    |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)),
                )
                .optional()?;
            let (digest, status, response) =
                audit.ok_or_else(|| Error::from("AUTH_REPLAY_GAP").local_integrity())?;
            ensure(
                bytes32(digest)? == frame.payload_digest().bytes(),
                "AUTH_CONFLICTING_REPLAY",
            )?;
            return match (status, response) {
                (1, Some(bytes)) => Ok(AuthenticatedReplayDecision::Cached(bytes)),
                (2, None) => Err("AUTH_REPLAY_RETIRED".into()),
                _ => Err(Error::from("AUTH_REPLAY_AUDIT").local_integrity()),
            };
        }
        let verified = admission
            .verify_frame(frame, &mut ExactFrameSource { payload })
            .map_err(|e| Error::peer_frame_source("AUTH_FRAME", e))?;
        admission
            .admit_verified(verified)
            .map_err(|e| Error::peer_admission_source("AUTH_REPLAY", e))?;
        if state.pending().is_some() {
            return Ok(AuthenticatedReplayDecision::Execute);
        }
        let tx = self
            .db
            .transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)?;
        let changed = tx.execute(
            "INSERT INTO peer_replay(session_id,chain_id,protocol_digest,peer_id,profile_digest,generation,highest_ack,pending_nonce,pending_digest,pending_bytes) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(session_id) DO UPDATE SET pending_nonce=excluded.pending_nonce,pending_digest=excluded.pending_digest,pending_bytes=excluded.pending_bytes",
            params![
                session_id.as_slice(),
                session.chain_id().bytes().as_slice(),
                session.protocol_digest().bytes().as_slice(),
                session.peer_id().bytes().as_slice(),
                session.profile_digest().bytes().as_slice(),
                session.generation(),
                state.highest_acknowledged_nonce(),
                frame.replay_nonce(),
                frame.payload_digest().bytes().as_slice(),
                frame.payload_bytes() as u64,
            ],
        )?;
        ensure(changed == 1, "AUTH_REPLAY_STATE").map_err(Error::local_integrity)?;
        let changed = tx.execute(
            "INSERT INTO peer_request_audit(session_id,nonce,payload_digest,payload,response_digest,response,status) VALUES(?,?,?,?,NULL,NULL,0)",
            params![
                session_id.as_slice(),
                frame.replay_nonce(),
                frame.payload_digest().bytes().as_slice(),
                payload,
            ],
        )?;
        ensure(changed == 1, "AUTH_REPLAY_AUDIT").map_err(Error::local_integrity)?;
        tx.commit()?;
        Ok(AuthenticatedReplayDecision::Execute)
    }

    pub(crate) fn finish_authenticated_request(
        &mut self,
        frame: AuthenticatedPeerFrameV0,
        response: &[u8],
    ) -> Result<()> {
        ensure(
            !response.is_empty() && response.len() <= 2 * 1024 * 1024,
            "AUTH_RESPONSE",
        )?;
        let state = self
            .authenticated_replay_state(frame.session())?
            .ok_or("AUTH_REPLAY_STATE")?;
        // Re-read and fully recover here even if begin succeeded: dispatch and
        // lost-ACK/restart recovery are separate mutable-owner operations.
        // Only the second identical recovery inside this call is redundant.
        let mut admission =
            CandidateP2pAdmissionV0::recover_verified(state, &mut ReplayRecovery { db: &self.db })
                .map_err(|e| Error::local_replay_source("AUTH_RECOVERY", e))?;
        let session = frame.session().session_id().bytes();
        let response_digest = hash(b"native-authenticated-response-v1", &[response]);
        if state.highest_acknowledged_nonce() >= frame.replay_nonce() {
            let audit: Option<(Vec<u8>, u64, Option<Vec<u8>>)> = self
                .db
                .query_row(
                    "SELECT response_digest,status,response FROM peer_request_audit WHERE session_id=? AND nonce=?",
                    params![session.as_slice(), frame.replay_nonce()],
                    |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?)),
                )
                .optional()?;
            let (digest, status, retained) =
                audit.ok_or_else(|| Error::from("AUTH_REPLAY_GAP").local_integrity())?;
            ensure(
                bytes32(digest)? == response_digest,
                "AUTH_RESPONSE_CONFLICT",
            )?;
            ensure(
                (status == 1 && retained.as_deref() == Some(response))
                    || (status == 2 && retained.is_none()),
                "AUTH_RESPONSE_CONFLICT",
            )?;
            return Ok(());
        }
        let next = admission
            .acknowledge(frame)
            .map_err(|e| Error::peer_admission_source("AUTH_REPLAY", e))?;
        let tx = self
            .db
            .transaction_with_behavior(rusqlite::TransactionBehavior::Immediate)?;
        let changed = tx.execute(
            "UPDATE peer_request_audit SET payload=NULL,response_digest=?,response=?,status=1 WHERE session_id=? AND nonce=? AND status=0 AND payload_digest=?",
            params![
                response_digest.as_slice(),
                response,
                session.as_slice(),
                frame.replay_nonce(),
                frame.payload_digest().bytes().as_slice(),
            ],
        )?;
        ensure(changed == 1, "AUTH_REPLAY_AUDIT").map_err(Error::local_integrity)?;
        let changed = tx.execute(
            "UPDATE peer_replay SET highest_ack=?,pending_nonce=NULL,pending_digest=NULL,pending_bytes=NULL WHERE session_id=?",
            params![next.highest_acknowledged_nonce(), session.as_slice()],
        )?;
        ensure(changed == 1, "AUTH_REPLAY_STATE").map_err(Error::local_integrity)?;
        let retire = next
            .highest_acknowledged_nonce()
            .saturating_sub(AUTH_RESPONSE_RETENTION);
        if retire > 0 {
            tx.execute(
                "UPDATE peer_request_audit SET response=NULL,status=2 WHERE session_id=? AND nonce<=? AND status=1",
                params![session.as_slice(), retire],
            )?;
        }
        tx.commit()?;
        Ok(())
    }

    pub(crate) fn authenticated_outbox_counts(&self) -> Result<(u64, u64)> {
        Ok((
            self.db
                .query_row("SELECT COUNT(*) FROM peer_outbox", [], |row| row.get(0))?,
            self.db.query_row(
                "SELECT COUNT(*) FROM peer_outbox WHERE pending_nonce IS NOT NULL",
                [],
                |row| row.get(0),
            )?,
        ))
    }

    pub(crate) fn authenticated_replay_counts(&self) -> Result<(u64, u64, u64)> {
        Ok((
            self.db
                .query_row("SELECT COUNT(*) FROM peer_replay", [], |row| row.get(0))?,
            self.db.query_row(
                "SELECT COUNT(*) FROM peer_replay WHERE pending_nonce IS NOT NULL",
                [],
                |row| row.get(0),
            )?,
            self.db
                .query_row("SELECT COUNT(*) FROM peer_request_audit", [], |row| {
                    row.get(0)
                })?,
        ))
    }
    fn namespace(&self) -> Result<()> {
        if let Some(snapshot) = &self.growth_observer_snapshot {
            snapshot.check()?;
        }
        ensure(
            !authenticated_migration_pending(&self.directory)?,
            "NATIVE_STATE_MIGRATION_PENDING",
        )?;
        let meta = fs::symlink_metadata(&self.directory)?;
        ensure(
            meta.is_dir() && (meta.dev(), meta.ino()) == self.directory_id,
            "NAMESPACE_CHANGED",
        )?;
        for name in [
            "native.sqlite",
            "native.sqlite-wal",
            "native.sqlite-shm",
            "owner.lock",
        ] {
            plain(&self.directory.join(name))?;
        }
        let dm = fs::metadata(self.directory.join("native.sqlite"))?;
        ensure(
            (dm.dev(), dm.ino()) == self.database_id,
            "DATABASE_REPLACED",
        )?;
        let actual = fs::metadata(self.directory.join("owner.lock"))?;
        let held = self.owner.metadata()?;
        ensure(
            (actual.dev(), actual.ino()) == (held.dev(), held.ino()),
            "OWNER_REPLACED",
        )
    }
    fn storage_context(&self) -> Result<()> {
        for (key, expected) in [
            (
                "schema",
                self.state_backend.selected_schema_id(&self.settings),
            ),
            ("parameters", self.settings.parameters()),
            ("genesis", self.settings.genesis()),
        ] {
            let actual: Option<Vec<u8>> = self
                .db
                .prepare_cached("SELECT value FROM metadata WHERE key=?")?
                .query_row([key], |row| fixed_blob::<32>(row, 0))
                .optional()?;
            ensure(
                actual.as_deref() == Some(expected.as_slice()),
                "STORAGE_CONTEXT",
            )
            .map_err(Error::local_integrity)?;
        }
        Ok(())
    }
    #[cfg(test)]
    fn check_persisted_state_with_readback(
        &self,
        id: Hash,
        state: &State,
        progress: &mut dyn FnMut() -> Result<()>,
        readback: Option<&mut native_authenticated::PostWriteReadback<'_>>,
    ) -> Result<()> {
        self.check_persisted_state_with_root_arithmetic(id, state, progress, readback, None)
    }
    fn check_persisted_state_with_root_arithmetic(
        &self,
        id: Hash,
        state: &State,
        progress: &mut dyn FnMut() -> Result<()>,
        readback: Option<&mut native_authenticated::PostWriteReadback<'_>>,
        arithmetic: Option<&pon_commitment::FullRootArithmetic>,
    ) -> Result<()> {
        let record = self.record(id).map_err(Error::local_integrity)?;
        continuity_v1::check_state(state, record.height, &self.settings.app)
            .map_err(|error| Error::from(error).local_integrity())?;
        // The native complete-state commitment may already contain this exact
        // full root. Compare all current State bytes before arithmetic reuse;
        // a miss retains the original root calculation and error order. Actual
        // SQL State, record, account graph and history checks still follow.
        let actual_root = if self.state_backend == StateBackend::AuthenticatedV1 {
            self.authenticated_arithmetic
                .state_root(&self.settings, state)?
        } else if let Some(arithmetic) = arithmetic {
            arithmetic.root(state)?
        } else {
            self.settings.state_root(state)?
        };
        ensure(actual_root == record.root, "ROOT").map_err(Error::local_integrity)?;
        if self.state_backend == StateBackend::AuthenticatedV1 {
            native_authenticated::verify_state_with_readback(
                &self.db,
                &self.settings,
                id,
                state,
                progress,
                Some(&self.authenticated_arithmetic),
                readback,
            )?;
        }
        Ok(())
    }
    /// Legacy reorganization and the final admission fence share bounded
    /// complete-State root arithmetic. Every caller still reads actual SQL rows
    /// and checks continuity, canonical grammar and the fresh stored root at its
    /// original boundary. PQ State grammar and the distinct Growth root keep
    /// their original paths; profile and backend exclusion remain explicit.
    fn legacy_persisted_root_arithmetic(&self) -> Option<&pon_commitment::FullRootArithmetic> {
        (self.state_backend == StateBackend::Legacy
            && !pq_accounts_v2::enabled(&self.settings.app)
            && !growth_profile_v2::enabled(&self.settings.app))
        .then_some(&self.commitment_root_arithmetic)
    }
    /// Check actual data after the last transactional write. A post-COMMIT
    /// observation cannot repair a suppressed write or a trigger-corrupted slot.
    #[cfg(test)]
    fn check_active_before_commit(&self) -> Result<()> {
        self.check_active_before_commit_with_progress(&mut || Ok(()))
    }
    fn check_active_before_commit_with_progress(
        &self,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<()> {
        self.check_active_before_commit_with_readback(progress, None)
    }
    fn check_active_before_commit_with_readback(
        &self,
        progress: &mut dyn FnMut() -> Result<()>,
        readback: Option<&mut native_authenticated::PostWriteReadback<'_>>,
    ) -> Result<()> {
        self.check_active_before_commit_with_root_arithmetic(progress, readback, None)
    }
    fn check_active_before_commit_with_root_arithmetic(
        &self,
        progress: &mut dyn FnMut() -> Result<()>,
        readback: Option<&mut native_authenticated::PostWriteReadback<'_>>,
        arithmetic: Option<&pon_commitment::FullRootArithmetic>,
    ) -> Result<()> {
        self.check_active_before_commit_with_root_role(progress, readback, arithmetic, false)
    }
    fn check_active_before_commit_with_root_role(
        &self,
        progress: &mut dyn FnMut() -> Result<()>,
        mut readback: Option<&mut native_authenticated::PostWriteReadback<'_>>,
        arithmetic: Option<&pon_commitment::FullRootArithmetic>,
        preserve_staging: bool,
    ) -> Result<()> {
        progress()?;
        self.namespace()?;
        self.storage_context()?;
        let count: u64 = self
            .db
            .prepare_cached("SELECT COUNT(*) FROM active")?
            .query_row([], |row| row.get(0))?;
        ensure(count == 1, "GENERATION").map_err(Error::local_integrity)?;
        let selected = self.active()?;
        let slot = self.slot()?;
        let state = self.slot_state_with_progress(slot, progress)?;
        if let Some(scope) = readback.as_deref_mut() {
            scope.nominate_active(&self.db, selected.0)?;
        }
        // During initial full-history activation, the still-published genesis
        // State alternates with staging State. Do not evict staging's bounded
        // pure arithmetic with that small, unrelated active input. All rows and
        // the root are still checked by the original complete-root algorithm.
        // Other active tips and every non-reorg caller keep their old policy.
        let arithmetic = if preserve_staging && selected.0 == self.settings.genesis() {
            None
        } else {
            arithmetic
        };
        self.check_persisted_state_with_root_arithmetic(
            selected.0,
            &state,
            progress,
            readback.as_deref_mut(),
            arithmetic,
        )?;
        crate::ancestry_index::validate_tip(&self.db, self.ancestry_context()?, selected.0)
            .map_err(Error::local_integrity)?;
        if self.state_backend == StateBackend::AuthenticatedV1 {
            native_authenticated::verify_history_with_readback(
                &self.db,
                &self.settings,
                selected.0,
                progress,
                Some(&self.authenticated_arithmetic),
                readback.as_deref_mut(),
            )?;
        }
        ensure(
            self.active()? == selected && self.slot()? == slot,
            "GENERATION",
        )
        .map_err(Error::local_integrity)?;
        if let Some(scope) = readback {
            scope.validate_consumed(&self.db)?;
        }
        Ok(())
    }
    fn record(&self, id: Hash) -> Result<Record> {
        let row = self
            .db
            .prepare_cached("SELECT parent,height,chainwork,state_root FROM blocks WHERE id=?")?
            .query_row([id.as_slice()], |r| {
                Ok((
                    optional_fixed_blob::<32>(r, 0)?,
                    r.get::<_, u64>(1)?,
                    fixed_blob::<64>(r, 2)?,
                    fixed_blob::<32>(r, 3)?,
                ))
            })
            .optional()?
            .ok_or("UNKNOWN_PARENT")?;
        Ok(Record {
            parent: row.0.map(bytes32).transpose()?,
            height: row.1,
            work: Work::from_bytes(bytes64(row.2)?),
            root: bytes32(row.3)?,
        })
    }
    pub fn active(&self) -> Result<(Hash, u64)> {
        let (tip, g) = self
            .db
            .prepare_cached("SELECT tip,generation FROM active WHERE singleton=1")?
            .query_row([], |r| Ok((fixed_blob::<32>(r, 0)?, r.get::<_, u64>(1)?)))?;
        Ok((bytes32(tip)?, g))
    }
    pub fn next_nonce(&self, sender: Hash) -> Result<u64> {
        if self.state_backend == StateBackend::PermanentAccountGrowthV2 {
            return self
                .growth_account(self.active()?.0, sender)?
                .map_or(0, |a| a.nonce)
                .checked_add(1)
                .ok_or_else(|| "NONCE_OVERFLOW".into());
        }
        let state = self.state_at(self.active()?.0)?;
        next_nonce_from_state(&state, sender)
    }
    /// Read up to 256 distinct senders from ONE fully checked SQLite snapshot.
    /// Results preserve input order and reserve no nonce or execution authority.
    /// The legacy singleton path is unchanged; no successful verdict survives a call.
    /// Growth binds all requested owners to the snapshot's active account root.
    pub fn next_nonces(&self, senders: &[Hash]) -> Result<Vec<u64>> {
        ensure((1..=256).contains(&senders.len()), "NONCE_QUERY_LIMIT")?;
        let unique: std::collections::BTreeSet<_> = senders.iter().collect();
        ensure(unique.len() == senders.len(), "DUPLICATE_NONCE_QUERY")?;
        if self.state_backend == StateBackend::PermanentAccountGrowthV2 {
            return self.growth_next_nonces(senders);
        }
        self.namespace()?;
        let tx = self.db.unchecked_transaction()?;
        self.storage_context()?;
        let state = self.state_at(self.active()?.0)?;
        let values = senders
            .iter()
            .map(|sender| next_nonce_from_state(&state, *sender))
            .collect::<Result<Vec<_>>>()?;
        tx.rollback()?;
        Ok(values)
    }
    fn slot(&self) -> Result<u64> {
        Ok(self
            .db
            .prepare_cached("SELECT state_slot FROM active WHERE singleton=1")?
            .query_row([], |r| r.get(0))?)
    }
    fn slot_state(&self, slot: u64) -> Result<State> {
        self.slot_state_with_progress(slot, &mut || Ok(()))
    }
    fn slot_state_with_progress(
        &self,
        slot: u64,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<State> {
        progress()?;
        // Validate stored dimensions before copying a cell into Rust. SQL types
        // are retained: TEXT is not a value BLOB, and a BLOB is not a key TEXT.
        // Cache only the compiled statement in the connection's existing
        // bounded cache. Every call still opens a new query, reads all actual
        // rows, and repeats the original dimensions/canonical/root checks.
        // No State, row, snapshot or validation verdict survives this call.
        let mut stmt = self.db.prepare_cached(
            "SELECT CASE WHEN typeof(key)='text' THEN CAST(substr(CAST(key AS BLOB),1,161) AS TEXT) ELSE key END,
             CASE WHEN typeof(value)='blob' THEN substr(value,1,4097) ELSE value END,
             length(CAST(key AS BLOB)),length(CAST(value AS BLOB))
             FROM kv WHERE slot=? ORDER BY kv.key",
        ).map_err(|error| Error::from(error).local_integrity())?;
        let mut rows = stmt
            .query([slot])
            .map_err(|error| Error::from(error).local_integrity())?;
        let mut state = State::new();
        let mut canonical_bytes = Vec::new();
        let mut previous_key = [0_u8; 160];
        let mut previous_key_len = None;
        while let Some(row) = rows
            .next()
            .map_err(|error| Error::from(error).local_integrity())?
        {
            if state.len().is_multiple_of(256) {
                progress()?;
            }
            let key: String = (|| -> Result<_> {
                let key_len: i64 = row.get(2)?;
                let value_len: i64 = row.get(3)?;
                ensure(
                    state.len()
                        < if growth_profile_v2::enabled(&self.settings.app) {
                            growth_profile_v2::MAX_TOTAL_KEYS
                        } else {
                            65_536
                        }
                        && (0..=160).contains(&key_len)
                        && (0..=4096).contains(&value_len),
                    "STATE_BYTES",
                )?;
                Ok(row.get(0)?)
            })()
            .map_err(Error::local_integrity)?;
            // The bounded SQL BLOB remains borrowed until this row advances.
            // Decoded State owns its data; no SQLite borrow escapes this scope.
            let cell = row
                .get_ref(1)
                .map_err(|error| Error::from(error).local_integrity())?;
            let bytes = cell.as_blob().map_err(|_| {
                Error::from(rusqlite::Error::InvalidColumnType(
                    1,
                    "value".into(),
                    cell.data_type(),
                ))
                .local_integrity()
            })?;
            // Reuse only the pure bytes-to-Value decoding of the previous
            // successful row in THIS complete scan. SQL types and dimensions
            // above still apply to the current row, and full current BLOB
            // equality is required. The local State owns the prior value;
            // no SQLite borrow, State verdict or fact survives this call.
            let decoded = previous_key_len
                .filter(|_| canonical_bytes.as_slice() == bytes)
                .and_then(|len| std::str::from_utf8(&previous_key[..len]).ok())
                .and_then(|prior| state.get(prior))
                .cloned();
            let value = if let Some(value) = decoded {
                value
            } else {
                let value: Value = serde_json::from_slice(bytes)
                    .map_err(|error| Error::from(error).local_integrity())?;
                canonical_bytes.clear();
                serde_json::to_writer(&mut canonical_bytes, &value)
                    .map_err(|error| Error::from(error).local_integrity())?;
                ensure(canonical_bytes == bytes, "STATE_BYTES").map_err(Error::local_integrity)?;
                value
            };
            // A fixed key buffer adds no per-row allocation. Exact map lookup
            // also preserves the old decoder under repeated keys or unusual
            // SQL ordering; this is never a claim that such a schema is valid.
            let next_previous_key_len = previous_key.get_mut(..key.len()).map(|prior| {
                prior.copy_from_slice(key.as_bytes());
                key.len()
            });
            state.insert(key, value);
            previous_key_len = next_previous_key_len;
        }
        progress()?;
        Ok(state)
    }
    fn invalidate_commitment(&self) {
        *self.commitment_cache.borrow_mut() = None;
        self.historical_commitment_cache.borrow_mut().clear();
    }
    /// Local calculation observation only, never a state/confirmation authority.
    pub fn derived_commitment_status(&self) -> DerivedCommitmentStatus {
        let cache = self.commitment_cache.borrow();
        DerivedCommitmentStatus {
            cache_root: cache.as_ref().map(|c| c.snapshot.root()),
            cache_keys: cache.as_ref().map_or(0, |c| c.snapshot.keys()),
            software_charge_bytes: cache
                .as_ref()
                .map_or(0, |c| c.snapshot.retained_charge_bytes()),
            last: self.commitment_observation.borrow().clone(),
        }
    }
    fn checked_commitment(
        &self,
        actual: &State,
        expected: Hash,
        prior: Option<&CheckedCommitment>,
    ) -> Result<PreparedCommitment> {
        let result = if growth_profile_v2::enabled(&self.settings.app) {
            pon_commitment::growth_reference_snapshot(actual, Some(expected), &self.settings.app)
        } else {
            pon_commitment::checked_snapshot_with_arithmetic(
                actual,
                expected,
                prior,
                CacheLimits::default(),
                &self.commitment_root_arithmetic,
            )
        };
        match result {
            Ok(prepared) => {
                if self.state_backend == StateBackend::AuthenticatedV1 {
                    self.authenticated_arithmetic
                        .offer_root_material(&self.settings, prepared.snapshot.as_ref());
                }
                *self.commitment_observation.borrow_mut() = Some(prepared.observation.clone());
                Ok(prepared)
            }
            Err("COMMITMENT_ROOT") => {
                self.invalidate_commitment();
                Err(Error::from("ROOT").local_integrity())
            }
            Err(error) => Err(Error::from(error).local_integrity()),
        }
    }
    fn cached_parent(&self, parent: Hash) -> Result<Option<CheckedCommitment>> {
        let (tip, generation) = self.active()?;
        let slot = self.slot()?;
        Ok(self
            .commitment_cache
            .borrow()
            .as_ref()
            .filter(|cache| {
                parent == tip
                    && cache.tip == tip
                    && cache.generation == generation
                    && cache.slot == slot
            })
            .map(|cache| cache.snapshot.clone()))
    }
    fn publish_commitment(
        &self,
        tip: Hash,
        generation: u64,
        slot: u64,
        prepared: PreparedCommitment,
    ) {
        *self.commitment_observation.borrow_mut() = Some(prepared.observation);
        *self.commitment_cache.borrow_mut() = prepared.snapshot.map(|snapshot| ActiveCommitment {
            tip,
            generation,
            slot,
            snapshot,
        });
    }
    // Keep the native execution entrypoint source-visible for independent
    // repository/evidence contract checks, but pass the already-typed request
    // rather than re-expanding its fields into an eight-argument wrapper.
    fn execute_derived(
        &self,
        actual: &State,
        block: ExecutionRequest<'_>,
    ) -> Result<trnm_mvcc_fee::pon_commitment::StagedOutput> {
        self.execute_derived_with_progress(actual, block, &|_| Ok(()))
    }
    fn execute_derived_with_progress(
        &self,
        actual: &State,
        block: ExecutionRequest<'_>,
        progress: &(impl Fn(ExecutionProgress) -> Result<()> + Sync),
    ) -> Result<trnm_mvcc_fee::pon_commitment::StagedOutput> {
        self.execute_derived_with_control(actual, block, &ExecutionControl::new(progress, &()))
    }
    fn execute_derived_with_control(
        &self,
        actual: &State,
        block: ExecutionRequest<'_>,
        control: &ExecutionControl<'_, Error>,
    ) -> Result<trnm_mvcc_fee::pon_commitment::StagedOutput> {
        self.owner_preview_available()?;
        self.execute_derived_core(actual, block, control, None)
    }
    fn execute_derived_core(
        &self,
        actual: &State,
        block: ExecutionRequest<'_>,
        control: &ExecutionControl<'_, Error>,
        owner_permit: Option<&OwnerPacketPermit>,
    ) -> Result<trnm_mvcc_fee::pon_commitment::StagedOutput> {
        self.execute_derived_core_with_rejection(actual, block, control, owner_permit, None)
            .map(|(output, _)| output)
    }
    fn execute_derived_core_with_rejection(
        &self,
        actual: &State,
        block: ExecutionRequest<'_>,
        control: &ExecutionControl<'_, Error>,
        owner_permit: Option<&OwnerPacketPermit>,
        exact_packet: Option<(&Header, &[u8])>,
    ) -> Result<(
        trnm_mvcc_fee::pon_commitment::StagedOutput,
        Option<root_rejection_cache::Scope>,
    )> {
        let _measurement = (self.state_backend == StateBackend::AuthenticatedV1).then(|| {
            self.authenticated_arithmetic
                .history
                .observe(native_authenticated::HistoryStage::Execute)
        });
        ensure(
            self.owner_policy.is_some() == owner_permit.is_some(),
            "OWNER_TASK_PERMIT_REQUIRED",
        )?;
        if let Some(permit) = owner_permit {
            permit.progress()?;
        }
        self.continuous_execution_gate(&block)?;
        self.mining_execution_gate(&block)?;
        let mining_progress = self.mining_progress_snapshot()?;
        let continuous_progress = self.continuous_progress_snapshot()?;
        let guarded_mining_progress = |point| -> Result<()> {
            (control.progress)(point)?;
            if let Some(p) = &continuous_progress {
                p.check()?;
            }
            if let Some(p) = &mining_progress {
                p.check()?;
            }
            Ok(())
        };
        let mining_control =
            ExecutionControl::new(&guarded_mining_progress, control.worker_accounting);
        let control = &mining_control;
        let progress = control.progress;
        progress(ExecutionProgress::BeforeParentBinding)?;
        let parent = block.parent_id;
        let parent_measurement = (self.state_backend == StateBackend::AuthenticatedV1).then(|| {
            self.authenticated_arithmetic
                .history
                .observe(native_authenticated::HistoryStage::ExecutionParentBinding)
        });
        let active_prior = self.cached_parent(parent)?;
        let current_root = self.record(parent)?.root;
        // Ordinary history import may execute several admitted parents before
        // activating the page tip. Full state_at already offered their bounded
        // opaque arithmetic, but an inactive parent cannot use the active slot.
        // The fresh SQL root above is only an index: check_and_bind still
        // canonically compares every actual State key/value and verifies its
        // computed root. An incoming header root or stored validity is no answer.
        // The ordinary Legacy History receiver uses the same complete replay
        // and opaque checked arithmetic. It must not rebuild an already read
        // inactive parent's tree solely because its storage backend differs.
        // This selects calculation material only; all actual State bytes and
        // the freshly read root still enter check_and_bind below.
        let historical_prior = (matches!(
            self.state_backend,
            StateBackend::Legacy | StateBackend::AuthenticatedV1
        ) && active_prior.is_none())
        .then(|| {
            self.historical_commitment_cache
                .try_borrow()
                .ok()
                .and_then(|cache| cache.candidate(parent, current_root))
        })
        .flatten();
        // Always encode/compare the actual supplied parent with its admitted root.
        // Missing/refused/wrong material retains the original complete fallback.
        if growth_profile_v2::enabled(&self.settings.app) {
            let result = pon_commitment::execute_growth_reference_with_control(
                actual,
                current_root,
                block,
                &self.settings.app,
                control,
            )
            .map_err(local_execution_error)?;
            *self.commitment_observation.borrow_mut() = Some(result.commitment.observation.clone());
            return Ok((result, None));
        }
        let (bound, observation) =
            pon_commitment::CheckedExecutionParent::check_and_bind_with_arithmetic(
                actual,
                current_root,
                active_prior.as_ref().or(historical_prior.as_ref()),
                CacheLimits::default(),
                &self.commitment_root_arithmetic,
            )
            .map_err(|error| {
                if error == "COMMITMENT_ROOT" {
                    self.invalidate_commitment();
                    Error::from("ROOT").local_integrity()
                } else {
                    Error::from(error).local_integrity()
                }
            })?;
        if self.state_backend == StateBackend::AuthenticatedV1 {
            self.authenticated_arithmetic.history.parent_binding(
                active_prior.is_some(),
                historical_prior.is_some(),
                observation.method,
            );
        }
        drop(parent_measurement);
        *self.commitment_observation.borrow_mut() = Some(observation);
        let request = || ExecutionRequest {
            timestamp: block.timestamp,
            transactions: block.transactions,
            height: block.height,
            miner: block.miner,
            parent_id: parent,
            workers: block.workers,
        };
        // Preserve the second original cancellation boundary without rebinding
        // and rehashing the same immutable, already-checked parent state.
        progress(ExecutionProgress::BeforeParentBinding)?;
        // Work, current eligibility, complete State/root/account graph, owner
        // gates and both original cancellation boundaries have all run afresh.
        // Only the deterministic M06/output portion may be omitted on a hit.
        let rejection = exact_packet
            .filter(|_| self.root_rejection_cache.borrow().is_some())
            .map(|(header, bytes)| {
                (
                    header,
                    bytes,
                    self.root_rejection_scope(parent, current_root),
                )
            });
        if let Some((header, bytes, scope)) = rejection {
            let rejects = self
                .root_rejection_cache
                .borrow_mut()
                .as_mut()
                .is_some_and(|cache| {
                    cache.rejects(scope, bytes, header, root_rejection_cache::now_ns())
                });
            if rejects {
                progress(ExecutionProgress::BeforeOutput)?;
                return Err("ROOT".into());
            }
        }
        let result = bound.execute_with_control(request(), &self.settings.app, control);
        match result {
            Ok(output) => {
                *self.commitment_observation.borrow_mut() =
                    Some(output.commitment.observation.clone());
                Ok((output, rejection.map(|(_, _, scope)| scope)))
            }
            Err(ExecutionError::Relation("COMMITMENT_PARENT" | "COMMITMENT_ROOT")) => {
                // A wrong internal snapshot cannot reject an otherwise valid
                // ledger state; the full actual-root path still checks context.
                self.invalidate_commitment();
                pon_commitment::execute_checked_with_control(
                    actual,
                    self.record(parent)?.root,
                    None,
                    request(),
                    &self.settings.app,
                    CacheLimits::default(),
                    control,
                )
                .map_err(local_execution_error)
                .map(|output| (output, rejection.map(|(_, _, scope)| scope)))
            }
            Err(error) => Err(local_execution_error(error)),
        }
    }
    fn derive_successor(
        &self,
        actual: &State,
        prior: Option<&CheckedCommitment>,
    ) -> Result<PreparedCommitment> {
        let prepared = if growth_profile_v2::enabled(&self.settings.app) {
            pon_commitment::growth_reference_snapshot(actual, None, &self.settings.app)?
        } else {
            pon_commitment::derive_snapshot_with_arithmetic(
                actual,
                prior,
                CacheLimits::default(),
                &self.commitment_root_arithmetic,
            )?
        };
        *self.commitment_observation.borrow_mut() = Some(prepared.observation.clone());
        Ok(prepared)
    }
    pub fn read_active(&self) -> Result<(Hash, u64, State)> {
        ensure(
            self.state_backend != StateBackend::PermanentAccountGrowthV2,
            "GROWTH_COMPLETE_STATE_UNAVAILABLE",
        )?;
        self.read_active_with_progress(&mut || Ok(()))
    }
    /// Rechecks actual KV bytes and root, with cancellation at most 256 rows apart.
    /// Root arithmetic is still bounded by the state limit and checked as one stage.
    pub fn read_active_with_progress(
        &self,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<(Hash, u64, State)> {
        self.read_active_with_readback(progress, None)
    }
    fn read_active_with_readback(
        &self,
        progress: &mut dyn FnMut() -> Result<()>,
        mut readback: Option<&mut native_authenticated::PostWriteReadback<'_>>,
    ) -> Result<(Hash, u64, State)> {
        ensure(
            self.state_backend != StateBackend::PermanentAccountGrowthV2,
            "GROWTH_COMPLETE_STATE_UNAVAILABLE",
        )?;
        let _measurement = (self.state_backend == StateBackend::AuthenticatedV1).then(|| {
            self.authenticated_arithmetic
                .history
                .observe(native_authenticated::HistoryStage::ReadActive)
        });
        progress()?;
        self.namespace()?;
        let (tip, generation) = self.active()?;
        let slot = self.slot()?;
        let state = self.slot_state_with_progress(slot, progress)?;
        continuity_v1::check_state(
            &state,
            self.record(tip).map_err(Error::local_integrity)?.height,
            &self.settings.app,
        )
        .map_err(|error| Error::from(error).local_integrity())?;
        let prior = self.cached_parent(tip)?;
        progress()?;
        let prepared = self.checked_commitment(
            &state,
            self.record(tip).map_err(Error::local_integrity)?.root,
            prior.as_ref(),
        )?;
        if self.state_backend == StateBackend::AuthenticatedV1 {
            if let Some(scope) = readback.as_deref_mut() {
                scope.nominate_active(&self.db, tip)?;
            }
            native_authenticated::verify_state_with_readback(
                &self.db,
                &self.settings,
                tip,
                &state,
                progress,
                Some(&self.authenticated_arithmetic),
                readback.as_deref_mut(),
            )?;
        }
        progress()?;
        ensure(
            self.active()? == (tip, generation) && self.slot()? == slot,
            "STALE_VIEW",
        )?;
        if let Some(scope) = readback {
            scope.validate_consumed(&self.db)?;
        }
        self.publish_commitment(tip, generation, slot, prepared);
        Ok((tip, generation, state))
    }
    fn ready(&self) -> Result<()> {
        self.namespace()?;
        let done: Option<u64> = self
            .db
            .query_row("SELECT done FROM reorg WHERE singleton=1", [], |r| r.get(0))
            .optional()?;
        ensure(done != Some(0), "REORG_IN_PROGRESS")?;
        if done == Some(2) {
            self.check_cancelled_reorg_lifecycle()?;
        }
        ensure(done.is_none_or(|value| value <= 2), "REORG_STEPS").map_err(Error::local_integrity)
    }
    pub fn packet(&self, id: Hash) -> Result<Packet> {
        let row = self.record(id)?;
        let raw: Option<Vec<u8>> = self
            .db
            .query_row(STORED_PACKET_SQL, [id.as_slice()], |r| r.get(0))?;
        let raw = raw.ok_or_else(|| {
            let error = Error::from("GENESIS_HAS_NO_PACKET");
            if id == self.settings.genesis() {
                error
            } else {
                error.local_integrity()
            }
        })?;
        let packet =
            Packet::decode_for_settings(&raw, &self.settings).map_err(Error::local_integrity)?;
        ensure(
            packet.id()? == id
                && Some(packet.header.parent) == row.parent
                && packet.header.height == row.height
                && packet.header.state == row.root,
            "STORAGE_PACKET",
        )?;
        Ok(packet)
    }
    /// Reuses only a prepared SQL statement, never a previous clock or ancestry verdict.
    /// The JOIN checks the parent in the same SQLite statement as the bounded header.
    fn stored_header_link(&self, id: Hash) -> Result<StoredHeaderLink> {
        let mut statement = self.db.prepare_cached(
            "SELECT b.parent,b.height,b.chainwork,b.state_root,substr(b.packet,1,?),
             substr(b.packet,-32),length(b.packet),p.height,p.chainwork,p.parent,p.state_root
             FROM blocks b LEFT JOIN blocks p ON p.id=b.parent WHERE b.id=?",
        )?;
        self.count_header_query();
        let projection = statement
            .query_row(
                params![self.settings.packet_header_length(), id.as_slice()],
                HeaderProjection::read,
            )
            .optional()?
            .ok_or("UNKNOWN_PARENT")?;
        self.check_header_projection(id, projection)
    }
    fn count_header_query(&self) {
        let mut counters = self.history_read_counters.get();
        counters.header_link_queries = counters.header_link_queries.saturating_add(1);
        self.history_read_counters.set(counters);
    }
    fn check_header_projection(
        &self,
        id: Hash,
        projection: HeaderProjection,
    ) -> Result<StoredHeaderLink> {
        // A projection exists only after the SQL owner found the requested row.
        // All failures below describe retained local data, not a new peer packet.
        (|| {
            let row = Record {
                parent: projection.parent.map(bytes32).transpose()?,
                height: projection.height,
                work: Work::from_bytes(bytes64(projection.work)?),
                root: bytes32(projection.root)?,
            };
            ensure(
                (self.settings.packet_header_length() + 2 + pon_work::PROOF_BYTES..=1_048_576)
                    .contains(&projection.length.ok_or("GENESIS_HAS_NO_PACKET")?),
                "PACKET_LIMIT",
            )?;
            let prefix = projection.prefix.ok_or("GENESIS_HAS_NO_PACKET")?;
            let trace = projection.trace.ok_or("GENESIS_HAS_NO_PACKET")?;
            let mut counters = self.history_read_counters.get();
            counters.header_trace_bytes = counters
                .header_trace_bytes
                .saturating_add((prefix.len() + trace.len()) as u64);
            self.history_read_counters.set(counters);
            let header = self.settings.decode_packet_header(&prefix)?;
            let trace = bytes32(trace)?;
            ensure(
                header.block_id(trace) == id
                    && Some(header.parent) == row.parent
                    && header.height == row.height
                    && header.state == row.root,
                "STORAGE_PACKET",
            )?;
            ensure(
                projection
                    .parent_height
                    .ok_or("UNKNOWN_PARENT")?
                    .checked_add(1)
                    == Some(row.height),
                "ANCESTRY_HEIGHT",
            )?;
            let parent_work =
                Work::from_bytes(bytes64(projection.parent_work.ok_or("UNKNOWN_PARENT")?)?);
            // Preserve the complete parent-record shape checks, including at genesis
            // where the ancestry loop stops without reading another header.
            let _ = projection.parent_parent.map(bytes32).transpose()?;
            let _ = bytes32(projection.parent_root.ok_or("UNKNOWN_PARENT")?)?;
            Ok(StoredHeaderLink {
                header,
                record: row,
                parent_work,
            })
        })()
        .map_err(Error::local_integrity)
    }
    /// A bounded read of actual rows, with the same ordered per-link checks as a
    /// single projection. No successful verdict or ancestry list survives the call.
    /// LIMIT bounds even corrupt cycles; ORDER BY makes validation order explicit.
    fn visit_header_batch(
        &self,
        start: Hash,
        visit: &mut impl FnMut(Hash, StoredHeaderLink) -> Result<()>,
    ) -> Result<(Hash, u64)> {
        self.visit_header_batch_limited(start, HISTORY_HEADER_BATCH, visit)
    }
    /// A caller may shorten a batch, but cannot read beyond the existing bound.
    /// Recent-target walks use their exact remaining window; full-history walks
    /// retain the original batch size and current observed-clock checks.
    fn visit_header_batch_limited(
        &self,
        start: Hash,
        maximum: u64,
        visit: &mut impl FnMut(Hash, StoredHeaderLink) -> Result<()>,
    ) -> Result<(Hash, u64)> {
        ensure(
            (1..=HISTORY_HEADER_BATCH).contains(&maximum),
            "ANCESTRY_LIMIT",
        )?;
        if start == self.settings.genesis() {
            return Ok((start, 0));
        }
        let mut statement = self.db.prepare_cached(
            "WITH RECURSIVE ancestry(id,parent,ordinal) AS (
                 SELECT id,parent,0 FROM blocks WHERE id=?1 AND id!=?2
                 UNION ALL
                 SELECT b.id,b.parent,a.ordinal+1
                 FROM ancestry a JOIN blocks b ON b.id=a.parent
                 WHERE b.id!=?2 LIMIT ?3
             )
             SELECT b.parent,b.height,b.chainwork,b.state_root,substr(b.packet,1,?4),
                 substr(b.packet,-32),length(b.packet),p.height,p.chainwork,p.parent,
                 p.state_root,b.id,a.ordinal
             FROM ancestry a JOIN blocks b ON b.id=a.id
             LEFT JOIN blocks p ON p.id=b.parent ORDER BY a.ordinal",
        )?;
        self.count_header_query();
        let mut rows = statement.query(params![
            start.as_slice(),
            self.settings.genesis().as_slice(),
            maximum,
            self.settings.packet_header_length(),
        ])?;
        let mut current = start;
        let mut checked = 0_u64;
        while let Some(row) = rows.next()? {
            let id = bytes32(row.get(11)?)?;
            ensure(
                checked < maximum && row.get::<_, u64>(12)? == checked && id == current,
                "ANCESTRY_HEIGHT",
            )
            .map_err(Error::local_integrity)?;
            let link = self.check_header_projection(id, HeaderProjection::read(row)?)?;
            current = link.header.parent;
            visit(id, link)?;
            checked = checked.checked_add(1).ok_or("ANCESTRY_LIMIT")?;
        }
        let complete = ensure(
            checked == maximum || current == self.settings.genesis(),
            "UNKNOWN_PARENT",
        );
        // An absent caller locator is stale context. Once a retained row was
        // observed, a missing internal ancestor is a local integrity failure.
        if checked == 0 {
            complete?;
        } else {
            complete.map_err(Error::local_integrity)?;
        }
        Ok((current, checked))
    }
    /// Reads only the committed header and trace of an already admitted local block.
    /// This does not verify new work or replace inclusion-body validation.
    fn stored_header(&self, id: Hash) -> Result<Header> {
        Ok(self.stored_header_link(id)?.header)
    }
    pub fn history_read_counters(&self) -> HistoryReadCounters {
        self.history_read_counters.get()
    }
    /// Explicit local diagnostics only; no validation, cache or budget is enabled.
    /// Repeated calls never reset counters. Other backends retain their profile.
    pub fn enable_native_legacy_reorg_observation(&self) -> bool {
        if self.state_backend != StateBackend::Legacy {
            return false;
        }
        self.authenticated_arithmetic
            .history
            .enable_legacy_reorg_observation();
        true
    }
    fn native_legacy_reorg_observation_enabled(&self) -> bool {
        self.state_backend == StateBackend::Legacy
            && self
                .authenticated_arithmetic
                .history
                .legacy_reorg_observation_enabled()
    }
    fn legacy_reorg_step_observation_enabled(
        &self,
        site: native_authenticated::SqlCommitSite,
    ) -> bool {
        self.native_legacy_reorg_observation_enabled()
            && matches!(site, native_authenticated::SqlCommitSite::ReorgStep)
    }
    /// Local cumulative diagnostics only. No SQL, native validation, CPU credit,
    /// clock verdict or durable fact is supplied by these nested observations.
    pub fn native_history_arithmetic_observation(&self) -> Value {
        if self.native_legacy_reorg_observation_enabled() {
            self.authenticated_arithmetic
                .history
                .legacy_reorg_observation()
        } else {
            self.authenticated_arithmetic.observation()
        }
    }

    fn parent(&self, id: Hash) -> Result<Hash> {
        let row = self.record(id)?;
        let parent = row
            .parent
            .ok_or_else(|| Error::from("UNKNOWN_PARENT").local_integrity())?;
        ensure(
            self.record(parent)
                .map_err(Error::local_integrity)?
                .height
                .checked_add(1)
                == Some(row.height),
            "ANCESTRY_HEIGHT",
        )
        .map_err(Error::local_integrity)?;
        Ok(parent)
    }
    fn delta_rows(&self, id: Hash) -> Result<Vec<Delta>> {
        if self.state_backend == StateBackend::AuthenticatedV1 {
            return native_authenticated::deltas(&self.db, id);
        }
        self.delta_rows_with_progress(id, &mut || Ok(()))
    }
    fn delta_rows_with_progress(
        &self,
        id: Hash,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<Vec<Delta>> {
        if self.state_backend == StateBackend::AuthenticatedV1 {
            return native_authenticated::deltas_with_progress(&self.db, id, progress);
        }
        progress()?;
        let mut stmt = self
            .db
            .prepare_cached("SELECT key,before,after FROM deltas WHERE block=? ORDER BY key")?;
        let rows = stmt.query_map([id.as_slice()], |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?)))?;
        let mut out = Vec::new();
        for row in rows {
            out.push(row?);
            if out.len().is_multiple_of(256) {
                progress()?;
            }
        }
        progress()?;
        Ok(out)
    }
    pub fn state_at(&self, tip: Hash) -> Result<State> {
        self.state_at_with_progress(tip, &mut || Ok(()))
    }
    fn state_at_with_progress(
        &self,
        tip: Hash,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<State> {
        self.state_at_with_readback(tip, progress, None)
    }
    fn state_at_with_readback(
        &self,
        tip: Hash,
        progress: &mut dyn FnMut() -> Result<()>,
        readback: Option<&mut native_authenticated::PostWriteReadback<'_>>,
    ) -> Result<State> {
        self.state_at_with_replay_prefix(tip, progress, readback, None)
    }
    fn state_at_with_replay_prefix(
        &self,
        tip: Hash,
        progress: &mut dyn FnMut() -> Result<()>,
        mut readback: Option<&mut native_authenticated::PostWriteReadback<'_>>,
        mut prefix: Option<&mut legacy_admission_readback::Parent<'_, '_>>,
    ) -> Result<State> {
        ensure(
            self.state_backend != StateBackend::PermanentAccountGrowthV2,
            "GROWTH_COMPLETE_STATE_UNAVAILABLE",
        )?;
        let _measurement = (self.state_backend == StateBackend::AuthenticatedV1).then(|| {
            self.authenticated_arithmetic
                .history
                .observe(native_authenticated::HistoryStage::StateAt)
        });
        progress()?;
        if tip == self.active()?.0 {
            return Ok(self.read_active_with_readback(progress, readback)?.2);
        }
        let mut path = reverse_path::ReversePath::new(tempfile::tempfile()?);
        let mut count = 0u64;
        let mut prefer_replay_prefix = false;
        let mut cur = tip;
        let (mut state, mut commitment): (State, Option<CheckedCommitment>) = loop {
            progress()?;
            if let Some(state) = prefix
                .as_deref_mut()
                .map(|prefix| prefix.take_if_current(&self.db, tip, cur))
                .transpose()?
                .flatten()
            {
                break (state, None);
            }
            let row = self.record(cur)?;
            let snapshot = self
                .db
                .prepare_cached("SELECT state FROM snapshots WHERE block=?")?
                .query_row([cur.as_slice()], |r| r.get::<_, Vec<u8>>(0))
                .optional()?;
            if let Some(bytes) = snapshot {
                let state: State = serde_json::from_slice(&bytes)
                    .map_err(|error| Error::from(error).local_integrity())?;
                ensure(canonical(&state)? == bytes, "STATE_BYTES")
                    .map_err(Error::local_integrity)?;
                continuity_v1::check_state(&state, row.height, &self.settings.app)
                    .map_err(|error| Error::from(error).local_integrity())?;
                prefer_replay_prefix = self.state_backend == StateBackend::Legacy;
                if prefer_replay_prefix {
                    self.historical_commitment_cache
                        .borrow_mut()
                        .begin_replay(cur);
                }
                let commitment = self
                    .checked_historical_commitment(
                        cur,
                        &state,
                        row.root,
                        None,
                        prefer_replay_prefix,
                    )?
                    .snapshot;
                if self.state_backend == StateBackend::AuthenticatedV1 {
                    native_authenticated::verify_state_with_readback(
                        &self.db,
                        &self.settings,
                        cur,
                        &state,
                        progress,
                        Some(&self.authenticated_arithmetic),
                        readback.as_deref_mut(),
                    )?;
                }
                break (state, commitment);
            }
            path.push(cur)?;
            count = count.checked_add(1).ok_or("ANCESTRY_LIMIT")?;
            cur = self.parent(cur)?;
        };
        for replay_index in 0..count {
            progress()?;
            let id = path.pop()?.ok_or("ANCESTRY_LIMIT")?;
            for (index, (key, before, after)) in self
                .delta_rows_with_progress(id, progress)?
                .into_iter()
                .enumerate()
            {
                if index.is_multiple_of(256) {
                    progress()?;
                }
                ensure(
                    state.get(&key).map(canonical).transpose()? == before,
                    "UNDO_ROOT",
                )
                .map_err(Error::local_integrity)?;
                if let Some(bytes) = after {
                    state.insert(
                        key,
                        serde_json::from_slice(&bytes)
                            .map_err(|error| Error::from(error).local_integrity())?,
                    );
                } else {
                    state.remove(&key);
                }
            }
            commitment = self
                .checked_historical_commitment(
                    id,
                    &state,
                    self.record(id)?.root,
                    commitment.as_ref(),
                    prefer_replay_prefix && replay_index < 6,
                )?
                .snapshot;
            continuity_v1::check_state(&state, self.record(id)?.height, &self.settings.app)
                .map_err(|error| Error::from(error).local_integrity())?;
            if self.state_backend == StateBackend::AuthenticatedV1 {
                native_authenticated::verify_state_with_readback(
                    &self.db,
                    &self.settings,
                    id,
                    &state,
                    progress,
                    Some(&self.authenticated_arithmetic),
                    readback.as_deref_mut(),
                )?;
            }
        }
        progress()?;
        if let Some(scope) = readback {
            scope.validate_consumed(&self.db)?;
        }
        Ok(state)
    }
    fn recent(&self, parent: Hash) -> Result<Vec<(u64, Hash)>> {
        self.recent_with_progress(parent, &mut || Ok(()))
    }
    fn recent_with_progress(
        &self,
        mut parent: Hash,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<Vec<(u64, Hash)>> {
        let mut out = Vec::new();
        let bound = self.settings.limit("retarget_interval")?.max(11);
        while parent != self.settings.genesis() && out.len() < (bound as usize) {
            progress()?;
            // The per-link projection already validates the complete child and
            // parent record shapes. Batch the exact window, without keeping a
            // previous ancestry, time or target verdict across calls.
            let maximum = (bound - out.len() as u64).min(HISTORY_HEADER_BATCH);
            (parent, _) = self.visit_header_batch_limited(parent, maximum, &mut |_, link| {
                progress()?;
                out.push((link.header.timestamp, link.header.target));
                Ok(())
            })?;
        }
        if parent == self.settings.genesis() {
            out.push((
                self.settings.genesis_time(),
                self.settings.target("initial_target_hex")?,
            ));
        }
        Ok(out)
    }
    /// The pool miner uses actual wall time, but admissibility is the native
    /// parent-first median rule. One legal future-dated tip must not stall a
    /// child whose current wall time is already above that branch's median.
    pub(crate) fn mining_wall_time_ready(&self, parent: Hash, now: u64) -> Result<bool> {
        // Preserve the original immediate-parent record and full packet checks.
        // A header projection alone cannot validate the retained packet body,
        // and stopping at genesis must not skip its record's shape checks.
        if self.parent_height(parent)? != 0 {
            self.packet(parent)?;
        }
        // This check also runs while waiting for the clock. Read only its MTP11
        // window, retaining the native per-link and final-parent record checks.
        let mut times = [0; 11];
        let mut count = 0;
        let (next, _) = self.visit_header_batch_limited(parent, 11, &mut |_, link| {
            times[count] = link.header.timestamp;
            count += 1;
            Ok(())
        })?;
        if next == self.settings.genesis() && count < times.len() {
            times[count] = self.settings.genesis_time();
            count += 1;
        }
        match consensus::check_time(
            now,
            &times[..count],
            now,
            self.settings.limit("future_skew_seconds")?,
        ) {
            Ok(()) => Ok(true),
            Err(error) if error.to_string() == "TIME" => Ok(false),
            Err(error) => Err(error),
        }
    }
    pub fn expected_target(&self, parent: Hash) -> Result<Hash> {
        if self.state_backend == StateBackend::PermanentAccountGrowthV2 {
            return self.growth_expected_target(parent);
        }
        let height = consensus::BranchTargetHeight::after(self.record(parent)?.height)?;
        let recent = self.recent(parent)?;
        self.target_from_recent(height, &recent)
    }
    // One invocation owns this immutable window. Callers must still acquire
    // fresh parent rows after owner release, W1 replay and transaction entry.
    fn target_from_recent(
        &self,
        height: consensus::BranchTargetHeight,
        recent: &[(u64, Hash)],
    ) -> Result<Hash> {
        let interval = self.settings.limit("retarget_interval")?;
        match height.window(recent, interval)? {
            consensus::TargetWindow::Parent(target) => Ok(target),
            consensus::TargetWindow::Retarget {
                target,
                first,
                last,
            } => consensus::retarget(
                target,
                first,
                last,
                interval,
                self.settings.limit("target_spacing_seconds")?,
                self.settings.target("pow_limit_hex")?,
            ),
        }
    }
    /// A cancelled controlled activation may have committed only part of its
    /// existing reorg intent. Permit only the exact already-admitted intent
    /// target to reach the original controlled activation/recovery checks.
    /// Every other request retains ready()'s REORG_IN_PROGRESS refusal.
    pub(crate) fn pending_exact_activation_replay(
        &self,
        packet: &Packet,
        observed_now: u64,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<Option<Hash>> {
        progress()?;
        self.namespace()?;
        let pending: Option<Vec<u8>> = self
            .db
            .query_row(
                "SELECT new_tip FROM reorg WHERE singleton=1 AND done=0",
                [],
                |row| fixed_blob::<32>(row, 0),
            )
            .optional()
            .map_err(|error| Error::from(error).local_integrity())?;
        let Some(pending) = pending else {
            return Ok(None);
        };
        let id = packet.id()?;
        if pending.as_slice() != id.as_slice() {
            return Ok(None);
        }
        self.precheck_owner_packet(packet)?;
        let h = &packet.header;
        ensure(
            h.network == self.settings.network() && h.parameters == self.settings.parameters(),
            "NETWORK",
        )?;
        ensure(
            self.packet(id)
                .map_err(Error::local_integrity)?
                .encode_for_settings(&self.settings)?
                == packet.encode_for_settings(&self.settings)?,
            "DUPLICATE_CONTENT",
        )?;
        ensure(
            h.timestamp as u128
                <= observed_now as u128 + self.settings.limit("future_skew_seconds")? as u128,
            "TIME_DEFERRED",
        )?;
        progress()?;
        Ok(Some(id))
    }
    pub(crate) fn check_admission_context(
        &self,
        packet: &Packet,
        observed_now: u64,
    ) -> Result<Option<Hash>> {
        self.check_admission_context_with_progress(packet, observed_now, &mut |_| Ok(()))
    }
    pub(crate) fn check_admission_context_with_progress(
        &self,
        packet: &Packet,
        observed_now: u64,
        progress: &mut dyn FnMut(ExecutionProgress) -> Result<()>,
    ) -> Result<Option<Hash>> {
        Ok(self
            .check_admission_context_for_permit(packet, observed_now, None, progress)?
            .existing())
    }
    /// The ordinary public V3 service verifies bounded W1 before reconstructing
    /// all parent State. Local owner policies still bind their complete task
    /// before any work. Final admission always repeats the full current context.
    pub(crate) fn precheck_public_admission_context_with_progress(
        &self,
        packet: &Packet,
        observed_now: u64,
        progress: &mut dyn FnMut(ExecutionProgress) -> Result<()>,
    ) -> Result<Option<Hash>> {
        let task_before_work = self.owner_policy.is_some()
            || self.continuous_owner.is_some()
            || self.mining_owner.is_some();
        if task_before_work {
            self.check_admission_context_with_progress(packet, observed_now, progress)
        } else {
            self.check_admission_header_context(packet, observed_now, None, &mut || {
                progress(ExecutionProgress::BeforeHeaderContext)
            })
        }
    }
    fn check_admission_context_for_permit(
        &self,
        packet: &Packet,
        observed_now: u64,
        reserved: Option<&OwnerPacketPermit>,
        progress: &mut dyn FnMut(ExecutionProgress) -> Result<()>,
    ) -> Result<CheckedAdmissionContext> {
        if let Some(id) =
            self.check_admission_header_context(packet, observed_now, reserved, &mut || {
                progress(ExecutionProgress::BeforeHeaderContext)
            })?
        {
            return Ok(CheckedAdmissionContext::Existing(id));
        }
        Ok(CheckedAdmissionContext::Parent(
            self.check_admission_parent(packet, &mut || {
                progress(ExecutionProgress::BeforeParentBinding)
            })?,
        ))
    }
    fn check_admission_header_context(
        &self,
        packet: &Packet,
        observed_now: u64,
        reserved: Option<&OwnerPacketPermit>,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<Option<Hash>> {
        // Bounded full-packet identity precedes State/lease/context/Work work.
        self.precheck_owner_packet(packet)?;
        self.ready()?;
        // Keep the complete encoder grammar at its original boundary. New
        // packets need no owned wire copy until the actual persistence step.
        packet.checked_wire_length_for_settings(&self.settings)?;
        let h = &packet.header;
        let id = packet.id()?;
        ensure(
            h.network == self.settings.network() && h.parameters == self.settings.parameters(),
            "NETWORK",
        )?;
        // Preserve the original cheap profile/network refusal before invoking
        // caller code. The following current-row work uses the original
        // request's cancellation/CPU/deadline callback, including preflight.
        let epoch = self.admission_state_epoch()?;
        let mut checkpoint_failed = false;
        let mut checkpoint = || {
            let result = progress();
            checkpoint_failed |= result.is_err();
            result
        };
        let result = (|| -> Result<Option<Hash>> {
            checkpoint()?;
            let previous: Option<Vec<u8>> = self
                .db
                .query_row(STORED_PACKET_SQL, [id.as_slice()], |r| r.get(0))
                .optional()?;
            if let Some(prior) = previous {
                let bytes = packet.encode_for_settings(&self.settings)?;
                ensure(prior == bytes, "DUPLICATE_CONTENT")?;
                // Immutable work can be cached; a previous caller's clock cannot.
                ensure(
                    h.timestamp as u128
                        <= observed_now as u128
                            + self.settings.limit("future_skew_seconds")? as u128,
                    "TIME_DEFERRED",
                )?;
                checkpoint()?;
                return Ok(Some(id));
            }
            if let Some(owner) = &self.owner_policy {
                if owner.journal.borrow().work_operation_is_used(&owner.policy) {
                    // A reservation without a durable exact block is in-flight or
                    // uncertain/failed, not another authorization to reconstruct State.
                    let permit = reserved.ok_or("OWNER_TASK_OPERATION_USED")?;
                    permit.progress()?;
                    owner
                        .journal
                        .borrow()
                        .recheck_before_commit(
                            &owner.policy,
                            &permit.reservation,
                            &permit.facts,
                            crate::operator_task_policy::now_ns().map_err(owner_error)?,
                        )
                        .map_err(owner_error)?;
                }
            }
            let parent = self.record(h.parent)?;
            ensure(
                parent.height.checked_add(1) == Some(h.height) && h.height <= i64::MAX as u64,
                "HEIGHT",
            )?;
            let height = consensus::BranchTargetHeight::after(parent.height)?;
            let recent = self.recent_with_progress(h.parent, &mut checkpoint)?;
            ensure(
                h.target == self.target_from_recent(height, &recent)?,
                "TARGET",
            )?;
            let times: Vec<_> = recent.iter().take(11).map(|p| p.0).collect();
            consensus::check_time(
                h.timestamp,
                &times,
                observed_now,
                self.settings.limit("future_skew_seconds")?,
            )?;
            ensure(
                h.transactions == sequence_root("transactions", &packet.transactions),
                "ROOT",
            )?;
            // Encoding, TaskId and a claimed ticket need no parent State. Reject
            // them before task lookup; a passing filter still requires full replay.
            pon_work::precheck_proof_statement(h.challenge(), h.work_task, h.target, &packet.proof)
                .map_err(|error| Error::from(format!("WORK:{error:?}")))?;
            checkpoint()?;
            // Only the unowned public preflight stops here. Final admission and
            // local owner policies still run check_admission_parent afresh.
            Ok(None)
        })();
        // Preserve the original cancellation/budget/permission refusal without
        // starting another read after its resource owner has stopped the call.
        if checkpoint_failed
            || result.as_ref().is_err_and(|error| {
                matches!(
                    error.kind(),
                    crate::ErrorKind::Cancelled
                        | crate::ErrorKind::Capacity
                        | crate::ErrorKind::PolicyRefusal
                )
            })
        {
            return result;
        }
        // Fence failed row-dependent decisions as well as successful returns.
        // A concurrent commit or callback write cannot turn a valid candidate
        // into a HEIGHT/TARGET/ROOT refusal from mixed local observations.
        // This is input freshness, not transaction identity or commit authority.
        ensure(
            self.admission_state_epoch()? == epoch,
            "ADMISSION_HEADER_EPOCH_CHANGED",
        )?;
        result
    }
    fn admission_state_epoch(&self) -> Result<AdmissionStateEpoch> {
        Ok(AdmissionStateEpoch {
            data_version: self
                .db
                .query_row("PRAGMA data_version", [], |row| row.get(0))?,
            total_changes: self.db.total_changes(),
        })
    }
    fn check_admission_parent(
        &self,
        packet: &Packet,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<CheckedAdmissionParent> {
        let h = &packet.header;
        // The Node owner excludes cooperating writers. These inexpensive SQLite
        // observations additionally withhold reuse after same-connection row mutations
        // or commits by a foreign connection, including diagnostic fault hooks.
        // They do not authenticate arbitrary out-of-band filesystem changes.
        let before = self.admission_state_epoch()?;
        let state = self.state_at_with_progress(h.parent, progress)?;
        let eligibility = self.eligible_work_task_from_state(&state, h.work_task, h.height)?;
        // Signed task context/expiry/parent registration reject before full work replay.
        if let Some(manifest) = eligibility.manifest() {
            // The fixed recipe's actual model and input artifacts are precisely the
            // proof's A/B bytes. An untrusted miner can bypass every local builder;
            // the validator must bind these commitments before transcript replay.
            let artifacts = pon_work::artifacts::commitments(&packet.proof)
                .map_err(|_| Error::from("TASK_PROOF_MATERIAL"))?;
            ensure(artifacts.model == manifest.model, "TASK_MODEL_BINDING")?;
            ensure(artifacts.input == manifest.input, "TASK_INPUT_BINDING")?;
        }
        let epoch = (self.admission_state_epoch()? == before).then_some(before);
        Ok(CheckedAdmissionParent {
            state,
            eligibility,
            epoch,
        })
    }
    pub fn admit(&mut self, packet: &Packet, observed_now: u64) -> Result<Hash> {
        if let Some(id) = self.check_admission_context(packet, observed_now)? {
            return Ok(id);
        }
        let permit = self.begin_owner_work(packet)?;
        let checked = self.attach_owner_work(WorkCheckedPacket::verify(packet.clone())?, permit)?;
        self.admit_work_checked(checked, observed_now)
    }
    /// Only the original Node checks current parent/task/permit/state/clock.
    /// The caller may refuse LOCAL resource continuation at mathematical W1
    /// checkpoints; cancellation must never masquerade as invalid work.
    #[cfg(test)]
    pub(crate) fn admit_with_work_progress(
        &mut self,
        packet: &Packet,
        observed_now: u64,
        progress: &mut impl FnMut(pon_work::VerificationProgress) -> Result<()>,
        execution_progress: &(impl Fn(ExecutionProgress) -> Result<()> + Sync),
    ) -> Result<Hash> {
        if let Some(id) = self.check_admission_context(packet, observed_now)? {
            return Ok(id);
        }
        let permit = self.begin_owner_work(packet)?;
        let checked = self.attach_owner_work(
            WorkCheckedPacket::verify_with_progress(packet.clone(), progress)?,
            permit,
        )?;
        // Keep the SAME caller-local Host owner through M06, authenticated
        // State and SQL deltas. A resource refusal before durable commit must
        // roll back the original Node transaction, not become invalid W1.
        self.admit_work_checked_with_progress(checked, observed_now, execution_progress)
    }
    fn precheck_owner_packet(&self, packet: &Packet) -> Result<()> {
        ensure(
            self.state_backend != StateBackend::PermanentAccountGrowthV2,
            "GROWTH_PACKET_REQUIRED",
        )?;
        self.continuous_packet_gate(packet)?;
        self.mining_packet_gate(packet)?;
        if let Some(owner) = &self.owner_policy {
            ensure(
                !owner.unavailable.load(std::sync::atomic::Ordering::Acquire),
                "OWNER_TASK_UNAVAILABLE",
            )?;
            owner
                .policy
                .check_window(crate::operator_task_policy::now_ns().map_err(owner_error)?)
                .map_err(owner_error)?;
            owner
                .policy
                .check_packet(&crate::operator_task_policy::digest_bytes(
                    &packet.encode_for_settings(&self.settings)?,
                ))
                .map_err(owner_error)?;
        }
        Ok(())
    }
    pub(crate) fn begin_owner_work(&self, packet: &Packet) -> Result<Option<OwnerPacketPermit>> {
        let Some(owner) = &self.owner_policy else {
            return Ok(None);
        };
        self.precheck_owner_packet(packet)?;
        let packet_sha256 =
            crate::operator_task_policy::digest_bytes(&packet.encode_for_settings(&self.settings)?);
        owner
            .policy
            .check_packet(&packet_sha256)
            .map_err(owner_error)?;
        owner
            .policy
            .check_commands(&packet.transactions)
            .map_err(owner_error)?;
        let h = &packet.header;
        let manifest = self
            .eligible_work_task(h.parent, h.work_task, h.height)?
            .ok_or("OWNER_TASK_COMPLETE_REGISTRATION_REQUIRED")?;
        // Initial supported actual case is Maintenance with a complete lifecycle lease.
        ensure(
            manifest.purpose == TaskPurpose::Maintenance,
            "OWNER_TASK_PURPOSE_PENDING",
        )?;
        let lease = self.lifecycle_task_lease(h.parent, h.work_task, h.height)?;
        let lease = lease
            .encode()
            .map_err(|_| Error::from("OWNER_TASK_LEASE"))?;
        let size = pon_work::CELLS * 4;
        ensure(
            packet.proof.len() == pon_work::PROOF_BYTES && packet.proof.get(..4) == Some(b"PNW1"),
            "OWNER_TASK_PROOF",
        )?;
        let mut task = owner.policy.task().clone();
        task.purpose = "maintenance-tag1".into();
        task.native_task = hex::encode(h.work_task);
        task.lease_sha256 = crate::operator_task_policy::digest_bytes(&lease);
        task.native_model = hex::encode(manifest.model);
        task.native_input = hex::encode(manifest.input);
        task.a_sha256 = crate::operator_task_policy::digest_bytes(&packet.proof[4..4 + size]);
        task.b_sha256 =
            crate::operator_task_policy::digest_bytes(&packet.proof[4 + size..4 + 2 * size]);
        task.dimension = 64;
        task.field_modulus = 4_294_967_291;
        task.encoding = "canonical-u32-le".into();
        let facts = crate::operator_task_policy::NativeFacts {
            network: hex::encode(h.network),
            parameters: hex::encode(h.parameters),
            parent: hex::encode(h.parent),
            task,
            packet_sha256,
            header_nonce: h.nonce,
        };
        let reservation = owner
            .journal
            .borrow_mut()
            .reserve(
                &owner.policy,
                &facts,
                crate::operator_task_policy::now_ns().map_err(owner_error)?,
            )
            .map_err(owner_error)?;
        Ok(Some(OwnerPacketPermit {
            epoch: std::sync::Arc::clone(&owner.epoch),
            expected_epoch: owner.epoch.load(std::sync::atomic::Ordering::Acquire),
            policy: std::sync::Arc::clone(&owner.policy),
            unavailable: std::sync::Arc::clone(&owner.unavailable),
            facts,
            reservation,
        }))
    }
    pub(crate) fn attach_owner_work(
        &self,
        mut checked: WorkCheckedPacket,
        permit: Option<OwnerPacketPermit>,
    ) -> Result<WorkCheckedPacket> {
        ensure(
            self.owner_policy.is_some() == permit.is_some(),
            "OWNER_TASK_PERMIT_REQUIRED",
        )?;
        if let Some(permit) = &permit {
            ensure(
                permit.facts.packet_sha256
                    == crate::operator_task_policy::digest_bytes(
                        &checked.packet.encode_for_settings(&self.settings)?,
                    ),
                "OWNER_TASK_PACKET_CHANGED",
            )?;
            permit.progress()?;
        }
        checked.owner_permit = permit;
        Ok(checked)
    }
    /// Trusted operator-only typed refresh. There is deliberately no anonymous RPC
    /// or candidate-selected latest source. CLI may stop/reopen using the same protected
    /// loader; an embedding owner must supply the externally fixed full descriptor.
    pub fn refresh_operator_task_policy(
        &mut self,
        inputs: crate::operator_task_policy::RestrictedNodeInputs,
    ) -> Result<()> {
        let owner = self
            .owner_policy
            .as_ref()
            .ok_or("OWNER_TASK_POLICY_REQUIRED")?;
        ensure(
            inputs.expected_uid == rustix::process::geteuid().as_raw(),
            "OWNER_TASK_UID",
        )?;
        ensure(
            (
                inputs.authority.registry_key.as_str(),
                inputs.authority.task_key.as_str(),
            ) == (owner.outside_keys.0.as_str(), owner.outside_keys.1.as_str()),
            "OWNER_TASK_KEYS_CHANGED",
        )?;
        let policy = crate::operator_task_policy::authenticate(
            &inputs.raw_policy,
            &inputs.authority,
            crate::operator_task_policy::now_ns().map_err(owner_error)?,
        )
        .map_err(owner_error)?;
        let old = owner.policy.context();
        let new = policy.context();
        ensure(
            new.source_commit == old.source_commit
                && new.node_policy_source == old.node_policy_source
                && new.registry2_package == old.registry2_package
                && policy.marker(&inputs.journal_path).map_err(owner_error)?
                    == owner.required_marker,
            "OWNER_TASK_NAMESPACE",
        )?;
        ensure(
            policy.next_view_of(&owner.policy),
            "OWNER_TASK_NEXT_VIEW_REQUIRED",
        )?;
        ensure(
            inputs.pool_permissions.len() <= 64,
            "OWNER_POOL_PERMISSION_LIMIT",
        )?;
        let mut pool_policies = Vec::new();
        for permission in &inputs.pool_permissions {
            let p = crate::operator_task_policy::pool::authenticate_pool(
                permission,
                &inputs.authority,
                &policy,
                crate::operator_task_policy::now_ns().map_err(owner_error)?,
            )
            .map_err(owner_error)?;
            ensure(
                !pool_policies.iter().any(
                    |p0: &std::sync::Arc<crate::operator_task_policy::pool::VerifiedPoolPolicy>| {
                        p0.same_operation(&p)
                    },
                ),
                "OWNER_POOL_DUPLICATE_PERMISSION",
            )?;
            pool_policies.push(std::sync::Arc::new(p));
        }
        crate::operator_task_policy::verify_catalog(&inputs, &policy).map_err(owner_error)?;
        let next_epoch = owner
            .epoch
            .load(std::sync::atomic::Ordering::Acquire)
            .checked_add(1)
            .ok_or("OWNER_TASK_EPOCH_OVERFLOW")?;
        let advanced = owner.journal.borrow_mut().advance(&policy);
        if let Err(error) = advanced {
            owner
                .unavailable
                .store(true, std::sync::atomic::Ordering::Release);
            return Err(owner_error(error));
        }
        // The durable anchor is now visible; invalidate outstanding old capabilities
        // before publishing new ones. No previously committed block is rewritten.
        owner
            .epoch
            .store(next_epoch, std::sync::atomic::Ordering::Release);
        let owner = self
            .owner_policy
            .as_mut()
            .ok_or("OWNER_TASK_POLICY_REQUIRED")?;
        owner.policy = std::sync::Arc::new(policy);
        owner.pool_policies = pool_policies;
        Ok(())
    }
    fn owner_pool_configured(&self) -> Result<()> {
        ensure(
            self.mining_owner.is_none(),
            "OWNER_MINING_POOL_PURPOSE_PENDING",
        )?;
        if self.continuous_owner.is_some() {
            return self.continuous_pool_configured();
        }
        if let Some(owner) = &self.owner_policy {
            ensure(
                !owner.pool_policies.is_empty(),
                "OWNER_POOL_EXACT_COMMAND_REQUIRED",
            )?;
        }
        Ok(())
    }
    fn begin_owner_pool(
        &self,
        command: &str,
        raws: &[Vec<u8>],
        context: Hash,
    ) -> Result<Option<OwnerPoolPermit>> {
        ensure(
            self.mining_owner.is_none(),
            "OWNER_MINING_POOL_PURPOSE_PENDING",
        )?;
        if self.continuous_owner.is_some() {
            return self
                .begin_continuous_pool_command(command, raws, context)
                .map(Some);
        }
        let Some(owner) = &self.owner_policy else {
            return Ok(None);
        };
        ensure(
            !owner.unavailable.load(std::sync::atomic::Ordering::Acquire),
            "OWNER_TASK_UNAVAILABLE",
        )?;
        owner
            .policy
            .check_window(crate::operator_task_policy::now_ns().map_err(owner_error)?)
            .map_err(owner_error)?;
        let payload = crate::operator_task_policy::pool::pool_payload_sha256(command, raws)
            .map_err(owner_error)?;
        let matches: Vec<_> = owner
            .pool_policies
            .iter()
            .filter(|p| p.matches(command, &payload))
            .collect();
        ensure(matches.len() == 1, "OWNER_POOL_EXACT_COMMAND_REQUIRED")?;
        let policy = std::sync::Arc::clone(matches[0]);
        ensure(
            !owner.journal.borrow().pool_operation_is_used(&policy),
            "OWNER_POOL_OPERATION_USED",
        )?;
        // Exact command equality precedes all parent-State/lease reconstruction.
        let (parent, generation) = self.active()?;
        policy
            .check_parent(&hex::encode(parent), generation, &hex::encode(context))
            .map_err(owner_error)?;
        let height = self.parent_height(parent)?.checked_add(1).ok_or("HEIGHT")?;
        let task =
            bytes32(hex::decode(policy.task()).map_err(|_| Error::from("OWNER_POOL_TASK_HEX"))?)?;
        let manifest = self
            .eligible_work_task(parent, task, height)?
            .ok_or("OWNER_TASK_COMPLETE_REGISTRATION_REQUIRED")?;
        ensure(
            manifest.purpose == TaskPurpose::Maintenance,
            "OWNER_TASK_PURPOSE_PENDING",
        )?;
        ensure(
            hex::encode(manifest.model) == owner.policy.task().native_model
                && hex::encode(manifest.input) == owner.policy.task().native_input,
            "OWNER_POOL_TASK_MATERIAL_CONTEXT",
        )?;
        let lease = self
            .lifecycle_task_lease(parent, task, height)?
            .encode()
            .map_err(|_| Error::from("OWNER_TASK_LEASE"))?;
        let facts = crate::operator_task_policy::pool::PoolFacts {
            parent: hex::encode(parent),
            generation,
            pool_context: hex::encode(context),
            registered_task: hex::encode(task),
            lease_sha256: crate::operator_task_policy::digest_bytes(&lease),
            command: command.into(),
            payload_sha256: payload,
        };
        policy
            .check(
                &facts,
                crate::operator_task_policy::now_ns().map_err(owner_error)?,
            )
            .map_err(owner_error)?;
        let reservation = owner
            .journal
            .borrow_mut()
            .reserve_pool(
                &policy,
                &facts,
                crate::operator_task_policy::now_ns().map_err(owner_error)?,
            )
            .map_err(owner_error)?;
        Ok(Some(OwnerPoolPermit {
            facts,
            authentication: OwnerPoolAuthentication::Legacy {
                policy,
                unavailable: std::sync::Arc::clone(&owner.unavailable),
                epoch: std::sync::Arc::clone(&owner.epoch),
                expected_epoch: owner.epoch.load(std::sync::atomic::Ordering::Acquire),
                reservation,
            },
        }))
    }
    fn recheck_owner_pool(&self, permit: Option<&OwnerPoolPermit>) -> Result<()> {
        ensure(
            self.mining_owner.is_none(),
            "OWNER_MINING_POOL_PURPOSE_PENDING",
        )?;
        if self.continuous_owner.is_some() {
            let permit = permit.ok_or("OWNER_CONTINUOUS_POOL_PERMIT_REQUIRED")?;
            ensure(
                matches!(
                    &permit.authentication,
                    OwnerPoolAuthentication::Continuous(_)
                ),
                "OWNER_CONTINUOUS_POOL_PERMIT_REQUIRED",
            )?;
            permit.progress()?;
            ensure(
                self.active()?
                    == (
                        bytes32(
                            hex::decode(&permit.facts.parent)
                                .map_err(|_| "OWNER_POOL_PARENT_HEX")?,
                        )?,
                        permit.facts.generation,
                    ),
                "OWNER_POOL_PARENT_CHANGED",
            )?;
            return Ok(());
        }
        ensure(
            self.owner_policy.is_some() == permit.is_some(),
            "OWNER_POOL_PERMIT_REQUIRED",
        )?;
        if let (Some(owner), Some(permit)) = (&self.owner_policy, permit) {
            permit.progress()?;
            let OwnerPoolAuthentication::Legacy {
                policy,
                reservation,
                ..
            } = &permit.authentication
            else {
                return Err("OWNER_POOL_PERMIT_REQUIRED".into());
            };
            owner
                .journal
                .borrow()
                .recheck_pool(
                    policy,
                    reservation,
                    &permit.facts,
                    crate::operator_task_policy::now_ns().map_err(owner_error)?,
                )
                .map_err(owner_error)?;
            ensure(
                self.active()?
                    == (
                        bytes32(
                            hex::decode(&permit.facts.parent)
                                .map_err(|_| Error::from("OWNER_POOL_PARENT_HEX"))?,
                        )?,
                        permit.facts.generation,
                    ),
                "OWNER_POOL_PARENT_CHANGED",
            )?;
        }
        Ok(())
    }
    fn check_owner_pool_retained(
        &self,
        permit: Option<&OwnerPoolPermit>,
        raws: &[Vec<u8>],
    ) -> Result<()> {
        self.recheck_owner_pool(permit)?;
        if self.continuous_owner.is_some() {
            let Some(OwnerPoolPermit {
                authentication: OwnerPoolAuthentication::Continuous(checkpoint),
                ..
            }) = permit
            else {
                return Err("OWNER_CONTINUOUS_POOL_PERMIT_REQUIRED".into());
            };
            return checkpoint.check_retained(raws);
        }
        if let (Some(owner), Some(permit)) = (&self.owner_policy, permit) {
            let payload =
                crate::operator_task_policy::pool::pool_payload_sha256("submit-bundle", raws)
                    .map_err(owner_error)?;
            let OwnerPoolAuthentication::Legacy { policy, .. } = &permit.authentication else {
                return Err("OWNER_POOL_PERMIT_REQUIRED".into());
            };
            owner
                .journal
                .borrow()
                .prefix_group_authorized(policy, &payload)
                .map_err(owner_error)?;
        }
        Ok(())
    }
    fn owner_preview_available(&self) -> Result<()> {
        self.continuous_preview_gate()?;
        self.mining_preview_gate()?;
        ensure(
            self.owner_policy.is_none(),
            "OWNER_TASK_POOL_PREVIEW_PENDING",
        )
    }
    /// Existing Native success is not rewritten if accounting fails after commit.
    pub fn operator_task_accounting_unknown(&mut self) -> Result<()> {
        if let Some(owner) = &self.owner_policy {
            owner
                .unavailable
                .store(true, std::sync::atomic::Ordering::Release);
            owner
                .journal
                .borrow_mut()
                .mark_unavailable()
                .map_err(owner_error)?;
        }
        Ok(())
    }
    /// Work is reusable only for the owned packet; branch/state/clock checks run again.
    pub(crate) fn admit_work_checked(
        &mut self,
        checked: WorkCheckedPacket,
        observed_now: u64,
    ) -> Result<Hash> {
        self.admit_work_checked_with_progress(checked, observed_now, &|_| Ok(()))
    }
    pub(crate) fn admit_work_checked_with_progress(
        &mut self,
        checked: WorkCheckedPacket,
        observed_now: u64,
        progress: &(impl Fn(ExecutionProgress) -> Result<()> + Sync),
    ) -> Result<Hash> {
        self.admit_work_checked_with_control(
            checked,
            observed_now,
            &ExecutionControl::new(progress, &()),
        )
    }
    pub(crate) fn admit_work_checked_with_control(
        &mut self,
        checked: WorkCheckedPacket,
        observed_now: u64,
        control: &ExecutionControl<'_, Error>,
    ) -> Result<Hash> {
        self.admit_work_checked_with_parent(checked, observed_now, control, None)
    }

    fn admit_work_checked_with_parent(
        &mut self,
        checked: WorkCheckedPacket,
        observed_now: u64,
        control: &ExecutionControl<'_, Error>,
        prepared_parent: Option<CheckedAdmissionParent>,
    ) -> Result<Hash> {
        let _measurement = (self.state_backend == StateBackend::AuthenticatedV1).then(|| {
            self.authenticated_arithmetic
                .history
                .observe(native_authenticated::HistoryStage::Admission)
        });
        let WorkCheckedPacket {
            packet,
            work: verified_work,
            owner_permit,
        } = checked;
        // Recheck every header/owner predicate even when this same-owner,
        // same-epoch private continuation can retain its validated parent.
        if let Some(id) = self.check_admission_header_context(
            &packet,
            observed_now,
            owner_permit.as_ref(),
            &mut || (control.progress)(ExecutionProgress::BeforeHeaderContext),
        )? {
            return Ok(id);
        }
        let checked_parent = match prepared_parent {
            Some(parent) if parent.epoch == Some(self.admission_state_epoch()?) => parent,
            _ => self.check_admission_parent(&packet, &mut || {
                (control.progress)(ExecutionProgress::BeforeParentBinding)
            })?,
        };
        ensure(
            self.owner_policy.is_some() == owner_permit.is_some(),
            "OWNER_TASK_PERMIT_REQUIRED",
        )?;
        if let (Some(owner), Some(permit)) = (&self.owner_policy, &owner_permit) {
            ensure(
                std::sync::Arc::ptr_eq(&owner.policy, &permit.policy),
                "OWNER_TASK_STALE_POLICY",
            )?;
            ensure(
                permit.facts.packet_sha256
                    == crate::operator_task_policy::digest_bytes(
                        &packet.encode_for_settings(&self.settings)?,
                    ),
                "OWNER_TASK_PACKET_CHANGED",
            )?;
            owner
                .journal
                .borrow()
                .recheck_before_commit(
                    &owner.policy,
                    &permit.reservation,
                    &permit.facts,
                    crate::operator_task_policy::now_ns().map_err(owner_error)?,
                )
                .map_err(owner_error)?;
        }
        // Only immutable permit/atomic flags are consulted while M06 or SQL run.
        // No journal mutex/RefCell guard or filesystem write is held across either.
        let mining_progress = self.mining_progress_snapshot()?;
        let continuous_progress = self.continuous_progress_snapshot()?;
        let guarded_progress = |point: ExecutionProgress| -> Result<()> {
            (control.progress)(point)?;
            if let Some(p) = &continuous_progress {
                p.check()?;
            }
            if let Some(p) = &mining_progress {
                p.check()?;
            }
            if let Some(permit) = &owner_permit {
                permit.progress()?;
            }
            Ok(())
        };
        let guarded_control = ExecutionControl::new(&guarded_progress, control.worker_accounting);
        let control = &guarded_control;
        let progress = control.progress;
        let bytes = packet.encode_for_settings(&self.settings)?;
        let h = &packet.header;
        let parent = self.record(h.parent)?;
        // Keep the original second parent-read cancellation/CPU boundary. The
        // first full State/root/account/task/material validation was in this
        // same admission, while holding this same owner. No new ledger writes
        // have run. A changed or unstable SQL epoch retains full fresh checks.
        progress(ExecutionProgress::BeforeParentBinding)?;
        let checked_parent = if checked_parent.epoch == Some(self.admission_state_epoch()?) {
            checked_parent
        } else {
            drop(checked_parent);
            self.check_admission_parent(&packet, &mut || {
                progress(ExecutionProgress::BeforeParentBinding)
            })?
        };
        let CheckedAdmissionParent {
            state: prior,
            eligibility: registered_task,
            ..
        } = checked_parent;
        let (executed, rejection_scope) = self.execute_derived_core_with_rejection(
            &prior,
            ExecutionRequest {
                timestamp: Some(h.timestamp),
                transactions: &packet.transactions,
                height: h.height,
                miner: h.miner,
                parent_id: h.parent,
                workers: self.workers,
            },
            control,
            owner_permit.as_ref(),
            Some((h, &bytes)),
        )?;
        let mut output = executed.output;
        let mut commitment = executed.commitment;
        if registered_task.manifest().is_some() {
            let product: Vec<u8> = verified_work
                .product()
                .iter()
                .flat_map(|value| value.to_le_bytes())
                .collect();
            if self.record_task_output(h.height, &mut output.state, &registered_task, &product)? {
                commitment = self.derive_successor(&output.state, commitment.snapshot.as_ref())?;
                output.root = commitment.root;
            }
        }
        let receipts_root = sequence_root("receipts", &output.receipts);
        if h.state != output.root || h.receipts != receipts_root {
            // This private fact is constructed only after successful full M06
            // and task-output derivation. No arbitrary Err(ROOT) is retained.
            if let Some(scope) = rejection_scope {
                progress(ExecutionProgress::BeforeOutput)?;
                if let Some(cache) = self.root_rejection_cache.borrow_mut().as_mut() {
                    cache.retain(
                        scope,
                        bytes,
                        root_rejection_cache::FinalMismatch {
                            state: output.root,
                            receipts: receipts_root,
                        },
                        root_rejection_cache::now_ns(),
                    );
                }
            }
            return Err("ROOT".into());
        }
        self.persist_admission_execution(
            AdmissionPersistence {
                packet,
                bytes,
                parent,
                prior,
                output,
                commitment,
            },
            control,
            None,
        )
    }

    /// Both held-owner and detached execution converge on the same original
    /// transaction, delta/packet/State readback, ancestry and active-tip fences.
    /// This private helper is never a public StagedOutput admission interface.
    fn persist_admission_execution(
        &mut self,
        admission: AdmissionPersistence,
        control: &ExecutionControl<'_, Error>,
        detached_fence: Option<detached_admission::CommitFence>,
    ) -> Result<Hash> {
        let AdmissionPersistence {
            packet,
            bytes,
            parent,
            prior,
            output,
            commitment,
        } = admission;
        let h = &packet.header;
        let id = packet.id()?;
        let progress = |point: ExecutionProgress| -> Result<()> {
            #[cfg(test)]
            legacy_admission_readback::test_progress(&self.db, point)?;
            (control.progress)(point)
        };
        ensure(
            h.state == output.root && h.receipts == sequence_root("receipts", &output.receipts),
            "ROOT",
        )?;
        if self.state_backend == StateBackend::AuthenticatedV1 {
            // Pure successor tree material is already available from M06. Offer
            // it to the existing bounded historical cache before SQL readback;
            // state_at still reads, canonically encodes and compares ALL actual
            // stored State, then checks the resulting root and account graph.
            // Rollback may leave optional arithmetic, never an admitted fact.
            self.historical_commitment_cache
                .borrow_mut()
                .retain(id, commitment.snapshot.as_ref());
            self.authenticated_arithmetic
                .offer_root_material(&self.settings, commitment.snapshot.as_ref());
        }
        let work = parent
            .work
            .checked_add(consensus::required_work(h.target)?)?;
        let index_context = self.ancestry_context()?;
        progress(ExecutionProgress::BeforePersistence)?;
        let tx = rusqlite::Transaction::new_unchecked(
            &self.db,
            rusqlite::TransactionBehavior::Immediate,
        )?;
        let legacy_readback_schema = match self.legacy_admission_readback_schema() {
            // An active-parent read comes from KV, while its child's original
            // path still reads historical snapshots/deltas. Those obligations
            // are different and must never borrow this common-prefix path.
            Some(expected) if !h.height.is_multiple_of(128) && h.parent != self.active()?.0 => {
                Some(expected)
            }
            _ => None,
        };
        // This is the existing c165 executed-transaction owner, captured before
        // any callback or write. total_changes alone cannot detect an ABA or DDL.
        let original_readback_owner = self
            .post_write_schema
            .as_ref()
            .or(legacy_readback_schema)
            .map(|_| {
                trnm_sqlite_io_boundary::TransactionScope::capture(&tx)
                    .map_err(native_authenticated::readback_scope_error)
            })
            .transpose()?;
        let transaction_result: Result<()> = (|| {
            if let Some(fence) = detached_fence {
                // BEGIN IMMEDIATE excludes foreign SQLite writers before the last
                // epoch/context check. An out-of-lock result is never authorized by
                // an earlier counter read followed by an unprotected write gap.
                fence.validate(self, &packet, control)?;
            }
            ensure(
                tx.execute(
                    "INSERT INTO blocks VALUES(?,?,?,?,?,?)",
                    params![
                        id.as_slice(),
                        h.parent.as_slice(),
                        h.height,
                        work.bytes().as_slice(),
                        &bytes,
                        h.state.as_slice()
                    ],
                )? == 1,
                "STORAGE_WRITE",
            )
            .map_err(Error::local_integrity)?;
            let inserted_ancestry = crate::ancestry_index::insert(&tx, index_context, id)?;
            let mut expected_deltas = Vec::new();
            {
                let mut insert = tx.prepare_cached("INSERT INTO deltas VALUES(?,?,?,?)")?;
                for (index, entry) in state_merge::entries(&prior, &output.state).enumerate() {
                    progress(ExecutionProgress::PersistenceDelta { index })?;
                    let state_merge::Entry {
                        key,
                        before: before_value,
                        after: after_value,
                    } = entry;
                    // Both complete States have already passed the original
                    // canonical root/execution checks. Equal JSON values have
                    // identical canonical bytes, so unchanged cells need no
                    // duplicate serialization merely to discover an empty delta.
                    // Keep each row's control checkpoint and every original
                    // transactional delta, packet and full-State readback below.
                    if before_value == after_value {
                        continue;
                    }
                    let before = before_value.map(canonical).transpose()?;
                    let after = after_value.map(canonical).transpose()?;
                    if before != after {
                        ensure(
                            insert.execute(params![id.as_slice(), key, &before, &after])? == 1,
                            "STORAGE_WRITE",
                        )
                        .map_err(Error::local_integrity)?;
                        expected_deltas.push((key.clone(), before, after));
                    }
                }
            }
            // Authenticated admission otherwise reconstructs the just-written state
            // from genesis, verifying every intermediate complete account tree.
            // Keep an ordinary canonical snapshot for each admitted native block.
            // These are disposable accelerators: retain the existing 64-row policy,
            // genesis anchor, full history/delta checks and post-write readback.
            // Legacy cadence remains unchanged; no validity verdict is cached.
            if self.state_backend == StateBackend::AuthenticatedV1
                || growth_profile_v2::enabled(&self.settings.app)
                || h.height.is_multiple_of(128)
            {
                ensure(
                    tx.execute(
                        "INSERT INTO snapshots VALUES(?,?)",
                        params![id.as_slice(), canonical(&output.state)?],
                    )? == 1,
                    "STORAGE_WRITE",
                )
                .map_err(Error::local_integrity)?;
                tx.execute("DELETE FROM snapshots WHERE block!=? AND block NOT IN (SELECT snapshots.block FROM snapshots JOIN blocks ON blocks.id=snapshots.block ORDER BY blocks.height DESC,blocks.id LIMIT 64)",[self.settings.genesis.as_slice()])?;
                let retained: u64 = tx.query_row(
                    "SELECT COUNT(*) FROM snapshots WHERE block!=?",
                    [self.settings.genesis.as_slice()],
                    |row| row.get(0),
                )?;
                ensure(retained <= 64, "SNAPSHOT_LIMIT").map_err(Error::local_integrity)?;
            }
            let mut publication_readback = None;
            if self.state_backend == StateBackend::AuthenticatedV1 {
                publication_readback = native_authenticated::publish_with_readback(
                    &tx,
                    &self.settings,
                    h.parent,
                    id,
                    &prior,
                    &output.state,
                    &mut || progress(ExecutionProgress::BeforeDurableCommit),
                    Some(&self.authenticated_arithmetic),
                    original_readback_owner
                        .as_ref()
                        .zip(self.post_write_schema.as_ref()),
                )?;
            }
            // All intended writes, including their triggers, precede this
            // baseline. A failed schema qualification keeps the original two
            // full replays; a replaced original writer is an integrity error.
            let mut legacy_readback = original_readback_owner
                .as_ref()
                .zip(legacy_readback_schema)
                .map(|(owner, expected)| {
                    native_authenticated::PostWriteReadback::new(
                        &tx,
                        &self.settings,
                        id,
                        owner,
                        expected,
                    )
                })
                .transpose()?
                .flatten();
            // Re-read after every write/trigger, while rollback can still remove the
            // whole block. A snapshot cannot conceal an omitted canonical delta.
            ensure(
                self.delta_rows_with_progress(id, &mut || {
                    progress(ExecutionProgress::BeforeDurableCommit)
                })? == expected_deltas
                    && self.packet(id)?.encode_for_settings(&self.settings)? == bytes,
                "STORAGE_WRITE",
            )
            .map_err(Error::local_integrity)?;
            if let Some(scope) = legacy_readback.as_mut() {
                self.check_legacy_admission_states(
                    (h.parent, id),
                    (&prior, &output.state),
                    &mut || progress(ExecutionProgress::BeforeDurableCommit),
                    scope,
                )?;
            } else {
                ensure(
                    self.state_at_with_readback(
                        h.parent,
                        &mut || progress(ExecutionProgress::BeforeDurableCommit),
                        publication_readback.as_mut(),
                    )? == prior
                        && self.state_at_with_readback(
                            id,
                            &mut || progress(ExecutionProgress::BeforeDurableCommit),
                            publication_readback.as_mut(),
                        )? == output.state,
                    "STORAGE_WRITE",
                )
                .map_err(Error::local_integrity)?;
            }
            crate::ancestry_index::verify_inserted(&tx, index_context, &inserted_ancestry)
                .map_err(Error::local_integrity)?;
            // Keep the last active-state read and all original post-write fences.
            // Only the classical complete-input root arithmetic is shared.
            self.check_active_before_commit_with_root_arithmetic(
                &mut || progress(ExecutionProgress::BeforeDurableCommit),
                publication_readback.as_mut(),
                self.legacy_persisted_root_arithmetic(),
            )?;
            progress(ExecutionProgress::BeforeDurableCommit)?;
            if let Some(scope) = publication_readback.as_mut() {
                scope.validate_consumed(&tx)?;
            }
            if let Some(scope) = legacy_readback.as_mut() {
                // Any use of the shared prefix stays fenced until AFTER the
                // last active/ancestry/control check. Never re-stamp this scope.
                scope.require_unchanged_after_last_write(&tx)?;
            }
            Ok(())
        })();
        // Check the original writer on success and failure. A scope detects a
        // callback's executed transaction replacement; it cannot undo its COMMIT.
        let transaction_result = match original_readback_owner
            .as_ref()
            .map(|owner| owner.same_write_snapshot(&tx))
            .transpose()
        {
            Ok(_) => transaction_result,
            Err(error) => Err(match transaction_result {
                Ok(()) => native_authenticated::readback_scope_error(error),
                Err(first) => Error::local_replay_source("NATIVE_POST_WRITE_SCOPE", first),
            }),
        };
        transaction_result?;
        let commit_observation = (self.state_backend == StateBackend::AuthenticatedV1).then(|| {
            self.authenticated_arithmetic
                .history
                .observe_sql_commit(native_authenticated::SqlCommitSite::AdmissionPersistence)
        });
        let commit_result = tx.commit();
        if let Some(observation) = commit_observation {
            observation.finish_sql_result(&commit_result);
        }
        commit_result?;
        // No cancellation fence after commit: the native durable fact stays true.
        Ok(id)
    }
    pub fn make(
        &self,
        parent: Hash,
        transactions: Vec<Vec<u8>>,
        miner: Hash,
        timestamp: u64,
        max_attempts: u64,
    ) -> Result<Packet> {
        ensure(
            self.settings.task_profile() == trnm_mvcc_fee::pon_executor::LEGACY_TASK_PROFILE,
            "EXPLICIT_TASK_REQUIRED",
        )?;
        let (a, b) = maintenance();
        self.make_from_matrices(parent, transactions, miner, timestamp, max_attempts, &a, &b)
    }
    /// Explicit genesis-maintenance choice; never substitutes for rejected signed
    /// work. Admission and proof verification still use the original Node owner.
    pub fn make_consensus_maintenance(
        &self,
        parent: Hash,
        transactions: Vec<Vec<u8>>,
        miner: Hash,
        timestamp: u64,
        max_attempts: u64,
    ) -> Result<Packet> {
        ensure(
            continuity_v1::enabled(&self.settings.app),
            "CONTINUITY_PROFILE",
        )?;
        let (a, b) = continuity_v1::maintenance_matrices();
        self.make_from_matrices(parent, transactions, miner, timestamp, max_attempts, &a, &b)
    }
    pub fn parent_height(&self, parent: Hash) -> Result<u64> {
        Ok(self.record(parent)?.height)
    }
    pub fn lifecycle_task_lease(
        &self,
        parent: Hash,
        task: Hash,
        height: u64,
    ) -> Result<trnm_protocol::qualified_work_task::lifecycle_v2::DemandLeaseV2> {
        Ok(qualified_task_lifecycle::eligible_task(
            &self.state_at(parent)?,
            task,
            height,
            &self.settings.app,
        )?
        .lease()
        .clone())
    }
    /// Explicit material-bound development route; no implicit maintenance or arbitrary
    /// unsigned source/context can authorize a task in the parent's branch state.
    #[allow(clippy::too_many_arguments)]
    pub fn make_with_task(
        &self,
        parent: Hash,
        transactions: Vec<Vec<u8>>,
        miner: Hash,
        timestamp: u64,
        max_attempts: u64,
        admission: &DevelopmentTaskAdmission,
        material: TaskMaterial<'_>,
    ) -> Result<Packet> {
        self.prepare_with_task(
            parent,
            transactions,
            miner,
            timestamp,
            max_attempts,
            admission,
            material,
        )?
        .search(max_attempts)
    }
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn prepare_with_task(
        &self,
        parent: Hash,
        transactions: Vec<Vec<u8>>,
        miner: Hash,
        timestamp: u64,
        max_attempts: u64,
        admission: &DevelopmentTaskAdmission,
        material: TaskMaterial<'_>,
    ) -> Result<crate::mining::PreparedCandidate> {
        ensure(
            matches!(
                self.settings.task_profile(),
                SIGNED_TASK_PROFILE
                    | LIFECYCLE_TASK_PROFILE
                    | ATOMIC_TASK_PROFILE
                    | OVERLAP_TASK_PROFILE
                    | CONTINUITY_TASK_PROFILE
                    | GROWTH_TASK_PROFILE
                    | CHECKPOINT_TASK_PROFILE
            ),
            "WORK_TASK_PROFILE",
        )?;
        self.parent_height(parent)?.checked_add(1).ok_or("HEIGHT")?;
        let actual = self.state_at(parent)?;
        self.prepare_with_task_from_parent(
            parent,
            transactions,
            miner,
            timestamp,
            max_attempts,
            admission,
            material,
            &actual,
            None,
        )
    }
    /// The registered-material route supplies its first actual parent read. Its
    /// lifecycle eligibility was checked before source admission; V1 eligibility
    /// remains after source admission, preserving the original error order.
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn prepare_with_task_from_parent(
        &self,
        parent: Hash,
        transactions: Vec<Vec<u8>>,
        miner: Hash,
        timestamp: u64,
        max_attempts: u64,
        admission: &DevelopmentTaskAdmission,
        material: TaskMaterial<'_>,
        actual: &State,
        eligibility: Option<ParentTaskEligibility>,
    ) -> Result<crate::mining::PreparedCandidate> {
        ensure(
            matches!(
                self.settings.task_profile(),
                SIGNED_TASK_PROFILE
                    | LIFECYCLE_TASK_PROFILE
                    | ATOMIC_TASK_PROFILE
                    | OVERLAP_TASK_PROFILE
                    | CONTINUITY_TASK_PROFILE
                    | GROWTH_TASK_PROFILE
                    | CHECKPOINT_TASK_PROFILE
            ),
            "WORK_TASK_PROFILE",
        )?;
        let height = self.parent_height(parent)?.checked_add(1).ok_or("HEIGHT")?;
        let eligible = match eligibility {
            Some(eligible) => eligible,
            None => self.eligible_work_task_from_state(actual, admission.matrix_task(), height)?,
        };
        let signed = eligible.manifest().ok_or("TASK_MANIFEST")?;
        let statement_id = match &eligible {
            ParentTaskEligibility::Lifecycle(task) => task.statement_id(),
            ParentTaskEligibility::PqTasksV5(task) => task.statement_id(),
            _ => signed.id().map_err(|_| Error::from("TASK_MANIFEST"))?,
        };
        ensure(
            statement_id == admission.manifest_id(),
            "TASK_ADMISSION_CONTEXT",
        )?;
        ensure(
            hash(b"artifact", &[material.model]) == signed.model
                && hash(b"qualified-task-input-v1", &[material.input]) == signed.input,
            "TASK_MATERIAL",
        )?;
        let (a, b) = derive_matrices(material.model, material.input)
            .map_err(|e| Error::from(format!("TASK_MATERIAL:{e:?}")))?;
        ensure(material.a == a && material.b == b, "TASK_MATRIX_BINDING")?;
        ensure(
            pon_work::task_id(&a, &b).map_err(|_| Error::from("WORK_TASK"))? == signed.matrix_task,
            "TASK_MATRIX_BINDING",
        )?;
        ensure((1..=4096).contains(&max_attempts), "WORK_BUDGET")?;
        self.prepare_from_checked_parent(
            parent,
            transactions,
            miner,
            timestamp,
            &a,
            &b,
            actual,
            &eligible,
        )
    }
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn prepare_with_task_from_parent_controlled(
        &self,
        parent: Hash,
        transactions: Vec<Vec<u8>>,
        miner: Hash,
        timestamp: u64,
        max_attempts: u64,
        admission: &DevelopmentTaskAdmission,
        material: TaskMaterial<'_>,
        actual: &State,
        eligibility: Option<ParentTaskEligibility>,
        control: &ExecutionControl<'_, Error>,
    ) -> Result<crate::mining::PreparedCandidate> {
        ensure(
            matches!(
                self.settings.task_profile(),
                SIGNED_TASK_PROFILE
                    | LIFECYCLE_TASK_PROFILE
                    | ATOMIC_TASK_PROFILE
                    | OVERLAP_TASK_PROFILE
                    | CONTINUITY_TASK_PROFILE
                    | GROWTH_TASK_PROFILE
                    | CHECKPOINT_TASK_PROFILE
            ),
            "WORK_TASK_PROFILE",
        )?;
        let height = self.parent_height(parent)?.checked_add(1).ok_or("HEIGHT")?;
        let eligible = match eligibility {
            Some(eligible) => eligible,
            None => self.eligible_work_task_from_state(actual, admission.matrix_task(), height)?,
        };
        let signed = eligible.manifest().ok_or("TASK_MANIFEST")?;
        let statement_id = match &eligible {
            ParentTaskEligibility::Lifecycle(task) => task.statement_id(),
            ParentTaskEligibility::PqTasksV5(task) => task.statement_id(),
            _ => signed.id().map_err(|_| Error::from("TASK_MANIFEST"))?,
        };
        ensure(
            statement_id == admission.manifest_id(),
            "TASK_ADMISSION_CONTEXT",
        )?;
        ensure(
            hash(b"artifact", &[material.model]) == signed.model
                && hash(b"qualified-task-input-v1", &[material.input]) == signed.input,
            "TASK_MATERIAL",
        )?;
        let (a, b) = derive_matrices(material.model, material.input)
            .map_err(|e| Error::from(format!("TASK_MATERIAL:{e:?}")))?;
        ensure(material.a == a && material.b == b, "TASK_MATRIX_BINDING")?;
        ensure(
            pon_work::task_id(&a, &b).map_err(|_| Error::from("WORK_TASK"))? == signed.matrix_task,
            "TASK_MATRIX_BINDING",
        )?;
        ensure((1..=4096).contains(&max_attempts), "WORK_BUDGET")?;
        self.prepare_from_checked_parent_controlled(
            parent,
            transactions,
            miner,
            timestamp,
            &a,
            &b,
            actual,
            &eligible,
            control,
        )
    }
    fn eligible_work_task(
        &self,
        parent: Hash,
        task: Hash,
        height: u64,
    ) -> Result<Option<QualifiedWorkTask>> {
        self.eligible_work_task_with_progress(parent, task, height, &mut || Ok(()))
    }
    fn eligible_work_task_with_progress(
        &self,
        parent: Hash,
        task: Hash,
        height: u64,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<Option<QualifiedWorkTask>> {
        Ok(self
            .eligible_work_task_from_state(
                &self.state_at_with_progress(parent, progress)?,
                task,
                height,
            )?
            .manifest()
            .cloned())
    }
    fn eligible_work_task_from_state(
        &self,
        state: &State,
        task: Hash,
        height: u64,
    ) -> Result<ParentTaskEligibility> {
        if continuity_v1::enabled(&self.settings.app) && task == continuity_v1::maintenance_task()?
        {
            continuity_v1::check_maintenance(state, task, &self.settings.app)?;
            return Ok(ParentTaskEligibility::ConsensusMaintenance);
        }
        if pq_accounts_v2::tasks_v5_enabled(&self.settings.app) {
            let eligible =
                pq_accounts_v2::tasks_v5::eligible_task(state, task, height, &self.settings.app)?;
            return Ok(ParentTaskEligibility::PqTasksV5(Box::new(eligible)));
        }
        if matches!(
            self.settings.task_profile(),
            LIFECYCLE_TASK_PROFILE
                | ATOMIC_TASK_PROFILE
                | OVERLAP_TASK_PROFILE
                | CONTINUITY_TASK_PROFILE
                | GROWTH_TASK_PROFILE
                | CHECKPOINT_TASK_PROFILE
        ) {
            let eligible =
                qualified_task_lifecycle::eligible_task(state, task, height, &self.settings.app)?;
            return Ok(ParentTaskEligibility::Lifecycle(Box::new(eligible)));
        }
        let registered = state
            .get(&format!("work:{}", hex::encode(task)))
            .ok_or("TASK")?;
        if self.settings.task_profile() != SIGNED_TASK_PROFILE {
            ensure(registered == &Value::Bool(true), "TASK")?;
            return Ok(ParentTaskEligibility::Legacy);
        }
        ensure(
            registered["schema"] == "qualified-work-registration-v1",
            "TASK_MANIFEST",
        )?;
        ensure(
            registered["admitted_height"]
                .as_u64()
                .ok_or("TASK_MANIFEST")?
                < height,
            "TASK_PARENT",
        )?;
        let text = registered["manifest"].as_str().ok_or("TASK_MANIFEST")?;
        ensure(text.len() == SIGNED_TASK_BYTES * 2, "TASK_MANIFEST")?;
        let bytes = hex::decode(text).map_err(|_| Error::from("TASK_MANIFEST"))?;
        ensure(hex::encode(&bytes) == text, "TASK_MANIFEST")?;
        let signed =
            SignedQualifiedWorkTask::decode(&bytes).map_err(|_| Error::from("TASK_MANIFEST"))?;
        ensure(signed.manifest.matrix_task == task, "TASK")?;
        let context = self
            .settings
            .qualified_task_context(signed.manifest.demand_id, height)?;
        let verified = verify_development_statement(&bytes, &context)
            .map_err(|e| Error::from(format!("TASK_STATEMENT:{e:?}")))?;
        ensure(
            registered["manifest_id"] == hex::encode(verified.manifest_id()),
            "TASK_MANIFEST",
        )?;
        ensure(
            state.get(&format!("work-withdrawal:{}", hex::encode(context.source)))
                == Some(&json_value(hex::encode(context.withdrawal_head))),
            "TASK_WITHDRAWAL",
        )?;
        let demand = state
            .get(&format!(
                "work-demand-registry:{}",
                hex::encode(context.demand_id)
            ))
            .ok_or("TASK_DEMAND")?;
        ensure(
            demand["purpose"].as_u64() == Some(signed.manifest.purpose as u64),
            "TASK_PURPOSE",
        )?;
        ensure(
            state.get(&format!("work-demand:{}", hex::encode(context.demand_id)))
                == Some(&json_value(hex::encode(verified.manifest_id()))),
            "TASK_DEMAND",
        )?;
        let source_nonce = state
            .get(&format!("work-source:{}", hex::encode(context.source)))
            .and_then(Value::as_u64)
            .ok_or("TASK_SOURCE_NONCE")?;
        ensure(
            source_nonce >= signed.manifest.demand_nonce,
            "TASK_SOURCE_NONCE",
        )?;
        Ok(ParentTaskEligibility::Signed(Box::new(signed.manifest)))
    }
    #[allow(clippy::too_many_arguments)]
    fn make_from_matrices(
        &self,
        parent: Hash,
        transactions: Vec<Vec<u8>>,
        miner: Hash,
        timestamp: u64,
        max_attempts: u64,
        a: &[u32],
        b: &[u32],
    ) -> Result<Packet> {
        ensure((1..=4096).contains(&max_attempts), "WORK_BUDGET")?;
        self.prepare_from_matrices(parent, transactions, miner, timestamp, a, b)?
            .search(max_attempts)
    }
    pub(crate) fn prepare_from_matrices(
        &self,
        parent: Hash,
        transactions: Vec<Vec<u8>>,
        miner: Hash,
        timestamp: u64,
        a: &[u32],
        b: &[u32],
    ) -> Result<crate::mining::PreparedCandidate> {
        self.ready()?;
        let height = self.record(parent)?.height.checked_add(1).ok_or("HEIGHT")?;
        let task = pon_work::task_id(a, b).map_err(|_| Error::from("WORK_TASK"))?;
        let actual = self.state_at(parent)?;
        let registered_task = self.eligible_work_task_from_state(&actual, task, height)?;
        self.prepare_from_checked_parent(
            parent,
            transactions,
            miner,
            timestamp,
            a,
            b,
            &actual,
            &registered_task,
        )
    }
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn prepare_from_checked_parent(
        &self,
        parent: Hash,
        transactions: Vec<Vec<u8>>,
        miner: Hash,
        timestamp: u64,
        a: &[u32],
        b: &[u32],
        actual: &State,
        registered_task: &ParentTaskEligibility,
    ) -> Result<crate::mining::PreparedCandidate> {
        self.ready()?;
        let height = self.record(parent)?.height.checked_add(1).ok_or("HEIGHT")?;
        let task = pon_work::task_id(a, b).map_err(|_| Error::from("WORK_TASK"))?;
        let executed = self.execute_derived(
            actual,
            ExecutionRequest {
                parent_id: parent,
                transactions: &transactions,
                height,
                timestamp: Some(timestamp),
                miner,
                workers: self.workers,
            },
        )?;
        let mut output = executed.output;
        let commitment = executed.commitment;
        let prepared =
            pon_work::PreparedTask::new(a, b).map_err(|e| Error::from(format!("WORK:{e:?}")))?;
        if registered_task.manifest().is_some()
            && self.record_task_output(
                height,
                &mut output.state,
                registered_task,
                prepared.product_bytes(),
            )?
        {
            output.root = self
                .derive_successor(&output.state, commitment.snapshot.as_ref())?
                .root;
        }
        let header = Header {
            network: self.settings.network(),
            parameters: self.settings.parameters(),
            parent,
            height,
            timestamp,
            target: self.expected_target(parent)?,
            miner,
            transactions: sequence_root("transactions", &transactions),
            state: output.root,
            receipts: sequence_root("receipts", &output.receipts),
            work_task: task,
            nonce: 0,
        };
        Ok(crate::mining::PreparedCandidate {
            header,
            transactions,
            prepared,
        })
    }
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn prepare_from_checked_parent_controlled(
        &self,
        parent: Hash,
        transactions: Vec<Vec<u8>>,
        miner: Hash,
        timestamp: u64,
        a: &[u32],
        b: &[u32],
        actual: &State,
        registered_task: &ParentTaskEligibility,
        control: &ExecutionControl<'_, Error>,
    ) -> Result<crate::mining::PreparedCandidate> {
        self.ready()?;
        let height = self.record(parent)?.height.checked_add(1).ok_or("HEIGHT")?;
        let task = pon_work::task_id(a, b).map_err(|_| Error::from("WORK_TASK"))?;
        let executed = self.execute_derived_with_control(
            actual,
            ExecutionRequest {
                timestamp: Some(timestamp),
                transactions: &transactions,
                height,
                miner,
                parent_id: parent,
                workers: self.workers,
            },
            control,
        )?;
        let mut output = executed.output;
        let commitment = executed.commitment;
        let prepared =
            pon_work::PreparedTask::new(a, b).map_err(|e| Error::from(format!("WORK:{e:?}")))?;
        if registered_task.manifest().is_some()
            && self.record_task_output(
                height,
                &mut output.state,
                registered_task,
                prepared.product_bytes(),
            )?
        {
            output.root = self
                .derive_successor(&output.state, commitment.snapshot.as_ref())?
                .root;
        }
        let header = Header {
            network: self.settings.network(),
            parameters: self.settings.parameters(),
            parent,
            height,
            timestamp,
            target: self.expected_target(parent)?,
            miner,
            transactions: sequence_root("transactions", &transactions),
            state: output.root,
            receipts: sequence_root("receipts", &output.receipts),
            work_task: task,
            nonce: 0,
        };
        Ok(crate::mining::PreparedCandidate {
            header,
            transactions,
            prepared,
        })
    }
    fn record_task_output(
        &self,
        height: u64,
        state: &mut State,
        eligible: &ParentTaskEligibility,
        product: &[u8],
    ) -> Result<bool> {
        record_eligible_output(height, state, eligible, product, &self.settings.app)
    }
    pub fn mine(
        &mut self,
        transactions: Vec<Vec<u8>>,
        timestamp: u64,
        observed_now: u64,
    ) -> Result<Packet> {
        let packet = self.make(
            self.active()?.0,
            transactions,
            development_public(0)?,
            timestamp,
            4096,
        )?;
        let id = self.admit(&packet, observed_now)?;
        self.activate_observed(id, observed_now)?;
        Ok(packet)
    }
    // Reference-budget and other local callers retain their no-cancellation
    // contract; all original transactional validation remains shared.
    fn atomic<T>(&self, run: impl FnOnce() -> Result<T>) -> Result<T> {
        self.atomic_with_progress(&mut || Ok(()), |_| run())
    }
    fn atomic_with_progress<T>(
        &self,
        progress: &mut dyn FnMut() -> Result<()>,
        run: impl FnOnce(&mut dyn FnMut() -> Result<()>) -> Result<T>,
    ) -> Result<T> {
        progress()?;
        let tx = rusqlite::Transaction::new_unchecked(
            &self.db,
            rusqlite::TransactionBehavior::Immediate,
        )?;
        let result = run(progress)?;
        self.check_active_before_commit_with_progress(progress)?;
        self.continuous_scope_checkpoint()?;
        self.mining_scope_checkpoint()?;
        progress()?;
        let commit_observation = (self.state_backend == StateBackend::AuthenticatedV1).then(|| {
            self.authenticated_arithmetic
                .history
                .observe_sql_commit(native_authenticated::SqlCommitSite::Atomic)
        });
        let commit_result = tx.commit();
        if let Some(observation) = commit_observation {
            observation.finish_sql_result(&commit_result);
        }
        commit_result?;
        // No cancellation after COMMIT: the durable result is already factual.
        Ok(result)
    }
    fn atomic_reorg_with_readback<'db>(
        &'db self,
        progress: &mut dyn FnMut() -> Result<()>,
        run: impl FnOnce(
            &mut dyn FnMut() -> Result<()>,
            Option<&trnm_sqlite_io_boundary::TransactionScope<'db>>,
        ) -> Result<Option<native_authenticated::PostWriteReadback<'db>>>,
    ) -> Result<()> {
        self.atomic_with_readback(
            progress,
            native_authenticated::SqlCommitSite::ReorgStep,
            run,
        )
    }
    /// Append and reorganization closures return readback from their explicit
    /// final write boundary. The original writer predates every callback and
    /// write; neither it nor any graph result survives this one transaction.
    fn atomic_with_readback<'db>(
        &'db self,
        progress: &mut dyn FnMut() -> Result<()>,
        commit_site: native_authenticated::SqlCommitSite,
        run: impl FnOnce(
            &mut dyn FnMut() -> Result<()>,
            Option<&trnm_sqlite_io_boundary::TransactionScope<'db>>,
        ) -> Result<Option<native_authenticated::PostWriteReadback<'db>>>,
    ) -> Result<()> {
        progress()?;
        let tx = rusqlite::Transaction::new_unchecked(
            &self.db,
            rusqlite::TransactionBehavior::Immediate,
        )?;
        let original_owner = (self.state_backend == StateBackend::AuthenticatedV1)
            .then(|| {
                trnm_sqlite_io_boundary::TransactionScope::capture(&self.db)
                    .map_err(native_authenticated::readback_scope_error)
            })
            .transpose()?;
        let transaction_result: Result<()> = (|| {
            let mut readback = run(progress, original_owner.as_ref())?;
            {
                let _stage = self
                    .legacy_reorg_step_observation_enabled(commit_site)
                    .then(|| {
                        self.authenticated_arithmetic
                            .history
                            .observe(native_authenticated::HistoryStage::ReadActive)
                    });
                let reorg = matches!(commit_site, native_authenticated::SqlCommitSite::ReorgStep);
                let arithmetic = reorg
                    .then(|| self.legacy_persisted_root_arithmetic())
                    .flatten();
                self.check_active_before_commit_with_root_role(
                    progress,
                    readback.as_mut(),
                    arithmetic,
                    reorg,
                )?;
            }
            self.continuous_scope_checkpoint()?;
            self.mining_scope_checkpoint()?;
            progress()?;
            if let Some(scope) = readback.as_mut() {
                // No legitimate write remains after the closure's explicit
                // boundary. This must follow the LAST caller callback, even
                // when no duplicate graph was consumed by the atomic tail.
                scope.require_unchanged_after_last_write(&self.db)?;
            }
            Ok(())
        })();
        // As in admission, a callback's transaction replacement cannot hide
        // behind an ordinary error/cancellation. Preserve that first error as
        // the source; a write alone does not override a failing callback.
        let transaction_result = match original_owner
            .as_ref()
            .map(|owner| owner.same_write_snapshot(&self.db))
            .transpose()
        {
            Ok(_) => transaction_result,
            Err(error) => Err(match transaction_result {
                Ok(()) => native_authenticated::readback_scope_error(error),
                Err(first) => Error::local_replay_source("NATIVE_POST_WRITE_SCOPE", first),
            }),
        };
        transaction_result?;
        let commit_observation = (self.state_backend == StateBackend::AuthenticatedV1
            || self.legacy_reorg_step_observation_enabled(commit_site))
        .then(|| {
            self.authenticated_arithmetic
                .history
                .observe_sql_commit(commit_site)
        });
        let commit_result = tx.commit();
        if let Some(observation) = commit_observation {
            observation.finish_sql_result(&commit_result);
        }
        commit_result?;
        Ok(())
    }
    fn reorg_post_write_readback<'db>(
        &'db self,
        block: Hash,
        original_owner: Option<&trnm_sqlite_io_boundary::TransactionScope<'_>>,
    ) -> Result<Option<native_authenticated::PostWriteReadback<'db>>> {
        original_owner
            .zip(self.post_write_schema.as_ref())
            .map(|(owner, expected)| {
                native_authenticated::PostWriteReadback::new(
                    &self.db,
                    &self.settings,
                    block,
                    owner,
                    expected,
                )
            })
            .transpose()
            .map(Option::flatten)
    }
    fn apply_delta_with_progress(
        &self,
        id: Hash,
        slot: u64,
        detach: bool,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<()> {
        progress()?;
        let mut read = self
            .db
            .prepare_cached("SELECT value FROM kv WHERE slot=? AND key=?")?;
        let mut write = self
            .db
            .prepare_cached("INSERT OR REPLACE INTO kv VALUES(?,?,?)")?;
        let mut delete = self
            .db
            .prepare_cached("DELETE FROM kv WHERE slot=? AND key=?")?;
        for (key, before, after) in self.delta_rows_with_progress(id, progress)? {
            progress()?;
            let (expected, new) = if detach {
                (after, before)
            } else {
                (before, after)
            };
            let actual: Option<Vec<u8>> = read
                .query_row(params![slot, &key], |r| r.get(0))
                .optional()?;
            ensure(actual == expected, "UNDO_ROOT").map_err(Error::local_integrity)?;
            if let Some(value) = new {
                ensure(
                    write.execute(params![slot, key, value])? == 1,
                    "STORAGE_WRITE",
                )
                .map_err(Error::local_integrity)?;
            } else {
                ensure(delete.execute(params![slot, key])? == 1, "STORAGE_WRITE")
                    .map_err(Error::local_integrity)?;
            }
        }
        Ok(())
    }
    /// The read-only prefix of activation, also used by cold reconciliation.
    fn activation_selection(&self, target: Hash) -> Result<(Hash, u64, Option<u64>)> {
        let (old, generation) = self.active()?;
        let next = if self.record(target)?.work > self.record(old)?.work {
            Some(
                generation
                    .checked_add(1)
                    .filter(|value| *value <= i64::MAX as u64)
                    .ok_or("GENERATION")?,
            )
        } else {
            None
        };
        Ok((old, generation, next))
    }
    pub fn activate(&mut self, target: Hash) -> Result<Hash> {
        if self.state_backend == StateBackend::PermanentAccountGrowthV2 {
            return self.growth_activate(target);
        }
        self.activate_with_fault(target, None)
    }
    pub fn activate_with_fault(
        &mut self,
        target: Hash,
        hook: Option<&mut Hook<'_>>,
    ) -> Result<Hash> {
        self.activate_with_fault_and_progress(target, hook, &mut || Ok(()), None)
    }
    fn activate_with_fault_and_progress(
        &mut self,
        target: Hash,
        mut hook: Option<&mut Hook<'_>>,
        progress: &mut dyn FnMut() -> Result<()>,
        termination_cpu: Option<&crate::ingress::public_v3::ServiceMutationCpuCheckpoint>,
    ) -> Result<Hash> {
        progress()?;
        if self.state_backend == StateBackend::PermanentAccountGrowthV2 {
            ensure(hook.is_none(), "GROWTH_USE_PROGRESS_HOOK")?;
            let progress = RefCell::new(progress);
            return self.growth_activate_with_progress(target, &|_| (progress.borrow_mut())());
        }
        self.continuous_activation_gate(target)?;
        self.mining_activation_gate(target)?;
        self.namespace()?;
        self.resume_owned_reorg(&mut hook, progress, termination_cpu)?;
        let (old, g, next) = self.activation_selection(target)?;
        let Some(next) = next else {
            return Ok(old);
        };
        if self.record(target)?.parent == Some(old) && hook.is_none() {
            let slot = self.slot()?;
            progress()?;
            let prior = self.cached_parent(old)?;
            progress()?;
            let mut staged = None;
            self.atomic_with_readback(
                progress,
                native_authenticated::SqlCommitSite::Atomic,
                |progress, original_owner| {
                    self.apply_delta_with_progress(target, slot, false, progress)?;
                    let state = self.slot_state_with_progress(slot, progress)?;
                    continuity_v1::check_state(
                        &state,
                        self.record(target)?.height,
                        &self.settings.app,
                    )
                    .map_err(|error| Error::from(error).local_integrity())?;
                    progress()?;
                    staged = Some(self.checked_commitment(
                        &state,
                        self.record(target)?.root,
                        prior.as_ref(),
                    )?);
                    progress()?;
                    ensure(
                        self.db.execute(
                            "UPDATE active SET tip=?,generation=? WHERE singleton=1",
                            params![target.as_slice(), next],
                        )? == 1,
                        "STORAGE_WRITE",
                    )
                    .map_err(Error::local_integrity)?;
                    ensure(
                        self.db.execute(
                            "INSERT INTO events VALUES(?,0,1,?)",
                            params![next, target.as_slice()],
                        )? == 1,
                        "STORAGE_WRITE",
                    )
                    .map_err(Error::local_integrity)?;
                    let readback = self.reorg_post_write_readback(target, original_owner)?;
                    ensure(
                        self.active()? == (target, next) && self.slot()? == slot,
                        "GENERATION",
                    )
                    .map_err(Error::local_integrity)?;
                    self.check_events_with_progress(next, &[(0, 1, target)], progress)?;
                    Ok(readback)
                },
            )?;
            ensure(
                self.active()? == (target, next) && self.slot()? == slot,
                "GENERATION",
            )
            .map_err(Error::local_integrity)?;
            self.publish_commitment(target, next, slot, staged.ok_or("ROOT")?);
            return Ok(target);
        }
        // Reorganizations retain the independent full-root path and reseed only
        // after actual durable publication/recovery, never from a stale preview.
        self.invalidate_commitment();
        let mut cancellation =
            self.reserve_reorg_cancellation(old, target, next, termination_cpu)?;
        self.atomic_reorg_with_readback(progress, |progress, original_owner| {
            // Reclaim abandoned staging only inside this original paid native
            // transaction, before any new durable intent exists. Cancellation
            // of this transaction retains the prior terminal lifecycle. This
            // bounds live staging to one full copy without charging a terminal
            // metadata cleanup for an unbounded State delete.
            self.db
                .execute("DELETE FROM kv WHERE slot!=?", [self.slot()?])?;
            self.db.execute(
                "INSERT INTO kv SELECT ?,key,value FROM kv WHERE slot=?",
                params![next, self.slot()?],
            )?;
            self.db.execute("DELETE FROM steps", [])?;
            let mut left = old;
            let mut right = target;
            let mut detached = 0i64;
            let mut attached = 0i64;
            while left != right {
                progress()?;
                if self.record(left)?.height >= self.record(right)?.height {
                    self.db.execute(
                        "INSERT INTO steps VALUES(?,0,?)",
                        params![detached, left.as_slice()],
                    )?;
                    detached = detached.checked_add(1).ok_or("ANCESTRY_LIMIT")?;
                    left = self.parent(left)?;
                } else {
                    attached = attached.checked_add(1).ok_or("ANCESTRY_LIMIT")?;
                    self.db.execute(
                        "INSERT INTO steps VALUES(?,1,?)",
                        params![-attached, right.as_slice()],
                    )?;
                    right = self.parent(right)?;
                }
            }
            let count = detached.checked_add(attached).ok_or("ANCESTRY_LIMIT")?;
            self.db.execute(
                "UPDATE steps SET ordinal=?+ordinal WHERE ordinal<0",
                [count],
            )?;
            self.db.execute(
                "INSERT OR REPLACE INTO reorg VALUES(1,?,?,?,0,0)",
                params![old.as_slice(), target.as_slice(), next],
            )?;
            self.insert_reorg_lifecycle(&mut cancellation)?;
            ensure(
                self.active()? == (old, g)
                    && self.check_steps_with_progress(old, target, 0, progress)? == count as u64,
                "REORG_STEPS",
            )
            .map_err(Error::local_integrity)?;
            self.check_reorg_row(old, target, next, 0, 0)?;
            let mut readback = self.reorg_post_write_readback(old, original_owner)?;
            {
                let _stage = self.native_legacy_reorg_observation_enabled().then(|| {
                    self.authenticated_arithmetic
                        .history
                        .observe(native_authenticated::HistoryStage::VerifyState)
                });
                self.check_persisted_state_with_root_arithmetic(
                    old,
                    &self.slot_state_with_progress(next, progress)?,
                    progress,
                    readback.as_mut(),
                    self.legacy_persisted_root_arithmetic(),
                )?;
            }
            Ok(readback)
        })?;
        let outcome = (|| {
            cut(&mut hook, "intent")?;
            #[cfg(test)]
            if std::mem::take(&mut self.cancel_next_activation_intent) {
                // A test-only pause AFTER the original durable intent commit.
                // Observe the actual caller's original deadline/control: do not
                // inject a different typed error and call it a production timeout.
                // No production environment, socket or caller can select this cut.
                let test_end = std::time::Instant::now() + std::time::Duration::from_secs(11);
                loop {
                    progress()?;
                    assert!(
                        std::time::Instant::now() < test_end,
                        "test activation cut did not observe the original bounded request deadline"
                    );
                    std::thread::sleep(std::time::Duration::from_millis(2));
                }
            }
            self.resume_intent_with_progress(&mut hook, progress)
        })();
        self.finish_or_cancel_reorg(&cancellation, outcome, &mut hook)
    }
    fn check_steps(&self, old: Hash, target: Hash, cursor: u64) -> Result<u64> {
        self.check_steps_with_progress(old, target, cursor, &mut || Ok(()))
    }
    fn check_steps_with_progress(
        &self,
        old: Hash,
        target: Hash,
        cursor: u64,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<u64> {
        progress()?;
        let mut stmt = self
            .db
            .prepare("SELECT ordinal,kind,block FROM steps ORDER BY ordinal")
            .map_err(|error| Error::from(error).local_integrity())?;
        let rows = stmt
            .query_map([], |r| {
                Ok((
                    r.get::<_, u64>(0)?,
                    r.get::<_, u64>(1)?,
                    r.get::<_, Vec<u8>>(2)?,
                ))
            })
            .map_err(|error| Error::from(error).local_integrity())?;
        let mut current = old;
        let mut count = 0u64;
        let mut attaching = false;
        for row in rows {
            progress()?;
            let (ordinal, kind, bytes) =
                row.map_err(|error| Error::from(error).local_integrity())?;
            let id = bytes32(bytes).map_err(Error::local_integrity)?;
            ensure(ordinal == count, "REORG_STEPS").map_err(Error::local_integrity)?;
            match kind {
                0 => {
                    ensure(!attaching && id == current, "REORG_STEPS")
                        .map_err(Error::local_integrity)?;
                    current = self.parent(id).map_err(Error::local_integrity)?;
                }
                1 => {
                    attaching = true;
                    ensure(
                        self.parent(id).map_err(Error::local_integrity)? == current,
                        "REORG_STEPS",
                    )
                    .map_err(Error::local_integrity)?;
                    current = id;
                }
                _ => return Err(Error::from("REORG_STEPS").local_integrity()),
            }
            count = count
                .checked_add(1)
                .ok_or_else(|| Error::from("ANCESTRY_LIMIT").local_integrity())?;
        }
        ensure(current == target && cursor <= count, "REORG_STEPS")
            .map_err(Error::local_integrity)?;
        Ok(count)
    }
    fn check_reorg_row(
        &self,
        old: Hash,
        target: Hash,
        generation: u64,
        cursor: u64,
        done: u64,
    ) -> Result<()> {
        let rows: Vec<ReorgRow> = self
            .db
            .prepare_cached(
                "SELECT old_tip,new_tip,generation,cursor,done FROM reorg ORDER BY singleton",
            )?
            .query_map([], |row| {
                Ok((
                    row.get(0)?,
                    row.get(1)?,
                    row.get(2)?,
                    row.get(3)?,
                    row.get(4)?,
                ))
            })?
            .collect::<std::result::Result<_, _>>()?;
        ensure(
            rows == vec![(old.to_vec(), target.to_vec(), generation, cursor, done)],
            "REORG_STEPS",
        )
        .map_err(Error::local_integrity)
    }
    fn check_events_with_progress(
        &self,
        generation: u64,
        expected: &[(u64, u64, Hash)],
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<()> {
        progress()?;
        let mut statement = self
            .db
            .prepare("SELECT ordinal,kind,block FROM events WHERE generation=? ORDER BY ordinal")?;
        let rows = statement.query_map([generation], |row| {
            Ok((
                row.get::<_, u64>(0)?,
                row.get::<_, u64>(1)?,
                row.get::<_, Vec<u8>>(2)?,
            ))
        })?;
        let mut count = 0usize;
        for row in rows {
            progress()?;
            let (ordinal, kind, id) = row?;
            ensure(
                expected.get(count).is_some_and(|want| {
                    want.0 == ordinal && want.1 == kind && want.2.as_slice() == id.as_slice()
                }),
                "REORG_EVENTS",
            )
            .map_err(Error::local_integrity)?;
            count += 1;
        }
        ensure(count == expected.len(), "REORG_EVENTS").map_err(Error::local_integrity)
    }
    /// Decode every original column even when a journal is already terminal.
    /// Observing only `done` would miss malformed completed-row metadata.
    fn checked_reorg_intent(&self) -> Result<Option<ReorgRow>> {
        let row = self
            .db
            .query_row(
                "SELECT old_tip,new_tip,generation,cursor,done FROM reorg WHERE singleton=1",
                [],
                |r| {
                    Ok((
                        r.get::<_, Vec<u8>>(0)?,
                        r.get::<_, Vec<u8>>(1)?,
                        r.get::<_, u64>(2)?,
                        r.get::<_, u64>(3)?,
                        r.get::<_, u64>(4)?,
                    ))
                },
            )
            .optional()?;
        if let Some((_, _, _, _, done)) = &row {
            ensure(*done <= 2, "REORG_STEPS").map_err(Error::local_integrity)?;
            if *done == 2 {
                self.check_cancelled_reorg_lifecycle()?;
            }
        }
        Ok(row)
    }
    fn resume_intent(&mut self, hook: &mut Option<&mut Hook<'_>>) -> Result<Hash> {
        self.resume_intent_with_progress(hook, &mut || Ok(()))
    }
    fn resume_intent_with_progress(
        &mut self,
        hook: &mut Option<&mut Hook<'_>>,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<Hash> {
        progress()?;
        let Some((old, target, g, position, done)) = self.checked_reorg_intent()? else {
            return Ok(self.active()?.0);
        };
        if done != 0 {
            return Ok(self.active()?.0);
        }
        self.invalidate_commitment();
        let old = bytes32(old)?;
        let target = bytes32(target)?;
        ensure(g > 0 && self.active()? == (old, g - 1), "GENERATION")
            .map_err(Error::local_integrity)?;
        // Control errors are not local-integrity failures. Only malformed
        // retained rows are classified by the checking functions themselves.
        let count = self.check_steps_with_progress(old, target, position, progress)?;
        for index in position..count {
            progress()?;
            let (kind, bytes) = self
                .db
                .prepare_cached("SELECT kind,block FROM steps WHERE ordinal=?")?
                .query_row([index], |r| {
                    Ok((r.get::<_, u64>(0)?, r.get::<_, Vec<u8>>(1)?))
                })?;
            let id = bytes32(bytes)?;
            self.atomic_reorg_with_readback(progress, |progress, original_owner| {
                self.apply_delta_with_progress(id, g, kind == 0, progress)?;
                ensure(
                    self.db
                        .execute("UPDATE reorg SET cursor=? WHERE singleton=1", [index + 1])?
                        == 1,
                    "STORAGE_WRITE",
                )
                .map_err(Error::local_integrity)?;
                self.check_reorg_row(old, target, g, index + 1, 0)?;
                let resulting = if kind == 0 { self.parent(id)? } else { id };
                let mut readback = self.reorg_post_write_readback(resulting, original_owner)?;
                {
                    let _stage = self.native_legacy_reorg_observation_enabled().then(|| {
                        self.authenticated_arithmetic
                            .history
                            .observe(native_authenticated::HistoryStage::VerifyState)
                    });
                    self.check_persisted_state_with_root_arithmetic(
                        resulting,
                        &self.slot_state_with_progress(g, progress)?,
                        progress,
                        readback.as_mut(),
                        self.legacy_persisted_root_arithmetic(),
                    )?;
                }
                Ok(readback)
            })?;
            cut(
                hook,
                &format!("{}:{index}", if kind == 0 { "detach" } else { "attach" }),
            )?;
        }
        let state = self.slot_state_with_progress(g, progress)?;
        progress()?;
        continuity_v1::check_state(&state, self.record(target)?.height, &self.settings.app)
            .map_err(|error| Error::from(error).local_integrity())?;
        let actual_root = match self.legacy_persisted_root_arithmetic() {
            Some(arithmetic) => arithmetic.root(&state)?,
            None => self.settings.state_root(&state)?,
        };
        ensure(actual_root == self.record(target)?.root, "ROOT").map_err(Error::local_integrity)?;
        progress()?;
        cut(hook, "before-publish")?;
        self.atomic_reorg_with_readback(progress, |progress, original_owner| {
            let expected: Vec<(u64, u64, Hash)> = self
                .db
                .prepare("SELECT ordinal,kind,block FROM steps ORDER BY ordinal")?
                .query_map([], |row| {
                    Ok((
                        row.get::<_, u64>(0)?,
                        row.get::<_, u64>(1)?,
                        row.get::<_, Vec<u8>>(2)?,
                    ))
                })?
                .map(|row| {
                    progress()?;
                    let (ordinal, kind, id) = row?;
                    Ok((ordinal, kind, bytes32(id)?))
                })
                .collect::<Result<_>>()?;
            ensure(
                self.db.execute(
                    "UPDATE active SET tip=?,generation=?,state_slot=? WHERE singleton=1",
                    params![target.as_slice(), g, g],
                )? == 1,
                "STORAGE_WRITE",
            )
            .map_err(Error::local_integrity)?;
            ensure(
                self.db.execute(
                    "INSERT INTO events SELECT ?,ordinal,kind,block FROM steps ORDER BY ordinal",
                    [g],
                )? == expected.len(),
                "STORAGE_WRITE",
            )
            .map_err(Error::local_integrity)?;
            ensure(
                self.db
                    .execute("UPDATE reorg SET done=1 WHERE singleton=1", [])?
                    == 1,
                "STORAGE_WRITE",
            )
            .map_err(Error::local_integrity)?;
            self.finish_reorg_lifecycle(old, target, g)?;
            self.db.execute("DELETE FROM kv WHERE slot!=?", [g])?;
            ensure(
                self.active()? == (target, g) && self.slot()? == g,
                "GENERATION",
            )
            .map_err(Error::local_integrity)?;
            self.check_reorg_row(old, target, g, count, 1)?;
            self.check_events_with_progress(g, &expected, progress)?;
            let mut readback = self.reorg_post_write_readback(target, original_owner)?;
            {
                let _stage = self.native_legacy_reorg_observation_enabled().then(|| {
                    self.authenticated_arithmetic
                        .history
                        .observe(native_authenticated::HistoryStage::VerifyState)
                });
                self.check_persisted_state_with_root_arithmetic(
                    target,
                    &self.slot_state_with_progress(g, progress)?,
                    progress,
                    readback.as_mut(),
                    self.legacy_persisted_root_arithmetic(),
                )?;
            }
            Ok(readback)
        })?;
        cut(hook, "published")?;
        Ok(target)
    }
    fn recovery_target(&self) -> Result<Hash> {
        let best: Vec<u8> = self.db.query_row(
            "SELECT id FROM blocks ORDER BY chainwork DESC,height,id LIMIT 1",
            [],
            |row| row.get(0),
        )?;
        bytes32(best)
    }
    pub fn recover(&mut self) -> Result<Hash> {
        if self.state_backend == StateBackend::PermanentAccountGrowthV2 {
            return self.growth_recover();
        }
        if let Some(tip) = self.continuous_recovery_unchanged()? {
            return Ok(tip);
        }
        if let Some(tip) = self.mining_recovery_unchanged()? {
            return Ok(tip);
        }
        self.invalidate_commitment();
        self.namespace()?;
        self.resume_intent(&mut None)?;
        let best = self.recovery_target()?;
        self.activate(best)
    }
    pub fn check_observed_history(&self, tip: Hash, observed_now: u64) -> Result<()> {
        self.check_observed_history_with_progress(tip, observed_now, &mut || Ok(()))
    }
    fn check_observed_history_with_progress(
        &self,
        tip: Hash,
        observed_now: u64,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<()> {
        progress()?;
        if self.state_backend == StateBackend::PermanentAccountGrowthV2 {
            return self.growth_check_observed_history_with_progress(tip, observed_now, progress);
        }
        let bound = observed_now as u128 + self.settings.limit("future_skew_seconds")? as u128;
        let mut current = tip;
        while current != self.settings.genesis() {
            progress()?;
            (current, _) = self.visit_header_batch(current, &mut |_, link| {
                progress()?;
                ensure(link.header.timestamp as u128 <= bound, "TIME_DEFERRED")
            })?;
        }
        progress()
    }
    pub fn activate_observed(&mut self, tip: Hash, observed_now: u64) -> Result<Hash> {
        self.activate_observed_with_progress(tip, observed_now, &mut || Ok(()))
    }
    /// Cooperative existing-packet recovery keeps all original time, owner,
    /// State and journal validation. SQL/root primitives remain indivisible;
    /// cancellation before a commit rolls back only that uncommitted step.
    pub(crate) fn activate_observed_with_progress(
        &mut self,
        tip: Hash,
        observed_now: u64,
        progress: &mut dyn FnMut() -> Result<()>,
    ) -> Result<Hash> {
        self.activate_observed_with_termination(tip, observed_now, progress, None)
    }

    pub(crate) fn activate_observed_with_termination(
        &mut self,
        tip: Hash,
        observed_now: u64,
        progress: &mut dyn FnMut() -> Result<()>,
        termination_cpu: Option<&crate::ingress::public_v3::ServiceMutationCpuCheckpoint>,
    ) -> Result<Hash> {
        progress()?;
        let _measurement = (self.state_backend == StateBackend::AuthenticatedV1).then(|| {
            self.authenticated_arithmetic
                .history
                .observe(native_authenticated::HistoryStage::Activation)
        });
        self.continuous_activation_gate(tip)?;
        self.mining_activation_gate(tip)?;
        self.check_observed_history_with_progress(tip, observed_now, progress)?;
        self.activate_with_fault_and_progress(tip, None, progress, termination_cpu)
    }
    pub fn confirmation(
        &self,
        transaction: Hash,
        included: Hash,
        observed_now: u64,
    ) -> Result<Observation> {
        self.confirmations(&[(transaction, included)], observed_now)?
            .observations
            .into_iter()
            .next()
            .ok_or_else(|| "EMPTY_CONFIRMATION".into())
    }
    pub fn confirmations(
        &self,
        queries: &[(Hash, Hash)],
        observed_now: u64,
    ) -> Result<ConfirmationBatch> {
        if self.state_backend == StateBackend::PermanentAccountGrowthV2 {
            return self.growth_confirmations_with_progress(queries, observed_now, &|_| Ok(()));
        }
        self.confirmations_with_progress(queries, observed_now, &mut |_| Ok(()))
    }
    /// Cancellation produces no partial batch and never stores a reusable clock verdict.
    pub fn confirmations_with_progress(
        &self,
        queries: &[(Hash, Hash)],
        observed_now: u64,
        progress: &mut dyn FnMut(u64) -> Result<()>,
    ) -> Result<ConfirmationBatch> {
        use std::collections::BTreeSet;
        ensure((1..=256).contains(&queries.len()), "CONFIRMATION_LIMIT")?;
        let unique: BTreeSet<_> = queries.iter().copied().collect();
        ensure(unique.len() == queries.len(), "DUPLICATE_QUERY")?;
        progress(0)?;
        // The growth W1/M06 callback is Sync. Never discard it or silently
        // substitute this legacy non-Sync FnMut callback for its checkpoints.
        ensure(
            self.state_backend != StateBackend::PermanentAccountGrowthV2,
            "GROWTH_USE_CONFIRMATION_PROGRESS",
        )?;
        self.ready()?;
        let (tip, generation, _) = self.read_active_with_progress(&mut || progress(0))?;
        let mut included = BTreeMap::new();
        for (transaction, block) in queries {
            if !included.contains_key(block) {
                let row = self.record(*block)?;
                let packet = self.packet(*block)?;
                ensure(
                    packet.header.transactions
                        == sequence_root("transactions", &packet.transactions),
                    "ROOT",
                )?;
                let members: BTreeSet<_> = packet
                    .transactions
                    .iter()
                    .map(|raw| hash(b"tx-id", &[raw]))
                    .collect();
                included.insert(*block, (row, packet.header.target, members));
            }
            ensure(included[block].2.contains(transaction), "MEMBERSHIP")?;
        }
        let observed = self.record(tip)?;
        let mut current = tip;
        let mut found = BTreeSet::new();
        let mut checked = 0u64;
        let bound = observed_now as u128 + self.settings.limit("future_skew_seconds")? as u128;
        while current != self.settings.genesis() {
            // The prior query has ended before cancellation or caller code runs.
            progress(checked)?;
            let (parent, count) = self.visit_header_batch(current, &mut |id, link| {
                if included.contains_key(&id) {
                    found.insert(id);
                }
                ensure(link.header.timestamp as u128 <= bound, "TIME_DEFERRED")
            })?;
            current = parent;
            checked = checked.checked_add(count).ok_or("ANCESTRY_LIMIT")?;
        }
        let depth_required = self.settings.limit("confirmation_depth")?;
        let multiplier = self.settings.limit("confirmation_work_multiplier")?;
        let mut observations = Vec::with_capacity(queries.len());
        for (transaction, block) in queries {
            let (row, target, _) = &included[block];
            let present = found.contains(block);
            let delta = present
                .then(|| observed.work.checked_sub(row.work))
                .transpose()?;
            let depth = present
                .then(|| observed.height.checked_sub(row.height).ok_or("HEIGHT"))
                .transpose()?;
            let threshold = consensus::required_work(*target)?.mul_small(multiplier)?;
            observations.push(Observation {
                transaction: hex::encode(transaction),
                genesis: hex::encode(self.settings.genesis()),
                policy: "installed-depth-and-required-work".into(),
                required_work_delta: hex::encode(threshold.bytes()),
                network: hex::encode(self.settings.network()),
                parameters: hex::encode(self.settings.parameters()),
                included_block: hex::encode(block),
                observed_tip: hex::encode(tip),
                included_height: row.height,
                observed_height: observed.height,
                depth,
                work_delta: delta.map(|w| hex::encode(w.bytes())),
                active_generation: generation,
                observed_now,
                confirmed: depth.is_some_and(|d| d >= depth_required)
                    && delta.is_some_and(|w| w >= threshold),
                reorged: !present,
                finalized: false,
                execution_authority: false,
            });
        }
        progress(checked)?;
        ensure(self.active()? == (tip, generation), "STALE_VIEW")?;
        Ok(ConfirmationBatch {
            observations,
            ancestry_checked: checked,
            distinct_bodies_checked: included.len(),
        })
    }
    /// Bounded public-read metadata. The state root is the admitted header's
    /// commitment, not a fresh scan or audit of the active key/value state.
    pub(crate) fn public_head_metadata(&self) -> Result<Value> {
        self.ready()?;
        let (tip, generation) = self.active()?;
        let row = self.record(tip)?;
        Ok(serde_json::json!({
            "network":hex::encode(self.settings.network()),
            "parameters":hex::encode(self.settings.parameters()),
            "genesis":hex::encode(self.settings.genesis()),
            "tip":hex::encode(tip),"height":row.height,
            "chainwork_hex":hex::encode(row.work.bytes()),
            "state_root":hex::encode(row.root),"generation":generation,
            "context_matches":true,
            "commitment_scope":"admitted-active-header; no fresh key/value audit",
            "production_activation":false
        }))
    }
    /// One public history packet, with exact ancestry and pre-allocation bounds.
    /// No unbounded tempfile spool or multi-packet JSON value is constructed.
    pub(crate) fn public_history_packet(
        &self,
        tip: Hash,
        after: Hash,
        maximum_steps: u64,
        progress: &mut dyn FnMut(u64) -> Result<()>,
    ) -> Result<Vec<Packet>> {
        progress(0)?;
        self.ready()?;
        #[cfg(test)]
        let maximum_steps = self
            .public_history_test_sql_limit
            .map_or(maximum_steps, |limit| maximum_steps.min(limit));
        let lookup = crate::ancestry_index::next_public_request(
            &self.db,
            self.ancestry_context()?,
            tip,
            after,
            maximum_steps,
            progress,
        )?;
        let Some(id) = lookup.next else {
            return Ok(Vec::new());
        };
        progress(lookup.sql_lookups + 1)?;
        // Query the scalar length before materializing a possibly damaged BLOB.
        let maximum = 1_048_576;
        let length: Option<usize> = self.db.query_row(
            "SELECT length(packet) FROM blocks WHERE id=?",
            [id.as_slice()],
            |r| r.get(0),
        )?;
        ensure(
            length.is_some_and(|n| n > 0 && n <= maximum),
            "PUBLIC_HISTORY_BYTES",
        )
        .map_err(Error::local_integrity)?;
        progress(lookup.sql_lookups + 2)?;
        let raw: Vec<u8> = self.db.query_row(
            "SELECT packet FROM blocks WHERE id=? AND length(packet)<=?",
            params![id.as_slice(), maximum],
            |r| r.get(0),
        )?;
        let packet =
            Packet::decode_for_settings(&raw, &self.settings).map_err(Error::local_integrity)?;
        ensure(
            packet.id()? == id
                && packet.header.parent == after
                && packet.header.height == lookup.height,
            "STORAGE_PACKET",
        )?;
        Ok(vec![packet])
    }
    /// Observe whether this exact packet is durably present in this already-open
    /// Node namespace. This never admits, activates, verifies work again, or creates
    /// an operation identity. Absence is only a local observation and cannot prove
    /// that another peer did not receive the packet.
    pub fn exact_packet_observation(&self, packet: &Packet) -> Result<Value> {
        self.ready()?;
        self.namespace()?;
        ensure(
            packet.header.network == self.settings.network()
                && packet.header.parameters == self.settings.parameters(),
            "NETWORK",
        )?;
        let id = packet.id()?;
        let expected = packet.encode_for_settings(&self.settings)?;
        let stored: Option<Vec<u8>> = self
            .db
            .query_row(STORED_PACKET_SQL, [id.as_slice()], |row| row.get(0))
            .optional()?;
        let (tip, generation) = self.active()?;
        let active_tip_record = self.record(tip)?;
        let active_tip_height = active_tip_record.height;
        let active_tip_chainwork_hex = hex::encode(active_tip_record.work.bytes());
        let (
            stored_exact,
            block_height,
            block_chainwork_hex,
            active_chain_member,
            active_depth,
            active_work_depth_hex,
            active_membership_sql_lookups,
        ) = match stored {
            None => (false, None, None, false, None, None, None),
            Some(raw) => {
                ensure(raw == expected, "DUPLICATE_CONTENT")?;
                let retained = self.packet(id)?;
                ensure(
                    retained.encode_for_settings(&self.settings)? == expected,
                    "STORAGE_PACKET",
                )?;
                let block_record = self.record(id)?;
                let block_height = block_record.height;
                let mut active_membership_sql_lookups = 0_u64;
                let active_chain_member = crate::ancestry_index::contains(
                    &self.db,
                    self.ancestry_context()?,
                    tip,
                    id,
                    crate::ancestry_index::READ_SQL_BUDGET,
                    &mut |used| {
                        active_membership_sql_lookups = used;
                        Ok(())
                    },
                )?;
                let active_depth = active_chain_member
                    .then(|| active_tip_height.checked_sub(block_height))
                    .flatten();
                let active_work_depth_hex = active_chain_member
                    .then(|| active_tip_record.work.checked_sub(block_record.work))
                    .transpose()?
                    .map(|work| hex::encode(work.bytes()));
                (
                    true,
                    Some(block_height),
                    Some(hex::encode(block_record.work.bytes())),
                    active_chain_member,
                    active_depth,
                    active_work_depth_hex,
                    Some(active_membership_sql_lookups),
                )
            }
        };
        let accepted_task = if stored_exact && active_chain_member {
            self.accepted_task_observation(packet, tip, generation)?
        } else {
            None
        };
        self.ready()?;
        ensure(self.active()? == (tip, generation), "STALE_VIEW")?;
        Ok(serde_json::json!({
            "schema":"pon-native-exact-packet-observation-v3",
            "block":hex::encode(id),
            "stored_exact":stored_exact,
            "block_height":block_height,
            "block_chainwork_hex":block_chainwork_hex,
            "active_tip":hex::encode(tip),
            "active_tip_height":active_tip_height,
            "active_tip_chainwork_hex":active_tip_chainwork_hex,
            "active_chain_member":active_chain_member,
            "active_depth":active_depth,
            "active_work_depth_hex":active_work_depth_hex,
            "active_membership_sql_lookups":active_membership_sql_lookups,
            "active_membership_sql_budget":crate::ancestry_index::READ_SQL_BUDGET,
            "generation":generation,
            "accepted_task":accepted_task,
            "local_target_only":true,
            "global_absence_authority":false,
            "confirmation_authority":false,
            "finality_authority":false,
            "execution_authority":false,
            "production_activation":false
        }))
    }

    pub fn stats(&self) -> Result<Value> {
        let (tip, g, state) = self.read_active()?;
        let row = self.record(tip)?;
        let blocks: u64 = self
            .db
            .query_row("SELECT COUNT(*) FROM blocks", [], |r| r.get(0))?;
        let events: u64 = self
            .db
            .query_row("SELECT COUNT(*) FROM events", [], |r| r.get(0))?;
        let (authenticated_sessions, authenticated_pending, authenticated_audit_rows) =
            self.authenticated_replay_counts()?;
        let (authenticated_outbox_sessions, authenticated_outbox_pending) =
            self.authenticated_outbox_counts()?;
        Ok(
            serde_json::json!({"network":hex::encode(self.settings.network()),"parameters":hex::encode(self.settings.parameters()),"genesis":hex::encode(self.settings.genesis()),"tip":hex::encode(tip),"height":row.height,"chainwork_hex":hex::encode(row.work.bytes()),"state_root":hex::encode(self.settings.state_root(&state)?),"generation":g,"state_keys":state.len(),"stored_blocks":blocks,"events":events,"authenticated_sessions":authenticated_sessions,"authenticated_pending":authenticated_pending,"authenticated_audit_rows":authenticated_audit_rows,"authenticated_outbox_sessions":authenticated_outbox_sessions,"authenticated_outbox_pending":authenticated_outbox_pending,"production_activation":false}),
        )
    }
}

#[cfg(test)]
mod error_boundary_tests {
    use super::*;
    use crate::{ErrorCode, ErrorKind};
    use std::error::Error as _;

    fn packet(node: &Node, parent: Hash, timestamp: u64, miner: u64) -> Packet {
        node.make(
            parent,
            vec![],
            development_public(miner).unwrap(),
            timestamp,
            4096,
        )
        .unwrap()
    }
    fn local(error: Error, message: &str) {
        assert_eq!(error.to_string(), message);
        assert_eq!(error.kind(), ErrorKind::LocalStructure);
        assert!(error.requires_owner_stop());
    }

    fn replay_frame(
        settings: &Settings,
        frame_sequence: u64,
        payload: &[u8],
    ) -> AuthenticatedPeerFrameV0 {
        let session = PeerSessionIdentityV0::new(
            IoDigest32V0::new(settings.genesis()).unwrap(),
            IoDigest32V0::new(settings.parameters()).unwrap(),
            IoDigest32V0::new([71; 32]).unwrap(),
            IoDigest32V0::new([72; 32]).unwrap(),
            IoDigest32V0::new(crate::authenticated_profile_digest()).unwrap(),
            1,
        )
        .unwrap();
        AuthenticatedPeerFrameV0::new(
            session,
            frame_sequence,
            IoDigest32V0::new(crate::authenticated_payload_digest(payload)).unwrap(),
            payload.len(),
        )
        .unwrap()
    }

    #[test]
    fn retained_completed_reply_shape_stops_and_exact_repair_restores_cached_replay() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let payload = b"completed journal request";
        let response = b"completed journal response";
        let frame = replay_frame(&settings, 1, payload);
        node.begin_authenticated_request(frame, payload).unwrap();
        node.finish_authenticated_request(frame, response).unwrap();
        let counts = node.authenticated_replay_counts().unwrap();

        for (status, damaged_response) in [(1_u64, None), (2_u64, Some(response.as_slice()))] {
            node.db
                .execute(
                    "UPDATE peer_request_audit SET status=?,response=? WHERE session_id=? AND nonce=1",
                    params![status, damaged_response, frame.session().session_id().bytes().as_slice()],
                )
                .unwrap();
            let error = node
                .begin_authenticated_request(frame, payload)
                .unwrap_err();
            assert!(error.is(ErrorCode::AuthReplayAudit));
            assert!(!Error::remote(error.to_string()).requires_owner_stop());
            assert!(!Error::from(error.to_string()).requires_owner_stop());
            local(error, "AUTH_REPLAY_AUDIT");
            assert_eq!(node.authenticated_replay_counts().unwrap(), counts);
        }
        node.db
            .execute(
                "UPDATE peer_request_audit SET status=1,response=? WHERE session_id=? AND nonce=1",
                params![
                    response.as_slice(),
                    frame.session().session_id().bytes().as_slice()
                ],
            )
            .unwrap();
        node.validate_authenticated_replay().unwrap();
        drop(node);
        let mut reopened = Node::open(directory.path(), settings, 1).unwrap();
        assert!(matches!(
            reopened.begin_authenticated_request(frame, payload).unwrap(),
            AuthenticatedReplayDecision::Cached(bytes) if bytes == response
        ));
        assert_eq!(reopened.authenticated_replay_counts().unwrap(), counts);
    }

    #[test]
    fn incoming_replay_payload_pending_and_ack_failures_keep_transport_enum_identity() {
        use trnm_transport::{PeerAdmissionErrorV0 as Peer, PeerFrameVerificationErrorV0};

        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let payload = b"real payload";
        let frame = replay_frame(&settings, 1, payload);
        let error = node
            .begin_authenticated_request(frame, b"bad payload")
            .unwrap_err();
        assert_eq!(
            error.to_string(),
            "AUTH_FRAME:peer frame source rejected: AUTH_PAYLOAD"
        );
        assert_eq!(error.kind(), ErrorKind::ProtocolInvalid);
        assert!(!error.requires_owner_stop());
        assert!(matches!(
            error.source().unwrap().downcast_ref::<PeerFrameVerificationErrorV0<Error>>(),
            Some(PeerFrameVerificationErrorV0::Source(source)) if source.is(ErrorCode::AuthPayload)
        ));
        assert_eq!(node.authenticated_replay_counts().unwrap(), (0, 0, 0));
        node.begin_authenticated_request(frame, payload).unwrap();
        let counts = node.authenticated_replay_counts().unwrap();
        let conflict = replay_frame(&settings, 1, b"new payload");
        let successor = replay_frame(&settings, 2, payload);
        for (candidate, bytes, cause, kind) in [
            (
                conflict,
                b"new payload".as_slice(),
                Peer::ConflictingReplay,
                ErrorKind::IdentityConflict,
            ),
            (
                successor,
                payload.as_slice(),
                Peer::PendingFrame,
                ErrorKind::Capacity,
            ),
        ] {
            let error = node
                .begin_authenticated_request(candidate, bytes)
                .unwrap_err();
            assert_eq!(
                error.to_string(),
                format!("AUTH_FRAME:peer frame boundary failed: {cause}")
            );
            assert_eq!(error.kind(), kind);
            assert!(!error.requires_owner_stop());
            assert!(matches!(
                error.source().unwrap().downcast_ref::<PeerFrameVerificationErrorV0<Error>>(),
                Some(PeerFrameVerificationErrorV0::Boundary(source)) if *source == cause
            ));
            assert_eq!(node.authenticated_replay_counts().unwrap(), counts);
        }
        let error = node
            .finish_authenticated_request(conflict, b"reply")
            .unwrap_err();
        assert_eq!(
            error.to_string(),
            format!("AUTH_REPLAY:{}", Peer::UnexpectedAcknowledgement)
        );
        assert_eq!(error.kind(), ErrorKind::IdentityConflict);
        assert_eq!(
            error.source().unwrap().downcast_ref::<Peer>(),
            Some(&Peer::UnexpectedAcknowledgement)
        );
        assert!(!error.requires_owner_stop());
        assert_eq!(
            node.authenticated_replay_state(frame.session())
                .unwrap()
                .unwrap()
                .pending(),
            Some(frame)
        );
        node.finish_authenticated_request(frame, b"reply").unwrap();

        node.reserve_authenticated_outbound(frame, payload, b"retained wire")
            .unwrap();
        let error = node
            .reserve_authenticated_outbound(conflict, b"new payload", b"other wire")
            .unwrap_err();
        assert_eq!(
            error.to_string(),
            format!(
                "AUTH_OUTBOX_FRAME:peer frame boundary failed: {}",
                Peer::ConflictingReplay
            )
        );
        assert_eq!(error.kind(), ErrorKind::IdentityConflict);
        assert!(!error.requires_owner_stop());
        assert!(matches!(
            error
                .source()
                .unwrap()
                .downcast_ref::<PeerFrameVerificationErrorV0<Error>>(),
            Some(PeerFrameVerificationErrorV0::Boundary(
                Peer::ConflictingReplay
            ))
        ));
        let error = node.finish_authenticated_outbound(conflict).unwrap_err();
        assert_eq!(error.kind(), ErrorKind::IdentityConflict);
        assert_eq!(
            error.source().unwrap().downcast_ref::<Peer>(),
            Some(&Peer::UnexpectedAcknowledgement)
        );
        assert!(!error.requires_owner_stop());
        assert_eq!(
            node.authenticated_outbound_reservation(frame.session())
                .unwrap(),
            (1, Some(b"retained wire".to_vec()))
        );
        node.finish_authenticated_outbound(frame).unwrap();
        assert_eq!(
            node.authenticated_outbound_reservation(frame.session())
                .unwrap(),
            (2, None)
        );
    }

    #[test]
    fn missing_caller_state_and_retired_replies_remain_nonfatal_stale_context() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let payload = b"bounded replay payload";
        let first = replay_frame(&settings, 1, payload);
        for (error, code) in [
            (
                node.finish_authenticated_request(first, b"reply")
                    .unwrap_err(),
                ErrorCode::AuthReplayState,
            ),
            (
                node.finish_authenticated_outbound(first).unwrap_err(),
                ErrorCode::AuthOutboxState,
            ),
        ] {
            assert!(error.is(code));
            assert_eq!(error.to_string(), code.as_str());
            assert_eq!(error.kind(), ErrorKind::StaleContext);
            assert!(!error.requires_owner_stop());
        }
        for nonce in 1..=AUTH_RESPONSE_RETENTION + 1 {
            let frame = replay_frame(&settings, nonce, payload);
            node.begin_authenticated_request(frame, payload).unwrap();
            node.finish_authenticated_request(frame, b"reply").unwrap();
        }
        let error = node
            .begin_authenticated_request(first, payload)
            .unwrap_err();
        assert!(error.is(ErrorCode::AuthReplayRetired));
        assert_eq!(error.to_string(), "AUTH_REPLAY_RETIRED");
        assert_eq!(error.kind(), ErrorKind::StaleContext);
        assert!(!error.requires_owner_stop());
        node.validate_authenticated_replay().unwrap();
        drop(node);
        let mut reopened = Node::open(directory.path(), settings, 1).unwrap();
        assert!(reopened
            .begin_authenticated_request(first, payload)
            .unwrap_err()
            .is(ErrorCode::AuthReplayRetired));
    }

    #[test]
    fn reservation_writes_cannot_report_success_without_complete_durable_state() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let payload = b"reservation payload";
        for nonce in 1..=2 {
            let frame = replay_frame(&settings, nonce, payload);
            let prior = node.authenticated_replay_state(frame.session()).unwrap();
            let counts = node.authenticated_replay_counts().unwrap();
            let replay_write = if nonce == 1 { "INSERT" } else { "UPDATE" };
            for (table, operation, code) in [
                ("peer_replay", replay_write, ErrorCode::AuthReplayState),
                ("peer_request_audit", "INSERT", ErrorCode::AuthReplayAudit),
            ] {
                node.db.execute_batch(&format!(
                    "CREATE TEMP TRIGGER omit_replay_reservation BEFORE {operation} ON {table} BEGIN SELECT RAISE(IGNORE); END;"
                )).unwrap();
                let error = node
                    .begin_authenticated_request(frame, payload)
                    .unwrap_err();
                assert!(error.is(code));
                local(error, code.as_str());
                assert_eq!(node.authenticated_replay_counts().unwrap(), counts);
                assert_eq!(
                    node.authenticated_replay_state(frame.session()).unwrap(),
                    prior
                );
                node.db
                    .execute_batch("DROP TRIGGER omit_replay_reservation;")
                    .unwrap();
            }
            node.begin_authenticated_request(frame, payload).unwrap();
            node.finish_authenticated_request(frame, b"reply").unwrap();

            let prior = node.authenticated_outbox_state(frame.session()).unwrap();
            let counts = node.authenticated_outbox_counts().unwrap();
            node.db.execute_batch(&format!(
                "CREATE TEMP TRIGGER omit_outbox_reservation BEFORE {replay_write} ON peer_outbox BEGIN SELECT RAISE(IGNORE); END;"
            )).unwrap();
            let error = node
                .reserve_authenticated_outbound(frame, payload, b"retained wire")
                .unwrap_err();
            assert!(error.is(ErrorCode::AuthOutboxState));
            local(error, "AUTH_OUTBOX_STATE");
            assert_eq!(node.authenticated_outbox_counts().unwrap(), counts);
            assert_eq!(
                node.authenticated_outbox_state(frame.session()).unwrap(),
                prior
            );
            node.db
                .execute_batch("DROP TRIGGER omit_outbox_reservation;")
                .unwrap();
            node.reserve_authenticated_outbound(frame, payload, b"retained wire")
                .unwrap();
            node.finish_authenticated_outbound(frame).unwrap();
        }
        drop(node);
        let mut reopened = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let frame = replay_frame(&settings, 2, payload);
        assert!(matches!(
            reopened.begin_authenticated_request(frame, payload).unwrap(),
            AuthenticatedReplayDecision::Cached(bytes) if bytes == b"reply"
        ));
        assert_eq!(reopened.authenticated_replay_counts().unwrap(), (1, 0, 2));
        assert_eq!(
            reopened
                .authenticated_outbound_reservation(frame.session())
                .unwrap(),
            (3, None)
        );
    }

    #[test]
    fn journal_transition_row_loss_is_local_and_rollback_preserves_exact_pending_frame() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let payload = b"pending payload";
        let frame = replay_frame(&settings, 1, payload);
        node.begin_authenticated_request(frame, payload).unwrap();
        // A test-owned SQLite trigger forces the already-validated conditional
        // transition to affect no row. The failed transaction must roll back.
        node.db.execute_batch("CREATE TEMP TRIGGER omit_replay_ack BEFORE UPDATE ON peer_request_audit BEGIN SELECT RAISE(IGNORE); END;").unwrap();
        let error = node
            .finish_authenticated_request(frame, b"reply")
            .unwrap_err();
        assert!(error.is(ErrorCode::AuthReplayAudit));
        local(error, "AUTH_REPLAY_AUDIT");
        assert_eq!(
            node.authenticated_replay_state(frame.session())
                .unwrap()
                .unwrap()
                .pending(),
            Some(frame)
        );
        node.db
            .execute_batch("DROP TRIGGER omit_replay_ack;")
            .unwrap();
        node.db.execute_batch("CREATE TEMP TRIGGER omit_replay_frontier BEFORE UPDATE ON peer_replay BEGIN SELECT RAISE(IGNORE); END;").unwrap();
        let error = node
            .finish_authenticated_request(frame, b"reply")
            .unwrap_err();
        assert!(error.is(ErrorCode::AuthReplayState));
        local(error, "AUTH_REPLAY_STATE");
        let status: u64 = node
            .db
            .query_row(
                "SELECT status FROM peer_request_audit WHERE session_id=? AND nonce=1",
                [frame.session().session_id().bytes().as_slice()],
                |row| row.get(0),
            )
            .unwrap();
        assert_eq!(status, 0, "the first acknowledgement update must roll back");
        assert_eq!(
            node.authenticated_replay_state(frame.session())
                .unwrap()
                .unwrap()
                .pending(),
            Some(frame)
        );
        node.db
            .execute_batch("DROP TRIGGER omit_replay_frontier;")
            .unwrap();
        node.finish_authenticated_request(frame, b"reply").unwrap();

        node.reserve_authenticated_outbound(frame, payload, b"retained wire")
            .unwrap();
        node.db.execute_batch("CREATE TEMP TRIGGER omit_outbox_ack BEFORE UPDATE ON peer_outbox BEGIN SELECT RAISE(IGNORE); END;").unwrap();
        let error = node.finish_authenticated_outbound(frame).unwrap_err();
        assert!(error.is(ErrorCode::AuthOutboxState));
        local(error, "AUTH_OUTBOX_STATE");
        assert_eq!(
            node.authenticated_outbound_reservation(frame.session())
                .unwrap(),
            (1, Some(b"retained wire".to_vec()))
        );
        node.db
            .execute_batch("DROP TRIGGER omit_outbox_ack;")
            .unwrap();
        node.finish_authenticated_outbound(frame).unwrap();
        drop(node);
        let reopened = Node::open(directory.path(), settings, 1).unwrap();
        assert_eq!(
            reopened
                .authenticated_outbound_reservation(frame.session())
                .unwrap(),
            (2, None)
        );
        assert_eq!(reopened.authenticated_replay_counts().unwrap(), (1, 0, 1));
    }

    #[test]
    fn retained_header_corruption_and_unknown_caller_locator_have_different_origins() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let block = packet(&node, settings.genesis(), 11, 0);
        let id = node.admit(&block, 1000).unwrap();
        node.activate_observed(id, 1000).unwrap();
        let original = block.encode().unwrap();
        let mut damaged = original.clone();
        damaged[0] ^= 0xff;

        let incoming = Packet::decode(&damaged).unwrap_err();
        assert!(incoming.is(ErrorCode::HeaderCodec));
        assert_eq!(incoming.kind(), ErrorKind::ProtocolInvalid);
        assert!(!incoming.requires_owner_stop());
        node.db
            .execute(
                "UPDATE blocks SET packet=? WHERE id=?",
                params![damaged, id.as_slice()],
            )
            .unwrap();
        local(node.packet(id).unwrap_err(), "HEADER_CODEC");
        local(
            node.check_observed_history(id, 1000).unwrap_err(),
            "HEADER_CODEC",
        );
        node.db
            .execute(
                "UPDATE blocks SET packet=? WHERE id=?",
                params![original, id.as_slice()],
            )
            .unwrap();

        let absent = node.check_observed_history([93; 32], 1000).unwrap_err();
        assert!(absent.is(ErrorCode::UnknownParent));
        assert_eq!(absent.kind(), ErrorKind::StaleContext);
        assert!(!absent.requires_owner_stop());
        assert!(!node
            .packet(settings.genesis())
            .unwrap_err()
            .requires_owner_stop());
        let genesis = node.record(settings.genesis()).unwrap();
        node.db
            .execute(
                "UPDATE blocks SET height=9 WHERE id=?",
                [settings.genesis().as_slice()],
            )
            .unwrap();
        local(
            node.check_observed_history(id, 1000).unwrap_err(),
            "ANCESTRY_HEIGHT",
        );
        // Normal mutations cannot remove a referenced ancestor. Simulate damaged
        // retained storage only in this temporary database, then restore both the
        // exact row and its enforced foreign-key contract before reopening.
        node.db.execute_batch("PRAGMA foreign_keys=OFF").unwrap();
        node.db
            .execute(
                "DELETE FROM blocks WHERE id=?",
                [settings.genesis().as_slice()],
            )
            .unwrap();
        let missing = node.check_observed_history(id, 1000).unwrap_err();
        assert!(missing.is(ErrorCode::UnknownParent));
        local(missing, "UNKNOWN_PARENT");
        node.db
            .execute(
                "INSERT INTO blocks VALUES(?,?,?,?,?,?)",
                params![
                    settings.genesis().as_slice(),
                    Option::<Vec<u8>>::None,
                    genesis.height,
                    genesis.work.bytes().as_slice(),
                    Option::<Vec<u8>>::None,
                    genesis.root.as_slice(),
                ],
            )
            .unwrap();
        node.db.execute_batch("PRAGMA foreign_keys=ON").unwrap();
        let violations: u64 = node
            .db
            .query_row("SELECT COUNT(*) FROM pragma_foreign_key_check", [], |row| {
                row.get(0)
            })
            .unwrap();
        assert_eq!(violations, 0);
        node.check_observed_history(id, 1000).unwrap();
        let before = node.read_active().unwrap();
        drop(node);
        assert_eq!(
            Node::open(directory.path(), settings, 1)
                .unwrap()
                .read_active()
                .unwrap(),
            before
        );
    }

    #[test]
    fn persisted_state_bytes_and_root_are_local_but_progress_errors_keep_their_identity() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let before = node.read_active().unwrap();
        let slot = node.slot().unwrap();
        let (key, bytes): (String, Vec<u8>) = node
            .db
            .query_row(
                "SELECT key,value FROM kv WHERE slot=? ORDER BY key LIMIT 1",
                [slot],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .unwrap();
        let mut noncanonical = bytes.clone();
        noncanonical.push(b' ');
        node.db
            .execute(
                "UPDATE kv SET value=? WHERE slot=? AND key=?",
                params![noncanonical, slot, key],
            )
            .unwrap();
        local(node.read_active().unwrap_err(), "STATE_BYTES");

        node.db
            .execute(
                "UPDATE kv SET value=? WHERE slot=? AND key=?",
                params![b"[".as_slice(), slot, key],
            )
            .unwrap();
        let error = node.read_active().unwrap_err();
        let source = serde_json::from_slice::<Value>(b"[").unwrap_err();
        assert_eq!(error.to_string(), format!("JSON: {source}"));
        assert!(error.source().unwrap().is::<serde_json::Error>());
        assert!(error.requires_owner_stop());

        node.db
            .execute(
                "UPDATE kv SET value=? WHERE slot=? AND key=?",
                params![b"null".as_slice(), slot, key],
            )
            .unwrap();
        local(node.read_active().unwrap_err(), "ROOT");
        node.db
            .execute(
                "UPDATE kv SET value=? WHERE slot=? AND key=?",
                params![bytes, slot, key],
            )
            .unwrap();
        for code in [
            ErrorCode::PublicRequestCancelled,
            ErrorCode::PublicMutationCpuBudget,
            ErrorCode::UnknownParent,
        ] {
            let mut calls = 0;
            let error = node
                .read_active_with_progress(&mut || {
                    calls += 1;
                    if calls == 2 {
                        Err(Error::new(code))
                    } else {
                        Ok(())
                    }
                })
                .unwrap_err();
            assert!(error.is(code));
            assert!(!error.requires_owner_stop());
            assert_eq!(calls, 2);
        }
        assert_eq!(node.read_active().unwrap(), before);
    }

    #[test]
    fn retained_history_cancellation_and_clock_deferral_never_become_storage_failure() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let timestamp = settings.limit("future_skew_seconds").unwrap() + 100;
        let block = packet(&node, settings.genesis(), timestamp, 0);
        let id = node.admit(&block, timestamp).unwrap();
        for code in [
            ErrorCode::PublicRequestCancelled,
            ErrorCode::PublicMutationCpuBudget,
            ErrorCode::UnknownParent,
        ] {
            let mut visited = 0;
            let error = node
                .visit_header_batch(id, &mut |_, _| {
                    visited += 1;
                    Err(Error::new(code))
                })
                .unwrap_err();
            assert!(error.is(code));
            assert!(!error.requires_owner_stop());
            assert_eq!(visited, 1);
        }
        let error = node.check_observed_history(id, 0).unwrap_err();
        assert!(error.is(ErrorCode::TimeDeferred));
        assert_eq!(error.kind(), ErrorKind::StaleContext);
        assert!(!error.requires_owner_stop());
        node.check_observed_history(id, timestamp).unwrap();
    }

    // Independent old walk: deliberately retain both original per-link calls.
    fn recent_reference(node: &Node, mut parent: Hash) -> Result<Vec<(u64, Hash)>> {
        let mut out = Vec::new();
        let bound = node.settings.limit("retarget_interval")?.max(11);
        while parent != node.settings.genesis() && out.len() < bound as usize {
            let header = node.stored_header(parent)?;
            out.push((header.timestamp, header.target));
            parent = node.parent(parent)?;
        }
        if parent == node.settings.genesis() {
            out.push((
                node.settings.genesis_time(),
                node.settings.target("initial_target_hex")?,
            ));
        }
        Ok(out)
    }

    fn recent_chain(node: &mut Node, blocks: u64) -> Vec<Hash> {
        let mut ids = vec![node.settings.genesis()];
        for height in 1..=blocks {
            let block = packet(node, *ids.last().unwrap(), 1 + 10 * height, 0);
            let id = node.admit(&block, 100_000).unwrap();
            node.activate_observed(id, 100_000).unwrap();
            ids.push(id);
        }
        ids
    }

    fn assert_recent_error(node: &Node, tip: Hash) {
        let expected = recent_reference(node, tip).unwrap_err();
        let actual = node.recent(tip).unwrap_err();
        assert_eq!(actual.to_string(), expected.to_string());
        assert_eq!(actual.kind(), expected.kind());
        assert_eq!(actual.requires_owner_stop(), expected.requires_owner_stop());
    }

    #[test]
    fn mining_wall_time_retains_current_parent_full_packet_validation() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let block = packet(&node, settings.genesis(), 11, 0);
        let parent = node.admit(&block, 100_000).unwrap();
        node.activate_observed(parent, 100_000).unwrap();
        let active = node.active().unwrap();
        let raw = block.encode().unwrap();
        let mut corrupt = raw.clone();
        let header_bytes = node.settings.packet_header_length();
        corrupt[header_bytes..header_bytes + 2].copy_from_slice(&257_u16.to_le_bytes());
        node.db
            .execute(
                "UPDATE blocks SET packet=? WHERE id=?",
                params![corrupt, parent.as_slice()],
            )
            .unwrap();
        // Prefix, final trace, length and row bindings are intact. The original
        // full packet parser still rejects this malformed retained body.
        node.stored_header(parent).unwrap();
        local(node.packet(parent).unwrap_err(), "TRANSACTION_LIMIT");
        local(
            node.mining_wall_time_ready(parent, 100_000).unwrap_err(),
            "TRANSACTION_LIMIT",
        );
        assert_eq!(node.active().unwrap(), active);
        node.db
            .execute(
                "UPDATE blocks SET packet=? WHERE id=?",
                params![raw, parent.as_slice()],
            )
            .unwrap();
        assert!(node.mining_wall_time_ready(parent, 100_000).unwrap());
    }

    #[test]
    fn mining_wall_time_retains_genesis_record_and_original_error_checks() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let genesis = settings.genesis();
        let record = node.record(genesis).unwrap();
        assert!(node.mining_wall_time_ready(genesis, 100_000).unwrap());
        node.db
            .execute(
                "UPDATE blocks SET height=1 WHERE id=?",
                [genesis.as_slice()],
            )
            .unwrap();
        let expected = node.packet(genesis).unwrap_err();
        let error = node.mining_wall_time_ready(genesis, 100_000).unwrap_err();
        assert_eq!(error.to_string(), "GENESIS_HAS_NO_PACKET");
        assert_eq!(error.to_string(), expected.to_string());
        assert_eq!(error.kind(), expected.kind());
        assert_eq!(error.requires_owner_stop(), expected.requires_owner_stop());
        node.db
            .execute(
                "UPDATE blocks SET height=0,state_root=? WHERE id=?",
                params![vec![0_u8; 3], genesis.as_slice()],
            )
            .unwrap();
        local(node.parent_height(genesis).unwrap_err(), "STORAGE_HASH");
        local(
            node.mining_wall_time_ready(genesis, 100_000).unwrap_err(),
            "STORAGE_HASH",
        );
        node.db
            .execute(
                "UPDATE blocks SET state_root=? WHERE id=?",
                params![record.root.as_slice(), genesis.as_slice()],
            )
            .unwrap();
        assert!(node.mining_wall_time_ready(genesis, 100_000).unwrap());
    }

    #[test]
    fn mining_wall_time_reads_eleven_headers_and_checks_the_boundary_parent() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings, 1).unwrap();
        let ids = recent_chain(&mut node, 12);
        let counters0 = node.history_read_counters();
        assert!(node.mining_wall_time_ready(ids[12], 100_000).unwrap());
        let counters1 = node.history_read_counters();
        assert_eq!(
            counters1.header_link_queries - counters0.header_link_queries,
            1
        );
        assert_eq!(
            counters1.header_trace_bytes - counters0.header_trace_bytes,
            11 * (node.settings.packet_header_length() as u64 + 32)
        );
        // The twelfth header is outside the clock window. Its record still
        // bounds the final visited link; full-history validation reads its header.
        let raw: Vec<u8> = node
            .db
            .query_row(
                "SELECT packet FROM blocks WHERE id=?",
                [ids[1].as_slice()],
                |r| r.get(0),
            )
            .unwrap();
        let mut corrupt = raw.clone();
        corrupt[0] ^= 0xff;
        node.db
            .execute(
                "UPDATE blocks SET packet=? WHERE id=?",
                params![corrupt, ids[1].as_slice()],
            )
            .unwrap();
        assert!(node.mining_wall_time_ready(ids[12], 100_000).unwrap());
        local(
            node.check_observed_history(ids[12], 100_000).unwrap_err(),
            "HEADER_CODEC",
        );
        node.db
            .execute(
                "UPDATE blocks SET packet=?,height=999 WHERE id=?",
                params![raw, ids[1].as_slice()],
            )
            .unwrap();
        local(
            node.mining_wall_time_ready(ids[12], 100_000).unwrap_err(),
            "ANCESTRY_HEIGHT",
        );
    }

    #[test]
    fn recent_batch_exact_window_and_complete_call_observation() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings, 1).unwrap();
        let ids = recent_chain(&mut node, 70);
        let before = node.read_active().unwrap();
        for &id in &ids {
            assert_eq!(
                node.recent(id).unwrap(),
                recent_reference(&node, id).unwrap()
            );
        }
        for maximum in [1, 2, 11, 16, 63, 64] {
            let mut timestamps = Vec::new();
            let (next, count) = node
                .visit_header_batch_limited(ids[70], maximum, &mut |_, link| {
                    timestamps.push(link.header.timestamp);
                    Ok(())
                })
                .unwrap();
            assert_eq!(count, maximum);
            assert_eq!(next, ids[70 - maximum as usize]);
            assert_eq!(
                timestamps,
                (71 - maximum..=70)
                    .rev()
                    .map(|h| 1 + 10 * h)
                    .collect::<Vec<_>>()
            );
        }
        for maximum in [0, HISTORY_HEADER_BATCH + 1] {
            let mut called = false;
            assert_eq!(
                node.visit_header_batch_limited(ids[70], maximum, &mut |_, _| {
                    called = true;
                    Ok(())
                })
                .unwrap_err()
                .to_string(),
                "ANCESTRY_LIMIT"
            );
            assert!(!called);
        }
        let n = 100_u64;
        let start = std::time::Instant::now();
        let counters0 = node.history_read_counters();
        for _ in 0..n {
            std::hint::black_box(recent_reference(&node, ids[70]).unwrap());
        }
        let reference_ns = start.elapsed().as_nanos();
        let counters1 = node.history_read_counters();
        let start = std::time::Instant::now();
        for _ in 0..n {
            std::hint::black_box(node.recent(ids[70]).unwrap());
        }
        let batched_ns = start.elapsed().as_nanos();
        let counters2 = node.history_read_counters();
        let bound = node.settings.limit("retarget_interval").unwrap().max(11);
        assert_eq!(
            counters1.header_link_queries - counters0.header_link_queries,
            n * bound
        );
        assert_eq!(
            counters2.header_link_queries - counters1.header_link_queries,
            n * bound.div_ceil(HISTORY_HEADER_BATCH)
        );
        assert_eq!(
            counters2.header_trace_bytes - counters1.header_trace_bytes,
            counters1.header_trace_bytes - counters0.header_trace_bytes
        );
        assert_eq!(node.read_active().unwrap(), before);
        println!(
            "{}",
            serde_json::json!({
                "schema": "native-recent-batch-complete-call-v1", "calls_per_path": n,
                "reference_header_projection_queries": counters1.header_link_queries - counters0.header_link_queries,
                "batched_header_projection_queries": counters2.header_link_queries - counters1.header_link_queries,
                "reference_complete_wall_ns": reference_ns, "batched_complete_wall_ns": batched_ns,
                "returned_header_trace_bytes_per_path": counters2.header_trace_bytes - counters1.header_trace_bytes,
                "all_sql_statements_counted": false, "state_unchanged": true,
                "quadratic_observed_history_removed": false, "confirmed_transaction_tps": false,
                "independent_wan": false, "scope": "local complete recent-target calls; no cross-call verdict cache"
            })
        );
    }

    #[test]
    fn recent_batch_retained_corruption_and_read_boundary_match_original() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings, 1).unwrap();
        let ids = recent_chain(&mut node, 70);
        let before = node.read_active().unwrap();
        let bound = node.settings.limit("retarget_interval").unwrap().max(11) as usize;
        let first = 71 - bound;
        let expected = node.recent(ids[70]).unwrap();
        assert_recent_error(&node, [93; 32]);
        // An earlier header body lies outside the recent window, but must still
        // be inspected by the unchanged whole-history current-clock validator.
        for height in [first - 1, first, 70] {
            let raw: Vec<u8> = node
                .db
                .query_row(
                    "SELECT packet FROM blocks WHERE id=?",
                    [ids[height].as_slice()],
                    |r| r.get(0),
                )
                .unwrap();
            let mut corrupt = raw.clone();
            corrupt[0] ^= 0xff;
            node.db
                .execute(
                    "UPDATE blocks SET packet=? WHERE id=?",
                    params![corrupt, ids[height].as_slice()],
                )
                .unwrap();
            if height == first - 1 {
                assert_eq!(node.recent(ids[70]).unwrap(), expected);
                assert_eq!(recent_reference(&node, ids[70]).unwrap(), expected);
            } else {
                assert_recent_error(&node, ids[70]);
            }
            local(
                node.check_observed_history(ids[70], 100_000).unwrap_err(),
                "HEADER_CODEC",
            );
            node.db
                .execute(
                    "UPDATE blocks SET packet=? WHERE id=?",
                    params![raw, ids[height].as_slice()],
                )
                .unwrap();
            assert_eq!(node.recent(ids[70]).unwrap(), expected);
        }
        // The final visited header's parent is still fully shape-checked.
        use rusqlite::types::Value as SqlValue;
        for (column, corrupt) in [
            ("height", SqlValue::Integer(999)),
            ("chainwork", SqlValue::Blob(vec![0; 3])),
            ("state_root", SqlValue::Blob(vec![0; 3])),
            ("parent", SqlValue::Blob(vec![0; 3])),
        ] {
            let id = ids[first - 1];
            let raw: SqlValue = node
                .db
                .query_row(
                    &format!("SELECT {column} FROM blocks WHERE id=?"),
                    [id.as_slice()],
                    |r| r.get(0),
                )
                .unwrap();
            let sql = format!("UPDATE blocks SET {column}=? WHERE id=?");
            node.db
                .execute(&sql, params![corrupt, id.as_slice()])
                .unwrap();
            assert_recent_error(&node, ids[70]);
            node.db.execute(&sql, params![raw, id.as_slice()]).unwrap();
        }
        // A missing retained parent must not become an unknown caller verdict.
        node.db
            .execute_batch("PRAGMA foreign_keys=OFF; BEGIN IMMEDIATE;")
            .unwrap();
        node.db
            .execute("DELETE FROM blocks WHERE id=?", [ids[first - 1].as_slice()])
            .unwrap();
        assert_recent_error(&node, ids[70]);
        assert!(node.recent(ids[70]).unwrap_err().requires_owner_stop());
        node.db
            .execute_batch("ROLLBACK; PRAGMA foreign_keys=ON;")
            .unwrap();
        let genesis_height: u64 = node
            .db
            .query_row(
                "SELECT height FROM blocks WHERE id=?",
                [ids[0].as_slice()],
                |r| r.get(0),
            )
            .unwrap();
        node.db
            .execute("UPDATE blocks SET height=9 WHERE id=?", [ids[0].as_slice()])
            .unwrap();
        assert_recent_error(&node, ids[1]);
        node.db
            .execute(
                "UPDATE blocks SET height=? WHERE id=?",
                params![genesis_height, ids[0].as_slice()],
            )
            .unwrap();
        assert_eq!(node.read_active().unwrap(), before);
        assert_eq!(node.recent(ids[70]).unwrap(), expected);
    }

    #[test]
    fn recent_batch_branch_reopen_and_callback_errors_preserve_context() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let ids = recent_chain(&mut node, 20);
        let mut fork = ids[10];
        for height in 11..=22 {
            let block = packet(&node, fork, 2 + height * 10, 1);
            fork = node.admit(&block, 100_000).unwrap();
            assert_eq!(
                node.recent(fork).unwrap(),
                recent_reference(&node, fork).unwrap()
            );
        }
        node.activate_observed(fork, 100_000).unwrap();
        for code in [
            ErrorCode::PublicRequestCancelled,
            ErrorCode::PublicMutationCpuBudget,
            ErrorCode::UnknownParent,
        ] {
            let mut visited = 0;
            let error = node
                .visit_header_batch_limited(fork, 11, &mut |_, _| {
                    visited += 1;
                    Err(Error::new(code))
                })
                .unwrap_err();
            assert!(error.is(code));
            assert!(!error.requires_owner_stop());
            assert_eq!(visited, 1);
        }
        let expected = node.recent(fork).unwrap();
        let before = node.read_active().unwrap();
        drop(node);
        let reopened = Node::open(directory.path(), settings, 1).unwrap();
        assert_eq!(reopened.read_active().unwrap(), before);
        assert_eq!(reopened.recent(fork).unwrap(), expected);
        assert_eq!(
            reopened.recent(ids[20]).unwrap(),
            recent_reference(&reopened, ids[20]).unwrap()
        );
        reopened.check_observed_history(fork, 100_000).unwrap();
    }

    #[test]
    fn durable_reorg_faults_stop_and_exact_repair_resumes_without_losing_hook_cancellation() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let left = packet(&node, settings.genesis(), 11, 0);
        let left_id = node.admit(&left, 1000).unwrap();
        node.activate_observed(left_id, 1000).unwrap();
        let right = packet(&node, settings.genesis(), 12, 1);
        let right_id = node.admit(&right, 1000).unwrap();
        let target = packet(&node, right_id, 22, 1);
        let target_id = node.admit(&target, 1000).unwrap();
        let expected = node.state_at(target_id).unwrap();
        let original_active = node.active().unwrap();
        let mut at_intent = 0;
        let error = node
            .activate_with_fault(
                target_id,
                Some(&mut |point| {
                    if point == "intent" {
                        at_intent += 1;
                        Err(Error::new(ErrorCode::PublicRequestCancelled))
                    } else {
                        Ok(())
                    }
                }),
            )
            .unwrap_err();
        assert!(error.is(ErrorCode::PublicRequestCancelled));
        assert!(!error.requires_owner_stop());
        assert_eq!(at_intent, 1);
        assert_eq!(node.active().unwrap(), original_active);

        // Typed cancellation now terminates only unpublished staging. Keep
        // that assertion, then create an actually pending native fault before
        // exercising the original durable-corruption/recovery checks below.
        assert_eq!(
            node.db
                .query_row::<u64, _, _>("SELECT done FROM reorg WHERE singleton=1", [], |row| row
                    .get(0))
                .unwrap(),
            2
        );
        let error = node
            .activate_with_fault(
                target_id,
                Some(&mut |point| {
                    if point == "intent" {
                        Err(Error::new(ErrorCode::StoragePacket).local_integrity())
                    } else {
                        Ok(())
                    }
                }),
            )
            .unwrap_err();
        local(error, "STORAGE_PACKET");
        assert_eq!(node.active().unwrap(), original_active);
        assert_eq!(
            node.db
                .query_row::<u64, _, _>(
                    "SELECT COUNT(*) FROM reorg_lifecycle_v1 WHERE outcome=2",
                    [],
                    |row| row.get(0)
                )
                .unwrap(),
            1
        );

        let kind: u64 = node
            .db
            .query_row("SELECT kind FROM steps WHERE ordinal=0", [], |row| {
                row.get(0)
            })
            .unwrap();
        node.db
            .execute("UPDATE steps SET kind=9 WHERE ordinal=0", [])
            .unwrap();
        local(node.recover().unwrap_err(), "REORG_STEPS");
        node.db
            .execute("UPDATE steps SET kind=? WHERE ordinal=0", [kind])
            .unwrap();
        let generation: u64 = node
            .db
            .query_row(
                "SELECT generation FROM reorg WHERE singleton=1",
                [],
                |row| row.get(0),
            )
            .unwrap();
        node.db
            .execute(
                "UPDATE reorg SET generation=? WHERE singleton=1",
                [generation + 1],
            )
            .unwrap();
        local(node.recover().unwrap_err(), "GENERATION");
        node.db
            .execute(
                "UPDATE reorg SET generation=? WHERE singleton=1",
                [generation],
            )
            .unwrap();

        let (key, prior): (String, Option<Vec<u8>>) = node
            .db
            .query_row(
                "SELECT key,before FROM deltas WHERE block=? ORDER BY key LIMIT 1",
                [right_id.as_slice()],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .unwrap();
        node.db
            .execute(
                "UPDATE deltas SET before=? WHERE block=? AND key=?",
                params![b"false".as_slice(), right_id.as_slice(), key],
            )
            .unwrap();
        local(node.recover().unwrap_err(), "UNDO_ROOT");
        assert_eq!(node.active().unwrap(), original_active);
        node.db
            .execute(
                "UPDATE deltas SET before=? WHERE block=? AND key=?",
                params![prior, right_id.as_slice(), key],
            )
            .unwrap();
        assert_eq!(node.recover().unwrap(), target_id);
        assert_eq!(node.read_active().unwrap().2, expected);
        drop(node);
        let reopened = Node::open(directory.path(), settings, 1).unwrap();
        assert_eq!(reopened.active().unwrap().0, target_id);
        assert_eq!(reopened.read_active().unwrap().2, expected);
    }

    #[test]
    fn actual_replay_and_outbox_recovery_preserve_typed_local_sources() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        // Exercise the durable replay owner's typed input. Authentication of
        // signed wire frames remains covered by the existing ingress tests.
        let session = PeerSessionIdentityV0::new(
            IoDigest32V0::new(settings.genesis()).unwrap(),
            IoDigest32V0::new(settings.parameters()).unwrap(),
            IoDigest32V0::new([71; 32]).unwrap(),
            IoDigest32V0::new([72; 32]).unwrap(),
            IoDigest32V0::new(crate::authenticated_profile_digest()).unwrap(),
            1,
        )
        .unwrap();
        let payload = b"actual replay component payload";
        let frame = AuthenticatedPeerFrameV0::new(
            session,
            1,
            IoDigest32V0::new(crate::authenticated_payload_digest(payload)).unwrap(),
            payload.len(),
        )
        .unwrap();
        assert!(matches!(
            node.begin_authenticated_request(frame, payload).unwrap(),
            AuthenticatedReplayDecision::Execute
        ));
        node.db
            .execute(
                "UPDATE peer_replay SET chain_id=? WHERE session_id=?",
                params![
                    [0_u8; 32].as_slice(),
                    session.session_id().bytes().as_slice()
                ],
            )
            .unwrap();
        let error = node
            .begin_authenticated_request(frame, payload)
            .unwrap_err();
        assert_eq!(
            error.to_string(),
            "AUTH_REPLAY:peer identity digest may not be zero"
        );
        assert!(error
            .source()
            .unwrap()
            .is::<trnm_transport::PeerAdmissionErrorV0>());
        assert!(error.requires_owner_stop());
        assert!(!Error::remote(error.to_string()).requires_owner_stop());
        node.db
            .execute(
                "UPDATE peer_replay SET chain_id=? WHERE session_id=?",
                params![
                    settings.genesis().as_slice(),
                    session.session_id().bytes().as_slice()
                ],
            )
            .unwrap();

        node.db
            .execute(
                "UPDATE peer_request_audit SET payload=? WHERE session_id=?",
                params![
                    b"damaged".as_slice(),
                    session.session_id().bytes().as_slice()
                ],
            )
            .unwrap();
        let error = node
            .begin_authenticated_request(frame, payload)
            .unwrap_err();
        assert_eq!(
            error.to_string(),
            "AUTH_RECOVERY:peer recovery source rejected: AUTH_PENDING_AUDIT"
        );
        assert!(error
            .source()
            .unwrap()
            .is::<trnm_transport::PeerRecoveryErrorV0<Error>>());
        assert!(error.requires_owner_stop());
        node.db
            .execute(
                "UPDATE peer_request_audit SET payload=? WHERE session_id=?",
                params![payload.as_slice(), session.session_id().bytes().as_slice()],
            )
            .unwrap();
        let conflicting =
            AuthenticatedPeerFrameV0::new(session, 1, IoDigest32V0::new([81; 32]).unwrap(), 7)
                .unwrap();
        let refusal = node
            .begin_authenticated_request(conflicting, b"changed")
            .unwrap_err();
        assert_eq!(
            refusal.to_string(),
            "AUTH_FRAME:peer frame boundary failed: pending peer frame replay changed its payload"
        );
        assert!(!refusal.requires_owner_stop());
        node.finish_authenticated_request(frame, b"actual retained response")
            .unwrap();

        node.reserve_authenticated_outbound(frame, payload, b"retained outbound wire")
            .unwrap();
        node.db
            .execute(
                "UPDATE peer_outbox SET pending_payload=? WHERE session_id=?",
                params![
                    b"damaged".as_slice(),
                    session.session_id().bytes().as_slice()
                ],
            )
            .unwrap();
        let error = node
            .authenticated_outbound_reservation(session)
            .unwrap_err();
        assert_eq!(
            error.to_string(),
            "AUTH_OUTBOX_RECOVERY:peer recovery source rejected: AUTH_OUTBOX_PENDING"
        );
        assert!(error
            .source()
            .unwrap()
            .is::<trnm_transport::PeerRecoveryErrorV0<Error>>());
        assert!(error.requires_owner_stop());
        node.db
            .execute(
                "UPDATE peer_outbox SET pending_payload=? WHERE session_id=?",
                params![payload.as_slice(), session.session_id().bytes().as_slice()],
            )
            .unwrap();
        drop(node);
        let mut reopened = Node::open(directory.path(), settings, 1).unwrap();
        assert!(matches!(
            reopened
                .begin_authenticated_request(frame, payload)
                .unwrap(),
            AuthenticatedReplayDecision::Cached(_)
        ));
        assert_eq!(
            reopened
                .authenticated_outbound_reservation(session)
                .unwrap(),
            (1, Some(b"retained outbound wire".to_vec()))
        );
    }
}

#[cfg(test)]
mod public_read_bounds_tests {
    use super::*;
    #[test]
    fn corrupt_packet_shapes_are_rejected_before_blob_load() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let genesis = settings.genesis();
        let row = node.record(genesis).unwrap();
        // Deliberately corrupt local rows test read boundaries, not consensus admission.
        node.db
            .execute(
                "INSERT INTO blocks VALUES(?,?,?,?,?,?)",
                params![
                    [1_u8; 32].as_slice(),
                    genesis.as_slice(),
                    4097_u64,
                    row.work.bytes().as_slice(),
                    Option::<Vec<u8>>::None,
                    row.root.as_slice()
                ],
            )
            .unwrap();
        let mut steps = Vec::new();
        let e = node
            .public_history_packet(
                [1; 32],
                genesis,
                crate::ancestry_index::READ_SQL_BUDGET,
                &mut |n| {
                    steps.push(n);
                    Ok(())
                },
            )
            .unwrap_err();
        assert_eq!(e.to_string(), "ANCESTRY_INDEX_PACKET_BYTES");
        assert_eq!(steps, vec![0, 1]);
        node.db
            .execute(
                "INSERT INTO blocks VALUES(?,?,?,?,?,?)",
                params![
                    [2_u8; 32].as_slice(),
                    genesis.as_slice(),
                    1_u64,
                    row.work.bytes().as_slice(),
                    vec![0_u8; 1_048_577],
                    row.root.as_slice()
                ],
            )
            .unwrap();
        let e = node
            .public_history_packet(
                [2; 32],
                genesis,
                crate::ancestry_index::READ_SQL_BUDGET,
                &mut |_| Ok(()),
            )
            .unwrap_err();
        assert_eq!(e.to_string(), "ANCESTRY_INDEX_PACKET_BYTES");
    }
}

#[cfg(test)]
mod native_ancestry_tests {
    use super::*;
    use trnm_crypto_primitives::{sign_hex, signing_key_from_hex};
    use trnm_protocol::pon_wire::Envelope;
    fn transfer(node: &Node) -> Vec<u8> {
        let sender = development_public(0).unwrap();
        let mut payload = development_public(1).unwrap().to_vec();
        payload.extend(1_u64.to_le_bytes());
        let mut tx = Envelope {
            network: node.settings().network(),
            sender,
            nonce: node.next_nonce(sender).unwrap(),
            expiry: 1000,
            fee_limit: 1_000_000,
            tag: 1,
            payload,
            signature: [0; 64],
        };
        let key =
            signing_key_from_hex(&hex::encode(hash(b"DEV-ONLY-KEY", &[&0_u64.to_le_bytes()])))
                .unwrap();
        tx.signature = hex::decode(sign_hex(&key, &tx.signing_digest().unwrap()))
            .unwrap()
            .try_into()
            .unwrap();
        tx.encode().unwrap()
    }
    fn make(node: &Node, parent: Hash, height: u64, miner: u64, txs: Vec<Vec<u8>>) -> Packet {
        node.make(
            parent,
            txs,
            development_public(miner).unwrap(),
            1 + height * 10,
            4096,
        )
        .unwrap()
    }
    #[test]
    fn local_state_cancellation_rolls_back_all_packet_rows_and_reopens_original_state() {
        for cancel_at in [
            ExecutionProgress::AfterPrepare { index: 0 },
            ExecutionProgress::AfterApply { index: 0 },
            ExecutionProgress::AfterCommitment,
            ExecutionProgress::BeforePersistence,
            ExecutionProgress::PersistenceDelta { index: 0 },
            ExecutionProgress::BeforeDurableCommit,
        ] {
            let dir = tempfile::tempdir().unwrap();
            let settings = Settings::development(Some(1)).unwrap();
            let mut node = Node::open(dir.path(), settings.clone(), 2).unwrap();
            let packet = make(&node, settings.genesis(), 1, 0, vec![transfer(&node)]);
            let id = packet.id().unwrap();
            let before = node.read_active().unwrap();
            let sender = development_public(0).unwrap();
            let nonce = node.next_nonce(sender).unwrap();
            let tables = [
                "blocks",
                "deltas",
                "ancestry_jump",
                "snapshots",
                "kv",
                "events",
                "steps",
                "reorg",
            ];
            let counts = |owner: &Node| {
                tables
                    .iter()
                    .map(|table| {
                        owner
                            .db
                            .query_row(&format!("SELECT COUNT(*) FROM {table}"), [], |row| {
                                row.get::<_, u64>(0)
                            })
                            .unwrap()
                    })
                    .collect::<Vec<_>>()
            };
            let original_counts = counts(&node);
            let reached = std::sync::atomic::AtomicBool::new(false);
            let checked = WorkCheckedPacket::verify(packet).unwrap();
            let error = node
                .admit_work_checked_with_progress(checked, 1000, &|point| {
                    if point == cancel_at {
                        reached.store(true, std::sync::atomic::Ordering::Release);
                        Err("PUBLIC_REQUEST_CANCELLED".into())
                    } else {
                        Ok(())
                    }
                })
                .unwrap_err();
            assert_eq!(error.to_string(), "PUBLIC_REQUEST_CANCELLED");
            assert!(reached.load(std::sync::atomic::Ordering::Acquire));
            assert_eq!(counts(&node), original_counts);
            assert!(node.record(id).is_err());
            assert_eq!(node.read_active().unwrap(), before);
            assert_eq!(node.next_nonce(sender).unwrap(), nonce);
            drop(node);
            let reopened = Node::open(dir.path(), settings, 2).unwrap();
            assert_eq!(counts(&reopened), original_counts);
            assert_eq!(reopened.read_active().unwrap(), before);
            assert_eq!(reopened.next_nonce(sender).unwrap(), nonce);
            assert!(reopened.record(id).is_err());
        }
    }

    #[test]
    fn checked_parent_binding_preserves_both_cancellation_boundaries_and_state() {
        let dir = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let node = Node::open(dir.path(), settings.clone(), 2).unwrap();
        let before = node.read_active().unwrap();
        let counts = |owner: &Node| {
            [
                "blocks",
                "deltas",
                "ancestry_jump",
                "snapshots",
                "kv",
                "events",
                "steps",
                "reorg",
            ]
            .map(|table| {
                owner
                    .db
                    .query_row(&format!("SELECT COUNT(*) FROM {table}"), [], |row| {
                        row.get::<_, u64>(0)
                    })
                    .unwrap()
            })
        };
        let original_counts = counts(&node);
        for cancel_at in [1, 2] {
            let calls = std::sync::atomic::AtomicUsize::new(0);
            let error = node
                .execute_derived_with_progress(
                    &before.2,
                    ExecutionRequest {
                        timestamp: None,
                        transactions: &[],
                        height: 1,
                        miner: development_public(0).unwrap(),
                        parent_id: settings.genesis(),
                        workers: 2,
                    },
                    &|point| {
                        if point == ExecutionProgress::BeforeParentBinding
                            && calls.fetch_add(1, std::sync::atomic::Ordering::Relaxed) + 1
                                == cancel_at
                        {
                            Err("COMMITMENT_ROOT".into())
                        } else {
                            Ok(())
                        }
                    },
                )
                .unwrap_err();
            assert_eq!(error.to_string(), "COMMITMENT_ROOT");
            assert_eq!(calls.load(std::sync::atomic::Ordering::Relaxed), cancel_at);
            assert_eq!(counts(&node), original_counts);
            assert_eq!(node.read_active().unwrap(), before);
        }
        let calls = std::sync::atomic::AtomicUsize::new(0);
        let output = node
            .execute_derived_with_progress(
                &before.2,
                ExecutionRequest {
                    timestamp: None,
                    transactions: &[],
                    height: 1,
                    miner: development_public(0).unwrap(),
                    parent_id: settings.genesis(),
                    workers: 2,
                },
                &|point| {
                    if point == ExecutionProgress::BeforeParentBinding {
                        calls.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                    }
                    Ok(())
                },
            )
            .unwrap();
        assert_eq!(calls.load(std::sync::atomic::Ordering::Relaxed), 2);
        assert_eq!(output.output.root, root(&output.output.state).unwrap());
        assert_eq!(counts(&node), original_counts);
        assert_eq!(node.read_active().unwrap(), before);
    }

    #[test]
    fn local_cancel_named_like_commitment_error_never_retries_full_preview() {
        let dir = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let node = Node::open(dir.path(), settings.clone(), 2).unwrap();
        let before = node.read_active().unwrap();
        let calls = std::sync::atomic::AtomicUsize::new(0);
        let error = node
            .execute_derived_with_progress(
                &before.2,
                ExecutionRequest {
                    timestamp: None,
                    transactions: &[],
                    height: 1,
                    miner: development_public(0).unwrap(),
                    parent_id: settings.genesis(),
                    workers: 2,
                },
                &|point| {
                    if point == ExecutionProgress::BeforeOutput {
                        calls.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                        Err("COMMITMENT_ROOT".into())
                    } else {
                        Ok(())
                    }
                },
            )
            .unwrap_err();
        assert_eq!(error.to_string(), "COMMITMENT_ROOT");
        assert_eq!(calls.load(std::sync::atomic::Ordering::Relaxed), 1);
        assert_eq!(node.read_active().unwrap(), before);
    }

    #[test]
    fn actual_work_index_abort_preserves_block_state_and_sender_nonce() {
        let dir = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(dir.path(), settings.clone(), 1).unwrap();
        let mut parent = settings.genesis();
        for height in 1..=3 {
            let packet = make(&node, parent, height, 0, vec![]);
            parent = node.admit(&packet, 1000).unwrap();
            node.activate_observed(parent, 1000).unwrap();
        }
        let before = node.read_active().unwrap();
        let sender = development_public(0).unwrap();
        let nonce = node.next_nonce(sender).unwrap();
        let packet = make(&node, parent, 4, 0, vec![transfer(&node)]);
        let id = packet.id().unwrap();
        // A real validated proof and signed transfer reach the write transaction.
        node.db.execute_batch("CREATE TRIGGER fail_index BEFORE INSERT ON ancestry_jump WHEN NEW.level=2 BEGIN SELECT RAISE(ABORT,'index fault');END;").unwrap();
        assert!(node.admit(&packet, 1000).is_err());
        assert_eq!(node.read_active().unwrap(), before);
        assert_eq!(node.next_nonce(sender).unwrap(), nonce);
        assert!(node.record(id).is_err());
        let rows: u64 = node
            .db
            .query_row(
                "SELECT COUNT(*) FROM ancestry_jump WHERE block=?",
                [id.as_slice()],
                |r| r.get(0),
            )
            .unwrap();
        assert_eq!(rows, 0);
        node.db.execute_batch("DROP TRIGGER fail_index").unwrap();
        assert_eq!(node.admit(&packet, 1000).unwrap(), id);
        node.activate_observed(id, 1000).unwrap();
        assert_eq!(node.next_nonce(sender).unwrap(), nonce + 1);
        drop(node);
        let node = Node::open(dir.path(), settings, 1).unwrap();
        assert_eq!(node.active().unwrap().0, id);
    }
    #[test]
    fn actual_native_forks_reopen_and_independent_validation_use_indexed_pages() {
        let dir = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let mut node = Node::open(dir.path(), settings.clone(), 1).unwrap();
        let mut ids = vec![settings.genesis()];
        for height in 1..=8 {
            let packet = make(&node, *ids.last().unwrap(), height, 0, vec![]);
            let id = node.admit(&packet, 1000).unwrap();
            node.activate_observed(id, 1000).unwrap();
            ids.push(id);
        }
        let mut fork = vec![ids[3]];
        for height in 4..=9 {
            let packet = make(&node, *fork.last().unwrap(), height, 1, vec![]);
            fork.push(node.admit(&packet, 1000).unwrap());
        }
        let tip = *fork.last().unwrap();
        node.activate_observed(tip, 1000).unwrap();
        drop(node);
        let node = Node::open(dir.path(), settings.clone(), 1).unwrap();
        assert_eq!(node.active().unwrap().0, tip);
        let first = node
            .public_history_packet(
                tip,
                ids[3],
                crate::ancestry_index::READ_SQL_BUDGET,
                &mut |_| Ok(()),
            )
            .unwrap();
        assert_eq!(first[0].id().unwrap(), fork[1]);
        assert_eq!(
            node.public_history_packet(
                ids[8],
                fork[1],
                crate::ancestry_index::READ_SQL_BUDGET,
                &mut |_| Ok(())
            )
            .unwrap_err()
            .to_string(),
            "CURSOR"
        );
        let other = tempfile::tempdir().unwrap();
        let mut confirmer = Node::open(other.path(), settings.clone(), 1).unwrap();
        let mut after = settings.genesis();
        while after != tip {
            let page = node
                .public_history_packet(
                    tip,
                    after,
                    crate::ancestry_index::READ_SQL_BUDGET,
                    &mut |_| Ok(()),
                )
                .unwrap();
            assert_eq!(page.len(), 1);
            assert_eq!(page[0].header.parent, after);
            after = confirmer.admit(&page[0], 1000).unwrap();
        }
        confirmer.activate_observed(tip, 1000).unwrap();
        let confirmed = confirmer.read_active().unwrap();
        let expected = node.read_active().unwrap();
        assert_eq!(confirmed.0, expected.0);
        assert_eq!(confirmed.2, expected.2);
        assert_eq!(
            confirmer.stats().unwrap()["chainwork_hex"],
            node.stats().unwrap()["chainwork_hex"]
        );
        node.db
            .execute(
                "UPDATE ancestry_jump SET seal=? WHERE block=? AND level=3",
                params![[0_u8; 32].as_slice(), tip.as_slice()],
            )
            .unwrap();
        drop(node);
        assert_eq!(
            Node::open(dir.path(), settings, 1)
                .err()
                .unwrap()
                .to_string(),
            "ANCESTRY_INDEX_SEAL"
        );
    }
    #[test]
    fn previous_ddl_is_refused_without_migration_or_database_mutation() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("native.sqlite");
        let db = Connection::open(&path).unwrap();
        db.execute_batch(BASE_DDL).unwrap();
        drop(db);
        let before = fs::read(&path).unwrap();
        let error = Node::open(dir.path(), Settings::development(Some(1)).unwrap(), 1)
            .err()
            .unwrap();
        assert_eq!(error.to_string(), "SCHEMA");
        assert_eq!(fs::read(path).unwrap(), before);
    }
}

#[cfg(test)]
#[path = "operator_task_store_tests.rs"]
mod operator_task_store_tests;

#[cfg(test)]
mod branch_target_tests {
    use super::*;

    fn open(path: &Path, settings: Settings, growth: bool) -> Node {
        if growth {
            Node::open_with_permanent_account_growth_v2(path, settings).unwrap()
        } else {
            Node::open(path, settings, 1).unwrap()
        }
    }

    #[test]
    fn both_storage_owners_derive_targets_from_real_fork_parents_at_15_16_17() {
        for growth in [false, true] {
            let directory = tempfile::tempdir().unwrap();
            let settings = if growth {
                Settings::development_with_profiles(
                    Some(1),
                    "native-public-evaluation-dev-v1",
                    continuity_v1::PROFILE,
                )
                .unwrap()
                .with_permanent_account_growth_v2("branch-target-boundary-test")
                .unwrap()
            } else {
                Settings::development(Some(1)).unwrap()
            };
            let mut node = open(directory.path(), settings.clone(), growth);
            let mut limit = [255; 32];
            limit[0] = 127;
            let mut half = [255; 32];
            half[0] = 63;
            assert_eq!(settings.target("initial_target_hex").unwrap(), limit);
            assert_eq!(settings.limit("retarget_interval").unwrap(), 16);
            assert_eq!(settings.limit("target_spacing_seconds").unwrap(), 10);
            let mut branches = [vec![settings.genesis()], vec![settings.genesis()]];
            for height in 1..=17 {
                for (branch, spacing) in [5, 10].into_iter().enumerate() {
                    let parent = *branches[branch].last().unwrap();
                    // Ordinary five/ten-second histories have exact 75/150
                    // second first periods. Their targets are P/2 and P,
                    // independently of either native retarget implementation.
                    let expected = if branch == 0 && height >= 16 {
                        half
                    } else {
                        limit
                    };
                    assert_eq!(node.expected_target(parent).unwrap(), expected);
                    let timestamp = 1 + height * spacing;
                    let miner = crate::development_public(branch as u64).unwrap();
                    let id = if growth {
                        let packet = node
                            .make_growth_consensus_maintenance(
                                parent,
                                vec![],
                                miner,
                                timestamp,
                                4096,
                            )
                            .unwrap();
                        assert_eq!(packet.header.ledger.height, height);
                        assert_eq!(packet.header.ledger.target, expected);
                        node.admit_growth(&packet, 100_000).unwrap()
                    } else {
                        let packet = node.make(parent, vec![], miner, timestamp, 4096).unwrap();
                        assert_eq!(packet.header.height, height);
                        assert_eq!(packet.header.target, expected);
                        node.admit(&packet, 100_000).unwrap()
                    };
                    branches[branch].push(id);
                }
            }
            // Admission did not substitute either fork for the selected parent.
            assert_eq!(node.active().unwrap().0, settings.genesis());
            let selected = *branches[0].last().unwrap();
            // Growth's public activation dispatch owns its PNP2 history and
            // journal checks; activate_observed reads the ordinary PNP1 header.
            let activated = if growth {
                node.activate(selected)
            } else {
                node.activate_observed(selected, 100_000)
            };
            assert_eq!(activated.unwrap(), selected);
            let active = node.active().unwrap();
            for reopened in [false, true] {
                if reopened {
                    drop(node);
                    node = open(directory.path(), settings.clone(), growth);
                    assert_eq!(node.active().unwrap(), active);
                }
                for (branch, ids) in branches.iter().enumerate() {
                    assert_eq!(node.expected_target(ids[14]).unwrap(), limit);
                    let expected = if branch == 0 { half } else { limit };
                    assert_eq!(node.expected_target(ids[15]).unwrap(), expected);
                    assert_eq!(node.expected_target(ids[16]).unwrap(), expected);
                    assert_eq!(node.expected_target(ids[17]).unwrap(), expected);
                }
            }
        }
    }
}

#[cfg(test)]
#[path = "continuity_tests.rs"]
mod continuity_tests;

#[cfg(test)]
#[path = "native_authenticated_tests.rs"]
mod native_authenticated_tests;

#[cfg(test)]
#[path = "native_ancestry_commit_tests.rs"]
mod native_ancestry_commit_tests;

#[cfg(test)]
#[path = "native_account_query_tests.rs"]
mod native_account_query_tests;

#[cfg(test)]
mod bounded_active_state_tests {
    use super::*;
    use crate::ErrorKind;

    fn open(path: &Path, authenticated: bool) -> Node {
        let settings = Settings::development(Some(1)).unwrap();
        if authenticated {
            Node::open_with_authenticated_state(path, settings, 1).unwrap()
        } else {
            Node::open(path, settings, 1).unwrap()
        }
    }

    fn assert_local(error: Error) {
        assert_eq!(error.kind(), ErrorKind::LocalStructure);
        assert!(error.requires_owner_stop());
    }

    #[test]
    fn live_state_cell_extent_and_type_refuse_before_root_and_keep_exact_repair() {
        for authenticated in [false, true] {
            let directory = tempfile::tempdir().unwrap();
            let node = open(directory.path(), authenticated);
            let original = node.read_active().unwrap();
            let slot = node.slot().unwrap();
            // These are deliberately corrupt SQLite rows, not valid admission.
            for statement in [
                "INSERT INTO kv VALUES(?,'!extent',zeroblob(16777216))",
                "INSERT INTO kv VALUES(?,printf('%0161d',0),X'30')",
                "INSERT INTO kv VALUES(?,X'616263',X'30')",
                "INSERT INTO kv VALUES(?,'!text','null')",
                "INSERT INTO kv VALUES(?,'!integer',1)",
                "INSERT INTO kv VALUES(?,'!trailing',X'3020')",
            ] {
                node.db.execute_batch("SAVEPOINT corrupt_cell").unwrap();
                node.db.execute(statement, [slot]).unwrap();
                assert_local(node.read_active().unwrap_err());
                node.db
                    .execute_batch("ROLLBACK TO corrupt_cell; RELEASE corrupt_cell")
                    .unwrap();
                assert_eq!(node.read_active().unwrap(), original);
            }
            drop(node);
            assert_eq!(
                open(directory.path(), authenticated).read_active().unwrap(),
                original
            );
        }
    }

    #[test]
    fn live_state_reads_exact_wire_edges_without_normalizing_sql_types() {
        let directory = tempfile::tempdir().unwrap();
        let node = open(directory.path(), false);
        let original = node.read_active().unwrap();
        let slot = node.slot().unwrap();
        node.db.execute_batch("SAVEPOINT edge_cells").unwrap();
        let key = "k".repeat(160);
        let value = Value::String("a".repeat(4094));
        node.db
            .execute(
                "INSERT INTO kv VALUES(?,?,?)",
                params![slot, &key, canonical(&value).unwrap()],
            )
            .unwrap();
        // Decode bound only: raw SQL does not give this state a committed root.
        assert_eq!(node.slot_state(slot).unwrap().get(&key), Some(&value));
        assert_local(node.read_active().unwrap_err());
        node.db
            .execute(
                "UPDATE kv SET value=? WHERE key=?",
                params![canonical(&Value::String("a".repeat(4095))).unwrap(), &key],
            )
            .unwrap();
        let error = node.slot_state(slot).unwrap_err();
        assert_eq!(error.to_string(), "STATE_BYTES");
        assert_local(error);
        node.db
            .execute("DELETE FROM kv WHERE key=?", [&key])
            .unwrap();
        // SQL length(TEXT) counts characters; the wire bound counts UTF-8 bytes.
        node.db
            .execute(
                "INSERT INTO kv VALUES(?,?,?)",
                params![slot, "λ".repeat(81), b"0".as_slice()],
            )
            .unwrap();
        let error = node.slot_state(slot).unwrap_err();
        assert_eq!(error.to_string(), "STATE_BYTES");
        assert_local(error);
        node.db
            .execute_batch("ROLLBACK TO edge_cells; RELEASE edge_cells")
            .unwrap();
        assert_eq!(node.read_active().unwrap(), original);
    }

    #[test]
    fn live_state_count_bound_and_cancellation_return_no_partial_state() {
        let directory = tempfile::tempdir().unwrap();
        let node = open(directory.path(), false);
        let original = node.read_active().unwrap();
        let slot = node.slot().unwrap();
        node.db.execute_batch("SAVEPOINT count_cells").unwrap();
        node.db
            .execute("DELETE FROM kv WHERE slot=?", [slot])
            .unwrap();
        node.db
            .execute(
                "WITH RECURSIVE n(i) AS (SELECT 0 UNION ALL SELECT i+1 FROM n WHERE i<65535)
             INSERT INTO kv SELECT ?,printf('key-%05d',i),X'30' FROM n",
                [slot],
            )
            .unwrap();
        // Mechanism boundary, not 65536 admitted accounts or an increased cap.
        let mut calls = 0;
        let state = node
            .slot_state_with_progress(slot, &mut || {
                calls += 1;
                Ok(())
            })
            .unwrap();
        assert_eq!(state.len(), 65_536);
        assert_eq!(calls, 258); // start, 256 row-boundaries, final.
        for cut in [1, 2, 129, 258] {
            let mut seen = 0;
            let error = node
                .slot_state_with_progress(slot, &mut || {
                    seen += 1;
                    if seen == cut {
                        Err(Error::new(crate::ErrorCode::PublicRequestCancelled))
                    } else {
                        Ok(())
                    }
                })
                .unwrap_err();
            assert_eq!(seen, cut);
            assert_eq!(error.kind(), ErrorKind::Cancelled);
            assert!(!error.requires_owner_stop());
        }
        node.db
            .execute("INSERT INTO kv VALUES(?,'zz-extra',X'30')", [slot])
            .unwrap();
        let error = node.slot_state(slot).unwrap_err();
        assert_eq!(error.to_string(), "STATE_BYTES");
        assert_local(error);
        node.db
            .execute_batch("ROLLBACK TO count_cells; RELEASE count_cells")
            .unwrap();
        assert_eq!(node.read_active().unwrap(), original);
    }
}

#[cfg(test)]
mod fixed_blob_read_tests {
    use super::*;
    use rusqlite::types::Value as SqlValue;

    fn outcome(
        result: Result<Record>,
    ) -> std::result::Result<(Option<Hash>, u64, Work, Hash), String> {
        result
            .map(|r| (r.parent, r.height, r.work, r.root))
            .map_err(|e| e.to_string())
    }

    type OriginalRow = (Option<Vec<u8>>, u64, Vec<u8>, Vec<u8>);

    // Original complete decoder is an independent test arm, not a live fallback.
    fn original_record(db: &Connection, id: Hash) -> Result<Record> {
        let row: Option<OriginalRow> = db
            .query_row(
                "SELECT parent,height,chainwork,state_root FROM blocks WHERE id=?",
                [id.as_slice()],
                |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?)),
            )
            .optional()?;
        let (parent, height, work, state) = row.ok_or("UNKNOWN_PARENT")?;
        Ok(Record {
            parent: parent.map(bytes32).transpose()?,
            height,
            work: Work::from_bytes(bytes64(work)?),
            root: bytes32(state)?,
        })
    }

    #[test]
    fn fixed_blob_copy_preserves_null_types_and_exact_boundaries() {
        let db = Connection::open_in_memory().unwrap();
        for width in [32, 64] {
            for value in [
                SqlValue::Null,
                SqlValue::Integer(1),
                SqlValue::Real(1.5),
                SqlValue::Text("not a blob".into()),
            ]
            .into_iter()
            .chain(
                [0, 1, 31, 32, 33, 63, 64, 65, 4096, 4 * 1024 * 1024]
                    .into_iter()
                    .map(|n| SqlValue::Blob(vec![7; n])),
            ) {
                let original = db.query_row("SELECT ?1 AS field", [&value], |r| {
                    r.get::<_, Option<Vec<u8>>>(0)
                });
                let bounded = db.query_row("SELECT ?1 AS field", [&value], |r| {
                    if width == 32 {
                        optional_fixed_blob::<32>(r, 0)
                    } else {
                        optional_fixed_blob::<64>(r, 0)
                    }
                });
                match (original, bounded) {
                    (Ok(Some(old)), Ok(Some(new))) => {
                        assert_eq!(new, old[..old.len().min(width + 1)]);
                        assert!(new.len() <= width + 1);
                        assert_eq!(old.len() == width, new.len() == width);
                    }
                    (Ok(None), Ok(None)) => assert_eq!(value, SqlValue::Null),
                    (Err(old), Err(new)) => assert_eq!(old.to_string(), new.to_string()),
                    _ => panic!("nullable conversion changed"),
                }
                let original =
                    db.query_row("SELECT ?1 AS field", [&value], |r| r.get::<_, Vec<u8>>(0));
                let bounded = db.query_row("SELECT ?1 AS field", [&value], |r| {
                    if width == 32 {
                        fixed_blob::<32>(r, 0)
                    } else {
                        fixed_blob::<64>(r, 0)
                    }
                });
                match (original, bounded) {
                    (Ok(old), Ok(new)) => assert_eq!(new, old[..old.len().min(width + 1)]),
                    (Err(old), Err(new)) => assert_eq!(old.to_string(), new.to_string()),
                    _ => panic!("required conversion changed"),
                }
            }
        }
    }

    #[test]
    fn fixed_header_projection_bounds_all_six_fields_without_type_coercion() {
        let db = Connection::open_in_memory().unwrap();
        let sql = "SELECT ?1,1,?1,?1,NULL,NULL,NULL,0,?1,?1,?1";
        let large = vec![8_u8; 4 * 1024 * 1024];
        let row = db.query_row(sql, [&large], HeaderProjection::read).unwrap();
        assert_eq!(row.parent.unwrap().len(), 33);
        assert_eq!(row.work.len(), 65);
        assert_eq!(row.root.len(), 33);
        assert_eq!(row.parent_work.unwrap().len(), 65);
        assert_eq!(row.parent_parent.unwrap().len(), 33);
        assert_eq!(row.parent_root.unwrap().len(), 33);
        let empty = Vec::<u8>::new();
        let row = db.query_row(sql, [&empty], HeaderProjection::read).unwrap();
        assert_eq!(row.parent, Some(vec![]));
        assert_eq!(row.parent_root, Some(vec![]));
        assert!(row.work.is_empty());
        for column in [0, 2, 3, 8, 9, 10] {
            let mut fields = [
                "NULL",
                "1",
                "zeroblob(64)",
                "zeroblob(32)",
                "NULL",
                "NULL",
                "NULL",
                "0",
                "zeroblob(64)",
                "NULL",
                "zeroblob(32)",
            ];
            fields[column] = "'wrong-type'";
            let error = db
                .query_row(
                    &format!("SELECT {}", fields.join(",")),
                    [],
                    HeaderProjection::read,
                )
                .err()
                .unwrap();
            assert!(
                matches!(error, rusqlite::Error::InvalidColumnType(index, _, _) if index == column)
            );
        }
    }

    #[test]
    fn fixed_record_rereads_original_errors_and_restores_both_native_backends() {
        for authenticated in [false, true] {
            let directory = tempfile::tempdir().unwrap();
            let settings = Settings::development(Some(1)).unwrap();
            let mut node = if authenticated {
                Node::open_with_authenticated_state(directory.path(), settings.clone(), 1).unwrap()
            } else {
                Node::open(directory.path(), settings.clone(), 1).unwrap()
            };
            let genesis = settings.genesis();
            let packet = node
                .make(genesis, vec![], development_public(0).unwrap(), 11, 4096)
                .unwrap();
            let block = node.admit(&packet, 1000).unwrap();
            node.activate(block).unwrap();
            let initial = node.read_active().unwrap();
            for cache in [0, 1, 16] {
                node.db.set_prepared_statement_cache_capacity(cache);
                assert_eq!(
                    outcome(node.record(block)),
                    outcome(original_record(&node.db, block))
                );
                for (field, value) in [
                    ("parent", SqlValue::Blob(vec![])),
                    ("parent", SqlValue::Blob(vec![1; 4 * 1024 * 1024])),
                    ("chainwork", SqlValue::Blob(vec![2; 4 * 1024 * 1024])),
                    ("state_root", SqlValue::Blob(vec![3; 4 * 1024 * 1024])),
                    ("chainwork", SqlValue::Text("bad-work".into())),
                    ("state_root", SqlValue::Integer(1)),
                ] {
                    node.db.execute_batch("SAVEPOINT damage").unwrap();
                    node.db
                        .execute(
                            &format!("UPDATE blocks SET {field}=? WHERE id=?"),
                            params![value, block.as_slice()],
                        )
                        .unwrap();
                    let actual = outcome(node.record(block));
                    assert!(actual.is_err());
                    assert_eq!(actual, outcome(original_record(&node.db, block)));
                    let error = node.stored_header_link(block).err().unwrap();
                    assert!(error.requires_owner_stop());
                    node.db
                        .execute_batch("ROLLBACK TO damage; RELEASE damage")
                        .unwrap();
                    assert_eq!(node.read_active().unwrap(), initial);
                    assert_eq!(
                        node.history(block, genesis, 16).unwrap()[0]
                            .encode()
                            .unwrap(),
                        packet.encode().unwrap()
                    );
                }
                // All SQL conversions precede shape validation, even with several corrupt cells.
                node.db.execute_batch("SAVEPOINT mixed").unwrap();
                node.db.execute("UPDATE blocks SET parent=zeroblob(33),chainwork='wrong-type',state_root=zeroblob(33) WHERE id=?", [block.as_slice()]).unwrap();
                let expected = outcome(original_record(&node.db, block));
                assert!(expected.as_ref().err().unwrap().contains("chainwork"));
                assert_eq!(outcome(node.record(block)), expected);
                node.db
                    .execute_batch("ROLLBACK TO mixed; RELEASE mixed")
                    .unwrap();
            }
            drop(node);
            let reopened = if authenticated {
                Node::open_with_authenticated_state(directory.path(), settings, 1).unwrap()
            } else {
                Node::open(directory.path(), settings, 1).unwrap()
            };
            assert_eq!(reopened.read_active().unwrap(), initial);
        }
    }

    #[test]
    fn fixed_context_and_active_tip_reject_oversize_prefix_aliases() {
        let directory = tempfile::tempdir().unwrap();
        let settings = Settings::development(Some(1)).unwrap();
        let node = Node::open(directory.path(), settings.clone(), 1).unwrap();
        let original = node.read_active().unwrap();
        for key in ["schema", "parameters", "genesis"] {
            let bytes: Vec<u8> = node
                .db
                .query_row("SELECT value FROM metadata WHERE key=?", [key], |r| {
                    r.get(0)
                })
                .unwrap();
            let mut large = bytes.clone();
            large.resize(4 * 1024 * 1024, 0);
            node.db.execute_batch("SAVEPOINT context_damage").unwrap();
            node.db
                .execute(
                    "UPDATE metadata SET value=? WHERE key=?",
                    params![large, key],
                )
                .unwrap();
            let error = node.storage_context().unwrap_err();
            assert_eq!(error.to_string(), "STORAGE_CONTEXT");
            assert!(error.requires_owner_stop());
            node.db
                .execute_batch("ROLLBACK TO context_damage; RELEASE context_damage")
                .unwrap();
            node.storage_context().unwrap();
        }
        node.db.execute_batch("SAVEPOINT tip_damage").unwrap();
        let mut tip = original.0.to_vec();
        tip.resize(4 * 1024 * 1024, 0);
        node.db.execute("UPDATE active SET tip=?", [tip]).unwrap();
        assert_eq!(node.active().unwrap_err().to_string(), "STORAGE_HASH");
        node.db
            .execute_batch("ROLLBACK TO tip_damage; RELEASE tip_damage")
            .unwrap();
        assert_eq!(node.read_active().unwrap(), original);
        drop(node);
        assert_eq!(
            Node::open(directory.path(), settings, 1)
                .unwrap()
                .read_active()
                .unwrap(),
            original
        );
    }
}
