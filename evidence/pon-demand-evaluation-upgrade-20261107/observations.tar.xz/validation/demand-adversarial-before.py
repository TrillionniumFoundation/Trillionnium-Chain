"""Independent adversarial composition probes; never native or demand proof.

Select the original saved source pair for historical reproduction, or the live
source directory after a repair. The unchanged mutation recipes use that source's
valid fixture builder so a new required contract field cannot create a vacuous
post-repair refusal. Valid baseline controls run in each invocation.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--source-dir', type=Path, required=True)
parser.add_argument('--dependency-dir', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.dependency_dir))
sys.path.insert(0, str(args.source_dir))
from test_demand_evidence import DemandTests, ident
from demand_evidence import commitment, validate_contract


def source_identity():
    return {name: hashlib.sha256((args.source_dir / name).read_bytes()).hexdigest()
            for name in ('demand_evidence.py', 'test_demand_evidence.py')}


def fixture():
    f = DemandTests()
    f.setUp()
    return f


def observation(f, bundle, **kwargs):
    before = f.book.snapshot()
    try:
        result = f.observe(bundle, **kwargs)
        return dict(accepted=True, observation={key: result[key] for key in
                    ('origin', 'independence_attested', 'conditional_fee_due', 'paid', 'status')})
    except Exception as error:
        return dict(accepted=False, exception=type(error).__name__, code=str(error),
                    refusal_preserved_snapshot=f.book.snapshot() == before)


before_source = source_identity()
results = []

for outcome, bonus in (('no-gain', False), ('positive-net', True)):
    f = fixture()
    results.append(dict(case='valid_' + outcome, expected='accepted',
                        **observation(f, f.bundle(outcome=outcome, bonus=bonus))))

f = fixture()
b = f.bundle()
b['acceptance'] = None
b['dispute'] = f.sign('dispute', dict(policy=b['contract']['dispute_policy'],
    output=ident('complete-output'), verdict='pay-service', resolved_at=0,
    evidence=ident('case')), validate_contract(b['contract']), 'dispute')
f.resign(b, 'payments', index=0, settled_at=1)
results.append(dict(case='dispute_0_payment_1_before_lock_10_delivery_50',
                    expected='refused', **observation(f, b)))

f = fixture()
b = f.bundle()
b['acceptance'] = None
b['dispute'] = f.sign('dispute', dict(policy=b['contract']['dispute_policy'],
    output=ident('complete-output'), verdict='pay-service', resolved_at=95,
    evidence=ident('case')), validate_contract(b['contract']), 'dispute')
f.resign(b, 'payments', index=0, settled_at=96)
results.append(dict(case='dispute_95_after_contract_dispute_end_80',
                    expected='refused', **observation(f, b)))

f = fixture()
b = f.bundle(outcome='positive-net', bonus=True)
f.resign(b, 'adoption', observed_at=65)
f.resign(b, 'payments', index=3, settled_at=66)
results.append(dict(case='improvement_paid_66_before_required_retention_90',
                    expected='refused', **observation(f, b)))

f = fixture()
b = f.bundle()
f.resign(b, 'payments', index=1, net_units=0)
results.append(dict(case='negative_evaluator_net_zero_with_fixed_gross_7',
                    expected='refused', **observation(f, b)))
results.append(dict(case='positive_evaluator_net_seven_same_fee_schedule',
                    expected='accepted', **observation(f, f.bundle(2, outcome='positive-net'))))

f = fixture()
b = f.bundle(outcome='positive-net', bonus=True)
f.resign(b, 'provenance', valid_from=99)
results.append(dict(case='independence_valid_only_from_99_bonus_already_paid_96',
                    expected='refused', **observation(f, b)))

f = fixture()
b1 = f.bundle(1, outcome='positive-net', bonus=True, inputs='inputs-A')
b2 = f.bundle(2, outcome='positive-net', bonus=True, inputs='inputs-B')
# Force the same candidate even if a repaired valid fixture now generates a
# different candidate for each number. Keep the operation and source IDs new.
same_output = b1['adoption']['body']['payload']['candidate']
for field in ('delivery', 'acceptance', 'evaluation', 'availability'):
    f.resign(b2, field, output=same_output)
f.resign(b2, 'adoption', candidate=same_output,
         evaluation=commitment('evaluation', b2['evaluation']))
for index in range(len(b2['payments'])):
    f.resign(b2, 'payments', index=index, output=same_output)
first = observation(f, b1)
second = observation(f, b2)
results.append(dict(case='same_parent_candidate_new_inputs_new_adoption_id',
                    expected='second-refused', first=first, second=second,
                    same_parent=b1['contract']['parent'] == b2['contract']['parent'],
                    same_candidate=b1['adoption']['body']['payload']['candidate'] ==
                                   b2['adoption']['body']['payload']['candidate'],
                    bonus_total=f.book.snapshot()['improvement_gross_observed']))

f = fixture()
b = f.bundle()
for key in ('delivery', 'acceptance', 'evaluation', 'availability', 'adoption'):
    b[key] = None
b['payments'] = []
sources = {account: dict(source, state='settled') for account, source in
           b['funding']['body']['payload']['sources'].items()}
f.resign(b, 'funding', observed_at=20, valid_until=40, sources=sources)
observed = observation(f, b, height=20)
queue = f.book.queue_observation(height=30, expected_anchor=f.anchor)
results.append(dict(case='no_delivery_all_sources_settled_not_funded_queue',
                    expected='refused-or-not-funded', observation=observed, queue=queue))

after_source = source_identity()
report = dict(schema='demand-adversarial-composition-observation-v1',
              source_directory=str(args.source_dir), before_source=before_source,
              after_source=after_source, source_unchanged=before_source == after_source,
              cases=results, native_executions=0, independent_demand_proven=False)
args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps(report, indent=2, sort_keys=True))
