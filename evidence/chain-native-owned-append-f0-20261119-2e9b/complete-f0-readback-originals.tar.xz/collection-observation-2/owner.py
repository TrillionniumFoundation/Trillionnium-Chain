from pathlib import Path
import json,hashlib,subprocess,time,sys
root=Path('/home/qian-qi/work/chain-native-owned-append-f0-20261119-2e9b');out=root/'collection-observation-2';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
p=root/'collection/job-135361036286-log.stdout';raw=p.read_bytes();lines=raw.decode(errors='replace').splitlines();selected=[{'line':i+1,'text':s} for i,s in enumerate(lines) if any(v in s.lower() for v in ('error','failed','cleanup','remaining','qualif','duration','import','packet','baseline','deplet','traceback'))]
state={'job_log':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},'selected':selected[-200:],'zip_files':[{'path':str(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in (root/'collection').glob('*.zip')]}
(out/'snapshot.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state,indent=2))
