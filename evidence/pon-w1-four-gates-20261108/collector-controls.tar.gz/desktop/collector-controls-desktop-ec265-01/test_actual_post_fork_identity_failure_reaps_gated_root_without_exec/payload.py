from pathlib import Path
Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/collector-controls-desktop-ec265-01/test_actual_post_fork_identity_failure_reaps_gated_root_without_exec/must-not-execute').write_text('bad')
