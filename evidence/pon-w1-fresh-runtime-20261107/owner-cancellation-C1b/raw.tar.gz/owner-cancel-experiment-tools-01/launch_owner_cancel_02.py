#!/usr/bin/env python3
"""Launch one explicitly declared research-owner cancellation under a new clock."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
CPUS = [8, 9, 10, 11, 20, 21, 22, 23]
SELECTOR = 'store::async_w1_generation_v2::tests::heavy::funded_fresh_full_w1_generation_owner_cancel_after_segment_start'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'ordinary original file required')
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(Path(path).parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def identity():
    membership = Path('/proc/self/cgroup').read_text()
    require(membership.startswith('0::/') and 'hepta-runtime-job-' in membership, 'owned actual Hepta job required')
    group = Path('/sys/fs/cgroup') / membership.strip()[3:].lstrip('/')
    value = {'pid': os.getpid(), 'proc_stat': Path('/proc/self/stat').read_text(),
             'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
             'cgroup_membership': membership, 'cpu_max': (group / 'cpu.max').read_text().strip(),
             'memory_max': (group / 'memory.max').read_text().strip(),
             'affinity': sorted(os.sched_getaffinity(0)), 'nice': os.getpriority(os.PRIO_PROCESS, 0)}
    quota, period = map(int, value['cpu_max'].split())
    require(period > 0 and quota == 8 * period and value['memory_max'] == str(8 * 1024**3)
            and value['affinity'] == CPUS, 'actual declared research allocation required')
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--expected-commit', required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    require(re.fullmatch('[0-9a-f]{40}', args.expected_commit), 'explicit full source commit required')
    require(pin(args.plan)['sha256'] == args.plan_sha256, 'externally selected original plan changed')
    plan = json.loads(args.plan.read_text())
    require(plan['schema'] == 'TRNM-W1-OWNER-CANCEL-LAUNCH-PLAN1'
            and plan['maximum_original_budget_ns'] == 600_000_000_000
            and plan['deadline_selected'] is False and plan['winner_or_proof_started'] is False,
            'one unstarted research cancellation plan required')
    config = plan['config_without_clock']
    require(config['expected_commit'] == args.expected_commit
            and config['repo'] == str(ROOT / 'integration-repo')
            and config['cpus'] == CPUS and config['reserve_nonce'] == 1
            and config['owner_cancellation']['native_task_action'] == 'cancel-reserved',
            'original source/authority/nonce/resource contract changed')
    for name in ('out', 'target_root', 'research_node_path'):
        require(not Path(config[name]).exists(), 'isolated research destination must be new: ' + name)
    owner = plan['owner_test']
    require(pin(owner['path']) == {k: owner[k] for k in ('path', 'bytes', 'sha256')}, 'qualified owner ELF changed')
    generator = ROOT / 'owner-cancel-experiment-tools-01/prepare_owner_cancel_config.py'
    require(pin(generator) == plan['generator'], 'original config generator changed')
    out = ROOT / 'owner-cancel-launch-02'
    out.mkdir(exist_ok=False)
    os.umask(0o077)
    os.sched_setaffinity(0, set(CPUS))
    before = identity()
    selected = time.monotonic_ns()
    deadline = selected + 600_000_000_000
    argv = ['/usr/bin/python3.12', '-B', str(generator), 'finalize', '--plan', str(args.plan),
            '--config', str(args.config), '--deadline-monotonic-ns', str(deadline), '--boot-id', before['boot_id']]
    write(out / 'declaration.json', {'schema': 'TRNM-W1-OWNER-CANCEL-LAUNCH-OBSERVATION1',
        'source_commit': args.expected_commit, 'selected_monotonic_ns': selected,
        'original_deadline_monotonic_ns': deadline, 'original_deadline_boot_id': before['boot_id'],
        'initial_identity': before, 'plan': pin(args.plan), 'generator': pin(generator),
        'wrapper': pin(Path(__file__).resolve()), 'finalize_argv': argv,
        'research_trial': 'one explicit owner cancellation after actual proving startup',
        'prior_A_tasks_mutated': False, 'proof_deadline_can_be_extended': False})
    with (out / 'finalize.stdout').open('xb') as so, (out / 'finalize.stderr').open('xb') as se:
        result = subprocess.run(argv, stdout=so, stderr=se,
                                timeout=min(120., (deadline - time.monotonic_ns()) / 1e9), check=False)
        for stream in (so, se):
            stream.flush()
            os.fsync(stream.fileno())
    write(out / 'finalize-result.json', {'exit': result.returncode, 'stdout': pin(out / 'finalize.stdout'),
        'stderr': pin(out / 'finalize.stderr'), 'observed_monotonic_ns': time.monotonic_ns(),
        'original_deadline_monotonic_ns': deadline})
    if result.returncode:
        raise SystemExit(result.returncode)
    require(time.monotonic_ns() < deadline and pin(args.plan)['sha256'] == args.plan_sha256,
            'original deadline or plan changed before dispatch')
    require(pin(owner['path']) == {k: owner[k] for k in ('path', 'bytes', 'sha256')}, 'qualified owner ELF changed')
    owner_argv = [owner['path'], SELECTOR, '--exact', '--ignored', '--test-threads=1', '--nocapture']
    write(out / 'owner-exec-intent.json', {'argv': owner_argv, 'config': pin(args.config),
        'owner_binary': owner, 'identity': identity(), 'observed_monotonic_ns': time.monotonic_ns(),
        'original_deadline_monotonic_ns': deadline, 'original_deadline_boot_id': before['boot_id'],
        'outcome': 'NOT_YET_OBSERVED', 'complete_proof_claim': False})
    require(time.monotonic_ns() < deadline, 'original deadline exhausted before owner exec')
    os.environ['TRNM_W1_FUNDED_CONFIG'] = str(args.config)
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    os.environ['RAYON_NUM_THREADS'] = '4'
    os.execv(owner_argv[0], owner_argv)


if __name__ == '__main__':
    main()

