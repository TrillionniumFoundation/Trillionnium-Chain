#!/usr/bin/env python3
"""Read a completed independent ROG receiver without extending its local deadline."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/chain-w1-funded-owner-20261107-r01')
BASE = ROOT / 'independent-receiver-01'
REPO = ROOT / 'repo'
HARNESS = BASE / 'receive_w1_on_rog.py'
HARNESS_SHA = '83a712f9accec1420a0d7f0a75a70df9e3fb8eff9e5b234813a72ad2d6bad0e1'
QUALIFICATION = BASE / 'verifier-build-A-01/qualification.json'
QUALIFICATION_SHA = '62315319c06d5070a4f339f1eeda84bff1924162d526b6da0c6100a191d5bbb5'
COMMIT = 'd3037ca5dfb6f301757c159b7888dca9b0317be0'
TREE = 'd4a8f84cdc896b9454ce0d03a164f8916e6afdf9'
LAUNCH_SHA = 'c435ec8357861952eea6f6a1cdda6ae822baf198d8baef47cb608191d6522c20'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('arm', choices=('funded-balanced', 'sequential-unfunded'))
    parser.add_argument('--receiver-job-id', required=True)
    args = parser.parse_args()
    output = BASE / ('new-' + args.arm + '-receive-01')
    destination = BASE / ('new-' + args.arm + '-terminal-readback-01.json')
    require(not destination.exists(), 'new readback only')
    require(hashlib.sha256(HARNESS.read_bytes()).hexdigest() == HARNESS_SHA, 'qualified receiver source changed')
    spec = importlib.util.spec_from_file_location('actual_qualified_rog_receiver', HARNESS)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    result = {'schema': 'TRNM-W1-ROG-TERMINAL-READBACK2', 'receiver_job_id': args.receiver_job_id,
              'receiver_output': str(output), 'readback_entered_monotonic_ns': time.monotonic_ns(),
              'readback_boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
              'all_checked': False, 'cancellation_sidecars': [], 'error': None,
              'parent_clock_compared': False, 'original_local_deadline_extended': False,
              'admission_authorized': False, 'payment_authorized': False,
              'complete_resource_accounting_established': False}
    try:
        q, qpin = module.qualification(argparse.Namespace(
            qualification=str(QUALIFICATION), qualification_sha256=QUALIFICATION_SHA))
        result['qualification'] = qpin
        ack, ack_pin = module.json_object(output / 'ack.json', 1024**2)
        result['ack'] = ack_pin
        launch, launch_pin = module.json_object(BASE / ('new-' + args.arm + '-launch-01.json'), 65536)
        require(launch.get('schema') == 'TRNM-W1-ROG-ACTUAL-LAUNCH1' and launch.get('arm') == args.arm
                and launch.get('request_sha256') == ack['request']['sha256']
                and launch.get('receiver_harness_sha256') == HARNESS_SHA
                and launch.get('qualification_sha256') == QUALIFICATION_SHA
                and launch.get('python_sha256') == q['python']['sha256']
                and launch.get('boot_id') == ack['receiver_boot_id']
                and launch.get('rayon_num_threads') == '2'
                and launch['entered_monotonic_ns'] <= launch['recorded_monotonic_ns'] <= ack['entered_monotonic_ns'],
                'actual launch identity differs from qualified receiver')
        require(launch['cgroup'].endswith('/hepta-runtime-job-' + args.receiver_job_id + '.service'),
                'actual receiver cgroup differs from original job')
        controls = launch['actual_controls']
        quota, period = map(int, controls['cpu.max'].split())
        require(period > 0 and quota == 2 * period and controls['memory.max'] == str(8 * 1024**3),
                'actual receiver allocation differs')
        expected_argv = [q['python']['path'], str(HARNESS), 'receive', '--qualification', str(QUALIFICATION),
                         '--qualification-sha256', QUALIFICATION_SHA, '--request', ack['request']['path'],
                         '--request-sha256', ack['request']['sha256'], '--out', str(output), '--local-seconds', '60']
        require(launch['receiver_argv'] == expected_argv, 'actual exec argv changed')
        launch_source = ROOT / 'crosshost-tools-02/rog-receiver-launch.py'
        require(hashlib.sha256(launch_source.read_bytes()).hexdigest() == launch['launch_source_sha256'] == LAUNCH_SHA,
                'actual launch collector changed')
        result['actual_launch_pin'] = launch_pin
        result['actual_launch_record'] = launch
        old_proc = Path('/proc') / str(launch['pid']) / 'stat'
        try:
            proc_text = old_proc.read_text()
            proc_fields = proc_text[proc_text.rfind(')') + 2:].split()
            same_birth = int(proc_fields[19]) == launch['pid_start_ticks']
            result['original_process_terminal_readback'] = {'state': 'SAME_BIRTH_PRESENT' if same_birth else 'PID_REUSED',
                'current_start_ticks': int(proc_fields[19]), 'original_pid': launch['pid'], 'original_start_ticks': launch['pid_start_ticks']}
            require(not same_birth, 'original receiver process identity remains present')
        except FileNotFoundError:
            result['original_process_terminal_readback'] = {'state': 'ABSENT', 'original_pid': launch['pid'],
                                                           'original_start_ticks': launch['pid_start_ticks']}
        original_group = Path(launch['cgroup'])
        require(str(original_group).startswith('/sys/fs/cgroup/'), 'original cgroup root')
        result['original_cgroup_terminal_readback'] = {'path': str(original_group), 'exists': original_group.exists()}
        if original_group.exists():
            groups = [original_group] + sorted(p for p in original_group.rglob('*') if p.is_dir())
            group_rows = [{'path': str(p), 'members': (p / 'cgroup.procs').read_text(),
                           'events': (p / 'cgroup.events').read_text()} for p in groups]
            result['original_cgroup_terminal_readback']['groups'] = group_rows
            require(all(not row['members'].strip() and 'populated 0' in row['events'].splitlines()
                        for row in group_rows), 'original receiver scope not observed empty')
        require(ack.get('schema') == 'TRNM-W1-ROG-INDEPENDENT-ACK1' and ack.get('verified') is True
                and ack.get('receiver_operation_complete') is True
                and ack.get('local_deadline_exhausted_at_snapshot') is False
                and ack.get('cancellation_event') is None and ack.get('error') is None,
                'receiver ACK not complete')
        require(ack.get('source_commit') == COMMIT and ack.get('source_tree') == TREE,
                'exact-A receiver required')
        sidecars = sorted(str(p) for p in output.rglob('*cancellation*.json'))
        result['cancellation_sidecars'] = sidecars
        require(not sidecars, 'operation cancellation sidecar vetoes ACK')
        require([row.get('label') for row in ack['stages']] ==
                ['source-before', 'independent-receiver', 'source-after'], 'all original stages required')
        result['stages'] = []
        for entry in ack['stages']:
            path = Path(entry['result']['path'])
            require(output in path.parents, 'stage result outside original output')
            row, record = module.json_object(path, 8 * 1024**2)
            module.same_pin(record, entry['result'])
            module.strict_stage(row)
            result['stages'].append({'label': entry['label'], 'pin': record, 'strict_terminal': True})
        result['source_checks'] = {}
        require(set(ack['source_checks']) == {'before', 'after'}, 'both source checks required')
        for which, selected in ack['source_checks'].items():
            row, record = module.json_object(selected['path'], 1024**2)
            module.same_pin(record, selected)
            require(row['tested_commit'] == COMMIT and row['tested_tree'] == TREE
                    and row['tracked_worktree_verified'] is True, 'original source guard failed')
            result['source_checks'][which] = record
        inner, inner_pin = module.json_object(output / 'receiver/ack.json', 8 * 1024**2)
        require(inner == ack['inner_ack'] and inner['schema'] == 'TRNM-W1-RECEIVER-ACK2'
                and inner.get('verified') is True and inner.get('receiver_operation_complete') is True
                and inner.get('error') is None and inner.get('cancellation_event') is None,
                'inner strict ACK changed')
        result['inner_ack'] = inner_pin
        for selected in ack['files'].values():
            module.same_pin(module.file_record(selected['path'], 16 * 1024**2), selected)
        module.same_pin(module.file_record(ack['request']['path'], 65536), ack['request'])
        module.same_pin(module.fixed_expected(), ack['expected_artifacts'])
        def git(*argv):
            return subprocess.check_output(['/usr/bin/git', '-C', str(REPO), *argv], text=True).strip()
        result['source_current'] = {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                                    'status': git('status', '--porcelain=v1', '--untracked-files=normal')}
        require(result['source_current'] == {'commit': COMMIT, 'tree': TREE, 'status': ''}, 'current ROG source changed')
        module.same_pin(module.file_record(output / 'ack.json', 1024**2), ack_pin)
        result['cancellation_sidecars'] = sorted(str(p) for p in output.rglob('*cancellation*.json'))
        require(not result['cancellation_sidecars'], 'late sidecar vetoes readback')
        result['all_checked'] = True
    except BaseException as error:
        result['error'] = {'type': type(error).__name__, 'message': str(error)}
    result['readback_finished_monotonic_ns'] = time.monotonic_ns()
    write_new(destination, result)
    record = module.file_record(destination, 1024**2)
    print(json.dumps({'readback': record, 'all_checked': result['all_checked'], 'error': result['error']}))
    return 0 if result['all_checked'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
