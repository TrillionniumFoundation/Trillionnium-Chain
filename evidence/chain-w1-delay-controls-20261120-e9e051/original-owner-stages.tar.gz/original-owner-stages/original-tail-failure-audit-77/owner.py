from pathlib import Path
import json,sys,time,resource,hashlib,re
root=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');src=root/'source';out=root/'original-tail-failure-audit-77';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);t=time.monotonic();b=resource.getrusage(resource.RUSAGE_SELF);path=root/'repository-tail-diagnostic-75/stderr.log';raw=path.read_bytes();lines=raw.decode(errors='replace').splitlines();contexts=[]
for i,line in enumerate(lines):
 if line.startswith('FAIL:') or line.startswith('ERROR:'):contexts.append({'line':i+1,'context':lines[i:i+18]})
p=src/'trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs';lines2=p.read_text().splitlines();idx=set()
for i,line in enumerate(lines2):
 if 'r22' in line or 'body-backoff' in line or 'body-refusal' in line:idx.update(range(max(0,i-12),min(len(lines2),i+14)))
data={'stderr_sha256':hashlib.sha256(raw).hexdigest(),'stderr_bytes':len(raw),'failures':contexts,'policy_source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'policy_lines':[str(i+1)+':'+lines2[i] for i in sorted(idx)]};encoded=(json.dumps(data,indent=2)+'\n').encode();(out/'READOUT.json').write_bytes(encoded);a=resource.getrusage(resource.RUSAGE_SELF);cost={'wall_seconds':time.monotonic()-t,'self_user_cpu_seconds':a.ru_utime-b.ru_utime,'self_system_cpu_seconds':a.ru_stime-b.ru_stime,'readout_bytes':len(encoded),'readout_sha256':hashlib.sha256(encoded).hexdigest()};(out/'RESULT.json').write_text(json.dumps(cost,indent=2)+'\n');print(json.dumps({'cost':cost,'readout':data}),flush=True)
