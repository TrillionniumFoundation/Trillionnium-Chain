#!/usr/bin/env python3
"""Strict C1 count reassessment: list cached Cargo tests, never rerun test bodies."""
import collections
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

ROOT = Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
REPO = ROOT / "integration-repo"
OUT = Path(__file__).resolve().parent
HEAD = "cb557c5e59b00ba7c6b1d40f78fbe51031a26f11"
TREE = "7971aca2ff432ec8907bb69545a2c58d70b4a215"
A = "d3037ca5dfb6f301757c159b7888dca9b0317be0"
C0 = "c2988ed56ba475888d93428add7db27700c14e8c"
SOURCE_SHA = "8b0b39f3cc9a224badcf9aae1924327c7618f431ec25e6133a5d86e5e63a9fc7"
NATIVE_DIR = ROOT / "clean-integration-native-verifier-cb557c5e59b0-01"
TARGET = ROOT / "target-native-integration"
TEST_PATH = "trillionnium/crates/trnm-crypto-primitives/src/pon_work/rejection_cache_tests.rs"
TEST_SHA = "6ced986fd49f46c2e29df809488c50844ad8ae6f05e69d540abaca1638fd611c"
ADDED = [
    "pon_work::rejection_cache::observation_tests::complete_key_expiry_collision_and_restart_keep_current_native_verification",
    "pon_work::rejection_cache::observation_tests::observation_distinguishes_replayed_refusal_hit_cancellation_and_valid_work",
    "pon_work::rejection_cache::observation_tests::retained_owner_bounds_count_allocated_slot_capacity",
]
TOOLCHAIN = Path("/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path):
    path = Path(path)
    first = path.lstat()
    require(stat.S_ISREG(first.st_mode), "ordinary retained file required")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    last = path.lstat()
    keys = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    require(all(getattr(first, k) == getattr(last, k) for k in keys), "file changed during read")
    return {"path": str(path), "bytes": first.st_size, "sha256": digest.hexdigest()}


def checked_json(path, expected):
    p = pin(path)
    require(p["sha256"] == expected, "original JSON bytes changed: " + str(path))
    return p, json.loads(Path(path).read_bytes())


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(OUT, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return pin(path)


def raw_command(row):
    require(row["exit"] == 0 and row.get("error") is None and not row["timed_out"],
            "original real command failed")
    for which in ("stdout", "stderr"):
        observed = pin(row[which + "_path"])
        require(observed["sha256"] == row[which + "_sha256"], "original command log changed")
    return row


def run_counts(text):
    names = collections.Counter(line[5:-7] for line in text.splitlines()
                                if line.startswith("test ") and line.endswith(" ... ok"))
    groups = []
    for line in text.splitlines():
        if line.startswith("test result: "):
            require(line.startswith("test result: ok. "), "real failed Rust group")
            parts = line.split(";")
            passed = int(parts[0].split()[-2])
            failed = int(parts[1].split()[0])
            ignored = int(parts[2].split()[0])
            filtered = int(parts[4].split()[0])
            require(failed == ignored == filtered == 0, "missing, failed, ignored or filtered tests")
            groups.append({"passed": passed, "failed": failed, "ignored": ignored,
                           "filtered_out": filtered, "raw": line})
    require(groups and sum(g["passed"] for g in groups) == sum(names.values()), "name/count mismatch")
    return names, groups


def guard(path):
    p = pin(path)
    v = json.loads(Path(path).read_bytes())
    require(p["sha256"] == SOURCE_SHA and v["tested_commit"] == HEAD and v["tested_tree"] == TREE
            and v["kind"] == "head" and v["tracked_worktree_verified"] is True
            and v["tests_executed_by_identity_check"] is False, "exact C1 raw source guard required")
    return {**p, "tested_commit": HEAD, "tested_tree": TREE}


def main():
    os.sched_setaffinity(0, {22, 23})
    report = {
        "schema": "TRNM-W1-NATIVE-C1-COUNT-REASSESSMENT1",
        "source_commit": HEAD, "source_tree": TREE,
        "assessment_complete": False, "accepted": False, "commands": [], "errors": [],
        "original_wrapper_status_rewritten": False,
        "original_wrapper_stays_failed_due_stale_A_expected_count": True,
        "test_bodies_reexecuted": False, "fresh_proof_generations": 0,
        "new_expected_native_test_count": 243, "old_A_expected_native_test_count": 240,
        "wrapper": pin(__file__),
    }
    env = os.environ.copy()
    try:
        old_pin, old = checked_json(ROOT / "clean-A-native-verifier-01/manifest.json",
            "2c0c45cc9f126f377e8dabad7350330d9be55beb9b58cbfb422fc03b7d692eff")
        new_pin, new = checked_json(NATIVE_DIR / "manifest.json",
            "474dcad256dc85fdc3506a5856c2035c251bab7a03a8dcb2ca150b2f7f904e1c")
        inspection_pin, inspection = checked_json(
            ROOT / "native-verifier-count-reconciliation-cb557c5e59b0-02/inspection.json",
            "b6fa30097f7944e947a7303444942ff2ee49e318ba343c37b3a6ada7cbf04275")
        status = json.loads((OUT / "original-wrapper-terminal.json").read_bytes())
        require(status["job_id"] == "1a1b7be3312-12894-c19" and status["state"] == "failed"
                and status["exit_code"] == 1 and status["output_complete"] is True
                and status["output_durable"] is True and status["timed_out"] is False
                and status["cancelled"] is False, "retain original failed terminal faithfully")
        require(new["source_commit"] == HEAD and new["source_tree"] == TREE and new["passed"] is False,
                "original C1 failed wrapper identity")
        require(inspection["inspection_complete"] is True
                and inspection["added_test_names"] == ADDED
                and inspection["removed_test_names"] == []
                and inspection["C0_and_C1_source_identical"] is True, "exact independent source inspection")
        require(pin(REPO / TEST_PATH)["sha256"] == TEST_SHA, "three integration tests source changed")
        commands = [raw_command(r) for r in new["commands"]]
        require(len(commands) == len(old["commands"]) == 21, "all original commands required")
        original_native = next(r for r in old["commands"] if r["label"] == "10-native-tests")
        current_native = next(r for r in commands if r["label"] == "10-native-tests")
        require(current_native["argv"] == original_native["argv"], "original Cargo selector/flags changed")
        before = guard(new["source_before"]["report_path"])
        after = guard(new["source_after"]["report_path"])
        old_names, old_groups = run_counts(Path(original_native["stdout_path"]).read_text())
        require(pin(original_native["stdout_path"])["sha256"] == original_native["stdout_sha256"],
                "old roster bytes changed")
        actual_names, actual_groups = run_counts(Path(current_native["stdout_path"]).read_text())
        require(sum(old_names.values()) == 240 and len(old_groups) == len(actual_groups) == 26,
                "original retained group identity")
        expected = old_names + collections.Counter(ADDED)
        require(sum(expected.values()) == 243 and actual_names == expected,
                "strict 243 roster; no skipped or substituted old test")
        expected_pin = save("fixed-expected-roster.json",
                            {"tests": [{"name": n, "count": c} for n, c in sorted(expected.items())],
                             "count": 243, "origin": {"old_A_manifest": old_pin, "added_source": pin(REPO / TEST_PATH)}})
        env_record = json.loads((NATIVE_DIR / "environment.json").read_bytes())
        env.update(env_record["explicit_toolchain_and_target"])
        env.update(env_record["qualified_openssl_environment"])
        if env_record["LD_LIBRARY_PATH_inherited"] is None:
            env.pop("LD_LIBRARY_PATH", None)
        else:
            env["LD_LIBRARY_PATH"] = env_record["LD_LIBRARY_PATH_inherited"]
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        require(env["CARGO_TARGET_DIR"] == str(TARGET) and env["CARGO_BUILD_JOBS"] == "2"
                and env["OPENSSL_STATIC"] == "1" and env["TRNM_PQ_OPENSSL_VERSION"] == "3.5.9",
                "same qualified Cargo/OpenSSL environment required")

        def run(label, argv, timeout=180):
            stdout, stderr = OUT / (label + ".stdout"), OUT / (label + ".stderr")
            started = time.monotonic_ns()
            with stdout.open("xb") as so, stderr.open("xb") as se:
                child = subprocess.run(argv, cwd=REPO, env=env, stdin=subprocess.DEVNULL,
                                       stdout=so, stderr=se, timeout=timeout, check=False)
                so.flush(); os.fsync(so.fileno()); se.flush(); os.fsync(se.fileno())
            row = {"label": label, "argv": argv, "cwd": str(REPO), "exit": child.returncode,
                   "stdout_path": str(stdout), "stderr_path": str(stderr),
                   "stdout_sha256": pin(stdout)["sha256"], "stderr_sha256": pin(stderr)["sha256"],
                   "elapsed_ns": time.monotonic_ns() - started}
            report["commands"].append(row)
            require(child.returncode == 0, label + " failed")
            return stdout, stderr

        run("preflight", ["/usr/bin/bash", "scripts/project-preflight.sh", "--dev"])
        run("source-before", ["/usr/bin/python3", "scripts/ci/verify_ci_source.py",
             "--kind", "head", "--expected-head", HEAD, "--output", str(OUT / "source-before.json")])
        source_before = guard(OUT / "source-before.json")
        argv = list(current_native["argv"])
        separator = argv.index("--")
        argv = argv[:separator] + ["--message-format=json", "--", "--list", "--test-threads=1"]
        listed_stdout, listed_stderr = run("cargo-list-only", argv, 300)
        listed = collections.Counter()
        events = []
        for line in listed_stdout.read_text().splitlines():
            if line.startswith("{"):
                event = json.loads(line)
                if event.get("reason") == "compiler-artifact":
                    events.append(event)
            elif line.endswith(": test"):
                listed[line[:-6]] += 1
        require(events and all(e.get("fresh") is True for e in events),
                "enumeration unexpectedly rebuilt an artifact; zero-recompile claim rejected")
        artifacts = [e for e in events if e.get("executable") and e.get("profile", {}).get("test") is True
                     and "integration-repo/trillionnium/crates/trnm-crypto-primitives" in e["package_id"]]
        require(len(artifacts) == 26 and listed == expected and sum(listed.values()) == 243,
                "actual Cargo enumeration must exactly match all 26 groups/243 executed tests")
        executable_pins = []
        for event in artifacts:
            p = Path(event["executable"])
            require(p.is_absolute() and TARGET in p.parents, "enumerated artifact escaped current target")
            executable_pins.append(pin(p))
        verifier = next(r for r in commands if r["label"] == "12-verifier-tests")
        vn, vg = run_counts(Path(verifier["stdout_path"]).read_text())
        require(sum(vn.values()) == 2 and len(vg) == 1, "exact two actual verifier tests")
        receiver = next(r for r in commands if r["label"] == "15-real-receiver-controls")
        receiver_text = Path(receiver["stderr_path"]).read_text()
        receiver_counts = [int(l.split()[1]) for l in receiver_text.splitlines()
                           if l.startswith("Ran ") and " tests in " in l]
        require(receiver_counts == [7] and "OK" in receiver_text.splitlines(),
                "exact seven successful real receiver controls")
        for row in new["binaries"].values():
            require(pin(row["path"])["sha256"] == row["sha256"], "built binary changed")
        run("source-after", ["/usr/bin/python3", "scripts/ci/verify_ci_source.py",
             "--kind", "head", "--expected-head", HEAD, "--output", str(OUT / "source-after.json")])
        source_after = guard(OUT / "source-after.json")
        require(source_before["sha256"] == source_after["sha256"] == before["sha256"] == after["sha256"],
                "source identity changed during independent evaluation")
        report.update(
            assessment_complete=True, accepted=True,
            original_A_manifest=old_pin, original_failed_C1_manifest=new_pin,
            original_failed_terminal=pin(OUT / "original-wrapper-terminal.json"),
            source_inspection=inspection_pin, fixed_expected_roster=expected_pin,
            all_21_original_commands_exit_zero=True,
            exact_original_Cargo_test_argv_unchanged=current_native["argv"],
            actual_native_test_count=243, actual_verifier_test_count=2, actual_real_receiver_controls=7,
            native_failed=0, native_ignored=0, native_filtered_out=0,
            original_source_before=before, original_source_after=after,
            source_before=source_before, source_after=source_after,
            actual_run_groups=actual_groups, enumerated_test_count=243, enumerated_group_count=26,
            all_Cargo_artifacts_cached=True, compilation_performed=False,
            enumeration_stdout=pin(listed_stdout), enumeration_stderr=pin(listed_stderr),
            enumerated_Cargo_artifacts=save("cargo-artifacts.json", events),
            actual_enumerated_executables=executable_pins,
            binaries_unchanged=new["binaries"],
            scope="Independent strict expectation reconciliation on unchanged C1 raw commands. Original wrapper terminal remains failed; no reclassification, no full test rerun, no proof."
        )
    except BaseException as exc:
        report["errors"].append({"type": type(exc).__name__, "message": str(exc)})
    report["finished_monotonic_ns"] = time.monotonic_ns()
    result = save("assessment.json", report)
    print(json.dumps({"accepted": report["accepted"], "assessment_complete": report["assessment_complete"],
                      "assessment": result, "errors": report["errors"]}), flush=True)
    return 0 if report["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

