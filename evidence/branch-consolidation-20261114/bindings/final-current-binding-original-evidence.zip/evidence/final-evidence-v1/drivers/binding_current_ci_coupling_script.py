from pathlib import Path
import ast,copy,hashlib,json,os,subprocess,sys,time
root=Path('/private/tmp/chain-final-current-bindings-20261114')
out=Path('/private/tmp/chain-final-current-bindings-evidence-20261114/current-ci-coupling-v1')
out.mkdir()
(out/'pid.json').write_text(json.dumps({'pid':os.getpid(),'started':time.time()})+'\n')
env={**os.environ,'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','GIT_NO_LAZY_FETCH':'1','TMPDIR':'/private/tmp/chain-final-current-bindings-evidence-20261114/final-checkpoint-v1/canonical-tmp','PYTHONDONTWRITEBYTECODE':'1'}
def run(args,name,expect=0):
    with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:
        r=subprocess.run(args,cwd=root,env=env,stdout=so,stderr=se,check=False)
    assert r.returncode==expect,(name,r.returncode)
    return r.returncode
def git(*args):
    return subprocess.run(['git','--no-replace-objects','-c','core.commitGraph=false',*args],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
def sha(b): return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()=='5c04c60e463462d9df8884786e0d5bb32af08a64'
initial=git('diff','--name-only').decode().splitlines()
assert len(initial)==25,initial
run(['bash','scripts/project-preflight.sh'],'01-preflight')
run([sys.executable,'scripts/ci/test_w1_qrom_current_ci.py','-v'],'02-original-current-ci-refusal',1)
old_failure=(out/'02-original-current-ci-refusal.stderr').read_text()
assert 'historical/current selected-byte differences lost' in old_failure
assert 'Ran 0 tests' in old_failure
edits={}
originals={}
def read(name):
    if name not in originals: originals[name]=(root/name).read_bytes()
    return edits.get(name,originals[name]).decode()
def put(name,text): edits[name]=text.encode()
def once(text,old,new):
    assert text.count(old)==1,(old,text.count(old))
    return text.replace(old,new)
def json_bytes(v): return (json.dumps(v,indent=2,sort_keys=True,ensure_ascii=False)+'\n').encode()
new_names=[
'test_w1_qrom_current_implementation_audit.CurrentImplementationTests.test_consolidated_local_sources_have_independent_reviewed_pins',
'test_w1_qrom_current_implementation_audit.CurrentImplementationTests.test_each_consolidated_source_refuses_omission_and_mutation']
rname='config/pon/w1-qrom-current-required-tests-v1.json'
roster=json.loads(read(rname)); old_roster=copy.deepcopy(roster)
assert roster['expected_tests']==75
row=next(x for x in roster['suites'] if x['module']=='test_w1_qrom_current_implementation_audit')
assert row['expected_tests']==14 and not set(new_names)&set(row['tests'])
row['tests']=sorted(row['tests']+new_names);row['expected_tests']=16;roster['expected_tests']=77
edits[rname]=json_bytes(roster)
sname='config/pon/w1-qrom-supplemental-tests-v1.json'
supp=json.loads(read(sname));old_supp=copy.deepcopy(supp)
assert supp['expected_tests']==22
row=next(x for x in supp['suites'] if x['suite']=='current')
assert row['expected_tests']==14 and row['tests']==next(x for x in old_roster['suites'] if x['module']==row['module'])['tests']
row['tests']=sorted(row['tests']+new_names);row['expected_tests']=16;supp['expected_tests']=24
assert supp['suites'][0]==old_supp['suites'][0]
assert supp['qualification']==old_supp['qualification']
edits[sname]=json_bytes(supp)
name='scripts/ci/w1_qrom_supplemental_controls.py'
text=read(name)
text=once(text,"ROSTER_SHA256 = '33bdae599edc3ef8f54efd84245d24b90b0b4effdb2f71b2cdae52a71d4001c4'","ROSTER_SHA256 = '"+sha(edits[sname])+"'")
text=once(text,"('current', 'test_w1_qrom_current_implementation_audit', 14)","('current', 'test_w1_qrom_current_implementation_audit', 16)")
text=once(text,"manifest['expected_tests'] == 22","manifest['expected_tests'] == 24")
put(name,text)
name='scripts/ci/w1_qrom_current_ci.py';text=read(name)
text=once(text,"ROSTER_SHA256 = 'e48c23d4d6737d0143798a5c93a194310ebdf7ba1a0cb87bdf3a36af65b8f581'","ROSTER_SHA256 = '"+sha(edits[rname])+"'")
anchor="DRIFT_REASON = 'input exceeds bound: formal/pon-nakamoto-v1/w1_v2_verifier/src/main.rs'\n"
addition="""# Independent reviewed order: a jointly edited report/map cannot erase or add drift.
REVIEWED_DIFFERENCE_PATHS = (
    'formal/pon-nakamoto-v1/w1_v2_verifier/src/main.rs',
    'formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock',
    'trillionnium/crates/trnm-crypto-primitives/src/pon_work.rs',
    'trillionnium/crates/trnm-protocol/src/pon_wire.rs',
)
"""
text=once(text,anchor,anchor+addition)
text=once(text,"    require(report.get('selected_source_differences') == expected and len(expected) == 2,\n","    require(report.get('selected_source_differences') == expected\n            and tuple(row['path'] for row in expected) == REVIEWED_DIFFERENCE_PATHS,\n")
put(name,text)
name='scripts/ci/test_w1_qrom_current_ci.py';text=read(name)
text=once(text,'executes the original eight historical and fourteen current controls.','executes the original eight historical and sixteen current controls.')
old="""        self.assertEqual([row['observed_bytes'] for row in self.drift['selected_source_differences']],
                         [11172, 32654])
"""
new="""        self.assertEqual(ci.REVIEWED_DIFFERENCE_PATHS, (
            'formal/pon-nakamoto-v1/w1_v2_verifier/src/main.rs',
            'formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock',
            'trillionnium/crates/trnm-crypto-primitives/src/pon_work.rs',
            'trillionnium/crates/trnm-protocol/src/pon_wire.rs',
        ))
        self.assertEqual([row['observed_bytes'] for row in self.drift['selected_source_differences']],
                         [11172, 46018, 106066, 32654])
"""
text=once(text,old,new)
text=once(text,"        for mutation in ('missing', 'wrong_reason', 'exit_zero', 'old_source', 'scope'):\n","        for mutation in ('missing', 'extra', 'wrong_digest', 'self_consistent_omission',\n                         'self_consistent_extra', 'wrong_reason', 'exit_zero', 'old_source', 'scope'):\n")
old="""                report = deepcopy(self.drift)
                if mutation == 'missing':
                    report['selected_source_differences'].pop()
                elif mutation == 'wrong_reason':
"""
new="""                report = deepcopy(self.drift)
                contract = deepcopy(self.contract)
                if mutation == 'missing':
                    report['selected_source_differences'].pop()
                elif mutation == 'extra':
                    report['selected_source_differences'].append(
                        deepcopy(report['selected_source_differences'][0]))
                elif mutation == 'wrong_digest':
                    report['selected_source_differences'][2]['observed_sha256'] = '0' * 64
                elif mutation == 'self_consistent_omission':
                    removed = report['selected_source_differences'].pop(2)
                    for row in contract['project_files']:
                        if row['path'] == removed['path']:
                            row.update(removed['historical'])
                elif mutation == 'self_consistent_extra':
                    old = {row['path']: row for row in self.legacy['project_files']}
                    added = next(row for row in contract['project_files']
                                 if row['path'] not in ci.REVIEWED_DIFFERENCE_PATHS)
                    added['sha256'] = '0' * 64
                    report['selected_source_differences'].append({
                        'path': added['path'], 'historical': old[added['path']], 'current': added,
                        'observed_bytes': added['bytes'], 'observed_sha256': added['sha256']})
                    order = {row['path']: i for i, row in enumerate(contract['project_files'])}
                    report['selected_source_differences'].sort(key=lambda row: order[row['path']])
                elif mutation == 'wrong_reason':
"""
text=once(text,old,new)
text=once(text,"                    ci.validate_drift(report, self.contract, self.legacy)\n","                    ci.validate_drift(report, contract, self.legacy)\n")
put(name,text)
name='docs/security/W1_QROM_CURRENT_SOURCE_MAPPING_V2.md'
text=read(name)
text += """
### Current CI consumer correspondence

The current named roster retains its preceding 75 controls and adds the two
independent consolidated-source controls, for 77 exact names. The supplemental
roster retains the original eight historical names unchanged and carries the
same 16 current mapping controls, for 24 names. Both runners still require the
complete registered, started and successful identities with no skips.

The historical-on-current diagnostic binds the four reviewed differences in
project-file order: verifier source, verifier lock, current PoN work source, and
protocol wire source. Missing, duplicate, substituted-digest and mutually edited
map/report difference sets are refused. This updates current CI correspondence;
the fixed historical job, original historical roster, saved reports and
cryptographic qualification are unchanged.
"""
put(name,text)
for name,raw in edits.items():
    if name.endswith('.py'): ast.parse(raw,filename=name)
# Preserve original method roster, adding no current-CI method or weakening old outcomes.
def names(raw):
    t=ast.parse(raw);return [(c.name,n.name) for c in t.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
assert names(originals['scripts/ci/test_w1_qrom_current_ci.py'])==names(edits['scripts/ci/test_w1_qrom_current_ci.py'])
for name,raw in edits.items(): (root/name).write_bytes(raw)
# Preserve original corpus formatting and only replace reviewed existing path-specific OIDs.
corpus_name='config/pon/pq-cross-branch-corpus-v1.json'
base_raw=git('show','HEAD:'+corpus_name)
base=json.loads(base_raw);working=json.loads((root/corpus_name).read_bytes())
assert base['required_paths']==working['required_paths']
assert set(base['pinned_blobs'])==set(working['pinned_blobs'])
assert {k:v for k,v in base.items() if k!='pinned_blobs'}=={k:v for k,v in working.items() if k!='pinned_blobs'}
text=base_raw.decode();pin_changes=[]
modified=git('diff','--name-only').decode().splitlines()
for name in modified:
    if name==corpus_name or name not in base['pinned_blobs']: continue
    raw=(root/name).read_bytes();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    old=base['pinned_blobs'][name]
    if old!=oid:
        needle=json.dumps(name)+': '+json.dumps(old)
        text=once(text,needle,json.dumps(name)+': '+json.dumps(oid))
        pin_changes.append({'path':name,'old_blob':old,'new_blob':oid,'bytes':len(raw),'sha256':sha(raw)})
(root/corpus_name).write_text(text)
run(['git','diff','--check'],'03-diff-check')
patch=git('diff','--binary')
(out/'working.patch').write_bytes(patch)
summary={'source_base':'5c04c60e463462d9df8884786e0d5bb32af08a64','prior_current_ci_exit':1,'prior_current_ci_tests_run':0,'prior_failure_reason':'historical/current selected-byte differences lost','current_named_tests':77,'supplemental_current':16,'supplemental_historical':8,'supplemental_total':24,'historical_row_unchanged':supp['suites'][0]==old_supp['suites'][0],'roster_sha256':sha(edits[rname]),'supplemental_roster_sha256':sha(edits[sname]),'modified_paths':git('diff','--name-only').decode().splitlines(),'new_coupled_edits':[{'path':n,'before_sha256':sha(originals[n]),'after_sha256':sha(b)} for n,b in edits.items()],'corpus_pin_changes':pin_changes,'working_patch':{'bytes':len(patch),'sha256':sha(patch)},'rust_sources_modified':False}
(out/'review.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('new_coupled_edits','corpus_pin_changes')},indent=2))
