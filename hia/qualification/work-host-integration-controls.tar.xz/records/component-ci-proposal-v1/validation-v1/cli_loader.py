from pathlib import Path
import sys,importlib.util
root=Path('/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo')
candidate=Path('/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/component-ci-proposal-v1/candidate')
sys.path.insert(0,str(root))
import hia.tools
def load(name):
 p=candidate/('hia/tools/'+name+'.py')
 spec=importlib.util.spec_from_file_location('hia.tools.'+name,p)
 m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);setattr(hia.tools,name,m);m.ROOT=root;return m
load('component_partition');q=load('qualify');r=load('qualify_components_ci')
which=sys.argv.pop(1)
raise SystemExit((q if which=='qualify' else r).main())
