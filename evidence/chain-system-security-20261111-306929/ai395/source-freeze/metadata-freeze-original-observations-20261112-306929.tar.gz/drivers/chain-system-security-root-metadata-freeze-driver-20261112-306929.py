import datetime,hashlib,json,os,pathlib,subprocess,sys,time,traceback
R=pathlib.Path('/home/qq/chain-system-security-20261112-306929')
O=pathlib.Path('/home/qq/chain-system-security-native-receipts-20261112-306929/root-metadata-freeze-813')
BASE='813620f387199bef3eae2493e2af07c70444db58'
OLD='7f83ea843d6d1578a475a7a0c4dc026da564a795'
LOCK='3eef9a9a1431914cae0f25f49a009a6103cf30caf0bc5f189918ad71fe91b71d'
OLD_LOCK='f7454a2cc0e38d0bb243d6ec56419a7bc3386108f0e5dfb2baf810f5be02e17f'
O.mkdir(parents=True,exist_ok=False)
E=dict(os.environ)
TC=pathlib.Path('/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu')
E.update(PATH=str(TC/'bin')+':'+E.get('PATH','/usr/bin:/bin'),RUSTC=str(TC/'bin/rustc'),LD_LIBRARY_PATH=str(TC/'lib'),CARGO_HOME='/home/qq/.cargo',CARGO_TARGET_DIR=str(R/'trillionnium/target'),CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='1',PYTHONPATH=str(R/'scripts/ci'))
records=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(R),*a],env=E)
def put(p,s): (R/p).write_text(s)
def jsonout(name,value):
 with (O/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def command(name,argv,expected=0):
 start=time.monotonic()
 with (O/(name+'.stdout.log')).open('xb') as stdout,(O/(name+'.stderr.log')).open('xb') as stderr:
  p=subprocess.run(argv,cwd=R,env=E,stdout=stdout,stderr=stderr)
 row={'name':name,'argv':argv,'cwd':str(R),'exit_code':p.returncode,'expected_exit_code':expected,'elapsed_seconds':time.monotonic()-start,'logs':[]}
 for suffix in ['stdout.log','stderr.log']:
  f=O/(name+'.'+suffix);b=f.read_bytes();row['logs'].append({'path':f.name,'bytes':len(b),'sha256':sha(b)})
 records.append(row);jsonout(name+'.json',row)
 print(json.dumps({'name':name,'exit_code':p.returncode,'elapsed_seconds':row['elapsed_seconds']}),flush=True)
 assert p.returncode==expected,(name,p.returncode,expected)
 return row
try:
 assert git('rev-parse','HEAD').decode().strip()==BASE
 assert not git('status','--porcelain=v1')
 command('preflight',['bash','scripts/project-preflight.sh'])
 command('authority-prior-refusal',['python3','scripts/ci/pq_authority_effect_register.py'],2)
 manifest_path='config/pon/pq-authority-effects-v1.json'
 checker_path='scripts/ci/pq_authority_effect_register.py'
 test_path='scripts/ci/test_pq_authority_effect_register.py'
 doc_path='docs/security/PQ_AUTHORITY_EFFECT_REGISTER_V1.md'
 plan_path='docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
 paths=[manifest_path,checker_path,test_path,doc_path,plan_path]
 originals={p:git('show',BASE+':'+p) for p in paths}
 assert all((R/p).read_bytes()==b for p,b in originals.items())
 m=json.loads(originals[manifest_path]);assert m['source_revision']==OLD
 prior_lock=sha(json.dumps({'source_revision':OLD,'files':m['source_files_sha256']},sort_keys=True,separators=(',',':')).encode())
 assert prior_lock==OLD_LOCK
 expected_changes={
 'trillionnium/crates/trnm-service-settlement/src/store.rs':('c990cfc2e1267d681633de6c99387c9074348b621ab51cafd956dd2c47db846b','b186e6f76c012dc3153490f869ac5dc5329017259a4e5eb907ca910b52ab0da4'),
 'trillionnium/crates/trnm-service-settlement/src/tests.rs':('209aec0e8974b1c276b4ac88a892138027f8059c47407918c69eb264bdc87663','bb7f3134591342a068440db860153bc7d74475023c2990823ba08bc2bd1d6f68')}
 actual={};changed={}
 for p,old in m['source_files_sha256'].items():
  b=git('show',BASE+':'+p);assert (R/p).read_bytes()==b
  actual[p]=sha(b)
  if old!=actual[p]:changed[p]=(old,actual[p])
 assert len(actual)==44 and changed==expected_changes
 assert sha(json.dumps({'source_revision':BASE,'files':actual},sort_keys=True,separators=(',',':')).encode())==LOCK
 m['source_revision']=BASE;m['source_files_sha256']=actual
 put(manifest_path,json.dumps(m,indent=2)+'\n')
 s=originals[checker_path].decode();assert s.count("SOURCE_REVISION = '"+OLD+"'")==1 and s.count(OLD_LOCK)==1
 s=s.replace("SOURCE_REVISION = '"+OLD+"'","SOURCE_REVISION = '"+BASE+"'").replace(OLD_LOCK,LOCK);put(checker_path,s)
 s=originals[test_path].decode();assert s.count(OLD)==1
 s=s.replace(OLD,BASE)
 anchor="for field, value in (('source_revision', '0' * 40),\n"
 assert s.count(anchor)==1
 s=s.replace(anchor,anchor+"                             ('source_revision', '"+OLD+"'),\n")
 put(test_path,s)
 s=originals[doc_path].decode()
 s=s.replace('8add285b6c0a91d8b7812efe2d02c9342f74c91b',BASE,1)
 s=s.replace('## Joint-source continuation\n\nThis review derives','## Retained joint-source continuation\n\nThat review derived',1)
 s=s.replace('## Current account-selector mapping, 2026-11-11','## Retained account-selector mapping, 2026-11-11',1)
 s=s.replace('The active source map uses','That source map used',1)
 s=s.replace('The active\ncanonical table digest',"That checkpoint's\ncanonical table digest",1)
 section="""## Current combined candidate binding, 2026-11-12

The reviewed source is @@813620f387199bef3eae2493e2af07c70444db58@@, tree
@@4670d4ca9354d862ed2a5b3061dcaa61c759004e@@. All 44 regular-file blobs
were read from that immutable checkpoint and compared with the actual checkout.
The canonical lock SHA-256, including that source revision, is
@@3eef9a9a1431914cae0f25f49a009a6103cf30caf0bc5f189918ad71fe91b71d@@.

Forty-two file pins are unchanged from the prior fixed
@@7f83ea843d6d1578a475a7a0c4dc026da564a795@@ map. Only the portable
Settlement @@store.rs@@ and @@tests.rs@@ pins change. The opener now uses
@@symlink_metadata@@: an existing journal, WAL or SHM object, including a dangling
symlink, is refused; only @@NotFound@@ means absent, and other metadata errors
are refused before SQLite opens the database. Its controls cover refused
create/reopen without changing existing database, sidecar or target bytes,
a real overlong-path metadata error, and clean create/reopen.

This remains @@portable-settlement-store-only@@. It adds no Node consumer,
PQ payment route, external-effect authority or general TOCTOU guarantee.
All seven routes, the 44-path roster and false qualification fields remain
unchanged. The checker and independent positive assertion bind this reviewed
revision, while the existing stale-context control also rejects the prior
@@7f83ea8@@ revision. Older checkpoint identities and failures below remain
historical records. This byte review does not execute or qualify native tests.

""".replace('@@',chr(96))
 anchor='## Retained joint-source continuation'
 assert s.count(anchor)==1
 put(doc_path,s.replace(anchor,section+anchor,1))
 prefix="""**System security combined source, 2026-11-12 UTC — HOLD:**

Use immutable runtime checkpoint @@813620f387199bef3eae2493e2af07c70444db58@@
to compose the original V5 witnessed historical provider-readback continuation,
the five existing no-sidecar SQLite opener refusal repairs, and the native
incentive/evaluation controls and documented counterexamples. The SQLite
changes preserve path bytes and reject sidecar objects or metadata failures;
they are not a dependency upgrade or a remote exploit reproduction, and do not
establish general TOCTOU safety.

Review the curated authority/effect register against all 44 immutable blobs at
this checkpoint. Exactly two Settlement pins change; freeze the canonical
source/revision table to
@@3eef9a9a1431914cae0f25f49a009a6103cf30caf0bc5f189918ad71fe91b71d@@.
Keep its seven effect scopes and all false qualification fields. The separate
43-file Root map and 1,162 corpus pins already match this checkpoint and retain
their existing reviewed bindings.

Run the complete source, metadata and retained native gates on the resulting
immutable metadata successor. Execute the default-feature incentive targets,
then the 51 Root witness/provider methods with the required PQ feature, then
the SQLite and strict Clippy gates, recording each actual feature set and
source before/after. Do not promote earlier static checks, provider smoke,
partial-source native observations or interrupted builds into a pass for this
combined source. Later evidence-only merges retain their own distinct heads.

The V5 witness constrains Root state and historical identity, not every provider
journal head. Cold provider-journal rollback still requires external same-operation
reconciliation; Unknown grants no redispatch authority. Independent custody,
daemon/wire and ordinary M15 assembly, actual external effects, unknown common
controllers, generalization and whole-chain guarantees remain open. Production
activation and main-merge authorization remain closed.

""".replace('@@',chr(96))
 put(plan_path,prefix+originals[plan_path].decode())
 assert sorted(git('diff','--name-only').decode().splitlines())==sorted(paths)
 command('metadata-diff-check',['git','diff','--check','--',*paths])
 jsonout('reviewed-binding.json',{'source_revision':BASE,'source_tree':'4670d4ca9354d862ed2a5b3061dcaa61c759004e','files':actual,'changed':changed,'canonical_sha256':LOCK,'prior_revision':OLD,'prior_canonical_sha256':OLD_LOCK,'source_origin':'git show immutable checkpoint; compared with current regular files','source_only_review':True,'native_tests_executed':False})
 command('commit-preflight',['bash','scripts/project-preflight.sh'])
 command('metadata-add',['git','add','--',*paths])
 command('metadata-commit',['git','-c','user.name=Codex','-c','user.email=codex@openai.com','commit','-s','-m','chore(security): bind combined authority source to the reviewed checkpoint'])
 head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
 assert git('rev-parse','HEAD^').decode().strip()==BASE and not git('status','--porcelain=v1')
 sys.path.insert(0,str(R/'scripts/ci'))
 from verify_ci_source import verify
 before=verify('head',head,root=R);jsonout('source-before-gates.json',before)
 command('authority-current',['python3','scripts/ci/pq_authority_effect_register.py'])
 command('root-current',['python3','scripts/ci/pq_root_dependency_register.py'])
 command('corpus-current',['python3','scripts/ci/check_pq_research_integration.py'])
 command('authority-and-root-controls',['python3','-m','unittest','test_pq_authority_effect_register','test_pq_root_dependency_register','test_run_pq_root_witness_v5','-v'])
 command('source-rejection-controls',['python3','scripts/ci/test_ci_source_integrity.py'])
 command('repository-links',['python3','scripts/ci/check_repository.py'])
 command('cargo-format',[str(TC/'bin/cargo'),'fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'])
 command('locked-default-graph',[str(TC/'bin/cargo'),'metadata','--locked','--manifest-path','trillionnium/Cargo.toml','--format-version','1'])
 command('locked-all-features-graph',[str(TC/'bin/cargo'),'metadata','--locked','--manifest-path','trillionnium/Cargo.toml','--all-features','--format-version','1'])
 after=verify('head',head,root=R);jsonout('source-after-gates.json',after);assert before==after
 bundle=O/'combined-metadata-from-813.bundle'
 command('metadata-bundle',['git','bundle','create',str(bundle),'HEAD','^'+BASE])
 command('metadata-bundle-verify',['git','bundle','verify',str(bundle)])
 b=bundle.read_bytes()
 result={'schema':'trnm-combined-metadata-freeze-v1','head':head,'tree':tree,'base':BASE,'clean':not git('status','--porcelain=v1'),'full_source_before_after_equal':before==after,'source_before':before,'source_after':after,'commands':records,'bundle':str(bundle),'bundle_bytes':len(b),'bundle_sha256':sha(b),'native_tests_executed':False,'status':'HOLD','production_activation':False}
 jsonout('freeze-result.json',result)
 print(json.dumps({'head':head,'tree':tree,'source_verified':True,'bundle':str(bundle),'bytes':len(b),'sha256':sha(b),'receipt':str(O/'freeze-result.json')}),flush=True)
except BaseException as error:
 failure={'error_type':type(error).__name__,'error':str(error),'traceback':traceback.format_exc(),'commands':records,'status':'HOLD','native_tests_executed':False}
 try:failure['current_head']=git('rev-parse','HEAD').decode().strip()
 except BaseException:pass
 jsonout('freeze-failure.json',failure)
 raise
