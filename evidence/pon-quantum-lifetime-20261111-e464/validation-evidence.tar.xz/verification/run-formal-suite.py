from pathlib import Path
import contextlib, datetime, hashlib, json, os, subprocess, sys, time, unittest

sys.dont_write_bytecode = True
ROOT=Path('/workspace/scratch/e4648d82092d/chain')
OUT=Path('/workspace/scratch/e4648d82092d/verification')
os.chdir(ROOT)
START=ROOT/'formal/pon-nakamoto-v1'
paths=sorted(set(START.rglob('*.py'))|set((ROOT/'scripts').rglob('*.py')))
paths=[p for p in paths if '__pycache__' not in p.parts]

def snapshot(files):
    result={}
    for path in files:
        rel=str(path.relative_to(ROOT))
        if path.is_file():
            raw=path.read_bytes()
            result[rel]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
        else:
            result[rel]={'missing':True}
    return result

def git(*args):
    p=subprocess.run(['git',*args],text=True,capture_output=True,cwd=ROOT)
    return {'exit_code':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()}

def write(name,data):
    with (OUT/name).open('x') as f:
        json.dump(data,f,sort_keys=True,indent=2)
        f.write('\n')

before=snapshot(paths)
test_paths=sorted(str(p.relative_to(ROOT)) for p in START.rglob('test*.py'))
metadata={'actual_command':[sys.executable,str(Path(__file__).resolve())],
          'unittest_command_equivalent':[sys.executable,'-m','unittest','discover','-s','formal/pon-nakamoto-v1','-p','test*.py','-v'],
          'working_directory':str(ROOT),'python_version':sys.version,
          'source_scope':'working candidate; Git HEAD does not include dirty/untracked changes',
          'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'git_head_before':git('rev-parse','HEAD'),'git_status_before':git('status','--porcelain'),
          'test_paths':test_paths,'python_sources_before':before}
write('formal-suite-before.json',metadata)
started=time.monotonic()
result=None
unexpected=None
exit_code=1
with (OUT/'formal-suite.log').open('x',buffering=1) as stream:
    with contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):
        print('ACTUAL_COMMAND',json.dumps(metadata['actual_command']))
        print('UNITTEST_COMMAND_EQUIVALENT',json.dumps(metadata['unittest_command_equivalent']))
        print('SOURCE_SCOPE',metadata['source_scope'])
        print('STARTED_AT_UTC',metadata['started_at_utc'])
        try:
            program=unittest.main(module=None, argv=['python -m unittest','discover','-s',str(START),'-p','test*.py','-v'],exit=False)
            result=program.result
            exit_code=0 if result.wasSuccessful() else 1
        except BaseException as error:
            import traceback
            unexpected={'type':type(error).__name__,'message':str(error)}
            traceback.print_exc()
        print('ELAPSED_SECONDS',time.monotonic()-started)
        print('HARNESS_EXIT_CODE',exit_code)

after=snapshot(paths)
changed={p:{'before':before[p],'after':after[p]} for p in before if before[p]!=after[p]}
imports={}
for name,module in sorted(sys.modules.copy().items()):
    file=getattr(module,'__file__',None)
    if not file: continue
    path=Path(file).resolve()
    try: relative=str(path.relative_to(ROOT))
    except ValueError: continue
    if relative in before:
        imports[name]={'path':relative,'before':before[relative],'after':after[relative]}
summary={'schema':'trnm-quantum-lifetime-formal-discovery-observation-v1',
         'actual_command':metadata['actual_command'],'unittest_command_equivalent':metadata['unittest_command_equivalent'],
         'source_scope':metadata['source_scope'],'started_at_utc':metadata['started_at_utc'],
         'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-started,
         'git_head_before':metadata['git_head_before'],'git_head_after':git('rev-parse','HEAD'),
         'test_paths':test_paths,'python_sources_before':before,'python_sources_after':after,
         'imported_repository_modules':imports,'changed_python_sources':changed,
         'source_unchanged':not changed,'exit_code':exit_code,'unhandled_exception':unexpected,
         'tests_run':result.testsRun if result is not None else None,
         'failures':[{'id':t.id(),'traceback':message} for t,message in result.failures] if result else [],
         'errors':[{'id':t.id(),'traceback':message} for t,message in result.errors] if result else [],
         'skipped':[{'id':t.id(),'reason':reason} for t,reason in result.skipped] if result else [],
         'expected_failures':[{'id':t.id(),'traceback':message} for t,message in result.expectedFailures] if result else [],
         'unexpected_successes':[t.id() for t in result.unexpectedSuccesses] if result else [],
         'full_log_sha256':hashlib.sha256((OUT/'formal-suite.log').read_bytes()).hexdigest(),
         'full_log_bytes':(OUT/'formal-suite.log').stat().st_size}
write('formal-suite-manifest.json',summary)
print(json.dumps({k:summary[k] for k in ('tests_run','elapsed_seconds','exit_code','source_unchanged','full_log_bytes','full_log_sha256')},sort_keys=True))
print(json.dumps({'failures':len(summary['failures']),'errors':len(summary['errors']),'skipped':len(summary['skipped']),'expected_failures':len(summary['expected_failures']),'unexpected_successes':len(summary['unexpected_successes']),'imported_repository_modules':len(imports),'test_module_paths':len(test_paths),'changed_python_sources':list(changed)},sort_keys=True))
sys.exit(exit_code)
