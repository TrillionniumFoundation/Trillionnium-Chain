#!/usr/bin/env python3
"""Generate reproducible finite-cohort summaries without qualifying hardness."""
from pathlib import Path
import argparse,json,statistics

def summarize(path):
    data=json.loads((path/'raw.json').read_text());summary=[]
    for case in data['cases']:
        for horizon in data['horizons']:
            groups={}
            for row in data['rows']:
                if row['case']==case and row['horizon']==horizon and row['status']=='BYTE_IDENTICAL_FULL_W1':
                    groups.setdefault(row['method'],[]).append(row)
            medians={name:statistics.median(r['total_producer_cpu_ns']/horizon for r in rows)for name,rows in groups.items()}
            best=min(medians,key=medians.get);wins=groups[best][0]['winners']
            summary.append(dict(case=case,horizon=horizon,best_observed_method=best,
                median_cpu_us_per_attempt_including_setup=medians[best]/1000,
                prepared_cpu_us_per_attempt_including_setup=medians['prepared']/1000,
                best_divided_by_prepared=medians[best]/medians['prepared'],
                winners_on_common_nonce_path=wins,
                median_cpu_us_per_observed_win_including_setup=medians[best]*horizon/wins/1000 if wins else None,
                method_cpu_us_per_attempt_including_setup={m:v/1000 for m,v in medians.items()}))
    return dict(schema='trnm-pure-pon-finite-cost-summary-v1',source=str(path),binary_sha256=data['binary_sha256'],
                rows=summary,global_cheapest_cost_qualified=False,statistical_independence_qualified=False,
                gpu_measured=False,node_task_eligibility_checked=False)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('directory',type=Path);args=p.parse_args()
    print(json.dumps(summarize(args.directory),indent=2))
