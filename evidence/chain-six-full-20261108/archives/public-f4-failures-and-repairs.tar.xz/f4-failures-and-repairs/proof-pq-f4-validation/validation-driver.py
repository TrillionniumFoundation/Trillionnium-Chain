import os,sys,json,hashlib,pathlib,subprocess,time,re,traceback,importlib.util
from datetime import datetime,timezone
ROOT=pathlib.Path("/data/chain-six-d9fb-20261108/delivery-source")
OUT=pathlib.Path("/data/chain-six-d9fb-20261108/evidence/final-integration/proof-pq-f4-validation")
HEAD="e9b7a60b9519e39b792199dc8756fb9d1245bab8"
TREE="d7d107818a74fdf4fe95e97d1de5c82664126363"
ART=pathlib.Path("/data/chain-six-d9fb-20261108/evidence/proof-github-ci-diagnosis/F3-candidate-head")
ZIP=ART.with_suffix(".zip")
PY=["/usr/bin/python3","-B"]
OUT.mkdir(parents=True,exist_ok=False)
(OUT/"validation-driver.py").write_text(p["driver"])
(OUT/"retained-candidate-offline-replay.py").write_text(p["api"])
TMP=pathlib.Path("/data/chain-six-d9fb-20261108/tmp-proof-f4")
TMP.mkdir(parents=True,exist_ok=True)
env=dict(os.environ)
env.update(PYTHONDONTWRITEBYTECODE="1",PYTHONUNBUFFERED="1",CARGO_BUILD_JOBS="2",CARGO_INCREMENTAL="0",RUSTUP_TOOLCHAIN="1.95.0",RAYON_NUM_THREADS="2",RUST_TEST_THREADS="1",CARGO_TERM_COLOR="never",CARGO_TARGET_DIR="/data/chain-six-d9fb-20261108/targets/proof",TMPDIR=str(TMP))
env["PATH"]="/home/qian-qi/.cargo/bin:"+env.get("PATH","/usr/bin:/bin")
prefix="/home/qian-qi/workspace/pon-demand-acceptance-20261107-root525798dad3c2/build-runtime/trnm-pq-provider-3.5.9.DYf2qEaX/install"
env.update(OPENSSL_DIR=prefix,OPENSSL_STATIC="1",OPENSSL_CONF="/dev/null",OPENSSL_MODULES=prefix+"/lib/ossl-modules",TRNM_PQ_OPENSSL=prefix+"/bin/openssl",TRNM_PQ_OPENSSL_SHA256="8ff7dd91270fd4a8fc377031f0fd2f2cee1cd17a32ce30e4fd773a25730a120f",TRNM_PQ_OPENSSL_VERSION="3.5.9")
os.environ.update(env)
records=[]
checks=[]
started=datetime.now(timezone.utc).isoformat()
def sha(path):
 h=hashlib.sha256()
 with path.open("rb") as f:
  for b in iter(lambda:f.read(1048576),b""):h.update(b)
 return h.hexdigest()
def write(name,data):
 (OUT/name).write_text(json.dumps(data,sort_keys=True,indent=2)+"\n")
def check(name,ok,details=None):
 item={"name":name,"passed":bool(ok),"details":details}
 checks.append(item)
 write("checks-progress.json",checks)
 print(json.dumps({"check":name,"passed":bool(ok)}),flush=True)
 return bool(ok)
def run(name,argv,expected=0,count=None,needle=None,timeout=1200):
 a=OUT/(name+".stdout.log");b=OUT/(name+".stderr.log")
 t=time.monotonic()
 print(json.dumps({"start":name,"argv":argv}),flush=True)
 rc=None;error=None
 with a.open("xb") as so,b.open("xb") as se:
  try:
   rc=subprocess.run(argv,cwd=ROOT,env=env,stdout=so,stderr=se,timeout=timeout,check=False).returncode
  except Exception as e:error=repr(e)
 item={"name":name,"argv":argv,"cwd":str(ROOT),"exit_code":rc,"expected_exit_code":expected,"wall_seconds":time.monotonic()-t,"stdout":{"path":a.name,"bytes":a.stat().st_size,"sha256":sha(a)},"stderr":{"path":b.name,"bytes":b.stat().st_size,"sha256":sha(b)},"error":error}
 ok=rc==expected and error is None
 if needle is not None:
  st=b.read_text(errors="replace")
  ok=ok and needle in st
  item["required_stderr_substring"]=needle
 if count is not None:
  st=b.read_text(errors="replace")
  summary=re.findall(r"(?m)^Ran (\d+) tests? in [0-9.]+s$",st)
  ids=re.findall(r"(?m)^test_[A-Za-z0-9_]+ \(([^)\n]+)\)",st)
  statuses=re.findall(r"(?m)\.\.\. (ok|FAIL|ERROR|skipped[^\n]*|expected failure|unexpected success)$",st)
  complete=summary==[str(count)] and st.endswith("\nOK\n") and len(ids)==count and len(set(ids))==count and len(statuses)==count and all(x=="ok" for x in statuses)
  item["tests"]={"expected":count,"reported":summary,"named":len(ids),"distinct":len(set(ids)),"statuses":len(statuses),"exact_success_roster":complete,"ids":ids}
  ok=ok and complete
 item["passed"]=ok
 if expected!=0:item["disposition"]="EXPECTED_REFUSAL" if ok else "UNEXPECTED_RESULT"
 records.append(item);write("commands-progress.json",records)
 print(json.dumps({"done":name,"exit":rc,"passed":ok,"wall_seconds":round(item["wall_seconds"],3)}),flush=True)
 if not ok:
  print(json.dumps({"failure":name,"stderr_tail":b.read_text(errors="replace")[-12000:]}),flush=True)
 return item
def manifest(root):
 result=[]
 for x in sorted(root.rglob("*")):
  if x.is_symlink():raise RuntimeError("unexpected retained artifact symlink: "+str(x))
  if x.is_file():result.append({"path":x.relative_to(root).as_posix(),"bytes":x.stat().st_size,"sha256":sha(x)})
 return result
source_cmd=PY+["scripts/ci/verify_ci_source.py","--kind","head","--expected-head",HEAD]
fatal=None
try:
 r=run("source-before",source_cmd+["--output",str(OUT/"source-before.json")])
 if not r["passed"]:raise RuntimeError("full source-before failed")
 before=json.loads((OUT/"source-before.json").read_text())
 if not check("expected-full-source",before["tested_commit"]==HEAD and before["tested_tree"]==TREE and before["tracked_worktree_verified"] is True,before):raise RuntimeError("source identity differs")
 run("preflight",["bash","scripts/project-preflight.sh"])
 approved={path:sha(ROOT/path) for path in p["expected"]}
 check("approved-seven-exact",approved==p["expected"],approved)
 art_before=manifest(ART);write("retained-candidate-members-before.json",art_before)
 check("retained-original-zip",ZIP.stat().st_size==31113550 and sha(ZIP)=="0db5b996a2ad941be64ef4aab4dca230bb7674aab4e5a281ae5ddc0f05a2bc17",{"path":str(ZIP),"bytes":ZIP.stat().st_size,"sha256":sha(ZIP)})
 run("candidate-historical-23",PY+["-m","unittest","discover","-s","scripts/ci","-p","test_w1_v2_controls_gate.py","-v"],count=23)
 run("candidate-current-10",PY+["-m","unittest","discover","-s","scripts/ci","-p","test_w1_v2_current_stage_gate.py","-v"],count=10)
 gate=ROOT/"scripts/ci/w1_v2_controls_gate.py"
 proof=ROOT/"evidence/pon-w1-full-v2-20261105"
 binary=ART/"bin/w1-verify-v2"
 run("retained-candidate-current-cli",PY+[str(gate),str(ART/"v2-controls"),str(proof),str(binary)],expected=1,needle="runner identity differs: verifier_path")
 r=run("retained-candidate-offline-v3-api",PY+[str(OUT/"retained-candidate-offline-replay.py"),str(gate),"current",str(ART/"v2-controls"),str(proof),str(binary)])
 if r["passed"]:
  z=json.loads((OUT/r["stdout"]["path"]).read_text())
  check("retained-candidate-offline-58",z["completed_controls"]==58 and z["positive"]==1 and z["negative"]==57 and z["stage_schema"]=="TRNM-W1-STAGE-MEASUREMENT3" and z["quantum_qualification"] is False,z)
 run("current-qrom-20",PY+["scripts/ci/test_w1_current_source_observation.py","-v"],count=20)
 r=run("current-qrom-observation",PY+["scripts/w1_current_source_observation.py","--root",str(ROOT),"--expected-head",HEAD,"--profile",str(ROOT/"config/pon/w1-qrom-current-source-observation-v1.json"),"--output",str(OUT/"current-qrom-observation.json")])
 if r["passed"]:
  z=json.loads((OUT/"current-qrom-observation.json").read_text())
  refusals=z["original_guard_observations"]
  ok=z["result"]=="CURRENT_SELECTED_SOURCE_OBSERVED_HOLD" and z["observed_current_commit"]==HEAD and len(z["selected_commit_blob_ids"])==39 and z["selected_current_files_match_commit"] is True and z["original_workflows_passed"] is False and z["current_binary_executed"] is False and z["security_disposition"]=="HOLD_NO_GO" and refusals["lifetime"]["source_scope_passed"] is False and refusals["implementation"]["source_scope_passed"] is False
  check("current-qrom-39-with-original-refusals",ok,{"selected_commit_count":len(z["selected_commit_blob_ids"]),"original_guard_observations":refusals,"qualification":z["qualification"],"original_implementation_lifetime_budget":z["original_implementation_lifetime_budget"]})
 run("corpus-57",PY+["scripts/ci/test_pq_research_integration.py","-v"],count=57)
 run("corpus-checker-899",PY+["scripts/ci/check_pq_research_integration.py"])
 spec=importlib.util.spec_from_file_location("f4_current_roster",ROOT/"evidence/chain-six-full-20261108/run_pq_composition_current.py")
 current=importlib.util.module_from_spec(spec);spec.loader.exec_module(current)
 claim_before=current.claim_source_snapshot(ROOT)
 r=run("claim-55",PY+["scripts/ci/test_pq_chain_claim_guard.py","-v"],count=55)
 claim_after=current.claim_source_snapshot(ROOT)
 claim=current.validate_current_claim_run((OUT/r["stdout"]["path"]).read_text(),(OUT/r["stderr"]["path"]).read_text(),r["exit_code"],claim_before,claim_after)
 write("claim-55-strict-roster.json",claim)
 check("claim-55-original-current-roster-validator",claim["passed"],{"reported_count":claim["reported_count"],"distinct_count":claim["distinct_count"],"errors":claim["errors"]})
 run("current-composition-9",PY+["evidence/chain-six-full-20261108/test_pq_composition_current.py","-v"],count=9)
 run("ci-contract-164",PY+["scripts/ci/test_ci_contract.py","-v"],count=164)
 run("ci-source-integrity-43",PY+["scripts/ci/test_ci_source_integrity.py","-v"],count=43)
 run("repository-50",PY+["scripts/ci/test_repository.py","-v"],count=50)
 run("ci-contract-gate",PY+["scripts/ci/check_ci_contract.py"])
 run("repository-gate",PY+["scripts/ci/check_repository.py"])
 run("distributed-source-inventory",PY+["scripts/refresh_distributed_source_inventory.py","--check"])
 run("git-diff-check",["git","diff","--check"])
 cargo=["/home/qian-qi/.cargo/bin/cargo","+1.95.0"]
 run("workspace-fmt",cargo+["fmt","--manifest-path","trillionnium/Cargo.toml","--all","--","--check"])
 run("workspace-locked-offline-default",cargo+["metadata","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","--format-version","1"])
 run("workspace-locked-offline-all-features",cargo+["metadata","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","--all-features","--format-version","1"])
 run("fuzz-locked-offline",cargo+["metadata","--locked","--offline","--manifest-path","tests/fuzz/Cargo.toml","--format-version","1"])
 art_after=manifest(ART);write("retained-candidate-members-after.json",art_after)
 check("retained-candidate-members-unchanged",art_before==art_after,{"files":len(art_after),"bytes":sum(x["bytes"] for x in art_after)})
except BaseException as e:
 fatal=repr(e)
 (OUT/"driver-exception.log").write_text(traceback.format_exc())
 print(json.dumps({"driver_exception":fatal}),flush=True)
finally:
 r=run("source-after",source_cmd+["--output",str(OUT/"source-after.json")])
 if (OUT/"source-before.json").exists() and (OUT/"source-after.json").exists():
  check("full-source-before-after-identical",json.loads((OUT/"source-before.json").read_text())==json.loads((OUT/"source-after.json").read_text()))
 failed=[r["name"] for r in records if not r["passed"]]+[x["name"] for x in checks if not x["passed"]]
 complete=fatal is None and not failed
 result={"schema":"trnm-chain-six-proof-pq-f4-scoped-validation-v1","started_at":started,"ended_at":datetime.now(timezone.utc).isoformat(),"root":str(ROOT),"output":str(OUT),"commit":HEAD,"tree":TREE,"scoped_validation_completed":complete,"security_disposition":"HOLD_NO_GO","qualification_upgraded":False,"new_cryptographic_executions":0,"native_campaign_rerun":False,"hosted_ci_pass_claimed":False,"current_cli_retained_artifact_accepted":False,"retained_artifact_api_is_offline_replay":True,"expected_named_python_controls":431,"actual_named_python_controls":sum(r.get("tests",{}).get("named",0) for r in records),"fatal":fatal,"failed_stages":failed,"commands":records,"checks":checks,"selected_environment":{k:env[k] for k in ["PYTHONDONTWRITEBYTECODE","PYTHONUNBUFFERED","CARGO_BUILD_JOBS","CARGO_INCREMENTAL","RUSTUP_TOOLCHAIN","RAYON_NUM_THREADS","RUST_TEST_THREADS","CARGO_TERM_COLOR","CARGO_TARGET_DIR","TMPDIR","OPENSSL_DIR","OPENSSL_STATIC","OPENSSL_CONF","OPENSSL_MODULES","TRNM_PQ_OPENSSL","TRNM_PQ_OPENSSL_SHA256","TRNM_PQ_OPENSSL_VERSION"]}}
 write("summary.json",result)
 index=[{"path":x.name,"bytes":x.stat().st_size,"sha256":sha(x)} for x in sorted(OUT.iterdir()) if x.is_file()]
 write("SHA256SUMS.json",index)
 print(json.dumps({"terminal":"completed" if complete else "failed","summary":str(OUT/"summary.json"),"summary_sha256":sha(OUT/"summary.json"),"index_sha256":sha(OUT/"SHA256SUMS.json"),"commands":len(records),"named_controls":result["actual_named_python_controls"],"failed":failed,"fatal":fatal}),flush=True)
sys.exit(0 if complete else 1)
