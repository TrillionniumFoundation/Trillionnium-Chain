#!/usr/bin/env python3
"""Capture the selected build tools and lock identities, without reading credentials."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/525798dad3c2/Trillionnium-Chain')
RUST = Path('/workspace/scratch/270e2a9ce94f/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
WRAPPER = Path('/workspace/scratch/525798dad3c2/cargo-task.sh')
OPENSSL = Path('/workspace/scratch/270e2a9ce94f/pq-provider/trnm-pq-provider-3.5.9.7u1wjN7Q/install')


def run(command):
    p = subprocess.run(command, capture_output=True, text=True, check=True)
    return {'command': [str(x) for x in command], 'stdout': p.stdout, 'stderr': p.stderr,
            'exit_code': p.returncode}


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


result = {
    'schema': 'pon-demand-upgrade-toolchain-observation-v1',
    'commands': [run([str(RUST / 'rustc'), '--version', '--verbose']),
                 run(['bash', str(WRAPPER), '--version']),
                 run([str(RUST / 'clippy-driver'), '--version']),
                 run([str(RUST / 'rustfmt'), '--version']),
                 run([str(OPENSSL / 'bin/openssl'), 'version', '-a']),
                 run([sys.executable, '--version'])],
    'identities': [identity(WRAPPER), identity(RUST / 'rustc'),
                   identity(OPENSSL / 'lib/libcrypto.a'),
                   identity(ROOT / 'trillionnium/Cargo.lock'),
                   identity(ROOT / 'tests/fuzz/Cargo.lock')],
    'profile_overrides_added': False,
    'lockfile_changes': False,
    'cargo_build_jobs': 2,
    'independent_acceptance': False,
    'production_activation': False,
}
print(json.dumps(result, indent=2, sort_keys=True))
