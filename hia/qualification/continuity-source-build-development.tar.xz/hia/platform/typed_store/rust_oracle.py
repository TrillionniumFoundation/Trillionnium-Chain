"""Execute actual original Node calls from a source-bound native corpus bundle."""
from __future__ import annotations
import argparse
import json
import lzma
import os
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
REPOSITORY = HERE.parents[2]
STORE = "trillionnium/crates/trnm-pon-node/src/store.rs"
HOOK = "hia_typed_staging_oracle.rs"
DECLARATION = b'\n#[cfg(test)]\n#[path = "hia_typed_staging_oracle.rs"]\nmod hia_typed_staging_oracle;\n'
TEST = "store::hia_typed_staging_oracle::evaluate"
MARKER = "HIA_TYPED_STAGE_ORACLE:"
ORIGINAL_TESTS = (
    "store::bounded_active_state_tests::live_state_cell_extent_and_type_refuse_before_root_and_keep_exact_repair",
    "store::bounded_active_state_tests::live_state_reads_exact_wire_edges_without_normalizing_sql_types",
    "store::bounded_active_state_tests::live_state_count_bound_and_cancellation_return_no_partial_state",
)

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

def main():
    if not __debug__:
        raise RuntimeError("Optimized Python is not admitted by this verifier")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", type=Path, default=REPOSITORY)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--target-dir", type=Path)
    args = parser.parse_args()
    repository = args.repository.resolve(strict=True)
    sys.path.insert(0, str(repository))
    from hia.platform.build import sha256
    from hia.platform.typed_store.build import file_identity, original_manifest
    from hia.platform.transport_request.rust_oracle import command
    output = args.output.absolute()
    if output.exists() or output.is_symlink():
        raise FileExistsError("Use a fresh oracle output directory")
    output.mkdir(mode=0o700, parents=True)
    base = {"schema": "trnm.hia.original-typed-staging-differential.v1",
        "production_runtime_dependency": False, "whole_node_qualified": False,
        "sql_materialization_error_order_qualified": False,
        "full_serde_error_text_or_source_chain_parity": False}
    stages = []
    try:
        missing = [name for name in ("cargo", "rustc") if shutil.which(name) is None]
        if missing:
            write_json(output / "report.json", dict(base, status="NOT_RUN", missing_tools=missing))
            return 1
        bundle = args.bundle.resolve(strict=True)
        captured_comparison = (bundle / "native-comparison.json").read_bytes()
        comparison = json.loads(captured_comparison)
        if comparison["status"] != "PASS" or comparison["build"]["status"] != "PASS":
            raise ValueError("The supplied native comparison did not pass")
        native = comparison["cases"]
        source_inputs = comparison["build"]["source_inputs"]
        original = original_manifest(repository)
        if original != comparison["build"]["original_sources"]:
            raise ValueError("Original source differs from the source used by native qualification")
        for relative, expected in source_inputs.items():
            if file_identity(repository / relative) != expected:
                raise ValueError("Native-bound HIA/harness source differs: " + relative)
        hook = (repository / "hia/platform/typed_store/rust_reference.rs").read_bytes()
        if source_inputs["hia/platform/typed_store/rust_reference.rs"]["sha256"] != sha256(hook):
            raise ValueError("Original hook differs from the native source binding")
        corpus = output / "corpus.jsonl"
        source_corpus = bundle / "corpus.jsonl"
        if source_corpus.exists():
            with source_corpus.open("rb") as source, corpus.open("wb") as destination:
                shutil.copyfileobj(source, destination, 1 << 20)
        else:
            with lzma.open(bundle / "corpus.jsonl.xz", "rb") as source, corpus.open("wb") as destination:
                shutil.copyfileobj(source, destination, 1 << 20)
        if file_identity(corpus) != comparison["corpus"]:
            raise ValueError("The exact native corpus bytes differ")
        isolated = output / "isolated-source"
        isolated.mkdir(mode=0o700)
        for relative in original:
            destination = isolated / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(repository / relative, destination)
        store = isolated / STORE
        original_store = store.read_bytes()
        if b"mod hia_typed_staging_oracle" in original_store:
            raise ValueError("Original store already declares this oracle")
        hook_path = store.parent / HOOK
        if hook_path.exists():
            raise FileExistsError("Refusing to replace an original source")
        hook_path.write_bytes(hook)
        store.write_bytes(original_store + DECLARATION)
        def check_sources(binary=None, binary_hash=None):
            if (bundle / "native-comparison.json").read_bytes() != captured_comparison:
                raise ValueError("Native comparison changed during original execution")
            if original_manifest(repository) != original:
                raise ValueError("Original source changed during execution")
            for relative, identity in original.items():
                path = isolated / relative
                if relative == STORE:
                    if path.read_bytes() != original_store + DECLARATION:
                        raise ValueError("Original store implementation was changed")
                elif file_identity(path) != identity:
                    raise ValueError("Isolated original source was changed: " + relative)
            for relative, identity in source_inputs.items():
                if file_identity(repository / relative) != identity:
                    raise ValueError("Native-bound source changed: " + relative)
            if hook_path.read_bytes() != hook or file_identity(corpus) != comparison["corpus"]:
                raise ValueError("Original hook or exact corpus changed")
            if binary is not None and file_identity(binary)["sha256"] != binary_hash:
                raise ValueError("Original executable changed")
        check_sources()
        version, row = command(["rustc", "-Vv"], isolated, output, "rustc-version", timeout=10)
        stages.append(row)
        target = args.target_dir.resolve() if args.target_dir else output / "cargo-target"
        if target == repository or repository in target.parents or target == isolated:
            raise ValueError("Cargo target must be outside the bound source repository")
        argv = ["cargo", "test", "--locked", "--manifest-path", str(isolated / "trillionnium/Cargo.toml"),
            "-p", "trnm-pon-node", "--lib", "--no-run", "--message-format=json", "--target-dir", str(target)]
        raw, row = command(argv, isolated, output, "cargo-original-test-build", timeout=900)
        stages.append(row)
        events = [json.loads(line) for line in raw.splitlines() if line.startswith(b"{")]
        artifacts = [event for event in events if event.get("reason") == "compiler-artifact"]
        serde = [event for event in artifacts if event["target"]["name"] == "serde_json"]
        binaries = [event for event in artifacts if event["target"]["name"] == "trnm_pon_node"
            and event.get("executable") and event["profile"].get("test")]
        if len(serde) != 1 or len(binaries) != 1:
            raise ValueError("Expected one actual serde artifact and one original Node test binary")
        if (not str(serde[0]["package_id"]).endswith("serde_json@1.0.149")
                or set(serde[0]["features"]) != {"default", "std"}):
            raise ValueError("The locked original serde feature profile changed")
        binary = Path(binaries[0]["executable"])
        binary_hash = file_identity(binary)["sha256"]
        check_sources(binary, binary_hash)
        listed, row = command([str(binary), "--list"], isolated, output, "list-original-tests", timeout=20)
        stages.append(row)
        tests = {line.removesuffix(": test") for line in listed.decode().splitlines() if line.endswith(": test")}
        if not set((TEST,) + ORIGINAL_TESTS) <= tests:
            raise ValueError("Required actual original tests are not linked: " +
                repr(set((TEST,) + ORIGINAL_TESTS) - tests))
        retained = []
        for index, name in enumerate(ORIGINAL_TESTS):
            _, row = command([str(binary), "--exact", name, "--nocapture", "--test-threads=1"],
                isolated, output, "retained-state-" + str(index), timeout=240)
            stages.append(row)
            retained.append(name)
        environment = dict(os.environ, TRNM_HIA_TYPED_STAGE_CORPUS=str(corpus))
        raw, row = command([str(binary), "--exact", TEST, "--nocapture", "--test-threads=1"],
            isolated, output, "actual-apply-slot-root-corpus", env=environment, timeout=600)
        stages.append(row)
        check_sources(binary, binary_hash)
        actual = [json.loads(line.split(MARKER, 1)[1]) for line in raw.decode().splitlines() if MARKER in line]
        if [row["name"] for row in actual] != [row["name"] for row in native]:
            raise ValueError("Actual original oracle returned missing, reordered or extra cases")
        controls = []
        for expected, observed in zip(native, actual, strict=True):
            same = all(expected[key] == observed[key] for key in
                ("name", "code", "progresses", "result_hex", "root_hex"))
            same = same and observed["rollback_exact"]
            controls.append({"name": observed["name"], "status": "PASS" if same else "FAIL",
                "native": expected, "original": observed})
        write_json(output / "comparison.json", {"controls": controls})
        if any(row["status"] != "PASS" for row in controls):
            raise ValueError("Actual original apply/slot_state/root differential failed")
        report = dict(base, status="PASS", controls=len(controls), failed=0,
            retained_original_tests=retained, compiler=version.decode(), stages=stages,
            executable_sha256=binary_hash, original_sources=original,
            native_source_set_sha256=comparison["build"]["source_set_sha256"],
            native_comparison_sha256=sha256(captured_comparison),
            exact_corpus=comparison["corpus"], serde_json_artifact=serde[0],
            original_store_sha256=sha256(original_store), hook_sha256=sha256(hook),
            appended_declaration_hex=DECLARATION.hex(), source_inputs_stable=True,
            actual_private_original_apply_slot_state_and_root_called=True,
            original_production_function_bytes_preserved=True)
        write_json(output / "report.json", report)
        print(json.dumps({"status": "PASS", "controls": len(controls),
            "original_tests": len(retained), "report": str(output / "report.json")}))
        return 0
    except BaseException as error:
        write_json(output / "report.json", dict(base, status="FAIL", error=repr(error), stages=stages))
        raise

if __name__ == "__main__":
    raise SystemExit(main())

