#!/usr/bin/env python3
"""Standalone parser cost observation; never executes or replaces a Host check."""
import csv
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/0654386882cd/chain-throughput')
RUSTC = Path('/workspace/scratch/5778f0ffb5d4/toolchain/installed/bin/rustc')
SOURCE = REPO / 'trillionnium/crates/trnm-pon-node/src/host_kernel_parent.rs'
RUST_SUFFIX = r'''
use std::hint::black_box;
use std::os::raw::{c_int, c_long};
use std::time::Instant;

#[repr(C)]
struct Timespec { tv_sec: c_long, tv_nsec: c_long }
unsafe extern "C" { fn clock_gettime(clock: c_int, value: *mut Timespec) -> c_int; }
fn thread_cpu_ns() -> u64 {
    let mut value = Timespec { tv_sec: 0, tv_nsec: 0 };
    // Linux CLOCK_THREAD_CPUTIME_ID, not elapsed wall time or an assumed CPU rate.
    assert_eq!(unsafe { clock_gettime(3, &mut value) }, 0);
    assert!(value.tv_sec >= 0 && (0..1_000_000_000).contains(&value.tv_nsec));
    (value.tv_sec as u64).checked_mul(1_000_000_000).unwrap()
        .checked_add(value.tv_nsec as u64).unwrap()
}

#[inline(never)]
fn reference(input: [&str; 5], expected: Limits) -> Result<Limits> {
    let actual = validate_limits(input[0], input[1], input[2], input[3], input[4])?;
    if actual == expected { Ok(actual) } else { Err("PUBLIC_HOST_KERNEL_LIMITS_CHANGED") }
}

#[inline(never)]
fn comparison_then_original(input: [&str; 5], expected_text: [&str; 5], expected: Limits) -> Result<Limits> {
    if input == expected_text { Ok(expected) } else { reference(input, expected) }
}

fn main() {
    let canonical = ["25000 100000\n", "0\n", "2147483648\n", "0\n", "256\n"];
    let expected = validate_limits(canonical[0], canonical[1], canonical[2], canonical[3], canonical[4]).unwrap();
    // Expectations derive only from the already validated immutable Limits.
    // This experiment never reads sysfs/procfs, retains a live verdict, or caches a file.
    let text = [format!("{} {}\n", expected.cpu_quota_us, expected.cpu_period_us),
                "0\n".to_owned(), format!("{}\n", expected.memory_bytes),
                "0\n".to_owned(), format!("{}\n", expected.tasks)];
    let expected_text = text.each_ref().map(String::as_str);
    assert_eq!(canonical, expected_text);
    let cases = [
        canonical,
        ["25000\t100000", " 0 ", "+2147483648", "\n0\n", "+256"],
        ["025000 0100000\n", "0", "02147483648", "0", "0256"],
        ["25000 100000\n", "0", "\u{2003}2147483648\u{2003}", "0", "256"],
        ["10000 100000\n", "0", "2147483648", "0", "256"],
        ["25001 100000\n", "0", "2147483648", "0", "256"],
        ["25000 100000 extra", "0", "2147483648", "0", "256"],
        ["25000 100000", "1", "2147483648", "0", "256"],
        ["25000 100000", "0", "max", "0", "256"],
        ["25000 100000", "0", "2147483648", "1", "256"],
        ["25000 100000", "0", "2147483648", "0", "257"],
        ["25000 100000", "0", "18446744073709551616", "0", "256"],
        ["25000\u{2003}100000", "0", "2147483648", "0", "256"],
        ["0 100000", "0", "2147483648", "0", "256"],
        ["25000 100000", "0", "2147483648", "0", "-1"],
    ];
    for (index, input) in cases.iter().enumerate() {
        assert_eq!(comparison_then_original(black_box(*input), black_box(expected_text), black_box(expected)),
                   reference(black_box(*input), black_box(expected)), "component input {index}");
    }
    eprintln!("PARSER_COMPONENT_INPUT_EQUIVALENCE {} cases; no fresh read/EOF/UTF8/Host authority claim", cases.len());
    const ITERATIONS: u64 = 250_000;
    println!("round,slot,arm,iterations,thread_cpu_ns,wall_ns");
    for round in 0..16 {
        for (slot, candidate) in [false, true, true, false].into_iter().enumerate() {
            // Each sample has the same already verified canonical input. Every
            // timed result must equal the original parser's exact four values.
            // These common checks deliberately remain part of both measurements.
            let cpu_start = thread_cpu_ns();
            let wall_start = Instant::now();
            for _ in 0..ITERATIONS {
                let input = black_box(canonical);
                let expected = black_box(expected);
                let value = if candidate {
                    comparison_then_original(input, black_box(expected_text), expected)
                } else {
                    reference(input, expected)
                };
                assert_eq!(black_box(value), Ok(expected));
            }
            let wall_ns = wall_start.elapsed().as_nanos();
            let cpu_ns = thread_cpu_ns().checked_sub(cpu_start).unwrap();
            println!("{round},{slot},{},{ITERATIONS},{cpu_ns},{wall_ns}",
                     if candidate { "exact_compare_then_original" } else { "original_parse_and_compare" });
        }
    }
}
'''


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def captured(argv, stem):
    start = time.monotonic_ns()
    with (HERE / (stem + '.stdout')).open('wb') as stdout, (HERE / (stem + '.stderr')).open('wb') as stderr:
        proc = subprocess.run(argv, cwd=HERE, stdout=stdout, stderr=stderr, check=False)
    record = {'argv': [str(x) for x in argv], 'exit_code': proc.returncode,
              'wall_ns': time.monotonic_ns() - start,
              'stdout_sha256': sha((HERE / (stem + '.stdout')).read_bytes()),
              'stderr_sha256': sha((HERE / (stem + '.stderr')).read_bytes())}
    (HERE / (stem + '.process.json')).write_text(json.dumps(record, indent=2) + '\n')
    if proc.returncode:
        raise RuntimeError(stem + ' failed; original outputs retained')
    return record


def main():
    source = SOURCE.read_bytes()
    decoded = source.decode()
    segment = decoded[decoded.index('    const MAX_MEMORY_BYTES:'):decoded.index('    const MAX_LIMIT_BYTES:')]
    functions = '\n'.join(line[4:] if line.startswith('    ') else line for line in segment.splitlines())
    generated = '// Source-extracted scalar parser. No Node, Host observer, I/O or Cargo.\n' + \
        'type Result<T> = std::result::Result<T, &\'static str>;\n' + functions + RUST_SUFFIX
    rust = HERE / 'component.rs'
    rust.write_text(generated)
    version_record = captured([str(RUSTC), '-Vv'], 'rustc-version')
    version = (HERE / 'rustc-version.stdout').read_text()
    if '\nrelease: 1.95.0\n' not in version:
        raise RuntimeError('exact Rust 1.95.0 required')
    binary = HERE / 'component'
    compile_record = captured([str(RUSTC), '--edition=2021', str(rust), '-o', str(binary),
        '-C', 'opt-level=3', '-C', 'debuginfo=0', '-C', 'debug-assertions=off',
        '-C', 'overflow-checks=off', '-C', 'codegen-units=1'], 'compile')
    run_record = captured([str(binary)], 'run')
    with (HERE / 'run.stdout').open() as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 64:
        raise RuntimeError('64 original ABBA samples required')
    arms = {}
    for arm in ['original_parse_and_compare', 'exact_compare_then_original']:
        values = [int(row['thread_cpu_ns']) / int(row['iterations']) for row in rows if row['arm'] == arm]
        arms[arm] = {'samples': len(values), 'cpu_ns_per_call_min': min(values),
                     'cpu_ns_per_call_median': statistics.median(values),
                     'cpu_ns_per_call_max': max(values)}
    pairs = []
    for round_number in range(16):
        group = [row for row in rows if int(row['round']) == round_number]
        costs = [int(row['thread_cpu_ns']) / int(row['iterations']) for row in group]
        pairs.append((costs[0] + costs[3] - costs[1] - costs[2]) / 2)
    manifest = {'schema': 'host-five-limit-parser-component-observation-v1',
        'source_file': str(SOURCE), 'source_sha256': sha(source),
        'source_extracted_segment_sha256': sha(segment.encode()),
        'generated_source_sha256': sha(rust.read_bytes()), 'binary_sha256': sha(binary.read_bytes()),
        'rustc': version, 'commands': [version_record, compile_record, run_record],
        'comparison_order': ['original', 'comparison', 'comparison', 'original'],
        'rounds': 16, 'iterations_per_sample': 250000, 'input_equivalence_cases': 15,
        'same_original_parser_result_checked_every_iteration': True,
        'arms': arms, 'paired_cpu_saving_ns_per_call': {'min': min(pairs), 'median': statistics.median(pairs), 'max': max(pairs)},
        'scope': 'canonical-input best case; includes common black_box/result checks and wrapper overhead; Linux thread CPU; pure in-memory numeric parsing/comparison only; excludes every fresh open/read/EOF/UTF8/identity/membership/live-resource check',
        'error_type_note': 'Extracted success-path parser uses static error labels in the standalone adapter; production error construction is not benchmarked.',
        'native_host_check_executed': False, 'native_campaign_executed': False,
        'service_improvement_demonstrated': False, 'production_source_changed': False}
    (HERE / 'report.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'arms': arms, 'paired_cpu_saving_ns_per_call': manifest['paired_cpu_saving_ns_per_call'], 'report': str(HERE / 'report.json')}))


if __name__ == '__main__':
    main()
