# Independent read-only review: detached M06 admission

**INTERIM — blocked pending the two implementation changes and final committed-source review.**

Baseline: `bb2d444a3f5fe24b0077c1f01ed1d0953c2b6ff1`. Worktree: `chain-history-m06`. The initial source was uncommitted; its exact 15-file byte hashes are retained in `m06_detached_review_source_before.json`. No implementation file was edited and no build/test was executed by this reviewer. The implementer is still running and revising the candidate.

## Required corrections

1. **M06-R1: the declared two-second initial capacity wait did not include nested mutex acquisition.** `admit_shared_checked` checked its `wait_end` only after acquiring the owner and receiving Busy. A caller could therefore wait longer inside `lock_owner`, then get a slot. The original request deadline remained in force for the actual service callers; this was a new local-wait-bound error rather than deadline renewal. The implementer accepted a fix that calls original caller progress, original execution control and the original two-second end during initial locking, and checks again after acquisition. Commit reacquisition must retain the original business end rather than begin a new deadline.

2. **M06-R2: the initial 8 MiB payload refusal is an availability regression and blocks acceptance.** Supported ordinary shared Submit/History always selected detached execution, and a larger parent payload returned Capacity. The state/root layer's 65,536-key and 160/4,096-byte per-cell bounds are not an 8 MiB total-state consensus rule. Root explicitly requires selecting the unchanged held checked-M06 scheduling path above the acceleration ceiling, preserving the exact W1-checked input, original CPU operation, deadlines and all native validation. This must be tested through a real original-validated native parent and actual W1/signed transition, rather than only a synthetic payload counter. A custom preallocated test genesis, if used, must be identified as such rather than presented as history grown from the installed genesis.

3. **M06-R3: clarify the clock statement.** History deliberately passes the original page's captured clock; Submit resamples `now`. Revalidating History timestamp/target is not a claim of fresh wall-clock sampling. Forward time makes the old observation conservative. The clarification must not create a new request deadline.

## Security paths inspected

The private preparation and result have no Clone, Deserialize, public output fields or arbitrary-result constructor. The unique lease retains the original Node's Arc identity; reopen or a different owner cannot reuse an artifact. Completion checks directory, DB and owner-lock identity, backend and immutable network/parameters/genesis. The same SQLite connection's `data_version` refuses foreign writes, including SQL write-and-restore. A same-owner `total_changes` increase triggers full parent/task/material rereading, allowing legitimate competing forks without accepting a stale parent.

The `CommitFence` runs inside `BEGIN IMMEDIATE`, before the first INSERT. Both scheduling paths converge on the same original transactional body: full packet/delta readback, parent and successor State reconstruction, ancestry and active-tip checks remain before COMMIT. The private result cannot bypass those validations. A successful durable commit is not undone by a later cancellation.

The dispatcher itself creates no CPU account or reservation. Actual History retains one original operation across W1, parent binding, M06, scoped workers and SQL; failed settlement or abandoned epoch keeps the existing account unavailable and the restart marker conservative. Restricted/mining/continuous/growth/ROOT-cache owners do not acquire this ordinary capability. Continuous History's existing durable-scope denial remains.

No additional artifact-reuse, foreign-writer publication gap, new CPU account, or invalid-work acceptance defect was established in the initial reviewed source. This does not qualify the candidate until M06-R1/R2 are fixed and reviewed against a commit.

## Cancellation and old-test expectations

The old test requiring cancellation observed at the admission commit boundary to nevertheless complete activation and return success conflicts with preserving original cancellation on subsequent work. The appropriate replacement preserves the committed packet, stops additional activation with typed Cancelled, and proves exact retry recovers without new W1 or duplicate payment. A partially committed reorg must retain its actual intent; only its exact stored target may enter controlled recovery.

Two old tests assert that local wrong-CPU-domain errors do not require an owner stop, while that classification is already fatal in the baseline. Updating those assertions is legitimate only while retaining the original tests' healthy server/original-domain behavior, no foreign reservation, and no W1 execution. It must not weaken the production classification or poison the healthy original account.

## Evidence limits

Implementer logs were read, not re-executed. The first detached test attempt failed because its concurrent observer probes contended with one another; that failure remains archived. The next observed attempt passed 11 tests; History passed 8, including the real kill-cut parent. The repository checker still failed an existing work-cost/DAA lane contract. The full native regression remained in progress at review time and is not reported as passing.

The observed cost fixture used 1,024 actual signed seed transfers, 1,035 state keys and 98,565 canonical bytes. Its raw precommit timings were roughly 23.124 ms preparation, 7.067 ms execution and 107.961 ms commit. This is not a >8 MiB test, saturation campaign or final-source measurement.

One retained detached slot is not a process RSS bound: full State is materialized before its payload is measured, executor output is cloned, and SQL reconstructs full State again. SQLite's existing five-second busy timeout, root operations and fsync remain indivisible. No hard real-time, service fairness, A03 Host, WAN throughput, or continuous durable-History qualification follows.

The machine-readable companion contains explicit statuses and the source/log provenance. A final review will record the committed source and changed-file hash comparison.

## Additional recovery boundary under review: M06-R4

The signed legacy authenticated listener calls `begin_authenticated_request` before the shared dispatcher. That method starts with `ready()`, which refuses a committed unfinished reorg (`done=0`). Consequently, after controlled activation cancellation leaves a partial intent, an authenticated exact retransmission cannot reach the dispatcher's `pending_exact_activation_replay` exception in the same process. The direct retry tests do not prove recovery through this signed socket entry. Node reopen/recover can resume.

This appears to predate the current delta for controlled existing replays, while newly controlling fresh Submit activation broadens the exposure. It is a source-derived availability/recovery finding, not an executed exploit or invalid-state proof. It has been sent to root and the implementer. A safe correction must bind the original authenticated pending frame and exact stored payload/intent target; a blanket removal of `ready()` would be unacceptable. Cancellation also prevents the legacy listener from reacquiring the owner to finalize a terminal reply, so its pending journal record commonly remains for the original exact retry.

## Blocking liveness gap: M06-R5

Root correctly expanded R4 beyond a cooperative client retry. A caller can stop after a valid admitted packet and committed reorg intent, then withhold its original authenticated frame forever. An exact-frame exception does not independently drive that intent to completion; `ready()` continues refusing ordinary native operations while `done=0`. The isolated M06 candidate must remain **BLOCKED**, even if exact retry passes, until original-owner online reconciliation or an equivalent safe transaction design is implemented and validated.

The call graph is narrower than a blanket assertion that only restart can help. `Node::open` invokes `recover`, and a configured pinned peer poller can conditionally call `activate_observed` when remote input selects a known/completed target. That activation can resume an existing intent. However, the poller depends on configuration and remote replies; its call uses the uncontrolled wrapper outside scalar metering. It is not a guaranteed bounded local recovery executor.

`RecoveryIngress` in `trnm-transport/src/proof_admission.rs` reserves one concurrent recovery slot separately from three public slots, with digest deduplication and cancellation generation. It grants no CPU allowance, deadline, durable operation identity or chain authority. Legacy `serve_inner` currently discards the capability.

V3 already has the same-Node scalar domain, durable epoch and fixed service lifetime. A candidate design could use one of its existing proof workers to attempt one owner-selected pending-intent step before dequeue. Running only when the queue is empty would allow public saturation to starve recovery; adding a worker or running heavy recovery in the reactor/read worker would change existing resource boundaries. The operation must use the same account and Host, settle its real CPU, preserve the original service end, and never bind itself to or renew an expired guest request. It needs a bounded-step API with the original full validation; the current resume function loops over all remaining steps. This design is not implemented or qualified by this review.

Legacy authenticated service may have no registered scalar domain, and its capacity token cannot substitute for one. Continuous startup `parent-reconcile` explicitly requires no pending intent and no best-tip advance. Continuous activation needs an active `activate`/`receiver-activate` claim for the exact packet and a durable operation/allowance. A generic `cpu.begin()` loop would bypass those authority boundaries. There is no existing universal reconciler that can safely be switched on for all these modes.

### Updated evidence state

The full native first attempt has now ended with SIGTERM (`exit_code=-15`, `timed_out=false`, 341.768 seconds); it is a stopped attempt containing the previously observed failures, not a successful regression. Uncommitted fixes for the two-second wait and private over-ceiling scheduling branch have been read and appear to preserve the intended boundaries. Their final-source execution evidence is still pending. No approval to integrate this candidate is given.
