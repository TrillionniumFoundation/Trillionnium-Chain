import datetime
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import time

root=Path('/workspace/scratch/62902f6722b7/chain-work')
out=Path('/workspace/scratch/62902f6722b7/composed-source-validation')
def source():
    def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
    return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),
            'status':git('status','--porcelain'),
            'lock_sha256':hashlib.sha256((root/'trillionnium/Cargo.lock').read_bytes()).hexdigest()}
before=source()
assert before['head']=='361825dd1f924770562705d7a68c78170f0375c3' and not before['status']
owned_paths=[out/name for name in ('strict-clippy-attempt.json','strict-clippy-preflight.log','strict-clippy.log','strict-clippy-receipt.json')]
if any(p.exists() for p in owned_paths):
    raise SystemExit('Refusing to overwrite an existing attempt; retain it and use a new attempt directory for any retry.')
with (out/'strict-clippy-attempt.json').open('x') as stream:
    json.dump({'schema':'trnm-composed-strict-clippy-attempt-v1','source_before':before,
               'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},stream,indent=2)
    stream.write('\n')
preflight_started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'strict-clippy-preflight.log').open('xb') as log:
    preflight=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=False)
if preflight.returncode:
    raw=(out/'strict-clippy-preflight.log').read_bytes()
    receipt={'schema':'trnm-composed-strict-clippy-v1','phase':'preflight_failed','clippy_executed':False,
             'command':['bash','scripts/project-preflight.sh'],'source_before':before,'source_after':source(),
             'started_utc':preflight_started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'exit_code':preflight.returncode,'log_bytes':len(raw),'log_sha256':hashlib.sha256(raw).hexdigest()}
    with (out/'strict-clippy-receipt.json').open('x') as stream:
        json.dump(receipt,stream,indent=2);stream.write('\n')
    print(json.dumps(receipt,indent=2),flush=True)
    raise SystemExit(preflight.returncode)
command=['cargo','clippy','--locked','--offline','--manifest-path','trillionnium/Cargo.toml',
         '--workspace','--all-targets','--all-features','--','-D','warnings']
started=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
usage0=resource.getrusage(resource.RUSAGE_CHILDREN)
with (out/'strict-clippy.log').open('xb') as log:
    result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=False)
usage1=resource.getrusage(resource.RUSAGE_CHILDREN)
ended=datetime.datetime.now(datetime.timezone.utc).isoformat()
raw=(out/'strict-clippy.log').read_bytes()
after=source()
receipt={'schema':'trnm-composed-strict-clippy-v1','command':command,'source_before':before,'source_after':after,
         'phase':'clippy_complete','clippy_executed':True,'preflight_exit_code':preflight.returncode,
         'started_utc':started,'ended_utc':ended,'exit_code':result.returncode,'wall_seconds':time.monotonic()-tick,
         'waited_children_cpu_seconds':usage1.ru_utime+usage1.ru_stime-usage0.ru_utime-usage0.ru_stime,
         'log_bytes':len(raw),'log_sha256':hashlib.sha256(raw).hexdigest(),
         'scope':'Whole-workspace all-target all-feature lint/build check, not unit-test execution or service qualification.'}
with (out/'strict-clippy-receipt.json').open('x') as stream:
    json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps(receipt,indent=2),flush=True)
