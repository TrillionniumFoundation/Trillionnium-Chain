import ast,copy,difflib,hashlib,json,pathlib,re,subprocess,zipfile
R=pathlib.Path("/home/qian-qi/work/chain-cell-storage-convergence-ci-failure-audit66b-20261109")
D=R/"fresh-head-readable"; D.mkdir(exist_ok=False)
Z=R/"baseline-and-fresh-artifact/head-fresh-artifact.stdout"
wanted=["fresh-service/fresh.log","fresh-service/original.log","fresh-service/manifest.json","fresh-service-host/child-result.json","fresh-service-host/systemd-run.log","fresh-service/fresh/report.json","fresh-service/original/report.json"]
members=[]
with zipfile.ZipFile(Z) as z:
 for name in wanted:
  info=z.getinfo(name);assert info.file_size<=16*1024*1024
  b=z.read(name);out=D/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
  m={"path":name,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()};members.append(m)
  if name.endswith(".log") or name.endswith("child-result.json"):print(json.dumps({"artifact_member":m,"text":b.decode()}))
  else:
   o=json.loads(b)
   print(json.dumps({"artifact_member":m,"keys":list(o),"top_scalars":{k:v for k,v in o.items() if not isinstance(v,(list,dict))}}))
   if name.endswith("manifest.json"):print(json.dumps({"manifest":o}))
   else:
    findings=[]
    def scan(v,path=""):
     if len(findings)>=60:return
     if isinstance(v,dict):
      for k,w in v.items():
       p=path+"/"+str(k)
       if any(n in k.lower() for n in ["failure","error","reason","violation"]) and w not in (None,False,"",[],{}):
        findings.append({"path":p,"value":w if not isinstance(w,(list,dict)) else str(w)[:2000]})
       if isinstance(w,(dict,list)):scan(w,p)
     elif isinstance(v,list):
      for i,w in enumerate(v):
       if isinstance(w,(dict,list)):scan(w,path+"/"+str(i))
    scan(o)
    print(json.dumps({"report_findings":name,"items":findings}))
out=D/"members.json";out.write_text(json.dumps(members,indent=2)+"\n")
print(json.dumps({"readable_manifest":str(out),"sha256":hashlib.sha256(out.read_bytes()).hexdigest()}))
repo="/home/qian-qi/work/chain-cell-storage-convergence-f2568-20261109";rev="66b7064be597039ce871b5b12ad5568850a2dd46"
def show(path):
 p=subprocess.run(["git","-C",repo,"show","--no-textconv",rev+":"+path],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=False)
 assert p.returncode==0,(path,p.stderr.decode());return p.stdout
P=pathlib.Path("/home/qian-qi/work/chain-cell-storage-convergence-current-source19-preparation");P.mkdir(exist_ok=False)
files=["scripts/w1_lifetime_ledger.py","config/pon/pq128-lifetime-budget-v1.json","config/pon/pq128-source-lock-v1.json"]
old={path:show(path) for path in files};new=dict(old)
ledgerpath=files[0];budpath=files[1];lockpath=files[2]
ledger=old[ledgerpath].decode();pins=None
for node in ast.parse(ledger).body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="SOURCE_PINS" for t in node.targets):pins=ast.literal_eval(node.value)
assert pins and len(pins)==20
current={path:show(path) for path in pins}
lmap=[]
for path,expected in pins.items():
 actual=hashlib.sha256(current[path]).hexdigest()
 lmap.append({"path":path,"before_pin":expected,"after_pin":actual,"source_commit":rev,"bytes":len(current[path]),"changed":actual!=expected})
 if actual!=expected:
  assert ledger.count(expected)==1;ledger=ledger.replace(expected,actual)
assert sum(row["changed"] for row in lmap)==2
new[ledgerpath]=ledger.encode()
budget=json.loads(old[budpath]);lock=json.loads(old[lockpath]);assert lock["source_revision"]==budget["experiment"]["source_revision"]=="0f0592ace4b08a1d39e1ffad31beee76ddc4fd66"
declared={p for event in budget["events"] for p in event["source_paths"]};assert declared==set(lock["files"]) and len(declared)==15
pmap=[]
locktext=old[lockpath].decode()
for path,expected in lock["files"].items():
 b=current.get(path)
 if b is None:b=show(path);current[path]=b
 actual=hashlib.sha256(b).hexdigest()
 pmap.append({"path":path,"before_pin":expected,"after_pin":actual,"source_commit":rev,"bytes":len(b),"changed":actual!=expected})
 if actual!=expected:
  assert locktext.count(expected)==1;locktext=locktext.replace(expected,actual)
assert sum(row["changed"] for row in pmap)==1
oldrev=lock["source_revision"];assert locktext.count(oldrev)==1
new[lockpath]=locktext.replace(oldrev,rev).encode()
bt=old[budpath].decode();assert bt.count(oldrev)==1;new[budpath]=bt.replace(oldrev,rev).encode()
afterbudget=json.loads(new[budpath]);cmp=copy.deepcopy(afterbudget);cmp["experiment"]["source_revision"]=oldrev;assert cmp==budget
afterlock=json.loads(new[lockpath]);assert set(afterlock)==set(lock) and afterlock["schema"]==lock["schema"] and set(afterlock["files"])==declared
for path,b in new.items():
 for kind,data in [("before",old[path]),("after",b)]:
  out=P/kind/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
patch="".join("".join(difflib.unified_diff(old[p].decode().splitlines(keepends=True),new[p].decode().splitlines(keepends=True),fromfile="a/"+p,tofile="b/"+p)) for p in files)
(P/"current-source19.patch").write_text(patch)
identity={"schema":"trnm-storage-current-source19-preparation-v1","source_commit":rev,"canonical_mutated":False,"native_executed":False,"historical_qrom_contract_unchanged":{"path":"config/pon/w1-qrom-implementation-v1.json","sha256":hashlib.sha256(show("config/pon/w1-qrom-implementation-v1.json")).hexdigest(),"reason":"Fixed historical selected-source mapping pins main.rs 9233 bytes from cb114b13; base and head actual source are identical11172 bytes. Exact base CI independently fails same bound. No bound, hash or historical receipt replaced."},"files":{p:{"before_bytes":len(old[p]),"before_sha256":hashlib.sha256(old[p]).hexdigest(),"after_bytes":len(new[p]),"after_sha256":hashlib.sha256(new[p]).hexdigest()} for p in files},"ledger_mapping":lmap,"pq_mapping":pmap,"budget_only_declared_revision_changed":cmp==budget,"qualification_and_unknown_terms_unchanged":True,"protocol_and_arithmetic_limits_unchanged":True,"patch_sha256":hashlib.sha256(patch.encode()).hexdigest(),"patch_bytes":len(patch.encode())}
(P/"source-identity.json").write_text(json.dumps(identity,indent=2)+"\n")
print(json.dumps({"patch_preparation":str(P),"identity_sha256":hashlib.sha256((P/"source-identity.json").read_bytes()).hexdigest(),"patch_bytes":len(patch.encode()),"patch_sha256":identity["patch_sha256"],"files":identity["files"]}))
for path in ["scripts/ci/test_pq_lifetime_budget.py","scripts/ci/test_w1_lifetime_ledger.py"]:
 b=show(path);out=P/"control-source"/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 ls=b.decode().splitlines();matches=[]
 for i,s in enumerate(ls):
  if any(n in s for n in ["subprocess","Popen","os.system","cargo","rustc","ROOT =","read_bytes","read_text","source_revision","sys.path","importlib"]):matches.append({"line":i+1,"text":s})
 print(json.dumps({"control_source":path,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),"execution_relevant":matches}))
doc=(R/"baseline-and-fresh-artifact/PQ128_LIFETIME_BUDGET_V1.md").read_text().splitlines()
print(json.dumps({"doc_scope":"217-273","text":"\n".join(f"{i+1}: {doc[i]}" for i in range(216,273))}))
