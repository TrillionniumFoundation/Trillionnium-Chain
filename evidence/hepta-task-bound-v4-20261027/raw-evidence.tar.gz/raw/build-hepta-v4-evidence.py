#!/usr/bin/env python3
"""Package terminal observations; never turn them into model admission."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/3d4ec372c488')
REPO = ROOT / 'hepta-chain'
SOURCE = 'c86cabce381ff24f0e002693eb46d9b7a49e1690'
BASE = '9035171271e9f437b7224b53532f41a2b2894be7'
OUT = REPO / 'evidence/hepta-task-bound-v4-20261027'


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + '\n').encode()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    run = ROOT / 'hepta-v4-run-002'
    cell = ROOT / 'hepta-v4-cell-002'
    result = read(run / 'result.json')
    transfer = read(cell / 'result.json')
    assert result['outcome'] == 'completed'
    assert result['all_required_controls_executed'] is True
    assert result['source_unchanged'] is True and result['parent_unchanged'] is True
    assert len(result['phases']) == 18
    assert transfer['outcome'] == 'completed' and transfer['source_unchanged'] is True
    assert transfer['provider_terminal_exit_code'] == 0
    assert read(run / 'freeze.json')['source_commit'] == SOURCE
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == SOURCE
    for phase in result['phases'] + [transfer['actual_readback_supervisor']]:
        assert phase['outcome'] == 'success' and phase['exit_code'] == 0
        assert phase['waited_child_reaped'] is True and phase['owned_child_reap_resolved'] is True
        assert phase['owned_child_echild_observed'] is False
    assert not any(result[k] for k in ('ordinary_installation', 'source_parent_is_admitted_current',
                                      'independent_evaluation', 'product_qualification', 'reward_eligible'))
    assert not any(transfer[k] for k in ('ordinary_installation', 'selected', 'product_qualification',
                                        'public_reward', 'independent_nodes', 'source_backbone_transferred'))
    OUT.mkdir(parents=True, exist_ok=False)
    files = {}
    excluded = []

    def add(path, name):
        assert path.is_file() and not path.is_symlink()
        item = dict(path=name, bytes=path.stat().st_size, sha256=digest(path))
        contains_model_bytes = path.suffix == '.safetensors' or '.sqlite' in path.name
        if path.stat().st_size > 20 * 1024**2 or contains_model_bytes:
            item.update(local_path=str(path), reason='Model tensor payload or payload-bearing cache retained locally; not exported after automatic review rejected checkpoint upload')
            excluded.append(item)
        else:
            assert name not in files
            files[name] = (path, item)

    for folder in ('hepta-v4-run-001', 'hepta-v4-run-002', 'hepta-v4-cell-001', 'hepta-v4-cell-002'):
        for path in sorted((ROOT / folder).rglob('*')):
            if path.is_file():
                add(path, 'raw/' + folder + '/' + str(path.relative_to(ROOT / folder)))
    historical = Path('/workspace/scratch/301262829a43/pon-hepta-impl/bf325-terminal-readback')
    for path in sorted(historical.rglob('*')):
        if path.is_file():
            add(path, 'historical-prior-gate/bf325/' + str(path.relative_to(historical)))
    add(Path('/workspace/scratch/301262829a43/pon-hepta-impl/hepta-answer-eos-caller-v3-5cec-readme-before-exit-scope.md'),
        'historical-prior-gate/caller-v3-gate-description.md')
    standalone = ('hepta-v4-run-001.log', 'hepta-v4-run-002.log',
        'hepta-v4-cell-001.log', 'hepta-v4-cell-001-attempt02.log', 'hepta-v4-cell-002.log',
        'hepta-v4-all-controls.log', 'hepta-observer-v1-test.log', 'hepta-observer-v1-torch.log',
        'hepta-v4-ci-controls-02.log', 'hepta-v4-ci-check.log', 'hepta-v4-controls-01.log',
        'hepta-v4-source-commit.json', 'hepta-v4-source-commit-02.json',
        'hepta-v5-parent-compatibility-refusal.json', 'hepta-v4-known-untracked-cleanup.json',
        'hepta-v4-cell-readback.py', 'build-hepta-v4-evidence.py',
        'hepta-v4-exact-source-tests.log', 'hepta-v4-exact-source-tests.json',
        'hepta-v4-full-tune-library-save-attempt01-failure.json',
        'hepta-v4-full-tune-library-save-attempt02-blocked.json',
        'hepta-v4-redundant-copy-cleanup.json')
    for name in standalone:
        add(ROOT / name, 'raw/' + name)
    modified = subprocess.check_output(['git', 'diff', '--name-only', BASE, SOURCE], cwd=REPO, text=True).splitlines()
    for name in modified:
        add(REPO / name, 'source/' + name)
    parent_dir = Path(read(run / 'freeze.json')['parent']['directory'])
    for name in ('parent-material.json', 'target-contract.json', 'wrapped-adapter.json', 'artifact.safetensors'):
        add(parent_dir / name, 'inputs/actual-source-parent/' + name)
    patches = subprocess.check_output(['git', 'diff', '--binary', BASE, SOURCE], cwd=REPO)
    (OUT / 'source.patch').write_bytes(patches)
    add(OUT / 'source.patch', 'source/source.patch')
    manifest = dict(schema='hepta-task-bound-v4-archive-manifest-v1', source_commit=SOURCE,
        source_base=BASE, included=[item for _, item in sorted(files.values(), key=lambda p: p[1]['path'])],
        excluded=excluded,
        historical_gate=dict(source_commit='bf32538ccb9b52e3e0a8e089983eea7e3940b6a5',
            run_id='40517226441', archive_id=12757793398, rerun_in_this_experiment=False,
            original_full_log_included=False, selected_raw_records_and_failure_extract_included=True),
        external_inputs=[dict(path='/workspace/scratch/301262829a43/pon-hepta-impl/materials-legacy-i09/model.safetensors',
            bytes=269060552, sha256='5af571cbf074e6d21a03528d2330792e532ca608f24ac70a143f6b369968ab8c',
            reason='Preexisting public source backbone reused; not copied or transferred by the candidate-only Cell experiment'),
            dict(path='/workspace/scratch/301262829a43/pon-work-impl/artifacts/trnm-cell-provider-fixed-57fbdfe',
            bytes=3167448, sha256=transfer['binary_sha256'], reason='Existing fixed provider binary; not rebuilt in this experiment')],
        authority=dict(ordinary_installation=False, product_qualification=False, independent_nodes=False,
                       independent_evaluation=False, public_reward=False))
    manifest_bytes = canonical(manifest)
    (OUT / 'manifest.json').write_bytes(manifest_bytes)
    archive = OUT / 'raw-evidence.tar.gz'
    with tarfile.open(archive, 'w:gz', compresslevel=6) as tf:
        for name, (path, item) in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size = item['bytes']; info.mode = 0o644; info.mtime = 0
            with path.open('rb') as stream:
                tf.addfile(info, stream)
        info = tarfile.TarInfo('manifest.json'); info.size = len(manifest_bytes); info.mode = 0o644
        tf.addfile(info, io.BytesIO(manifest_bytes))
    with tarfile.open(archive) as tf:
        assert sorted(tf.getnames()) == sorted(list(files) + ['manifest.json'])
        for name, (_, item) in files.items():
            raw = tf.extractfile(name).read()
            assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
        assert tf.extractfile('manifest.json').read() == manifest_bytes
    costs = [{k: p.get(k) for k in ('name', 'outcome', 'exit_code', 'observed_wall_ns', 'child_cpu_ns',
        'observer_cpu_ns', 'sampled_peak_rss_bytes', 'waited_child_peak_rss_bytes', 'cleanup_method',
        'waited_child_reaped', 'owned_child_reap_resolved', 'owned_child_echild_observed', 'stop_reason')}
        for p in result['phases']]
    summary = dict(schema='hepta-task-bound-v4-evidence-summary-v1', source_commit=SOURCE,
        source_tree=subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True).strip(),
        outcome=result['outcome'], scores=result['scores'], decision=result['decision'],
        gain_vs_strongest_control=result['gain_vs_strongest_control'],
        gain_vs_actual_source_parent=result['gain_vs_actual_source_parent'], training=result['training'],
        phases=costs, cell_transfer=transfer['transfer'], cell_readback={k: transfer[k] for k in
            ('actual_loaded_candidate', 'next_task_receipt_sha256', 'next_task_response',
             'provider_terminal_exit_code', 'actual_readback_supervisor')},
        test_run=read(ROOT / 'hepta-v4-exact-source-tests.json'),
        archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=digest(archive),
            manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(), verified_members=len(files)+1,
            excluded_model_or_cache_count=len(excluded)),
        limits=dict(source_parent_is_admitted_current=False, original_hepta_full_lane_passed=False,
            ordinary_installation=False, independent_nodes=False, independent_evaluation=False,
            product_qualification=False, public_reward=False,
            all_costs_measured_on_shared_host=True, source_parent_inference_uses_eight_separate_processes=True,
            wait4_rss_is_single_process_high_water_not_simultaneous_tree=True,
            flops_are_supported_profiler_operator_counts_not_total_work=True))
    (OUT / 'summary.json').write_bytes(canonical(summary))
    print(json.dumps(dict(output=str(OUT), archive=summary['archive'], scores=result['scores'],
                         decision=result['decision'])))


if __name__ == '__main__':
    main()
