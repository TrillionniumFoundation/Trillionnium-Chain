#!/usr/bin/env bash
set -euo pipefail
source /workspace/scratch/62902f6722b7/env-next.sh
set -a
source /workspace/scratch/62902f6722b7/pq-next/exports.env
set +a
export CARGO_HOME=/workspace/scratch/c9b48df754d6/cargo-fuzz
export CARGO_TARGET_DIR=/workspace/scratch/c9b48df754d6/target-fuzz-metadata
export CARGO_NET_OFFLINE=true
cargo metadata --locked --offline --all-features --format-version 1 --manifest-path tests/fuzz/Cargo.toml
