#!/usr/bin/env python3
"""Independent read-only verification of six evidence archives and their indexes."""
from __future__ import annotations
import hashlib,json,os,re,stat,sys,tarfile,time,traceback
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
STAGE=Path("/workspace/scratch/pon-joint-58fd59-build/evidence-staging")
OUT=Path("/workspace/scratch/pon-joint-58fd59-build/preparation-independent-archive-verification")
ORIGINAL_NATIVE=Path("/workspace/scratch/pon-joint-58fd59-build/remote-native-117/extracted/manifest.json")
NATIVE_MANIFEST_SHA="3586aec5ad2a76ee8b40ea5a4b77ca9b735e873a25658d21cd4f7faf9831c357"
assert not OUT.resolve().is_relative_to(STAGE.resolve())
def dump(path,obj):
    with path.open("x",encoding="utf-8") as f:json.dump(obj,f,indent=2,sort_keys=True);f.write("\n")
def identity(s):
    return {"device":s.st_dev,"inode":s.st_ino,"bytes":s.st_size,"mode":stat.S_IMODE(s.st_mode),
        "mtime_ns":s.st_mtime_ns,"ctime_ns":s.st_ctime_ns}
def open_readonly(path):
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    s=os.fstat(fd)
    if not stat.S_ISREG(s.st_mode):os.close(fd);raise ValueError("not a regular input file: "+str(path))
    return os.fdopen(fd,"rb"),identity(s)
def raw_identity(path,keep=False):
    f,before=open_readonly(path)
    with f:
        raw=f.read() if keep else None
        if keep:digest=hashlib.sha256(raw).hexdigest()
        else:digest=hashlib.file_digest(f,"sha256").hexdigest()
        after=identity(os.fstat(f.fileno()))
    if before!=after:raise ValueError("input changed while reading: "+str(path))
    return {"path":str(path),"sha256":digest,**before},raw
def unique_object(pairs):
    result={}
    for k,v in pairs:
        if k in result:raise ValueError("duplicate JSON key: "+k)
        result[k]=v
    return result
def parse(raw):return json.loads(raw.decode("utf-8"),object_pairs_hook=unique_object)
def safe_name(name):
    if not isinstance(name,str) or not name or "\0" in name or "\\" in name:
        return False
    p=PurePosixPath(name)
    return (not p.is_absolute() and str(p)==name and not re.match(r"^[A-Za-z]:",name)
        and all(part not in ("",".","..") for part in name.split("/"))
        and not any(ord(c)<32 or ord(c)==127 for c in name))
def entry_map(doc):
    rows=doc["files"] if isinstance(doc,dict) else doc
    if not isinstance(rows,list):raise ValueError("file index is not an array")
    result={}
    for row in rows:
        name=row["path"]
        if not safe_name(name) or name in result:raise ValueError("unsafe/duplicate indexed path: "+str(name))
        size=row.get("bytes",row.get("size"))
        if not isinstance(size,int) or isinstance(size,bool) or size<0:raise ValueError("invalid indexed file size")
        if "bytes" in row and "size" in row and row["bytes"]!=row["size"]:raise ValueError("conflicting indexed sizes")
        digest=row["sha256"]
        if not isinstance(digest,str) or not re.fullmatch("[0-9a-f]{64}",digest):raise ValueError("invalid indexed SHA256")
        result[name]={"bytes":size,"sha256":digest}
    return result
started=datetime.now(timezone.utc).isoformat()
metadata_paths=sorted(STAGE.glob("*-archive.json"))
if len(metadata_paths)!=6:raise RuntimeError("expected exactly six archive sidecars")
archive_names={p.name for p in STAGE.iterdir() if p.name.endswith((".tar.gz",".tar.xz"))}
if len(archive_names)!=6:raise RuntimeError("expected exactly six archive files")
results=[]
tracked_inputs={}
for metadata_path in metadata_paths:
    label=metadata_path.name.removesuffix("-archive.json")
    result={"archive_label":label,"passed":False,"errors":[]}
    try:
        meta_id,meta_raw=raw_identity(metadata_path,True);tracked_inputs[str(metadata_path)]=meta_id
        metadata=parse(meta_raw)
        index_path=STAGE/(label+"-files.json")
        index_id,index_raw=raw_identity(index_path,True);tracked_inputs[str(index_path)]=index_id
        index=parse(index_raw);expected=entry_map(index)
        name=metadata["file"]
        if not safe_name(name) or "/" in name or name not in archive_names:raise ValueError("unexpected archive file reference")
        archive=STAGE/name
        archive_id,_=raw_identity(archive);tracked_inputs[str(archive)]=archive_id
        result.update(archive=name,archive_identity=archive_id,archive_sidecar=meta_id,file_index=index_id,
            expected_file_count=metadata["file_count"],indexed_file_count=len(expected))
        if archive_id["bytes"]!=metadata["bytes"] or archive_id["sha256"]!=metadata["sha256"]:
            raise ValueError("outer archive size/SHA256 differs from sidecar")
        if not 0<metadata["file_count"]<=10000:raise ValueError("unreasonable declared member count")
        observed={};manifest_raw=None;nonregular=[];unsafe=[];duplicates=[]
        f,before=open_readonly(archive)
        with f,tarfile.open(fileobj=f,mode="r|*",ignore_zeros=True) as tf:
            member_count=0
            for member in tf:
                member_count+=1
                if member_count>10000:raise ValueError("archive member ceiling exceeded")
                if not safe_name(member.name):unsafe.append(member.name);continue
                if member.name in observed:duplicates.append(member.name);continue
                if not member.isfile() or member.issym() or member.islnk() or member.sparse:
                    nonregular.append({"path":member.name,"type":repr(member.type)});continue
                if member.size<0 or member.size>128*1024*1024:raise ValueError("member size ceiling exceeded")
                h=hashlib.sha256();count=0;manifest_parts=[] if member.name=="manifest.json" else None
                with tf.extractfile(member) as src:
                    while True:
                        chunk=src.read(1024*1024)
                        if not chunk:break
                        h.update(chunk);count+=len(chunk)
                        if manifest_parts is not None:
                            if count>2*1024*1024:raise ValueError("native manifest unexpectedly large")
                            manifest_parts.append(chunk)
                if count!=member.size:raise ValueError("member payload length mismatch: "+member.name)
                observed[member.name]={"bytes":count,"sha256":h.hexdigest()}
                if manifest_parts is not None:manifest_raw=b"".join(manifest_parts)
                if sum(v["bytes"] for v in observed.values())>256*1024*1024:
                    raise ValueError("total member payload ceiling exceeded")
            after=identity(os.fstat(f.fileno()))
        if before!=after:raise ValueError("archive changed while streaming")
        if nonregular or unsafe or duplicates:
            raise ValueError("unsafe archive members: "+json.dumps({"nonregular":nonregular,"unsafe":unsafe,"duplicates":duplicates}))
        ancestors={str(PurePosixPath(n).parent) for n in observed}
        for n in observed:
            for ancestor in PurePosixPath(n).parents:
                if str(ancestor)!="." and str(ancestor) in observed:
                    raise ValueError("file/ancestor collision: "+n)
        native=index.get("manifest_excludes_itself") is True
        actual_names=set(observed)
        expected_names=set(expected)|({"manifest.json"} if native else set())
        if actual_names!=expected_names:
            raise ValueError("member set differs: "+json.dumps({"missing":sorted(expected_names-actual_names),"extra":sorted(actual_names-expected_names)}))
        mismatches=[name for name,row in expected.items() if observed[name]!=row]
        if mismatches:raise ValueError("member size/SHA256 mismatch: "+json.dumps(mismatches))
        if len(observed)!=metadata["file_count"]:raise ValueError("member count differs from archive sidecar")
        bytes_total=sum(row["bytes"] for row in observed.values())
        listed_bytes=sum(row["bytes"] for row in expected.values())
        native_check=None
        if native:
            if label!="117-ai395-native" or manifest_raw is None:raise ValueError("unexpected native manifest scope")
            inside=parse(manifest_raw)
            if inside!=index:raise ValueError("native internal manifest differs from external file index")
            original_id,original_raw=raw_identity(ORIGINAL_NATIVE,True);tracked_inputs[str(ORIGINAL_NATIVE)]=original_id
            if parse(original_raw)!=inside or original_raw!=manifest_raw:
                raise ValueError("native manifest differs from original downloaded manifest")
            if hashlib.sha256(manifest_raw).hexdigest()!=metadata["manifest_sha256"] or metadata["manifest_sha256"]!=NATIVE_MANIFEST_SHA:
                raise ValueError("native manifest hash differs")
            if metadata["manifest_listed_files"]!=len(expected) or metadata["uncompressed_bytes_excluding_manifest"]!=listed_bytes:
                raise ValueError("native listed count/bytes differ")
            native_check={"internal_manifest_sha256":hashlib.sha256(manifest_raw).hexdigest(),
                "original_manifest":original_id,"original_internal_bytes_equal":True,
                "external_index_internal_semantics_equal":True,"external_index_internal_bytes_equal":index_raw==manifest_raw,
                "listed_files":len(expected),"manifest_excluded_from_own_list":True}
        elif metadata["uncompressed_bytes"]!=bytes_total:
            raise ValueError("total uncompressed bytes differ")
        observed_rows=[{"path":n,**observed[n]} for n in sorted(observed)]
        observed_path=OUT/(label+"-observed-files.json")
        dump(observed_path,{"schema":"independent-archive-member-hashes-v1","archive_sha256":archive_id["sha256"],"files":observed_rows})
        observation_id,_=raw_identity(observed_path)
        final_id,_=raw_identity(archive)
        if final_id!=archive_id:raise ValueError("archive changed before final checksum")
        result.update(passed=True,actual_file_count=len(observed),listed_payload_bytes=listed_bytes,
            total_payload_bytes=bytes_total,outer_size_and_sha256_match=True,all_member_sizes_and_sha256_match=True,
            complete_member_set_matches=True,canonical_relative_paths=True,regular_files_only=True,
            duplicate_paths=0,file_ancestor_collisions=0,archive_stable=True,
            observed_member_inventory=observation_id,native_manifest=native_check)
    except Exception as exc:
        result["errors"].append({"type":type(exc).__name__,"message":str(exc)})
    results.append(result)
input_rechecks=[]
for pathname,before in sorted(tracked_inputs.items()):
    try:
        after,_=raw_identity(Path(pathname))
        input_rechecks.append({"path":pathname,"unchanged":before==after,"sha256":after["sha256"],"bytes":after["bytes"]})
    except Exception as exc:
        input_rechecks.append({"path":pathname,"unchanged":False,"error":repr(exc)})
verified_names={r.get("archive") for r in results}
passed=(len(results)==6 and all(r["passed"] for r in results) and verified_names==archive_names
    and all(r["unchanged"] for r in input_rechecks))
report={"schema":"pon-joint-independent-archive-verification-v1","passed":passed,
    "started_utc":started,"finished_utc":datetime.now(timezone.utc).isoformat(),
    "stage":str(STAGE),"output":str(OUT),"verifier_sha256":raw_identity(Path(__file__))[0]["sha256"],
    "python_version":sys.version,"archive_count":len(results),
    "verified_regular_files":sum(r.get("actual_file_count",0) for r in results),
    "verified_archive_bytes":sum(r.get("archive_identity",{}).get("bytes",0) for r in results),
    "verified_payload_bytes":sum(r.get("total_payload_bytes",0) for r in results),
    "results":results,"input_stability_rechecks":input_rechecks,
    "archive_contents_executed":False,"archives_extracted":False,"test_results_reexecuted":False,
    "stage_or_source_written":False,"scope":"archive/member integrity and safe path validation only"}
dump(OUT/"verification.json",report)
print(json.dumps({"passed":passed,"report":str(OUT/"verification.json"),"archives":len(results),
    "files":report["verified_regular_files"],"archive_bytes":report["verified_archive_bytes"],
    "payload_bytes":report["verified_payload_bytes"],
    "results":[{"archive":r.get("archive",r["archive_label"]),"passed":r["passed"],
    "files":r.get("actual_file_count"),"payload_bytes":r.get("total_payload_bytes"),"errors":r["errors"]} for r in results]},sort_keys=True))
raise SystemExit(0 if passed else 1)

