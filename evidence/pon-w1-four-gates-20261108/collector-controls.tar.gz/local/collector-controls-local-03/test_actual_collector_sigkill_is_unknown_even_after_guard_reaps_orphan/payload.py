import os,time,signal,json
from pathlib import Path
signal.signal(signal.SIGTERM,signal.SIG_IGN)
raw=Path('/proc/self/stat').read_text();tail=raw[raw.rfind(')')+2:].split()
Path('/workspace/scratch/ec265b67753e/collector-controls-local-03/test_actual_collector_sigkill_is_unknown_even_after_guard_reaps_orphan/payload-identity.json').write_text(json.dumps({'pid':os.getpid(),'start_ticks':int(tail[19]),'boot_id':'673cfd48-3d8e-45de-8933-8ed1b12c2604'}))
time.sleep(3)
