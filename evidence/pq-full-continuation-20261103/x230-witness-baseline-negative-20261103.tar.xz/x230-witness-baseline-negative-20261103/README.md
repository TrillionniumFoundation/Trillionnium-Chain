# X230 old-source witness admission negative control

This diagnostic ran only after root job `1a1a12385cc-96a-6d73` reached authoritative terminal state with complete logs, after both the full Node command and subsequent strict Clippy finished. The original full Node command timed out (return 124); Clippy returned 0. Original summary/source-before/source-after/build records and the fixed test binary SHA-256/size were retained before mutation. The checkout/target had no remaining native build or test process.

Only `trillionnium/crates/trnm-pon-node/src/store/pq_network.rs` was temporarily replaced by the exact `1c7e8ab7cd6a321cad4e6c7f7e8a197d7b3be14c` version (SHA-256 `036a2b1d78e60c565f565d404905cc7d3dfb477522ea755ae7be495b86c5f932`). The two new tests and the other seven changed files were untouched. No business budget, Cargo profile, feature set or retained selector was changed.

## Results

- Ordinary admission: native exit 101 at the intended operation-count assertion. The actual old-source log contains `left: [1, 1, 2]` and `right: [1, 2]`, with exactly one failed test and no ignored test. This reached the count assertion; no witness deadline occurred first.
- Expired admission: native exit 0, with exactly one passed test and no ignored test. This is the expected compatibility control: actual expiry still requires retirement and a new guarded admission, asserted as `[1, 2, 1, 2]`, with epoch/state/checkpoint/cold-reopen assertions retained.
- The first test stops at its fresh-admission assertion. Its old-source pending-replay counter was therefore not reached or measured. Fixed pending replay was separately exercised in the previously retained fixed tests.
- `finally` restored the fixed `pq_network.rs` bytes. All eight fixed-source SHA-256 values matched the initial capture; an independent subsequent readback matched them again.

## Exact configuration and evidence scope

Both commands used normal `cargo +1.95.0 test --locked --manifest-path trillionnium/Cargo.toml -p trnm-pon-node --lib <exact-selector> -- --exact --show-output --test-threads=1`, default features, the original repository test profile, and the unchanged 250 ms witness budget. The X230 configuration was inherited from the successful fixed-controls run: PATH includes the normal Cargo shim, canonical absolute RUSTC, the same target directory, two build jobs, and no new CARGO_HOME/RUSTFLAGS/CARGO_INCREMENTAL override. All observed environment values and full argument vectors are in the records.

The shared target now contains the baseline-built test binary. The fixed source is restored; any future fixed-source Cargo run must rebuild normally. Do not use the retained baseline binary directly as fixed-source evidence. The original fixed binary SHA-256/size and the differing baseline binary SHA-256/size are retained, without copying build caches or binaries.

This negative control establishes the redundant fresh Current exchange in the old implementation and preservation of real expiry behavior. It does not turn the earlier main-host failures, the incomplete full Node suite, whole-system rollback coverage, migration, WAN, or whole-chain quantum-security qualification into passes. Qualification remains false.
