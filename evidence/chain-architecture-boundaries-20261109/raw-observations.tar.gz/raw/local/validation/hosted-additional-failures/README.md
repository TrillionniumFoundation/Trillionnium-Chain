# Additional exact-head hosted failures

Candidate: `34bffa42461e746a602cfd687b8efb082df926c8`; tree `b692872dfd441a3ee89a6604ec51556fd1f6bddf`.

## Original native campaign — run 42553752948

The sole head/release job 128954800085 completed failure. The original 1.95.0 release opt3 build succeeded. All three predeclared complete campaign observations exited 101 at `public_v3_multiprocess.rs:1765`, with `finite experiment criteria failed`; the workflow reports `ORIGINAL_THREE_RUN_CAMPAIGN_FAILED`. No phase startup or report-validation error was reported.

All three original reports have economics_complete=true and finite_experiment_criteria_met=false. Each baseline confirms 1 of 3 planned rounds; each from-zero and late-product phase confirms 0 of 3. All nine phases report `PUBLIC_REQUEST_DEADLINE`, false state equality, false phase criteria and false observed depletion. These are current real acceptance failures. The harness and resource contracts are unchanged, but native runtime changed this round; causal attribution cannot be inferred from unchanged harness or prior red status. No unknown-PQ refusal is observed: all nine phases report zero PQ authentication attempts and unavailable=false.

## Next architecture — run 42553753001

Three lanes succeeded. Only x64 prospective-merge job 128954938763 failed, testing `e6f02e4d35ce36178f4dc92463f4f6d32262a991` with the same tree. The complete default-feature data-availability crate reports 449 passed, 1 failed, 0 ignored. Test `fixture_setup_wait_preserves_original_tcp_announcement_budget` completed setup and accept-loop readiness, then its first announcement returned `io / WouldBlock / errno 11` after 204,793,399 ns. The original request timeout remains 200 ms; overall timeout remains 10 seconds. Panic: `sequence_tests.rs:102:9`.

The entire data-availability crate, workspace manifest/lockfile and workflow are unchanged versus fixed baseline e798d7125724d4b9f98c24d00cc80031f2eab4a9. This is an actual failed timing/I/O observation. Other lane success does not establish a scheduler/network root cause or justify replacing the failure.

## Provenance and publication subset

Complete failed-job logs and run/job metadata are retained. Native artifact 13647335180 was downloaded using the official GitHub connector. ZIP size 76,016,627 and SHA256 4ff65f26af38e3896d386baac78fcc0d66ffcc6fb3ec3906e73da258aaab54a9 independently match GitHub metadata. The full ZIP remains local and is excluded from the publication manifest.

`native-artifact-extracted/` contains 41 verbatim selected artifact entries: runner/source/resource records, three run stdout/stderr logs, three campaign-failure records and three workflow-derived phase readbacks. The readbacks are derived workflow outputs, not complete original reports. `native-original-report-excerpts.json` is a labeled selection of original report fields and independently verified complete-report hashes. Full reports remain in the ZIP. No independent binary execution or verification is claimed.

`failure-summary.json`, `failure-excerpts.json`, `source-comparison.json`, the artifact retrieval receipt/index and selected-entry hashes retain the detailed evidence. `MANIFEST.sha256` covers every republishable file, excluding itself and the local ZIP, so it remains valid after unpacking the publication subset.

No repository edit, repin, workflow rerun, or Cargo invocation was performed.
