# Native observer validation records

This package preserves two distinct source-bound attempts. It is an evidence packaging operation, not a new test run.

| Record | Actual source | Focused controls | Other checks |
| --- | --- | --- | --- |
| Remote ai395 | `8f4d69a594dfe78541ce8afaba55c1fe2f623322` / tree `a7d820d364f926784c28732107de1f7bb28306bd` | **11 PASS**, default features, exact 7 + 2 + 2 test IDs retained | preflight, workspace fmt, locked/offline default and all-features metadata, strict workspace/all-targets/all-features Clippy all PASS |
| Earlier local cloud attempt | `48441d091f1f9dd6f183f0ef3fac476c83ea6791` / tree `63f089cab7c1bd18eb85902d709187de90ce5ee6` | **11 NOT_EXECUTED**: dependency compilation failed with ENOSPC, Cargo exit 101, before tests; subsequent selectors were not launched | preflight and complete source checks PASS; later low-write fmt and both metadata checks PASS; local Clippy not executed |

The remote test execution belongs to commit 8f4d69a. Commit 48441d0 is a separate evidence child and is not relabeled as the tested remote commit. Both attempts retained the original repository profile, one build job and incremental disabled. Existing per-package profile settings were not removed.

## Package contents

- `remote-ai395-8f4d69a/history-observer-ai395-validation-8f4d69a-1.tar.gz` is the original 150,983-byte remote success archive, byte-for-byte unchanged (SHA-256 `0a8d03529ec030815bf9b060282eace4b3b60835bfc544cb393b0cb8792fa875`). Its complete stage logs, metadata graphs, source-before/after records, provider checks, final process receipts and original manifest remain intact.
- `local-cloud-48441d0/history-observer-validation-48441d0-1/` contains every one of the 19 files in the frozen local attempt directory, including ENOSPC, later fmt/metadata and both source records. Original JSON and log bytes are preserved.
- `runner/runner.py` is the exact executed 8f runner, also present in the nested archive (SHA-256 `edb6a67bba12fdf066a28218c0e6b4d9b3d30fbef7d88bd2214c807abcb1ba4b`).
- `provenance/remote-test-binary-file-info.json` is the original binary identity receipt, also present in the nested archive.
- `scope.json` records the distinct outcomes and their limits in machine-readable form.
- The adjacent `native-validation-manifest.json` lists every outer member and every nested remote member with byte length and SHA-256, original input-file identities before/after packaging, and archive readback verification.

## Verification scope

All 11 actually executed observer controls used default features. All-features scope is **dependency graph and strict Clippy compilation only**, not all-features tests, PQ runtime qualification, a new original native campaign, or hosted CI. Strict Clippy used the existing pinned OpenSSL 3.5.9 installation; five specified installed files were read before and after and matched their expected SHA-256 values. This is not a claim to verify the provider's full build identity. The local attempt recorded system OpenSSL 3.5.7 and remains a distinct environment.

Complete source-before/after records match within each attempt: remote 26,168 entries / 2,501,260,625 bytes; local 26,201 entries / 2,534,971,793 bytes.

The 512,675,440-byte test binary is omitted. Its original remote path, size, version and SHA-256 `3afef64d4074a1c464777e19b099ed45185860a244da53d26c2238749ef3f6e5` remain in the receipt and scope record. It is the unit-test executable for these controls, not the original campaign executable.

Historical campaign failures are not overwritten or reclassified by these controls. No campaign acceptance or production qualification is granted. No repository source, frozen input record or provider file was edited during packaging. No changing publication or transfer records are included. Outer tar metadata is normalized; all original input file contents, including the entire nested archive, are preserved byte-for-byte.
