/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/foreign_types-b3d0edd53f842697.d: /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign-types-0.3.2/src/lib.rs

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libforeign_types-b3d0edd53f842697.rmeta: /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign-types-0.3.2/src/lib.rs

/workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/foreign-types-0.3.2/src/lib.rs:
