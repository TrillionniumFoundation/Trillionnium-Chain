#!/usr/bin/env python3
"""Construct old production + exactly the shared test-only observation hooks.
No compiler or native execution is invoked. Inputs are preserved next to this script.
"""
import difflib, hashlib, json, pathlib, re
ROOT=pathlib.Path(__file__).resolve().parent
BASE=json.loads((ROOT/'base.json').read_text())
SRC='trillionnium/crates/trnm-pon-node/src/'
TEST=SRC+'pool_run_control_tests.rs'
changes={
'mining.rs': [
('mod prepare_control_tests;\n', 'mod prepare_control_tests;\n\n#[cfg(test)]\n#[path = "pool_run_control_tests.rs"]\npub(crate) mod pool_run_control_tests;\n'),
('        let batch_result = owner.pool_mining_batch(', '        #[cfg(test)]\n        pool_run_control_tests::enter_stage("pool-batch", end);\n        let batch_result = owner.pool_mining_batch('),
('        report.pool_batch_ns += event.pool_batch_ns;\n', '        report.pool_batch_ns += event.pool_batch_ns;\n        #[cfg(test)]\n        pool_run_control_tests::after_stage("pool-batch");\n'),
('        let prepared = (|| match &config.material {', '        #[cfg(test)]\n        pool_run_control_tests::enter_stage("prepare", end);\n        let prepared = (|| match &config.material {'),
('        report.prepare_ns += event.prepare_ns;\n        drop(owner);\n', '        report.prepare_ns += event.prepare_ns;\n        drop(owner);\n        #[cfg(test)]\n        pool_run_control_tests::after_stage("prepare");\n'),
('            let validation = owner.pool_validate_batch(&batch);', '            #[cfg(test)]\n            pool_run_control_tests::enter_stage("batch-revalidation", end);\n            let validation = owner.pool_validate_batch(&batch);'),
('            report.post_search_batch_validation_ns += event.post_search_batch_validation_ns;\n', '            report.post_search_batch_validation_ns += event.post_search_batch_validation_ns;\n            #[cfg(test)]\n            pool_run_control_tests::after_stage("batch-revalidation");\n'),
],
'store.rs': [
('            if state.len().is_multiple_of(256) {\n                progress()?;', '            if state.len().is_multiple_of(256) {\n                #[cfg(test)]\n                crate::mining::pool_run_control_tests::state_rows(state.len());\n                progress()?;'),
],
'store/mempool.rs': [
('        let output = self\n            .prefix', '        #[cfg(test)]\n        crate::mining::pool_run_control_tests::before_pool_execution();\n        let output = self\n            .prefix'),
('            })?;\n        *node.commitment_observation.borrow_mut() = Some(output.commitment.observation);', '            })?;\n        #[cfg(test)]\n        crate::mining::pool_run_control_tests::after_pool_execution();\n        *node.commitment_observation.borrow_mut() = Some(output.commitment.observation);'),
],
}
def sha(b): return hashlib.sha256(b).hexdigest()
patch=[]; mapping=[]
for path,expected in BASE['paths'].items():
    original=(ROOT/'old-production'/path).read_bytes()
    assert sha(original)==expected, f'changed old production: {path}'
    source=original.decode()
    pairs=changes.get(path.removeprefix(SRC),[])
    for old,new in pairs:
        assert source.count(old)==1,(path,'non-unique anchor',old)
        source=source.replace(old,new)
    restored=source
    for old,new in reversed(pairs):
        assert restored.count(new)==1
        restored=restored.replace(new,old)
    assert restored.encode()==original, f'hooks did not erase exactly: {path}'
    target=ROOT/'h0-source'/path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(source)
    if source.encode()!=original:
        patch.append(f'diff --git a/{path} b/{path}\n')
        patch.extend(difflib.unified_diff(original.decode().splitlines(True),source.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
    mapping.append({'path':path,'base_sha256':sha(original),'h0_sha256':sha(source.encode()),'hook_insertions':len(pairs),'production_restored_byte_identical':True})
test=(ROOT/'same-test'/TEST).read_bytes()
expected=json.loads((ROOT/'test-pin.json').read_text())['sha256']
assert sha(test)==expected
(ROOT/'h0-source'/TEST).write_bytes(test)
patch.append(f'diff --git a/{TEST} b/{TEST}\nnew file mode 100644\n')
patch.extend(difflib.unified_diff([],test.decode().splitlines(True),fromfile='/dev/null',tofile='b/'+TEST))
(ROOT/'tests-only.patch').write_text(''.join(patch))
(ROOT/'h0-binding.json').write_text(json.dumps({'base':BASE['source'],'test_sha256':sha(test),'mapping':mapping,'patch_sha256':sha(''.join(patch).encode()),'native_execution':'NOT_RUN'},indent=2)+'\n')
print(json.dumps({'base':BASE['source'],'test_sha256':sha(test),'hook_only_paths':len(changes),'unchanged_error_rs':not changes.get('error.rs'),'native_execution':'NOT_RUN'}))
