#!/usr/bin/env python3
"""Narrow C8 precommit checks; no Cargo build or operation."""
from pathlib import Path
import hashlib,json,re,subprocess,time
REPO=Path('/home/qian-qi/work/chain-w1-base9417-integration-20261108-ec265b')
ROOT=Path('/home/qian-qi/work/chain-w1-base9417-adversarial-integration-20261108-ec265b-01')
OUT=ROOT/'precommit-checks-01'
C7='40a3a45d6b8afc5c4706c5235fec47634f4aabbe'
BASE='9417e495165865ef6c1288b39084856e31020634'
OUT.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(x):return (json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def write(p,b):
    with p.open('xb') as f:f.write(b)
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
assert git('rev-parse','HEAD').decode().strip()==C7
assert git('rev-parse','MERGE_HEAD').decode().strip()==BASE
expected={'.github/workflows/pon-recent-batch-acceptance.yml','config/pon/pq-cross-branch-corpus-v1.json',
'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md','scripts/ci/test_history_stage_diagnostic.py',
'trillionnium/crates/trnm-pon-node/src/store.rs','trillionnium/crates/trnm-pon-node/src/store/historical_commitment.rs',
'trillionnium/crates/trnm-pon-node/src/store/historical_commitment_tests.rs','trillionnium/crates/trnm-pon-node/tests/history_stage_diagnostic.rs'}
assert set(git('diff','--name-only',C7).decode().splitlines())==expected
assert git('ls-files','-u')==b''
before=git('diff','--binary',C7)
write(OUT/'candidate-before.patch',before)
commands=[
('00-preflight',['bash','scripts/project-preflight.sh']),
('01-diff-whitespace',['git','diff','--cached','--check']),
('02-changed-rust-format',['/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustfmt','--check','--edition','2021','--config','skip_children=true',
'trillionnium/crates/trnm-pon-node/src/store.rs','trillionnium/crates/trnm-pon-node/src/store/historical_commitment.rs','trillionnium/crates/trnm-pon-node/src/store/historical_commitment_tests.rs','trillionnium/crates/trnm-pon-node/tests/history_stage_diagnostic.rs']),
('03-distributed-source-inventory',['python3','scripts/refresh_distributed_source_inventory.py','--check']),
('04-pq-source-contract',['python3','scripts/ci/check_pq_research_integration.py']),
('05-ci-contract',['python3','scripts/ci/check_ci_contract.py']),
('06-ci-contract-negative-controls',['python3','scripts/ci/test_ci_contract.py','-v']),
('07-pq-source-negative-controls',['python3','scripts/ci/test_pq_research_integration.py','-v']),
('08-history-diagnostic-controls',['python3','scripts/ci/test_history_stage_diagnostic.py','-v'])]
rows=[]
for label,argv in commands:
    t=time.monotonic_ns()
    with (OUT/(label+'.stdout')).open('xb') as so,(OUT/(label+'.stderr')).open('xb') as se:
        try:
            p=subprocess.run(argv,cwd=REPO,stdout=so,stderr=se,timeout=240)
            code=p.returncode;timeout=False
        except subprocess.TimeoutExpired:
            code=124;timeout=True
    end=time.monotonic_ns()
    a=(OUT/(label+'.stdout')).read_bytes();b=(OUT/(label+'.stderr')).read_bytes()
    text=(a+b'\n'+b).decode('utf-8')
    counts=[int(x) for x in re.findall(r'^Ran ([0-9]+) tests? in ',text,re.M)]
    row={'label':label,'argv':argv,'cwd':str(REPO),'exit':code,'timed_out':timeout,
        'started_monotonic_ns':t,'finished_monotonic_ns':end,
        'stdout_bytes':len(a),'stdout_sha256':sha(a),'stderr_bytes':len(b),'stderr_sha256':sha(b),
        'python_reported_methods':counts,'python_exact_OK_summaries':len(re.findall(r'^OK$',text,re.M))}
    rows.append(row);print(json.dumps(row),flush=True)
after=git('diff','--binary',C7)
unchanged=before==after
write(OUT/'candidate-after.patch',after)
write(OUT/'candidate-stat.txt',git('diff','--stat',C7))
write(OUT/'candidate-name-status.txt',git('diff','--name-status',C7))
tests=[r for r in rows if r['python_reported_methods']]
success=all(r['exit']==0 for r in rows) and unchanged
report={'schema':'TRNM-W1-C8-PRECOMMIT-CHECKS1','repo':str(REPO),'parent':C7,'fixed_base':BASE,
    'commands':rows,'actual_command_count':len(rows),'complete':success,
    'candidate_unchanged_during_checks':unchanged,'candidate_diff_sha256':sha(before),
    'python_method_executions':sum(sum(r['python_reported_methods']) for r in rows),
    'all_reported_suites_have_exact_OK':all(r['python_exact_OK_summaries']==len(r['python_reported_methods']) for r in tests),
    'cargo_builds':0,'rust_test_executions':0,'new_operations':0,'new_proofs':0,
    'scope':'Precommit candidate checks only. Does not establish committed C8 source qualification.'}
write(OUT/'manifest.json',dump(report))
print(json.dumps({'complete':success,'out':str(OUT),'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'methods':report['python_method_executions']}),flush=True)
raise SystemExit(0 if success else 1)
