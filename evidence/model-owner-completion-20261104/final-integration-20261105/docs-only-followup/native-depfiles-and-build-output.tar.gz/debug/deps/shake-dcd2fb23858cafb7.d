/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/shake-dcd2fb23858cafb7.d: /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/shake-0.1.0/src/lib.rs /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/shake-0.1.0/src/../README.md

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libshake-dcd2fb23858cafb7.rlib: /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/shake-0.1.0/src/lib.rs /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/shake-0.1.0/src/../README.md

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libshake-dcd2fb23858cafb7.rmeta: /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/shake-0.1.0/src/lib.rs /workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/shake-0.1.0/src/../README.md

/workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/shake-0.1.0/src/lib.rs:
/workspace/scratch/79360d3567d1/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/shake-0.1.0/src/../README.md:
