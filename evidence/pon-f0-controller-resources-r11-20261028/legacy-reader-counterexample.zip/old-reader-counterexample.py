#!/usr/bin/env python3
"""Parser-only synthetic F0 counterexample; no Host/native execution claim."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path('/workspace/scratch/56818e4fba76/chain-history-resource-r11')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
sys.path.insert(0, str(ROOT / 'scripts/ci'))
import run_fixed_host_root_f0 as runner
from test_fixed_root_f0 import F0DenominatorControls


def report_fixture():
    value = F0DenominatorControls.report()
    identity = {
        'process': {'pid': 123, 'parent_pid': 100, 'start_ticks': 1,
                    'cgroup': '/system.slice/f0-fixture.service',
                    'boot_id': '00000000-0000-0000-0000-000000000001',
                    'executable': {'device': 1, 'inode': 17, 'bytes': 100,
                        'modified_seconds': 1, 'modified_nanoseconds': 0}},
        'cgroup': {'device': 1, 'inode': 99, 'uid': 0, 'gid': 0, 'mode': 493},
    }
    meter = {'schema': 'public-v3-local-stored-cpu-budget-v1',
             'burst_ns': 2_000_000_000, 'start_reserve_ns': 100_000_000,
             'refill_ns_per_second': 250_000_000, 'worker_limit': 2,
             'accounting_unavailable': False}
    flow = {'schema': 'public-v3-local-actual-cpu-flow-v1',
            'balance_identity_verified': True, 'initial_credit_ns': 2_000_000_000,
            'credited_refill_ns': 0, 'paid_cpu_debit_ns': 2_000_000_000,
            'live_debited_cpu_ns': 2_000_000_000, 'settlement_residual_cpu_ns': 0,
            'remaining_paid_credit_ns': 0, 'settlement_discard_ns': 0,
            'stored_credit_ns': 0, 'booked_reservation_ns': 0, 'live_owners': 0,
            'unsettled_known_live_cpu_ns': 0, 'settled_full_cpu_ns': 2_000_000_000}
    value.update({key: runner.INPUTS[key] for key in ('seed_transfers', 'seed_blocks',
        'business_blocks', 'phase_seconds', 'actor_call_cap', 'planned_complete_runs', 'm06_workers')})
    value.update({key: False for key in runner.QUALIFICATIONS})
    value.update(schema='native-public-v3-fixed-host-root-f0-v1',
                 placement_profile=runner.PHASE_PROFILE, placement_complete=True,
                 controller_stable=True, planned_confirmations=6,
                 new_f1_parameters_implemented=False, original_scalar_profile_changed=False,
                 controller_identity_before=identity, controller_identity_after={'Ok': identity},
                 preparation_cost_known=True, preparation={'cpu_ns': 1, 'wall_ns': 2},
                 producer_state_equal=True, supplemental_criteria_met=True)
    for ordinal, phase in enumerate(value['phases']):
        count = 0 if ordinal == 0 else 24
        actors, spawned = [], []
        for number in range(count):
            process = {'pid': 1000 + number, 'parent_pid': 123, 'start_ticks': 2000 + number,
                       **{key: identity['process'][key] for key in ('cgroup', 'boot_id', 'executable')}}
            observed = {'ordinal': number, 'pid': process['pid'], 'identity': process}
            spawned.append(observed)
            actors.append({'ordinal': number, 'pid': process['pid'], 'verified': True,
                'observation': {'Ok': {'identity': process, 'spawn_observation': observed,
                    'ready': {'pid': process['pid'], 'mode': 'valid-work-root',
                              'cgroup': process['cgroup']}}}})
        phase.update(duration_seconds=30, initial_meter=meter,
                     finite_phase_criteria_met=ordinal == 0,
                     fixed_root_external_actor_membership={
                         'verified': True, 'controller_check': {'Ok': None},
                         'controller_identity': identity, 'expected_actors': count,
                         'observed_actors': count, 'distinct_pids': count, 'actors': actors},
                     phase_process_context={'schema': runner.PHASE_PROFILE,
                         'controller_identity': identity, 'controller_live_identity_after_verified': True,
                         'runtime_business_deadline_changed': False, 'scalar_policy_changed': False,
                         'phase_cgroup': '/trnmponpublic.slice/f0-fixture-' + str(ordinal)},
                     external_controller_observation={'schema': runner.PHASE_PROFILE,
                         'controller_identity': identity, 'controller_live_identity_after_verified': True,
                         'launched': count, 'reaped': count, 'actual_attack_process_contexts': spawned})
    pressure = value['phases'][1]
    ready = [actor['observation']['Ok']['ready'] for actor in pressure['fixed_root_external_actor_membership']['actors']]
    acquisitions, children = [], []
    for index in range(24):
        digest = f'{index:064x}'
        acquisition = {'valid_work_for_root_rejection': True, 'setup_calls': 1, 'method_index': 0,
            'public_request_body_digest': digest, 'acquisition_cpu_ns': 1,
            'acquisition_wall_ns': 2, 'diagnostic_cpu_ns': 3, 'diagnostic_wall_ns': 4}
        calls = [{'public_request_body_digest': digest, 'status': 'refused', 'error': None,
                  'returned_after_window': False, 'response': {'ok': False, 'value': {'error': 'ROOT'}},
                  'started_ns': (1 + 4 * number) * 10**9,
                  'ended_ns': (1 + 4 * number) * 10**9 + 100_000_000} for number in range(3)]
        actor = {'pid': 1000 + index, 'worker': index, 'attempt_cap_reached': False,
                 'acquisition': acquisition, 'calls': calls,
                 'traffic_cpu_ns': None, 'entire_actor_cpu_ns': None}
        children.append({'pid': actor['pid'], 'exit_success': True, 'parent_forced_kill': False,
                         'report': {'error': None, 'result': actor}})
        acquisitions.append(acquisition)
    snapshot = {'meter': meter, 'actual_flow': flow, 'sample_at_ns': 1_500_000_000,
                'clock_failures': 0, 'depleted': True}
    pressure.update(root_supplement={
        'controller_cgroup': identity['process']['cgroup'], 'criteria_met': True,
        'aggregate_membership_verified': True, 'whole_domain_paid_reconciled': True,
        'aggregate_scoped_cpu_ns': 0, 'hostile_packets_absent_live': True,
        'hostile_packets_absent_cold': True, 'cold_state_equal': True,
        'expected_legal_counts_and_tip': True, 'hostile_packet_ids': [f'{i:064x}' for i in range(24)],
        'actor_readiness': ready, 'checked_acquisitions_complete': True,
        'acquisitions': acquisitions, 'mutation_owner_cpu_ns': 2_000_000_000},
        children=children, attacker_processes_ready=24, observer_complete=True,
        verifier_errors=[], receiver_client_state_equal=True,
        actor_reports_successful_without_cap_or_kill=True,
        receiver_observation={'records_not_retained': 0, 'measurement_failures': 0,
            'counter_overflow': False, 'accepted_connections_seen': 1,
            'records': [{'complete': True, 'observation_failed': False, 'operation': 1,
                         'dispatch_started': True, 'dispatch_thread_cpu_ns': 2_000_000_000}]},
        final_actual_flow=flow, service_outcome={'Ok': {'mutation_cpu_charged_ns': 2_000_000_000}},
        budget_samples=[{'observation_started_ns': 1_400_000_000,
                         'observation_ended_ns': 1_600_000_000, 'meter': {'Ok': snapshot},
                         'attacker_process_rss': {'complete': False, 'sum_rss_bytes': None,
                             'processes': [{'pid': 1000 + i, 'rss_bytes': None,
                                 'parent_and_executable_identity_verified': False} for i in range(24)]}}],
        depletion_meter=snapshot, genuine_budget_depletion_observed=True)
    for index, row in enumerate(pressure['confirmations']):
        row.update(observation={'depth': 6}, accepted_work_admission_refusal_during_round=True,
                   signed_root_responses_inside_round=24,
                   receiver_hostile_admission_before={'accepted_work_admission_refusals': index,
                                                      'admission_cpu_ns': index},
                   receiver_hostile_admission_after={'accepted_work_admission_refusals': index+1,
                                                     'admission_cpu_ns': index+1},
                   paid_credit_depletion_observed_during_round=index == 0)
    value['all_planned_rounds'] = [{**row, 'old_root_code_already_enforced_four_second_slo': False}
                                 for row in runner.f0_rounds(value)]
    value['all_planned_business_packets'] = runner.f0_packets(value)
    return value


if __name__ == '__main__':
    fixture = report_fixture()
    path = OUT / 'old-reader-missing-resources-fixture.json'
    with path.open('x') as stream:
        json.dump(fixture, stream, indent=2, sort_keys=True)
        stream.write('\n')
    outputs = []
    for function in (runner.check_report, runner.check_f0_placement_and_timing):
        try:
            actual = function(copy.deepcopy(fixture), fixture['controller_identity_before']['process']['cgroup'])
            outputs.append({'function': function.__name__, 'accepted': True, 'returned': actual})
        except (OSError, ValueError, KeyError, TypeError) as error:
            outputs.append({'function': function.__name__, 'accepted': False,
                            'exception_type': type(error).__name__, 'error': str(error)})
    sources = {}
    for name in ('scripts/run_fixed_host_root_f0.py', 'scripts/ci/finalize_fixed_root_f0.py',
                 'scripts/read_original_native_campaign.py', 'scripts/ci/test_fixed_root_f0.py'):
        raw = (ROOT / name).read_bytes()
        sources[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        destination = OUT / 'old-source' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
    result = {'schema': 'f0-resource-parser-counterexample-r11-v1',
              'scope': 'synthetic parser fixture only; no Host, native W1, resource or service execution',
              'fixture_basis': 'F0DenominatorControls.report plus coherent fields required by the original readers',
              'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
              'source_status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True),
              'source_files': sources, 'fixture_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
              'controller_resource_observation_present': False,
              'retained_rss': fixture['phases'][1]['budget_samples'][0]['attacker_process_rss'],
              'function_results': outputs,
              'counterexample_confirmed': all(row['accepted'] for row in outputs)}
    with (OUT / 'old-reader-counterexample-result.json').open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps(result, indent=2, sort_keys=True))
    raise SystemExit(0 if result['counterexample_confirmed'] else 1)
