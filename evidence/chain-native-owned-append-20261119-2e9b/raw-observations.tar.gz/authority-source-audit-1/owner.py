from pathlib import Path
import subprocess,json,hashlib,sys,time,resource
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'authority-source-audit-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
start=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
p=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=src,capture_output=True);(out/'preflight.stdout').write_bytes(p.stdout);(out/'preflight.stderr').write_bytes(p.stderr);assert p.returncode==0
m=json.loads((src/'config/pon/pq-authority-effects-v1.json').read_text());rows=[]
for path,expected in m['source_files_sha256'].items():
 f=src/path;raw=f.read_bytes() if f.is_file() else subprocess.check_output(['git','show','HEAD:'+path],cwd=src)
 actual=hashlib.sha256(raw).hexdigest();rows.append({'path':path,'present':f.is_file(),'bytes':len(raw),'expected':expected,'actual':actual,'matches':actual==expected})
changed=[r for r in rows if not r['matches']]
res={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'rows':rows,'changed':changed,'qualifications':{k:m[k] for k in ['source_revision','purpose','coverage_complete','whole_chain_pq_qualified','production_activation']},'wall_seconds':time.monotonic()-start}
(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
for path in ['docs/development/PQ_AUTHORITY_EFFECT_REGISTER_V1.md','config/pon/pq-cross-branch-corpus-v1.json']:
 f=src/path;raw=f.read_text() if f.is_file() else subprocess.check_output(['git','show','HEAD:'+path],cwd=src,text=True)
 if path.endswith('corpus-v1.json'):
  d=json.loads(raw);print(json.dumps({'path':path,'top_keys':list(d),'matching_lines':[x for x in raw.splitlines() if 'authority' in x or 'store.rs' in x or 'source_revision' in x][:50]},indent=2))
 else:print(json.dumps({'path':path,'text':raw},indent=2))
