#!/usr/bin/env python3
"""Independent integer-model check; does not execute or certify the Rust kernel."""
import hashlib
import json
from pathlib import Path
from random import Random

B = 1 << 32
Q = B - 5
MAX_TERMS = 64
ROOT = Path(__file__).resolve().parent / "chain-work"


def main():
    loose_sum_bound = (MAX_TERMS + 1) * B - 1 + 5 * (MAX_TERMS * B - 1)
    folded_bound = B - 1 + 5 * (loose_sum_bound // B)
    assert loose_sum_bound < (1 << 41)
    assert folded_bound < 2 * Q
    rng = Random(0x504F4E)
    cases = 0
    boundary_values = [0, 1, Q - 2, Q - 1, 1 << 16, 1 << 31]
    for length in range(MAX_TERMS + 1):
        for trial in range(200):
            left = [
                rng.choice(boundary_values) if trial < 50 else rng.randrange(Q)
                for _ in range(length)
            ]
            right = [
                rng.choice(boundary_values) if trial < 50 else rng.randrange(Q)
                for _ in range(length)
            ]
            prior = rng.randrange(Q)
            products = [a * b for a, b in zip(left, right)]
            low = prior + sum(p & (B - 1) for p in products)
            high = sum(p >> 32 for p in products)
            summed = low + 5 * high
            folded = (summed & (B - 1)) + 5 * (summed >> 32)
            result = folded - Q if folded >= Q else folded
            assert low < (length + 1) * B
            assert high < length * B if length else high == 0
            assert summed < (6 * length + 1) * B
            assert folded < 2 * Q
            assert result == (prior + sum(products)) % Q
            cases += 1
    paths = [
        "trillionnium/crates/trnm-crypto-primitives/src/pon_work.rs",
        "trillionnium/crates/trnm-crypto-primitives/src/pon_work/maintenance_limb.rs",
    ]
    print(json.dumps({
        "schema": "pon-full-limb-independent-integer-check-v1",
        "result": "PASS",
        "cases": cases,
        "term_lengths": [0, MAX_TERMS],
        "seed": 0x504F4E,
        "loose_sum_bound": loose_sum_bound,
        "folded_bound": folded_bound,
        "twice_q": 2 * Q,
        "source_sha256_at_observation": {
            path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
            for path in paths
        },
        "native_rust_executed": False,
        "performance_measured": False,
        "work_hardness_qualified": False,
        "scope": "Independent Python integer arithmetic only; not execution of Rust or proof of arbitrary compiler behavior.",
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
