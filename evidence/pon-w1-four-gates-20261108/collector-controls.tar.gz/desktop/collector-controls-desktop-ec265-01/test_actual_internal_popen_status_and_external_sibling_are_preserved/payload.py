import subprocess,sys
p=subprocess.Popen(['/usr/bin/python3.12','-c','import sys;sys.exit(37)'])
print(p.wait(),flush=True)
sys.exit(23)
