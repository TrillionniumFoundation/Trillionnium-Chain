from pathlib import Path
import json,sys,time,resource,subprocess,hashlib,re
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'original-binary-input-audit-60';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);t=time.monotonic();b=resource.getrusage(resource.RUSAGE_SELF);bc=resource.getrusage(resource.RUSAGE_CHILDREN)
prefixes={'evidence/hepta-real-native-adoption-20261108'}
for p in [src/'scripts/test_cell_learning_business_join.py',src/'scripts/test_cell_learning_training_no_update_join.py']:
 for v in re.findall(r'evidence/[a-zA-Z0-9_.-]+',p.read_text()):prefixes.add(v)
tree=subprocess.check_output(['git','ls-tree','-rz','HEAD','--',*sorted(prefixes)],cwd=src);rows=[]
for item in tree.split(b'\0'):
 if not item:continue
 meta,name=item.split(b'\t');mode,kind,oid=meta.decode().split();name=name.decode();p=src/name
 assert mode in ('100644','100755') and kind=='blob'
 if not p.exists():rows.append({'path':name,'mode':mode,'git_blob':oid})
a=resource.getrusage(resource.RUSAGE_SELF);ac=resource.getrusage(resource.RUSAGE_CHILDREN);r={'prefixes':sorted(prefixes),'missing':rows,'missing_count':len(rows),'wall_seconds':time.monotonic()-t,'self_user_cpu_seconds':a.ru_utime-b.ru_utime,'self_system_cpu_seconds':a.ru_stime-b.ru_stime,'child_user_cpu_seconds':ac.ru_utime-bc.ru_utime,'child_system_cpu_seconds':ac.ru_stime-bc.ru_stime};(out/'READOUT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
