# Trillionnium-Chain：正常受保护合并与分支清理执行设计

状态：仅设计与只读验证。没有执行合并、删除、PR 元数据修改或保护变更。此文件不授权任何规则绕过，也不表示远端 CI 已通过。用户原始请求已覆盖正常合并与清理；实际执行仍由 root 使用已授权通道承担。

## 1. 已观察事实与当前边界

| 项目 | 已读取的事实 | 实际执行时要求 |
| --- | --- | --- |
| 合并方式 | 仓库允许 squash、rebase、merge commit；#847 在本轮输入中 rebaseable=false | 选择 squash；main 的线性历史规则仍有效 |
| main 保护 | strict=true，五个原 required contexts，GitHub App 15368；线性历史、会话解决；禁止 force/删除 | 正常保护路径执行，不利用管理员豁免 |
| 审批数量 | root 的 05:38 viewer-rule 观察为 requireApprovingReviewCount=0；本设计未重新读取该份原件 | 合并前按最新完整规则执行，不自审，不虚构额外审批要求 |
| 候选 PR | #847，候选 ref 为 fix/chain-hepta-closure-candidate-20261109-481716；旧观察 head=e40d7071…，draft=true，blocked | 发布完成后重新绑定实际 C；旧 e40d 不能作为新提交的通过证明 |
| 自动删除 | delete_branch_on_merge=true | 合并之前必须完成远端归档验证，允许候选自然消失但必须留回执 |
| 旧保护分支 | fix/chain-bulk-state-tree-20261017，allow_deletions=false | 不纳入删除集合；这是“仅剩一个 branch”的真实阻塞 |
| 全部分支 | remote0170 为 908 refs / 892 unique tips，后续发布必须有明确 overlay | 每次真正 mutation 前重新读完整 heads；新 ref/新 SHA 不能静默归入旧账 |
| 历史归档 | 旧 20261113-5954 名称与 b9cc24 对象缺失的更正仍成立 | 只使用本轮实际创建并完成远端核验的新 tag；不使用旧 PR 正文作证明 |

本设计不会给候选分支与 archive tag 的原子发布新增 main 保护 gate。完整 main/legacy 保护复核放在真正 merge/delete 前；此前候选/tag 发布维持 root 已审核的独立 v4 流程。GitHub 插件的 main-protection 403 是集成权限限制；legacy URL 400 是连接器 URL 拒绝，二者都不能解释为“没有保护”。不读取或复制凭据。

固定输入与哈希见 planning-inputs.json、open-pr-impact-v1.json。原 semantic ledger 仍保持其覆盖限制：908 refs 全部有明确处置；历史保留与选择不采用的协议不写成等价吸收；未逐行读完所有旧实现、未执行所有旧测试。上述限制不因本执行设计而改变。

## 2. 先完成远端归档，再允许任何可能删除 head 的操作

候选/tag 发布由 root 按 v4 的固定源码和计划执行。以后准备 merge 时，读取该次原始 publication receipt，验证实际远端候选 C、archive tag OID/目标 commit A，以及发布前后完整 ref 清单。tag 必须实际存在且对象可读取；本地 tag 存在不等于远端保存完成。

归档验证绑定精确原 tip 集合与最终 C。以受限 cat-file 读取原始 commit bytes、核 Git 对象身份、tree 和 parent 集合；避免对数百父提交使用曾经阻塞的 git show 父图展开。保留原 892 tips、后续候选 C，以及 ledger 指明的已消耗 hosted-once intent 的可达性证明。必要的远端 fetch/readback使用独立验证目录，不改共享 checkout，也不重写现有 tag。

如果发布或 readback 的终态未知，只做只读 reconcile。未确认前不继续 merge/cleanup，不重用未知结果去自动补发。后续候选 C 有新提交时，新 C 的保护必须先明确补齐，不能用上一次只保护旧 C 的 receipt 顶替。

## 3. 固定真正要合并的 B、C、P、T

定义 B=新鲜 main tip，C=新鲜 #847 head，P=本次 GitHub prospective merge commit，T=P 的完整 tree。同时保存全 heads map H、archive 身份 A、完整 branch protection/rulesets、PR 元数据和审核/会话状态，全部带采集时间与 SHA。

按现行 required-baseline workflow 核对以下证据：

| 阶段 | 必需具名结果 |
| --- | --- |
| Exact head | repository-truth；protocol-contract；fuzz-smoke；external-evidence-contract；rust-baseline |
| Prospective merge | prospective-merge (repository-truth)；prospective-merge (protocol-contract)；prospective-merge (fuzz-smoke)；prospective-merge (external-evidence-contract)；prospective-merge (rust-baseline) |

前五个原保护 context 及预期 App 15368 不改。Prospective 行是本项目现有验收要求，不假称它们已是另外五条保护配置。Rust fan-in 必须绑定实际 runtime/quality shards 的同 run/attempt/source；只看到 fan-in 名字不足以替代其内容。

实际 run 必须 completed/success、无缺失，使用当前 workflow 身份、原预算和失败传播；保留 run ID、attempt、job ID、完整日志及 source receipts。Check-run 自身关联 SHA 未必等于工作区所测 P，因此 prospective 的判断必须读 source.json 中 B/C/P、ordered parents 和 before/after 原始源码身份，不能只在 check API 上搜索 P。确认 P 的父为该 B/C，并绑定 tree T；如果 strict up-to-date 条件不满足，先正常整合新的 main，再对新 C/P 跑原门槛。

历史 4 秒 Host/confirmation 失败仍是历史失败；本机 unit/Clippy 或绑定 gate 通过不解除它。最终 head/prospective required CI 没有实际通过时，merge 阶段停在等待/失败，不能降阈值或把 skipped/neutral 写成执行成功。研究 qualification/HOLD 也不会因为合并而升级。

等原 CI 完成后，在 mutation 前重新读取 main=B、PR head=C、prospective=P、H 与规则。如果 main/head 或与本轮相关 ref 漂移，保留已完成证据，重新建立精确候选，不重置别人提交。不要将前一次通过状态复用给不同提交。

## 4. 使用普通 protected squash 路径

#847 仍为 draft 时，实际执行阶段按原合并目标正常转为 ready；此设计阶段没有修改它。检查新鲜 review/thread 要求，当前未要求额外审批的观察不能延伸为未来永久豁免。禁止 self-approve、admin/bypass、修改规则或直接 push main。

推荐使用官方异步 merge API，以结构化参数固定 C：

    PUT /repos/TrillionniumFoundation/Trillionnium-Chain/pulls/847/merge-async
    {
      "sha": "<fresh verified C>",
      "merge_method": "squash",
      "merge_action": "direct_merge",
      "bypass_rules": false
    }

这是调用设计，不是已发送请求。如果最新规则要求 merge queue，就使用正常队列，并核验真正 merge-group 的原要求；不强行 direct_merge。异步 202 只代表已受理，保存 UUID 后轮询同一个请求。409 已有请求要核对原 UUID/head/options，不能盲发第二次。pending/enqueued 均不是 merged。超时后只读查询原操作与 PR；不要以换接口作为重试绕过失败。

API 的 sha 参数只约束 C，不是 expected-base/fullrefs 原子条件。本设计采用新鲜 B/H 读验、现有 strict 保护和事后核对；不宣称这组合提供全仓原子 CAS。后台合并期间的规则或未触 refs 漂移仍可能发生，发现后停止清理。

成功后独立读取 PR.merged、服务返回的合并 OID S、main ref 与 S 原始 commit。要求 main=S，S 只有一个 parent B，S.tree=T；同时核归档与保护未发生未解释变化。满足这些才记“合并完成”。Squash 会产生新 commit，因此不能要求 C 是 S 的祖先，也不能因为该祖先检查为 false 而误判源码丢失。历史 DAG 由 archive A 保留。

若实际 S.parent/tree 不符合冻结 tuple，保存真实结果并 HOLD cleanup；不能自动 reset/revert main。合并 API 返回成功但后续 main 又前进，也要区分自己的合并结果与他人后续工作，不覆盖它。

## 5. 合并后的 PR 与 refs 影响

原开放 PR 盘点非原子分页，范围为 04:50:42.630337–04:52:21.898537 UTC：

- 579 open：569 draft、10 non-draft；80 base=main，499 base 非 main。
- 578 unique head refs；#521 和 #533 共用 fix/chain-finite-rate-boundary-20261028。
- 候选 head 只对应 #847；#891、#893、#896、#910、#948 的 base 是候选。GitHub 在合并后删除该 head 时可能按其既定行为把这些 base 改到 main。
- legacy head 对应 #323；#324、#328、#330、#506 的 base 是 legacy。
- 非保护 head 对应 578 个 PR、577 个 refs。#847 正常合并后，另 577 个 PR 的 head 可能被后续清理触及；必须读取其实际关闭/保留/重定向结果。

保存 merge 前、merge 后、每次 cleanup 后的完整 PR inventory。分别记 merged、因 head 删除而 closed、base 自动变化、未受影响；不得写“579 个 PR 都合并了”。不额外批量 close、评论、改 base 或触发重跑来美化结果。平台拒绝删除时保留拒绝原因，不改 PR/保护去绕过。

自动删除候选是允许的预期 side effect；postmerge H 只应出现 main B→S 和候选可能消失，再加有独立并发说明的变化。候选不存在时不把旧 ref 放入删除 batch；候选仍存在时必须以其新鲜非零 tip 单列，不能直接按旧 C 执行。

## 6. 冻结可删除集合，使用普通 push 的 advertised-old 约束

在 archive 远端核验与上述 merge 结果完成后重新读取 heads、所有 branch protection/rulesets 和 PR。把当前 main、legacy 及任何其他不允许删除的 ref 排除。每个可删除 ref 必须有精确 SHA、ledger disposition、archive 可达性和最新保护判断；新 ref 或新 tip 先留存并补审/补归档，不能仅因为名字相似就删除。

旧 908 基线下，候选已自动删除则最多 905 个可删除 refs；未自动删除则最多 906。实际数量以该时刻 H 为准。成功删除全部可删侧分支后，至少仍有 main 与 legacy；legacy 的 allow_deletions=false 是明确未完成项，不能利用 enforce_admins=false 或 actor admin 权限删掉它。

推荐单一受限 push 连接；命令只作将来执行模板：

    /usr/bin/git -c core.hooksPath=<owned-reviewed-hook-directory> \
      -c push.followTags=false -c push.recurseSubmodules=no \
      push --verify --atomic --porcelain --no-follow-tags \
      --no-recurse-submodules origin \
      :refs/heads/<explicit-ref-1> :refs/heads/<explicit-ref-2> ...

不使用 force、force-with-lease、+refspec、mirror、wildcard prune、all、no-verify 或 REST Delete-ref。显式枚举全部 refspec，禁止给 main/tag 塞入“same-OID no-op”并称它能锁住该 ref。

preflight 固定一次实际 origin push URL，要求单个 canonical HTTPS repo 地址；拒绝 remote group、多 push URL、未解释 URL rewrite/helper 或其他跨连接行为。记录 Git 二进制/version/config 的相关身份；不打印凭据。--atomic 只对同一服务端连接中的 ref transaction 生效。服务器不支持时退出，不降级普通多次删除。若有限制必须分批，每批都重新冻结 H/保护与独立 receipts；不声称全批次跨连接原子。

## 7. pre-push guard 的精确责任

本包附离线纯函数草稿 deletion_advertisement_validator_draft.py，只验证一个完整已到 EOF 的 stdin。它没有文件/网络/Git调用，也不能直接安装成 hook；作为脚本执行会拒绝。未来完整 driver 还须完成上述所有外部 gate。

真正 hook 必须：

1. 固定计划文件 bytes/SHA，计划包含非空、有界、唯一的 fully qualified ref→非零旧 SHA 映射；main 与 legacy 为代码中的字面 deny，另合并新鲜 protected 集合。
2. 核两个 argv：实际 remote 名与 push URL。以有限字节数读到 EOF，检查实际四元组集合、唯一 ref 和精确数量。遗漏、重复、空输入、已消失 ref 的 old=zero 全拒绝。
3. 每行必须是 (delete)、newOID=全零、精确 remote ref 和冻结的非零 advertised oldOID。其他 update/create/tag/ref 一概拒绝。
4. 固定 owned hook/plan 哈希，检查普通可执行文件、专属目录身份。若现有必需 hook 存在，不删除/绕过；保留其执行及原 stdin/argv，任一非零即拒绝。未审现有 hook 时先停。
5. 保存 hook 确实被调用、原 stdin hash、完整集合判断、计划/脚本身份及退出状态。Git 在找不到 hook 时可以继续 push，所以 push exit0 本身不是 guard 运行证明。显式 --verify，结束后再核 hook/plan 身份。
6. driver 保存精确 argv、porcelain、stderr、权威退出码与独立远端 readback；不能因本地 ref 缺失或 hook 拒绝后进程状态不明就记删除成功。

正常 Git receive-pack 删除携带 advertised oldOID，服务器 transaction 再校验该旧值；配合 hook 的冻结值比较，可阻止目标 ref 在正常 advertisement/write 区间前进后被静默删除。这是每个被修改 ref 的约束，不锁未触 refs 或保护，也不检测 A→B→A。官方实现还允许清理损坏/缺失旧对象时放弃 oldOID 比较；因此保证限定为已核实可解析且有 archive 保存的正常远端 commit 对象，不宣称对损坏服务器仍有无条件 CAS。

## 8. 成功、拒绝和未知结果的读回

正常删除只在同一批次全部 server statuses 成功、guard 实际运行、远端全部目标缺失且 main/archive/其他 refs 与冻结计划一致时计成功。任何 atomic 拒绝保留全部原记录；不自动换 REST、非 atomic 或 admin 途径。

网络超时或无权威终态：先只读获取 heads/tags、operation 日志和 hook receipt，区分全部未变、全部已删、未知/并发变化。不要自动重发相同删除。远端已缺失只证明当前状态，不足以归因是本执行成功；保留观察与归因限制。

删除后再次核 archive 的远端 tag 与目标 commit 身份、完整剩余 branches、main OID、保护及 PR inventory。存精确 removed map、remaining map、unexpected changes、被保护保留的 reason、API/push 原输出与时间。报告“只剩 main”必须真的只剩 main；当前 legacy 保护意味着不能提前作此承诺。

## 9. 官方依据与独立复审

- GitHub REST pull requests：sha、merge method、async UUID、bypass_rules 默认 false 与终态。
  https://docs.github.com/en/rest/pulls/pulls
- GitHub protected branches：required/strict checks、预期 app、线性历史、会话规则。
  https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches
- GitHub merging pull requests：draft、queue、合并后删 head 对其他 PR base 的影响。
  https://docs.github.com/en/pull-requests/how-tos/merge-and-close-pull-requests/merging-a-pull-request
- GitHub branch management 与自动删除：
  https://docs.github.com/en/pull-requests/how-tos/commit-changes/managing-branches-within-your-repository
  https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/configuring-pull-request-merges/managing-the-automatic-deletion-of-branches
- Git hooks / push / wire protocol：
  https://git-scm.com/docs/githooks
  https://git-scm.com/docs/git-push
  https://git-scm.com/docs/gitprotocol-pack
- Git v2.53.0 实现由 architecture_audit 独立只读复核：transport.c 的 omitted up-to-date hook rows、remote.c 的 missing deletion、receive-pack 的 oldOID transaction/损坏对象例外；这不是运行过一次真实 push 的证明。
  https://github.com/git/git/blob/v2.53.0/transport.c
  https://github.com/git/git/blob/v2.53.0/remote.c
  https://github.com/git/git/blob/v2.53.0/builtin/receive-pack.c

本包只运行 synthetic offline validator controls；没有 hook 安装、Git ref 写入、远端 mutation 或新 native/CI 运行。最终执行应写独立 execution receipt，避免把 receipt 本身算入它先前扫描/归档的自引用范围。
