import ast, difflib, hashlib, json, os, pathlib, re, subprocess, textwrap
stage=pathlib.Path("/tmp/proof-pq-d9fb-credit-fix")
audit=pathlib.Path("/tmp/proof-pq-d9fb-github-failures")
out=audit/"credit-wiring-validation"
out.mkdir(exist_ok=False)
workflow=".github/workflows/pon-credit-envelope.yml"
old=(audit/"source"/workflow).read_text()
new=(stage/workflow).read_text()
old_command='python3 scripts/ci/test_ci_source_integrity.py 2>&1 | tee "$OUT/source-integrity-controls.log"'
new_command='python3 -u scripts/ci/test_ci_source_integrity.py 2>&1 | tee "$OUT/source-integrity-controls.log"'
assert old.count(old_command)==1 and new==old.replace(old_command,new_command)
records=json.loads((audit/"credit-staged-source-index.json").read_text())
def verify_sources():
    result=[]
    for row in records:
        raw=(stage/row["path"]).read_bytes()
        actual=hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
        assert actual==row["git_blob"],row["path"]
        result.append({**row,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()})
    return result
before=verify_sources()
parsed=ast.parse((stage/"scripts/ci/test_ci_source_integrity.py").read_text())
required=sorted(node.name for node in ast.walk(parsed) if isinstance(node,ast.FunctionDef) and node.name.startswith("test_"))
assert len(required)==len(set(required))==43
# Execute the unmodified per-log parser body; this is explicitly one log,
# not completion of the other three retained workflow suites.
start=old.index("              text = (Path(os.environ['OUT'])/name).read_text()")
end=old.index("\n          PY",start)
parser_body=textwrap.dedent(old[start:end])
assert "terminal = re.search" in parser_body and r"OK\s*\Z" in parser_body
(out/"original-single-log-parser.py").write_text(parser_body+"\n")
env=os.environ.copy()
env.pop("PYTHONUNBUFFERED",None)
env["PYTHONDONTWRITEBYTECODE"]="1"
observations=[]
for mode,command in (("buffered-original",old_command),("unbuffered-fix",new_command)):
    target=out/mode
    target.mkdir()
    child_env={**env,"OUT":str(target)}
    argv=["/bin/bash","-c","set -euo pipefail\n"+command]
    p=subprocess.run(argv,cwd=stage,env=child_env,capture_output=True)
    (target/"command.stdout").write_bytes(p.stdout)
    (target/"command.stderr").write_bytes(p.stderr)
    raw=(target/"source-integrity-controls.log").read_bytes()
    text=raw.decode()
    matches=re.findall(r"^Ran (\d+) tests? in ",text,re.M)
    names=re.findall(r"^(test_\w+) \(__main__\.TrackedSourceTests\.\1\) \.\.\. ",text,re.M)
    assert p.returncode==0 and matches==["43"] and sorted(names)==required
    assert not re.search(r"^(?:FAIL:|ERROR:|FAILED \(|OK \(skipped=)",text,re.M)
    parser_env={**child_env,"TESTED_PARSER":str(out/"original-single-log-parser.py")}
    parser_argv=["python3","-B","-c","import os,re; from pathlib import Path; name='source-integrity-controls.log'; exec(compile(Path(os.environ['TESTED_PARSER']).read_text(),'<original-per-log-parser>','exec'))"]
    q=subprocess.run(parser_argv,cwd=stage,env=parser_env,capture_output=True)
    (target/"parser.stdout").write_bytes(q.stdout)
    (target/"parser.stderr").write_bytes(q.stderr)
    observations.append({"mode":mode,"argv":argv,"cwd":str(stage),"test_exit_code":p.returncode,
                         "required_names":required,"actual_started_names":sorted(names),"actual_test_count":43,
                         "parser_exit_code":q.returncode,"log_sha256":hashlib.sha256(raw).hexdigest(),
                         "log_bytes":len(raw),"last_output_lines":text.splitlines()[-8:]})
    if mode=="buffered-original":
        assert q.returncode==1 and b"missing, empty, skipped or unsuccessful suite: source-integrity-controls.log" in q.stderr
    else:
        assert q.returncode==0 and re.search(r"Ran 43 tests in [0-9.]+s\n\nOK\s*\Z",text)
    print(json.dumps({"mode":mode,"test_exit_code":p.returncode,"actual_test_count":43,"parser_exit_code":q.returncode}),flush=True)
after=verify_sources()
assert before==after
patch="".join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile="a/"+workflow,tofile="b/"+workflow))
assert sum(line.startswith("+") and not line.startswith("+++") for line in patch.splitlines())==1
assert sum(line.startswith("-") and not line.startswith("---") for line in patch.splitlines())==1
(audit/"credit-unbuffered.patch").write_text(patch)
summary={"schema":"trnm-credit-unbuffered-wiring-observation-v1","source_commit":"0101b0ce76239832e0b2d19d0fd3f07e40fabeb4",
         "result":"PASS_SCOPED_WIRING_CONTROL","changes":{"files":1,"added_lines":1,"removed_lines":1},
         "source_inputs":before,"source_inputs_unchanged":True,"observations":observations,
         "scope":"original 43 real Git/filesystem tests twice and unmodified single-log terminal predicate",
         "other_three_retained_suites_executed":False,"whole_workflow_completed":False,"native_runtime_validated":False,
         "qualification":"HOLD_NO_GO","production_activation":False}
(out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps({"summary":str(out/"summary.json"),"patch":str(audit/"credit-unbuffered.patch"),"result":summary["result"]}),flush=True)
