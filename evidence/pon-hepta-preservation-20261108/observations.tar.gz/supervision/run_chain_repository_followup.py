from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

workspace = Path('/workspace/scratch/ac851b3fedf0')
root = workspace / 'chain-integrated'
out = workspace / 'chain-validation-repository-tmpdir-91dd3082'
out.mkdir(exist_ok=False)
tmp = workspace / 'chain-repository-fixture-temp'
tmp.mkdir(exist_ok=False)
head = '91dd3082633ea0b3a5ec9b0ed91f28603229be01'
env = os.environ.copy()
env.update({
    'RUSTUP_HOME': str(workspace / 'toolchains/rustup'),
    'CARGO_HOME': str(workspace / 'toolchains/cargo'),
    'CARGO_TARGET_DIR': str(workspace / 'target-chain-integrated'),
    'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0',
    'RUST_TEST_THREADS': '1', 'CARGO_TERM_COLOR': 'never',
    'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': str(tmp),
})
env['PATH'] = str(workspace / 'toolchains/cargo/bin') + os.pathsep + env['PATH']
for line in (workspace / 'provider/provider.env').read_text().splitlines():
    key, value = line.split('=', 1)
    env[key] = value
env['TRNM_GROUPED_NATIVE'] = str(workspace / 'target-chain-integrated/debug/examples/pon_routed_int257_grouped')
original_path = workspace / 'chain-validation-runtime-91dd3082/repository-controls.json'
original = json.loads(original_path.read_text())
command = ['python3', '-u', '-B', 'scripts/ci/test_repository.py']
if original['argv'] != command or original['status'] != 'command_failed':
    raise SystemExit('Unexpected original failed observation')
context = {
    'schema': 'trnm-repository-fixture-environment-followup-v1',
    'source': head, 'argv': command, 'automatic_retry': False,
    'reason': 'Original full repository-control fixture copy failed with ENOSPC in shared /tmp tmpfs.',
    'original_receipt_sha256': hashlib.sha256(original_path.read_bytes()).hexdigest(),
    'original_log_sha256': original['log_sha256'],
    'original_receipt': str(original_path),
    'original_status_preserved': True,
    'explicit_environment_change': {'TMPDIR': str(tmp)},
    'source_tests_and_thresholds_changed': False,
    'resource_acceptance_claim': False,
    'filesystem_before': subprocess.check_output(['df', '-PT', '/tmp', str(tmp)], text=True),
}
(out / 'environment.json').write_text(json.dumps(context, indent=2) + '\n')
argv = ['python3', '-u', '-B', 'scripts/ci/record_pq_native_command.py',
        '--kind', 'head', '--candidate', head, '--tested', head,
        '--label', 'repository-controls', '--output', str(out), '--'] + command
result = subprocess.run(argv, cwd=root, env=env, text=True, capture_output=True)
(out / 'repository-controls.recorder.log').write_text(result.stdout + result.stderr)
receipt = json.loads((out / 'repository-controls.json').read_text())
context.update({
    'recorder_exit_code': result.returncode,
    'followup_status': receipt['status'], 'followup_exit_code': receipt['exit_code'],
    'same_argv': receipt['argv'] == original['argv'],
    'same_complete_source': receipt.get('before') == original['before'] == receipt.get('after'),
    'filesystem_after': subprocess.check_output(['df', '-PT', '/tmp', str(tmp)], text=True),
})
(out / 'environment.json').write_text(json.dumps(context, indent=2) + '\n')
print(json.dumps(context, indent=2), flush=True)
sys.exit(result.returncode)
