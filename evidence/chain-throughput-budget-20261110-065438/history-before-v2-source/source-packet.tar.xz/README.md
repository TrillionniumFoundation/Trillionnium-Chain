# Budget before v2 source package

This reconstructs intentionally old production plus the identical current seven budget controls. It is not native execution evidence and it does not qualify an old source against the current corpus. No budgets, deadlines, callbacks, accounting predicates or application policy are altered in the old production baseline.

The immutable parent is the pool-only negative-control commit `db93026b9314bfd8bc4350945036998f1b7d34aa` (tree `379f05bda52b20130e5d895788f0613aa680472c`). The production baseline is G0 `d6bbac6baf9e5356721ab56f7432058d07b6b49b` (tree `653b1a8b483ccdbf69b272255ec0369d98296302`).

`build_prefixtest.py --repo /path/to/repo` reads only those immutable Git blobs, the saved exact pool test-hook insertions and the pinned common History test. It reconstructs the six replacement files under `replacement-source/` and emits `from-pool-h0.patch` against the parent. The four production files are `ingress.rs`, `ingress/history_import.rs`, `mining.rs` and `store.rs`. Their only additions to G0 are cfg(test) observations/module wiring. Removing the explicit inserted test text restores each original G0 file byte for byte; the exact hashes and insertion counts are in `binding.json`.

The fifth restored file, `ingress/history_import_tests.rs`, retains G0's existing test API calls and common detached-budget module declaration. It must accompany the old ingress implementation because the later private `SharedAdmissionExecution` API does not exist in G0. This is the unmodified original G0 test file, not an API stand-in.

The sixth replacement is the exact current `history_import_detached_budget_tests.rs`, SHA-256 `8481cd8ace6188f0d8874de62bebc7f887739a650e802dc695b04b330a2176fa`. The new before-epoch-close cfg(test) observation is identical in old and fixed production. Its read-only settled-account data is captured before any intentional last-epoch crash fence. All CPU arithmetic, native W1 replays, five-second original deadline and resource controls remain actual. The negative assertion is at line 221 and requires the original detached refusal; failures in setup, settlement identity or crash-fence assertions must not qualify as the intended negative control.

The parent's seven pool tests and its nine observation calls remain present so the parent tree can be retained. They are not executed or claimed as budget-arm outcomes. The inherited mempool, error, scalar-accounting and mining-test inputs are checked against G0 plus the exact pool hooks in `binding.json`. The four common mining budget tests remain byte-identical to G0 and fixed source.

The five new scalar handoff controls exercise a new private API and run only on fixed source. They are not present or claimed in this old budget arm. There is no stubbed implementation in the old source.

The package builder's strip-and-restore checks succeeded. A temporary directory containing only the six immutable parent files was used for an actual `git apply --check`, application and byte-for-byte comparison with all six generated replacements; `verification.json` records those checks. No full worktree or Cargo build was created. Native compilation and test outcomes remain `NOT_RUN`.
