#!/usr/bin/env python3
"""Capture exact local validation; a business refusal stays a refusal."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/1790ff0f3cc3/chain')
OUT = Path('/workspace/scratch/1790ff0f3cc3/work/frozen/native')
HEAD = 'c54e1e325b3174b0f671bb064ab8b07924cba62d'
OUT.mkdir(parents=True, exist_ok=False)
env = os.environ.copy()
env['PATH'] = '/root/.cargo/bin:' + env['PATH']
env['CARGO_HOME'] = '/workspace/scratch/1790ff0f3cc3/work/cargo-home'
env['CARGO_TARGET_DIR'] = '/workspace/scratch/1790ff0f3cc3/work/cargo-target'
env['CARGO_BUILD_JOBS'] = '2'
env['CARGO_NET_OFFLINE'] = 'true'
record = dict(schema='pon-architecture-frozen-local-validation-v1',
              source_commit=HEAD, source_tree='848872af917fc085696c94f98b35ab85b99af38b',
              cwd=str(ROOT), runs=[], production_activation=False,
              ci_flags_modified=False, kernel_host_configuration_modified=False,
              cargo_environment={key: env[key] for key in ('CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE')},
              observed_ci_flags={key: os.environ.get(key) for key in ('CI','GITHUB_ACTIONS','TRNM_PUBLIC_FIXTURE_HOST_CHILD')})

def save():
    (OUT/'commands.json').write_text(json.dumps(record, indent=2)+'\n')

def run(name, command, timeout=180, required=True):
    row = dict(name=name, command=command, timeout_seconds=timeout, required_local_control=required,
               started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    start = time.perf_counter_ns()
    with (OUT/(name+'.stdout')).open('wb') as stdout, (OUT/(name+'.stderr')).open('wb') as stderr:
        try:
            process = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, timeout=timeout)
            row.update(exit_code=process.returncode, timed_out=False)
        except subprocess.TimeoutExpired:
            row.update(exit_code=None, timed_out=True)
    row['wall_ns'] = time.perf_counter_ns()-start
    for stream in ('stdout','stderr'):
        path=OUT/(name+'.'+stream)
        row[stream] = dict(path=path.name, bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    record['runs'].append(row)
    save()
    print(json.dumps({key:row[key] for key in ('name','exit_code','timed_out','wall_ns')}),flush=True)
    return row

assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
run('preflight',['bash','scripts/project-preflight.sh'])
run('source-before',['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',HEAD,'--output',str(OUT/'source-before.json')])
run('rustc-version',['rustc','--version','--verbose'])
run('cargo-version',['cargo','--version'])
run('cargo-metadata',['cargo','metadata','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','--format-version','1'])
common=['cargo','test','--locked','--release','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--test','architecture_delivery_compare']
run('native-build',common+['--no-run','--message-format=json'],timeout=900)
run('native-components',common+['--','--skip','signed_dag_delivery_comparison_uses_same_native_business_and_confirmation_contract','--nocapture','--test-threads=1'])
run('clippy',['cargo','clippy','--locked','--release','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--test','architecture_delivery_compare','--','-D','warnings'],timeout=900)
run('format',['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'])
run('distributed-inventory',['python3','-B','scripts/refresh_distributed_source_inventory.py','--check'])
run('business-execution-owner',['python3','-B','formal/pon-nakamoto-v1/experiments/architecture_compare.py','--out',str(OUT/'business')],timeout=1250,required=False)
run('repository-contract',['python3','-B','scripts/ci/check_repository.py'])
run('diff-check',['git','diff','--check'])
run('source-after',['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',HEAD,'--output',str(OUT/'source-after.json')])
record['required_local_controls_passed']=all(row['exit_code']==0 and not row['timed_out'] for row in record['runs'] if row['required_local_control'])
record['business_execution_passed']=next(row for row in record['runs'] if row['name']=='business-execution-owner')['exit_code']==0
record['business_pass_is_original_4s_16_hostile_w1_acceptance']=False
save()
raise SystemExit(0 if record['required_local_controls_passed'] else 1)
