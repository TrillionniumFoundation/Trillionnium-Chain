#!/usr/bin/env python3
"""Read back all four completed W1 research artifact payloads without rerunning them."""
from pathlib import Path, PurePosixPath
import ast
import hashlib
import json
import re
import stat
import zipfile

ROOT = Path(__file__).resolve().parent
HEAD = "12fe5f2c1f19704fe7eb635dede6839ed8b1e91e"
BASE = "2e72a989d001cf51bd0aed0e1401526e45db31f1"
MERGE = "0357031364787574cb7058b05329aa2e2730f947"
TREE = "c44112da731e3f958e55eb024e5762d6723ea2c9"
RUN = 41628135456
PARAMETERS = "ece5e9b8ae2cd6ea6b1827b464ff0348f9a7f4decd269c0087fdfd75098da013"
IMAGE = [4203990569,1706128024,889896351,2751765305,3434005897,1411617246,870515685,3215144349]
INPUTS = {
    "W1_HEADER": "7b96038f228a1eedccf7b29ffc54802aba691be7259e33937846c6bf6126d78f",
    "W1_RECEIPT": "ca4d3c9f5159b7001abae7491604cadbbbfa97c0f93d90d5943e48936813ca2b",
    "W1_LIFT": "d2b06a1feca2d15e8dc5741b43f481a82c32d7d3dab01e413d357012467093d3",
}
CONTROL_NAMES = {
    "valid","trailing","truncated","declared_seal_length_overflow",
    "composite_tag","groth16_tag","fake_tag","wrong_header",
    "journal_byte_0","journal_byte_20","journal_byte_338","journal_byte_370",
    "journal_byte_402","journal_byte_16817","control_id","verifier_parameters",
    "hash_function","hash_function_sha256","hash_function_blake2b","claim_digest",
    "seal_first","seal_body","seal_last","seal_empty","seal_short","seal_invalid_field",
}
TEST_NAMES = {
    "tests::rejects_non_succinct_tags_before_deserialization",
    "tests::short_public_statement_cannot_panic_or_authorize_work",
    "tests::frozen_context_contains_only_the_measured_succinct_profile",
    "tests::profile_selection_refuses_other_suites_and_parameter_sets",
}
LANES = [
    ("x64-head","X64","head",125890592176,13226234301,"w1-x64-head-13226234301.zip"),
    ("x64-merge","X64","prospective-merge",125890591419,13226169545,"w1-x64-merge-13226169545.zip"),
    ("arm-head","ARM64","head",125890592077,13226363199,"w1-arm-head-13226363199.zip"),
    ("arm-merge","ARM64","prospective-merge",125890591942,13225943961,"w1-arm-merge-13225943961.zip"),
]
MANIFEST = "formal/pon-nakamoto-v1/w1_hardened_verifier/Cargo.toml"
HEADER = "evidence/pon-w1-complete-succinct-20261028/full-proof/header.bin"
RECEIPT = "evidence/pon-w1-complete-succinct-20261028/full-proof/succinct.bin"
LIFT = "evidence/pon-w1-verifier-hardening-20261028/real-lift-0000.bin"
BIN = "/home/runner/work/_temp/pq-w1-verifier-target/release/trnm-w1-hardened-verifier"
OUT = "/home/runner/work/_temp/pq-w1-verifier-records"
COMMANDS = {
    "compiler": ["rustc","+1.95.0","-Vv"],
    "frozen-inputs": ["python3",OUT+"/verify-frozen-inputs.py"],
    "locked-graph": ["cargo","+1.95.0","metadata","--locked","--manifest-path",MANIFEST,"--format-version","1"],
    "format": ["cargo","+1.95.0","fmt","--manifest-path",MANIFEST,"--","--check"],
    "profile-tests": ["cargo","+1.95.0","test","--locked","--release","--manifest-path",MANIFEST],
    "build": ["cargo","+1.95.0","build","--locked","--release","--manifest-path",MANIFEST],
    "full-proof": [BIN,"verify",HEADER,RECEIPT],
    "full-controls": [BIN,"controls",HEADER,RECEIPT,OUT+"/full-controls"],
    "require-controls": ["python3",OUT+"/require-controls.py"],
    "recursion-only": [BIN,"verify-recursion",LIFT],
    "require-recursion": ["python3",OUT+"/require-recursion.py"],
    "clippy": ["cargo","+1.95.0","clippy","--locked","--release","--manifest-path",MANIFEST,"--all-targets","--","-D","warnings"],
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def obj(path):
    return json.loads(path.read_bytes())

def require(ok, message):
    if not ok:
        raise AssertionError(message)

run = obj(ROOT/"api/run.json")
artifacts = {a["id"]:a for a in obj(ROOT/"api/artifacts.json")}
jobs = {j["id"]:j for j in obj(ROOT/"api/jobs.json")}
head = obj(ROOT/"api/head-commit.json")
merge = obj(ROOT/"api/merge-commit.json")
require(run["id"]==RUN and run["head_sha"]==HEAD and run["run_attempt"]==1, "run identity")
require(head["sha"]==HEAD and head["tree"]["sha"]==TREE, "head tree")
require([p["sha"] for p in head["parents"]]==["1c7e8ab7cd6a321cad4e6c7f7e8a197d7b3be14c"], "head parent")
require(merge["sha"]==MERGE and merge["tree"]["sha"]==TREE, "merge tree")
require([p["sha"] for p in merge["parents"]]==[BASE,HEAD], "actual merge parents")
for f in obj(ROOT/"api/source-files.json"):
    data=(ROOT/"source"/f["path"]).read_bytes()
    git=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
    require(git==f["git_blob_sha"], "fetched source blob "+f["path"])

lane_summaries=[]
member_inventory=[]
for lane,arch,kind,job_id,artifact_id,filename in LANES:
    a=artifacts[artifact_id]
    j=jobs[job_id]
    require(j["run_id"]==RUN and j["status"]=="completed" and j["conclusion"]=="success", lane+" job")
    require(all(s["status"]=="completed" and s["conclusion"]=="success" for s in j["steps"]),lane+" job steps")
    require(a["workflow_run"]["head_sha"]==HEAD and a["workflow_run"]["id"]==RUN and a["expired"] is False,lane+" artifact metadata")
    archive=ROOT/"artifacts"/filename
    archive_bytes=archive.read_bytes()
    require(len(archive_bytes)==a["size_in_bytes"] and "sha256:"+sha(archive_bytes)==a["digest"],lane+" original ZIP identity")
    with zipfile.ZipFile(archive) as z:
        require(z.testzip() is None,lane+" ZIP CRC")
        names=z.namelist()
        require(len(names)==len(set(names))==82,lane+" unique complete payload")
        for info in z.infolist():
            p=PurePosixPath(info.filename)
            require(not p.is_absolute() and ".." not in p.parts and not info.is_dir(),lane+" payload path")
            require(not stat.S_ISLNK(info.external_attr>>16),lane+" symlink")
            data=z.read(info)
            dest=ROOT/"lanes"/lane/info.filename
            dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists():
                require(dest.read_bytes()==data,lane+" retained member changed")
            else:
                dest.write_bytes(data)
            member_inventory.append({"lane":lane,"path":info.filename,"bytes":len(data),"sha256":sha(data)})
        read=lambda name:json.loads(z.read(name))
        source=read("source.json")
        expected_commit=HEAD if kind=="head" else MERGE
        require(source["schema"]=="trnm-ci-source-v1" and source["kind"]==kind,lane+" source schema/kind")
        require(source["candidate"]==HEAD and source["tested_commit"]==expected_commit and source["tested_tree"]==TREE,lane+" source commits")
        require(source["base"]==(None if kind=="head" else BASE),lane+" base")
        require(source["prospective_merge"]==(None if kind=="head" else MERGE),lane+" merge field")
        require(source["tracked_worktree_verified"] is True and source["tests_executed_by_identity_check"] is False,lane+" source flags")
        require(source["tracked_entries"]==6831 and source["tracked_bytes"]==782174381,lane+" tracked inventory")
        command_summaries=[]
        for label,argv in COMMANDS.items():
            record=read(label+".json")
            log=z.read(label+".log")
            require(record["schema"]=="trnm-pq-native-command-v1",lane+" command schema "+label)
            require(record["status"]=="command_succeeded" and record["exit_code"]==0,lane+" command result "+label)
            require(record["before"]==record["after"]==source,lane+" unchanged complete tracked source "+label)
            require(record["argv"]==argv,lane+" exact argv "+label)
            require(record["log_file"]==label+".log" and record["log_bytes"]==len(log) and record["log_sha256"]==sha(log),lane+" raw log identity "+label)
            require(record["whole_chain_quantum_security_qualified"] is False,lane+" qualification flag "+label)
            env=record["environment"]
            require(env["GITHUB_RUN_ID"]==str(RUN) and env["GITHUB_RUN_ATTEMPT"]=="1" and env["RUNNER_ARCH"]==arch,lane+" environment "+label)
            require(env["CARGO_BUILD_JOBS"]=="2" and env["CARGO_INCREMENTAL"]=="0",lane+" compiler settings "+label)
            require(all(env[k] is None for k in ["RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS","RUSTC","RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER"]),lane+" unexpected override "+label)
            command_summaries.append({"label":label,"exit_code":0,"log_sha256":sha(log),"log_bytes":len(log)})
        compiler=z.read("compiler.log").decode()
        require(compiler.startswith("rustc 1.95.0 "),lane+" compiler")
        require(("host: aarch64-unknown-linux-gnu" if arch=="ARM64" else "host: x86_64-unknown-linux-gnu") in compiler,lane+" compiler host")
        metadata_lines=[line for line in z.read("locked-graph.log").decode().splitlines() if line.startswith("{")]
        require(len(metadata_lines)==1,lane+" one complete Cargo metadata object")
        graph=json.loads(metadata_lines[0])
        sdk=[p for p in graph["packages"] if p["name"]=="risc0-zkvm"]
        require(len(sdk)==1 and sdk[0]["version"]=="3.0.6",lane+" locked SDK")
        tests=z.read("profile-tests.log").decode()
        require(set(re.findall(r"^test (\S+) \.\.\. ok$",tests,re.M))==TEST_NAMES,lane+" four executed units")
        require("test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;" in tests,lane+" complete unit totals")
        require(ast.literal_eval(z.read("frozen-inputs.log").decode())==INPUTS,lane+" actual frozen input hashes")
        full=read("full-proof.log")
        full_expected={
            "schema":"TRNM-W1-HARDENED-FULL-VERIFY1","sdk":"3.0.6",
            "outcome":"SAVED_FULL_SUCCINCT_STARK_VERIFIED","image_id":IMAGE,
            "hash_function":"poseidon2","verifier_parameters_digest":PARAMETERS,
            "receipt_sha256":INPUTS["W1_RECEIPT"],"header_sha256":INPUTS["W1_HEADER"],
            "receipt_bytes":256886,"seal_words":55667,
            "control_id":"7a8f24092c34ed3eb81b3d0a0b796c588c615d3488ef9e61c21dbd1e4b83ea6e",
        }
        full_expected["work_id"]="ccf544056c6df13a5ab4e6c021e587ff0008d92388270e64f72a6e2168a326cd"
        full_expected["journal_sha256"]="1d53c0d3c403492a1c52a345e64a579644c6ec77ff9a8decf18bd6a09c889b1a"
        require({k:full[k] for k in full_expected}==full_expected,lane+" full proof statement/profile")
        require(full["consensus_admission"] is False and full["production_tail_established"] is False,lane+" full qualification")
        require(full["independent_proof_trials"]==1 and full["proof_randomness_tickets"]==0,lane+" full work identity limits")
        controls=read("full-controls/result.json")
        require(controls==read("full-controls.log"),lane+" controls raw log and saved result")
        require(controls["schema"]=="TRNM-W1-HARDENED-VERIFIER-CONTROLS1" and controls["sdk"]=="3.0.6" and controls["image_id"]==IMAGE,lane+" controls profile")
        rows=controls["cases"]
        require(len(rows)==26 and {r["name"] for r in rows}==CONTROL_NAMES,lane+" all original/new control names")
        require(controls["all_passed"] is True and controls["fake_proofs_used"] is False and controls["consensus_admission"] is False,lane+" control flags")
        for row in rows:
            name=row["name"]
            expected="ACCEPT" if name=="valid" else "REJECT"
            require(row["passed"] is True and row["expected"]==expected and row["observed"]["outcome"]==expected,lane+" actual control result "+name)
            require(sha(z.read("full-controls/"+name+".header"))==row["header_sha256"],lane+" exact control header "+name)
            require(sha(z.read("full-controls/"+name+".receipt"))==row["receipt_sha256"],lane+" exact control receipt "+name)
        lift=read("recursion-only.log")
        lift_expected={
            "schema":"TRNM-W1-RECURSION-ONLY-VERIFY2","sdk":"3.0.6",
            "hash_function":"poseidon2","verifier_parameters_digest":PARAMETERS,
            "receipt_sha256":INPUTS["W1_LIFT"],"receipt_bytes":223154,
            "control_id":"e7934a23ddce1423b425cf32aa23be29f48cd40e0b6ff9376dce6f3bf9d0bc35",
        }
        require({k:lift[k] for k in lift_expected}==lift_expected,lane+" real lift identity/profile")
        require(lift["result"]["outcome"]=="ACCEPT" and lift["complete_w1_claim"] is False and lift["consensus_admission"] is False,lane+" lift outcome/limits")
        job_log=(ROOT/"job-logs"/(str(job_id)+".log")).read_bytes()
        job_lines=job_log.decode("utf-8-sig").splitlines()
        checkout_positions=[i for i,line in enumerate(job_lines) if "[command]/usr/bin/git log -1 --format=%H" in line]
        require(len(checkout_positions)==1,lane+" one checkout identity output")
        checkout_line=job_lines[checkout_positions[0]+1]
        require(checkout_line.split()[-1]==expected_commit,lane+" actual checkout commit")
        summary={
            "lane":lane,"architecture":arch,"kind":kind,"job_id":job_id,
            "artifact_id":artifact_id,"artifact_name":a["name"],
            "artifact_zip_bytes":len(archive_bytes),"artifact_zip_sha256":sha(archive_bytes),
            "artifact_payload_members":len(names),"source":source,
            "command_receipts_checked":command_summaries,
            "unit_tests":{"passed":4,"failed":0,"ignored":0,"filtered":0},
            "full_receipt":"VERIFIED","controls":{"passed":26,"accepted":1,"rejected":25,"panics":0},
            "real_prefix_lift":"VERIFIED","strict_clippy":"PASS","format":"PASS","locked_graph":"PASS",
            "recursion_complete_w1_claim":False,"consensus_admission":False,
            "job_log_bytes":len(job_log),"job_log_sha256":sha(job_log),
            "artifact_payloads_preserved_byte_for_byte":True,
        }
        lane_summaries.append(summary)
summary={
    "schema":"trnm-hosted-w1-artifact-readback-v1","run_id":RUN,"run_attempt":1,
    "candidate":HEAD,"base":BASE,"prospective_merge":MERGE,"tested_tree":TREE,
    "lanes":lane_summaries,"complete_lanes_verified":4,
    "whole_chain_quantum_security_qualified":False,"consensus_admission":False,
    "native_network_witness_jobs_not_qualified_by_this_record":True,
    "readback_performed":"Downloaded ZIP identity, all payloads, raw command/log hashes and results; no new proof execution",
    "compiled_verifier_binaries_in_hosted_artifacts":False,
}
(ROOT/"artifact-member-sha256.json").write_text(json.dumps(member_inventory,indent=2)+"\n")
(ROOT/"readback-summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps({"complete_lanes_verified":4,"source_head":HEAD,"source_merge":MERGE,"source_tree":TREE,
    "per_lane":[{"lane":x["lane"],"commands":len(x["command_receipts_checked"]),"unit_tests":4,"controls":26,"full_receipt":"VERIFIED","real_lift":"VERIFIED","strict_clippy":"PASS"} for x in lane_summaries],
    "preserved_payload_files":len(member_inventory)},indent=2))
