import difflib,hashlib,json,os,re,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
positive=Path('/tmp/chain-pq-fa62381e')
negative=Path('/tmp/chain-pq-negative-fa62381e')
out=Path('/tmp/chain-pq-negative-source-fa62381e-s3')
S3='454ae116159867ff6cddd91b964523df7f7e16f0'
OLD_S2='3c98e08e92094bb79ac811b682192d7252a7c325'
BASE='6c35f94d9387fac41c1547f05742d70150320b2e'
assert negative.is_dir() and not out.exists(), 'existing clean negative checkout and fresh lineage output required'
def git(root,*args,text=True):
    return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root,text=text)
assert git(positive,'rev-parse','HEAD').strip()==S3
assert git(negative,'rev-parse','HEAD').strip()==OLD_S2
assert not git(negative,'status','--porcelain','--untracked-files=all').strip()
assert not git(positive,'status','--porcelain','--untracked-files=all').strip()
assert re.fullmatch('[0-9a-f]{40}',S3), 'frozen actual S3 required'
out.mkdir()
def logged(label,command,cwd):
    with (out/(label+'.log')).open('xb') as stream:
        value=subprocess.run(command,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT)
    assert value.returncode==0, label+' failed; preserve log'
logged('positive-preflight',['bash','scripts/project-preflight.sh'],positive)
sys.path.insert(0,str(positive/'scripts/ci'))
from verify_ci_source import verify
positive_before=verify('head',S3,root=positive)
negative_preparation_base=verify('head',OLD_S2,root=negative)
logged('negative-fetch-frozen-source',['git','fetch','--no-tags','--no-write-fetch-head',str(positive),S3],negative)
logged('negative-checkout',['git','switch','-c','fix/chain-pq-negative-fa62381e-s3',S3],negative)
assert git(negative,'config','--get','remote.origin.url').strip()==git(positive,'config','--get','remote.origin.url').strip()
logged('negative-preflight',['bash','scripts/project-preflight.sh'],negative)
ingress='trillionnium/crates/trnm-pon-node/src/ingress.rs'
witness='trillionnium/crates/trnm-pon-node/src/pq_rollback_witness.rs'
base_ingress=git(negative,'show',BASE+':'+ingress)
current_ingress=git(negative,'show',S3+':'+ingress)
header='fn require_classical_network_settings(settings: &Settings) -> Result<()> {'
pattern=re.compile('(?ms)^'+re.escape(header)+r'\n.*?^\}')
old=pattern.findall(base_ingress)
new=pattern.findall(current_ingress)
assert len(old)==len(new)==1 and old[0]!=new[0]
assert old[0]=='''fn require_classical_network_settings(settings: &Settings) -> Result<()> {
    ensure(
        !settings.app.is_pq_account_profile(),
        "AUTH_CLASSICAL_FOR_PQ_PROFILE",
    )
}'''
changed=current_ingress.replace(new[0],old[0],1)
assert changed.count('mod account_scope_tests;')==1
relative_diff=list(difflib.unified_diff(base_ingress.splitlines(),changed.splitlines()))
removed=[line[1:] for line in relative_diff if line.startswith('-') and not line.startswith('---') and line[1:].strip()]
added=[line[1:] for line in relative_diff if line.startswith('+') and not line.startswith('+++') and line[1:].strip()]
module_block='#[cfg(test)]\nmod account_scope_tests;\n\n'
assert changed.count(module_block)==1 and changed.replace(module_block,'',1)==base_ingress, relative_diff
(negative/ingress).write_text(changed)
old_witness=git(negative,'show',BASE+':'+witness,text=False)
assert git(negative,'rev-parse',BASE+':'+witness).strip()=='56359fb2b597fcf7cfbb39d6288e9b0d0c030389'
assert git(negative,'rev-parse',S3+':'+witness).strip()=='89a0acf1f7851822fc3b54fdcf7a91596252ec98'
(negative/witness).write_bytes(old_witness)
assert git(negative,'diff','--name-only').splitlines()==[ingress,witness]
logged('negative-diff-check',['git','diff','--check'],negative)
for key in ('user.name','user.email'):
    configured=subprocess.run(['git','config','--get',key],cwd=negative,capture_output=True,text=True)
    if configured.returncode:
        value=git(positive,'config','--get',key).strip()
        assert value
        subprocess.run(['git','config',key,value],cwd=negative,check=True)
logged('negative-precommit-preflight',['bash','scripts/project-preflight.sh'],negative)
subprocess.run(['git','add','--',ingress,witness],cwd=negative,check=True)
logged('negative-commit',['git','commit','-m','test: restore pre-fix guards for isolated negative controls'],negative)
N=git(negative,'rev-parse','HEAD').strip()
assert git(negative,'rev-parse','HEAD^').strip()==S3
assert git(negative,'diff-tree','--no-commit-id','--name-only','-r',N).splitlines()==[ingress,witness]
negative_identity=verify('head',N,root=negative)
positive_after=verify('head',S3,root=positive)
assert positive_after==positive_before
account='trillionnium/crates/trnm-pon-node/src/ingress/account_scope_tests.rs'
witness_tests='trillionnium/crates/trnm-pon-node/src/pq_rollback_witness/tests.rs'
for path in (account,witness_tests,'trillionnium/Cargo.lock','tests/fuzz/Cargo.lock',
             'config/pon/pq-system-required-tests-v1.json','config/pon/pq-system-supplemental-tests-v1.json'):
    assert git(negative,'show',N+':'+path,text=False)==git(negative,'show',S3+':'+path,text=False),path
account_raw=(negative/account).read_text()
assert account_raw.splitlines()[68].strip()=='.unwrap_err();'
assert account_raw.splitlines()[85].strip()=='let error = authenticate_request(&wire, &settings, &server).unwrap_err();'
assert account_raw.splitlines()[147].strip()=='assert_eq!('
witness_raw=(negative/witness_tests).read_text()
live_at=witness_raw.index('retry.advance(forged, next).unwrap_err().to_string(),')
cold_start=witness_raw.index('fn cold_reopen_refuses_database_retry_history_and_accepts_new_successors()')
cold_at=witness_raw.index('.unwrap_err()',cold_start)
unwrap_marker='called '+chr(96)+'Result::unwrap_err()'+chr(96)+' on an '+chr(96)+'Ok'+chr(96)+' value'
expected=[
{'test':'ingress::account_scope_tests::invalid_account_scope_refuses_classical_session_and_signed_request','source_file':account,'panic_line':69,'markers':[unwrap_marker]},
{'test':'ingress::account_scope_tests::current_local_scope_refuses_previously_valid_classical_request','source_file':account,'panic_line':86,'markers':[unwrap_marker]},
{'test':'ingress::account_scope_tests::invalid_account_scope_never_connects_or_advances_classical_clients','source_file':account,'panic_line':148,'markers':['authenticated production_activation-wrong, protected=false','left: 1','right: 0']},
{'test':'pq_rollback_witness::tests::live_retry_refuses_changed_durable_predecessor_at_the_same_head','source_file':witness_tests,'panic_line':witness_raw[:live_at].count('\n')+1,'markers':[unwrap_marker]},
{'test':'pq_rollback_witness::tests::cold_reopen_refuses_database_retry_history_and_accepts_new_successors','source_file':witness_tests,'panic_line':witness_raw[:cold_at].count('\n')+1,'markers':[unwrap_marker]},
]
(out/'negative-source.diff').write_bytes(git(negative,'diff','--binary','--full-index',S3,N,text=False))
logged('negative-bundle',['git','bundle','create',str(out/'negative-source.bundle'),'HEAD','^'+S3],negative)
logged('negative-bundle-verify',['git','bundle','verify',str(out/'negative-source.bundle')],negative)
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
critical=[ingress,witness,account,witness_tests,'trillionnium/Cargo.lock','tests/fuzz/Cargo.lock',
'config/pon/pq-system-required-tests-v1.json','config/pon/pq-system-supplemental-tests-v1.json',
'scripts/ci/record_pq_native_command.py','scripts/ci/pinned_native_process.py',
'scripts/ci/ci_observation.py','scripts/ci/verify_ci_source.py']
report={'schema':'trnm-isolated-pq-negative-source-v1','positive_source':S3,'base_behavior_source':BASE,
'negative_source':N,'negative_tree':git(negative,'rev-parse','HEAD^{tree}').strip(),
'changed_paths':[ingress,witness],'negative_preparation_base_source':OLD_S2,'negative_preparation_base_identity':negative_preparation_base,'positive_source_before':positive_before,
'positive_source_after':positive_after,'negative_source_identity':negative_identity,
'failure_expectations':expected,'native_tests_executed':False,
'source_files_sha256':{path:sha(negative/path) for path in critical},
'whole_chain_quantum_security_qualified':False,'production_activation':False,
'qualification_scope':'isolated intentionally regressed source for seven named controls only',
'artifact_sha256':{p.name:sha(p) for p in out.iterdir() if p.is_file()}}
(out/'source-lineage.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'negative_source':N,'positive_source':S3,'changed_paths':[ingress,witness],
'failure_expectations':expected,'output':str(out),'positive_source_unchanged':True,
'native_build_started':False},sort_keys=True))