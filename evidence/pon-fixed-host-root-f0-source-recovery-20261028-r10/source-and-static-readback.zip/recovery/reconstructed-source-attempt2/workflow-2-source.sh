set -euo pipefail
python3 scripts/ci/verify_ci_source.py --kind head --expected-head "$EXPECTED_HEAD" --output "$OUT/source-before.json" > "$OUT/source-before.log" 2>&1
expected_tree="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["tested_tree"])' "$OUT/source-before.json")"
printf 'EXPECTED_TREE=%s\n' "$expected_tree" >> "$GITHUB_ENV"
bash scripts/project-preflight.sh --audit 2>&1 | tee "$OUT/preflight.log"
python3 -m unittest discover -s scripts/ci -p 'test_native_phase_host.py' -v 2>&1 | tee "$OUT/original-launcher-controls.log"
python3 -m unittest discover -s scripts/ci -p 'test_fixed_root*.py' -v 2>&1 | tee "$OUT/f0-source-controls.log"
