import hashlib,json,math,os,statistics,subprocess,sys
from pathlib import Path
ROOT=Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
BASE=ROOT/"common-rayon2-abba-A-01"
OUT=ROOT/"common-rayon2-abba-observation-02"
data=json.load(sys.stdin)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
 p=Path(p);return {"path":str(p),"sha256":sha(p),"bytes":p.stat().st_size}
def read(p):return json.loads(Path(p).read_text())
def need(v,m):
 if not v:raise ValueError(m)
def save(path,value):
 with Path(path).open("x",encoding="utf-8") as f:json.dump(value,f,sort_keys=True,indent=2,allow_nan=False);f.write("\n");f.flush();os.fsync(f.fileno())
def raw_save(path,text):
 with Path(path).open("x",encoding="utf-8") as f:f.write(text);f.flush();os.fsync(f.fileno())
need(not OUT.exists(),"new readback output only")
OUT.mkdir()
raw_save(OUT/"readback02.py",data["script_text"])
raw_save(OUT/"first-readback-terminal.json",data["first_failure_terminal_text"])
raw_save(OUT/"first-readback-stderr.log",data["first_failure_stderr"])
save(OUT/"first-readback-request.json",data["first_request"])
terminal=json.loads(data["terminal_text"])
need(terminal["job_id"]=="1a1b7cc14c0-12894-c57" and terminal["state"]=="succeeded" and type(terminal["exit_code"]) is int and terminal["exit_code"]==0,"actual successful terminal")
need(terminal["output_complete"] is True and terminal["output_durable"] is True and terminal["timed_out"] is False and terminal["cancelled"] is False,"complete durable terminal")
main_pin=pin(BASE/"result.json")
need(main_pin["sha256"]=="4394fef1f6f862bae295ba53dfcf29cdcafb28e502dfc6fd40c773ecfd92c98f","main raw hash")
main=read(main_pin["path"])
need(main["operation_complete"] is True and main["error"] is None and main["cancellation_event"] is None and main["canceled_signal"] is None and main["audit_errors"]==[],"main success facts")
need(main["owned_scope_closed_observed"] is True and main["deadline_exhausted_at_snapshot"] is False,"owned closure and deadline")
need(main["fresh_proof_generations"]==0 and main["main_generation_deadline_extended"] is False,"zero generation and no original extension")
need(main["local_cost_deadline_monotonic_ns"]-main["local_cost_started_monotonic_ns"]==600000000000,"original local600")
binding_pin=pin(ROOT/"common-rayon2-abba-binding-01/binding.json")
need(binding_pin["sha256"]=="8a3f3961e29692b7ade104b5060a40d0f467853031d776dd66e8ddb7b6f8a7af","binding pin")
binding=read(binding_pin["path"])
order=["native","proof","proof","native"]*10
ledger=main["planned_rows"]
need(len(ledger)==80 and all(x["dispatched"] is True and x["accepted"] is True and x["state"]=="ACCEPTED" for x in ledger),"all eighty explicit rows")
sidecars=[str(p) for p in BASE.rglob("operation-cancellation.json")]
need(sidecars==[],"no operation cancellation sidecars anywhere in study")
work_ids=set();journals=set();arms=[];row_pins=[]
for index,(record,arm) in enumerate(zip(main["arm_observations"],binding["arms"])):
 need(record["arm"]==arm["id"],"arm identity")
 comp=pin(record["comparison"]["path"])
 need(comp==record["comparison"],"raw comparison pinned")
 proc=pin(record["process"]["path"])
 need(proc==record["process"],"outer process pinned")
 process=read(proc["path"])
 need(process["stage_process_complete"] is True and process["returncode"]==0 and process.get("canceled_signal") is None and process["termination_reasons"]==[],"outer process completion")
 directory=Path(record["comparison_output_directory"])
 need(not (directory/"operation-cancellation.json").exists(),"no comparator cancellation")
 report=read(comp["path"])
 need(report["schema"]=="TRNM-W1-DEPLOYMENT-COMPARISON2","frozen comparator schema")
 cancel_field_state="ABSENT_BY_SCHEMA" if "cancellation_event" not in report else ("EXPLICIT_NULL" if report["cancellation_event"] is None else "OBSERVED")
 need(report["operation_complete"] is True and report["error"] is None and report.get("cancellation_event") is None and report["fresh_proof_generations"]==0 and report["deadline_exhausted_at_snapshot"] is False,"comparison complete through independent actual process/row/sidecar facts; absent optional field is not explicit false")
 need(report["planned_order"]==order and len(report["rows"])==40,"ABBA exact forty")
 for key in ("input","header","expected_artifacts"):
  need(report["identities"][key+"_sha256"]==binding["statement"][key]["sha256"],"same common external statement")
 need(report["identities"]["receipt_sha256"]==arm["receipt"]["sha256"] and pin(arm["receipt"]["path"])==arm["receipt"],"real receipt identity")
 need(report["identities"]["verifier_sha256"]=="582b53d8607cca6ec228c18de8047e1d6564f0fd9cd3cdeafa06c66f460ad3d5","actual verifier")
 journals.add(report["identities"]["journal_sha256"])
 for row_index,row in enumerate(report["rows"]):
  need(type(row["index"]) is int and row["index"]==row_index and row["kind"]==order[row_index] and row["dispatched"] is True and row["accepted"] is True,"canonical accepted row")
  stage_path=directory/("row-%04d-%s"%(row_index,row["kind"]))/"result.json"
  stdout_path=stage_path.parent/"stdout.log"
  stage=read(stage_path)
  observation_path=directory/("row-%04d-observation.json"%row_index)
  need(read(observation_path)==row,"original embedded/raw row exact")
  need(row["stage"]==stage,"embedded/raw stage exact")
  need(read(stdout_path)==row["verifier_report"],"actual verifier stdout exact")
  need(stage["schema"]=="TRNM-W1-STAGE-MEASUREMENT3" and stage["stage_process_complete"] is True and stage["returncode"]==0 and stage["termination_reasons"]==[] and stage["canceled_signal"] is None and stage["cancellation_event"] is None and stage["error"] is None and stage["deadline_exhausted_at_snapshot"] is False and stage["completion_observed_before_deadline"] is True and stage["owned_session_observation_complete"] is True and stage["cleanup_errors"]==[] and stage["final_owned_session_members"]==[],"real verifier process completion")
  need(sha(stdout_path)==stage["stdout_sha256"] and sha(stage_path.parent/"stderr.log")==stage["stderr_sha256"],"original verifier log SHA")
  need(stage["environment"]["RAYON_NUM_THREADS"]=="2","actual common Rayon2")
  need(type(row["inner_ns"]) is int and row["inner_ns"]>0,"actual positive integer inner timing")
  work_ids.add(row["verifier_report"]["work_id"])
  row_pins.append({"arm":arm["id"],"index":row_index,"kind":row["kind"],"row_observation":pin(observation_path),"stage":pin(stage_path),"verifier_stdout":pin(stdout_path),"verifier_stderr":pin(stage_path.parent/"stderr.log")})
 for kind in ("native","proof"):
  xs=sorted(row["inner_ns"] for row in report["rows"] if row["kind"]==kind)
  stats=report["cost_comparison"][kind]["verifier_inner_ns"]
  need(len(xs)==20 and stats["count"]==20 and stats["median"]==statistics.median(xs) and stats["p95_nearest_rank"]==xs[math.ceil(.95*len(xs))-1] and stats["p99_nearest_rank"]==xs[math.ceil(.99*len(xs))-1],"independent finite statistic readback")
 need(report["cost_comparison"]==main["cost_comparison"]["per_arm"][index],"main statistics exact copy")
 arms.append({"id":arm["id"],"receipt":arm["receipt"],"comparison":comp,"outer_process":proc,"planned_rows":40,"accepted_rows":40,"cancellation_event_field_state":cancel_field_state,"finite_statistics":report["cost_comparison"]})
need(len(work_ids)==1 and len(journals)==1,"one complete work claim and public journal")
for phase in ("before","after"):
 need(sha(BASE/("audit/source-"+phase+".json"))=="e2e1d88b8bb08d6da57361287d3f76df9f78299fb5a44b45d3bdb0ea61c08556","exact A source")
states={}
for label,repo,head in (("A",ROOT/"repo","d3037ca5dfb6f301757c159b7888dca9b0317be0"),("C1",ROOT/"integration-repo","cb557c5e59b00ba7c6b1d40f78fbe51031a26f11")):
 actual=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
 status=subprocess.check_output(["git","status","--porcelain=v1","--untracked-files=all"],cwd=repo,text=True)
 need(actual==head and status=="","repo identity and clean after")
 states[label]={"commit":actual,"status":status}
for item in row_pins:
 for key in ("row_observation","stage","verifier_stdout","verifier_stderr"): need(pin(item[key]["path"])==item[key],"raw row files unchanged during readback")
need(pin(main_pin["path"])==main_pin,"original main result hash unchanged")
for arm in arms:
 need(pin(arm["comparison"]["path"])==arm["comparison"] and pin(arm["outer_process"]["path"])==arm["outer_process"],"original arm result hashes unchanged")
save(OUT/"row-pins.json",row_pins)
raw_save(OUT/"authoritative-job-terminal.json",data["terminal_text"])
raw_save(OUT/"authoritative-launch-response.json",data["launch_text"])
summary={"schema":"TRNM-W1-COMMON-RAYON2-ACTUAL-READBACK1","raw_result":main_pin,"binding":binding_pin,"authoritative_terminal":pin(OUT/"authoritative-job-terminal.json"),"authoritative_launch_response":pin(OUT/"authoritative-launch-response.json"),"readback_complete":True,"planned_rows":80,"accepted_rows":80,"arms":arms,"work_ids":sorted(work_ids),"journal_sha256":sorted(journals),"arm2_over_arm1_proof_inner_median":main["cost_comparison"]["arm2_over_arm1_proof_inner_median"],"row_raw_pins_record":pin(OUT/"row-pins.json"),"raw_row_count":80,"raw_file_hashes_equal_before_after_readback":True,"operation_cancellation_sidecars":sidecars,"missing_optional_event_not_interpreted_as_explicit_false":True,"readback_script":pin(OUT/"readback02.py"),"first_readback_failure":{"job_id":"1a1b7d01012-12894-c66","terminal":pin(OUT/"first-readback-terminal.json"),"stderr":pin(OUT/"first-readback-stderr.log"),"request":pin(OUT/"first-readback-request.json")},"source_states_after":states,"source_before":pin(BASE/"audit/source-before.json"),"source_after":pin(BASE/"audit/source-after.json"),"owned_scope_closed_observed":True,"actual_cpu_max":main["scope_after"]["cpu_max"],"actual_memory_max":main["scope_after"]["memory_max"],"fresh_proof_generations":0,"original_measurement_files_modified":False,"mathematical_verification_executed_by_this_readback":False,"interpretation":"20 repeated verifications per kind per receipt; finite ratio of medians and nearest-rank p95/p99, not population tail or fresh generation; prior R4/R8 retained separately; cold-process wall includes supervisor polling; no Node/WAN/funding/resource-completeness qualification"}
save(OUT/"readback.json",summary)
print(json.dumps({"readback":pin(OUT/"readback.json"),"terminal":pin(OUT/"authoritative-job-terminal.json"),"main":main_pin,"all80raw_rows_match":True,"work_ids":sorted(work_ids),"source_states_after":states},sort_keys=True))
