import os,pathlib,hashlib,json,time,stat
root=pathlib.Path("/home/qian/chain-pq-migration-recovery-e1dee-20261106")
path=root/"custody/fresh-checkpoint.bin"
expected="6b1cbc4afafca25b15c40e849f827a387c3a1354be338494f1d2d7fe600e54d3"
fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
info=os.fstat(fd)
assert stat.S_ISREG(info.st_mode) and stat.S_IMODE(info.st_mode)==0o600 and info.st_nlink==1 and info.st_size==84
data=os.read(fd,85);assert len(data)==84 and hashlib.sha256(data).hexdigest()==expected
os.fsync(fd);os.close(fd)
parent=os.open(path.parent,os.O_DIRECTORY|os.O_NOFOLLOW);os.fsync(parent);os.close(parent)
assert data[:12]==b"TRNMCPX1"+bytes([1,0,0,0])
assert hashlib.sha256(b"trnm.external-node-checkpoint.journal-export.v1\0"+(52).to_bytes(8,"big")+data[:52]).digest()==data[52:]
receipt={"schema":"trnm-isolated-independent-pin-custody-v1","created_unix_ns":time.time_ns(),"host_alias":"x230","hostname":os.uname().nodename,"boot_id":pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip(),"machine_id_sha256":hashlib.sha256(pathlib.Path("/etc/machine-id").read_text().strip().encode()).hexdigest(),"physical_model":pathlib.Path("/sys/devices/virtual/dmi/id/product_name").read_text().strip(),"pin_path":str(path),"pin_sha256":expected,"pin_size":len(data),"record_count":int.from_bytes(data[12:20],"big"),"root":data[20:52].hex(),"pin_device":info.st_dev,"pin_inode":info.st_ino,"pin_mode":stat.S_IMODE(info.st_mode),"file_and_parent_fsync":True,"production_custody_qualified":False,"independent_admin_qualified":False}
with (root/"records/custody-fsync.json").open("x") as stream:json.dump(receipt,stream,indent=2);stream.flush();os.fsync(stream.fileno())
parent=os.open(root/"records",os.O_DIRECTORY);os.fsync(parent);os.close(parent)
print(json.dumps(receipt,sort_keys=True),flush=True)

