### Original three-run native campaign

[Run 42553751914](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553751914)
actually builds and executes all three planned release campaigns on 117.
Build exits 0; each original campaign exits 101 with a valid retained report.
There are no phase startup errors, report-validation failures or finalization
failures. Complete campaigns meeting the original criteria: **0/3**.

This original campaign uses three 30-second modes per run. Its per-run outcomes
are identical across the three runs:

| Mode in each run | Hostile processes | Planned confirmation rounds | Observed rounds | Confirmed rounds | Unobserved rounds | Submit ACKs |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| baseline | 0 | 3 | 2 | 1 | 1 | 14/14 |
| from-zero | 24 | 3 | 1 | 0 | 2 | 7/7 |
| late-product | 24 | 3 | 1 | 0 | 2 | 7/7 |

Across nine phases: **27 planned, 12 observed, 3 confirmed, 15 unobserved**.
An unobserved round is not a completed failed execution and has no zero-cost
assumption. All nine phases retain `PUBLIC_REQUEST_DEADLINE`,
`receiver_client_state_equal=false` and
`genuine_budget_depletion_observed=false`. The original finite criteria remain
false. The attack-free mode has partial confirmation and still fails its full
original target.

The controller/build domain retains its declared 4-CPU / 16-GiB limit, while
the actual receiver/verifier phase retains the original 0.25-CPU / 2-GiB public
domain. These domains are not conflated. The checked original test binary is
12,601,856 bytes, before/after SHA-256
`f9cd85c7b053746cea0610aa184bd4993def306bd6bb8aeb875583c803dfa619`.
The complete original provider ZIP, including that binary, is retained.

### Original four-second service cases

These are separate cases from the 30-second, three-run campaign.
[Required-baseline run 42553751938](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553751938)
has the following four completed native failures:

| Completed job | Native child calls | Baseline independent confirmation | Pressure independent confirmation |
| --- | --- | --- | --- |
| Protocol head, 128954796906 | 5/5 exit 0; no timeout | 1/1 | 0/1 |
| Protocol prospective merge, 128954797047 | 5/5 exit 0; no timeout | 1/1 | 0/1 |
| Cross-architecture x64, 128954796813 | 5/5 exit 0; no timeout | 1/1 | 0/1 |
| Cross-architecture arm64, 128954796735 | 5/5 exit 0; no timeout | 1/1 | 0/1 |

Each keeps the original four-second / 16-hostile case, actual
`cpu.max=25000 100000`, 2 GiB, zero swap and 256 PIDs. OOM and OOM-kill counts
are zero. Service and sustained reports pass, but the confirmation validator
rejects `CONFIRMATION_TARGET`; its later predicates are not independently
claimed as passed. The execution-completed flag only records that child calls
returned. Acceptance remains false.

All four pressure cases retain 7/7 Submit ACKs for blocks carrying one business
item. Head, prospective merge and x64 fail the last independent replay with
`PUBLIC_REQUEST_DEADLINE`. ARM64 finishes its six observed replays, but the
seventh History response fails or misses the original window.

The changed History control is on this actual replay path. No paired causal
experiment attributes these failures to the change or excludes its involvement.
The new V4 example command is not reached after the failing from-zero command;
the Growth-specific branch is not used by this ordinary Submit/History fixture.

### Work/time research controls

[Run 42553751985](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553751985)
passes both the 117 head and b472 prospective-merge lanes. Each lane records
104 required/started/successful named controls and 13 successful historical
reference controls, with no failures, errors or skips. Its finite Python
catalogue contains 24 cohorts, and generation/replay commands exit 0.

This is current research replay of fixed historical W1 source
`b16bae2824e6c8236ef2011fc93a74df3ac7f039`. Both lanes explicitly retain
`native_execution=false` for those controls,
`current_native_cost_qualified=false` and `HOLD_NO_GO`.
`original_current_contract.matched=false` retains the original
`SOURCE_BYTES:config/pon/pq-cross-branch-corpus-v1.json` refusal.
Passing these controls does not qualify current native cost, all legal
algorithms, quantum resource envelopes or production activation.

### Other retained failed gates

The two completed external-evidence jobs in required-baseline each run 71
named tests with 84 failures and 22 errors, including subtests. The checker and source-replacement test fixtures still expect
`growth_observation_only`; the actual `store.rs` uses `observation_only`.
The complete checker, test-suite and store blobs are identical at e798 and
117. This inherited static mismatch remains FAIL; no guard or historical pin
is rewritten.

[W1 QROM implementation run 42553751987](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553751987)
fails both lanes. Each has 81 required controls, 67 started, 63 successful,
two test failures, two test errors and 14 not started after a separate
setUpClass error. The historical verifier source bound rejects 11,172 actual
bytes against its original 9,233-byte contract. Related source, guards and
workflow blobs are unchanged from e798, and the current-source observer
explicitly retains that refusal. Later scope reporting is skipped.

This is a scoped account of inspected jobs. The required-baseline workflow
was still in progress in the retained root snapshot; six completed job
failures do not establish the final status of every other job. Other workflow
titles or successful statuses are not security or availability proofs.
