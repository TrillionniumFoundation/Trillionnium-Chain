#!/usr/bin/env python3
"""Assemble completed observations for one exact code commit into a new directory.

This collector runs no Cargo commands, tests, benchmarks, Git mutations or network
operations. It rechecks recorded data and source bytes, then writes only the
requested staging directory. It refuses incomplete command receipts and an
absent, incomplete or unsuccessfully checked benchmark. It never upgrades HOLD.
The explicit --blocked-native mode retains three verified compiler failures and
three genuinely unexecuted Node checks without treating either as acceptance.

Run only after all producers have stopped:
    python3 /workspace/scratch/9d99fced0bf1/assemble_profile_evidence.py

For the recorded final-source compiler SIGKILL blockage only:
    python3 /workspace/scratch/9d99fced0bf1/assemble_profile_evidence.py --blocked-native

The staging directory must not already exist. A later evidence-only commit is
deliberately unknown here; its identity must not replace the tested code commit.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import tempfile
import tomllib

sys.dont_write_bytecode = True

BASE = Path(__file__).resolve().parent
CODE_COMMIT = "ad081dac8d2c1bccdf463bad82b9db7bd92477d3"
CODE_TREE = "4a552f0cf554718fae8bddd7cf1344999cb4fd29"
BASELINE = "5a5ddbd4577207af7f7771a4a50c76620f32940f"
COMMAND_SCHEMA = "trnm-pq-native-command-v1"
UNKNOWN = "unknown"
SOURCE_LABELS = (
    "preflight", "compiler", "cargo-version", "locked-graph", "format",
    "profile-oracle", "inventory", "source-pins", "claim-guard", "repository",
    "ci-contract", "test-ci-source-integrity", "test-record-pq-native-command",
    "test-pq-research-integration", "test-pq-chain-claim-guard",
    "test-pq-authority-surface-scan",
)
NATIVE_LABELS = (
    "components", "protocol-doc", "m06-units", "m06-integrations",
    "node-build", "node-network", "required-controls", "node-continuous-owner",
    "clippy", "benchmark-build", "benchmark-run", "benchmark-reader",
)
REQUIRED_LABELS = frozenset(SOURCE_LABELS + NATIVE_LABELS)
BLOCKED_NOT_RUN = frozenset(("node-network", "required-controls", "node-continuous-owner"))
BLOCKED_FAILURES = frozenset(("node-build", "node-build-retry1", "clippy"))
BLOCKED_REQUIRED_LABELS = (REQUIRED_LABELS - BLOCKED_NOT_RUN) | BLOCKED_FAILURES
BLOCKED_CORE_LABELS = BLOCKED_REQUIRED_LABELS - BLOCKED_FAILURES
NODE_BUILD_ARGV = (
    "cargo", "test", "--locked", "--offline", "--manifest-path", "trillionnium/Cargo.toml",
    "-p", "trnm-pon-node", "--all-features", "--lib", "--no-run", "--message-format=json",
)
BLOCKED_FAILURE_ARGV = {
    "node-build": NODE_BUILD_ARGV,
    "node-build-retry1": ("taskset", "-c", "0", *NODE_BUILD_ARGV),
    "clippy": (
        "cargo", "clippy", "--locked", "--offline", "--manifest-path", "trillionnium/Cargo.toml",
        "--workspace", "--all-targets", "--all-features", "--", "-D", "warnings",
    ),
}
CONTINUOUS_OWNER_SELECTOR = (
    "operator_pq_startup::tests::"
    "pq_continuous_real_bootstrap_receiver_and_cold_reopen_keep_state_fees_work_and_local_revocation"
)
GATE_NAMES = frozenset((
    "authorization", "proof_pq128", "quantum_mining_fork_choice",
    "migration_and_rollback", "capacity_and_invalid_input", "independent_end_to_end",
))
HARNESSES = (
    "run_exact.py", "run_required_controls.py", "run_parameter_observation.py",
    "run_tail.py", "run-pq.sh", "assemble_profile_evidence.py",
)
SOURCE_FILES = (
    "AGENTS.md", "rust-toolchain.toml", "trillionnium/Cargo.toml",
    "trillionnium/Cargo.lock", "config/pon/work-profile-v1.json",
    "config/pon/pq-system-required-tests-v1.json",
    "config/pon/pq-cross-branch-corpus-v1.json",
    "scripts/project-preflight.sh", "scripts/ci/project_boundary.py",
    "scripts/ci/verify_ci_source.py", "scripts/ci/record_pq_native_command.py",
    "scripts/ci/check_required_native_test.py",
    "scripts/ci/pq_chain_claim_guard.py",
    "evidence/crypto-profile-20261104/recompute_benchmark.py",
    "evidence/crypto-profile-20261104/recompute_profile_ids.py",
)
TEXT_SUFFIXES = frozenset((".json", ".jsonl", ".log", ".txt", ".stderr", ".stdout"))
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_ARCHIVE_INPUT_BYTES = 256 * 1024 * 1024


class EvidenceError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise EvidenceError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"duplicate JSON key: {key}")
        result[key] = value
    return result


def json_value(raw, label="JSON"):
    try:
        return json.loads(raw, object_pairs_hook=unique_object,
                          parse_constant=lambda value: (_ for _ in ()).throw(
                              EvidenceError(f"nonfinite JSON number: {value}")))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise EvidenceError(f"invalid {label}: {exc}") from exc


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def fingerprint(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size,
            info.st_mtime_ns, info.st_ctime_ns)


def regular_file(path):
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode), f"not a regular retained file: {path}")
    require(path.resolve() == path.absolute(), f"symlinked retained path: {path}")
    return info


class Inputs:
    """Capture bounded, immutable text inputs; archives contain these exact bytes."""

    def __init__(self):
        self.files = {}
        self.archive = {}
        self.total_bytes = 0

    def read(self, path):
        path = Path(path).absolute()
        if path not in self.files:
            before = regular_file(path)
            require(before.st_size <= MAX_FILE_BYTES, f"oversized evidence input: {path}")
            data = path.read_bytes()
            require(fingerprint(before) == fingerprint(path.lstat()),
                    f"evidence changed while reading: {path}")
            require(len(data) == before.st_size, f"evidence size changed: {path}")
            require(not data.startswith(b"\x7fELF"), f"binary is not an evidence log: {path}")
            self.total_bytes += len(data)
            require(self.total_bytes <= MAX_ARCHIVE_INPUT_BYTES, "evidence input budget exceeded")
            self.files[path] = (fingerprint(before), data)
        return self.files[path][1]

    def add(self, path, archive_name):
        require(not archive_name.startswith("/") and ".." not in Path(archive_name).parts,
                f"unsafe archive name: {archive_name}")
        data = self.read(path)
        require(archive_name not in self.archive or self.archive[archive_name] == data,
                f"conflicting archive entry: {archive_name}")
        self.archive[archive_name] = data
        return data

    def check_unchanged(self):
        for path, (before, data) in self.files.items():
            require(fingerprint(regular_file(path)) == before,
                    f"evidence changed after collection began: {path}")
            require(sha256(path.read_bytes()) == sha256(data), f"evidence bytes changed: {path}")


def stable_binary_hash(path):
    """Stream a binary for identity only; never add it to the archive."""
    path = Path(path)
    if not path.exists():
        return {"verification_at_collection": UNKNOWN, "reason": "binary no longer present"}
    before = regular_file(path)
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    require(fingerprint(before) == fingerprint(path.lstat()), f"binary changed during hashing: {path}")
    return {"verification_at_collection": "matched", "sha256": digest, "bytes": before.st_size}


def git(repo, *arguments):
    return subprocess.check_output(["git", "--no-replace-objects", *arguments], cwd=repo)


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def compact_source(record, label):
    require(isinstance(record, dict) and record.get("schema") == "trnm-ci-source-v1",
            f"missing source identity: {label}")
    require(record.get("kind") == "head" and record.get("candidate") == CODE_COMMIT
            and record.get("tested_commit") == CODE_COMMIT
            and record.get("tested_tree") == CODE_TREE,
            f"source identity is not the frozen code commit: {label}")
    require(record.get("tracked_worktree_verified") is True
            and record.get("tests_executed_by_identity_check") is False,
            f"source identity is not a raw-byte verification: {label}")
    require(record.get("base") is None and record.get("prospective_merge") is None,
            f"unexpected merge identity: {label}")
    for key in ("tracked_entries", "tracked_bytes"):
        require(type(record.get(key)) is int and record[key] > 0, f"missing {key}: {label}")
    return {key: record[key] for key in (
        "tested_commit", "tested_tree", "tracked_entries", "tracked_bytes",
        "tracked_worktree_verified", "tests_executed_by_identity_check")}


RUST_SUMMARY = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
    r"(\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s$"
)
RUST_COUNTS = ("passed", "failed", "ignored", "measured", "filtered_out")


def test_statistics(raw):
    """Count actual harness summaries, never expected counts or exit-code guesses."""
    text = raw.decode("utf-8", errors="replace")
    lines = text.splitlines()
    suites = []
    harness = UNKNOWN
    ignored = []
    running = None
    for line in lines:
        match = re.match(r"^\s*Running (.*?) \(([^)]+)\)$", line)
        if match:
            harness = {"description": match[1], "binary_path": match[2]}
            ignored = []
        doc = re.match(r"^\s*Doc-tests (\S+)$", line)
        if doc:
            harness = {"doc_tests": doc[1]}
            ignored = []
        count = re.fullmatch(r"running (\d+) tests?", line)
        if count:
            running = int(count[1])
        ignored_case = re.match(r"^test (.*?) \.\.\. ignored(?:, (.*))?$", line)
        if ignored_case:
            ignored.append({"name": ignored_case[1], "reason": ignored_case[2] or UNKNOWN})
        summary = RUST_SUMMARY.fullmatch(line)
        if summary:
            counts = dict(zip(RUST_COUNTS, map(int, summary.groups()[1:6])))
            if running is not None:
                require(running == sum(counts[key] for key in RUST_COUNTS[:4]),
                        "libtest running count disagrees with its terminal summary")
            suites.append({"harness": harness, "result": summary[1], **counts,
                           "seconds": float(summary[7]), "ignored_cases": ignored,
                           "summary_line": line})
            ignored = []
            running = None
    python_suites = []
    for index, line in enumerate(lines):
        match = re.fullmatch(r"Ran (\d+) tests? in ([0-9.]+)s", line)
        if not match:
            continue
        terminal = next((value for value in lines[index + 1:] if value.strip()), "")
        status = re.fullmatch(r"(OK|FAILED)(?: \(([^)]*)\))?", terminal)
        require(status is not None, "unittest count lacks its terminal status")
        extras = {key.strip().replace(" ", "_"): int(value)
                  for key, value in re.findall(r"([a-z ]+)=([0-9]+)", status[2] or "")}
        ran = int(match[1])
        nonpasses = sum(extras.get(key, 0) for key in (
            "failures", "errors", "skipped", "expected_failures", "unexpected_successes"))
        python_suites.append({"result": status[1], "ran": ran,
                              "passed": ran - nonpasses if nonpasses <= ran else UNKNOWN,
                              "seconds": float(match[2]), **extras,
                              "summary_line": terminal})
    result = {"rust_suites": suites, "python_unittest_suites": python_suites,
              "count_basis": "retained harness terminal summaries; executions are not distinct cases"}
    result["rust_totals"] = ({key: sum(row[key] for row in suites) for key in RUST_COUNTS}
                             if suites else UNKNOWN)
    result["python_tests_ran"] = sum(row["ran"] for row in python_suites) if python_suites else UNKNOWN
    return result


def evidence_files(records):
    require(records.is_dir() and not records.is_symlink(), "missing/linked records directory")
    result = []
    for path in sorted(records.rglob("*")):
        require(not path.is_symlink(), f"symlink in records: {path}")
        if path.is_dir():
            continue
        require(path.suffix in TEXT_SUFFIXES, f"unreviewed record type (not archived): {path}")
        regular_file(path)
        result.append(path)
    return result


def check_command(label, record, raw, repo):
    require(record.get("status") != "running", f"command still running: {label}")
    require(record.get("status") in ("command_succeeded", "command_failed"),
            f"incomplete/failed command recorder: {label} ({record.get('status')})")
    code = record.get("exit_code")
    require(type(code) is int, f"unknown command exit code: {label}")
    require((record["status"] == "command_succeeded") == (code == 0),
            f"status and exit disagree: {label}")
    require(record.get("whole_chain_quantum_security_qualified") is False,
            f"invalid command qualification claim: {label}")
    require(record.get("cwd") == str(repo), f"wrong recorded cwd: {label}")
    require(isinstance(record.get("argv"), list) and record["argv"]
            and all(isinstance(value, str) for value in record["argv"]),
            f"missing actual argv: {label}")
    require(record.get("log_file") == label + ".log", f"unexpected log name: {label}")
    require(record.get("log_bytes") == len(raw) and record.get("log_sha256") == sha256(raw),
            f"receipt/log hash or length mismatch: {label}")
    before = compact_source(record.get("before"), label + ":before")
    after = compact_source(record.get("after"), label + ":after")
    require(record["before"] == record["after"], f"source changed during command: {label}")
    require(type(record.get("elapsed_ns")) is int and record["elapsed_ns"] >= 0,
            f"missing command duration: {label}")
    require(isinstance(record.get("started_utc"), str), f"missing start timestamp: {label}")
    datetime.fromisoformat(record["started_utc"].replace("Z", "+00:00"))
    statistics = test_statistics(raw)
    if code == 0:
        require(all(row["result"] == "ok" and row["failed"] == 0
                    for row in statistics["rust_suites"]), f"successful receipt contains failed libtest: {label}")
        require(all(row["result"] == "OK" for row in statistics["python_unittest_suites"]),
                f"successful receipt contains failed unittest: {label}")
    return {"label": label, "argv": record["argv"], "cwd": record["cwd"],
            "status": record["status"], "exit_code": code,
            "started_utc": record["started_utc"], "elapsed_ns": record["elapsed_ns"],
            "source_before": before, "source_after": after,
            "log_file": "final-validation/" + record["log_file"],
            "log_bytes": len(raw), "log_sha256": sha256(raw),
            "environment": record.get("environment", UNKNOWN),
            "test_statistics": statistics}


def cargo_artifacts(raw, target, test=None):
    found = []
    for line in raw.decode("utf-8", errors="replace").splitlines():
        try:
            row = json_value(line)
        except EvidenceError:
            continue
        if (isinstance(row, dict) and row.get("reason") == "compiler-artifact"
                and row.get("target", {}).get("name") == target and row.get("executable")
                and (test is None or row.get("profile", {}).get("test") is test)):
            found.append(row)
    return found


def binary_observation(identity):
    require(isinstance(identity, dict) and isinstance(identity.get("path"), str), "missing binary path")
    require(re.fullmatch(r"[0-9a-f]{64}", identity.get("sha256", "")) is not None,
            "missing recorded binary SHA-256")
    require(type(identity.get("bytes")) is int and identity["bytes"] > 0, "missing binary size")
    checked = stable_binary_hash(identity["path"])
    if checked["verification_at_collection"] == "matched":
        require(checked["sha256"] == identity["sha256"] and checked["bytes"] == identity["bytes"],
                f"retained binary identity changed: {identity['path']}")
    return {"path": identity["path"], "bytes": identity["bytes"],
            "sha256": identity["sha256"], "collection_check": checked,
            "binary_archived": False}


def required_selector_roster(inputs, repo):
    roster_path = "config/pon/pq-system-required-tests-v1.json"
    roster_raw = inputs.read(repo / roster_path)
    require(roster_raw == git(repo, "show", BASELINE + ":" + roster_path), "original selector roster changed")
    roster = json_value(roster_raw)
    selectors = roster["tests"]
    require(len(selectors) == len(set(selectors)) == roster["expected_meaningful_controls"] == 45,
            "required selector inventory is not the original 45")
    require(not set(selectors) & set(roster["child_process_harnesses_not_counted"]), "child harness counted")
    return roster


def validate_required_selectors(inputs, records, repo, documents, commands):
    roster = required_selector_roster(inputs, repo)
    selectors = roster["tests"]
    rows = documents.get("required-selector-results.json")
    require(isinstance(rows, list) and len(rows) == len(selectors), "required selector run is incomplete")
    identity = documents.get("node-test-binary.json")
    require(isinstance(identity, dict), "missing node-test-binary.json")
    build_label = identity.get("build_receipt_label")
    require(isinstance(build_label, str) and re.fullmatch(r"[A-Za-z0-9_-]{1,160}", build_label)
            and build_label in commands, "Node binary lacks its actual build receipt label")
    require(commands[build_label]["status"] == "command_succeeded"
            and commands[build_label]["exit_code"] == 0, "selected Node build did not succeed")
    runner_argv = commands["required-controls"]["argv"]
    runner_positions = [index for index, value in enumerate(runner_argv)
                        if Path(value).name == "run_required_controls.py"]
    require(len(runner_positions) == 1, "required-controls command does not identify its retained runner")
    build_arguments = runner_argv[runner_positions[0] + 1:]
    require(build_arguments == [build_label] or (build_label == "node-build" and not build_arguments),
            "required-controls argv and selected Node build differ")
    binary = binary_observation(identity)
    binary["build_receipt_label"] = build_label
    artifacts = cargo_artifacts(inputs.read(records / (build_label + ".log")), "trnm_pon_node", test=True)
    require(len(artifacts) == 1 and identity.get("artifact") == artifacts[0],
            "Node binary does not match its retained Cargo artifact")
    require(artifacts[0]["executable"] == identity["path"], "Node artifact path mismatch")
    checker = load_module(repo / "scripts/ci/check_required_native_test.py", "_evidence_named_checker")
    checked_rows = []
    for index, (selector, row) in enumerate(zip(selectors, rows)):
        label = f"required-{index:02d}"
        require(row.get("label") == label and row.get("selector") == selector, "required selector order/identity changed")
        require(row.get("argv") == [identity["path"], selector, "--exact", "--show-output", "--test-threads=1"],
                f"required selector argv changed: {label}")
        require(row.get("binary_sha256") == identity["sha256"], f"required selector binary mismatch: {label}")
        for key in ("exit_code", "execution_check_exit_code", "elapsed_ns"):
            require(type(row.get(key)) is int, f"incomplete required selector {key}: {label}")
        raw = inputs.read(records / (label + ".log"))
        require(row.get("log_sha256") == sha256(raw), f"required selector log changed: {label}")
        check_raw = inputs.read(records / (label + "-execution.txt"))
        try:
            result = checker.validate(raw.decode("utf-8").splitlines(), selector)
            checker_ok = True
        except (UnicodeError, ValueError):
            result = {"result": "FAIL", "scope": "named-libtest-execution-only"}
            checker_ok = False
        require(checker_ok == (row["execution_check_exit_code"] == 0), f"named checker outcome changed: {label}")
        if checker_ok:
            require(json_value(check_raw) == result, f"named checker raw result mismatch: {label}")
        checked_rows.append({**row, "execution_check_sha256": sha256(check_raw),
                             "recomputed_named_execution": result,
                             "test_statistics": test_statistics(raw)})
    batch_rows = []
    for line in inputs.read(records / "required-controls.log").decode().splitlines():
        if line.strip().startswith("{"):
            batch_rows.append(json_value(line))
    require(batch_rows == rows, "required selector child results differ from batch stdout")
    success = sum(row["exit_code"] == row["execution_check_exit_code"] == 0 for row in rows)
    if commands["required-controls"]["exit_code"] == 0:
        require(success == len(selectors), "successful batch contains failed controls")
    return {"required": len(selectors), "completed": len(rows), "passed": success,
            "failed": len(rows) - success, "child_harnesses_not_counted": roster["child_process_harnesses_not_counted"],
            "roster_unchanged_from_baseline": True, "node_test_binary": binary,
            "source_binding": "parent required-controls receipt before/after; child logs and recorded binary SHA matched; collection_check reports whether the binary remains present",
            "selectors": checked_rows}


def require_command_coverage(receipts, blocked_native):
    required = BLOCKED_REQUIRED_LABELS if blocked_native else REQUIRED_LABELS
    require(required <= set(receipts), "missing required command receipts: "
            + ", ".join(sorted(required - set(receipts))))
    if blocked_native:
        require(not BLOCKED_NOT_RUN & set(receipts),
                "blocked-native requires the three Node checks to be unexecuted, not recorded commands")


def validate_blocked_native(inputs, records, repo, paths, commands):
    """Admit only this verified blockage; absent evidence alone never grants it."""
    require_command_coverage(commands, True)
    failed = {label for label, row in commands.items() if row["exit_code"] != 0}
    require(failed == BLOCKED_FAILURES, "blocked-native requires exactly the three retained compiler failures")
    for label in sorted(BLOCKED_CORE_LABELS):
        row = commands[label]
        require(row["status"] == "command_succeeded" and row["exit_code"] == 0,
                f"blocked-native requires successful core evidence: {label}")
        if label.startswith("test-"):
            suites = row["test_statistics"]["python_unittest_suites"]
            require(suites and all(suite["result"] == "OK" and suite["ran"] > 0 for suite in suites),
                    f"successful source test command has no actual unittest execution: {label}")
    for path in paths:
        name = path.name
        require(name != "node-test-binary.json"
                and not name.startswith(("required-", "node-network", "node-continuous-owner")),
                f"blocked-native cannot classify retained partial/executed Node evidence as not_run: {name}")
    failures = []
    for label in sorted(BLOCKED_FAILURES):
        row = commands[label]
        require(row["status"] == "command_failed" and row["exit_code"] == 101,
                f"blocked-native compiler failure receipt is not the observed exit 101: {label}")
        require(tuple(row["argv"]) == BLOCKED_FAILURE_ARGV[label],
                f"blocked-native compiler command scope changed: {label}")
        raw = inputs.read(records / (label + ".log"))
        lines = raw.decode("utf-8").splitlines()
        require("error: could not compile `trnm-pon-node` (lib test)" in lines,
                f"missing Node lib-test compilation failure: {label}")
        diagnostics = [(index + 1, line) for index, line in enumerate(lines)
                       if line.strip().startswith("process didn't exit successfully: ")
                       and "--crate-name trnm_pon_node " in line
                       and "/rustc " in line
                       and line.endswith(" (signal: 9, SIGKILL: kill)")]
        require(len(diagnostics) == 1, f"missing/ambiguous actual compiler SIGKILL: {label}")
        if label == "clippy":
            require("/clippy-driver " in diagnostics[0][1], "Clippy failure is not its compiler process")
        else:
            require(not cargo_artifacts(raw, "trnm_pon_node", test=True),
                    f"blocked Node build unexpectedly retained a test executable: {label}")
            terminal = json_value(lines[-1], "failed Cargo build terminal record")
            require(terminal == {"reason": "build-finished", "success": False},
                    f"Node build terminal record does not confirm failure: {label}")
        failures.append({
            "label": label, "status": row["status"], "exit_code": row["exit_code"],
            "log_file": row["log_file"], "log_bytes": row["log_bytes"],
            "log_sha256": row["log_sha256"], "compiler_signal_number": 9,
            "compiler_signal_name": "SIGKILL", "diagnostic_line": diagnostics[0][0],
            "diagnostic_sha256": sha256(diagnostics[0][1].encode()),
            "root_cause": UNKNOWN,
        })
    roster = required_selector_roster(inputs, repo)
    reason = "Both retained final-source Node lib-test build attempts failed before a test executable was available."
    required = {
        "status": "not_run", "required": len(roster["tests"]), "executed": 0,
        "completed": 0, "reason": reason, "node_test_binary": None,
        "roster_unchanged_from_baseline": True,
        "child_harnesses_not_counted": roster["child_process_harnesses_not_counted"],
        "source_binding": "Unexecuted selectors are the original roster at the frozen code commit; no execution is claimed.",
        "selectors": [{"selector": selector, "status": "not_run"} for selector in roster["tests"]],
    }
    owner = {"status": "not_run", "test": CONTINUOUS_OWNER_SELECTOR,
             "executed": 0, "reason": reason, "execution_receipt": None}
    not_run = [{"label": label, "status": "not_run", "executed": 0,
                "reason": reason, "execution_receipt": None}
               for label in sorted(BLOCKED_NOT_RUN)]
    return {
        "status": "blocked", "native_acceptance_complete": False,
        "root_cause": UNKNOWN,
        "observed_failure": "Compiler processes terminated with SIGKILL; Cargo exited 101.",
        "interpretation": "The logs establish termination, not an OOM diagnosis or any other cause. No failed or unexecuted check passes.",
        "failures": failures,
    }, required, owner, not_run


def validate_benchmark(inputs, records, repo, documents, commands):
    for label in ("benchmark-build", "benchmark-run", "benchmark-reader"):
        require(commands[label]["exit_code"] == 0, f"benchmark requires successful {label}")
    meta = documents.get("parameter-run.json")
    require(isinstance(meta, dict) and meta.get("schema") == "trnm-crypto-profile-parameter-observation-v1",
            "parameter-run.json missing or overwritten by outer command receipt")
    require(meta.get("exit_code") is not None, "parameter measurement still running")
    require(type(meta.get("exit_code")) is int and meta["exit_code"] == 0, "parameter run failed")
    for key in ("whole_chain_quantum_security_qualified", "candidate_87_activated", "production_tail_latency_qualified"):
        require(meta.get(key) is False, f"unsupported benchmark claim: {key}")
    for key, filename in (("stdout", "parameter-observations.jsonl"), ("stderr", "parameter-observations.stderr")):
        data = inputs.read(records / filename)
        item = meta.get(key, {})
        require(item.get("file") == filename and item.get("bytes") == len(data)
                and item.get("sha256") == sha256(data), f"benchmark {key} missing/changed")
    raw = inputs.read(records / "parameter-observations.jsonl")
    rows = []
    for index, line in enumerate(raw.splitlines(), 1):
        require(bool(line.strip()), f"blank benchmark record at {index}")
        rows.append(json_value(line, "benchmark JSONL"))
    reader = load_module(repo / "evidence/crypto-profile-20261104/recompute_benchmark.py", "_evidence_benchmark_reader")
    independent = reader.validate(rows)
    require(independent.get("result") == "PASS", "benchmark raw reader did not pass")
    recorded = json_value(inputs.read(records / "benchmark-reader.log"), "benchmark-reader log")
    require(recorded == independent, "recorded benchmark reader differs from raw recomputation")
    reader_argv = commands["benchmark-reader"]["argv"]
    require(len(reader_argv) >= 3, "missing benchmark reader argv")
    reader_input = Path(reader_argv[-1])
    if not reader_input.is_absolute():
        reader_input = repo / reader_input
    require(reader_input.resolve() == (records / "parameter-observations.jsonl").resolve(), "reader checked another input")
    binary = binary_observation(meta.get("binary"))
    artifact = documents.get("benchmark-binary-artifact.json")
    artifacts = cargo_artifacts(inputs.read(records / "benchmark-build.log"), "pq_parameter_bench")
    require(len(artifacts) == 1 and artifact == artifacts[0], "benchmark Cargo artifact is missing/ambiguous")
    require(artifact["executable"] == binary["path"], "benchmark artifact path mismatch")
    require(meta.get("argv") == [binary["path"], "--samples", str(rows[0]["samples_per_stage_case"])],
            "benchmark runtime arguments differ from its header")
    measurements = [{key: value for key, value in row.items() if key != "sample_ns"} for row in rows[1:-1]]
    selected = [row for row in measurements if row["message_bytes"] in (176, 65536)
                and row["signer_count"] in (1, 8)
                and row["operation"] in ("sign_encode_self_verify_and_drop", "valid_verify_with_preexpanded_key",
                                         "candidate_observation_frame_preflight_and_verify")]
    return {"header": rows[0], "completion": rows[-1], "reader": independent,
            "raw_file": "final-validation/parameter-observations.jsonl", "raw_bytes": len(raw),
            "raw_sha256": sha256(raw), "binary": binary, "cargo_artifact_profile": artifact.get("profile", UNKNOWN),
            "runtime_record": meta, "host": meta.get("host", UNKNOWN),
            "load_before": meta.get("before", UNKNOWN), "load_after": meta.get("after", UNKNOWN),
            "selected_measurements": selected,
            "measurement_selection": "message sizes 176/65536, signer counts 1/8, sign/valid-verify/complete-frame-verify",
            "measurement_rows_retained": len(rows) - 2,
            "raw_sample_values_retained": sum(len(row["sample_ns"]) for row in rows[1:-1]),
            "all_raw_samples_and_measurements_retained_in_archive": True,
            "interpretation": "TRNMCPB1 fixed-input local signer groups; no CPQ1 effect, PNQ/NPQ, WAN or production-tail qualification"}


def validate_unchanged(inputs, records, repo, documents):
    record = documents.get("unchanged-contracts.json")
    require(isinstance(record, dict) and record.get("baseline") == BASELINE, "missing unchanged-contracts record")
    paths = git(repo, "ls-tree", "-r", "--name-only", CODE_COMMIT).decode().splitlines()
    expected = {
        "cargo": {path for path in paths if Path(path).name in ("Cargo.toml", "Cargo.lock")},
        "work": {path for path in paths if "/src/pon_work" in path or path.endswith("pon_wire.rs")
                 or path == "config/pon/work-profile-v1.json"},
    }
    require(set(record.get("groups", {})) == set(expected), "unchanged groups missing/extra")
    result = {}
    for group, wanted in expected.items():
        rows = record["groups"][group]
        require(isinstance(rows, list) and len(rows) == len({row["path"] for row in rows})
                and {row["path"] for row in rows} == wanted, f"unchanged {group} path inventory incomplete")
        checked = []
        for row in rows:
            path = row["path"]
            baseline = git(repo, "show", BASELINE + ":" + path)
            current = inputs.read(repo / path)
            require(current == baseline and sha256(current) == row.get("sha256"), f"changed contract: {path}")
            checked.append({"path": path, "bytes": len(current), "sha256": sha256(current)})
        result[group] = {"unchanged": True, "path_count": len(checked), "paths": checked}
    return {"baseline": BASELINE, "code_commit": CODE_COMMIT, "groups": result,
            "work_predicate": "path contains /src/pon_work OR ends with pon_wire.rs OR equals config/pon/work-profile-v1.json",
            "work_security_qualification_implied": False}


def make_tar(path, entries):
    with path.open("xb") as output:
        with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0) as compressed:
            with tarfile.open(mode="w", fileobj=compressed, format=tarfile.PAX_FORMAT) as archive:
                for name, data in sorted(entries.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(data))


def assemble(repo, records, output, blocked_native=False):
    repo, records, output = repo.absolute(), records.absolute(), output.absolute()
    require(not output.exists(), f"staging output already exists: {output}")
    require(not output.resolve().is_relative_to(repo.resolve())
            and not output.resolve().is_relative_to(records.resolve()), "staging must be outside source and input records")
    require(repo.resolve() == repo and records.resolve() == records, "symlinked source/input root")
    verifier = load_module(repo / "scripts/ci/verify_ci_source.py", "_evidence_source_verifier")
    source = verifier.verify("head", CODE_COMMIT, root=repo)
    compact_source(source, "assembly")
    require(git(repo, "show", "-s", "--format=%P", CODE_COMMIT).decode().strip() == BASELINE, "code parent changed")
    inputs = Inputs()
    paths_before = evidence_files(records)
    documents = {}
    for path in paths_before:
        relative = path.relative_to(records).as_posix()
        raw = inputs.add(path, "final-validation/" + relative)
        if path.suffix == ".json":
            documents[relative] = json_value(raw, relative)
    receipts = {}
    for name, row in documents.items():
        if isinstance(row, dict) and row.get("schema") == COMMAND_SCHEMA:
            label = Path(name).stem
            require(name == label + ".json" and label not in receipts,
                    f"nested/duplicate command receipt label: {name}")
            receipts[label] = row
    for name, row in documents.items():
        if isinstance(row, dict):
            require(row.get("status") != "running", f"record still running: {name}")
    require_command_coverage(receipts, blocked_native)
    commands = {}
    for label, row in sorted(receipts.items()):
        commands[label] = check_command(label, row, inputs.read(records / (label + ".log")), repo)
        require(row["before"] == source and row["after"] == source,
                f"command source inventory differs from exact assembled code: {label}")
    for name in ("source-checks.json", "native-checks.json", "tail-checks.json"):
        if name in documents:
            rows = documents[name]
            require(isinstance(rows, list), f"invalid batch summary: {name}")
            for row in rows:
                require(row.get("label") in commands and row.get("exit_code") == commands[row["label"]]["exit_code"],
                        f"batch summary disagrees with command receipt: {name}")
    for label in ("components", "protocol-doc", "m06-units", "m06-integrations", "node-network", "node-continuous-owner"):
        if blocked_native and label in BLOCKED_NOT_RUN:
            continue
        if commands[label]["exit_code"] == 0:
            stats = commands[label]["test_statistics"]["rust_totals"]
            require(isinstance(stats, dict) and stats["passed"] > 0, f"successful native filter ran no passing tests: {label}")
    for path in SOURCE_FILES:
        inputs.add(repo / path, "source-contracts/" + path)
    harnesses = []
    for name in HARNESSES:
        data = inputs.add(BASE / name, "external-harnesses/" + name)
        harnesses.append({"name": name, "bytes": len(data), "sha256_at_collection": sha256(data),
                          "executed_bytes_independently_pinned": UNKNOWN})
    known_harnesses = {str((BASE / name).resolve()) for name in HARNESSES}
    for command in commands.values():
        for value in command["argv"]:
            if not value.endswith((".py", ".sh")):
                continue
            candidate = Path(value)
            if not candidate.is_absolute():
                candidate = repo / candidate
            candidate = candidate.resolve()
            if candidate.is_relative_to(BASE) and not candidate.is_relative_to(repo) and str(candidate) not in known_harnesses:
                data = inputs.add(candidate, "external-harnesses/" + candidate.relative_to(BASE).as_posix())
                harnesses.append({"name": candidate.relative_to(BASE).as_posix(), "bytes": len(data),
                                  "sha256_at_collection": sha256(data), "executed_bytes_independently_pinned": UNKNOWN})
                known_harnesses.add(str(candidate))
    for name in ("profile-code-commit.json", "profile-code-commit.raw", "profile-code-source-verification.json"):
        inputs.add(BASE / name, "source-identities/" + name)
    original_source = json_value(inputs.read(BASE / "profile-code-source-verification.json"))
    compact_source(original_source, "original source identity")
    require(source == original_source, "source inventory differs from frozen code identity")
    raw_commit = inputs.read(BASE / "profile-code-commit.raw")
    require(hashlib.sha1(b"commit " + str(len(raw_commit)).encode() + b"\0" + raw_commit).hexdigest() == CODE_COMMIT,
            "retained raw commit object identity mismatch")
    commit_metadata = json_value(inputs.read(BASE / "profile-code-commit.json"))
    require(commit_metadata.get("sha") == CODE_COMMIT
            and commit_metadata.get("tree", {}).get("sha") == CODE_TREE
            and [row.get("sha") for row in commit_metadata.get("parents", [])] == [BASELINE],
            "retained GitHub commit metadata identity mismatch")
    blockage = None
    not_run = []
    if blocked_native:
        blockage, required, owner_result, not_run = validate_blocked_native(
            inputs, records, repo, paths_before, commands)
    else:
        required = validate_required_selectors(inputs, records, repo, documents, commands)
    benchmark = validate_benchmark(inputs, records, repo, documents, commands)
    unchanged = validate_unchanged(inputs, records, repo, documents)
    if not blocked_native:
        named_checker = load_module(repo / "scripts/ci/check_required_native_test.py", "_evidence_owner_checker")
        owner_argv = commands["node-continuous-owner"]["argv"]
        require("--exact" in owner_argv, "continuous owner control lost exact selection")
        owner_selectors = [arg for arg in owner_argv if "::" in arg]
        require(len(owner_selectors) == 1, "continuous owner selector missing/ambiguous")
        if commands["node-continuous-owner"]["exit_code"] == 0:
            owner_result = named_checker.validate(inputs.read(records / "node-continuous-owner.log").decode().splitlines(), owner_selectors[0])
            require(json_value(inputs.read(records / "node-continuous-owner-execution.txt")) == owner_result, "continuous owner exact execution mismatch")
        else:
            owner_result = {"result": "FAIL", "test": owner_selectors[0]}
    graph = json_value(inputs.read(records / "locked-graph.log"), "locked Cargo metadata")
    lock = tomllib.loads(inputs.read(repo / "trillionnium/Cargo.lock").decode())
    graph_summary = {"workspace_members": len(graph["workspace_members"]),
                     "packages": len(graph["packages"]), "resolve_nodes": len(graph["resolve"]["nodes"]),
                     "lock_packages": len(lock["package"]),
                     "metadata_log_sha256": sha256(inputs.read(records / "locked-graph.log")),
                     "lock_sha256": sha256(inputs.read(repo / "trillionnium/Cargo.lock")),
                     "resolved_ml_dsa": [{"name": row["name"], "version": row["version"]}
                                         for row in graph["packages"] if row["name"] in ("ml-dsa", "openssl", "openssl-sys", "sha2")]}
    guard = json_value(inputs.read(records / "claim-guard.log"), "claim guard output")
    require(guard.get("status") == "HOLD" and set(guard.get("gates", {})) == GATE_NAMES, "whole-chain HOLD gates changed")
    require(all(row.get("status") == "UNQUALIFIED" for row in guard["gates"].values()), "whole-chain gate promoted")
    for key in ("pq_128_qualified", "production_activation", "whole_chain_pq_qualified"):
        require(guard.get(key) is False, f"unsupported qualification: {key}")
    priors = []
    for path in sorted(BASE.iterdir()):
        if path.is_file() and path.suffix in (".log", ".stderr", ".stdout"):
            data = inputs.add(path, "prior-observations/" + path.name)
            priors.append({"file": "prior-observations/" + path.name, "bytes": len(data), "sha256": sha256(data),
                           "source_commit": UNKNOWN, "argv": UNKNOWN, "process_exit_code": UNKNOWN,
                           "final_code_acceptance_evidence": False, "classification": "pre-freeze or unpinned observation",
                           "test_statistics": test_statistics(data)})
    source_unittests = sum(commands[label]["test_statistics"]["python_tests_ran"]
                           for label in SOURCE_LABELS
                           if isinstance(commands[label]["test_statistics"]["python_tests_ran"], int))
    failed_labels = [label for label, row in commands.items() if row["exit_code"] != 0]
    native_complete = (not blocked_native
                       and all(commands[label]["exit_code"] == 0 for label in NATIVE_LABELS)
                       and required.get("passed") == required["required"]
                       and owner_result.get("result") == "PASS")
    inputs.archive["source-identities/source-at-assembly.json"] = json_bytes(source)
    artifacts = {"schema": "trnm-crypto-profile-raw-evidence-inventory-v1", "code_commit": CODE_COMMIT,
                 "code_tree": CODE_TREE,
                 "manifest_excludes_only_itself": True,
                 "files": [{"name": name, "bytes": len(data), "sha256": sha256(data)}
                           for name, data in sorted(inputs.archive.items())]}
    inputs.archive["artifact-manifest.json"] = json_bytes(artifacts)
    reproduction = {
        "schema": "trnm-crypto-profile-reproduction-v1", "status": "HOLD",
        "assembled_utc": datetime.now(timezone.utc).isoformat(),
        "collector": {"argv": sys.argv, "python_executable": sys.executable,
                      "python_version": sys.version, "executes_native_tests_or_benchmarks": False,
                      "mode": "blocked_native" if blocked_native else "strict_completed"},
        "observation_completion": ("completed_observations_with_native_acceptance_blocked" if blocked_native
                                   else "completed_with_failures" if failed_labels else "completed_commands_succeeded"),
        "native_acceptance_complete": native_complete,
        "native_blockage": blockage,
        "not_run_commands": not_run,
        "failed_command_labels": failed_labels,
        "tested_code": {"commit": CODE_COMMIT, "tree": CODE_TREE, "parent": BASELINE,
                        "source_at_assembly": source, "source_before_each_command_and_after_each_command_required": True},
        "publication": {"evidence_only_commit": UNKNOWN, "remote_ref_update": UNKNOWN,
                        "later_combined_commit_tested_by_these_commands": False,
                        "note": "Later evidence packaging or composition does not change which code commit these commands exercised. No success is transferred to a later combined commit."},
        "commands": list(commands.values()),
        "source_checks": {"command_count": len(SOURCE_LABELS), "python_unittest_executions": source_unittests,
                          "all_commands_succeeded": all(commands[label]["exit_code"] == 0 for label in SOURCE_LABELS)},
        "test_count_scope": "Per-command executions, not deduplicated tests. The 45 selectors overlap other component filters. Child harness is excluded.",
        "required_controls": required, "continuous_owner_control": owner_result,
        "toolchain": {"rustc_Vv": inputs.read(records / "compiler.log").decode(),
                      "cargo_V": inputs.read(records / "cargo-version.log").decode(),
                      "rust_toolchain_toml_sha256": sha256(inputs.read(repo / "rust-toolchain.toml")),
                      "per_command_environment": "see commands[].environment"},
        "cargo_graph": graph_summary, "unchanged_contracts": unchanged,
        "profile_oracle": json_value(inputs.read(records / "profile-oracle.log")),
        "benchmark": benchmark, "external_harnesses": harnesses,
        "external_harness_scope": "Archived actual files at collection; Git before/after verification covers the repository, not historical immutability of these external runners.",
        "prior_observations": priors,
        "prior_observation_scope": "All root-level .log/.stderr/.stdout files retained separately; absent process/source metadata remains unknown. No prior log substitutes for final-source execution.",
        "qualification": {"status": "HOLD", "whole_chain_pq_qualified": False, "pq_128_qualified": False,
                          "native_acceptance_complete": native_complete,
                          "production_activation": False, "candidate_87_activated": False,
                          "production_tail_latency_qualified": False,
                          "full_node_regression_claimed": False, "four_second_confirmation_qualified": False,
                          "history_4105_block_acceptance_qualified": False, "independent_wan_qualified": False,
                          "gates": {key: guard["gates"][key]["status"] for key in sorted(GATE_NAMES)}},
        "limitations": ["Source checks are not cryptographic or production qualification.",
                        "Benchmark samples use fixed local inputs and shared host load; groups are not individual-request latency.",
                        "TRNMCPB1 is a measurement frame, not CPQ1, PNQ2 or NPQ6 effect authorization.",
                        "The empirical p99 of 64 observations is the sample maximum, not a qualified production tail.",
                        "No complete Node runtime, WAN, recovery composition, governance/release or consensus-security acceptance is inferred.",
                        "No binaries, build caches or whole repository snapshots are archived."],
    }
    if blocked_native:
        reproduction["limitations"].append(
            "Final-source Node build, its single-CPU retry and workspace Clippy failed with compiler SIGKILL; root cause is unknown. Node network tests, the original 45 required controls and continuous-owner replay were not run.")
    require(evidence_files(records) == paths_before, "record producer added/removed files during assembly")
    inputs.check_unchanged()
    require(verifier.verify("head", CODE_COMMIT, root=repo) == source, "source changed during assembly")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".crypto-profile-evidence-", dir=output.parent) as temporary:
        stage = Path(temporary) / "ready"
        stage.mkdir()
        archive = stage / "raw-observations.tar.gz"
        make_tar(archive, inputs.archive)
        with archive.open("rb") as stream:
            archive_digest = hashlib.file_digest(stream, "sha256").hexdigest()
        reproduction["raw_archive"] = {"file": archive.name, "bytes": archive.stat().st_size,
                                       "sha256": archive_digest, "entries": len(inputs.archive),
                                       "member_manifest": "artifact-manifest.json",
                                       "retained_input_bytes": sum(len(data) for data in inputs.archive.values())}
        (stage / "reproduction.json").write_bytes(json_bytes(reproduction))
        inputs.check_unchanged()
        require(evidence_files(records) == paths_before, "records changed during archive writing")
        require(verifier.verify("head", CODE_COMMIT, root=repo) == source,
                "source changed before evidence staging became final")
        require(not output.exists(), "staging destination appeared during collection")
        os.rename(stage, output)
    reproduction_raw = (output / "reproduction.json").read_bytes()
    print(json.dumps({"result": "ASSEMBLED_HOLD", "output": str(output),
                      "code_commit": CODE_COMMIT, "failed_commands": failed_labels,
                      "native_acceptance_complete": native_complete,
                      "not_run_commands": [row["label"] for row in not_run],
                      "archive_sha256": archive_digest,
                      "archive_bytes": reproduction["raw_archive"]["bytes"],
                      "reproduction_sha256": sha256(reproduction_raw),
                      "reproduction_bytes": len(reproduction_raw),
                      "publication_commit": UNKNOWN}, sort_keys=True))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=BASE / "chain")
    parser.add_argument("--records", type=Path, default=BASE / "final-validation")
    parser.add_argument("--output", type=Path, default=BASE / "evidence-staging")
    parser.add_argument("--blocked-native", action="store_true",
                        help="retain the three verified SIGKILL failures and three unexecuted Node checks as HOLD; all core checks and raw benchmark remain mandatory")
    args = parser.parse_args()
    assemble(args.repo, args.records, args.output, blocked_native=args.blocked_native)


if __name__ == "__main__":
    try:
        main()
    except (EvidenceError, OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        print(f"REFUSED: {error}", file=sys.stderr)
        raise SystemExit(1)
