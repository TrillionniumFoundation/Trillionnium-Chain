# M08 Generation-atomic reorg and coherent confirmation

Revision: invariant-driven revision3. Selected target: `pon-nakamoto-v1`.
[Sole development plan](../development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md); [exact invariant registry](../../config/pon/invariants-v2.json).

## Scope and ownership

Native Node and separate reference Ledger disk-SQLite recovery. The detailed Ledger-named phase contracts below identify the reference API; the native mapping is stated in the continuation section. Process crash is not physical power-loss evidence.

The claims below apply to their named component and tests, not to an independently accepted full native node.

## PoN State machine

### M08.PlanReorg

**Inputs / preconditions:** Ledger exclusive owner; fully verified stored target BlockId; active(old_tip,generation,state_slot); optional crash-cut callback

**Output:** Existing tip for no strictly greater work, direct-extension publication, or committed staging intent consumed by RecoverAndPublish

**Algorithm and actual entry:** This is the planning phase inside Ledger.activate, not a separate public API. Finish an existing staging intent first and reread active state. Compare stored 512-bit work; equal/lower returns old tip without new events. A direct child with no fault callback applies deltas and publishes on the existing slot in one transaction. Otherwise walk old/new ancestry by height to the common ancestor; order detach tip-to-fork and attach fork-to-tip; copy the active slot and write old/new tips, next generation, ordered steps and cursor zero in one IMMEDIATE transaction. Never accept caller-supplied work totals or step lists.

**Atomic/commit boundary:** Direct extension: delta, active tip/generation and attach event commit atomically. Fork: staging copy plus reorg intent commit together before any detach; active pointer remains unchanged.

**Errors:** UNKNOWN_PARENT; UNDO_ROOT or ROOT on direct append; existing-intent GENERATION/SCHEMA failures; propagated SQLite/OSError. Resource exhaustion is a local failure, not consensus-invalid history.

**Retry and resource boundary:** One owner and one pending intent. Actual planning currently holds detach/attach lists and a full staging copy; bounded native planning is not implemented. No fixed depth becomes finality.

### M08.RecoverAndPublish

**Inputs / preconditions:** Ledger._recover_intent reads the persisted singleton(old_tip,new_tip,generation,steps,position,status); optional crash-cut callback

**Output:** No pending/done intent: active tip unchanged. Successful recovery: target tip with coherent generation, root and one ordered remove/add event set

**Algorithm and actual entry:** This is Ledger._recover_intent, called by activate and recover. Require active==(old_tip,generation-1). From persisted cursor, check detach/attach kind and each delta before-image, then apply that step and advance its cursor in one IMMEDIATE transaction. After all steps, recompute the staged target root. Publish active tip/generation/state_slot, events, done status and old-slot retirement in one transaction. Ledger.recover then selects any fully verified indexed strictly heavier tip; completing one intent alone is not best-chain selection.

**Atomic/commit boundary:** Every delta step and cursor commit together; final active tuple, ordered events, done flag and old-slot deletion have a separate single commit. Independent EffectJournal is never part of undo.

**Errors:** GENERATION for stale active tuple; SCHEMA for invalid step kind; UNDO_ROOT for before-image mismatch; ROOT before publication; UNKNOWN_PARENT or propagated SQLite/OSError. Do not label any failure as an executed remote effect.

**Retry and resource boundary:** Resume committed cursor after interruption; done/no intent is idempotent and creates no repeated events. On root/generation corruption retain the intent and fence new admission for diagnosis; do not auto-clear it. Full staged state/root replay and physical power-loss qualification remain open.

## M08.ReorgAtomicView

**Invariant:** All eight reorg process-crash cuts recover the same root and one event set while irreversible local records survive.

**Scope:** Native Node and separate reference Ledger disk-SQLite recovery. The detailed Ledger-named phase contracts below identify the reference API; the native mapping is stated in the continuation section. Process crash is not physical power-loss evidence.

**Atomic boundary:** Each delta and cursor commit together; final active slot, logical generation, events and old-slot retirement publish atomically.

**Failure schedule:** Intent; Two detaches; Three attaches; Before publish; After publish; Repeated recovery.

**Expected result:** All eight reorg process-crash cuts recover the same root and one event set while irreversible local records survive.

**Resource and retention rule:** Ordinary append avoids full copies; real forks use a staging slot; readers retain SQLite transaction snapshots.

## Concrete regression selectors

`formal/pon-nakamoto-v1/test_contracts.py::DiskReorgTests.test_every_reorg_process_crash_cut_recovers_exactly`

These exact functions contain executable assertions. The registry only checks binding; actual outcomes and source/input identities belong to the separate qualification report.

## Module-specific threat and residual work

Mixed generations, wrong undo values, duplicated notifications and erasing external effects.

Remote target compensation and long-running native node recovery are separate obligations.

## Current source and verification

- [`trillionnium/crates/trnm-pon-node/src/store.rs`](../../trillionnium/crates/trnm-pon-node/src/store.rs).
- [`formal/pon-nakamoto-v1/ledger.py`](../../formal/pon-nakamoto-v1/ledger.py).

No test binding or local campaign grants independent acceptance, ordinary Hepta execution or production activation. Preserve the exact source, profile and environment of every outcome.

## Executed evidence and scope

[Responsibility-level evidence navigation](README.md#responsibility-and-evidence) reads
measured commits from immutable receipts. The module's entries in
[module-maturity-v1.json](../../config/pon/module-maturity-v1.json) identify actual callable
owners, controlled entrypoints, backends, persistence and exact observed test selectors.
Run `python3 scripts/ci/report_module_evidence.py --module M08` from the repository
root to see subject-byte and complete recorded-runtime matches separately, plus scenarios
not observed in each package. A byte match is not a new test run or product acceptance.
Historical v1/v3/v4 results are never repinned. The sole plan selects further work.

## Native development continuation and remaining scope

Node::activate_with_fault plans native ordered steps; Node::resume_intent commits each step/cursor and atomic root-checked publication. Startup additionally selects admitted heavier history. Actual subprocess cuts cover initialization and reorg; no physical power cut or external-effect compensation is inferred.

The current callable mappings remain in `config/pon/module-maturity-v1.json`.
Exact native entry, storage and work behavior is specified by N3 in NETWORK_CLIENT,
the native continuation in STATE_RECOVERY and the prepared-producer section in WORK_PROFILE.
No historical receipt is relabelled as executing this source.

## Joined full-history projection

The [history/state resource contract](../protocol/pon-nakamoto-v1/details/HISTORY_STATE_RESOURCE_BOUNDS_V1.md) reduces a full-confirmation ancestor step to one checked joined metadata query. Full observed-clock ancestry, inclusion-body roots, membership, cancellation and final generation checks remain. This does not cache an old clock verdict or claim constant-time confirmation/recovery.

## Explicit authenticated-state archive

The [durable research archive](../protocol/pon-nakamoto-v1/details/AUTHENTICATED_STATE_ARCHIVE_V1.md)
uses its own namespace and explicit caller operation. It imports actual native genesis,
reexecutes an admitted block through complete authenticated-state inputs and checks
full state/receipts before atomically publishing checkpoint, delta and optional selection.
CAS generations do not rewind when selecting an older branch. Missing data, altered
records, stale selection, quota exhaustion and cancellation refuse without partial
publication. Reads and reopen reconstruct complete states and compare actual native
branch data. This separate reference-backed store adds no ordinary startup selection,
installed state root, public proof service, pruning or rollback of local operation facts.

## Native authenticated branch publication and migration

The [explicit native backend](../protocol/pon-nakamoto-v1/details/NATIVE_AUTHENTICATED_STORAGE_V1.md)
places persistent account nodes and exact branch state commitments inside the same
SQLite owner transaction as actual block data. Active selection and each staged
reorganization step check the required authentication material. Missing records
refuse; full State reconstruction and comparison remain required on recovery.

Both old and explicitly selected new backends now read back the real final writes
before COMMIT. Admission checks affected row counts, exact deltas, retained packets
and parent/child states. Fast activation checks expected tip, generation, slot and
events; staged reorganization also checks cursor, staged State and final done marker.
A last-event trigger that deletes KV or rewinds the active pointer rolls back the
current transaction. Earlier valid staged transactions retain their original
recoverable meaning. Tests remove the fault and exercise continued recovery.

Explicit migration holds the source writer and a write-excluding read snapshot,
replays every retained branch and preserves all old local-fact tables. It first
publishes a pending-fenced fresh target with atomic no-replace directory rename;
the fence is removed only after a fresh SQLite read and final file/table checks.
Pending reorganization state is copied before target recovery, so the later explicit
target open completes that existing cursor once. Source retention, external-owner
refusal and real subprocess-exit tests are specified in the native backend contract.


## 本轮来源绑定（Round 10）

本节补充 `M08.ReorgAtomicView` 的当前来源绑定。
[原生 ancestry 索引](../protocol/pon-nakamoto-v1/details/NATIVE_ANCESTRY_INDEX.md)
检查最终活动 tip 的精确行集合，包括 genesis 的空集合要求；最后 events 写入破坏或
增加 ancestry 时，本次发布不能提交成功。先前合法的 pending 重组事务保留原有恢复
含义。[原生认证后端](../protocol/pon-nakamoto-v1/details/NATIVE_AUTHENTICATED_STORAGE_V1.md)
继续在同一 writer 事务内发布状态和认证材料，独立 reader 则从完整保留 parent 图重算
各分支 ancestry，防止迁移源与目标共享损坏而仅凭相等获得通过。

完整容量 fixture 定义强制退款、清理后新账户进入及 pending 重组恢复。该测试在普通
debug suite 中 ignored，必须由实际 `--release --exact --ignored` 执行及其精确源码
日志建立结果。下列来源绑定不证明物理断电、远端补偿、公共网络最终性或独立验收，
也不允许回退本地不可逆事实，`independent_accepted=false`。

对应完整回归 selector：

- `trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_store_batch_tests.rs::native_authenticated_full_capacity_refund_entry_and_pending_reorganization_recover`.
- `trillionnium/crates/trnm-pon-node/src/native_ancestry_commit_tests.rs::activation_final_events_cannot_commit_missing_or_extra_active_ancestry`.
- `trillionnium/crates/trnm-pon-node/src/native_ancestry_commit_tests.rs::restart_checks_exact_active_tip_row_set_including_genesis`.
- `formal/pon-nakamoto-v1/test_native_authenticated_storage_oracle.py::NativeAuthenticatedStorageOracle.test_all_retained_ancestry_rows_are_reconstructed_across_inactive_forks`.
- `formal/pon-nakamoto-v1/test_native_authenticated_storage_oracle.py::NativeAuthenticatedStorageOracle.test_ancestry_missing_extra_genesis_and_unknown_rows_are_refused`.
- `formal/pon-nakamoto-v1/test_native_authenticated_storage_oracle.py::NativeAuthenticatedStorageOracle.test_resealed_wrong_ancestor_height_and_component_seals_are_recomputed`.
- `formal/pon-nakamoto-v1/test_native_authenticated_storage_oracle.py::NativeAuthenticatedStorageOracle.test_ancestry_rows_require_exact_types_and_unique_keys`.
- `formal/pon-nakamoto-v1/test_native_authenticated_storage_oracle.py::MigrationPreservationOracle.test_identically_corrupt_migration_ancestry_is_not_qualified_by_cell_equality`.
