## Problem

The joint DAA audit already records that rejecting negative endpoint spans would not eliminate compressed, strictly increasing timestamp schedules. The existing native risk-ledger reader also used Python container equality, which could equate JSON `false` with `0`, or `1` with `1.0`.

## Changes

- Extend the existing temporal reference and native PNH1/PGH2 fixture with a branch using exactly `parent.timestamp + 1` after the common prefix. Positive epoch spans of 15 still clamp to 38; the finite fixture expects height 64 / required work 793 against ordinary height 65 / 130.
- Preserve both original negative-span tests and the historical reader's acceptance contract. Add separately named monotone exports, a strict independent reader, 26 reader controls per profile, and the existing CI/work-time roster wiring.
- Bind the risk-ledger wrapper to the native terminal's complete parsed JSON types and values. Preserve the original byte/checkpoint contracts and negative observations.
- Update the joint audit, sole development plan and source-stage evidence record. Refresh only the reviewed current corpus pins; preserve historical work-cost source commitments.

The implementation is frozen at `d23488c5f9b4a6696c3799b12f14b8af0a1b81fc`, tree `72b106b4458299c37da146b0218b8f5276195b6d`, based on #863 at `249f772cc2a2ace5e363fd5fbfec4241a26f4d4d`.

## Validation at draft publication

| Check | Observed result |
| --- | --- |
| Exact-source CI contract controls | 168 passed |
| Temporal reference controls | 33 passed |
| Native risk-ledger reader controls | 27 passed |
| Joint qualification controls | 34 passed; qualification remains refused |
| Source-integrity controls | 43 passed |
| Current cross-branch source corpus | 915 pinned blobs passed |
| Repository checks | 26 packages, 1,390 Rust files, 6,120 links passed |
| Native exact-source identity | 26,619 tracked entries / 2,530,888,134 bytes verified against the frozen commit |
| Locked Cargo graphs | 26 workspace members; 176 default / 181 all-feature packages; both passed |
| Native Cargo formatting | Passed |
| Four native DAA tests, raw exports and independent raw readers | Native compilation observed; final tests and reader outcomes pending |
| Strict affected all-feature Clippy | Pending in the same original native execution |
| Frozen-baseline work/time runner | 106 + 13 controls still running at preparation of this draft |

Initial durable-start acknowledgements timed out. Readback subsequently confirmed the original exact-source execution; no replacement native execution was started. Original errors and actual command receipts are retained. Final native/reader results and raw evidence will be added in an evidence-only child commit and this validation table will be updated.

## Scope and release boundary

Each native run requires 114 unique packets within that run: 15 common, 50 ordinary and 49 compressed. These are complete W1 relations when actually generated and verified, not 114 independent attacks; repeated profiles may share packet bytes. Logical validation clocks do not establish wall-clock mining cadence, adversarial resource share, quantum cost or profitability. The independent reader does not execute M06, SQL or native cold recovery itself.

No production timestamp, target, accumulated-work, confirmation, signed-domain or stored-schema rule is changed. No monotonicity rule or square-root score is activated. Public-network qualification and production activation remain false. `HOLD_NO_GO` remains: 18 unknown environment inputs, 13 open joint-model proof obligations, and null CP/CG/CQ, installed confirmation and lifetime failure bounds.
