#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
python /workspace/scratch/c9b48df754d6/validation-four-gates/finite-native-review/review_native.py \
  --repo /workspace/scratch/c9b48df754d6/chain-quantum-next \
  --evidence /workspace/scratch/c9b48df754d6/validation-four-gates/rog-native-ec3a939/native-evidence-ec3a939 \
  --output /workspace/scratch/c9b48df754d6/validation-four-gates/finite-native-review/review.json \
  --expected-head ec3a939706592c6ec9dd677b70589a7e8860cdfd \
  --expected-tree 94a2dd1ebda9ce4eb262b6887b739e623616f08a \
  > /workspace/scratch/c9b48df754d6/validation-four-gates/finite-native-review/review.stdout.json \
  2> /workspace/scratch/c9b48df754d6/validation-four-gates/finite-native-review/review.stderr.txt
