from pathlib import Path
import json,os,signal,sys,time
def identity(pid):
    raw=Path(f"/proc/{pid}/stat").read_text()
    fields=raw.rsplit(")",1)[1].split()
    return {"pid":pid,"birth_ticks":int(fields[19]),"state":fields[0],
            "parent":int(fields[1]),"group":int(fields[2]),"session":int(fields[3])}
def save(path,value):
    with path.open("x") as f:
        json.dump(value,f,sort_keys=True);f.write("\n");f.flush();os.fsync(f.fileno())
mode,root,directory,deadline,grace=sys.argv[1:]
out=Path(directory);deadline=float(deadline)
if mode=="leaf":
    signal.signal(signal.SIGTERM,signal.SIG_IGN)
    save(out/"leaf-identity.json",identity(os.getpid()))
    while True:time.sleep(.05)
sys.path.insert(0,str(Path(root)/"formal/pon-nakamoto-v1/experiments"))
import w1_stage_measure as stage
def entry():
    save(out/(mode+"-identity.json"),identity(os.getpid()))
    with stage.cancel_on_signals():
        if mode=="inner":
            original=signal.getsignal(signal.SIGTERM)
            def delayed_cancel(signum,frame):
                save(out/"inner-term-observed.json",{"signal":signum,"monotonic":time.monotonic()})
                time.sleep(.6)
                original(signum,frame)
            signal.signal(signal.SIGTERM,delayed_cancel)
        command=[sys.executable,__file__,"leaf" if mode=="inner" else "inner",root,directory,repr(deadline),"default"]
        kwargs={"deadline":deadline}
        if mode=="outer" and grace!="default":
            kwargs["termination_grace_seconds"]=float(grace)
        try:
            stage.measure(command,out/(mode+"-stage"),60,**kwargs)
        except (stage.Canceled,KeyboardInterrupt) as failure:
            stage.publish_cancellation(out/(mode+"-cancellation.json"),failure,"real-nested-session-control-"+mode)
        return 0
raise SystemExit(stage.run_cli(entry))
