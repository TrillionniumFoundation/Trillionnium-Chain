#!/usr/bin/env python3
"""Record one local command against the actual source and retained binaries."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/2e04527a60e8')
ROOT = BASE / 'chain'
OUT = BASE / 'validation'

def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()

def source() -> dict:
    names = subprocess.check_output(
        ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT
    ).split(b'\0')
    entries = []
    for raw in sorted(set(names)):
        if not raw:
            continue
        name = os.fsdecode(raw)
        path = ROOT / name
        if path.is_symlink():
            raise RuntimeError('source symlink: ' + name)
        if not path.is_file():
            raise RuntimeError('source missing: ' + name)
        entries.append({'path': name, 'bytes': path.stat().st_size, 'sha256': digest(path)})
    encoded = json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()
    return {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'head_tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip(),
        'status': subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT, text=True),
        'entries': entries,
        'source_sha256': hashlib.sha256(encoded).hexdigest(),
    }

name = sys.argv[1]
command = sys.argv[2:]
if not name or '/' in name or not command:
    raise SystemExit('name and exact argv required')
prefix = OUT / name
result_path = prefix.with_suffix('.json')
if result_path.exists() or prefix.with_suffix('.log').exists():
    raise SystemExit('refuse overwrite of retained attempt')
environment = dict(os.environ)
environment.update({
    'PATH': str(BASE / 'toolchain/1.95.0-x86_64-unknown-linux-gnu/bin') + ':/usr/local/bin:/usr/bin:/bin',
    'CARGO_HOME': str(BASE / 'cargo'),
    'CARGO_TARGET_DIR': str(BASE / 'target'),
    'CARGO_BUILD_JOBS': '2',
    'CARGO_INCREMENTAL': '0',
    'RUST_TEST_THREADS': '1',
    'CARGO_TERM_COLOR': 'never',
    'PYTHONDONTWRITEBYTECODE': '1',
})
before = source()
prefix.with_suffix('.source-before.json').write_text(json.dumps(before, indent=2) + '\n')
started = time.time()
clock = time.monotonic()
with prefix.with_suffix('.log').open('xb') as log:
    result = subprocess.run(command, cwd=ROOT, env=environment, stdout=log, stderr=subprocess.STDOUT)
elapsed = time.monotonic() - clock
after = source()
prefix.with_suffix('.source-after.json').write_text(json.dumps(after, indent=2) + '\n')
binaries = []
target = BASE / 'target/debug'
if target.exists():
    for path in sorted(target.rglob('*')):
        if path.is_file() and not path.is_symlink() and os.access(path, os.X_OK):
            if path.stat().st_size < 4:
                continue
            with path.open('rb') as stream:
                magic = stream.read(4)
            if magic == b'\x7fELF':
                binaries.append({'path': str(path.relative_to(BASE)), 'bytes': path.stat().st_size, 'sha256': digest(path)})
receipt = {
    'schema': 'trnm-cell-bt-local-command-v1',
    'argv': command,
    'cwd': str(ROOT),
    'started_unix_seconds': started,
    'elapsed_seconds': elapsed,
    'exit_code': result.returncode,
    'source_before_sha256': before['source_sha256'],
    'source_after_sha256': after['source_sha256'],
    'source_unchanged': before == after,
    'log_sha256': digest(prefix.with_suffix('.log')),
    'explicit_environment': {key: environment[key] for key in ('PATH','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','RUST_TEST_THREADS','CARGO_TERM_COLOR','PYTHONDONTWRITEBYTECODE')},
    'retained_elf_files': binaries,
    'elf_inventory_is_not_proof_each_binary_executed': True,
}
result_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ('retained_elf_files','explicit_environment')}, sort_keys=True))
raise SystemExit(result.returncode if before == after else 98)
