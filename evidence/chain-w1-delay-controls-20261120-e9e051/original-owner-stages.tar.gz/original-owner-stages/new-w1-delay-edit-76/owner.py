from pathlib import Path
import sys,json,time,resource,subprocess,hashlib,os,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'new-w1-delay-edit-76';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);d=json.loads(sys.argv[2]);(out/'edit-input.json').write_text(json.dumps(d,indent=2)+'\n');t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN);bs=resource.getrusage(resource.RUSAGE_SELF);res={'complete':False,'commands':[]};env=os.environ.copy();env['PATH']='/home/qq/.cargo/bin:'+env['PATH']
def sha(raw):return hashlib.sha256(raw).hexdigest()
def run(name,args):
 start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:p=subprocess.run(args,cwd=src,env=env,stdout=so,stderr=se)
 after=resource.getrusage(resource.RUSAGE_CHILDREN);res['commands'].append({'name':name,'argv':args,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start,'child_user_cpu_seconds':after.ru_utime-before.ru_utime,'child_system_cpu_seconds':after.ru_stime-before.ru_stime});assert p.returncode==0,res['commands'][-1]
try:
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip();assert head=='e8b0ec93ab6a6a1ff5e36cfcf9d1179e030a5975';res['head']=head;before=subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src);assert sha(before)=='2727fb59b8fbe3fa7c4625f6b01eb01df1890e7e17be22b5aea4b391a71a7b05';(out/'source-before.patch').write_bytes(before);run('preflight',['bash','scripts/project-preflight.sh']);p=src/d['path'];q=src/d['testpath'];a=p.read_bytes();c=q.read_bytes();assert sha(a)==d['oldsha'] and sha(c)==d['testsha'];(out/'production.before.rs').write_bytes(a);(out/'controls.before.rs').write_bytes(c);text=a.decode();assert text.count(d['old'])==1;p.write_text(text.replace(d['old'],d['new']));q.write_text(c.decode()+d['appended']);run('fmt',['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--package','trnm-pon-node'])
 for name,path in [('production',p),('controls',q)]:
  patch=subprocess.check_output(['git','diff','--full-index','HEAD','--',str(path.relative_to(src))],cwd=src);(out/(name+'.patch')).write_bytes(patch);res[name]={'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'patch_bytes':len(patch),'patch_sha256':sha(patch)}
 res['source_diff_sha256']=sha(subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src));res['changed_paths']=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=src,text=True).splitlines();res['complete']=True
except BaseException as e:res['error']=repr(e);(out/'error.log').write_text(traceback.format_exc());raise
finally:
 a=resource.getrusage(resource.RUSAGE_CHILDREN);ase=resource.getrusage(resource.RUSAGE_SELF);res.update(wall_seconds=time.monotonic()-t,child_user_cpu_seconds=a.ru_utime-b.ru_utime,child_system_cpu_seconds=a.ru_stime-b.ru_stime,self_user_cpu_seconds=ase.ru_utime-bs.ru_utime,self_system_cpu_seconds=ase.ru_stime-bs.ru_stime);(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res),flush=True)
