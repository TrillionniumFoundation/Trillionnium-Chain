from pathlib import Path
import subprocess,json,hashlib,time,resource,sys,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'authority-source-lock-edit-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
res={'schema':'chain-authority-current-source-repair-v1','head':'f0a8364118df01113c14d6a81fbb6fdb6210e4ff','stages':[],'complete':False,'native_qualification':False,'f0_qualification':False}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,cmd,expected=0):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(cmd,cwd=src,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);r={'name':name,'command':cmd,'exit_code':rc,'expected':expected,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['stages'].append(r);save();print(json.dumps(r),flush=True);assert rc==expected
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()==res['head']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=src)
 run('preflight',['bash','scripts/project-preflight.sh'])
 run('original-reader',['python3','scripts/ci/pq_authority_effect_register.py'],2)
 manifest_path='config/pon/pq-authority-effects-v1.json';checker_path='scripts/ci/pq_authority_effect_register.py';test_path='scripts/ci/test_pq_authority_effect_register.py';doc_path='docs/security/PQ_AUTHORITY_EFFECT_REGISTER_V1.md';plan_path='docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md';corpus_path='config/pon/pq-cross-branch-corpus-v1.json'
 changed_paths=[manifest_path,checker_path,test_path,doc_path,plan_path,corpus_path]
 originals={p:(src/p).read_bytes() for p in changed_paths}
 for p,raw in originals.items():(out/(p.replace('/','__')+'.before')).write_bytes(raw)
 m=json.loads(originals[manifest_path]);oldmap=dict(m['source_files_sha256']);audit=[]
 for p,digest in oldmap.items():
  row=subprocess.check_output(['git','ls-tree',res['head'],'--',p],cwd=src,text=True).strip();mode,kind,blob_and_path=row.split(' ',2);blob,entry=blob_and_path.split('\t',1);assert mode=='100644' and kind=='blob' and entry==p
  raw=subprocess.check_output(['git','show',res['head']+':'+p],cwd=src);actual=(src/p).read_bytes();assert raw==actual
  digest_new=hashlib.sha256(raw).hexdigest();audit.append({'path':p,'git_blob':blob,'size':len(raw),'old_sha256':digest,'sha256':digest_new,'unchanged':digest==digest_new})
  m['source_files_sha256'][p]=digest_new
 diff=[r for r in audit if not r['unchanged']]
 assert len(audit)==44 and len(diff)==1 and diff[0]['path']=='trillionnium/crates/trnm-pon-node/src/store.rs'
 assert diff[0]['old_sha256']=='9d79fd3c37db4a664d0a01b89e943276e07d2800cc64cb4986a1452ccf8fb820'
 assert diff[0]['sha256']=='cb063dff4cde5d2f0c60f123cd91cc4e7041964c790a05c1e2e75de6b88b2ec9'
 oldlock='67583ec38887eabe00536dc4cd5ec7cc7fd48acc4397a52165bf4f591c9fa4a7'
 assert hashlib.sha256(json.dumps({'source_revision':m['source_revision'],'files':oldmap},sort_keys=True,separators=(',',':')).encode()).hexdigest()==oldlock
 lock=hashlib.sha256(json.dumps({'source_revision':m['source_revision'],'files':m['source_files_sha256']},sort_keys=True,separators=(',',':')).encode()).hexdigest()
 for p in [checker_path,test_path]:
  text=originals[p].decode();assert text.count(oldlock)==1;text=text.replace(oldlock,lock)
  if p==test_path:
   anchor='        # The preceding discovery fixture cannot be relabelled as this checkpoint.\n'
   assert text.count(anchor)==1
   text=text.replace(anchor,"        # The preceding current-map store pin cannot authorize successor bytes.\n        self.data = deepcopy(self.original)\n        self.data['source_files_sha256'][\n            'trillionnium/crates/trnm-pon-node/src/store.rs'\n        ] = '9d79fd3c37db4a664d0a01b89e943276e07d2800cc64cb4986a1452ccf8fb820'\n        self.refused('fixed reviewed lock')\n\n"+anchor)
  (src/p).write_text(text)
 (src/manifest_path).write_text(json.dumps(m,indent=2)+'\n')
 section=f"""## Current candidate correspondence, 2026-11-19 — HOLD

The immutable candidate \`f0a8364118df01113c14d6a81fbb6fdb6210e4ff\`
retains the 44-path register's original scope and review-lineage label
\`5c04c60e463462d9df8884786e0d5bb32af08a64\`. All 44 regular Git blobs were
read independently and matched to this isolated checkout before updating the
current map. Exactly one selected path differs: Node \`src/store.rs\`, 397,703
bytes, SHA-256 \`cb063dff4cde5d2f0c60f123cd91cc4e7041964c790a05c1e2e75de6b88b2ec9\`.
Its preceding current-map pin
\`9d79fd3c37db4a664d0a01b89e943276e07d2800cc64cb4986a1452ccf8fb820\`
remains an explicit refusal control.

The resulting canonical review-label-plus-current-file lock is
\`{lock}\`. The strict reader, manifest and
independent positive assertion select that same lock. The old unchanged reader
actually returned exit 2 on these bytes. The retained #968 original F0 still
fails its six-target business and numeric-depletion requirements; source
consistency repairs neither result. Earlier dated mappings below retain their
historical identities. Seven routes, 44 paths and every HOLD/false qualification
boundary remain unchanged. This check is not Git provenance authentication,
complete authority coverage, native execution or production activation.

"""
 text=originals[doc_path].decode();anchor='## Selected source correspondence after ordering review, 2026-11-14\n';assert text.count(anchor)==1;(src/doc_path).write_text(text.replace(anchor,section+anchor))
 note="""

## 2026-11-19 continuation: retain F0 failure and repair the current authority map

The exact 3db79eb original F0 44451798839 remains a failed observation:
30-second targets 1/6, original four-second targets 0/6 and timely ACKs 17/42.
Its #969 evidence retains the complete original artifact, source identity,
cost observations and the full 26-run provider denominator at the recorded
timepoint. No native liveness, complete physical-cost or depletion qualification
follows from source checks or the preceding 127 local controls.

The current authority/effect register actually refuses the candidate's store.rs
bytes. Independently compare all 44 immutable regular Git blobs with the isolated
checkout, repair only its single stale current-map store pin, and update the
canonical fixed lock and positive assertion together. Add the preceding store
digest as a refusal without removing old negatives. Keep the retained review
label, seven routes, 44 paths, original historical mappings and all HOLD/false
qualification boundaries. Refresh only the corresponding current corpus blob
pins. Continue first-full-graph/Host performance work under the original true
physical checks, SQL transaction scope, six business goals, windows and credits;
do not reuse a graph's authority across a reorganization transaction.
"""
 (src/plan_path).write_bytes(originals[plan_path]+note.encode())
 corpus=json.loads(originals[corpus_path]);changes=[]
 for p in changed_paths:
  if p==corpus_path or p not in corpus['pinned_blobs']:continue
  raw=(src/p).read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();old=corpus['pinned_blobs'][p];corpus['pinned_blobs'][p]=blob;changes.append({'path':p,'old':old,'new':blob})
 assert set(r['path'] for r in changes)=={manifest_path,checker_path,test_path}
 (src/corpus_path).write_text(json.dumps(corpus,indent=2,sort_keys=True)+'\n')
 res['audit']=audit;res['new_lock']=lock;res['old_lock']=oldlock;res['corpus_changes']=changes;save()
 run('reader',['python3','scripts/ci/pq_authority_effect_register.py'])
 run('adversarial-controls',['python3','-m','unittest','discover','-s','scripts/ci','-p','test_pq_authority_effect_register.py','-v'])
 run('whitespace',['git','diff','--check'])
 patch=subprocess.check_output(['git','diff','--',*changed_paths],cwd=src);(out/'source.patch').write_bytes(patch);res['patch']={'bytes':len(patch),'sha256':hashlib.sha256(patch).hexdigest()};res['files']=[{'path':p,'size':(src/p).stat().st_size,'sha256':hashlib.sha256((src/p).read_bytes()).hexdigest()} for p in changed_paths];res['complete']=True;save();print(json.dumps({'complete':True,'lock':lock,'patch':res['patch'],'files':res['files']},indent=2),flush=True)
except BaseException as e:
 res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
