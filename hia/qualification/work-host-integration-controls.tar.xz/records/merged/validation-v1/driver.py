from pathlib import Path
import sys,json,hashlib,subprocess,unittest,contextlib,importlib.util,os,re,ast,time,traceback
root=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo");base=root.parent/"work-components-integration-v3";out=base/"validation-v1";out.mkdir(mode=0o700);(out/"driver.py").write_text(sys.argv[1]);os.chdir(root);sys.path.insert(0,str(root))
started=time.monotonic_ns();report={"status":"FAIL","native_runtime_executed":False,"original_cargo_executed":False}
def need(v,m):
 if not v:raise ValueError(m)
def ident(p):
 raw=p.read_bytes();return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
try:
 before=json.loads((base/"candidate-source.json").read_text());need({n:ident(root/n) for n in before}==before,"Installed source changed")
 pre=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=root,capture_output=True);(out/"preflight.stdout.raw").write_bytes(pre.stdout);(out/"preflight.stderr.raw").write_bytes(pre.stderr);need(pre.returncode==0,"Preflight failed")
 modules=["hia.tests.test_component_partition","hia.tests.test_foundation_ci","hia.tests.test_execution_ci","hia.tests.test_genesis_ci","hia.tests.test_work_owner_ci","hia.tests.test_work_owner_transfer_ci"]
 suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromName(name) for name in modules])
 spec=importlib.util.spec_from_file_location("bootstrap_guards",root/"scripts/ci/test_hia_workflow_bootstrap.py");boot=importlib.util.module_from_spec(spec);spec.loader.exec_module(boot);suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(boot))
 with (out/"tests.stdout.raw").open("w") as stdout,(out/"tests.stderr.raw").open("w") as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
  result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(suite)
 report["tests"]={"run":result.testsRun,"failures":[[str(t),e] for t,e in result.failures],"errors":[[str(t),e] for t,e in result.errors],"skips":[[str(t),e] for t,e in result.skipped]}
 need(result.wasSuccessful() and not result.skipped,"Merged source controls failed")
 from hia.tools import component_partition as part
 discovered=unittest.defaultTestLoader.discover(str(root/"hia/tests"),pattern="test_*.py",top_level_dir=str(root));ids=[t.id() for t in part.flatten(discovered)]
 groups={g:part.descriptor(ids,g) for g in part.GROUPS};selected=[x for g in part.GROUPS for x in groups[g]["selected_tests"]]
 need(len(selected)==len(set(selected)) and sorted(selected)==sorted(ids),"Real test inventory partition differs")
 report["test_inventory"]={"total":len(ids),"groups":{g:len(v["selected_tests"]) for g,v in groups.items()},"rosters":groups,"business_tests_executed_by_discovery":False}
 import yaml
 class Unique(yaml.SafeLoader):pass
 def mapping(loader,node,deep=False):
  value={}
  for kn,vn in node.value:
   key=loader.construct_object(kn,deep=deep);need(key not in value,"Duplicate YAML key");value[key]=loader.construct_object(vn,deep=deep)
  return value
 Unique.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,mapping)
 raw=(root/".github/workflows/hia-native-migration.yml").read_text();workflow=yaml.load(raw,Loader=Unique)
 need(len(workflow["jobs"])==46,"Merged job count differs")
 bash=python=0
 for name,job in workflow["jobs"].items():
  need(type(job["timeout-minutes"]) is int and job["timeout-minutes"]==20,"Job deadline changed "+name)
  for i,step in enumerate(job.get("steps",[])):
   if "run" not in step:continue
   script=re.sub(r"\$\{\{.*?\}\}","CI_EXPRESSION",step["run"]);done=subprocess.run(["bash","-n"],input=script.encode(),capture_output=True)
   need(done.returncode==0,"Bash parse failed "+name+":"+str(i)+":"+done.stderr.decode());bash+=1
   for m in re.finditer(r"<<['\"]?(PY[A-Z0-9_]*)['\"]?\n(.*?)^\1$",script,re.M|re.S):ast.parse(m.group(2));python+=1
 report["workflow"]={"jobs":len(workflow["jobs"]),"bootstrap_gates":len(boot.BOOTSTRAP.findall(raw)),"bash_fragments":bash,"python_heredocs":python,"all_limits_minutes":20}
 handoff=Path("/tmp/trnm-work-owner-canonical-326-20261116-ut1ee1rf/next-closure-v1/handoff-ded-ci-v7")
 m=json.loads((handoff/"source-manifest.json").read_text());actual={n:ident(root/n) for n in m["source_inputs"]};diffs={n:{"frozen":m["source_inputs"][n],"integrated":v} for n,v in actual.items() if m["source_inputs"][n]!=v}
 readers={n:ident(root/n) for n in m["reader_sources"]};reader_diffs={n:{"frozen":m["reader_sources"][n],"integrated":v} for n,v in readers.items() if m["reader_sources"][n]!=v}
 def hash_map(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(",",":")).encode()).hexdigest()
 report["work_host_source_transition"]={"native_count":len(actual),"frozen_native":m["native_source_set_sha256"],"integrated_native":hash_map(actual),"native_differences":diffs,"frozen_reader":m["reader_source_set_sha256"],"integrated_reader":hash_map(readers),"reader_differences":reader_diffs,"fresh_hosted_run":"NOT_RUN"}
 report["source_after"]={n:ident(root/n) for n in before};need(report["source_after"]==before,"Installed source changed during controls")
 report.update(status="PASS",source_before=before,canonical_parent="c3901ff19c26815205d9cdd6975fc24ecc51ae88",committed=False,published=False)
except BaseException as e:report["failure"]={"error":repr(e),"traceback":traceback.format_exc()};raise
finally:
 report["elapsed_ns"]=time.monotonic_ns()-started;(out/"report.json").write_text(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+"\n")
 print(json.dumps({k:v for k,v in report.items() if k not in ("source_before","source_after","test_inventory")}|{"test_inventory":{k:v for k,v in report.get("test_inventory",{}).items() if k!="rosters"}}),flush=True)
