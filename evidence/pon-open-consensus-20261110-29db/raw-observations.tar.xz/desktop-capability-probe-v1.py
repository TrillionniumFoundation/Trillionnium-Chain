import json, os, pathlib, shutil, subprocess
root=pathlib.Path('/home/qian-qi/workspace')
out={}
mem={}
for line in pathlib.Path('/proc/meminfo').read_text().splitlines():
    k,v=line.split(':',1)
    if k in ('MemTotal','MemAvailable','SwapTotal','SwapFree'): mem[k]=v.strip()
out['memory']=mem
out['cgroup']={}
for name in ('memory.max','memory.current','memory.swap.max','memory.swap.current'):
    p=pathlib.Path('/sys/fs/cgroup')/name
    try: out['cgroup'][name]=p.read_text().strip()
    except OSError as e: out['cgroup'][name]=type(e).__name__
out['workspace_exists']=root.is_dir()
if root.is_dir():
    usage=shutil.disk_usage(root)
    out['workspace_disk_bytes']={'total':usage.total,'used':usage.used,'free':usage.free}
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
def run(args, timeout=8):
    try:
        result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout,env=env)
        return {'exit':result.returncode,'stdout':result.stdout[:1600],'stderr':result.stderr[:300]}
    except Exception as e: return {'error':type(e).__name__}
rustroot=pathlib.Path('/home/qian-qi/.rustup/toolchains')
out['rust_toolchains']=[]
if rustroot.is_dir():
    for tool in sorted(rustroot.iterdir())[:8]:
        if tool.is_dir():
            item={'path':str(tool)}
            for binary in ('rustc','cargo'):
                p=tool/'bin'/binary
                if p.is_file(): item[binary]=run([str(p),'--version'])
            out['rust_toolchains'].append(item)
out['cargo_cache']={}
for rel in ('registry/cache','registry/src','git/db'):
    p=pathlib.Path('/home/qian-qi/.cargo')/rel
    out['cargo_cache'][rel]={'exists':p.is_dir(),'entries':len(list(p.iterdir())) if p.is_dir() else 0}
candidates={root/'Trillionnium-Chain',root/'pon-open-consensus-20261110-29db'/'source'}
if root.is_dir():
    top=sorted((p for p in root.iterdir() if p.is_dir()), key=lambda p:p.name)
    out['workspace_directories']=[p.name for p in top[:80]]
    for p in top[:80]:
        if (p/'.git').exists(): candidates.add(p)
        if any(token in p.name.lower() for token in ('pon','chain','trillionnium')):
            for child in sorted(p.iterdir())[:80]:
                if child.is_dir() and (child/'.git').exists(): candidates.add(child)
out['git_candidates']=[]
for p in sorted(candidates):
    item={'path':str(p),'exists':p.is_dir(),'git_marker':(p/'.git').exists()}
    if item['git_marker']:
        item['identity']=run(['/usr/bin/git','-C',str(p),'rev-parse','HEAD','--show-toplevel','--git-common-dir'])
        item['base_62378_present']=run(['/usr/bin/git','-C',str(p),'cat-file','-e','62378d28415ead28b5f99ec6ea6033fde93e3215^{commit}'])['exit']==0
        item['objects']=run(['/usr/bin/git','-C',str(p),'count-objects','-v'])
    out['git_candidates'].append(item)
print(json.dumps(out,indent=2))
