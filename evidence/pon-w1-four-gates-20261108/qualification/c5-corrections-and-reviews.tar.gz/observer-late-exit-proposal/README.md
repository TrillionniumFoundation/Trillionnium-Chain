# Stable late-observed-exit-zero control

This changes only `test_late_observed_exit_zero_cannot_pass_the_budget` in
`scripts/ci/test_w1_staged_observer.py`. The method count remains 32. Production
`w1_stage_measure.py`, its deadline gates and every historical declaration are
unchanged.

The old control combined a 200ms stage allowance, a child that slept 250ms, and a
400ms observer sleep. In the reported C4 run under build load, the allowance
expired before dispatch. The observer correctly retained `returncode: null`; the
fixture's assertion of an actual zero exit therefore failed before it exercised
the intended late-observation path.

The new fixture gives this new finite control a five-second declared allowance.
A test-only Popen wrapper actually launches the child and uses kernel
`waitid(WEXITED | WNOHANG | WNOWAIT)` to confirm that child exited zero. WNOWAIT
leaves the real status available for production `stage.measure` to consume with
its own wait4. The wrapper delays its return until after the deadline in the
already-written declaration. It never changes the deadline or patches the
production clock. Assertions bind the actual PID, stdout execution marker,
unchanged declared deadline, real zero return status and required failure reason.

## Single actual verification

Desktop job `1a1b978027d-12894-147a` completed with exit 0, durable and complete
output. The isolated single test passed in 5.420 seconds. Retained raw facts are:

- Child PID: 3086326.
- Real wait4 returncode: 0.
- Started monotonic clock: 1190690.31003059 seconds.
- Original effective deadline: 1190695.31003059 seconds.
- Observed wall duration: 5.38769096089527 seconds.
- Sole termination reason: `COMPLETION_NOT_OBSERVED_BEFORE_DEADLINE`.
- `completion_observed_before_deadline: false`.
- `stage_process_complete: false`.
- `error: null`.

The full retained declaration, result, process samples, stdout/stderr and terminal
are in `evidence/`, with exact checksums. This is a finite lifecycle control; it
produces no W1 proof or success qualification.

## File identity

Base test SHA-256:
`ef0a19f0c7b11cb4b30ff224141cde33f21de6f535db338200a7f110fd3e39e9`.
Base Git blob SHA-1: `fc539b20c5a4f658e0b29170775067653b6fc2eb`.

New test SHA-256:
`826b4348d8af00f03c5c3ec1fa1e15ebd30067b9e0fe0fb73f0179d78db5e25d`.
New Git blob SHA-1: `7c08e82576ca5aea8f9afc2f7a1590158bb4a1d3`.

The production observer was independently checked before and after this control:
`a3c80e25ec202749225ddd1a4fc45f3f22ab753f5e9e6941e694a3aa4a547df9`.

Reproduce the single control with:

```sh
python3 scripts/ci/test_w1_staged_observer.py ProcessLifecycleTests.test_late_observed_exit_zero_cannot_pass_the_budget -v
```

The root integration tree was not edited. The parent owns final source integration
and the full C4 gate run. The PQ manifest owner has received the new SHA-256 and
Git blob SHA-1 for its exact source pins.
