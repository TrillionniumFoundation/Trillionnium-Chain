from pathlib import Path
import datetime
import gzip
import hashlib
import json
import re
import shutil
import tarfile
import zipfile

ROOT = Path(__file__).resolve().parent
CARRIER = ROOT / 'carrier'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n')


receipt = json.loads((CARRIER / 'readback-receipt.json').read_text())
results = json.loads((CARRIER / 'original/results.json').read_text())
rows = []
first_confirmations = []
for number in [1, 2, 3]:
    cost = json.loads((CARRIER / f'coverage/run-{number}-cost-coverage.json').read_text())
    raw = json.loads((ROOT / f'expanded-inputs/run-{number}-report.json').read_text())
    assert cost['original_finite_experiment_criteria_met'] is False
    for index, (original, phase) in enumerate(zip(raw['phases'], cost['phases'])):
        assert original['mode'] == phase['mode']
        history = phase['history']
        checkpoint = next(item for item in history['host_checks'] if item['phase'] == 'checkpoint')
        pq = phase['listener']['pq_authentication']
        assert pq['missing_fields'] == []
        assert all(pq[key] == 0 for key in ['pq_authentication_attempts', 'pq_authentication_bytes',
                                          'pq_authentication_thread_cpu_ns'])
        assert pq['pq_authentication_unavailable'] is False
        assert phase['original_outcome']['scheduled_confirmation_rounds'] == 3
        assert phase['original_outcome']['native_phase_criteria_met'] is False
        confirmation = None
        if phase['mode'] == 'baseline':
            original_round = next(item for item in original['confirmations']
                                  if item['confirmed_inside_pressure_window'])
            observation = original_round['observation']
            assert observation['confirmed'] is True and observation['depth'] == 6
            confirmation = {
                'run': number, 'mode': original['mode'], 'round': original_round['round'],
                'source_path': f'phases[{index}].confirmations[0]',
                'started_ns': original_round['started_ns'], 'ended_ns': original_round['ended_ns'],
                'elapsed_ns': original_round['ended_ns'] - original_round['started_ns'],
                'calculation': 'ended_ns minus started_ns within this original round only',
                'confirmed_inside_pressure_window': True, 'depth': 6,
                'observation': observation,
            }
            first_confirmations.append(confirmation)
        row = {
            'run': number, 'mode': original['mode'], 'epoch': phase['epoch'],
            'original_report_sha256': cost['input']['report_sha256'],
            'duration_seconds': original['duration_seconds'],
            'attacker_processes_requested': original['attacker_processes_requested'],
            'attacker_processes_ready': original['attacker_processes_ready'],
            'original_outcome': phase['original_outcome'],
            'first_baseline_depth6_confirmation': confirmation,
            'phase_process_cpu_ns': phase['phase_process_cpu_ns'],
            'phase_process_wall_ns': phase['phase_process_wall_ns'],
            'setup_process_cpu_ns': phase['setup_process_cpu_ns'],
            'setup_wall_ns': phase['setup_wall_ns'], 'process_scope': phase['process_scope'],
            'listener': phase['listener'], 'receiver': phase['receiver'],
            'history': {key: value for key, value in history.items() if key != 'records'},
            'history_record_epochs': [record['epoch'] for record in history['records']],
            'history_record_outcomes': [{key: record[key] for key in [
                'history_call_index', 'epoch', 'succeeded', 'error', 'caller_thread_cpu_ns', 'caller_wall_ns'
            ]} for record in history['records']],
            'fixed_parent': phase['fixed_parent'],
            'unknown_costs': {key: phase[key] for key in [
                'complete_pipeline_cpu_ns', 'physical_network_bytes', 'disk_growth_bytes',
                'payload_transfer_cpu_ns', 'cold_recovery_cpu_ns', 'request_peak_rss_bytes'
            ]},
        }
        assert all(value is None for value in row['unknown_costs'].values())
        rows.append(row)

with zipfile.ZipFile(ROOT / 'artifact-13495362625.zip') as zipped:
    binary = zipped.read('public_v3_multiprocess.bin')
    assert len(binary) == results['binary']['bytes']
    assert digest(binary) == results['binary']['sha256_before'] == results['binary']['sha256_after']
for stream in ['stdout', 'stderr']:
    data = (CARRIER / 'original' / results['build'][stream]).read_bytes()
    assert len(data) == results['build'][stream + '_bytes']
    assert digest(data) == results['build'][stream + '_sha256']
receipt['retained_binary_archive_member_verified'] = {
    'path': 'public_v3_multiprocess.bin', 'bytes': len(binary), 'sha256': digest(binary),
    'copied_into_compact_carrier': False, 'executed_during_readback': False,
}
receipt['build_log_digests_verified_against_original_results'] = True
write_json(CARRIER / 'readback-receipt.json', receipt)
summary = {
    'schema': 'pon-9eda-original-failure-cost-summary-v1',
    'original_source_head': receipt['original_execution_source_head'],
    'original_source_tree': receipt['original_execution_source_tree'],
    'reader_commit': receipt['reader_commit'], 'reader_tree': receipt['reader_tree'],
    'github_run_id': 42201852774, 'github_job_id': 127838794285, 'github_artifact_id': 13495362625,
    'original_campaign_result': results['failure'], 'native_exit_codes': [101, 101, 101],
    'original_inputs': results['original_inputs'], 'original_resources': results['expected_resources'],
    'public_phase_placement': results['public_phase_placement'],
    'first_baseline_depth6_confirmations': first_confirmations, 'phase_rows': rows,
    'F0': {'evidence_in_this_artifact': False, 'result': None,
           'scope': 'Only the original baseline/from-zero/late-product campaign is retained here; noF0 result is inferred.'},
    'scope': {'new_native_execution': False, 'production_qualification': False,
              'cross_source_improvement_claimed': False, 'cross_epoch_timestamps_joined': False,
              'overlapping_cpu_domains_added': False, 'missing_costs_treated_as_zero': False,
              'history_sums': 'Reader sums observed per-call values within each phase separately; complete per-import epochs remain in coverage and raw. No phase or attempt counters are joined.'},
}
write_json(CARRIER / 'summary.json', summary)
shutil.copyfile(ROOT / 'prepare_cost_readback.py', CARRIER / 'prepare_cost_readback.py')
shutil.copyfile(Path(__file__), CARRIER / 'finalize_carrier.py')

table = []
host_table = []
for row in rows:
    history = row['history']
    checkpoint = next(item for item in history['host_checks'] if item['phase'] == 'checkpoint')
    outcome = row['original_outcome']
    table.append('| {run} | {mode} | {ready}/{requested} | {observed}/{planned} | {confirmed} | {missing} | {imports} | {cpu:.6f} | {wall:.6f} | {checks:,} | {host:.6f} |'.format(
        run=row['run'], mode=row['mode'], ready=row['attacker_processes_ready'],
        requested=row['attacker_processes_requested'], observed=outcome['observed_confirmation_rounds'],
        planned=outcome['scheduled_confirmation_rounds'], confirmed=outcome['confirmed_rounds'],
        missing=outcome['unobserved_scheduled_rounds'], imports=history['retained_imports'],
        cpu=history['caller_thread_cpu_ns']['sum_all_observed'] / 1e9,
        wall=history['caller_wall_ns']['sum_all_observed'] / 1e9,
        checks=checkpoint['calls_started'], host=checkpoint['thread_cpu_ns']['sum_all_observed'] / 1e9))
    counters = row['fixed_parent']['counter_deltas']
    host_table.append('| {run} | {mode} | {cpu:.6f} | {periods} | {throttled} | {duration:.6f} |'.format(
        run=row['run'], mode=row['mode'], cpu=counters['cpu_usage_usec'] / 1e6,
        periods=counters['cpu_nr_periods'], throttled=counters['cpu_nr_throttled'],
        duration=counters['cpu_throttled_usec'] / 1e6))
confirmation_table = '\n'.join(
    f"| {row['run']} | {row['started_ns']} | {row['ended_ns']} | {row['elapsed_ns']} | {row['elapsed_ns'] / 1e9:.9f} |"
    for row in first_confirmations)
raw_table = '\n'.join(
    f"| {row['number']} | [{row['gzip_file']}]({row['gzip_file']}) | {row['original_report_bytes']:,} | `{row['original_report_sha256']}` |"
    for row in receipt['reports'])
readme = f'''# 9eda 原失败 campaign：三个报告的来源绑定成本读取

**原结果仍为 `ORIGINAL_THREE_RUN_CAMPAIGN_FAILED`：三次 native 命令都 exit 101，三个 attempt 的全部九个 phase 均未满足原标准。** 本目录只重读已经完成的历史原报告，没有运行新的 native campaign，也没有把当前源码测试结果归入历史执行。

## 来源与核验

原执行 head：`{receipt['original_execution_source_head']}`；tree：`{receipt['original_execution_source_tree']}`。GitHub [run 42201852774](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42201852774) 的 job `127838794285` 由 [API jobs](api/api-workflow-run-jobs.json) 核对为 completed/failure。原 artifact `13495362625` 为 65,440,211 bytes，SHA256 `24ba87d4e957a9dc99a64177e4410b5a0da9208a3c00a637b43dc629e5d9a55b` 与 [API artifact digest](api/api-workflow-run-artifacts.json) 一致。

[readback receipt](readback-receipt.json) 保留所有原成员、输入、输出和命令摘要。已逐一检查三个报告的原 `report_sha256`、原 artifact-files manifest 对应摘要、各 before/after source 相等、三次命令 stdout/stderr 的大小与摘要、原 build logs，以及 ZIP 内原 binary 的前后摘要。原 source receipts 与原 command logs 原字节保留；这些检查建立材料一致性，不扩大为独立执行见证。

成本读取器来自 commit `{receipt['reader_commit']}`，tree `{receipt['reader_tree']}` 的五个实际 Git blobs，随 [reader-source manifest](reader-source-manifest.json) 和 `reader-source/` 一同保留。三个读取命令都 exit 0；**reader 的成功仅表示可以读取这些失败报告，不能改变原 native failure。**

## 原分母、History 与 Host checkpoint

原输入仍是三种 mode、每 phase 30 秒、每 phase 3 轮确认、business_blocks=21、seed_blocks=4、seed_transfers=1024。外层资源条件和 receiver/verifier 的固定 public parent 限制均见 [原 results](original/results.json)，没有修改原预算、截止时间或成功标准。

下表逐 attempt／phase 保留分母。History CPU 与墙钟为读取器在该 phase 内对已观察 import 调用求和；每个 import 的独立 epoch 和完整 native snapshot 仍保留。Host checkpoint CPU 与 import spans 重叠，不能相加得到总 CPU。

| Attempt | Phase | Attacker ready/requested | 已观察/计划确认轮 | 已确认 | 未观察计划轮 | Imports | Import caller CPU s | Import wall s | Checkpoint 次数 | Checkpoint CPU s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(table)}

对应完整读数：[run 1](coverage/run-1-cost-coverage.json)、[run 2](coverage/run-2-cost-coverage.json)、[run 3](coverage/run-3-cost-coverage.json)。[summary.json](summary.json) 另保留所有确认轮原读数、逐 import 成败与 epoch、receiver/listener 成本和 unknown 字段；没有跨 attempt 或跨 phase 拼接时间轴。

## Baseline 首个 depth 6 确认

三个原 round 的 `observation.confirmed=true`、`depth=6`，且 `confirmed_inside_pressure_window=true`。以下严格使用该 round 的 `ended_ns - started_ns`，不把 phase 起点到结束的偏移当成确认时长。原 observation 的 `finalized=false`、`execution_authority=false` 也在 summary 中保留。

| Attempt | started_ns | ended_ns | 差值 ns | 确认时长 s |
| --- | ---: | ---: | ---: | ---: |
{confirmation_table}

**F0 不在该 artifact 内。** 本归档仅包含原 baseline／from-zero／late-product campaign，不提供或推断 F0 结果，也不与其他 source 的 F0 或后续验收拼接。

## 每个固定 public parent 的 Host 样本

以下仅相减该 phase 自己的 before/after 样本。CPU usage 与 throttling 各有自己的语义；throttled duration 不是可追加的执行 CPU。完整上下文、PID、cgroup 和原样本保留在 coverage；memory/pids 只作为时点样本，不称为峰值。

| Attempt | Phase | CPU usage delta s | Periods delta | Throttled periods delta | Throttled duration delta s |
| --- | --- | ---: | ---: | ---: | ---: |
{chr(10).join(host_table)}

## PQ 与仍未测量的成本

全部九个 listener epoch 的 PQ attempts、bytes、calling-thread CPU 都是原始明确的 0；`missing_fields=[]`、`pq_authentication_unavailable=false`。这些零值没有覆盖 PQ 认证负载，不能据此声称 PQ 很便宜或已通过完整业务验收。

全部 phase 的完整 pipeline CPU、物理网络字节、磁盘增长、payload transfer CPU、cold recovery CPU、request peak RSS 均仍为 `null`。没有将未知改为零，也没有把嵌套的 phase、receiver、History、Host CPU 相加。不同 source 或不同 epochs 的结果不用于归因性能改善。

## 三份完整原报告与重算

下面 gzip 的 mtime 固定为 0，解压后逐字节匹配原 ZIP member，并匹配原 `results.json` 中每次 report SHA256。完整 65 MB ZIP 另由下载 receipt 定位，不在此 compact carrier 内重复保存。

| Attempt | 无损原报告 | 原 JSON bytes | 原 JSON SHA256 |
| --- | --- | ---: | --- |
{raw_table}

可在全新输出目录重算三个成本文件：

```sh
python3 -B recompute.py /tmp/pon-9eda-cost-recompute
```

[recompute.py](recompute.py) 先验证本 carrier manifest，再检查解压后的原报告摘要，运行保留的精确 reader，并要求三个输出 SHA256 与已有读数一致。它不启动 node、不下载依赖、不覆盖既有证据。`prepare_cost_readback.py` 和 `finalize_carrier.py` 仅保留本次组装过程；其原绝对路径由 receipt 记录，迁移后的直接重算入口是上述 `recompute.py`。

本归档不能证明当前 0bca 或后续 source 的 native 性能、生产资格或完整六项改造完成。
'''
(CARRIER / 'README.md').write_text(readme)
links = 0
for markdown in CARRIER.rglob('*.md'):
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', markdown.read_text()):
        if '://' in target or target.startswith('#'):
            continue
        assert (markdown.parent / target.split('#', 1)[0]).resolve().exists(), target
        links += 1
files = []
for path in sorted(CARRIER.rglob('*')):
    if not path.is_file():
        continue
    data = path.read_bytes()
    files.append({'file': path.relative_to(CARRIER).as_posix(), 'bytes': len(data), 'sha256': digest(data)})
manifest = {'schema': 'pon-9eda-compact-carrier-manifest-v1',
            'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'original_head': receipt['original_execution_source_head'],
            'original_tree': receipt['original_execution_source_tree'],
            'reader_head': receipt['reader_commit'], 'reader_tree': receipt['reader_tree'],
            'original_failure_preserved': True, 'new_native_execution': False,
            'relative_links_checked': links, 'self_hash_included': False, 'files': files}
write_json(CARRIER / 'manifest.json', manifest)

bundle = ROOT / '9eda-historical-cost-carrier.tar.gz'
assert not bundle.exists()
with bundle.open('xb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0, compresslevel=9) as zipped:
        with tarfile.open(mode='w', fileobj=zipped, format=tarfile.PAX_FORMAT) as tar:
            for path in sorted(CARRIER.rglob('*')):
                if not path.is_file():
                    continue
                info = tar.gettarinfo(str(path), arcname='9eda-historical-cost/' + path.relative_to(CARRIER).as_posix())
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                info.mode = 0o644
                info.pax_headers = {}
                with path.open('rb') as source:
                    tar.addfile(info, source)
delivery = {'schema': 'pon-9eda-cost-carrier-delivery-v1', 'carrier_directory': str(CARRIER),
            'files': len(files) + 1, 'carrier_bytes': sum(p.stat().st_size for p in CARRIER.rglob('*') if p.is_file()),
            'manifest_sha256': digest((CARRIER / 'manifest.json').read_bytes()),
            'bundle': str(bundle), 'bundle_bytes': bundle.stat().st_size,
            'bundle_sha256': digest(bundle.read_bytes()), 'relative_links_checked': links,
            'first_baseline_depth6_elapsed_ns': [row['elapsed_ns'] for row in first_confirmations],
            'original_native_exit_codes': [101, 101, 101], 'new_native_execution': False}
write_json(ROOT / 'carrier-delivery.json', delivery)
print(json.dumps(delivery), flush=True)
