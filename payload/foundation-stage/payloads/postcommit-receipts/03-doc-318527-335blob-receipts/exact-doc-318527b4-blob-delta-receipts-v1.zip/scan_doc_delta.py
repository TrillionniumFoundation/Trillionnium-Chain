"""Read-only exact-commit documentation/evidence blob delta scan. No fsck, fetch, ref or checkout writes."""
import ast,collections,datetime,hashlib,json,mmap,os,pathlib,re,subprocess,sys,tempfile,time,zipfile

BASE="96643a2dd8a90cded0059216cae15e2cd620c77b"
REPO="/private/tmp/chain-audit-recovery-records-20261113/full-history-independent-v1/complete.git"
ROOT=pathlib.Path("/private/tmp/chain-audit-20261114-branch-graph/final-doc-blob-delta-review-v1")
PATTERN_SOURCE=pathlib.Path("/private/tmp/chain-audit-20261114-branch-graph/final-object-delta-review-v1/run-v1/patterns-and-scope.json")
EXPECTED_PATTERN_SHA="33cdf0d872006fd692c72388443f0e8a47e804cfe679b28c6e612074ef5cf479"
DOC_HEAD=sys.argv[1]
assert re.fullmatch(r"[0-9a-f]{40}",DOC_HEAD) and DOC_HEAD!=BASE
RUN=ROOT/("run-"+DOC_HEAD);RUN.mkdir(exist_ok=False)
ENV={**os.environ,"GIT_NO_LAZY_FETCH":"1","GIT_OPTIONAL_LOCKS":"0","GIT_TERMINAL_PROMPT":"0"}
GIT=["/usr/bin/git","--git-dir="+REPO]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
t0=time.monotonic();stage="initialization";proc=None

def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,value):
    p=RUN/name
    with p.open("x",encoding="utf-8") as f:json.dump(value,f,indent=2,sort_keys=True,ensure_ascii=True);f.write("\n")
    return p
def git(*args,input=None):
    p=subprocess.run(GIT+list(args),input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=ENV)
    assert p.returncode==0,"read-only Git command failed"
    return p.stdout
def blob_literal_classification(raw,offsets,paths):
    if len(raw)>2*1024*1024 or not any(p.endswith(".py") for p in paths):return None
    try:
        source=raw.decode("utf-8");tree=ast.parse(source)
    except (UnicodeError,SyntaxError,ValueError,MemoryError):return None
    offsets_by_line=[];n=0
    for line in raw.splitlines(keepends=True):offsets_by_line.append(n);n+=len(line)
    parents={child:parent for parent in ast.walk(tree) for child in ast.iter_child_nodes(parent)}
    literal_spans=[]
    for node in ast.walk(tree):
        if not isinstance(node,ast.Constant) or not isinstance(node.value,(str,bytes)):continue
        value=node.value.encode("utf-8") if isinstance(node.value,str) else node.value
        if not compiled["private_key_header"].search(value):continue
        non_marker=[line for line in value.splitlines() if line.strip() and not line.startswith(b"-----")]
        start=offsets_by_line[node.lineno-1]+node.col_offset
        end=offsets_by_line[node.end_lineno-1]+node.end_col_offset
        context=[];p=node
        while p in parents:
            p=parents[p]
            if isinstance(p,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):context.append({"kind":type(p).__name__,"name":p.name})
        literal_spans.append((start,end,{"line":node.lineno,"literal_bytes":len(value),"has_end_private_marker":b"-----END " in value,"non_marker_lines":len(non_marker),"context":context}))
    results=[]
    for offset in offsets:
        matches=[meta for start,end,meta in literal_spans if start<=offset<end]
        if not matches:return {"all_matches_marker_only_literals":False,"matched_offsets":results}
        safe=[m for m in matches if not m["has_end_private_marker"] and m["non_marker_lines"]==0]
        results.append({"offset":offset,"literal_metadata":safe or matches})
        if not safe:return {"all_matches_marker_only_literals":False,"matched_offsets":results}
    return {"all_matches_marker_only_literals":True,"matched_offsets":results}

try:
    write("started.json",{"started_at":started,"pid":os.getpid(),"base":BASE,"doc_head":DOC_HEAD,"repo":REPO,"execution_only_after_coordinator_supplied_exact_head":True})
    assert git("cat-file","-t",BASE).strip()==b"commit"
    assert git("cat-file","-t",DOC_HEAD).strip()==b"commit"
    ancestor=subprocess.run(GIT+["merge-base","--is-ancestor",BASE,DOC_HEAD],env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    assert ancestor.returncode==0,"provided baseline is not ancestor of provided documentation head"
    identity=git("show","-s","--format=%H%n%T%n%P",DOC_HEAD).decode("ascii").splitlines()
    assert identity[0]==DOC_HEAD
    pattern_bytes=PATTERN_SOURCE.read_bytes();assert sha(pattern_bytes)==EXPECTED_PATTERN_SHA
    spec=json.loads(pattern_bytes)
    compiled={p["id"]:re.compile(p["bytes_regex_ascii"].encode("ascii")) for p in spec["patterns"]}
    (RUN/"patterns-and-scope.json").write_bytes(pattern_bytes)
    write("input.json",{"base":BASE,"doc_head":DOC_HEAD,"doc_tree":identity[1],"doc_parents":identity[2].split(),"pattern_source":str(PATTERN_SOURCE),"pattern_sha256":EXPECTED_PATTERN_SHA,"scope":"Only new/content-modified blobs named by exact base-to-head raw tree diff; unique OIDs scanned once. Deleted blobs, identical-OID mode-only changes and nonblob gitlinks are explicitly recorded but not scanned. No recursion into archive payloads.","original_full_database_rescan":False,"full_fsck":False,"git_writes":False,"future_report_or_archive_objects_included":False})
    stage="exact immutable tree diff"
    diff=git("diff-tree","-r","--no-commit-id","--raw","--no-renames","--no-ext-diff","--abbrev=40","-z",BASE,DOC_HEAD)
    (RUN/"raw-diff.bin").write_bytes(diff)
    parts=diff.split(b"\0");assert parts[-1]==b"";parts.pop()
    assert len(parts)%2==0
    rows=[];selected={}
    for i in range(0,len(parts),2):
        header,pathraw=parts[i:i+2]
        fields=header.decode("ascii").split()
        assert len(fields)==5 and fields[0].startswith(":")
        oldmode,newmode,oldoid,newoid,status=fields[0][1:],fields[1],fields[2],fields[3],fields[4]
        assert status in ("A","M","D","T") and re.fullmatch("[0-9a-f]{40}",oldoid) and re.fullmatch("[0-9a-f]{40}",newoid)
        path=os.fsdecode(pathraw)
        row={"path":path,"old_mode":oldmode,"new_mode":newmode,"old_oid":oldoid,"new_oid":newoid,"status":status}
        if status=="D" or newoid=="0"*40:row["disposition"]="deleted_no_new_blob"
        elif oldoid==newoid:row["disposition"]="mode_only_identical_blob_not_rescanned"
        elif newmode=="160000":row["disposition"]="gitlink_nonblob_not_scanned"
        else:
            assert newmode in ("100644","100755","120000"),"unexpected Git mode"
            row["disposition"]="selected_blob"
            selected.setdefault(newoid,[]).append(path)
        rows.append(row)
    write("diff-paths.json",rows)
    if selected:
        meta=git("cat-file","--batch-check=%(objectname) %(objecttype) %(objectsize)",input=("".join(oid+"\n" for oid in sorted(selected))).encode("ascii")).decode("ascii").splitlines()
    else:meta=[]
    blobs=[]
    for oid,line in zip(sorted(selected),meta,strict=True):
        fields=line.split();assert len(fields)==3 and fields[0]==oid and fields[1]=="blob"
        blobs.append((oid,int(fields[2])))
    write("selection.json",{"selected_paths":sum(r["disposition"]=="selected_blob" for r in rows),"unique_blobs":[{"oid":oid,"bytes":size,"paths":selected[oid]} for oid,size in blobs],"all_diff_status_counts":dict(collections.Counter(r["status"] for r in rows)),"disposition_counts":dict(collections.Counter(r["disposition"] for r in rows))})
    stage="selected raw blob scan"
    totals={k:0 for k in compiled};hits=[];scanned=0;scanned_bytes=0
    with (RUN/"batch.stderr.log").open("xb") as err,(RUN/"blob-coverage.jsonl").open("x") as coverage:
        proc=subprocess.Popen(GIT+["cat-file","--batch"],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,env=ENV)
        for oid,size in blobs:
            proc.stdin.write((oid+"\n").encode("ascii"));proc.stdin.flush()
            header=proc.stdout.readline().decode("ascii").split();assert header==[oid,"blob",str(size)]
            digest=hashlib.sha256();address=hashlib.sha1(b"blob "+str(size).encode("ascii")+b"\0")
            matched={}
            with tempfile.TemporaryFile(dir=RUN) as tmp:
                remaining=size
                while remaining:
                    chunk=proc.stdout.read(min(1024*1024,remaining));assert chunk,"truncated blob"
                    tmp.write(chunk);digest.update(chunk);address.update(chunk);remaining-=len(chunk)
                assert proc.stdout.read(1)==b"\n" and address.hexdigest()==oid
                tmp.flush()
                if size:
                    with mmap.mmap(tmp.fileno(),0,access=mmap.ACCESS_READ) as view:
                        for name,pattern in compiled.items():
                            offsets=[m.start() for m in pattern.finditer(view)]
                            if offsets:matched[name]={"count":len(offsets),"offsets":offsets};totals[name]+=len(offsets)
                        if matched:
                            hit={"oid":oid,"paths":selected[oid],"bytes":size,"sha256":digest.hexdigest(),"matches":matched,"classification":"REVIEW_REQUIRED","raw_secret_values_retained":False}
                            if set(matched)=={"private_key_header"}:
                                classification=blob_literal_classification(view[:] if size<=2*1024*1024 else b"",matched["private_key_header"]["offsets"],selected[oid])
                                if classification is not None:
                                    hit["python_literal_evidence"]=classification
                                    if classification["all_matches_marker_only_literals"]:hit["classification"]="MARKER_ONLY_PYTHON_LITERAL"
                            hits.append(hit)
            scanned+=1;scanned_bytes+=size
            coverage.write(json.dumps({"oid":oid,"bytes":size,"sha256":digest.hexdigest(),"paths":selected[oid],"content_address_verified":True,"raw_bytes_scanned":size,"patterns_checked":list(compiled)},sort_keys=True)+"\n")
        proc.stdin.close();assert proc.wait(timeout=60)==0;proc=None
    assert scanned==len(blobs) and scanned_bytes==sum(size for _,size in blobs)
    write("hits-redacted.json",hits)
    summary={"schema":"exact-final-doc-head-blob-delta-review-v1","started_at":started,"finished_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"seconds":round(time.monotonic()-t0,3),"base":BASE,"doc_head":DOC_HEAD,"doc_tree":identity[1],"raw_diff_sha256":sha(diff),"changed_paths":len(rows),"diff_status_counts":dict(collections.Counter(r["status"] for r in rows)),"disposition_counts":dict(collections.Counter(r["disposition"] for r in rows)),"scanned_unique_blobs":scanned,"scanned_raw_bytes":scanned_bytes,"all_selected_bytes_scanned":True,"all_selected_content_addresses_verified":True,"match_counts":totals,"hit_blob_count":len(hits),"unclassified_hit_count":sum(h["classification"]=="REVIEW_REQUIRED" for h in hits),"marker_only_python_literal_hit_count":sum(h["classification"]=="MARKER_ONLY_PYTHON_LITERAL" for h in hits),"pattern_definitions_sha256":EXPECTED_PATTERN_SHA,"no_raw_secret_values_disclosed":True,"recursive_archive_decompression":False,"all_secret_types_excluded":False,"previous_full_database_rescanned":False,"fsck_rerun":False,"git_mutations":False,"newer_objects_outside_exact_diff_included":False,"scope_exclusions":["Deleted contents, mode-only identical contents, nonblob gitlinks.","All objects not in the exact immutable base-to-doc-head selected blob diff.","Recursive ZIP or other compressed payload decoding.","Any later report, archive or execution-receipt objects; these external receipts are not part of the audited commit."]}
    summary_path=write("summary.json",summary)
    write("terminal.json",{"exit":0,"stage":"complete","summary_sha256":sha(summary_path.read_bytes()),"unclassified_hit_count":summary["unclassified_hit_count"],"credential_review_complete":not summary["unclassified_hit_count"]})
    print(json.dumps({"summary":str(summary_path),"summary_sha256":sha(summary_path.read_bytes()),"base":BASE,"doc_head":DOC_HEAD,"scanned_unique_blobs":scanned,"scanned_raw_bytes":scanned_bytes,"match_counts":totals,"hit_blob_count":len(hits),"unclassified_hit_count":summary["unclassified_hit_count"]}),flush=True)
except BaseException as error:
    if proc is not None:
        try:proc.terminate();proc.wait(timeout=10)
        except BaseException:pass
    try:write("failed.json",{"stage":stage,"error_type":type(error).__name__,"raw_error_or_secret_values_disclosed":False})
    finally:print(json.dumps({"status":"FAILED","stage":stage,"error_type":type(error).__name__}),flush=True)
    raise SystemExit(1)
