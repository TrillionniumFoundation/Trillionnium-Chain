from pathlib import Path
import json,re,sys,hashlib
root=Path('/home/qian-qi/work/chain-native-operation-readback-f0-20261119-2e9b');out=root/'analysis-2';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
snap=json.loads((root/'automatic-ci-at-f0-1/SNAPSHOT.json').read_text());result=[]
for run in snap['runs']:
 for f in run['failed_job_log_requests']:
  p=root/'automatic-ci-at-f0-1'/f['file'];raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==f['sha256']
  lines=raw.decode(errors='replace').splitlines();hits=[]
  for i,l in enumerate(lines):
   if re.search(r'(?i)(error:|traceback|assertionerror|^.*(?:FAILED|FAIL:)|##\[error\]|no such file|not found|missing required|source.*mismatch|source.*changed)',l):hits.append(i)
  context=sorted(set(j for i in hits[-24:] for j in range(max(0,i-1),min(len(lines),i+3))))
  result.append({'run':run['run']['id'],'workflow':run['run']['name'],'job_id':f['job_id'],'job':f['name'],'failed_steps':[s['name'] for j in run['jobs']['items'] if j['id']==f['job_id'] for s in j.get('steps',[]) if s['conclusion']=='failure'],'line_count':len(lines),'matched_lines':len(hits),'context':[(j+1,lines[j]) for j in context]})
(out/'ci-first-failures.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
