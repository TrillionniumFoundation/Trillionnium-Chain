#!/usr/bin/env python3
"""Restore every bundled logical file into a new directory; verify all objects."""
import hashlib,json,pathlib,sys
base=pathlib.Path(__file__).resolve().parent
manifest=json.loads((base/'manifest.json').read_text())
out=pathlib.Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
for relative,record in manifest['files'].items():
    rel=pathlib.PurePosixPath(relative)
    if rel.is_absolute() or any(p in ('','..','.') for p in rel.parts):raise ValueError('unsafe logical path')
    obj=base/'objects'/record['sha256'];data=obj.read_bytes()
    if len(data)!=record['bytes'] or hashlib.sha256(data).hexdigest()!=record['sha256']:raise ValueError('object mismatch: '+relative)
    dest=out/relative;dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('xb') as stream:stream.write(data)
    dest.chmod(record['mode'] & 0o777)
print(json.dumps({'restored_files':len(manifest['files']),'unique_objects':len(manifest['objects']),'qualification':'HOLD_NO_GO'}))
