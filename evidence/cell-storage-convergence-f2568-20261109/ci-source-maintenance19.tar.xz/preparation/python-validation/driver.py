import ast,hashlib,json,os,pathlib,re,stat,subprocess,time
P=pathlib.Path("/home/qian-qi/work/chain-cell-storage-convergence-current-source19-preparation")
V=P/"python-validation";V.mkdir(exist_ok=False);T=V/"tree";T.mkdir()
repo=pathlib.Path("/home/qian-qi/work/chain-cell-storage-convergence-f2568-20261109");rev="66b7064be597039ce871b5b12ad5568850a2dd46"
identity=json.loads((P/"source-identity.json").read_bytes())
def show(path):
 p=subprocess.run(["git","-C",str(repo),"show","--no-textconv",rev+":"+path],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=False)
 assert p.returncode==0,(path,p.stderr.decode());return p.stdout
def actual(path):
 cur=repo
 for comp in pathlib.PurePosixPath(path).parts:
  cur=cur/comp;s=cur.lstat();assert not stat.S_ISLNK(s.st_mode)
 s=cur.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 with cur.open("rb") as f:
  before=os.fstat(f.fileno());b=f.read(2*1024*1024+1);after=os.fstat(f.fileno())
 assert len(b)<=2*1024*1024 and (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)
 return b
inputs=set(r["path"] for r in identity["ledger_mapping"]+identity["pq_mapping"])|set(identity["files"])|{"scripts/ci/pq_lifetime_budget.py","scripts/ci/pq_source_reader.py","scripts/ci/test_pq_lifetime_budget.py","scripts/ci/test_w1_lifetime_ledger.py","config/pon/pq128-lifetime-example-v1.json"}
example=json.loads(show("config/pon/pq128-lifetime-example-v1.json"))
for row in example["events"]:inputs.update(row["source_paths"])
records=[]
for path in sorted(inputs):
 b=show(path);entry=subprocess.check_output(["git","-C",str(repo),"--literal-pathspecs","ls-tree","-z",rev,"--",path],timeout=30)
 meta,name=entry.removesuffix(b"\0").split(b"\t");mode,kind,oid=meta.decode().split();assert kind=="blob" and mode in ("100644","100755") and name.decode()==path
 assert hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()==oid
 work=actual(path);assert work==b,("current source differs from66",path)
 selected=(P/"after"/path).read_bytes() if path in identity["files"] else b
 out=T/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(selected);out.chmod(int(mode,8)&0o777)
 records.append({"path":path,"git_mode":mode,"git_blob":oid,"source_bytes":len(b),"source_sha256":hashlib.sha256(b).hexdigest(),"actual_worktree_equal_to_66":True,"validation_bytes":len(selected),"validation_sha256":hashlib.sha256(selected).hexdigest()})
def snapshot():return {r["path"]:hashlib.sha256((T/r["path"]).read_bytes()).hexdigest() for r in records}
before=snapshot();(V/"input-identities.json").write_text(json.dumps(records,indent=2)+"\n")
def expected_tests(source):
 tree=ast.parse(source);classes={n.name:n for n in tree.body if isinstance(n,ast.ClassDef)}
 def inherited(name,seen=()):
  if name in seen:return set()
  c=classes[name];names={n.name for n in c.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith("test_")}
  for base in c.bases:
   if isinstance(base,ast.Name) and base.id in classes:names|=inherited(base.id,seen+(name,))
  return names
 return sorted(name+"."+test for name in classes for test in inherited(name))
runs=[];env=os.environ.copy();env["PYTHONDONTWRITEBYTECODE"]="1"
for stem,path in [("w1-lifetime","scripts/ci/test_w1_lifetime_ledger.py"),("pq-lifetime","scripts/ci/test_pq_lifetime_budget.py")]:
 argv=["/usr/bin/python3","-I","-S","-B",str(T/path),"-v"];start=time.monotonic();out=b"";err=b"";timed=False;error=None
 try:
  p=subprocess.run(argv,cwd=T,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120,check=False);out=p.stdout;err=p.stderr;code=p.returncode
 except subprocess.TimeoutExpired as ex:out=ex.stdout or b"";err=ex.stderr or b"";timed=True;code=None;error=str(ex)
 except OSError as ex:code=None;error=str(ex)
 (V/(stem+".stdout")).write_bytes(out);(V/(stem+".stderr")).write_bytes(err)
 expected=expected_tests((T/path).read_text());text=err.decode(errors="replace")
 observed=re.findall(r"^test_[^\n]+\(__main__\.([A-Za-z0-9_]+\.test_[A-Za-z0-9_]+)\) \.\.\. ok$",text,re.M)
 counts=re.findall(r"^Ran ([0-9]+) tests? in [^\n]+$",text,re.M)
 passed=code==0 and not timed and len(counts)==1 and int(counts[0])==len(expected) and sorted(observed)==expected and len(set(observed))==len(observed) and len(re.findall(r"^OK$",text,re.M))==1
 r={"argv":argv,"cwd":str(T),"returncode":code,"timed_out":timed,"error":error,"elapsed_seconds":time.monotonic()-start,"stdout_bytes":len(out),"stdout_sha256":hashlib.sha256(out).hexdigest(),"stderr_bytes":len(err),"stderr_sha256":hashlib.sha256(err).hexdigest(),"expected_tests":expected,"observed_tests":observed,"actual_summary_counts":counts,"passed":passed}
 (V/(stem+".receipt.json")).write_text(json.dumps(r,indent=2)+"\n");runs.append(r)
 print(json.dumps({k:v for k,v in r.items() if k not in ("expected_tests","observed_tests")}|{"expected_count":len(expected),"observed_count":len(observed)}))
after=snapshot();assert before==after
result={"schema":"trnm-storage-source19-python-validation-v1","source_commit":rev,"source_before":before,"source_after":after,"source_unchanged":before==after,"all_original_tests_passed":all(r["passed"] for r in runs),"native_executed":False,"model_executed":False,"canonical_mutated":False,"runs":runs}
(V/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"validation_result":str(V/"result.json"),"bytes":(V/"result.json").stat().st_size,"sha256":hashlib.sha256((V/"result.json").read_bytes()).hexdigest(),"passed":result["all_original_tests_passed"],"source_unchanged":before==after}))
