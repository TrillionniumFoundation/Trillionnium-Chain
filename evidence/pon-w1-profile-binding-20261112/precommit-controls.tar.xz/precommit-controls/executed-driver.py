
from pathlib import Path
import base64,hashlib,json,os,subprocess,time,sys,traceback
root=Path('/home/qian-qi/work/chain-w1-profile-binding-20261112-b34d')
out=Path('/home/qian-qi/work/w1-binding-controls-20261112-b34d')
base='229b14c2d366a257f51f287d502a550df2332338'
expected={
'config/pon/pq-proof-profile-binding-v1.json':('548839b84660b8971dcdd8bf5fd0156a0f9cfd54','9ee5796ce1824d48f86a95b7e080ff75e568021a'),
'.github/workflows/chain-hepta-closure-candidate.yml':('26699a44003d4462b97dd8aa369025bbabef51bc','82efb03fd84281c7d9e66f2d545f8f9e265a0bdb'),
'scripts/ci/test_pq_proof_profile_binding.py':('57f769a061d880a5da848a0f4ec1fe8dd176948a','524d067aa0c1cfa992e97565f8c2d07b89ed4636'),
'config/pon/pq-cross-branch-corpus-v1.json':('be7f5a1fd10089616fb6b57c102d187ae0349a12','773e2394b825b053129f3b3cecc0d62bf658fcca')}
def blob(raw): return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=root)
assert root.is_dir() and git('rev-parse','--show-toplevel').decode().strip()==str(root)
assert git('rev-parse','HEAD').decode().strip()==base
assert not git('status','--porcelain=v1','--untracked-files=all')
for name,pins in expected.items(): assert blob((root/name).read_bytes())==pins[0],name
out.mkdir(exist_ok=False)
raw=base64.b64decode('LS0tIGEvY29uZmlnL3Bvbi9wcS1wcm9vZi1wcm9maWxlLWJpbmRpbmctdjEuanNvbgorKysgYi9jb25maWcvcG9uL3BxLXByb29mLXByb2ZpbGUtYmluZGluZy12MS5qc29uCkBAIC00LDggKzQsOCBAQAogICAic2VsZWN0ZWRfcHJvZmlsZV9pZCI6ICJ0cm5tLXcxLXJpc2MwLTMuMC42LXBvc2VpZG9uMi1qb2luLXYyIiwKICAgIm1hcHBpbmdfY29udHJhY3QiOiB7CiAgICAgInBhdGgiOiAiY29uZmlnL3Bvbi93MS1xcm9tLWltcGxlbWVudGF0aW9uLWN1cnJlbnQtdjIuanNvbiIsCi0gICAgImJ5dGVzIjogNDMxNzAsCi0gICAgInNoYTI1NiI6ICJlZTQxYTU1OWM5MWI2MTNiZTQ2YTgwMDgxZGQ0NWQ4NzEzMGQ4M2Q5NWUyZDA2ODM1MmVhMDNhODUyNDBjOTNmIgorICAgICJieXRlcyI6IDQ0NDI3LAorICAgICJzaGEyNTYiOiAiOGU0NTA4ZDEzMmFlMjEwM2YwODYwMjViNzYxNGExOWVmMzBiYWUwNGE3ZmVjMTdmNTgzNDg5N2ZhMWM4M2QzNiIKICAgfSwKICAgInN5c3RlbV9saWZldGltZV9yZWdpc3RlciI6IHsKICAgICAicGF0aCI6ICJjb25maWcvcG9uL3BxMTI4LWxpZmV0aW1lLWJ1ZGdldC12MS5qc29uIiwKLS0tIGEvLmdpdGh1Yi93b3JrZmxvd3MvY2hhaW4taGVwdGEtY2xvc3VyZS1jYW5kaWRhdGUueW1sCisrKyBiLy5naXRodWIvd29ya2Zsb3dzL2NoYWluLWhlcHRhLWNsb3N1cmUtY2FuZGlkYXRlLnltbApAQCAtNjEsNyArNjEsNyBAQAogICAgICAgICAgICAgcHJvb2YtcHJvZmlsZSkKICAgICAgICAgICAgICAgcHl0aG9uMyBzY3JpcHRzL2NpL3Rlc3RfcHFfcHJvb2ZfcHJvZmlsZV9iaW5kaW5nLnB5IC12CiAgICAgICAgICAgICAgIHB5dGhvbjMgc2NyaXB0cy9jaS9wcV9wcm9vZl9wcm9maWxlX2JpbmRpbmcucHkgXAotICAgICAgICAgICAgICAgIC0tZXhwZWN0ZWQtcHJvZmlsZS1kZXNjcmlwdG9yLXNoYTI1NiBkZDc3ZDJhODliYmViMGMzMDhlNDlkMTY4MDAyMGI2Y2I5ZWVhODJmNzQ1YWM0NjIzZjljZjkwNmQ4YTRiZGVkCisgICAgICAgICAgICAgICAgLS1leHBlY3RlZC1wcm9maWxlLWRlc2NyaXB0b3Itc2hhMjU2IDBkNDdlMjNkMzk1ZDYzMzJhMGJkZjFjOTA5M2NmNWIxOTgxNmFhZDk4NDFlM2RiNmU4Y2IyNGY1M2UwZjE4YjMKICAgICAgICAgICAgICAgOzsKICAgICAgICAgICAgIGNhbXBhaWduLXJlYWRlcikKICAgICAgICAgICAgICAgcHl0aG9uMyBzY3JpcHRzL2NpL3Rlc3RfYXVkaXRfbmF0aXZlX2NhbXBhaWduX291dGNvbWVzLnB5IC12Ci0tLSBhL3NjcmlwdHMvY2kvdGVzdF9wcV9wcm9vZl9wcm9maWxlX2JpbmRpbmcucHkKKysrIGIvc2NyaXB0cy9jaS90ZXN0X3BxX3Byb29mX3Byb2ZpbGVfYmluZGluZy5weQpAQCAtMTgyLDYgKzE4MiwzNCBAQAogICAgICAgICB3aXRoIHNlbGYuYXNzZXJ0UmFpc2VzUmVnZXgoYmluZGluZy5Qcm9maWxlRXJyb3IsICdzb3VyY2UgcGluIGRpZmZlcnMnKToKICAgICAgICAgICAgIGJpbmRpbmcuaW5zcGVjdChyb290KQogCisgICAgZGVmIHRlc3RfZ3Jvd25fbWFwcGluZ19yZXRhaW5zX3RoZV9leGFjdF9vcmlnaW5hbF9ieXRlX2JvdW5kKHNlbGYpOgorICAgICAgICByb290ID0gc2VsZi5jaGVja291dCgpCisgICAgICAgIHBhdGggPSByb290IC8gYmluZGluZy5NQVBQSU5HCisgICAgICAgIHBhdGgud3JpdGVfYnl0ZXMocGF0aC5yZWFkX2J5dGVzKCkgKyBiJ1xuJykKKyAgICAgICAgd2l0aCBzZWxmLmFzc2VydFJhaXNlc1JlZ2V4KGJpbmRpbmcuU291cmNlUmVhZEVycm9yLCAnbm9ucmVndWxhci9vdmVyc2l6ZSBzb3VyY2UnKToKKyAgICAgICAgICAgIGJpbmRpbmcuaW5zcGVjdChyb290KQorCisgICAgZGVmIHRlc3Rfc2hydW5rZW5fbWFwcGluZ19pc19yZWZ1c2VkX3dpdGhvdXRfYV9waW5fcmVmcmVzaChzZWxmKToKKyAgICAgICAgcm9vdCA9IHNlbGYuY2hlY2tvdXQoKQorICAgICAgICBwYXRoID0gcm9vdCAvIGJpbmRpbmcuTUFQUElORworICAgICAgICBvcmlnaW5hbCA9IHBhdGgucmVhZF9ieXRlcygpCisgICAgICAgIHNlbGYuYXNzZXJ0VHJ1ZShvcmlnaW5hbC5lbmRzd2l0aChiJ1xuJykpCisgICAgICAgIHBhdGgud3JpdGVfYnl0ZXMob3JpZ2luYWxbOi0xXSkKKyAgICAgICAgd2l0aCBzZWxmLmFzc2VydFJhaXNlc1JlZ2V4KGJpbmRpbmcuUHJvZmlsZUVycm9yLCAnc291cmNlIHBpbiBkaWZmZXJzJyk6CisgICAgICAgICAgICBiaW5kaW5nLmluc3BlY3Qocm9vdCkKKworICAgIGRlZiB0ZXN0X3NhbWVfbGVuZ3RoX21hcHBpbmdfc3Vic3RpdHV0aW9uX2lzX3JlZnVzZWQoc2VsZik6CisgICAgICAgIHJvb3QgPSBzZWxmLmNoZWNrb3V0KCkKKyAgICAgICAgcGF0aCA9IHJvb3QgLyBiaW5kaW5nLk1BUFBJTkcKKyAgICAgICAgb3JpZ2luYWwgPSBwYXRoLnJlYWRfYnl0ZXMoKQorICAgICAgICBjaGFuZ2VkID0gb3JpZ2luYWwucmVwbGFjZShiJ09mZmxpbmUgcmVzZWFyY2ggbWFwcGluZyBvbmx5LicsCisgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGInb2ZmbGluZSByZXNlYXJjaCBtYXBwaW5nIG9ubHkuJywgMSkKKyAgICAgICAgc2VsZi5hc3NlcnROb3RFcXVhbChjaGFuZ2VkLCBvcmlnaW5hbCkKKyAgICAgICAgc2VsZi5hc3NlcnRFcXVhbChsZW4oY2hhbmdlZCksIGxlbihvcmlnaW5hbCkpCisgICAgICAgIHBhdGgud3JpdGVfYnl0ZXMoY2hhbmdlZCkKKyAgICAgICAgd2l0aCBzZWxmLmFzc2VydFJhaXNlc1JlZ2V4KGJpbmRpbmcuUHJvZmlsZUVycm9yLCAnc291cmNlIHBpbiBkaWZmZXJzJyk6CisgICAgICAgICAgICBiaW5kaW5nLmluc3BlY3Qocm9vdCkKKwogICAgIGRlZiB0ZXN0X2V4cGVjdGVkX3YxX2d1ZXN0X2Nhbm5vdF9yZXBsYWNlX3YyX2lkZW50aXR5KHNlbGYpOgogICAgICAgICByb290ID0gc2VsZi5jaGVja291dCgpCiAgICAgICAgIGNoYW5nZWQgPSBjb3B5LmRlZXBjb3B5KHNlbGYuY29udHJhY3QpCi0tLSBhL2NvbmZpZy9wb24vcHEtY3Jvc3MtYnJhbmNoLWNvcnB1cy12MS5qc29uCisrKyBiL2NvbmZpZy9wb24vcHEtY3Jvc3MtYnJhbmNoLWNvcnB1cy12MS5qc29uCkBAIC0xNDAsNyArMTQwLDcgQEAKICAgfSwKICAgInBhcmVudF9wcm9maWxlIjogInBvbi1uYWthbW90by12MSIsCiAgICJwaW5uZWRfYmxvYnMiOiB7Ci0gICAgIi5naXRodWIvd29ya2Zsb3dzL2NoYWluLWhlcHRhLWNsb3N1cmUtY2FuZGlkYXRlLnltbCI6ICIyNjY5OWE0NDAwM2Q0NDYyYjk3ZGQ4YWEzNjkwMjViYmFiZWY1MWJjIiwKKyAgICAiLmdpdGh1Yi93b3JrZmxvd3MvY2hhaW4taGVwdGEtY2xvc3VyZS1jYW5kaWRhdGUueW1sIjogIjgyZWZiMDNmZDg0MjgxYzdkOWU2NmYyZDU0NWY4ZjllMjY1YTBiZGIiLAogICAgICIuZ2l0aHViL3dvcmtmbG93cy9jb2RlcWwtcmVhbC1leGFjdC1zb3VyY2UueW1sIjogIjZkNzZjZGZlYTY5ZDZjMTQ2NjBkZjNhODhjZDI1Y2FkNGFkOTVkMjgiLAogICAgICIuZ2l0aHViL3dvcmtmbG93cy9jcHExLWZ1bGwtY29udGVudC55bWwiOiAiODdlY2JjMzFkNTE4N2E2YTAzOWMxMjExNzQ3MjdkNjExNmI0NjA4NiIsCiAgICAgIi5naXRodWIvd29ya2Zsb3dzL3Bvbi1icmFuY2gtZW5jb2RpbmctYWNjZXB0YW5jZS55bWwiOiAiYjIxZjQ4N2M1OGIyNjVjZTc4MGU2Yzk0NzJkYTZlZmFlYTBmNjlkYSIsCkBAIC0xNjksNyArMTY5LDcgQEAKICAgICAiY29uZmlnL3Bvbi9wcS1pbml0aWFsLXJvb3QtbWF0ZXJpYWwtcmVxdWlyZWQtdGVzdHMtdjEuanNvbiI6ICIwYzE0ZWJmNWM3MGZiMGY3ZWU4MjNkMzI0ODk3ZTEyZmI0MTgyMGM4IiwKICAgICAiY29uZmlnL3Bvbi9wcS1uYXRpdmUtdGxzLXJlcXVpcmVkLXRlc3RzLXYxLmpzb24iOiAiNzg5NDdjNWNkMmRiZTU0MzBhNjVlMzM4MDY1MWM5ZTgzN2FkZDM5MCIsCiAgICAgImNvbmZpZy9wb24vcHEtbmF0aXZlLXRscy13aXRuZXNzLXJlcXVpcmVkLXRlc3RzLXYxLmpzb24iOiAiNDc0YjVhYWVkOTA5MmRhZDhlMTI0MTIzMTNjZWUwOTNlMTZiMGIxMyIsCi0gICAgImNvbmZpZy9wb24vcHEtcHJvb2YtcHJvZmlsZS1iaW5kaW5nLXYxLmpzb24iOiAiNTQ4ODM5Yjg0NjYwYjg5NzFkY2RkOGJmNWZkMDE1NmEwZjljZmQ1NCIsCisgICAgImNvbmZpZy9wb24vcHEtcHJvb2YtcHJvZmlsZS1iaW5kaW5nLXYxLmpzb24iOiAiOWVlNTc5NmNlMTgyNGQ0OGY4NmE5NWI3ZTA4MGZmNzVlNTY4MDIxYSIsCiAgICAgImNvbmZpZy9wb24vcHEtcmVsZWFzZS1hdXRob3JpdHktcmVxdWlyZWQtdGVzdHMtdjIuanNvbiI6ICJhMDBlNGUwNGQ0MmY4MGIyMDZiNzE0Yzg4ZDU5NjllMDA3OGQzY2I5IiwKICAgICAiY29uZmlnL3Bvbi9wcS1yb290LWN1c3RvZHktcmV2aWV3LXYxLmpzb24iOiAiNDY2ZWUyZjk1ZDk1OTg5ZmVjZjA0ODcyMTgyYjE5NzEzYmZkYWZiNSIsCiAgICAgImNvbmZpZy9wb24vcHEtcm9vdC1jdXN0b2R5LXJldmlldy12Mi5qc29uIjogImQ0MGI5Zjk0ZGM2YzU4YzUwMmY1MTYxZmI4Y2NiNDYzZTA3NGI3MTAiLApAQCAtNjAzLDcgKzYwMyw3IEBACiAgICAgInNjcmlwdHMvY2kvdGVzdF9wcV9hdXRob3JpdHlfc3VyZmFjZV9zY2FuLnB5IjogImY5ODgzMjkxYTJhODQ0ZTczNDdkOWNmZDI2ZDdjMmY0NjI4ODg1MWIiLAogICAgICJzY3JpcHRzL2NpL3Rlc3RfcHFfY2hhaW5fY2xhaW1fZ3VhcmQucHkiOiAiOTVkNzc0NjNhMzVjNjkwYjE4OGQ1ZGJmY2IxNmViZjQ5OTI3NmNjNiIsCiAgICAgInNjcmlwdHMvY2kvdGVzdF9wcV9saWZldGltZV9idWRnZXQucHkiOiAiZmRlN2ZhM2YzODhkYjlhYjlmOTc2MGI5MjI5ZjkyOGE3YjJmMjc2NyIsCi0gICAgInNjcmlwdHMvY2kvdGVzdF9wcV9wcm9vZl9wcm9maWxlX2JpbmRpbmcucHkiOiAiNTdmNzY5YTA2MWQ4ODBhNWRhODQ4YTBmNGVjMWZlOGRkMTc2OTQ4YSIsCisgICAgInNjcmlwdHMvY2kvdGVzdF9wcV9wcm9vZl9wcm9maWxlX2JpbmRpbmcucHkiOiAiNTI0ZDA2N2FhMGMxY2ZhOTkyZTk3NTY1ZjhjMmQwN2I4OWVkNDYzNiIsCiAgICAgInNjcmlwdHMvY2kvdGVzdF9wcV9yZXNlYXJjaF9pbnRlZ3JhdGlvbi5weSI6ICI4MzU5YzNjMzY3M2NlZTY3MWIxMWFkNWZlMzQ5YTE0MDU2NDVjM2NkIiwKICAgICAic2NyaXB0cy9jaS90ZXN0X3BxX3Jvb3RfY3VzdG9keV9yZXZpZXdfdjEucHkiOiAiNjNkMWRkOTljMTBkYWE4MDcwNWM0YTFhYTc0ZjcyYjdlMzcyOTRjOSIsCiAgICAgInNjcmlwdHMvY2kvdGVzdF9wcV9yb290X2N1c3RvZHlfcmV2aWV3X3YyLnB5IjogIjBjMDhiYTJiZDFjODQ5Zjc2YmY4Y2EyNzI2MGFmNjNkYzIzMmQ4ZTMiLAo=',validate=True)
(out/'profile-binding-fix.patch').write_bytes(raw)
summary={'base_commit':base,'root':str(root),'records':[],'scope':'uncommitted exact four-file source candidate; no native execution or committed-source/hosted qualification','completed':False,'production_activation':False}
(out/'run-declaration.json').write_text(json.dumps({'root':str(root),'base':base,'patch_sha256':hashlib.sha256(raw).hexdigest(),'changed_paths':sorted(expected),'native_changes':False},indent=2)+'\n')
def run(stem,command,expected_exit=0,timeout=300):
 start=time.time_ns()
 with (out/(stem+'.begin.json')).open('x') as f: json.dump({'command':command,'cwd':str(root),'timeout':timeout,'expected_exit':expected_exit,'start_unix_ns':start},f)
 try:
  p=subprocess.run(command,cwd=root,capture_output=True,timeout=timeout,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','NO_COLOR':'1'})
  stdout,stderr,code,timed=p.stdout,p.stderr,p.returncode,False
 except subprocess.TimeoutExpired as e: stdout,stderr,code,timed=e.stdout or b'',e.stderr or b'',None,True
 (out/(stem+'.stdout')).write_bytes(stdout);(out/(stem+'.stderr')).write_bytes(stderr)
 row={'stem':stem,'command':command,'cwd':str(root),'exit':code,'expected_exit':expected_exit,'timed_out':timed,'elapsed_ns':time.time_ns()-start,'stdout_bytes':len(stdout),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_bytes':len(stderr),'stderr_sha256':hashlib.sha256(stderr).hexdigest()}
 summary['records'].append(row);(out/(stem+'.result.json')).write_text(json.dumps(row,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if timed or code!=expected_exit: raise RuntimeError(stem+' unexpected command result')
try:
 run('00-preflight',['bash','scripts/project-preflight.sh'])
 run('01-source-before',['python3','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',base,'--output',str(out/'source-before.json')])
 run('02-baseline-profile',['python3','scripts/ci/test_pq_proof_profile_binding.py','-v'],expected_exit=1)
 assert git('rev-parse','HEAD').decode().strip()==base and not git('status','--porcelain=v1','--untracked-files=all')
 for name,pins in expected.items(): assert blob((root/name).read_bytes())==pins[0],name
 run('03-apply-check',['git','apply','--check',str(out/'profile-binding-fix.patch')])
 run('04-apply',['git','apply',str(out/'profile-binding-fix.patch')])
 assert set(git('diff','--name-only').decode().splitlines())==set(expected)
 assert not git('ls-files','--others','--exclude-standard')
 for name,pins in expected.items(): assert blob((root/name).read_bytes())==pins[1],name
 for stem,command in [
 ('05-profile-tests',['python3','scripts/ci/test_pq_proof_profile_binding.py','-v']),
 ('06-exact-descriptor',['python3','scripts/ci/pq_proof_profile_binding.py','--expected-profile-descriptor-sha256','0d47e23d395d6332a0bdf1c9093cf5b19816aad9841e3db6e8cb24f53e0f18b3']),
 ('07-ci-contract-tests',['python3','scripts/ci/test_ci_contract.py','-v']),
 ('08-ci-contract-check',['python3','scripts/ci/check_ci_contract.py']),
 ('09-source-integrity-negatives',['python3','scripts/ci/test_ci_source_integrity.py','-v']),
 ('10-corpus-tests',['python3','scripts/ci/test_pq_research_integration.py','-v']),
 ('11-corpus-check',['python3','scripts/ci/check_pq_research_integration.py']),
 ('12-inventory',['python3','scripts/refresh_distributed_source_inventory.py','--check']),
 ('13-repository-tests',['python3','scripts/ci/test_repository.py','-v']),
 ('14-repository-markdown',['python3','scripts/ci/check_repository.py']),
 ('15-diff-whitespace',['git','diff','--check']),
 ('16-final-preflight',['bash','scripts/project-preflight.sh'])]:
  run(stem,command)
 assert git('rev-parse','HEAD').decode().strip()==base
 assert set(git('diff','--name-only').decode().splitlines())==set(expected)
 assert not git('ls-files','--others','--exclude-standard')
 for name,pins in expected.items(): assert blob((root/name).read_bytes())==pins[1],name
 diff=git('diff','--binary');(out/'observed-final.diff').write_bytes(diff)
 summary['changed_files']={name:{'bytes':len((root/name).read_bytes()),'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest(),'git_blob':blob((root/name).read_bytes())} for name in sorted(expected)}
 summary['final_diff_sha256']=hashlib.sha256(diff).hexdigest();summary['head_unchanged']=True;summary['completed']=True
except BaseException as error:
 summary['error']=repr(error);(out/'driver-failure.txt').write_text(traceback.format_exc())
finally:
 (out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'completed':summary['completed'],'records':len(summary['records']),'output':str(out),'error':summary.get('error')}),flush=True)
sys.exit(0 if summary['completed'] else 1)
