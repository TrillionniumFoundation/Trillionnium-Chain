# 552 Cell runtime 与 PQ current-view 的只读调用审查

## 结论

**最小安全合并不需要削弱 `VerifiedCellPqReleaseV2::release_at`。保留本地 P2 的完整 current-view API、负例与 CLI 认证块，再叠加 552 的服务就绪、取消、驻留张量和存储义务改动。** 本次在已检查路径中没有发现第二个需要改变 PQ API 的生产调用，也没有找到此次三方合并引入的、可由所读代码确定的另一个旧资金/未知结果绕过。

这不是全链 PQ 授权闭环结论。552 的新增 TCA2 存储接口与驻留张量接口没有接入 publisher current-view；它们分别执行存储义务和验证字节，不拥有 CURRENT/FinalUse 权限。已有签名、存储 ACK、张量句柄或资金快照均不能被提升为这些权限。

## 固定审查源码与方法

- 三方基线：`2e7fbaeabc396d501d9d802adc63df963f1d288c`。
- 本地 P2：`2cc4aaa0da7ebcbf7de665bf293effb206d1e445`。
- 新增 Cell runtime：`55257c61c46a2687669a0ed6b317b7263db0bd5a`。
- 比较依据：`receipts/incoming-552-compare.json` 的完整 2e7...552 API compare，以及以上固定提交的 `git show` / `git grep` / `git diff`。
- 552 精确对象最初从 `/workspace/scratch/0c2d131ac5a9/chain-storage` 只读读取；随后 capacity 审计线程已将整个 552 tree 恢复到 root 自己的对象库。
- 本次只读代码审查；未运行 Cargo 或任何测试，未修改源码、HEAD、index 或远端。仅写此报告。写报告前 `project-preflight.sh` 结果为 PASS、26 packages。

P2 与 552 相对 2e7 的改动交集共四个路径：corpus 配置、唯一开发计划、`trnm-cell.rs`、分布式源码 inventory。**生产 Rust 交集只有 `trnm-cell.rs`，且两侧修改的区域分离。** 对 552 的源码阅读不是最终合并树的测试结果，既往 363 项通过记录也不能转记到尚未测试的合并树。

| 路径（相对 `trillionnium/crates/`） | 2e7 blob | P2 blob | 552 blob |
|---|---|---|---|
| `trnm-data-availability/src/bin/trnm-cell.rs` | `5ac13d27aea2430e28653dcd46eff35610cdb609` | `16f087a25f544b6ceabd6473d09cde9cf1c78520` | `e99237f490655753533a2a1ea258ff99edf5e35f` |
| `trnm-data-availability/src/cell/pq.rs` | `bf773ce44f40f8a7facb43a09297267e041f490a` | `716646e95bc507e2e901fd5320a982e47766f482` | 与 2e7 相同 |
| `trnm-data-availability/src/cell/pq/tests.rs` | `7ed1b2a9af072cada29d5369bf1bc48a3e0ad4e8` | `79c7f6cd9fae5016465370f306ecc1ebe28ab907` | 与 2e7 相同 |
| `trnm-data-availability/src/cell/release.rs` | `46c7236c362fb065dfe78cb55146a5e8a7488875` | 与 2e7 相同 | `5791802e3c25a8b5271af36cf2cc4b9dcdf37e72` |
| `trnm-service-settlement/src/native_budget.rs` | `2cc37bada4a6d68b9ce21d3d471006fdc3b5ffe7` | 与 2e7 相同 | `f8e5c12c3015d4c25eb8d5cc87ee944578405783` |
| `trnm-pon-node/src/store/funding.rs` | `71ab19e0ad93dc6962ca91c74c2f5c606e6fdca2` | 与 2e7 相同 | 与 2e7 相同 |
| `trnm-pon-node/src/store/storage_service/release.rs` | 不存在 | 不存在 | `daef6ff4c8a52745c29f552f99757fa8bb1636ce` |
| `trnm-pon-node/src/store/storage_service/release_tests.rs` | 不存在 | 不存在 | `6e343a5a7d1b4ba52da55a1301ee2b079a35f041` |
| `trnm-data-availability/src/cell/residency/tensor.rs` | 不存在 | 不存在 | `805515659ca9589373828874e2ddf11bb9bbf896` |

## 1. 唯一 PQ 生产调用与必须保留的适配

552 的 `trnm-cell.rs:617–627` 仍使用旧形式：先用临时 expectation 验签，再调用 `checked.release_at(wall.as_secs())`。552 对本文件的新增 patch 全在服务 readiness 区域，没有修改这段认证逻辑；`pq.rs`、`pq/tests.rs` 也没有在 552 中改变。不能通过复制整份 552 CLI、回退 `pq.rs`、增加 now-only 兼容入口，或跳过 `release_at` 来消除编译差异。

保留 P2 中已有的这一块即可：

```rust
let expected = CellPqReleaseExpectationV2 {
    network: *network,
    parameters: *parameters,
    key,
    sequence: *sequence,
    now: wall.as_secs(),
};
let checked = auth.verify_at(release, &expected)?;
// This CLI pins an immutable acquisition policy for this command.
// Runtime activation requires the actual owner's current view.
checked.release_at(&expected)?;
```

随后原有 `checked.expires_at()` 到单调时钟 `limits.deadline` 的收紧及最终 deadline 检查也应保留。它限定本次 CLI 下载/验证命令的有效窗口；该命令的 pin、generation、sequence 仍是本次输入的不可变 acquisition policy，不能声称存在在线撤销订阅或普通 CURRENT 激活。

P2 的 `release_at(&current)` 必须继续校验：key 编码/ID、key 当前 lifetime/revocation、network、parameters、signer key ID、key generation、owner sequence，以及证明的 verification/expiry 时间范围。签名 statement 自报的 key/sequence 不是独立 current view；不能据此构造替代 current。资金 anchor 的 generation 也不是 publisher key generation。

源内有意保留的 `release_at(300)` 出现在 compile-fail 文档负例中。合并后不能用“所有旧语法字符串都应消失”的文本规则删掉这个负例。

## 2. 新增真实效果接口的权限范围

| 新路径 | 当前检查与效果 | 缺少的 PQ / 使用授权集成 |
|---|---|---|
| `Node::retain_native_cell_release` | 完整 TCA2 合同、成员/资金绑定、真实 Node funding owner、持久 intent、物理目标读回 | 请求不含 `VerifiedCellPqReleaseV2` 或当前 publisher owner；不能把存储成功视为发布、CURRENT 或 FinalUse 授权 |
| `repair_native_cell_release_member` | 原 root/member、独立 task/claim/repair operation、repair CPU/window、目标读回 | 没有 current publisher view；修复存储义务不会恢复被撤销的模型使用权 |
| `retire_native_cell_release` / member retirement | 原完成效果、当前原生链 anchor、完整 rooted GC、共享引用与未结 repair 检查 | 当前链高度和保管到期不是 publisher rotation/revocation 授权 |
| `admit_local_tensor_model` / `admit_selected_tensor_model` | 独立 TMA1 pin、caller loader context、驻留字节完整解析、deadline/cancellation、借用期间防本地 eviction | typed handle 与 process-local selection 不检查 publisher current-view、CURRENT 或 FinalUse |
| `fetch_closure_cancellable` | 原预算与 deadline、取消锁存、缓存字节；不发布 CURRENT | 没有赋予模型选择或执行权 |

在 552 的 `trillionnium` 与 `scripts` 源码内搜索，新增 Node release 方法的调用仅见其单元测试；新增 typed admission 的外部调用也仅见测试/文档示例，内部 selected 方法调用 local 方法。没有找到 ordinary daemon/Hepta 执行入口调用这些方法的证据。

将来接入真正的 activation、设备安装或 FinalUse 效果时，最小正确集成点在拥有该效果的 owner：在实际提交前获取当前可信根/撤销/sequence 视图，调用 `release_at(&current)` 并绑定 exact release，再与该 owner 的撤销/代际改变序列化或做提交前代际复验。复制旧 expectation、只传 now、从远端 release 自报数据生成 pin，均不能完成这一责任。此报告没有提出把通用字节或存储 API 改造成伪造的授权 capability。

## 3. 资金、重放与未知结果：必须保留的现有安全结构

552 `storage_service/release.rs` 与 `native_budget.rs` 的新增组合结构应成组保留；它们不与 P2 的资金代码修改冲突，因为 P2 对这些路径相对 2e7 没有变化。

1. `release_checks` 绑定完整合同 commitment、原成员合同、任务来源、claim subject、beneficiary、字节和 byte-block 预留。outer 与每个 physical member 使用不同 task；多个 release 共享成员时，保留成员原 operation/claim/条款，不能重命名或延长物理租期。
2. `check_effects` 在临时台账快照上依次应用原 `Open/Reserve/Intent` 验证，发现后续成员资金缺失时不写任何台账。该预检返回值不是执行许可。实际 `open_budget`、`reserve` 与新 `begin_effect_in_window` 再读原生 owner；已有 exact replay 只能沿原身份返回 Pending/Done。
3. `check_recovery_members` 在预检后和真实 intent 后都执行。outer 已是 Pending/Done 时，所有成员必须已有 intent；不能借 outer 历史补造缺失成员工作。
4. 所有成员 intent 先于 outer intent，且所有 intent 先于初次物理复制。只有 outer=New 且该 member=New 才调用带 cache 的 `acknowledge_member`。member Pending/Done 走无 cache 的 `reconcile_member`；outer Pending/Done 直接走无 source/cache 参数的 `reconcile_release`。中断后补齐 cache 不会再次发出旧复制。
5. 修复是新 task/claim/repair operation，subject 绑定完整原 root 和 exact member；旧 repair 的 Pending/Done 只调用 `reconcile_repair_member`。旧修复到期仍可回读原目标，不能变成新复制或新收费。
6. `complete_effect` 写本地目标 receipt，不发行资金、记账退款或证明付款。新增 Node release 路径没有调用 `record_native_payment`；真实付款仍须由原生交易/奖励效果及 `observe_payment` 验证。`record_native_payment` 与 `reobserve_native_payment` 并未被 552 改写，当前链读回失败也不授权再次付款。
7. 数据库提交后 deadline 失败仍可能是 unknown caller outcome；以原 operation 重试必须读回已持久状态。失败/未知不撤销预留、不清空 operation、不生成退款；原 `record_resources(Unknown, None)` 按完整 reservation 计成本。
8. 重组后 funding row 可以消失；新 intent 因缺失当前来源而拒绝。原 exact effects 可读回物理义务，不把资金消失变为回滚本地成本/历史的理由。retirement 从原完成的效果读取当前原生 anchor，遍历成员时要求 anchor 相等，并继续执行 rooted GC。

源码定位：552 `storage_service/release.rs:185–196, 212–328, 334–460, 465–560`；`native_budget.rs:868–957, 959–1122, 1125–1234, 1356–1374, 1580–1680`；`archive.rs:550–649, 743–777, 807–843, 957–986`。这些检查不是跨 Node/M12/存储 owner 的原子事务，也没有保证运营者把所有外部台账回滚到旧备份时仍具备外部防回滚 fence。

## 4. 最小合并要求与限定回归建议

### 必须的代码保留

- 保留 P2 `pq.rs` blob `716646e95bc507e2e901fd5320a982e47766f482` 及 `pq/tests.rs` blob `79c7f6cd9fae5016465370f306ecc1ebe28ab907`。
- CLI 合并同时包含 P2 `release_at(&expected)` 和 552 readiness 改动；不能整文件回退到任一方来消解冲突。
- 接入 552 `cell/release.rs` 取消逻辑时，保留 no-marker 末端 `check_deadline(deadline)` 并新增 `session.check_cancelled()`，不能用取消检查替换时间检查。
- 成组保留 552 Node release、archive 的 member/reconcile API、native_budget 的 composition preflight 及对应测试。不能把 New/Pending/Done 合并到带 cache 的统一重试路径。

### 在最终固定源码上值得执行的已有测试

本审查没有执行下列测试；它们只是已经定位到的有意义回归范围，交由主线程按资源安排运行并记录实际结果：

- M09 `cell::pq::tests` 五项，尤其 `cached_release_rechecks_current_retirement_rotation_scope_and_sequence`、`selecting_old_content_requires_a_new_owner_approved_sequence`；保留 now-only 的 compile-fail 文档负例。
- `pq_cell_cli` 两项，尤其 `original_release_cli_pq_fetch_checks_auth_before_cache_or_marker`；它能覆盖 CLI 适配后的真实命令入口。
- 552 `store::storage_service::release_tests`：complete/shared/reopen、scope/late-funding、outer-missing-member-intent、interrupted-members-no-redispatch、reorg-no-fresh-funding、repair-scope/deadline/exact-reconciliation。
- M12 `composition_preflight_checks_late_funding_failure_without_changing_the_journal` 与 `composition_preflight_is_not_authority_and_exact_recovery_keeps_original_context`。后者源码明确包含预检后 source 消失导致 reserve/begin 拒绝，以及 exact Pending/Done 重放仍检查 owner context。
- 原 no-marker deadline 负例和 552 `residency_prefetch_stops_payload_requests_when_original_owner_cancels`，确认新增 cancellation 不使 timeout 或部分效果变为成功。

## 5. 仍不能声称的结论

本次审查不支持“全部授权入口受当前 PQ 根约束”“CURRENT/FinalUse 闭合”“存储 ACK 即原生付款”“回滚旧备份不会破坏外部效果”“独立多方已完成验收”或“最终合并源码全部测试通过”。本次可以声称：固定两侧源码的调用/资金重放结构已完成只读审查，确定了唯一 PQ 调用适配保留点，并明确新增 runtime 的授权边界与必须保留的未知结果语义。
