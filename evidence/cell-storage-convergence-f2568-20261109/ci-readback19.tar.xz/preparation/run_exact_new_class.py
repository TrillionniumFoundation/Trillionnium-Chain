import ast,hashlib,json,pathlib,subprocess,sys,tempfile,unittest
path=pathlib.Path(sys.argv[1]);tree=ast.parse(path.read_text())
nodes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CellCurrentApiReadbackTests'];assert len(nodes)==1
namespace={'__name__':'cell_current_api_preparation','__file__':str(path),'Path':pathlib.Path,'hashlib':hashlib,'json':json,'subprocess':subprocess,'sys':sys,'tempfile':tempfile,'unittest':unittest}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec',dont_inherit=True),namespace)
case=namespace['CellCurrentApiReadbackTests']
suite=unittest.TestSuite([case('test_actual_current_view_doc_observation_is_accepted')]) if sys.argv[2]=='red' else unittest.defaultTestLoader.loadTestsFromTestCase(case)
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
