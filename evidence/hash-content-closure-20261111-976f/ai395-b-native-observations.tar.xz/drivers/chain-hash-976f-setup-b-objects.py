#!/usr/bin/env python3
"""Continue after exact base objects are present, preserving every prior failure."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

SOURCE = Path('/home/qq/trnm-v4-e12ecc-recovery/repo')
REPO = Path('/home/qq/chain-hash-transitive-976f-20261111')
OUT = Path('/home/qq/chain-hash-transitive-976f-20261111-native-b')
BUNDLE = Path('/tmp/chain-hash-source-b-976f-9fd6ee29.bundle')
B = '9fd6ee29a7a663cef547040d9d42cc36a371a17e'
TREE = '7351f83fa9ac5c0e7540fa64bce06ea6f328602f'
BASE = '6ac9a79c2fb37d6102c526c354fe2d448a9f4e6d'
BRANCH = 'fix/chain-hash-transitive-20261111-976f'
PROVIDER = Path('/home/qq/trnm-v4-e12ecc-recovery/tmp/trnm-pq-provider-3.5.9.EuFYF5vc/install')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args, cwd=REPO):
    return subprocess.check_output(['git', *args], cwd=cwd, env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'), text=True).strip()


def main():
    previous = json.loads((OUT / 'setup-complete-summary.json').read_text())
    assert previous['candidate'] == B and previous['status'] == 'failed'
    assert [(c['label'], c['exit_code']) for c in previous['commands']] == [('task-promisor-format', 0), ('task-promisor-extension', 0), ('task-promisor-remote', 0), ('task-promisor-filter', 0), ('fetch-exact-base-blobs', 1)]
    assert "bad revision '07044acb3d1289940b917cd02a944d00b6f90ed5'" in (OUT / 'setup-complete/fetch-exact-base-blobs.log').read_text()
    assert list(p.name for p in REPO.iterdir()) == ['.git']
    assert git('branch', '--show-current') == BRANCH
    assert git('remote', 'get-url', 'origin') == 'https://github.com/TrillionniumFoundation/Trillionnium-Chain.git'
    common = Path(git('rev-parse', '--path-format=absolute', '--git-common-dir', cwd=SOURCE)).resolve(strict=True)
    objects = (common / 'objects').resolve(strict=True)
    assert (REPO / '.git/objects/info/alternates').read_text() == str(objects) + '\n'
    assert git('cat-file', '-t', BASE) == 'commit'
    assert digest(BUNDLE) == 'db5efc64269d1cc15ad0681fc5185832be1db0879791aae16d279497d28a1fa5'
    logs = OUT / 'setup-objects'
    logs.mkdir()
    summary = OUT / 'setup-objects-summary.json'
    record = {'candidate': B, 'tree': TREE, 'base': BASE, 'status': 'running', 'commands': [],
              'prior_failure_preserved': str(OUT / 'setup-complete-summary.json'),
              'started_utc': datetime.now(timezone.utc).isoformat()}
    with summary.open('x') as stream:
        json.dump(record, stream, indent=2)

    def run(label, argv, env=None):
        log = logs / (label + '.log')
        with log.open('xb') as stream:
            code = subprocess.run(argv, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT).returncode
        record['commands'].append({'label': label, 'argv': argv, 'exit_code': code, 'log': str(log),
                                   'bytes': log.stat().st_size, 'sha256': digest(log)})
        summary.write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps({'setup_objects': label, 'exit_code': code}), flush=True)
        if code:
            raise RuntimeError('setup continuation failed: ' + label)

    try:
        assert git('rev-parse', 'HEAD') == BASE
        missing = ["07044acb3d1289940b917cd02a944d00b6f90ed5","127461ab89ba0c669ae6bb633263e71b74300e75","4c860d26d023a27c5f08f3db23a25d8e6c3e4e23","590a45c388b54fbd83ce105fd7e7b732d5ea3e63","6b8a0824630cef2d084b803f189d8fb54aafce76","74a6ac339f147f789b74f3bad14339aae7be6670","7779393c9919bf66eedc155c604a5d658adb72db","a766d083bc1955041bf2fc537cb2731e2d4eb6c4","c387c55c920707f803408b8543a02aa215263339","cc1085716b5d0b77541440952171827f2d54cf9c","d4c9f7f9b2fbd8bd5e8f4f832e46d99aae5ce8df","fde50ae18fa370b19042b24243b6f023fb3f6f77"]
        checked = subprocess.check_output(['git', 'cat-file', '--batch-check'], cwd=REPO,
            input='\n'.join(missing) + '\n', text=True,
            env=dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0'))
        (logs / 'base-object-check.log').write_text(checked)
        rows = checked.splitlines()
        assert len(rows) == len(missing)
        assert all(row.split()[:2] == [oid, 'blob'] for row, oid in zip(rows, missing))
        run('bundle-verify', ['git', 'bundle', 'verify', str(BUNDLE)])
        run('bundle-unbundle', ['git', 'bundle', 'unbundle', str(BUNDLE)])
        # Enumerate only B's actual tree, without old refs or unrelated history.
        for round_number in range(16):
            listing = subprocess.check_output(
                ['git', 'rev-list', '--objects', '--no-object-names', '--missing=print', B + '^{tree}'],
                cwd=REPO, env=dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0'), text=True)
            pending = sorted(set(line[1:] for line in listing.splitlines() if line.startswith('?')))
            if any(len(oid) != 40 or any(c not in '0123456789abcdef' for c in oid) for oid in pending):
                raise RuntimeError('noncanonical missing source object')
            if len(pending) > 100000:
                raise RuntimeError('source object admission limit')
            with (logs / ('missing-tree-round-' + str(round_number) + '.json')).open('x') as stream:
                json.dump({'candidate': B, 'missing': pending}, stream, indent=2)
            print(json.dumps({'missing_source_round': round_number, 'objects': len(pending)}), flush=True)
            if not pending:
                break
            for offset in range(0, len(pending), 128):
                run('fetch-b-tree-' + str(round_number) + '-' + str(offset),
                    ['git', '-c', 'fetch.negotiationAlgorithm=noop', '-c', 'protocol.version=2', '-c', 'http.lowSpeedLimit=1', '-c', 'http.lowSpeedTime=60',
                     'fetch', '--no-tags', '--no-write-fetch-head', '--no-auto-maintenance', '--recurse-submodules=no', '--no-filter', 'origin', *pending[offset:offset + 128]],
                    dict(os.environ, GIT_TERMINAL_PROMPT='0'))
        else:
            raise RuntimeError('source object traversal still incomplete')
        run('checkout-b', ['git', 'reset', '--hard', B])
        assert git('rev-parse', 'HEAD') == B and git('rev-parse', 'HEAD^{tree}') == TREE
        run('preflight', ['bash', 'scripts/project-preflight.sh'])
        run('source-before', [sys.executable, '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', B,
                              '--output', str(OUT / 'source-before.json')], dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        print('CMH2_B_CHECKOUT_READY ' + str(REPO), flush=True)
        for name in ['registry', 'git']:
            source = Path('/home/qq/trnm-v4-e12ecc-recovery/cargo-home') / name
            if source.is_dir():
                run('copy-cargo-' + name, ['cp', '-a', '--reflink=auto', str(source), str(OUT / 'cargo-home' / name)])
        allowed = {'OPENSSL_DIR', 'OPENSSL_STATIC', 'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256',
                   'TRNM_PQ_OPENSSL_VERSION', 'OPENSSL_CONF', 'OPENSSL_MODULES'}
        values = dict(line.split('=', 1) for line in Path('/home/qq/trnm-v4-e12ecc-recovery/provider.env').read_text().splitlines()
                      if '=' in line and line.split('=', 1)[0] in allowed)
        assert set(values) == allowed and values['OPENSSL_DIR'] == str(PROVIDER)
        assert values['OPENSSL_STATIC'] == '1' and values['TRNM_PQ_OPENSSL_VERSION'] == '3.5.9'
        assert values['TRNM_PQ_OPENSSL'] == str(PROVIDER / 'bin/openssl')
        identities = [{'path': str(PROVIDER / name), 'bytes': (PROVIDER / name).stat().st_size,
                       'sha256': digest(PROVIDER / name)}
                      for name in ['bin/openssl', 'lib/libcrypto.a', 'lib/libssl.a', 'include/openssl/opensslv.h']]
        assert identities[0]['sha256'] == values['TRNM_PQ_OPENSSL_SHA256']
        environment = dict(values, CARGO_HOME=str(OUT / 'cargo-home'), CARGO_TARGET_DIR=str(OUT / 'target'),
                           CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', RUST_TEST_THREADS='1', RUSTUP_TOOLCHAIN='1.95.0',
                           PYTHONDONTWRITEBYTECODE='1', PATH='/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:/home/qq/.cargo/bin:/usr/local/bin:/usr/bin:/bin')
        with (OUT / 'environment.json').open('x') as stream:
            json.dump(environment, stream, sort_keys=True, indent=2)
        with (OUT / 'provider-identities.json').open('x') as stream:
            json.dump(identities, stream, sort_keys=True, indent=2)
        child_env = dict(os.environ, **environment)
        for key in list(child_env):
            if key in {'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'} or key.startswith('CARGO_PROFILE_'):
                child_env.pop(key)
        run('rust-195', ['rustc', '--version', '--verbose'], child_env)
        run('cargo-195', ['cargo', '--version'], child_env)
        run('openssl-359', [str(PROVIDER / 'bin/openssl'), 'version', '-a'], child_env)
        record['status'] = 'ready'
        record['environment_file'] = str(OUT / 'environment.json')
        print('CMH2_NATIVE_B_READY ' + str(OUT), flush=True)
    except Exception as error:
        record.update(status='failed', error=str(error))
        raise
    finally:
        record['finished_utc'] = datetime.now(timezone.utc).isoformat()
        summary.write_text(json.dumps(record, indent=2) + '\n')


if __name__ == '__main__':
    main()
