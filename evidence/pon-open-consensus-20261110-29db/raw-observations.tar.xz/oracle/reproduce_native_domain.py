"""Reproduce Python-oracle inputs rejected by the unchanged native contract."""
import hashlib
import importlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
root = Path.cwd()
module_name = sys.argv[1] if len(sys.argv) > 1 else 'reference'
if module_name not in ('reference', 'native_consensus_reference_v1'):
    raise SystemExit('unsupported oracle module')
source = root / 'formal/pon-nakamoto-v1' / (module_name + '.py')
sys.path.insert(0, str(source.parent))
module = importlib.import_module(module_name)
retarget, timestamp_state = module.retarget, module.timestamp_state

u64_max = (1 << 64) - 1
u256_max = (1 << 256) - 1
cases = (
    ('empty-ancestry', lambda: timestamp_state(1, [], 1, 0), 'UNKNOWN_PARENT'),
    ('retarget-desired-overflow',
     lambda: retarget(1, 0, u64_max, 16, u64_max // 15 + 1, u256_max),
     'TARGET_PARAMETERS'),
    ('retarget-upper-clamp-overflow',
     lambda: retarget(1, 0, u64_max, 16, u64_max // 60 + 1, u256_max),
     'TARGET_PARAMETERS'),
    ('retarget-maximum-interval',
     lambda: retarget(1, 0, u64_max, u64_max, 1, u256_max),
     'TARGET_PARAMETERS'),
    ('timestamp-outside-native-u64',
     lambda: timestamp_state(1 << 64, [0], 1 << 64, 0),
     'outside-native-u64-domain'),
)
observations = []
for name, call, expected in cases:
    try:
        observed = call()
        refused = False
    except ValueError as error:
        observed = str(error)
        refused = True
    observations.append(dict(case=name, expected_native_refusal=expected,
                             python_refused=refused, observed=observed))
print(json.dumps({
    'schema': 'pon-independent-oracle-domain-reproduction-v1',
    'oracle_module': module_name,
    'head_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'reference_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'scope': 'Python oracle input-domain checks; no new native execution or network exploit claim',
    'production_activation': False,
    'cases': observations,
}, indent=2, sort_keys=True))
raise SystemExit(0 if all(row['python_refused'] for row in observations) else 1)
