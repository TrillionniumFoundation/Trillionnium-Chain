"""Read recorded outputs independently; never rerun product tests or campaigns."""
import argparse
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import subprocess


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def resource_arithmetic(value):
    kinds = ('X', 'CNOT', 'Toffoli')
    for name, stage in value['stages'].items():
        gates = {kind: sum(value['leaves'][leaf]['wrapped_gate_counts'][kind] * count
                          for leaf, count in stage['calls'].items()) for kind in kinds}
        require(gates == stage['gate_counts'], 'stage gate counts: ' + name)
        require(sum(gates.values()) == stage['gate_count'], 'stage total: ' + name)
        depth = sum(value['leaves'][leaf]['wrapped_depth_upper_bound'] * count
                    for leaf, count in stage['calls'].items())
        require(depth == stage['depth_upper_bound'], 'stage depth: ' + name)
    forward = {kind: sum(stage['gate_counts'][kind] for stage in value['stages'].values())
               + int(kind == 'X') for kind in kinds}
    require(forward == value['forward_gate_counts'], 'forward gate counts')
    require(sum(forward.values()) == value['forward_gate_count'], 'forward total')
    require(value['phase_oracle_gate_count'] == 2 * value['forward_gate_count'] + 1,
            'phase total')
    require(value['phase_oracle_depth_upper_bound'] == 2 * (
        1 + sum(stage['depth_upper_bound'] for stage in value['stages'].values())) + 1,
        'phase depth')
    require(value['logical_qubits'] == value['persistent_register_qubits']
            + value['reused_workspace_qubits'], 'logical qubits')
    for flag in ('native_node_admission_verified', 'quantum_hardware_executed',
                 'quantum_work_lower_bound_proved', 'quantum_mining_security_qualified',
                 'production_activation'):
        require(value[flag] is False, 'resource qualification: ' + flag)
    return True


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--input', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--head', required=True)
parser.add_argument('--tree', required=True)
args = parser.parse_args()
root, base = args.root, args.input
require(subprocess.check_output(['git', 'rev-parse', args.head + '^{tree}'], cwd=root,
                                text=True).strip() == args.tree, 'git tree identity')
runner = read_json(base / 'runner.json')
result = read_json(base / 'result.json')
progress = read_json(base / 'progress.json')
require(runner['head'] == result['head'] == args.head, 'runner head')
require(runner['tree'] == result['tree'] == args.tree, 'runner tree')
require(result['commands'] == progress, 'terminal/progress records differ')
require(result['not_executed'] == [] and result['all_commands_succeeded'] is True,
        'incomplete terminal runner')
require(len(progress) == 13 and len({row['label'] for row in progress}) == 13,
        'command cardinality')
require(set(runner['planned_commands']) == {row['label'] for row in progress},
        'planned command set')
for key in ('whole_chain_pq_qualified', 'public_wan_qualified', 'production_activation'):
    require(result[key] is False, 'terminal qualification: ' + key)

commands, all_names, suite_counts, outputs = [], [], {}, {}
for row in progress:
    label = row['label']
    receipt_path, log_path = base / (label + '.json'), base / (label + '.log')
    receipt_raw, log_raw = receipt_path.read_bytes(), log_path.read_bytes()
    receipt = json.loads(receipt_raw)
    require(sha(receipt_raw) == row['receipt_sha256'], 'receipt digest: ' + label)
    require(sha(log_raw) == receipt['log_sha256'] and len(log_raw) == receipt['log_bytes'],
            'log digest or byte count: ' + label)
    require(receipt['log_file'] == log_path.name, 'log binding: ' + label)
    require(receipt['exit_code'] == row['command_exit'] == row['recorder_exit'] == 0,
            'nonzero exit: ' + label)
    require(receipt['status'] == row['status'] == 'command_succeeded', 'status: ' + label)
    require(receipt['argv'] == ['timeout', str(row['cap_seconds']), *row['command']],
            'actual command: ' + label)
    require(receipt['before'] == receipt['after'], 'source changed: ' + label)
    identity = receipt['before']
    require(identity['candidate'] == identity['tested_commit'] == args.head
            and identity['tested_tree'] == args.tree
            and identity['tracked_worktree_verified'] is True, 'source identity: ' + label)
    require(receipt['whole_chain_quantum_security_qualified'] is False, 'receipt qualification')
    item = {'label': label, 'argv': receipt['argv'], 'exit_code': receipt['exit_code'],
            'receipt_file': str(receipt_path), 'receipt_sha256': sha(receipt_raw),
            'log_file': str(log_path), 'log_sha256': sha(log_raw), 'log_bytes': len(log_raw),
            'recorder_log_sha256': sha((base / (label + '.recorder.log')).read_bytes()),
            'source_before_after_equal': True,
            'tracked_entries': identity['tracked_entries'],
            'tracked_bytes': identity['tracked_bytes']}
    if label.startswith('test_'):
        text = log_raw.decode()
        names = re.findall(r'^test_[^\n]*?\(([^\n]+)\) \.\.\. ok$', text, re.M)
        totals = re.findall(r'^Ran ([0-9]+) tests? in ', text, re.M)
        require(len(totals) == 1 and len(names) == int(totals[0])
                == row['unittest_parent_count'] and re.search(r'^OK\s*$', text, re.M),
                'actual unittest outcomes: ' + label)
        suite_counts[label] = len(names)
        all_names += names
        item['passed_test_names'] = names
    else:
        outputs[label] = json.loads(log_raw)
        item['observed_stdout'] = outputs[label]
    commands.append(item)
require(len(suite_counts) == 9 and len(all_names) == len(set(all_names)) == 182,
        'unit test total or duplicate identity')

source_cache = {}
def source_readback(source, count):
    require(source['git_head'] == args.head and source['all_sources_committed_at_head'] is True
            and source['uncommitted_source_files'] == [], 'campaign source commitment')
    require(len(source['source_sha256']) == count, 'declared source count')
    for name, digest in source['source_sha256'].items():
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts, 'unsafe source path')
        if name not in source_cache:
            raw = subprocess.check_output(['git', 'show', args.head + ':' + name], cwd=root)
            source_cache[name] = {'committed_sha256': sha(raw),
                                  'working_file_sha256': sha((root / name).read_bytes())}
        require(source_cache[name]['committed_sha256'] == digest
                == source_cache[name]['working_file_sha256'], 'source hash: ' + name)
    return source

reports, artifacts = {}, {}
for name, count in (('constructive', 16), ('restricted', 18)):
    directory = base / (name + '-campaign')
    require({path.name for path in directory.iterdir()} == {'report.json', 'manifest.json'},
            'campaign inventory: ' + name)
    raw = (directory / 'report.json').read_bytes()
    manifest_raw = (directory / 'manifest.json').read_bytes()
    report, manifest = json.loads(raw), json.loads(manifest_raw)
    require(manifest['report_sha256'] == sha(raw), 'campaign digest: ' + name)
    source_readback(report['source'], count)
    for action, flag in (('observe', '--out'), ('replay', '--verify')):
        row = next(row for row in progress if row['label'] == name + '-' + action)
        require(row['command'][-2:] == [flag, str(directory)], 'campaign command binding')
    artifacts[name] = {'report_file': str(directory / 'report.json'),
                       'report_sha256': sha(raw), 'report_bytes': len(raw),
                       'manifest_sha256': sha(manifest_raw),
                       'declared_sources': count, 'source': report['source'],
                       'assertions': report['assertions']}
    reports[name] = report

constructive = reports['constructive']
require(constructive['historical_native_control'] is None
        and constructive['historical_input_locations'] is None, 'unexpected historical control')
require(outputs['constructive-observe']['report_sha256'] == artifacts['constructive']['report_sha256']
        and outputs['constructive-observe']['bytes'] == artifacts['constructive']['report_bytes'],
        'observe stdout/artifact digest')
require(outputs['constructive-replay']['result'] == 'CONSTRUCTIVE_SOURCE_BOUND_REPLAY_PASS',
        'constructive replay result')
constructive_cases = []
for row in constructive['records']:
    resources, observed = row['resources'], row['observation']
    resource_arithmetic(resources)
    require(observed['clean_ancillas'] is True and observed['nonce_preserved'] is True
            and observed['inverse_executed'] is True, 'constructive uncompute')
    if row['execution_mode'] == 'gates':
        require(observed['leaf_gates_executed'] + observed['outer_X_Z_gates_executed']
                == resources['phase_oracle_gate_count'], 'executed constructive gate count')
    constructive_cases.append({'name': row['name'], 'nonce': row['nonce'],
        'execution_mode': row['execution_mode'], 'observation': observed,
        'metrics': {key: resources[key] for key in ('profile', 'logical_qubits',
            'forward_gate_count', 'phase_oracle_gate_count', 'phase_oracle_depth_upper_bound')},
        'recorded_resource_arithmetic_consistent': True})
require(len(constructive_cases) == outputs['constructive-observe']['cases']
        == outputs['constructive-replay']['cases'] == 4, 'constructive case count')
require(sum(row['execution_mode'] == 'macro' for row in constructive_cases) == 2,
        'constructive execution scope')

restricted = reports['restricted']
restricted_cases, proof_hashes = [], []
for row in restricted['records']['cases']:
    domain, macros = row['domain'], row['macro_observations']
    outcomes = domain['outcomes']
    size, full = len(outcomes), sum(outcome['winner'] for outcome in outcomes)
    marked = sum(outcome['winner'] and outcome['prefix_all_accepted'] for outcome in outcomes)
    proofs = sum(outcome['complete_PNW1_scalar_verified'] for outcome in outcomes)
    require(size == domain['domain_size'] == row['Grover_domain_size']
            == 2 ** domain['enumerated_low_nonce_bits'] == len(macros), 'restricted domain size')
    require(full == domain['marked_count'] == row['full_marked_count']
            and marked == domain['prefix_restricted_marked_count'] == row['restricted_marked_count']
            and full - marked == row['discarded_full_winners'], 'restricted marked counts')
    require(proofs == domain['native_winning_proofs_verified'], 'native proof count')
    for outcome, macro in zip(outcomes, macros):
        require(outcome['nonce'] == macro['nonce'] and outcome['challenge'] == macro['challenge']
                and macro['winner'] is (outcome['winner'] and outcome['prefix_all_accepted'])
                and macro['clean_ancillas'] is True and macro['nonce_preserved'] is True
                and macro['inverse_executed'] is True, 'restricted macro differential')
        if outcome['complete_PNW1_scalar_verified']:
            require(domain['native_shape'] is True and outcome['winner'] is True,
                    'native proof scope')
            proof_hashes.append(outcome['proof_sha256'])
    resource_arithmetic(row['restricted_resources'])
    for comparison in row['comparison'].values():
        require(Fraction(comparison['restricted'], comparison['full'])
                == Fraction(comparison['ratio_numerator'], comparison['ratio_denominator']),
                'construction ratio')
    for gate in row['reduced_actual_gate_observations']:
        require(gate['native_shape'] is False and gate['mode'] == 'gates'
                and gate['clean_ancillas'] is True and gate['nonce_preserved'] is True
                and gate['inverse_executed'] is True, 'restricted gate control scope')
        require(gate['leaf_gates_executed'] + gate['outer_X_Z_gates_executed']
                == row['restricted_resources']['phase_oracle_gate_count'], 'restricted executed gates')
    restricted_cases.append({'name': row['name'], 'native_shape': domain['native_shape'],
        'domain_size': size, 'low_nonce_bits': domain['enumerated_low_nonce_bits'],
        'unsearched_nonce_bits': domain['unsearched_nonce_bits'],
        'full_marked_count': full, 'restricted_marked_count': marked,
        'discarded_full_winners': full - marked, 'native_PNW1_scalar_verified': proofs,
        'reduced_gate_observations': row['reduced_actual_gate_observations'],
        'recorded_resource_arithmetic_consistent': True})
summary = {'cases': len(restricted_cases), 'literal_nonces': sum(row['domain_size'] for row in restricted_cases),
    'native_PNW1_winners_verified': sum(row['native_PNW1_scalar_verified'] for row in restricted_cases),
    'actual_reduced_gate_controls': sum(len(row['reduced_gate_observations']) for row in restricted_cases),
    'discarded_full_winners': sum(row['discarded_full_winners'] for row in restricted_cases)}
require(summary == {'cases': 5, 'literal_nonces': 60, 'native_PNW1_winners_verified': 3,
                    'actual_reduced_gate_controls': 2, 'discarded_full_winners': 25}, 'restricted totals')
require(len(set(proof_hashes)) == 3, 'distinct native scalar proofs')
for action, result_name in (('observe', 'RESTRICTED_W1_DIFFERENTIAL_OBSERVED'),
                            ('replay', 'RESTRICTED_W1_DIFFERENTIAL_REPLAY_PASS')):
    output = outputs['restricted-' + action]
    require(output['result'] == result_name and all(output[k] == v for k, v in summary.items())
            and output['security_qualified'] is False and output['production_activation'] is False,
            'restricted execution readback: ' + action)

report = {'schema': 'trnm-independent-quantum-output-readback-v1',
    'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
    'result': 'RECORDED_EXECUTION_AND_OUTPUT_CONSISTENCY_PASS',
    'head': args.head, 'tree': args.tree, 'source_root': str(root), 'input_directory': str(base),
    'reader_source_sha256': sha(Path(__file__).read_bytes()),
    'runner_sha256': runner['runner_sha256'],
    'terminal_result_sha256': sha((base / 'result.json').read_bytes()),
    'progress_sha256': sha((base / 'progress.json').read_bytes()),
    'commands': commands, 'commands_verified': len(commands),
    'unit_suite_counts': suite_counts, 'distinct_passed_unittest_names': len(set(all_names)),
    'campaign_artifacts': artifacts, 'declared_source_files_read_back': source_cache,
    'constructive_cases': constructive_cases, 'restricted_cases': restricted_cases,
    'restricted_totals': summary, 'distinct_native_scalar_proof_sha256': sorted(proof_hashes),
    'full_nonce64_resource_census_only': restricted['records']['full_nonce64_resource_census_only'],
    'reviewer_reran_tests_or_campaigns': False, 'reviewer_reran_native_node': False,
    'reviewer_recomputed_recorded_outcome_counts_and_resource_arithmetic': True,
    'reviewer_independently_reproved_oracle_semantics': False,
    'product_disposition': 'HOLD', 'whole_chain_pq_qualified': False,
    'quantum_mining_security_qualified': False, 'production_activation': False,
    'limitations': [
        'Counts and hashes bind the recorded executions; this reader did not rerun the campaigns or independently prove the circuit.',
        'Constructive run has four cases: two native-size scalar macro non-winners and two reduced classical basis-interpreter gate controls; no optional historical native-admission fixture was used.',
        'Restricted native cases enumerate only low two nonce bits (four candidates each); remaining 62 bits are unsearched. No full nonce64 marked-domain characterization follows.',
        'Three PNW1 winners are checked by the separate Python scalar relation, not by native Rust Node admission; parent/task/time/required-target admission is outside this campaign.',
        'Resource figures are upper bounds for two deliberately nonoptimal fixed-context constructions, not a lower bound or the cheapest legal quantum attack.',
        'Restricted search retains the unfiltered nonce dimension, discards legal winners, and must use its own marked count. Prefix/ticket independence is unproved.',
        'No quantum hardware, physical calibration, measured quantum latency, calibrated classical/quantum advantage, or complete end-to-end machine-failure bound is supplied.',
        'These two campaigns do not execute the broad network/adversarial/OHIE/Fast-DAA campaigns. Unit checks do not establish mixed-resource common-prefix, growth, quality or liveness for deployed DAA and fork choice.',
        'Classical observer wall times are not quantum mining clocks. All production and whole-chain qualification remains HOLD.'
    ]}
with args.output.open('x', encoding='utf-8') as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'result': report['result'], 'commands': len(commands),
    'distinct_tests': len(set(all_names)), 'restricted': summary, 'output': str(args.output),
    'sha256': sha(args.output.read_bytes()), 'product_disposition': 'HOLD'}, sort_keys=True))
