#!/usr/bin/env python3
"""Supplemental exact-profile reader validation; the v4 FAIL is retained.

PNH1 has no AAM1 witness, so the original named witness-mutation test explicitly
skips there. The same test must actually pass for PGH2. This program executes the
original readers and both complete original test suites without changing them.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

HEAD = "1a446a79700cc093a2b1a7f10367ef4a5ddbd680"
TREE = "928b180bf769a813e5643827329667cb11f2a3a5"
ORIGINAL_RUNNER_SHA = "d82a61c02a2068246649e290f578de4146cf5bad05ae927ce1ddad9343bac7cb"
TEST_SOURCE = "scripts/ci/test_pon_joint_daa_reader.py"
TEST_SOURCE_SHA = "51fcfe6d090ca8f15f6eb3fd6e39d4c4be5062cbb155040395b641c3729095ef"
BACKENDS = ("pnh1-authenticated", "pgh2-growth")
GROWTH_WITNESS = "test_growth_witness_bytes_cannot_change_under_the_same_commitment"
SKIP_REASON = "AAM1 witness commitment exists only in the separate PGH2 profile"
# Independently reviewed full roster, never inferred from submitted log lines.
ROSTER = (
    "test_activation_order_cannot_choose_the_lower_work_longer_branch",
    "test_actual_packets_replay_full_work_and_keep_native_observation_scope",
    "test_binding_probe_grid_and_permissive_filter_scope_are_mandatory",
    "test_cold_reopen_cannot_change_selected_generation_or_root",
    "test_cumulative_work_is_recomputed_from_each_actual_parent",
    "test_external_report_digest_is_checked_before_packet_processing",
    "test_fake_retarget_summary_cannot_override_real_endpoints",
    "test_growth_activation_cannot_claim_the_pnh1_global_clock_gate",
    "test_growth_witness_bytes_cannot_change_under_the_same_commitment",
    "test_header_profile_and_domain_are_not_interchangeable",
    "test_integer_and_schema_types_reject_boolean_aliases",
    "test_json_duplicate_keys_and_noninteger_numbers_are_rejected",
    "test_logical_clock_and_full_verification_scope_cannot_be_removed",
    "test_missing_or_extra_packet_cannot_change_the_denominator",
    "test_missing_or_reordered_records_cannot_shrink_the_trajectory",
    "test_nonce_implied_attempts_cannot_be_underreported",
    "test_parent_median_uses_exact_branch_not_reported_ancestors",
    "test_record_digest_pins_actual_packet_bytes",
    "test_sqrt_credit_cannot_replace_linear_chainwork",
    "test_target_passing_false_product_reaches_full_relation_replay",
    "test_valid_same_bytes_in_wrong_profile_directory_fail_api_and_cli",
    "test_wrong_target_cannot_pass_after_rewriting_required_and_cumulative_work",
)
ENTRY = re.compile(r"(test_[a-z0-9_]+) \(__main__\.RetainedJointDaaCounterexamples\.(test_[a-z0-9_]+)\) \.\.\. (ok|skipped '([^'\n]*)')")
FRAME = re.compile(r"(?P<entries>(?:[^\n]+\n){22})\n-{70}\nRan 22 tests in [0-9]+\.[0-9]+s\n\n(?P<footer>OK(?: \(skipped=1\))?)\n")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def verify_frame(raw: bytes, backend: str, exit_code: int, test_source: bytes):
    require(backend in BACKENDS, "unknown backend")
    require(type(exit_code) is int and exit_code == 0, "reader test process failed")
    require(sha(test_source) == TEST_SOURCE_SHA, "original test source drift")
    frame = FRAME.fullmatch(raw.decode("utf-8", errors="strict"))
    require(frame is not None, "incomplete, extra, or fabricated unittest frame")
    found = {}
    for line in frame["entries"].splitlines():
        item = ENTRY.fullmatch(line)
        require(item is not None, "unexpected test result/status")
        name, qualified, status, reason = item.groups()
        require(name == qualified and name in ROSTER and name not in found,
                "missing, duplicate, unknown, or mislabelled test identity")
        expected_skip = backend == "pnh1-authenticated" and name == GROWTH_WITNESS
        require((status == f"skipped '{SKIP_REASON}'" and reason == SKIP_REASON)
                if expected_skip else status == "ok", "wrong original profile outcome")
        found[name] = "profile_not_applicable" if expected_skip else "ok"
    require(set(found) == set(ROSTER) and len(found) == 22, "full 22-name roster required")
    require(frame["footer"] == ("OK (skipped=1)" if backend == BACKENDS[0] else "OK"),
            "wrong original profile terminal summary")
    return {"backend": backend, "outcomes": found,
            "executed_ok": sum(v == "ok" for v in found.values()),
            "profile_not_applicable": [n for n, v in found.items() if v != "ok"],
            "log_sha256": sha(raw), "source_sha256": sha(test_source)}


def git(root, *args):
    return subprocess.check_output(["git", "--no-replace-objects", *args], cwd=root, text=True).strip()


def identity(root):
    return {"head": git(root, "rev-parse", "HEAD"), "tree": git(root, "rev-parse", "HEAD^{tree}"),
            "status": git(root, "status", "--porcelain", "--untracked-files=all")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--original-campaign-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    root, original, output = args.source_root.resolve(), args.original_campaign_dir.resolve(), args.output_dir.resolve()
    require(not output.is_relative_to(root) and output != original, "independent output required")
    expected_source = {"head": HEAD, "tree": TREE, "status": ""}
    require(identity(root) == expected_source, "exact clean F3 source required")
    test_source = (root / TEST_SOURCE).read_bytes()
    require(sha(test_source) == TEST_SOURCE_SHA, "original source hash differs")
    original_raw = (original / "checks.json").read_bytes()
    campaign = json.loads(original_raw)
    require(campaign["source"] == expected_source and campaign["complete"] is True
            and campaign["all_passed"] is False and campaign["runner_sha256"] == ORIGINAL_RUNNER_SHA,
            "completed original v4 FAIL must be retained")
    rows = {row["name"]: row for row in campaign["checks"]}
    require(len(rows) == len(campaign["checks"]), "duplicate original check rows")
    for name in ("source-before", "source-after", "native-joint-daa"):
        row = rows[name]
        require(row["passed"] is True and row["returncode"] == 0 and row["error"] is None
                and row["before"] == row["after"] == expected_source and row["source_unchanged"] is True
                and sha((original / (name + ".log")).read_bytes()) == row["log_sha256"],
                "original exact-source/native execution binding differs")
    reports = {r["backend"]: r for r in campaign["fresh_native_reports"]}
    require(set(reports) == set(BACKENDS) and len(campaign["fresh_native_reports"]) == 2, "both original native reports required")
    original_outcomes = []
    for backend in BACKENDS:
        raw_dir = original / "joint-daa" / backend
        digest = sha((raw_dir / "joint-daa.json").read_bytes())
        require(digest == reports[backend]["joint_daa_sha256"] and reports[backend]["current_source"] == HEAD,
                "original actual native report changed")
        name = "joint-daa-reader-controls-" + backend
        row = rows[name]
        command = ["/usr/bin/python3", "-B", TEST_SOURCE, "--raw-dir", str(raw_dir), "-v"]
        require(row["command"] == command and row["before"] == row["after"] == expected_source
                and row["source_unchanged"] is True and row["error"] is None
                and row["python_tests_run"] == [22] and row["passed"] is (backend == "pgh2-growth"),
                "original command/profile result altered")
        raw = (original / (name + ".log")).read_bytes()
        require(sha(raw) == row["log_sha256"], "original actual log changed")
        original_outcomes.append(verify_frame(raw, backend, row["returncode"], test_source))
    input_files = [original / "checks.json", original / "source-before.json", original / "source-after.json"]
    original_pins = {str(p): sha(p.read_bytes()) for p in input_files}
    output.mkdir(parents=True, exist_ok=False)
    result = {"schema": "chain-six-joint-daa-original-profile-validation-v1", "source": expected_source,
              "original_runner_sha256": ORIGINAL_RUNNER_SHA, "original_campaign_all_passed": False,
              "original_failed_checks": [r["name"] for r in campaign["checks"] if not r["passed"]],
              "original_failure_reinterpreted": False, "original_input_sha256": original_pins,
              "original_outcomes": original_outcomes, "fresh_outcomes": [], "commands": [],
              "qualification": "HOLD_NO_GO", "current_native_cost_qualified": False, "complete": False}

    def execute(name, command):
        before = identity(root)
        require(before == expected_source, "source changed before original command")
        started = time.monotonic()
        path = output / (name + ".log")
        with path.open("xb") as stream:
            code = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT,
                                  timeout=1200).returncode
        after = identity(root)
        result["commands"].append({"name": name, "command": command, "timeout_seconds": 1200,
            "exit_code": code, "elapsed_seconds": time.monotonic()-started,
            "before": before, "after": after, "log_sha256": sha(path.read_bytes())})
        require(code == 0 and before == after == expected_source, "original command/source failed")
        return path.read_bytes(), code

    try:
        execute("source-before", ["/usr/bin/python3", "-B", "scripts/ci/verify_ci_source.py", "--kind", "head",
            "--expected-head", HEAD, "--output", str(output / "source-before.json")])
        for backend in BACKENDS:
            raw_dir = original / "joint-daa" / backend
            execute("reader-"+backend, ["/usr/bin/python3", "-B", "scripts/pon_joint_daa_reader.py", "--raw-dir", str(raw_dir),
                "--expected-report-sha256", reports[backend]["joint_daa_sha256"]])
            raw, code = execute("tests-"+backend, ["/usr/bin/python3", "-B", TEST_SOURCE, "--raw-dir", str(raw_dir), "-v"])
            result["fresh_outcomes"].append(verify_frame(raw, backend, code, (root / TEST_SOURCE).read_bytes()))
        execute("source-after", ["/usr/bin/python3", "-B", "scripts/ci/verify_ci_source.py", "--kind", "head",
            "--expected-head", HEAD, "--output", str(output / "source-after.json")])
        require(original_pins == {str(p): sha(p.read_bytes()) for p in input_files}, "original campaign evidence mutated")
        for backend in BACKENDS:
            require(sha((original / "joint-daa" / backend / "joint-daa.json").read_bytes()) == reports[backend]["joint_daa_sha256"],
                    "actual native report changed during replay")
        require(sha((root / TEST_SOURCE).read_bytes()) == TEST_SOURCE_SHA, "test source drift after replay")
        result["complete"] = True
        result["profile_specific_reader_validation_passed"] = True
        print(json.dumps({"complete": True, "pnh1_ok": 21, "pnh1_declared_not_applicable": GROWTH_WITNESS,
            "pgh2_ok": 22, "pgh2_witness_actual_ok": True, "original_campaign_all_passed": False}, sort_keys=True))
    finally:
        (output / "validation.json").write_text(json.dumps(result, sort_keys=True, indent=2)+"\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
