#!/usr/bin/env python3
"""Execute the requested frozen-B Python gates and retain all raw observations."""
from pathlib import Path
import concurrent.futures
import datetime
import hashlib
import json
import os
import re
import signal
import subprocess
import time

ROOT = Path('/dev/shm/chain-w0w7-6478-full')
OUT = Path('/workspace/scratch/6478cdf21f8e/final-B-python-gates')
EXPECTED_HEAD = '4d291c4d90e862498303ae2b4f2677b19b482faf'
EXPECTED_TREE = '1b988506d24b72a9ada8c3395270e188f8312428'
RUNTIME_A = 'b3bc526b96d3a8e2ad0be7faa4f00f11d9f7ea53'
DESCRIPTOR = 'dd77d2a89bbeb0c308e49d1680020b6cb9eea82f745ac4623f9cf906d8a4bded'
ENV = os.environ.copy()
ENV['PATH'] = '/workspace/scratch/4a0b199bc6c0/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:' + ENV['PATH']
ENV['CARGO_HOME'] = '/workspace/scratch/6ea4184bb859/toolchain/cargo'
ENV['TMPDIR'] = '/dev/shm/chain-python-B-6478'
ENV['PYTHONDONTWRITEBYTECODE'] = '1'


def command(name, script, *args, expected_exit=0):
    return name, ['python3', '-B', script, *args], expected_exit


CASES = [
    command('corpus-tests', 'scripts/ci/test_pq_research_integration.py', '-v'),
    command('source-integrity-tests', 'scripts/ci/test_ci_source_integrity.py', '-v'),
    command('authority-tests', 'scripts/ci/test_pq_authority_effect_register.py', '-v'),
    command('root-tests', 'scripts/ci/test_pq_root_dependency_register.py', '-v'),
    command('lifetime-tests', 'scripts/ci/test_pq_lifetime_budget.py', '-v'),
    command('upstream-tests', 'scripts/ci/test_w1_upstream_security.py', '-v'),
    command('binding-tests', 'scripts/ci/test_pq_proof_profile_binding.py', '-v'),
    command('corpus-reader', 'scripts/ci/check_pq_research_integration.py'),
    command('authority-reader', 'scripts/ci/pq_authority_effect_register.py'),
    command('root-reader', 'scripts/ci/pq_root_dependency_register.py'),
    command('lifetime-reader', 'scripts/ci/pq_lifetime_budget.py'),
    command('upstream-reader', 'scripts/ci/w1_upstream_security.py'),
    command('binding-reader', 'scripts/ci/pq_proof_profile_binding.py', '--expected-profile-descriptor-sha256', DESCRIPTOR),
    command('upstream-current-refusal', 'scripts/ci/w1_upstream_security.py', '--require-current', expected_exit=2),
    command('binding-current-refusal', 'scripts/ci/pq_proof_profile_binding.py', '--require-current', expected_exit=2),
    command('repository-reader', 'scripts/ci/check_repository.py'),
    command('ci-contract-reader', 'scripts/ci/check_ci_contract.py'),
]
SOURCE_PATHS = sorted({case[1][2] for case in CASES} | {
    'scripts/ci/test_ci_contract.py', 'scripts/ci/ci_job.sh',
    'scripts/ci/pq_source_reader.py', 'scripts/ci/verify_ci_source.py',
    'config/pon/pq-cross-branch-corpus-v1.json',
    'config/pon/pq-authority-effects-v1.json',
    'config/pon/pq-root-dependency-register-v3.json',
    'config/pon/pq128-lifetime-budget-v1.json', 'config/pon/pq128-source-lock-v1.json',
    'config/pon/w1-upstream-security-v1.json',
    'config/pon/pq-proof-profile-binding-v1.json',
    'config/pon/w1-qrom-implementation-current-v2.json',
    '.github/workflows/trnm-required-baseline.yml',
    '.github/workflows/chain-hepta-closure-candidate.yml',
})


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def identity():
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV, text=True).strip()
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'porcelain': git('status', '--porcelain=v1'),
            'selected_source_sha256': {p: sha((ROOT / p).read_bytes()) for p in SOURCE_PATHS}}


def semantics(name, stdout, stderr):
    if name.endswith('-tests'):
        text = stderr.decode('utf-8')
        footer = text.rstrip().splitlines()[-1] if text.strip() else ''
        count = re.search(r'Ran (\d+) tests? in [\d.]+s', text)
        number = int(count.group(1)) if count else None
        expected = {'source-integrity-tests': 43, 'authority-tests': 18,
                    'lifetime-tests': 58, 'upstream-tests': 14, 'binding-tests': 31}.get(name)
        return {'passed': footer == 'OK' and number is not None and (expected is None or number == expected),
                'test_count': number, 'expected_test_count': expected,
                'unittest_footer': footer, 'skip_reported': bool(re.search(r'\bskipped=\d+', footer))}
    report = json.loads(stdout)
    if name == 'preflight':
        checks = {'result_pass': report['result'] == 'PASS'}
    elif name == 'corpus-reader':
        checks = {'hold': report['status'] == 'HOLD_NO_GO',
                  'pins_1624': report['exact_source_blobs'] == 1624,
                  'no_crypto_acceptance': report['cryptographic_acceptance'] is False,
                  'no_activation': report['node_activated'] is False}
    elif name == 'authority-reader':
        checks = {'hold': report['status'] == 'HOLD', 'source_consistency': report['source_consistency'] == 'PASS',
                  'source_paths_44': len(report['source_files_sha256']) == 44,
                  'routes_7': report['curated_routes_checked'] == 7,
                  'runtime_A': report['source_revision'] == RUNTIME_A,
                  'coverage_partial': report['coverage_complete'] is False,
                  'no_qualification': report['whole_chain_pq_qualified'] is False,
                  'no_activation': report['production_activation'] is False}
    elif name == 'root-reader':
        checks = {'hold': report['status'] == 'HOLD', 'source_paths_43': len(report['source_files_sha256']) == 43,
                  'source_files_checked': report['source_files_checked'] is True,
                  'revision_unbound': report['source_revision_bound'] is False,
                  'source_scope': report['source_binding_scope'] == 'declared-root-component-files-only',
                  'no_qualification': report['whole_chain_pq_qualified'] is False,
                  'no_activation': report['production_activation'] is False}
    elif name == 'lifetime-reader':
        checks = {'hold': report['status'] == 'HOLD', 'source_paths_15': len(report['source_paths']) == 15,
                  'runtime_A': report['experiment']['source_revision'] == RUNTIME_A,
                  'unknown_terms_8': len(report['unknown_terms']) == 8,
                  'unknown_query_budgets_4': len(report['unknown_query_budgets']) == 4,
                  'unknown_lifetime_bound': report['actual_lifetime_failure_bound'] is None,
                  'no_qualification': report['whole_chain_pq_qualified'] is False,
                  'no_activation': report['production_activation'] is False}
    elif name.startswith(('upstream-', 'binding-')):
        upstream = report['upstream_security'] if name.startswith('binding-') else report
        checks = {'known_affected': upstream['status'] == 'KNOWN_AFFECTED_SELECTED_PROFILE',
                  'affected_entries_15': len(upstream['affected_locked_packages']) == 15,
                  'backend_count_3': len(upstream['backend_observations']) == 3,
                  'current_use_refused': upstream['current_proof_use_eligible'] is False,
                  'migration_unapproved': upstream['migration_approved'] is False,
                  'no_qualification': upstream['whole_chain_pq_qualified'] is False,
                  'no_activation': upstream['production_activation'] is False}
        if name.startswith('binding-'):
            checks.update({'revoked_hold': report['status'] == 'PROFILE_BOUND_UPSTREAM_REVOKED_HOLD',
                           'descriptor_unchanged': report['selected_profile_descriptor_sha256'] == DESCRIPTOR,
                           'no_profile_eligibility': report['current_proof_use_eligible'] is False,
                           'no_arithmetic_import': report['system_lifetime_register']['arithmetic_imported'] is False,
                           'profile_not_covered_by_system_register': report['system_lifetime_register']['selected_proof_profile_covered'] is False})
        if name.endswith('-current-refusal'):
            refusal = json.loads(stderr)
            checks.update({'refusal_status': refusal['status'] == 'REFUSE',
                           'exact_refusal_reason': refusal['reason'] == 'selected proof profile is not eligible for current use',
                           'stderr_current_use_refused': refusal['current_proof_use_eligible'] is False})
    elif name == 'repository-reader':
        checks = {'pass': report['result'] == 'PASS', 'head_B': report['head'] == EXPECTED_HEAD,
                  'tree_B': report['tree'] == EXPECTED_TREE, 'clean': report['source_state'] == 'committed-clean',
                  'markdown_links_checked': report['local_links'] > 0,
                  'runtime_not_qualified': report['runtime_implemented'] is False,
                  'activation_false': report['activation'] is False}
    elif name == 'ci-contract-reader':
        checks = {'required_jobs': report['head_jobs'] > 0 and report['head_jobs'] == report['merge_lanes'],
                  'reader_only': report['tests_executed'] is False}
    else:
        raise ValueError('unrecognized case ' + name)
    if not name.endswith('-current-refusal'):
        checks['empty_stderr'] = stderr == b''
    return {'passed': all(checks.values()), 'checks': checks}


def run(case):
    name, argv, expected = case
    record = {'name': name, 'argv': argv, 'cwd': str(ROOT), 'expected_exit': expected,
              'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'watchdog_seconds': 600, 'source_head': EXPECTED_HEAD, 'source_tree': EXPECTED_TREE}
    started = time.monotonic()
    with (OUT / (name + '.stdout')).open('wb') as stdout, (OUT / (name + '.stderr')).open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr, start_new_session=True)
        record['child_pid'] = process.pid
        try:
            record['returncode'] = process.wait(timeout=600)
            record['timeout'] = False
        except subprocess.TimeoutExpired:
            record['timeout'] = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
            record['returncode'] = process.returncode
    record['duration_seconds'] = time.monotonic() - started
    record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stdout = (OUT / (name + '.stdout')).read_bytes()
    stderr = (OUT / (name + '.stderr')).read_bytes()
    record.update(stdout_bytes=len(stdout), stderr_bytes=len(stderr), stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
    try:
        record['semantic_assertions'] = semantics(name, stdout, stderr)
    except (KeyError, TypeError, ValueError, IndexError) as error:
        record['semantic_assertions'] = {'passed': False, 'error': str(error)}
    record['expectation_met'] = not record['timeout'] and record['returncode'] == expected and record['semantic_assertions']['passed']
    dump(name + '.receipt.json', record)
    print(json.dumps(record, sort_keys=True), flush=True)
    return record


def main():
    OUT.mkdir(exist_ok=False)
    Path(ENV['TMPDIR']).mkdir(exist_ok=True)
    before = identity()
    dump('identity-before.json', before)
    assert before['head'] == EXPECTED_HEAD and before['tree'] == EXPECTED_TREE and before['porcelain'] == ''
    (OUT / 'run-script.py').write_bytes(Path(__file__).read_bytes())
    dump('selected-environment.json', {k: ENV[k] for k in ('CARGO_HOME', 'TMPDIR', 'PYTHONDONTWRITEBYTECODE')} |
         {'PATH_prefix': ENV['PATH'].split(':')[0], 'parallel_commands': 3, 'full_repository_copied': False})
    corpus = json.loads((ROOT / 'config/pon/pq-cross-branch-corpus-v1.json').read_bytes())
    dump('corpus-counts.json', {'pinned_blobs': len(corpus['pinned_blobs']), 'required_paths': len(corpus['required_paths'])})
    assert len(corpus['pinned_blobs']) == 1624 and len(corpus['required_paths']) == 1530
    prior = json.loads(Path('/workspace/scratch/6478cdf21f8e/w7-recovered-evidence/source-before.json').read_bytes())
    selected = ['scripts/ci/test_ci_contract.py', 'scripts/ci/check_ci_contract.py', 'scripts/ci/ci_job.sh']
    prior_checks = {p: before['selected_source_sha256'][p] == prior[p]['sha256'] for p in selected}
    dump('prior-ci-contract-observation.json', {
        'scope': 'prior precommit selected-source observation, not a test execution on Metadata B',
        'prior_base_head': '8970e2c81abbf48e2a4d3f0802d79624ab20fadd',
        'test_count': 188, 'unittest_footer': 'OK',
        'raw_test_stderr_sha256': 'e1cb00f7393203c3039f49e3dc27bb217ef89a06ee9177c288e36008a4eb372e',
        'selected_implementation_files_equal_to_B': prior_checks,
        'tests_rerun_on_B': False, 'ci_contract_reader_in_this_run': True,
        'recorder_false_negative_retained_in_prior_archive': True,
    })
    assert all(prior_checks.values())
    preflight = run(('preflight', ['bash', 'scripts/project-preflight.sh'], 0))
    if not preflight['expectation_met']:
        dump('summary.json', {'scope': 'preflight failed; no tests executed', 'results': [preflight]})
        return 1
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results = [preflight] + list(pool.map(run, CASES))
    after = identity()
    dump('identity-after.json', after)
    success = before == after and all(r['expectation_met'] for r in results)
    summary = {'schema': 'trnm-metadata-B-python-gates-observation-v1', 'head': EXPECTED_HEAD,
               'tree': EXPECTED_TREE, 'source_identity_unchanged': before == after,
               'clean_before': before['porcelain'] == '', 'clean_after': after['porcelain'] == '',
               'all_expectations_met': success, 'results': results,
               'scope': 'requested Python gates on exact committed B; full physical-source and native execution observations are separate',
               'ci_contract_188_tests_scope': 'prior precommit selected-source observation; not rerun on B',
               'native_execution_performed_by_this_runner': False,
               'whole_chain_pq_qualified': False, 'production_activation': False}
    dump('summary.json', summary)
    print(json.dumps({'summary': str(OUT / 'summary.json'), 'all_expectations_met': success,
                      'source_identity_unchanged': before == after}), flush=True)
    return 0 if success else 1


if __name__ == '__main__':
    raise SystemExit(main())
