#!/usr/bin/env python3
"""Observe only eleven unfinished C1 witness V5 cases; never promote the failed group."""
from __future__ import annotations
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import time

COMMIT = 'c09dbbe9921da12db8bf7240a8a95a0e9a789e50'
BASE = Path('/home/qian-qi/work')
ORIGINAL = BASE / 'chain-pq-closure-20261111-d4d2-validation-c09dbbe9921d-01'
RUNNER = BASE / 'chain-pq-closure-20261111-d4d2-validate-c09dbbe9921d-data.py'
RUNNER_SHA = 'e5a378b43130e888d58b021ed58dc28f4c560c1075d8e08b7db79313765bc45e'
OUT = Path('/data/chain-pq-closure-20261111-d4d2-witness-v5-subset-c09dbbe9921d-01')
EXE = Path('/data/chain-pq-closure-20261111-d4d2-cargo-target-c09dbbe9921d-01/'
           'debug/deps/root_witness_v5_native-fb785672eb81b96f')
EXE_SHA = '91908655f8d81365fe6fdb4611d61b5014561a0eafe80b6922469772b992ff1a'
EXE_BYTES = 248613192
DONE = (
    'native_witness_v5_another_recovery_epoch_cannot_use_the_same_service_pin',
    'native_witness_v5_callback_budget_replacement_and_cancellation_remain_fenced',
    'native_witness_v5_changed_signed_pending_and_anchor_cannot_bypass_role_snapshot',
    'native_witness_v5_complete_binding_and_role_separation_are_required',
    'native_witness_v5_context_and_intent_recheck_live_witness_and_latch_failure',
    'native_witness_v5_corrupt_pending_never_advances_the_witness',
)
REMAINING = (
    'native_witness_v5_lost_ack_retains_pending_and_resumes_without_another_cas',
    'native_witness_v5_open_checks_retained_root_key_roles',
    'native_witness_v5_pre_cas_disconnect_retries_only_the_verified_witness_transition',
    'native_witness_v5_restoring_every_authority_remains_an_explicit_counterexample',
    'native_witness_v5_rotation_cannot_reuse_witness_keys',
    'native_witness_v5_signed_response_must_bind_the_complete_fresh_request',
    'native_witness_v5_success_is_witnessed_before_pending_is_completed',
    'native_witness_v5_surviving_witness_refuses_common_owner_anchor_restore',
    'native_witness_v5_unavailable_witness_has_no_static_floor_fallback',
    'native_witness_v5_unwitnessed_v3_commit_cannot_be_promoted_from_an_ancestor_floor',
    'native_witness_v5_wrong_signature_and_outcome_are_refused',
)
SKIP = [arg for name in DONE for arg in ('--skip', name)]
LIST_ARGV = [str(EXE), *SKIP, '--list']
TEST_ARGV = [str(EXE), *SKIP, '--show-output', '--test-threads=1']
TIMEOUT = 1200


def read_json(path):
    return json.loads(path.read_text())


def pinned_descriptor(m):
    fd = os.open(EXE, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        m.require(stat.S_ISREG(info.st_mode) and info.st_size == EXE_BYTES
                  and info.st_nlink == 1 and info.st_mode & 0o111,
                  'native executable descriptor/type/size changed')
        digest, offset = hashlib.sha256(), 0
        while offset < EXE_BYTES:
            data = os.pread(fd, min(1024**2, EXE_BYTES - offset), offset)
            m.require(bool(data), 'native executable truncated')
            digest.update(data)
            offset += len(data)
        m.require(digest.hexdigest() == EXE_SHA, 'native executable SHA256 changed')
        m.require(m.fingerprint(info) == m.fingerprint(os.fstat(fd))
                  == m.fingerprint(EXE.lstat()), 'native executable changed during binding')
        return fd, {'path': str(EXE), 'sha256': EXE_SHA, 'bytes': EXE_BYTES,
                    'device': info.st_dev, 'inode': info.st_ino,
                    'actual_exec': f'/proc/self/fd/{fd}',
                    'binding': 'hashed descriptor held through exec; argv[0] is the original path'}
    except BaseException:
        os.close(fd)
        raise


def command(m, name, argv, env, list_only):
    m.require(min(shutil.disk_usage(m.REPO).free, shutil.disk_usage(OUT).free) >= m.LOW_WATER,
              'source or output volume below 10 GiB')
    fd, executable = pinned_descriptor(m)
    row = {'schema': 'trnm-witness-v5-subset-command-v1', 'name': name, 'argv': argv,
           'cwd': str(m.REPO), 'source_before': m.identity(COMMIT),
           'started_utc': m.now(), 'timeout_seconds': TIMEOUT,
           'environment': {key: env.get(key) for key in (*m.ENV_KEYS, 'TMPDIR')},
           'native_executable': executable,
           'original_group_failed': True, 'aggregate_budget_qualified': False,
           'free_bytes_before': shutil.disk_usage(m.REPO).free,
           'output_free_bytes_before': shutil.disk_usage(OUT).free}
    stdout, stderr = OUT / f'{name}.stdout.log', OUT / f'{name}.stderr.log'
    process, code, timeout, exception, cleanup = None, None, False, None, []
    began = time.monotonic()
    try:
        with stdout.open('xb') as normal, stderr.open('xb') as errors:
            try:
                process = subprocess.Popen(argv, executable=executable['actual_exec'],
                                           pass_fds=(fd,), cwd=m.REPO, env=env,
                                           stdin=subprocess.DEVNULL, stdout=normal,
                                           stderr=errors, start_new_session=True)
                row['pid'] = process.pid
                code = process.wait(timeout=TIMEOUT)
            except subprocess.TimeoutExpired:
                timeout = True
                code = m.stop_group(process, cleanup)
            except BaseException as error:
                exception = {'type': type(error).__name__, 'message': str(error)}
                if process is not None and process.poll() is None:
                    code = m.stop_group(process, cleanup)
            normal.flush()
            errors.flush()
            os.fsync(normal.fileno())
            os.fsync(errors.fileno())
    finally:
        os.close(fd)
    row.update({'finished_utc': m.now(), 'elapsed_seconds': time.monotonic() - began,
                'exit_code': code, 'timed_out': timeout, 'exception': exception,
                'cleanup': cleanup,
                'direct_child_reaped': process is None or process.poll() is not None,
                'stdout': {'name': stdout.name, **m.file_hash(stdout)},
                'stderr': {'name': stderr.name, **m.file_hash(stderr)},
                'free_bytes_after': shutil.disk_usage(m.REPO).free,
                'output_free_bytes_after': shutil.disk_usage(OUT).free})
    row['passed'] = code == 0 and not timeout and exception is None
    try:
        row['source_after'] = m.identity(COMMIT)
        row['executable_after'] = m.file_hash(EXE)
        m.require(row['executable_after']['sha256'] == EXE_SHA
                  and row['executable_after']['bytes'] == EXE_BYTES,
                  'native executable changed after command')
        text = stdout.read_text()
        if list_only:
            names = re.findall(r'^([A-Za-z0-9_:]+): test$', text, re.M)
            m.require(code == 0 and len(names) == len(REMAINING)
                      and set(names) == set(REMAINING), 'listed remaining test set differs')
            m.require(re.findall(r'^(\d+) tests?, (\d+) benchmarks?$', text, re.M)
                      == [(str(len(REMAINING)), '0')], 'listed native count differs')
            row['listed_tests'] = names
        else:
            row['native_observation'] = m.native_result(text, list(REMAINING), code)
            m.require(row['native_observation']['filtered_out'] == len(DONE),
                      'exactly six previously completed cases must be filtered')
    except Exception as error:
        row['observation_error'] = str(error)
        row['passed'] = False
    m.write_json(OUT / f'{name}.receipt.json', row)
    print(json.dumps({'command': name, 'exit_code': code, 'passed': row['passed'],
                      'timed_out': timeout, 'seconds': row['elapsed_seconds'],
                      'aggregate_budget_qualified': False}), flush=True)
    return row


def main():
    assert hashlib.sha256(RUNNER.read_bytes()).hexdigest() == RUNNER_SHA
    spec = importlib.util.spec_from_file_location('frozen_validation_runner', RUNNER)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    original = read_json(ORIGINAL / 'summary.json')
    original_receipt = read_json(ORIGINAL / 'root-witness-v5-native.receipt.json')
    original_plan = read_json(ORIGINAL / 'plan.json')
    m.require(original['source'] == COMMIT and original['source_unchanged']
              and original['provider_unchanged'], 'original C1 group is not finished and unchanged')
    m.require(original_receipt['timed_out'] and original_receipt['exit_code'] == -15
              and not original_receipt['passed'], 'original witness V5 failure must remain retained')
    m.require(set(original_receipt['expected_tests']) == set(DONE) | set(REMAINING),
              'original seventeen-case roster differs')
    original_stdout = (ORIGINAL / 'root-witness-v5-native.stdout.log').read_text()
    complete_names = re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\. ok$', original_stdout, re.M)
    m.require(len(complete_names) == len(DONE) and set(complete_names) == set(DONE),
              'actual original completed test set differs')
    m.require(OUT.parent == Path('/data') and OUT.resolve() == OUT and not OUT.exists(),
              'fresh /data output required')
    m.require(not os.statvfs(EXE.parent).f_flag & os.ST_NOEXEC, 'native target volume is noexec')
    m.identity(COMMIT)
    env = dict(os.environ)
    forbidden = [k for k in env if k.startswith('CARGO_PROFILE_') or k in
                 ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER',
                  'GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_OBJECT_DIRECTORY',
                  'GIT_ALTERNATE_OBJECT_DIRECTORIES')]
    m.require(not any(env[k] for k in forbidden), 'inherited build/Git override refused')
    for key, value in original_plan['environment'].items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    env.pop('OPENSSL_LIBS', None)
    env['GIT_NO_REPLACE_OBJECTS'] = '1'
    m.require(min(shutil.disk_usage(m.REPO).free, shutil.disk_usage(OUT.parent).free) >= m.LOW_WATER,
              'source or output volume below 10 GiB')
    OUT.mkdir(mode=0o700)
    source_before = source_after = provider_before = provider_after = None
    rows, fatal = [], None
    began = m.now()
    try:
        source_before = m.source_snapshot(COMMIT, OUT / 'source-before.json')
        provider_before = m.provider_snapshot(OUT / 'provider-before.json')
        m.require(provider_before == read_json(ORIGINAL / 'provider-after.json'),
                  'provider changed since original group')
        m.write_json(OUT / 'plan.json', {
            'schema': 'trnm-witness-v5-subset-plan-v1', 'source': COMMIT,
            'runner': m.file_hash(Path(__file__)), 'original_group': str(ORIGINAL),
            'original_summary': m.file_hash(ORIGINAL / 'summary.json'),
            'original_failure_receipt': m.file_hash(ORIGINAL / 'root-witness-v5-native.receipt.json'),
            'executable': {'path': str(EXE), **m.file_hash(EXE)},
            'list_argv': LIST_ARGV, 'test_argv': TEST_ARGV, 'timeout_seconds': TIMEOUT,
            'completed_cases_not_repeated': list(DONE), 'remaining_cases': list(REMAINING),
            'concurrency': 1, 'test_threads': 1, 'cargo_invoked_for_tests': False,
            'environment': {key: env.get(key) for key in (*m.ENV_KEYS, 'TMPDIR')},
            'original_group_failed': True, 'aggregate_budget_qualified': False,
            'whole_chain_quantum_security_qualified': False,
        })
        row, _ = m.run_command('preflight', ['bash', 'scripts/project-preflight.sh'],
                               120, None, env, OUT, COMMIT)
        rows.append(row)
        m.require(row['passed'], 'project preflight refused')
        rows.append(command(m, 'list-remaining', LIST_ARGV, env, True))
        m.require(rows[-1]['passed'], 'remaining set was not proven; no native subset started')
        rows.append(command(m, 'run-remaining', TEST_ARGV, env, False))
    except BaseException as error:
        fatal = {'type': type(error).__name__, 'message': str(error)}
    finally:
        for name, function in (('source-after', lambda: m.source_snapshot(COMMIT, OUT / 'source-after.json')),
                               ('provider-after', lambda: m.provider_snapshot(OUT / 'provider-after.json'))):
            try:
                value = function()
                if name == 'source-after':
                    source_after = value
                else:
                    provider_after = value
            except BaseException as error:
                m.write_json(OUT / (name + '-error.json'),
                             {'type': type(error).__name__, 'message': str(error)})
    source_equal = source_before is not None and source_before == source_after
    provider_equal = provider_before is not None and provider_before == provider_after
    complete = len(rows) == 3 and all(r['passed'] for r in rows)
    summary = {'schema': 'trnm-witness-v5-subset-observations-v1', 'source': COMMIT,
               'started_utc': began, 'finished_utc': m.now(), 'original_group': str(ORIGINAL),
               'commands': rows, 'fatal': fatal, 'source_unchanged': source_equal,
               'provider_unchanged': provider_equal, 'original_group_failed': True,
               'aggregate_budget_qualified': False, 'remaining_subset_complete': complete
                   and source_equal and provider_equal and fatal is None,
               'completed_original_cases_not_repeated': list(DONE),
               'requested_remaining_cases': list(REMAINING),
               'whole_chain_quantum_security_qualified': False, 'production_activation': False,
               'observation_scope': 'remaining function behavior only; original 17-case wall-budget failure retained'}
    m.write_json(OUT / 'summary.json', summary)
    print(json.dumps({k: v for k, v in summary.items() if k != 'commands'}), flush=True)
    return 0 if summary['remaining_subset_complete'] else 1


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))
    raise SystemExit(main())
