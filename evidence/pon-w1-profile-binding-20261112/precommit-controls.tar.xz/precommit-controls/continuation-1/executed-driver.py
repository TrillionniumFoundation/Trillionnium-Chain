
from pathlib import Path
import hashlib,json,os,subprocess,time,traceback,sys,re
root=Path('/home/qian-qi/work/chain-w1-profile-binding-20261112-b34d')
baseout=Path('/home/qian-qi/work/w1-binding-controls-20261112-b34d')
out=baseout/'continuation-1'
head='229b14c2d366a257f51f287d502a550df2332338'
expected={'config/pon/pq-proof-profile-binding-v1.json':'9ee5796ce1824d48f86a95b7e080ff75e568021a','.github/workflows/chain-hepta-closure-candidate.yml':'82efb03fd84281c7d9e66f2d545f8f9e265a0bdb','scripts/ci/test_pq_proof_profile_binding.py':'524d067aa0c1cfa992e97565f8c2d07b89ed4636','config/pon/pq-cross-branch-corpus-v1.json':'773e2394b825b053129f3b3cecc0d62bf658fcca'}
def git(*args): return subprocess.check_output(['git',*args],cwd=root)
def blob(raw): return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def guard():
 assert git('rev-parse','HEAD').decode().strip()==head
 assert set(git('diff','--name-only').decode().splitlines())==set(expected)
 assert not git('ls-files','--others','--exclude-standard')
 for name,pin in expected.items(): assert blob((root/name).read_bytes())==pin,name
guard()
prior=json.loads((baseout/'summary.json').read_bytes())
assert prior['completed'] is False and prior['records'][-1]['stem']=='10-corpus-tests' and prior['records'][-1]['timed_out'] is True
out.mkdir(exist_ok=False)
with (out/'executed-driver.py').open('x') as f: f.write(sys.argv[1])
summary={'root':str(root),'base_commit':head,'completed':False,'scope':'uncommitted four-file candidate checks; first300secondtimeout retained; no corpus repeat/native/committed-source qualification','prior_summary_sha256':hashlib.sha256((baseout/'summary.json').read_bytes()).hexdigest(),'records':[],'production_activation':False}
def run(stem,command,timeout=600):
 guard();start=time.time_ns()
 with (out/(stem+'.begin.json')).open('x') as f: json.dump({'command':command,'cwd':str(root),'timeout':timeout,'start_unix_ns':start},f)
 try:
  p=subprocess.run(command,cwd=root,capture_output=True,timeout=timeout,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','NO_COLOR':'1'})
  stdout,stderr,code,timed=p.stdout,p.stderr,p.returncode,False
 except subprocess.TimeoutExpired as e: stdout,stderr,code,timed=e.stdout or b'',e.stderr or b'',None,True
 (out/(stem+'.stdout')).write_bytes(stdout);(out/(stem+'.stderr')).write_bytes(stderr)
 row={'stem':stem,'command':command,'cwd':str(root),'exit':code,'timed_out':timed,'timeout_seconds':timeout,'elapsed_ns':time.time_ns()-start,'stdout_bytes':len(stdout),'stdout_sha256':hashlib.sha256(stdout).hexdigest(),'stderr_bytes':len(stderr),'stderr_sha256':hashlib.sha256(stderr).hexdigest()}
 m=re.search(rb'Ran ([0-9]+) tests? in ',stderr)
 if m: row['unittest_methods']=int(m.group(1))
 summary['records'].append(row);(out/(stem+'.result.json')).write_text(json.dumps(row,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 guard()
 if timed or code!=0: raise RuntimeError(stem+' unexpected result')
try:
 for stem,command,timeout in [
 ('12-inventory',['python3','scripts/refresh_distributed_source_inventory.py','--check'],300),
 ('13-repository-tests',['python3','scripts/ci/test_repository.py','-v'],600),
 ('14-repository-markdown',['python3','scripts/ci/check_repository.py'],600),
 ('15-diff-whitespace',['git','diff','--check'],300),
 ('16-final-preflight',['bash','scripts/project-preflight.sh'],120)]:
  run(stem,command,timeout)
 diff=git('diff','--binary');(out/'observed-final.diff').write_bytes(diff)
 summary['final_diff_sha256']=hashlib.sha256(diff).hexdigest();summary['head_unchanged']=True;summary['completed']=True
 summary['changed_files']={name:{'bytes':len((root/name).read_bytes()),'sha256':hashlib.sha256((root/name).read_bytes()).hexdigest(),'git_blob':blob((root/name).read_bytes())} for name in sorted(expected)}
except BaseException as error:
 summary['error']=repr(error);(out/'driver-failure.txt').write_text(traceback.format_exc())
finally:
 (out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
 combined=[]
 for attempt,directory in [('first',baseout),('continuation-1',out)]:
  for p in sorted(directory.glob('*.result.json')):
   row=json.loads(p.read_bytes());row['attempt']=attempt
   stderr=(directory/(row['stem']+'.stderr')).read_bytes()
   m=re.search(rb'Ran ([0-9]+) tests? in ',stderr)
   if m: row['unittest_methods']=int(m.group(1))
   combined.append(row)
 aggregate={'base_commit':head,'scope':summary['scope'],'first_attempt_status':prior['completed'],'continuation_completed':summary['completed'],'commands':combined,'expected_baseline_failure_retained':True,'self_imposed300second_corpus_timeout_retained':True,'corpus_controls_not_repeated':True,'committed_source_validation':False,'native_execution':False,'production_activation':False,'changed_files':summary.get('changed_files'),'final_diff_sha256':summary.get('final_diff_sha256')}
 (baseout/'final-aggregate.json').write_text(json.dumps(aggregate,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'completed':summary['completed'],'records':len(summary['records']),'output':str(out),'error':summary.get('error')}),flush=True)
sys.exit(0 if summary['completed'] else 1)
