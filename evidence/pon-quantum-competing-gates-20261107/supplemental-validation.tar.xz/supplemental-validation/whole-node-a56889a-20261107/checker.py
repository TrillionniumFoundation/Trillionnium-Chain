#!/usr/bin/env python3
"""Recognize this exact retained outer libtest run against the same ELF inventory.
No test execution: only --list and --ignored --list. Fail closed on unknown output.
"""
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,re,shutil,subprocess,sys,time,traceback
from pathlib import Path
ROOT=Path('/home/qian-qi/work/trnm-quantum-four-gates-20261107-c9b4')
REPO=ROOT/'repo'; RUN=ROOT/'validation-competing-a56889a'
OUT=ROOT/'supplemental-validation/whole-node-a56889a-20261107'
HEAD='a56889a54aac5f14141bb45fb602141dd6a37645'
SOURCE={'head':HEAD,'tree':'b4e64c82d2646b9f32124feb510edc3349a375d0','tracked_files':11030,'inventory_sha256':'a1f7fa55fccc079391b874a86b2bdd5ae667615777aa305ad355d55b66c99424'}
DRIVER=ROOT/'run_competing_gates_validation.py'; DRIVER_SHA='48a259891b7da79f845cf578f71c035679c73844d6c3ddc3610352f22e2f9f39'
ENVFILE=ROOT/'build-environment-normal-loader-fresh-target.json'; ENV_SHA='e997245b8004f49da3cf8f1805934a0ddcdb910a205034f9382a2c4e3adeb4a4'
LOG=RUN/'commands/30-whole-node-lib.log'; LOG_SHA='bdebbc877e2ce0e98a05fab84a3a409dc06fc64bd6864b1ac1b674cfde0d0a75'
ROW=LOG.with_suffix('.json')
SUMMARY=re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in (\d+\.\d+)s$')
NESTED={
 'operator_task_policy::file_tests::held_file_substitutions_reject_without_blocking': {
   'child':'operator_task_policy::file_tests::held_file_substitution_child','count':1,'normal_summary':True,
   'source':'trillionnium/crates/trnm-pon-node/src/operator_task_policy_file_tests.rs','termination':'success asserted by outer parent'},
 'store::authenticated_migration::tests::authenticated_migration_process_exit_leaves_pending_and_source_reopens':{
   'count':5,'normal_summary':False,'source':'trillionnium/crates/trnm-pon-node/src/store/authenticated_migration_tests.rs','termination':'each of five cut children exits 87; outer parent asserts code'},
 'store::authenticated_migration::tests::growth_rehearsal_file_reads_refuse_fifo_replacement_before_open':{
   'count':2,'normal_summary':True,'source':'trillionnium/crates/trnm-pon-node/src/store/authenticated_migration_tests.rs','termination':'hash and receipt children both succeed; outer parent asserts'},
 'store::authenticated_migration::tests::growth_rehearsal_process_exit_retains_pending_and_source_reopens':{
   'count':1,'normal_summary':False,'source':'trillionnium/crates/trnm-pon-node/src/store/authenticated_migration_tests.rs','termination':'child exits 93; outer parent asserts code'},
 'store::growth::tests::native_growth_v2_process_cut_before_commit_recovers':{
   'count':1,'normal_summary':False,'source':'trillionnium/crates/trnm-pon-node/src/store/growth/tests.rs','termination':'child exits 91; outer parent asserts code'},
 'store::reorg_cancellation::tests::three_actual_sigkill_cuts_keep_active_state_replay_and_unknown_cpu_fence':{
   'child':'store::reorg_cancellation::tests::reorg_cancellation_kill_child','count':3,'normal_summary':False,
   'source':'trillionnium/crates/trnm-pon-node/src/store/reorg_cancellation/tests.rs','termination':'three children SIGKILL at declared cuts; parent asserts signal'},
}
def need(ok,message):
 if not ok: raise ValueError(message)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc(): return datetime.now(timezone.utc).isoformat()
def write(p,v):
 tmp=p.with_name(p.name+'.pending')
 with tmp.open('w') as f:
  json.dump(v,f,sort_keys=True,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
 tmp.replace(p)
def strict(raw):
 def pairs(rows):
  d={}
  for k,v in rows: need(k not in d,'DUPLICATE_JSON_KEY'); d[k]=v
  return d
 return json.loads(raw,object_pairs_hook=pairs)
def main():
 need(sha(DRIVER)==DRIVER_SHA,'DRIVER_HASH')
 need(sha(ENVFILE)==ENV_SHA,'ENV_HASH')
 spec=importlib.util.spec_from_file_location('retained_guard',DRIVER)
 mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
 env=dict(strict(ENVFILE.read_bytes()),LC_ALL='C',LANG='C',PYTHONDONTWRITEBYTECODE='1',CARGO_NET_OFFLINE='true',PYTHONUNBUFFERED='1')
 os.environ.clear(); os.environ.update(env)
 need(mod.source(REPO,HEAD)==SOURCE,'INITIAL_SOURCE')
 need(not subprocess.check_output(['git','ls-files','--others','-z'],cwd=REPO),'INITIAL_EXTRA_FILES')
 OUT.mkdir(parents=True,exist_ok=False); (OUT/'sources').mkdir(); (OUT/'original').mkdir()
 result={'schema':'trnm-whole-node-outer-inventory-supplement-v1','status':'STARTED','created_utc':utc(),
  'head':HEAD,'original_driver_row_modified':False,'whole_test_suite_rerun':False,
  'only_elf_list_commands_executed':True,'native_main_job_modified':False,
  'quantum_hardware_executed':False,'quantum_mining_qualified':False}
 snapshots={p:sha(p) for p in (LOG,ROW,RUN/'native-test-elf.json',RUN/'commands/27-node-lib-test-build-json.json',RUN/'commands/27-node-lib-test-build-json.log')}
 need(snapshots[LOG]==LOG_SHA,'ORIGINAL_LOG_SHA')
 row=strict(ROW.read_bytes()); binding=strict((RUN/'native-test-elf.json').read_bytes())
 elf=Path(binding['identity']['path']); elf_identity=mod.identity(elf)
 original_configs=[]
 for name in ('config','config.toml'):
  p=Path(env['CARGO_HOME'])/name
  original_configs.append((str(p),os.path.lexists(p),sha(p) if p.exists() else None))
 def guard(name):
  rec={'checked_utc':utc()}
  try:
   need(sha(DRIVER)==DRIVER_SHA and sha(ENVFILE)==ENV_SHA,'DRIVER_OR_ENV_CHANGED')
   for p,h in snapshots.items(): need(sha(p)==h,'ORIGINAL_INPUT_CHANGED:'+str(p))
   for path,exists,h in original_configs:
    p=Path(path); need(os.path.lexists(p)==exists and (not exists or sha(p)==h),'ORIGINAL_CARGO_CONFIG_CHANGED')
   need(mod.identity(elf)==elf_identity==binding['identity'],'ELF_IDENTITY_CHANGED')
   need(not subprocess.check_output(['git','ls-files','--others','-z'],cwd=REPO),'EXTRA_SOURCE')
   source=mod.source(REPO,HEAD); need(source==SOURCE,'SOURCE_CHANGED')
   need(not subprocess.check_output(['git','ls-files','--others','-z'],cwd=REPO),'EXTRA_SOURCE')
   rec.update(status='VERIFIED',source=source,elf_sha256=elf_identity['sha256'])
   return source
  except BaseException as e:
   rec.update(status='FAILED',error=repr(e)); raise
  finally: write(OUT/'sources'/(name+'.json'),rec)
 def listing(label,args):
  guard(label+'-before')
  start=time.monotonic()
  proc=subprocess.run([str(elf),*args],cwd=REPO,env=env,capture_output=True,timeout=30)
  (OUT/(label+'.stdout')).write_bytes(proc.stdout); (OUT/(label+'.stderr')).write_bytes(proc.stderr)
  rec={'argv':[str(elf),*args],'exit_code':proc.returncode,'elapsed_seconds':time.monotonic()-start,
       'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(proc.stderr).hexdigest(),
       'source_after':guard(label+'-after')}
  write(OUT/(label+'.json'),rec)
  need(proc.returncode==0 and not proc.stderr,'LIST_COMMAND_FAILURE:'+label)
  lines=proc.stdout.decode('utf-8').splitlines(); entries=[]; summary=[]
  for line in lines:
   if not line: continue
   m=re.fullmatch(r'([A-Za-z0-9_:]+): test',line)
   if m: entries.append(m[1]); continue
   m=re.fullmatch(r'(\d+) tests?, (\d+) benchmarks?',line)
   need(m is not None,'UNRECOGNIZED_LIST_LINE:'+line)
   summary.append(tuple(map(int,m.groups())))
  need(summary==[(len(entries),0)] and entries==sorted(set(entries)),'LIST_INVENTORY_COUNT_OR_ORDER')
  return entries
 try:
  guard('initial')
  shutil.copyfile(__file__,OUT/'checker.py')
  for p in snapshots: shutil.copyfile(p,OUT/'original'/p.name)
  need(row['state']=='FINISHED' and row['executed'] is True and row['exit_code']==0 and row['timed_out'] is False,'ORIGINAL_EXIT_OR_TIMEOUT')
  need('exception' not in row and 'source_after_error' not in row,'ORIGINAL_FATAL')
  need(row['pass'] is False and row['checks']==[{'kind':'nonzero-node-suite','pass':False}],'UNEXPECTED_ORIGINAL_REJECTION')
  need(row['source_before']==row['source_after']==binding['source']==SOURCE,'ORIGINAL_SOURCE_BINDING')
  need(row['environment_file_sha256']==ENV_SHA and row['environment_overrides']=={},'ORIGINAL_ENV_BINDING')
  need(row['argv']==[str(elf),'--test-threads=1'] and row['log_sha256']==LOG_SHA and row['log_bytes']==LOG.stat().st_size,'ORIGINAL_COMMAND_BINDING')
  build=strict((RUN/'commands/27-node-lib-test-build-json.json').read_bytes())
  need(build['pass'] is True and build['exit_code']==0 and not build['timed_out'],'BUILD_NOT_SUCCESSFUL')
  need(build['source_before']==build['source_after']==SOURCE,'BUILD_SOURCE')
  need(build['log_sha256']==binding['cargo_log_sha256']==sha(RUN/'commands/27-node-lib-test-build-json.log'),'BUILD_LOG_BINDING')
  values=[]
  for line in (RUN/'commands/27-node-lib-test-build-json.log').read_text().splitlines():
   try: value=strict(line)
   except ValueError: continue
   if isinstance(value,dict): values.append(value)
  artifacts=[v for v in values if v.get('reason')=='compiler-artifact' and v.get('target',{}).get('name')=='trnm_pon_node'
             and v.get('target',{}).get('kind')==['lib'] and v.get('profile',{}).get('test') is True and v.get('executable')]
  need(artifacts==[binding['compiler_artifact']] and artifacts[0]['executable']==str(elf),'UNIQUE_CARGO_ELF_BINDING')
  need([v.get('success') for v in values if v.get('reason')=='build-finished']==[True],'BUILD_FINISHED')
  all_names=listing('all-tests-list',['--list'])
  ignored_names=listing('ignored-tests-list',['--ignored','--list'])
  need(set(ignored_names)<=set(all_names),'IGNORED_NOT_SUBSET')
  total=len(all_names); ignored=set(ignored_names)
  need(total==1287 and len(ignored)==37,'UNEXPECTED_FROZEN_ELF_INVENTORY')
  lines=[(i+1,line) for i,line in enumerate(LOG.read_text().splitlines()) if line.strip()]
  need(lines[0][1]==f'running {total} tests','OUTER_INITIAL_COUNT')
  cursor=1; outer=[]; nested=[]; recognized_summaries=[]
  def take(expected):
   nonlocal cursor
   need(cursor<len(lines),'TRUNCATED_OUTER_RUN')
   numbered=lines[cursor]
   need(numbered[1]==expected,f'OUTPUT_MISMATCH_AT_{numbered[0]}:'+repr(numbered[1])+' expected '+repr(expected))
   cursor+=1; return numbered[0]
  def read_summary(passed,failed,ignored_count,filtered,label):
   nonlocal cursor
   need(cursor<len(lines),'MISSING_SUMMARY:'+label)
   line_no,text=lines[cursor]; match=SUMMARY.fullmatch(text)
   need(match is not None,'MALFORMED_SUMMARY:'+text)
   values=tuple(map(int,match.groups()[1:6]))
   need(match[1]=='ok' and values==(passed,failed,ignored_count,0,filtered),'WRONG_SUMMARY:'+label)
   cursor+=1
   rec={'scope':label,'line':line_no,'outcome':match[1],'passed':passed,'failed':failed,'ignored':ignored_count,
        'measured':0,'filtered_out':filtered,'reported_seconds':match[7]}
   recognized_summaries.append(rec); return rec
  for name in all_names:
   need(cursor<len(lines),'MISSING_OUTER_TEST:'+name)
   line_no,text=lines[cursor]; prefix='test '+name+' ... '
   need(text.startswith(prefix),'OUTER_INVENTORY_ORDER:'+name+':'+text)
   suffix=text[len(prefix):]
   if name in ignored:
    need(suffix=='ignored' or suffix.startswith('ignored, '),'IGNORED_STATUS_MISMATCH:'+name)
    cursor+=1; outer.append({'name':name,'status':'ignored','line':line_no}); continue
   if name not in NESTED:
    need(suffix=='ok','NONPASS_OUTER_TEST:'+name+':'+suffix)
    cursor+=1; outer.append({'name':name,'status':'ok','line':line_no}); continue
   need(suffix=='','NESTED_PARENT_PREFIX:'+name); cursor+=1
   declared=NESTED[name]; child=declared.get('child',name)
   need(child in all_names,'NESTED_CHILD_NOT_IN_ELF')
   observations=[]
   for index in range(declared['count']):
    begin=take('running 1 test')
    child_prefix='test '+child+' ... '
    if declared['normal_summary']:
     child_line=take(child_prefix+'ok')
     summary=read_summary(1,0,0,total-1,'child-of:'+name)
     observations.append({'running_line':begin,'test_line':child_line,'summary':summary})
    else:
     terminal='ok' if index==declared['count']-1 else ''
     child_line=take(child_prefix+terminal)
     observations.append({'running_line':begin,'test_line':child_line,'normal_child_summary_absent_due_to_declared_process_termination':True,
        'final_ok_belongs_to_outer_parent':index==declared['count']-1})
   if declared['normal_summary']: outer_ok_line=take('ok')
   else: outer_ok_line=observations[-1]['test_line']
   nested.append({'outer_test':name,'outer_prefix_line':line_no,'outer_ok_line':outer_ok_line,
     **declared,'child':child,'observations':observations,'source_sha256':sha(REPO/declared['source'])})
   outer.append({'name':name,'status':'ok','line':line_no,'terminal_line':outer_ok_line})
  final=read_summary(total-len(ignored),0,len(ignored),0,'outer-complete-elf-inventory')
  need(cursor==len(lines),'UNACCOUNTED_TRAILING_OUTPUT')
  need(len(nested)==6 and sum(v['count'] for v in nested)==13,'NESTED_INVENTORY')
  need(len(recognized_summaries)==4,'SUMMARY_COUNT')
  need([{'outcome':r['outcome'],'passed':r['passed'],'failed':r['failed'],'ignored':r['ignored'],'measured':r['measured'],'filtered_out':r['filtered_out']}
        for r in recognized_summaries]==row['rust_summaries'],'ORIGINAL_PARSE_DISAGREES')
  source=guard('final')
  write(OUT/'test-inventory.json',{'all':all_names,'ignored':ignored_names,'outer_observations':outer})
  write(OUT/'nested-output-recognition.json',{'scope':'exact known source/ELF/run-specific grammar, no arbitrary last-summary selection',
    'parents':nested,'summaries':recognized_summaries,'all_nonempty_log_lines_accounted_for':True,
    'nested_child_successes_not_added_to_outer_pass_count':True})
  result.update(status='PASS',outer_passed=final['passed'],outer_failed=final['failed'],outer_ignored=final['ignored'],
    outer_total=total,outer_filtered_out=0,outer_measured=0,outer_summary_line=final['line'],
    ordinary_outer_tests_exactly_match_elf_inventory=True,ignored_inventory_exact=True,
    nested_invocations=13,nested_success_summaries=3,source=source,elf_identity=elf_identity,
    original_log_sha256=LOG_SHA,original_row_sha256=snapshots[ROW],original_driver_pass=False,
    original_driver_rejection='len(rust_summaries)==1 rejects legitimate nested subprocess summaries',
    actual_whole_node_test_process_exit_code=0,raw_inputs_unchanged=True,
    test_inventory_sha256=sha(OUT/'test-inventory.json'),recognition_sha256=sha(OUT/'nested-output-recognition.json'),
    checker_sha256=sha(__file__))
 except BaseException as e:
  result.update(status='REFUSED',error=repr(e),traceback=traceback.format_exc())
  try: result['source_after_refusal']=guard('refusal-final')
  except BaseException as ge: result['guard_error']=repr(ge)
 finally:
  result['completed_utc']=utc(); write(OUT/'result.json',result)
  write(OUT/'artifact-inventory.json',[{'path':str(p.relative_to(OUT)),'sha256':sha(p),'bytes':p.stat().st_size}
     for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='artifact-inventory.json'])
  print(json.dumps(result,sort_keys=True),flush=True)
 return 0 if result['status']=='PASS' else 1
if __name__=='__main__': raise SystemExit(main())
