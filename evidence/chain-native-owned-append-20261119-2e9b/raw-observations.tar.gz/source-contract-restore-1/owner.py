from pathlib import Path
import subprocess,json,sys,time,resource,hashlib,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'source-contract-restore-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
t=time.monotonic();res={'schema':'chain-current-contract-input-restore-v1','head':'f0a8364118df01113c14d6a81fbb6fdb6210e4ff','restored':[],'complete':False}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
try:
 p=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=src,capture_output=True);(out/'preflight.stdout').write_bytes(p.stdout);(out/'preflight.stderr').write_bytes(p.stderr);assert p.returncode==0
 raw=subprocess.check_output(['git','ls-tree','-r','--full-tree',res['head']],cwd=src,text=True);entries={}
 for line in raw.splitlines():
  meta,path=line.split('\t',1);mode,kind,blob=meta.split();entries[path]=(mode,kind,blob)
 corpus=json.loads((src/'config/pon/pq-cross-branch-corpus-v1.json').read_text());needed=sorted(set(corpus['pinned_blobs'])|set(corpus['required_paths']))
 for path in needed:
  target=src/path
  if target.exists():continue
  assert not Path(path).is_absolute() and '..' not in Path(path).parts
  mode,kind,blob=entries[path];assert kind=='blob' and mode in ['100644','100755']
  data=subprocess.check_output(['git','cat-file','blob',blob],cwd=src);actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert actual==blob
  target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('xb') as f:f.write(data)
  if mode=='100755':target.chmod(0o755)
  res['restored'].append({'path':path,'git_blob':blob,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 res['restored_files']=len(res['restored']);res['restored_bytes']=sum(r['bytes'] for r in res['restored']);res['wall_seconds']=time.monotonic()-t;res['complete']=True;save()
 print(json.dumps({k:v for k,v in res.items() if k!='restored'},indent=2))
 selected=[p for p in entries if p.startswith('scripts/') and any(w in p for w in ['ci-job','repository_truth','corpus','markdown'])]
 print(json.dumps({'selected_paths':selected},indent=2))
 for path in selected:
  if path.endswith('ci-job.sh'):
   lines=(src/path).read_text().splitlines();print(json.dumps({'path':path,'first_lines':lines[:110]},indent=2))
except BaseException as exc:
 res['error']=repr(exc);res['wall_seconds']=time.monotonic()-t;save();(out/'error.log').write_text(traceback.format_exc());raise
