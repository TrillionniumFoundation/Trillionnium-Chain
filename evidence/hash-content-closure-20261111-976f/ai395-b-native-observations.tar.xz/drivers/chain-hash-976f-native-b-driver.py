#!/usr/bin/env python3
"""Run the frozen B native gates through the unchanged source recorder."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

REPO = Path('/home/qq/chain-hash-transitive-976f-20261111')
OUT = Path('/home/qq/chain-hash-transitive-976f-20261111-native-b')
B = '9fd6ee29a7a663cef547040d9d42cc36a371a17e'
TREE = '7351f83fa9ac5c0e7540fa64bce06ea6f328602f'
PACKAGES = ['trnm-protocol', 'trnm-crypto-primitives', 'trnm-data-availability',
            'trnm-mvcc-fee', 'trnm-release-bundle']


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    phase = sys.argv[1] if len(sys.argv) == 2 else ''
    assert phase in {'focused', 'full', 'clippy'}, 'explicit phase required'
    setup = json.loads((OUT / 'setup-objects-summary.json').read_text())
    assert setup['status'] == 'ready' and setup['candidate'] == B and setup['tree'] == TREE
    environment = json.loads((OUT / 'environment.json').read_text())
    assert all(isinstance(k, str) and isinstance(v, str) for k, v in environment.items())
    assert environment['CARGO_BUILD_JOBS'] == '2'
    assert environment['CARGO_INCREMENTAL'] == '0'
    assert environment['RUST_TEST_THREADS'] == '1'
    assert environment['RUSTUP_TOOLCHAIN'] == '1.95.0'
    assert environment['CARGO_TARGET_DIR'] == str(OUT / 'target')
    assert environment['CARGO_HOME'] == str(OUT / 'cargo-home')
    assert environment['TRNM_PQ_OPENSSL_VERSION'] == '3.5.9'
    assert environment['OPENSSL_STATIC'] == '1'
    for identity in json.loads((OUT / 'provider-identities.json').read_text()):
        path = Path(identity['path'])
        assert path.stat().st_size == identity['bytes'] and digest(path) == identity['sha256']
    child_env = dict(os.environ, **environment)
    for key in list(child_env):
        if key in {'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'} or key.startswith('CARGO_PROFILE_'):
            child_env.pop(key)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == B
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True).strip() == TREE
    cargo_test = ['cargo', 'test', '--manifest-path', 'trillionnium/Cargo.toml', '--locked']
    packages = [arg for package in PACKAGES for arg in ['-p', package]]
    harness = ['--', '--nocapture', '--test-threads=1']
    commands = {
        'focused': [
            ('b-m06-history-all-features', cargo_test + ['-p', 'trnm-mvcc-fee', '--all-features', '--lib',
                                                     'content_commitment_v1::history_v2'] + harness),
            ('b-node-history-default', cargo_test + ['-p', 'trnm-pon-node', '--lib',
                                                    'store::migration_history_v2'] + harness),
            ('b-node-history-all-features', cargo_test + ['-p', 'trnm-pon-node', '--all-features', '--lib',
                                                         'store::migration_history_v2'] + harness),
        ],
        'full': [
            ('b-five-packages-lib-default', cargo_test + packages + ['--lib'] + harness),
            ('b-five-packages-lib-all-features', cargo_test + packages + ['--all-features', '--lib'] + harness),
            ('b-five-packages-doc', cargo_test + packages + ['--doc'] + harness),
        ],
        'clippy': [
            ('b-six-packages-strict-clippy', ['cargo', 'clippy', '--manifest-path', 'trillionnium/Cargo.toml',
                                            '--locked'] + packages + ['-p', 'trnm-pon-node',
                                            '--all-targets', '--all-features', '--', '-D', 'warnings']),
        ],
    }[phase]
    records = OUT / 'records'
    records.mkdir(exist_ok=True)
    summary_path = OUT / ('native-' + phase + '-summary.json')
    summary = {'candidate': B, 'tree': TREE, 'phase': phase, 'status': 'running',
               'started_utc': datetime.now(timezone.utc).isoformat(),
               'whole_chain_quantum_security_qualified': False, 'commands': []}
    with summary_path.open('x') as stream:
        json.dump(summary, stream, indent=2)
    try:
        for label, command in commands:
            receipt_path = records / (label + '.json')
            log_path = records / (label + '.log')
            assert not receipt_path.exists() and not log_path.exists(), 'refuse replay of an existing native record'
            argv = [sys.executable, '-B', 'scripts/ci/record_pq_native_command.py',
                    '--kind', 'head', '--candidate', B, '--tested', B,
                    '--label', label, '--output', str(records), '--', *command]
            print(json.dumps({'native_started': label, 'argv': command}, sort_keys=True), flush=True)
            code = subprocess.run(argv, cwd=REPO, env=child_env).returncode
            item = {'label': label, 'argv': command, 'recorder_exit_code': code,
                    'receipt': str(receipt_path), 'log': str(log_path)}
            if receipt_path.is_file():
                receipt = json.loads(receipt_path.read_text())
                item.update(status=receipt['status'], exit_code=receipt['exit_code'],
                            receipt_sha256=digest(receipt_path),
                            log_sha256=receipt.get('log_sha256'), log_bytes=receipt.get('log_bytes'))
            summary['commands'].append(item)
            summary_path.write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
            print(json.dumps({'native_finished': item}, sort_keys=True), flush=True)
            if code != 0 or item.get('status') != 'command_succeeded' or item.get('exit_code') != 0:
                summary['status'] = 'failed'
                return code if 0 < code < 256 else 1
        summary['status'] = 'passed'
        return 0
    except Exception as error:
        summary.update(status='failed', error=str(error))
        raise
    finally:
        summary['finished_utc'] = datetime.now(timezone.utc).isoformat()
        summary_path.write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n')
        print(json.dumps({'native_phase': phase, 'status': summary['status'],
                          'summary': str(summary_path)}, sort_keys=True), flush=True)


if __name__ == '__main__':
    raise SystemExit(main())
