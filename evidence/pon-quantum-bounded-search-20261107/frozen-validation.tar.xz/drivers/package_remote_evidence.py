#!/usr/bin/env python3
"""Package actual executions on the public implementation commit."""
from pathlib import Path
import json
import re
import subprocess
import package_quantum_evidence as util

ROOT = Path('/workspace/scratch/c9b48df754d6')
REPO = ROOT / 'chain-quantum-next'
DEST = REPO / 'evidence/pon-quantum-bounded-search-20261107'
HEAD = 'e31e4e1122c1f88c72025b507d5706a0dc96fbd7'
TREE = '9ba43628c3004950f4d79392301dba306adb5a1f'
OLD_HEAD = 'aa46f28505ac6d7cf4bb9830db043510a5aac3e2'
OLD_EVIDENCE = 'f22c513ac515cba9808e348d4b8374c02eecf31a'


def old_file(name):
    return subprocess.check_output(['git', 'show', OLD_EVIDENCE + ':evidence/pon-quantum-bounded-search-20261107/' + name], cwd=REPO)


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True).strip() == TREE
    base = ROOT / 'validation-remote'
    observations = {}
    for group in ('quantum', 'repository', 'campaign', 'rust-rerun'):
        directory = base / group
        before = json.loads((directory / 'source-before.json').read_text())
        assert before == json.loads((directory / 'source-after.json').read_text())
        assert before['head'] == HEAD and before['tree'] == TREE
        rows = json.loads((directory / 'commands.json').read_text())
        for row in rows:
            assert util.sha((directory / row['log']).read_bytes()) == row['sha256']
        observations[group] = json.loads((directory / 'result.json').read_text())
    assert all(observations[g]['status'] == 'PASS' for g in ('quantum', 'repository', 'campaign'))
    assert observations['rust-rerun']['status'] == 'FAIL'
    clippy = json.loads((base / 'clippy-supplemental/receipt.json').read_text())
    assert clippy['result'] == 'PASS' and clippy['source']['head'] == HEAD
    assert util.sha((base / 'clippy-supplemental/clippy.log').read_bytes()) == clippy['log_sha256']
    assert json.loads((base / 'clippy-supplemental/source-before.json').read_text()) == json.loads((base / 'clippy-supplemental/source-after.json').read_text())
    fuzz = json.loads((base / 'fuzz-metadata/receipt.json').read_text())
    assert fuzz['result'] == 'PASS' and fuzz['frozen_source'] == HEAD and fuzz['actual_new_execution']
    assert fuzz['source_before'] == fuzz['source_after']
    for name in ('independent-22', 'independent-10'):
        d = json.loads((base / name / 'receipt.json').read_text())
        assert d['exit_code'] == 0 and d['source_stable']
        assert d['before']['head'] == d['after']['head'] == HEAD
        for kind, ext in [('stdout', 'json'), ('stderr', 'txt')]:
            assert util.sha((base / name / (kind + '.' + ext)).read_bytes()) == d[kind + '_sha256']
    campaign = (base / 'campaign/campaign.json').read_bytes()
    review = json.loads((base / 'campaign-review/review.json').read_text())
    assert review['input_sha256'] == util.sha(campaign) and review['source_head'] == HEAD
    assert review['run_count'] == 16 and review['completed_grover_iterations_all_runs'] == 0
    counts = [int(re.findall(r'^Ran (\d+) tests? in ', (base / 'quantum' / f'{i:02d}.log').read_text(), re.M)[0]) for i in range(6)]
    assert counts == [153, 105, 17, 11, 36, 19]

    frozen_rows = util.collect(base, 'remote-frozen-validation')
    for name in ('run_remote_validation.py', 'run_remote_clippy.py', 'run_frozen_validation.py',
                 'package_remote_evidence.py', 'package_quantum_evidence.py'):
        frozen_rows['drivers/' + name] = (ROOT / name).read_bytes()
    for name in ('independent_driver.py', 'constructed_driver.py'):
        frozen_rows['drivers/' + name] = (ROOT / 'validation-next/bounded-independent' / name).read_bytes()
    frozen_archive = util.archive('frozen-validation.tar.xz', frozen_rows,
        'Actual new executions at public e31e4e11, including retained environment bootstrap failure, failed Clippy environment attempt and separate successful Clippy supplement. Unit/control counts are not added to previous source executions.')
    history_rows = util.collect(ROOT / 'validation-next', 'development-observations')
    history_rows.update(util.collect(ROOT / 'validation-frozen', 'original-local-frozen-validation'))
    history_rows['original-local-validation.bundle'] = (ROOT / 'original-local-validation.bundle').read_bytes()
    history_rows['original-local-evidence-index.md'] = old_file('README.md')
    history_archive = util.archive('development-observations.tar.xz', history_rows,
        'Original development and aa46 local frozen observations, including unmodified failures and independent repeats. The Git bundle preserves aa46/f22 local history with the published #755 parent as prerequisite. prepared-frozen-* files were plans, not executed command receipts. Downloaded crate bytes excluded; official receipts retained.')
    qualification = json.loads(old_file('qualification.json'))
    qualification['schema'] = 'trnm-w1-bounded-search-qualification-v2'
    qualification['frozen_source'] = observations['quantum']['source']
    qualification['source_scope'] = 'Actual new executions on the public implementation commit. The API-created commit has the same tree as the earlier local implementation; old logs remain historical observations and were not relabelled. Later evidence commits do not imply another suite execution.'
    validation = qualification['validation']
    validation.pop('original_groups', None)
    validation['execution_groups'] = observations
    validation['fuzz_metadata_initial'] = 'Historical aa46 local cache miss retained in development archive; not the current public-source run.'
    validation['fuzz_metadata_supplemental'] = {
        'status': 'PASS', 'source': HEAD, 'actual_new_execution': True,
        'packages': 149, 'registry_packages': 136, 'lockfile_changed': False,
        'compilation_or_fuzz_execution': False,
        'receipt': 'frozen-validation.tar.xz:remote-frozen-validation/fuzz-metadata/receipt.json'}
    validation['rust_environment_failures'] = {
        'bootstrap': 'Missing exported TRNM_PQ_OPENSSL variable; failed before Cargo invocations.',
        'first_clippy': 'OpenSSL variables existed as shell values but were not exported; openssl-sys could not locate the installation. rust-rerun/result.json remains FAIL.',
        'repair': 'Export all existing OpenSSL 3.5.9 environment values and repeat only strict Clippy with full source checks.',
        'source_or_lock_changed': False,
        'successful_clippy_receipt': 'frozen-validation.tar.xz:remote-frozen-validation/clippy-supplemental/receipt.json'}
    validation['strict_clippy_workspace_all_targets_all_features_warnings_denied'] = 'PASS in separate exact-source supplement; original environment failure retained'
    qualification['local_lint_environment']['successful_clippy_environment'] = clippy['environment']
    qualification['campaign']['sha256'] = util.sha(campaign)
    qualification['campaign']['bytes'] = len(campaign)
    qualification['campaign']['groups'] = review['groups']
    qualification['campaign']['interpretation_limits'] = review['interpretation_limits']
    qualification['archives'] = {'frozen-validation.tar.xz': frozen_archive,
                                  'development-observations.tar.xz': history_archive}
    publication = {
        'schema': 'trnm-quantum-publication-source-v1',
        'base': '7a98f27f99abccc28da2f1f3cc60bdaa2eca4890',
        'original_local_implementation': OLD_HEAD,
        'original_local_evidence': OLD_EVIDENCE,
        'public_implementation': HEAD,
        'identical_implementation_tree': TREE,
        'changed_source_blobs_uploaded_and_verified': 17,
        'ordinary_https_git_push': 'Failed with missing username/credential; no remote ref was updated by that attempt.',
        'publication_channel': 'Connected GitHub Git-data API; normal new-branch creation and fast-forward continuation only.',
        'api_commit_metadata_preserves_local_commit_sha': False,
        'public_source_validation_actually_rerun': True,
        'historical_records_relabelled': False,
        'old_history_bundle': {'archive': 'development-observations.tar.xz',
            'member': 'original-local-validation.bundle',
            'sha256': util.sha((ROOT / 'original-local-validation.bundle').read_bytes()),
            'prerequisite': '7a98f27f99abccc28da2f1f3cc60bdaa2eca4890'},
        'remote_ci_pass_claimed': False,
    }
    readme = old_file('README.md').decode().replace(OLD_HEAD, HEAD)
    readme = readme.replace('da6d869a8c3b849a7ebe995a2ab2e4f75e3e1c3b9b79a5309e90dbc3df665a3c', util.sha(campaign))
    readme = readme.replace('| Initial fuzz locked/offline dependency graph | Failed because the local cache lacked locked dependencies; original exit 101 retained |\n| Supplemental fuzz locked/offline dependency graph | Passed after isolated cache repair; 149 packages, including 136 registry packages; no source or lockfile change |',
        '| Fuzz full locked/offline dependency graph | Passed on the public commit using the previously checksum-verified isolated cache; 149 packages, including 136 registry packages; no fuzz execution |')
    start = readme.index('The original `rust/result.json` remains **FAIL**.')
    end = readme.index('The full Rust runtime test suite was not rerun', start)
    readme = readme[:start] + '''The first local validation at `aa46f285` encountered a missing fuzz cache;
its original Rust aggregate remains **FAIL** and its separate cache-repaired
metadata pass is retained in the historical archive. The public-commit fuzz
metadata above is a new execution, not a relabelled old receipt.

On the public commit, an initial Rust wrapper failed before invoking Cargo
because `TRNM_PQ_OPENSSL` was not exported. The next attempt passed full main
metadata and formatting, but Clippy failed because the remaining OpenSSL values
were shell variables rather than exported process environment. That attempt's
`rust-rerun/result.json` remains **FAIL**. Exporting the existing OpenSSL 3.5.9
values fixed the environment; only strict Clippy was repeated, with complete
before/after source checks, and passed. Both failed attempts and the successful
supplement are retained. No source, lockfile, dependency version or test gate was
changed to repair the environment.

''' + readme[end:]
    readme = readme.replace('The retained Clippy log contains no warning or error lines. These static checks\ndo not establish provider parity or runtime performance.',
        'The successful Clippy log is retained. These static checks do not establish\nprovider parity or runtime performance.')
    readme = readme.replace('The implementation was committed before final validation:',
        'The public implementation was committed before a complete new validation run:')
    boundary = 'This evidence-only continuation does not represent a later composed tree as\nhaving run the same suites again.'
    readme = readme.replace(boundary, boundary + '''

Ordinary HTTPS Git push had no credential in the shell. Publication through the
connected GitHub API preserved all 17 changed blob IDs and the complete source
tree, but generated a different commit ID. All main suites, the campaign,
independent controls, fuzz metadata and Clippy were therefore actually rerun on
the public commit above. [publication.json](publication.json) records this source
transition. The original local `aa46f285` and evidence `f22c513a` history remains
available in the historical archive's Git bundle, with the published #755 commit
as prerequisite. Fresh-clone replay of the primary campaign uses the public
commit and does not depend on importing that historical bundle.
''')
    readme = readme.replace('frozen command logs, before/after identities, the original Rust failure,\n  separate cache-recovery receipts, frozen independent controls, campaign',
        'public-source command logs, before/after identities, retained Rust environment\n  failures and the successful supplement, independent controls, campaign')
    readme = readme.replace('pre-fix numerical failures, the physical-model acceptance failure, earlier\n  controls and their original source identities.',
        'pre-fix numerical failures, the physical-model acceptance failure, earlier\n  controls, the first local frozen validation and their original source identities.\n  Its Git bundle preserves the corresponding original local commits.')
    (DEST / 'README.md').write_text(readme)
    (DEST / 'campaign.json').write_bytes(campaign)
    (DEST / 'qualification.json').write_bytes(util.json_bytes(qualification))
    (DEST / 'publication.json').write_bytes(util.json_bytes(publication))
    files = {p.name: {'bytes': p.stat().st_size, 'sha256': util.sha(p.read_bytes())}
             for p in sorted(DEST.iterdir()) if p.is_file() and p.name != 'manifest.json'}
    (DEST / 'manifest.json').write_bytes(util.json_bytes({
        'schema': 'trnm-w1-bounded-search-evidence-manifest-v2', 'source_commit': HEAD,
        'self_excluded': 'manifest.json', 'files': files}))
    print(json.dumps({'source': HEAD, 'tree': TREE, 'campaign_sha256': util.sha(campaign),
                      'files': len(files), 'archives': qualification['archives']}))


if __name__ == '__main__':
    main()
