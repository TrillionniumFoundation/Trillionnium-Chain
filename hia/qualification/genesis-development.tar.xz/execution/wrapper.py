"""Private real-original Genesis execution wrapper; no candidate mutation."""
from __future__ import annotations
import hashlib, importlib, json, os, pathlib, stat, subprocess, sys, tarfile, tempfile, time, traceback

ROOT = pathlib.Path("/tmp/trnm-genesis-owner-20261116-8ppak97a/repo")
BUNDLE = pathlib.Path("/tmp/trnm-genesis-owner-20261116-8ppak97a/registry-fixed-semantic/bundle")
TARGET = pathlib.Path("/tmp/trnm-typedstore-rust-20261116-jqi3qetj/isolated-cargo-target")
EXPECTED_SOURCE_SET = "a0c3d62591815a2c86df1a77d243b79999f9cbe5238bca230fd15a4243dd3d8b"
EXPECTED_ORACLE = {"bytes": 69181, "sha256": "fb3bb325a86c79eaf2fb902e7af3a1ceb62725dc7db8bc5b1939a02fcb6bfca5"}
EXPECTED_CORPUS = {"bytes": 2234, "sha256": "cfa3dde3dc0a02a02a1d3f543b7a5cb83199996a642dda7221291391cf47089c"}
ARCHIVE = ROOT.parent / "registry-fixed-semantic-source-bundle.tar.xz"
EXPECTED_ARCHIVE = {"bytes": 1258560, "sha256": "a62ccb9522af36b4362e8315e034789c1a96abe0682689996581177906bdce21"}
EXPECTED_BUNDLE = {
    "corpus.jsonl": EXPECTED_CORPUS,
    "corpus.jsonl.xz": {"bytes": 364, "sha256": "63ffd3cccb4b1b77ace8dc2c79eb54c485380afb9f335bfcf83efc070f743957"},
    "native-comparison.json": {"bytes": 1929381, "sha256": "29e7ecbf840e8802a744cc200ea91329f62fd3bde8a3ddf494998755ef76199f"},
    "native-report.json": {"bytes": 1956819, "sha256": "b0929ab20b036a76d2bfb1859862ee58b531d00a655b335cfd18871306f6fd45"},
}

def identity(path):
    digest = hashlib.sha256()
    total = 0
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            total += len(block)
            digest.update(block)
    return {"bytes": total, "sha256": digest.hexdigest()}

def write_json(path, obj):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(obj, stream, sort_keys=True, indent=2)
        stream.write("\n")

def require(value, message):
    if not value:
        raise RuntimeError(message)

def main():
    require(__debug__ and not os.environ.get("PYTHONOPTIMIZE"), "Optimized wrapper is not admitted")
    output = pathlib.Path(tempfile.mkdtemp(prefix="trnm-genesis-original-registry-fixed-20261116-"))
    os.chmod(output, 0o700)
    start = time.monotonic_ns()
    launch = {"schema": "trnm.genesis-original-registry-fixed-launch.v1", "repository": str(ROOT),
              "bundle": str(BUNDLE), "target": str(TARGET), "output": str(output),
              "expected_source_set_sha256": EXPECTED_SOURCE_SET,
              "created_wall_time_ns": time.time_ns(), "wrapper_file": str(pathlib.Path(__file__).absolute()),
              "wrapper_source": identity(pathlib.Path(__file__))}
    write_json(output / "launch.json", launch)
    print(json.dumps({"status": "STARTED_ADMISSION_PENDING", "output": str(output)}), flush=True)
    primary = None
    qualifier_exit = None
    status = "FAIL"
    admitted = None
    report = None
    binary = None
    argv = ["/usr/bin/python3", "-B", "-m", "hia.platform.genesis_store.rust_oracle",
            "--repository", str(ROOT), "--bundle", str(BUNDLE),
            "--output", str(output / "original"), "--target-dir", str(TARGET)]
    try:
        oracle_path = ROOT / "hia/platform/genesis_store/rust_oracle.py"
        require(identity(oracle_path) == EXPECTED_ORACLE, "Wrong frozen Genesis oracle bytes")
        sys.path.insert(0, str(ROOT))
        oracle = importlib.import_module("hia.platform.genesis_store.rust_oracle")
        require(pathlib.Path(oracle.__file__).absolute() == oracle_path, "Wrong oracle import")
        admitted = oracle.validate_bundle(ROOT, BUNDLE)
        require(admitted["comparison"]["build"]["source_set_sha256"] == EXPECTED_SOURCE_SET,
                "Wrong complete source binding")
        require(len(admitted["source_inputs"]) == 45 and len(admitted["original_sources"]) == 4361,
                "Wrong independently verified complete source counts")
        require(admitted["comparison"]["corpus"]["raw"] == EXPECTED_CORPUS,
                "Wrong original canonical30 corpus")
        require(len(admitted["inputs"]) == 30 and len(admitted["comparison"]["cases"]) == 30,
                "Wrong complete native semantic history count")
        require(admitted["native_counts"]["cases"] == 30
                and admitted["native_counts"]["processes"] == 62,
                "Wrong actual native semantic process count")
        require(admitted["bundle_artifacts"] == EXPECTED_BUNDLE, "Wrong actually completed native artifact bytes")
        archive_stat = ARCHIVE.lstat()
        require(stat.S_ISREG(archive_stat.st_mode) and archive_stat.st_nlink == 1
                and stat.S_IMODE(archive_stat.st_mode) == 0o400,
                "Archive is not the sealed single-link regular package")
        require(identity(ARCHIVE) == EXPECTED_ARCHIVE, "Sealed actual native package differs")
        expected_members = {**admitted["source_inputs"],
                            **{"bundle/" + name: value for name, value in EXPECTED_BUNDLE.items()}}
        actual_members = {}
        with tarfile.open(ARCHIVE, "r:xz") as archive:
            for member in archive:
                require(member.isfile() and member.name in expected_members
                        and member.name not in actual_members,
                        "Unadmitted, duplicate, or nonregular package member")
                require(member.size == expected_members[member.name]["bytes"], "Package member length differs")
                with archive.extractfile(member) as stream:
                    raw = stream.read(member.size + 1)
                observed = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
                require(observed == expected_members[member.name], "Package member hash differs")
                actual_members[member.name] = observed
        require(actual_members == expected_members and len(actual_members) == 49,
                "Package complete source and native artifact set differs")
        write_json(output / "package-admission.json", {
            "status": "PASS_ADMISSION_ONLY", "path": str(ARCHIVE), **EXPECTED_ARCHIVE,
            "members": actual_members, "member_count": len(actual_members),
            "original_runtime_executed": False})
        write_json(output / "independent-native-admission.json", {
            "status": "PASS_ADMISSION_ONLY", "native_counts": admitted["native_counts"],
            "source_set_sha256": EXPECTED_SOURCE_SET, "native_sources": admitted["source_inputs"],
            "original_sources": admitted["original_sources"], "corpus": EXPECTED_CORPUS,
            "bundle_artifacts": admitted["bundle_artifacts"],
            "original_execution": "NOT_RUN_AT_ADMISSION"})
        env = dict(os.environ)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["PATH"] = "/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:" + env.get("PATH", "/usr/bin:/bin")
        with (output / "qualifier.stdout.raw").open("xb") as stdout, (output / "qualifier.stderr.raw").open("xb") as stderr:
            result = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, check=False)
        qualifier_exit = result.returncode
        report_path = output / "original/report.json"
        require(report_path.is_file(), "Actual oracle did not produce a final report")
        report = oracle.load_json(report_path.read_bytes())
        if report.get("original_test_binary") is not None:
            observed = report["original_test_binary"]
            binary_path = pathlib.Path(observed["path"])
            require(binary_path == output / "original/original-test-binary", "Wrong retained original binary path")
            binary = {"path": str(binary_path), **identity(binary_path)}
            require({key: binary[key] for key in ("bytes", "sha256")} ==
                    {key: observed[key] for key in ("bytes", "sha256")}, "Final binary identity differs")
        require(qualifier_exit == 0 and report.get("status") == "PASS",
                "Actual original qualifier failed; all original logs and report are preserved")
        require(report.get("original_case_rows_observed") == 30 and report.get("controls") == 30
                and report.get("passed") == 30 and report.get("failed") == 0,
                "Actual comparison count is incomplete")
        require(report.get("original_tests") == list(oracle.ORIGINAL_TESTS),
                "Required actual original tests were not all completed")
        require(report.get("native_source_set_sha256") == EXPECTED_SOURCE_SET
                and report.get("exact_corpus") == EXPECTED_CORPUS, "Actual report binding differs")
        require(report.get("primary_error") is None and report.get("final_errors") == [],
                "Actual oracle retained failures")
        require(all(row.get("status") == "PASS" for row in report["source_fences"]),
                "Actual source/dependency/binary fence failed")
        require(identity(ARCHIVE) == EXPECTED_ARCHIVE, "Original native source package changed during execution")
        status = "PASS"
    except BaseException as error:
        primary = {"error": repr(error), "traceback": traceback.format_exc()}
    artifacts = {}
    for relative in ("launch.json", "package-admission.json", "independent-native-admission.json", "qualifier.stdout.raw",
                     "qualifier.stderr.raw", "original/report.json", "original/comparison.json",
                     "original/original-observations.json", "original/source-and-binary-after.json"):
        path = output / relative
        if path.is_file():
            artifacts[relative] = identity(path)
    summary = {
        "schema": "trnm.genesis-original-registry-fixed-wrapper.v1", "status": status,
        "qualifier_exit_code": qualifier_exit, "wrapper_error": primary,
        "argv": argv, "cwd": str(ROOT), "output": str(output),
        "elapsed_ns": time.monotonic_ns() - start, "artifacts": artifacts,
        "binary": binary, "expected_source_set_sha256": EXPECTED_SOURCE_SET,
        "native_source_package": {"path": str(ARCHIVE), **EXPECTED_ARCHIVE},
        "original_case_rows_observed": None if report is None else report.get("original_case_rows_observed"),
        "actual_controls": None if report is None else report.get("controls"),
        "actual_passed": None if report is None else report.get("passed"),
        "actual_failed": None if report is None else report.get("failed"),
        "actual_original_tests": [] if report is None else report.get("original_tests"),
        "original_primary_error": None if report is None else report.get("primary_error"),
        "original_final_errors": None if report is None else report.get("final_errors")}
    write_json(output / "wrapper-execution.json", summary)
    print(json.dumps({"status": status, "qualifier_exit_code": qualifier_exit,
                      "summary": str(output / "wrapper-execution.json"),
                      "actual_rows": summary["original_case_rows_observed"],
                      "actual_passed": summary["actual_passed"],
                      "actual_original_tests": len(summary["actual_original_tests"]),
                      "error": primary}), flush=True)
    return 0 if status == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
