import hashlib,json,os,shutil,subprocess,sys,time,tomllib
from pathlib import Path
repo=Path('/home/qian-qi/worktrees/trnm-pq-frozen-verifier-20261103')
out=Path('/home/qian-qi/qualification/pq-frozen-verifier-20261103-4502-isolated-cache')
out.mkdir(parents=True,exist_ok=False)
paths=['formal/pon-nakamoto-v1/w1_hardened_verifier/'+x for x in ['src/main.rs','README.md','Cargo.toml','Cargo.lock']]
manifest='formal/pon-nakamoto-v1/w1_hardened_verifier/Cargo.toml'
cargo='/home/qian-qi/.cargo/bin/cargo'
home=out/'cargo-home'
home.mkdir()
lock=tomllib.loads((repo/'formal/pon-nakamoto-v1/w1_hardened_verifier/Cargo.lock').read_text())
packages=[p for p in lock['package'] if p.get('source')=='registry+https://github.com/rust-lang/crates.io-index']
original_cargo=Path('/home/qian-qi/.cargo')
copied={'packages':len(packages),'crate_archives':0,'archive_bytes':0,'index_entries':0}
for index in (original_cargo/'registry/index').glob('index.crates.io-*'):
    if not index.is_dir(): continue
    config=index/'config.json'
    if not config.is_file(): continue
    cfg=json.loads(config.read_text())
    if not str(cfg.get('dl','')).startswith('https://static.crates.io/'): continue
    dest_index=home/'registry/index'/index.name
    dest_index.mkdir(parents=True)
    shutil.copyfile(config,dest_index/'config.json')
    for p in packages:
        name=p['name'].lower()
        rel=('1/'+name if len(name)==1 else '2/'+name if len(name)==2 else '3/'+name[0]+'/'+name if len(name)==3 else name[:2]+'/'+name[2:4]+'/'+name)
        src=index/'.cache'/rel
        if src.is_file():
            dst=dest_index/'.cache'/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(src,dst)
            copied['index_entries']+=1
        archive=original_cargo/'registry/cache'/index.name/(p['name']+'-'+p['version']+'.crate')
        if archive.is_file():
            data=archive.read_bytes()
            if hashlib.sha256(data).hexdigest()!=p['checksum']: continue
            dst=home/'registry/cache'/index.name/archive.name
            dst.parent.mkdir(parents=True,exist_ok=True)
            dst.write_bytes(data)
            copied['crate_archives']+=1
            copied['archive_bytes']+=len(data)
(out/'public-cache-snapshot.json').write_text(json.dumps(copied,indent=2)+'\n')
old=Path('/home/qian-qi/qualification/pq-frozen-verifier-20261103-4502')
(out/'initial-lock-wait.json').write_text(json.dumps({'job_id':'1a1a0fc1cfc-96a-6c01','observed_state':'cancelled','supervisor_exit_code':-15,'original_records_retained':str(old),'original_test_log_sha256':hashlib.sha256((old/'tests.log').read_bytes()).hexdigest(),'original_test_log':(old/'tests.log').read_text(),'reason':'own waiting job stopped; independent public package cache used; unrelated lock owner untouched'},indent=2)+'\n')
env=os.environ.copy()
env['CARGO_HOME']=str(home)
print(json.dumps({'public_cache_snapshot':copied,'cargo_home':str(home)}),flush=True)
env.update(CARGO_TARGET_DIR=str(out/'target'),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',RUSTC='/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc')
for k in ['RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RISC0_DEV_MODE','BONSAI_API_URL','BONSAI_API_KEY','RISC0_PROVER']:
    if env.get(k): raise RuntimeError('unexpected override '+k)
def hashes():
    return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
def run(label,argv,frozen=True,allow_failure=False):
    start=time.monotonic_ns()
    before=hashes() if frozen else None
    rec={'label':label,'argv':argv,'cwd':str(repo),'status':'running','source_before':before,'base_commit':'1c7e8ab7cd6a321cad4e6c7f7e8a197d7b3be14c','whole_chain_quantum_security_qualified':False}
    rp=out/(label+'.json'); lp=out/(label+'.log')
    rp.write_text(json.dumps(rec,indent=2)+'\n')
    with lp.open('xb') as f:
        result=subprocess.run(argv,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
    after=hashes() if frozen else None
    rec.update(status='command_succeeded' if result.returncode==0 else 'command_failed',exit_code=result.returncode,elapsed_ns=time.monotonic_ns()-start,log_sha256=hashlib.sha256(lp.read_bytes()).hexdigest(),log_bytes=lp.stat().st_size,source_after=after)
    rp.write_text(json.dumps(rec,indent=2)+'\n')
    print(json.dumps({'label':label,'exit_code':result.returncode,'source_unchanged':before==after if frozen else None,'log':str(lp)}),flush=True)
    if frozen and before!=after: raise RuntimeError('source changed during '+label)
    if result.returncode and not allow_failure: print(lp.read_text(errors='replace')[-6000:],flush=True); sys.exit(result.returncode)
    return result.returncode
run('preflight',['bash','scripts/project-preflight.sh'])
run('format',[cargo,'+1.95.0','fmt','--manifest-path',manifest],False)
run('diff-check',['git','diff','--check'])
(out/'source.json').write_text(json.dumps({'base_commit':'1c7e8ab7cd6a321cad4e6c7f7e8a197d7b3be14c','worktree_modified':True,'source':hashes(),'scope':'isolated verification-only crate, not full source corpus'},indent=2)+'\n')
proof=out/'retained-proof';proof.mkdir()
prefix='evidence/pon-w1-complete-succinct-20261028/full-proof/'
assets=[('header.bin',prefix+'header.bin','7b96038f228a1eedccf7b29ffc54802aba691be7259e33937846c6bf6126d78f'),('succinct.bin',prefix+'succinct.bin','ca4d3c9f5159b7001abae7491604cadbbbfa97c0f93d90d5943e48936813ca2b'),('real-lift.bin','evidence/pon-w1-verifier-hardening-20261028/real-lift-0000.bin','d2b06a1feca2d15e8dc5741b43f481a82c32d7d3dab01e413d357012467093d3')]
for name,source_path,expected in assets:
    blob=subprocess.check_output(['git','show','HEAD:'+source_path],cwd=repo)
    assert hashlib.sha256(blob).hexdigest()==expected,name
    (proof/name).write_bytes(blob)
(out/'asset-identities.json').write_text(json.dumps(assets,indent=2)+'\n')
run('toolchain',[env['RUSTC'],'--version','--verbose'])
if run('metadata-offline',[cargo,'+1.95.0','metadata','--locked','--offline','--format-version','1','--manifest-path',manifest],allow_failure=True):
    run('metadata-fetch',[cargo,'+1.95.0','metadata','--locked','--format-version','1','--manifest-path',manifest])
run('tests',[cargo,'+1.95.0','test','--offline','--locked','--release','--manifest-path',manifest])
run('build',[cargo,'+1.95.0','build','--offline','--locked','--release','--manifest-path',manifest])
run('clippy',[cargo,'+1.95.0','clippy','--offline','--locked','--release','--all-targets','--manifest-path',manifest,'--','-D','warnings'])
run('fmt-check',[cargo,'+1.95.0','fmt','--manifest-path',manifest,'--','--check'])
binary=out/'target/release/trnm-w1-hardened-verifier'
(out/'binary.json').write_text(json.dumps({'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()},indent=2)+'\n')
run('full-receipt',[str(binary),'verify',str(proof/'header.bin'),str(proof/'succinct.bin')])
run('full-controls',[str(binary),'controls',str(proof/'header.bin'),str(proof/'succinct.bin'),str(out/'controls')])
run('recursion-diagnostic',[str(binary),'verify-recursion',str(proof/'real-lift.bin')])
(out/'final-source.json').write_text(json.dumps(hashes(),indent=2)+'\n')
subprocess.run(['git','diff','--stat'],cwd=repo,check=True)
print('COMPLETE '+str(out),flush=True)
