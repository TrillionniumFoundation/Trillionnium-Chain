"""Evidence caller for four original pilot controls; never an authority owner.

This is a post-observation comparison with an existing V2 parent candidate. It
does not issue the original five-artifact prospective experiment assessment.
Every model phase uses the unchanged pilot child and original supervisor/caps.
"""
from fractions import Fraction
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
CHAIN = ROOT / "chain-native-c96022"
RUN = ROOT / "real-model-run-001"
OUTPUT = RUN / "original-four-controls-followup"
PYTHON = ROOT / "model-env-3123-offline/bin/python"
MATERIALS = ROOT / "materials-legacy-i09"
sys.path.insert(0, str(CHAIN / "scripts"))
import llm_runtime_pilot as runtime
import llm_runtime_candidate_observation_v1 as observation

os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                  PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1",
                  OMP_NUM_THREADS="2", MKL_NUM_THREADS="2", OPENBLAS_NUM_THREADS="2")

assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=CHAIN, text=True).strip() == "c96022b897c1235fdbdbfcfa32764403511c6aab"
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=CHAIN, text=True).strip()
plan = runtime.validate_plan(runtime.read_json(RUN / "training-plan.json"))
manifest, _ = runtime.verify_materials(MATERIALS)
assert plan == runtime.experiment_plan(manifest, threads=2, steps=10)
candidate_input = runtime.read_json(RUN / "candidate-observe/candidate-observation-input.json")
candidate_result = runtime.read_json(RUN / "candidate-observe/candidate-observation-result.json")
observation._terminal(candidate_result["supervisor"], plan["inference_budget"])
assert observation._verify_observation(candidate_input) == candidate_result["actual_observation_sha256"]
assert candidate_input["plan_digest"] == runtime.identity(plan)
candidate_actual = runtime.read_json(RUN / "candidate-observe/execution/actual-observation.json")
derived_contract = candidate_actual["actual_loaded_contract"]
candidate_rows = runtime.read_json(RUN / "candidate-observe/execution/predictions.json")
predictions = {"candidate": runtime.verify_predictions(candidate_rows, plan, "candidate",
    candidate_input["candidate"]["adapter"], candidate_input["parent"]["contract"])}
train_actual = runtime.read_json(RUN / "parent-train/execution/actual-receipt.json")

# This is an additional local disk admission check, not a reservation or a
# replacement for any historical LAN root budget. Retain >=1.4 GiB before effects.
assert shutil.disk_usage(ROOT).free >= 1400 * 1024**2, "CONTROL_DISK_GATE"
OUTPUT.mkdir(mode=0o700)
summary = dict(schema="controlled-original-four-controls-followup-v1",
    scope="post-observation-same-operator-public-task-comparison-not-prospective-or-native",
    source_chain="c96022b897c1235fdbdbfcfa32764403511c6aab",
    caller_sha256=runtime.file_sha(__file__), plan=runtime.identity(plan),
    plan_file_sha256=runtime.file_sha(RUN / "training-plan.json"),
    candidate= candidate_input["candidate"],
    candidate_original_contract=candidate_input["parent"]["contract"],
    candidate_actual_loaded_contract=derived_contract,
    candidate_task_link=candidate_actual["task_link"],
    existing_candidate_observation_sha256=candidate_result["actual_observation_sha256"],
    control_order=runtime.CONTROLS, training_budget=plan["training_budget"],
    inference_budget=plan["inference_budget"], candidate_already_observed=True,
    prospective_experiment=False, independent_evaluation=False,
    ordinary_installation=False, adoption_eligible=False, reward_eligible=False,
    original_five_participant_receipt_issued=False, phases=[], outcome="running")
runtime.save(OUTPUT / "freeze.json", dict(summary, frozen_before_control_training=True,
    monotonic_ns=time.monotonic_ns(), wall_time_ns=time.time_ns(),
    disk_free_bytes=shutil.disk_usage(ROOT).free))

def phase(role, operation):
    name = operation + "-" + role
    dest = OUTPUT / name
    args = [str(PYTHON), str(CHAIN / "scripts/llm_runtime_pilot.py"), "_child",
        "--materials", str(MATERIALS), "--plan", str(RUN / "training-plan.json"),
        "--output", str(dest), "--phase", operation, "--role", role]
    if operation == "evaluate":
        args += ["--artifact", str(OUTPUT / ("train-" + role))]
    budget = plan["training_budget" if operation == "train" else "inference_budget"]
    result = runtime.supervise(args, dest, budget, exit_observation=plan.get("exit_observation"))
    summary["phases"].append(dict(name=name, command=args, result=result))
    runtime.save(OUTPUT / "summary.json", summary)
    print(json.dumps(dict(phase=name, outcome=result["outcome"],
                         stop_reason=result.get("stop_reason"))), flush=True)
    observation._terminal(result, budget)
    report = runtime.read_json(dest / "actual-receipt.json")
    assert report["outcome"] == "success" and report["contract"] == derived_contract
    assert report["experiment"] == runtime.identity(plan) and report["role"] == role
    assert report["runtime_source"] == plan["runtime_source"]
    return report

try:
    training = {}
    artifacts = {"candidate": candidate_input["candidate"]["adapter"]}
    for role in runtime.CONTROLS:
        # Account for the one full FP32 model artifact without lowering the
        # predeclared 1.4 GiB floor when the shared workspace is under pressure.
        assert shutil.disk_usage(ROOT).free >= 1400 * 1024**2, "CONTROL_DISK_GATE"
        actual = phase(role, "train")
        training[role] = actual["training"]
        artifacts[role] = actual["artifact"]
    assert len(set(artifacts.values())) == 5, "CONTROL_ARTIFACT_ALIAS"
    counts = [(train_actual["training"][key]) for key in ("steps", "tokens", "supervised_tokens")]
    for role in ("fresh-budget-matched-lora", "budget-matched-full-tune"):
        assert [training[role][key] for key in ("steps", "tokens", "supervised_tokens")] == counts
    assert all(training[role]["steps"] == 0 for role in
        ("current-backbone", "randomized-rank-matched-lora"))
    runtime.save(OUTPUT / "control-roster.json", dict(artifacts=artifacts,
        frozen_before_control_evaluation=True, candidate_was_already_evaluated=True,
        plan=runtime.identity(plan), derived_contract=derived_contract))
    for role in runtime.CONTROLS:
        phase(role, "evaluate")
        rows = runtime.read_json(OUTPUT / ("evaluate-" + role) / "predictions.json")
        predictions[role] = runtime.verify_predictions(rows, plan, role, artifacts[role], derived_contract)
    scores = {}
    for role in runtime.PARTICIPANTS:
        scores[role] = {}
        for partition in ("calibration", "evaluation"):
            groups = {}
            for task in plan["tasks"]:
                if task["partition"] == partition:
                    groups.setdefault(task["source_group"], []).append(
                        int(predictions[role][task["id"]] == task["target_output_sha256"]))
            score = sum((Fraction(sum(group), len(group)) for group in groups.values()), Fraction()) / len(groups)
            scores[role][partition] = [score.numerator, score.denominator]
    strongest = max(Fraction(*scores[role]["evaluation"]) for role in runtime.CONTROLS)
    gain = Fraction(*scores["candidate"]["evaluation"]) - strongest
    selected = max(runtime.CONTROLS, key=lambda role:
        (Fraction(*scores[role]["calibration"]), -runtime.CONTROLS.index(role)))
    assert observation._verify_observation(candidate_input) == candidate_result["actual_observation_sha256"]
    summary.update(outcome="completed", scores=scores,
        calibration_selected_control=selected,
        gain_vs_strongest_evaluation_control=[gain.numerator, gain.denominator],
        positive_vs_all_controls=gain > 0, all_four_original_controls_executed=True,
        matched_steps_tokens_supervised_tokens=counts,
        output_byte_metric="equal-source-group-exact-output-bytes",
        actual_consumption_assumed_equal=False,
        quality_verdict="NONPOSITIVE_GAIN_REJECT" if gain <= 0 else "LOCAL_POSITIVE_GAIN_NO_QUALIFICATION")
except BaseException as error:
    summary.update(outcome="aborted", error_type=type(error).__name__, error=str(error),
        all_four_original_controls_executed=False, quality_verdict="INCOMPLETE_NO_ADOPTION")
    raise
finally:
    runtime.save(OUTPUT / "summary.json", summary)
