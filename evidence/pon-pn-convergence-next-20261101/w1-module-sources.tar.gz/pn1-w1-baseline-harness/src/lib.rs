//! Exact W1 source-module regression harness; not a workspace/PQ build.
pub mod pon_work;
