from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=s.parent/'native-append-controls-3';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);tests=sys.argv[2];res={'schema':'chain-actual-native-owned-append-controls-v1','complete':False,'stages':[]}
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(s.parent/'target');env['PATH']='/home/qq/.cargo/bin:'+env['PATH']
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=s,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['stages'].append(row);save();print(json.dumps(row),flush=True)
 if name=='original-post-write-and-append-controls' or rc:
  print((out/(name+'.stdout')).read_text(errors='replace')[-24000:],flush=True);print((out/(name+'.stderr')).read_text(errors='replace')[-10000:],flush=True)
 return rc
def replace(text,before,after):
 assert text.count(before)==1,(before[:100],text.count(before));return text.replace(before,after)
try:
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 post=s/'trillionnium/crates/trnm-pon-node/src/store/native_authenticated/post_write_readback.rs';t=post.read_text();(out/'before-post-write.rs').write_text(t)
 t=replace(t,'    /// This private native operation owns the ONLY allowed write itself. It\n    /// never accepts a caller\\'s "unchanged" claim, allowed-write count, graph\n    /// receipt or replacement scope. The parent graph was fully checked in a\n    /// scope captured BEFORE its first read and remained unwritten through its\n    /// final callback, actual SQL deltas and native apply.','''    /// This private native operation owns the metadata INSERT itself. The
    /// consumed parent owner can additionally hold only the facts sealed by
    /// its actual native apply, never a supplied allowed-write count or graph
    /// verdict. The original complete parent read precedes the native appends;
    /// their passive schema and exact total effects are independently fenced.''')
 t=replace(t,'                    // The exact Root remains backed by the actual graph just\n                    // verified before our sole passive metadata INSERT.','''                    // The original complete parent Root remains backed by its
                    // actual graph before our proven passive writes.''')
 t=replace(t,'                    // All old-owner/schema/sole-passive-write checks above must\n                    // succeed first. No extra record, SQL operation or callback\n                    // is introduced, and an absent/mismatched frontier retains\n                    // the original full graph reader.','''                    // All original-owner/schema/exact-passive-write checks
                    // above must succeed first. No new graph source or callback
                    // is introduced, and an absent/mismatched frontier retains
                    // the original full graph reader.''')
 post.write_text(t)
 front=post.parent/'post_write_readback/frontier_tests.rs';raw=front.read_bytes();assert raw==subprocess.check_output(['git','show','HEAD:'+str(front.relative_to(s))],cwd=s)
 front.write_text(raw.decode()+'\n#[path = "append_tests.rs"]\nmod append_controls;\n')
 test=front.with_name('append_tests.rs')
 with test.open('x') as f:f.write(tests)
 assert run('format',['/home/qq/.cargo/bin/cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all'])==0
 production=[
 'trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_store.rs',
 'trillionnium/crates/trnm-pon-node/src/store/native_authenticated/post_write_readback.rs',
 'trillionnium/crates/trnm-pon-node/src/store/native_authenticated.rs']
 patch=subprocess.check_output(['git','diff','--',*production],cwd=s);(out/'production.patch').write_bytes(patch)
 ap=s/'trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_append.rs';(out/'native_append.rs').write_bytes(ap.read_bytes());(out/'append_tests.rs').write_bytes(test.read_bytes())
 res['production_patch']={'bytes':len(patch),'sha256':hashlib.sha256(patch).hexdigest()};res['added_production']={'path':str(ap),'bytes':ap.stat().st_size,'sha256':hashlib.sha256(ap.read_bytes()).hexdigest()};res['added_tests']={'path':str(test),'bytes':test.stat().st_size,'sha256':hashlib.sha256(test.read_bytes()).hexdigest()};save()
 rc=run('original-post-write-and-append-controls',['/home/qq/.cargo/bin/cargo','test','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--release','--locked','--offline','--lib','store::native_authenticated::post_write_readback::','--','--nocapture','--test-threads=1'])
 res['complete']=True;res['native_exit_code']=rc;save();print(json.dumps(res,indent=2),flush=True);sys.exit(rc)
except BaseException as e:
 if isinstance(e,SystemExit):raise
 res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
