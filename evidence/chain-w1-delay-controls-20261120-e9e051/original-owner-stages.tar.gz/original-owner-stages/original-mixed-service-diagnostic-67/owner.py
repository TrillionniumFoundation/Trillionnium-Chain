from pathlib import Path
import json,sys,time,resource,subprocess,hashlib,os,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'original-mixed-service-diagnostic-67';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);env=os.environ.copy();env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];env['CARGO_TARGET_DIR']=str(src.parent/'target');env['TRNM_PUBLIC_V3_CAMPAIGN_DIR']=str(out/'mixed-service-campaign');env['TRNM_CI_RECEIPT_DIR']=str(out/'receipts');cmd=['cargo','+1.95.0','test','--release','--locked','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--test','public_v3_service_campaign','public_v3_mixed_calls_reopen_with_complete_failure_denominators','--','--exact','--show-output','--test-threads=1'];r={'schema':'chain-additional-original-mixed-service-diagnostic-v1','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'original_test_sha256':hashlib.sha256((src/'trillionnium/crates/trnm-pon-node/tests/public_v3_service_campaign.rs').read_bytes()).hexdigest(),'source_diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src)).hexdigest(),'command':cmd,'original_four_ci_failures_preserved':True,'replacement_for_original_ci_or_f0':False,'complete':False}
def save():(out/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=src,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);x={'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};r[name]=x;save();return rc
try:
 save();assert run('preflight',['bash','scripts/project-preflight.sh'])==0;rc=run('original-test',cmd);p=out/'mixed-service-campaign/report.json'
 if p.exists():
  raw=p.read_bytes();report=json.loads(raw);r['report']={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'attempts':len(report['attempts']),'finite_target_met':report['finite_target_met'],'phase_count':len(report['phases'])}
 r['complete']=True;save();print(json.dumps(r),flush=True);print((out/'original-test.stderr').read_text(errors='replace')[-2500:],flush=True);sys.exit(rc)
except BaseException as e:
 if isinstance(e,SystemExit):raise
 r['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
