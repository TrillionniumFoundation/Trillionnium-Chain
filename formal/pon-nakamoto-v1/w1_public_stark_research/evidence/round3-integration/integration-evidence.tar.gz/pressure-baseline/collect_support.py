#!/usr/bin/env python3
"""Read-only post-run cleanup check and small evidence archive; no verifier jobs."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess
import tarfile
import time
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parent
REPO=Path('/home/qian-qi/work/chain-w1-bounded-verifier-20261108-f16ac5')
COMMIT='cae1e3657b0913991d9465995e709a544218a27c'
CONTRACTS=('docs/research/PON_WORK_REJECTION_COST_V2_PLAN.md',
           'docs/protocol/pon-nakamoto-v1/details/PUBLIC_POOL_INTAKE_V3.md',
           'docs/security/PON_ORIGINAL_FOUR_SECOND_REPLAY_STAGES_20261031.md',
           'config/systemd/trnmponpublic.slice')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    result=json.loads((ROOT/'campaign-01/result.json').read_text())
    unit=result['unit'];cg=Path(result['cgroup_before']['path'])
    query=subprocess.run(['systemctl','--user','show',unit,'--property=LoadState','--property=ActiveState',
                          '--property=SubState','--property=ControlGroup','--property=MainPID'],capture_output=True,text=True)
    identities=[]
    for request in result['requests']:
        pid=request['pid'];p=Path('/proc')/str(pid)/'stat'
        try:
            raw=p.read_text();ticks=int(raw[raw.rfind(')')+2:].split()[19])
        except (FileNotFoundError,ProcessLookupError):ticks=None
        identities.append({'pid':pid,'original_starttime_ticks':request['membership_before_release']['starttime_ticks'],
                           'current_starttime_ticks':ticks,'same_process_still_present':ticks==request['membership_before_release']['starttime_ticks']})
    active_copies=[];expected=str(ROOT/'inputs/verifier')
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            if os.readlink(p/'exe')==expected:active_copies.append(int(p.name))
        except OSError:pass
    value={'schema':'w1-pressure-postcleanup-independent-read-v1','observed_utc':datetime.now(timezone.utc).isoformat(),
           'monotonic_ns':time.monotonic_ns(),'unit':unit,'query_exit_code':query.returncode,
           'query_stdout':query.stdout,'query_stderr':query.stderr,'cgroup_path':str(cg),
           'cgroup_exists':cg.exists(),'known_pid_identities':identities,'active_exact_verifier_copy_pids':active_copies,
           'original_result_sha256':sha(ROOT/'campaign-01/result.json'),
           'cleanup_confirmed':not cg.exists() and not any(x['same_process_still_present'] for x in identities) and not active_copies}
    (ROOT/'independent_cleanup.json').write_text(json.dumps(value,indent=2)+'\n')
    target=ROOT/'contracts';target.mkdir(exist_ok=False)
    pinned={}
    for path in CONTRACTS:
        result=subprocess.run(['git','-C',str(REPO),'show',COMMIT+':'+path],capture_output=True,check=True)
        copy=target/Path(path).name;copy.write_bytes(result.stdout)
        pinned[path]={'source_commit':COMMIT,'copy':'contracts/'+copy.name,'bytes':len(result.stdout),
                      'sha256':hashlib.sha256(result.stdout).hexdigest()}
    (target/'manifest.json').write_text(json.dumps(pinned,indent=2)+'\n')
    files=[]
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(ROOT).as_posix()
        if rel in ('guarded-baseline-verifier','inputs/verifier') or rel.endswith('.bin') or rel.endswith('.tar.gz') or rel=='evidence-files.json':continue
        if '__pycache__' in p.parts:continue
        files.append(p)
    inventory={p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in files}
    (ROOT/'evidence-files.json').write_text(json.dumps(inventory,indent=2)+'\n');files.append(ROOT/'evidence-files.json')
    archive=ROOT/'pressure-evidence.tar.gz'
    with archive.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as tar:
                for p in sorted(files):
                    info=tar.gettarinfo(str(p),arcname=p.relative_to(ROOT).as_posix())
                    info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
                    with p.open('rb') as stream:tar.addfile(info,stream)
    print(json.dumps({'cleanup_confirmed':value['cleanup_confirmed'],'known_pids':len(identities),
                      'active_exact_verifier_copy_pids':active_copies,'cgroup_exists':cg.exists(),
                      'archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),
                      'full_binary_and_proof_inputs_retained_remote_but_not_duplicated_in_metadata_archive':True}))

if __name__=='__main__':main()
