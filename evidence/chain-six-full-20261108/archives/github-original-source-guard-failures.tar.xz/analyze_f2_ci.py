import ast, hashlib, json, pathlib, re
root=pathlib.Path("/tmp/proof-pq-d9fb-github-failures")
source=root/"source"
head="0101b0ce76239832e0b2d19d0fd3f07e40fabeb4"
base="7e044b65454f4c9ea505591727332acffb33e7e5"
merge="d5ba8574297839ed06e7a016207827b7993825c6"
index=json.loads((root/"pinned-source-archive-index.json").read_text())
for row in index:
    path=(root/"historical-source"/row["historical_file"]) if "historical_file" in row else source/row["path"]
    raw=path.read_bytes()
    assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==row["git_blob"],str(path)
tree=ast.parse((source/"scripts/w1_lifetime_ledger.py").read_text())
literals={}
for n in tree.body:
    if isinstance(n,ast.Assign):
        for target in n.targets:
            if isinstance(target,ast.Name) and target.id in ("SOURCE_BASE","SOURCE_PINS"):
                literals[target.id]=ast.literal_eval(n.value)
pins=literals["SOURCE_PINS"]
contract=json.loads((source/"config/pon/w1-qrom-implementation-v1.json").read_text())
old_store=(root/"historical-source/ledger-7150d96-store.rs").read_bytes()
assert hashlib.sha256(old_store).hexdigest()==pins["trillionnium/crates/trnm-pon-node/src/store.rs"]
old_main=(root/"historical-source/implementation-cb114b1-main.rs").read_bytes()
main_pin=next(x for x in contract["project_files"] if x["path"].endswith("w1_v2_verifier/src/main.rs"))
assert len(old_main)==main_pin["bytes"] and hashlib.sha256(old_main).hexdigest()==main_pin["sha256"]
def compare(records):
    rows=[]
    for pin in records:
        raw=(source/pin["path"]).read_bytes()
        row={"path":pin["path"],"expected_sha256":pin["sha256"],"current_sha256":hashlib.sha256(raw).hexdigest(),
             "current_bytes":len(raw)}
        if "bytes" in pin:row["expected_bytes"]=pin["bytes"]
        row["matches"]=row["expected_sha256"]==row["current_sha256"] and (pin.get("bytes",len(raw))==len(raw))
        rows.append(row)
    return rows
pin_review={"source_commit":head,"qualification":"HOLD_NO_GO",
            "ledger":{"historical_source_base":literals["SOURCE_BASE"],"current_records":compare([{"path":k,"sha256":v} for k,v in pins.items()])},
            "implementation":{"historical_source_base":contract["source_base_commit"],"contract_path":"config/pon/w1-qrom-implementation-v1.json",
                              "project_records":compare(contract["project_files"]),"helper_records":compare(contract["audit_helpers"]),
                              "saved_binary_and_upstream_snapshot_modified":False,"current_binary_execution_performed":False}}
(root/"pin-drift-observation.json").write_text(json.dumps(pin_review,indent=2)+"\n")
job_rows=[]
for runid in (42515032701,42515032598,42515032608):
    run=json.loads((root/f"run-{runid}.json").read_text())
    assert run["head_sha"]==head and run["run_attempt"]==1 and run["event"]=="pull_request"
    assert run["pull_requests"][0]["number"]==821 and run["pull_requests"][0]["base"]["sha"]==base
    jobs=json.loads((root/f"run-{runid}-jobs.json").read_text())["jobs"]
    assert len(jobs)==2
    for job in jobs:
        raw=(root/f"job-{job['id']}.log").read_bytes()
        log=raw.decode()
        lines=[re.sub(r"^\d{4}-\d\d-\d\dT\S+Z ","",x) for x in log.splitlines()]
        receipts=[]
        for i,line in enumerate(lines):
            if line=="{" and i+1<len(lines) and lines[i+1].startswith('  "base":'):
                tail="\n".join(lines[i:])
                obj,_=json.JSONDecoder().raw_decode(tail)
                if obj.get("schema")=="trnm-ci-source-v1":receipts.append(obj)
        assert len(receipts)==2 and receipts[0]==receipts[1]
        receipt=receipts[0]
        assert receipt["candidate"]==head and receipt["tracked_worktree_verified"] is True
        assert receipt["tested_commit"]==(head if receipt["kind"]=="head" else merge)
        assert receipt["base"]==(None if receipt["kind"]=="head" else base)
        record={"run":runid,"run_url":run["html_url"],"workflow":run["path"],"attempt":1,
                "job_id":job["id"],"job_name":job["name"],"source":receipt,"source_before_after_equal":True,
                "conclusion":job["conclusion"],"failed_steps":[x for x in job["steps"] if x["conclusion"]=="failure"],
                "skipped_steps":[x for x in job["steps"] if x["conclusion"]=="skipped"],
                "unittest_counts_printed":[int(m[1]) for line in lines if (m:=re.match(r"Ran (\d+) tests? in ",line))],
                "log_bytes":len(raw),"log_sha256":hashlib.sha256(raw).hexdigest()}
        job_rows.append(record)
diagnosis={"schema":"trnm-F2-github-failure-diagnosis-v1","reader_login":"ProfHepta","head":head,"base":base,"prospective_merge":merge,
           "event":"pull_request","pr":821,"workflow_reexecuted":False,"primary_modified":False,"jobs":job_rows,
           "classifications":[
               {"run":42515032701,"kind":"historical_selected_source_guard_refusal","first_failure":"store.rs differs from the fixed SOURCE_PINS; LifetimeLedgerTests.setUpClass fails before any of that class executes","completion_guard":"correctly rejects missing named starts; all failure statuses retained"},
               {"run":42515032598,"kind":"historical_implementation_contract_guard_refusal","first_failure":"current w1_v2_verifier/src/main.rs is larger than exact fixed project file size; INPUT_REJECTED","completion_guard":"correctly rejects failed/absent named completion; unknown budget steps remain successful HOLD observations"},
               {"run":42515032608,"kind":"combined_output_ordering_wiring_defect","first_failure":"actual source-integrity 43 tests succeed, followed by buffered expected negative-fixture stdout, so unchanged terminal-OK predicate rejects the log","minimal_fix":"only python3 -u on the source-integrity command; original strict predicate and pipefail retained"}],
           "quantum_or_lifetime_qualification_established":False,"qualification":"HOLD_NO_GO"}
(root/"diagnosis.json").write_text(json.dumps(diagnosis,indent=2)+"\n")
all_files=[]
for path in sorted(root.rglob("*")):
    if path.is_file() and path.name!="artifact-index.json":
        raw=path.read_bytes();all_files.append({"path":str(path.relative_to(root)),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()})
(root/"artifact-index.json").write_text(json.dumps({"schema":"artifact-index-v1","files":all_files},indent=2)+"\n")
print(json.dumps({"jobs":len(job_rows),"source_before_after_equal":all(x["source_before_after_equal"] for x in job_rows),
                  "ledger_changed":[x for x in pin_review["ledger"]["current_records"] if not x["matches"]],
                  "implementation_project_changed":[x for x in pin_review["implementation"]["project_records"] if not x["matches"]],
                  "implementation_helpers_changed":[x for x in pin_review["implementation"]["helper_records"] if not x["matches"]],
                  "files":len(all_files)},indent=2))
