pub const TRNM_W1_FULL_GUEST_V2_ELF: &[u8] = include_bytes!("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/target-w1-host-v2-integration/release/build/trnm-w1-zk-methods-v2-af8f3778ab56933c/out/retained-v2-guest.bin");
pub const TRNM_W1_FULL_GUEST_V2_PATH: &str = "/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/target-w1-host-v2-integration/release/build/trnm-w1-zk-methods-v2-af8f3778ab56933c/out/retained-v2-guest.bin";
pub const TRNM_W1_FULL_GUEST_V2_ID: [u32; 8] = [1958252411, 3287394615, 1805488136, 1516578702, 78549041, 790278610, 301018785, 4279049364];
pub const TRNM_W1_GUEST_BUILD_MODE: &str = "retained-v2-guest";
