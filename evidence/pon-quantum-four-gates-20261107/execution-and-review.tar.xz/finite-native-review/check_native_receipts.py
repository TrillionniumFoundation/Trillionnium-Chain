#!/usr/bin/env python3
"""Read-only source/log/manifest checks supplement the finite arithmetic review."""
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/scratch/c9b48df754d6/validation-four-gates/rog-native-ec3a939')
OUT = Path(__file__).resolve().parent
HEAD = 'ec3a939706592c6ec9dd677b70589a7e8860cdfd'
TREE = '94a2dd1ebda9ce4eb262b6887b739e623616f08a'


def sha(data):
    return hashlib.sha256(data).hexdigest()


manifest_raw = (BASE / 'native-core-manifest.json').read_bytes()
manifest = json.loads(manifest_raw)
assert manifest['source_head'] == HEAD and manifest['pipeline_complete'] is True
rows = []
for relative, expected in manifest['files'].items():
    path = (BASE / relative).resolve()
    assert path.is_relative_to(BASE.resolve())
    raw = path.read_bytes()
    assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256'], relative
    rows.append({'path': relative, **expected})

pipeline = json.loads((BASE / 'bridge-pipeline-result.json').read_text())
fixture = json.loads((BASE / 'native-evidence-ec3a939/native-fixture.json').read_text())
replay = json.loads((BASE / 'native-evidence-ec3a939/native-replay.json').read_text())
assert pipeline['head'] == HEAD and pipeline['complete'] is True and pipeline['binary_unchanged'] is True
assert pipeline['binary_sha256'] == fixture['native_source']['binary_sha256'] == replay['native_source']['binary_sha256']
assert pipeline['quantum_hardware_executed'] is False and pipeline['quantum_mining_qualified'] is False
assert pipeline['host_cpu_context']['exclusive_host_cpu_calibration'] is False
assert pipeline['clock_calibrated_from_cpu'] is False
assert pipeline['retained_full_regression']['failed_tests_remain_failures'] is True
commands = []
for path in sorted((BASE / 'commands').glob('*.json')):
    record = json.loads(path.read_text())
    assert record['exit_code'] == 0 and record['status'] == 'command_succeeded', path.name
    assert record['whole_chain_quantum_security_qualified'] is False
    assert record['before'] == record['after'], path.name
    identity = record['before']
    assert identity['tested_commit'] == HEAD and identity['tested_tree'] == TREE
    assert identity['tracked_worktree_verified'] is True
    log = (path.parent / record['log_file']).read_bytes()
    assert sha(log) == record['log_sha256'] and len(log) == record['log_bytes']
    if path.name in ('native-dag-export.json', 'native-search-replay.json'):
        assert b'test result: ok. 1 passed; 0 failed;' in log
    commands.append({'name': path.name, 'exit_code': 0, 'argv': record['argv'],
                     'source_commit': HEAD, 'source_tree': TREE, 'source_identity_before_after_equal': True,
                     'command_receipt_sha256': sha(path.read_bytes()), 'log_sha256': sha(log)})
assert len(commands) == 6

report = {
    'schema': 'trnm-independent-native-package-receipts-review-v1',
    'result': 'PASS', 'source_commit': HEAD, 'source_tree': TREE,
    'driver_sha256': sha(Path(__file__).read_bytes()),
    'manifest_sha256': sha(manifest_raw), 'manifest_payload_files': len(rows),
    'manifest_payload_bytes': sum(row['bytes'] for row in rows), 'verified_manifest_rows': rows,
    'commands': commands, 'pipeline_binary_sha256': pipeline['binary_sha256'],
    'host_cpu_context': pipeline['host_cpu_context'],
    'separately_retained_whole_node_regression': pipeline['retained_full_regression'],
    'whole_node_regression_claimed_pass_by_this_review': False,
    'separate_native_compile_command_in_core_package': False,
    'scope': 'six named bridge commands and transferred core manifest; exact-source compile/regression receipt remains separate',
    'quantum_hardware_or_whole_network_security_claimed': False,
}
destination = OUT / 'source-receipts-review.json'
with destination.open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'result': 'PASS', 'payload_files': len(rows), 'commands': len(commands),
                  'source_receipts_review_sha256': sha(destination.read_bytes()),
                  'whole_node_regression_claimed_pass': False}, sort_keys=True))
