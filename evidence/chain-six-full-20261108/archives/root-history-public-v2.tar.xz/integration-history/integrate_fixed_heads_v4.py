import subprocess, pathlib, json, hashlib, re, os, sys
root=pathlib.Path("/home/qian-qi/work/chain-six-unified-d9fb-20261108")
out=pathlib.Path("/home/qian-qi/work/chain-six-unified-d9fb-evidence-20261108")
os.chdir(root)
pattern=re.compile(r"(?ms)^<<<<<<<[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n")
inventory="trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs"
plan="docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md"
manifest_name="config/pon/pq-cross-branch-corpus-v1.json"
history=[]
def git(*argv): return subprocess.check_output(["git",*argv],cwd=root,text=True).strip()
def run(argv):
    print("RUN",json.dumps(argv),flush=True)
    subprocess.run(argv,cwd=root,check=True)
def common_conflicts():
    names=git("diff","--name-only","--diff-filter=U").splitlines()
    for name in names:
        if name==inventory: continue
        if name==plan:
            p=root/name;before=p.read_text()
            blocks=list(pattern.finditer(before))
            assert blocks
            def combine(m):
                a,b=m[1],m[2]
                if b.strip() in a:return a
                if a.strip() in b:return b
                return a+"\n"+b
            p.write_text(pattern.sub(combine,before))
            run(["git","add",name])
            history.append({"action":"preserve_both_plan_sections","blocks":len(blocks)})
        elif name==manifest_name:
            a=json.loads(git("show",":2:"+name));b=json.loads(git("show",":3:"+name))
            other=[k for k in set(a)|set(b) if k not in ("pinned_blobs","required_paths") and a.get(k)!=b.get(k)]
            if other:
                print("MANIFEST_SEMANTIC_REVIEW_REQUIRED",other,flush=True);continue
            a["pinned_blobs"]={**b["pinned_blobs"],**a["pinned_blobs"]}
            a["required_paths"]=sorted(set(a["required_paths"])|set(b["required_paths"]))
            (root/name).write_text(json.dumps(a,indent=2,sort_keys=True)+"\n")
            run(["git","add",name])
            history.append({"action":"union_source_corpus_paths","pins":len(a["pinned_blobs"])})
    return [n for n in git("diff","--name-only","--diff-filter=U").splitlines() if n!=inventory]
def refresh(pr):
    run(["python3","scripts/refresh_distributed_source_inventory.py"])
    run(["/home/qian-qi/.cargo/bin/cargo","+1.95.0","fmt","--manifest-path","trillionnium/Cargo.toml","--all"])
    pin_re=re.compile(r'(test "\$\(git hash-object ([A-Za-z0-9_./-]+)\)" = )([0-9a-f]{40})')
    pins=[]
    for p in sorted((root/".github/workflows").glob("*.yml")):
        before=p.read_text()
        def replace(m):
            raw=(root/m[2]).read_bytes()
            new=hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
            if new!=m[3]:pins.append({"workflow":str(p.relative_to(root)),"source":m[2],"before":m[3],"after":new})
            return m[1]+new
        after=pin_re.sub(replace,before)
        if after!=before:p.write_text(after)
    mpath=root/manifest_name
    manifest=json.loads(mpath.read_text())
    for name in manifest["pinned_blobs"]:
        raw=(root/name).read_bytes()
        manifest["pinned_blobs"][name]=hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
    mpath.write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")
    run(["git","add","-u"])
    assert not git("diff","--name-only","--diff-filter=U")
    run(["python3","scripts/refresh_distributed_source_inventory.py","--check"])
    run(["python3","scripts/ci/check_pq_research_integration.py"])
    preliminary=subprocess.run(["git","diff","--cached","--check"],capture_output=True,text=True)
    (out/f"merge-{pr}-whole-diff-before-eof-v4.txt").write_text(preliminary.stdout+preliminary.stderr)
    for line in preliminary.stdout.splitlines():
        m=re.fullmatch(r"(.+):[0-9]+: new blank line at EOF\.",line)
        if m and not m[1].startswith("evidence/") and "/evidence/" not in m[1]:
            p=root/m[1]
            assert p.resolve().is_relative_to(root)
            raw=p.read_bytes()
            p.write_bytes(raw.rstrip(b"\n")+b"\n")
            history.append({"action":"remove_new_active_source_blank_eof","path":m[1]})
    current_manifest=json.loads(mpath.read_text())
    rebound=False
    for name,old_pin in current_manifest["pinned_blobs"].items():
        raw=(root/name).read_bytes()
        new_pin=hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
        if old_pin!=new_pin:
            current_manifest["pinned_blobs"][name]=new_pin
            rebound=True
    if rebound:
        mpath.write_text(json.dumps(current_manifest,indent=2,sort_keys=True)+"\n")
        run(["python3","scripts/ci/check_pq_research_integration.py"])
    run(["git","add","-u"])
    check=subprocess.run(["git","diff","--cached","--check"],capture_output=True,text=True)
    (out/f"merge-{pr}-whole-diff-check-v4.txt").write_text(check.stdout+check.stderr)
    if check.returncode:
        run(["git","diff","--cached","--check","--",".",":(exclude)evidence/**",":(exclude)formal/**/evidence/**"])
    run(["bash","scripts/project-preflight.sh"])
    run(["git","commit","--signoff","-m",f"Integrate fixed capability continuation from PR #{pr}"])
    item={"pr":pr,"commit":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"source_pin_refreshes":pins,"whole_diff_check_exit":check.returncode}
    history.append(item)
    (out/f"merge-{pr}-completed.json").write_text(json.dumps(item,indent=2)+"\n")
    print("MERGED",json.dumps(item),flush=True)
heads=[row for row in json.loads((out/"fixed-original-heads.json").read_text()) if row["pr"]>=807]
run(["bash","scripts/project-preflight.sh"])
assert git("rev-parse","MERGE_HEAD")==heads[0]["head"]
pending=common_conflicts()
if pending: print("MANUAL_CONFLICTS",pending,flush=True);sys.exit(2)
refresh(heads[0]["pr"])
for row in heads[1:]:
    run(["bash","scripts/project-preflight.sh"])
    m=subprocess.run(["git","merge","--no-ff","--no-commit",row["head"]],capture_output=True,text=True)
    (out/f"merge-{row['pr']}-initial.json").write_text(json.dumps({"returncode":m.returncode,"stdout":m.stdout,"stderr":m.stderr},indent=2)+"\n")
    print("MERGE_ATTEMPT",row["pr"],m.returncode,flush=True)
    assert m.returncode in (0,1), m.stderr
    assert git("rev-parse","MERGE_HEAD")==row["head"]
    pending=common_conflicts()
    if pending:
        (out/"current-merge.json").write_text(json.dumps({"pr":row["pr"],"head":row["head"],"conflicts":pending,"completed":history},indent=2)+"\n")
        print("MANUAL_CONFLICTS",row["pr"],pending,flush=True)
        sys.exit(2)
    refresh(row["pr"])
(out/"fixed-heads-merge-complete.json").write_text(json.dumps(history,indent=2)+"\n")
print("ALL_FIXED_HEADS_MERGED",git("rev-parse","HEAD"),flush=True)
