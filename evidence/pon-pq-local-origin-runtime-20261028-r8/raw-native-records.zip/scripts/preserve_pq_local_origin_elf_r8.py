import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import resource
import time

ROOT = Path('/tmp/chain-pq-target-56818e4fba76/debug/deps')
OUT = Path('/workspace/scratch/56818e4fba76/recovery/round8/preserved-native-elf')
NAMES = ['trnm_pon_node-75744e5b33675b38']
FLOOR = 1024 ** 3
records = []
started = time.monotonic()


def digest(path, compressed=False):
    h = hashlib.sha256()
    size = 0
    opener = gzip.open if compressed else open
    with opener(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 ** 2), b''):
            h.update(block)
            size += len(block)
    return size, h.hexdigest()


OUT.mkdir(exist_ok=True)
receipt = OUT / 'pq-local-origin-candidate-elf-receipt.json'
qualification = Path('/workspace/scratch/56818e4fba76/recovery/round8/pq-local-origin-candidate-attempt1/result.json')
q = json.loads(qualification.read_text())
assert q['intent']['source'] == '990aeb651f793ca44bf94b074356be06e58e75c1'
assert q['source_unchanged'] and q['guard']['status'] == 'completed' and not q['guard']['remaining_owned_processes']
assert q['supervisor_returncode'] == 0 and len(q['observations']) == 4
assert all(not o['failures'] for o in q['observations'])
assert not receipt.exists()
try:
    for name in NAMES:
        src = ROOT / name
        before = src.lstat()
        assert stat.S_ISREG(before.st_mode) and not src.is_symlink()
        assert src.resolve().parent == ROOT.resolve()
        with src.open('rb') as stream:
            assert stream.read(4) == b'\x7fELF'
        active = []
        unreadable = 0
        for proc in Path('/proc').iterdir():
            if not proc.name.isdigit():
                continue
            try:
                if os.readlink(proc / 'exe') == str(src):
                    active.append(int(proc.name))
            except (FileNotFoundError, ProcessLookupError):
                pass
            except PermissionError:
                unreadable += 1
        assert not active, active
        assert shutil.disk_usage(ROOT).free > FLOOR + before.st_size
        target = OUT / (name + '-local-origin-990aeb651.gz')
        assert not target.exists()
        raw_identity = digest(src)
        with src.open('rb') as source, target.open('xb') as raw:
            with gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=1, mtime=0) as dest:
                for block in iter(lambda: source.read(1024 ** 2), b''):
                    assert time.monotonic() - started < 180
                    assert shutil.disk_usage(ROOT).free > FLOOR
                    dest.write(block)
            raw.flush()
            os.fsync(raw.fileno())
        recovered_identity = digest(target, compressed=True)
        assert recovered_identity == raw_identity
        after = src.lstat()
        assert (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns)
        item = {'source': str(src), 'source_commit': q['intent']['source'], 'qualification_receipt': str(qualification), 'qualification_sha256': digest(qualification)[1], 'archive': str(target), 'source_bytes': raw_identity[0],
                'source_sha256': raw_identity[1], 'source_mode': before.st_mode,
                'source_allocated': before.st_blocks * 512,
                'archive_bytes': target.stat().st_size, 'archive_sha256': digest(target)[1],
                'decompressed_identity_verified': True, 'active_matching_readable_processes': active,
                'unreadable_proc_exe_count': unreadable,
                'ownership_basis': 'Root-owned named target; root and History/W1 workers report no active native process in this target; no global process-inactivity claim.'}
        records.append(item)
        receipt.write_text(json.dumps({'status': 'verified_before_unlink', 'records': records}, indent=2) + '\n')
        src.unlink()
        item['redundant_source_unlinked'] = True
        item['free_after'] = shutil.disk_usage(ROOT).free
finally:
    receipt.write_text(json.dumps({'status': 'completed' if len(records) == 1 and all(x.get('redundant_source_unlinked') for x in records) else 'incomplete',
                                   'elapsed_seconds': time.monotonic() - started, 'self_cpu_seconds': resource.getrusage(resource.RUSAGE_SELF).ru_utime + resource.getrusage(resource.RUSAGE_SELF).ru_stime, 'self_peak_rss_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                                   'free_after': shutil.disk_usage(ROOT).free,
                                   'records': records}, indent=2) + '\n')
print(receipt.read_text())
