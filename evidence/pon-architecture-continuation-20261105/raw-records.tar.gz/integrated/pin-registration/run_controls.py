import hashlib
import json
import re
import shlex
import subprocess
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/1790ff0f3cc3/chain')
OUT = Path('/workspace/scratch/1790ff0f3cc3/work/integrated/pin-registration')
EXPECTED = '28b379ed75d4503da634ef71fb54ce51edb96d57'
TREE = '7f9d85e33a8ab7f5e3a96dfa2ea9ef47a4d397a9'
PRIOR = 'd992451cc8bfb3d69a1c9f1906bee6732255fad6'
MANIFEST = 'config/pon/pq-cross-branch-corpus-v1.json'
ORIGINAL = Path('/workspace/scratch/1790ff0f3cc3/work/integrated/ci-controls/pq-integration-original-failure.json')


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT, text=True).strip()


def identity():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status_porcelain': git('status', '--porcelain=v1', '--untracked-files=all')}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


initial = identity()
assert initial == {'head': EXPECTED, 'tree': TREE, 'status_porcelain': ''}, initial
assert git('rev-parse', 'HEAD^') == PRIOR
changed_paths = git('diff', '--name-only', PRIOR, EXPECTED).splitlines()
assert changed_paths == [MANIFEST], changed_paths
old_raw = subprocess.check_output(['git', '--no-replace-objects', 'show', PRIOR + ':' + MANIFEST], cwd=ROOT)
new_raw = (ROOT / MANIFEST).read_bytes()
old = json.loads(old_raw)
new = json.loads(new_raw)
expected_diff = [
    {'json_pointer': '/pinned_blobs/scripts~1ci~1ci_job.sh',
     'path': 'scripts/ci/ci_job.sh',
     'old': '818d4b4a6a1af46818d1d069ac84085058d1aed9',
     'new': '5257dd4a05f4222ec02835fed40da8c5c7486b3b'},
    {'json_pointer': '/pinned_blobs/trillionnium~1crates~1trnm-pon-node~1examples~1support~1distributed_source_inventory.rs',
     'path': 'trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs',
     'old': 'cf8b70c0dd8ae7a49a1039e8dfe3412ba3a1b1db',
     'new': 'a35a594685aa3d787b92461895feb9f9ec45f0d9'},
]
replaced = old_raw
for change in expected_diff:
    assert old['pinned_blobs'][change['path']] == change['old']
    assert new['pinned_blobs'][change['path']] == change['new']
    assert git('rev-parse', EXPECTED + ':' + change['path']) == change['new']
    assert replaced.count(change['old'].encode()) == 1
    replaced = replaced.replace(change['old'].encode(), change['new'].encode())
assert replaced == new_raw, 'Commit must contain only two byte replacements'
(OUT / 'exact-two-field.diff').write_text(subprocess.check_output(
    ['git', '--no-replace-objects', 'diff', '--no-ext-diff', '--unified=3', PRIOR, EXPECTED, '--', MANIFEST],
    cwd=ROOT, text=True))
records = []


def run(label, command):
    before = identity()
    assert before == initial, before
    path = OUT / (label + '.log')
    assert not path.exists(), path
    start = time.monotonic()
    with path.open('x') as stream:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
    elapsed = time.monotonic() - start
    after = identity()
    counts = re.findall(r'Ran (\d+) tests? in ', path.read_text())
    record = {'label': label, 'command': command, 'command_text': shlex.join(command),
              'cwd': str(ROOT), 'exit_code': result.returncode, 'wall_seconds': elapsed,
              'source_before': before, 'source_after': after, 'source_unchanged': before == after,
              'reported_unittest_count': int(counts[-1]) if counts else None,
              'log_path': str(path), 'log_sha256': digest(path), 'log_bytes': path.stat().st_size,
              'passed': result.returncode == 0 and before == after}
    (OUT / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    records.append(record)
    print(json.dumps({key: record[key] for key in ('label', 'exit_code', 'reported_unittest_count', 'source_unchanged', 'wall_seconds', 'passed')}), flush=True)
    print('\n'.join(path.read_text().splitlines()[-4:]), flush=True)


run('source-before', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', EXPECTED, '--output', str(OUT / 'source-before-identity.json')])
run('preflight', ['bash', 'scripts/project-preflight.sh', '--audit'])
run('pq-integration', ['python3', '-B', 'scripts/ci/check_pq_research_integration.py'])
run('pq-integration-tests', ['python3', '-B', 'scripts/ci/test_pq_research_integration.py', '-v'])
run('inventory', ['python3', '-B', 'scripts/refresh_distributed_source_inventory.py', '--check'])
run('source-after', ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', EXPECTED, '--output', str(OUT / 'source-after-identity.json')])
final = identity()
source_before = json.loads((OUT / 'source-before-identity.json').read_text())
source_after = json.loads((OUT / 'source-after-identity.json').read_text())
original = json.loads(ORIGINAL.read_text())
summary = {
    'schema': 'trnm-pin-registration-controls-v1',
    'source_commit': EXPECTED, 'source_tree': TREE, 'prior_source_commit': PRIOR,
    'all_checks_passed': all(item['passed'] for item in records) and final == initial and source_before == source_after,
    'source_before': source_before, 'source_after': source_after,
    'initial_git_identity': initial, 'final_git_identity': final,
    'commands': records, 'reported_pq_unit_test_count': next(item['reported_unittest_count'] for item in records if item['label'] == 'pq-integration-tests'),
    'exact_two_field_diff': expected_diff,
    'diff_path': str(OUT / 'exact-two-field.diff'), 'diff_sha256': digest(OUT / 'exact-two-field.diff'),
    'only_changed_tracked_path': MANIFEST, 'only_two_pin_value_byte_replacements': True,
    'original_failure_reference': {'receipt_path': str(ORIGINAL), 'receipt_sha256': digest(ORIGINAL),
        'log_path': original['log_path'], 'log_sha256': original['log_sha256'],
        'source_commit': PRIOR, 'exit_code': original['exit_code'],
        'result': 'HOLD_NO_GO: changed source: scripts/ci/ci_job.sh'},
    'scope': 'Exact source identity, project preflight, PQ research source registration and its negative controls, and generated inventory only; no native or business acceptance.',
    'native_tests_run': False, 'business_acceptance_claimed': False, 'activation_claimed': False,
    'closure_scope': 'HOLD', 'tracked_files_modified_by_controls': False,
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'summary': str(OUT / 'summary.json'), 'all_checks_passed': summary['all_checks_passed'], 'pq_tests': summary['reported_pq_unit_test_count'], 'source_commit': EXPECTED, 'source_tree': TREE}), flush=True)
raise SystemExit(0 if summary['all_checks_passed'] else 1)
