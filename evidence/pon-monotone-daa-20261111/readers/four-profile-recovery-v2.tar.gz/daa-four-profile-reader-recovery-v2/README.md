# Four-profile independent scalar replay: local recovery v2

Actual result: **PASS**. Execution occurred in the local managed `/workspace` runtime.

Frozen implementation: `d23488c5f9b4a6696c3799b12f14b8af0a1b81fc`; tree `72b106b4458299c37da146b0218b8f5276195b6d`. Full source identity was checked before and after execution.

| Schedule | Backend | Full W1 proofs within profile | Methods | Passed | Skipped | Result |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| monotone-daa | pnh1-authenticated | 114 | 26 | 25 | 1 | PASS |
| monotone-daa | pgh2-growth | 114 | 26 | 26 | 0 | PASS |
| joint-daa | pnh1-authenticated | 114 | 22 | 21 | 1 | PASS |
| joint-daa | pgh2-growth | 114 | 22 | 22 | 0 | PASS |

## Input and execution record

The separately retained native archive is `native-run-d23488c5-v1.tar.gz`, 4,657,951 bytes, SHA256 `6c33da56842862608e365acb7c69d72175538556a2a76b74254f7b0357de9c81`. Its full digest, all 36 saved RPC chunks, archive members, and 460 report/packet files were checked locally. The full archive and its duplicate `git show` stdout are intentionally not nested in this reader bundle.

`run/` retains the exact reader JSON, suite stdout/stderr, command argv/environment/exit codes, source-before/after verification records, input-before/after hashes, actual runtime limits, and final result. `outer-execution/` retains the sole local driver launch and its outer exit/logs. The method counts include positive validation methods; these are not all negative tests. Replaying four profiles does not create four independent attack trials.

## Transport recovery record

Two identical remote launch requests timed out; their launch outcome remains UNKNOWN. A create-only, regular-file fence was written and its full hash rechecked at the driver's first exclusive launcher-log path, blocking any late original driver from passing that pre-execution gate. No successful remote reader or resource-scope execution is claimed. The fixed-version RPC transfer saved 36 verified chunks, retained 13 explicit timeouts, and stopped with 8 read-only requests of unknown outcome. The complete archive was subsequently recovered through normal Git fetch and git show from an evidence-only commit. `controller/`, `transfer/`, and `git-recovery/` retain the successful observations and failures.

## Scope

The Python readers independently recompute scalar W1 transcripts and products, lineage, timestamps, retargets, clamping, and cumulative required work. They do not independently authenticate the host, derive runtime namespace identity from source, execute native M06/admission, reopen the native database, or verify AAM1 account proofs. Native behavior has its separate retained native execution record. The old negative-span reader and the new positive-span reader retain separate strict schemas.

Qualification remains HOLD_NO_GO, production/public-network activation is false, and CP/CG/CQ, six-confirmation, and lifetime failure bounds remain unknown (`null`). This replay establishes neither quantum profitability nor a real-time honest-network attack. Local elapsed time and resource limits are execution observations, not physical-cost or security bounds.
