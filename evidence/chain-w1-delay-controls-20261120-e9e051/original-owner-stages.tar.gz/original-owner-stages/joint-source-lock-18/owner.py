from pathlib import Path
import subprocess,json,hashlib,resource,time,sys,traceback,copy
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'joint-source-lock-18';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);arg=json.loads(sys.argv[2]);res={'schema':'chain-joint-current-source-lock-reviewed-map-v1','head':'e8b0ec93ab6a6a1ff5e36cfcf9d1179e030a5975','complete':False,'commands':[]};start=time.monotonic()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,cmd):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(cmd,cwd=src,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);r={'name':name,'argv':cmd,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['commands'].append(r);save();print(json.dumps(r),flush=True);return rc
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()==res['head']
 assert subprocess.check_output(['git','diff','HEAD'],cwd=src)==b''
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 paths={'manifest':'config/pon/joint-consensus-qualification-v1.json','reader':'formal/pon-nakamoto-v1/joint_consensus_qualification.py','test':'formal/pon-nakamoto-v1/test_joint_consensus_qualification.py'}
 originals={}
 for key,name in paths.items():
  raw=(src/name).read_bytes();assert sha(raw)==arg[key+'_sha'];originals[key]=raw;(out/('original-'+Path(name).name)).write_bytes(raw)
 assert run('original-reader',['python3',paths['reader'],'--check'])==2
 data=json.loads(originals['manifest']);pins=data['source_sha256'];old_map=sha(json.dumps(pins,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode());assert old_map=='c054bb9b2f0c5ec695c8e999799d3df86dde068681a14eb52e2033fb4f4dda0e'
 old='9d79fd3c37db4a664d0a01b89e943276e07d2800cc64cb4986a1452ccf8fb820';new='cb063dff4cde5d2f0c60f123cd91cc4e7041964c790a05c1e2e75de6b88b2ec9';target='trillionnium/crates/trnm-pon-node/src/store.rs';audit=[]
 for name,expected in sorted(pins.items()):
  raw=(src/name).read_bytes();git_raw=subprocess.check_output(['git','show',res['head']+':'+name],cwd=src);assert raw==git_raw
  observed=sha(raw);audit.append({'path':name,'bytes':len(raw),'manifest_sha256':expected,'observed_sha256':observed,'identical_to_frozen_head':True})
  assert observed==(new if name==target else expected),name
 assert len(audit)==23 and pins[target]==old
 (out/'all-23-current-source-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
 updated=copy.deepcopy(data);updated['source_sha256'][target]=new
 assert {k:v for k,v in updated.items() if k!='source_sha256'}=={k:v for k,v in data.items() if k!='source_sha256'}
 new_map=sha(json.dumps(updated['source_sha256'],sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode())
 text=originals['manifest'].decode();assert text.count(old)==1;text=text.replace(old,new);assert json.loads(text)==updated;(src/paths['manifest']).write_text(text)
 text=originals['reader'].decode();assert text.count(old_map)==1;text=text.replace(old_map,new_map);(src/paths['reader']).write_text(text)
 test=originals['test'].decode();marker='    def test_prior_or_unknown_source_revision_is_refused(self):\n';assert test.count(marker)==1
 negative='    def test_prior_store_digest_cannot_reinstall_the_old_current_map(self):\n        data = deepcopy(self.original)\n        data["source_sha256"]["trillionnium/crates/trnm-pon-node/src/store.rs"] = (\n            "'+old+'"\n        )\n        self.reject(data, "REVIEWED_SOURCE_MAP")\n\n'
 (src/paths['test']).write_text(test.replace(marker,negative+marker))
 patch=subprocess.check_output(['git','diff','--',*paths.values()],cwd=src);(out/'source.patch').write_bytes(patch)
 res.update(old_map_sha256=old_map,new_map_sha256=new_map,only_changed_source_pin=target,current_source_sha256=new,source_paths_unchanged=23,historical_anchor_unchanged=data['reviewed_native_source_commit'],qualification_unchanged=data['qualification'],production_source_modified=False,patch_bytes=len(patch),patch_sha256=sha(patch));save()
 assert run('current-reader',['python3',paths['reader'],'--check'])==0
 assert run('original-and-old-map-negative-controls',['python3',paths['test'],'-v'])==0
 assert run('qualification-remains-refused',['python3',paths['reader'],'--require-qualified'])==3
 assert run('diff-check',['git','diff','--check'])==0
 res.update(complete=True,wall_seconds=time.monotonic()-start);save();print(json.dumps(res,indent=2),flush=True)
except BaseException as e:res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
