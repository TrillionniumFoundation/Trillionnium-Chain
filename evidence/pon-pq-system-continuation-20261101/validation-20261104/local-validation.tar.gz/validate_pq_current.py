#!/usr/bin/env python3
"""Temporary command runner for the fixed composed candidate; no gate overrides."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/f4aa9e32ef1c')
REPO = BASE / 'chain-pq'
OUT = BASE / 'pq-validation'
OUT.mkdir(exist_ok=True)
RUNTIME = Path('/workspace/scratch/76b6e0e6eb14/round4-runtime')
ENV = os.environ.copy()
ENV.update(CARGO_HOME=str(RUNTIME / 'cargo'), RUSTUP_HOME=str(RUNTIME / 'rustup'),
           CARGO_TARGET_DIR=str(BASE / 'pq-target'), CARGO_BUILD_JOBS='2',
           PYTHONDONTWRITEBYTECODE='1')
ENV['PATH'] = str(RUNTIME / 'cargo/bin') + ':' + ENV['PATH']
for line in (RUNTIME / 'provider.env').read_text().splitlines():
    key, value = line.split('=', 1)
    ENV[key] = value
assert not any(key.startswith('CARGO_PROFILE_') or key in
               ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER') for key in ENV)
EXPECTED = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
TREE = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True).strip()


def run(label, command, timeout=1800):
    stdout = OUT / (label + '.stdout')
    stderr = OUT / (label + '.stderr')
    receipt = OUT / (label + '.json')
    assert not any(path.exists() for path in (stdout, stderr, receipt)), label
    started = time.monotonic()
    with stdout.open('wb') as out, stderr.open('wb') as err:
        try:
            result = subprocess.run(command, cwd=REPO, env=ENV, stdout=out, stderr=err, timeout=timeout)
            code, expired = result.returncode, False
        except subprocess.TimeoutExpired:
            code, expired = None, True
    value = dict(source_commit=EXPECTED, source_tree=TREE, command=command,
                 exit_code=code, timeout=expired, elapsed_seconds=time.monotonic()-started,
                 whole_chain_qualified=False, native_acceptance_inferred=False)
    for stream in (stdout, stderr):
        raw = stream.read_bytes()
        value[stream.suffix[1:]] = dict(path=stream.name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    receipt.write_text(json.dumps(value, indent=2)+'\n')
    print(json.dumps(dict(label=label, exit_code=code, timeout=expired, elapsed_seconds=value['elapsed_seconds'])), flush=True)
    return code == 0 and not expired


phase = sys.argv[1]
source = ['python3', '-B', 'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', EXPECTED]
assert run(phase+'-source-before', source)
cargo = [str(RUNTIME/'cargo/bin/cargo'), '+1.95.0']
commands = []
if phase == 'checks':
    commands = [
        ('preflight', ['bash', 'scripts/project-preflight.sh']),
        ('fmt', cargo+['fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check']),
        ('verifier-fmt', cargo+['fmt','--manifest-path','formal/pon-nakamoto-v1/w1_hardened_verifier/Cargo.toml','--','--check']),
        ('source-integrity', ['python3','-B','-m','unittest','discover','-s','scripts/ci','-p','test_ci_source_integrity.py','-v']),
        ('pq-source-integrity', ['python3','-B','-m','unittest','discover','-s','scripts/ci','-p','test_pq_research_integration.py','-v']),
        ('claim-guard-controls', ['python3','-B','scripts/ci/test_pq_chain_claim_guard.py','-v']),
        ('pq-provider-controls', ['python3','-B','scripts/ci/test_pq_provider_ci.py','-v']),
        ('pins', ['python3','-B','scripts/ci/check_pq_research_integration.py']),
        ('claim-guard', ['python3','-B','scripts/ci/pq_chain_claim_guard.py']),
        ('ci-contract', ['python3','-B','scripts/ci/check_ci_contract.py']),
        ('repository-links', ['python3','-B','scripts/ci/check_repository.py']),
        ('inventory', ['python3','-B','scripts/refresh_distributed_source_inventory.py','--check']),
    ]
elif phase == 'lint':
    commands = [('workspace-clippy', cargo+['clippy','--offline','--locked','--manifest-path','trillionnium/Cargo.toml','--workspace','--all-targets','--all-features','--','-D','warnings'])]
elif phase == 'graphs':
    for name,manifest,target in [('workspace-x64','trillionnium/Cargo.toml','x86_64-unknown-linux-gnu'),('workspace-arm','trillionnium/Cargo.toml','aarch64-unknown-linux-gnu'),('fuzz-x64','tests/fuzz/Cargo.toml','x86_64-unknown-linux-gnu')]:
        commands.append((name,cargo+['metadata','--offline','--locked','--manifest-path',manifest,'--filter-platform',target,'--all-features','--format-version','1']))
else:
    raise SystemExit('unknown phase')
results = [run(phase+'-'+label, command) for label, command in commands]
results.append(run(phase+'-source-after',source))
raise SystemExit(0 if all(results) else 1)
