#!/usr/bin/env python3
"""Observe frozen-B CI suites; full physical source guards are owned by root."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys

ROOT = Path('/workspace/scratch/e4648d82092d/chain')
OUTPUT = Path(__file__).resolve().parent
EXPECTED = '523a4f431b65f8a52128962f5880c4030e3e05db'
TREE = '51b57df779e46bb16518c5c6c7aef90e48faa06d'
SOURCE_BEFORE = Path('/workspace/scratch/e4648d82092d/verification/committed-b/source-before.json')
SOURCE_BEFORE_SHA256 = '68b23e7425686170f9190f09949809ec34650f4ad2025a1d47ea1062b26c6043'
SUITES = ('test_ci_contract.py', 'test_pq_research_integration.py', 'test_ci_source_integrity.py')
sys.path.insert(0, str(ROOT / 'scripts/ci'))
from ci_observation import run


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_new(path, value):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def identity():
    def git(*args):
        return subprocess.check_output(['/usr/bin/git', '--no-replace-objects', *args],
                                       cwd=ROOT, text=True, timeout=30).strip()
    head, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
    changes = git('diff-index', '--cached', '--name-status', EXPECTED, '--')
    stage = subprocess.check_output(['/usr/bin/git', '--no-replace-objects', 'ls-files', '--stage', '-z'],
                                    cwd=ROOT, timeout=30)
    return {'head': head, 'tree': tree, 'index_changes_from_frozen_commit': changes,
            'index_stage_entries_sha256': hashlib.sha256(stage).hexdigest(),
            'head_and_index_match_frozen_commit': head == EXPECTED and tree == TREE and not changes,
            'physical_worktree_checked_by_this_identity_read': False}


def unittest_summary(text):
    summaries = list(re.finditer(r'^Ran (\d+) tests? in ([0-9.]+)s$', text, re.MULTILINE))
    if not summaries:
        return {'summary_observed': False, 'tests_run': None, 'failures': None,
                'errors': None, 'skipped': None, 'reported_seconds': None}
    match = summaries[-1]
    terminal = text[match.end():].strip().splitlines()[0]
    values = {key: int(value) for key, value in
              re.findall(r'(failures|errors|skipped|expected failures|unexpected successes)=(\d+)', terminal)}
    return {'summary_observed': True, 'tests_run': int(match.group(1)),
            'reported_seconds': match.group(2), 'terminal_summary': terminal,
            'failures': values.get('failures', 0), 'errors': values.get('errors', 0),
            'skipped': values.get('skipped', 0),
            'expected_failures': values.get('expected failures', 0),
            'unexpected_successes': values.get('unexpected successes', 0),
            'nested_summaries_not_added_to_count': True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--suite', required=True, choices=SUITES)
    args = parser.parse_args()
    if os.environ.get('PYTHONDONTWRITEBYTECODE') != '1':
        raise ValueError('PYTHONDONTWRITEBYTECODE_1_REQUIRED')
    root_guard = json.loads(SOURCE_BEFORE.read_bytes())
    if (sha256(SOURCE_BEFORE) != SOURCE_BEFORE_SHA256
            or root_guard.get('tested_commit') != EXPECTED
            or root_guard.get('tested_tree') != TREE
            or root_guard.get('tracked_worktree_verified') is not True):
        raise ValueError('ROOT_SOURCE_BEFORE_NOT_MATCHED')
    name = args.suite.removesuffix('.py')
    output = OUTPUT / name
    output.mkdir(exist_ok=False)
    before = identity()
    command = [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'scripts/ci',
               '-p', args.suite, '-v']
    start = {'command': command, 'cwd': str(ROOT), 'source_expected': EXPECTED,
             'tree_expected': TREE, 'started_at_utc': datetime.now(timezone.utc).isoformat(),
             'python_executable': sys.executable, 'python_version': platform.python_version(),
             'platform': platform.platform(), 'PYTHONDONTWRITEBYTECODE': '1',
             'root_whole_source_before_path': str(SOURCE_BEFORE),
             'root_whole_source_before_sha256': SOURCE_BEFORE_SHA256,
             'root_whole_source_before': root_guard, 'head_and_index_before': before,
             'ci_observation_sha256': sha256(ROOT / 'scripts/ci/ci_observation.py'),
             'helper_sha256': sha256(Path(__file__))}
    write_new(output / 'start.json', start)
    if not before['head_and_index_match_frozen_commit']:
        raise ValueError('HEAD_OR_INDEX_CHANGED_BEFORE_COMMAND')
    log = output / 'original.log'
    observation = run(command, log, timeout=1800, env=os.environ.copy(), cwd=ROOT,
                      expected_source=None)
    after = identity()
    record = {'schema': 'local-frozen-b-ci-observation-v1', 'source_expected': EXPECTED,
              'tree_expected': TREE, 'start': start, 'original_observation': observation,
              'head_and_index_after': after,
              'per_command_physical_source_guard_executed': False,
              'physical_source_scope': 'root source-before and later root source-after cover all parallel suites',
              'native_execution_or_performance_measurement': False,
              'log_bytes': log.stat().st_size, 'log_sha256': sha256(log),
              'unittest': unittest_summary(log.read_text(errors='replace')),
              'finished_at_utc': datetime.now(timezone.utc).isoformat()}
    record['command_and_metadata_passed'] = (
        observation['exit_code'] == 0 and after['head_and_index_match_frozen_commit']
        and record['unittest']['summary_observed'] and record['unittest']['tests_run'] > 0
        and record['unittest'].get('terminal_summary', '').startswith('OK'))
    write_new(output / 'observation.json', record)
    print(json.dumps({'suite': args.suite, 'receipt': str(output / 'observation.json'),
                      'exit_code': observation['exit_code'], 'timed_out': observation['timed_out'],
                      'elapsed_ns': observation['elapsed_ns'], 'unittest': record['unittest'],
                      'head_index_stable': after['head_and_index_match_frozen_commit'],
                      'passed': record['command_and_metadata_passed']}, sort_keys=True), flush=True)
    return 0 if record['command_and_metadata_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
