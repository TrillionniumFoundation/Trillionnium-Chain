"""Read-only locked Cargo graph capture for the work/knowledge boundary candidate."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=False)
base = '513e92dfc27044ef3e0c9d62e7ae504fa5bea38f'
summary = {'schema': 'work-knowledge-cargo-graphs-v1', 'comparison_base': base,
           'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
           'cargo': subprocess.check_output(['cargo', '--version'], cwd=root, text=True).strip(),
           'rustc': subprocess.check_output(['rustc', '--version'], cwd=root, text=True).strip(),
           'graphs': {}}
for name, manifest in [('workspace', 'trillionnium/Cargo.toml'), ('fuzz', 'tests/fuzz/Cargo.toml')]:
    lock = str(Path(manifest).with_name('Cargo.lock'))
    before = (root / lock).read_bytes()
    original = subprocess.check_output(['git', 'show', base + ':' + lock], cwd=root)
    if original != before:
        raise ValueError('LOCK_CHANGED_FROM_INTEGRATION_BASE: ' + lock)
    command = ['cargo', 'metadata', '--offline', '--locked', '--all-features',
               '--format-version', '1', '--manifest-path', manifest]
    raw = subprocess.check_output(command, cwd=root)
    parsed = json.loads(raw)
    if (root / lock).read_bytes() != before:
        raise ValueError('LOCK_CHANGED_BY_METADATA: ' + lock)
    (out / (name + '.json')).write_bytes(raw)
    summary['graphs'][name] = {'command': command, 'metadata_sha256': hashlib.sha256(raw).hexdigest(),
        'workspace_members': len(parsed['workspace_members']), 'packages': len(parsed['packages']),
        'resolved_nodes': len(parsed['resolve']['nodes']), 'lock_path': lock,
        'lock_sha256': hashlib.sha256(before).hexdigest(),
        'lock_unchanged_from_integration_base_and_during_capture': True}
if summary['graphs']['workspace']['workspace_members'] != 26:
    raise ValueError('WORKSPACE_GRAPH_COUNT')
if summary['graphs']['fuzz']['workspace_members'] != 1:
    raise ValueError('FUZZ_GRAPH_COUNT')
summary['result'] = 'PASS'
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, sort_keys=True))
