from pathlib import Path
import os,sys,json,time,resource,subprocess,hashlib,re,traceback,shutil
base=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b')
src=base/'resume-20261120-e9e051/source';out=src.parent/'validation-1';out.mkdir(exist_ok=False)
(out/'owner.py').write_text(sys.argv[1])
env=os.environ.copy();env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];env['CARGO_TARGET_DIR']=str(src.parent/'target')
env['RUST_TEST_THREADS']='1';env['TRNM_CI_RECEIPT_DIR']=str(out/'receipts');env['TRNM_PUBLIC_V3_CAMPAIGN_DIR']=str(out/'mixed-service-campaign')
res={'schema':'chain-w1-delay-compile-continuation-v1','source':str(src),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'complete':False,'commands':[],'original_limits_unchanged':True,'original_f0_repeated':False}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args,require_tests=False):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=src,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);log=(out/(name+'.stdout')).read_text(errors='replace')
 r={'name':name,'argv':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime,'libtest_summaries':re.findall(r'test result: .*',log)};res['commands'].append(r);save();print(json.dumps(r),flush=True)
 if rc:print((out/(name+'.stderr')).read_text(errors='replace')[-6000:],flush=True)
 assert rc==0,r
 if require_tests:assert re.search(r'test result: ok\. [1-9][0-9]* passed;',log),r
try:
 run('preflight',['bash','scripts/project-preflight.sh'])
 restored=[]
 for row in subprocess.check_output(['git','ls-files','-s','-z'],cwd=base/'source').split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,expected,stage=meta.decode().split();rel=path.decode();a=base/'source'/rel;b=src/rel
  if not b.exists() and a.is_file():
   data=a.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
   assert actual==expected,(rel,actual,expected)
   b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b);restored.append({'path':rel,'bytes':len(data),'blob':actual})
 (out/'restored-inputs.json').write_text(json.dumps(restored,indent=2)+'\n');print(json.dumps({'restored_exact_inputs':len(restored),'bytes':sum(x['bytes'] for x in restored)}),flush=True)
 diff=subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src);(out/'source.patch').write_bytes(diff);res['source_diff_sha256']=hashlib.sha256(diff).hexdigest();res['lock_sha256']=hashlib.sha256((src/'trillionnium/Cargo.lock').read_bytes()).hexdigest();save()
 run('fmt',['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'])
 args=['cargo','test','--release','--locked','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node']
 for name,selector in [('w1-rejection','ingress::public_v3::work_rejection::tests::'),('body-refusal','ingress::public_v3::body_refusal::tests::'),('native-root-delay','ingress::public_v3::native_root_delay_tests::')]:
  run(name,args+['--lib',selector,'--','--test-threads=1','--nocapture'],True)
 run('original-mixed-130',args+['--test','public_v3_service_campaign','public_v3_mixed_calls_reopen_with_complete_failure_denominators','--','--exact','--test-threads=1','--nocapture'],True)
 p=out/'mixed-service-campaign/report.json';raw=p.read_bytes();report=json.loads(raw)
 res['mixed_report']={'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'attempts':len(report['attempts']),'finite_target_met':report['finite_target_met'],'gap_ns':report['honest_probe_max_gap_including_restart_ns']}
 assert res['lock_sha256']==hashlib.sha256((src/'trillionnium/Cargo.lock').read_bytes()).hexdigest()
 res['complete']=True;save();print(json.dumps(res['mixed_report']),flush=True)
except BaseException as e:
 res['error']=repr(e);res['complete']=True;save();(out/'owner.error').write_text(traceback.format_exc());raise
