"""Record exact final graph and static-analysis checks without native execution."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path('/workspace/scratch/a6448796d7e7/chain-pq')
OUT = Path('/workspace/scratch/a6448796d7e7/validation-276a1e26/supplement')
HEAD = '276a1e26f1989aef4b3d75263ff5b55e073b46e9'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
OUT.mkdir(parents=True, exist_ok=False)
commands = [
    ('standalone-locked-graph', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1',
     '--manifest-path', 'evidence/pon-w1-work-security-20261101/matching-direct-deps/harness/crypto/Cargo.toml']),
    ('workspace-all-features-graph', ['cargo', 'metadata', '--locked', '--offline', '--format-version', '1',
     '--manifest-path', 'trillionnium/Cargo.toml', '--all-features']),
    ('strict-clippy', ['cargo', 'clippy', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml',
     '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings']),
]
rows = []
for label, command in commands:
    print(json.dumps({'label': label, 'status': 'started'}), flush=True)
    argv = [sys.executable, '-B', 'scripts/ci/record_pq_native_command.py', '--kind', 'head',
            '--candidate', HEAD, '--tested', HEAD, '--label', label, '--output', str(OUT),
            '--', 'timeout', '1500', *command]
    with (OUT / (label + '.recorder.log')).open('x') as stream:
        code = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT).returncode
    receipt = OUT / (label + '.json')
    result = json.loads(receipt.read_text()) if receipt.exists() else {}
    row = {'label': label, 'command': command, 'recorder_exit': code,
           'command_exit': result.get('exit_code'), 'status': result.get('status'),
           'receipt_sha256': hashlib.sha256(receipt.read_bytes()).hexdigest() if receipt.exists() else None,
           'native_tests_executed': False}
    rows.append(row)
    print(json.dumps(row), flush=True)
value = {'schema': 'trnm-final-source-static-supplement-v1', 'head': HEAD,
         'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip(),
         'commands': rows, 'native_tests_executed': False,
         'all_commands_succeeded': all(r['recorder_exit'] == 0 and r['command_exit'] == 0
                                       and r['status'] == 'command_succeeded' for r in rows)}
(OUT / 'result.json').write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
sys.exit(0 if value['all_commands_succeeded'] else 1)
