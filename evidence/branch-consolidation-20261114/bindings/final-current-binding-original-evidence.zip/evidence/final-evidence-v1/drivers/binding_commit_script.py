from pathlib import Path
import ast,hashlib,json,os,subprocess,time
root=Path('/private/tmp/chain-final-current-bindings-20261114')
ev=Path('/private/tmp/chain-final-current-bindings-evidence-20261114')
out=ev/'commit-v1';out.mkdir()
(out/'pid.json').write_text(json.dumps({'pid':os.getpid(),'started':time.time()})+'\n')
env={**os.environ,'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','GIT_NO_LAZY_FETCH':'1','PYTHONDONTWRITEBYTECODE':'1','GIT_PAGER':'cat','PAGER':'cat'}
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-c','core.commitGraph=false','-c','gc.auto=0',*args],cwd=root,env=env)
base='5c04c60e463462d9df8884786e0d5bb32af08a64'
assert git('rev-parse','HEAD').decode().strip()==base
summary=json.loads((ev/'final-gates-v1/summary.json').read_bytes());assert summary['all_gates_passed']
paths=[x['path'] for x in summary['paths']]
assert git('diff','--name-only').decode().splitlines()==paths and len(paths)==34
assert git('diff','--cached','--name-only')==b''
for row in summary['paths']:
    assert sha((root/row['path']).read_bytes())==row['after_sha256'],row['path']
with (out/'preflight.stdout').open('xb') as so,(out/'preflight.stderr').open('xb') as se:
    assert subprocess.run(['bash','scripts/project-preflight.sh'],cwd=root,env=env,stdout=so,stderr=se).returncode==0
message="""Bind consolidated current sources while preserving historical proofs

Rebind authority44, current lifetime20, the six-crate QROM145 inventory and
root-dependency46 to reviewed source 5c04c60e. Keep original historical source
pins, proof assets, unknown obligations, caps and withdrawn-profile refusal.

Synchronize paired profile/route consumers and exact current named rosters.
Require the independent four-path drift set and ordering. Record only the
two reviewed current lock provenance changes in an explicit correspondence
namespace while freezing both preceding report bytes.

Route retained workflow controls to the actual historical named runner or
current supplemental/status consumer, preserving all original methods and
negative-control goals. No Rust source or activation qualification changes.
"""
(out/'commit-message.txt').write_text(message)
git('add','--',*paths)
assert git('diff','--cached','--name-only').decode().splitlines()==paths
with (out/'commit.stdout').open('xb') as so,(out/'commit.stderr').open('xb') as se:
    r=subprocess.run(['git','--no-replace-objects','-c','core.commitGraph=false','-c','gc.auto=0','commit','-F',str(out/'commit-message.txt')],cwd=root,env=env,stdout=so,stderr=se,check=False)
assert r.returncode==0,r.returncode
commit=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
assert git('rev-parse','HEAD^').decode().strip()==base
assert git('status','--porcelain')==b''
actual=git('diff-tree','--no-commit-id','--name-only','-r',commit).decode().splitlines()
assert actual==paths
for row in summary['paths']:
    assert sha(git('show',commit+':'+row['path']))==row['after_sha256'],row['path']
patch=git('show','--format=fuller','--binary','--full-index',commit)
(out/'commit.patch').write_bytes(patch)
result={'commit':commit,'tree':tree,'parent':base,'branch':git('branch','--show-current').decode().strip(),'worktree':str(root),'common_git_directory':git('rev-parse','--git-common-dir').decode().strip(),'clean':True,'changed_paths':paths,'files':summary['paths'],'patch':{'path':str(out/'commit.patch'),'bytes':len(patch),'sha256':sha(patch)},'source_scope':{'authority':44,'current_lifetime':20,'qrom_local_crates':6,'qrom_closure_inputs':145,'root_dependency':46,'distinct_input_union':232},'rust_source_changed':False,'historical_report_and_job_bytes_preserved':True,'qualification_escalation':False,'root_merge_note':{'root_parent':'51c215b45c41180fc044ec806fde39c7ceffb75c','preserve_corpus_pin_path':'scripts/ci/test_ci_contract.py','preserve_corpus_pin':'8683f6b319cb6104bf7dc201e3b363c648901468'},'raw_evidence_package_pending':True}
(out/'commit-summary.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('files','changed_paths')},indent=2),flush=True)
print(json.dumps({'commit_summary_bytes':(out/'commit-summary.json').stat().st_size,'commit_summary_sha256':sha((out/'commit-summary.json').read_bytes())}),flush=True)
