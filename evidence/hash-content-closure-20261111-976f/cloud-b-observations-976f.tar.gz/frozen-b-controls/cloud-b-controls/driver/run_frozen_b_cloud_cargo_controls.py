#!/usr/bin/env python3
"""Run read-only frozen-B gates through the unmodified repository recorder."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import subprocess
import threading

ROOT = Path('/workspace/scratch/976f20cefa32/chain-hash')
OUT = Path('/workspace/scratch/976f20cefa32/validation/frozen-b-controls-cloud-cargo')
SOURCE = '9fd6ee29a7a663cef547040d9d42cc36a371a17e'
TREE = '7351f83fa9ac5c0e7540fa64bce06ea6f328602f'
RECORDER = 'scripts/ci/record_pq_native_command.py'
PYTHON = 'python3'
GATES = [
    ('b-vectors', [PYTHON, 'scripts/ci/check_content_commitment_vectors.py']),
    ('b-graph-vectors', [PYTHON, 'scripts/ci/check_cell_content_graph_vectors_v3.py']),
    ('b-hash-purpose-controls', [PYTHON, 'scripts/ci/test_hash_use_contract.py']),
    ('b-hash-purpose-source', [PYTHON, 'scripts/ci/hash_use_contract.py']),
    ('b-authority-controls', [PYTHON, 'scripts/ci/test_pq_authority_effect_register.py']),
    ('b-authority-source', [PYTHON, 'scripts/ci/pq_authority_effect_register.py']),
    ('b-root-dependency-source', [PYTHON, 'scripts/ci/pq_root_dependency_register.py']),
    ('b-current-qrom-source', [PYTHON, 'scripts/w1_qrom_current_implementation_audit.py']),
    ('b-corpus-source', [PYTHON, 'scripts/ci/check_pq_research_integration.py']),
    ('b-corpus-controls', [PYTHON, 'scripts/ci/test_pq_research_integration.py']),
    ('b-source-controls', [PYTHON, 'scripts/ci/test_ci_source_integrity.py']),
    ('b-recorder-controls', [PYTHON, 'scripts/ci/test_record_pq_native_command.py']),
    ('b-repository', [PYTHON, 'scripts/ci/check_repository.py']),
    ('b-ci-contract-source', [PYTHON, 'scripts/ci/check_ci_contract.py']),
    ('b-ci-contract-controls', [PYTHON, 'scripts/ci/test_ci_contract.py']),
    ('b-inventory', [PYTHON, 'scripts/refresh_distributed_source_inventory.py', '--check']),
    ('b-format', ['cargo', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check']),
    ('b-workspace-metadata', ['cargo', 'metadata', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml', '--format-version', '1']),
    ('b-workspace-all-features-metadata', ['cargo', 'metadata', '--locked', '--offline', '--all-features', '--manifest-path', 'trillionnium/Cargo.toml', '--format-version', '1']),
    ('b-fuzz-metadata', ['cargo', 'metadata', '--locked', '--offline', '--manifest-path', 'tests/fuzz/Cargo.toml', '--format-version', '1']),
    ('b-rustc-version', ['rustc', '-Vv']),
]

STOP = threading.Event()
LOCK = threading.Lock()


def emit(value):
    with LOCK:
        print(json.dumps(value, sort_keys=True), flush=True)


def log_summary(label, payload):
    content = payload.decode('utf-8', errors='replace')
    result = {}
    matches = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s\s*$', content, re.MULTILINE)
    if matches:
        result['unittest_runs'] = [dict(tests=int(count), seconds=float(seconds))
                                   for count, seconds in matches]
        result['unittest_terminal_lines'] = [line for line in content.splitlines()
                                             if line == 'OK' or line.startswith('FAILED (')
                                             or line.startswith('OK (')]
    try:
        parsed = json.loads(content)
    except ValueError:
        parsed = None
    if isinstance(parsed, dict):
        if label.endswith('metadata'):
            result['metadata_counts'] = {
                'packages': len(parsed.get('packages', [])),
                'workspace_members': len(parsed.get('workspace_members', [])),
                'resolve_nodes': len((parsed.get('resolve') or {}).get('nodes', [])),
            }
        elif len(payload) <= 65536:
            result['payload_json'] = parsed
        else:
            result['payload_json_keys'] = sorted(parsed)
    if label.endswith('rustc-version'):
        result['version'] = content.strip()
    return result


def one(entry):
    label, command = entry
    if STOP.is_set():
        return {'label': label, 'status': 'NOT_STARTED', 'reason': 'earlier recorder/source failure'}
    if shutil.disk_usage(OUT).free < 64 * 1024 * 1024:
        STOP.set()
        return {'label': label, 'status': 'NOT_STARTED', 'reason': 'less than 64 MiB free'}
    env = dict(os.environ)
    env.update(RUSTUP_HOME='/workspace/scratch/976f20cefa32/toolchain/rustup', CARGO_HOME='/workspace/scratch/976f20cefa32/toolchain/cargo',
               RUSTUP_TOOLCHAIN='1.95.0', CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
               CARGO_TARGET_DIR='/workspace/scratch/976f20cefa32/target')
    env['PATH'] = env['CARGO_HOME'] + '/bin:' + os.environ['PATH']
    argv = [PYTHON, RECORDER, '--kind', 'head', '--candidate', SOURCE,
            '--tested', SOURCE, '--label', label, '--output', str(OUT), '--', *command]
    started = datetime.now(timezone.utc).isoformat()
    emit({'label': label, 'status': 'STARTING', 'started_utc': started})
    driver_log = OUT / (label + '.driver.log')
    with driver_log.open('xb') as stream:
        execution = subprocess.run(argv, cwd=ROOT, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, check=False)
    receipt_file = OUT / (label + '.json')
    receipt = json.loads(receipt_file.read_text()) if receipt_file.is_file() else {}
    record = {'label': label, 'driver_exit': execution.returncode,
              'command_exit': receipt.get('exit_code'), 'status': receipt.get('status', 'NO_RECEIPT'),
              'receipt': str(receipt_file), 'started_utc': started,
              'finished_utc': datetime.now(timezone.utc).isoformat()}
    if record['status'] in ('command_succeeded', 'command_failed'):
        before = receipt.get('before') or {}
        after = receipt.get('after') or {}
        payload = (OUT / receipt['log_file']).read_bytes()
        verified = (before == after and before.get('tested_commit') == SOURCE
                    and before.get('tested_tree') == TREE
                    and before.get('tracked_worktree_verified') is True
                    and len(payload) == receipt.get('log_bytes')
                    and hashlib.sha256(payload).hexdigest() == receipt.get('log_sha256'))
        record['independent_receipt_check'] = verified
        record['log_bytes'] = len(payload)
        record['tracked_entries'] = before.get('tracked_entries')
        record['tracked_bytes'] = before.get('tracked_bytes')
        record.update(log_summary(label, payload))
        if not verified:
            STOP.set()
            record['driver_verification_error'] = 'source or log binding mismatch'
        if record['status'] == 'command_failed':
            record['failure_tail'] = payload.decode('utf-8', errors='replace')[-4000:]
    else:
        STOP.set()
        record['error'] = receipt.get('error')
        record['driver_tail'] = driver_log.read_text(errors='replace')[-4000:]
    compact = {key: value for key, value in record.items()
               if key not in ('payload_json', 'version')}
    emit(compact)
    return record


if __name__ == '__main__':
    preflight_file = Path('/workspace/scratch/976f20cefa32/validation/frozen-b-controls/b-preflight.json')
    preflight = json.loads(preflight_file.read_text())
    assert preflight['status'] == 'command_succeeded' and preflight['exit_code'] == 0
    assert preflight['before'] == preflight['after']
    assert preflight['before']['tested_commit'] == SOURCE
    assert preflight['before']['tested_tree'] == TREE
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip() == TREE
    OUT.mkdir(mode=0o700, parents=False, exist_ok=False)
    selected = [(label.replace('b-', 'b-cloud-', 1), command) for label, command in GATES[16:]]
    assert len(selected) == 5
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = {pool.submit(one, item): item[0] for item in selected}
        rows = [future.result() for future in as_completed(futures)]
    rows.sort(key=lambda row: row['label'])
    report = {'source': SOURCE, 'tree': TREE, 'host': 'cloud',
              'scope': 'fmt check, locked offline metadata, rustc version only; no build/test/clippy',
              'maximum_parallel_commands': 2, 'minimum_free_before_command_bytes': 64 * 1024 * 1024,
              'cloud_preflight_receipt': str(preflight_file), 'commands': rows,
              'all_commands_succeeded': all(row['status'] == 'command_succeeded'
                   and row.get('independent_receipt_check') is True for row in rows)}
    with (OUT / 'controls-summary.json').open('x') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    emit({'result': 'PASS' if report['all_commands_succeeded'] else 'FAIL',
          'commands': len(rows), 'summary': str(OUT / 'controls-summary.json')})
    raise SystemExit(0 if report['all_commands_succeeded'] else 1)
