"""Produce replayable reduced-fixture preprocessing scopes and source hashes."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    parser.add_argument("--view", choices=("report", "observation"), default="report")
    args = parser.parse_args()
    repo = args.repo.resolve()
    formal = repo / "formal/pon-nakamoto-v1"
    sys.path.insert(0, str(formal))
    from test_w1_preprocessing_reuse import PreprocessingReuseTests, wire_fields
    from w1_preprocessing_reuse import compare_preprocessing
    from w1_quantum_oracle import h_bytes, template_from_spec

    PreprocessingReuseTests.setUpClass()
    observations = []
    for name, left, right, nonce, expected_blocks, same_task in PreprocessingReuseTests.cases:
        # Round-trip the exact inputs that this evidence file retains.
        inputs = {"left_template": left.spec(), "right_template": right.spec(),
                  "left_nonce": 0, "right_nonce": nonce}
        result = compare_preprocessing(template_from_spec(inputs["left_template"]),
                                       template_from_spec(inputs["right_template"]), 0, nonce)
        if (result["matching_fixed_prefix_blocks"] != expected_blocks
                or result["ab_inputs_equal"] != same_task
                or result["task_commitment_input_equal"] != same_task):
            raise AssertionError(name)
        before, after = wire_fields(left, 0), wire_fields(right, nonce)
        observations.append({"case": name, "inputs": inputs, "result": result,
                             "changed_wire_fields": sorted(field for field in before
                                                           if before[field] != after[field])})
    sources = ("w1_preprocessing_reuse.py", "test_w1_preprocessing_reuse.py",
               "w1_quantum_oracle.py", "w1_quantum_restricted_oracle.py",
               "w1_quantum_primitives.py", "reversible_components.py",
               "test_w1_quantum_oracle.py")
    report = {"scope": "eight reduced-fixture changes; no timing or energy measurement",
              "source_sha256": {name: hashlib.sha256((formal / name).read_bytes()).hexdigest()
                                for name in sources},
              "control_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "correction": "parent offset 70; prior mislabeled offset 66 evidence retained separately"}
    if args.view == "observation":
        rows = []
        for row in observations:
            left = template_from_spec(row["inputs"]["left_template"])
            right = template_from_spec(row["inputs"]["right_template"])
            result = row["result"]
            rows.append({"case": row["case"], "left_profile": left.profile,
                         "right_profile": right.profile,
                         "AB_dependencies_equal": result["ab_inputs_equal"],
                         "task_hash_input_equal": result["task_commitment_input_equal"],
                         "reusable_initial_fixed_sha_blocks": result["matching_fixed_prefix_blocks"],
                         "five_block_input_equal": result["fixed_five_block_input_equal"],
                         "challenge_input_equal": result["challenge_input_equal"],
                         "observed_challenge_hash_equal": (result["left_challenge_sha256"]
                                                           == result["expected_challenge_sha256"]),
                         "left_frame_bytes_before_header": len(h_bytes(left.challenge_tag, left.header)) - len(left.header),
                         "right_frame_bytes_before_header": len(h_bytes(right.challenge_tag, right.header)) - len(right.header),
                         "changed_wire_fields": row["changed_wire_fields"]})
        report["cases"] = rows
    else:
        report["observations"] = observations
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
