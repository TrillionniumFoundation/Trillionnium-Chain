import pathlib,subprocess,json,hashlib,tarfile,gzip,io,time,sys,re,os
R=pathlib.Path('/home/qian-qi/chain-stark-challenge-20261109-886f');P=R/'repo';C='858393d9c49e90a9c5ab948b2cfa6bca860c2198';T='3ff56675cee2a4103e8e2d7742e6ec10c9e9a16c';B='85a53d09604a765352102f91a865dcf25ecede38'
def git(*a):return subprocess.check_output(['git',*a],cwd=P).decode().strip()
pre=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=P,capture_output=True);assert pre.returncode==0
assert git('rev-parse','HEAD')==C and git('rev-parse','HEAD^{tree}')==T and not git('status','--porcelain')
J=R/'evidence-publication';J.mkdir(exist_ok=False);(J/'controller.py').write_text(sys.orig_argv[-1]);(J/'preflight-before.stdout.log').write_bytes(pre.stdout);(J/'preflight-before.stderr.log').write_bytes(pre.stderr)
def sha(b):return hashlib.sha256(b).hexdigest()
def js(v):return (json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
V=R/'validation';Q=R/'validation-recovery/provider-3.5.9-v1';N=pathlib.Path('/tmp/p3-sampling-native-20261109-7e8b')
original=json.loads((V/'result.json').read_text());recovery=json.loads((Q/'result.json').read_text());nf=json.loads((N/'result-final.json').read_text())
assert original['commit']==C and original['tree']==T and original['all_commands_passed'] is False
assert [(x['label'],x['exit_code']) for x in original['commands'] if x['exit_code']]==[('cargo-clippy',101)]
assert recovery['exit_code']==0 and recovery['commit']==C and recovery['tree']==T and recovery['source_guard_count']==26181 and recovery['source_guard_bytes']==2502546850
assert all(recovery[k] for k in ['all_tracked_source_bytes_unchanged','clean_after','provider_bytes_unchanged','original_failure_stderr_unchanged'])
assert (Q/'source-before.json').read_bytes()==(Q/'source-after.json').read_bytes()
assert len(json.loads((V/'source-before.json').read_text())['changed_files'])==14
assert nf['exit_code']==0 and nf['all_copied_source_bytes_unchanged_after_run'] and sha((N/'source-manifest.json').read_bytes())==nf['manifest_sha256']
assert re.search(r'test result: ok\. 6 passed; 0 failed; 0 ignored;', (N/'native.stdout.log').read_text())
records={}
for label,folder in [('validation',V),('validation-recovery/provider-3.5.9-v1',Q)]:
 for f in sorted(folder.iterdir()):
  assert f.is_file() and not f.is_symlink();records[label+'/'+f.name]=f.read_bytes()
tests=[]
for label,count in [('field',16),('routes',22),('deep',7),('p3',13),('ci-contract',168),('corpus',58)]:
 s=(V/('test-'+label+'.stderr.log')).read_text();assert re.findall(r'Ran ([0-9]+) tests? in ',s)==[str(count)] and re.search(r'\nOK\s*$',s) and 'skipped=' not in s
 tests.append({'suite':label,'completed_methods':count,'record':'validation/test-'+label+'.stderr.log'})
assert sum(x['completed_methods'] for x in tests)==284
for name in ['source-manifest.json','result.json','result-final.json','native.stdout.log','native.stderr.log','tests/tagged_sha3_sampling.rs']:records['native/'+name]=(N/name).read_bytes()
production=[]
for name in nf['copied_production_inputs_match_original_git_blobs']:
 data=(N/name).read_bytes();path='formal/pon-nakamoto-v1/w1_public_stark_research/'+name
 for rev in [B,C]:assert data==subprocess.check_output(['git','show',rev+':'+path],cwd=P)
 production.append({'path':name,'bytes':len(data),'sha256':sha(data),'git_blob':git('rev-parse',C+':'+path),'matches_commits':[B,C]});records['native/production-sources/'+name]=data
assert len(production)==14
records['assembly/native-production-correspondence.json']=js({'production_inputs':production,'scope':'fourteen copied production inputs, not whole-source native execution or a full proof run','fixture_sha256':sha((N/'tests/tagged_sha3_sampling.rs').read_bytes())})
records['assembly/python-accounting.json']=js({'tested_commit':C,'tested_tree':T,'suites':tests,'python_total':284,'native_adapter_tests_separate':6});records['assembly/controller.py']=sys.orig_argv[-1].encode()
Erel='evidence/pon-w1-conditional-sampling-20261110';E=P/Erel;E.mkdir(parents=True,exist_ok=False);buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for name,data in sorted(records.items()):
  t=tarfile.TarInfo(name);t.size=len(data);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(data))
archive=gzip.compress(buf.getvalue(),mtime=0);(E/'records.tar.gz').write_bytes(archive)
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(records) and len({m.name for m in members})==len(records)
 for m in members:assert m.isfile() and tar.extractfile(m).read()==records[m.name]
qual={'status':'HOLD_NO_GO','full_security_obligations_discharged':0,'quantum_extractor_qualified':False,'complete_fri_or_pcs_soundness_qualified':False,'fiat_shamir_knowledge_soundness_qualified':False,'recursive_composition_qualified':False,'actual_lifetime_failure_bound':None,'whole_chain_pq_qualified':False,'production_activation':False,'consensus_admission':False}
manifest={'schema':'TRNM-W1-CONDITIONAL-SAMPLING-EVIDENCE1','tested_code_commit':C,'tested_code_tree':T,'parent_source_commit':B,'publication_scope':'evidence only, not relabelled as tested code','python_suites':tests,'python_completed_methods':284,'native_adapter_completed_tests':6,'native_scope':'separate original fixture; fourteen production inputs match prior and tested commits; no new full proof execution','source_guard_scopes':{'initial_changed_files':14,'later_complete_tracked_files':26181,'later_complete_tracked_bytes':2502546850},'original_clippy_exit_code':101,'provider_recovery_clippy_exit_code':0,'original_all_commands_passed_retained':False,'archive':{'path':'records.tar.gz','bytes':len(archive),'sha256':sha(archive),'record_count':len(records),'uncompressed_record_bytes':sum(map(len,records.values())),'member_encoding':'regular tar files, no links'},'records':[{'path':n,'bytes':len(d),'sha256':sha(d)} for n,d in sorted(records.items())],'excluded':['ELF and build targets','dependency caches and provider binaries/libraries','private environment or authentication responses','smoke private keys and unrelated host files'],'qualification':qual}
(E/'manifest.json').write_bytes(js(manifest))
(E/'README.md').write_text("""# Conditional W1 DEEP and sampler evidence

Tested code: 858393d9c49e90a9c5ab948b2cfa6bca860c2198.
Tested tree: 3ff56675cee2a4103e8e2d7742e6ec10c9e9a16c.
Prior source: 85a53d09604a765352102f91a865dcf25ecede38.
This later evidence-only publication is not relabelled as the executed code.

The RISC Zero result counts two named algebraic events: the global pole set has
16N elements and its union with the shifted trace-zerofier set has 17N.
The displayed 17N/p^4 probability is exact only under a challenge conditionally
uniform on F_(p^4). It proves neither actual Poseidon2 conditional uniformity,
complete bad-event coverage, accepted trace reachability, forgery probability,
nor a security-bit ceiling.

The P3 result binds actual challenger/FRI archives and the query sampling path.
Tagged SHA3 raw-byte masking is uniform under an ideal independent uniform byte
stream. The retained Goldilocks field mask has a small nonzero bias under its
separate ideal uniform field-stream premise. The 64 draws are with replacement;
a duplicate event is not a false-proof event or a replacement for FRI soundness.

Six Python suites completed 284 methods: field 16, routes 22, DEEP 7, P3 13,
CI contract 168, corpus 58. Every original command, raw stream, report and result
is retained. Prior runs are not added to this denominator. Six native adapter
fixtures passed separately in /tmp/p3-sampling-native-20261109-7e8b. Its fixture,
manifest, results and streams are retained; fourteen copied production inputs
match Git blobs in both named source commits. This is not a new full W1 proof,
recursive execution, whole-source native execution or performance qualification.

The initial guard covers only 14 changed files. The later provider-recovery
guard covers all 26,181 tracked files / 2,502,546,850 bytes before and after
Clippy: bytes and HEAD/tree remained identical and the checkout stayed clean.
Publication-only evidence files were not part of that earlier code checkout.

Default/all-feature Cargo metadata, workspace/P3 formatting and all seven
selected source/report commands passed. Original strict Clippy exited 101
because the selected older OpenSSL headers lacked PKey::private_key_from_seed.
Its raw failure and original all_commands_passed=false remain unchanged.
Separate recovery selected the existing pinned static OpenSSL 3.5.9 installation;
the same workspace/all-targets/all-features/locked/offline Clippy command with
-D warnings passed, exit 0, in 88.96 seconds. Five installed provider inputs match
the historical successful preparation receipt. Provider bytes, source bytes and
the old failure log stayed unchanged. The source archive pin is retained from
that historical receipt; recovery did not freshly retrieve the compressed
archive, rebuild OpenSSL or perform a new provider smoke.

The fifteen historical obligation IDs remain. The earlier pinned manuscript
version-correspondence sub-obligation is distinct from full security obligations:
zero complete security obligations are discharged and all eight implementation
interfaces remain open. Actual FRI/PCS and Fiat-Shamir knowledge soundness,
quantum extraction, compiler refinement, shared-oracle assumptions, recursion,
lifetime composition, independent resource acceptance and production admission
remain unqualified. The lifetime failure bound remains null. All three routes
remain HOLD / NO-GO.

[manifest.json](manifest.json) binds every record and the complete
[records.tar.gz](records.tar.gz) by bytes and SHA256. No ELF, target, dependency
cache, provider binary/library, private key or private environment is included.
No production or consensus authority changes.
""")
cmds=[];env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
def run(label,args):
 start=time.time();p=subprocess.run(args,cwd=P,env=env,capture_output=True,timeout=300);(J/(label+'.stdout.log')).write_bytes(p.stdout);(J/(label+'.stderr.log')).write_bytes(p.stderr)
 row={'label':label,'args':args,'exit_code':p.returncode,'wall_seconds':time.time()-start};cmds.append(row);(J/'commands.json').write_bytes(js(cmds));print(json.dumps(row),flush=True);return p
selected=[Erel+'/'+n for n in ['README.md','manifest.json','records.tar.gz']]
assert run('diff-check-before',['git','diff','--check']).returncode==0
assert run('stage',['git','add','--']+selected).returncode==0
assert git('diff','--cached','--name-only').splitlines()==sorted(selected)
assert run('staged-preflight',['bash','scripts/project-preflight.sh','--staged']).returncode==0
assert run('commit',['git','-c','user.name=Qian QI','-c','user.email=102159240+ProfHepta@users.noreply.github.com','commit','--signoff','-m','Retain exact conditional sampler and provider recovery evidence']).returncode==0
final=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');assert git('rev-parse','HEAD^')==C and git('diff','--name-only',C,final).splitlines()==sorted(selected)
for label,args in [('repository',['python3','scripts/ci/check_repository.py']),('diff-check',['git','diff','--check',C,final]),('preflight',['bash','scripts/project-preflight.sh']),('corpus',['python3','scripts/ci/check_pq_research_integration.py'])]:run('post-'+label,args)
assert git('rev-parse','HEAD')==final and git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain')
bundle=R/'evidence.delta.bundle';assert run('bundle',['git','bundle','create',str(bundle),C+'..'+final]).returncode==0;assert run('bundle-verify',['git','bundle','verify',str(bundle)]).returncode==0
summary={'tested_code_commit':C,'tested_code_tree':T,'evidence_commit':final,'evidence_tree':tree,'evidence_parent':C,'evidence_only_paths':selected,'record_count':len(records),'archive_bytes':len(archive),'archive_sha256':sha(archive),'manifest_sha256':sha((E/'manifest.json').read_bytes()),'bundle_path':str(bundle),'bundle_bytes':bundle.stat().st_size,'bundle_sha256':sha(bundle.read_bytes()),'post_checks':[r for r in cmds if r['label'].startswith('post-')],'all_post_checks_passed':all(r['exit_code']==0 for r in cmds if r['label'].startswith('post-')),'clean_after':True,'qualification':qual}
(J/'result.json').write_bytes(js(summary));print('EVIDENCE_FINAL '+json.dumps(summary),flush=True)
