from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/a638c5cc4765')
ROOT = BASE / 'Trillionnium-Chain'
OUTPUT = BASE / 'owner-extension-final-v2'
assert OUTPUT.is_dir()
environment = dict(os.environ)
environment.update({
    'HIA_TOOLCHAIN_ROOT': '/workspace/scratch/bc089b09ffa5/Hepta-toolchain',
    'HIA_NATIVE_COMPILER': '/workspace/scratch/bc089b09ffa5/hia-bootstrap/native-compiler',
    'HIA_NATIVE_COMPILER_SHA256': '87c247e4d1c3c9a449d2947fd4227fdc186d519bffd203a04cafce7861a4ed54',
    'PATH': '/workspace/scratch/bc089b09ffa5/rust-toolchain/install/bin:' + os.environ['PATH'],
    'LD_LIBRARY_PATH': '/workspace/scratch/bc089b09ffa5/rust-toolchain/install/lib',
    'CARGO_HOME': '/workspace/scratch/bc089b09ffa5/rust-toolchain/cargo-home',
    'HIA_CONTROL_PLANE_SHA2': '/workspace/scratch/bc089b09ffa5/rs46-original-qualification-v2/original/cargo-target/debug/deps/libsha2-fafdf068c84600ef.rlib',
})
rows = [
    ('governance', 'hia.tests.test_governance', 'TRNM_HIA_GOVERNANCE_OUTPUT'),
    ('control-guard', 'hia.tests.test_control_guard', 'HIA_CONTROL_GUARD_OUTPUT'),
    ('peer-lease', 'hia.tests.test_peer_lease', 'HIA_PEER_LEASE_OUTPUT'),
]

def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def run(row):
    label, module, variable = row
    env = dict(environment)
    env[variable] = str(OUTPUT / label)
    if label == 'peer-lease':
        env['HIA_PEER_LEASE_ORIGINAL_BASELINE'] = str(BASE / 'peer-lease-next/work/remote-original-baseline')
    command = [sys.executable, '-B', '-m', 'unittest', module, '-v']
    started = time.monotonic()
    with (OUTPUT / (label + '.stdout.raw')).open('xb') as stdout, (OUTPUT / (label + '.stderr.raw')).open('xb') as stderr:
        process = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, timeout=600, check=False)
    result = {'module': module, 'argv': command, 'cwd': str(ROOT), 'returncode': process.returncode,
        'wall_seconds': time.monotonic() - started, 'stdout': identity(OUTPUT / (label + '.stdout.raw')),
        'stderr': identity(OUTPUT / (label + '.stderr.raw')), 'output': label,
        'original_retained_test_location': 'ROG original retained baseline; local oracle rebuilt from unchanged source' if label == 'peer-lease' else 'local original binary'}
    (OUTPUT / (label + '.execution.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
    return result

result = run(rows[0])
assert result['returncode'] == 0
