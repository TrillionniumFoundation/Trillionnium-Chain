#!/usr/bin/env python3
"""Execute original commands on a clean exact source; retain every attempt."""
import hashlib, json, os, re, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path
repo = Path('/workspace/scratch/ee79b3ed025e/trillionnium-chain')
out = Path('/workspace/scratch/ee79b3ed025e/throughput-20261106-ee79/raw/0bca-local-exact-v1')
head = '0bca28ebf59058b6aba9db5eb956c4479556e9ee'
tests = [
 ('authenticated-roster', 'scripts/ci/test_authenticated_suite_count.py', 11),
 ('ci-contract', 'scripts/ci/test_ci_contract.py', 109),
 ('source-integrity', 'scripts/ci/test_ci_source_integrity.py', 43),
 ('command-recorder', 'scripts/ci/test_record_pq_native_command.py', 4),
 ('cost-coverage', 'scripts/ci/test_throughput_cost_coverage.py', 18),
 ('fixed-host-phase-reader', 'scripts/ci/test_fixed_root_phase_host.py', 19),
 ('native-host-phase-reader', 'scripts/ci/test_native_phase_host.py', 11),
 ('six-native-rosters', 'scripts/ci/test_six_workpackage_native_rosters.py', 6),
 ('runtime-packaging', 'scripts/test_llm_runtime_release.py', 25),
 ('public-v3-phase-reader', 'scripts/ci/test_pon_public_v3_phase_read.py', 57),
 ('public-v3-policy-reader', 'scripts/ci/test_pon_public_v3_policy_read.py', 7),
 ('recent-batch-roster', 'scripts/ci/test_recent_batch_suite_count.py', 4),
 ('pq-corpus-negatives', 'scripts/ci/test_pq_research_integration.py', 38),
 ('applicability', 'scripts/ci/test_applicability.py', 37),
]
plans = [(label, [sys.executable, '-B', script, '-v'], count) for label,script,count in tests]
plans += [
 ('pq-corpus', [sys.executable, '-B', 'scripts/ci/check_pq_research_integration.py'], None),
 ('distributed-inventory', [sys.executable, '-B', 'scripts/refresh_distributed_source_inventory.py', '--check'], None),
 ('repository-and-markdown', [sys.executable, '-B', 'scripts/ci/check_repository.py'], None),
]
assert sum(count for _,_,count in plans if count is not None)==389
out.mkdir(exist_ok=False,parents=True)
report = {'schema':'trnm-local-original-command-batch-v1','source':head,
          'started_utc':datetime.now(timezone.utc).isoformat(), 'status':'running',
          'planned_commands':len(plans), 'planned_python_tests':389,
          'native_execution':False, 'production_qualified':False,
          'executor_loss_previous_raw_reconstructed':False, 'rows':[]}
report_path = out / 'batch.json'

def save():
    report_path.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')

save()
env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR='/tmp')
for label,command,count in plans:
    invocation=[sys.executable,'-B','scripts/ci/record_pq_native_command.py',
                '--kind','head','--candidate',head,'--tested',head,'--label',label,
                '--output',str(out),'--',*command]
    started=time.monotonic_ns()
    result=subprocess.run(invocation,cwd=repo,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=False)
    (out/(label+'.recorder.log')).write_text(result.stdout)
    receipt_path=out/(label+'.json');log_path=out/(label+'.log')
    receipt=json.loads(receipt_path.read_text()) if receipt_path.exists() else {}
    content=log_path.read_text() if log_path.exists() else ''
    observed=[int(n) for n in re.findall(r'^Ran (\d+) tests? in ', content, re.M)]
    passed=result.returncode==0 and receipt.get('status')=='command_succeeded'
    if count is not None:
        passed=passed and observed==[count] and bool(re.search(r'^OK\s*$',content,re.M))
    row={'label':label,'argv':command,'recorder_exit_code':result.returncode,
         'expected_python_tests':count,'observed_test_summaries':observed,
         'passed':passed,'elapsed_ns':time.monotonic_ns()-started,
         'receipt_sha256':hashlib.sha256(receipt_path.read_bytes()).hexdigest() if receipt_path.exists() else None,
         'log_sha256':hashlib.sha256(log_path.read_bytes()).hexdigest() if log_path.exists() else None}
    report['rows'].append(row);save()
    print(json.dumps(row,sort_keys=True),flush=True)
report['finished_utc']=datetime.now(timezone.utc).isoformat()
report['passed_commands']=sum(r['passed'] for r in report['rows'])
report['passed_python_tests']=sum(r['expected_python_tests'] or 0 for r in report['rows'] if r['passed'])
report['status']='passed' if all(r['passed'] for r in report['rows']) else 'failed'
save()
print(json.dumps({'status':report['status'],'passed_commands':report['passed_commands'],'passed_python_tests':report['passed_python_tests']},sort_keys=True),flush=True)
sys.exit(0 if report['status']=='passed' else 1)
