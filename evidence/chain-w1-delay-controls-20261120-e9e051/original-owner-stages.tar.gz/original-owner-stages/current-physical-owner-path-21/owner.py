from pathlib import Path
import sys,json
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'current-physical-owner-path-21';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
specs=[('trillionnium/crates/trnm-pon-node/src/ingress.rs',2615,2735),('trillionnium/crates/trnm-pon-node/src/store.rs',4770,5370),('trillionnium/crates/trnm-pon-node/src/host_kernel_parent.rs',60,412)]
for name,lo,hi in specs:
 lines=(src/name).read_text().splitlines();p=out/(Path(name).name+'.txt');p.write_text('\n'.join(lines[lo-1:hi])+'\n');print(json.dumps({'path':str(p),'start':lo,'end':hi,'bytes':p.stat().st_size}))
