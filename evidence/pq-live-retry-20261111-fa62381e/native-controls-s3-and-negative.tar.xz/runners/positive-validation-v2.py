#!/usr/bin/env python3
"""Temporary default-profile focused validation; not a repository gate change.

Record one fresh Cargo build and one 64-control batch with the existing exact
source recorder. The batch pins and observes the actual built ELF for listing
and every named execution, using existing repository helpers. Each execution
has its own bounded process owner, raw log/hash, actual exit, and named check.
Original hosted PNQ2 52-control membership and budgets remain unchanged.

An optional build barrier records build-ready first and bounds coordination
before any libtest listing or execution. It never grants a PASS or extends
native test deadlines; the original batch source and ELF checks still follow.

Requires the original prepare_pq_provider.sh environment and fresh absolute
outside-source --out and --target paths. No build/profile override is accepted.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time

GROUPS = [
    [
        "account",
        [
            "ingress::account_scope_tests::invalid_account_scope_refuses_classical_session_and_signed_request",
            "ingress::account_scope_tests::current_local_scope_refuses_previously_valid_classical_request",
            "ingress::account_scope_tests::invalid_account_scope_never_connects_or_advances_classical_clients",
            "ingress::account_scope_tests::valid_development_scope_retains_classical_signature_and_socket_path",
            "ingress::account_scope_tests::explicit_pq_selector_retains_classical_route_refusal_precedence"
        ]
    ],
    [
        "witness-new",
        [
            "pq_rollback_witness::tests::live_retry_refuses_changed_durable_predecessor_at_the_same_head",
            "pq_rollback_witness::tests::cold_reopen_refuses_database_retry_history_and_accepts_new_successors"
        ]
    ],
    [
        "witness-retained",
        [
            "pq_rollback_witness::tests::known_checkpoint_preserves_exact_retry_and_unobserved_other_writer_progress",
            "pq_rollback_witness::tests::cold_reopen_requires_exact_independently_retained_checkpoint",
            "pq_rollback_witness::tests::failed_local_commit_fences_owner_until_explicit_reopen"
        ]
    ],
    [
        "m12-recovery",
        [
            "store::async_w1_generation_v2::tests::recovery_v3::lost_or_corrupt_cas_ack_recovers_same_operation_pending_without_redispatch",
            "store::async_w1_generation_v2::tests::recovery_v3::independent_service_reopen_pin_rejects_restored_witness_database",
            "store::async_w1_generation_v2::tests::recovery_v3::local_commit_without_external_commit_remains_quarantined_on_cold_reopen"
        ]
    ],
    [
        "cleanup",
        [
            "store::pq_rollback_witness::combined_tests::guarded_npq6_valid_submit_cleanup_preserves_primary_error_and_child_diagnostics"
        ]
    ]
]
SELECTION = [(f"{group}-{index + 1:02d}", name)
             for group, names in GROUPS for index, name in enumerate(names)]


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def select_controls(root):
    """Freeze the retained52, exact supplemental7, and5 focused extras."""
    original_path = "config/pon/pq-system-required-tests-v1.json"
    supplemental_path = "config/pon/pq-system-supplemental-tests-v1.json"
    original_raw = (root / original_path).read_bytes()
    supplemental_raw = (root / supplemental_path).read_bytes()
    original_sha = hashlib.sha256(original_raw).hexdigest()
    supplemental_sha = hashlib.sha256(supplemental_raw).hexdigest()
    if original_sha != "31960141da6e571eaa373ac6374a956e1458b4eaf5beb622aa11bb145b89f3bc":
        raise ValueError("original retained52 roster bytes changed")
    original, supplemental = json.loads(original_raw), json.loads(supplemental_raw)
    retained = original["tests"]
    added = supplemental["tests"]
    expected_added = [name for group, names in GROUPS if group in ("account", "witness-new")
                      for name in names]
    if (original["schema"] != "trnm-pq-system-required-tests-v1"
            or original["expected_meaningful_controls"] != 52
            or len(retained) != 52 or len(set(retained)) != 52
            or original["whole_chain_quantum_security_qualified"] is not False
            or set(retained) & set(original["child_process_harnesses_not_counted"])):
        raise ValueError("original52 roster contract failed")
    if (supplemental["schema"] != "trnm-pq-system-supplemental-tests-v1"
            or supplemental["scope"] != "account-scope-and-witness-retry-provenance-only"
            or supplemental["retained_roster"] != original_path
            or supplemental["retained_meaningful_controls"] != 52
            or supplemental["expected_meaningful_controls"] != 7
            or len(added) != 7 or len(set(added)) != 7 or set(added) != set(expected_added)
            or supplemental["whole_chain_quantum_security_qualified"] is not False
            or supplemental["original_business_budgets_changed"] is not False
            or set(retained) & set(added)):
        raise ValueError("supplemental7 roster contract failed")
    selected = [(f"pnq2-{i + 1:02d}", name) for i, name in enumerate(retained)]
    selected += [(f"supplemental-{i + 1:02d}", name) for i, name in enumerate(added)]
    seen, extra = set(retained) | set(added), []
    for label, name in SELECTION:
        if name not in seen:
            selected.append((label, name))
            extra.append(name)
            seen.add(name)
    if (len(selected) != 64 or len(seen) != 64 or len(extra) != 5
            or not all(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*",
                                   name) for _, name in selected)):
        raise ValueError("expected64 unique exact native controls")
    provenance = {
        "retained_path": original_path, "retained_sha256": original_sha,
        "supplemental_path": supplemental_path, "supplemental_sha256": supplemental_sha,
        "retained_tests": retained, "supplemental_tests": added, "focused_extra_tests": extra,
        "retained_controls": 52, "supplemental_controls": 7,
        "focused_extra_controls": 5, "unique_controls": 64,
    }
    return selected, provenance


def imports(root):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root / "scripts/ci"))


def verify_runner(expected):
    if digest(Path(__file__).resolve()) != expected:
        raise ValueError("temporary runner digest changed")


def wait_for_build_barrier(path, expected_source, output, timeout):
    """Wait only before libtest dispatch; this release is not a test verdict."""
    record = {
        "status": "WAITING", "positive_source": expected_source,
        "barrier_path": str(path), "timeout_seconds": timeout,
        "native_tests_started": False, "validation_complete": False,
        "timed_out": False, "polls": 0,
        "started_monotonic_ns": time.monotonic_ns(),
    }
    receipt = output / "build-barrier-observation.json"
    write_json(receipt, record)
    deadline = time.monotonic() + timeout
    maximum = 16 * 1024

    def fingerprint(info):
        return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink,
                info.st_size, info.st_mtime_ns, info.st_ctime_ns)

    def unique_keys(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("build barrier JSON has duplicate keys")
            value[key] = item
        return value

    def bad_constant(value):
        raise ValueError("build barrier JSON has non-JSON constant: " + value)

    try:
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                record.update(status="TIMED_OUT", timed_out=True)
                raise TimeoutError("build barrier was not released before its separate deadline")
            record["polls"] += 1
            try:
                info = path.lstat()
            except FileNotFoundError:
                time.sleep(min(0.25, remaining))
                continue
            if not stat.S_ISREG(info.st_mode) or not 0 < info.st_size <= maximum:
                raise ValueError("build barrier must be a bounded regular JSON file")
            descriptor = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW | os.O_NONBLOCK)
            try:
                opened = os.fstat(descriptor)
                if not stat.S_ISREG(opened.st_mode) or fingerprint(opened) != fingerprint(info):
                    raise ValueError("build barrier changed before its descriptor was opened")
                data = os.read(descriptor, maximum + 1)
                if len(data) != opened.st_size or os.read(descriptor, 1):
                    raise ValueError("build barrier file was partial or changed during read")
                after = os.fstat(descriptor)
                named = path.lstat()
                if fingerprint(after) != fingerprint(opened) or fingerprint(named) != fingerprint(opened):
                    raise ValueError("build barrier changed during observation")
            finally:
                os.close(descriptor)
            value = json.loads(data.decode("utf-8"), object_pairs_hook=unique_keys,
                               parse_constant=bad_constant)
            if (type(value) is not dict
                    or value.get("status") != "all-native-builds-complete"
                    or value.get("positive_source") != expected_source):
                raise ValueError("build barrier status or exact positive source is invalid")
            if time.monotonic() >= deadline:
                record.update(status="TIMED_OUT", timed_out=True)
                raise TimeoutError("build barrier read completed after its separate deadline")
            record.update(
                status="RELEASE_OBSERVED", barrier_sha256=hashlib.sha256(data).hexdigest(),
                barrier_bytes=len(data), released_status=value["status"],
                device=opened.st_dev, inode=opened.st_ino,
                barrier_mtime_ns=opened.st_mtime_ns,
            )
            return record
    except (OSError, ValueError) as exc:
        if record["status"] != "TIMED_OUT":
            record["status"] = "REFUSED"
        record["error"] = str(exc)
        raise
    finally:
        record["elapsed_ns"] = time.monotonic_ns() - record["started_monotonic_ns"]
        write_json(receipt, record)


def native_worker(argv):
    root, executable, expected, out_text, runner_pin, *native_args = argv
    root, out = Path(root), Path(out_text)
    verify_runner(runner_pin)
    imports(root)
    from pinned_native_process import run_pinned
    record = {"argv": [executable, *native_args], "status": "running",
              "native_exit_code": None, "native_execution": None,
              "expected_executable_sha256": expected, "runner_sha256": runner_pin}
    receipt, log = out.with_suffix(".native.json"), out.with_suffix(".log")
    with receipt.open("x") as stream:
        json.dump(record, stream)
    exit_code = 1
    started = time.monotonic_ns()
    try:
        with log.open("xb") as stream:
            code, identity = run_pinned(record["argv"], root, stream, expected)
        record.update(native_exit_code=code, native_execution=identity)
        success = code == 0 and identity["status"] == "PINNED_AND_OBSERVED"
        record["status"] = "command_succeeded" if success else "command_failed"
        exit_code = (code if code >= 0 else 128 - code) if code else int(not success)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        record.update(status="record_failed", error=str(exc))
    finally:
        record["elapsed_ns"] = time.monotonic_ns() - started
        if log.exists():
            record.update(log=log.name, log_bytes=log.stat().st_size, log_sha256=digest(log))
        write_json(receipt, record)
    return exit_code


def native_batch(argv):
    root_text, artifact_text, artifact_pin, out_text, runner_pin, timeout_text = argv
    root, artifact_path, output = Path(root_text), Path(artifact_text), Path(out_text)
    timeout = int(timeout_text)
    verify_runner(runner_pin)
    artifact_bytes = artifact_path.read_bytes()
    if hashlib.sha256(artifact_bytes).hexdigest() != artifact_pin:
        raise ValueError("build provenance artifact changed")
    artifact = json.loads(artifact_bytes)
    selection = [tuple(row) for row in artifact["selected_tests"]]
    provenance = artifact["selection_provenance"]
    if len(selection) != 64 or len({name for _, name in selection}) != 64:
        raise ValueError("frozen64-control selection changed")
    if select_controls(root) != (selection, provenance):
        raise ValueError("frozen S2 roster bytes or exact membership changed")
    executable, expected = artifact["executable"], artifact["executable_sha256"]
    imports(root)
    from ci_observation import run as run_observed
    from check_required_native_test import validate
    records = []
    passed = 0

    def run_one(label, native_args, required_name=None):
        prefix = output / label
        worker = [sys.executable, str(Path(__file__).resolve()), "_native_worker",
                  str(root), executable, expected, str(prefix), runner_pin, *native_args]
        owner = run_observed(worker, output / (label + ".owner.log"),
                             cwd=root, timeout=timeout)
        error, execution, validation = None, None, None
        log = prefix.with_suffix(".log")
        try:
            execution = json.loads(prefix.with_suffix(".native.json").read_text())
            if (owner["exit_code"] != 0 or owner["timed_out"]
                    or execution["status"] != "command_succeeded"
                    or execution["native_exit_code"] != 0
                    or execution["native_execution"]["status"] != "PINNED_AND_OBSERVED"):
                raise ValueError("native exit, timeout, or live ELF identity failed")
            if execution["log_sha256"] != digest(log):
                raise ValueError("native transcript digest changed")
            if required_name is not None:
                with log.open() as stream:
                    validation = validate(stream, required_name)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            error = str(exc)
        row = {"label": label, "required_test": required_name, "owner": owner,
               "native_receipt": execution, "named_execution": validation, "error": error}
        if log.exists():
            row.update(log=log.name, log_bytes=log.stat().st_size, log_sha256=digest(log))
        records.append(row)
        write_json(output / "batch-observations.json", records)
        print(json.dumps({"label": label, "owner_exit": owner["exit_code"],
                          "native_exit": execution.get("native_exit_code") if execution else None,
                          "timed_out": owner["timed_out"], "error": error}), flush=True)
        return error is None

    phase_error = None
    try:
        if not run_one("native-list", ["--list", "--format", "pretty"]):
            raise ValueError("pinned native inventory failed")
        listing = (output / "native-list.log").read_text()
        names = Counter(line[:-6] for line in listing.splitlines() if line.endswith(": test"))
        bad = {name: names[name] for _, name in selection if names[name] != 1}
        write_json(output / "named-inventory.json", {
            "required": [name for _, name in selection], "bad_matches": bad,
            "all_required_exactly_once": not bad,
        })
        if bad:
            raise ValueError("missing or duplicate exact native names: " + str(bad))
        for label, name in selection:
            if run_one(label, [name, "--exact", "--show-output", "--test-threads=1",
                               "--format", "pretty"], name):
                passed += 1
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        phase_error = str(exc)
    success = passed == 64 and phase_error is None
    def completed(names):
        return sum(row["error"] is None and row["named_execution"] is not None
                   and row["required_test"] in names for row in records)
    retained_passed = completed(set(provenance["retained_tests"]))
    supplemental_passed = completed(set(provenance["supplemental_tests"]))
    extra_passed = completed(set(provenance["focused_extra_tests"]))
    write_json(output / "batch-summary.json", {
        "component_validation_passed": success, "named_tests_passed": passed,
        "named_tests_required": 64, "phase_error": phase_error,
        "executable": executable, "executable_sha256": expected,
        "artifact_sha256": artifact_pin, "runner_sha256": runner_pin,
        "original_business_budgets_changed": False,
        "retained_pnq2_roster_executed_in_full": retained_passed == 52,
        "retained_controls_passed": retained_passed,
        "supplemental_controls_passed": supplemental_passed,
        "focused_extra_controls_passed": extra_passed,
        "selection_provenance": provenance,
        "whole_chain_quantum_security_qualified": False,
        "production_activation": False,
    })
    return 0 if success else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--build-timeout", type=int, default=3600)
    parser.add_argument("--test-timeout", type=int, default=900)
    parser.add_argument("--build-barrier", type=Path,
                        help="Optional outside-source atomic JSON release before any libtest invocation")
    parser.add_argument("--build-barrier-timeout", type=int, default=1800,
                        help="Separate build coordination cap in seconds; never changes a test budget")
    args = parser.parse_args()
    root, output, target = (p.resolve() for p in (args.root, args.out, args.target))
    if not re.fullmatch("[0-9a-f]{40}", args.source):
        raise ValueError("full committed S2 SHA required")
    if min(args.build_timeout, args.test_timeout) <= 0:
        raise ValueError("positive owner wall-time caps required")
    if not 1 <= args.build_barrier_timeout <= 7200:
        raise ValueError("build barrier timeout must be between 1 and 7200 seconds")
    barrier_path = None
    if args.build_barrier is not None:
        if not args.build_barrier.is_absolute() or ".." in args.build_barrier.parts:
            raise ValueError("build barrier path must be absolute without parent traversal")
        # Resolve its parent, never a potentially present leaf symlink.
        barrier_path = args.build_barrier.parent.resolve() / args.build_barrier.name
        if barrier_path.is_relative_to(root) or barrier_path.is_relative_to(target):
            raise ValueError("build barrier must remain outside source and compilation target")

    if any(p.is_relative_to(root) for p in (output, target)):
        raise ValueError("output and target must remain outside source")
    if output == target or output.is_relative_to(target) or target.is_relative_to(output):
        raise ValueError("separate output and target directories required")
    if output.exists() or target.exists():
        raise ValueError("fresh output and target paths required")
    if len(SELECTION) != 14 or len({name for _, name in SELECTION}) != 14:
        raise ValueError("focused test selection changed")
    overrides = [key for key, value in os.environ.items()
                 if value and (key.startswith("CARGO_PROFILE_")
                               or key.endswith(("_RUSTFLAGS", "_RUSTC", "_RUSTC_WRAPPER",
                                                "_RUSTC_WORKSPACE_WRAPPER"))
                               or key in ("RUSTFLAGS", "RUSTC", "RUSTC_WRAPPER",
                                          "RUSTC_WORKSPACE_WRAPPER"))]
    if overrides:
        raise ValueError("remove default-profile overrides: " + ", ".join(sorted(overrides)))
    provider_keys = ("OPENSSL_DIR", "OPENSSL_STATIC", "TRNM_PQ_OPENSSL",
                     "TRNM_PQ_OPENSSL_SHA256", "TRNM_PQ_OPENSSL_VERSION",
                     "OPENSSL_CONF", "OPENSSL_MODULES")
    provider = {key: os.environ.get(key) for key in provider_keys}
    if not all(provider.values()):
        raise ValueError("official prepared provider environment is required")
    if (provider["OPENSSL_STATIC"] != "1" or provider["TRNM_PQ_OPENSSL_VERSION"] != "3.5.9"
            or provider["OPENSSL_CONF"] != "/dev/null"
            or not re.fullmatch("[0-9a-f]{64}", provider["TRNM_PQ_OPENSSL_SHA256"])
            or digest(provider["TRNM_PQ_OPENSSL"]) != provider["TRNM_PQ_OPENSSL_SHA256"]):
        raise ValueError("prepared provider environment or CLI digest mismatch")
    output.mkdir(parents=True)
    target.mkdir(parents=True)
    commands, owners, batch = (output / p for p in ("commands", "owners", "batch"))
    for directory in (commands, owners, batch):
        directory.mkdir()
    os.environ.update(CARGO_BUILD_JOBS="2", CARGO_INCREMENTAL="0",
                      RUST_TEST_THREADS="1", PYTHONDONTWRITEBYTECODE="1",
                      CARGO_TARGET_DIR=str(target))
    imports(root)
    from ci_observation import run as run_observed
    from verify_ci_source import verify
    from pinned_native_process import descriptor_digest
    runner_pin = digest(Path(__file__).resolve())
    observations = []
    selection, provenance = select_controls(root)
    write_json(output / "plan.json", {
        "source": args.source, "runner_sha256": runner_pin, "selected_controls": 64,
        "selected_tests": selection, "selection_provenance": provenance,
        "groups": GROUPS, "provider_environment": provider,
        "build_timeout_seconds": args.build_timeout,
        "per_test_timeout_seconds": args.test_timeout, "default_workspace_profiles": True,
        "build_barrier_path": str(barrier_path) if barrier_path is not None else None,
        "build_barrier_timeout_seconds": args.build_barrier_timeout if barrier_path is not None else None,
        "business_budgets_changed": False, "retained_pnq2_roster_executed_in_full": False,
        "whole_chain_quantum_security_qualified": False,
    })

    def observed(label, command, timeout, record_source):
        argv = command
        if record_source:
            argv = [sys.executable, str(root / "scripts/ci/record_pq_native_command.py"),
                    "--kind", "head", "--candidate", args.source, "--tested", args.source,
                    "--label", label, "--output", str(commands), "--", *command]
        if label == "focused-native-batch":
            # Its native children each have their own original bounded owner.
            # Do not create a second timed process group around those groups:
            # killing only that parent group could strand an active owner.
            # The durable job remains the overall execution/cancellation owner.
            started = time.monotonic_ns()
            outer_log = owners / (label + ".log")
            with outer_log.open("xb") as stream:
                process = subprocess.run(argv, cwd=root, stdout=stream,
                                         stderr=subprocess.STDOUT, check=False)
            owner = {"command": argv, "cwd": str(root), "exit_code": process.returncode,
                     "process_exit_code": process.returncode, "timed_out": False,
                     "elapsed_ns": time.monotonic_ns() - started,
                     "log": outer_log.name, "executed": True,
                     "timeout_scope": "each native invocation; durable job owns whole batch",
                     "owns_process_group": False}
        else:
            owner = run_observed(argv, owners / (label + ".log"), cwd=root, timeout=timeout)
        receipt, error = None, None
        try:
            if owner["exit_code"] != 0 or owner["timed_out"]:
                raise ValueError("bounded owner command failed or timed out")
            if record_source:
                receipt = json.loads((commands / (label + ".json")).read_text())
                if (receipt["status"] != "command_succeeded" or receipt["exit_code"] != 0
                        or receipt["before"] != receipt["after"]
                        or receipt["before"]["tested_commit"] != args.source):
                    raise ValueError("exact source command receipt failed")
        except (OSError, ValueError, KeyError) as exc:
            error = str(exc)
        row = {"label": label, "owner": owner, "source_recorded": record_source,
               "source_receipt": str(commands / (label + ".json")) if record_source else None,
               "error": error}
        observations.append(row)
        write_json(output / "observations.json", observations)
        print(json.dumps({"label": label, "exit_code": owner["exit_code"],
                          "timed_out": owner["timed_out"], "error": error}), flush=True)
        return error is None, receipt

    before, passed, phase_error = None, False, None
    batch_result = {}
    try:
        for label, command in (
            ("preflight", ["bash", "scripts/project-preflight.sh", "--audit"]),
            ("compiler", ["rustc", "+1.95.0", "-Vv"]),
        ):
            ok, _ = observed(label, command, 180, False)
            if not ok:
                raise ValueError(label + " failed")
        cargo = ["cargo", "+1.95.0", "test", "--locked", "--manifest-path",
                 "trillionnium/Cargo.toml", "-p", "trnm-pon-node", "--lib",
                 "--all-features", "--no-run", "--message-format=json"]
        ok, receipt = observed("node-lib-build", cargo, args.build_timeout, True)
        if receipt is not None:
            before = receipt.get("before")
            write_json(output / "source-before.json", before)
        if not ok:
            raise ValueError("source-recorded native build failed")
        if select_controls(root) != (selection, provenance):
            raise ValueError("roster changed between planning and exact source build")
        artifacts = []
        source_file = root / "trillionnium/crates/trnm-pon-node/src/lib.rs"
        for line in (commands / "node-lib-build.log").read_text().splitlines():
            try:
                value = json.loads(line)
            except ValueError:
                continue
            if (value.get("reason") == "compiler-artifact"
                    and value.get("target", {}).get("kind") == ["lib"]
                    and value.get("profile", {}).get("test") is True
                    and value.get("executable")
                    and Path(value["target"]["src_path"]).resolve() == source_file):
                artifacts.append(value)
        if len(artifacts) != 1:
            raise ValueError("expected exactly one actual Node libtest Cargo artifact")
        artifact = artifacts[0]
        executable = Path(artifact["executable"])
        if (not executable.is_absolute() or ".." in executable.parts
                or not executable.resolve().is_relative_to(target)
                or artifact.get("fresh") is not False
                or not {"pq-native-openssl", "pq-root-v3"}.issubset(artifact["features"])):
            raise ValueError("native artifact is not the fresh all-features target")
        fd = os.open(executable, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
        try:
            executable_sha, info = descriptor_digest(fd)
            if os.pread(fd, 4, 0) != b"\x7fELF":
                raise ValueError("Cargo native test artifact is not ELF")
        finally:
            os.close(fd)
        artifact_path = output / "native-artifact.json"
        write_json(artifact_path, {
            "source": args.source, "executable": str(executable),
            "selected_tests": selection, "selection_provenance": provenance,
            "executable_sha256": executable_sha, "executable_bytes": info.st_size,
            "device": info.st_dev, "inode": info.st_ino, "cargo_artifact": artifact,
            "build_receipt_sha256": digest(commands / "node-lib-build.json"),
            "build_log_sha256": digest(commands / "node-lib-build.log"),
            "runner_sha256": runner_pin,
        })
        # Freeze the actual build identity before a coordinator may release us.
        artifact_pin = digest(artifact_path)
        write_json(output / "build-ready.json", {
            "status": ("native-build-complete-awaiting-barrier" if barrier_path is not None
                       else "native-build-complete"),
            "positive_source": args.source, "native_tests_started": False,
            "validation_complete": False,
            "native_artifact_path": str(artifact_path),
            "native_artifact_sha256": artifact_pin,
            "executable": str(executable), "executable_sha256": executable_sha,
            "build_receipt": str(commands / "node-lib-build.json"),
            "build_receipt_sha256": digest(commands / "node-lib-build.json"),
            "build_source_before": receipt["before"],
            "build_source_after": receipt["after"],
            "barrier_path": str(barrier_path) if barrier_path is not None else None,
            "runner_sha256": runner_pin,
        })
        print(json.dumps({"stage": "build-ready", "positive_source": args.source,
                          "build_ready": str(output / "build-ready.json"),
                          "native_tests_started": False}), flush=True)
        if barrier_path is not None:
            wait_for_build_barrier(barrier_path, args.source, output, args.build_barrier_timeout)
        if digest(artifact_path) != artifact_pin:
            raise ValueError("build artifact record changed while waiting for release")
        command = [sys.executable, str(Path(__file__).resolve()), "_native_batch",
                   str(root), str(artifact_path), artifact_pin, str(batch),
                   runner_pin, str(args.test_timeout)]
        ok, receipt = observed("focused-native-batch", command, None, True)
        if receipt is not None:
            write_json(output / "source-after-batch.json", receipt.get("after"))
        batch_result = json.loads((batch / "batch-summary.json").read_text())
        passed = (ok and batch_result["component_validation_passed"] is True
                  and batch_result["named_tests_passed"] == 64
                  and batch_result["retained_controls_passed"] == 52
                  and batch_result["supplemental_controls_passed"] == 7
                  and batch_result["focused_extra_controls_passed"] == 5)
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as exc:
        phase_error = str(exc)
    try:
        final = verify("head", args.source, root=root)
        write_json(output / "source-final.json", final)
        verify_runner(runner_pin)
        passed = passed and before is not None and final == before
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        passed = False
        phase_error = (phase_error + "; " if phase_error else "") + str(exc)
    summary = {
        "source": args.source, "component_validation_passed": passed,
        "phase_error": phase_error, "observations": observations,
        "runner_sha256": runner_pin, "default_workspace_profiles": True,
        "original_business_budgets_changed": False,
        "retained_pnq2_roster_executed_in_full": batch_result.get("retained_controls_passed") == 52,
        "named_tests_passed": batch_result.get("named_tests_passed", 0), "named_tests_required": 64,
        "retained_controls_passed": batch_result.get("retained_controls_passed", 0),
        "supplemental_controls_passed": batch_result.get("supplemental_controls_passed", 0),
        "focused_extra_controls_passed": batch_result.get("focused_extra_controls_passed", 0),
        "selection_provenance": provenance,
        "whole_chain_quantum_security_qualified": False, "production_activation": False,
    }
    write_json(output / "summary.json", summary)
    print(json.dumps({"component_validation_passed": passed, "output": str(output),
                      "phase_error": phase_error}, sort_keys=True), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "_native_worker":
        raise SystemExit(native_worker(sys.argv[2:]))
    if len(sys.argv) > 1 and sys.argv[1] == "_native_batch":
        raise SystemExit(native_batch(sys.argv[2:]))
    raise SystemExit(main())
