# Additional hosted CI diagnosis and candidate gate repair

This capsule retains original hosted observations. It does not relabel any failed workflow as successful. The tested application source remained frozen while the proposed Python/workflow repair was prepared and checked outside the primary checkout.

## Transparent candidate: a current producer and historical reader mismatch

| Run | Source kind | Job | Tested commit | Tree |
| --- | --- | --- | --- | --- |
| 42518203803 | F3 head | 128845754112 | 1a446a79700cc093a2b1a7f10367ef4a5ddbd680 | 928b180bf769a813e5643827329667cb11f2a3a5 |
| 42518203803 | F3 prospective merge | 128845754019 | 24350527a77a3caee6f1e7a21973874664ab603f | 928b180bf769a813e5643827329667cb11f2a3a5 |
| 42515032681 | F2 head | 128836076847 | 0101b0ce76239832e0b2d19d0fd3f07e40fabeb4 | f57618067a8106d0a96f74dd38291a25416ff68c |
| 42515032681 | F2 prospective merge | 128836077084 | d5ba8574297839ed06e7a016207827b7993825c6 | f57618067a8106d0a96f74dd38291a25416ff68c |

The base is 7e044b65454f4c9ea505591727332acffb33e7e5. All four complete logs contain matching actual source-before/source-after receipts. F3 checks 24,851 tracked entries and 2,419,095,485 bytes; F2 checks 24,847 entries and 2,419,054,249 bytes. Source identity verification does not execute tests.

In every job, the actual saved-v2 receipt runner reports 58 planned and 58 completed controls, with all controls passed. The following consistency gate fails with the exact error `ValueError: process observation differs: schema`. The final required-stage check then correctly records `receipt_controls_v2` as failed.

The current producer, `formal/pon-nakamoto-v1/experiments/w1_stage_measure.py`, emits `TRNM-W1-STAGE-MEASUREMENT3`. The gate, `scripts/ci/w1_v2_controls_gate.py`, still fixes the process schema to version 2. The original 23 gate controls replay the unchanged historical version-2 archive, so they did not cover the current producer interface.

### Proposed repair and validation

`candidate-v3-gate.patch` changes three files. It preserves the historical validator's default version 2 and every original 23 control. The current CLI explicitly selects version 3 and has no downgrade option. It retains every original process field, all 58 ordered receipt controls, one common 120-second budget, input and binary hashes, rejection-layer checks, and process cleanup checks. Version 3 additionally requires the exact cancellation schema, a pre-handoff-snapshot marker, null cancellation signal/event, an unexhausted snapshot deadline, and false resource/completed-proof qualification flags.

The shared field checker now checks key presence before comparing type/value; omitted null fields therefore produce the intended explicit rejection rather than an incidental KeyError. The initial new-control run exposed this issue and is retained as `candidate-v3-current-controls-initial-failure.log`. Its CLI-dispatch stub is a unit-test double, not a proof execution. The final test captures that stub's informational output to avoid confusing it with the separate actual artifact review.

Ten new process-contract controls execute real short child processes for positive and clean nonzero exit observations, then check version mismatch, absent fields, cancellation, deadline exhaustion, qualification promotion, type coercion, unknown selectors and CLI dispatch. These children are process fixtures, not proof verifiers. The workflow keeps the original exact 23-name roster and adds a separate exact 10-name roster with no skips, duplicates or arbitrary counts.

The independent desktop validation job `1a1bceb96d1-138b0-520` completed successfully with durable complete output:

- The original 23 historical controls passed.
- All ten new process-contract controls passed.
- The original unchanged gate reproduced the schema refusal on the actual F3 head artifact.
- The proposed current gate checked all 58 actual retained F3 controls successfully, including the one positive and 57 negative observations, their saved bytes, logs, commands and binary hash.
- The copied source/patch capsule was unchanged before and after.

The F3 artifact is GitHub artifact 13632342278 from job 128845754112. The downloaded 31,113,550-byte ZIP exactly matches the GitHub API digest `0db5b996a2ad941be64ef4aab4dca230bb7674aab4e5a281ae5ddc0f05a2bc17`. Its compiled verifier SHA256 is `dffc97dd6592ff53857fa39da0ccbc6a5251dc2f0ecc242e571c08a50371aa4f`.

The artifact review uses the validator's explicit recorded-path interface because the GitHub output has been relocated. The original paths are identities; they are not rewritten or executed. This review executes no new cryptography, generates no proof, and does not grant execution provenance or quantum qualification. A subsequent actual hosted run is still required to validate the repaired current CLI in its normal workflow. The original four workflow failures remain failures.

## F2 fresh service: an actual business target failure

Run 42515032752 has two failed fresh-service jobs: head 128836078208 and prospective merge 128836078012. Their complete decoded logs are retained, as are the downloaded raw artifacts:

| Source | Artifact | ZIP SHA256 |
| --- | --- | --- |
| Head | 13631707634 | d915825fc8c75383d4b02cc7c22b2abd40be84c047575b65377696a6367a367a |
| Prospective merge | 13631417829 | e5c22733b923279b95b3c5853097cac29d980bba8a7ea750154223ed4c81f920 |

The host wrapper prepared the binary successfully and retained the original public resource limits: CPU `25000 100000`, memory 2 GiB, and 256 PIDs. Its host error lists are empty. Source identities and the binary hash agree before and after.

Both jobs actually execute both named native observations. The original test exits zero but reports `finite_target_met=false`; the Python business gate correctly refuses `CONFIRMATION_TARGET`. The fresh-challenge native test exits 101 at `fresh_challenge.rs:244`, reporting failure to meet the original four-second/six-depth target. The required 16 workers and four-second window remain unchanged.

For the head job, the last observed pressure history replay in each observation records `PUBLIC_REQUEST_DEADLINE`. For the merge job, the last replay is accepted while the overall finite target remains false. An accepted individual replay cannot replace the full business criterion, and a zero native test exit cannot override the report. This is a genuine failed observation under the retained constraints. No threshold, deadline or host resource relaxation is proposed.

The small manifests/logs are mirrored under `validated/F2-fresh-*`. The complete native reports, databases and binaries remain in the verified raw ZIPs and extracted directories on the desktop evidence volume. No downloaded binary was executed during diagnosis.

## F2 CodeQL export: exact-source drift refusal

Run 42515032697, job 128836078906, completes its exporter source checks and 16 controls. It waits for exact-source analyses, then reports at 20:04:35 UTC:

> PR head/base moved or PR is no longer an open same-repository PR

The PR had advanced from F2 to F3. This is the exporter's exact-source guard refusing a changed PR tuple. Its original failure is retained. It does not establish that a CodeQL analysis completed or that there are no findings. No weakening of this guard is proposed.

Raw run API objects may include the PR's later mutable head tuple. The diagnosis uses each run's immutable `head_sha` and the actual source receipts in its job logs, rather than borrowing the later PR head.

## Files and scope

`logs/` contains 27 complete decoded job logs, including the four candidate jobs, all 22 executed F2 work-security jobs, and the CodeQL exporter. The skipped work-security setup job has no execution log. Raw run/job metadata, candidate source tuples, selected unchanged source files, the independent patch, and original/final control outputs are retained alongside them.

The proposed patch is still separate from the frozen primary. The original W1 proof/MMCS campaigns and their results belong to their own exact F3 source evidence. Every mathematical, complete quantum, work-cost, independent public-network and production qualification remains outside this consistency repair.

## Hosted references

- [F3 transparent candidate](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42518203803)
- [F2 transparent candidate](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42515032681)
- [F2 W1 work security](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42515032752)
- [F2 exact-source CodeQL export](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42515032697)
