#!/usr/bin/env python3
"""Read completed frontier/cache artifacts; summarize, never rerun their models.

This reader verifies self hashes, declared grids, internal sums, stage journal,
cross-input source/fixture identities, and optionally an outer source inventory.
It does not execute repository code, a compiler, a proof producer, Node or QPU.
A source-bound native/model replay receipt remains separate evidence.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
import itertools
import json
from pathlib import Path
import re
import sys

SCHEMAS = {
    'service': 'trnm-w1-service-architecture-frontier-v1',
    'original': 'trnm-w1-constructed-machine-frontier-v1',
    'cache': 'trnm-w1-native-preprocessing-cache-cpu-observation-v1',
    'comparison': 'trnm-w1-complete-proof-preprocessing-cache-v1',
}
CAPACITIES = [0, 4096, 262144]
CACHE_COUNTERS = ('lookups', 'hits', 'misses', 'key_bytes_compared', 'value_bytes_read',
                  'insertions', 'insertion_refusals', 'key_and_value_bytes_written',
                  'evictions', 'key_and_value_bytes_evicted')
WORK_COUNTERS = ('challenge_sha_compressions', 'cached_challenge_sha_compressions_reused',
                 'ab_products_computed', 'ab_products_reused', 'ab_field_multiply_add_pairs',
                 'noise_hashes', 'noise_raw_words_checked', 'low_rank_field_multiply_add_pairs',
                 'offset_field_additions', 'trace_field_multiply_add_pairs', 'trace_prefix_words',
                 'trace_input_bytes_hashed', 'ticket_input_bytes_hashed', 'proof_bytes_materialized')


def need(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, name, minimum=0):
    need(type(value) is int and value >= minimum, name + ': integer/range')
    return value


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def strict_load(raw):
    def pairs(rows):
        result = {}
        for key, value in rows:
            need(key not in result, 'duplicate JSON key: ' + key)
            result[key] = value
        return result
    def invalid(value):
        raise ValueError('nonfinite JSON: ' + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def digest_string(value, name):
    need(type(value) is str and re.fullmatch(r'[0-9a-f]{64}', value) is not None, name + ': SHA-256')
    return value


def fraction(value):
    need(type(value) is dict and set(value) == {'numerator', 'denominator'}, 'rational schema')
    n, d = value['numerator'], value['denominator']
    need(type(n) is int and type(d) is int and d > 0, 'rational integers')
    result = Fraction(n, d)
    need(result.numerator == n and result.denominator == d, 'noncanonical rational')
    return result


def rational(value):
    return {'numerator': value.numerator, 'denominator': value.denominator}


def interval(value):
    need(type(value) is dict and set(value) == {'lower', 'upper'}, 'probability interval schema')
    lo, hi = fraction(value['lower']), fraction(value['upper'])
    need(0 <= lo <= hi <= 1, 'probability interval ordering')
    return lo, hi


def hashed_record(record, field, label):
    need(type(record) is dict, label + ': object')
    expected = digest_string(record.get(field), label + ': ' + field)
    need(sha(canonical({k: v for k, v in record.items() if k != field})) == expected,
         label + ': content hash mismatch')


def false_claims(claims, label):
    need(type(claims) is dict and claims, label + ': claims')
    need(all(value is False or type(value) is int and value == 0 for value in claims.values()),
         label + ': unexpected positive qualification claim')


class Reader:
    def __init__(self):
        self.files, self.sources, self.fixture_hashes, self.domain_hashes = [], {}, set(), set()
        self.inventory = None
        self.inventory_source = None

    def raw(self, path, maximum):
        path = Path(path).absolute()
        need(path.is_file(), 'missing regular input: ' + str(path))
        size = path.stat().st_size
        need(0 < size <= maximum, 'input size: ' + str(path))
        raw = path.read_bytes()
        need(len(raw) == size, 'input changed while reading: ' + str(path))
        row = {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}
        self.files.append(row)
        return raw, row

    def json(self, path, maximum=128 * 1024 * 1024):
        raw, meta = self.raw(path, maximum)
        return strict_load(raw), meta

    def source_map(self, values):
        need(type(values) is dict and values, 'missing source map')
        for path, value in values.items():
            need(type(path) is str and path and not path.startswith('/') and '..' not in Path(path).parts,
                 'noncanonical source path')
            digest_string(value, path)
            need(path not in self.sources or self.sources[path] == value, 'incompatible source identity: ' + path)
            if self.inventory is not None:
                need(self.inventory.get(path) == value, 'source does not match outer inventory: ' + path)
            self.sources[path] = value

    def bind_fixture(self, value):
        self.fixture_hashes.add(digest_string(value, 'native fixture'))
        need(len(self.fixture_hashes) == 1, 'different native fixtures across inputs')

    def load_inventory(self, path, expected_head):
        value, meta = self.json(path, 32 * 1024 * 1024)
        need(value.get('columns') == ['path', 'git_mode', 'git_blob_sha1', 'sha256'], 'outer inventory columns')
        entries, source = value['entries'], value['source']
        need(type(entries) is list and source['tracked_files'] == len(entries), 'outer inventory count')
        need(sha(json.dumps(entries, separators=(',', ':')).encode()) == source['inventory_sha256'],
             'outer inventory content hash')
        for key in ('head', 'tree'):
            need(type(source[key]) is str and re.fullmatch(r'[0-9a-f]{40}', source[key]) is not None,
                 'outer inventory ' + key)
        if expected_head is not None:
            need(source['head'] == expected_head, 'outer inventory wrong expected HEAD')
        inventory = {}
        for entry in entries:
            need(type(entry) is list and len(entry) == 4, 'outer inventory row')
            name, mode, blob, value_hash = entry
            need(name not in inventory, 'outer inventory duplicate path')
            need(mode in ('100644', '100755', '120000')
                 and re.fullmatch(r'[0-9a-f]{40}', blob) is not None, 'outer inventory Git identity')
            inventory[name] = digest_string(value_hash, 'outer inventory digest')
        self.inventory = inventory
        self.inventory_source = source
        return {'input': meta, 'source': source,
                'qualification': 'matches supplied strict-driver inventory; does not rerun source guard'}

    def frontier(self, path, kind):
        report, meta = self.json(path)
        need(report.get('schema') == SCHEMAS[kind], 'frontier schema')
        hashed_record(report, 'report_sha256', kind + ' frontier')
        false_claims(report['claims'], kind)
        self.bind_fixture(report['native_fixture_sha256'])
        domain = digest_string(report['domain_sha256'], 'frontier domain')
        self.domain_hashes.add(domain)
        need(len(self.domain_hashes) == 1, 'frontiers use different literal domains')
        grid, cells = report['declared_grid'], report['cells']
        need(type(cells) is list, 'frontier cells')
        need(grid['predicates'] == ['full', 'prefix-restricted']
             and grid['processors'] == [1, 2, 4] and grid['iterations'] == [0, 1, 2]
             and type(grid['trials']) is int and grid['trials'] == 2
             and grid['horizon_seconds'] == '4' and type(grid['physical_qubit_budget']) is int
             and grid['physical_qubit_budget'] == 10**16, 'frontier grid differs from frozen declared scope')
        service = kind == 'service'
        architectures = [v['name'] for v in grid['architectures']] if service else ['original-serial']
        need(len(architectures) == (3 if service else 1) and len(set(architectures)) == len(architectures),
             'architecture inventory')
        expected = set(itertools.product(architectures, grid['predicates'], grid['processors'], grid['iterations']))
        need(len(cells) == report['planned_cells'] == (54 if service else 18)
             and len(cells) == report['retained_cells' if service else 'observed_model_cells'],
             'frontier missing cells')
        if service:
            self.source_map(report['source_sha256'])
        else:
            self.source_map({'formal/pon-nakamoto-v1/experiments/w1_machine_frontier.py':
                             report['comparison_source_sha256']})
        summarized, seen, names = [], set(), set()
        for cell in cells:
            architecture = cell['architecture'] if service else 'original-serial'
            identity = (architecture, cell['predicate'], cell['processors'], cell['iterations'])
            need(identity in expected and identity not in seen and cell['name'] not in names,
                 'frontier cell identity/inventory')
            integer(cell['processors'], 'processor count', 1)
            integer(cell['iterations'], 'Grover iteration count')
            seen.add(identity)
            names.add(cell['name'])
            row = {key: cell[key] for key in ('name', 'predicate', 'processors', 'iterations', 'status')}
            row.update(architecture=architecture,
                       execution_kind='conditional-machine-q0' if cell['iterations'] == 0 else 'conditional-machine-q-positive',
                       classical_cpu_baseline=False, actual_quantum_hardware_execution=False)
            if cell['status'] == 'REFUSED':
                need(type(cell['reason']) is str and cell['reason'], 'refused reason')
                row['reason'] = cell['reason']
                summarized.append(row)
                continue
            need(cell['status'] == ('CONSTRUCTED_CONDITIONAL_MODEL' if service else 'CONSTRUCTED'),
                 'unknown frontier status')
            if service:
                architecture_record = cell['architecture_record']
                hashed_record(architecture_record, 'record_sha256', 'architecture')
                self.source_map(architecture_record['source_sha256'])
                false_claims(architecture_record['claims'], 'architecture')
                need(architecture_record['resources'] == cell['resources'], 'service resource copy')
                row['calibration'] = architecture_record['calibration']
                need(row['calibration']['status'] == 'MISSING_EXTERNAL_EVIDENCE', 'unexpected calibration state')
                machine = architecture_record['machine_record']
            else:
                machine = cell['machine_record']
            hashed_record(machine, 'record_sha256', 'machine envelope')
            self.source_map(machine['source_sha256'])
            need(machine['schema'] == ('trnm-w1-machine-reserved-service-envelope-v2' if service
                                      else 'trnm-w1-machine-lifecycle-envelope-v1'), 'machine schema')
            for flag in ('physical_parameters_calibrated', 'fault_tolerant_layout_and_controller_compiled',
                         'quantum_hardware_executed', 'native_block_admission_verified',
                         'minimum_attacker_cost_proved', 'quantum_mining_qualified'):
                need(machine[flag] is False, 'unexpected positive machine flag: ' + flag)
            premises, envelope = machine['premises'], machine['envelope']
            need(premises['processors'] == cell['processors'] and premises['predicate'] == cell['predicate']
                 and premises['horizon_seconds'] == grid['horizon_seconds']
                 and premises['physical_qubit_budget'] == grid['physical_qubit_budget']
                 and premises['schedule'] == [[0, cell['iterations']]] * grid['trials'],
                 'machine and frontier premise mismatch')
            physical = integer(envelope['physical_qubits_all_processors'], 'physical allocation', 1)
            need(physical == cell['resources']['physical_qubits'] <= grid['physical_qubit_budget'],
                 'physical allocation budget')
            eps = fraction(envelope['whole_plan_failure_union_upper'])
            need(0 <= eps <= Fraction(envelope['unchanged_declared_failure_budget']), 'declared fault budget')
            ideal = machine['ideal_schedule_probability']
            need(ideal['delivery_probability'] == cell['ideal_delivery_probability']
                 and machine['conditional_machine_delivery_probability'] == cell['conditional_delivery_probability'],
                 'delivery interval copy mismatch')
            ideal_lo, ideal_hi = interval(cell['ideal_delivery_probability'])
            conditional_lo, conditional_hi = interval(cell['conditional_delivery_probability'])
            branches = ideal['evaluated_trial_branches']
            need(type(branches) is list and 1 <= len(branches) <= grid['trials']
                 and ideal['planned_trials'] == grid['trials'], 'evaluated trial count')
            horizon, clock, times = Fraction(grid['horizon_seconds']), Fraction(0), []
            for index, branch in enumerate(branches):
                need(branch['schedule_index'] == index, 'trial sequence')
                trial = machine['planned_rounds'][index]
                finish = clock + fraction(trial['search_seconds_exact'])
                search_complete = clock < horizon and finish <= horizon
                delivery_complete = search_complete and finish + fraction(trial['winner_seconds_exact']) <= horizon
                need(type(branch['search_complete_by_deadline']) is bool
                     and type(branch['delivery_complete_by_deadline']) is bool
                     and branch['search_complete_by_deadline'] == search_complete
                     and branch['delivery_complete_by_deadline'] == delivery_complete
                     and fraction(branch['all_failure_path_start_seconds_exact']) == clock
                     and fraction(branch['all_failure_path_checks_finish_seconds_exact']) == finish,
                     'trial deadline arithmetic')
                if search_complete:
                    need(fraction(branch['winning_branch_delivery_finish_seconds_exact'])
                         == finish + fraction(trial['winner_seconds_exact']), 'proof/delivery finish arithmetic')
                else:
                    need(index == len(branches) - 1, 'trials continue after search censoring')
                times.append({key: branch[key] for key in (
                    'schedule_index', 'all_failure_path_start_seconds_exact',
                    'all_failure_path_checks_finish_seconds_exact',
                    'search_complete_by_deadline', 'delivery_complete_by_deadline')})
                times[-1]['winning_branch_delivery_finish_seconds_exact'] = branch.get('winning_branch_delivery_finish_seconds_exact')
                clock = finish
            provisioned = sum((fraction(v['search_seconds_exact']) for v in machine['planned_rounds']), Fraction(0))
            provisioned += premises['reserved_maximum_winners'] * max(fraction(v['winner_seconds_exact'])
                                                                      for v in machine['planned_rounds'])
            if service:
                need(provisioned == fraction(cell['resources']['complete_plan_seconds_reserved']), 'full reserved duration')
            row.update(constructed_with_declared_error_and_qubit_bounds=True,
                candidate_check_time_feasible=any(v['search_complete_by_deadline'] for v in branches),
                delivery_slot_time_feasible=any(v['delivery_complete_by_deadline'] for v in branches),
                all_trial_checks_time_feasible=len(branches) == grid['trials'] and all(v['search_complete_by_deadline'] for v in branches),
                full_reserved_plan_fits_horizon=provisioned <= horizon,
                full_reserved_plan_seconds_exact=rational(provisioned),
                ideal_delivery_lower_positive=ideal_lo > 0, ideal_delivery_upper_positive=ideal_hi > 0,
                conditional_delivery_lower_positive=conditional_lo > 0, conditional_delivery_upper_positive=conditional_hi > 0,
                ideal_delivery_probability=cell['ideal_delivery_probability'],
                conditional_delivery_probability=cell['conditional_delivery_probability'],
                code_distance=cell['code_distance'], resources=cell['resources'],
                whole_plan_failure_union_upper=envelope['whole_plan_failure_union_upper'],
                deadline_branches=times)
            summarized.append(row)
        need(seen == expected, 'missing declared cell')
        frontier = report['undominated_with_certified_interval_order']
        need(type(frontier) is list and len(frontier) == len(set(frontier))
             and all(v in names for v in frontier), 'reported frontier names')
        groups = defaultdict(list)
        for row in summarized:
            groups[(row['architecture'], row['execution_kind'])].append(row)
        def counts(rows):
            constructed = [v for v in rows if v['status'] != 'REFUSED']
            return {'retained_cells': len(rows), 'constructed_under_declared_bounds': len(constructed),
                    'refused_cells': len(rows) - len(constructed),
                    'refusal_reasons': dict(Counter(v['reason'] for v in rows if v['status'] == 'REFUSED')),
                    **{key + '_cells': sum(v[key] for v in constructed) for key in (
                        'candidate_check_time_feasible', 'delivery_slot_time_feasible',
                        'all_trial_checks_time_feasible', 'full_reserved_plan_fits_horizon',
                        'ideal_delivery_lower_positive', 'ideal_delivery_upper_positive',
                        'conditional_delivery_lower_positive', 'conditional_delivery_upper_positive')}}
        return {'input': meta, 'schema': report['schema'], 'report_sha256': report['report_sha256'],
                'source_fields': {key: report[key] for key in ('source_sha256', 'comparison_source_sha256') if key in report},
                'native_fixture_sha256': report['native_fixture_sha256'], 'domain_sha256': domain,
                'native_shape': report['native_shape'], 'declared_grid': grid, 'counts': counts(summarized),
                'groups': [{'architecture': key[0], 'execution_kind': key[1], **counts(rows)}
                           for key, rows in sorted(groups.items())],
                'reported_undominated_names': frontier, 'dominance_not_recomputed_by_summary_reader': True,
                'claims': report['claims'], 'cells': summarized,
                'interpretation': [
                    'Constructed means declared error/qubit constraints passed; it is not observed machine completion.',
                    'A time-feasible delivery slot can have zero winning probability; positive ideal bounds are counted separately.',
                    'A positive fault-coupled upper endpoint alone is not evidence that an ideal delivery completed.',
                    'q=0 still pays the conditional quantum-machine lifecycle; it is not the independent CPU baseline.']}

    def cache(self, report_path, journal_path):
        report, meta = self.json(report_path, 32 * 1024 * 1024)
        need(report.get('schema') == SCHEMAS['cache'], 'cache observation schema')
        hashed_record(report, 'report_sha256', 'cache observation')
        need(report.get('status') == 'PASS' and report.get('failure') is None,
             'cache observation is failed/partial; inspect original report and retained journal')
        false_claims(report['claims'], 'cache observation')
        need(canonical(report['source_sha256_before']) == canonical(report['source_sha256_after']), 'cache source changed')
        self.source_map(report['source_sha256_before'])
        self.bind_fixture(report['native_fixture_sha256'])
        comparison = report['comparison']
        need(comparison.get('schema') == SCHEMAS['comparison'], 'cache comparison schema')
        hashed_record(comparison, 'record_sha256', 'cache comparison')
        self.source_map(comparison['source_sha256'])
        false_claims(comparison['claims'], 'cache comparison')
        need(report['capacities_payload_bytes'] == comparison['capacities_payload_bytes'] == CAPACITIES,
             'cache capacities')
        need(comparison['native_shape'] is True and comparison['same_complete_proof_outcomes_across_capacities'] is True,
             'cache native/complete-outcome claims')
        schedule, cells = comparison['schedule'], comparison['cells']
        need(type(schedule) is list and 1 <= len(schedule) <= 128 and type(cells) is list
             and [v['capacity_payload_bytes'] for v in cells] == CAPACITIES, 'cache schedule/cell inventory')
        expected_timings = [(capacity, i, stage) for capacity in CAPACITIES
                            for i in range(len(schedule)) for stage in ('producer', 'independent_full_relation_check')]
        timings = report['timings']
        need(type(timings) is list and len(timings) == len(expected_timings), 'cache timing count')
        timing_by_capacity = defaultdict(lambda: defaultdict(lambda: {'cpu_ns': 0, 'wall_ns': 0, 'completed_stages': 0}))
        for row, identity in zip(timings, expected_timings):
            need(set(row) == {'capacity_payload_bytes', 'attempt_index', 'stage', 'status', 'error', 'cpu_ns', 'wall_ns'},
                 'cache timing fields')
            need((row['capacity_payload_bytes'], row['attempt_index'], row['stage']) == identity
                 and row['status'] == 'COMPLETED' and row['error'] is None, 'cache timing order/completion')
            integer(row['capacity_payload_bytes'], 'timing capacity')
            integer(row['attempt_index'], 'timing attempt')
            aggregate = timing_by_capacity[row['capacity_payload_bytes']][row['stage']]
            for clock in ('cpu_ns', 'wall_ns'):
                aggregate[clock] += integer(row[clock], clock)
            aggregate['completed_stages'] += 1
        whole = report['process_observation']
        for clock in ('cpu', 'wall'):
            stage_total = sum(v[clock + '_ns'] for v in timings)
            need(integer(whole['accounted_stage_' + clock + '_ns'], 'stage clock') == stage_total
                 and integer(whole[clock + '_ns'], 'whole clock')
                 == stage_total + integer(whole['other_observation_' + clock + '_ns'], 'other clock'),
                 'cache clock totals')
        need(integer(whole['process_high_water_rss_bytes_after'], 'RSS after')
             >= integer(whole['process_high_water_rss_bytes_before'], 'RSS before'), 'RSS rewound')
        journal_raw, journal_meta = self.raw(journal_path, 4 * 1024 * 1024)
        need(journal_raw.endswith(b'\n'), 'journal incomplete last line')
        need(report['progress_journal'] == {'file': Path(journal_path).name, 'bytes': len(journal_raw),
                                           'sha256': sha(journal_raw)}, 'journal byte binding')
        events = [strict_load(line) for line in journal_raw.splitlines()]
        expected_events = [{'event': 'declared', 'source_sha256': report['source_sha256_before'],
                            'native_fixture_sha256': report['native_fixture_sha256'],
                            'schedule': schedule, 'capacities_payload_bytes': CAPACITIES}]
        for row in timings:
            expected_events.append({'event': 'stage_started', 'capacity_payload_bytes': row['capacity_payload_bytes'],
                                    'attempt_index': row['attempt_index'], 'stage': row['stage']})
            expected_events.append({'event': 'stage_terminal', **row})
        expected_events.append({'event': 'observation_terminal', 'status': 'PASS', 'failure': None})
        need(canonical(events) == canonical(expected_events), 'journal event/completion binding')
        summary, baseline = [], None
        for cell in cells:
            capacity, attempts, cache = cell['capacity_payload_bytes'], cell['attempts'], cell['cache']
            need(cell['initial_cache'] == 'empty' and cell['all_attempts_and_failures_retained'] is True
                 and len(attempts) == len(schedule), 'cache attempts/cold-start ledger')
            total_work, total_cache = Counter(), Counter()
            outcomes, complete, identities = Counter(), 0, []
            for index, (attempt, action) in enumerate(zip(attempts, schedule)):
                need(type(action) is list and len(action) == 2 and attempt['attempt_index'] == index
                     and [attempt['context_index'], attempt['nonce']] == action, 'cache attempt identity')
                for field, keys, accumulator in (('work_units', WORK_COUNTERS, total_work),
                                                 ('cache_counter_delta', CACHE_COUNTERS, total_cache)):
                    need(set(attempt[field]) == set(keys), 'cache operation-counter fields')
                    for key in keys:
                        accumulator[key] += integer(attempt[field][key], key)
                outcome = attempt['outcome']
                need(outcome in ('TARGET_HIT', 'TARGET_MISS', 'NOISE_EXHAUSTED'), 'cache attempt outcome')
                outcomes[outcome] += 1
                verification = attempt['verification']
                need(verification['full_relation_checked'] is True and verification['native_block_admitted'] is False
                     and type(verification['complete_proof']) is bool, 'independent relation completion')
                size = integer(attempt['proof_bytes'], 'proof bytes')
                if verification['complete_proof']:
                    need(size > 0 and outcome != 'NOISE_EXHAUSTED', 'complete proof outcome')
                    digest_string(attempt['proof_sha256'], 'complete proof')
                    complete += 1
                else:
                    need(size == 0 and outcome == 'NOISE_EXHAUSTED' and attempt['proof_sha256'] is None, 'exhausted proof')
                need(integer(attempt['resident_payload_bytes_after'], 'resident after') <= capacity, 'payload capacity')
                identities.append({key: attempt[key] for key in (
                    'context_index', 'nonce', 'challenge', 'trace', 'ticket', 'outcome', 'proof_sha256', 'proof_bytes')})
            need(dict(total_work) == cell['work_units_total'] and dict(total_cache) == cache['counters'],
                 'cache cost decomposition mismatch')
            need(cache['capacity_payload_bytes'] == capacity
                 and 0 <= cache['resident_payload_bytes'] <= cache['peak_resident_payload_bytes'] <= capacity
                 and cache['python_objects_allocator_and_transient_workspace_included_in_capacity'] is False,
                 'cache payload-memory scope')
            need(total_cache['hits'] + total_cache['misses'] == total_cache['lookups']
                 and total_cache['insertions'] - total_cache['evictions'] == cache['resident_entries'],
                 'cache event identities')
            need(total_work['proof_bytes_materialized'] == sum(v['proof_bytes'] for v in attempts)
                 and total_work['ab_products_computed'] + total_work['ab_products_reused'] == complete,
                 'cache proof/preprocessing counts')
            for label, outcome in (('target_hits', 'TARGET_HIT'), ('target_misses', 'TARGET_MISS'),
                                   ('noise_exhaustions', 'NOISE_EXHAUSTED')):
                need(cell[label] == outcomes[outcome], 'cache retained outcome totals')
            if baseline is None:
                baseline = identities
            else:
                need(canonical(identities) == canonical(baseline), 'capacities change complete proof outcomes')
            summary.append({'capacity_payload_bytes': capacity, 'initial_cache': 'empty',
                'attempts': len(attempts), 'target_hits': outcomes['TARGET_HIT'],
                'target_misses': outcomes['TARGET_MISS'], 'noise_exhaustions': outcomes['NOISE_EXHAUSTED'],
                'complete_proofs': complete, 'complete_relation_checks': len(attempts),
                'failed_execution_stages': 0, 'cache_event_counters': cache['counters'],
                'work_unit_cost_components': cell['work_units_total'],
                'resident_payload_bytes': cache['resident_payload_bytes'],
                'peak_resident_payload_bytes': cache['peak_resident_payload_bytes'],
                'resident_entries': cache['resident_entries'], 'lru_state_sha256': cache['lru_state_sha256'],
                'actual_cpu_stage_observations': dict(timing_by_capacity[capacity]),
                'capacity_is_total_physical_or_process_memory': False,
                'per_capacity_exclusive_process_memory_observed': False})
        equivalence = report['native_fixture_equivalence']
        need(equivalence['actual_native_fixture_proof_identities_checked'] == len(cells) * len(schedule)
             and equivalence['full_proofs_match_retained_native_packets'] is True
             and equivalence['same_packet_new_node_execution_claimed'] is False, 'native fixture proof identities')
        return {'input': meta, 'journal_input': journal_meta, 'schema': report['schema'],
                'status': report['status'], 'report_sha256': report['report_sha256'],
                'comparison_record_sha256': comparison['record_sha256'],
                'native_fixture_sha256': report['native_fixture_sha256'],
                'source_sha256_before': report['source_sha256_before'],
                'source_sha256_after': report['source_sha256_after'],
                'comparison_source_sha256': comparison['source_sha256'],
                'execution_kind': 'actual-CPU-proof-production-and-independent-scalar-verification',
                'not_a_QPU_run_or_Grover_sample': True, 'capacities': summary,
                'journal': {'events': len(events), 'started_stages': len(timings),
                            'completed_stages': len(timings), 'failed_stages': 0,
                            'unmatched_started_stages': 0, 'full_event_binding_checked': True},
                'native_fixture_equivalence': equivalence, 'runtime': report['runtime'],
                'observed_at_utc': report['observed_at_utc'], 'process_observation': whole,
                'claims': report['claims'], 'comparison_claims': comparison['claims'],
                'interpretation': [
                    'Cache lookup misses, W1 target misses, and failed execution stages are separate counts.',
                    'All reported successful stages completed; target misses still produce and verify full proofs.',
                    'Payload limits exclude Python objects, allocator overhead and transient workspace; RSS is process-wide high-water.',
                    'Capacities run sequentially in one process/OS environment; timings are descriptive, not an unbiased speed comparison.',
                    'Inner clocks exclude interpreter startup/imports/final serialization; the external driver command clocks cover them.',
                    'No coherent oracle-cost reduction, total-resource equality, calibrated worst-case runtime or cheapest algorithm is inferred.']}

    def recheck_inputs(self):
        for row in self.files:
            need(sha(Path(row['path']).read_bytes()) == row['sha256'], 'input changed during summary: ' + row['path'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--service-frontier', type=Path)
    parser.add_argument('--original-frontier', type=Path)
    parser.add_argument('--cache-observation', type=Path)
    parser.add_argument('--cache-journal', type=Path)
    parser.add_argument('--source-inventory', type=Path)
    parser.add_argument('--expected-head')
    parser.add_argument('--native-fixture', type=Path)
    args = parser.parse_args()
    reader = Reader()
    result = {'schema': 'trnm-machine-evidence-readonly-summary-v1',
              'status': 'SUMMARY_ONLY', 'model_or_proof_reexecution_performed': False,
              'native_node_or_QPU_executed_by_reader': False,
              'calibration_or_economic_qualification_inferred': False}
    try:
        need(any((args.service_frontier, args.original_frontier, args.cache_observation)), 'no result inputs supplied')
        need(bool(args.cache_observation) == bool(args.cache_journal), 'cache observation and journal must be supplied together')
        need(not args.expected_head or args.source_inventory, '--expected-head requires source inventory')
        if args.source_inventory:
            result['outer_source_inventory'] = reader.load_inventory(args.source_inventory, args.expected_head)
        if args.native_fixture:
            raw, meta = reader.raw(args.native_fixture, 64 * 1024 * 1024)
            fixture = strict_load(raw)
            reader.bind_fixture(sha(raw))
            native_source = fixture['native_source']
            need(type(native_source) is dict and native_source['worktree_status'] == '',
                 'native fixture reports a dirty source tree')
            digest_string(native_source['binary_sha256'], 'native fixture ELF digest')
            need(type(native_source['git_head']) is str
                 and re.fullmatch(r'[0-9a-f]{40}', native_source['git_head']) is not None,
                 'native fixture HEAD')
            if reader.inventory_source is not None:
                need(native_source['git_head'] == reader.inventory_source['head'],
                     'native fixture HEAD differs from outer source inventory')
            reader.source_map(native_source['source_sha256'])
            result['native_fixture_input'] = {'input': meta, 'native_source': native_source,
                'compiler_source_binding_not_reproved_by_reader': True}
        if args.original_frontier:
            result['original_frontier'] = reader.frontier(args.original_frontier, 'original')
        if args.service_frontier:
            result['service_frontier'] = reader.frontier(args.service_frontier, 'service')
        if args.cache_observation:
            result['cache_observation'] = reader.cache(args.cache_observation, args.cache_journal)
        reader.recheck_inputs()
        result['source_identities'] = dict(sorted(reader.sources.items()))
        result['source_binding'] = ('matched supplied outer tracked-source inventory'
                                    if reader.inventory is not None else 'cross-input hash agreement only; no outer HEAD authentication')
        result['input_files'] = reader.files
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False))
        return 0
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        print(json.dumps({'schema': result['schema'], 'status': 'REFUSED',
                          'error': type(error).__name__ + ': ' + str(error),
                          'inputs_read': reader.files, 'missing_counts_were_not_filled': True,
                          'model_or_proof_reexecution_performed': False},
                         ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
