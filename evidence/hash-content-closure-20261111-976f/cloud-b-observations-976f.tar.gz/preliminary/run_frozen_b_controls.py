#!/usr/bin/env python3
"""Run only requested read-only gates through the repository's original recorder."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import threading

ROOT = Path('/workspace/scratch/976f20cefa32/chain-hash')
OUT = Path('/workspace/scratch/976f20cefa32/validation/frozen-b-controls')
SOURCE = '9fd6ee29a7a663cef547040d9d42cc36a371a17e'
RECORDER = 'scripts/ci/record_pq_native_command.py'
PYTHON = 'python3'
GATES = [
    ('b-vectors', [PYTHON, 'scripts/ci/check_content_commitment_vectors.py']),
    ('b-graph-vectors', [PYTHON, 'scripts/ci/check_cell_content_graph_vectors_v3.py']),
    ('b-hash-purpose-controls', [PYTHON, 'scripts/ci/test_hash_use_contract.py']),
    ('b-hash-purpose-source', [PYTHON, 'scripts/ci/hash_use_contract.py']),
    ('b-authority-controls', [PYTHON, 'scripts/ci/test_pq_authority_effect_register.py']),
    ('b-authority-source', [PYTHON, 'scripts/ci/pq_authority_effect_register.py']),
    ('b-root-dependency-source', [PYTHON, 'scripts/ci/pq_root_dependency_register.py']),
    ('b-current-qrom-source', [PYTHON, 'scripts/w1_qrom_current_implementation_audit.py']),
    ('b-corpus-source', [PYTHON, 'scripts/ci/check_pq_research_integration.py']),
    ('b-corpus-controls', [PYTHON, 'scripts/ci/test_pq_research_integration.py']),
    ('b-source-controls', [PYTHON, 'scripts/ci/test_ci_source_integrity.py']),
    ('b-recorder-controls', [PYTHON, 'scripts/ci/test_record_pq_native_command.py']),
    ('b-repository', [PYTHON, 'scripts/ci/check_repository.py']),
    ('b-ci-contract-source', [PYTHON, 'scripts/ci/check_ci_contract.py']),
    ('b-ci-contract-controls', [PYTHON, 'scripts/ci/test_ci_contract.py']),
    ('b-inventory', [PYTHON, 'scripts/refresh_distributed_source_inventory.py', '--check']),
    ('b-format', ['cargo', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check']),
    ('b-workspace-metadata', ['cargo', 'metadata', '--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml', '--format-version', '1']),
    ('b-workspace-all-features-metadata', ['cargo', 'metadata', '--locked', '--offline', '--all-features', '--manifest-path', 'trillionnium/Cargo.toml', '--format-version', '1']),
    ('b-fuzz-metadata', ['cargo', 'metadata', '--locked', '--offline', '--manifest-path', 'tests/fuzz/Cargo.toml', '--format-version', '1']),
    ('b-rustc-version', ['rustc', '-Vv']),
]

STOP = threading.Event()
LOCK = threading.Lock()


def one(entry):
    label, command = entry
    if STOP.is_set():
        return {'label': label, 'status': 'NOT_STARTED', 'reason': 'earlier recorder/source failure'}
    if shutil.disk_usage(OUT).free < 32 * 1024 * 1024:
        STOP.set()
        return {'label': label, 'status': 'NOT_STARTED', 'reason': 'less than 32 MiB free'}
    env = dict(os.environ)
    env.update(RUSTUP_HOME='/workspace/scratch/976f20cefa32/toolchain/rustup',
               CARGO_HOME='/workspace/scratch/976f20cefa32/toolchain/cargo',
               CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
               CARGO_TARGET_DIR='/workspace/scratch/976f20cefa32/target')
    env['PATH'] = env['CARGO_HOME'] + '/bin:' + env['PATH']
    argv = [PYTHON, RECORDER, '--kind', 'head', '--candidate', SOURCE,
            '--tested', SOURCE, '--label', label, '--output', str(OUT), '--', *command]
    started = datetime.now(timezone.utc).isoformat()
    with LOCK:
        print(json.dumps({'label': label, 'status': 'STARTING', 'started_utc': started}), flush=True)
    driver_log = OUT / (label + '.driver.log')
    with driver_log.open('xb') as stream:
        result = subprocess.run(argv, cwd=ROOT, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, check=False)
    receipt_file = OUT / (label + '.json')
    receipt = json.loads(receipt_file.read_text()) if receipt_file.is_file() else {}
    record = {'label': label, 'driver_exit': result.returncode,
              'command_exit': receipt.get('exit_code'), 'status': receipt.get('status', 'NO_RECEIPT'),
              'receipt': str(receipt_file), 'started_utc': started,
              'finished_utc': datetime.now(timezone.utc).isoformat()}
    if record['status'] in ('record_failed', 'NO_RECEIPT', 'running'):
        STOP.set()
        record['error'] = receipt.get('error')
    with LOCK:
        print(json.dumps(record), flush=True)
    return record


if __name__ == '__main__':
    preflight = json.loads((OUT / 'b-preflight.json').read_text())
    assert preflight['status'] == 'command_succeeded' and preflight['exit_code'] == 0
    assert preflight['before'] == preflight['after']
    assert preflight['before']['tested_commit'] == SOURCE
    for label, _ in GATES:
        assert not (OUT / (label + '.json')).exists(), label
        assert not (OUT / (label + '.driver.log')).exists(), label
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = {pool.submit(one, item): item[0] for item in GATES}
        rows = [future.result() for future in as_completed(futures)]
    rows.sort(key=lambda row: row['label'])
    report = {'source': SOURCE, 'scope': 'read-only gates only; no native runtime execution',
              'maximum_parallel_commands': 2, 'commands': rows,
              'all_commands_succeeded': all(row['status'] == 'command_succeeded' for row in rows)}
    with (OUT / 'controls-summary.json').open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'result': 'PASS' if report['all_commands_succeeded'] else 'FAIL',
                      'commands': len(rows), 'summary': str(OUT / 'controls-summary.json')}), flush=True)
    raise SystemExit(0 if report['all_commands_succeeded'] else 1)
