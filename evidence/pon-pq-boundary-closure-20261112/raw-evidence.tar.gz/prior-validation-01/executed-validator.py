#!/usr/bin/env python3
"""Retain exact-source PQ component observations without granting qualification."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import types

PROVIDER_HELPER = Path('/home/qian-qi/work/w1-baseline-9082-validation-165d/supplemental-provider-clippy/helpers/supplemental-provider-clippy-165d.py')
PROVIDER_HELPER_SHA256 = '363fa66725ddedf2a6fa1e34b785b31c2e8ddeaa767f058766b2037c0f4ea492'
TCV3_TESTS = tuple('cell::version_content_closure_v3::tests::' + name for name in (
    'tcv3_cold_cache_reads_full_model_environment_and_explicit_ancestor',
    'tcv3_missing_parent_is_not_an_origin_or_legacy_digest_wrapper',
    'tcv3_checks_independent_full_pin_and_exact_selected_roots_before_scanning',
    'tcv3_rejects_duplicate_legacy_alias_even_when_strong_claims_differ',
    'tcv3_alternate_ancestor_content_changes_root_and_cannot_pass_actual_scan',
    'tcv3_unreachable_extra_origin_and_non_decreasing_parent_generation_refuse',
    'tcv3_foreign_family_cannot_be_imported_as_an_ancestor',
    'tcv3_shared_transitive_ancestor_is_scanned_once_per_declared_version',
    'tcv3_graph_rejects_cycle_and_overdeep_paths_including_shared_subgraphs',
    'tcv3_member_scans_share_the_original_finite_session',
    'tcv3_failed_late_member_keeps_both_reservations_and_no_partial_readback',
    'tcv3_requires_exact_retained_owner_set_epoch_and_window_before_reads',
    'tcv3_missing_actual_cache_bytes_refuse_despite_complete_pinned_metadata',
    'tcv3_namespace_canonical_order_counts_and_all_byte_boundaries_are_strict',
    'tcv3_commitment_matches_independent_python_vector_without_tcv2_domain_alias',
))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def put(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--head', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root, out = args.root.resolve(), args.output.resolve()
    assert out.is_absolute() and not out.is_relative_to(root)
    out.mkdir(exist_ok=False)
    os.chdir(root)
    os.environ['PATH'] = '/home/qian-qi/.cargo/bin:' + os.environ['PATH']
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    os.environ['GIT_NO_LAZY_FETCH'] = '1'
    os.environ['CARGO_TARGET_DIR'] = '/home/qian-qi/work/w1-baseline-9082-target-165d'
    os.environ['CARGO_BUILD_JOBS'] = '2'
    os.environ['CARGO_TERM_COLOR'] = 'never'
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root / 'scripts/ci'))
    from verify_ci_source import verify
    from check_required_native_test import validate as check_native
    result = {'schema': 'trnm-pq-boundary-component-observations-v1',
              'source': args.head, 'commands': [], 'failures': [],
              'qualification': 'HOLD', 'whole_chain_pq_qualified': False,
              'actual_lifetime_failure_bound': None, 'production_activation': False,
              'target_reused': True, 'ordinary_caller_switched': False,
              'source_observation_scope': 'complete batch before and after; not live executable attestation'}
    (out / 'executed-validator.py').write_bytes(Path(__file__).read_bytes())

    def source(label):
        value = verify('head', args.head, None, None, root)
        put(out / (label + '.json'), value)
        return value

    def run(label, argv, timeout=600, fatal=False, python_count=None, python_suite=False, native_name=None):
        print(json.dumps({'started': label}), flush=True)
        started = time.monotonic_ns()
        log = out / (label + '.log')
        with log.open('xb') as stream:
            process = subprocess.run(['timeout', '--kill-after=20', str(timeout)] + argv,
                                     cwd=root, stdout=stream, stderr=subprocess.STDOUT)
        row = {'label': label, 'argv': argv, 'timeout_seconds': timeout,
               'exit_code': process.returncode, 'elapsed_ns': time.monotonic_ns() - started,
               'log': log.name, 'log_bytes': log.stat().st_size, 'log_sha256': sha(log)}
        passed = process.returncode == 0
        text = None
        if python_count is not None or python_suite or native_name is not None or label.endswith('-lib') or label == 'checkpoint-tests':
            text = log.read_text(errors='replace')
        if python_count is not None or python_suite:
            counts = [int(n) for n in re.findall(r'(?m)^Ran (\d+) tests? in ', text)]
            row['python_test_counts'] = counts
            counts_valid = counts == [python_count] if python_count is not None else len(counts) == 1 and counts[0] > 0
            passed = passed and counts_valid and re.search(r'(?m)^OK\s*$', text) is not None
        if native_name is not None:
            try:
                row['named_execution'] = check_native(text.splitlines(), native_name)
            except ValueError as error:
                passed = False
                row['reader_error'] = str(error)
        if label.endswith('-lib') or label == 'checkpoint-tests':
            summaries = [tuple(map(int, m)) for m in re.findall(
                r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text)]
            row['native_summaries'] = [dict(zip(('passed', 'failed', 'ignored', 'measured', 'filtered_out'), m)) for m in summaries]
            passed = passed and bool(summaries) and sum(m[0] for m in summaries) > 0 and all(m[1] == 0 for m in summaries)
            if label.startswith('da-'):
                coverage = {name: re.findall(r'(?m)^test ' + re.escape(name) + r' \.\.\. (\S+)\s*$', text)
                            for name in TCV3_TESTS}
                row['tcv3_named_executions'] = coverage
                passed = passed and len(TCV3_TESTS) == len(set(TCV3_TESTS)) == 15
                passed = passed and all(states == ['ok'] for states in coverage.values())
                passed = passed and len(summaries) == 1 and summaries[0][3:] == (0, 0)
        row['component_check_passed'] = bool(passed)
        put(out / (label + '.json'), row)
        result['commands'].append(row)
        with (out / 'commands.jsonl').open('a') as stream:
            stream.write(json.dumps(row, sort_keys=True) + '\n')
        if not passed:
            result['failures'].append(label)
        print(json.dumps({'finished': label, 'exit_code': process.returncode, 'passed': bool(passed)}), flush=True)
        if fatal and not passed:
            raise RuntimeError(label + ': prerequisite failed')
        return row

    try:
        result['source_before'] = source('source-before')
        run('preflight', ['bash', 'scripts/project-preflight.sh'], fatal=True)
        raw = PROVIDER_HELPER.read_bytes()
        assert len(raw) == 18226 and hashlib.sha256(raw).hexdigest() == PROVIDER_HELPER_SHA256
        (out / 'provider-helper.py').write_bytes(raw)
        module = types.ModuleType('reviewed_provider')
        module.__file__ = str(PROVIDER_HELPER)
        inherited = dict(os.environ)
        exec(compile(raw, str(PROVIDER_HELPER), 'exec'), module.__dict__)
        assert dict(os.environ) == inherited
        selection = module.check_inherited_environment(inherited)
        assert selection['compatible'], 'provider selection conflicts'
        result['provider_selection'] = selection
        result['provider_before'] = module.provider_identity()
        assert result['provider_before']['all_five_match']
        os.environ.update(module.expected_environment())
        disallowed = ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER')
        result['compiler_override_names'] = [key for key in disallowed if os.environ.get(key)]
        assert not result['compiler_override_names'], 'unreviewed compiler override'
        run('rust-version', ['rustc', '+1.95.0', '-vV'], 30, fatal=True)
        assert '\nrelease: 1.95.0\n' in (out / 'rust-version.log').read_text()
        run('cargo-version', ['cargo', '+1.95.0', '--version'], 30, fatal=True)
        run('graphs-unchanged', ['git', 'diff', '--exit-code', '8970e2c81abbf48e2a4d3f0802d79624ab20fadd', args.head,
                               '--', 'trillionnium/Cargo.toml', 'trillionnium/Cargo.lock', 'tests/fuzz/Cargo.toml',
                               'tests/fuzz/Cargo.lock', 'rust-toolchain.toml'], fatal=True)
        cargo = ['cargo', '+1.95.0']
        manifest = ['--manifest-path', 'trillionnium/Cargo.toml']
        graph = cargo + ['metadata', '--locked', '--offline', '--format-version', '1'] + manifest
        run('graph-default', graph, 300, fatal=True)
        run('graph-all-features', graph + ['--all-features'], 300, fatal=True)
        run('graph-fuzz', cargo + ['metadata', '--locked', '--offline', '--format-version', '1', '--manifest-path', 'tests/fuzz/Cargo.toml'], 300, fatal=True)
        run('formatting', cargo + ['fmt'] + manifest + ['--all', '--', '--check'], 300)
        python = ['python3', '-B']
        for label, path, count in (
            ('source-negatives', 'scripts/ci/test_ci_source_integrity.py', 43),
            ('lifetime-controls', 'scripts/ci/test_pq_lifetime_budget.py', 58),
            ('root-register-controls', 'scripts/ci/test_pq_root_dependency_register.py', 43),
        ):
            run(label, python + [path, '-v'], 600, python_count=count)
        for label, path in (
            ('ci-contract-controls', 'scripts/ci/test_ci_contract.py'),
            ('corpus-controls', 'scripts/ci/test_pq_research_integration.py'),
            ('claim-controls', 'scripts/ci/test_pq_chain_claim_guard.py'),
        ):
            run(label, python + [path, '-v'], 600, python_suite=True)
        for label, command in (
            ('ci-contract', python + ['scripts/ci/check_ci_contract.py']),
            ('corpus-current', python + ['scripts/ci/check_pq_research_integration.py']),
            ('lifetime-current', python + ['scripts/ci/pq_lifetime_budget.py']),
            ('root-register-current', python + ['scripts/ci/pq_root_dependency_register.py']),
            ('claim-current', python + ['scripts/ci/pq_chain_claim_guard.py']),
            ('native-inventory', python + ['scripts/refresh_distributed_source_inventory.py', '--check']),
            ('repository-links', python + ['scripts/ci/check_repository.py']),
            ('whitespace', ['git', 'diff', '--check', '8970e2c81abbf48e2a4d3f0802d79624ab20fadd', args.head]),
        ):
            run(label, command, 600)
        run('preflight-native', ['bash', 'scripts/project-preflight.sh'], fatal=True)
        before_native = source('source-before-native')
        assert before_native == result['source_before']
        put(out / 'tcv3-frozen-native-roster.json', {'tests': TCV3_TESTS, 'unique_methods': 15})
        run('da-default-lib', cargo + ['test', '--locked', '--offline'] + manifest + ['-p', 'trnm-data-availability', '--lib', '--', '--format', 'pretty'], 1800)
        run('da-all-features-lib', cargo + ['test', '--locked', '--offline'] + manifest + ['-p', 'trnm-data-availability', '--lib', '--all-features', '--', '--format', 'pretty'], 1800)
        run('checkpoint-tests', cargo + ['test', '--locked', '--offline'] + manifest + ['-p', 'trnm-checkpoint-store', '--tests', '--all-features'], 1200)
        retained = json.loads((root / 'config/pon/pq-system-required-tests-v1.json').read_bytes())
        supplement = json.loads((root / 'config/pon/pq-system-supplemental-tests-v1.json').read_bytes())
        assert retained['expected_meaningful_controls'] == len(retained['tests']) == 52
        assert supplement['expected_meaningful_controls'] == len(supplement['tests']) == 11
        names = retained['tests'] + supplement['tests']
        assert len(set(names)) == 63
        put(out / 'native-pq-exact-roster.json', {'retained': retained, 'supplement': supplement, 'tests': names})
        for index, name in enumerate(names):
            run(f'pq-native-{index:02d}', cargo + ['test', '--locked', '--offline'] + manifest + [
                '-p', 'trnm-pon-node', '--lib', '--all-features', name, '--', '--exact', '--show-output', '--test-threads=1'],
                1200, native_name=name)
        run('strict-clippy', cargo + ['clippy', '--locked', '--offline'] + manifest + [
            '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings'], 3600)
        result['provider_after'] = module.provider_identity()
        assert result['provider_after'] == result['provider_before'], 'provider inputs changed'
        result['source_after'] = source('source-after')
        assert result['source_after'] == result['source_before'], 'source changed'
        result['all_requested_component_checks_passed'] = not result['failures']
        result['completed'] = True
    except Exception as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
        result['completed'] = False
        result['all_requested_component_checks_passed'] = False
    finally:
        result['artifact_files'] = {str(p.relative_to(out)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
                                    for p in sorted(out.rglob('*')) if p.is_file()}
        put(out / 'validation.json', result)
    print(json.dumps({'completed': result['completed'], 'failed': result['failures'],
                      'error': result.get('error'), 'commands': len(result['commands'])}), flush=True)
    return 0 if result['all_requested_component_checks_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
