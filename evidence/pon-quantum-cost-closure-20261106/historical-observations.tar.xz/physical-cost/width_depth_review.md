# Read-only review of width/depth capacity checks

No repository source was changed during this follow-up. The review covers the existing declared gate-schedule model, not arbitrary alternate circuit-depth conventions.

## Toffoli depth and Clifford gates

`reversible_components.Circuit.metrics()` computes `tlayer = max(tdepth[q] for q in wires) + (op == 3)` and assigns that label to **all** used wires for every gate. X and CNOT add zero Toffoli cost, but still propagate the maximum dependency label; no wire label decreases.

If two Toffolis share a wire and the first has label k, the second must have label at least k+1. Therefore all Toffolis with the same label occupy disjoint triples of wires, even when arbitrary zero-cost Clifford operations occur between them. With Q declared live wires and maximum Toffoli label D_F, each label can contain at most floor(Q/3) Toffolis, proving F <= floor(Q/3)*D_F for these metrics. Ignoring Clifford **cost** does not ignore wire conflicts or reset dependency labels.

This is not a claim about a Toffoli decomposition's optimized T-depth, an alternative gate model that permits shared-wire simultaneous operations, measurement-assisted transformations, or depth metrics computed after dropping wire dependencies. Those would require a different contract and their own checks. The current field and constructor use Toffoli dependency depth, not decomposition T-depth.

## Overall gate width

The all-gate metric increments every used wire's maximum depth by one. Gates with one all-gate layer label cannot share a wire. Every counted gate occupies at least one wire; a Toffoli occupies three. Thus G+2F <= Q*D is necessary. There is no separate CNOT count in the resource input, so the check intentionally treats every non-Toffoli as occupying only one wire. It can accept other unrealizable schedules and does not prove feasibility; it does not incorrectly reject a valid schedule because CNOT's second wire was omitted.

The analogous direct-T bound T <= Q*D_T assumes the declared direct-T depth retains same-wire dependency, consistent with a T-layer schedule.

## Serial aggregation and peak width

For valid stages i, let widths be Q_i, depths D_i, Toffoli depths D_Fi, and nonnegative repetition counts m_i. `account()` and `_sum_circuits()` add counts and corresponding depths with the same multipliers, including prepare calls and both winner compute directions, and use Q=max(Q_i).

Summing each stage inequality gives:

- sum m_i*(G_i+2F_i) <= sum m_i*Q_i*D_i <= Q*sum m_i*D_i;
- sum m_i*F_i <= sum m_i*floor(Q_i/3)*D_Fi <= floor(Q/3)*sum m_i*D_Fi;
- sum m_i*T_i <= Q*sum m_i*D_Ti.

Hence aggregation with peak width preserves all three inequalities. It need not add widths for serial stages. This argument still depends on the existing premise that each stage's declared width includes every live persistent register and stage register allocations are compatible. The capacity check cannot establish those premises.

## Exact scope of the no-false-rejection conclusion

No false rejection was found for actual gate counts and conservative depth upper bounds describing the **same** declared schedule under the current wire-exclusion metric. Increasing a valid depth upper bound or the declared width only relaxes these constraints. The current W1 constructor reports actual wrapped primitive gate counts and sums conservative depths, which matches this case.

This conclusion does **not** extend to unrelated loose count ceilings paired with an independently tight depth ceiling: such pairs need not obey a packing inequality even when some smaller real circuit meets both ceilings. They are excluded by the current schedule-accounting contract (and the pre-existing count/subtotal/count-depth consistency conventions). A future API explicitly accepting independent ceilings would need separate semantics rather than reusing this validator unchanged. The checks also cannot verify that an asserted circuit implements W1 or is fault tolerant.
