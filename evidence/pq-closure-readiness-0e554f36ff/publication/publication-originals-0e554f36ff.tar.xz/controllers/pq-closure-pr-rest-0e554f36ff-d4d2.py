#!/usr/bin/env python3
"""Update only the reviewed PR body after a known gh classic-Projects failure."""
import hashlib
import importlib.util
import json
from pathlib import Path
import traceback

PUBLISHER = Path('/data/pq-closure-publish-0e554f36ff-d4d2.py')
assert hashlib.sha256(PUBLISHER.read_bytes()).hexdigest() == 'ab9ce16c25cd17140a1af6e2b28565e80eb33ddb5a5704a1ef7ac34241cfa5b4'
spec = importlib.util.spec_from_file_location('published_source_observer', PUBLISHER)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
original = m.OUT
out = Path('/data/pq-closure-pr-rest-0e554f36ff-d4d2')
assert not out.exists()
assert 'Projects (classic) is being deprecated' in (original / 'update-pr-body.stderr.log').read_text()
assert json.loads((original / 'update-pr-body.receipt.json').read_text())['exit_code'] == 1
assert json.loads((original / 'push-c2.receipt.json').read_text())['exit_code'] == 0
assert (original / 'remote-after.stdout.log').read_text().split() == [m.C2, 'refs/heads/' + m.BRANCH]
assert m.sha(m.BODY.read_bytes()) == m.BODY_SHA
out.mkdir(mode=0o700)
m.OUT = out
try:
    m.write('source-before.json', m.identity())
    m.run('preflight', ['bash', 'scripts/project-preflight.sh'])
    actor = m.run('actor', ['gh', 'api', 'user', '--jq', '.login']).strip()
    m.require(actor == 'ProfHepta', 'wrong GitHub actor')
    endpoint = 'repos/' + m.REPO + '/pulls/901'
    before = json.loads(m.run('pr-before', ['gh', 'api', endpoint]))
    m.require(before['head']['sha'] == m.C2 and before['head']['ref'] == m.BRANCH
              and before['base']['sha'] == m.BASE and before['draft'] is True,
              'PR source identity changed')
    m.require(m.sha(before['body'].strip().encode()) == m.INITIAL_BODY_NORMALIZED_SHA,
              'PR body changed; preserve concurrent content')
    m.write('body.json', {'body': m.BODY.read_text()})
    patched = json.loads(m.run('update-pr-rest', ['gh', 'api', '--method', 'PATCH', endpoint,
                                                '--input', str(out / 'body.json')]))
    m.require(patched['head']['sha'] == m.C2 and patched['draft'] is True
              and patched['body'].strip() == m.BODY.read_text().strip(), 'PATCH response mismatch')
    after = json.loads(m.run('pr-after', ['gh', 'api', endpoint]))
    m.require(after['head']['sha'] == m.C2 and after['draft'] is True
              and after['body'].strip() == m.BODY.read_text().strip(), 'persisted PR body mismatch')
    m.write('source-after.json', m.identity())
    summary = {'schema': 'TRNM-C2-PR-REST-CORRECTION1', 'source': {'commit':m.C2,'tree':m.TREE},
               'actor': actor, 'pull_request': after['html_url'], 'draft': True,
               'original_gh_pr_edit_failed': True,
               'original_error': 'deprecated Projects classic GraphQL field repository.pullRequest.projectCards',
               'original_failure_preserved': True, 'push_repeated': False,
               'reviewed_body_sha256': m.BODY_SHA, 'rest_patch_completed_and_read_back': True,
               'whole_chain_pq_qualified': False, 'production_activation': False,
               'commands': m.ROWS, 'finished_utc': m.now()}
    m.write('summary.json', summary)
    print(json.dumps({k:v for k,v in summary.items() if k != 'commands'}), flush=True)
except BaseException as error:
    m.write('failure.json', {'error_type':type(error).__name__,'message':str(error),
                             'traceback':traceback.format_exc(),'commands':m.ROWS,
                             'finished_utc':m.now(),'inspect_actual_pr_before_any_retry':True})
    raise
