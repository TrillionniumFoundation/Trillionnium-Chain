#!/usr/bin/env python3
"""Aggregate exact C1 development evidence without replaying builds or proofs."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import time

ROOT = Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
REPO = ROOT / "integration-repo"
BASE = ROOT / "clean-C1-build-qualification-01"
OUT = Path(__file__).resolve().parent
HEAD = "cb557c5e59b00ba7c6b1d40f78fbe51031a26f11"
TREE = "7971aca2ff432ec8907bb69545a2c58d70b4a215"
SOURCE_SHA = "8b0b39f3cc9a224badcf9aae1924327c7618f431ec25e6133a5d86e5e63a9fc7"
GUEST_SHA = "25718312ec3c6f5219d832e3516adfb5f82983156f669c5e7daa15bd22d1798f"
R0_SHA = "2acdf550f9aca4d05b74072463e4ed307c3824309c754a5cb5f93aa84f3390e6"
IMAGE = [1958252411, 3287394615, 1805488136, 1516578702, 78549041, 790278610, 301018785, 4279049364]
MANIFESTS = {
    "backend": ("backend-validation/exact-integration-cb557c5e59b0-01/manifest.json", "26e049dbec77cf2da98ddf7a26457c60619bafb71060b201688af83a3d33f3b6"),
    "native": ("clean-integration-native-verifier-cb557c5e59b0-01/manifest.json", "474dcad256dc85fdc3506a5856c2035c251bab7a03a8dcb2ca150b2f7f904e1c"),
    "owner": ("clean-C1-build-qualification-01/owner-node-m12-01/manifest.json", "bf50f155c47001c2db5e7350ee38ab5c5b3f709b143112cb9880415358100606"),
    "ci": ("integration-validation/exact-c1-cb557c5e-01/aggregate.json", "594141b30e36cf7a01406e6210ca556cd0d4b755b3eac8073fac035fe29f773a"),
    "native_reassessment": ("native-verifier-count-reassessment-cb557c5e59b0-01/assessment.json", "a5c357ab2c885cf12b0d85c691f4387f302d5cf86eda1faad700b6a623c36e76"),
}
JOBS = {
    "backend": "1a1b7bdf4de-12894-c18", "native": "1a1b7be3312-12894-c19",
    "owner": "1a1b7c086c0-12894-c21", "ci": "1a1b7c08db9-12894-c22",
    "native_reassessment": "1a1b7d02260-12894-c67",
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def pin(path, elf=False):
    p = Path(path)
    before = p.lstat()
    require(stat.S_ISREG(before.st_mode), "ordinary file required: " + str(p))
    digest = hashlib.sha256()
    with p.open("rb") as f:
        if elf:
            header = f.read(64)
            require(header[:6] == b"\x7fELF\x02\x01" and int.from_bytes(header[18:20], "little") == 62
                    and before.st_mode & 0o111, "actual executable x86_64 ELF required")
            f.seek(0)
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    after = p.lstat()
    fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    require(all(getattr(before, k) == getattr(after, k) for k in fields), "file changed while hashing")
    return {"path": str(p), "bytes": before.st_size, "sha256": digest.hexdigest()}


def check(record, elf=False):
    p = pin(record["path"], elf)
    require(p["sha256"] == record["sha256"]
            and ("bytes" not in record or p["bytes"] == record["bytes"]), "retained file pin mismatch")
    return p


def save(path, value):
    path = Path(path)
    with path.open("x") as f:
        json.dump(value, f, sort_keys=True, indent=2, allow_nan=False)
        f.write("\n"); f.flush(); os.fsync(f.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return pin(path)


def guard(row):
    path = row.get("report_path", row.get("path"))
    p = check({"path": path, "sha256": row["sha256"]})
    data = json.loads(Path(path).read_bytes())
    require(p["sha256"] == SOURCE_SHA and data["schema"] == "trnm-ci-source-v1"
            and data["kind"] == "head" and data["tested_commit"] == HEAD
            and data["candidate"] == HEAD and data["tested_tree"] == TREE
            and data["tracked_worktree_verified"] is True
            and data["tests_executed_by_identity_check"] is False, "full raw C1 source identity required")
    if "report" in row:
        require(data == row["report"], "embedded source report differs from raw report")
    return {"report_path": path, "sha256": p["sha256"], "bytes": p["bytes"],
            "tested_commit": HEAD, "tested_tree": TREE}


def normalize(name, row, manifest_pin):
    exit_code = row["exit_code"] if "exit_code" in row else row["exit"]
    require(type(exit_code) is int and exit_code == 0 and not row.get("timed_out", False)
            and row.get("error") is None and row.get("accepted", True) is True,
            "all actual constituent commands must succeed")
    require(isinstance(row["argv"], list) and row["argv"] and all(type(x) is str for x in row["argv"]),
            "raw command argv required")
    logs = {}
    for key in ("stdout", "stderr"):
        if key + ".log" in row:
            selected = row[key + ".log"]
        elif key in row and isinstance(row[key], dict):
            selected = row[key]
        else:
            selected = {"path": row[key + "_path"], "sha256": row[key + "_sha256"]}
        logs[key] = check(selected)
    return {"component": name, "label": name + "/" + row["label"], "original_label": row["label"],
            "argv": row["argv"], "cwd": row.get("cwd", str(REPO)), "exit": 0,
            "stdout_path": logs["stdout"]["path"], "stdout_sha256": logs["stdout"]["sha256"],
            "stderr_path": logs["stderr"]["path"], "stderr_sha256": logs["stderr"]["sha256"],
            "raw_component_manifest": manifest_pin}


def main():
    os.sched_setaffinity(0, {10, 11})
    attempt = {"schema": "TRNM-W1-C1-AGGREGATE-ATTEMPT1", "source_commit": HEAD, "source_tree": TREE,
               "completed": False, "commands": [], "errors": [], "wrapper": pin(__file__),
               "fresh_proof_generations": 0, "test_bodies_executed": False}
    env = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C", "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        def run(label, argv, timeout=180):
            stdout, stderr = OUT / (label + ".stdout"), OUT / (label + ".stderr")
            with stdout.open("xb") as so, stderr.open("xb") as se:
                r = subprocess.run(argv, cwd=REPO, env=env, stdout=so, stderr=se,
                                   stdin=subprocess.DEVNULL, timeout=timeout, check=False)
                so.flush(); os.fsync(so.fileno()); se.flush(); os.fsync(se.fileno())
            row = {"label": "aggregate/" + label, "argv": argv, "cwd": str(REPO), "exit": r.returncode,
                   "stdout_path": str(stdout), "stdout_sha256": pin(stdout)["sha256"],
                   "stderr_path": str(stderr), "stderr_sha256": pin(stderr)["sha256"]}
            attempt["commands"].append(row)
            require(r.returncode == 0, label + " failed")
            return stdout, stderr

        run("preflight", ["/usr/bin/bash", "scripts/project-preflight.sh", "--dev"])
        run("source-before", ["/usr/bin/python3", "scripts/ci/verify_ci_source.py", "--kind", "head",
                             "--expected-head", HEAD, "--output", str(OUT / "source-before.json")])
        source_before = guard(pin(OUT / "source-before.json"))
        statuses = {}
        for name, job_id in JOBS.items():
            raw = OUT / ("terminal-" + name + ".json")
            value = json.loads(raw.read_bytes())
            require(value["job_id"] == job_id and value["output_complete"] is True
                    and value["output_durable"] is True and value["timed_out"] is False
                    and value["cancelled"] is False, "actual complete durable terminal required")
            expected = ("failed", 1) if name == "native" else ("succeeded", 0)
            require((value["state"], value["exit_code"]) == expected, "original terminal changed")
            statuses[name] = {"raw": pin(raw), "status": value}
        status_pin = save(OUT / "gate-job-statuses.json", statuses)
        manifests, manifest_pins = {}, {}
        for name, (relative, digest) in MANIFESTS.items():
            p = check({"path": str(ROOT / relative), "sha256": digest})
            value = json.loads(Path(p["path"]).read_bytes())
            if name == "ci":
                require(value["expected_head"] == HEAD and value["expected_tree"] == TREE,
                        "CI expected source identity")
            else:
                require(value["source_commit"] == HEAD and value["source_tree"] == TREE,
                        "component exact source identity")
            manifests[name], manifest_pins[name] = value, p
        b, n, o, ci, reassessment = [manifests[k] for k in ("backend", "native", "owner", "ci", "native_reassessment")]
        require(b["qualification_complete"] is True and b["errors"] == []
                and b["test_result"]["passed"] == 22 and b["test_result"]["failed"] == 0
                and b["test_result"]["ignored"] == 0, "backend exact gates")
        require(o["qualification_complete"] is True and o["errors"] == [] and o["fresh_cargo_target"] is False
                and o["test_counts"] == {"node_passed": 15, "node_explicit_ignored": 3, "m12_passed": 10, "m12_ignored": 0},
                "owner exact gates")
        require(ci["all_passed"] is True and ci["executed_checks"] == ci["planned_checks_including_source_after"] == 19
                and ci["source_identity_equal_before_after"] is True and ci["frozen_candidate_bytes_unchanged"] is True
                and ci["selected_test_methods_planned"] == 461 and ci["mandatory_test_methods_planned"] == 94,
                "CI exact nineteen checks and method counts")
        require(n["passed"] is False and n["source_clean_after"] is True and n["locks_unchanged"] is True
                and set(n["binaries"]) == {"native_winner", "verifier"}
                and n["test_counts"]["10-native-tests"] == {"groups": 26, "passed": 243, "failed": 0, "ignored": 0}
                and n["test_counts"]["12-verifier-tests"] == {"groups": 1, "passed": 2, "failed": 0, "ignored": 0},
                "original native failure must remain solely the stale count mismatch")
        require(reassessment["accepted"] is True and reassessment["assessment_complete"] is True
                and reassessment["errors"] == [] and reassessment["original_wrapper_status_rewritten"] is False
                and reassessment["original_wrapper_stays_failed_due_stale_A_expected_count"] is True
                and reassessment["actual_native_test_count"] == reassessment["enumerated_test_count"] == 243
                and reassessment["enumerated_group_count"] == 26
                and reassessment["actual_verifier_test_count"] == 2
                and reassessment["actual_real_receiver_controls"] == 7
                and reassessment["all_Cargo_artifacts_cached"] is True
                and reassessment["compilation_performed"] is False
                and reassessment["test_bodies_reexecuted"] is False
                and reassessment["original_failed_C1_manifest"] == manifest_pins["native"],
                "strict independent 243 reassessment required")
        check(reassessment["fixed_expected_roster"])
        check(reassessment["enumeration_stdout"])
        check(reassessment["enumeration_stderr"])
        check(reassessment["enumerated_Cargo_artifacts"])
        for row in reassessment["commands"]:
            normalize("native_reassessment", row, manifest_pins["native_reassessment"])
        normalized = []
        source_guards = {}
        for name, expected_count in (("backend", 13), ("native", 21), ("owner", 14), ("ci", 19)):
            value = manifests[name]
            require(len(value["commands"]) == expected_count, "complete retained command set required")
            normalized.extend(normalize(name, row, manifest_pins[name]) for row in value["commands"])
            source_guards[name] = {phase: guard(value[phase]) for phase in ("source_before", "source_after")}
        for phase in ("source_before", "source_after"):
            guard(reassessment[phase])
        for raw in ci["raw_files"]:
            check(raw)
        require(len(normalized) == 67, "exact current component command count")
        binaries = {}
        for role, row in (("native_winner", n["binaries"]["native_winner"]),
                          ("verifier", n["binaries"]["verifier"]), ("owner_test", o["binaries"]["owner_test"]),
                          ("runner", b["runner"])):
            p = check(row, elf=True)
            require("integration" in p["path"], "no A-built repository ELF may substitute for C1")
            binaries[role] = {**p, "kind": "repository_build", "source_commit": HEAD, "source_tree": TREE,
                              "raw_role_record": row}
        r0 = pin(ROOT / "fixed-backend-01/r0vm", elf=True)
        require(r0["sha256"] == R0_SHA and r0["bytes"] == 108764424, "fixed original upstream r0vm")
        version_out, _ = run("r0vm-version", [r0["path"], "--version"], 60)
        require(version_out.read_text().strip() == "risc0-r0vm 3.0.3", "actual fixed r0vm version")
        binaries["r0vm"] = {**r0, "kind": "fixed_upstream_release", "upstream_version": "3.0.3",
                            "version_stdout": pin(version_out), "newly_built_for_C1": False}
        lock_paths = [
            "trillionnium/Cargo.lock", "formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock",
            "formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock",
            "formal/pon-nakamoto-v1/w1_zkvm/methods/guest/Cargo.lock",
            "formal/pon-nakamoto-v1/w1_zkvm/methods/guest-v2/Cargo.lock",
        ]
        locks = {relative: pin(REPO / relative) for relative in lock_paths}
        nb = json.loads((Path(manifest_pins["native"]["path"]).parent / "locks-before.json").read_bytes())
        na = json.loads((Path(manifest_pins["native"]["path"]).parent / "locks-after.json").read_bytes())
        require(nb == na and all(locks[k]["sha256"] == v for k, v in nb.items()), "native locks changed")
        require(o["locks_before"] == o["locks_after"]
                and locks["trillionnium/Cargo.lock"]["sha256"] == o["locks_before"]["trillionnium/Cargo.lock"]["sha256"],
                "owner lock closure")
        for relative in lock_paths:
            if relative in b["owned_source_before"]:
                require(b["owned_source_before"][relative]["sha256"] == b["owned_source_after"][relative]["sha256"]
                        == locks[relative]["sha256"], "backend lock closure")
        guest = pin(REPO / "evidence/pon-w1-full-v2-20261105/guest.bin")
        require(guest["sha256"] == GUEST_SHA and guest["bytes"] == 375928, "original retained guest bytes")
        require(b["guest_build_provenance"], "actual current build provenance required")
        for row in b["guest_build_provenance"]:
            check(row["original"]); check(row["raw_copy"]); check(row["retained_guest"]); check(row["generated_methods"])
            value = json.loads(Path(row["raw_copy"]["path"]).read_bytes())
            require(value == row["value"] and value["mode"] == "retained-v2-guest"
                    and value["sha256"] == GUEST_SHA and value["image_id"] == IMAGE
                    and value["sdk_image_checked"] is True and value["guest_compilation_performed"] is False,
                    "retained guest SDK qualification")
        guest.update(image_id=IMAGE, guest_compilation_performed=False,
                     build_provenance=b["guest_build_provenance"])
        run("source-after", ["/usr/bin/python3", "scripts/ci/verify_ci_source.py", "--kind", "head",
                            "--expected-head", HEAD, "--output", str(OUT / "source-after.json")])
        source_after = guard(pin(OUT / "source-after.json"))
        require(source_before["sha256"] == source_after["sha256"], "aggregate source changed")
        for name, p in manifest_pins.items():
            check(p)
        for row in binaries.values():
            check(row, elf=True)
        qualification = {
            "schema": "TRNM-W1-CLEAN-BUILD-QUALIFICATION1", "source_commit": HEAD, "source_tree": TREE,
            "repo_path": str(REPO), "qualification_complete": True,
            "source_clean_before": True, "source_clean_after": True,
            "source_before": source_before, "source_after": source_after,
            "commands": normalized + attempt["commands"], "component_successful_command_count": 67,
            "aggregate_observation_command_count": len(attempt["commands"]),
            "binaries": binaries, "locks": locks, "guest": guest,
            "gate_manifests": manifest_pins, "gate_jobs": status_pin, "component_source_guards": source_guards,
            "native_count_reassessment": {
                "assessment": manifest_pins["native_reassessment"], "accepted_current_count": 243,
                "original_A_expected_count": 240, "original_wrapper_passed": False,
                "original_wrapper_terminal": statuses["native"], "original_wrapper_stays_failed": True,
                "all_21_actual_commands_exit_zero": True,
                "basis": "Fixed 243 roster, unchanged all-targets/all-features selector, 26-group Cargo cached enumeration, exact real run names, 0 failed/ignored/filtered, 2 verifier tests and 7 real receiver controls. Original stale-expectation failure and first inspection regex diagnostic remain retained."
            },
            "test_methods_reported": {"backend": 22, "native": 243, "verifier": 2, "real_receiver_controls": 7,
                                      "node": 15, "m12": 10, "ci": 461, "sum": 760,
                                      "owner_heavy_entries_explicitly_ignored": 3},
            "fresh_cargo_target": False, "fresh_cargo_target_basis": "Owner target reused existing cache; per-target observations retained separately.",
            "target_observations": {
                "native": {"path": n["target_dir"], "target_existed_before": n["target_existed_before"],
                           "target_initial_entries": n["target_initial_entries"], "fresh_directory_observed": n["fresh_cargo_target"],
                           "scope": "Directory existence only; shared toolchain and registry cache."},
                "owner": {"path": o["target"], "fresh_directory_observed": False, "cache_reuse_allowed": o["cache_reuse_allowed"]},
                "backend": {"path": b["target_dir"], "fresh_directory_observed": None,
                            "owned_release_fingerprint_observation_before": b["cargo_fingerprints_before"],
                            "cargo_artifact_fresh_rebuilt_readback": b["cargo_json_artifacts"],
                            "scope": "No separate before-build directory-absence observation; never infer cleanroom or fresh-directory history from a new path."}
            },
            "fresh_proof_generations": 0, "guest_compilation_performed": False,
            "independent_reproducible_build_established": False, "original_business_budget_qualified": False,
            "security_qualified": False, "production_qualified": False, "payment_qualified": False,
            "scope": "Exact C1 source/build identities and retained development gates only. No new full proof, deployment, original business-budget, full resource-accounting, payment or cryptographic-security qualification.",
            "aggregate_wrapper": pin(__file__), "observed_monotonic_ns": time.monotonic_ns(),
        }
        require(set(binaries) == {"owner_test", "native_winner", "runner", "verifier", "r0vm"}, "exact five roles")
        qpin = save(BASE / "qualification.json", qualification)
        attempt.update(completed=True, qualification=qpin)
    except BaseException as exc:
        attempt["errors"].append({"type": type(exc).__name__, "message": str(exc)})
    attempt["completed_monotonic_ns"] = time.monotonic_ns()
    record = save(OUT / "result.json", attempt)
    print(json.dumps({"completed": attempt["completed"], "result": record,
                      "qualification": attempt.get("qualification"), "errors": attempt["errors"]}), flush=True)
    return 0 if attempt["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

