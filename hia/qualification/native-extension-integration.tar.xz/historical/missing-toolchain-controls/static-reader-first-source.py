from pathlib import Path
import ast, hashlib, json, re, stat, subprocess, textwrap
import yaml

BASE=Path('/workspace/scratch/a638c5cc4765'); ROOT=BASE/'Trillionnium-Chain'; OUT=BASE/'extension-integration-controls-v2'
def identity(path):
    data=path.read_bytes();return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def run(argv,**kwargs):
    return subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,**kwargs)
workflow=ROOT/'.github/workflows/hia-native-migration.yml'
wf=yaml.safe_load(workflow.read_text()); jobs=wf['jobs']; assert len(jobs)==54
shells=python_blocks=0
for name,job in jobs.items():
    assert job['timeout-minutes']==20,name
    assert 'runner.' not in json.dumps(job.get('env',{})),name
    for index,step in enumerate(job['steps']):
        if 'run' not in step: continue
        shell=step.get('shell','bash')
        assert shell in ('bash','sh'),(name,index,shell)
        command=re.sub(r'\$\{\{.*?\}\}','REVIEWED_EXPRESSION',step['run'],flags=re.S)
        run(['bash','-n'],input=command.encode());shells+=1
        pattern=r"(?ms)^[^\n]*\bpython3?\b[^\n]*<<['\"](?P<tag>[A-Za-z_][A-Za-z_0-9]*)['\"]\n(?P<body>.*?)^\s*(?P=tag)\s*$"
        for match in re.finditer(pattern,command):
            ast.parse(textwrap.dedent(match['body']),filename=f'{name}:{index}');python_blocks+=1
bootstrap=len(re.findall(r'^ {10}python3 - "\$RUNNER_TEMP/hia-bootstrap/bootstrap\.json"',workflow.read_text(),re.M));assert bootstrap==42
work=jobs['native-work-owner']
assert sum(step.get('name','')=='Reproduce original and fixed native startup handshakes' for step in work['steps']) == 1
assert any('hia-work-handshake-' in str(step) and step.get('if')=='always()' for step in work['steps'])
inventory=json.loads((ROOT/'config/hia-migration-v1.json').read_bytes())
assert len(inventory['components'])==48 and len(inventory['native_foundations'])==22
assert len(inventory['legacy_packages'])==26 and sum(p['state']=='partially-ported' for p in inventory['legacy_packages'])==15
assert len(inventory['blocking_gates'])==9 and not any(p['retirement_accepted'] for p in inventory['legacy_packages'])
assert all(inventory[k] is False for k in ('whole_chain_native','old_stack_can_be_removed','production_activation'))
sources=sorted((ROOT/'hia').rglob('*.hepta'));assert len(sources)==137
hashes={}
for path in sources: hashes.setdefault(identity(path)['sha256'],[]).append(path.relative_to(ROOT).as_posix())
assert not any(len(v)>1 for v in hashes.values()),'Duplicate active HIA source content'
freeze=json.loads((BASE/'owner-extension-manifest-freeze.json').read_bytes())
# Current source-bound component records are the authority for both frozen manifests.
gov=json.loads((ROOT/'hia/qualification/governance-development.json').read_bytes())
for name in ('hia/components.json','config/hia-migration-v1.json'):
    assert identity(ROOT/name)==gov['final_execution']['source_inputs'][name]
for label in ('governance','control-guard','peer-lease'):
    record=json.loads((ROOT/'hia/qualification'/f'{label}-development.json').read_bytes())
    for name,expected in record['final_execution']['source_inputs'].items():
        actual=identity(ROOT/name)
        assert actual==expected if isinstance(expected,dict) else actual['sha256']==expected,(label,name)
    assert record['final_execution']['status']=='PASS' and record['hosted_execution'].startswith('NOT_RUN')
volumes=[]
for label in ('governance','control-guard','peer-lease','work-handshake'):
    directory=ROOT/'hia/qualification'/f'{label}-development.parts';manifest=json.loads((directory/'manifest.json').read_bytes())
    total=0;digest=hashlib.sha256()
    assert {p.name for p in directory.iterdir()}=={'manifest.json'}|{r['path'] for r in manifest['parts']}
    for index,row in enumerate(manifest['parts']):
        path=directory/row['path'];st=path.lstat()
        assert row['path']==f'part-{index:03d}' and row['offset']==total
        assert stat.S_ISREG(st.st_mode) and st.st_nlink==1 and 0<row['bytes']<=6*1024*1024
        data=path.read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
        digest.update(data);total+=len(data)
    assert {'bytes':total,'sha256':digest.hexdigest()}==manifest['archive']
    assert identity(BASE/'owner-extension-full-archives'/manifest['logical_name'])==manifest['archive']
    volumes.append({'name':label,'parts':len(manifest['parts']),**manifest['archive']})
changed=run(['git','diff','--name-only']).stdout.decode().splitlines()
untracked=run(['git','ls-files','--others','--exclude-standard']).stdout.decode().splitlines()
paths=sorted(set(changed+untracked)); python_files=0
for name in paths:
    path=ROOT/name
    if path.suffix=='.py': ast.parse(path.read_text(),filename=name);python_files+=1
    if path.suffix in ('.py','.rs','.c','.hepta','.md','.json','.yml'):
        assert all(line==line.rstrip() for line in path.read_text().splitlines()),name
run(['git','diff','--check'])
corpus_path='config/pon/pq-cross-branch-corpus-v1.json'; new=json.loads((ROOT/corpus_path).read_bytes())
old=json.loads(run(['git','show','HEAD:'+corpus_path]).stdout)
plan='docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
assert new['pinned_blobs'][plan]==run(['git','hash-object',plan]).stdout.decode().strip()
copy=json.loads(json.dumps(new));copy['pinned_blobs'][plan]=old['pinned_blobs'][plan];assert copy==old
assert len(new['pinned_blobs'])==2613 and len(new['required_paths'])==2517
result={'schema':'trnm.hia.extension-static-checks.v1','status':'PASS','workflow':identity(workflow),
        'jobs':54,'bootstrap_gates':42,'all_timeout_minutes':20,'bash_steps_checked':shells,'python_heredocs_checked':python_blocks,
        'changed_python_files_parsed':python_files,'unique_hia_sources':137,'kernels':48,'foundations':22,
        'retained_packages':26,'partially_ported_packages':15,'not_ported_packages':11,'retired_packages':0,'open_gates':9,
        'final_component_source_fences':'PASS','volume_readbacks':volumes,'corpus_pins_changed':[plan],
        'pinned_count':2613,'required_paths_count':2517,'git_diff_whitespace':'PASS','runtime_executed':False}
(OUT/'static-checks.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result))
