#!/usr/bin/env python3
"""Generate new-stage copies only after the actual committed source is clean.

Usage: python3 prepare_retirement_execution.py --commit ACTUAL_SHA --tree ACTUAL_TREE
This prepares scratch files only. It does not execute a verifier, Cargo, tests,
or an evidence collector, and never edits the repository or the 59f helpers.
"""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tempfile

BASE = Path('/workspace/scratch/9d99fced0bf1')
ROOT = BASE / 'chain-current'
OLD_COMMIT = '59f75acd1d4261972b8aaa45e0c36259fcafd45c'
OLD_TREE = 'c0dc8282e5b2618ffb35061f108bb2fa96e9b348'
TEMPLATES = {
    'run_current_exact.py': ('run_retirement_exact.py', '52856e7d6e7d1398f158fcbf16c27f7d67d510139f97a3bf0c9f442ae60a4787'),
    'run_current_required_controls.py': ('run_retirement_required_controls.py', 'f26df51fe4d5570ac4112ffbd1fc4f0537970b2970da1aa16d7e498d8f72563a'),
    'assemble_current_evidence.py': ('assemble_retirement_evidence.py', '24a2c47cb838fedd71e2357c21f24ba7c9b67465d518d1ae71a497bcda3f1c0e'),
    'run_current_parameter_observation.py': ('run_retirement_parameter_observation.py', '9f69f430757f1cf8e25e45aa22ac0b968f3d6a86246b9060c58e0e30c5a0ac3b'),
}
RUNTIME = 'run-current-pq.sh'
RUNTIME_SHA256 = '21986adc86819c17cde990a0b755a52acddac4a7b2d9f5ade5456e76ec75525c'
RECEIPT = 'retirement-execution-generation.json'
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1', PYTHONDONTWRITEBYTECODE='1')
for key in ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_INDEX_FILE'):
    ENV.pop(key, None)


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT, env=ENV)


def actual_source(commit, tree):
    require(git('rev-parse', '--verify', 'HEAD').decode().strip() == commit, 'actual HEAD differs from requested new commit')
    require(git('cat-file', '-t', commit).strip() == b'commit', 'requested source is not a commit')
    require(git('rev-parse', '--verify', 'HEAD^{tree}').decode().strip() == tree, 'actual tree differs from requested tree')
    require(not git('for-each-ref', '--format=%(refname)', 'refs/replace/'), 'replacement refs are not source identity')
    grafts = ROOT / git('rev-parse', '--git-path', 'info/grafts').decode().strip()
    require(not grafts.exists(), 'grafted source history is not accepted')
    entries = git('ls-files', '-v', '-z').split(b'\0')
    require(not any(entry and (entry[:1].islower() or entry[:1] == b'S') for entry in entries), 'hidden index entry flags are not accepted')
    require(not git('status', '--porcelain=v1', '--untracked-files=all', '--ignore-submodules=none'), 'actual source must be clean')
    return {'commit': commit, 'tree': tree, 'clean_git_state_checked': True,
            'raw_source_verifier_executed_during_generation': False}


def read_template(name, expected):
    path = BASE / name
    require(path.is_file() and not path.is_symlink(), 'template must be a regular file: ' + name)
    raw = path.read_bytes()
    require(sha(raw) == expected, 'reviewed template hash changed: ' + name)
    return raw, stat.S_IMODE(path.stat().st_mode)


def render(name, raw, commit, tree):
    text, replacements = raw.decode(), []
    def replace(old, new, count=None):
        nonlocal text
        actual = text.count(old)
        if count is not None:
            require(actual == count, 'template replacement anchor changed: ' + name + ' / ' + old)
        if actual:
            text = text.replace(old, new)
            replacements.append({'old': old, 'new': new, 'occurrences': actual})
    for original, (renamed, _) in TEMPLATES.items():
        replace(original, renamed)
    if name in ('run_current_exact.py', 'run_current_required_controls.py'):
        replace(OLD_COMMIT, commit, 1)
    if name == 'run_current_required_controls.py':
        replace(OLD_TREE, tree, 1)
    if name != 'assemble_current_evidence.py':
        replace('current-validation', 'retirement-validation', 1)
    if name == 'run_current_exact.py':
        replace('fixed 59f75acd.', 'fixed ' + commit[:8] + '.', 1)
    if name == 'assemble_current_evidence.py':
        replace('completed 59f observations', 'completed ' + commit[:8] + ' observations', 1)
        replace('current_required_support', 'retirement_required_support', 1)
        replace("'current-evidence-staging'", "'retirement-evidence-staging'", 1)
        replace("prefix='current-evidence-'", "prefix='retirement-evidence-'", 1)
        replace("'benchmark-build', 'benchmark-run', 'benchmark-reader']",
                "'benchmark-build', 'benchmark-run', 'benchmark-reader', 'interop']", 1)
        replace("'restore-profile-checkout-receipt.json', 'restore-profile-source-verification.json']",
                "'restore-profile-checkout-receipt.json', 'restore-profile-source-verification.json',\n"
                "             'prepare_retirement_execution.py', 'retirement-execution-generation.json',\n"
                "             'prepare_retirement_cache.py', 'retirement-cache/cache-complete.json',\n"
                "             'retirement-cache/Cargo.lock.snapshot']", 1)
    require(OLD_COMMIT not in text and OLD_TREE not in text and 'current-validation' not in text,
            'old execution source/destination binding remains: ' + name)
    require(not any(original in text for original in TEMPLATES), 'old helper reference remains: ' + name)
    ast.parse(text, filename=TEMPLATES[name][0])
    return text.encode(), replacements


def generate(commit, tree):
    require(bool(re.fullmatch(r'[0-9a-f]{40}', commit)) and bool(re.fullmatch(r'[0-9a-f]{40}', tree)),
            'commit and tree must be full lowercase Git SHAs')
    require(commit != OLD_COMMIT and tree != OLD_TREE, 'the completed 59f source cannot be relabeled as retirement execution')
    source = actual_source(commit, tree)
    outputs = [renamed for renamed, _ in TEMPLATES.values()] + [RECEIPT]
    reserved = outputs + ['retirement-validation', 'retirement-evidence-staging']
    require(not any(os.path.lexists(BASE / name) for name in reserved), 'preserve existing retirement outputs')
    runtime, _ = read_template(RUNTIME, RUNTIME_SHA256)
    snapshots, generated, changes, modes = {}, {}, {}, {}
    for name, (renamed, expected) in TEMPLATES.items():
        snapshots[name], modes[renamed] = read_template(name, expected)
        generated[renamed], changes[renamed] = render(name, snapshots[name], commit, tree)
    report = {
        'schema': 'trnm-retirement-execution-generation-v1', 'created_utc': datetime.now(timezone.utc).isoformat(),
        'source': source, 'root': str(ROOT), 'records': str(BASE / 'retirement-validation'),
        'collector_default_output': str(BASE / 'retirement-evidence-staging'),
        'runtime_reused': {'path': str(BASE / RUNTIME), 'sha256': sha(runtime)},
        'templates': {name: {'sha256': sha(raw), 'bytes': len(raw)} for name, raw in snapshots.items()},
        'generated': {name: {'sha256': sha(raw), 'bytes': len(raw), 'changes': changes[name]}
                      for name, raw in generated.items()},
        'diffs': {new: ''.join(difflib.unified_diff(snapshots[old].decode().splitlines(True),
                   generated[new].decode().splitlines(True), fromfile=old, tofile=new))
                  for old, (new, _) in TEMPLATES.items()},
        'guard_semantics_changed': False, 'required_control_count': 49,
        'original_45_order_guard_retained': True, 'raw_source_before_after_guards_retained': True,
        'native_commands_executed': False, 'source_verifier_executed': False,
        'repository_modified': False, 'old_execution_results_reused': False,
        'whole_chain_pq_qualified': False,
    }
    generated[RECEIPT] = (json.dumps(report, indent=2, sort_keys=True) + '\n').encode()
    modes[RECEIPT] = 0o644
    require(actual_source(commit, tree) == source, 'source identity changed during generation')
    require(all((BASE / name).read_bytes() == raw for name, raw in snapshots.items())
            and (BASE / RUNTIME).read_bytes() == runtime, 'reviewed input changed during generation')
    require(not any(os.path.lexists(BASE / name) for name in reserved), 'retirement output appeared during generation')
    temporary = Path(tempfile.mkdtemp(prefix='retirement-execution-staging-', dir=BASE))
    installed = []
    try:
        for name, raw in generated.items():
            path = temporary / name
            with path.open('xb') as stream:
                stream.write(raw); stream.flush(); os.fsync(stream.fileno())
            path.chmod(modes[name])
        for name in outputs:
            source_path, target = temporary / name, BASE / name
            os.link(source_path, target)  # Exclusive creation; never replaces another attempt.
            installed.append((target, source_path.stat().st_ino))
    except BaseException:
        for target, inode in reversed(installed):
            if target.exists() and target.stat().st_ino == inode:
                target.unlink()
        raise
    finally:
        shutil.rmtree(temporary)
    print(json.dumps({'result': 'GENERATED_ONLY', 'source': source, 'outputs': report['generated'],
                      'receipt': str(BASE / RECEIPT), 'native_executed': False}, sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--tree', required=True)
    args = parser.parse_args()
    try:
        generate(args.commit, args.tree)
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        parser.exit(1, 'REFUSED: ' + str(error) + '\n')
