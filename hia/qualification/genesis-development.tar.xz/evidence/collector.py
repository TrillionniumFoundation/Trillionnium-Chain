"""Read-only collection of completed actual Genesis evidence into a fresh archive."""
import hashlib, importlib, io, json, os, pathlib, stat, sys, tarfile, tempfile, time
ROOT=pathlib.Path("/tmp/trnm-genesis-owner-20261116-8ppak97a/repo")
BASE=ROOT.parent
RUN=pathlib.Path("/tmp/trnm-genesis-original-registry-fixed-20261116-may9bnke")
NATIVE=BASE/"registry-fixed-semantic"
SOURCE_SET="a0c3d62591815a2c86df1a77d243b79999f9cbe5238bca230fd15a4243dd3d8b"
TOOLS=json.loads("{\"launch\":{\"audit_recorded\":true,\"automatic_retry\":false,\"host\":\"desktop\",\"persistent_across_runtime_restart\":true,\"reused\":false,\"session_id\":\"dpty-fa3ea6b5705f1b18f0ccce57a21268a067d9407c09e48290e85ac1f2e00c322e\",\"status\":{\"boot\":\"8c55b477-233a-4771-995a-6f666f6299b3\",\"bytes_seen\":114,\"bytes_stored\":114,\"capture_error\":null,\"created_unix_ms\":1794843095479,\"output_complete\":false,\"owner_pid\":2115613,\"pid\":2115614,\"state\":\"running\"}},\"initial\":{\"archive_path\":\"/home/qian-qi/.local/state/hepta-runtime-mac-worker/terminals/dpty-fa3ea6b5705f1b18f0ccce57a21268a067d9407c09e48290e85ac1f2e00c322e/output.log\",\"available_end\":114,\"bytes_hex\":\"7b22737461747573223a2022535441525445445f41444d495353494f4e5f50454e44494e47222c20226f7574707574223a20222f746d702f74726e6d2d67656e657369732d6f726967696e616c2d72656769737472792d66697865642d32303236313131362d6d617939626e6b65227d0d0a\",\"chunk_sha256\":\"0bce7d1c9859f048c6140ced9ac0a0764c36bf5bf0c0091219e6131a219f0b5f\",\"host\":\"desktop\",\"next_offset\":114,\"offset\":0,\"output_complete\":false,\"persistent_across_runtime_restart\":true,\"session_id\":\"dpty-fa3ea6b5705f1b18f0ccce57a21268a067d9407c09e48290e85ac1f2e00c322e\",\"status\":{\"boot\":\"8c55b477-233a-4771-995a-6f666f6299b3\",\"bytes_seen\":114,\"bytes_stored\":114,\"capture_error\":null,\"created_unix_ms\":1794843095479,\"output_complete\":false,\"owner_pid\":2115613,\"pid\":2115614,\"state\":\"running\"},\"storage\":\"target_archive\",\"text\":\"{\\\"status\\\": \\\"STARTED_ADMISSION_PENDING\\\", \\\"output\\\": \\\"/tmp/trnm-genesis-original-registry-fixed-20261116-may9bnke\\\"}\\r\\n\",\"text_is_lossy\":false,\"truncated_before_offset\":false,\"utf8_pending\":false},\"terminal\":{\"archive_path\":\"/home/qian-qi/.local/state/hepta-runtime-mac-worker/terminals/dpty-fa3ea6b5705f1b18f0ccce57a21268a067d9407c09e48290e85ac1f2e00c322e/output.log\",\"available_end\":340,\"bytes_hex\":\"7b22737461747573223a202250415353222c20227175616c69666965725f657869745f636f6465223a20302c202273756d6d617279223a20222f746d702f74726e6d2d67656e657369732d6f726967696e616c2d72656769737472792d66697865642d32303236313131362d6d617939626e6b652f777261707065722d657865637574696f6e2e6a736f6e222c202261637475616c5f726f7773223a2033302c202261637475616c5f706173736564223a2033302c202261637475616c5f6f726967696e616c5f7465737473223a20332c20226572726f72223a206e756c6c7d0d0a\",\"chunk_sha256\":\"1cc216f5879e4dd53893991c49a17c0734a4574c378f16b61909c5aa3970e419\",\"host\":\"desktop\",\"next_offset\":340,\"offset\":114,\"output_complete\":true,\"persistent_across_runtime_restart\":true,\"session_id\":\"dpty-fa3ea6b5705f1b18f0ccce57a21268a067d9407c09e48290e85ac1f2e00c322e\",\"status\":{\"boot\":\"8c55b477-233a-4771-995a-6f666f6299b3\",\"bytes_seen\":340,\"bytes_stored\":340,\"capture_error\":null,\"closed\":false,\"created_unix_ms\":1794843095479,\"exit_code\":0,\"output_complete\":true,\"owner_pid\":2115613,\"pid\":2115614,\"state\":\"exited\"},\"storage\":\"target_archive\",\"text\":\"{\\\"status\\\": \\\"PASS\\\", \\\"qualifier_exit_code\\\": 0, \\\"summary\\\": \\\"/tmp/trnm-genesis-original-registry-fixed-20261116-may9bnke/wrapper-execution.json\\\", \\\"actual_rows\\\": 30, \\\"actual_passed\\\": 30, \\\"actual_original_tests\\\": 3, \\\"error\\\": null}\\r\\n\",\"text_is_lossy\":false,\"truncated_before_offset\":false,\"utf8_pending\":false},\"independent_binary\":{\"metadata\":{\"acl_sha256\":\"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\",\"gid\":1000,\"link_count\":1,\"metadata_platform\":\"linux\",\"mode\":320,\"uid\":1000,\"xattr_names\":[],\"xattr_sha256\":{}},\"mode\":320,\"path\":\"/tmp/trnm-genesis-original-registry-fixed-20261116-may9bnke/original/original-test-binary\",\"sha256\":\"08f636b9ec96829698f80856f27221b5155de7f4d8956fdb5a8ef5929788038d\",\"size\":611585296,\"version\":\"2050:38063677:611585296:1794843334130398575:1794843334130398575\"}}")
EXPECTED_REPORT={"bytes":976051,"sha256":"b8f803da2232dafbf49d32e63982c73dad9ef27228fcadfd9ba69e3c480326a0"}
EXPECTED_BINARY={"bytes":611585296,"sha256":"08f636b9ec96829698f80856f27221b5155de7f4d8956fdb5a8ef5929788038d"}
def require(ok,message):
    if not ok: raise RuntimeError(message)
def digest(raw): return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def identify(path):
    s=path.lstat()
    require(stat.S_ISREG(s.st_mode),"nonregular evidence "+str(path))
    h=hashlib.sha256(); total=0
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    with os.fdopen(fd,"rb") as f:
        before=os.fstat(f.fileno())
        require((s.st_dev,s.st_ino)==(before.st_dev,before.st_ino),"changed evidence inode")
        for block in iter(lambda:f.read(1<<20),b""):h.update(block);total+=len(block)
        after=os.fstat(f.fileno())
    after_path=path.lstat()
    require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)==(after_path.st_dev,after_path.st_ino,after_path.st_size,after_path.st_mtime_ns,after_path.st_ctime_ns),"evidence changed during read")
    require(total==s.st_size,"evidence size changed")
    return {"bytes":total,"sha256":h.hexdigest()}
def write(path,value):
    raw=(json.dumps(value,indent=2,sort_keys=True)+"\n").encode()
    with path.open("xb") as f:f.write(raw)
    return digest(raw)
def read(path): return json.loads(path.read_bytes())
def main():
    out=pathlib.Path(tempfile.mkdtemp(prefix="trnm-genesis-registry-fixed-evidence-20261116-"))
    os.chmod(out,0o700)
    report_path=RUN/"original/report.json"
    require(identify(report_path)==EXPECTED_REPORT,"actual report changed")
    report=read(report_path); wrapper=read(RUN/"wrapper-execution.json")
    require(wrapper["status"]=="PASS" and wrapper["qualifier_exit_code"]==0 and wrapper["wrapper_error"] is None,"wrapper not successful")
    require(report["status"]=="PASS" and (report["controls"],report["passed"],report["failed"])==(30,30,0) and report["original_case_rows_observed"]==30,"incomplete actual differential")
    require(report["primary_error"] is None and report["final_errors"]==[],"actual retained errors")
    require(report["original_tests"]==report["required_original_tests"] and len(report["original_tests"])==3,"incomplete retained original tests")
    require(report["native_source_set_sha256"]==SOURCE_SET and len(report["source_inputs"])==45 and len(report["original_sources"])==4361,"incorrect source identity")
    require(all(x["status"]=="PASS" and x["errors"]==[] for x in report["source_fences"]),"source fence failure")
    require(len(report["stages"])==8 and all(x["status"]=="PASS" and x["exit_code"]==0 and not x["timed_out"] and x["cleanup_error"] is None for x in report["stages"]),"actual stages not all successful")
    require(TOOLS["terminal"]["status"]["exit_code"]==0 and TOOLS["terminal"]["status"]["state"]=="exited" and TOOLS["terminal"]["output_complete"] and TOOLS["terminal"]["next_offset"]==TOOLS["terminal"]["available_end"],"terminal evidence incomplete")
    binary=RUN/"original/original-test-binary"
    require(identify(binary)==EXPECTED_BINARY,"independent original binary differs")
    require({"bytes":TOOLS["independent_binary"]["size"],"sha256":TOOLS["independent_binary"]["sha256"]}==EXPECTED_BINARY,"independent tool binary evidence differs")
    require(TOOLS["independent_binary"]["metadata"]["link_count"]==1 and TOOLS["independent_binary"]["mode"]==0o500,"unexpected retained executable metadata")
    sys.path.insert(0,str(ROOT))
    oracle=importlib.import_module("hia.platform.genesis_store.rust_oracle")
    admitted=oracle.validate_bundle(ROOT,NATIVE/"bundle")
    require(admitted["source_inputs"]==report["source_inputs"] and admitted["original_sources"]==report["original_sources"],"public admission differs from actual run")
    require(admitted["native_counts"]=={"cases":30,"processes":62},"native semantic counts differ")
    compare=read(RUN/"original/comparison.json")
    observations=read(RUN/"original/original-observations.json")
    require(len(compare["controls"])==30 and all(x["status"]=="PASS" and x["differences"]==[] for x in compare["controls"]),"comparison rows differ")
    cases=observations["cases"]
    require(len(cases)==30 and observations["observed_case_rows"]==30 and observations["complete_differential_pass"],"raw observations incomplete")
    require([x["name"] for x in cases]==[x["name"] for x in admitted["inputs"]],"original corpus order differs")
    statuses={s:sum(x["status"]==s for x in cases) for s in ("OK","ERR")}
    require(statuses=={"OK":16,"ERR":14},"actual result split differs")
    for row in cases:
        if row["status"]=="OK":
            require(row["full_reopen_observation_equal"] is True and row["held_lock_probe"]["opened"] is False,"successful original lifecycle incomplete")
    for stage in report["stages"]:
        for stream in ("stdout","stderr"):
            require(identify(RUN/"original"/stage["stage"]/(stream+".raw"))==stage[stream],"raw stage output differs")
        require(read(RUN/"original"/stage["stage"]/"receipt.json")==stage,"actual stage receipt differs")
    native_report=read(NATIVE/"report.json")
    require(native_report==read(NATIVE/"bundle/native-report.json"),"native top-level and admitted semantic report differ")
    old_native=BASE/"final-native-evidence.tar.xz"
    old_failure=pathlib.Path("/tmp/trnm-genesis-original-first-failure-evidence-20261116-574x7q71/genesis-first-original-failure-and-decoder-evidence.tar.xz")
    old_refs={
      "old_a0fa_complete_five_native_suites":{"path":str(old_native),**identify(old_native),"controls":254,"processes":356,"source_set_sha256":"a0fa6c27d48779ae04a7c69cb175b92e00d714e5c443e46a49483c217b870046","upgraded_to_current_source":False},
      "first_actual_original_admission_failure_and_old_decoder_acceptance":{"path":str(old_failure),**identify(old_failure),"actual_original_case_rows":0,"actual_original_build_executed":False,"status":"FAIL_PRESERVED"},
    }
    require(old_refs["old_a0fa_complete_five_native_suites"]["sha256"]=="c17aa5f11f10544c8a2ff3762f1700abc0c243220ca99ab42c3be6a0adc40506","old native archive changed")
    require(old_refs["first_actual_original_admission_failure_and_old_decoder_acceptance"]["sha256"]=="8bcf545b68da2d061f3863b60ed72d56997247eac8e29cdb2463bb8955d4dbef","old failure archive changed")
    binding={
      "schema":"trnm.genesis-registry-fixed-native-original-observation.v1","status":"PASS",
      "native_source_set_sha256":SOURCE_SET,"native_sources":report["source_inputs"],
      "original_source_files":len(report["original_sources"]),
      "original_source_set_sha256":hashlib.sha256(json.dumps(report["original_sources"],sort_keys=True,separators=(",",":")).encode()).hexdigest(),
      "native":{"controls":30,"processes":62,"elapsed_ns":native_report["elapsed_ns"],"build":{k:native_report["build"][k] for k in ("executable","source_set_sha256","compiler_sha256")},"report":{"path":str(NATIVE/"report.json"),**identify(NATIVE/"report.json")},"bundle_artifacts":report["native_bundle_artifacts"]},
      "original":{"controls":30,"passed":30,"failed":0,"statuses":statuses,"retained_tests":report["original_tests"],"original_method_and_observer_invocations_attempted":sum(len(x["public_and_observation_invocations_attempted"]) for x in cases),"elapsed_ns":report["elapsed_ns"],"wrapper_elapsed_ns":wrapper["elapsed_ns"],"compiler":report["compiler"],"hook":report["original_hook"],"production_store":report["original_store"],"binary":{"path":str(binary),**EXPECTED_BINARY},"stages":report["stages"],"source_fences":report["source_fences"],"serde_json_source":report["serde_json_source"],"serde_json_artifact":report["serde_json_artifact"],"report":{"path":str(report_path),**EXPECTED_REPORT},"wrapper":{"path":str(RUN/"wrapper-execution.json"),**identify(RUN/"wrapper-execution.json")}},
      "terminal_observations":TOOLS,"historical_observations":old_refs,
      "scope":{"actual_source_bound_development_observation":True,"same_head_ci_still_required":True,"four_other_physical_suites_current_source_rerun":False,"arbitrary_commit":False,"successor_admission":False,"complete_node":False,"cross_format_sqlite_compatibility":False,"original_error_strings_equivalent":False,"physical_power_loss":False,"os_page_cache_flushed":False},
      "created_wall_time_ns":time.time_ns(),
    }
    write(out/"binding.json",binding)
    members={}; metadata=[]; sources={}
    def add(name,path):
        require(name not in members and not name.startswith("/") and ".." not in pathlib.PurePosixPath(name).parts,"bad archive member name")
        members[name]=identify(path);sources[name]=path
    def scan(prefix,path,exclude=()):
        for entry in sorted(os.scandir(path),key=lambda e:e.name):
            full=path/entry.name
            rel=entry.name
            if rel in exclude or (prefix=="original-run/original" and rel in {"isolated-source","original-test-binary"}):continue
            named=prefix+"/"+rel
            st=full.lstat()
            if stat.S_ISDIR(st.st_mode):
                scan(named,full)
            elif stat.S_ISREG(st.st_mode):
                add(named,full)
            else:
                metadata.append({"path":named,"mode":st.st_mode,"uid":st.st_uid,"gid":st.st_gid,"nlink":st.st_nlink,"size":st.st_size,"inode":st.st_ino,"device":st.st_dev,"rdev":st.st_rdev,"mtime_ns":st.st_mtime_ns,"ctime_ns":st.st_ctime_ns,"symlink_target":os.readlink(full) if stat.S_ISLNK(st.st_mode) else None,"content_archived":False})
    scan("original-run",RUN,exclude=())
    add("native-source-package/registry-fixed-semantic-source-bundle.tar.xz",BASE/"registry-fixed-semantic-source-bundle.tar.xz")
    add("native-source-package/registry-fixed-semantic-source-bundle.json",BASE/"registry-fixed-semantic-source-bundle.json")
    scan("native-semantic",NATIVE)
    add("original-source-extract/store.rs",RUN/"original/isolated-source/trillionnium/crates/trnm-pon-node/src/store.rs")
    add("original-source-extract/hia_genesis_owner_oracle.rs",RUN/"original/isolated-source/trillionnium/crates/trnm-pon-node/src/hia_genesis_owner_oracle.rs")
    add("original-source-extract/Cargo.lock",RUN/"original/isolated-source/trillionnium/Cargo.lock")
    add("execution/wrapper.py",pathlib.Path("/tmp/trnm-genesis-oracle-proposal-20261116-cu0hyqjz/remote_wrapper_registry_fixed_sealed.py"))
    add("evidence/collector.py",pathlib.Path(__file__))
    add("evidence/binding.json",out/"binding.json")
    terminal_raw=bytes.fromhex(TOOLS["initial"]["bytes_hex"])+bytes.fromhex(TOOLS["terminal"]["bytes_hex"])
    require(len(terminal_raw)==TOOLS["terminal"]["available_end"]==340,"actual terminal byte stream incomplete")
    (out/"terminal.raw").write_bytes(terminal_raw)
    add("execution/terminal.raw",out/"terminal.raw")
    manifest={"schema":"trnm.complete-regular-evidence-members.v1","regular_members":members,"special_metadata_only":metadata,"excluded_rebuildable":["original-run/original/isolated-source/","original-run/original/original-test-binary"],"retained_original_binary":{"path":str(binary),**EXPECTED_BINARY}}
    write(out/"member-manifest.json",manifest)
    add("evidence/member-manifest.json",out/"member-manifest.json")
    require(sum(x["bytes"] for x in members.values())<512*(1<<20),"unexpected evidence volume")
    archive_path=out/"genesis-registry-fixed-native-original-evidence.tar.xz"
    with tarfile.open(archive_path,"x:xz",preset=6,format=tarfile.PAX_FORMAT) as archive:
        for name,info in sorted(members.items()):
            path=sources[name]
            require(identify(path)==info,"evidence changed before archive")
            entry=tarfile.TarInfo(name);entry.size=info["bytes"];entry.mode=0o400;entry.mtime=0
            fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
            with os.fdopen(fd,"rb") as stream:archive.addfile(entry,stream)
            require(identify(path)==info,"evidence changed while archived")
    os.chmod(archive_path,0o400)
    readback={}
    with tarfile.open(archive_path,"r:xz") as archive:
        for entry in archive:
            require(entry.isfile() and entry.name in members and entry.name not in readback,"unadmitted readback member")
            h=hashlib.sha256();size=0
            with archive.extractfile(entry) as stream:
                for block in iter(lambda:stream.read(1<<20),b""):h.update(block);size+=len(block)
            readback[entry.name]={"bytes":size,"sha256":h.hexdigest()}
    require(readback==members,"archive readback mismatch")
    receipt={"schema":"trnm.genesis-registry-fixed-evidence-archive.v1","status":"PASS","path":str(archive_path),**identify(archive_path),"regular_members":len(members),"raw_regular_bytes":sum(x["bytes"] for x in members.values()),"special_metadata_records":len(metadata),"all_members_reopened_and_hashed":True,"binding":{"path":str(out/"binding.json"),**identify(out/"binding.json")},"manifest":{"path":str(out/"member-manifest.json"),**identify(out/"member-manifest.json")},"retained_binary":binding["original"]["binary"],"scope":binding["scope"]}
    write(out/"receipt.json",receipt)
    print(json.dumps(receipt,sort_keys=True))
if __name__=="__main__":main()
