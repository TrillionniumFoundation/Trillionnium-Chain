import hashlib,itertools,json,random,sys,time
from functools import lru_cache
from pathlib import Path
sys.path.insert(0, str(Path.cwd()/'formal/pon-nakamoto-v1'))
import ghostdag_order_reference as model
SOURCE=Path(model.__file__)
source_before=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
OUT=Path('/workspace/scratch/1790ff0f3cc3/work/ghostdag-review')
BACKCHECK=[]

def direct_algorithm(parents,k):
    # Independent sets and recursive complete induced graphs, not bitsets,
    # kernel caches/counts, selected-parent internals, or the kernel's helpers.
    @lru_cache(None)
    def past(node):
        found=set(); remaining=list(parents[node])
        while remaining:
            item=remaining.pop()
            if item in found: continue
            found.add(item); remaining.extend(parents[item])
        return frozenset(found)
    genesis=next(node for node in parents if not parents[node])
    @lru_cache(None)
    def order(nodes):
        if nodes==frozenset([genesis]): return frozenset([genesis]),(genesis,),genesis
        references={p for n in nodes for p in parents[n] if p in nodes}
        tips=nodes-references
        previous={tip:order(past(tip)) for tip in tips}
        selected=min(tips,key=lambda tip:(-len(previous[tip][0]),tip))
        blue=set(previous[selected][0])|{selected}
        ordered=list(previous[selected][1])+[selected]
        remaining=set(nodes)-set(past(selected))-{selected}
        while remaining:
            candidate=min(n for n in remaining if not (parents[n]&remaining))
            proposal=blue|{candidate}
            sizes={b:len([a for a in proposal if a!=b and a not in past(b) and b not in past(a)])
                   for b in proposal}
            if max(sizes.values())<=k: blue=proposal
            elif sizes[candidate]<=k and not BACKCHECK:
                BACKCHECK.append({'k':k,'parents':{key:sorted(value) for key,value in parents.items()},
                                  'selected':selected,'candidate':candidate,'before_blue':sorted(blue),
                                  'proposal_anticones':sizes})
            ordered.append(candidate); remaining.remove(candidate)
        return frozenset(blue),tuple(ordered),selected
    blue,ordered,selected=order(frozenset(parents))
    scores={node:(0,None) if not past(node) else (len(order(past(node))[0]),order(past(node))[2])
            for node in parents}
    counts={node:sum(other!=node and other not in past(node) and node not in past(other) for other in blue)
            for node in blue}
    return blue,ordered,selected,scores,counts

def check(parents,k):
    expected=direct_algorithm(parents,k)
    blocks=[model.Block(node,tuple(sorted(p))) for node,p in parents.items()]
    observed=model.order_dag(blocks,k)
    actual=(frozenset(observed.blue),observed.order,observed.selected_tip,
            {r.block_id:(r.blue_score,r.selected_parent) for r in observed.scores},
            dict(observed.blue_anticone_sizes))
    if expected!=actual:
        failure={'k':k,'parents':{a:sorted(b) for a,b in parents.items()},
                 'expected':str(expected),'actual':str(actual)}
        (OUT/'mismatch.json').write_text(json.dumps(failure,indent=2)+'\n')
        raise AssertionError('algorithm mismatch: '+str(failure))
    assert len(observed.order)==len(parents)==len(set(observed.order))
    assert set(observed.blue).isdisjoint(observed.red)
    assert set(observed.blue)|set(observed.red)==set(parents)
    return observed

started=time.monotonic(); enumerated=0; randomized=0; permutations=0
for count in range(1,6):
    ids=[f'{i:064x}' for i in range(count)]
    choices=[list(range(1,1<<i)) for i in range(1,count)]
    for masks in itertools.product(*choices):
        graph={ids[0]:set()}
        for i,mask in enumerate(masks,1): graph[ids[i]]={ids[j] for j in range(i) if mask&(1<<j)}
        for k in range(4): check(graph,k); enumerated+=1
rng=random.Random(569631)
for sample in range(300):
    count=rng.randrange(2,26)
    ids=[f'{i:064x}' for i in range(count)]; rng.shuffle(ids)
    graph={ids[0]:set()}
    for i in range(1,count):
        graph[ids[i]]={ids[j] for j in range(i) if rng.random()<0.25}
        if not graph[ids[i]]: graph[ids[i]]={rng.choice(ids[:i])}
    for k in (0,1,2,5,count):
        before=check(graph,k); randomized+=1
        if sample<20:
            blocks=[model.Block(node,tuple(reversed(sorted(p)))) for node,p in graph.items()]
            rng.shuffle(blocks); after=model.order_dag(blocks,k)
            assert before.decision()==after.decision()
            assert before.graph_sha256==after.graph_sha256
            permutations+=1
source_after=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
assert source_before==source_after, 'source changed during review'
result={'source':str(SOURCE),'sha256':source_before,'enumerated_cases':enumerated,
        'randomized_cases':randomized,'permutation_cases':permutations,
        'independent_set_oracle':True,'passed':True,'wall_seconds':time.monotonic()-started,
        'scope':'finite complete DAG Algorithm 1 comparison; no native W1/PQ/network or security qualification',
        'reverse_k_cluster_witness':BACKCHECK[0] if BACKCHECK else None}
(OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
