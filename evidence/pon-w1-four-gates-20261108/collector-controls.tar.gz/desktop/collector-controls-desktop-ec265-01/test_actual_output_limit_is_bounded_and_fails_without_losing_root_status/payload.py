import os,time
os.write(1,b'x'*8192)
time.sleep(3)
