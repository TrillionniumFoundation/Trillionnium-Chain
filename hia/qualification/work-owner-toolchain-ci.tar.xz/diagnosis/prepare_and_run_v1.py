#!/usr/bin/env python3
"""Private exact-head reproduction and workflow-only toolchain correction."""
from pathlib import Path
import difflib, hashlib, json, os, re, shutil, subprocess, sys, time, traceback

D = Path(__file__).resolve().parent
ROOT = Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo")
HEAD = "bd6201646f92a37edc641b2ab0ae8032507b5784"
TREE = "8a273894649be8393e2b1dc493d7482b2a07d6c0"
sys.path.insert(0, str(ROOT))
from hia.tools import qualify_work_owner_ci as q

def need(ok, text):
    if not ok: raise ValueError(text)
def identity(path):
    raw = Path(path).read_bytes()
    return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def js(path, value):
    with Path(path).open("x") as f: json.dump(value, f, sort_keys=True, indent=2); f.write("\n")
def command(label, argv, *, env=None, stdin=None, timeout=180):
    out=D/"verification-v1"/label
    out.mkdir(parents=True, exist_ok=False)
    start=time.monotonic_ns()
    cp=subprocess.run(argv,cwd=ROOT,env=env,input=stdin,capture_output=True,timeout=timeout)
    (out/"stdout.raw").write_bytes(cp.stdout)
    (out/"stderr.raw").write_bytes(cp.stderr)
    row={"argv":argv,"cwd":str(ROOT),"exit_code":cp.returncode,"elapsed_ns":time.monotonic_ns()-start,
         "stdout":identity(out/"stdout.raw"),"stderr":identity(out/"stderr.raw")}
    js(out/"receipt.json",row)
    print(json.dumps({"stage":label,"exit":cp.returncode,"seconds":row["elapsed_ns"]/1e9}),flush=True)
    return cp,row
def git(*args):
    p=subprocess.run(["git","--no-replace-objects",*args],cwd=ROOT,capture_output=True,check=True)
    need(not p.stderr,"Git diagnostic"); return p.stdout.decode().strip()
def job(text,name):
    m=re.search(r"(?m)^  "+re.escape(name)+r":\n",text);need(m is not None,"Job missing "+name)
    tail=re.search(r"(?m)^  [a-z][a-z0-9-]*:\n",text[m.end():])
    end=m.end()+tail.start() if tail else len(text)
    return m.start(),end,text[m.start():end]

report={"schema":"trnm.work-owner.bd620-toolchain-correction.v1","status":"FAIL","head":HEAD,"tree":TREE,
        "actual_hosted_requalification":False,"production_runtime_changed":False,
        "frozen_native_133_sources_changed":False,"frozen_six_CI_reader_sources_changed":False,
        "original_Rust_or_Cargo_build_executed":False,"native_61_or_fault_execution_repeated":False,
        "original_failed_job":{"run":44041831642,"attempt":1,"job":133897989699,
          "tests":65,"passed":64,"errors":1,"native_execution":"NOT_RUN",
          "failure":"test_actual_normal_compiler_loader_identity: captured_std version contract"}}
before=None
try:
    need(git("rev-parse","HEAD")==HEAD and git("rev-parse","HEAD^{tree}")==TREE,"Current exact head differs")
    need(not git("status","--porcelain"),"Read-only source is not clean")
    cp,row=command("preflight",["bash","scripts/project-preflight.sh","--audit"])
    need(cp.returncode==0,"Project preflight refused")
    original=(D/"upstream-workflow.yml").read_text()
    need((ROOT/".github/workflows/hia-native-migration.yml").read_text()==original,"Plugin/local exact workflow differ")
    before={"native":q.build.source_manifest(),"readers":q.reader_manifest()}
    js(D/"source-before.json",before)
    need(len(before["native"])==133 and len(before["readers"])==6,"Current closure count differs")
    report["native_source_set_sha256"]=q.object_hash(before["native"])
    report["reader_source_set_sha256"]=q.object_hash(before["readers"])
    cp,_=command("full-source-before",["/usr/bin/python3","-B","scripts/ci/verify_ci_source.py",
        "--kind","head","--expected-head",HEAD,"--output",str(D/"full-source-before.json")])
    need(cp.returncode==0,"Full source before failed")

    selector = """set -euo pipefail
rustup toolchain install 1.95.0 --profile minimal --component rust-src
trnm_work_rustc="$(rustup which --toolchain 1.95.0-x86_64-unknown-linux-gnu rustc)"
test -x "$trnm_work_rustc"
printf '%s\\n' "$(dirname "$trnm_work_rustc")" >> "$GITHUB_PATH"
printf 'RUSTUP_TOOLCHAIN=1.95.0-x86_64-unknown-linux-gnu\\n' >> "$GITHUB_ENV"
"""
    new_step="      - name: Install and select the exact original compiler and standard library source\n        run: |-\n"+ "".join("          "+line+"\n" for line in selector.splitlines())
    start,end,native=job(original,"native-work-owner")
    marker="      - name: Execute every source and transport admission control\n"
    need(native.count(marker)==1,"Native source-controls step absent")
    native_new=native.replace(marker,new_step+marker)
    candidate=original[:start]+native_new+original[end:]
    start,end,original_job=job(candidate,"native-work-owner-original")
    old_step="""      - name: Install the exact original compiler and standard library source
        run: |-
          set -euo pipefail
          rustup toolchain install 1.95.0 --profile minimal --component rust-src
"""
    need(original_job.count(old_step)==1,"Original exact install step absent")
    original_new=original_job.replace(old_step,new_step)
    candidate=candidate[:start]+original_new+candidate[end:]
    for name in ("native-work-owner-qualification","native-work-owner-readback"):
        need(job(candidate,name)[2]==job(original,name)[2],"Byte-only consumer unexpectedly changed")
    all_jobs=re.findall(r"(?m)^  ([a-z][a-z0-9-]*):\n",original)
    changed=[name for name in all_jobs if job(candidate,name)[2]!=job(original,name)[2]]
    need(changed==["native-work-owner","native-work-owner-original"],"Workflow scope expanded")
    for name in changed:
        value=job(candidate,name)[2]
        need("timeout-minutes: 20" in value,"Job budget changed")
        gate="Execute every source" if name=="native-work-owner" else "Execute all original histories"
        need(value.index("Install and select the exact")<value.index(gate),"Installation after actual dependency use")
    (D/"candidate-workflow.yml").write_text(candidate)
    patch="".join(difflib.unified_diff(original.splitlines(keepends=True),candidate.splitlines(keepends=True),
                   fromfile="a/.github/workflows/hia-native-migration.yml",
                   tofile="b/.github/workflows/hia-native-migration.yml"))
    (D/"workflow.patch").write_text(patch)
    (D/"select-toolchain.sh").write_text(selector)
    cp,_=command("selector-bash-syntax",["bash","-n",str(D/"select-toolchain.sh")])
    need(cp.returncode==0,"Selector syntax failed")

    # A real installed newer compiler, not a fake version-returning wrapper,
    # precedes the rustup shims. RUSTUP_TOOLCHAIN alone cannot select another
    # compiler when PATH names a direct executable.
    cp,_=command("wrong-direct-compiler-path",["rustup","which","--toolchain",
                     "1.99.1-x86_64-unknown-linux-gnu","rustc"])
    need(cp.returncode==0 and not cp.stderr,"Actual alternate compiler unavailable")
    wrong=Path(cp.stdout.decode().strip()).resolve(strict=True)
    wrong_env=dict(os.environ)
    wrong_env["PATH"]=str(wrong.parent)+os.pathsep+os.environ["PATH"]
    wrong_env["RUSTUP_TOOLCHAIN"]="1.95.0-x86_64-unknown-linux-gnu"
    wrong_env["HIA_TOOLCHAIN_ROOT"]="/tmp/trnm-threadcpu-native-20261116-qvgbgeb_/pinned-hepta-f33d"
    wrong_env["HIA_NATIVE_COMPILER"]="/tmp/trnm-threadcpu-native-20261116-qvgbgeb_/native-bootstrap/native-compiler"
    wrong_env["HIA_NATIVE_COMPILER_SHA256"]="87c247e4d1c3c9a449d2947fd4227fdc186d519bffd203a04cafce7861a4ed54"
    wrong_env["PYTHONDONTWRITEBYTECODE"]="1"
    cp,_=command("wrong-direct-version",["rustc","-Vv"],env=wrong_env)
    need(cp.returncode==0 and cp.stdout.startswith(b"rustc 1.99.1 "),"Wrong compiler control is not real 1.99.1")
    report["wrong_default"]={"path":str(wrong),**identity(wrong),"version":cp.stdout.decode()}
    wrong_temp=D/"wrong-default";wrong_temp.mkdir()
    wrong_env["RUNNER_TEMP"]=str(wrong_temp)
    cp,row=command("wrong-default-public-controls",["/usr/bin/python3","-B","-m",
                  "hia.tools.qualify_work_owner_ci","native-controls"],env=wrong_env)
    controls=wrong_temp/"hia-work-owner-native-observations/source-controls"
    bad=json.loads((controls/"report.json").read_text())
    err=(controls/"stderr.raw").read_text()
    need(cp.returncode!=0 and bad["exit_code"]==1 and len(bad["tests"])==65,"Wrong default did not reject all-controls invocation")
    need(err.count(" ... ok\n")==64 and err.count(" ... ERROR\n")==1
         and "ERROR: test_actual_normal_compiler_loader_identity" in err
         and "Original compiler/std contract differs" in err
         and "Ran 65 tests" in err and "FAILED (errors=1)" in err,"Wrong-default failure differs from actual hosted symptom")
    report["wrong_default_control"]={"status":"REJECTED","tests":65,"passed":64,"errors":1,
         "report":identity(controls/"report.json"),"stderr":identity(controls/"stderr.raw")}

    # Execute exactly the added workflow step, then emulate GitHub's documented
    # application of that step's path/environment files to the next step.
    path_file=D/"github-path";env_file=D/"github-env"
    path_file.write_bytes(b"");env_file.write_bytes(b"")
    select_env={**wrong_env,"GITHUB_PATH":str(path_file),"GITHUB_ENV":str(env_file)}
    cp,row=command("actual-workflow-toolchain-selection",["bash",str(D/"select-toolchain.sh")],env=select_env,timeout=180)
    need(cp.returncode==0,"Actual pinned installation/selection failed")
    paths=path_file.read_text().splitlines()
    envlines=env_file.read_text().splitlines()
    need(len(paths)==1 and envlines==["RUSTUP_TOOLCHAIN=1.95.0-x86_64-unknown-linux-gnu"],"Workflow exports differ")
    selected=Path(paths[0]);need(selected.is_absolute() and (selected/"rustc").is_file(),"No exact compiler bin selected")
    good_env=dict(wrong_env)
    good_env["PATH"]=str(selected)+os.pathsep+wrong_env["PATH"]
    good_env["RUSTUP_TOOLCHAIN"]="1.95.0-x86_64-unknown-linux-gnu"
    good_temp=D/"explicit-pinned";good_temp.mkdir();good_env["RUNNER_TEMP"]=str(good_temp)
    cp,_=command("selected-direct-version",["rustc","-Vv"],env=good_env)
    contract=json.loads((ROOT/"hia/platform/paid_cpu/abi.json").read_text())["standard_library"]
    need(cp.returncode==0 and not cp.stderr and hashlib.sha256(cp.stdout).hexdigest()==contract["rustc_version_sha256"],
         "Selected compiler is not exact pinned identity")
    report["selected_compiler"]={"path":str(selected/"rustc"),**identity(selected/"rustc"),"version":cp.stdout.decode()}
    cp,row=command("explicit-pinned-public-controls",["/usr/bin/python3","-B","-m",
                  "hia.tools.qualify_work_owner_ci","native-controls"],env=good_env)
    need(cp.returncode==0,"Complete 65 pinned controls failed")
    controls=good_temp/"hia-work-owner-native-observations/source-controls"
    good=json.loads((controls/"report.json").read_text());text=(controls/"stderr.raw").read_text()
    need(good["exit_code"]==0 and len(good["tests"])==65 and text.count(" ... ok\n")==65
         and "Ran 65 tests" in text and text.endswith("\nOK\n"),"Pinned full controls did not all execute")
    report["explicit_pinned_control"]={"status":"PASS","tests":65,"passed":65,"skipped":0,
        "report":identity(controls/"report.json"),"stderr":identity(controls/"stderr.raw")}
    report["candidate_workflow"]=identity(D/"candidate-workflow.yml")
    report["workflow_patch"]=identity(D/"workflow.patch")
    report["changed_jobs"]=changed
    report["budgets_minutes"]={name:20 for name in changed}
    report["qualification_and_readback_require_local_std"]=False
    report["status"]="PASS"
except BaseException as error:
    report.update(failure=repr(error),traceback=traceback.format_exc())
finally:
    try:
        if before is not None:
            after={"native":q.build.source_manifest(),"readers":q.reader_manifest()}
            js(D/"source-after.json",after)
            need(after==before,"Frozen native/reader source changed")
            need(git("rev-parse","HEAD")==HEAD and git("rev-parse","HEAD^{tree}")==TREE
                 and not git("status","--porcelain"),"Canonical source or head changed")
            cp,_=command("full-source-after",["/usr/bin/python3","-B","scripts/ci/verify_ci_source.py",
                "--kind","head","--expected-head",HEAD,"--output",str(D/"full-source-after.json")])
            need(cp.returncode==0,"Full source after failed")
            need((D/"full-source-before.json").read_bytes()==(D/"full-source-after.json").read_bytes(),"Full source before/after differ")
            report["source_after"]="MATCH"
    except BaseException as error:
        report.update(status="FAIL",final_fence_failure=repr(error))
    js(D/"verification-v1-report.json",report)
print(json.dumps({"status":report["status"],"failure":report.get("failure"),
                 "report":str(D/"verification-v1-report.json"),
                 "source_after":report.get("source_after")}),flush=True)
raise SystemExit(0 if report["status"]=="PASS" else 1)
