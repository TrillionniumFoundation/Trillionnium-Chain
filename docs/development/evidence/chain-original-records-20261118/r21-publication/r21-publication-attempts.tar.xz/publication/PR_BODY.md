## 问题

原 r20 候选 119c 在双架构原 4 秒 / 0.25 CPU / 16 workers 压力窗口都只有 0/1 独立确认。已有严格 W1 负缓存已消除多数重复数学回放，但同一已拒绝正文仍反复支付协商、解码、上下文和客户端 CPU，挤占独立 History 的 fresh Host 回放。

本 PR 叠在 #954 上，保留其完整成本记录和原失败。新业务结果必须来自本 PR 精确候选的原 hosted-CI 窗口。

## 修改

- 发布 r21-native-invalid-body-backpressure-v1 新签名资源域，保留历史 r20 与更早向量并显式拒绝旧 cookies。
- 只有已完成 native Transcript/Product 拒绝或严格负缓存返回的已鉴权完整正文，才能发布 1,000 ms 等待提示；每 live server 固定 256 槽，不驱逐活项。
- Hello 只能查找，不能创建或刷新提示。未到时项不占 paid grant / worker，不阻塞新正文或读取的 FIFO；到时仍执行全部原验证。
- 记录提示发布与等待计数，沿用现有等待及全进程 CPU 原件，不重复相加嵌套成本。
- 同步原生成器清单与 2,618 个精确源码 pins，保留全部 HOLD_NO_GO 资格位。

外部窗口、CPU、攻击输入/循环、worker 数、确认目标、挑战强度/速率及全部 fresh Host 检查均不变。适用范围是已实际证伪的同一完整正文重复洪泛；不声称一般新正文或 Sybil 公平性。

## 验证

- 40 个去重 Rust 控制通过，包括真实 TCP 中重复坏正文等待、合法新正文与 Head/History 先完成，之后原 native 拒绝仍执行。
- 7 个策略读取器控制、6 个 PQ 源码负例、43 个 CI 源完整性负例通过。
- 原 locked Cargo graph、全功能配置严格 Clippy、格式、完整源码 gate 和生成清单 --check 通过。
- 完整 stdout/stderr、实际进程收据、首编译/首 Clippy/空 selector/EOF 检查失败与最终源码摘要已保存在 docs/development/evidence/chain-known-invalid-backpressure-20261118/。
- 新候选的原压力业务结果在提交冻结时为 NOT_RUN，不能由上述工程控制或 Cargo 退出码推导。

没有部署、生产激活或合并。
