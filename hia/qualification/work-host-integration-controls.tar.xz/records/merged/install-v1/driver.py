from pathlib import Path
import sys,json,hashlib,subprocess,stat,os,time,traceback,tempfile
root=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo");base=root.parent/"work-components-integration-v3";candidate=base/"candidate";out=base/"install-v1";out.mkdir(mode=0o700);(out/"driver.py").write_text(sys.argv[1])
started=time.monotonic_ns();report={"status":"FAIL","mutated":[],"native_runtime_executed":False}
def need(v,m):
 if not v:raise ValueError(m)
def identity(p):
 st=p.lstat();need(stat.S_ISREG(st.st_mode) and st.st_nlink==1,"Nonregular/linked file "+str(p));raw=p.read_bytes();return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
try:
 before=json.loads((base/"canonical-before.json").read_text());after=json.loads((base/"candidate-source.json").read_text())
 need(len(before)==len(after)==43 and before.keys()==after.keys(),"Owned list changed")
 pre=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=root,capture_output=True);(out/"preflight.stdout.raw").write_bytes(pre.stdout);(out/"preflight.stderr.raw").write_bytes(pre.stderr);need(pre.returncode==0,"Preflight failed")
 need(subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()=="c3901ff19c26815205d9cdd6975fc24ecc51ae88","Head moved")
 need(subprocess.check_output(["git","status","--porcelain"],cwd=root,text=True)=="","Canonical no longer clean")
 for rel,want in before.items():
  p=root/rel
  need((identity(p) if p.exists() else {"status":"ABSENT"})==want,"Canonical owned source changed "+rel)
  need(identity(candidate/rel)==after[rel],"Prepared candidate changed "+rel)
 for rel,want in after.items():
  target=root/rel;raw=(candidate/rel).read_bytes()
  if before[rel]==want:continue
  target.parent.mkdir(parents=True,exist_ok=True);need(target.parent.resolve()==target.parent,"Linked target directory")
  mode=stat.S_IMODE(target.lstat().st_mode) if target.exists() else 0o644
  fd,name=tempfile.mkstemp(prefix=".trnm-install-",dir=target.parent)
  try:
   with os.fdopen(fd,"wb") as f:f.write(raw);f.flush();os.fsync(f.fileno())
   os.chmod(name,mode);os.replace(name,target)
  finally:
   if os.path.exists(name):os.unlink(name)
  need(identity(target)==want,"Installed bytes differ");report["mutated"].append(rel)
 need({rel:identity(root/rel) for rel in after}==after,"Installed source set differs")
 diff=subprocess.run(["git","diff","--check"],cwd=root,capture_output=True);(out/"diff-check.stdout.raw").write_bytes(diff.stdout);(out/"diff-check.stderr.raw").write_bytes(diff.stderr);need(diff.returncode==0,"Diff whitespace check failed")
 status=subprocess.check_output(["git","status","--porcelain","--untracked-files=all"],cwd=root,text=True);(out/"git-status.txt").write_text(status)
 need(not subprocess.check_output(["git","diff","--cached","--name-only"],cwd=root,text=True),"Index changed unexpectedly")
 report.update(status="PASS",owned_files=43,changed_files=len(report["mutated"]),installed_source=after,source_parent="c3901ff19c26815205d9cdd6975fc24ecc51ae88",committed=False,published=False)
except BaseException as e:report["failure"]={"error":repr(e),"traceback":traceback.format_exc()};raise
finally:
 report["elapsed_ns"]=time.monotonic_ns()-started;(out/"report.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n");print(json.dumps({k:v for k,v in report.items() if k not in ("installed_source","mutated")}),flush=True)
