#!/usr/bin/env python3
import hashlib, importlib.util, json, os
from pathlib import Path
from types import SimpleNamespace
ROOT = Path('/home/qq/work/chain-throughput-20261106-ee79/qualification-114-0bca28ebf590-runtime2')
BASE = ROOT.parent
HEAD = '0bca28ebf59058b6aba9db5eb956c4479556e9ee'
repo, raw = (ROOT / 'repo').resolve(strict=True), ROOT / 'raw'
runner = ROOT / 'run_native_qualification.py'
assert hashlib.sha256(runner.read_bytes()).hexdigest() == '2944189be70e53103debc4a9ae0a95866cde53ddbf3271a314b716614458074d'
spec = importlib.util.spec_from_file_location('pinned_native_runner', runner)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
env = helper.environment(repo)
args = SimpleNamespace(repo=repo, out=raw, head=HEAD)
summary = dict(schema='trnm-original-workspace-private-temp-attempt-v1', status='running',
 head=HEAD, original_failed_attempt=str(BASE / 'qualification-114-0bca28ebf590/raw/runtime-stage.json'),
 environment={key: env.get(key) for key in tuple(helper.ENVIRONMENT) + ('TMPDIR',)},
 all_114_control_results_reused_as_new_execution=False, original_docs_reexecuted=False,
 production_qualified=False, commands=[])
path = raw / 'runtime-attempt.json'
helper.write_json(path, summary, exclusive=True)
try:
 preflight = helper.run_recorded(args, 'runtime-preflight', ['bash', 'scripts/project-preflight.sh', '--audit'], env)
 summary['preflight'] = preflight
 helper.require(preflight['passed'], 'source-bound preflight required')
 command = ['cargo', '+1.95.0', 'test', '--locked', '--manifest-path', 'trillionnium/Cargo.toml',
            '--workspace', '--all-targets', '--all-features']
 result = helper.run_recorded(args, 'runtime-tests', command, env)
 summary['commands'].append(result)
 summary['status'] = 'passed' if result['passed'] else 'failed'
except (OSError, ValueError, KeyError, TypeError) as error:
 summary.update(status='failed', error=str(error))
helper.write_json(path, summary)
print(json.dumps({'status': summary['status'], 'receipt': str(path)}), flush=True)
raise SystemExit(0 if summary['status'] == 'passed' else 1)
