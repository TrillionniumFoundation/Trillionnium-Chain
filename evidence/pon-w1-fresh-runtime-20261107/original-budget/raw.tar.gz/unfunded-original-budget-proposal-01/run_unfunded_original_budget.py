#!/usr/bin/env python3
"""One declared, unfunded A proof-path observation under one original budget.

This external observer does not fund a NativeTask, exercise M12 settlement, or
qualify a hostile/admission matrix. Importing it never executes the probe.
Only the explicit "run --execute" command can dispatch the real A programs.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
REPO = ROOT / "repo"
HEAD = "d3037ca5dfb6f301757c159b7888dca9b0317be0"
TREE = "d4a8f84cdc896b9454ce0d03a164f8916e6afdf9"
SCHEMA = "TRNM-W1-UNFUNDED-ORIGINAL-BUDGET-PROBE1"
SOURCE_REPORT_SHA = "e2e1d88b8bb08d6da57361287d3f76df9f78299fb5a44b45d3bdb0ea61c08556"
QUALIFICATION_SHA = "cc52956605ae4d4abc75084c04ba312c7baab316b4ac3d0ad18097ed3ab71b57"
STAGE_REL = "formal/pon-nakamoto-v1/experiments/w1_stage_measure.py"
RUNTIME_REL = "scripts/w1_owned_generation_runtime_v2.py"
POSTWIN_REL = "scripts/run_w1_postwin_proof.py"
STAGE_SHA = "a3c80e25ec202749225ddd1a4fc45f3f22ab753f5e9e6941e694a3aa4a547df9"
RUNTIME_SHA = "500f2712942ff2e5f46e82cb2fb1a5d514be55a9ca6e851b7cede79374c15119"
POSTWIN_SHA = "dca5351d21f5d4f89ec9dca5655160f3044a1d79e20286e9b28e5089e938caa2"
BUDGET_NS = 4_000_000_000
MEMORY_BYTES = 2 * 1024**3
LABELS = ["native-winner", "postwin-proof"]
PINNED_INPUTS = {
    "material": {"path": str(ROOT / "experiment-inputs-01/material.bin"),
                 "sha256": "6a0400bbe34f342e7fc2f89221884482f5e7ec0743745ed0916053ab97a22ce3"},
    "header_template": {"path": str(ROOT / "experiment-inputs-01/header-template-search0.bin"),
                        "sha256": "7b96038f228a1eedccf7b29ffc54802aba691be7259e33937846c6bf6126d78f",
                        "bytes": 318},
    "expected_artifacts": {"path": str(ROOT / "experiment-inputs-01/expected-artifacts.bin"),
                           "sha256": "802adcdd951cfb4cd7271df22c3bca6af66fee9f40454c74f8b5ff2c98a1b683",
                           "bytes": 64},
}
PINNED_PROGRAMS = {
    "native_winner": {"path": str(ROOT / "target-native/release/examples/pon_w1_native_winner_v2"),
                      "sha256": "87118afd349dc5645e38216802fa6e70e965e6ae59d60737fe1221de6ad3b4a3",
                      "bytes": 752472},
    "verifier": {"path": str(ROOT / "target-native/release/w1-verify-v2"),
                 "sha256": "582b53d8607cca6ec228c18de8047e1d6564f0fd9cd3cdeafa06c66f460ad3d5",
                 "bytes": 19337648},
    "runner": {"path": str(ROOT / "target-w1-host-v2/release/w1-staged-prover-v2"),
               "sha256": "7392a2ca67ade788ed9f2f8a92dfc4ad6e2de02f4ba795a19fbb8bffd73261bf",
               "bytes": 47811400},
    "r0vm": {"path": str(ROOT / "fixed-backend-01/r0vm"),
             "sha256": "2acdf550f9aca4d05b74072463e4ed307c3824309c754a5cb5f93aa84f3390e6",
             "bytes": 108764424},
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def strict_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key")
        result[key] = value
    return result


def read_json(path, maximum=8 * 1024 * 1024):
    with Path(path).open("rb") as stream:
        raw = stream.read(maximum + 1)
    require(len(raw) <= maximum, "bounded JSON")
    value = json.loads(raw, object_pairs_hook=strict_object,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))
    require(type(value) is dict, "JSON object")
    return value


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def file_record(path):
    path = Path(path)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)}


def write_new(path, value):
    path = Path(path)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def pinned(pin):
    path = Path(pin["path"])
    require(path.is_absolute() and path.is_file() and not path.is_symlink(), "absolute regular pinned file")
    if "bytes" in pin:
        require(path.stat().st_size == pin["bytes"], "pinned length changed")
    require(sha(path) == pin["sha256"], "pinned bytes changed: " + str(path))
    return path


def fixed_contract(observer_path, observer_sha):
    return {
        "schema": SCHEMA,
        "execution_status": "NOT_RUN",
        "funding_status": "UNFUNDED",
        "trial_count": 1,
        "planned_rows": LABELS,
        "output": str(ROOT / "unfunded-original-budget-A-01"),
        "source": {"repo": str(REPO), "commit": HEAD, "tree": TREE},
        "qualification": {"path": str(ROOT / "clean-A-build-qualification-01/qualification.json"),
                          "sha256": QUALIFICATION_SHA},
        "source_report_sha256": SOURCE_REPORT_SHA,
        "observer": {"path": str(Path(observer_path).resolve()), "sha256": observer_sha},
        "inputs": PINNED_INPUTS,
        "programs": PINNED_PROGRAMS,
        "budget": {"wall_ns": BUDGET_NS, "origin": "parent monotonic immediately before native dispatch preparation",
                   "clock": "Linux CLOCK_MONOTONIC", "native_maximum_attempts": 10000,
                   "first_nonce": 0, "reset_allowed": False},
        "resources": {"cpu_quota_percent": 25, "memory_max_bytes": MEMORY_BYTES,
                      "cpu_affinity": [8, 9, 10, 11], "segment_workers": 1,
                      "compression_mode": "sequential", "compression_workers": 1, "rayon_threads": 1,
                      "comparison_repeats": 0},
        "cleanup": {"outer_term_grace_seconds": 30, "postwin_controller_term_grace_seconds": 12,
                    "inner_stage_term_grace_seconds": 5, "owned_cgroup_fallback_seconds": 5,
                    "eligibility_extended": False,
                    "scope": "one isolated Hepta job; A Scope recursively checks descendants and kills only new PID+birth identities"},
        "setup_scope": "existing A build qualification, source check, binary/input hashes, imports and resource checks; precedes native origin",
        "postrun_audit_scope": "source/hash readback and report persistence after timed endpoint; never changes native deadline or earlier endpoint",
        "timed_endpoint": "parent observation of actual postwin exit, bound raw result/ACK and empty owned scope",
        "limits": {"native_task_funding_exercised": False, "m12_cold_recovery_exercised": False,
                   "six_confirmation_matrix_qualified": False, "sixteen_hostile_matrix_qualified": False,
                   "wan_qualified": False, "population_tail_established": False,
                   "complete_resource_accounting_established": False, "production_qualified": False},
    }


def validate_contract(value, observer_path):
    require(type(value) is dict and type(value.get("observer")) is dict, "declaration shape")
    observer_sha = value["observer"].get("sha256")
    require(type(observer_sha) is str and len(observer_sha) == 64
            and all(c in "0123456789abcdef" for c in observer_sha), "observer SHA256")
    require(value == fixed_contract(observer_path, observer_sha), "declaration differs from fixed original-budget plan")
    # Equality alone treats True==1 in Python. Signed/hash data still require types.
    for number in (value["trial_count"], value["budget"]["wall_ns"], value["budget"]["native_maximum_attempts"],
                   value["budget"]["first_nonce"], value["resources"]["cpu_quota_percent"],
                   value["resources"]["memory_max_bytes"], value["resources"]["segment_workers"],
                   value["resources"]["compression_workers"], value["resources"]["rayon_threads"],
                   value["resources"]["comparison_repeats"], *value["resources"]["cpu_affinity"]):
        require(type(number) is int, "exact integer declaration required")


def enforce_resources(snapshot, affinity):
    require(type(snapshot) is dict and type(affinity) is list, "resource observation shape")
    parts = snapshot["cpu_max"].split()
    require(len(parts) == 2 and all(part.isdecimal() for part in parts), "finite actual CPU quota")
    quota, period = map(int, parts)
    require(quota > 0 and period > 0 and quota * 4 == period, "actual CPU quota must equal 25 percent")
    require(snapshot["memory_max"] == str(MEMORY_BYTES), "actual MemoryMax must equal 2 GiB")
    require(affinity == [8, 9, 10, 11], "actual CPU affinity changed")


def planned_commands(contract, out, origin_ns, boot_id):
    require(type(origin_ns) is int and origin_ns >= 0 and type(boot_id) is str and boot_id, "original clock")
    deadline = origin_ns + BUDGET_NS
    p, i = contract["programs"], contract["inputs"]
    native = [p["native_winner"]["path"], i["material"]["path"], i["expected_artifacts"]["path"],
              i["header_template"]["path"], str(out / "winner"), str(deadline), boot_id, "10000"]
    postwin = ["/usr/bin/python3", str(REPO / POSTWIN_REL), "--winner-dir", str(out / "winner"),
               "--out", str(out / "postwin")]
    for name in ("runner", "r0vm", "verifier"):
        postwin += ["--" + name, p[name]["path"], "--" + name + "-sha256", p[name]["sha256"]]
    postwin += ["--segment-workers", "1", "--compression-mode", "sequential", "--compression-workers", "1",
                "--rayon-threads", "1", "--comparison-repeats", "0"]
    return deadline, dict(zip(LABELS, (native, postwin)))


def decide(rows, end_ns, deadline_ns, canceled_signal, cleanup_known, audit_ok, failure):
    """Pure decision logic; it does not establish a proof from supplied flags."""
    require([row.get("label") for row in rows] == LABELS, "planned denominator changed")
    if deadline_ns is not None and (end_ns is None or end_ns >= deadline_ns):
        return "DEADLINE_EXHAUSTED"
    if canceled_signal is not None:
        require(type(canceled_signal) is int and canceled_signal in (2, 15), "actual cancellation signal")
        return "CANCELED"
    if not cleanup_known:
        return "UNKNOWN_RESOURCE_CLOSURE"
    if failure is not None or not audit_ok:
        return "FAILED"
    if all(row.get("dispatched") is True and row.get("actual_stage_complete") is True
           and row.get("error") is None for row in rows):
        return "COMPLETE_OBSERVED_WITHIN_ORIGINAL_BUDGET"
    return "INCOMPLETE"


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def command_record(argv, directory, label, timeout=90):
    started = time.monotonic_ns()
    stdout, stderr = directory / (label + ".stdout"), directory / (label + ".stderr")
    with stdout.open("xb") as out, stderr.open("xb") as err:
        try:
            child = subprocess.run(argv, cwd=REPO, stdout=out, stderr=err, timeout=timeout,
                                   env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}, check=False)
            code, error = child.returncode, None
        except BaseException as failure:
            code, error = None, {"type": type(failure).__name__, "message": str(failure)}
            row = {"label": label, "argv": list(map(str, argv)), "exit": code, "error": error,
                   "started_monotonic_ns": started, "finished_monotonic_ns": time.monotonic_ns(),
                   "stdout": file_record(stdout), "stderr": file_record(stderr)}
            try:
                out.flush()
                err.flush()
                os.fsync(out.fileno())
                os.fsync(err.fileno())
                write_new(directory / (label + ".json"), row)
            except BaseException as retention:
                failure.retention_error = {"type": type(retention).__name__, "message": str(retention)}
                raise failure from retention
            raise
    row = {"label": label, "argv": list(map(str, argv)), "exit": code, "error": error,
           "started_monotonic_ns": started, "finished_monotonic_ns": time.monotonic_ns(),
           "stdout": file_record(stdout), "stderr": file_record(stderr)}
    write_new(directory / (label + ".json"), row)
    require(code == 0, "required audit command failed: " + label)
    return row


def source_check(directory, label):
    path = directory / (label + ".json")
    row = command_record(["/usr/bin/python3", str(REPO / "scripts/ci/verify_ci_source.py"),
                          "--kind", "head", "--expected-head", HEAD, "--output", str(path)],
                         directory, label + "-command")
    require(sha(path) == SOURCE_REPORT_SHA, "raw exact-A source report changed")
    value = read_json(path)
    require(value["tested_commit"] == HEAD and value["tested_tree"] == TREE, "source identity differs from A")
    return {"command": row, "report": file_record(path)}


def all_pins(contract):
    return [contract["qualification"], *contract["inputs"].values(), *contract["programs"].values(),
            {"path": str(REPO / STAGE_REL), "sha256": STAGE_SHA},
            {"path": str(REPO / RUNTIME_REL), "sha256": RUNTIME_SHA},
            {"path": str(REPO / POSTWIN_REL), "sha256": POSTWIN_SHA},
            contract["observer"]]


def validate_actual_winner(postwin_module, directory, contract, origin_ns, deadline_ns, boot_id):
    value, raw_pins = postwin_module.capture_winner_identity(directory, time.monotonic_ns(), boot_id)
    intent = read_json(directory / "intent.json")
    require(value["original_deadline_monotonic_ns"] == deadline_ns, "native deadline changed")
    require(intent["maximum_attempts"] == 10000 and intent["first_nonce"] == 0, "native search declaration changed")
    require(origin_ns <= intent["entered_monotonic_ns"] <= value["search_started_monotonic_ns"]
            <= value["native_winner_monotonic_ns"], "native timestamps precede original observer")
    for key, material in (("material_sha256", "material"), ("header_template_sha256", "header_template"),
                          ("expected_artifacts_sha256", "expected_artifacts")):
        require(intent[key] == contract["inputs"][material]["sha256"], "native input differs from independent fixed material")
    return {"value": value, "raw_record_hashes": raw_pins}


def validate_postwin(directory, native, deadline_ns, boot_id):
    report_path = directory / "result.json"
    report = read_json(report_path)
    require(report["schema"] == "TRNM-W1-POSTWIN-PROOF2" and report.get("operation_complete") is True,
            "actual postwin process did not report complete operation")
    require(report.get("error") is None and report.get("cancellation_event") is None
            and not (directory / "operation-cancellation.json").exists(), "postwin error/cancellation")
    require(report["winner"] == native["value"] and report["winner_record_sha256"] == native["raw_record_hashes"]["result.json"]
            and report["winner_intent_sha256"] == native["raw_record_hashes"]["intent.json"], "postwin changed selected native records")
    require(report["original_deadline_monotonic_ns"] == deadline_ns
            and report["original_deadline_boot_id"] == boot_id, "postwin changed original budget")
    require(report.get("full_proof_verified_observed") is True, "no actual complete proof observation")
    controller_path = directory / "controller/result.json"
    require(report["controller_result"]["sha256"] == sha(controller_path), "controller raw binding")
    controller = read_json(controller_path)
    require(controller.get("complete_proof_claim") is True and controller.get("end_to_end_observation_complete") is True
            and controller.get("error") is None and controller.get("controller_canceled_signal") is None
            and controller.get("controller_cancellation_event") is None
            and controller.get("unretained_stage_labels") == [], "incomplete controller operation")
    require(not (directory / "controller/cancellation.json").exists(), "controller cancellation sidecar")
    ack_path = directory / "receiver/ack.json"
    ack = read_json(ack_path)
    require(ack.get("schema") == "TRNM-W1-RECEIVER-ACK2" and ack.get("verified") is True
            and ack.get("receiver_operation_complete") is True and ack.get("admission_authorized") is False
            and ack.get("error") is None and ack.get("cancellation_event") is None
            and not (directory / "receiver/operation-cancellation.json").exists(), "receiver ACK is not an eligible operation")
    for key in ("header_sha256", "expected_artifacts_sha256"):
        require(ack[key] == native["value"][key], "receiver changed native statement")
    receipt = directory / "checkpoint/succinct.bin"
    require(ack["receipt_sha256"] == sha(receipt), "receiver receipt binding")
    observed = controller.get("parent_observed_receiver_ack_monotonic_ns")
    require(type(observed) is int and controller.get("parent_observed_receiver_ack_boot_id") == boot_id
            and native["value"]["native_winner_monotonic_ns"] <= observed <= time.monotonic_ns() < deadline_ns,
            "original-clock receiver endpoint is absent or late")
    return {"report": file_record(report_path), "controller": file_record(controller_path),
            "receiver_ack": file_record(ack_path), "receipt": file_record(receipt),
            "parent_observed_receiver_ack_monotonic_ns": observed,
            "winner_to_receiver_ns": observed - native["value"]["native_winner_monotonic_ns"]}



def collect_terminal_observations(out, native, origin_ns, deadline_ns, boot_id):
    """Retain earlier actual saved facts even when the outer operation failed."""
    paths = {
        "native_result": out / "winner/result.json",
        "native_intent": out / "winner/intent.json",
        "native_statement_recheck": out / "postwin/native-statement-recheck/stdout.log",
        "postwin_result": out / "postwin/result.json",
        "postwin_cancellation": out / "postwin/operation-cancellation.json",
        "controller_result": out / "postwin/controller/result.json",
        "controller_cancellation": out / "postwin/controller/cancellation.json",
        "receiver_ack": out / "postwin/receiver/ack.json",
        "receiver_cancellation": out / "postwin/receiver/operation-cancellation.json",
    }
    found, values = {}, {}
    for key, path in paths.items():
        if not path.exists():
            found[key] = {"path": str(path), "state": "UNOBSERVED"}
            continue
        found[key] = {**file_record(path), "state": "SAVED"}
        try:
            values[key] = read_json(path)
        except (ValueError, OSError) as failure:
            found[key]["parse_error"] = {"type": type(failure).__name__, "message": str(failure)}
    controller, ack = values.get("controller_result"), values.get("receiver_ack")
    native_recheck = values.get("native_statement_recheck", {})
    early = {"state": "UNOBSERVED", "qualifies_outer_operation": False,
             "scope": "A controller's same-host monotonic receiver completion fact; subsequent diagnostics and cancellation remain separate"}
    if controller is not None and ack is not None and native is not None:
        observed = controller.get("parent_observed_receiver_ack_monotonic_ns")
        receiver_stages = [row for row in controller.get("stages", [])
                           if type(row) is dict and row.get("stage") == "independent-receiver"]
        receipt = out / "postwin/checkpoint/succinct.bin"
        predicate = (
            type(observed) is int and origin_ns is not None and deadline_ns is not None
            and controller.get("schema") == "TRNM-W1-COMPLETE-STAGED-RUN3"
            and controller.get("complete_proof_claim") is True
            and controller.get("parent_observed_receiver_ack_boot_id") == boot_id
            and origin_ns <= native["value"]["native_winner_monotonic_ns"] <= observed < deadline_ns
            and len(receiver_stages) == 1
            and receiver_stages[0].get("result", {}).get("stage_process_complete") is True
            and receiver_stages[0].get("result", {}).get("returncode") == 0
            and receiver_stages[0].get("result", {}).get("canceled_signal") is None
            and receiver_stages[0].get("result", {}).get("termination_reasons") == []
            and ack.get("schema") == "TRNM-W1-RECEIVER-ACK2"
            and ack.get("receiver_operation_complete") is True
            and ack.get("verified") is True and ack.get("admission_authorized") is False
            and ack.get("error") is None and ack.get("cancellation_event") is None
            and ack.get("canceled_signal") is None
            and type(native_recheck.get("work_id")) is str
            and ack.get("work_id") == native_recheck["work_id"]
            and found["receiver_cancellation"]["state"] == "UNOBSERVED"
            and ack.get("header_sha256") == native["value"]["header_sha256"]
            and ack.get("expected_artifacts_sha256") == PINNED_INPUTS["expected_artifacts"]["sha256"]
            and receipt.is_file() and ack.get("receipt_sha256") == sha(receipt)
        )
        early.update({"state": "BOUND_SAVED_ACK_WITHIN_ORIGINAL_DEADLINE" if predicate else "INCOMPLETE_OR_INELIGIBLE",
                      "parent_observed_receiver_ack_monotonic_ns": observed,
                      "original_clock_boot_id": controller.get("parent_observed_receiver_ack_boot_id"),
                      "receipt_verified_claim": controller.get("complete_proof_claim"),
                      "winner_to_ack_ns": observed - native["value"]["native_winner_monotonic_ns"]
                                           if predicate else None,
                      "native_dispatch_origin_to_ack_ns": observed - origin_ns if predicate else None})
    return {"files": found, "early_receiver_fact": early,
            "complete_controller_receipt_claim": controller.get("complete_proof_claim") if controller else None,
            "new_cryptographic_verification_performed_by_this_reader": False}


def run_actual(declaration_path, declaration_sha, measure):
    entered = time.monotonic_ns()
    require(sha(declaration_path) == declaration_sha, "external declaration digest mismatch")
    contract = read_json(declaration_path)
    validate_contract(contract, __file__)
    pinned(contract["observer"])
    out = Path(contract["output"])
    require(out.parent == ROOT and out.name == "unfunded-original-budget-A-01", "exclusive output path")
    out.mkdir(exist_ok=False)
    audit = out / "audit"
    audit.mkdir()
    write_new(out / "declaration-copy.json", contract)
    rows = [{"label": label, "dispatched": False, "actual_stage_complete": False,
             "reason": "NOT_DISPATCHED", "stage_result": None, "error": None} for label in LABELS]
    setup = {"started_monotonic_ns": entered, "commands": [], "qualification": None}
    source_before = source_after = None
    scope = None
    failure = None
    origin_ns = deadline_ns = end_ns = None
    boot_id = None
    native = postwin = None
    timed_before = timed_after = None
    audit_ok, cleanup_known = False, False
    initial_cgroup_snapshot = None
    try:
        os.chdir(REPO)
        os.sched_setaffinity(0, {8, 9, 10, 11})
        setup["commands"].append(command_record(["/usr/bin/bash", "scripts/project-preflight.sh", "--dev"], audit, "preflight"))
        source_before = source_check(audit, "source-before")
        for pin in all_pins(contract):
            pinned(pin)
        qualification = read_json(contract["qualification"]["path"])
        require(qualification.get("qualification_complete") is True
                and qualification["source_commit"] == HEAD and qualification["source_tree"] == TREE,
                "exact A build qualification is incomplete")
        for name, pin in PINNED_PROGRAMS.items():
            for key in ("path", "sha256", "bytes"):
                require(qualification["binaries"][name][key] == pin[key], "qualified executable identity changed")
        setup["qualification"] = file_record(contract["qualification"]["path"])
        require(not any(key in os.environ for key in ("RISC0_DEV_MODE", "RISC0_PROVER", "BONSAI_API_KEY", "BONSAI_API_URL")),
                "unexpected proof backend environment")
        sys.path.insert(0, str(REPO / "scripts"))
        runtime = load_module("probe_owned_runtime", REPO / RUNTIME_REL)
        postwin_module = load_module("probe_postwin", REPO / POSTWIN_REL)
        scope = runtime.Scope({})
        initial_cgroup_snapshot = scope.snapshot()
        enforce_resources(initial_cgroup_snapshot, sorted(os.sched_getaffinity(0)))
        require(not scope.remaining(), "new owned processes existed before native trial")
        boot_id = measure.local_boot_id()
        setup["finished_monotonic_ns"] = time.monotonic_ns()
        setup["wall_ns"] = setup["finished_monotonic_ns"] - entered
        write_new(out / "setup.json", setup)
        with measure.cancel_on_signals():
            timed_before = scope.snapshot()
            origin_ns = time.monotonic_ns()
            deadline_ns, commands = planned_commands(contract, out, origin_ns, boot_id)
            write_new(out / "origin.json", {"schema": SCHEMA, "origin_monotonic_ns": origin_ns,
                      "original_deadline_monotonic_ns": deadline_ns, "original_deadline_boot_id": boot_id,
                      "native_budget_ns": BUDGET_NS, "declaration_sha256": declaration_sha,
                      "commands": commands, "planned_rows": LABELS})
            for row in rows:
                require(measure.local_boot_id() == boot_id, "original clock boot changed")
                if time.monotonic_ns() >= deadline_ns:
                    row["reason"] = "ORIGINAL_DEADLINE_EXHAUSTED_BEFORE_DISPATCH"
                    raise TimeoutError("original budget exhausted; no dispatch")
                row["dispatched"] = True
                row["reason"] = "DISPATCHED"
                stage_out = out / ("measure-" + row["label"])
                try:
                    value = measure.measure(commands[row["label"]], stage_out, 4.,
                            deadline=deadline_ns / 1e9,
                            environment_overrides={"RAYON_NUM_THREADS": "1", "PYTHONDONTWRITEBYTECODE": "1",
                                                   "RISC0_HOME": str(ROOT / "task-risc0")},
                            termination_grace_seconds=30)
                except BaseException as caught:
                    snapshot = getattr(caught, "observed_snapshot", None)
                    if snapshot and snapshot.get("kind") == "stage":
                        row["stage_result"] = {key: snapshot[key] for key in ("path", "sha256")}
                    row["error"] = {"type": type(caught).__name__, "message": str(caught)}
                    raise
                row["stage_result"] = file_record(stage_out / "result.json")
                row["actual_stage_complete"] = value.get("stage_process_complete") is True
                row["reason"] = "COMPLETE" if row["actual_stage_complete"] else "DISPATCHED_INCOMPLETE"
                require(row["actual_stage_complete"], "actual stage did not complete: " + row["label"])
                require(time.monotonic_ns() < deadline_ns, "original deadline exhausted after actual stage handoff")
                if row["label"] == "native-winner":
                    native = validate_actual_winner(postwin_module, out / "winner", contract, origin_ns, deadline_ns, boot_id)
                else:
                    postwin = validate_postwin(out / "postwin", native, deadline_ns, boot_id)
            require(scope.wait_empty(deadline_ns), "owned processes did not close under the original deadline")
            end_ns = time.monotonic_ns()
            require(end_ns < deadline_ns, "timed endpoint is late")
    except BaseException as caught:
        failure = caught
        end_ns = time.monotonic_ns() if origin_ns is not None else None

    # Reporting and emergency cleanup do not dispatch proof work or change origin.
    # If cancellation arrives after a saved completion fact, outer operation is
    # canceled; the earlier ACK/raw snapshots remain unmodified.
    if scope is None:
        prior = failure if isinstance(failure, (measure.Canceled, KeyboardInterrupt)) else None
        try:
            with measure.DeferredCancellation(prior, phase="unfunded-probe-setup-report") as handoff:
                report = {"schema": SCHEMA, "declaration_sha256": declaration_sha,
                          "outcome": "CANCELED" if handoff.canceled_signal is not None else "SETUP_FAILED",
                          "planned_rows": rows, "error": {"type": type(failure).__name__, "message": str(failure)},
                          "canceled_signal": handoff.canceled_signal, "cancellation_event": handoff.pending_event(),
                          "origin_monotonic_ns": None, "eligible_complete_postwin_observed": False,
                          "setup": setup, "source_before": source_before, "limits": contract["limits"],
                          "result_is_pre_handoff_snapshot": True}
                write_new(out / "result.json", report)
                handoff.published_snapshot("unfunded-probe", out / "result.json")
        except (measure.Canceled, KeyboardInterrupt) as caught:
            measure.publish_cancellation(out / "operation-cancellation.json", caught, "unfunded-probe-setup")
        return 1
    prior = failure if isinstance(failure, (measure.Canceled, KeyboardInterrupt)) else None
    reporting_errors = []
    raw_terminal = {}
    try:
        with measure.cancel_on_signals():
            live = (deadline_ns / 1e9, boot_id) if deadline_ns is not None else None
            with measure.DeferredCancellation(prior, phase="unfunded-probe-report", live_deadline=live) as handoff:
                if scope is not None:
                    try:
                        cleanup_known = not scope.remaining() or scope.cleanup()
                        timed_after = scope.snapshot()
                        enforce_resources(timed_after, sorted(os.sched_getaffinity(0)))
                    except BaseException as caught:
                        reporting_errors.append({"type": type(caught).__name__, "message": str(caught), "scope": "owned-cgroup-cleanup"})
                        cleanup_known = False
                try:
                    for pin in all_pins(contract):
                        pinned(pin)
                    require(sha(declaration_path) == declaration_sha, "original declaration changed")
                    source_after = source_check(audit, "source-after")
                    raw_terminal = collect_terminal_observations(out, native, origin_ns, deadline_ns, boot_id)
                    audit_ok = True
                except BaseException as caught:
                    reporting_errors.append({"type": type(caught).__name__, "message": str(caught), "scope": "postrun-audit"})
                signal_value = handoff.canceled_signal
                outcome = ("SETUP_FAILED" if origin_ns is None else
                           decide(rows, end_ns, deadline_ns, signal_value, cleanup_known, audit_ok, failure))
                if outcome != "COMPLETE_OBSERVED_WITHIN_ORIGINAL_BUDGET":
                    for row in rows:
                        if not row["dispatched"]:
                            row["reason"] = ("ORIGINAL_DEADLINE_EXHAUSTED_BEFORE_DISPATCH"
                                             if deadline_ns is not None and time.monotonic_ns() >= deadline_ns
                                             else "EARLIER_STAGE_OR_SETUP_FAILED")
                report = {"schema": SCHEMA, "declaration_sha256": declaration_sha,
                    "source": contract["source"], "funding_status": "UNFUNDED", "outcome": outcome,
                    "planned_rows": rows, "origin_monotonic_ns": origin_ns,
                    "original_deadline_monotonic_ns": deadline_ns, "original_deadline_boot_id": boot_id,
                    "timed_endpoint_observed_monotonic_ns": end_ns,
                    "timed_scope_ns": end_ns - origin_ns if end_ns is not None else None,
                    "canceled_signal": signal_value, "cancellation_event": handoff.pending_event(),
                    "error": None if failure is None else {"type": type(failure).__name__, "message": str(failure)},
                    "reporting_errors": reporting_errors, "setup": setup,
                    "source_before": source_before, "source_after": source_after,
                    "native_observation": native, "postwin_observation": postwin,
                    "eligible_complete_postwin_observed": postwin is not None,
                    "raw_terminal_observations": raw_terminal,
                    "complete_proof_claim_is_not_operation_success": True,
                    "owned_scope_closed_observed": cleanup_known,
                    "scope_at_setup_validation": initial_cgroup_snapshot,
                    "scope_before_native": timed_before, "scope_after_timed_path_and_cleanup": timed_after,
                    "cpu_ns_for_timed_path_plus_cleanup": (timed_after["cpu_usage_ns"] - timed_before["cpu_usage_ns"]
                                                          if timed_before and timed_after else None),
                    "resource_accounting_note": "one cgroup delta only; includes outer supervision/cleanup, excludes later audit; do not add nested wait4 or RSS",
                    "memory_note": "cumulative Hepta job peak includes setup; not aggregate instantaneous proof RSS",
                    "deadline_exhausted_at_reporting_snapshot": deadline_ns is not None and time.monotonic_ns() >= deadline_ns,
                    "timed_endpoint_scope": contract["timed_endpoint"], "postrun_audit_scope": contract["postrun_audit_scope"],
                    "result_is_pre_handoff_snapshot": True, "actual_exit_zero_and_no_cancellation_sidecar_required": True,
                    "limits": contract["limits"]}
                write_new(out / "result.json", report)
                handoff.published_snapshot("unfunded-probe", out / "result.json")
    except (measure.Canceled, KeyboardInterrupt) as caught:
        measure.publish_cancellation(out / "operation-cancellation.json", caught, "unfunded-original-budget-probe")
    print(json.dumps({"schema": SCHEMA, "outcome": report["outcome"], "report": str(out / "result.json")}))
    if report["outcome"] == "DEADLINE_EXHAUSTED":
        return 124
    return 0 if report["outcome"] == "COMPLETE_OBSERVED_WITHIN_ORIGINAL_BUDGET" else 1


def main(argv=None, measure=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    run = sub.add_parser("run")
    run.add_argument("--execute", action="store_true", required=True)
    run.add_argument("--declaration", type=Path, required=True)
    run.add_argument("--declaration-sha256", required=True)
    args = parser.parse_args(argv)
    require(measure is not None, "pinned A measurement module required")
    with measure.cancel_on_signals():
        return run_actual(args.declaration, args.declaration_sha256, measure)


def cli():
    pinned({"path": str(REPO / STAGE_REL), "sha256": STAGE_SHA})
    measure = load_module("probe_stage_measure", REPO / STAGE_REL)
    return measure.run_cli(lambda: main(measure=measure))


if __name__ == "__main__":
    raise SystemExit(cli())
