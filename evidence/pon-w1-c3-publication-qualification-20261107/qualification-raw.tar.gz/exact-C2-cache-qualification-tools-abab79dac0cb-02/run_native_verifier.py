#!/usr/bin/env python3
import argparse,atexit,collections,hashlib,json,os,pathlib,re,signal,subprocess,sys,time
ROOT=pathlib.Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
parser=argparse.ArgumentParser(description="Exact frozen integration native/verifier qualification; no full proof dispatch")
parser.add_argument("--expected-head",required=True)
parser.add_argument("--expected-tree",required=True)
parser.add_argument("--attempt",required=True)
parser.add_argument("--target-dir",type=pathlib.Path,required=True)
parser.add_argument("--output-dir",type=pathlib.Path,required=True)
parser.add_argument("--cache-setup",type=pathlib.Path,required=True)
parser.add_argument("--cache-setup-sha256",required=True)
args=parser.parse_args()
assert re.fullmatch(r"[0-9a-f]{40}",args.expected_head),"full final commit required"
assert re.fullmatch(r"[0-9a-f]{40}",args.expected_tree),"full final tree required"
assert re.fullmatch(r"[0-9]{2}",args.attempt),"unique two-digit attempt required"
A=args.expected_head; TREE=args.expected_tree
REPO=ROOT/"integration-repo"
OUT=args.output_dir
TARGET=args.target_dir
assert OUT.is_absolute() and TARGET.is_absolute() and ROOT in OUT.parents and ROOT in TARGET.parents
assert REPO not in OUT.parents and REPO not in TARGET.parents
assert TARGET==ROOT/("target-native-exact-"+A[:12]+"-"+args.attempt)
assert OUT==ROOT/("clean-exact-native-verifier-"+A[:12]+"-"+args.attempt)
target_existed_before=TARGET.exists()
target_entries_before=sorted(p.name for p in TARGET.iterdir()) if target_existed_before else []
os.sched_setaffinity(0,{22,23})
assert os.sched_getaffinity(0)=={22,23},"requested two-CPU affinity required"
TOOLCHAIN=pathlib.Path("/home/qian-qi/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin")
CARGO=str(TOOLCHAIN/"cargo")
OUT.mkdir(exist_ok=False)
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(args.cache_setup)==args.cache_setup_sha256
cache_setup=json.loads(args.cache_setup.read_bytes())
assert cache_setup['cache_setup_complete'] is True and cache_setup['role']=='native'
assert cache_setup['source_commit']==A and cache_setup['source_tree']==TREE
assert cache_setup['destination_target']==str(TARGET) and cache_setup['shared_original_regular_inodes']==0
assert cache_setup['fresh_cargo_target'] is False and TARGET.is_dir()
for old in cache_setup['original_C2_binaries'].values():assert sha(old['path'])==old['sha256']
reassessment_path=ROOT/'native-verifier-count-reassessment-cb557c5e59b0-01/assessment.json'
assert sha(reassessment_path)=='a5c357ab2c885cf12b0d85c691f4387f302d5cf86eda1faad700b6a623c36e76'
reassessment=json.loads(reassessment_path.read_bytes())
assert reassessment['accepted'] is True and reassessment['actual_native_test_count']==243
roster_pin=reassessment['fixed_expected_roster']
assert sha(roster_pin['path'])==roster_pin['sha256']
roster=json.loads(pathlib.Path(roster_pin['path']).read_bytes())
assert roster['count']==243 and sum(row['count'] for row in roster['tests'])==243
expected_names=collections.Counter({row['name']:row['count'] for row in roster['tests']})
assert len(expected_names)==len(roster['tests'])
def save(name,value):
 p=OUT/name
 with p.open("w") as f: json.dump(value,f,indent=2,sort_keys=True);f.write("\n");f.flush();os.fsync(f.fileno())
env=os.environ.copy()
env.update({"PATH":str(TOOLCHAIN)+":"+env["PATH"],"RUSTUP_TOOLCHAIN":"1.95.0","CARGO_TARGET_DIR":str(TARGET),"CARGO_BUILD_JOBS":"2","RUST_TEST_THREADS":"1","PYTHONDONTWRITEBYTECODE":"1","RAYON_NUM_THREADS":"2"})
provider=ROOT/"setup-evidence/native-openssl-provider-01/exported.env"
expected_env={"OPENSSL_DIR","OPENSSL_STATIC","TRNM_PQ_OPENSSL","TRNM_PQ_OPENSSL_SHA256","TRNM_PQ_OPENSSL_VERSION","OPENSSL_CONF","OPENSSL_MODULES"}
values={}
for line in provider.read_text().splitlines():
 k,v=line.split("=",1);assert k in expected_env and k not in values;values[k]=v
assert sha(provider)=="378c4c53a9442613075fde8c5750166d13e1699777cc222128354efcb6b9ff86"
assert set(values)==expected_env and values["OPENSSL_STATIC"]=="1" and values["TRNM_PQ_OPENSSL_VERSION"]=="3.5.9"
prefix=ROOT/"setup-evidence/native-openssl-provider-01/tmp/trnm-pq-provider-3.5.9.pJT891kv/install"
assert values["OPENSSL_DIR"]==str(prefix) and values["OPENSSL_CONF"]=="/dev/null"
assert values["OPENSSL_MODULES"]==str(prefix/"lib/ossl-modules")
assert sha(values["TRNM_PQ_OPENSSL"])==values["TRNM_PQ_OPENSSL_SHA256"]=="e3126bc611b4f8db33561bd4d594d1ecf789499b13f36164e188590deab9c89b"
env.update(values)
assert "RISC0_SKIP_BUILD" not in env and "RISC0_DEV_MODE" not in env
assert "RUSTC_WRAPPER" not in env and "RUSTC_WORKSPACE_WRAPPER" not in env
rows=[]
original_manifest=ROOT/"clean-A-native-verifier-01/manifest.json"
assert sha(original_manifest)=="2c0c45cc9f126f377e8dabad7350330d9be55beb9b58cbfb422fc03b7d692eff"
original_qualification=json.loads(original_manifest.read_text())
assert original_qualification["passed"] is True
save("predecessor-A-manifest.json",original_qualification)
save("environment.json",{"explicit_toolchain_and_target":{"PATH":env["PATH"],"RUSTUP_TOOLCHAIN":env["RUSTUP_TOOLCHAIN"],"CARGO_TARGET_DIR":str(TARGET),"CARGO_BUILD_JOBS":"2","RUST_TEST_THREADS":"1","RAYON_NUM_THREADS":"2"},"qualified_openssl_environment":values,"qualified_environment_path":str(provider),"qualified_environment_sha256":sha(provider),"LD_LIBRARY_PATH_inherited":env.get("LD_LIBRARY_PATH"),"target_existed_before":target_existed_before,"target_initial_entries":target_entries_before,"fresh_cargo_target_means_directory_absent_only":True,"independent_reproducible_build_established":False,"wrapper_sha256":sha(__file__),"predecessor_wrapper_sha256":"7dacec8c5bdbb8de2f9bb323999d92dd04dc6bba67d82425853c50a488fbca2a","wrapper_argv":sys.argv})
# This observer records resource controls; it never claims complete process-tree billing.
def observe_resource(label):
 membership=pathlib.Path("/proc/self/cgroup").read_text().strip()
 assert membership.startswith("0::/") and "\n" not in membership
 group=pathlib.Path("/sys/fs/cgroup")/membership[3:].lstrip("/")
 assert group.name.startswith("hepta-runtime-job-") and group.name.endswith(".service")
 controls={name:(group/name).read_text() for name in ("cpu.max","memory.max","cpu.stat","memory.current","memory.peak","cgroup.events")}
 quota,period=controls["cpu.max"].split()
 assert quota!="max" and 0<int(quota)<=2*int(period)
 assert controls["memory.max"].strip()!="max" and 0<int(controls["memory.max"])<=8589934592
 value={"boot_id":pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip(),"pid":os.getpid(),"affinity":sorted(os.sched_getaffinity(0)),"membership_raw":membership,"cgroup_path":str(group),"controls_raw":controls,"complete_resource_accounting":False}
 save("resource-"+label+".json",value)
 return value
resource_before=observe_resource("before")
# Even an early assertion retains a distinct incomplete manifest; it never becomes PASS.
def incomplete_at_exit():
 if not (OUT/"manifest.json").exists():
  save("incomplete.json",{"schema":"TRNM-W1-INTEGRATION-NATIVE-VERIFIER-INCOMPLETE1","source_commit":A,"source_tree":TREE,"repo_path":str(REPO),"passed":False,"qualification_complete":False,"commands":rows,"target_existed_before":target_existed_before,"source_after_observed":(OUT/"source-after.json").exists(),"proof_launched":False})
atexit.register(incomplete_at_exit)
def run(label,argv,timeout=1800):
 stdout=OUT/(label+".stdout");stderr=OUT/(label+".stderr")
 started=time.monotonic_ns();timed_out=False;proc=None;code=None;failure=None;cleanup=[];caught=None
 with stdout.open("xb") as so,stderr.open("xb") as se:
  try:
   proc=subprocess.Popen(argv,cwd=REPO,env=env,stdout=so,stderr=se,start_new_session=True)
   try: code=proc.wait(timeout=timeout)
   except subprocess.TimeoutExpired:
    timed_out=True
    # This leader has not been reaped; its new session still owns the PGID.
    try: os.killpg(proc.pid,signal.SIGTERM);cleanup.append({"signal":int(signal.SIGTERM),"outcome":"SENT"})
    except ProcessLookupError:cleanup.append({"signal":int(signal.SIGTERM),"outcome":"ALREADY_ABSENT"})
    try: code=proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
     try: os.killpg(proc.pid,signal.SIGKILL);cleanup.append({"signal":int(signal.SIGKILL),"outcome":"SENT"})
     except ProcessLookupError:cleanup.append({"signal":int(signal.SIGKILL),"outcome":"ALREADY_ABSENT"})
     code=proc.wait(timeout=30)
  except BaseException as exc:
   caught=exc
   failure={"type":type(exc).__name__,"message":str(exc)}
   if proc is not None and proc.returncode is None:
    # Never signal a saved PGID after Popen has already reaped its leader.
    try: os.killpg(proc.pid,signal.SIGKILL);cleanup.append({"signal":int(signal.SIGKILL),"outcome":"SENT_AFTER_ERROR"})
    except ProcessLookupError:cleanup.append({"signal":int(signal.SIGKILL),"outcome":"ALREADY_ABSENT_AFTER_ERROR"})
    except BaseException as err:cleanup.append({"cleanup_error":f"{type(err).__name__}: {err}"})
    try:code=proc.wait(timeout=30)
    except BaseException as err:cleanup.append({"wait_error":f"{type(err).__name__}: {err}"})
  finally:
   so.flush();os.fsync(so.fileno());se.flush();os.fsync(se.fileno())
 row={"label":label,"argv":argv,"cwd":str(REPO),"exit":code,"timed_out":timed_out,"error":failure,"cleanup_observations":cleanup,"direct_child_waited":proc is not None and proc.returncode is not None,"all_descendants_reaped":None,"wall_ns":time.monotonic_ns()-started,"stdout_path":str(stdout),"stderr_path":str(stderr),"stdout_sha256":sha(stdout),"stderr_sha256":sha(stderr)}
 rows.append(row);save("commands.json",rows)
 print(json.dumps(row),flush=True)
 if caught is not None:raise caught
 return code if failure is None else 1

def text_cmd(label,argv):
 code=run(label,argv,180);assert code==0,label
 return (OUT/(label+".stdout")).read_text().strip()
assert text_cmd("00-head",["git","rev-parse","HEAD"])==A
assert text_cmd("01-tree",["git","rev-parse","HEAD^{tree}"])==TREE
assert text_cmd("02-clean",["git","status","--porcelain=v1","--untracked-files=all"])==""
assert run("03-preflight",["/usr/bin/bash","scripts/project-preflight.sh","--dev"],180)==0
assert run("04-source-before",["/usr/bin/python3","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",A,"--output",str(OUT/"source-before.json")],180)==0
lock_paths=["trillionnium/Cargo.lock","formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock","formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock"]
locks_before={p:sha(REPO/p) for p in lock_paths};save("locks-before.json",locks_before)
run("05-rustc-version",[str(TOOLCHAIN/"rustc"),"--version","--verbose"],120)
run("06-cargo-version",[CARGO,"--version","--verbose"],120)
for name,manifest in [("native","trillionnium/Cargo.toml"),("verifier","formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.toml")]:
 for mode in ("default","all"):
  argv=[CARGO,"metadata","--locked","--offline","--manifest-path",manifest,"--format-version","1"]
  if mode=="all":argv+=["--all-features"]
  run("07-"+name+"-graph-"+mode,argv,300)
run("08-owned-fmt",[str(TOOLCHAIN/"rustfmt"),"--check","--edition","2021","--config","skip_children=true","trillionnium/crates/trnm-crypto-primitives/examples/pon_w1_native_winner_v2.rs","formal/pon-nakamoto-v1/w1_v2_verifier/src/main.rs"],180)
run("09-native-clippy",[CARGO,"clippy","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","-p","trnm-crypto-primitives","--all-targets","--all-features","--","-D","warnings"])
run("10-native-tests",[CARGO,"test","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","-p","trnm-crypto-primitives","--all-targets","--all-features","--","--test-threads=1"])
run("11-verifier-clippy",[CARGO,"clippy","--locked","--offline","--manifest-path","formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.toml","--all-targets","--all-features","--","-D","warnings"])
run("12-verifier-tests",[CARGO,"test","--locked","--offline","--manifest-path","formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.toml","--all-targets","--all-features","--","--test-threads=1"])
run("13-native-winner-build",[CARGO,"build","--release","--locked","--offline","--manifest-path","trillionnium/Cargo.toml","-p","trnm-crypto-primitives","--example","pon_w1_native_winner_v2","--message-format=json"])
run("14-verifier-build",[CARGO,"build","--release","--locked","--offline","--manifest-path","formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.toml","--message-format=json"])
binaries={}
for role,label,name in [("native_winner","13-native-winner-build","pon_w1_native_winner_v2"),("verifier","14-verifier-build","w1-verify-v2")]:
 records=[]
 for line in (OUT/(label+".stdout")).read_text().splitlines():
  try:r=json.loads(line)
  except json.JSONDecodeError:continue
  if r.get("reason")=="compiler-artifact" and r.get("target",{}).get("name")==name and r.get("executable"):records.append(r)
 if len(records)==1:
  r=records[0];p=pathlib.Path(r["executable"]);assert TARGET in p.parents and p.read_bytes()[:6]==b"\x7fELF\x02\x01"
  binaries[role]={"path":str(p),"bytes":p.stat().st_size,"sha256":sha(p),"kind":"repository_build","cargo_fresh":r["fresh"],"cargo_artifact":r}
if "verifier" in binaries:
 hist=REPO/"evidence/pon-w1-full-v2-20261105"
 run("15-real-receiver-controls",["/usr/bin/python3","scripts/ci/test_w1_receiver_real.py","--verifier",binaries["verifier"]["path"],"--verifier-sha256",binaries["verifier"]["sha256"],"--receipt",str(hist/"succinct.bin"),"--input",str(hist/"input.bin"),"--header",str(hist/"header.bin"),"--expected-artifacts",str(hist/"expected-artifacts.bin"),"--out",str(OUT/"real-receiver-controls")],300)
run("16-source-after",["/usr/bin/python3","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",A,"--output",str(OUT/"source-after.json")],180)
locks_after={p:sha(REPO/p) for p in lock_paths};save("locks-after.json",locks_after)
source_reports={}
for phase in ("before","after"):
 p=OUT/("source-"+phase+".json");v=json.loads(p.read_text())
 assert v["tested_commit"]==A and v["tested_tree"]==TREE and v["tracked_worktree_verified"] is True and v["tests_executed_by_identity_check"] is False
 source_reports["source_"+phase]={"report_path":str(p),"sha256":sha(p),"tested_commit":A,"tested_tree":TREE}
counts={}
for label in ("10-native-tests","12-verifier-tests"):
 text=(OUT/(label+".stdout")).read_text()
 values=[tuple(map(int,x)) for x in re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;",text)]
 counts[label]={"groups":len(values),"passed":sum(x[0] for x in values),"failed":sum(x[1] for x in values),"ignored":sum(x[2] for x in values)}
clean=text_cmd("17-final-clean",["git","status","--porcelain=v1","--untracked-files=all"])==""
def normalized_to_predecessor(argv):
 old_repo=str(ROOT/"repo"); old_out=str(ROOT/"clean-A-native-verifier-01"); old_target=str(ROOT/"target-native")
 result=[]
 for arg in argv:
  arg=arg.replace(str(REPO),old_repo).replace(str(OUT),old_out).replace(str(TARGET),old_target)
  if arg==A: arg="d3037ca5dfb6f301757c159b7888dca9b0317be0"
  if arg==TREE: arg="d4a8f84cdc896b9454ce0d03a164f8916e6afdf9"
  if "verifier" in binaries and arg==binaries["verifier"]["sha256"]: arg=original_qualification["binaries"]["verifier"]["sha256"]
  result.append(arg)
 return result
assert len(rows)==len(original_qualification["commands"])==21,"all existing qualification commands required"
assert all(new["label"]==old["label"] and normalized_to_predecessor(new["argv"])==old["argv"] for new,old in zip(rows,original_qualification["commands"])),"original command contract changed beyond source/target/output/binary identity"
actual_names=collections.Counter(line[5:-7] for line in (OUT/'10-native-tests.stdout').read_text().splitlines()
    if line.startswith('test ') and line.endswith(' ... ok'))
actual_groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',
    (OUT/'10-native-tests.stdout').read_text())
assert len(actual_groups)==26 and all(tuple(map(int,g))[1:]==(0,0,0,0) for g in actual_groups)
assert actual_names==expected_names and sum(actual_names.values())==243,'exact current retained native roster changed'
receiver_text=(OUT/'15-real-receiver-controls.stderr').read_text()
assert [int(line.split()[1]) for line in receiver_text.splitlines() if line.startswith('Ran ') and ' tests in ' in line]==[7]
assert 'OK' in receiver_text.splitlines(),'exact seven actual receiver controls required'
for old in cache_setup['original_C2_binaries'].values():assert sha(old['path'])==old['sha256'],'C2 qualified ELF changed'
passed=all(r["exit"]==0 and not r["timed_out"] and r["error"] is None for r in rows) and clean and locks_before==locks_after and set(binaries)=={"native_winner","verifier"} and counts["10-native-tests"]["passed"]==243 and counts["12-verifier-tests"]["passed"]==2 and all(v["failed"]==0 and v["ignored"]==0 for v in counts.values())
manifest={"schema":"TRNM-W1-INTEGRATION-NATIVE-VERIFIER1","source_commit":A,"source_tree":TREE,"repo_path":str(REPO),"passed":passed,"source_clean_after":clean,"fresh_cargo_target":not target_existed_before,"target_existed_before":target_existed_before,"target_initial_entries":target_entries_before,"target_dir":str(TARGET),"fresh_cargo_target_means_directory_absent_only":True,"independent_reproducible_build_established":False,"commands":rows,"binaries":binaries,"test_counts":counts,"locks_unchanged":locks_before==locks_after,"openssl_env_sha256":sha(provider),**source_reports}
manifest['strict_native_roster']={'count':243,'exact_actual_names_equal':True,'expected_roster':roster_pin,
    'reassessment_path':str(reassessment_path),'reassessment_sha256':sha(reassessment_path),'actual_groups':26,'actual_receiver_controls':7}
manifest['copied_cache_setup']={'path':str(args.cache_setup),'sha256':args.cache_setup_sha256}
manifest['original_C2_binaries']=cache_setup['original_C2_binaries']
manifest['original_C2_binaries_unchanged_after']=True
manifest['fresh_cargo_target']=False
manifest["resource_after"]=observe_resource("after")
manifest["qualified_environment_path"]=str(provider)
manifest["wrapper_sha256"]=sha(__file__)
manifest["predecessor_wrapper_sha256"]="7dacec8c5bdbb8de2f9bb323999d92dd04dc6bba67d82425853c50a488fbca2a"
manifest["predecessor_A_manifest_sha256"]=sha(original_manifest)
manifest["proof_launched"]=False
manifest["receiver_control_uses_historical_receipt"]=True
save("manifest.json",manifest)
print(json.dumps({"passed":passed,"manifest_path":str(OUT/"manifest.json"),"manifest_sha256":sha(OUT/"manifest.json"),"test_counts":counts,"binaries":{k:{kk:vv for kk,vv in v.items() if kk!="cargo_artifact"} for k,v in binaries.items()}}),flush=True)
raise SystemExit(0 if passed else 1)
