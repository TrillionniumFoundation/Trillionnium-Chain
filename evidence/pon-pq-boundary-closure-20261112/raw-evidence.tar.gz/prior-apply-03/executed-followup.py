#!/usr/bin/env python3
"""Apply bounded peer controls and atomic retained-cache staging after the complete C2 observation."""
import argparse
import base64
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/work/chain-pq-boundary-closure-20261112-4150')
PRIOR_HEAD = '13bdc38023d57607a9ba81f52e123f7fb556bec3'
BASE = '8970e2c81abbf48e2a4d3f0802d79624ab20fadd'
INGRESS = 'de7acc8a59d77f11be4c17c380cc9c2bca91905c'
PRIOR = Path('/home/qian-qi/work/pq-boundary-validation-20261112-4150-v2')
PACKETS = (
    ('peer', Path('/home/qian-qi/work/pq-boundary-bounded-peer-package-4150.json'),
     '1c31d1173662a70e2843420be8a772f99b0007905fbe76f58b0527783d680c11'),
    ('paired-cache', Path('/home/qian-qi/work/pq-boundary-paired-cache-package-4150.json'),
     'cda83252fdbe3512535343008e7a76c7f12bbf336ac06cd36c0b7a1c74d9f3be'),
    ('retained-plan', Path('/home/qian-qi/work/pq-boundary-retained-plan-package-4150.json'),
     '80afbf1a414560b28c931480bf2fd684c097ceec96b1869b9751e0ccb72a5022'),
)
DIAGNOSIS = Path('/home/qian-qi/work/pq-boundary-pq41-diagnosis-package-4150.json')
DIAGNOSIS_SHA256 = '10f73c298d123e23fde30acc9bcded487ec81c80efa8922d42ab69b2551d836e'
PRIOR_RECEIPT_SHA256 = '42efd7039031ada68472ed2907a01b1714482d65edd8b2f921ee35f3ae64003c'
SOURCE_FILES = {
    'trillionnium/crates/trnm-data-availability/src/cell/bep52_peer/tests.rs',
    'trillionnium/crates/trnm-data-availability/src/cell/store.rs',
    'trillionnium/crates/trnm-data-availability/src/cell/cache_wal_tests.rs',
    'trillionnium/crates/trnm-data-availability/src/cell/erasure/provider.rs',
    'trillionnium/crates/trnm-data-availability/src/cell/erasure/retained_plan.rs',
    'trillionnium/crates/trnm-data-availability/src/cell/erasure/provider/tests.rs',
}
KNOWN_FAILURES = {
    'da-default-lib': (-15, 'c4fa3a0af8115d54dd6650e457eb73a0ecfd53ec34c3771e915d04e55d1c27eb'),
    'da-all-features-lib': (101, '4d8e2409dab3345e669cc649c148482b8f5635d31125e825ee4c4028ee489fc0'),
    'pq-native-41': (101, '7965cb205e97287543474b2f41a3702f71442946fb504b659ea3b1ef3fbad904'),
}
CORPUS = 'config/pon/pq-cross-branch-corpus-v1.json'
BUDGET = 'config/pon/pq128-lifetime-budget-v1.json'
LOCK = 'config/pon/pq128-source-lock-v1.json'
ROOT_REGISTER = 'config/pon/pq-root-dependency-register-v3.json'
PLAN = 'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md'
INVENTORY = 'trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs'
ALLOWED = SOURCE_FILES | {CORPUS, BUDGET, LOCK, PLAN, INVENTORY}
NOTE = """**Bounded peer cleanup and atomic retained-cache staging, 2026-11-12 — HOLD:**

The complete single-threaded observation on
`13bdc38023d57607a9ba81f52e123f7fb556bec3` retained three unsuccessful commands.
The default DA command was explicitly interrupted by the operator after a
read-only join/accept wait observation; it had no complete native summary.
The all-features DA library reported 733 passed and one failed, with
CacheWriterBusy from the original 65/128 capacity control. That error can also
mean an expired deadline and does not prove another writer existed. PQ exact
control 41 exhausted the unchanged production 250 ms witness exchange budget;
without an authenticated matching receipt, the node refused local commit.
Checkpoint's 58 methods including four socket controls and the other recorded
checks remain separate observations. All original failures and source/provider
receipts are retained; none is rewritten as a success.

The existing slow fragmented-handshake fixture could reject before dialing and
then wait indefinitely for its peer. Bound fixture cleanup while preserving the
original full fetch entry and its 120 ms / 600 ms / unchanged-deadline / byte
assertions. Add a separate actual production socket-handshake observation and an
explicit no-connection cleanup control. Required-connection fixtures still
reject a missing connection.

The retained-plan path previously staged each of six verified shards through
separate manifest and chunk transactions. Add a narrow paired cache batch with
at most eight members and 32 MiB of complete inputs, checking every canonical
single-chunk manifest, content pin and payload before the existing writer
boundary. Group the six slots of each original chunk into one such transaction
in build and catalog staging. Keep the existing FULL pager, WAL/reader refusal,
quota triggers, writer identity and caller deadline; publish a plan only after
its full build succeeds. Preserve the original cold empty cache, source-file
deletion, 65/128 workloads, six slots and ten-second absolute deadline.
The source-derived transaction count falls from 13N+2 to 2N+2; this is not yet a
runtime performance claim. Require the unchanged capacity control plus new late
invalid-input, quota rollback, actual deadline propagation, reader refusal and
cold-reopen observations on the new source.

The PQ exchange cap, fail-closed path and receipt requirement are unchanged.
A later successful control is a new source-bound observation and cannot erase
the prior measured budget refusal or establish its physical timing cause.

Re-anchor the same twenty-one directly registered implementation objects to
this source checkpoint. Their bytes and the Root dependency register remain
unchanged; this partial direct inventory is not the complete call graph. All
eight lifetime terms stay unknown/null. Ordinary callers, public WAN,
historical migration, independent custody, W1/DAA hardness, FinalUse and
whole-chain production qualification remain unproved.

"""


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw,
                        usedforsecurity=False).hexdigest()


def put(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n')


def main():
    if sys.flags.optimize:
        raise RuntimeError('apply helper requires Python assertions enabled')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    assert args.output.is_absolute() and not out.is_relative_to(ROOT)
    out.mkdir(exist_ok=False)
    (out / 'executed-followup.py').write_bytes(Path(__file__).read_bytes())
    os.chdir(ROOT)
    os.environ['PATH'] = '/home/qian-qi/.cargo/bin:' + os.environ['PATH']
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    os.environ['GIT_NO_LAZY_FETCH'] = '1'
    os.environ['GIT_NO_REPLACE_OBJECTS'] = '1'
    sys.dont_write_bytecode = True
    records = []

    def run(label, argv, timeout=600):
        start = time.monotonic_ns()
        p = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, timeout=timeout)
        (out / (label + '.stdout')).write_bytes(p.stdout)
        (out / (label + '.stderr')).write_bytes(p.stderr)
        row = {'label': label, 'argv': argv, 'returncode': p.returncode,
               'elapsed_ns': time.monotonic_ns() - start}
        records.append(row)
        put(out / 'commands.json', records)
        print(json.dumps(row), flush=True)
        p.check_returncode()
        return p.stdout.decode().strip()

    def git(*argv):
        return subprocess.check_output(['git', *argv], cwd=ROOT, text=True).strip()

    def object_bytes(revision, name):
        return subprocess.check_output(['git', 'cat-file', 'blob', revision + ':' + name], cwd=ROOT)

    def changed():
        names = set(git('diff', '--name-only', PRIOR_HEAD).splitlines())
        names.update(git('ls-files', '--others', '--exclude-standard').splitlines())
        assert names <= ALLOWED, sorted(names - ALLOWED)
        return names

    def refresh_corpus(label):
        names = changed() - {CORPUS}
        old = json.loads((ROOT / CORPUS).read_bytes())
        value = copy.deepcopy(old)
        for name, expected in old['pinned_blobs'].items():
            actual = blob((ROOT / name).read_bytes())
            assert actual == expected or name in names, ('unrelated stale pin', name)
        rows = []
        for name in sorted(names):
            raw = (ROOT / name).read_bytes()
            assert len(raw) <= 4_194_304
            rows.append({'path': name, 'before': value['pinned_blobs'].get(name),
                         'after': blob(raw), 'sha256': sha(raw), 'bytes': len(raw)})
            value['pinned_blobs'][name] = blob(raw)
            if name not in value['required_paths']:
                value['required_paths'].append(name)
        assert all(value[k] == old[k] for k in old if k not in ('pinned_blobs', 'required_paths'))
        assert set(old['required_paths']) <= set(value['required_paths'])
        put(ROOT / CORPUS, value)
        put(out / (label + '.json'), rows)

    run('preflight-before-inspection', ['bash', 'scripts/project-preflight.sh'])
    assert git('rev-parse', 'HEAD') == PRIOR_HEAD and not git('status', '--porcelain')
    prior_raw = (PRIOR / 'validation.json').read_bytes()
    assert sha(prior_raw) == PRIOR_RECEIPT_SHA256
    prior = json.loads(prior_raw)
    assert prior['source'] == PRIOR_HEAD and prior['completed'] is True
    assert prior['all_requested_component_checks_passed'] is False
    assert prior['failures'] == list(KNOWN_FAILURES)
    assert [row['label'] for row in prior['commands'] if not row['component_check_passed']] == list(KNOWN_FAILURES)
    for row in prior['commands']:
        if row['label'] in KNOWN_FAILURES:
            assert (row['exit_code'], row['log_sha256']) == KNOWN_FAILURES[row['label']]
        else:
            assert row['component_check_passed'] is True and row['exit_code'] == 0
    stop = json.loads((PRIOR / 'operator-interruption-da-default-result.json').read_bytes())
    assert stop['schema'] == 'pq-operator-test-interruption-v1' and stop['source'] == PRIOR_HEAD
    assert stop['label'] == 'da-default-lib' and stop['signal_dispatched'] is True
    assert stop['automatic_timeout_expired'] is False and stop['native_assertion_failure_claimed'] is False
    assert stop['production_process'] is False
    assert prior['runtime_test_threads'] == 1
    assert len(prior['commands']) == 90 and 'error' not in prior
    assert prior['source_before'] == prior['source_after']
    assert prior['provider_before'] == prior['provider_after']
    assert prior['provider_after']['all_five_match'] is True
    for name, pin in prior['artifact_files'].items():
        raw = (PRIOR / name).read_bytes()
        assert {'bytes': len(raw), 'sha256': sha(raw)} == pin, name
    sys.path.insert(0, str(ROOT / 'scripts/ci'))
    from verify_ci_source import verify
    assert verify('head', PRIOR_HEAD, None, None, ROOT) == prior['source_after']
    put(out / 'retained-prior-observation.json', {
        'source': PRIOR_HEAD, 'directory': str(PRIOR), 'validation_sha256': sha((PRIOR / 'validation.json').read_bytes()),
        'completed': True, 'failures': prior['failures'], 'all_requested_component_checks_passed': False,
        'raw_artifacts_unchanged': True, 'new_native_execution_claimed': False})
    diagnosis_raw = DIAGNOSIS.read_bytes()
    assert sha(diagnosis_raw) == DIAGNOSIS_SHA256
    (out / 'reviewed-pq41-derived-diagnosis-package.json').write_bytes(diagnosis_raw)
    diagnostic = json.loads(diagnosis_raw)
    diagnostic_dir = out / 'derived-pq41-diagnosis'
    diagnostic_dir.mkdir()
    for item in diagnostic['files']:
        assert Path(item['path']).name == item['path']
        raw = base64.b64decode(item['content_base64'], validate=True)
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
        with (diagnostic_dir / item['path']).open('xb') as stream:
            stream.write(raw)
    replacements = {}
    admitted = []
    for label, packet_path, packet_sha in PACKETS:
        raw = packet_path.read_bytes()
        assert sha(raw) == packet_sha
        package = json.loads(raw)
        (out / ('reviewed-' + label + '-package.json')).write_bytes(raw)
        for row in package['files']:
            name = row['path']
            assert name in SOURCE_FILES and name not in replacements
            before = (ROOT / name).read_bytes()
            assert sha(before) == row['before_sha256'] and before == object_bytes(PRIOR_HEAD, name)
            assert blob(before) == row['base_git_blob']
            replacement = base64.b64decode(row['content_base64'], validate=True)
            assert sha(replacement) == row['after_sha256']
            replacements[name] = replacement
            admitted.append({'path': name, 'packet_sha256': packet_sha,
                             'before_sha256': sha(before), 'reviewed_unformatted_sha256': sha(replacement)})
    assert set(replacements) == SOURCE_FILES
    run('preflight-before-edit', ['bash', 'scripts/project-preflight.sh'])
    for name, replacement in replacements.items():
        (ROOT / name).write_bytes(replacement)
    run('format-reviewed-rust', ['rustfmt', '+1.95.0', '--edition', '2021'] + sorted(SOURCE_FILES))
    for row in admitted:
        row['formatted_sha256'] = sha((ROOT / row['path']).read_bytes())
    put(out / 'reviewed-formatted-source.json', admitted)
    run('refresh-native-inventory', ['python3', '-B', 'scripts/refresh_distributed_source_inventory.py'])
    plan = ROOT / PLAN
    assert not plan.read_text().startswith(NOTE.splitlines()[0])
    plan.write_text(NOTE + plan.read_text())
    refresh_corpus('reviewed-followup-pins')
    run('workspace-fmt', ['cargo', '+1.95.0', 'fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check'])
    run('preflight-runtime-commit', ['bash', 'scripts/project-preflight.sh'])
    run('stage-runtime', ['git', 'add', '--'] + sorted(changed()))
    run('runtime-whitespace', ['git', 'diff', '--cached', '--check'])
    run('runtime-commit', ['git', 'commit', '-s', '-m', 'fix(da): batch retained-cache writes within original deadlines and bound peer cleanup'])
    r = git('rev-parse', 'HEAD')
    put(out / 'runtime.json', {'source': r, 'base': BASE, 'ingress_source': INGRESS})
    old_budget, old_lock = json.loads((ROOT / BUDGET).read_bytes()), json.loads((ROOT / LOCK).read_bytes())
    budget, lock = copy.deepcopy(old_budget), copy.deepcopy(old_lock)
    assert len(lock['files']) == 21
    bindings = []
    for name, expected in lock['files'].items():
        raw = object_bytes(r, name)
        assert raw == (ROOT / name).read_bytes() and sha(raw) == expected
        bindings.append({'path': name, 'sha256': expected, 'implementation_bytes_unchanged': True})
    assert object_bytes(r, ROOT_REGISTER) == object_bytes(PRIOR_HEAD, ROOT_REGISTER)
    run('preflight-source-register', ['bash', 'scripts/project-preflight.sh'])
    budget['experiment']['source_revision'] = lock['source_revision'] = r
    assert all(term['status'] == 'unknown' and term['bound'] is None for term in budget['terms'])
    assert len(budget['events']) == len(budget['terms']) == 8
    put(ROOT / BUDGET, budget)
    put(ROOT / LOCK, lock)
    put(out / 'lifetime-reviewed-source.json', bindings)
    refresh_corpus('reviewed-final-pins')
    run('stage-source-register', ['git', 'add', '--', BUDGET, LOCK, CORPUS])
    run('metadata-whitespace', ['git', 'diff', '--cached', '--check'])
    run('preflight-source-commit', ['bash', 'scripts/project-preflight.sh'])
    run('source-register-commit', ['git', 'commit', '-s', '-m', 'security(pq): rebind direct component inventory after bounded cache staging'])
    c = git('rev-parse', 'HEAD')
    assert set(git('diff', '--name-only', r, c).splitlines()) == {BUDGET, LOCK, CORPUS}
    assert not git('status', '--porcelain')
    for row in bindings:
        assert sha(object_bytes(c, row['path'])) == row['sha256']
    put(out / 'candidate.json', {'source': c, 'runtime_revision': r, 'base': BASE,
        'ingress_source': INGRESS, 'native_tests_executed_on_candidate': False,
        'whole_chain_pq_qualified': False, 'production_activation': False})
    print(json.dumps({'candidate_ready': c, 'runtime_revision': r,
                      'prior_source': PRIOR_HEAD, 'native_tests_executed': False}), flush=True)


if __name__ == '__main__':
    main()
