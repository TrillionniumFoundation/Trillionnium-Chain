#!/usr/bin/env python3
"""Additional archive/source/Cargo checks; never executes retained native binaries."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tomllib
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RUN = 41298626837
HEAD = "8327719ebd90ad08c1d66bc10f6c6fd79d7c0b47"
MERGE = "a7169139ce2a24f0d582ac348be8f74d56d44f9f"
TREE = "7b3bf58b08cf59ba1466059f3e0d5a7d8a96e74a"
CAPTURE = ROOT / f"ci-captures/run-{RUN}"


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


metadata_path = ROOT / f"ci-monitor/run-{RUN}-artifacts.json"
metadata = json.loads(metadata_path.read_text())["artifacts"]
lock_path = HERE / "reader-source/trillionnium/Cargo.lock"
manifest_path = HERE / "reader-source/trillionnium/Cargo.toml"
lock = tomllib.loads(lock_path.read_text())
workspace = tomllib.loads(manifest_path.read_text())
locked = {(p["name"], p["version"], p.get("source")) for p in lock["package"]}
locked_versions = {(p["name"], p["version"]) for p in lock["package"]}
expected_members = set(workspace["workspace"]["members"])
assert "release" not in workspace.get("profile", {})
assert json.loads((HERE / "merge-commit.json").read_text())["tree"] == TREE
results = []
graph_hashes = set()

for artifact in metadata:
    if not artifact["name"].startswith(("w1-false-trace-", "w1-legal-strategy-")):
        continue
    ident = str(artifact["id"])
    directory = CAPTURE / ident
    archive = ROOT / f"ci-downloads/run-{RUN}-artifact-{ident}.zip"
    assert sha(archive) == artifact["digest"].removeprefix("sha256:")
    assert archive.stat().st_size == artifact["size_in_bytes"]
    with zipfile.ZipFile(archive) as zipped:
        names = [i.filename for i in zipped.infolist() if not i.is_dir()]
        assert len(names) == len(set(names))
        for info in zipped.infolist():
            name = PurePosixPath(info.filename)
            assert not name.is_absolute() and ".." not in name.parts
            if info.is_dir():
                continue
            local = directory / info.filename
            assert local.is_file() and not local.is_symlink()
            assert local.stat().st_size == info.file_size
            digest = hashlib.sha256()
            with zipped.open(info) as stream:
                while block := stream.read(1024 * 1024):
                    digest.update(block)
            assert digest.hexdigest() == sha(local), (ident, info.filename)
    before = json.loads((directory / "source-before.json").read_text())
    after = json.loads((directory / "source-after.json").read_text())
    assert before == after
    expected = HEAD if before["kind"] == "head" else MERGE
    assert before["candidate"] == HEAD and before["tested_commit"] == expected
    assert before["tested_tree"] == TREE and before["tracked_worktree_verified"] is True
    assert expected in artifact["name"]
    assert artifact["workflow_run"]["id"] == RUN
    assert artifact["workflow_run"]["head_sha"] == HEAD
    graph_path = directory / "cargo-graph.json"
    graph_check = {"retained": graph_path.is_file()}
    if graph_path.is_file():
        graph = json.loads(graph_path.read_text())
        packages = {(p["name"], p["version"], p["source"]) for p in graph["packages"]}
        assert packages <= locked
        identifiers = {p["id"] for p in graph["packages"]}
        nodes = graph["resolve"]["nodes"]
        assert identifiers == {n["id"] for n in nodes}
        assert all(set(n["dependencies"]) <= identifiers for n in nodes)
        assert all({d["pkg"] for d in n["deps"]} <= identifiers for n in nodes)
        node_pkg = next(p for p in graph["packages"] if p["name"] == "trnm-pon-node")
        assert any(t["name"] == "pon_w1_false_trace_reuse_v1" and t["kind"] == ["example"] for t in node_pkg["targets"])
        actual_members = {
            str(PurePosixPath(p["manifest_path"]).parent.relative_to(graph["workspace_root"]))
            for p in graph["packages"] if p["id"] in graph["workspace_members"]
        }
        assert actual_members == expected_members
        graph_hashes.add(sha(graph_path))
        graph_check.update(
            sha256=sha(graph_path), package_count=len(packages), workspace_member_count=len(actual_members),
            all_resolved_names_versions_sources_match_lock=True, dependency_references_closed=True,
            workspace_members_match_exact_source=True,
            locked_but_not_in_metadata=[list(x) for x in sorted(locked - packages)],
        )
    captures = []
    for path in sorted(directory.glob("w1*/manifest.json")):
        m = json.loads(path.read_text())
        folder = path.parent
        assert {p.name for p in folder.iterdir() if p.is_file()} == set(m["artifact_sha256"]) | {"manifest.json"}
        assert m["source_before"] == m["source_after"]
        assert m["source_before"]["commit"] == expected and m["source_before"]["tree"] == TREE
        assert m["source_before"]["tracked_entries"] == before["tracked_entries"]
        assert m["source_before"]["tracked_bytes"] == before["tracked_bytes"]
        assert m["runner_context"]["GITHUB_RUN_ID"] == str(RUN)
        assert m["execution_context"] == "github-hosted"
        assert m["default_release_configuration_checked"] is True
        assert m["build_environment_overrides"] == {}
        assert not m["source_changed"] and not m["cargo_configuration_changed"]
        assert m["cargo_configuration_before"] == m["cargo_configuration_after"]
        assert m["cargo_configuration_before"]["violations"] == []
        assert all(f["state"] == "absent" for f in m["cargo_configuration_before"]["files"])
        assert m["cargo_configuration_before"]["configuration_semantics_attested"] is False
        assert m["target"] == ("x86_64-unknown-linux-gnu" if m["architecture"] == "x64" else "aarch64-unknown-linux-gnu")
        rustc = (folder / "rustc.stdout").read_text()
        assert "release: 1.95.0" in rustc and ("host: " + m["target"]) in rustc
        assert (folder / "cargo.stdout").read_text().startswith("cargo 1.95.0 ")
        expected_example = "pon_w1_legal_strategy_v1" if "legal" in folder.name else "pon_w1_false_trace_reuse_v1"
        with (folder / expected_example).open("rb") as binary:
            header = binary.read(20)
        assert header[:6] == b"\x7fELF\x02\x01"
        build = [o for o in m["observations"] if "build" in o["command"]]
        assert len(build) == 1
        assert build[0]["command"] == ["cargo", "+1.95.0", "build", "--locked", "--release", "--manifest-path", "trillionnium/Cargo.toml", "--target", m["target"], "-p", "trnm-pon-node", "--example", expected_example]
        assert build[0]["timeout_seconds"] == 900 and build[0]["exit_code"] == 0
        compiled = re.findall(r"^\s*Compiling\s+(\S+)\s+v(\S+)", (folder / "build.stderr").read_text(), re.M)
        assert set(compiled) <= locked_versions
        run_observations = [o for o in m["observations"] if o["stdout"].startswith("campaign")]
        assert len(run_observations) == (30 if "legal" in folder.name else 1)
        assert all(o["timeout_seconds"] == 300 and o["exit_code"] == 0 and not o["timed_out"] for o in run_observations)
        captures.append({
            "path": str(path.relative_to(CAPTURE)), "manifest_sha256": sha(path),
            "actual_source_commit": expected, "actual_source_tree": TREE,
            "architecture": m["architecture"], "target": m["target"],
            "cargo_locked_default_release_command_match": True,
            "captured_cargo_configs_all_absent_before_and_after": True,
            "native_compiler_host_target_match": True, "reported_compiled_crates_match_lock": True,
            "reported_compiled_crate_count": len(compiled),
            "actual_campaign_count": len(run_observations), "all_original_command_budgets_preserved": True,
            "cargo_graph_retained_for_this_job": graph_path.is_file(),
            "runner_context": m["runner_context"],
        })
    results.append({
        "artifact_id": artifact["id"], "artifact_name": artifact["name"],
        "original_zip_sha256": sha(archive), "original_zip_bytes": archive.stat().st_size,
        "github_digest_matches": True, "all_extracted_zip_members_match": True,
        "zip_file_member_count": len(names), "source_before_after_identical": True,
        "source_identity": before, "cargo_graph": graph_check, "captures": captures,
    })
    print(json.dumps({"validated_archive_source_cargo": artifact["id"], "captures": len(captures), "graph_retained": graph_path.is_file()}), flush=True)

assert len(results) == 8 and sum(len(x["captures"]) for x in results) == 12
result = {
    "schema": "pon-w1-independent-ci-provenance-readback-v1", "run_id": RUN,
    "result": "PASS_RETAINED_CONSISTENCY_CHECKS", "artifact_metadata_sha256": sha(metadata_path),
    "expected_head": HEAD, "expected_merge": MERGE, "same_source_tree": TREE,
    "reader_source": json.loads((HERE / "reader-source/SOURCE.json").read_text()),
    "merge_git_identity": json.loads((HERE / "merge-commit.json").read_text()),
    "cargo_lock_sha256": sha(lock_path), "workspace_manifest_sha256": sha(manifest_path),
    "metadata_graph_count": sum(r["cargo_graph"]["retained"] for r in results),
    "distinct_metadata_graph_sha256": sorted(graph_hashes), "artifacts": results,
    "limitations": [
        "No native binary was executed by this readback.",
        "Four false-trace job artifacts retain cargo metadata graphs; the four legal-strategy jobs do not retain separate metadata graphs. Their locked command, exact tree, configuration, compiler identity and reported build output are checked; missing graphs are not reconstructed as original evidence.",
        "Cargo metadata resolved packages are checked against the exact lockfile, but this does not independently reproduce a native build or artifact provenance.",
        "Source/binary/archive consistency is not attestation of hardware independence, runtime clocks, adversarial optimality, work hardness or public service acceptance.",
    ],
}
(HERE / "provenance-report.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(json.dumps({"result": result["result"], "artifacts": len(results), "captures": 12, "graph_count": result["metadata_graph_count"]}), flush=True)
