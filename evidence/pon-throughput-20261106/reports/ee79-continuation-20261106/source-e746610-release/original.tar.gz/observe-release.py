#!/usr/bin/env python3
"""Observe the completed original release gate, bind its announced ELF and archive originals."""
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import time

HEAD = 'e7466106a2a647c8032556273101440384d88b70'
TREE = '63e03dc848eeb92d747fe2c7926c2f758b277cef'
JOB = '1a1b1db83f0-fc05-7b28'
ROOT = Path('/home/qian-qi/chain-ee79-release-e746-v1')
RAW = ROOT / 'raw'
REPO = Path('/home/qian-qi/work/chain-throughput-20261106-ee79/repo')
SUPPORT = json.loads("{\"launch\":\"{\\n  \\\"audit_recorded\\\": true,\\n  \\\"job\\\": {\\n    \\\"args\\\": [\\n      \\\"-c\\\",\\n      \\\"python3 -B /home/qian-qi/work/chain-throughput-20261106-ee79/rog-release-e746-setup-v1.py\\\"\\n    ],\\n    \\\"created_unix_ms\\\": 1793985315824,\\n    \\\"cwd\\\": \\\"/home/qian-qi/work/chain-throughput-20261106-ee79/repo\\\",\\n    \\\"env_keys\\\": [\\n      \\\"CARGO_BUILD_JOBS\\\",\\n      \\\"CARGO_HOME\\\",\\n      \\\"CARGO_INCREMENTAL\\\",\\n      \\\"CARGO_TARGET_DIR\\\",\\n      \\\"CI\\\",\\n      \\\"GIT_OPTIONAL_LOCKS\\\",\\n      \\\"GIT_TERMINAL_PROMPT\\\",\\n      \\\"OPENSSL_CONF\\\",\\n      \\\"OPENSSL_DIR\\\",\\n      \\\"OPENSSL_MODULES\\\",\\n      \\\"OPENSSL_STATIC\\\",\\n      \\\"PATH\\\",\\n      \\\"PYTHONDONTWRITEBYTECODE\\\",\\n      \\\"RUSTUP_AUTO_INSTALL\\\",\\n      \\\"RUST_TEST_THREADS\\\",\\n      \\\"TMPDIR\\\",\\n      \\\"TRNM_PQ_OPENSSL\\\",\\n      \\\"TRNM_PQ_OPENSSL_SHA256\\\",\\n      \\\"TRNM_PQ_OPENSSL_VERSION\\\",\\n      \\\"TRNM_RELEASE_SETUP_SHA256\\\",\\n      \\\"TRNM_RETAINED_DELTA_COST_PATH\\\"\\n    ],\\n    \\\"executable\\\": \\\"/bin/bash\\\",\\n    \\\"execution_mode\\\": \\\"operator\\\",\\n    \\\"host\\\": \\\"rog\\\",\\n    \\\"id\\\": \\\"1a1b1db83f0-fc05-7b28\\\",\\n    \\\"idempotency_key\\\": \\\"chain-ee79-release-e746-auth118-v1\\\",\\n    \\\"launch_error\\\": null,\\n    \\\"launch_state\\\": \\\"launched\\\",\\n    \\\"remote_job_dir\\\": \\\"/home/qian-qi/.local/state/hepta-runtime-mac-worker/jobs/1a1b1db83f0-fc05-7b28\\\",\\n    \\\"request_digest\\\": \\\"0883c2c794cf2737d7805515625b418fe71cbc5443cb72c480662d2092e7051b\\\",\\n    \\\"request_fingerprint\\\": 613548136703403831,\\n    \\\"ssh_target\\\": \\\"rog-ts\\\",\\n    \\\"system_jobctl\\\": false,\\n    \\\"unit\\\": \\\"hepta-runtime-job-1a1b1db83f0-fc05-7b28\\\"\\n  },\\n  \\\"launch\\\": {\\n    \\\"backend\\\": \\\"systemd\\\",\\n    \\\"launcher_pid\\\": null,\\n    \\\"ok\\\": true,\\n    \\\"unit\\\": \\\"hepta-runtime-job-1a1b1db83f0-fc05-7b28\\\"\\n  },\\n  \\\"local_record_pending\\\": false,\\n  \\\"reused\\\": false\\n}\",\"terminal\":\"{\\n  \\\"at_unix_ms\\\": 1793985543636,\\n  \\\"audit_recorded\\\": true,\\n  \\\"automatic_retry\\\": false,\\n  \\\"cancelled\\\": false,\\n  \\\"exit_code\\\": 0,\\n  \\\"job_id\\\": \\\"1a1b1db83f0-fc05-7b28\\\",\\n  \\\"launch_nonce\\\": \\\"fb3e4c4f57f3be42488c0770d14a8bee\\\",\\n  \\\"log_bytes\\\": {\\n    \\\"stderr\\\": {\\n      \\\"seen\\\": 0,\\n      \\\"stored\\\": 0\\n    },\\n    \\\"stdout\\\": {\\n      \\\"seen\\\": 3191,\\n      \\\"stored\\\": 3191\\n    }\\n  },\\n  \\\"log_errors\\\": {\\n    \\\"stderr\\\": null,\\n    \\\"stdout\\\": null\\n  },\\n  \\\"log_synced\\\": {\\n    \\\"stderr\\\": true,\\n    \\\"stdout\\\": true\\n  },\\n  \\\"log_truncated\\\": {\\n    \\\"stderr\\\": false,\\n    \\\"stdout\\\": false\\n  },\\n  \\\"output_complete\\\": true,\\n  \\\"output_durable\\\": true,\\n  \\\"state\\\": \\\"succeeded\\\",\\n  \\\"terminal_publication_confirmed\\\": true,\\n  \\\"terminal_publication_protocol\\\": 1,\\n  \\\"timed_out\\\": false\\n}\",\"stdout_hex\":\"7b22617661696c61626c655f6279746573223a203131363631383231313332382c2022636f73745f70617468223a20222f686f6d652f7169616e2d71692f636861696e2d656537392d72656c656173652d653734362d76312f7261772f72657461696e65642d64656c74612d636f73742e6a736f6e6c222c202268656164223a202265373436363130366132613634376338303332353536323733313031343430333834643838623730222c20227068617365223a202273657475705f7265616479222c202272656365697074223a20222f686f6d652f7169616e2d71692f636861696e2d656537392d72656c656173652d653734362d76312f7261772f73657475702d726563656970742e6a736f6e222c2022726563656970745f736861323536223a202236653364393634633466343332633533336539306133643033663130323139623830383666363434333134383232353661366564396334363932393563306365222c2022726f6f74223a20222f686f6d652f7169616e2d71692f636861696e2d656537392d72656c656173652d653734362d7631227d0a7b2261726776223a205b222f7573722f62696e2f707974686f6e33222c20222d42222c20222f686f6d652f7169616e2d71692f636861696e2d656537392d72656c656173652d653734362d76312f72756e5f72656c656173655f61757468656e746963617465642e7079222c20222d2d7265706f222c20222f686f6d652f7169616e2d71692f776f726b2f636861696e2d7468726f7567687075742d32303236313130362d656537392f7265706f222c20222d2d6f7574222c20222f686f6d652f7169616e2d71692f636861696e2d656537392d72656c656173652d653734362d76312f726177222c20222d2d68656164222c202265373436363130366132613634376338303332353536323733313031343430333834643838623730225d2c20226368696c645f657869745f636f6465223a20302c20226368696c645f7069645f616e645f70726f636573735f67726f7570223a20313339393934342c2022637764223a20222f686f6d652f7169616e2d71692f636861696e2d656537392d72656c656173652d653734362d76312f7265706f222c20226469736b5f67756172645f747269676765726564223a2066616c73652c2022656e666f7263656d656e74223a202273616d706c65642065787465726e616c2073746f702c206e6f7420612066696c6573797374656d207265736572766174696f6e206f7220686172642071756f7461222c202265787065637465645f68656164223a202265373436363130366132613634376338303332353536323733313031343430333834643838623730222c202266696e616c5f617661696c61626c655f6279746573223a203131363235393033333038382c202266696e69736865645f756e69785f6e73223a20313739333938353534333535373836393634332c2022666c6f6f725f617661696c61626c655f6279746573223a20383538393933343539322c202267756172645f736861323536223a202239653035306331613031373062313030363632373539623364343136316637396234393038383865663262353364383865343130653431376238393365333232222c2022696e697469616c5f617661696c61626c655f6279746573223a203131363631383138363735322c20226c6173745f617661696c61626c655f6279746573223a203131363235393034313238302c20226c6f675f6279746573223a203334342c20226c6f675f736861323536223a202231646263336530663638353735633031656239646165363862353765306164623063323836633439323666386136376330643465616533663161663737656335222c20226d696e696d756d5f617661696c61626c655f6279746573223a203131363232323437323139322c2022706f6c6c5f7365636f6e6473223a20302e32352c202272756e6e65725f73756363657373223a20747275652c2022736368656d61223a202274726e6d2d65787465726e616c2d6469736b2d67756172642d7631222c2022737461727465645f756e69785f6e73223a20313739333938353332313632353039353837332c2022737461747573223a2022706173736564227d0a7b22636f73745f66696c65223a207b226279746573223a20363939352c2022646576696365223a2036363330362c20226469726563746f7279223a2066616c73652c2022676964223a20313030302c2022696e6f6465223a2032383037393130382c20226d6f6465223a2022306f363030222c202270617468223a20222f686f6d652f7169616e2d71692f636861696e2d656537392d72656c656173652d653734362d76312f7261772f72657461696e65642d64656c74612d636f73742e6a736f6e6c222c2022726567756c6172223a20747275652c2022736861323536223a202231353630303537323565656332643161343631623861333938633366326638653136646536626266363261623138643531663236623834393230353830333761222c202273796d6c696e6b223a2066616c73652c2022756964223a20313030307d2c20226469736b5f617661696c61626c655f6279746573223a203131363235393033333038382c202266696e69736865645f756e69785f6e73223a20313739333938353534333536353337373838362c202267756172645f636f6d6d616e64223a205b222f7573722f62696e2f707974686f6e33222c20222d42222c20222f686f6d652f7169616e2d71692f636861696e2d656537392d72656c656173652d653734362d76312f6469736b5f67756172642e7079222c20222d2d726f6f74222c20222f686f6d652f7169616e2d71692f636861696e2d656537392d72656c656173652d653734362d7631222c20222d2d68656164222c202265373436363130366132613634376338303332353536323733313031343430333834643838623730222c20222d2d6c6162656c222c202272656c65617365222c20222d2d222c20222f7573722f62696e2f707974686f6e33222c20222d42222c20222f686f6d652f7169616e2d71692f636861696e2d656537392d72656c656173652d653734362d76312f72756e5f72656c656173655f61757468656e746963617465642e7079222c20222d2d7265706f222c20222f686f6d652f7169616e2d71692f776f726b2f636861696e2d7468726f7567687075742d32303236313130362d656537392f7265706f222c20222d2d6f7574222c20222f686f6d652f7169616e2d71692f636861696e2d656537392d72656c656173652d653734362d76312f726177222c20222d2d68656164222c202265373436363130366132613634376338303332353536323733313031343430333834643838623730225d2c202267756172645f657869745f636f6465223a20302c202268656164223a202265373436363130366132613634376338303332353536323733313031343430333834643838623730222c2022736368656d61223a202274726e6d2d726f672d707269766174652d72656c656173653131382d6c61756e63682d726573756c742d7631222c2022736f757263655f6166746572223a207b226272616e6368223a207b2261726776223a205b22676974222c202273796d626f6c69632d726566222c20222d2d7175696574222c202248454144225d2c2022657869745f636f6465223a20302c2022737464657272223a2022222c20227374646f7574223a2022726566732f68656164732f6669782f636861696e2d7468726f7567687075742d7075626c6973682d32303236313130362d316565645c6e227d2c20226964656e74697479223a207b2261726776223a205b22676974222c20227265762d7061727365222c202248454144222c2022484541445e7b747265657d225d2c2022657869745f636f6465223a20302c2022737464657272223a2022222c20227374646f7574223a2022653734363631303661326136343763383033323535363237333130313434303338346438386237305c6e363365303364633834386565623932643734376665326337393236633266373538623237376365665c6e227d2c2022737461747573223a207b2261726776223a205b22676974222c2022737461747573222c20222d2d706f7263656c61696e3d7631222c20222d2d756e747261636b65642d66696c65733d616c6c225d2c2022657869745f636f6465223a20302c2022737464657272223a2022222c20227374646f7574223a2022227d7d2c2022737461747573223a2022706173736564222c202274726565223a202236336530336463383438656562393264373437666532633739323663326637353862323737636566227d0a\",\"stderr_hex\":\"\"}")


def require(value, message):
    if not value:
        raise RuntimeError(message)

def write_bytes(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())

def write_json(path, value):
    write_bytes(path, (json.dumps(value, sort_keys=True, indent=2) + '\n').encode())

def main():
    require(ROOT.resolve(strict=True) == ROOT and RAW.resolve(strict=True) == RAW,
            'exact private release root required')
    require(ROOT.lstat().st_uid == os.getuid() and stat.S_IMODE(ROOT.lstat().st_mode) == 0o700,
            'private release root owner/mode differs')
    runner = ROOT / 'run_native_qualification.py'
    require(hashlib.sha256(runner.read_bytes()).hexdigest() ==
            'da7dc56e80384b2d5b44ae84d11024a36fa28e94a6ba7c0cf7684937cc322fb2',
            'original pinned runner required')
    spec = importlib.util.spec_from_file_location('original_pinned_runner', runner)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)

    def read_json(path):
        helper.file_facts(path)
        return helper.strict_json(path.read_text())

    terminal = helper.strict_json(SUPPORT['terminal'])
    require(terminal['job_id'] == JOB and terminal['state'] == 'succeeded'
            and terminal['exit_code'] == 0 and terminal['terminal_publication_confirmed'] is True
            and terminal['output_complete'] is True and terminal['output_durable'] is True
            and all(value is False for value in terminal['log_truncated'].values()),
            'authoritative successful completed original job required')
    for filename, raw in (
        ('outer-job-launch.json', SUPPORT['launch'].encode()),
        ('outer-job-terminal.json', SUPPORT['terminal'].encode()),
        ('outer-job.stdout', bytes.fromhex(SUPPORT['stdout_hex'])),
        ('outer-job.stderr', bytes.fromhex(SUPPORT['stderr_hex'])),
    ):
        write_bytes(RAW / filename, raw)
    write_bytes(ROOT / 'observe-release.py', Path(__file__).read_bytes())

    def source(label):
        receipt = RAW / ('observation-source-' + label + '.json')
        log = RAW / ('observation-source-' + label + '.log')
        argv = [sys.executable, '-B', str(REPO / 'scripts/ci/verify_ci_source.py'),
                '--kind', 'head', '--expected-head', HEAD, '--output', str(receipt)]
        with log.open('xb') as stream:
            process = subprocess.run(argv, cwd=REPO, env=dict(os.environ), stdout=stream,
                                     stderr=subprocess.STDOUT, check=False)
        require(process.returncode == 0, 'source identity check failed: ' + label)
        value = read_json(receipt)
        require(value['tested_commit'] == HEAD and value['tested_tree'] == TREE
                and value['tracked_worktree_verified'] is True
                and value['tests_executed_by_identity_check'] is False,
                'source receipt does not bind this readback')
        return dict(argv=argv, exit_code=process.returncode,
                    receipt=helper.file_facts(receipt), log=helper.file_facts(log), source=value)

    before = source('before')
    stage = read_json(RAW / 'release-authenticated-stage.json')
    guard = read_json(RAW / 'guard-release.json')
    launch = read_json(RAW / 'launch-result.json')
    require(stage['status'] == 'passed' and stage['head'] == HEAD
            and stage['expected_tests'] == 118 and stage['preflight']['passed'] is True,
            'original release stage did not pass')
    require(guard['status'] == 'passed' and guard['runner_success'] is True
            and guard['child_exit_code'] == 0 and guard['expected_head'] == HEAD
            and guard['disk_guard_triggered'] is False
            and guard['floor_available_bytes'] == 8589934592
            and guard['guard_sha256'] == '9e050c1a0170b100662759b3d4161f79b490888ef2b53d88e410e417b893e322',
            'original disk guard did not pass unchanged')
    require(launch['status'] == 'passed' and launch['guard_exit_code'] == 0
            and launch['head'] == HEAD and launch['tree'] == TREE,
            'original outer release result did not pass')
    labels = ['release-authenticated', 'release-authenticated-summary-check',
              'release-authenticated-roster-check']
    require([row['label'] for row in stage['commands']] == labels,
            'original execution/summary/roster command set differs')
    records = {}
    for row in stage['commands']:
        require(row['passed'] is True and row['command_exit_code'] == 0,
                'original release command failed')
        record = read_json(RAW / (row['label'] + '.json'))
        helper.source_receipt(record, HEAD)
        require(record['before']['tested_tree'] == TREE
                and record['status'] == 'command_succeeded' and record['exit_code'] == 0
                and record['argv'] == row['command'],
                'original command receipt mismatch')
        facts = helper.file_facts(RAW / record['log_file'])
        require(facts['sha256'] == record['log_sha256'] and facts['bytes'] == record['log_bytes'],
                'original command log digest differs')
        records[row['label']] = record
    expected_argv = ['cargo', '+1.95.0', 'test', '--release', '--locked', '--manifest-path',
                     'trillionnium/Cargo.toml', '-p', 'trnm-pon-node', '--lib',
                     'store::native_authenticated::', '--', '--include-ignored',
                     '--show-output', '--test-threads=1']
    require(records['release-authenticated']['argv'] == expected_argv,
            'original cargo release command changed')
    cargo_log = RAW / 'release-authenticated.log'
    cargo_text = cargo_log.read_text()
    announcements = [line for line in cargo_text.splitlines()
                     if re.fullmatch(r'\s*Running unittests src/lib\.rs \([^()\r\n]+\)', line)]
    require(len(announcements) == 1, 'one actual Cargo-announced release Node ELF required')
    match = re.fullmatch(r'\s*Running unittests src/lib\.rs \(([^()\r\n]+)\)', announcements[0])
    executable = Path(match.group(1))
    require(executable.is_absolute() and executable.parent == ROOT / 'target/release/deps'
            and executable.resolve(strict=True) == executable,
            'Cargo-announced ELF is not this private release target')
    elf = helper.file_facts(executable, elf=True)
    require(len(re.findall(r'^test result: ok\. 118 passed; 0 failed; 0 ignored; 0 measured; '
                          r'\d+ filtered out; finished in [0-9.]+s$', cargo_text, re.MULTILINE)) == 1,
            'one original exact 118-test summary required')

    cost_path = RAW / 'retained-delta-cost.jsonl'
    cost = helper.file_facts(cost_path)
    require(cost['sha256'] == launch['cost_file']['sha256']
            and cost['bytes'] == launch['cost_file']['bytes'],
            'cost output differs from original post-run observation')
    lines = cost_path.read_text().splitlines()
    require(len(lines) == 34, 'header + 32 observations + footer required')
    values = [helper.strict_json(line) for line in lines]
    expected_header = {
        'schema': 'pon-native-retained-delta-cost-v1',
        'scope': 'actual in-memory SQLite ordered read, canonical validation and complete delta root; not Node/state/history/physical I/O/RSS/TPS',
        'comparison': 'exact eee8db8 full-list reader and streaming root versus current bounded streamed reader/root',
        'synthetic_sqlite_rows': True, 'speed_threshold': None, 'production_activation': False,
    }
    expected_footer = {'completed': True, 'pairs': 16, 'observations': 32,
                       'scope': 'no timing threshold or performance qualification'}
    require(values[0] == expected_header and values[-1] == expected_footer,
            'original cost scope or completion metadata differs')
    index = 1
    cases = []
    keys = {'case', 'rows', 'payload_width', 'pair', 'arm', 'wall_ns',
            'root', 'count', 'error', 'equal'}
    for case, (count, width) in enumerate(((256, 64), (4096, 64), (4096, 4093), (16384, 64))):
        root = None
        for pair in range(4):
            for arm in (('baseline226', 'streamed') if pair % 2 == 0 else ('streamed', 'baseline226')):
                row = values[index]
                require(set(row) == keys, 'original observation keys differ')
                require(all(type(row[key]) is int for key in ('case', 'rows', 'payload_width', 'pair', 'count')),
                        'integer observation identity required')
                require((row['case'], row['rows'], row['payload_width'], row['pair'], row['arm']) ==
                        (case, count, width, pair, arm), 'paired observation identity/order differs')
                require(isinstance(row['wall_ns'], str)
                        and re.fullmatch(r'(?:0|[1-9][0-9]*)', row['wall_ns']) is not None,
                        'original nonnegative wall_ns string required')
                require(row['equal'] is True and row['error'] is None and row['count'] == count
                        and isinstance(row['root'], str)
                        and re.fullmatch(r'[0-9a-f]{64}', row['root']) is not None,
                        'failed or incomplete raw paired observation')
                root = row['root'] if root is None else root
                require(row['root'] == root, 'paired roots differ')
                index += 1
        cases.append(dict(case=case, rows=count, payload_width=width, pairs=4,
                          observations=8, root=root))
    require(index == 33, 'all original observations must be consumed exactly')
    require(helper.file_facts(cost_path) == cost, 'cost file changed while validating')
    helper.check_fingerprint(elf)
    after = source('after')
    result = dict(schema='trnm-original-release118-elf-cost-observation-v1',
        native_job=JOB, source_head=HEAD, source_tree=TREE, native_gate_passed=True,
        tests_executed_by_this_observer=False, elf_executed_by_this_observer=False,
        native_execution_evidence='original cargo command log and original summary/PYLOG guards',
        production_qualified=False, original_cargo_argv=expected_argv,
        original_cargo_log=helper.file_facts(cargo_log),
        cargo_announcement=announcements[0],
        cargo_finished_lines=[line for line in cargo_text.splitlines()
                              if ('Finished ' + chr(96) + 'release' + chr(96) + ' profile') in line],
        release_node_elf=elf, original_stage=helper.file_facts(RAW / 'release-authenticated-stage.json'),
        manifest=helper.file_facts(REPO / 'trillionnium/Cargo.toml'),
        lockfile=helper.file_facts(REPO / 'trillionnium/Cargo.lock'),
        cost_file=cost, cost_header=values[0], cost_footer=values[-1], cost_cases=cases,
        cost_validation=dict(observations=32, pairs=16, cases=4, alternating_original_order=True,
                             all_results_equal=True, all_errors_null=True, timing_threshold=None),
        source_before=before, source_after=after, observed_unix_ns=time.time_ns())
    write_json(RAW / 'release-elf-cost-observation.json', result)

    archive_root = ROOT / 'archive'
    archive_root.mkdir(mode=0o700, exist_ok=False)
    selected = sorted(RAW.iterdir()) + [
        ROOT / 'run_release_authenticated.py', ROOT / 'run_native_qualification.py',
        ROOT / 'disk_guard.py', ROOT / 'setup-script.py', ROOT / 'observe-release.py']
    names = [str(path.relative_to(ROOT)) for path in selected]
    require(len(names) == len(set(names)), 'duplicate archive entry')
    entries = []
    for path, relative in zip(selected, names):
        info = path.lstat()
        require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1
                and not relative.startswith('/') and '..' not in Path(relative).parts,
                'original regular single-link archive input required')
        entries.append(dict(relative_path=relative, **helper.file_facts(path)))
    manifest = dict(schema='trnm-original-release-evidence-archive-manifest-v1',
                    source_head=HEAD, source_tree=TREE, native_job=JOB,
                    tests_executed_by_archive=False, file_count=len(entries), files=entries)
    manifest_path = archive_root / 'manifest.json'
    write_json(manifest_path, manifest)
    archive_path = archive_root / 'release-e746-originals.tar.gz'
    with archive_path.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for path, entry in zip(selected, entries):
                    helper.check_fingerprint(entry)
                    archive.add(path, arcname=entry['relative_path'], recursive=False)
                    require(helper.file_facts(path) == {key: entry[key] for key in ('path', 'bytes', 'sha256', 'fingerprint')},
                            'original changed during archive')
                archive.add(manifest_path, arcname='manifest.json', recursive=False)
        output.flush()
        os.fsync(output.fileno())
    receipt = dict(schema='trnm-original-release-evidence-archive-v1',
                   source_head=HEAD, source_tree=TREE, native_job=JOB,
                   original_files=len(entries), original_file_bytes=sum(row['bytes'] for row in entries),
                   archive=helper.file_facts(archive_path),
                   manifest=helper.file_facts(manifest_path),
                   metadata=helper.file_facts(RAW / 'release-elf-cost-observation.json'),
                   native_gate_passed=True, archive_execution_is_native_test=False)
    write_json(archive_root / 'archive-receipt.json', receipt)
    print(json.dumps(receipt, sort_keys=True), flush=True)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
