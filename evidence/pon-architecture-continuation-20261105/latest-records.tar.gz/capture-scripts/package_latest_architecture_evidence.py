from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile

ROOT=Path('/workspace/scratch/1790ff0f3cc3/chain')
WORK=Path('/workspace/scratch/1790ff0f3cc3/work')
BASE=WORK/'final-composition'
OUT=ROOT/'evidence/pon-architecture-continuation-20261105'
SOURCE='cb8ed84404977320fdb09d75284f99149654107d'
PUBLISHED='cf8c88acc026bd36a00aedb40e09aa380ddbc0eb'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,text=True).strip()
assert git('rev-parse','HEAD')==PUBLISHED and not git('status','--porcelain')
subprocess.run(['bash','scripts/project-preflight.sh'],cwd=ROOT,check=True)
native=read(BASE/'native/commands.json');ci=read(BASE/'ci/summary.json')
review=read(BASE/'review/summary.json');published=read(BASE/'published-source/summary.json')
assert native['required_local_controls_passed'] and ci['all_checks_passed'] and review['all_passed'] and published['all_checks_passed']
assert published['exact_tested_binary'] and published['source_commit']==PUBLISHED
before=read(BASE/'native/source-before.json');after=read(BASE/'native/source-after.json')
assert before==after and before['tested_commit']==SOURCE
owner=read(BASE/'native/business/manifest.json');report_file=BASE/'native/business/native/report.json';report=read(report_file)
assert owner['source_before']==owner['source_after']==before and not owner['passed']
assert len(report['samples'])==18 and all(x['errors']==['PUBLIC_HOST_KERNEL_PARENT'] and not x['finite_business_target_met'] for x in report['samples'])
assert '12 passed; 0 failed; 0 ignored; 0 measured; 1 filtered out' in (BASE/'native/native-components.stdout').read_text()
assert owner['binary_sha256']==published['binary_sha256']

records={}
def add(p,name):
 assert p.is_file() and not p.is_symlink() and name not in records
 records[name]=p.read_bytes()
for group in ['ci','review','published-source']:
 for p in sorted((BASE/group).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:add(p,group+'/'+p.relative_to(BASE/group).as_posix())
for p in sorted((BASE/'native').iterdir()):
 if p.is_file():add(p,'native/'+p.name)
for rel in ['manifest.json','build/stdout','build/stderr','native/report.json',
 'reference_dag_rejects_withheld_body_equivocation_and_changed_signed_history/stdout',
 'reference_dag_rejects_withheld_body_equivocation_and_changed_signed_history/stderr',
 'signed_dag_delivery_comparison_uses_same_native_business_and_confirmation_contract/stdout',
 'signed_dag_delivery_comparison_uses_same_native_business_and_confirmation_contract/stderr']:
 add(BASE/'native/business'/rel,'native/business/'+rel)
for rel in ['pins-before-repair.json','pq-before.json','pq-before.stdout','pq-before.stderr','latest-merge.json']:
 add(BASE/rel,rel)
for rel in ['run_final_composition_checks.py','package_latest_architecture_evidence.py']:
 add(WORK/rel,'capture-scripts/'+rel)
index={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(records.items())}
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0,filename='') as gz:
 with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
  for name,data in sorted(records.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
archive=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
 for item in tar.getmembers():
  data=tar.extractfile(item).read();assert index[item.name]=={'bytes':len(data),'sha256':sha(data)}
(OUT/'latest-records.tar.gz').write_bytes(archive)
dump(OUT/'latest-records-index.json',dict(archive_sha256=sha(archive),archive_bytes=len(archive),records=index,
 omissions='Native ELF, Cargo caches and generated SQLite stores omitted; complete raw report, source guards and all command outputs retained.'))
summary=dict(schema='pon-architecture-latest-composition-v1',tested_source_commit=SOURCE,
 tested_source_tree=before['tested_tree'],published_source_commit=PUBLISHED,published_source_tree=published['source_tree'],
 concurrent_inputs=['657bf2a462ff13a6101ebcb4fbe0fb91c515c972','2a8fee974b41fab6e2c4e662dcce1807fcd19bdd'],
 previous_evidence_commit='413084b29b30ebbf1e7a1e97643b743ec5a751c8',
 source_before=before,source_after=after,published_source_checks=published,
 native_binary_sha256=owner['binary_sha256'],native_commands=native['runs'],
 tests=dict(native_components_passed=12,native_full_business_selector_separately_executed=True,
  architecture_reader_passed=22,host_adapter_passed=17,phase_reader_passed=51,ci_contract_passed=98,pq_source_guard_passed=35),
 strict_source_blobs=490,business=dict(passed=False,samples=18,passed_samples=0,errors=['PUBLIC_HOST_KERNEL_PARENT'],
  execution_owner_exit_code=2,native_selector_exit_code=101,raw_report_sha256=sha(report_file.read_bytes()),
  raw_report_archive_path='native/business/native/report.json'),
 source_preservation_review='review/review.json',ci_review='ci/summary.json',module_review='review/loaded-python-modules.json',
 archive='latest-records.tar.gz',archive_sha256=sha(archive),record_count=len(index),
 original_ohie_and_ghostdag_evidence_retained=True,original_4s_16_hostile_w1_acceptance=False,
 full_alternative_protocol_qualified=False,independent_accepted=False,wan_tested=False,production_activation=False,
 result='SCOPED_COMPONENTS_PASS_ORIGINAL_BUSINESS_HOLD')
dump(OUT/'latest-composition.json',summary)
text=f'''# Latest concurrent composition — 2026-11-05

The architecture work is integrated into the existing Draft PR #688. The final
recorded native combination is `{SOURCE}`; the published source anchor is
`{PUBLISHED}`. This supplement retains the later Growth, public-request
observation and runtime-release changes. Earlier records keep their original
commit identities and are not relabeled as new executions.

## Concrete results

| Control | Actual result | Source |
| --- | --- | --- |
| Architecture native release target | Compiled; 12 component tests PASS | `cb8ed844` |
| Strict target Clippy, formatting, inventory and repository checks | PASS | `cb8ed844` |
| Architecture reader / Host adapter | 22 / 17 PASS | `cb8ed844`; rerun because the phase-reader dependency changed |
| Phase reader / CI contract / PQ source controls | 51 / 98 / 35 PASS | `cb8ed844` |
| Original full-business selector | Exit 101; all 18 samples fail with `PUBLIC_HOST_KERNEL_PARENT` | `cb8ed844`; original settings retained |
| Complete business execution owner | Exit 2, passed=false | Complete raw report retained |
| Source identity before/after | PASS | Both `cb8ed844` and published `cf8c88ac`, separately recorded |
| Published-source locked build freshness | PASS; byte-identical tested native ELF | `cf8c88ac` |
| Exact source registry | 490 blobs match; HOLD_NO_GO | Source identity only, no cryptographic acceptance |

The current ELF SHA-256 is
`{owner['binary_sha256']}`.
The complete Rust workspace and formal-source subtrees are identical between
`cb8ed844` and `cf8c88ac`. All 17 actual loaded architecture Python modules also
have identical Git blobs. The last merge preserves two unrelated runtime-release
scripts and their registrations; those scripts are not among the loaded modules.
The locked build explicitly confirms binary equality instead of assuming it.

## Preservation and source registration

The Growth/request-accounting input contributes 16 changed paths. Its direct
intersection with the architecture line is only the development plan and
generated inventory; both merge by additions, with no original lines removed.
The inventory contains the exact 1,228-path union. The reader and adapter are
rerun because their real import closure includes the updated phase reader.

Nine existing registry values required synchronization in `cb8ed844`: eight
exactly match the concurrent remote source changes and one binds the combined
inventory. The next registration merge preserves the remote runtime-release
updates and changes only the existing CI and combined-inventory pin values
relative to that remote. Original guard failures and exact diffs remain in the
archive; no required path, activation flag, admission limit or safety predicate
is removed.

## Records and limits

- [latest-composition.json](latest-composition.json) binds commands, results,
  commit/tree identities, native binary and remaining HOLD flags.
- [latest-records-index.json](latest-records-index.json) records the byte count
  and SHA-256 of each of the {len(index)} retained records.
- [latest-records.tar.gz](latest-records.tar.gz) contains the original logs,
  complete failed native report, strict source guards, composition reviews and
  capture scripts. It omits native executables, caches and generated databases.

The original [GHOSTDAG campaign](ghostdag-order-max6.json) and
[exact replay](ghostdag-replay.json) remain bound to their recorded `d992451c`
source and unchanged kernel/oracle/campaign bytes. The OHIE red/green and standard
scenario controls likewise retain their original scope. No test executions are
added together to inflate distinct coverage.

The full-business refusal remains an actual failed acceptance result. The
original no-attack, four-second/16 hostile-W1, depth-and-required-work confirmation,
4,105-block History, full PQ/state/recovery, WAN and independent-operator gates
remain open. This supplement declares no performance winner, complete alternative
consensus implementation, security theorem or production activation.
'''
(OUT/'LATEST_COMPOSITION.md').write_text(text)
p=OUT/'README.md';s=p.read_text();heading='# Permissionless architecture continuation — 2026-11-05\n'
assert s.startswith(heading)
s=s.replace(heading,heading+'\n**Latest integration:** see [LATEST_COMPOSITION.md](LATEST_COMPOSITION.md) and\n[latest-composition.json](latest-composition.json) for the subsequent Growth/request\ncomposition, fresh native execution and published-source byte equality. The\nrecords below retain their earlier source anchors.\n',1)
s=s.replace('all 18 final integrated samples report','all 18 recorded `d992451c` integration samples report')
p.write_text(s)
for p in [OUT/'README.md',OUT/'LATEST_COMPOSITION.md']:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).resolve().exists(),target
print(json.dumps({'source':SOURCE,'published':PUBLISHED,'records':len(index),'archive_bytes':len(archive),'archive_sha256':sha(archive)}))
