from pathlib import Path
import json,sys,hashlib
base=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');p=base/'source/scripts/ci/check_ci_contract.py';lines=p.read_text().splitlines();out=base/'ci-inline-pin-source-35';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);hit=[i for i,l in enumerate(lines) if 'inline source pin differs' in l]
for k,at in enumerate(hit):
 start=max(i for i in range(at+1) if lines[i].startswith('def '));end=next((i for i in range(at+1,len(lines)) if lines[i].startswith('def ')),len(lines));txt='\n'.join(str(i+1)+': '+lines[i] for i in range(start,end));dest=out/('reader-'+str(k)+'.txt');dest.write_text(txt);print(json.dumps({'path':str(dest),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'excerpt':txt}),flush=True)
