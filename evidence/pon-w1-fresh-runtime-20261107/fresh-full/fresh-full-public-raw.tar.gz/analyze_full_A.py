#!/usr/bin/env python3
"""Read completed A trials; copy small evidence and query only private DB copies."""
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import statistics
import struct
import subprocess
import time

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
REPO = ROOT / 'repo'
OUT = ROOT / 'full-A-terminal-analysis-01'
A = 'd3037ca5dfb6f301757c159b7888dca9b0317be0'
TREE = 'd4a8f84cdc896b9454ce0d03a164f8916e6afdf9'
BOOT = '14f92beb-43c6-4786-839e-b57307ae8048'
ARMS = {'funded-balanced': ('proof', '1a1b75f99d3-12894-a75'),
        'sequential-unfunded': ('postwin', '1a1b75fd351-12894-a76')}
INVENTORY = {}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def write(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def read(path, maximum=None):
    first = path.lstat()
    require(stat.S_ISREG(first.st_mode), 'ordinary source file required: ' + str(path))
    if maximum is not None:
        require(first.st_size <= maximum, 'source too large: ' + str(path))
    raw = path.read_bytes()
    last = path.lstat()
    keys = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    require(all(getattr(first, k) == getattr(last, k) for k in keys), 'source changed while reading: ' + str(path))
    row = {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
           'device': first.st_dev, 'inode': first.st_ino, 'hardlinks': first.st_nlink}
    old = INVENTORY.get(str(path))
    require(old is None or all(old[k] == row[k] for k in ('bytes', 'sha256', 'device', 'inode')),
            'original source changed since prior read')
    if old is not None and 'retained_copy' in old:
        row['retained_copy'] = old['retained_copy']
    INVENTORY[str(path)] = row
    return raw


def obj(path):
    return json.loads(read(path, 8 * 1024**2))


def source_guard(label):
    destination = OUT / (label + '.json')
    argv = ['/usr/bin/python3', str(REPO / 'scripts/ci/verify_ci_source.py'), '--kind', 'head',
            '--expected-head', A, '--output', str(destination)]
    before = time.monotonic_ns()
    run = subprocess.run(argv, cwd=REPO, stdin=subprocess.DEVNULL, capture_output=True, timeout=60,
                         env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
    write(OUT / (label + '.stdout.log'), run.stdout)
    write(OUT / (label + '.stderr.log'), run.stderr)
    row = {'argv': argv, 'exit': run.returncode, 'started_ns': before, 'finished_ns': time.monotonic_ns()}
    write(OUT / (label + '.command.json'), encode(row))
    require(run.returncode == 0, 'source guard failed')
    v = obj(destination)
    require(v['tested_commit'] == A and v['tested_tree'] == TREE and v['tracked_worktree_verified'] is True,
            'exact A source guard')
    return INVENTORY[str(destination)]


def strict_stage(v):
    require(v['schema'] == 'TRNM-W1-STAGE-MEASUREMENT3' and v['returncode'] == 0
            and v['stage_process_complete'] is True and v['timed_out'] is False
            and v['deadline_exhausted_at_snapshot'] is False and v['completion_observed_before_deadline'] is True
            and v['error'] is None and v['canceled_signal'] is None and v['cancellation_event'] is None
            and v['termination_reasons'] == [] and v['owned_session_observation_complete'] is True
            and v['cleanup_errors'] == [] and v['proc_scan_errors'] == [] and v['group_probe_errors'] == []
            and v['final_owned_session_members'] == [] and v['process_group_remaining_after_child_exit'] is False
            and all(x['state'] == 'ABSENT' for x in v['final_known_group_probes']), 'strict stage terminal failure')


def summary_ns(values):
    return {'count': len(values), 'sum_ns': sum(values), 'min_ns': min(values),
            'median_ns': statistics.median(values), 'max_ns': max(values)} if values else {'count': 0}


def process_identity(identity):
    p = Path('/proc') / str(identity['pid']) / 'stat'
    try:
        value = p.read_text()
        fields = value[value.rfind(')') + 2:].split()
        birth = int(fields[19])
        same = identity.get('boot_id', BOOT) == Path('/proc/sys/kernel/random/boot_id').read_text().strip() and birth == identity['start_ticks']
        return {'original': identity, 'state': 'SAME_BIRTH_PRESENT' if same else 'PID_REUSED',
                'observed_start_ticks': birth, 'process_state': fields[0]}
    except FileNotFoundError:
        return {'original': identity, 'state': 'ABSENT'}
    except Exception as exc:
        return {'original': identity, 'state': 'UNKNOWN', 'error': str(exc)}


def group_observation(path):
    result = {'path': str(path), 'observed_monotonic_ns': time.monotonic_ns(),
              'historical_full_billing_established': False, 'all_descendants_wait_reaped': None}
    try:
        first = path.lstat()
    except FileNotFoundError:
        result.update({'state': 'ABSENT', 'current_live_members_observed': False})
        return result
    try:
        dirs = [path] + sorted(p for p in path.rglob('*') if p.is_dir())
        require(len(dirs) <= 128, 'bounded original cgroup traversal')
        rows = []
        for q in dirs:
            s = q.stat()
            rows.append({'path': str(q), 'device': s.st_dev, 'inode': s.st_ino,
                         'procs': (q / 'cgroup.procs').read_text(), 'events': (q / 'cgroup.events').read_text()})
        require([(str(q), q.stat().st_ino) for q in dirs] == [(r['path'], r['inode']) for r in rows], 'cgroup identities changed')
        final = path.stat()
        require((first.st_dev, first.st_ino) == (final.st_dev, final.st_ino), 'root cgroup identity changed')
        empty = all(not r['procs'].strip() and 'populated 0' in r['events'].splitlines() for r in rows)
        result.update({'state': 'OBSERVED_EMPTY' if empty else 'MEMBERS_PRESENT', 'groups': rows,
                       'current_live_members_observed': not empty})
    except Exception as exc:
        result.update({'state': 'UNKNOWN', 'error': str(exc)})
    return result


def arm_analysis(arm, statuses):
    name, job_id = ARMS[arm]
    run = ROOT / (arm + '-run-01')
    p = run / name
    status = json.loads(statuses[arm])
    require(status['job_id'] == job_id and status['state'] == 'succeeded' and status['exit_code'] == 0
            and status['output_complete'] is True and status['output_durable'] is True
            and status['cancelled'] is False and status['timed_out'] is False, 'original job terminal closure')
    write(OUT / 'connector' / (arm + '-terminal.json'), statuses[arm].encode())
    files = sorted(q for q in run.rglob('*') if q.is_file())
    require(len(files) <= 10000 and sum(q.stat().st_size for q in files) <= 2 * 1024**3, 'bounded original inventory')
    copied = 0
    for q in files:
        raw = read(q)
        copy = ((q.suffix in ('.json', '.log') and len(raw) <= 8 * 1024**2)
                or q.name in ('stages.jsonl', 'trials.jsonl', 'succinct.bin', 'header.bin', 'expected-artifacts.bin', 'input.bin'))
        if copy:
            dest = OUT / 'raw' / q.relative_to(ROOT)
            write(dest, raw)
            INVENTORY[str(q)]['retained_copy'] = str(dest.relative_to(OUT))
            copied += 1
    postwin = obj(p / 'result.json')
    controller = obj(p / 'controller/result.json')
    manifest = obj(p / 'checkpoint/manifest.json')
    winner = obj(run / 'native-winner/result.json')
    events_raw = [json.loads(line) for line in read(p / 'checkpoint/stages.jsonl').splitlines()]
    events = [x['event'] for x in events_raw]
    counts = collections.Counter(x['stage'] for x in events)
    segments = [x for x in events if x['stage'] in ('REAL_SEGMENT_STARK_SAVED_VERIFIED', 'REAL_SEGMENT_CANDIDATE_SAVED_VERIFIED_UNLINKED')]
    recursion = [x for x in events if x['stage'] == 'REAL_RECURSIVE_STARK_SAVED_VERIFIED']
    require(len(segments) == 43 and sorted(x['index'] for x in segments) == list(range(43)), 'one new seal per segment required')
    require(counts['REAL_SEGMENT_PROVING_STARTED'] == 43 and counts['EXECUTE_STARTED'] == 1
            and counts['COMPLETE_RELATION_EXECUTED'] == 1 and counts['SEGMENT_EXPORTED'] == 43, 'fresh full execution and starts required')
    require(len(recursion) == 85 and sum(x['operation'] == 'lift' for x in recursion) == 43
            and sum(x['operation'] == 'join' for x in recursion) == 42
            and all(x['checkpoint_reused'] is False for x in recursion), 'fresh 43 lifts + 42 joins required')
    require(len({x['name'] for x in recursion}) == 85, 'recursion names unique')
    final = [x for x in events if x['stage'] == 'FULL_SUCCINCT_STARK_SAVED_VERIFIED']
    require(len(final) == 1, 'one complete Succinct publication')
    final = final[0]
    receipt = INVENTORY[str(p / 'checkpoint/succinct.bin')]
    require(receipt['sha256'] == final['receipt_sha256'] == controller['identity']['receipt_sha256']
            and receipt['bytes'] == final['receipt_bytes'] == 257014, 'actual final receipt binding')
    require(manifest['source_commit'] == A and len(manifest['segments']) == 43
            and manifest['input_sha256'] == winner['input_sha256'], 'fixed source/input manifest')
    labels = [x['stage'] for x in controller['stages']]
    require(labels == controller['stage_dispatch_attempts'] and controller['unretained_stage_labels'] == [], 'no lost stage dispatch')
    for row in controller['stages']:
        strict_stage(row['result'])
        original = obj(p / 'controller' / row['stage'] / 'result.json')
        require(original == row['result'], 'embedded stage differs from actual raw file')
    require(controller['complete_proof_claim'] is True and controller['end_to_end_observation_complete'] is True
            and controller['controller_canceled_signal'] is None and controller['controller_cancellation_event'] is None
            and controller['error'] is None and controller['deadline_exhausted_at_snapshot'] is False
            and controller['fresh_full_pipeline_trials_observed'] == 1
            and controller['fresh_preparation_included'] is True and controller['prior_runs'] == [], 'full controller closure')
    require(postwin['operation_complete'] is True and postwin['error'] is None and postwin['cancellation_event'] is None
            and postwin['deadline_exhausted_at_snapshot'] is False, 'postwin successful operation')
    sidecars = [str(q) for q in files if 'cancellation' in q.name.lower()]
    require(not sidecars, 'cancellation sidecar veto')
    by_label = {r['stage']: r['result']['wall_seconds'] for r in controller['stages']}
    segment_wall = [v for k, v in by_label.items() if k.startswith('prove-')]
    constructors = [x['constructor_ns'] for x in events if x['stage'] == 'BACKEND_CLIENT_CONSTRUCTED']
    rows = [{'label': row['stage'], 'wall_seconds': row['result']['wall_seconds'], 'command': row['result']['command'],
             'environment': row['result']['environment'], 'stage_process_complete': row['result']['stage_process_complete'],
             'rusage': row['result']['rusage']} for row in controller['stages']]
    write(OUT / (arm + '-stage-table.json'), encode(rows))
    remote = obj(ROOT / 'crosshost-observation-01' / arm / 'parent-observation.json')
    outer = Path('/sys/fs/cgroup/user.slice/user-1000.slice/user@1000.service/app.slice') / ('hepta-runtime-job-' + job_id + '.service')
    scope = {'original_job_scope': group_observation(outer), 'original_postwin_scope': group_observation(Path('/sys/fs/cgroup') / postwin['cgroup_membership'].strip()[3:].lstrip('/'))}
    if arm == 'funded-balanced':
        tr = obj(run / 'target-terminal-readback.json')
        scope['original_target_worker'] = process_identity(tr['worker']['identity'])
        scope['original_target_child'] = process_identity(tr['result']['child_identity'])
        scope['legacy_A_target_observation_limit'] = 'The original A target reported direct cgroup members only; current whole original scope observation is separate and does not retroactively prove full historical billing or descendant wait/reap.'
    result = {'arm': arm, 'original_job_id': job_id, 'terminal_success_complete_durable': True,
              'original_files_inventoried': len(files), 'small_raw_files_retained': copied,
              'fresh_full_proof_trials_observed': 1, 'new_segment_seals': 43, 'new_lifts': 43, 'new_joins': 42,
              'reused_recursion_checkpoints': 0, 'checkpoint_event_counts': dict(counts),
              'controller_stages_complete': len(labels), 'stage_table': arm + '-stage-table.json',
              'observed_stage_wait4_cpu_seconds': controller['observed_new_stage_wait4_user_cpu_seconds'] + controller['observed_new_stage_wait4_system_cpu_seconds'],
              'observed_stage_wait4_cpu_scope': controller['wait4_cpu_sum_scope'],
              'event_timings_scope': 'Different operations within one proof; these are not independent prover trials or tail samples.',
              'sdk_segment_call_ns': summary_ns([x['prover_ns'] for x in segments]),
              'sdk_lift_call_ns': summary_ns([x['prover_ns'] for x in recursion if x['operation'] == 'lift']),
              'sdk_join_call_ns': summary_ns([x['prover_ns'] for x in recursion if x['operation'] == 'join']),
              'explicit_client_constructor_ns': summary_ns(constructors),
              'constructor_observation': 'explicit parallel client events only; zero events is uninstrumented, not zero startup cost',
              'startup_loading_scope': 'SDK call timers include backend subprocess startup/loading; constructors, stage CLI/source checks, verification, publication and caller ACK occupy separately recorded scopes. Inner startup and loading have no isolated measurement.',
              'complete_execute': next(x for x in events if x['stage'] == 'COMPLETE_RELATION_EXECUTED'),
              'compression_internal': final,
              'timing_seconds': {'prepare_stage': by_label['prepare-full-execution'], 'segment_stage_sum': sum(segment_wall),
                 'segment_process_stage_count': len(segment_wall), 'compression_stage': by_label['complete-recursive-compression'],
                 'fresh_strict_verify_stage': by_label['fresh-process-strict-verification'],
                 'fresh_full_pipeline': controller['fresh_proof_pipeline_seconds'], 'whole_controller': controller['new_controller_wall_seconds'],
                 'winner_to_local_receiver_ack': postwin['winner_to_receiver_seconds'],
                 'winner_to_crosshost_complete_bundle': remote['winner_to_observed_remote_ack_ns'] / 1e9},
              'resource_plan': controller['resource_plan'], 'original_deadline_ns': winner['original_deadline_monotonic_ns'],
              'native_winner_ns': winner['native_winner_monotonic_ns'], 'receipt': receipt,
              'input_sha256': manifest['input_sha256'], 'guest_sha256': manifest['guest_sha256'], 'image_id': manifest['image_id'],
              'guest_rebuilt': False, 'source_commit': A, 'source_tree': TREE,
              'resource_scope_complete': False, 'gpu_ns': None, 'production_qualified': False,
              'node_admission_qualified': False, 'readback': scope}
    write(OUT / (arm + '-analysis.json'), encode(result))
    return result


def private_db_copy(path, label):
    for suffix in ('-wal', '-shm', '-journal'):
        require(not Path(str(path) + suffix).exists(), 'active or incomplete database sidecar closure: ' + str(path))
    raw = read(path, 8 * 1024**2)
    dest = OUT / 'private-analysis-only' / (label + '.sqlite')
    write(dest, raw)
    c = sqlite3.connect('file:' + str(dest) + '?mode=ro&immutable=1', uri=True)
    schemas = list(c.execute("SELECT name,sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"))
    dump = {'original_pin': INVENTORY[str(path)], 'copy_only': str(dest), 'publish_database': False, 'tables': []}
    def cell(x):
        return {'bytes_hex': x.hex(), 'bytes': len(x)} if isinstance(x, bytes) else x
    for name, sql in schemas:
        require(re.fullmatch('[A-Za-z_][A-Za-z_0-9]*', name), 'ordinary table name')
        count = c.execute('SELECT count(*) FROM "' + name + '"').fetchone()[0]
        cur = c.execute('SELECT * FROM "' + name + '" LIMIT 512')
        dump['tables'].append({'name': name, 'sql': sql, 'total_rows': count, 'complete_rows': count <= 512,
                              'columns': [x[0] for x in cur.description], 'rows': [[cell(x) for x in row] for row in cur]})
    c.close()
    require(read(path) == raw, 'original database changed after private copy query')
    for suffix in ('-wal', '-shm', '-journal'):
        require(not Path(str(path) + suffix).exists(), 'database sidecar appeared')
    write(OUT / 'private-analysis-only' / (label + '-sqlite-readback.json'), encode(dump))
    return dump


def funding_analysis():
    run = ROOT / 'funded-balanced-run-01'
    result = obj(run / 'funded-result.json')
    config_path = ROOT / 'experiment-launch-plans-01/funded-balanced-config.json'
    config = obj(config_path)
    require(INVENTORY[str(config_path)]['sha256'] == 'da00644c188f37d3b6e69329aa6d0f3a4eea97e2a37c1d3bb7525c3f02404395', 'original funded config pin')
    intent = obj(run / 'native-funded-intent.json')
    dump = private_db_copy(run / 'native-generation-v2.sqlite', 'm12-generation')
    tables = {x['name']: x for x in dump['tables']}
    meta = dict(zip(tables['native_generation_meta_v2']['columns'], tables['native_generation_meta_v2']['rows'][0]))
    journal = bytes.fromhex(meta['journal']['bytes_hex'])
    require(journal.hex() == intent['journal_identity'], 'original journal identity')
    previous = bytes(32)
    rows = []
    names = ['Prepare', 'Intent', 'BindJob', 'Verified', 'Failure', 'Cancel', 'Settlement', 'Payment']
    for n, row in enumerate(tables['native_generation_events_v2']['rows'], 1):
        row = dict(zip(tables['native_generation_events_v2']['columns'], row))
        payload = bytes.fromhex(row['payload']['bytes_hex'])
        calculated = hashlib.sha256(b'pon-native-owner-w1-generation-budget-v2' + journal + previous + struct.pack('<QQ', n, len(payload)) + payload).digest()
        require(row['sequence'] == n and calculated.hex() == row['root']['bytes_hex'], 'exact M12 byte chain')
        require(payload[0] < len(names), 'known source-bound Borsh event tag')
        rows.append({'sequence': n, 'kind': names[payload[0]], 'payload_bytes': len(payload),
                     'payload_sha256': hashlib.sha256(payload).hexdigest(), 'root': calculated.hex()})
        previous = calculated
    require(meta['sequence'] == len(rows) and meta['root']['bytes_hex'] == previous.hex(), 'exact journal terminal head')
    require([x['kind'] for x in rows] == ['Prepare', 'Intent', 'BindJob'], 'expected pending journal; no Positive or settlement/payment')
    require(result['funded_generation'] == 'Pending' and result['node_positive'] is False
            and result['payment_observed'] is False and result['can_authorize_payment'] is False
            and result['native_remaining_units'] == 1000 and result['resource_reservation_retained'] is True
            and result['cold_replay_dispatch'] == 'Pending', 'actual funded hold facts')
    node = private_db_copy(ROOT / 'funded-research-node-01/native.sqlite', 'research-native')
    fence = private_db_copy(ROOT / 'funded-research-node-01/native.sqlite.w1-generation-owner-v2.sqlite', 'generation-owner-fence')
    public = {'schema': 'TRNM-W1-A-FUNDED-TERMINAL-ANALYSIS1', 'original_result': result,
              'actual_original_config': INVENTORY[str(config_path)], 'resource_cap_retained': config['resource_cap'],
              'gpu_usage_ns': None, 'native_task_refund_observed': False, 'resource_credit_granted': False,
              'journal_identity': journal.hex(), 'journal_raw_chain_verified': True, 'event_tags': rows,
              'event_tag_decode_scope': 'Exact stored Borsh discriminants and hash chain only; actual Rust cold replay and full state checks are retained in funded result and source.',
              'journal_payment_event_present': False, 'journal_settlement_event_present': False,
              'source_formula': 'GenerationReadbackV2 uses the full original resource_cap when neither Verified nor a Failure with complete consumption is recorded.',
              'database_original_pins': [x['original_pin'] for x in (dump, node, fence)],
              'private_copies_and_dumps_excluded_from_publication': True,
              'native_database_schema': [{'name': x['name'], 'columns': x['columns'], 'total_rows': x['total_rows']} for x in node['tables']]}
    write(OUT / 'funding-analysis.json', encode(public))
    return public


def main(statuses):
    require(not OUT.exists() and ROOT.is_dir(), 'new external analysis output required')
    OUT.mkdir()
    write(OUT / 'analyze_full_A.py', SCRIPT_TEXT.encode())
    summary = {'schema': 'TRNM-W1-A-TERMINAL-ANALYSIS1', 'analysis_complete': False, 'errors': [],
               'source_commit': A, 'source_tree': TREE, 'original_databases_opened': False,
               'proofs_dispatched_by_analysis': 0, 'started_monotonic_ns': time.monotonic_ns(),
               'actual_affinity': sorted(os.sched_getaffinity(0)), 'arms': {},
               'publish_exclusion': ['private-analysis-only/**'], 'source_checks': {}}
    try:
        summary['source_checks']['before'] = source_guard('source-before')
        for arm in ARMS:
            summary['arms'][arm] = arm_analysis(arm, statuses)
        summary['funding'] = funding_analysis()
        source_files = [
            'trillionnium/crates/trnm-service-settlement/src/native_generation_budget_v2.rs',
            'trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2/tests/heavy.rs',
            'scripts/w1_generation_target_v2.py', 'scripts/w1_owned_generation_runtime_v2.py',
            'scripts/w1_full_staged_run.py', 'scripts/run_w1_postwin_proof.py']
        for rel in source_files:
            q = REPO / rel
            write(OUT / 'source-originals' / rel, read(q, 1024**2))
        b = summary['arms']['funded-balanced']['timing_seconds']
        s = summary['arms']['sequential-unfunded']['timing_seconds']
        summary['comparison'] = {'fresh_proof_count': 2, 'funded_fresh_proof_count': 1, 'unfunded_fresh_proof_count': 1,
            'full_pipeline_balanced_minus_sequential_seconds': b['fresh_full_pipeline'] - s['fresh_full_pipeline'],
            'full_pipeline_balanced_divided_by_sequential': b['fresh_full_pipeline'] / s['fresh_full_pipeline'],
            'isolated_causal_optimization_benefit_established': False, 'population_tail_established': False,
            'scope': 'One fixed-input fresh trial per plan, concurrently on one host with distinct requested eight-core affinities and equal quotas/memory limits; shared caches/bandwidth and caller work differ. No independent random sample or p99 claim.'}
        summary['analysis_complete'] = True
    except BaseException as exc:
        summary['errors'].append({'type': type(exc).__name__, 'message': str(exc)})
    finally:
        try:
            summary['source_checks']['after'] = source_guard('source-after')
        except BaseException as exc:
            summary['analysis_complete'] = False
            summary['errors'].append({'scope': 'source-after', 'type': type(exc).__name__, 'message': str(exc)})
        summary['completed_monotonic_ns'] = time.monotonic_ns()
        write(OUT / 'original-file-inventory.json', encode({'schema': 'TRNM-W1-RAW-INVENTORY1', 'files': sorted(INVENTORY.values(), key=lambda x:x['path'])}))
        write(OUT / 'manifest.json', encode(summary))
        print(json.dumps({'analysis_complete': summary['analysis_complete'], 'errors': summary['errors'],
                          'manifest': str(OUT / 'manifest.json'), 'inventory_files': len(INVENTORY),
                          'arms': {k:v['timing_seconds'] for k,v in summary['arms'].items()},
                          'native_database_schema': summary.get('funding', {}).get('native_database_schema')}))
    return 0 if summary['analysis_complete'] else 1


if __name__ == '__main__':
    raise SystemExit(main(CONNECTOR_RAW))
