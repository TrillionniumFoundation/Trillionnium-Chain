# PR #785: retained head CI source-pin failure

This package preserves two failed GitHub-hosted head jobs from run 42431784279
at dcd114a9dc1308e069bae205cf3e091f62046ccc. It does not replace those failures
with a later result. No GitHub rerun, cancellation, comment or repository edit
was performed by this audit.

## Observed cause

Both x64 and ARM jobs passed the exact checked-source identity/preflight step
and five Python guard unit suites. Both then failed the actual command:
python3 scripts/ci/check_pq_research_integration.py

The command emitted:
HOLD_NO_GO: changed source: scripts/ci/check_ci_contract.py

The failing step was Require retained source and claim controls.
Compiler installation, OpenSSL provider preparation and native Rust execution
were all skipped after this failure. The logs therefore demonstrate a source
binding integration regression, not a provider installation failure or a
runtime failure of the new Rust observer.

## Complete source-pin comparison

The base is 4a7e07e970d5bdb79626dda6bc98ae7906a02f18. GitHub's complete recursive
base and head trees both report truncated=false. All 580 base pins match;
572 head pins match and the following eight do not. The guard correctly
rejects the stale manifest. This audit did not execute the full base checker.

| Source path | Retained manifest/base Git blob | Actual head Git blob |
| --- | --- | --- |
| scripts/ci/check_ci_contract.py | 03926c57fb31756c98ec4630d86c22212f834670 | b08492454cdf8e377d2e3356b83d554668444154 |
| scripts/ci/ci_job.sh | af2d413c8ae5f170c693b1c4e8c85844146f7be0 | 72576f1412ff36aa0c2d99dcebc51927e4bbefa3 |
| scripts/ci/test_ci_contract.py | 2e71d8e683424a3aa36f7d1351ba413cb7c73618 | 55e13ea85db51ac8e95e72a979604cf0256fc774 |
| trillionnium/crates/trnm-crypto-primitives/src/lib.rs | 530d3097745eb2448300876aaaf34862b8a6aec0 | b4b83396f1b7b7b88dddb25974dc4f8fa16076c8 |
| trillionnium/crates/trnm-pon-node/examples/support/distributed_source_inventory.rs | 3cec8fae2a55d6708d23ee1f37026aeba23b4fe5 | 69fa7aefe397cdc8a4eec67c2ef5bc8b981ad4e6 |
| trillionnium/crates/trnm-pon-node/src/lib.rs | 0b1e224e81bdd832f70891a71e8bacc977bb08d5 | e52f09d92f4cc00319229fe9c868f03737fcbc69 |
| trillionnium/crates/trnm-pon-node/src/store/task_operation_v2/reconciliation.rs | 090ed0e0624c36275740aea0435e95ee8b67c378 | 8eb8638b78e8260d316aa15c84c7a95f7ac5e6ed |
| trillionnium/crates/trnm-pon-node/tests/native_task_operation_v2.rs | bc0cc0db2741ec44c460e536a80b2a28db613c03 | 7d27c2e45b51b8d3baa6206398c2cc434d51d902 |

All eight complete base/head diffs are in source-comparison/diffs/. The decoded
source bytes and their verified Git blob/SHA-256 identities are retained beside
both complete Git tree responses. No diff was synthesized by restoring or
weakening an existing acceptance control.

The CI contract and lane add two fresh-work Python commands and two grouped
native targets. Its tests add omission, duplication, swallowed-error and
ignored-target rejection controls. The crypto library exports the new grouped
research seal module; the Node library exports two explicitly research-only
grouped modules. The generated source inventory adds source paths. The native
reconciliation/test changes add the previously reviewed bounded current-paid
Task observation and its controlled branch/reorg/GC tests.

## Minimal repair proposal and semantics

proposed-eight-pin-sync.diff changes only the eight pinned_blobs values in the
corpus. It is an unapplied, exact-base proposal. The checker and every non-pin
manifest field remain unchanged. Its proposed hashes are valid only if the
eight corresponding source files remain at the reviewed head bytes.

The exact checker declares that it verifies source identity and false
activation flags, not cryptography or production qualification. It requires
research-only-hold-no-go, requires all eight acceptance assertions false, and
on success still returns HOLD_NO_GO with cryptographic_acceptance=false and
node_activated=false. Evidence locator readability is explicitly not test
acceptance. The corpus separately sets historical_records_are_current_acceptance
and checkpoint_is_final_tested_source to false, and marks the old PNQ1 slice
historical-source-contract-not-current-runtime.

Accordingly, synchronizing these reviewed current-source pins selects bytes
for new experiments; it does not rerun, revise or extend old measurements.
No old test count, evidence locator, parent/provenance field, claim, acceptance
flag or unresolved blocker needs to be changed for this pin synchronization.
Fresh validation must be retained under the new exact source identity. The
actual source checker must run in addition to its unit tests; prior 33-command
or Colab results must not be relabelled as having executed this failed gate.

## Provenance and public scope

The raw GitHub logs retain GitHub's original masking. Exact job/run metadata,
public GitHub repository source bytes, full diffs, pin comparisons and original
tree responses are included. No private Hepta implementation, authentication
configuration, token, cookie or SSH configuration is included. API content
wrappers used to obtain decoded source bytes remain in the runtime audit
directory; those source bytes are verified against the returned Git blobs.

MANIFEST.json hashes every package file except itself. FINDING.json gives exact
job URLs, failure line numbers, original log hashes and the proposal's binding.
This package concerns the two head jobs only; prospective-merge jobs are kept
in a separate audit package.
