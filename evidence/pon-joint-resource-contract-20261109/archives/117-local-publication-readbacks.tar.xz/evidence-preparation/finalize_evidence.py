from pathlib import Path
import hashlib,json,tarfile
R=Path("/workspace/scratch/pon-joint-58fd59-build")
D=R/"chain/evidence/pon-joint-resource-contract-20261109"
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(1048576),b""):h.update(b)
 return h.hexdigest()
roots=[(R/"evidence-preparation","evidence-preparation"),(R/"preparation/ci-readback-117/main-hosted-42553751914-42553751985","main-hosted"),(R/"runtime-shard-readback","runtime-shard")]
files=[]
for base,prefix in roots:
 assert base.is_dir(),str(base)
 for p in sorted(base.rglob("*")):
  if p.is_file() and p.suffix not in {".zip",".xz",".gz"}:
   assert not p.is_symlink()
   files.append((p,prefix+"/"+str(p.relative_to(base))))
for p in sorted((R/"publication").iterdir()):
 if p.is_file() and p.name not in {"pr827-final-body-draft.md"} and p.suffix not in {".pack",".idx"} and not p.name.startswith(("evidence-object","evidence-transfer","evidence-post","pr827-final")):
  files.append((p,"publication/"+p.name))
assert len({n for _,n in files})==len(files)
rows=[{"path":n,"bytes":p.stat().st_size,"sha256":sha(p)} for p,n in files]
a=D/"archives/117-local-publication-readbacks.tar.xz"
with tarfile.open(a,"x:xz",preset=6) as t:
 for p,n in files:
  m=t.gettarinfo(str(p),arcname=n);m.uid=m.gid=0;m.uname=m.gname="";m.mtime=0;m.pax_headers={}
  with p.open("rb") as f:t.addfile(m,f)
for (p,_),row in zip(files,rows):assert p.stat().st_size==row["bytes"] and sha(p)==row["sha256"]
with tarfile.open(a) as t:
 ms=t.getmembers();assert len(ms)==len(rows)
 for m,row in zip(ms,rows):
  assert m.isfile() and m.name==row["path"] and m.size==row["bytes"]
  assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==row["sha256"]
meta={"file":a.name,"bytes":a.stat().st_size,"sha256":sha(a),"file_count":len(rows),"uncompressed_bytes":sum(r["bytes"] for r in rows)}
(D/"inventories/117-local-publication-readbacks-archive.json").write_text(json.dumps(meta,indent=2)+"\n")
(D/"inventories/117-local-publication-readbacks-files.json").write_text(json.dumps({"schema":"pon-joint-evidence-archive-v1","files":rows,"raw_bytes_preserved":True,"archive_header_time_and_owner_normalized":True},indent=2)+"\n")
scopes={
"history-original-control.tar.xz":"Original-source History comparison",
"fc5-validation.tar.xz":"Initial implementation successes and failures",
"preliminary-ci-failure.tar.xz":"Preliminary failure and capture gap",
"117-local-validation.tar.xz":"Final local static/native/V4 observations",
"117-ai395-native.tar.gz":"Original ai395 native archive",
"preparation-and-hosted-failures.tar.xz":"Preparation and original six baseline/QROM failure captures",
"original-campaign-42553751914.zip":"Complete original campaign ZIP, including executable",
"worktime-head-42553751985.zip":"Complete work/time head ZIP",
"worktime-merge-42553751985.zip":"Complete work/time prospective-merge ZIP",
"117-desktop-publication-receipts.tar.xz":"Desktop publication, workflow logs and latest CI snapshot",
"117-local-publication-readbacks.tar.xz":"Local receipts, complete job logs and runtime failure readback",
"runtime-observations-13648102770.zip":"Complete prospective runtime observations ZIP",
"runtime-shard-proof-13647628991.zip":"Complete prospective runtime source-proof ZIP"}
archives=[]
for p in sorted((D/"inventories").glob("*-archive.json")):
 x=json.loads(p.read_text());f=D/"archives"/x["file"]
 assert f.stat().st_size==x["bytes"] and sha(f)==x["sha256"]
 x.update(path=str(f.relative_to(D)),metadata=str(p.relative_to(D)),scope=scopes[x["file"]]);archives.append(x)
assert len(archives)==13
index={"schema":"pon-joint-resource-evidence-index-v1","tested_implementation":"11791e2da79b69322271be2cffe03725165151d1","tested_tree":"162552848110fda532504b78865a16930bc6d9bb","tested_prospective_merge":"b472c21f7b14ba27bb87d9d2f52d299365ed3145","evidence_branch":"fix/chain-pon-joint-resource-evidence-20261109-58fd59","evidence_child_inherits_native_qualification":False,"all_legal_algorithm_cost_lower_bound_proved":False,"joint_classical_quantum_consensus_security_proved":False,"original_public_resource_acceptance_passed":False,"production_activation":False,"archives":archives,"archive_count":len(archives),"total_archive_bytes":sum(x["bytes"] for x in archives),"capture_gap":"Preliminary uncommitted CI-placement console was truncated; missing output is not reconstructed.","source_check_scope":"Individual fixed-source recorder commands; V4 observation pair shares a full-source before/after pair with separate child executable/output/process receipts."}
(D/"artifacts.json").write_text(json.dumps(index,indent=2)+"\n")
table=["| Archive | Bytes | Members | Scope |","| --- | ---: | ---: | --- |"]
for x in archives:table.append(f'| [{x["file"]}]({x["path"]}) | {x["bytes"]:,} | {x["file_count"]:,} | {x["scope"]} |')
table+=["","Exact outer SHA-256 values are in [artifacts.json](artifacts.json).","[SHA256SUMS](SHA256SUMS) covers every package file except itself; the Git","commit binds that index. Per-member inventories and independent reviews","are retained under inventories/ and integrity/. The 1,724 selected desktop","extraction entries do not replace the original campaign ZIP's complete","1,766-file denominator."]
readme=(R/"evidence-staging/README-draft.md").read_text();assert readme.count("__ARCHIVE_TABLE__")==1
readme=readme.replace("__ARCHIVE_TABLE__","\n".join(table));assert "__HOSTED_RESULTS__" not in readme
(D/"README.md").write_text(readme)
sums=[]
for p in sorted(D.rglob("*")):
 assert not p.is_symlink()
 if p.is_file() and p.name!="SHA256SUMS":sums.append(f"{sha(p)}  {p.relative_to(D)}")
(D/"SHA256SUMS").write_text("\n".join(sums)+"\n")
print(json.dumps({"local_archive":meta,"archives":len(archives),"archive_bytes":index["total_archive_bytes"],"package_files":len(sums)+1,"readme_bytes":(D/"README.md").stat().st_size}))
