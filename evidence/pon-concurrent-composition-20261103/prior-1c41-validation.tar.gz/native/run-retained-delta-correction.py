#!/usr/bin/env python3
"""Preparation-only correction, preserving failed minimum phase unchanged."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import textwrap
sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('original_controls', BASE/'run-controls.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
assert m.sha(BASE/'run-controls.py') == '2e1c25d6278d324e14e313bce9f982466ce375b6e5fbdc6e3131d1428f84a666'
old_summary = BASE/'minimum/summary.json'
old_sha = m.sha(old_summary)
old = json.loads(old_summary.read_text())
assert old['status'] == 'failed' and old['identity_after'] == 'passed' and len(old['controls']) == 55
assert [r['name'] for r in old['controls'] if not r['passed']] == ['native-authenticated']
environment = m.env()
artifacts = m.load_artifacts()
directory, result = m.phase_start('retained-delta-correction-v1', artifacts, environment)
output = directory/'retained-delta-cost.jsonl'
assert not output.exists()
environment['TRNM_RETAINED_DELTA_COST_PATH'] = str(output)
workflow = m.REPO/'.github/workflows/pon-recent-batch-acceptance.yml'
workflow_text = workflow.read_text()
assert 'echo "TRNM_RETAINED_DELTA_COST_PATH=$out/retained-delta-cost.jsonl" >> "$GITHUB_ENV"' in workflow_text
original_checker = textwrap.dedent(workflow_text.split("          python3 - \"$OUT/$name.log\" <<'PYLOG'\n",1)[1].split('          PYLOG',1)[0])
checker_path = directory/'original-workflow-group-checker.py'
with checker_path.open('x') as f: f.write(original_checker)
result.update(correction_reason='Original include-ignored group requires TRNM_RETAINED_DELTA_COST_PATH to a new path; first 55-command phase remains failed and retained.', original_minimum_summary_sha256=old_sha, correction_script_sha256=m.sha(Path(__file__)), workflow_sha256=m.sha(workflow), original_workflow_checker_sha256=m.sha(checker_path), environment_additions={'TRNM_RETAINED_DELTA_COST_PATH': str(output)}, output_required_create_new=True)
m.save(directory/'summary.json',result)
try:
 row=m.group(directory,'native-authenticated','node','store::native_authenticated::',83,0,True,artifacts,environment)
 result['controls'].append(row)
 m.save(directory/'summary.json',result)
 check=m.command(directory,'original-workflow-group-checker',['python3',str(checker_path),str(directory/'native-authenticated.log')],m.REPO,environment)
 result['controls'].append({'name':'original-workflow-group-checker','kind':'retained-original-reader','native':check,'passed':check['exit_code']==0})
 m.save(directory/'summary.json',result)
 try:
  lines=output.read_text().splitlines()
  assert len(lines)==34, f'expected header + 32 observations + completion, got {len(lines)}'
  records=[json.loads(line) for line in lines]
  header=records[0]; tail=records[-1]; observations=records[1:-1]
  assert header['schema']=='pon-native-retained-delta-cost-v1'
  assert header['synthetic_sqlite_rows'] is True and header['production_activation'] is False and header['speed_threshold'] is None
  assert tail=={'completed':True,'pairs':16,'observations':32,'scope':'no timing threshold or performance qualification'}
  expected=[]
  for case,(rows,width) in enumerate([(256,64),(4096,64),(4096,4093),(16384,64)]):
   for pair in range(4):
    for arm in (['baseline226','streamed'] if pair%2==0 else ['streamed','baseline226']):
     expected.append((case,rows,width,pair,arm))
  assert [(r['case'],r['rows'],r['payload_width'],r['pair'],r['arm']) for r in observations]==expected
  roots={}
  for r in observations:
   assert r['equal'] is True and r['error'] is None and r['count']==r['rows']
   assert isinstance(r['wall_ns'],str) and re.fullmatch(r'[0-9]+',r['wall_ns']) and int(r['wall_ns'])>0
   assert isinstance(r['root'],str) and re.fullmatch(r'[0-9a-f]{64}',r['root'])
   if r['case'] in roots: assert roots[r['case']]==r['root']
   else: roots[r['case']]=r['root']
  retained={'result':'PASS','observations':32,'pairs':16,'cases':4,'raw_sha256':m.sha(output),'raw_bytes':output.stat().st_size,'sequence_valid':True,'all_equal':True,'roots_by_case':roots,'timing_threshold':None,'scope':'Complete raw readback of original synthetic SQLite observation under local original test profile; not a release, CPU, RSS or service acceptance result.'}
 except Exception as error:
  retained={'result':'FAIL','error':repr(error),'raw_exists':output.exists()}
  if output.exists(): retained.update(raw_sha256=m.sha(output),raw_bytes=output.stat().st_size)
 m.save(directory/'retained-samples-reader.json',retained)
 result['controls'].append({'name':'retained-samples-reader','kind':'raw-observation-integrity-reader','reader':retained,'passed':retained['result']=='PASS'})
 assert m.sha(old_summary)==old_sha, 'original failed summary changed'
 result['original_failed_summary_unchanged']=True
except Exception as error:
 result['fatal']=repr(error)
 m.save(directory/'summary.json',result)
code=m.phase_end(directory,result,artifacts,environment)
assert m.sha(old_summary)==old_sha, 'original failed summary changed'
sys.exit(code)
