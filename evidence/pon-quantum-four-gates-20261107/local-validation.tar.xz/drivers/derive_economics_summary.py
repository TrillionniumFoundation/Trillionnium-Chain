#!/usr/bin/env python3
"""Summarize the frozen reparse once per cohort; never count its sample rows twice."""
from collections import Counter, defaultdict
from fractions import Fraction
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
path = root / 'frozen/economics/observed-economics.json'
raw = path.read_bytes()
d = json.loads(raw)
counts = Counter()
fastest = Counter()
ratios, shares = [], []
budgets = defaultdict(Counter)
keys = ('actual_searches', 'actual_setup_calls', 'attempts', 'exhausted_searches',
        'target_hits', 'proof_materializations', 'serialized_proof_bytes')
for cell in d['cost_grid']:
    rows = cell['strategy_costs']
    best = min(rows, key=lambda r: r['inclusive_cohort_total']['cpu_ns'])
    fastest[best['arithmetic'] + '/' + best['materialization']] += 1
    ratios.append(Fraction(max(r['inclusive_cohort_total']['cpu_ns'] for r in rows),
                           best['inclusive_cohort_total']['cpu_ns']))
    for row in rows:
        for key in keys:
            assert row[key] == sum(s[key] for s in row['per_sample_denominators']), key
            counts[key] += row[key]
        for verdict in row['native_outcome_counts'].values():
            counts.update(verdict)
        shares.append(Fraction(**row['observed_setup_share_of_producer_cpu']))
        for budget in row['fixed_budget_replays']:
            budgets[budget['budget_cpu_ns']][budget['termination']] += 1

def rational(value):
    return {'numerator': value.numerator, 'denominator': value.denominator,
            'approximate_display_only': float(value)}

report = {
    'schema': 'pon-w1-observed-economics-summary-v1',
    'input_sha256': hashlib.sha256(raw).hexdigest(),
    'source_reader_commit': 'ec3a939706592c6ec9dd677b70589a7e8860cdfd',
    'cost_grid_cells': len(d['cost_grid']), 'strategy_cohorts': sum(len(x['strategy_costs']) for x in d['cost_grid']),
    'separate_control_shards': d['separate_control_shards'],
    'unique_cost_search_streams': d['unique_cost_search_streams'],
    'counted_once_totals': dict(counts),
    'failed_nonce_attempts': counts['attempts'] - counts['target_hits'],
    'posthoc_fastest_observed_cohort_cells': dict(fastest),
    'within_cell_slowest_to_fastest_cohort_cpu_ratio_range': [rational(min(ratios)), rational(max(ratios))],
    'setup_share_of_producer_cpu_range': [rational(min(shares)), rational(max(shares))],
    'fixed_cpu_budget_cohort_termination_counts': {str(k): dict(v) for k,v in budgets.items()},
    'archive_readback': d['archive_readback'],
    'execution_source': d['execution_source'],
    'semantic_alert_count': sum(len(c['semantic_alerts']) for c in d['cost_grid']),
    'scope': 'Historical retained producer CPU records; posthoc cohort comparisons are descriptive, not an executable per-sample oracle or an optimal-cost proof.',
    'aggregation_note': 'A transient exploratory console calculation added both aggregate and sample hit/proof/byte counts. This retained summary checks their equality and counts each cohort only once.',
    'excluded_from_cpu_budget': ['separately timed verification', 'network propagation', 'attempt-evidence writing', 'energy and capital costs'],
    'fresh_measurement_on_current_source': False,
    'quantum_hardware_executed': False,
    'cheapest_legal_implementation_proved': False,
}
output = root / 'frozen/economics/summary.json'
with output.open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'status':'PASS','counted_once_totals':dict(counts),'failed_nonce_attempts':report['failed_nonce_attempts'],'summary_sha256':hashlib.sha256(output.read_bytes()).hexdigest()},sort_keys=True))
