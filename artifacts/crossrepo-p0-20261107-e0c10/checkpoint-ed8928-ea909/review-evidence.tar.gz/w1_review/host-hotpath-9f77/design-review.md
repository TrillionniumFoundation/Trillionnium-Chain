# 9f77 Host 热路径独立源码审查

## 决策

在保留每个 checkpoint 的完整 fresh 观察、五个当前 limit 文件 open/read/EOF、当前调用线程 membership、初始和最终绝对 parent fence 的前提下，**当前源码没有足以解释大幅性能收益的重复解析、重复 read 或正常短路径 heap 分配可以直接删除**。已有实现已完成多数低风险机械优化。不得把未经测量的 metadata/parser 小改宣称为四秒修复。

另外发现一个实际入口覆盖缺口：`KernelBudget::open` 初始化 limits 仍走 `fs::read_to_string(budget.parent.join(name))`，在后续保护完整的 `checked.check()` 之前，可以阻塞在 FIFO、跟随 symlink 或进行无界读取。它不是每 checkpoint 的 81,891 次热项，但应作为独立 hardening 修订处理。

本审查为内部 source review。没有修改 frozen 9f77，没有新建 native/campaign/workflow 执行；external acceptance=false。

## 精确材料

- Chain head `9f77f4334a365387d7389735d5b67c37f12a02a0`，`host_kernel_parent.rs` blob `7a962491b1ec1ca3aff7f401c5f9044fc2a3e0da`，61,455 bytes。
- 同候选 Cargo.lock 将 rustix 固定到 1.1.4；无须引入新 dependency。
- Rust 实际门使用 1.95；审查的是官方 `rust-lang/rust` tag `1.95.0` 的 `library/std/src/sys/fs/unix.rs` 与 `sys/helpers/small_c_string.rs`，并核验原 Git blob SHA。
- 原 F0 ZIP SHA：`c396369487eb99c63d94d373eb779439aa2a0fda145228cadc3082845342769e`；解析见同级 `../f0-9f77-42323271496/analysis.json` 与 `review.md`。

完整来源、字节数、SHA256、Git blob SHA 均在 `source-manifest.json`。官方源码链接：[Rust 1.95 Unix file metadata](https://github.com/rust-lang/rust/blob/1.95.0/library/std/src/sys/fs/unix.rs)、[Rust 1.95 short C-string path](https://github.com/rust-lang/rust/blob/1.95.0/library/std/src/sys/helpers/small_c_string.rs)。

## 每次成功 check 的实际工作

| 顺序 | 实际观察 | 常见短文件的最低文件 syscall 数 | 保留理由 |
|---|---|---:|---|
| 1 | fresh boot file open、read 至 EOF、close；UTF-8、trim 与既有 boot identity 比较 | 4 | 当前 context，不可保留旧 fd 或旧成功 verdict |
| 2 | 对绝对 parent 路径执行 nofollow metadata，比较 directory、权限、dev/ino/uid | 1 | held directory FD 不能替代当前路径绑定 |
| 3 | fresh `/proc/thread-self/cgroup` open、read 至 EOF、close；完整单行/路径语法和所属 parent 检查 | 4 | 必须观察实际调用 TID，不能改成 thread-group leader |
| 4 | 依原顺序对五个 child 各执行 openat(NOFOLLOW, NONBLOCK)、opened-FD regular 检查、read 至 EOF、close | 25 | 每个实际对象的 fresh/read-boundary 都保留 |
| 5 | 一次 validate_limits、一次与原 Limits 比较，然后绝对 parent 最终 fence | 1 | 读错误先于 parse，parse/changed 先于最终 fence；防止 detached parent 借出成功 |
| 合计 | 至少 35 个文件 syscall，未计 observer 时钟及额外短读/重试 | **35** | 源码路径计数，不是 strace 实测 |

因此 F0 baseline 的 81,891 次 Host 检查对应常见路径至少约 2,866,185 次文件 syscall。原实测嵌套 Host CPU 为 5.096705 秒，不能由此推定每个 syscall 的独立成本或直接预测某个替换的收益。

## 已有优化不能重复算为新收益

`read_context_text` 在 256-byte 常见区间返回 borrowed Cow，只有真实超长文本才从同一 stream 转入 owned buffer；`read_limits` 使用五个 129-byte stack buffer。五个 `openat` 名称已是 static CStr，无 join/String。每次只执行一次原 `validate_limits`；`check()` 不调用 canonicalize。`impl Read` 是泛型静态分发，并非必然的 dyn vtable 热点。`resource_sample` 的 BTreeMap 属于 counter 观测，不是每次 `check()` 的分支。

官方 Rust 1.95 的短 Path→CStr helper 使用 384-byte stack 路径；当前 boot/membership/fixed-parent 的短路径不为每次 File::open 或 symlink_metadata 分配 CString。因此将它们简单改成预存 CStr，不能声称消除了已存在的 heap allocation。

## 可评估方案与风险

| 方案 | 安全条件 | 当前判断 |
|---|---|---|
| 只改变 fresh metadata 的表示/API | 仍对相同实际 opened FD 检查 regular；绝对 parent 的 nofollow/type/mode/dev/ino/uid 全部相同；保留错误归类和检查顺序 | 有条件的小试验。Rust std 在 Linux 优先取 STATX_BASIC_STATS 与 BTIME 再转换 FileAttr，当前 regular 检查不需 birth time。可以研究 rustix fresh stat 或精确 mask，但 syscall 总数不减少，收益未测，不能承诺解决四秒 |
| 已完成五次真实读取后，对当前完整 bytes 做 pure parsing fast path，任何非精确匹配回原 parser | 不保留成功 resource verdict；不先 parse CPU 从而跳过后续 I/O；包含全部字节且保留 UTF-8/EOF/大小行为 | 理论上等价，但原数字解析无 heap、文本极短，预计收益小且未测；不建议抢占主修复 |
| 去掉第一次 metadata、最后 parent fence、regular-fd 检查或 EOF 探针 | 无法维持当前威胁模型 | 拒绝 |
| 保留 limit/proc fd 后 seek/pread，cache membership/boot/limits，降低 checkpoint 次数 | 会改变 current path 或 current authority 观察 | 拒绝 |
| 并行读取五个文件或 io_uring 批提交 | 会改变原错误优先级、时序、第五文件同步切点，且很难在 read 前拒绝非regular对象 | 不作为最小修复；需要独立设计，当前不采用 |
| 用 held parent metadata 取代绝对路径 metadata；只观察 `/proc/self/cgroup` | 分别丢失当前路径替换与实际工作线程迁移观察 | 拒绝 |

metadata 小试验如果实施，必须保留 type、mode、uid、dev/ino 的跨 x64/arm64 行为；注意旧内核或 seccomp 对 statx/fstat 不同拒绝可能改变原失败语义。只保留接收面不变的保守 fallback，不能以新 syscall 成功掩盖旧路径明确权限拒绝。没有实际 native 结果前，不给任何性能通过结论。

## 初始化入口缺口及最小修复边界

`KernelBudget::open` 先验证固定 root-owned parent 并持有目录，再用五次绝对路径 `read_to_string` 取得初始 Limits，最后才运行完整 `check`。后者的安全保护无法补救前者已经发生的无期限阻塞。既有 20-case FIFO/directory/symlink 回归调用的是 `ParentDirectory::verify_limits`，尚未覆盖这一 constructor acquisition。

最小候选设计是让 constructor 的初始 acquisition 也进入同一 held-directory fresh child reader，包含 NONBLOCK、NOFOLLOW、opened-FD regular、真实 EOF 和有限字节。在成功建立 KernelBudget 后，保留原完整 `checked.check()`；不得拿初始化读取代替它。

必须明确两个边界：原 Linux cgroupfs 本身不会允许普通无权限客户端创建这些 FIFO，因此这不是现有网络客户端能够直接注入 FIFO 的证明；触发需要错误或已被替换的实际挂载/文件对象。其次，初始化的旧读取没有 128-byte 上限；直接改成既有 bounded reader，会令某些“前项语法坏且后项过长”的错误从旧 parse error 提前变为 acquisition error。所有最终成功接收都仍需现有 bounded check，接受面不会扩大，但**旧 constructor 错误身份不是自动逐字等价**，实施前需明确并以双故障回归固定所需优先级。

对应有意义回归应让原 production constructor acquisition 所调用的真实 helper 在子进程接受五个文件×四种非regular情形，共 20 cases；无环境 helper 必须失败；有界 timeout 后 kill/reap，必须看到进入和拒绝双 marker。继续保留原8个 meaningful relative controls与原最终 fifth-open selector。普通临时目录仍只验证 acquisition，不得由测试获得 public Host 资格。

## 对服务修复的限制

F0 的 baseline client import 中 Host 占已知线程 CPU 的约 85.37%，但残余计算、receiver 提交、CPU wait、kernel quota 与最终独立确认仍有实际成本。metadata 或 parsing 小改没有测量依据可将 62 μs 左右的整次 Host check 降到目标量级。必须与保持当前状态观察的 account-graph/历史结构工作一起评估，最终仍使用原 6/42、4秒/30秒、quarter-CPU 分母验证，不以热路径微基准替代服务门。
