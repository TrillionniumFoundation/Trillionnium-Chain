#!/usr/bin/env python3
import ctypes,hashlib,json,os,pathlib,stat,time
P=pathlib.Path('/tmp/chain-pq-fa62381e-s3-positive')
N=pathlib.Path('/tmp/chain-pq-fa62381e-s3-negative')
C=pathlib.Path('/tmp/chain-pq-fa62381e-s3-coordination')
S='454ae116159867ff6cddd91b964523df7f7e16f0'
T='3117250c4db0f2ae681d51ed6ee5e6a2fa7555a9'
NS='f7c51532cc6657360b97226d9f396158253cea78'
NT='628f0d54ad9127471cc3902b50b915c4df2dcad7'
PR='effa69e49141bc020bfd0b9861218a7da1729d4811ec7c6003a52c72513ff60b'
NR='58e2fa946a7dc34cf58e8b357e04c2789da98f8b6218768d8e29651c6cf6b6f7'
def sha(b):return hashlib.sha256(b).hexdigest()
def fp(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def raw(p):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
 try:
  a=os.fstat(fd);assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
  chunks=[]
  while True:
   b=os.read(fd,1048576)
   if not b:break
   chunks.append(b)
  b=b''.join(chunks);assert len(b)==a.st_size and fp(a)==fp(os.fstat(fd))==fp(p.stat(follow_symlinks=False))
  return b
 finally:os.close(fd)
def unique(pairs):
 r={}
 for k,v in pairs:
  assert k not in r,'duplicate JSON key';r[k]=v
 return r
def read(p):
 b=raw(p);return json.loads(b,object_pairs_hook=unique),sha(b)
def elf(p,expected):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  a=os.fstat(fd);assert stat.S_ISREG(a.st_mode) and a.st_nlink==1
  assert os.pread(fd,4,0)==b'\x7fELF'
  h=hashlib.sha256()
  while True:
   b=os.read(fd,1048576)
   if not b:break
   h.update(b)
  assert h.hexdigest()==expected
  assert fp(a)==fp(os.fstat(fd))==fp(pathlib.Path(p).stat(follow_symlinks=False))
  return {'sha256':expected,'bytes':a.st_size,'device':a.st_dev,'inode':a.st_ino}
 finally:os.close(fd)
def verify(out,source,tree,runner,positive=False):
 ready,rpin=read(out/'build-ready.json')
 assert ready['native_tests_started'] is False and ready['runner_sha256']==runner
 if positive:
  assert rpin=='a8af1a70192ef8b03781ce10d7c35cdef2004150e795493c5c3a848f3897bef8'
  assert ready['positive_source']==S and ready['status']=='native-build-complete-awaiting-barrier'
 else:
  assert ready['negative_source']==NS and ready['positive_source']==S
  assert ready['status']=='native-build-complete-awaiting-negative-release'
 receipt,cph=read(out/'commands/node-lib-build.json')
 assert cph==ready['build_receipt_sha256']
 assert receipt['status']=='command_succeeded' and receipt['exit_code']==0
 assert receipt['before']==receipt['after']
 ident=receipt['before']
 assert ident['tested_commit']==source and ident['tested_tree']==tree and ident['tracked_worktree_verified'] is True
 assert receipt['argv']==['cargo','+1.95.0','test','--locked','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib','--all-features','--no-run','--message-format=json']
 artifact,aph=read(out/'native-artifact.json')
 assert aph==ready['native_artifact_sha256'] and artifact['source']==source and artifact['runner_sha256']==runner
 assert artifact['build_receipt_sha256']==cph and artifact['executable_sha256']==ready['executable_sha256']
 cargo=artifact['cargo_artifact'];assert cargo['fresh'] is False and cargo['profile']['test'] is True and cargo['target']['kind']==['lib']
 assert sha(raw(out/'commands/node-lib-build.log'))==receipt['log_sha256']==artifact['build_log_sha256']
 if positive:
  assert cph=='96025722e0048134e52b4ad834692b00ac94629340fcbd5deeb0db219c890c80'
  assert aph=='fd771ceffcda88a5b5424a971b677e4c43b874ff0688729babf834381c3b3bae'
  assert ready['executable_sha256']=='081ee2780e100ac74ee57a934edc5ae83dca0eaac2a3c370eb294ec442efe4ef'
 else:
  assert artifact['positive_source']==S
  assert sha(raw(pathlib.Path('/tmp/chain-pq-negative-source-fa62381e-s3/source-lineage.json')))==artifact['source_lineage_sha256']
 return {'source':source,'tree':tree,'ready_sha256':rpin,'build_receipt_sha256':cph,'artifact_sha256':aph,'elf':elf(artifact['executable'],ready['executable_sha256']),'profile':cargo['profile'],'features':cargo['features']}

# Only the preceding read/build/ELF functions are copied from the reviewed
# positive coordinator. Its top-level main and publication code are not run.
import io,sys,subprocess,types
from collections import Counter
sys.dont_write_bytecode=True
ROOT=pathlib.Path('/tmp/chain-pq-fa62381e')
NROOT=pathlib.Path('/tmp/chain-pq-negative-fa62381e')
PR_PATH=pathlib.Path('/tmp/chain-pq-fa62381e-validation-plan-batched64-barrier-v2.py')
NR_PATH=pathlib.Path('/tmp/chain-pq-fa62381e-negative-tools/chain-pq-fa62381e-negative-validation-v3.py')
DECISION=C/'negative-release-decision.json'
RELEASE=C/'negative-release.json'

def require(condition,message):
 if not condition:raise ValueError(message)

def load_bytes_module(name,path,data):
 module=types.ModuleType(name);module.__file__=str(path)
 sys.modules[name]=module
 exec(compile(data,str(path),'exec'),module.__dict__)
 return module

def committed_module(name,relative):
 path=ROOT/relative
 data=raw(path)
 result=subprocess.run(['git','--no-pager','show',S+':'+relative],cwd=ROOT,
                       stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 require(data==result.stdout,'original helper differs from frozen S3: '+relative)
 return load_bytes_module(name,path,data),sha(data)

def successful_command(path,identity,argv=None):
 value,pin=read(path)
 require(value['status']=='command_succeeded' and value['exit_code']==0,
         'recorded command did not succeed: '+str(path))
 require(value['before']==value['after']==identity,'source identity changed: '+str(path))
 if argv is not None:require(value['argv']==argv,'recorded command argv changed')
 log=raw(path.with_suffix('.log'))
 require(sha(log)==value['log_sha256'],'recorded command log hash changed')
 return value,pin

def validate_positive(proof):
 artifact,artifact_pin=read(P/'native-artifact.json')
 build,_=read(P/'commands/node-lib-build.json')
 identity=build['before']
 before,before_pin=read(P/'source-before.json')
 final,final_pin=read(P/'source-final.json')
 after,after_pin=read(P/'source-after-batch.json')
 require(before==final==after==identity,'positive before/final source identity differs')
 require(identity['tested_commit']==S and identity['tested_tree']==T
         and identity['tracked_worktree_verified'] is True,'positive source guard did not verify S3')
 runner_raw=raw(PR_PATH);require(sha(runner_raw)==PR,'positive runner changed')
 runner=load_bytes_module('positive_release_pinned_runner',PR_PATH,runner_raw)
 selection,provenance=runner.select_controls(ROOT)
 require(len(selection)==64 and len({name for _,name in selection})==64,'exact64 selection missing')
 require(artifact['selected_tests']==[list(row) for row in selection]
         and artifact['selection_provenance']==provenance,'artifact selection differs from frozen rosters')
 summary,summary_pin=read(P/'summary.json')
 batch,batch_pin=read(P/'batch/batch-summary.json')
 required_counts={'named_tests_passed':64,'named_tests_required':64,
                  'retained_controls_passed':52,'supplemental_controls_passed':7,
                  'focused_extra_controls_passed':5}
 for label,value in [('positive',summary),('batch',batch)]:
  for key,count in required_counts.items():require(value[key]==count,label+' incomplete '+key)
  require(value['component_validation_passed'] is True and value['phase_error'] is None,
          label+' native controls did not pass')
  require(value['runner_sha256']==PR and value['selection_provenance']==provenance,
          label+' selection or runner changed')
  require(value['retained_pnq2_roster_executed_in_full'] is True
          and value['original_business_budgets_changed'] is False
          and value['whole_chain_quantum_security_qualified'] is False
          and value['production_activation'] is False,label+' scope or budgets changed')
 require(summary['source']==S and summary['default_workspace_profiles'] is True,'source/profile mismatch')
 require(batch['artifact_sha256']==artifact_pin and batch['executable']==artifact['executable']
         and batch['executable_sha256']==artifact['executable_sha256'],'batch artifact identity differs')
 outer,outer_pin=read(P/'observations.json')
 require(summary['observations']==outer and len(outer)==4,'outer observation roster changed')
 expected_outer=['preflight','compiler','node-lib-build','focused-native-batch']
 for row,label in zip(outer,expected_outer):
  require(row['label']==label and row['error'] is None,'failed/missing outer observation')
  require(row['owner']['exit_code']==0 and row['owner']['timed_out'] is False,'failed outer owner')
 require([row['source_recorded'] for row in outer]==[False,False,True,True],'source recorder missing')
 command,command_pin=successful_command(P/'commands/focused-native-batch.json',identity)
 expected_suffix=[str(PR_PATH),'_native_batch',str(ROOT),str(P/'native-artifact.json'),
                  artifact_pin,str(P/'batch'),PR,'900']
 require(command['argv'][1:]==expected_suffix,'positive exact native batch argv differs')
 require(pathlib.Path(command['argv'][0]).is_absolute(),'batch interpreter is not absolute')
 checker,checker_pin=committed_module('check_required_native_test','scripts/ci/check_required_native_test.py')
 rows,rows_pin=read(P/'batch/batch-observations.json')
 require(len(rows)==65,'expected one inventory plus exactly64 actual invocations')
 logs=[]
 expected=[('native-list',None),*selection]
 for row,(label,name) in zip(rows,expected):
  require(row['label']==label and row['required_test']==name and row['error'] is None,
          'native row identity or error differs: '+label)
  owner=row['owner']
  require(owner['exit_code']==0 and owner['timed_out'] is False,'native owner failed: '+label)
  actual,receipt_pin=read(P/'batch'/(label+'.native.json'))
  require(actual==row['native_receipt'],'embedded/actual native receipt differs: '+label)
  require(actual['status']=='command_succeeded' and actual['native_exit_code']==0
          and actual['native_execution']['status']=='PINNED_AND_OBSERVED','actual native failure: '+label)
  require(actual['expected_executable_sha256']==artifact['executable_sha256']
          and actual['runner_sha256']==PR,'native ELF/runner pin differs: '+label)
  native_args=(['--list','--format','pretty'] if name is None else
               [name,'--exact','--show-output','--test-threads=1','--format','pretty'])
  require(actual['argv']==[artifact['executable'],*native_args],'native argv differs: '+label)
  require(row['log']==actual['log']==label+'.log','native log basename differs: '+label)
  log=raw(P/'batch'/(label+'.log'));log_pin=sha(log)
  require(log_pin==row['log_sha256']==actual['log_sha256']
          and len(log)==row['log_bytes']==actual['log_bytes'],'actual log hash/size differs: '+label)
  # Parse the same bytes that were hashed, never re-open after verification.
  if name is not None:
   checked=checker.validate(io.StringIO(log.decode('utf-8')),name)
   require(checked==row['named_execution'],'original exact named validation differs: '+label)
  else:
   require(row['named_execution'] is None,'inventory is not an executed test')
   names=Counter(line[:-6] for line in log.decode('utf-8').splitlines() if line.endswith(': test'))
   require(all(names[name]==1 for _,name in selection),'inventory missing/duplicate exact selector')
  logs.append({'label':label,'test':name,'log_sha256':log_pin,'receipt_sha256':receipt_pin,
               'actual_native_exit_code':actual['native_exit_code']})
 require(proof['artifact_sha256']==artifact_pin,'coordinator positive artifact differs')
 return {'summary_sha256':summary_pin,'batch_summary_sha256':batch_pin,
         'batch_observations_sha256':rows_pin,'outer_observations_sha256':outer_pin,
         'source_before_sha256':before_pin,'source_final_sha256':final_pin,
         'source_after_batch_sha256':after_pin,'batch_command_receipt_sha256':command_pin,
         'original_named_checker_sha256':checker_pin,'actual_rows':65,'actual_named_passes':64,
         'retained_passes':52,'supplemental_passes':7,'focused_extra_passes':5,
         'revalidated_logs':logs},identity

def conservative_time_bound(ready_stat):
 # The negative runner did not persist its exact monotonic start. The ready
 # file is written before that start. This wall-clock age is ONLY an auxiliary
 # conservative bound; the running original barrier retains its 1800s monotonic
 # deadline and independently refuses any late release. No deadline is reset.
 now_wall=time.time_ns();now_mono=time.monotonic_ns()
 age=now_wall-ready_stat.st_mtime_ns
 require(0<=age<1800*1_000_000_000,'negative ready wall-clock age exceeds conservative1800s bound')
 return now_mono+(1800*1_000_000_000-age)

def publish_negative(value,deadline,ready_stat):
 fd=os.open(C,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:
  tmp='negative-release.tmp';dest='negative-release.json'
  f=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=fd)
  b=(json.dumps(value,sort_keys=True)+'\n').encode()
  with os.fdopen(f,'wb') as stream:stream.write(b);stream.flush();os.fsync(stream.fileno())
  libc=ctypes.CDLL(None,use_errno=True)
  rename=libc.renameat2
  rename.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint]
  rename.restype=ctypes.c_int
  require(time.monotonic_ns()<deadline,'conservative negative publication deadline elapsed')
  require(time.time_ns()<ready_stat.st_mtime_ns+1800*1_000_000_000,
          'negative ready wall-clock1800s bound elapsed before publication')
  if rename(fd,tmp.encode(),fd,dest.encode(),1)!=0:
   raise OSError(ctypes.get_errno(),'atomic no-replace negative release failed')
  os.fsync(fd)
  require(raw(RELEASE)==b,'published negative release readback differs')
  return sha(b)
 finally:os.close(fd)

def main():
 record={'schema':'trnm-pq-negative-release-decision-v1','status':'started',
         'native_tests_executed_by_coordinator':False,'negative_release_written':False,
         'whole_chain_quantum_security_qualified':False,'production_activation':False,
         'original_negative_barrier_timeout_seconds':1800,
         'external_exact_monotonic_deadline_known':False,'negative_deadline_extended':False}
 # Entry is create-only; retry of this helper never publishes a second release.
 with DECISION.open('x') as entry:
  json.dump(record,entry,sort_keys=True);entry.write('\n');entry.flush();os.fsync(entry.fileno())
 try:
  require(not RELEASE.exists() and not (C/'negative-release.tmp').exists(),'negative release already exists')
  ready_stat=(N/'build-ready.json').stat(follow_symlinks=False)
  deadline=conservative_time_bound(ready_stat)
  decision,decision_pin=read(C/'positive-release-decision.json')
  require(decision['status']=='positive-release-published'
          and decision['native_tests_executed_by_coordinator'] is False
          and decision['negative_release_written'] is False,'original coordinator did not safely release positive')
  require(sha(raw(C/'positive-release.json'))==decision['release_sha256'],'positive release changed')
  p=verify(P,S,T,PR,True);n=verify(N,NS,NT,NR)
  require(p==decision['positive'] and n==decision['negative'],'fresh build proof differs from original coordinator')
  require(p['profile']==n['profile'] and p['features']==n['features'],'positive/negative build profiles differ')
  require(sha(raw(NR_PATH))==NR,'negative runner changed')
  validated,identity=validate_positive(p)
  # Read-only use of the original frozen physical source guard at publication.
  sys.path.insert(0,str(ROOT/'scripts/ci'))
  source_guard,guard_pin=committed_module('verify_ci_source','scripts/ci/verify_ci_source.py')
  require(source_guard.verify('head',S,root=ROOT)==identity,'positive original physical source verification changed')
  nreceipt,_=read(N/'commands/node-lib-build.json')
  require(source_guard.verify('head',NS,root=NROOT)==nreceipt['before'],
          'negative original physical source verification changed')
  # Repeat identity/hash observations after transcript and physical-source reads.
  require(verify(P,S,T,PR,True)==p and verify(N,NS,NT,NR)==n,'build identity changed during release checks')
  ready,ready_pin=read(N/'build-ready.json')
  require(ready_pin==n['ready_sha256'] and fp(ready_stat)==fp((N/'build-ready.json').stat(follow_symlinks=False)),
          'negative ready identity changed')
  require(ready['barrier_timeout_seconds']==1800 and ready['release_path']==str(RELEASE)
          and ready['component_validation_passed'] is False and ready['native_tests_started'] is False,
          'negative original barrier contract changed')
  require(not (N/'negative-release-observation.json').exists()
          and not (N/'batch/batch-observations.json').exists(),'negative native execution already started')
  expected={'schema':'trnm-pq-negative-native-release-v1','status':'positive-native-controls-complete',
            'negative_source':NS,'positive_source':S,'native_artifact_sha256':n['artifact_sha256'],
            'executable_sha256':n['elf']['sha256']}
  require(ready['required_release_value']==expected,'negative required release value differs')
  record.update(positive=p,negative=n,positive_validation=validated,
                original_positive_coordinator_sha256=decision_pin,original_source_guard_sha256=guard_pin,
                negative_ready_mtime_ns=ready_stat.st_mtime_ns,
                conservative_auxiliary_deadline_monotonic_ns=deadline)
  record['release_sha256']=publish_negative(ready['required_release_value'],deadline,ready_stat)
  record.update(status='negative-release-published',negative_release_written=True,
                released_monotonic_ns=time.monotonic_ns())
 except BaseException as exc:
  record.update(status='refused',error=repr(exc));raise
 finally:
  # This is our own create-only journal, not a prior execution observation.
  with DECISION.open('w') as stream:
   json.dump(record,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
  print(json.dumps(record,sort_keys=True),flush=True)

if __name__=='__main__':main()
