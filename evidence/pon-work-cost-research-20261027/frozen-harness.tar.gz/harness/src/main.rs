use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{
    error::Error,
    fs::{self, File, OpenOptions},
    io::{Read, Write},
    path::{Path, PathBuf},
    time::Instant,
};
use trnm_pure_pon_research::{
    low_rank_prefix::{Kernel, LowRankPrefixPrepared},
    pon_work::{self, hash, Hash, WorkError, CELLS, N, Q},
    statement::{self, CompleteStatement},
};

type AnyResult<T> = Result<T, Box<dyn Error>>;
type Producer = Box<dyn Fn(Hash) -> Result<Vec<u8>, WorkError>>;
mod rejection_cost;
const METHODS: &[&str] = &[
    "scalar-full",
    "prepared",
    "paired",
    "tiled-classical",
    "strassen-one-level",
    "structured",
    "blocked-zero",
    "blocked-zero-paired",
    "blocked-one-zero",
    "maintenance-prefix",
    "maintenance-integer-paired",
    "maintenance-periodic",
    "maintenance-limb",
    "low-rank-prefix-scalar",
    "low-rank-prefix-paired",
];

fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{x:02x}")).collect()
}
fn digest(b: &[u8]) -> String {
    hex(&Sha256::digest(b))
}
fn cpu_ns() -> AnyResult<u128> {
    let mut t = libc::timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    // The research harness is Linux-only; failure is an error, never a zero cost.
    if unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut t) } != 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    Ok(t.tv_sec as u128 * 1_000_000_000 + t.tv_nsec as u128)
}
fn bounded_read(path: &Path, limit: usize) -> AnyResult<Vec<u8>> {
    let mut bytes = Vec::new();
    File::open(path)?
        .take((limit + 1) as u64)
        .read_to_end(&mut bytes)?;
    if bytes.len() > limit {
        return Err("input exceeds bound".into());
    }
    Ok(bytes)
}
fn write_new(path: &Path, b: &[u8]) -> AnyResult<()> {
    let mut f = OpenOptions::new().write(true).create_new(true).open(path)?;
    f.write_all(b)?;
    f.sync_all()?;
    Ok(())
}
fn write_json(path: &Path, value: &Value) -> AnyResult<()> {
    let mut bytes = serde_json::to_vec_pretty(value)?;
    bytes.push(b'\n');
    write_new(path, &bytes)
}
fn random_words(label: &[u8], n: usize) -> Vec<u32> {
    let mut out = Vec::with_capacity(n);
    for counter in 0_u64.. {
        for b in hash(b"p0-material-v1", &[label, &counter.to_le_bytes()]).chunks_exact(4) {
            let x = u32::from_le_bytes(b.try_into().unwrap());
            if u128::from(x) < Q {
                out.push(x);
                if out.len() == n {
                    return out;
                }
            }
        }
    }
    unreachable!()
}
fn rank_matrix(rank: usize, label: &[u8]) -> Vec<u32> {
    if rank == 0 {
        return vec![0; CELLS];
    }
    let mut left_label = label.to_vec();
    left_label.push(0);
    let mut right_label = label.to_vec();
    right_label.push(1);
    let l = random_words(&left_label, N * rank);
    let r = random_words(&right_label, rank * N);
    (0..N)
        .flat_map(|i| {
            (0..N).map({
                let l = &l;
                let r = &r;
                move |j| {
                    ((0..rank)
                        .map(|k| u128::from(l[i * rank + k]) * u128::from(r[k * N + j]))
                        .sum::<u128>()
                        % Q) as u32
                }
            })
        })
        .collect()
}
fn material(name: &str) -> AnyResult<(Vec<u32>, Vec<u32>)> {
    let pair = match name {
        "zero" => (vec![0; CELLS], vec![0; CELLS]),
        "rank1" => (rank_matrix(1, b"a1"), rank_matrix(1, b"b1")),
        "rank2" => (rank_matrix(2, b"a2"), rank_matrix(2, b"b2")),
        "rank4" => (rank_matrix(4, b"a4"), rank_matrix(4, b"b4")),
        "rank8" => (rank_matrix(8, b"a8"), rank_matrix(8, b"b8")),
        "one-zero" => (rank_matrix(1, b"a1"), vec![0; CELLS]),
        "identity" => {
            let a: Vec<_> = (0..CELLS).map(|i| u32::from(i / N == i % N)).collect();
            (a.clone(), a)
        }
        "diagonal" => {
            let a: Vec<_> = (0..CELLS)
                .map(|i| {
                    if i / N == i % N {
                        (i / N + 1) as u32
                    } else {
                        0
                    }
                })
                .collect();
            (a.clone(), a)
        }
        "sparse" => {
            let a: Vec<_> = (0..CELLS)
                .map(|i| {
                    if (i * 31 + 7) % 67 == 0 {
                        (i + 1) as u32
                    } else {
                        0
                    }
                })
                .collect();
            (a.clone(), a)
        }
        "repeated-rows" => {
            let row = random_words(b"repeat", N);
            let a: Vec<_> = (0..CELLS).map(|i| row[i % N]).collect();
            (a.clone(), a)
        }
        "maintenance" => (
            (0..CELLS).map(|i| ((13 * i + 17) % 257) as u32).collect(),
            (0..CELLS).map(|i| ((29 * i + 31) % 263) as u32).collect(),
        ),
        "legacy-periodic" => (
            (0..CELLS).map(|i| (i % 31) as u32).collect(),
            (0..CELLS).map(|i| ((i * 7) % 37) as u32).collect(),
        ),
        "dense" => (
            random_words(b"dense-a", CELLS),
            random_words(b"dense-b", CELLS),
        ),
        _ => return Err("unknown material case".into()),
    };
    Ok(pair)
}
fn header(task: Hash, nonce: u64, target_bits: u32) -> Vec<u8> {
    let mut h = vec![0; statement::HEADER_BYTES];
    h[..6].copy_from_slice(b"PNH1\x01\0");
    h[6..38].copy_from_slice(&hash(b"p0-network-fixture-v1", &[]));
    h[38..70].copy_from_slice(&hash(b"p0-parameters-fixture-v1", &[]));
    h[70..102].copy_from_slice(&hash(b"p0-parent-fixture-v1", &[]));
    h[102..110].copy_from_slice(&1_u64.to_le_bytes());
    h[110..118].copy_from_slice(&1_800_000_000_u64.to_le_bytes());
    let mut target = [255; 32];
    for bit in 0..target_bits {
        target[(bit / 8) as usize] &= !(1 << (7 - bit % 8));
    }
    h[118..150].copy_from_slice(&target);
    h[150..182].copy_from_slice(&hash(b"p0-miner-fixture-v1", &[]));
    h[278..310].copy_from_slice(&task);
    h[310..318].copy_from_slice(&nonce.to_le_bytes());
    h
}
fn build(method: &str, a: &[u32], b: &[u32]) -> Result<Option<Producer>, WorkError> {
    macro_rules! required {
        ($p:expr) => {{
            let p = $p?;
            Some(Box::new(move |c| p.prove(c)) as Producer)
        }};
    }
    macro_rules! optional {
        ($p:expr) => {{
            $p?.map(|p| Box::new(move |c| p.prove(c)) as Producer)
        }};
    }
    Ok(match method {
        "scalar-full" => {
            let a = a.to_vec();
            let b = b.to_vec();
            Some(Box::new(move |c| pon_work::prove(c, &a, &b)) as Producer)
        }
        "prepared" => required!(pon_work::PreparedTask::new(a, b)),
        "paired" => required!(pon_work::paired_product::PairedPreparedTask::new(a, b)),
        "tiled-classical" => required!(pon_work::structured::TiledPreparedTask::new(
            a,
            b,
            pon_work::structured::TileKernel::Classical
        )),
        "strassen-one-level" => required!(pon_work::structured::TiledPreparedTask::new(
            a,
            b,
            pon_work::structured::TileKernel::StrassenOneLevel
        )),
        "structured" => optional!(pon_work::structured::StructuredPreparedTask::new(a, b)),
        "blocked-zero" => optional!(pon_work::blocked_zero::BlockedZeroPreparedTask::new(a, b)),
        "blocked-zero-paired" => {
            optional!(pon_work::blocked_zero_paired::BlockedZeroPairedPreparedTask::new(a, b))
        }
        "blocked-one-zero" => {
            optional!(pon_work::blocked_one_zero::BlockedOneZeroRankOnePreparedTask::new(a, b))
        }
        "maintenance-prefix" => {
            optional!(pon_work::maintenance_prefix::MaintenancePrefixPreparedTask::new(a, b))
        }
        "maintenance-integer-paired" => {
            optional!(pon_work::maintenance_prefix::MaintenanceIntegerPairedPreparedTask::new(a, b))
        }
        "maintenance-periodic" => {
            optional!(pon_work::maintenance_periodic::MaintenancePeriodicPreparedTask::new(a, b))
        }
        "maintenance-limb" => {
            optional!(pon_work::maintenance_limb::MaintenanceLimbPreparedTask::new(a, b))
        }
        "low-rank-prefix-scalar" => optional!(LowRankPrefixPrepared::new(a, b, Kernel::Scalar)),
        "low-rank-prefix-paired" => optional!(LowRankPrefixPrepared::new(a, b, Kernel::Paired)),
        _ => return Err(WorkError::Version),
    })
}
fn work_error(e: WorkError) -> Box<dyn Error> {
    format!("W1 {e:?}").into()
}
fn measure<T>(run: impl FnOnce() -> AnyResult<T>) -> AnyResult<(T, u128, u128)> {
    let cpu = cpu_ns()?;
    let wall = Instant::now();
    let value = run()?;
    let elapsed = wall.elapsed().as_nanos();
    Ok((value, elapsed, cpu_ns()? - cpu))
}

fn export(out: &Path, case: &str, target_bits: u32, max_attempts: u64) -> AnyResult<()> {
    if target_bits > 20 || max_attempts == 0 || max_attempts > 65536 {
        return Err("export search bounds".into());
    }
    let (a, b) = material(case)?;
    let task = pon_work::task_id(&a, &b).map_err(work_error)?;
    let (producer, setup_wall, setup_cpu) = measure(|| {
        Ok(build("paired", &a, &b)
            .map_err(work_error)?
            .ok_or("unsupported")?)
    })?;
    let mut observations = Vec::new();
    let mut winner = None;
    for nonce in 1..=max_attempts {
        let ((h, proof, ticket, hit), wall, cpu) = measure(|| {
            let h = header(task, nonce, target_bits);
            let c = hash(b"challenge", &[&h]);
            let proof = producer(c).map_err(work_error)?;
            let ticket = hash(b"ticket", &[&c, &proof[proof.len() - 32..]]);
            let target: Hash = h[118..150].try_into().unwrap();
            Ok((h, proof, ticket, ticket <= target))
        })?;
        observations.push(json!({"nonce":nonce,"wall_ns":wall,"process_cpu_ns":cpu,"ticket":hex(&ticket),"winner":hit,"proof_sha256":digest(&proof)}));
        if hit {
            winner = Some((h, proof));
            break;
        }
    }
    fs::create_dir(out)?;
    write_json(
        &out.join("search.json"),
        &json!({"schema":"trnm-pure-pon-search-v1","case":case,"target_bits":target_bits,"setup_wall_ns":setup_wall,"setup_cpu_ns":setup_cpu,"attempts":observations,"winner_found":winner.is_some(),"failed_attempt_cost_included":true}),
    )?;
    let Some((h, proof)) = winner else {
        return Err("bounded winner search exhausted; search.json retains all attempts".into());
    };
    let (s, verify_wall, verify_cpu) = measure(|| {
        CompleteStatement::from_winner(&h, &proof).map_err(|e| format!("{e:?}").into())
    })?;
    let (w, witness_wall, witness_cpu) =
        measure(|| statement::export_witness(&s, &proof).map_err(|e| format!("{e:?}").into()))?;
    let files = [
        ("header.bin", h),
        ("pnw1.bin", proof),
        ("noise.bin", w.noise_bytes()),
        ("noised-a.bin", w.noised_a_bytes()),
        ("noised-b.bin", w.noised_b_bytes()),
        ("transcript.bin", w.transcript.clone()),
    ];
    let mut artifacts = Vec::new();
    for (name, bytes) in &files {
        write_new(&out.join(name), bytes)?;
        artifacts.push(json!({"path":name,"bytes":bytes.len(),"sha256":digest(bytes)}));
    }
    let trace_len = b"TRNM-PON-TRACE1\0".len() + 32 + statement::TRACE_BYTES;
    let blocks = |len: usize| (len + 9).div_ceil(64);
    write_json(
        &out.join("statement.json"),
        &json!({
            "schema":statement::STATEMENT_SCHEMA,"status":"COMPLETE_W1_WITNESS_ONLY_NOT_SUCCINCT_PROOF","source_commit":statement::SOURCE_COMMIT,"profile":pon_work::PROFILE,
            "statement_id":hex(&s.statement_id),"challenge":hex(&s.challenge),"task":hex(&s.task),"target":hex(&s.target),"trace":hex(&s.trace),"ticket":hex(&s.ticket),"semantic_block_id":hex(&s.block_id),"pnw1_sha256":hex(&s.proof_digest),
            "fri_commit_grinding_bits":0,"fri_query_grinding_bits":0,"proof_grinding_bits":0,"independent_work_puzzle":false,
            "transparent_backend_executed":false,"succinct_proof_generated":false,"computational_hardness_qualified":false,"post_quantum_qualified":false,"parent_state_or_chain_validity_checked":false,"node_task_eligibility_checked":false,
            "admission_scope":"W1 primitive acceptance only; synthetic parent/network, no task registration, lease, reward, DAA or chain acceptance",
            "complete_original_w1_verified":true,"full_verifier_wall_ns":verify_wall,"full_verifier_cpu_ns":verify_cpu,"witness_export_wall_ns":witness_wall,"witness_export_cpu_ns":witness_cpu,
            "noise_hashes":w.noise_hashes,"trace_cells":statement::TRACE_BYTES/4,"native_field_multiplications":458752,
            "sha256_workload":{"task_blocks":blocks(10+2+4+8+2*CELLS*4),"noise_blocks":w.noise_hashes.iter().sum::<u32>()*2,"transcript_blocks":blocks(trace_len),"ticket_blocks":blocks(10+2+6+8+64),"challenge_blocks":blocks(10+2+9+4+318),"pnw1_binding_blocks":blocks(pon_work::PROOF_BYTES)},
            "non_native_risk":"W1 q=2^32-5; exact modular arithmetic and SHA-256 must be proved, not replaced. q-1 has two-adicity 1.","artifacts":artifacts
        }),
    )?;
    println!(
        "{}",
        json!({"event":"winner_witness_exported","directory":out,"attempts":observations.len(),"succinct_proof":false})
    );
    Ok(())
}

fn benchmark(out: &Path, samples: usize, horizons: &[usize], cases: &[&str]) -> AnyResult<()> {
    if samples == 0
        || samples > 12
        || horizons.is_empty()
        || horizons.iter().any(|h| *h == 0 || *h > 1024)
    {
        return Err("benchmark bounds".into());
    }
    fs::create_dir(out)?;
    let exe = fs::read(std::env::current_exe()?)?;
    write_json(
        &out.join("intent.json"),
        &json!({"schema":"trnm-pure-pon-adversarial-intent-v1","source_commit":statement::SOURCE_COMMIT,"binary_sha256":digest(&exe),"samples":samples,"horizons":horizons,"cases":cases,"target_bits":4,"status":"STARTED_NOT_COMPLETED","node_task_eligibility_checked":false,"succinct_proof":false}),
    )?;
    let mut rows = Vec::new();
    let mut controls = Vec::new();
    let mut proof_streams = Vec::new();
    for case in cases {
        let (a, b) = material(case)?;
        let task = pon_work::task_id(&a, &b).map_err(work_error)?;
        let ranks = LowRankPrefixPrepared::new(&a, &b, Kernel::Scalar)
            .map_err(work_error)?
            .map(|p| p.ranks());
        let stream_name = format!("proofs-{case}.bin");
        let mut stream = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(out.join(&stream_name))?;
        let mut stream_hash = Sha256::new();
        let mut retained: Vec<String> = Vec::new();
        for horizon in horizons {
            // A common exact challenge sequence and an independent scalar oracle.
            // Oracle generation/verification is not included in producer timings.
            let mut expected = Vec::new();
            for nonce in 1..=*horizon {
                let h = header(task, nonce as u64, 4);
                let c = hash(b"challenge", &[&h]);
                let p = pon_work::prove(c, &a, &b).map_err(work_error)?;
                pon_work::verify(c, task, [255; 32], &p).map_err(work_error)?;
                expected.push((h, c, p));
            }
            for sample in 0..samples {
                let mut order = METHODS.to_vec();
                let len = order.len();
                order.rotate_left(sample % len);
                if sample % 2 == 1 {
                    order.reverse();
                }
                for method in order {
                    let (prepared, setup_wall, setup_cpu) =
                        measure(|| build(method, &a, &b).map_err(work_error))?;
                    let Some(producer) = prepared else {
                        rows.push(json!({"case":case,"method":method,"horizon":horizon,"sample":sample,"status":"UNSUPPORTED","setup_wall_ns":setup_wall,"setup_cpu_ns":setup_cpu}));
                        continue;
                    };
                    let mut attempts = Vec::new();
                    let mut winner_count = 0;
                    let mut generate_cpu = 0;
                    let mut generate_wall = 0;
                    let mut verify_cpu = 0;
                    let mut verify_wall = 0;
                    for (nonce, (h, c, reference)) in expected.iter().enumerate() {
                        let ((proof, attempt_c, ticket, winner), wall, cpu) = measure(|| {
                            let attempt_h = header(task, (nonce + 1) as u64, 4);
                            let attempt_c = hash(b"challenge", &[&attempt_h]);
                            let proof = producer(attempt_c).map_err(work_error)?;
                            let ticket = hash(b"ticket", &[&attempt_c, &proof[proof.len() - 32..]]);
                            let target: Hash = attempt_h[118..150].try_into().unwrap();
                            Ok((proof, attempt_c, ticket, ticket <= target))
                        })?;
                        if attempt_c != *c {
                            return Err("challenge mismatch".into());
                        }
                        if &proof != reference {
                            return Err(format!(
                                "DIFFERENTIAL_MISMATCH {case} {method} nonce {}",
                                nonce + 1
                            )
                            .into());
                        }
                        let proof_digest = digest(&proof);
                        if nonce == retained.len() {
                            stream.write_all(h)?;
                            stream.write_all(&proof)?;
                            stream_hash.update(h);
                            stream_hash.update(&proof);
                            retained.push(proof_digest.clone());
                        } else if retained.get(nonce) != Some(&proof_digest) {
                            return Err("retained timed proof mismatch".into());
                        }
                        let target: Hash = h[118..150].try_into().unwrap();
                        let (vwall, vcpu) = if winner {
                            winner_count += 1;
                            let (_, vwall, vcpu) = measure(|| {
                                pon_work::verify(*c, task, target, &proof).map_err(work_error)
                            })?;
                            (vwall, vcpu)
                        } else {
                            (0, 0)
                        };
                        generate_cpu += cpu;
                        generate_wall += wall;
                        verify_cpu += vcpu;
                        verify_wall += vwall;
                        attempts.push(json!({"nonce":nonce+1,"generate_wall_ns":wall,"generate_cpu_ns":cpu,"ticket":hex(&ticket),"winner":winner,"winner_verify_wall_ns":vwall,"winner_verify_cpu_ns":vcpu,"proof_sha256":proof_digest}));
                    }
                    rows.push(json!({"case":case,"actual_low_ranks":ranks,"method":method,"horizon":horizon,"sample":sample,"status":"BYTE_IDENTICAL_FULL_W1","setup_wall_ns":setup_wall,"setup_cpu_ns":setup_cpu,"generate_cpu_ns":generate_cpu,"generate_wall_ns":generate_wall,"winner_verify_cpu_ns":verify_cpu,"winner_verify_wall_ns":verify_wall,"winners":winner_count,"total_producer_cpu_ns":setup_cpu+generate_cpu,"cpu_ns_per_win":(setup_cpu+generate_cpu).checked_div(winner_count),"attempts":attempts}));
                }
            }
        }
        // A separate untrusted-ticket negative control. It is never accepted as
        // useful work or used as an admission/security fallback.
        let h = header(task, 1, 4);
        let c = hash(b"challenge", &[&h]);
        let target: Hash = h[118..150].try_into().unwrap();
        let (mut forged, forge_wall, forge_cpu) = measure(|| {
            let mut proof = b"PNW1".to_vec();
            for values in [&a, &b, &vec![0; CELLS]] {
                for v in values {
                    proof.extend_from_slice(&v.to_le_bytes());
                }
            }
            for nonce in 0_u64..65536 {
                let t = hash(b"p0-false-trace-negative-v1", &[&nonce.to_le_bytes()]);
                if hash(b"ticket", &[&c, &t]) <= target {
                    proof.extend_from_slice(&t);
                    return Ok((proof, nonce + 1));
                }
            }
            Err("negative control bounded search exhausted".into())
        })?;
        let (_, precheck_wall, precheck_cpu) = measure(|| {
            pon_work::precheck_proof_statement(c, task, target, &forged.0).map_err(work_error)
        })?;
        let (result, reject_wall, reject_cpu) =
            measure(|| Ok(pon_work::verify(c, task, target, &forged.0).err()))?;
        if result != Some(WorkError::Transcript) {
            return Err("false transcript control was not rejected".into());
        }
        let control_name = format!("false-trace-{case}.bin");
        let mut control_bytes = h.clone();
        control_bytes.extend_from_slice(&forged.0);
        write_new(&out.join(&control_name), &control_bytes)?;
        controls.push(json!({"case":case,"cheap_filter_passed":true,"full_verifier_result":format!("{result:?}"),"hash_trials":forged.1,"forge_wall_ns":forge_wall,"forge_cpu_ns":forge_cpu,"precheck_wall_ns":precheck_wall,"precheck_cpu_ns":precheck_cpu,"reject_wall_ns":reject_wall,"reject_cpu_ns":reject_cpu,"independent_security_puzzle":false,"path":control_name,"bytes":control_bytes.len(),"sha256":digest(&control_bytes)}));
        forged.0.fill(0);
        stream.sync_all()?;
        proof_streams.push(json!({"case":case,"path":stream_name,"format":"fixed-header318-pnw149188-records-v1","record_bytes":statement::HEADER_BYTES+pon_work::PROOF_BYTES,"records":retained.len(),"bytes":retained.len()*(statement::HEADER_BYTES+pon_work::PROOF_BYTES),"sha256":hex(&stream_hash.finalize()),"source":"actual first timed producer bytes; all other timings byte-compared to the same deterministic scalar oracle and retained SHA256","includes_target_misses":true}));
        eprintln!("completed case {case}");
    }
    write_json(
        &out.join("raw.json"),
        &json!({"schema":"trnm-pure-pon-adversarial-cost-v1","source_commit":statement::SOURCE_COMMIT,"binary_sha256":digest(&exe),"profile":pon_work::PROFILE,"target_bits":4,"samples":samples,"horizons":horizons,"cases":cases,"rows":rows,"proof_streams":proof_streams,"false_transcript_negative_controls":controls,"cpu_scope":"CLOCK_PROCESS_CPUTIME_ID single process; shared x86_64 host","admission_scope":"W1 primitive acceptance only; synthetic parent/network, no task registration, lease, reward, DAA or chain acceptance","included_costs":["per-row preparation/factor discovery","all successful and unsuccessful attempts","per-attempt header, challenge, original proof, ticket and target check"],"separate_costs":["winner full verification","oracle and differential checks","negative-control acquisition, cheap precheck and full rejection"],"qualifications":{"source_byte_identity":true,"finite_algorithm_comparison":true,"finite_algorithm_comparison_only":true,"minimal_adversarial_cost":false,"node_task_eligibility_checked":false,"real_model_utility":false,"gpu_measured":false,"network_measured":false,"succinct_proof":false,"production_activation":false}}),
    )?;
    println!(
        "{}",
        json!({"event":"benchmark_complete","directory":out,"rows":rows.len()})
    );
    Ok(())
}

fn main() -> AnyResult<()> {
    let args: Vec<_> = std::env::args().collect();
    match args.get(1).map(String::as_str) {
        Some("negative") if args.len()==5=>{let cases:Vec<_>=args[4].split(',').collect();rejection_cost::run(Path::new(&args[2]),args[3].parse()?,&cases)},
        Some("export") if args.len()==6=>export(Path::new(&args[2]),&args[3],args[4].parse()?,args[5].parse()?),
        Some("bench") if args.len()==6=>{let horizons:Vec<usize>=args[4].split(',').map(str::parse).collect::<Result<_,_>>()?;let cases:Vec<_>=args[5].split(',').collect();benchmark(Path::new(&args[2]),args[3].parse()?,&horizons,&cases)},
        Some("verify") if args.len()==4=>{let h=bounded_read(Path::new(&args[2]),318)?;let p=bounded_read(Path::new(&args[3]),pon_work::PROOF_BYTES)?;let s=CompleteStatement::from_winner(&h,&p).map_err(|e|format!("{e:?}"))?;println!("{}",json!({"full_w1_verified":true,"statement_id":hex(&s.statement_id),"semantic_block_id":hex(&s.block_id),"chain_validity":false}));Ok(())},
        Some("solve") if args.len()==6=>{let h=bounded_read(Path::new(&args[3]),318)?;if h.len()!=318{return Err("header length".into());}let bytes=bounded_read(Path::new(&args[4]),CELLS*8)?;if bytes.len()!=CELLS*8{return Err("material length".into());}let words:Vec<_>=bytes.chunks_exact(4).map(|b|u32::from_le_bytes(b.try_into().unwrap())).collect();let p=build(&args[2],&words[..CELLS],&words[CELLS..]).map_err(work_error)?.ok_or("unsupported task; no fallback")?;write_new(&PathBuf::from(&args[5]),&p(hash(b"challenge",&[&h])).map_err(work_error)?)},
        _=>Err("usage: pon-research export OUT CASE TARGET_BITS MAX_ATTEMPTS | bench OUT SAMPLES HORIZONS_CSV CASES_CSV | negative OUT SAMPLES CASES_CSV | verify HEADER PNW1 | solve METHOD HEADER MATERIAL OUTPUT".into())
    }
}
