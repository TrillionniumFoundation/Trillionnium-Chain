#!/usr/bin/env python3
"""Load the recorded fresh provider for source-bound local observations."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/tmp/chain-pq-fa62381e')
PROVIDER_ROOT = Path('/tmp/chain-pq-fa62381e-provider/attempt-4-gh-source')
PREFIX = PROVIDER_ROOT / 'runner/trnm-pq-provider-3.5.9.lcOEkd1h/install'
ENV_SHA = '4a7ebaaf9d93afb8faffcb38629a6179aaee2ab22ea88047c9bafc0f90b1d300'
RECEIPT_SHA = '11385cc846676d18e392d46055e9a946bc027c55c2d487e01fe289a220c21d03'
ARTIFACTS = {
    'bin/openssl': '9c55ae4a8820dd89dcd57359579e15b92a6e827eb5d4be8b07d9dc211c7b4fed',
    'lib/libcrypto.a': '053ccb2992b187a71af3389204e87c86d2e15597fa29c00eef16c5b24a9c6675',
    'lib/libssl.a': 'f355167951857505b5b0305fd2e8ea8f224fa29d780211175d32767b07234727',
    'include/openssl/opensslv.h': '9647fc99758cf83e3bcf11ae310894fd4911ad62bff22d8213a614df89cfedda',
    'include/openssl/configuration.h': '406c26f93511299b264062f9f3faf0760e7a0506e91a61717c491f3c92e1a996',
}
ENV_KEYS = {'OPENSSL_DIR', 'OPENSSL_STATIC', 'TRNM_PQ_OPENSSL',
            'TRNM_PQ_OPENSSL_SHA256', 'TRNM_PQ_OPENSSL_VERSION',
            'OPENSSL_CONF', 'OPENSSL_MODULES'}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('native', 'clippy'), required=True)
    parser.add_argument('--source', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--target', type=Path, required=True)
    parser.add_argument('--runner', type=Path)
    parser.add_argument('--runner-sha')
    parser.add_argument('--build-barrier', type=Path)
    args = parser.parse_args()
    require(re.fullmatch('[0-9a-f]{40}', args.source), 'full source SHA required')
    output, target = args.out.resolve(), args.target.resolve()
    require(not output.is_relative_to(ROOT) and not target.is_relative_to(ROOT),
            'outputs must stay outside source')
    require(output != target and not output.is_relative_to(target)
            and not target.is_relative_to(output), 'output and target must be separate')
    require(not output.exists(), 'fresh observation directory required')
    if args.mode == 'native':
        require(not target.exists(), 'fresh native target required')
        require(args.runner is not None and args.runner_sha is not None
                and args.build_barrier is not None, 'frozen runner and build barrier required')
        require(sha(args.runner) == args.runner_sha, 'runner digest differs')
    else:
        require(target.is_dir(), 'Clippy must name the completed positive target')
    environment_file = PROVIDER_ROOT / 'github-env'
    provider_receipt = PROVIDER_ROOT / 'receipts/pq-provider/provider.json'
    require(sha(environment_file) == ENV_SHA, 'provider environment digest differs')
    require(sha(provider_receipt) == RECEIPT_SHA, 'provider receipt digest differs')
    environment = {}
    for line in environment_file.read_text().splitlines():
        require('=' in line, 'invalid provider environment line')
        key, value = line.split('=', 1)
        require(key in ENV_KEYS and key not in environment and bool(value),
                'unexpected, duplicate, or empty provider key')
        environment[key] = value
    require(set(environment) == ENV_KEYS, 'incomplete provider environment')
    require(environment['OPENSSL_DIR'] == str(PREFIX)
            and environment['TRNM_PQ_OPENSSL'] == str(PREFIX / 'bin/openssl')
            and environment['TRNM_PQ_OPENSSL_SHA256'] == ARTIFACTS['bin/openssl']
            and environment['OPENSSL_STATIC'] == '1'
            and environment['TRNM_PQ_OPENSSL_VERSION'] == '3.5.9'
            and environment['OPENSSL_CONF'] == '/dev/null', 'provider identity differs')
    for relative, expected in ARTIFACTS.items():
        artifact = PREFIX / relative
        require(artifact.is_file() and not artifact.is_symlink(), 'nonregular provider artifact')
        require(sha(artifact) == expected, 'provider artifact digest differs: ' + relative)
    inherited = os.environ.copy()
    disallowed = [key for key, value in inherited.items() if value and (
        key.startswith('CARGO_PROFILE_')
        or key.endswith(('_RUSTFLAGS', '_RUSTC', '_RUSTC_WRAPPER', '_RUSTC_WORKSPACE_WRAPPER'))
        or key in ('RUSTFLAGS', 'RUSTC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'))]
    require(not disallowed, 'inherited compiler/profile overrides: ' + ', '.join(disallowed))
    openssl_overrides = ('OPENSSL_DIR', 'OPENSSL_LIB_DIR', 'OPENSSL_INCLUDE_DIR',
                         'OPENSSL_STATIC', 'OPENSSL_LIBS', 'OPENSSL_NO_VENDOR')
    removed = []
    for key in list(inherited):
        if key in openssl_overrides or any(key.endswith('_' + name) for name in openssl_overrides):
            removed.append(key)
            del inherited[key]
    inherited.update(environment)
    inherited.update(PATH='/home/qian-qi/.cargo/bin:' + inherited.get('PATH', ''),
                     CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', RUST_TEST_THREADS='1',
                     PYTHONDONTWRITEBYTECODE='1', CARGO_TARGET_DIR=str(target))
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    status = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT, text=True)
    require(head == args.source and not status, 'source is not the frozen clean commit')
    subprocess.run(['bash', 'scripts/project-preflight.sh'], cwd=ROOT, env=inherited, check=True)
    launch_dir = output.with_name(output.name + '-launch')
    launch_dir.mkdir(exist_ok=False)
    record = {'source': args.source, 'mode': args.mode, 'status': 'running',
              'provider_environment_sha256': ENV_SHA, 'provider_receipt_sha256': RECEIPT_SHA,
              'provider_environment': environment, 'provider_artifact_sha256': ARTIFACTS,
              'cleared_ambient_openssl_override_keys': sorted(removed),
              'default_workspace_profiles': True, 'original_business_budgets_changed': False,
              'whole_chain_quantum_security_qualified': False,
              'target': str(target), 'output': str(output), 'launcher_sha256': sha(__file__)}
    if args.mode == 'native':
        command = ['python3', '-B', str(args.runner.resolve()), '--root', str(ROOT),
                   '--source', args.source, '--out', str(output), '--target', str(target),
                   '--build-barrier', str(args.build_barrier.resolve())]
        record.update(runner_sha256=args.runner_sha, build_barrier=str(args.build_barrier.resolve()))
    else:
        output.mkdir()
        command = ['python3', '-B', 'scripts/ci/record_pq_native_command.py', '--kind', 'head',
                   '--candidate', args.source, '--tested', args.source, '--label', 'strict-clippy',
                   '--output', str(output), '--', 'timeout', '--signal=TERM', '--kill-after=10',
                   '1800', 'cargo', '+1.95.0', 'clippy', '--locked', '--manifest-path',
                   'trillionnium/Cargo.toml', '--workspace', '--all-targets', '--all-features',
                   '--', '-D', 'warnings']
    record['command'] = command
    dump(launch_dir / 'launch.json', record)
    started = time.monotonic_ns()
    result = subprocess.run(command, cwd=ROOT, env=inherited, check=False)
    record.update(status='command_succeeded' if result.returncode == 0 else 'command_failed',
                  exit_code=result.returncode, elapsed_ns=time.monotonic_ns() - started)
    dump(launch_dir / 'launch.json', record)
    print(json.dumps({'mode': args.mode, 'exit_code': result.returncode,
                      'launch_record': str(launch_dir / 'launch.json')}), flush=True)
    return result.returncode if result.returncode >= 0 else 128 - result.returncode


if __name__ == '__main__':
    raise SystemExit(main())
