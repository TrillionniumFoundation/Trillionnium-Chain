"""Fork V6 after complete adapter audit; preserve frozen V5 and actual failed run."""
from __future__ import annotations
import hashlib,json,pathlib,shutil,subprocess,sys
BASE=pathlib.Path(__file__).resolve().parent
V5=BASE/"candidate-v5-snapshot";V6=BASE/"candidate-v6-snapshot"
def need(condition,message):
    if not condition:raise ValueError(message)
def identity(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def main():
    need(not V6.exists(),"V6 already exists")
    sys.path.insert(0,str(V5))
    from hia.platform.continuity_store.rust_oracle import complete_source_manifest,canonical_json_hash
    from hia.platform.typed_store.build import original_manifest
    prior=complete_source_manifest(V5);original=original_manifest(V5)
    need(canonical_json_hash(prior)=="12dd16f62547fae1235416fc4421739f6f1a5905d75ff08bc3316e835aebd625",
         "V5 source changed")
    shutil.copytree(V5,V6,symlinks=True)
    preflight=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=V6,capture_output=True,timeout=30)
    (BASE/"v6-preflight.stdout").write_bytes(preflight.stdout)
    (BASE/"v6-preflight.stderr").write_bytes(preflight.stderr)
    need(preflight.returncode==0,"V6 project preflight failed")
    path=V6/"hia/platform/continuity_store/rust_reference.rs"
    before=path.read_bytes()
    need(identity(before)=={"bytes":11658,"sha256":"5ce4ffff7a6720819edbbfed51e9c7732a0b6c58ebcccac4e42bcda69833ec50"},
         "V5 actual compiled hook changed")
    old=b"""        let node = if variant < 2 {
            Node::open(directories[variant].path(), settings, 1).unwrap()
        } else {
            Node::open_with_permanent_account_growth_v2(directories[variant].path(), settings).unwrap()
        };
        assert_eq!(node.state_backend == StateBackend::PermanentAccountGrowthV2, variant >= 2);
"""
    new=b"""        // These installed complete-State reference profiles share the Legacy owner.
        // PermanentAccountGrowthV2 requires a distinct Settings transformation.
        assert!(!settings.is_permanent_account_growth_v2());
        assert_eq!(growth_profile_v2::enabled(&cfg), variant >= 2);
        let node = Node::open(directories[variant].path(), settings, 1).unwrap();
        assert!(node.state_backend == StateBackend::Legacy);
"""
    need(before.count(old)==1,"V6 constructor correction is not unique")
    path.write_bytes(before.replace(old,new))
    path=V6/"hia/platform/continuity_store/README.md";before_doc=path.read_bytes()
    need(identity(before_doc)=={"bytes":13889,"sha256":"4be121b2ca8500836a686bd1dc1756b7b33032481f1d0f48d0d247f124fbaa56"},
         "V5 README changed")
    old_doc=b"""network and parameters with @@Config::installed_with_profiles@@, and uses the
real growth-specific Node opener for variants 2 and 3.
""".replace(b"@@",bytes([96]))
    new_doc=b"""network and parameters with @@Config::installed_with_profiles@@. All four use the
original @@Node::open(..., 1)@@ and @@StateBackend::Legacy@@. The growth-reference task
in variants 2 and 3 selects its complete-State capacity and commitment rules.
@@PermanentAccountGrowthV2@@ requires a separate Settings transformation and is
outside these four installed constructors.
""".replace(b"@@",bytes([96]))
    need(before_doc.count(old_doc)==1,"V6 documentation correction is not unique")
    path.write_bytes(before_doc.replace(old_doc,new_doc))
    current=complete_source_manifest(V6)
    changed=sorted(k for k in set(prior)|set(current) if prior.get(k)!=current.get(k))
    need(changed==["hia/platform/continuity_store/README.md","hia/platform/continuity_store/rust_reference.rs"],
         "V6 changed another source")
    need(complete_source_manifest(V5)==prior and original_manifest(V6)==original,
         "Frozen or original source changed")
    report={"schema":"trnm.continuity-v5-to-v6-source-transition.v1",
        "status":"SOURCE_WRITTEN_NOT_YET_BUILT","v5":str(V5),"v6":str(V6),
        "v5_source_set_sha256":canonical_json_hash(prior),"v6_source_set_sha256":canonical_json_hash(current),
        "source_inputs":current,"original_sources_sha256":canonical_json_hash(original),
        "original_source_files":len(original),"changed_paths":changed,
        "constructor_change":{"old_hook_block":old.decode(),"new_hook_block":new.decode(),
            "documentation_old":old_doc.decode(),"documentation_new":new_doc.decode()},
        "basis":{"static_audit":str(BASE/"four-constructor-adapter-audit-v1.json"),
            "actual_v5_pty":"dpty-f5361e2fab119d121df8a7ed4c7fafa13bf98ccce34161b95afec9787e43c723",
            "actual_v5_exit":1,"actual_v5_output_complete":True,"actual_v5_retained_tests_passed":4,
            "actual_v5_semantic_rows_executed":0,"actual_v5_error":"GROWTH_PROFILE at hook 240:96",
            "actual_v5_binary_bytes":610955888,
            "actual_v5_binary_sha256":"7c884eb67afbcc79e2a3e2163e3a581d093fccd936b1fab71abc8d92e9d37d4c"},
        "native_runtime_source_changed":False,"rust_production_source_changed":False,
        "corpus_source_changed":False,"retained_tests_removed":False,
        "previous_versions_and_failed_evidence_preserved":True,
        "v6_full_native_capacity_original":"NOT_RUN; required on exact final integrated source"}
    target=BASE/"continuity-v5-to-v6-transition.json"
    target.write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
    print(json.dumps({"status":report["status"],"v6":str(V6),"changed_paths":changed,
        "source_set_sha256":report["v6_source_set_sha256"],
        "changed_files":{k:current[k] for k in changed},"transition":identity(target.read_bytes())}))
if __name__=="__main__":main()
