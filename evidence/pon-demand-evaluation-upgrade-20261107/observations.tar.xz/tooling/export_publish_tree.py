#!/usr/bin/env python3
"""Export committed text changes for GitHub Git Data; never export working bytes."""
import json
from pathlib import Path
import re
import subprocess
import sys

sha = sys.argv[1]
if re.fullmatch('[0-9a-f]{40}', sha) is None:
    raise SystemExit('exact commit required')
root = Path('/workspace/scratch/525798dad3c2/Trillionnium-Chain')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)


parent = git('rev-parse', sha + '^').decode().strip()
base_tree = git('rev-parse', parent + '^{tree}').decode().strip()
entries = []
for raw in git('diff', '--name-only', '-z', parent, sha).split(b'\0'):
    if not raw:
        continue
    path = raw.decode()
    item = git('ls-tree', sha, '--', path).decode().split()
    if not item:
        raise RuntimeError('deletion requires explicit handling: ' + path)
    mode, kind, blob = item[:3]
    if kind != 'blob':
        raise RuntimeError('unsupported type')
    content = git('show', sha + ':' + path).decode('utf8')
    entries.append(dict(path=path, mode=mode, type='blob', content=content))
out = root.parent / 'publish' / ('tree-' + sha + '.json')
out.parent.mkdir(exist_ok=True)
text = json.dumps(dict(base_tree_sha=base_tree, tree_elements=entries))
out.write_text(text)
print(json.dumps(dict(path=str(out), chars=len(text), files=len(entries),
    expected_tree=git('rev-parse', sha + '^{tree}').decode().strip())))
