from __future__ import annotations

import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

WORKSPACE = Path('/workspace/scratch/ac851b3fedf0')
REPO = WORKSPACE / 'chain-integrated'
RUNTIME = WORKSPACE / 'chain-validation-runtime-91dd3082'
HEAD = '91dd3082633ea0b3a5ec9b0ed91f28603229be01'
TREE = '8a14e5aa053af94d1f19cfb8b907a09c6ac4399b'
BASE = 'e798d7125724d4b9f98c24d00cc80031f2eab4a9'
HEPTA = 'd81cb97c5b01aea0df03d84d40336b25576337de'
HEPTA_TREE = '49829b9efd25251907743d36fd9c87625ae2bdce'
DEST = WORKSPACE / 'chain-evidence-ready/evidence/pon-hepta-preservation-20261108'


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def main() -> None:
    summary = json.loads((RUNTIME / 'summary.json').read_text())
    if not summary['complete'] or len(summary['results']) != 22:
        raise SystemExit('The original 22-command campaign is not complete.')
    if summary['tested_commit'] != HEAD:
        raise SystemExit('Wrong runtime source.')
    commands = json.loads((RUNTIME / 'commands.json').read_text())
    expected_labels = [
        'preflight', 'graph-default', 'graph-all-features', 'service-settlement',
        'crypto-library', 'grouped-session', 'grouped-cli-build',
        'grouped-cross-language', 'legal-optimizations', 'factor-reference',
        'service-no-update-reference', 'node-payment-integration',
        'strict-workspace-clippy', 'workspace-format', 'source-integrity-controls',
        'ci-contract-controls', 'corpus-controls', 'ci-contract',
        'source-inventory', 'corpus-identity', 'repository-links',
        'repository-controls',
    ]
    if [item[0] for item in commands] != expected_labels or [item['label'] for item in summary['results']] != expected_labels:
        raise SystemExit('The original ordered command roster differs.')
    current = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    if current != HEAD:
        raise SystemExit('Runtime checkout was moved before evidence packaging.')
    if subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=REPO):
        raise SystemExit('Tracked runtime source changed before evidence packaging.')
    DEST.mkdir(parents=True, exist_ok=False)
    members: dict[str, bytes] = {}
    receipts = []
    counts = {}
    for result, command in zip(summary['results'], commands, strict=True):
        label = result['label']
        receipt = json.loads((RUNTIME / (label + '.json')).read_text())
        if receipt['argv'] != command[1]:
            raise SystemExit('Command argv differs: ' + label)
        if any(result[field] != receipt[field] for field in ('status', 'exit_code', 'elapsed_ns')):
            raise SystemExit('Summary differs from its original receipt: ' + label)
        expected_recorder_code = receipt['exit_code'] if receipt['exit_code'] >= 0 else 128 - receipt['exit_code']
        if result['recorder_exit_code'] != expected_recorder_code:
            raise SystemExit('Recorder code differs: ' + label)
        if receipt['before'] != receipt['after']:
            raise SystemExit('Source moved: ' + label)
        if receipt['before']['tested_commit'] != HEAD or receipt['before']['tested_tree'] != TREE:
            raise SystemExit('Source mismatch: ' + label)
        if not receipt['before']['tracked_worktree_verified']:
            raise SystemExit('Missing complete raw-source verification: ' + label)
        raw = (RUNTIME / receipt['log_file']).read_bytes()
        if digest(raw) != receipt['log_sha256'] or len(raw) != receipt['log_bytes']:
            raise SystemExit('Raw output differs from original receipt: ' + label)
        receipts.append(receipt)
        counts[label] = re.findall(r'^(?:test result:.*|Ran \d+ tests? in .*|OK(?: \(.*\))?|FAILED(?: \(.*\))?)$', raw.decode(errors='replace'), re.MULTILINE)
    for path in sorted(RUNTIME.iterdir()):
        if path.is_file():
            members['runtime/' + path.name] = path.read_bytes()
    for directory, prefix in [
        ('factor-validation', 'preliminary/factors'),
        ('settlement-validation', 'preliminary/settlement'),
        ('provider/ci-observations/pq-provider', 'provider'),
        ('ci-observed-91dd3082', 'hosted-ci'),
        ('evidence-review', 'review'),
        ('chain-validation-repository-tmpdir-91dd3082', 'followup-repository-controls'),
    ]:
        for path in sorted((WORKSPACE / directory).rglob('*')):
            if path.is_file():
                members[prefix + '/' + path.relative_to(WORKSPACE / directory).as_posix()] = path.read_bytes()
    for name in [
        'run_chain_validation.py', 'prepare_chain_evidence.py',
        'chain-validation-supervisor.log', 'corpus-pin-refresh.json',
        'baseline-source-integrity.log', 'baseline-source-integrity-correct.log',
        'baseline-corpus.log', 'composition-ci-contract.log',
        'composition-corpus-controls.log',
        'build-cache-cleanup.json', 'chain-retained-binaries.json',
        'run_chain_repository_followup.py', 'chain-repository-followup-supervisor.log',
    ]:
        path = WORKSPACE / name
        if path.exists():
            members['supervision/' + name] = path.read_bytes()
    members['provider/provider.env'] = (WORKSPACE / 'provider/provider.env').read_bytes()
    index = []
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, raw in sorted(members.items()):
            if name.startswith('/') or '..' in Path(name).parts:
                raise SystemExit('Unsafe archive name.')
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            info.mtime = 0
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            archive.addfile(info, io.BytesIO(raw))
            index.append({'path': name, 'bytes': len(raw), 'sha256': digest(raw)})
    compressed = gzip.compress(buffer.getvalue(), compresslevel=9, mtime=0)
    (DEST / 'observations.tar.gz').write_bytes(compressed)
    with tarfile.open(fileobj=io.BytesIO(compressed), mode='r:gz') as archive:
        observed = {item.name: archive.extractfile(item).read() for item in archive.getmembers()}
    if observed != members:
        raise SystemExit('Archive round-trip changed original bytes.')
    write_json(DEST / 'archive-index.json', {
        'schema': 'trnm-hepta-preservation-archive-index-v1',
        'archive': {'path': 'observations.tar.gz', 'bytes': len(compressed), 'sha256': digest(compressed)},
        'files': index,
    })
    for name in ['summary.json', 'commands.json', 'toolchain.json']:
        shutil.copyfile(RUNTIME / name, DEST / name)
    write_json(DEST / 'native-receipts.json', receipts)
    write_json(DEST / 'test-summary-lines.json', counts)
    followup_dir = WORKSPACE / 'chain-validation-repository-tmpdir-91dd3082'
    followup = json.loads((followup_dir / 'repository-controls.json').read_text())
    followup_env = json.loads((followup_dir / 'environment.json').read_text())
    original = next(item for item in receipts if item['argv'] == ['python3', '-u', '-B', 'scripts/ci/test_repository.py'])
    followup_raw = (followup_dir / followup['log_file']).read_bytes()
    if followup['before'] != followup['after'] or followup['before'] != original['before'] or followup['argv'] != original['argv']:
        raise SystemExit('Repository follow-up changed source or command.')
    if digest(followup_raw) != followup['log_sha256'] or len(followup_raw) != followup['log_bytes']:
        raise SystemExit('Repository follow-up log integrity mismatch.')
    if followup_env['followup_status'] != followup['status'] or followup_env['followup_exit_code'] != followup['exit_code']:
        raise SystemExit('Repository follow-up supervisor and receipt disagree.')
    passing = {item['label'] for item in summary['results'] if item['status'] == 'command_succeeded' and item['exit_code'] == 0 and item['recorder_exit_code'] == 0}
    if followup['status'] == 'command_succeeded' and followup['exit_code'] == 0 and followup_env['recorder_exit_code'] == 0:
        passing.add('repository-controls')
    write_json(DEST / 'validation-resolution.json', {
        'original_campaign_summary_preserved': True,
        'original_campaign_all_commands_succeeded': summary['all_commands_succeeded'],
        'original_failed_commands': [item['label'] for item in summary['results'] if item['status'] != 'command_succeeded'],
        'followup_command': 'repository-controls', 'followup_receipt': followup,
        'followup_environment': followup_env,
        'followup_terminal_lines': re.findall(r'^(?:Ran \d+ tests? in .*|OK(?: \(.*\))?|FAILED(?: \(.*\))?)$', followup_raw.decode(errors='replace'), re.MULTILINE),
        'all_local_command_scopes_have_passing_observations': passing == set(expected_labels),
        'all_hosted_ci_passed': False, 'production_activation': False,
    })
    write_json(DEST / 'sources.json', {
        'schema': 'trnm-hepta-preservation-sources-v1',
        'native_tested_commit': HEAD, 'native_tested_tree': TREE, 'base_commit': BASE,
        'native_source_entries': receipts[0]['before']['tracked_entries'],
        'native_source_bytes': receipts[0]['before']['tracked_bytes'],
        'publication_kind': 'evidence-and-unpinned-documentation-only-descendant',
        'native_tests_rerun_on_evidence_descendant': False,
        'paired_hepta_source': HEPTA,
        'paired_hepta_tree': HEPTA_TREE,
        'hepta_execution_qualified_by_this_packet': False,
        'joint_cross_repository_execution': False,
        'all_hosted_ci_passed': False, 'production_activation': False,
        'whole_chain_quantum_security_qualified': False, 'qualification': 'HOLD_NO_GO',
    })
    print(json.dumps({'destination': str(DEST), 'raw_files': len(index), 'raw_bytes': sum(x['bytes'] for x in index), 'archive_bytes': len(compressed), 'runtime_success': summary['all_commands_succeeded'], 'test_summary_lines': counts}, indent=2))


if __name__ == '__main__':
    main()
