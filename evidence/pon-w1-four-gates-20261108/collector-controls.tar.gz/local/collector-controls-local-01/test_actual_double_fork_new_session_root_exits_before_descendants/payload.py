import os,time
from pathlib import Path
if os.fork(): os._exit(0)
os.setsid()
if os.fork(): os._exit(0)
os.setsid()
time.sleep(.20)
Path('/workspace/scratch/ec265b67753e/collector-controls-local-01/test_actual_double_fork_new_session_root_exits_before_descendants/grandchild-finished').write_text('actual grandchild finished')
os._exit(0)
