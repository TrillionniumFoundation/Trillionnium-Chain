import json, os
from pathlib import Path
report = json.loads((Path(os.environ['PQ_OUT']) / 'recursion-only.log').read_text())
expected = {
    'schema': 'TRNM-W1-RECURSION-ONLY-VERIFY2',
    'sdk': '3.0.6',
    'hash_function': 'poseidon2',
    'verifier_parameters_digest': 'ece5e9b8ae2cd6ea6b1827b464ff0348f9a7f4decd269c0087fdfd75098da013',
    'receipt_sha256': 'd2b06a1feca2d15e8dc5741b43f481a82c32d7d3dab01e413d357012467093d3',
    'receipt_bytes': 223154,
    'control_id': 'e7934a23ddce1423b425cf32aa23be29f48cd40e0b6ff9376dce6f3bf9d0bc35',
}
assert {key: report[key] for key in expected} == expected
assert report['result']['outcome'] == 'ACCEPT'
assert report['complete_w1_claim'] is False and report['consensus_admission'] is False
print('Pinned real lift verified; complete W1 claim and consensus admission remain false')
