#!/usr/bin/env python3
"""Run only explicitly selected, nonempty tests from recorded frozen artifacts."""
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import time

spec = importlib.util.spec_from_file_location(
    'frozen_build', Path(__file__).with_name('d873-native-validation.py'))
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)

FIXED_TIP = ('ingress::history_import::tests::'
             'history_page_cannot_decode_past_fixed_tip_before_native_admission')
RELEASE = [
    ('public_submit_recovery', '', 26, False),
    ('pinned_peer_polling', '', 1, False),
    ('public_v3_multiprocess',
     'arithmetic_campaign_profile_binding_preserves_raw_and_rejects_partial_actor_jobs', 1, False),
    ('public_v3_service_campaign',
     'network_only_business::network_only_business_confirmations_survive_rotating_false_work', 1, True),
]
LIBRARY = [
    ('trnm_pon_node', FIXED_TIP, 1, True),
    ('trnm_pon_node', 'public_history_page_', 3, False),
    ('trnm_pon_node', 'public_history_batch_', 6, False),
    ('trnm_pon_node', 'public_history_formatting_', 3, False),
    ('trnm_pon_node', 'store::public_reader::tests::', 10, False),
    ('trnm_pon_node', 'peer_polling::tests::', 17, False),
    ('trnm_pon_node', 'work_arithmetic::tests::', 5, False),
    ('trnm_pon_node', 'paid_envelope_resource_profile_has_fresh_exact_signed_commitment', 1, False),
    ('trnm_pon_node',
     'resource_revision_r16_rejects_signed_old_cookies_and_preserves_control_output_reserve', 1, False),
    ('trnm_pon_node', 'scalar_cpu::metered_fact_network_tests::', 1, False),
    ('trnm_pon_node', 'ingress::history_import::tests::', 30, False),
    ('trnm_pon_node', 'store::read_query_cache_tests::', 1, False),
]


def run(phase):
    debug0 = phase == 'debug0-components'
    assert debug0 or phase == 'release-regressions'
    build_phase = 'debug0-library-build' if debug0 else 'release-six-build'
    build_path = base.LOGS / f'd873-{build_phase}.result.json'
    build = json.loads(build_path.read_text())
    assert build['complete_success'], 'require successful exact recorded build'
    before = base.source_identity()
    assert before == build['source_after']
    assert before['commit'] == base.HEAD and before['status_porcelain'] == ''
    env, recorded_env = base.environment(debug0)
    artifacts = {row['target']['name']: row for row in build['artifacts']
                 if row['profile']['test'] and row['target']['kind'] == (['lib'] if debug0 else ['test'])}
    artifact_hashes = {row['path']: base.sha256(row['path']) for row in build['artifacts']}
    assert all(artifact_hashes[row['path']] == row['sha256'] for row in build['artifacts'])
    result_path = base.LOGS / f'd873-{phase}.result.json'
    assert not result_path.exists(), 'preserve every prior attempt'
    report = {'schema': 'local-frozen-native-tests-v1', 'phase': phase,
              'build_manifest': str(build_path), 'source_before': before,
              'environment_overrides': recorded_env, 'artifact_sha256_before': artifact_hashes,
              'fixed_host_qualified': False, 'profile_scope': build['profile_scope'],
              'intentional_duplicate': FIXED_TIP if debug0 else None, 'groups': []}
    lists = {}
    selected_unique = set()
    for index, (target, query, expected, exact) in enumerate(LIBRARY if debug0 else RELEASE, 1):
        artifact = artifacts[target]
        binary = artifact['path']
        if target not in lists:
            listing = subprocess.run([binary, '--list'], cwd=base.REPO, env=env,
                                     capture_output=True, text=True)
            list_path = base.LOGS / f'd873-{phase}-{target}.list.log'
            list_path.write_text(listing.stdout + listing.stderr)
            assert listing.returncode == 0
            lists[target] = [line[:-6] for line in listing.stdout.splitlines() if line.endswith(': test')]
        selected = [name for name in lists[target] if (name == query if exact else query in name)]
        assert selected and len(selected) == expected, (target, query, expected, selected)
        selected_unique.update(target + '::' + name for name in selected)
        command = [binary]
        if query:
            command.append(query)
        if exact:
            command.append('--exact')
        command += ['--test-threads=1', '--nocapture']
        log_path = base.LOGS / f'd873-{phase}-{index:02d}.log'
        row = {'index': index, 'target': target, 'filter': query, 'exact': exact,
               'selected_count': len(selected), 'selected_tests': selected, 'command': command,
               'binary_sha256': artifact['sha256'], 'binary_profile': artifact['profile'],
               'log': str(log_path)}
        group_env = env.copy()
        if target == 'public_v3_service_campaign':
            receipts = base.LOGS / f'd873-{phase}-{index:02d}-receipts'
            receipts.mkdir(exist_ok=False)
            group_env['TRNM_CI_RECEIPT_DIR'] = str(receipts)
            row['receipt_output_directory'] = str(receipts)
            row['receipt_environment'] = {'TRNM_CI_RECEIPT_DIR': str(receipts)}
        (base.LOGS / f'd873-{phase}-{index:02d}.command.json').write_text(json.dumps(row, indent=2)+'\n')
        print(json.dumps({'started_group': index, 'target': target, 'filter': query,
                          'selected_count': len(selected), 'log': str(log_path)}), flush=True)
        start = time.monotonic()
        with log_path.open('w') as log:
            result = subprocess.run(command, cwd=base.REPO, env=group_env, stdout=log, stderr=subprocess.STDOUT)
        raw = log_path.read_text()
        summaries = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', raw)
        row.update(returncode=result.returncode, elapsed_seconds=round(time.monotonic()-start, 3),
                   log_sha256=base.sha256(log_path))
        if summaries:
            last = summaries[-1]
            row.update(harness_result=last[0], passed=int(last[1]), failed=int(last[2]),
                       ignored=int(last[3]), measured=int(last[4]), filtered_out=int(last[5]))
            row['count_matches_selection'] = sum(row[k] for k in ('passed', 'failed', 'ignored', 'measured')) == len(selected)
            row['has_actual_execution'] = row['passed'] + row['failed'] > 0
        else:
            row.update(harness_result='missing-summary', count_matches_selection=False, has_actual_execution=False)
        row['ignored_tests'] = sorted(set(re.findall(r'^test (.+?) \.\.\. ignored(?:,.*)?$', raw, re.M)))
        if row.get('receipt_output_directory'):
            row['json_receipts'] = [
                {'path': str(path), 'bytes': path.stat().st_size, 'sha256': base.sha256(path)}
                for path in Path(row['receipt_output_directory']).rglob('*.json')]
        row['complete_success'] = result.returncode == 0 and row['harness_result'] == 'ok' and row['count_matches_selection'] and row['has_actual_execution']
        report['groups'].append(row)
        result_path.write_text(json.dumps(report, indent=2)+'\n')
        print(json.dumps({k: v for k, v in row.items() if k not in ('selected_tests', 'command')}, indent=2), flush=True)
        if not row['complete_success']:
            print(raw[-7000:], flush=True)
            break
    report['source_after'] = base.source_identity()
    report['artifact_sha256_after'] = {path: base.sha256(path) for path in artifact_hashes}
    report['totals'] = {k: sum(row.get(k, 0) for row in report['groups'])
                        for k in ('selected_count', 'passed', 'failed', 'ignored', 'measured')}
    ignored_unique = {row['target'] + '::' + name for row in report['groups'] for name in row['ignored_tests']}
    report['unique_selected_count'] = len(selected_unique)
    report['unique_ignored_count'] = len(ignored_unique)
    report['unique_passed_count'] = len(selected_unique - ignored_unique) if all(row['complete_success'] for row in report['groups']) else None
    report['actual_execution_seconds'] = round(sum(row['elapsed_seconds'] for row in report['groups']), 3)
    report['complete_success'] = (len(report['groups']) == len(LIBRARY if debug0 else RELEASE)
        and all(row['complete_success'] for row in report['groups'])
        and report['source_after'] == before and report['artifact_sha256_after'] == artifact_hashes)
    result_path.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k: v for k, v in report.items() if k not in
                     ('source_before', 'source_after', 'artifact_sha256_before', 'artifact_sha256_after', 'groups')}, indent=2), flush=True)
    return 0 if report['complete_success'] else 1


if __name__ == '__main__':
    sys.exit(run(sys.argv[1]))
