#!/usr/bin/env python3
"""Replay the same real filesystem race controls against frozen old/new readers."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

base = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--phase', choices=('pre_fix', 'post_fix', 'both'), default='both')
args = parser.parse_args()
manifest = json.loads((base / 'source-hashes.json').read_text())
phases = ('pre_fix', 'post_fix') if args.phase == 'both' else (args.phase,)
results = []
for phase in phases:
    folder = base / phase
    for name, identity in manifest['snapshots'][phase].items():
        actual = hashlib.sha256((folder / name).read_bytes()).hexdigest()
        if actual != identity['sha256']:
            raise SystemExit('refuse changed replay source: ' + phase + '/' + name)
    command = [sys.executable, '-m', 'unittest', '-v',
               'test_pq_chain_claim_guard.ClaimReaderRaceTests',
               'test_pq_research_integration.CorpusReaderRaceTests']
    result = subprocess.run(command, cwd=folder, capture_output=True, timeout=30)
    (base / (phase + '.stdout')).write_bytes(result.stdout)
    (base / (phase + '.stderr')).write_bytes(result.stderr)
    output = result.stderr.decode('utf-8', errors='replace')
    count = re.search(r'Ran (\d+) tests in ([0-9.]+)s', output)
    failures = re.search(r'failures=(\d+)', output)
    errors = re.search(r'errors=(\d+)', output)
    results.append({'phase': phase, 'command': command, 'cwd': str(folder),
                    'returncode': result.returncode,
                    'tests': int(count[1]) if count else None,
                    'seconds': float(count[2]) if count else None,
                    'failures': int(failures[1]) if failures else 0,
                    'errors': int(errors[1]) if errors else 0,
                    'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                    'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
summary = {'base_commit': manifest['base_commit'], 'results': results,
           'qualification': 'Filesystem reader regression only; all system qualification remains HOLD.'}
(base / 'replay-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
if any(value['tests'] is None for value in results):
    raise SystemExit('replay did not finish the selected controls')
if any(value['returncode'] != 0 for value in results if value['phase'] == 'post_fix'):
    raise SystemExit('post-fix controls failed')
