#!/usr/bin/env python3
"""Derive an explicit qualification from unchanged completed F source receipts."""
from __future__ import annotations
import ast, hashlib, json, pathlib, re, stat, subprocess, traceback

REPO = pathlib.Path("/home/qq/chain-system-security-20261112-306929")
SOURCE = "2d72fa3293989b01596ec8ce0ba3ff370dc4c584"
TREE = "ebc11e05eb0015ae5be58ca85ed764e06f4386be"
NATIVE = "bac6b7659bd7e2d633e25c2da0add60f6a10c7fb"
ORIGINAL = pathlib.Path("/home/qq/chain-system-security-native-receipts-20261112-306929/final-source-F-2d72fa329398")
OUTPUT = pathlib.Path("/home/qq/chain-system-security-native-receipts-20261112-306929/final-source-F-derived-2d72fa329398")
TERMINALS = pathlib.Path("/home/qq/chain-system-security-native-receipts-20261112-306929/final-source-terminal-observations-20261112-306929.json")
EXPECTED_SUMMARY = "e7461e37ddf48711faf23a3090e16558abe4e9ad9a076eddaaaa6060fe5610b7"
EXPECTED_TERMINALS = "9c83223a51930d26b0dedd52e5375478ee8d1afe6b0b3191ff4ff58c2061e7d9"
CARGO = "/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/cargo"
CAP = 4194304

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode) and info.st_size <= CAP, "not bounded regular file: " + str(path))
    raw = path.read_bytes()
    require(len(raw) == info.st_size, "file changed while reading: " + str(path))
    return raw

def git(*argv):
    return subprocess.check_output(["git", "-C", str(REPO), *argv])

def inventory():
    result = []
    for path in sorted(ORIGINAL.rglob("*")):
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        raw = read(path)
        result.append({"relative": path.relative_to(ORIGINAL).as_posix(), "bytes": len(raw), "sha256": sha(raw)})
    return result

def source_inventory(module, alias=None):
    relative = "scripts/ci/" + module + ".py"
    raw = git("show", SOURCE + ":" + relative)
    module_ast = ast.parse(raw, filename=relative)
    expected, fixture_methods = [], []
    for cls in module_ast.body:
        if not isinstance(cls, ast.ClassDef):
            continue
        for node in cls.body:
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) or not node.name.startswith("test_"):
                continue
            identity = (alias or module) + "." + cls.name + "." + node.name
            expected.append(identity)
            if any(isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
                   and call.func.attr == "_finish_report" for call in ast.walk(node)):
                fixture_methods.append(identity)
    require(expected and len(expected) == len(set(expected)), "invalid source AST test inventory")
    return expected, {"path": relative, "git_blob": git("rev-parse", SOURCE + ":" + relative).decode().strip(),
                      "bytes": len(raw), "sha256": sha(raw), "methods": sorted(expected),
                      "fixture_finish_report_methods": sorted(fixture_methods)}

def suite(log_raw, modules, expected_count, allow_fixture_tail):
    text = log_raw.decode("utf-8").replace("\r\n", "\n")
    row_pattern = re.compile(r"(?m)^(test_[A-Za-z0-9_]+) \(([^)\n]+)\) \.\.\. ([^\n]+)$")
    rows = list(row_pattern.finditer(text))
    sources, expected = [], []
    for module, alias in modules:
        names, binding = source_inventory(module, alias)
        expected.extend(names); sources.append(binding)
    require(len(expected) == expected_count and len(expected) == len(set(expected)), "wrong AST expected count")
    observed = [row.group(2) for row in rows]
    require(len(rows) == expected_count and len(observed) == len(set(observed))
            and sorted(observed) == sorted(expected), "observed exact method inventory mismatch")
    require(all(row.group(1) == row.group(2).split(".")[-1] and row.group(3) == "ok" for row in rows),
            "a method did not report plain ok")
    summaries = list(re.finditer(r"(?m)^Ran ([0-9]+) tests? in [0-9.]+s\n\n(OK(?: \([^\n]*\))?|FAILED[^\n]*)\n?", text))
    require(len(summaries) == 1 and int(summaries[0].group(1)) == expected_count
            and summaries[0].group(2) == "OK", "not one plain unittest OK summary")
    match = summaries[0]
    require(all(row.end() < match.start() for row in rows), "test method after unittest summary")
    preamble = text[:match.start()]
    for line in preamble.splitlines():
        require(not line or set(line) == {"-"} or row_pattern.fullmatch(line) is not None,
                "unrecognized text before unittest summary")
    tail = [line for line in text[match.end():].splitlines() if line]
    fixtures = []
    if allow_fixture_tail:
        require(len(tail) == 6, "not the identified six buffered fixture receipt lines")
        for line in tail:
            fixture = json.loads(line)
            require(isinstance(fixture, dict) and set(fixture) == {"receipt", "result"}, "unexpected fixture output fields")
            require(isinstance(fixture["receipt"], str) and re.fullmatch(
                    r"/tmp/trnm-ci-raw-source-[A-Za-z0-9_-]+/\.git/receipt(?:-PASS|-FAIL)?",
                    fixture["receipt"]), "unexpected fixture receipt path")
            fixtures.append(fixture)
        require([item["result"] for item in fixtures] == ["FAIL", "FAIL", "FAIL", "FAIL", "PASS", "FAIL"],
                "unexpected fixture success/failure sequence")
        require(all(item["receipt"].endswith("/.git/receipt") for item in fixtures[:4])
                and len({item["receipt"] for item in fixtures[:4]}) == 4, "unexpected first four fixture paths")
        require(fixtures[-2]["receipt"].endswith("/.git/receipt-PASS")
                and fixtures[-1]["receipt"] == fixtures[-2]["receipt"][:-4] + "FAIL",
                "final PASS/FAIL fixture pair is not the same source fixture")
        require(len(sources) == 1 and len(sources[0]["fixture_finish_report_methods"]) == 5,
                "identified fixture emitters differ from fixed source")
    else:
        require(not tail, "unexpected trailing text in authority/Root suite")
    return {"expected_method_count": expected_count, "observed_method_count": len(rows),
            "exact_source_ast_inventory_equal": True, "source_files": sources,
            "observed_method_ids": observed, "single_unittest_summary": match.group(0),
            "plain_ok_without_skips_failures_or_errors": True,
            "buffered_fixture_output_allowed": allow_fixture_tail, "buffered_fixture_receipts": fixtures,
            "fixture_results_are_not_test_failures": bool(fixtures),
            "log_sha256": sha(log_raw), "log_bytes": len(log_raw)}

def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2); stream.write("\n")

def main():
    OUTPUT.mkdir(exist_ok=False)
    try:
        require(git("rev-parse", "HEAD").decode().strip() == SOURCE and not git("status", "--porcelain=v1"),
                "shared source is not clean F")
        before_files = inventory()
        summary_raw = read(ORIGINAL / "summary.json")
        require(sha(summary_raw) == EXPECTED_SUMMARY, "original summary changed")
        summary = json.loads(summary_raw)
        require(summary["schema"] == "trnm-final-source-gates-v1" and summary["mode"] == "full"
                and summary["source"] == SOURCE and summary["tree"] == TREE, "wrong original summary identity")
        require(summary["all_gates_passed"] is False and summary["python_controls_observed"] == 65
                and summary["controls"]["source-rejection-controls"]["plain_ok_without_skips"] is False,
                "original parser refusal was not preserved")
        require(summary["source_before_after_equal"] is True and summary["protected_native_bytes_equal"] is True
                and summary["native_tests_executed"] is False and summary["clippy_executed"] is False,
                "unexpected original scope")
        terminal_raw = read(TERMINALS)
        require(sha(terminal_raw) == EXPECTED_TERMINALS, "terminal observations changed")
        terminal = json.loads(json.loads(terminal_raw)["observations"]["full_F"])
        require(terminal["status"]["state"] == "exited" and terminal["status"]["exit_code"] == 1
                and terminal["output_complete"] is True and terminal["status"]["output_complete"] is True,
                "original wrapper terminal is not actual exit1")
        pty_output = read(pathlib.Path(terminal["archive_path"]))
        require(len(pty_output) == terminal["available_end"] == terminal["status"]["bytes_seen"]
                == terminal["status"]["bytes_stored"] == 16289, "original PTY archive length mismatch")
        portion = pty_output[terminal["offset"]:terminal["next_offset"]]
        require(portion == bytes.fromhex(terminal["bytes_hex"]) and sha(portion) == terminal["chunk_sha256"],
                "terminal response differs from original PTY archive")
        before = json.loads(read(ORIGINAL / "source-before.json"))
        after = json.loads(read(ORIGINAL / "source-after.json"))
        require(before == after and before["tested_commit"] == SOURCE and before["tested_tree"] == TREE
                and before["tracked_worktree_verified"] is True and before["tracked_entries"] == 28758
                and before["tracked_bytes"] == 2595711115, "original complete source guard mismatch")
        protected = json.loads(read(ORIGINAL / "protected-native-source-comparison.json"))
        require(protected["native_source"] == NATIVE and protected["candidate"] == SOURCE
                and protected["all_bytes_equal"] is True
                and protected["protected_roots"] == ["trillionnium", "formal", "scripts/ci"],
                "protected comparison identity mismatch")
        require(all(row["native_blob"] == row["candidate_blob"] for row in protected["files"]),
                "protected files are not equal")
        expected_commands = [
          ("preflight", ["bash", "scripts/project-preflight.sh"]),
          ("authority-current", ["python3", "scripts/ci/pq_authority_effect_register.py"]),
          ("root-current", ["python3", "scripts/ci/pq_root_dependency_register.py"]),
          ("corpus-current", ["python3", "scripts/ci/check_pq_research_integration.py"]),
          ("authority-and-root-controls", ["python3", "-m", "unittest", "test_pq_authority_effect_register",
             "test_pq_root_dependency_register", "test_run_pq_root_witness_v5", "-v"]),
          ("source-rejection-controls", ["python3", "scripts/ci/test_ci_source_integrity.py"]),
          ("repository-links", ["python3", "scripts/ci/check_repository.py"]),
          ("cargo-format", [CARGO, "fmt", "--manifest-path", "trillionnium/Cargo.toml", "--all", "--", "--check"]),
          ("locked-default-graph", [CARGO, "metadata", "--locked", "--manifest-path", "trillionnium/Cargo.toml", "--format-version", "1"]),
          ("locked-all-features-graph", [CARGO, "metadata", "--locked", "--manifest-path", "trillionnium/Cargo.toml", "--all-features", "--format-version", "1"]),
        ]
        require([row["label"] for row in summary["commands"]] == [label for label, _ in expected_commands],
                "wrong actual command inventory")
        command_bindings, observations = [], {}
        for row, (label, argv) in zip(summary["commands"], expected_commands):
            receipt_path = ORIGINAL / "records" / (label + ".json")
            receipt_raw = read(receipt_path); receipt = json.loads(receipt_raw)
            require(row["recorder_exit_code"] == row["actual_exit_code"] == receipt["exit_code"] == 0
                    and row["actual_status"] == receipt["status"] == "command_succeeded",
                    "actual command did not succeed: " + label)
            require(row["receipt"] == str(receipt_path) and receipt["argv"] == argv and receipt["before"] == receipt["after"] == before,
                    "command/source identity mismatch: " + label)
            require(receipt["log_file"] == label + ".log", "unexpected raw log path")
            log_path = ORIGINAL / "records" / receipt["log_file"]; log_raw = read(log_path)
            require(len(log_raw) == receipt["log_bytes"] and sha(log_raw) == receipt["log_sha256"],
                    "raw command log binding mismatch: " + label)
            command_bindings.append({"label": label, "argv": argv, "exit_code": 0, "recorder_exit_code": 0,
                                     "receipt_relative": receipt_path.relative_to(ORIGINAL).as_posix(),
                                     "receipt_sha256": sha(receipt_raw), "log_relative": log_path.relative_to(ORIGINAL).as_posix(),
                                     "log_bytes": len(log_raw), "log_sha256": sha(log_raw)})
            if label == "authority-and-root-controls":
                observations[label] = suite(log_raw, [(name, None) for name in
                    ("test_pq_authority_effect_register", "test_pq_root_dependency_register", "test_run_pq_root_witness_v5")], 65, False)
            elif label == "source-rejection-controls":
                observations[label] = suite(log_raw, [("test_ci_source_integrity", "__main__")], 43, True)
        require(inventory() == before_files, "original artifacts changed while deriving qualification")
        require(git("rev-parse", "HEAD").decode().strip() == SOURCE and not git("status", "--porcelain=v1"),
                "source identity changed during raw-only reread")
        report = {
          "schema": "trnm-final-source-gates-derived-qualification-v1",
          "derivation_mode": "raw-only-parser-correction",
          "source": SOURCE, "tree": TREE, "native_qualification_source": NATIVE,
          "original_directory": str(ORIGINAL), "original_summary_path": str(ORIGINAL / "summary.json"),
          "original_summary_sha256": sha(summary_raw), "original_summary_bytes": len(summary_raw),
          "original_driver_path": "/home/qq/chain-system-security-final-source-gates-v2-20261112-306929.py",
          "original_driver_sha256": "6c539b2f83037642a86d9ad9e3348397e99a22e66984f9e6eae01d5ca19de074",
          "original_driver_exit_code": 1, "original_all_gates_passed": False,
          "original_python_controls_observed": 65, "original_parser_false_preserved": True,
          "parser_error": "v2 required OK at the end of the combined stream; six expected buffered fixture receipt JSON lines follow the source-integrity unittest OK summary",
          "original_terminal_observations_sha256": sha(terminal_raw),
          "original_pty_output_sha256": sha(pty_output), "original_pty_output_bytes": len(pty_output),
          "all_actual_commands_passed": True, "actual_commands_verified": len(command_bindings),
          "python_controls_verified": sum(item["observed_method_count"] for item in observations.values()),
          "source_before_after_equal": True, "source_identity": before, "protected_native_bytes_equal": True,
          "original_files": before_files, "command_bindings": command_bindings, "suite_observations": observations,
          "original_artifacts_unchanged": True, "new_repository_test_execution": False,
          "native_tests_executed": False, "clippy_executed": False,
          "status": "HOLD", "production_activation": False}
        require(report["python_controls_verified"] == 108, "not exactly108 original observed controls")
        save(OUTPUT / "qualification.json", report)
        print(json.dumps({key: value for key, value in report.items()
                          if key not in ("original_files", "command_bindings", "suite_observations")}), flush=True)
        return 0
    except BaseException as error:
        save(OUTPUT / "failure.json", {"schema": "trnm-final-source-derived-qualification-failure-v1",
             "error": str(error), "type": type(error).__name__, "traceback": traceback.format_exc(),
             "original_source": SOURCE, "original_artifacts_modified": False, "new_tests_executed": False})
        raise

if __name__ == "__main__":
    raise SystemExit(main())
