#!/usr/bin/env python3
"""Run only after root has released the X230 worktree and build target."""
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import tempfile
import time
import traceback

ROOT = Path('/home/qian/trillionnium-review-source/pq-full-20261103-4502')
EVIDENCE = Path('/home/qian/trillionnium-review-source/pq-witness-baseline-evidence-20261103-4502')
FIXED_EVIDENCE = Path('/home/qian/trillionnium-review-source/pq-evidence-20261103-4502/integrated-native-default')
BASE = '1c7e8ab7cd6a321cad4e6c7f7e8a197d7b3be14c'
PUBLISHED = '12fe5f2c1f19704fe7eb635dede6839ed8b1e91e'
PUBLISHED_TREE = 'c44112da731e3f958e55eb024e5762d6723ea2c9'
SOURCE = 'trillionnium/crates/trnm-pon-node/src/store/pq_network.rs'
BASE_SOURCE_SHA256 = '036a2b1d78e60c565f565d404905cc7d3dfb477522ea755ae7be495b86c5f932'
EXPECTED_BLOBS = {
    '.github/workflows/pon-pq-system-continuation.yml': '4f1e551850e4654c0a798735f7529d2de6bcac46',
    'config/pon/pq-cross-branch-corpus-v1.json': '7069569b0d19d9475834730184b9a4e5b3d883f2',
    'config/pon/pq-system-required-tests-v1.json': '4e85293ff42bfb347a7d6e5d2d259d7fd9675ed1',
    'docs/security/WHOLE_CHAIN_PQ_CLAIM_GUARD_20261031.md': '430b71c0a8a6ab037d688d717924b24116bceb06',
    'formal/pon-nakamoto-v1/w1_hardened_verifier/README.md': '340837e6feea08389bf823d160f818d64c50fb4f',
    'formal/pon-nakamoto-v1/w1_hardened_verifier/src/main.rs': 'a1886b5a52a719a945a1fd97089186f6bfed930a',
    SOURCE: 'da6f83549c726a82fd5bda91902093bf5ec8ba38',
    'trillionnium/crates/trnm-pon-node/src/store/pq_rollback_witness/tests.rs': '34d7992cfa54aaaa6bac25708b63cd1e78a1a58d',
}
SELECTORS = [
    'store::pq_rollback_witness::tests::ordinary_admission_reuses_fresh_witness_guard_without_rechecking_unchanged_state',
    'store::pq_rollback_witness::tests::expired_admission_commits_retirement_then_obtains_a_new_witness_guard',
]
ENV = os.environ.copy()
ENV.update({
    'PATH': '/home/qian/.cargo/bin:/usr/local/bin:/usr/bin:/bin',
    'RUSTUP_TOOLCHAIN': '1.95.0',
    'RUSTC': '/home/qian/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin/rustc',
    'CARGO_TARGET_DIR': '/home/qian/trillionnium-review-source/pq-target-20261103-4502',
    'CARGO_BUILD_JOBS': '2',
})
ACTIVE = None
RECORDS = []


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def blob_sha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def file_identity(path):
    before = path.stat()
    hasher = hashlib.sha256()
    with path.open('rb') as handle:
        while block := handle.read(1024 * 1024):
            hasher.update(block)
    after = path.stat()
    if (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
        raise RuntimeError('file changed while hashing: ' + str(path))
    return {'path': str(path), 'bytes': after.st_size, 'sha256': hasher.hexdigest(),
            'mtime_ns': after.st_mtime_ns, 'inode': after.st_ino}


def require_idle_target():
    active = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            executable = os.readlink(entry / 'exe')
            cwd = os.readlink(entry / 'cwd')
        except (OSError, PermissionError):
            continue
        if executable.startswith(ENV['CARGO_TARGET_DIR'] + '/') or (
            cwd == str(ROOT) and Path(executable).name in ('cargo', 'rustc', 'rustup', 'clippy-driver')
        ):
            active.append({'pid': int(entry.name), 'executable': executable, 'cwd': cwd})
    write_json('target-process-precheck.json', {'active': active, 'checked_utc': utc()})
    if active:
        raise RuntimeError('checkout/target still has native build or test processes')


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def write_json(name, value):
    (EVIDENCE / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def hashes():
    return {name: sha256((ROOT / name).read_bytes()) for name in EXPECTED_BLOBS}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV)


def atomic_source(data, mode):
    path = ROOT / SOURCE
    fd, temporary = tempfile.mkstemp(prefix='.pq-witness-baseline-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
            handle.flush()
            os.fchmod(handle.fileno(), mode)
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def interrupted(signum, frame):
    raise InterruptedError('runner received signal ' + str(signum))


def run(name, argv, expected_hashes=None):
    global ACTIVE
    before = hashes()
    if expected_hashes is not None and before != expected_hashes:
        raise RuntimeError(name + ': source changed before command')
    log_path = EVIDENCE / (name + '.log')
    started = utc()
    start = time.monotonic()
    interrupted_error = None
    with log_path.open('xb') as output:
        ACTIVE = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdout=output,
                                  stderr=subprocess.STDOUT, start_new_session=True)
        try:
            rc = ACTIVE.wait()
        except BaseException as error:
            interrupted_error = error
            for sig in (signal.SIGTERM, signal.SIGKILL):
                if ACTIVE.poll() is None:
                    os.killpg(ACTIVE.pid, sig)
                    try:
                        ACTIVE.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        pass
            rc = ACTIVE.poll()
        finally:
            ACTIVE = None
    record = {
        'name': name, 'argv': argv, 'cwd': str(ROOT), 'started_utc': started,
        'finished_utc': utc(), 'elapsed_seconds': time.monotonic() - start,
        'exit_code': rc, 'source_hashes_before': before,
        'source_hashes_after': hashes(), 'log_sha256': sha256(log_path.read_bytes()),
        'log_bytes': log_path.stat().st_size,
    }
    if interrupted_error is not None:
        record['interruption'] = repr(interrupted_error)
    write_json(name + '.json', record)
    RECORDS.append(record)
    print(json.dumps({key: record[key] for key in ('name', 'exit_code', 'elapsed_seconds')}), flush=True)
    if interrupted_error is not None:
        raise interrupted_error
    if expected_hashes is not None and record['source_hashes_after'] != expected_hashes:
        raise RuntimeError(name + ': source changed during command')
    return record


def main():
    if not EVIDENCE.is_dir() or not (EVIDENCE / 'runner.py').is_file():
        raise RuntimeError('launcher must create fresh evidence directory with exact runner.py first')
    if any((EVIDENCE / name).exists() for name in ('initial.json', 'summary.json', 'fixed-pq_network.rs')):
        raise RuntimeError('refusing to overwrite an earlier experiment')
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    root_status = json.loads((EVIDENCE / 'root-job-terminal-status.json').read_text())
    if root_status.get('output_complete') is not True or root_status.get('state') not in (
        'succeeded', 'failed', 'timeout', 'timed_out', 'cancelled'
    ):
        raise RuntimeError('conditional GO requires authoritative terminal root job with complete output')
    require_idle_target()
    fixed = (ROOT / SOURCE).read_bytes()
    fixed_hashes = hashes()
    mode = (ROOT / SOURCE).stat().st_mode & 0o777
    actual_blobs = {name: blob_sha((ROOT / name).read_bytes()) for name in EXPECTED_BLOBS}
    if actual_blobs != EXPECTED_BLOBS:
        raise RuntimeError('fixed eight-file bytes do not match published commit')
    if sha256(fixed) != fixed_hashes[SOURCE]:
        raise RuntimeError('fixed source changed while capturing backup')
    retained = EVIDENCE / 'fixed-run-retained'
    retained.mkdir()
    original_records = []
    for name in ('summary.json', 'source-after.json', 'source-before.json', 'build.log', 'build.json',
                 'node-lib.json', 'clippy.json'):
        data = (FIXED_EVIDENCE / name).read_bytes()
        (retained / name).write_bytes(data)
        original_records.append({'name': name, 'bytes': len(data), 'sha256': sha256(data)})
    write_json('fixed-run-retained-manifest.json', original_records)
    binary_paths = re.findall(r'Executable unittests src/lib\.rs \(([^)]+)\)',
                             (retained / 'build.log').read_text())
    if len(binary_paths) != 1 or not binary_paths[0].startswith(ENV['CARGO_TARGET_DIR'] + '/'):
        raise RuntimeError('could not uniquely bind the fixed test binary from original build.log')
    test_binary = Path(binary_paths[0])
    fixed_binary = file_identity(test_binary)
    write_json('fixed-test-binary.json', fixed_binary)
    initial = {
        'started_utc': utc(), 'host': 'x230', 'published_commit': PUBLISHED,
        'published_tree': PUBLISHED_TREE, 'worktree_head': git('rev-parse', 'HEAD').decode().strip(),
        'git_status': git('status', '--porcelain=v1').decode(),
        'source_hashes': fixed_hashes, 'git_blobs': actual_blobs,
        'baseline_commit': BASE, 'baseline_source_sha256': BASE_SOURCE_SHA256,
        'budget_ms': 250, 'features': 'default', 'release': False,
        'profile': 'unchanged repository test profile, including existing per-package optimization',
        'environment': {key: ENV.get(key) for key in (
            'PATH', 'RUSTUP_TOOLCHAIN', 'RUSTC', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
            'CARGO_HOME', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CARGO_INCREMENTAL', 'LD_LIBRARY_PATH')},
        'profile_environment': {key: value for key, value in ENV.items() if key.startswith('CARGO_PROFILE_')},
        'runner_sha256': sha256((EVIDENCE / 'runner.py').read_bytes()),
        'fixed_test_binary': fixed_binary,
        'scope': 'Only old pq_network.rs with the two unchanged new tests; not a release source qualification.',
    }
    write_json('initial.json', initial)
    (EVIDENCE / 'fixed-pq_network.rs').write_bytes(fixed)
    if run('preflight', ['bash', 'scripts/project-preflight.sh'], fixed_hashes)['exit_code'] != 0:
        raise RuntimeError('preflight failed before source modification')
    for name, argv in (
        ('rustc-version', [ENV['RUSTC'], '--version', '--verbose']),
        ('cargo-version', ['cargo', '+1.95.0', '--version', '--verbose']),
    ):
        if run(name, argv, fixed_hashes)['exit_code'] != 0:
            raise RuntimeError(name + ' failed')
    baseline = git('show', BASE + ':' + SOURCE)
    if sha256(baseline) != BASE_SOURCE_SHA256:
        raise RuntimeError('baseline source hash mismatch')
    required_path = 'config/pon/pq-system-required-tests-v1.json'
    required = json.loads((ROOT / required_path).read_text())
    old_required = json.loads(git('show', BASE + ':' + required_path))
    if required['tests'][:43] != old_required['tests'] or required['tests'][43:] != SELECTORS:
        raise RuntimeError('original 43 controls or new exact selectors changed')
    (EVIDENCE / 'baseline-pq_network.rs').write_bytes(baseline)
    variant_hashes = dict(fixed_hashes)
    variant_hashes[SOURCE] = BASE_SOURCE_SHA256
    summary = {'started_utc': utc(), 'baseline_commit': BASE, 'selectors': SELECTORS,
               'fixed_source_hashes': fixed_hashes, 'variant_source_hashes': variant_hashes,
               'whole_chain_quantum_security_qualified': False,
               'original_business_budgets_changed': False}
    error = None
    try:
        atomic_source(baseline, mode)
        if hashes() != variant_hashes:
            raise RuntimeError('baseline switch changed unexpected bytes')
        (EVIDENCE / 'baseline-source.diff').write_bytes(git('diff', '--', SOURCE))
        for index, selector in enumerate(SELECTORS):
            argv = ['cargo', '+1.95.0', 'test', '--locked', '--manifest-path',
                    'trillionnium/Cargo.toml', '-p', 'trnm-pon-node', '--lib', selector,
                    '--', '--exact', '--show-output', '--test-threads=1']
            run('baseline-native-' + str(index), argv, variant_hashes)
        summary['baseline_test_binary'] = file_identity(test_binary)
        summary['baseline_binary_differs_from_fixed'] = summary['baseline_test_binary']['sha256'] != fixed_binary['sha256']
    except BaseException as caught:
        error = caught
        summary['error'] = repr(caught)
        (EVIDENCE / 'runner-error.log').write_text(traceback.format_exc())
    finally:
        current = (ROOT / SOURCE).read_bytes()
        if sha256(current) not in (BASE_SOURCE_SHA256, fixed_hashes[SOURCE]):
            summary['restore_refused_unknown_source'] = sha256(current)
            summary['restored'] = False
        else:
            if current != fixed:
                atomic_source(fixed, mode)
            summary['final_source_hashes'] = hashes()
            summary['restored'] = summary['final_source_hashes'] == fixed_hashes
        summary['records'] = RECORDS
        summary['finished_utc'] = utc()
        summary['git_status_after'] = git('status', '--porcelain=v1').decode()
        ordinary = EVIDENCE / 'baseline-native-0.log'
        if ordinary.exists():
            content = ordinary.read_text(errors='replace')
            summary['observed_fresh_admission_count_assertion'] = (
                'left: [1, 1, 2]' in content and 'right: [1, 2]' in content)
        summary['pending_replay_baseline_count_measured'] = False
        summary['target_note'] = 'Shared target may contain baseline artifacts; fixed source restored, future Cargo invocations must rebuild normally.'
        write_json('summary.json', summary)
        print(json.dumps({key: summary.get(key) for key in (
            'restored', 'observed_fresh_admission_count_assertion', 'error', 'finished_utc')}), flush=True)
    if not summary['restored']:
        raise RuntimeError('all eight fixed file hashes were not restored; root action required')
    if error is not None:
        raise error


if __name__ == '__main__':
    main()
