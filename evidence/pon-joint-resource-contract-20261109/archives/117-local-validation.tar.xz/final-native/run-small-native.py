from pathlib import Path
import json,os,subprocess,sys,time
root=Path('/workspace/scratch/pon-joint-58fd59-build/chain')
out=root.parent/'final-native'
tool=Path('/workspace/scratch/5faaca703596/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
env=os.environ.copy();env.update(json.loads((out/'serial-environment.json').read_text())['environment']);env['PATH']=str(tool)+os.pathsep+env['PATH']
head=json.loads((out/'environment.json').read_text())['head']
base=[str(tool/'cargo')]
commands=[
 ('example-tests',base+['test','--release','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--example','pon_w1_cost_matrix_v2','--example','pon_w1_reused_cost_v3','--example','pon_w1_lifecycle_cost_v4','--','--nocapture']),
 ('v4-build',base+['build','--release','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--example','pon_w1_lifecycle_cost_v4','--message-format=json']),
 ('clippy',base+['clippy','--workspace','--all-targets','--all-features','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','--','-D','warnings'])]
summary=[]
for label,argv in commands:
 wrapped=[sys.executable,'scripts/ci/record_pq_native_command.py','--kind','head','--candidate',head,'--tested',head,'--label',label,'--output',str(out),'--',*argv]
 with (out/(label+'-launcher.stdout')).open('x') as stdout,(out/(label+'-launcher.stderr')).open('x') as stderr:
  r=subprocess.run(wrapped,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=2400)
 row={'label':label,'returncode':r.returncode,'receipt':str(out/(label+'.json'))};summary.append(row);print(json.dumps(row),flush=True)
(out/'small-native-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
