# Exact-head hosted QROM failure audit

## Source and scope

Read-only audit of the completed first attempts of runs [42553753080](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553753080) and [42553752939](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553752939).

Both runs bind candidate `34bffa42461e746a602cfd687b8efb082df926c8`. The head jobs tested that commit. The prospective-merge jobs tested `e6f02e4d35ce36178f4dc92463f4f6d32262a991`. All four logs record the same tested tree, `b692872dfd441a3ee89a6604ec51556fd1f6bddf`, before and after execution. Both runs and all four jobs completed with conclusion `failure`.

| Workflow | Head job | Prospective-merge job | Earliest observed refusal |
| --- | --- | --- | --- |
| W1 QROM implementation | [128954800911](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553753080/job/128954800911) | [128954800583](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553753080/job/128954800583) | `input exceeds bound: formal/pon-nakamoto-v1/w1_v2_verifier/src/main.rs` |
| W1 QROM closure | [128954800138](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553752939/job/128954800138) | [128954800370](https://github.com/TrillionniumFoundation/Trillionnium-Chain/actions/runs/42553752939/job/128954800370) | `source identity mismatch: trillionnium/crates/trnm-pon-node/src/store.rs` |

## Implementation: fixed input byte bound

`config/pon/w1-qrom-implementation-v1.json` fixes the verifier input to 9,233 bytes and SHA256 `07415e8e3bb53f3e81dd489e4ebda63368170efbe4a217ae6b0dd6cc0af14128`. The actual file at the candidate is 11,172 bytes with SHA256 `5e102fcbe4881e3d163c7a8b65364304b14d080ae64f23b0d5032daa84208aa7`. The bounded reader rejects it before the subsequent exact-length/hash check.

The actual logs show `ImplementationAuditTests` running 19 tests with 2 failures and 2 errors. Both failures expected the later `pinned input drift` reason, but the earlier size bound refused the input. `WorkflowGateTests.setUpClass` also refuses this input, so that module executes zero test bodies. The fixed implementation-map reproduction exits 2 with `INPUT_REJECTED`. Report-scope validation is skipped. The final gate reports incomplete `named_tests`, `implementation`, and `report_scopes`, plus invalid named-test completion.

## Closure: fixed source identity

`scripts/w1_lifetime_ledger.py` fixes the selected `store.rs` SHA256 to `b712a86b9997a098df5e8257f309d22445b2c749c9aa474457e958a0f65f5153`. The candidate file has SHA256 `108621f304255841ea2e1a7353858c3f0f5d8cb70a235f6a4aef6d57ebe0c554` (382,866 bytes).

The logs show `LifetimeLedgerTests.setUpClass` raising `LedgerError` before any lifetime test body executes. Other modules continue, but fixed named completion refuses because `started_ids` differs. The reproduction step emits `REFUSED` for the same source mismatch and exits 2. In that step, semantics runs before lifetime; `set -euo pipefail` stops later composition/joint-oracle reproduction and saved-report comparisons after the lifetime refusal. The final independent completion gate fails because the required observations did not all complete.

## Relationship to this round

This conclusion is based on direct Git blob and SHA256 comparison with fixed baseline `e798d7125724d4b9f98c24d00cc80031f2eab4a9`, not on another PR's red status. Both rejected input files are byte-identical between baseline and candidate. The relevant project contract, audit scripts, directly affected tests, and both workflows are also byte-identical. In particular, this round changed sibling files under `store/`; it did not change the rejected `store.rs` file itself.

Therefore this round did not introduce either earliest refusal shown by these logs. This does not prove that downstream stages would pass after a new, reviewed input qualification. Both hosted workflows remain failed. No historical contract was repinned or relaxed, no workflow was rerun, and no Cargo command or source edit was performed for this audit.

## Evidence inventory

- `job-*.log`: complete decoded GitHub job log text, saved as UTF-8.
- `run-*-run.json` and `run-*-jobs.json`: retrieved run/job metadata.
- `failure-excerpts.json`: error and source-identity log excerpts with original one-based line numbers.
- `source-comparison.json`: fixed baseline/candidate Git blobs, byte counts, SHA256 values, and input pins.
- `failure-summary.json`: machine-readable run, job, gate, cause, and scope summary.
- `retrieved-files-sha256.json`: hashes of the initially retrieved log and API files.
- `MANIFEST.sha256`: hashes of the saved evidence files, excluding the manifest itself.

These failures establish incomplete fixed-input reproduction and gate completion. They establish neither a cryptographic counterexample nor complete W1/QROM/chain qualification. Local native or Python gate results remain separate evidence and do not turn these hosted workflows green.
