from pathlib import Path
import sys,json,hashlib,tarfile,gzip,io,os,stat,subprocess
base=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');src=base/'resume-20261120-e9e051/source';out=src.parent/'original-stage-packaging';out.mkdir(exist_ok=False)
(out/'owner.py').write_text(sys.argv[2]);stages=json.loads(sys.argv[1])
with (out/'preflight.stdout').open('wb') as so,(out/'preflight.stderr').open('wb') as se:subprocess.run(['bash','scripts/project-preflight.sh'],cwd=src,stdout=so,stderr=se,check=True)
dest=src/'evidence/chain-w1-delay-controls-20261120-e9e051';archive=dest/'original-owner-stages.tar.gz';rows=[]
with archive.open('xb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tf:
   for name in stages:
    for p in sorted((base/name).rglob('*')):
     if not p.is_file():continue
     a=p.lstat();assert stat.S_ISREG(a.st_mode) and a.st_nlink==1 and not p.is_symlink()
     data=p.read_bytes();b=p.stat();assert (a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(b.st_size,b.st_mtime_ns,b.st_ctime_ns)
     rel=p.relative_to(base).as_posix();row={'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':stat.S_IMODE(a.st_mode),'mtime_ns':a.st_mtime_ns};rows.append(row)
     info=tarfile.TarInfo('original-owner-stages/'+rel);info.size=len(data);info.mode=stat.S_IMODE(a.st_mode);info.mtime=0
     tf.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tf:
 actual=tf.getmembers();assert len(actual)==len(rows)
 for row,m in zip(rows,actual):
  assert m.name=='original-owner-stages/'+row['path'] and m.isfile()
  assert hashlib.sha256(tf.extractfile(m).read()).hexdigest()==row['sha256']
result={'schema':'chain-original-owner-stage-archive-v1','scope':'All original stage directories alongside source; source checkout, target build cache and isolated continuation excluded. Original F0 provider archives are inherited separately from ea356c.','directories':stages,'files':rows,'file_count':len(rows),'uncompressed_bytes':sum(x['bytes'] for x in rows),'archive_file':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_verified':True}
(dest/'original-owner-stages.manifest.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'RESULT.json').write_text(json.dumps({k:v for k,v in result.items() if k not in ['files','directories']},indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['files','directories']}),flush=True)
