# Current F0 Growth union verification

The two retained current F0 outputs independently reconcile to **77 unique passed library tests and the same 2 originally ignored experiments**.

- Prefix run: 53 selected, 51 passed, 2 ignored.
- Complement run: 26 selected, 26 passed, 0 ignored.
- Union: 79 distinct selected names.
- Missing names compared with the original 79: none.
- Extra names: none.
- Duplicate top-level names within either run: none.
- Overlap between runs: none.
- Passed and ignored name sets exactly equal the original roster's corresponding sets.

Both current commands explicitly use --features pq-native-openssl, toolchain +1.95.0, and the library test target. Both stderr logs reference the same npq6/debug/deps test-binary path. The original F3 command used default features and selected the whole store::growth:: module. The original execution environment has not been relabeled.

The process-cut test's final ok appears after internal child-process output on a separate line. Segment parsing associates that ok with its single named top-level test start. The child output does not create another named top-level roster entry.

This independent audit read existing outputs and metadata and did not run tests or modify source. Current source identity observations, per-run records, original input hashes, full per-name status evidence, and source-after availability are retained in audit.json. The supplement's broader campaign may still be running; see source-identity-observed.json for whether its final source-after record existed at audit time.

The original audit directory and manifest remain unchanged. This appended subdirectory has its own manifest.
