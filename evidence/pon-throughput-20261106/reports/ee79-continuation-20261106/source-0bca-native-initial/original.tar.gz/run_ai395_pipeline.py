#!/usr/bin/env python3
"""Task-only serial locked graphs and original guarded native qualification."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace

SHARED = Path('/home/qq/work/chain-throughput-20261106-ee79')
ROOT = SHARED / 'qualification-114-0bca28ebf590'
HEAD = '0bca28ebf59058b6aba9db5eb956c4479556e9ee'
TREE = '06e394f20b8f491c4ea1f91a357e2b6e8a4c0812'
RUNNER_SHA = '2944189be70e53103debc4a9ae0a95866cde53ddbf3271a314b716614458074d'
GUARD_SHA = '9e050c1a0170b100662759b3d4161f79b490888ef2b53d88e410e417b893e322'
MANIFESTS = ('trillionnium/Cargo.toml', 'tests/fuzz/Cargo.toml',
             'formal/pon-nakamoto-v1/w1_native_cost/Cargo.toml')
PROVIDER_KEYS = ('OPENSSL_DIR', 'OPENSSL_STATIC', 'OPENSSL_CONF', 'OPENSSL_MODULES',
                 'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_SHA256', 'TRNM_PQ_OPENSSL_VERSION')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def main():
    repo, raw = (ROOT / 'repo').resolve(strict=True), ROOT / 'raw'
    if repo != (SHARED / 'repo').resolve(strict=True):
        raise ValueError('actual shared checkout mismatch')
    if len({p.stat().st_dev for p in (ROOT, SHARED / 'target', SHARED / 'cargo', SHARED / 'tmp')}) != 1:
        raise ValueError('disk guard and all Cargo write paths must share one filesystem')
    path = raw / 'serial-pipeline.json'
    report = dict(schema='trnm-ai395-serial-qualification-v1', status='running',
        expected_head=HEAD, expected_tree=TREE, started_ns=time.time_ns(),
        pipeline_sha256=digest(Path(__file__).resolve()), stages=[],
        whole_chain_or_service_qualification=False)
    with path.open('x') as stream:
        json.dump(report, stream)
    try:
        runner, guard = ROOT / 'run_native_qualification.py', ROOT / 'disk_guard.py'
        if digest(runner) != RUNNER_SHA or digest(guard) != GUARD_SHA:
            raise ValueError('original runner or external guard digest mismatch')
        actual = subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'],
                                         cwd=repo, text=True).splitlines()
        if actual != [HEAD, TREE]:
            raise ValueError('exact source head/tree mismatch')
        provider = json.loads((raw / 'provider-discovery.json').read_text())
        if provider.get('reusable') is not True:
            raise ValueError('original static provider not verified')
        env = dict(os.environ, PATH='/home/qq/.cargo/bin:' + os.environ.get('PATH', ''),
            PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0',
            RUSTUP_AUTO_INSTALL='0', CARGO_HOME=str(SHARED / 'cargo'),
            CARGO_TARGET_DIR=str(SHARED / 'target'), CARGO_BUILD_JOBS='2',
            CARGO_INCREMENTAL='0', RUST_TEST_THREADS='1', TMPDIR=str(SHARED / 'tmp'), CI='true')
        for key in PROVIDER_KEYS:
            value = provider['environment'].get(key)
            if value is not None:
                if not isinstance(value, str):
                    raise ValueError('nonstring provider environment')
                env[key] = value
        os.environ.update(env)
        spec = importlib.util.spec_from_file_location('native_qualification_owner', runner)
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        env = helper.environment(repo)
        source_args = SimpleNamespace(repo=repo, out=raw, head=HEAD)
        preflight = helper.run_recorded(source_args, 'graphs-preflight',
            ['bash', 'scripts/project-preflight.sh', '--audit'], env)
        if not preflight['passed']:
            raise ValueError('locked graph preflight failed')
        inputs = [repo / name for manifest in MANIFESTS
                  for name in (manifest, str(Path(manifest).with_name('Cargo.lock')))]
        before = {str(p.relative_to(repo)): digest(p) for p in inputs}
        graphs = dict(schema='trnm-three-locked-graph-observation-v1', status='running',
            expected_graphs=3, source_head=HEAD, source_tree=TREE,
            manifest_and_lock_sha256_before=before, commands=[],
            scope='original locked Cargo metadata graphs; no cargo-deny advisory or license-policy qualification')
        graph_path = raw / 'locked-graphs.json'
        write(graph_path, graphs)
        for index, manifest in enumerate(MANIFESTS):
            # Existing PQ and W1 CI use these exact metadata flags. The later
            # workspace build keeps its separate original --all-features graph.
            command = ['cargo', '+1.95.0', 'metadata', '--locked', '--manifest-path',
                       manifest, '--format-version', '1']
            result = helper.run_recorded(source_args, 'locked-graph-' + str(index), command, env)
            result['manifest'] = manifest
            if result['passed']:
                messages = [json.loads(line) for line in (raw / f'locked-graph-{index}.log').read_text().splitlines()
                            if line.startswith('{')]
                if len(messages) != 1 or messages[0].get('resolve') is None:
                    result.update(passed=False, graph_error='one resolved actual Cargo metadata graph required')
                else:
                    result['packages'] = len(messages[0]['packages'])
                    result['resolved_nodes'] = len(messages[0]['resolve']['nodes'])
            graphs['commands'].append(result)
            write(graph_path, graphs)
        graphs['manifest_and_lock_sha256_after'] = {str(p.relative_to(repo)): digest(p) for p in inputs}
        graphs['status'] = ('passed' if before == graphs['manifest_and_lock_sha256_after']
                            and all(row['passed'] for row in graphs['commands']) else 'failed')
        write(graph_path, graphs)
        report['locked_graphs'] = dict(status=graphs['status'], receipt=str(graph_path),
                                      sha256=digest(graph_path))
        write(path, report)
        if graphs['status'] != 'passed':
            raise ValueError('one or more locked graphs failed; original failures retained')
        observer = ROOT / 'observe_authenticated_ignored.py'
        if digest(observer) != '3759514d6075dc861b3dc4b3f17ea7793f0f5b37d1668533ebaa0e38b53ad6c6':
            raise ValueError('ignored registration observer digest mismatch')
        for stage in ('quality', 'build', 'controls', 'runtime'):
            command = [sys.executable, str(guard), '--root', str(ROOT), '--head', HEAD,
                       '--label', stage, '--', sys.executable, str(runner),
                       '--repo', str(repo), '--out', str(raw), '--head', HEAD, '--stage', stage]
            row = dict(stage=stage, argv=command, started_ns=time.time_ns(), exit_code=None)
            report['stages'].append(row)
            write(path, report)
            with (raw / ('pipeline-' + stage + '.log')).open('xb') as stream:
                result = subprocess.run(command, cwd=repo, env=env, stdin=subprocess.DEVNULL,
                                        stdout=stream, stderr=subprocess.STDOUT, check=False)
            row.update(exit_code=result.returncode, finished_ns=time.time_ns(),
                       log_sha256=digest(raw / ('pipeline-' + stage + '.log')))
            write(path, report)
            print(json.dumps({'stage': stage, 'exit_code': result.returncode}), flush=True)
            if result.returncode:
                raise ValueError('original stage failed: ' + stage)
            if stage == 'controls':
                observation = helper.run_recorded(source_args, 'authenticated-registration',
                    [sys.executable, str(observer), '--repo', str(repo), '--out', str(raw), '--head', HEAD], env)
                report['authenticated_registration'] = observation
                write(path, report)
                if not observation['passed']:
                    raise ValueError('actual ignored-registration observation failed')
            if stage == 'build':
                receipt = json.loads((raw / 'build.json').read_text())
                if receipt.get('status') != 'command_succeeded' or receipt.get('exit_code') != 0:
                    raise ValueError('controls require the successful complete original workspace build')
        report['status'] = 'passed'
    except (OSError, ValueError, KeyError, TypeError, ImportError, subprocess.SubprocessError) as error:
        report.update(status='failed', error=str(error))
    report['finished_ns'] = time.time_ns()
    report['unexecuted_stages'] = [stage for stage in ('quality', 'build', 'controls', 'runtime')
                                  if stage not in {row['stage'] for row in report['stages']}]
    write(path, report)
    print(json.dumps({'status': report['status'], 'error': report.get('error'),
                      'receipt': str(path)}), flush=True)
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
