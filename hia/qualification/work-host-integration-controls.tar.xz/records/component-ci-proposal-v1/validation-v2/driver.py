ROOT_PATH="/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo"
from pathlib import Path
import sys,json,hashlib,subprocess,importlib.util,contextlib,io,unittest,time,traceback,os,re,ast
root=Path(ROOT_PATH);base=root.parent/"component-ci-proposal-v1";candidate=base/"candidate";out=base/"validation-v2";out.mkdir(mode=0o700)
(out/"driver.py").write_text(sys.argv[1]);started=time.monotonic_ns();report={"status":"FAIL","native_business_runtime_executed":False,"original_cargo_executed":False}
def need(v,m):
 if not v:raise ValueError(m)
def identity(p):
 raw=p.read_bytes();return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def load_module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
 if "." in name and name.rsplit(".",1)[0] in sys.modules:setattr(sys.modules[name.rsplit(".",1)[0]],name.rsplit(".",1)[1],mod)
 return mod
names=["hia/tools/component_partition.py","hia/tools/qualify.py","hia/tools/qualify_components_ci.py","hia/tests/test_component_partition.py",".github/workflows/hia-native-migration.yml","scripts/ci/test_hia_workflow_bootstrap.py"]
source={name:identity(candidate/name) for name in names}
try:
 pre=subprocess.run(["bash","scripts/project-preflight.sh"],cwd=root,capture_output=True);(out/"preflight.stdout.raw").write_bytes(pre.stdout);(out/"preflight.stderr.raw").write_bytes(pre.stderr);need(pre.returncode==0,"Preflight failed")
 sys.path.insert(0,str(root));import hia.tools,hia.tests
 part=load_module("hia.tools.component_partition",candidate/"hia/tools/component_partition.py")
 qualifier=load_module("hia.tools.qualify",candidate/"hia/tools/qualify.py");qualifier.ROOT=root
 reader=load_module("hia.tools.qualify_components_ci",candidate/"hia/tools/qualify_components_ci.py");reader.ROOT=root
 tests=load_module("hia.tests.test_component_partition",candidate/"hia/tests/test_component_partition.py")
 boot=load_module("component_bootstrap_proposal",candidate/"scripts/ci/test_hia_workflow_bootstrap.py")
 suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(tests),unittest.defaultTestLoader.loadTestsFromModule(boot)])
 with (out/"tests.stdout.raw").open("w") as stdout,(out/"tests.stderr.raw").open("w") as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
  result=unittest.TextTestRunner(stream=stderr,verbosity=2).run(suite)
 report["unit_tests"]={"run":result.testsRun,"failures":[[str(t),e] for t,e in result.failures],"errors":[[str(t),e] for t,e in result.errors],"skips":[[str(t),e] for t,e in result.skipped]}
 need(result.wasSuccessful() and not result.skipped,"Partition/bootstrap controls failed")
 discovered=unittest.defaultTestLoader.discover(str(root/"hia/tests"),pattern="test_*.py",top_level_dir=str(root))
 ids=[t.id() for t in part.flatten(discovered)]+[t.id() for t in part.flatten(unittest.defaultTestLoader.loadTestsFromModule(tests))]
 rosters={group:part.descriptor(ids,group) for group in part.GROUPS}
 selected=[x for group in part.GROUPS for x in rosters[group]["selected_tests"]]
 need(len(selected)==len(set(selected)) and sorted(selected)==sorted(ids),"Partition omitted/repeated a real discovered test")
 report["complete_test_inventory"]={"total":len(ids),"groups":{g:len(v["selected_tests"]) for g,v in rosters.items()},"rosters":rosters,"tests_executed_by_discovery":False}
 import yaml
 class Unique(yaml.SafeLoader):pass
 def mapping(loader,node,deep=False):
  result={}
  for kn,vn in node.value:
   key=loader.construct_object(kn,deep=deep);need(key not in result,"Duplicate YAML key: "+str(key));result[key]=loader.construct_object(vn,deep=deep)
  return result
 Unique.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,mapping)
 workflow=yaml.load((candidate/".github/workflows/hia-native-migration.yml").read_text(),Loader=Unique)
 old=yaml.load((base/"baseline/.github/workflows/hia-native-migration.yml").read_text(),Loader=Unique)
 need(set(workflow["jobs"])==set(old["jobs"])|{"native-components-state-root","native-components-readback"},"Existing job omitted or unexpected job added")
 for name in ("native-components","native-components-state-root","native-components-readback"):need(type(workflow["jobs"][name]["timeout-minutes"]) is int and workflow["jobs"][name]["timeout-minutes"]==20,"Component time limit changed")
 need(workflow["jobs"]["native-components-readback"]["needs"]==["native-components","native-components-state-root"],"Missing actual predecessor")
 bash=0;python=0
 for jobname,job in workflow["jobs"].items():
  for n,step in enumerate(job.get("steps",[])):
   if "run" not in step:continue
   code=re.sub(r"\$\{\{.*?\}\}","CI_EXPRESSION",step["run"])
   r=subprocess.run(["bash","-n"],input=code.encode(),capture_output=True)
   need(r.returncode==0,"Bash parse failed "+jobname+":"+str(n)+":"+r.stderr.decode());bash+=1
   for m in re.finditer(r"<<['\"]?(PY[A-Z0-9_]*)['\"]?\n(.*?)^\1$",code,re.M|re.S):
    ast.parse(m.group(2));python+=1
 report["workflow"]={"jobs":len(workflow["jobs"]),"bash_fragments":bash,"python_heredocs":python,"native_bootstrap_gates":len(boot.BOOTSTRAP.findall((candidate/".github/workflows/hia-native-migration.yml").read_text())),"limits_minutes":20}
 wrapper=out/"cli_loader.py"
 wrapper.write_text("from pathlib import Path\nimport sys,importlib.util\nroot=Path("+repr(str(root))+")\ncandidate=Path("+repr(str(candidate))+")\nsys.path.insert(0,str(root))\nimport hia.tools\ndef load(name):\n p=candidate/('hia/tools/'+name+'.py')\n spec=importlib.util.spec_from_file_location('hia.tools.'+name,p)\n m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);setattr(hia.tools,name,m);m.ROOT=root;return m\nload('component_partition');q=load('qualify');r=load('qualify_components_ci')\nwhich=sys.argv.pop(1)\nraise SystemExit((q if which=='qualify' else r).main())\n")
 controls=[]
 env={k:v for k,v in os.environ.items() if k not in ("PYTHONOPTIMIZE","TRNM_EXPECTED_SOURCE_SHA","GITHUB_RUN_ID","GITHUB_RUN_ATTEMPT")}
 for which in ("qualify","readback"):
  for flag in ("-O","-OO"):
   target=out/(which+flag+"-must-not-exist.json")
   args=[sys.executable,"-B",flag,str(wrapper),which]
   if which=="readback":args+=["--general",str(out/"absent-general"),"--state-root",str(out/"absent-root")]
   args+=["--output",str(target)]
   r=subprocess.run(args,cwd=root,env=env,capture_output=True,timeout=20)
   prefix=out/(which+flag);prefix.with_suffix(".stdout.raw").write_bytes(r.stdout);prefix.with_suffix(".stderr.raw").write_bytes(r.stderr)
   need(r.returncode!=0 and b"refuses optimized Python" in r.stderr and not target.exists(),"Optimized CLI did not refuse before qualification")
   controls.append({"argv":args,"exit":r.returncode,"output_absent":True})
 report["actual_public_cli_controls"]=controls
 report["source_after"]={name:identity(candidate/name) for name in names};need(report["source_after"]==source,"Private source changed during tests")
 expected=json.loads((base/"source-before.json").read_text());need({n:identity(root/n) for n in expected}==expected,"Canonical c390 source changed")
 report.update(status="PASS",canonical_source_after="MATCH",source_before=source)
except BaseException as e:report["failure"]={"error":repr(e),"traceback":traceback.format_exc()};raise
finally:
 report["elapsed_ns"]=time.monotonic_ns()-started
 (out/"report.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
 print(json.dumps({"status":report["status"],"elapsed_ns":report["elapsed_ns"],"unit_tests":report.get("unit_tests"),"workflow":report.get("workflow"),"inventory":{k:v for k,v in report.get("complete_test_inventory",{}).items() if k!="rosters"},"cli_controls":len(report.get("actual_public_cli_controls",[])),"failure":report.get("failure")}),flush=True)
