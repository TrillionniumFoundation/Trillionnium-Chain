import hashlib,json,os,pathlib,signal,subprocess,time
root=pathlib.Path('/workspace/scratch/pon-joint-58fd59-build/history-red')
out=pathlib.Path('/workspace/scratch/pon-joint-58fd59-build/history-deadline-evidence')
binpath=pathlib.Path('/workspace/scratch/5faaca703596/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
env=os.environ.copy()
env.update(CARGO_HOME='/workspace/scratch/5faaca703596/toolchain/cargo',RUSTUP_HOME='/workspace/scratch/5faaca703596/toolchain/rustup',CARGO_TARGET_DIR='/workspace/scratch/pon-joint-58fd59-build/target',RUSTC=str(binpath/'rustc'),RUSTDOC=str(binpath/'rustdoc'),OPENSSL_LIB_DIR='/usr/lib/x86_64-linux-gnu',OPENSSL_INCLUDE_DIR='/usr/include',CARGO_BUILD_JOBS='2')
env['PATH']=str(binpath)+os.pathsep+env['PATH']
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def capture(name):
 files=[]; mismatches=[]; total=0
 for entry in git('ls-files','--stage','-z').split(b'\0'):
  if not entry:continue
  meta,raw=entry.split(b'\t',1);mode,blob,stage=meta.decode().split(); path=raw.decode()
  p=root/path
  data=os.readlink(p).encode() if mode=='120000' else p.read_bytes()
  actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  item={'path':path,'mode':mode,'git_blob':blob,'actual_git_blob':actual,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  files.append(item); total+=len(data)
  if actual!=blob:mismatches.append(path)
 data={'scope':'exact base plus test-only reproducer; no production or whole-system qualification','head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'status':git('status','--porcelain=v1').decode(),'tracked_entries':len(files),'tracked_bytes':total,'mismatches':mismatches,'files':files}
 (out/name).write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
 return data
pre=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=root,env=env,capture_output=True)
(out/'red-preflight.stdout').write_bytes(pre.stdout);(out/'red-preflight.stderr').write_bytes(pre.stderr)
assert pre.returncode==0,pre.stderr.decode()
before=capture('red-source-before.json')
assert before['mismatches']==['trillionnium/crates/trnm-pon-node/src/ingress/history_import_deadline_tests.rs'],before['mismatches']
(out/'red-tests-only.patch').write_bytes(git('diff','--binary'))
metadata={key:env[key] for key in ['CARGO_HOME','RUSTUP_HOME','CARGO_TARGET_DIR','RUSTC','RUSTDOC','OPENSSL_LIB_DIR','OPENSSL_INCLUDE_DIR','CARGO_BUILD_JOBS']}
metadata['rustc_vv']=subprocess.check_output([str(binpath/'rustc'),'-Vv'],env=env,text=True)
metadata['openssl_version']=subprocess.check_output(['openssl','version'],env=env,text=True)
command=[str(binpath/'cargo'),'test','--release','--locked','--offline','-p','trnm-pon-node','--lib','history_import::tests::deadline_controls','--','--nocapture']
(out/'red-command.json').write_text(json.dumps({'argv':command,'cwd':str(root/'trillionnium'),'environment':metadata,'timeout_seconds':2400},indent=2)+'\n')
started=time.time(); timed_out=False
with (out/'red.stdout').open('wb') as stdout,(out/'red.stderr').open('wb') as stderr:
 proc=subprocess.Popen(command,cwd=root/'trillionnium',env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=proc.wait(timeout=2400)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(proc.pid,signal.SIGTERM)
  try:code=proc.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
after=capture('red-source-after.json')
summary={'phase':'original production source plus new test-only reproducer','exit_code':code,'timed_out':timed_out,'wall_seconds':time.time()-started,'source_equal':before==after,'head':before['head'],'mismatches':before['mismatches']}
(out/'red-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
