#!/usr/bin/env python3
"""Archive completed evidence only. No source edits, subprocesses, or native runs."""
import argparse
import collections
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile

BASE = Path('/home/qian-qi/work/chain-pq-composition-663507-20261108')
OUT_NAME = 'continuation-resource-evidence-5633c55-v1'
COLLECTOR = 'archive_continuation_resource_5633.py'
ROOTS = ['native-continuation-5633c55', 'owned-resource-repair-5633c55']
RUNNER_PINS = {'native_continuation_campaign_5633.py': '59cb1244816b743e37a92be709383b2e42cf3feecf531d74af40befba7e81058', 'tls25-source-roster-5633.json': 'cc3bee7070d680df0d952ea102d3416646886c474638f15d634fd916bb75e7be', 'small-package-roster-5633.json': 'c03fd53d5c02e75bf98f790453f827b45e574355d5670a807346103d0aaac895', 'owned_cache_repair_5633.py': '1814259d2cb6b69b4cef0e44df620434892c440231fa45c396975faaad4546cd', 'owned_cleanup_known_jobs_5633.json': '66f6d9a21634808dd4a0e8cbba9063fa7da5eb36f3c30c4b7a170fbec351dd2b', 'native-continuation-5633-launch-request.json': '3460db6596bbdb1d46dee18fd3013ba4faa1ae24c04a6866cf554d806e2e23a9', 'native-continuation-5633-launch-receipt.json': '1b5365912b65703b19aa1421552b4bdc6e836c0aa0cfd1b5243399ce5ac23a74', 'native-continuation-5633-upload-receipts.json': 'a673663e2fb9f63e018e7581405e16cbacc4b2c9bfe0bfe323ab197ab3dcdfef', 'native-continuation-5633-final-upload-receipt.json': '64360beb374b14ccbee949b93174f4fd01a6a681c46a5a16edf74aa184e93e23', 'native-continuation-independent-readback-5633.json': '35d2f2276c932b06199e01b43812e9e7fd28e4fb5bfb72c8b2f886713ff4d6fa', 'native-continuation-terminal-read-5633.json': 'f5c48a988fba463541e07f18a8951c126ecee01d667ea9793fd123a344cb88d1', 'owned-resource-repair-readback-5633.json': 'a241d387d3dc785aad13e5a55933005ff12292eb09d51092474345807d649ed2', 'metadata_import_terminal_evidence_5633.json': '9767b7ad4c41d76fef47e2657f3ba6b2dbda1aab56204a8a1d817ee32fe00fed', 'continuation_resource_authoritative_controls_5633.json': '40845fb47514f65be156b3e9adc4b5a70937be9e85c350d7c055be9fbc7f1303', 'continuation_resource_scope_decision_5633.json': '6933d69c96f42454f821bcfc0ae6f2a93ef39fb5c3a258dfe4a066c401d4a61e'}
SKIP = {'native-continuation-5633c55/native-target'}
NATIVE_SUMMARY_PIN = '0e3d3ba84e3fa7edcbb51cdc1c856e214195517a539fd6ca782fef5e7706972d'
SOURCE_RECEIPT_PIN = '0c0c76846a4cace0b3a378b631f16fb23a88841d22a5edcce4ce1ddf7cb8d1b1'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def identity(info):
    return {'device': info.st_dev, 'inode': info.st_ino, 'mode': info.st_mode,
            'nlink': info.st_nlink, 'uid': info.st_uid, 'gid': info.st_gid,
            'size': info.st_size, 'mtime_ns': info.st_mtime_ns, 'ctime_ns': info.st_ctime_ns}


def open_dir(path):
    parts = PurePosixPath(path).parts
    require(parts and parts[0] == '/', 'directory must be absolute')
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in parts[1:]:
            require(part not in {'.', '..'}, 'unsafe directory component')
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


def parent_fd(base_fd, relative):
    parts = PurePosixPath(relative).parts
    require(parts and not PurePosixPath(relative).is_absolute()
            and all(part not in {'.', '..'} for part in parts), 'unsafe relative path')
    fd = os.dup(base_fd)
    try:
        for part in parts[:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        return fd, parts[-1]
    except BaseException:
        os.close(fd)
        raise


def inventory(base_fd):
    rows = []

    def walk(fd, relative):
        before = identity(os.fstat(fd))
        rows.append({'path': relative, 'kind': 'directory', 'stat': before})
        for name in sorted(os.listdir(fd)):
            info = os.stat(name, dir_fd=fd, follow_symlinks=False)
            path = relative + '/' + name
            row = {'path': path, 'stat': identity(info)}
            if stat.S_ISDIR(info.st_mode):
                if path in SKIP:
                    rows.append(dict(row, kind='excluded_cache_directory'))
                    continue
                child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                try:
                    require(identity(os.fstat(child)) == row['stat'], 'directory changed: ' + path)
                    walk(child, path)
                finally:
                    os.close(child)
            elif stat.S_ISREG(info.st_mode):
                rows.append(dict(row, kind='regular'))
            elif stat.S_ISLNK(info.st_mode):
                rows.append(dict(row, kind='symlink', target=os.readlink(name, dir_fd=fd)))
            else:
                rows.append(dict(row, kind='special'))
        require(identity(os.fstat(fd)) == before, 'directory changed during walk: ' + relative)

    for root in ROOTS:
        info = os.stat(root, dir_fd=base_fd, follow_symlinks=False)
        require(stat.S_ISDIR(info.st_mode), 'evidence root is not a directory: ' + root)
        fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=base_fd)
        try:
            require(identity(os.fstat(fd)) == identity(info), 'root changed during opening')
            walk(fd, root)
        finally:
            os.close(fd)
    for name in RUNNER_PINS:
        info = os.stat(name, dir_fd=base_fd, follow_symlinks=False)
        rows.append({'path': name, 'kind': 'runner_regular' if stat.S_ISREG(info.st_mode)
                     else 'runner_invalid', 'stat': identity(info)})
    return rows


def read_regular(base_fd, relative, expected=None):
    parent, name = parent_fd(base_fd, relative)
    try:
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
    finally:
        os.close(parent)
    try:
        before = identity(os.fstat(fd))
        require(stat.S_ISREG(before['mode']) and before['nlink'] == 1,
                'non-regular or hard-linked input: ' + relative)
        require(before['size'] <= 16 * 1024 * 1024, 'oversized input needs explicit review: ' + relative)
        require(expected is None or before == expected, 'input identity changed: ' + relative)
        pieces = []
        remaining = before['size']
        while remaining:
            chunk = os.read(fd, min(1024 * 1024, remaining))
            require(bool(chunk), 'input shortened: ' + relative)
            pieces.append(chunk)
            remaining -= len(chunk)
        require(not os.read(fd, 1), 'input grew: ' + relative)
        require(identity(os.fstat(fd)) == before, 'input changed during read: ' + relative)
        return b''.join(pieces), before
    finally:
        os.close(fd)


def write_new(fd, name, data):
    require('/' not in name, 'output must be a direct child')
    target = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=fd)
    with os.fdopen(target, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def sensitive_findings(payloads):
    detectors = {
        'private_key_pem': rb'-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----',
        'github_credential': rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,})',
        'aws_access_key': rb'AKIA[0-9A-Z]{16}',
        'bearer_credential': rb'(?i)authorization[\"\s:=]+bearer\s+[A-Za-z0-9._~-]{16,}',
        'credential_assignment': rb'(?i)[\"\x27](?:OPENAI_API_KEY|AWS_SECRET_ACCESS_KEY|GH_TOKEN|GITHUB_TOKEN|SSH_PRIVATE_KEY|access_token|password)[\"\x27]\s*:\s*[\"\x27][^\"\x27\s]{8,}',
    }
    return [{'path': path, 'detector': name} for path, data in payloads.items()
            for name, expression in detectors.items() if re.search(expression, data)]


def archive_bytes(payloads):
    target = io.BytesIO()
    with gzip.GzipFile(fileobj=target, filename='', mode='wb', compresslevel=9, mtime=0) as packed:
        with tarfile.open(fileobj=packed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for path in sorted(payloads):
                info = tarfile.TarInfo(path)
                info.size = len(payloads[path])
                info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                archive.addfile(info, io.BytesIO(payloads[path]))
    return target.getvalue()


def verify_archive(data, payloads):
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        members = archive.getmembers()
        require([m.name for m in members] == sorted(payloads), 'archive member set/order differs')
        for member in members:
            require(member.isfile() and member.uid == member.gid == member.mtime == 0
                    and member.mode == 0o644, 'archive contains unexpected member metadata')
            copied = archive.extractfile(member).read()
            require(copied == payloads[member.name], 'archive bytes differ: ' + member.name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-runner-sha256', required=True)
    args = parser.parse_args()
    require(Path(__file__).absolute() == BASE / COLLECTOR, 'unexpected collector location')
    base_fd = open_dir(str(BASE))
    out_fd = None
    try:
        collector, collector_identity = read_regular(base_fd, COLLECTOR)
        require(digest(collector) == args.expected_runner_sha256, 'collector SHA mismatch')
        before = inventory(base_fd)
        metadata_hash = digest(json.dumps(before, sort_keys=True, separators=(',', ':')).encode())
        regular = [row for row in before if row['kind'] in ('regular', 'runner_regular')]
        require(not any(row['kind'] in ('symlink', 'special', 'runner_invalid') for row in before),
                'new symlink/special entry requires metadata review')
        os.mkdir(OUT_NAME, mode=0o700, dir_fd=base_fd)
        out_fd = os.open(OUT_NAME, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=base_fd)
        payloads = {}
        files = []
        for row in regular:
            body, observed = read_regular(base_fd, row['path'], row['stat'])
            payloads[row['path']] = body
            files.append({'path': row['path'], 'bytes': len(body), 'sha256': digest(body),
                          'source_identity': observed})
        require(digest(payloads['native-continuation-5633c55/summary.json']) == NATIVE_SUMMARY_PIN,
                'terminal native summary differs')
        for name, expected in RUNNER_PINS.items():
            require(digest(payloads[name]) == expected, 'frozen runner differs: ' + name)
        receipts = ['native-continuation-5633c55/' + name + '.source.json'
                    for name in ('source-before', 'source-after-primary', 'source-after-final')]
        receipts += ['owned-resource-repair-5633c55/' + name + '.source.json'
                     for name in ('inspect-1', 'delete-1')]
        require(all(digest(payloads[name]) == SOURCE_RECEIPT_PIN for name in receipts),
                'source receipts differ from retained identities')
        require(digest(payloads['owned-resource-repair-5633c55/inspect.receipt.json']) ==
                'bcd52a4c17d506b95ff8a33bb92f7a2af96d227d1cd95db7aa610e8aaf6adeb8', 'inspection receipt differs')
        require(digest(payloads['owned-resource-repair-5633c55/delete.receipt.json']) ==
                '8d60fad1672f4dda1629f609e2aed4df6c72e4cc239b1e9ea9e418e31b6d1955', 'deletion receipt differs')
        summary = json.loads(payloads['native-continuation-5633c55/summary.json'])
        require(summary['result'] == 'FAILED_OR_BLOCKED', 'blocked continuation was relabeled')
        heavy = [row for row in summary['commands'] if row.get('blocked')]
        require(len(heavy) == 4 and all(row['exit_code'] is None and 'pid' not in row for row in heavy),
                'the zero-native resource refusal changed')
        cleanup = json.loads(payloads['owned-resource-repair-5633c55/delete.receipt.json'])
        require(cleanup['result'] == 'PASS_WHITELIST_REPAIR' and len(cleanup['deletions']) == 4 and
                cleanup['conditional_new_run_entry_16gib_met'] is False, 'cleanup outcome differs')
        evidence = json.loads(payloads['metadata_import_terminal_evidence_5633.json'])
        expected = {'parallel_main': ('1a1bc526042-138b0-1aa', 'failed', 1),
                    'bounded_io': ('1a1bc6ad0fc-138b0-257', 'succeeded', 0),
                    'da_recovery': ('1a1bc9287f7-138b0-354', 'succeeded', 0),
                    'original_node_two_case': ('1a1bcaf5f3b-138b0-408', 'succeeded', 0),
                    'native_continuation': ('1a1bcd5be33-138b0-4c5', 'failed', 1),
                    'cache_inspection': ('1a1bce1ff35-138b0-4fa', 'succeeded', 0),
                    'cache_deletion': ('1a1bce4f3dd-138b0-508', 'succeeded', 0)}
        require(set(evidence['jobs']) == set(expected), 'terminal role set differs')
        terminal = {}
        for role, want in expected.items():
            row = evidence['jobs'][role]['observed']
            require((row['job_id'], row['state'], row['exit_code']) == want and
                    row['output_complete'] and row['output_durable'] and row['terminal_publication_confirmed'],
                    'a required job lacks its exact authoritative terminal: ' + role)
            terminal[role] = row
        require(evidence['da_original_unknown']['termination_confirmed'] is False and
                evidence['da_original_unknown']['reclassified'] is False, 'historical DA unknown was relabeled')
        findings = sensitive_findings(payloads)
        if findings:
            write_new(out_fd, 'sensitive-findings.json', json_bytes({'findings': findings, 'values_disclosed': False}))
            raise ValueError('possible sensitive values detected; archive withheld')
        payloads['collection/collector.py'] = collector
        payloads['collection/required-terminal-statuses.json'] = json_bytes(terminal)
        manifest = {
            'schema': 'trnm-continuation-resource-evidence-archive-v1',
            'source_base': str(BASE), 'evidence_roots': ROOTS, 'source_files': sorted(files, key=lambda r: r['path']),
            'source_regular_files': len(files), 'source_regular_bytes': sum(r['bytes'] for r in files),
            'source_inventory': before, 'source_inventory_metadata_sha256': metadata_hash,
            'excluded_subtrees': [row for row in before if row['kind'] == 'excluded_cache_directory'],
            'exclusion_policy': {'exact_excluded_cache_subtrees': sorted(SKIP), 'large_files': 'none over 16 MiB in included inventory; unexpected large input refuses collection',
                                 'symlinks': 'never followed; metadata observed by lstat/readlink only; none present in frozen scope',
                                 'excluded_subtree_contents_enumerated_or_hashed': False},
            'frozen_runner_sha256': RUNNER_PINS,
            'continuation_result': 'FAILED_OR_BLOCKED', 'native_test_cases_executed_in_continuation': 0,
            'cleanup_result': 'PASS_WHITELIST_REPAIR', 'after_cleanup_native_started': False,
            'scope_decision_is_separate_from_raw_runtime_receipts': True,
            'native_summary_sha256': NATIVE_SUMMARY_PIN,
            'native_suite_completed': False, 'partial_records_are_full_suite_counts': False,
            'whole_chain_pq_qualified': False, 'source_repository_accessed_by_collector': False,
            'original_logs_or_runners_modified': False, 'native_commands_executed_by_collector': False,
            'secret_scan': {'scope': 'bounded high-confidence credential pattern scan; not a universal absence proof', 'findings': []},
            'archive_format': {'type': 'tar+gzip', 'member_order': 'lexicographic', 'uid': 0, 'gid': 0, 'mtime': 0, 'mode': '0644', 'gzip_mtime': 0, 'gzip_filename': ''},
            'additional_members': [{'path': path, 'bytes': len(body), 'sha256': digest(body)}
                                   for path, body in sorted(payloads.items()) if path.startswith('collection/')],
        }
        manifest_bytes = json_bytes(manifest)
        payloads['ARCHIVE-MANIFEST.json'] = manifest_bytes
        packed = archive_bytes(payloads)
        require(packed == archive_bytes(payloads), 'deterministic archive rebuild differs')
        verify_archive(packed, payloads)
        write_new(out_fd, 'continuation-resource-evidence-5633c55.tar.gz', packed)
        write_new(out_fd, 'manifest.json', manifest_bytes)
        for row in regular:
            body, _ = read_regular(base_fd, row['path'], row['stat'])
            require(body == payloads[row['path']], 'source bytes changed after archive: ' + row['path'])
        require(inventory(base_fd) == before, 'source inventory changed after archive')
        collector_after, _ = read_regular(base_fd, COLLECTOR, collector_identity)
        require(collector_after == collector, 'collector changed during collection')
        archived, _ = read_regular(out_fd, 'continuation-resource-evidence-5633c55.tar.gz')
        manifest_after, _ = read_regular(out_fd, 'manifest.json')
        require(archived == packed and manifest_after == manifest_bytes, 'published archive changed')
        verify_archive(archived, payloads)
        result = {'status': 'ARCHIVED_VERIFIED', 'output': str(BASE / OUT_NAME),
                  'archive': {'file': 'continuation-resource-evidence-5633c55.tar.gz', 'bytes': len(packed), 'sha256': digest(packed)},
                  'manifest': {'file': 'manifest.json', 'bytes': len(manifest_bytes), 'sha256': digest(manifest_bytes)},
                  'members': len(payloads), 'source_regular_files': len(files),
                  'original_evidence_read_identities_and_bytes_equal': True,
                  'source_inventory_before_after_equal': True, 'collector_before_after_equal': True,
                  'deterministic_rebuild_identical': True, 'native_tests_executed': False,
                  'whole_chain_pq_qualified': False}
        write_new(out_fd, 'collection-result.json', json_bytes(result))
        os.fsync(out_fd)
        print(json.dumps(result, sort_keys=True), flush=True)
    except Exception as error:
        if out_fd is not None:
            write_new(out_fd, 'collection-failure.json', json_bytes({'status': 'FAILED', 'error_type': type(error).__name__, 'message': str(error), 'native_tests_executed': False}))
        raise
    finally:
        if out_fd is not None:
            os.close(out_fd)
        os.close(base_fd)


if __name__ == '__main__':
    main()
