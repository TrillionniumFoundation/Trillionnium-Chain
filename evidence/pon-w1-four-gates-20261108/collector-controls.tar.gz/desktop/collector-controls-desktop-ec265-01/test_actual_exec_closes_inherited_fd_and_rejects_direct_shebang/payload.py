import os,json
values=[]
for name in os.listdir('/proc/self/fd'):
 try: values.append(os.readlink('/proc/self/fd/'+name))
 except FileNotFoundError: pass
print(json.dumps(values))
