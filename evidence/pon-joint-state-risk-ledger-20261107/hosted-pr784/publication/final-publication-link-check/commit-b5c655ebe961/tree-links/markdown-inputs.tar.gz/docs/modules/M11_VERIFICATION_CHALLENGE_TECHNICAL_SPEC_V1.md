# M11 Evaluation profile, attested trust and integer merit

Revision: invariant-driven revision3. Selected target: `pon-nakamoto-v1`.
[Sole development plan](../development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md); [exact invariant registry](../../config/pon/invariants-v2.json).

## Scope and ownership

Controlled real training and explicit evaluation producer; signatures still use the experimental attestor trust model.

The claims below apply to their named component and tests, not to an independently accepted full native node.

## PoN State machine

### M11.EvaluateFrozenModel

A candidate losing to the strongest calibration-locked control receives no improvement score; many snippets in one file are one statistical cluster. Freeze candidate/control/calibration before evaluation; calculate exact source-group sign test with multiplicity correction.

**Atomic/commit boundary:** Freeze candidate/control/calibration before evaluation; calculate exact source-group sign test with multiplicity correction.

### M11.AdmitEvaluation

Require one of three named development evaluators, not author, unique sender, expected plan and nonzero evidence. First2 valid attestations freeze minimum score; no extra votes change it. This admits attestation truth, not objectively recomputed ML correctness.

**Atomic/commit boundary:** Votes embedded in contribution state; no chainwork or validationmembership mutation.

## M11.StrongClusterControl

**Invariant:** A candidate losing to the strongest calibration-locked control receives no improvement score; many snippets in one file are one statistical cluster.

**Scope:** Controlled real training and explicit evaluation producer; signatures still use the experimental attestor trust model.

**Atomic boundary:** Freeze candidate/control/calibration before evaluation; calculate exact source-group sign test with multiplicity correction.

**Failure schedule:** Best single stronger than base; Candidate loses to best control; One hundred snippets from one source; Caller labels data future.

**Expected result:** A candidate losing to the strongest calibration-locked control receives no improvement score; many snippets in one file are one statistical cluster.

**Resource and retention rule:** At least20 clusters, four-comparison correction, integer/Fraction arithmetic; public reward eligibility stays false without owner-verified evidence.

## Concrete regression selectors

`formal/pon-nakamoto-v1/test_evaluation.py::ModelGateTests.test_stronger_single_control_not_weak_base_is_selected`

`formal/pon-nakamoto-v1/test_evaluation.py::ModelGateTests.test_improving_over_base_but_losing_to_control_is_not_rewarded`

`formal/pon-nakamoto-v1/test_evaluation.py::ModelGateTests.test_snippets_from_one_file_do_not_become_independent_samples`

`formal/pon-nakamoto-v1/test_evaluation.py::ModelGateTests.test_positive_cluster_result_does_not_mint_future_acceptance`

These exact functions contain executable assertions. The registry only checks binding; actual outcomes and source/input identities belong to the separate qualification report.

## Bounded integer normal form reused by native admission

[`exact_integer_linear_v1::verify_integer_linear_v1`](../../trillionnium/crates/trnm-verification-profiles/src/exact_integer_linear_v1.rs)
checks its frozen3×257 integer family, rank1..8, scale/range and full BA values.
Its opaque result authenticates that arithmetic contract, not a caller's current
model, State parent, source permission, functional behavior or reward. The explicit
[M06 revision11 admission](../protocol/pon-nakamoto-v1/details/NATIVE_INTEGER_FACTOR_CANDIDATE_V2.md)
separately loads the complete V2 model and restricts rank to1..2 before reusing this
kernel. The two family domains are distinct. The
[component contract](../protocol/pon-nakamoto-v1/details/INTEGER_LINEAR_NORMAL_FORM_COMPONENT_V1.md)
records canonical identity and exact bounds; it is not FP32 LoRA equivalence,
complementary-bundle attribution or an independent strongest-control quality test.

## Module-specific threat and residual work

Weak baselines, correlated samples, adaptive holdout reuse, poisoned evaluators and first-two arrival manipulation.

Fresh future windows, independent evaluators and a public dispute/aggregation profile are still required.

## Current source and verification

- [`formal/pon-nakamoto-v1/evaluation.py`](../../formal/pon-nakamoto-v1/evaluation.py).
- [`formal/pon-nakamoto-v1/experiments/model_loop.py`](../../formal/pon-nakamoto-v1/experiments/model_loop.py).

No test binding or local campaign grants independent acceptance, ordinary Hepta execution or production activation. Preserve the exact source, profile and environment of every outcome.

## Executed evidence and scope

[Responsibility-level evidence navigation](README.md#responsibility-and-evidence) reads
measured commits from immutable receipts. The module's entries in
[module-maturity-v1.json](../../config/pon/module-maturity-v1.json) identify actual callable
owners, controlled entrypoints, backends, persistence and exact observed test selectors.
Run `python3 scripts/ci/report_module_evidence.py --module M11` from the repository
root to see subject-byte and complete recorded-runtime matches separately, plus scenarios
not observed in each package. A byte match is not a new test run or product acceptance.
Historical v1/v3/v4 results are never repinned. The sole plan selects further work.

## Frozen evaluation and consent continuation

See [E3](../protocol/pon-nakamoto-v1/details/EVALUATION_BUNDLE.md) for exact bytes,
owner boundaries and failure schedules. No public export or future-window authority
is created by a frozen artifact. The following additional regressions are executable:

- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::StatisticalBoundaryTests.test_calibration_weights_source_groups_not_number_of_snippets`.
- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::StatisticalBoundaryTests.test_positive_direction_majority_with_negative_mean_is_rejected`.
- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::FrozenEvaluationTests.test_every_control_parameter_is_bound_before_inference`.
- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::FrozenEvaluationTests.test_input_label_content_identity_and_group_substitution_reject`.
- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::EvaluationWorkerTests.test_legacy_unbound_reference_cannot_authorize_evaluation`.

Actual producer/evaluator implementation: `formal/pon-nakamoto-v1/evaluation_bundle.py`;
normal controlled worker and three-attempt caller consume it rather than a parallel trainer.

Calibration claims are recomputed, not accepted merely because a producer can hash them:

- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::FrozenEvaluationTests.test_self_consistent_rehashed_calibration_score_still_requires_actual_replay`.
- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::FrozenEvaluationTests.test_changed_calibration_data_cannot_be_substituted`.

## Native development continuation and remaining scope

Statement classes and the difference between retrospective gain, prospective benefit and bounded optimality are explicit in MODEL_EVALUATION. No optimality verifier or independent future-window authority has been admitted. Revision3 first-two evaluation order remains an explicit successor-policy obligation.

The current callable mappings remain in `config/pon/module-maturity-v1.json`.
Exact native entry, storage and work behavior is specified by N3 in NETWORK_CLIENT,
the native continuation in STATE_RECOVERY and the prepared-producer section in WORK_PROFILE.
No historical receipt is relabelled as executing this source.

The existing frozen evaluator and settlement producer also bind the versioned empirical
accuracy/marginal-value/bound statement in MODEL_EVALUATION. Its canonical replay rejects
false prospective/general-circuit authority and numeric aliases. A perfect empirical
score proves only that fixed accuracy objective, not public reward eligibility or model
safety. Revision3 first-two attestation arrival semantics remain unchanged and unqualified.

## Explicit successor without rewriting revision3

[M1 closed-round successor](../protocol/pon-nakamoto-v1/details/MODEL_EVALUATION.md#explicit-closed-round-successor-all-eligible-attestations-not-first-arrivals)
adds a profile-bound all-eligible minimum rule in the existing M11/M06 owners.
The default first-two rule and its economic counterexample remain historical/default
facts, not silently repaired bytes. The selected successor requires a fresh network and
store context. No attestation becomes objective ML truth, independent acceptance or work.

Concrete selectors: `formal/pon-nakamoto-v1/test_evaluation_round.py::ClosedRoundTests.test_all_six_arrival_orders_close_to_the_same_state_with_all_workers`
and `formal/pon-nakamoto-v1/test_evaluation_round.py::ClosedRoundTests.test_two_fast_high_scores_do_not_unlock_and_missing_vote_expires`.

### M11.CompleteEvaluatorRound

The explicit successor closes only the complete frozen eligible roster. Its exact
counterexamples above compare all arrival orders and withheld/expired evidence. This
invariant applies to a fresh revision4 context; the registry's genesis revision remains
the unchanged installed revision3 default. No new authority is obtained by choosing a
profile or by registering a test selector.

## Native full evidence replay in the explicit model profile

[Model evidence v3](../protocol/pon-nakamoto-v1/details/NATIVE_MODEL_EVIDENCE_V3.md) installs actual frozen tasks and four complete retained controls, recomputes candidate/parent/control scores in M06, and requires every signed reveal to match native score and digest. This finite statement is executable. Source attestations, hidden common control, general LLM behavior, prospective gain and public dispute adjudication remain distinct obligations.

## Explicit revision16 task binding

The separate [revision16 model evolution](../development/specs/pon/MODEL_EVOLUTION_V5.md)
reuses this quorum algorithm while native inference observes the enabled expert
mask and full changed model. Its optional [owner-pinned task windows](../development/specs/pon/MODEL_TASK_WINDOWS_V1.md)
bind source snapshot/content hashes, complete task roots and ordered activation
rounds before genesis. The submission round selects the same window for the
parent, candidate and four controls; the selected root enters the frozen quorum
generation context. Two six-text controlled windows test actual source loading,
activation and no cross-window evidence reuse. Fixed owner signatures and new
fixture bytes do not prove independent evaluators, truthful labels, private
future-task custody, live governance or production generalization.

## Explicit revision15 evaluation liveness

[Native evaluation quorum V2](../protocol/pon-nakamoto-v1/details/NATIVE_EVALUATION_QUORUM_V2.md)
adds a fresh selector for the fully replayed native V3/V4 models. Four controlled
development keys freeze the non-author roster and `ceil(2*n/3)` real matching
reveals; a disqualified key remains in the denominator and cannot count. One
missing key therefore does not automatically abort an otherwise sufficient
evaluation. The original complete-roster and hash-appeal-hold rules remain under
their old selector.

Signed equivocation affects the actual key, and the same native adoption
transaction rechecks global disqualifications for bundle and components. An
opaque tag17 appeal remains an audit record without an automatic veto. New
round/reveal/closure/storage domains and an actual-parent/dataset/round generation
commitment prevent replay across contexts. Neither this threshold nor the fixed
four keys establish BFT finality or independently governed evaluators. The25
public retrospective tasks remain finite; future-window custody and activation
are not supplied by this liveness increment. Insufficient evidence and zero gain
remain bounded no-update outcomes.

## Native composition evaluation in revision14

[Model composition V4](../protocol/pon-nakamoto-v1/details/NATIVE_MODEL_COMPOSITION_V4.md)
reuses the complete integer inference kernel,25 public historical tasks and four
frozen controls. It evaluates each full component and every exact leave-one-out
model against the actual current full parent; caller-supplied allocation weights
must match those measured gains. The two-generation fixture adopts a24/25 parent
before evaluating the next25/25 bundle, so the second parent is an actual release.

A component with zero standalone gain may participate only in this fresh profile
when its exact omission reduces the bundle score. Exact-zero subset rejection closes
the known cancelling-pair example; it does not establish coalition fairness, causal
training effort or protection against general component splitting. The fixed corpus
saturates at25/25 and supplies no next untouched evaluation window. Independent
prospective usefulness and public model rewards remain unaccepted.

A separate Python integer implementation now compares all42 named native codec,
composition, inference, tie, range and exactly cancelling subset observations, and the
actual signed lifecycle's full empirical/composition records. It recomputes expected
scores and digests from model bytes and frozen tasks; reported native score fields
cannot supply the answer. This conformance layer leaves signatures, roster closure,
ILF2 witness validity and future-task custody as separately scoped premises.

## Bounded reported-window continuity

The optional [model window history](../protocol/pon-nakamoto-v1/details/MODEL_OPERATIONS_ACCEPTANCE_V1.md#explicit-continuation-across-reported-evaluation-windows)
requires externally fixed previous-history and new-window digests. Ordered rows
rebuild prior task/probe prompts and contacted source groups; new evaluation must
pass current V1 record validation and historical exclusions. Complete valid negative-gate
records consume their window, and preregistration reserves enough bytes for the
mandatory completed row. Candidate changes are allowed within a fixed owner and
governance context. This pure sidecar does not authenticate historical execution,
secret custody, real time or unreported exposure, and grants no native reward.
