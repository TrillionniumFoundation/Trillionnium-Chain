"""Replay 32 reduced-domain accounting controls; no horizon or hardware claim."""
import argparse
from dataclasses import asdict
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=Path.cwd())
    args = parser.parse_args()
    repo = args.repo.resolve()
    formal = repo / "formal/pon-nakamoto-v1"
    if not (formal / "w1_marked_domain.py").is_file():
        parser.error("--repo or cwd must identify the Trillionnium-Chain repository")
    sys.path.insert(0, str(formal))
    from test_w1_quantum_oracle import fixture
    from w1_quantum_oracle import FixedTemplate, Shape
    from w1_marked_domain import enumerate_domain, simulate_measurements
    from quantum_adversarial_search import TrialCosts

    def target_one(template):
        header = bytearray(template.header)
        offset = 118 + (4 if template.profile == "PGH2" else 0)
        header[offset:offset + 32] = (1).to_bytes(32, "big")
        return FixedTemplate.from_header(bytes(header), template.a, template.b,
                                         template.nonce_bits, template.shape)

    def ratio(value):
        return Fraction(value["numerator"], value["denominator"])

    def require(condition, label):
        if not condition:
            raise AssertionError(label)

    shape = Shape(1, 1, 4, 1)
    plain = fixture(shape, nonce_bits=2)
    growth = fixture(shape, profile="PGH2", nonce_bits=2)
    empty = enumerate_domain(target_one(plain))
    other_empty = enumerate_domain(target_one(growth))
    all_marked = enumerate_domain(plain)
    require(empty["marked_count"] == other_empty["marked_count"] == 0, "M=0 fixtures")
    require(all_marked["marked_count"] == all_marked["domain_size"], "M=N fixture")
    scenarios = (
        ("retry_empty", (empty,), ((0, 0), (0, 1), (0, 100)), 3, 1, False),
        ("eviction_empty", (empty, other_empty),
         ((0, 0), (0, 1), (1, 2), (1, 3), (0, 4)), 5, 3, False),
        ("duplicate_alias", (empty, empty), ((0, 0), (1, 1), (0, 2)), 3, 1, False),
        ("proof_once_stop", (all_marked,), ((0, 0), (0, 1), (0, 2)), 1, 1, True),
    )
    records = []
    for costs in (TrialCosts(1, 2, 3, 5, 7, 11, "upward"),
                  TrialCosts(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, "upward")):
        for processors in (1, 2, 4, 64):
            for label, domains, schedule, used, setups, won in scenarios:
                observed = simulate_measurements(domains, schedule, processors, 19, costs)
                clock = lambda name: Fraction(getattr(costs, name))
                # Independent closed form over the known executed schedule prefix.
                iterations = sum(count for _, count in schedule[:used])
                coherent = (used * (clock("prepare_seconds") + clock("measurement_seconds"))
                            + iterations * clock("iteration_seconds"))
                expected = (setups * clock("domain_setup_seconds") + coherent
                            + used * processors * clock("candidate_check_seconds")
                            + int(won) * clock("proof_seconds"))
                require(ratio(observed["elapsed_assumed_seconds_exact"]) == expected, label)
                require(ratio(observed["coherent_processor_seconds_exact"])
                        == processors * coherent, label + ": coherent")
                require(observed["domain_setup_charges"] == setups, label + ": setups")
                require(observed["unused_predeclared_trials"] == len(schedule) - used,
                        label + ": stop")
                require(observed["success"] == won, label + ": success")
                require(sum(len(trial["measurements"]) for trial in observed["trials"])
                        == used * processors, label + ": all measured candidates")
                records.append({"case": label, "processors": processors,
                                "fractional_clock": costs.prepare_seconds == 0.1,
                                "elapsed_exact": str(expected), "setup_charges": setups,
                                "candidate_checks": used * processors, "proofs": int(won),
                                "result": "PASS"})
    sources = ("w1_marked_domain.py", "quantum_adversarial_search.py",
               "w1_quantum_oracle.py", "test_w1_quantum_oracle.py")
    print(json.dumps({
        "result": "PASS", "cases": records, "independent_formulas": True,
        "finite_horizon_parameter_exists": False, "same_resource_production_claim": False,
        "repo_changes": False, "source_sha256": {
            name: hashlib.sha256((formal / name).read_bytes()).hexdigest() for name in sources},
        "control_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "cost_inputs": [asdict(TrialCosts(1, 2, 3, 5, 7, 11, "upward")),
                        asdict(TrialCosts(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, "upward"))],
    }, indent=2))


if __name__ == "__main__":
    main()
