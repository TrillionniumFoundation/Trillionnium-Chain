#!/usr/bin/env python3
"""Package observed evidence without relabeling development or prior-tree results."""
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

BASE = Path('/workspace/scratch/525798dad3c2')
ROOT = BASE / 'Trillionnium-Chain'
VALIDATION = BASE / 'validation'
OUT = ROOT / 'evidence/pon-demand-evaluation-upgrade-20261107'
LOCAL = '99220dd03626760d6cb015f66bb133d1d61217ec'
PUBLIC = 'ed0ad15c5aaf0b0ca0c6edbb1c67b9976a5019dd'
TREE = 'a4db639e2c346b914ade186697182727a7e43ca4'
OUT.mkdir(exist_ok=False)


def digest(data):
    return hashlib.sha256(data).hexdigest()


receipts = []
for path in sorted((VALIDATION / 'frozen').glob('final-*.json')):
    row = json.loads(path.read_text())
    assert row['exit_code'] == 0 and row['source_unchanged'] is True
    assert row['before'] == row['after']
    assert row['before']['commit'] == LOCAL and row['before']['tree'] == TREE
    log = (path.parent / row['log']).read_bytes()
    assert row['log_sha256'] == digest(log)
    counts = re.findall(r'Ran (\d+) tests?', log.decode())
    rust = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed', log.decode())
    receipts.append(dict(label=path.stem, exit_code=row['exit_code'],
        elapsed_seconds=round(row['elapsed_seconds'], 3),
        python_test_counts=[int(x) for x in counts], rust_test_counts=rust,
        receipt='validation/frozen/' + path.name, log='validation/frozen/' + row['log'],
        log_sha256=row['log_sha256']))
assert len(receipts) == 15

members = []
for path in sorted(VALIDATION.rglob('*')):
    if path.is_file():
        members.append(('validation/' + path.relative_to(VALIDATION).as_posix(), path.read_bytes()))
for name in ['record_validation.py', 'run_final_validation.py', 'observe_toolchain.py',
             'cargo-task.sh', 'export_publish_tree.py', 'build_demand_evidence.py']:
    members.append(('tooling/' + name, (BASE / name).read_bytes()))
members.sort()
archive = OUT / 'observations.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as tar:
    for name, data in members:
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
index = [dict(path=name, bytes=len(data), sha256=digest(data)) for name, data in members]
index_text = '{\n  "schema": "pon-demand-observation-index-v1",\n  "members": [\n'
index_text += ',\n'.join('    ' + json.dumps(row, sort_keys=True) for row in index)
index_text += '\n  ]\n}\n'
(OUT / 'observations-index.json').write_text(index_text)
with tarfile.open(archive, 'r:xz') as tar:
    assert len(tar.getmembers()) == len(index)
    for item in index:
        data = tar.extractfile(item['path']).read()
        assert len(data) == item['bytes'] and digest(data) == item['sha256']

mapping = json.loads((VALIDATION / 'publication-source-map.json').read_text())
assert mapping['local_source_commit'] == LOCAL and mapping['published_source_commit'] == PUBLIC
assert all(c['tree_equal'] for c in mapping['commits'])
(OUT / 'publication-source-map.json').write_text(json.dumps(mapping, indent=2, sort_keys=True) + '\n')
summary = dict(schema='pon-demand-evaluation-upgrade-validation-v1',
    local_executed_commit=LOCAL, published_source_commit=PUBLIC, source_tree=TREE,
    publication_method='Git Data; all ten source trees independently matched local trees',
    native_public_git_fetch_verified=True,
    source_manifest=receipts and json.loads((VALIDATION / 'frozen/final-preflight.json').read_text())['before'],
    prior_frozen_commit='a4121fe4e0c0e2c479fa89a6bc81a500b1414904',
    prior_results_transferred_to_final=False, commands=receipts,
    native_integration_tests=2, native_integration_backend_scenarios=6,
    demand_tests=29, upgrade_tests=23,
    root_cargo_graph=dict(workspace_members=26, packages=180, resolve_nodes=180),
    fuzz_cargo_graph=dict(workspace_members=1, packages=147, resolve_nodes=147),
    full_node_lib_harness_qualified=False, independent_demand_proven=False,
    native_demand_export_adapter_implemented=False, real_training_measured=False,
    real_independent_evaluation_measured=False, hepta_current_adoption_qualified=False,
    production_activation=False, archive=dict(path=archive.name, bytes=archive.stat().st_size,
        sha256=digest(archive.read_bytes()), members=len(members)))
(OUT / 'validation-summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')

readme = f'''# Funded demand, evaluation and upgrade: frozen implementation evidence

Status: **reviewable candidate; HOLD for full native/external acceptance**.
The [sole plan](../../docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md)
and [contract](../../docs/development/specs/pon/DEMAND_EVALUATION_UPGRADE_V1.md)
retain the original consensus, PQ, work-security and activation decisions.

## Exact source and publication

- Executed local commit: `{LOCAL}`.
- Published source commit: `{PUBLIC}`.
- Complete shared source tree: `{TREE}`.
- Initial integration base: `3d1b6507671ec694ce58e86d4063a125c8deeb66`.
- Preserved concurrent integration head: `adebe0bd78e6e1bdb55a599179ffe2313997170e`.

HTTPS Git push had no shell credentials. Authenticated Git Data publication
preserved ten separate source commits and verified every returned Git tree against
its local counterpart. Commit metadata differs; the executed commit must not be
renamed to the published SHA. [The mapping](publication-source-map.json) retains
both identities. An ordinary public Git fetch then confirmed the published source
commit and complete tree. The archive includes a Git bundle of the local source
history with its verification log and prerequisite base.

Every final command captured all tracked bytes, blob IDs, modes and SHA-256 hashes
before and after execution. All 15 final commands ran against the local commit
above, with a clean source and unchanged complete manifests. Earlier frozen
`a4121fe4` results remain separately named and were not transferred to this tree.
This evidence-only continuation does not claim that subsequently added archive
bytes were present during runtime tests.

## Actual results

| Final gate | Observed result | Archive log |
| --- | --- | --- |
| New demand and upgrade references | 52 passed: demand 29, upgrade 23 | `final-new-references.log` |
| Retained model/reward/evaluation boundaries | 131 passed | `final-retained-model-boundaries.log` |
| M12, all targets and features | 49 passed | `final-m12.log` |
| Native Node NoGain integration target | 2 passed; 6 backend scenarios | `final-native-no-gain.log` |
| CI registration/mutation controls | 102 passed | `final-ci-contract.log` |
| Source-integrity, PQ and repository negatives | 130 passed | `final-source-integrity.log` |
| Strict workspace Clippy, all targets/features | exit 0; `-D warnings` | `final-strict-clippy.log` |
| Workspace formatting | exit 0 | `final-rustfmt.log` |
| Locked/offline root Cargo graph | 26 members; 180 resolved packages | `final-root-cargo-graph.log` |
| Locked/offline fuzz Cargo graph | 1 member; 147 resolved packages | `final-fuzz-cargo-graph.log` |
| Repository and local Markdown links | exit 0; 3,464 links checked | `final-repository.log` |
| Source-pin corpus | 564 exact blobs; original HOLD flags retained | `final-pq-source-pins.log` |
| Project boundary and patch whitespace | both exit 0 | `final-preflight.log`, `final-patch-whitespace.log` |
| Selected tools and lock identities | exit 0; versions and SHA-256 captured | `final-toolchain.log` |

All log paths above have prefix `validation/frozen/` inside the archive. Commands,
exit codes, timings and source identities are in matching JSON receipts and the
[machine summary](validation-summary.json). Expected mutant `FAIL` observations
inside a passing negative-test suite are not failed whole-suite executions.
No Cargo lock, compiler optimization, debug profile or lint requirement was
relaxed to obtain these results.

## What the native tests establish

The [public-API integration target](../../trillionnium/crates/trnm-pon-node/tests/no_gain_fees.rs)
executes real signed Task reserve, provider output and payer acceptance through
the local Node. Task/Contribution and Task/Evaluation each run on Legacy,
Authenticated and Growth backends, with exact provider credit of 2,000 native
development units. Actual native payment readback and a completed M12 effect are
both required. Missing payment, incomplete effect, conflicting operation, a second
nonce payment and NoGain-to-Positive relabel are refused.

Each scenario closes/reopens twice and activates a stronger branch that removes
current payment membership. Historical M12 operation/payment facts remain;
completed effects cannot be redispatched or claimed again. No model, release or
contribution record is created by that negative-result service fee.

The NoGain outcome, resources and training material are controlled test inputs.
These are not six independently operated organizations, six beneficial model
upgrades or a real training benchmark. SQLite I/O-boundary `UNQUALIFIED` output
remains an unqualified boundary. The target does not replace the failed full Node
unit-test harness described below.

## Preserved failures and adversarial repair

[Failure provenance](failures.md) identifies setup failures, the unresolved full
Node lib compilation SIGKILL, and the original observer counterexamples.
The archive retains runnable attacks, old source pairs and before/after outputs.
Later fixes include expired provenance in queue selection and the cross-account
reviewer bonus attack: a fixed evaluation fee of 7 had allowed 5 extra bonus units
for a positive vote. The provider-only bonus beneficiary rule now refuses that
contract for evaluators, auditors and adoption owners, even with valid signatures.
All reported Python receipts remain synthetic; no production payment capability
is created. Legitimate provider bonuses and unknown-origin queue controls remain.

## Evidence archive

- [observations.tar.xz](observations.tar.xz): {len(members)} members, {archive.stat().st_size:,} bytes.
- SHA-256: `{digest(archive.read_bytes())}`.
- [Member index](observations-index.json): exact path, size and SHA-256 for every member.

The archive includes original and final command logs, complete source manifests,
development failures, attack scripts and snapshots, local Git history, publication
identity checks and the exact execution wrapper/recorders. It contains no live
service data, account credentials or user keys; deterministic test keys are
explicitly synthetic fixtures. Archive members were reopened and matched to
every indexed hash before committing this record.

## Acceptance that remains open

The demand observer and upgrade policy do not export or enforce native funding,
dispatch tasks, pay bonuses, install a model or prove independent demand. Their
authorization flags remain false. Full native statement export/reconciliation,
request/model/output-bound admission, enforceable dispute resolution, durable
cross-epoch evidence ownership, audited independent customers/evaluators and
fresh cost-matched evaluation still need their actual owners and evidence.
Ordinary Hepta canary/install/next-task/rollback and full Node harness qualification
also remain open. A capped subsidy bounds exposure; it does not make an internal
customer/provider transfer proof of outside demand.

The upgrade error bound is conditional on full-history sampling assumptions and
retained attempt history. Exact rational arithmetic does not certify cost truth,
freshness, causal adoption or permanent improvement. No production activation,
main merge, release approval or independent-acceptance declaration is made here.
'''
(OUT / 'README.md').write_text(readme)

failures = '''# Failures and their disposition

Raw observations are inside `observations.tar.xz`; paths below start at `validation/`.

| Observation | Original evidence | Disposition |
| --- | --- | --- |
| Offline Node build missing `foreign-types 0.3.2` | `node-build.log` | Original locked dependencies fetched through the ordinary configured network; lockfiles unchanged. `cargo-fetch.log` retained. |
| Full Node lib test harness compilation terminated by SIGKILL, exit 101 | `node-build-2.log` | Unresolved qualification gap. This was a pre-freeze development build, without a full exact-source receipt. Do not claim a full Node test pass or a proven cause of the signal. |
| Wrong fuzz manifest path under `trillionnium/tests` | `frozen/fuzz-cargo-graph.{json,log}` | Failed command preserved. Correct root `tests/fuzz/Cargo.toml` graph passed separately on both frozen source versions. |
| Initial seven demand counterexamples | `demand-adversarial-before.*`, `demand-adversarial-before-source/` | Original time-travel dispute/bonus, net-fee outcome dependence, retroactive control audit, same-candidate bonus replay and spent-source queue classifications preserved. Corrected source and final runs are separate. |
| Refund/unresolved queue and no-delivery pay-service cases | `demand-adversarial-refund-{before,after}.{json,log}` | Fixed with explicit dispute/delivery eligibility; refusals preserve snapshots. |
| Audit expiry after observation | `demand-provenance-expiry-{before,after}-result.{json,log}` | V2 observations retain provenance expiry; later queue queries exclude expired attached attestations. Original source pair and runnable probe retained. |
| Evaluator/auditor/adopter as improvement beneficiary | `demand-bonus-recipient-{before,after}-result.{json,log}` | Provider-only improvement beneficiary; valid re-signed contracts cannot route positive-result bonus to a reviewer account. Original script retained. |
| Upgrade development fixture supplied bet greater than 1 | Contemporaneous worker report: 20 passed, 1 error; no raw log available | Corrected the invalid fixture, not the admissible bet rule. This report is not fabricated into a raw observation. Final 23 upgrade tests passed in both frozen runs. |
| Git HTTPS dry-run lacked terminal credentials | `publish-dry-run.log` | Used the existing authenticated GitHub connector, preserved review commits and checked each returned tree; ordinary public Git fetch independently read the result. |

An initial publication payload export exceeded its chosen output budget before any
API mutation; bounded chunk reads replaced it. No runtime pass is inferred from
that transport repair. Source-check negative tests intentionally preserve expected
fixture failures, while the containing test suite must actually exit successfully.

The new Node integration target exercises six local backend scenarios through real
native APIs. It neither reruns the failed monolithic lib harness nor certifies the
SQLite I/O boundary, production economics, real training or external independence.
'''
(OUT / 'failures.md').write_text(failures)
print(json.dumps(dict(directory=str(OUT), members=len(members), archive_bytes=archive.stat().st_size,
                     archive_sha256=digest(archive.read_bytes()), final_commands=len(receipts))))
