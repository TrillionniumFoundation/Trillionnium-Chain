from pathlib import Path
import subprocess,json,hashlib,time,resource,sys,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');old=src.parent/'authority-source-lock-edit-1';out=src.parent/'authority-source-lock-edit-2';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
res={'schema':'chain-authority-current-source-repair-v2','head':'f0a8364118df01113c14d6a81fbb6fdb6210e4ff','prior_failed_preparation':str(old/'RESULT.json'),'stages':[],'complete':False,'native_qualification':False,'f0_qualification':False}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,cmd):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(cmd,cwd=src,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);r={'name':name,'command':cmd,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['stages'].append(r);save();print(json.dumps(r),flush=True);assert rc==0
try:
 run('preflight',['bash','scripts/project-preflight.sh'])
 paths=['config/pon/pq-authority-effects-v1.json','scripts/ci/pq_authority_effect_register.py','scripts/ci/test_pq_authority_effect_register.py','docs/security/PQ_AUTHORITY_EFFECT_REGISTER_V1.md','docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md']
 doc=src/paths[3];raw=doc.read_text();a=raw.index('## Current candidate correspondence, 2026-11-19');b=raw.index('## Selected source correspondence after ordering review, 2026-11-14');part=raw[a:b];part=part.replace(chr(92)+chr(96),chr(96));doc.write_text(raw[:a]+part+raw[b:])
 m=json.loads((src/paths[0]).read_text());before=json.loads((old/(paths[0].replace('/','__')+'.before')).read_text());audit=[]
 for p,d in m['source_files_sha256'].items():
  raw=subprocess.check_output(['git','show',res['head']+':'+p],cwd=src);actual=(src/p).read_bytes();assert raw==actual and hashlib.sha256(raw).hexdigest()==d
  blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();audit.append({'path':p,'git_blob':blob,'size':len(raw),'old_sha256':before['source_files_sha256'][p],'sha256':d})
 lock=hashlib.sha256(json.dumps({'source_revision':m['source_revision'],'files':m['source_files_sha256']},sort_keys=True,separators=(',',':')).encode()).hexdigest();assert lock in (src/paths[1]).read_text() and lock in (src/paths[2]).read_text()
 assert len(audit)==44 and sum(r['old_sha256']!=r['sha256'] for r in audit)==1
 for key in m:
  if key!='source_files_sha256':assert m[key]==before[key]
 corpus_path='config/pon/pq-cross-branch-corpus-v1.json';corpus=json.loads((src/corpus_path).read_text());oldcorpus=json.loads((old/(corpus_path.replace('/','__')+'.before')).read_text());assert corpus==oldcorpus
 changes=[]
 for p in paths:
  if p not in corpus['pinned_blobs']:continue
  raw=(src/p).read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();changes.append({'path':p,'old':corpus['pinned_blobs'][p],'new':blob});corpus['pinned_blobs'][p]=blob
 assert set(r['path'] for r in changes).issubset(set(paths)) and set(paths[:3]).issubset(set(r['path'] for r in changes))
 (src/corpus_path).write_text(json.dumps(corpus,indent=2,sort_keys=True)+'\n')
 res['audit']=audit;res['lock']=lock;res['corpus_changes']=changes;save()
 run('reader',['python3','scripts/ci/pq_authority_effect_register.py'])
 run('adversarial-controls',['python3','-m','unittest','discover','-s','scripts/ci','-p','test_pq_authority_effect_register.py','-v'])
 run('whitespace',['git','diff','--check'])
 patch=subprocess.check_output(['git','diff','--',*paths,corpus_path],cwd=src);(out/'source.patch').write_bytes(patch);res['patch']={'bytes':len(patch),'sha256':hashlib.sha256(patch).hexdigest()};res['files']=[{'path':p,'size':(src/p).stat().st_size,'sha256':hashlib.sha256((src/p).read_bytes()).hexdigest()} for p in paths+[corpus_path]];res['complete']=True;save();print(json.dumps({'complete':True,'lock':lock,'corpus_changes':changes,'patch':res['patch'],'files':res['files']},indent=2),flush=True)
except BaseException as e:
 res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
