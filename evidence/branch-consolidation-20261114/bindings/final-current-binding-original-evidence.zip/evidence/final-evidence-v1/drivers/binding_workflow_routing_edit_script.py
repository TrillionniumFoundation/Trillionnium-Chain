from pathlib import Path
import ast,difflib,hashlib,json,os,subprocess,sys,time
root=Path('/private/tmp/chain-final-current-bindings-20261114')
out=Path('/private/tmp/chain-final-current-bindings-evidence-20261114/workflow-routing-fix-v1');out.mkdir()
(out/'pid.json').write_text(json.dumps({'pid':os.getpid(),'started':time.time()})+'\n')
env={**os.environ,'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','GIT_NO_LAZY_FETCH':'1','TMPDIR':'/private/tmp/chain-final-current-bindings-evidence-20261114/final-checkpoint-v1/canonical-tmp','PYTHONDONTWRITEBYTECODE':'1','GIT_PAGER':'cat','PAGER':'cat'}
with (out/'preflight.stdout').open('xb') as so,(out/'preflight.stderr').open('xb') as se:
    assert subprocess.run(['bash','scripts/project-preflight.sh'],cwd=root,env=env,stdout=so,stderr=se).returncode==0
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-c','core.commitGraph=false',*args],cwd=root,env=env)
def once(s,old,new):
    assert s.count(old)==1,(old,s.count(old))
    return s.replace(old,new)
p='scripts/ci/test_w1_qrom_workflow_gate.py'
before=(root/p).read_bytes();s=before.decode()
old="""REQUIRED_STAGES = (
    'observations', 'checkout', 'source_before', 'preflight', 'named_tests',
    'historical_controls', 'implementation', 'current_implementation',
    'budget_unknown', 'budget_hypothetical',
    'report_scopes', 'source_after',
)
"""
new="""# Independent current-job stage contract; the historical name runner stays separate.
REQUIRED_STAGES = (
    'observations', 'checkout', 'source_before', 'preflight', 'named_tests',
    'historical_drift', 'implementation',
    'supplemental_historical_controls', 'supplemental_historical_mapping',
    'supplemental_current_mapping', 'supplemental_budget_unknown',
    'supplemental_budget_hypothetical', 'supplemental_report_scopes', 'source_after',
)
"""
s=once(s,old,new)
old="""        historical_job = cls.workflow_text.split(
            '  qrom-historical-implementation:\\n', 1)[1].split(
            '  qrom-current-implementation:\\n', 1)[0]
        cls.codes = {step: embedded_python(historical_job, step)
                     for step in ('named_tests', 'report_scopes', 'status')}
"""
new="""        historical_job, current_job = cls.workflow_text.split(
            '  qrom-historical-implementation:\\n', 1)[1].split(
            '  qrom-current-implementation:\\n', 1)
        # Original named-runner controls belong to the fixed historical job.
        # Relocated mapping/budget controls belong to the current supplemental step.
        cls.codes = {
            'named_tests': embedded_python(historical_job, 'named_tests'),
            'report_scopes': embedded_python(current_job, 'supplemental_report_scopes'),
        }
        if REQUIRED_STAGES != current_ci.REQUIRED_STAGES or any(
                current_job.count('        id: ' + stage + '\\n') != 1
                for stage in REQUIRED_STAGES):
            raise ValueError('independent current stage roster differs from the actual workflow')
        verify_command = (
            '          python3 scripts/ci/w1_qrom_current_ci.py verify '
            '--repo-root "$GITHUB_WORKSPACE" --out "$w1_qrom_current_out" '
            '--kind "$SOURCE_KIND" --expected-source "$EXPECTED_SOURCE" '
            '--expected-head "$EXPECTED_HEAD" --expected-base "$EXPECTED_BASE" '
            '2>&1 | tee "$w1_qrom_current_out/current-ci-status.log"\\n')
        if current_job.count(verify_command) != 1 or current_job.count(
                '          W1_QROM_CURRENT_STEP_RESULTS: $' + '{{ toJSON(steps) }}\\n') != 1:
            raise ValueError('current final gate invocation differs')
        cls.current_roster, cls.current_roster_bytes = current_ci.load_roster(ROOT)
        with tempfile.TemporaryDirectory(prefix='current-workflow-drift-') as directory:
            cls.current_drift = current_ci.observe_drift(ROOT, Path(directory))
            cls.drift_stdout = (Path(directory) / 'historical-on-current.stdout.log').read_bytes()
            cls.drift_stderr = (Path(directory) / 'historical-on-current.stderr.log').read_bytes()
"""
s=once(s,old,new)
s=once(s,"            'W1_QROM_STEP_RESULTS': json.dumps(steps), 'SOURCE_KIND': 'head',\n","            'W1_QROM_STEP_RESULTS': json.dumps(steps),\n            'W1_QROM_CURRENT_STEP_RESULTS': json.dumps(steps), 'SOURCE_KIND': 'head',\n")
s=once(s,"        source_root = ROOT if step == 'report_scopes' else root\n","        source_root = ROOT if step in ('report_scopes', 'status') else root\n")
old="""                exec(compile(self.codes[step], str(WORKFLOW) + ':' + step, 'exec'),
                     {'__name__': '__main__'})
"""
new="""                if step == 'status':
                    # Call the same production CLI selected by the exact workflow
                    # command above; no test-side reconstruction of verify logic.
                    argv = ['w1_qrom_current_ci.py', 'verify', '--repo-root', str(ROOT),
                            '--out', str(out), '--kind', 'head', '--expected-source', HEAD,
                            '--expected-head', HEAD, '--expected-base', BASE]
                    with mock.patch.object(sys, 'argv', argv):
                        exit_code = current_ci.main()
                else:
                    exec(compile(self.codes[step], str(WORKFLOW) + ':' + step, 'exec'),
                         {'__name__': '__main__'})
"""
s=once(s,old,new)
old="""    def completed_workspace(self):
        root, out = self.workspace()
        result = self.run_named(root, out)
        self.assertEqual(result[0], 0, result[2])
        self.assertIs(read_json(out / 'named-tests.json')['all_named_controls_passed'], True)
        return root, out
"""
new="""    def completed_workspace(self, *, status=False):
        root, out = self.workspace()
        if status:
            # The current final gate has its own receipt namespace and nested
            # supplemental records. These inert named cases isolate completion
            # validation; they are never reported as scientific test execution.
            (out / 'required-tests.json').write_bytes(self.current_roster_bytes)
            suites = {row['module']: row['tests'] for row in self.current_roster['suites']}
            def isolated_discovery(loader, start_dir, pattern='test*.py', top_level_dir=None):
                return unittest.TestSuite(named_fixture(name) for name in suites[Path(pattern).stem])
            with mock.patch.object(unittest.TestLoader, 'discover', isolated_discovery):
                named = current_ci.execute_named(ROOT, self.current_roster, io.StringIO())
            current_ci.validate_named(named, self.current_roster)
            write_json(out / 'named-tests.json', named)
            write_json(out / 'implementation.json', self.reports['implementation-current.json'])
            write_json(out / 'historical-drift.json', self.current_drift)
            (out / 'historical-on-current.stdout.log').write_bytes(self.drift_stdout)
            (out / 'historical-on-current.stderr.log').write_bytes(self.drift_stderr)
            supplemental_out = out / 'supplemental'
            supplemental_out.mkdir()
            (supplemental_out / supplemental.RETAINED_ROSTER).write_bytes(
                self.supplemental_roster_bytes)
            for name in supplemental.OUTPUTS.values():
                write_json(supplemental_out / name, self.reports[name])
        else:
            result = self.run_named(root, out)
            self.assertEqual(result[0], 0, result[2])
        self.assertIs(read_json(out / 'named-tests.json')['all_named_controls_passed'], True)
        return root, out
"""
s=once(s,old,new)
tree=ast.parse(s);lines=s.splitlines(keepends=True)
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='WorkflowGateTests')
for node in sorted([n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_status_')],key=lambda n:n.lineno,reverse=True):
    body=''.join(lines[node.lineno-1:node.end_lineno])
    body=body.replace('self.completed_workspace()','self.completed_workspace(status=True)')
    body=body.replace("'ci-status.json'","'current-ci-status.json'")
    body=body.replace("'all_required_observations_passed'","'all_required_current_observations_passed'")
    body=body.replace("(out / name).unlink()  # All other evidence and step successes remain.","target = out / name if name == 'named-tests.json' else out / 'supplemental' / name\n                target.unlink()  # All other evidence and step successes remain.")
    body=body.replace("report['post_quantum_soundness_qualified'] = 0","report['qualification']['post_quantum_soundness_qualified'] = 0")
    body=body.replace("path = out / supplemental.OUTPUTS[suite]","path = out / 'supplemental' / supplemental.OUTPUTS[suite]")
    body=body.replace("                self.assertIs(read_json(out / 'current-ci-status.json')['supplemental_completion_verified'], False)","                status_report = read_json(out / 'current-ci-status.json')\n                self.assertEqual(status_report['identities'], {})\n                self.assertTrue(any('supplemental' in reason\n                                    for reason in status_report['validation_errors']))")
    lines[node.lineno-1:node.end_lineno]=[body]
s=''.join(lines);ast.parse(s)
def methods(raw):
    t=ast.parse(raw);c=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='WorkflowGateTests')
    return {n.name:ast.dump(n,include_attributes=False) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
old_methods=methods(before);new_methods=methods(s)
assert set(old_methods)==set(new_methods) and len(old_methods)==14
changed_methods=[name for name in old_methods if old_methods[name]!=new_methods[name]]
assert set(changed_methods)=={'test_status_rejects_exit_zero_without_named_completion','test_status_independently_rechecks_named_ids_and_boolean_scope','test_status_requires_every_step_outcome_and_conclusion'},changed_methods
assert old_methods['test_report_scope_rejects_qualification_escalation_and_false_as_zero']==new_methods['test_report_scope_rejects_qualification_escalation_and_false_as_zero']
(root/p).write_text(s)
doc='docs/security/W1_QROM_CURRENT_SOURCE_MAPPING_V2.md';db=(root/doc).read_bytes();ds=db.decode()
old="""The original embedded-workflow negative controls select the fixed historical
job by its exact job boundaries and unchanged hash before requiring one matching
step ID inside that job. Reused step names in the separate current job do not
weaken step or completion validation. The original Mac compiler refusal is
retained; its eight native C controls subsequently pass with the installed
GCC 15 compiler and the original OpenMP and warning flags.
"""
new="""The original named-runner controls select the fixed historical job by its
exact boundaries and unchanged hash. Relocated report and budget mutations
execute the actual current supplemental_report_scopes step; final-status
controls call the current verifier CLI named by the exact workflow command.
Its independent 14-stage roster, current receipt namespace, original drift
stdout/stderr, and nested supplemental receipts are all checked. Reused step
names cannot route current controls to a historical consumer that ignores them.
The original Mac compiler refusal is retained; its eight native C controls
subsequently pass with installed GCC 15 and the original OpenMP and warning flags.
"""
ds=once(ds,old,new);(root/doc).write_text(ds)
corpus_name='config/pon/pq-cross-branch-corpus-v1.json';cr=(root/corpus_name).read_text();cv=json.loads(cr)
for name in [p,doc]:
    raw=(root/name).read_bytes();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    cr=once(cr,json.dumps(name)+': '+json.dumps(cv['pinned_blobs'][name]),json.dumps(name)+': '+json.dumps(oid))
(root/corpus_name).write_text(cr)
assert subprocess.run(['git','diff','--check'],cwd=root,env=env).returncode==0
patch=git('diff','--binary','--full-index');(out/'working.patch').write_bytes(patch)
focused=''.join(difflib.unified_diff(before.decode().splitlines(True),s.splitlines(True),fromfile='a/'+p,tofile='b/'+p))+''.join(difflib.unified_diff(db.decode().splitlines(True),ds.splitlines(True),fromfile='a/'+doc,tofile='b/'+doc))
(out/'focused.patch').write_text(focused)
mapping=[]
for name in old_methods:
    if name.startswith('test_named_'): consumer='fixed historical job named_tests; original supplemental.run_suite refusal controls where present'
    elif name.startswith('test_status_'):consumer='actual current w1_qrom_current_ci.main verify; current namespace and nested supplemental receipts'
    else:consumer='actual current job supplemental_report_scopes embedded Python'
    mapping.append({'test':name,'consumer':consumer,'body_AST_unchanged':old_methods[name]==new_methods[name]})
summary={'source_base':'5c04c60e463462d9df8884786e0d5bb32af08a64','original_methods':14,'unchanged_method_AST':11,'adapted_status_method_AST':3,'all_original_report_mutators_unchanged':True,'method_consumer_mapping':mapping,'workflow_bytes_unchanged':(root/'.github/workflows/pon-w1-qrom-implementation.yml').read_bytes()==git('show','HEAD:.github/workflows/pon-w1-qrom-implementation.yml'),'focused_patch':{'bytes':len(focused.encode()),'sha256':sha(focused.encode())},'working_patch':{'bytes':len(patch),'sha256':sha(patch)},'test_before_sha256':sha(before),'test_after_sha256':sha(s.encode()),'production_files_changed_in_this_fix':False}
(out/'review.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2),flush=True)
with (out/'14-controls.stdout').open('xb') as so,(out/'14-controls.stderr').open('xb') as se:
    r=subprocess.run([sys.executable,p,'-v'],cwd=root,env=env,stdout=so,stderr=se,check=False)
(out/'test-result.json').write_text(json.dumps({'exit':r.returncode,'stderr_sha256':sha((out/'14-controls.stderr').read_bytes())},indent=2)+'\n')
print(json.dumps({'test_exit':r.returncode,'stderr_sha256':sha((out/'14-controls.stderr').read_bytes())}),flush=True)
sys.exit(r.returncode)
