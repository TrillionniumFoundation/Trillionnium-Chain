from pathlib import Path
import json,hashlib,sys
base=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');src=base/'source/trillionnium/crates/trnm-pon-node/src';out=base/'physical-checkpoint-flow-25';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);manifest=[]
for rel in ['ingress/history_import.rs','ingress/history_import/observation.rs','ingress/public_v3.rs','host_kernel_parent.rs','account_archive_prototype.rs']:
 p=src/rel;lines=p.read_text().splitlines()
 needles={'ingress/history_import.rs':['struct Control','fn check','fn receive','control.resource','checkpoint','owner_checkpoint','resource()'],'ingress/history_import/observation.rs':['observe_host'],'ingress/public_v3.rs':['struct ServiceMutationCpuCheckpoint','impl ServiceMutationCpuCheckpoint','kernel.verify','host_kernel','fn checkpoint'],'host_kernel_parent.rs':['fn verify(','fn check(','fn current_parent','pub fn verify'],'account_archive_prototype.rs':['pub(crate) fn account_root_with_lifts','struct DigestLeaf','fn account_root_digest','fn sorted_account']}[rel]
 ranges=[]
 for i,l in enumerate(lines):
  if any(n in l for n in needles):ranges.append((max(0,i-10),min(len(lines),i+70)))
 merged=[]
 for a,b in ranges:
  if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(b,merged[-1][1]))
  else:merged.append((a,b))
 parts=['\n'.join(str(i+1)+': '+lines[i] for i in range(a,b)) for a,b in merged]
 dest=out/(rel.replace('/','__')+'.sections');dest.write_text('\n\n'.join(parts));manifest.append({'path':str(dest),'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':dest.stat().st_size,'ranges':merged})
 print(json.dumps(manifest[-1]),flush=True)
(out/'RESULT.json').write_text(json.dumps(manifest,indent=2)+'\n')
