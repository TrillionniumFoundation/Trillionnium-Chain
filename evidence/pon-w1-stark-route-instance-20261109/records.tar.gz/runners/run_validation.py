import argparse
import concurrent.futures
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('group', choices=['python', 'rust'])
parser.add_argument('head')
parser.add_argument('--attempt')
args = parser.parse_args()
root = Path('/workspace/scratch/7e8b6061b88c/chain-stark-work')
out = Path('/workspace/scratch/7e8b6061b88c/validation') / args.head / (args.attempt or args.group)
out.mkdir(parents=True, exist_ok=False)
def git(*values):
    return subprocess.check_output(['git', *values], cwd=root, text=True).strip()
assert git('rev-parse', 'HEAD') == args.head
assert git('status', '--porcelain') == ''
source = {'head': args.head, 'tree': git('rev-parse', 'HEAD^{tree}'), 'clean_before': True}
env = dict(os.environ)
rustup_bin = Path('/workspace/scratch/fe81f46237d0/cargo-home/bin')
env['PATH'] = str(rustup_bin) + ':' + env.get('PATH', '')
env['RUSTUP_HOME'] = '/workspace/scratch/a6fe7c2e72c7/pq-validation/rustup'
env['CARGO_HOME'] = '/workspace/scratch/a6fe7c2e72c7/pq-validation/cargo'
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['CARGO_INCREMENTAL'] = '0'
env['CARGO_BUILD_JOBS'] = '1'
env['CARGO_TARGET_DIR'] = '/workspace/scratch/7e8b6061b88c/rust-target'
if args.group == 'rust':
    provider_keys = {'OPENSSL_DIR', 'OPENSSL_STATIC', 'TRNM_PQ_OPENSSL',
                     'TRNM_PQ_OPENSSL_SHA256', 'TRNM_PQ_OPENSSL_VERSION',
                     'OPENSSL_CONF', 'OPENSSL_MODULES'}
    for line in Path('/workspace/scratch/a6fe7c2e72c7/pq-validation/provider.env').read_text().splitlines():
        key, value = line.split('=', 1)
        assert key in provider_keys
        env[key] = value
    recorded_keys = sorted(provider_keys | {'PATH', 'RUSTUP_HOME', 'CARGO_HOME',
                            'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL'})
    inherited_keys = ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC', 'RUSTC_WRAPPER',
                      'RUSTC_WORKSPACE_WRAPPER', 'LD_LIBRARY_PATH',
                      'CARGO_PROFILE_DEV_OPT_LEVEL', 'CARGO_PROFILE_DEV_DEBUG',
                      'CARGO_PROFILE_RELEASE_OPT_LEVEL', 'CARGO_PROFILE_RELEASE_DEBUG']
    (out/'environment.json').write_text(json.dumps({k:env.get(k) for k in recorded_keys+inherited_keys},indent=2)+'\n')
    toolchain = Path(env['RUSTUP_HOME'])/'toolchains/1.95.0-x86_64-unknown-linux-gnu'
    provider = Path(env['OPENSSL_DIR'])
    input_paths = [rustup_bin/'rustup']+[toolchain/'bin'/n for n in ['cargo','rustc','clippy-driver','rustfmt']]
    input_paths += [provider/n for n in ['bin/openssl','include/openssl/opensslv.h',
                                        'include/openssl/configuration.h','lib/libcrypto.a','lib/libssl.a']]
    def snapshot_inputs():
        return [{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in input_paths]
    inputs_before = snapshot_inputs()
    (out/'selected-build-inputs-before.json').write_text(json.dumps({'scope':'Selected tooling and provider files only; not a complete compiler closure.','files':inputs_before},indent=2)+'\n')

def run(row):
    name, command = row
    start = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    start_error = None
    with (out/(name+'.stdout')).open('xb') as stdout, (out/(name+'.stderr')).open('xb') as stderr:
        try:
            p = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr)
            exit_code = p.returncode
        except OSError as error:
            start_error = str(error)
            stderr.write((start_error+'\n').encode())
            exit_code = 127
    logs = {}
    for stream in ['stdout', 'stderr']:
        raw = (out/(name+'.'+stream)).read_bytes()
        logs[stream] = {'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest()}
    text = (out/(name+'.stderr')).read_text(errors='replace')
    counts = re.findall(r'^Ran ([0-9]+) tests? in ', text, re.M)
    result = {'name':name, 'argv':command, 'source':source, 'started_utc':started,
              'elapsed_seconds':time.monotonic()-start, 'exit_code':exit_code,
              'process_started':start_error is None, 'start_error':start_error,
              'logs':logs, 'unittest_method_counts':[int(x) for x in counts],
              'unittest_outcomes':re.findall(r'^(?:OK(?: \(.*\))?|FAILED(?: \(.*\))?)$',text,re.M)}
    (out/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['name','exit_code','elapsed_seconds','unittest_method_counts','unittest_outcomes']}),flush=True)
    return result

if args.group == 'python':
    source_command = ['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',args.head]
    source_before = run(('complete-source-before',source_command))
    assert source_before['exit_code'] == 0
    names = ['test_w1_stark_field_certificates','test_w1_stark_route_audit',
             'test_w1_qrom_current_implementation_audit','test_ci_contract',
             'test_ci_source_integrity','test_pq_research_integration',
             'test_repository','test_pq_chain_claim_guard']
    rows = [(n,['python3','-B','scripts/ci/'+n+'.py']) for n in names]
    rows += [('field-report',['python3','-B','scripts/w1_stark_field_certificates.py']),
             ('route-report',['python3','-B','scripts/w1_stark_route_audit.py']),
             ('current-risc-map',['python3','-B','scripts/w1_qrom_current_implementation_audit.py']),
             ('repository-check',['python3','-B','scripts/ci/check_repository.py']),
             ('source-corpus',['python3','-B','scripts/ci/check_pq_research_integration.py']),
             ('ci-contract',['python3','-B','scripts/ci/check_ci_contract.py']),
             ('inventory',['python3','-B','scripts/refresh_distributed_source_inventory.py','--check']),
             ('preflight',['bash','scripts/project-preflight.sh'])]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results = [source_before]+list(pool.map(run, rows))
    results.append(run(('complete-source-after',source_command)))
else:
    cargo = [str(rustup_bin/'cargo'),'+1.95.0']
    workspace = 'trillionnium/Cargo.toml'
    rows = [('cargo-version',cargo+['--version']),
            ('rustc-version',[str(rustup_bin/'rustc'),'+1.95.0','-vV']),
            ('workspace-metadata-default',cargo+['metadata','--manifest-path',workspace,'--locked','--offline','--format-version=1']),
            ('workspace-metadata-all',cargo+['metadata','--manifest-path',workspace,'--all-features','--locked','--offline','--format-version=1']),
            ('p3-metadata',cargo+['metadata','--manifest-path','formal/pon-nakamoto-v1/w1_public_stark_research/Cargo.toml','--locked','--offline','--format-version=1']),
            ('risc-v2-metadata',cargo+['metadata','--manifest-path','formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.toml','--locked','--offline','--format-version=1']),
            ('workspace-format',cargo+['fmt','--manifest-path',workspace,'--all','--','--check']),
            ('p3-format',cargo+['fmt','--manifest-path','formal/pon-nakamoto-v1/w1_public_stark_research/Cargo.toml','--all','--','--check']),
            ('strict-clippy',cargo+['clippy','--manifest-path',workspace,'--workspace','--all-targets','--all-features','--locked','--offline','--','-D','warnings'])]
    results = [run(row) for row in rows]
source['clean_after'] = git('status','--porcelain') == ''
source['head_after'] = git('rev-parse','HEAD')
source['tree_after'] = git('rev-parse','HEAD^{tree}')
summary = {'source':source,'group':args.group,'results':results,
           'all_commands_exit_zero':all(row['exit_code']==0 for row in results),
           'native_proof_execution_claimed':False,'production_qualified':False}
if args.group == 'rust':
    inputs_after = snapshot_inputs()
    (out/'selected-build-inputs-after.json').write_text(json.dumps({'scope':'Selected tooling and provider files only; not a complete compiler closure.','files':inputs_after},indent=2)+'\n')
    summary['selected_build_inputs_equal_before_after'] = inputs_before == inputs_after
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'summary':str(out/'summary.json'),'all_commands_exit_zero':summary['all_commands_exit_zero'],'source':source}),flush=True)
