#!/usr/bin/python3
"""Closed trial02: capture exact raw facts and query PRIVATE SQLite copies only."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path("/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery")
OUT = ROOT / "owner-cancel-state-audit-02"
REPO = ROOT / "integration-repo"
RUN = ROOT / "owner-cancel-run-02"
NODE = ROOT / "owner-cancel-research-node-02"
COLD = ROOT / "owner-cancel-cold-readback-02"
CONFIG = ROOT / "owner-cancel-launch-plans-02/config.json"
COMMIT = "0f18f93f2d35b62c6ca6d63faf4f336d55cbf4bf"
TREE = "94334bb6b52cfd13040059a5e71f47d8cc9603f2"
OP = "ebe3c586d634730e7464f2e3661aea37f6ed7402c0d74f1a695224510d2e2f5e"
PINNED = {
    "owner-cancel-run-02/funded-owner-cancellation-result.json": "26330c0b15ceb0da601ad986174f17e0ac9fb669ff05ea22d7c182af1ee0f958",
    "owner-cancel-cold-readback-02/result.json": "e134bcc6b5be3bc3e17d753c26247064212a153d6b3f86943a7342b518016e16",
    "owner-cancel-launch-plans-02/config.json": "483f28090674fd4180777786a7458116c80188bbe8ddd9a324b3f0fa862154e1",
    "owner-cancel-launch-plans-02/plan.json": "65dfcf935393c9802a5cc73569c74b35755eaa7bb2736635a586e556d6f01c1c",
    "owner-cancel-launch-02/original-job-receipt.json": "15dcc59764316596e89b952c804e7e81550c6115684eb6c324ca6865bac8a9f9"
}
RELATIVES = [
    "owner-declaration.json", "native-funded-intent.json", "target-request.json",
    "native-cancel-dispatch-intent.json", "native-cancel-submission-observed.json",
    "native-cancel-wire.bin", "native-cancel-packet.bin",
    "owner-cancel-requested.json", "owner-cancel-m12-outcome.json",
    "owner-cancel-start/result.json", "owner-cancel-reconcile/result.json"
]
SOURCES = [
    "trillionnium/crates/trnm-service-settlement/src/native_generation_budget_v2.rs",
    "trillionnium/crates/trnm-service-settlement/src/native_budget.rs",
    "trillionnium/crates/trnm-pon-node/src/store/async_w1_generation_v2/tests/heavy/cancellation.rs",
    "scripts/w1_generation_target_v2.py"
]

def main():
    os.umask(0o077)
    payload = json.load(sys.stdin)
    helper = OUT / "readback_helpers.py"
    require = lambda ok, message: None if ok else (_ for _ in ()).throw(ValueError(message))
    require(hashlib.sha256(helper.read_bytes()).hexdigest() == "f69496d01b321776f60c4129a03b9930952b312ceed76f0397348f11af4cd6a1", "retained helper bytes")
    spec = importlib.util.spec_from_file_location("retained_readback_helpers", helper)
    h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
    h.OUT = OUT; h.INVENTORY = {}
    record = {"schema": "TRNM-W1-OWNER-CANCEL02-PRIVATE-COLLECTION1", "collection_complete": False,
              "analysis_complete": False, "errors": [], "original_database_connections_opened": 0,
              "original_databases_written": False, "Node_M12_target_calls": 0,
              "new_proof_generations": 0, "source_commit": COMMIT, "source_tree": TREE,
              "original_operation": OP, "private_database_publication_prohibited": True}
    try:
        for label, job in (("trial", "1a1b80aa46c-12894-d18"), ("cold", "1a1b80d2416-12894-d1e")):
            raw = payload[label]
            v = json.loads(raw)
            require(v["job_id"] == job and v["state"] == "succeeded" and v["exit_code"] == 0
                    and v["output_complete"] is True and v["output_durable"] is True
                    and v["cancelled"] is False and v["timed_out"] is False, "actual terminal before private copy")
            h.write(OUT / "public/raw" / (label + "-terminal.json"), raw.encode())
        for rel, wanted in PINNED.items():
            data = h.stable(ROOT / rel)
            require(hashlib.sha256(data).hexdigest() == wanted, "original pin changed: " + rel)
            h.write(OUT / "public/raw" / rel, data)
        for rel in RELATIVES:
            h.write(OUT / "public/raw/owner-cancel-run-02" / rel, h.stable(RUN / rel))
        config = h.obj(CONFIG)
        declaration = h.obj(RUN / "owner-declaration.json")
        require(config["expected_commit"] == COMMIT and config["expected_tree"] == TREE
                and config["out"] == str(RUN) and config["research_node_path"] == str(NODE)
                and config["provider_operation"] == OP
                and config["original_deadline_ns"] == declaration["original_deadline_ns"]
                and declaration["config_sha256"] == PINNED["owner-cancel-launch-plans-02/config.json"],
                "actual original config/declaration")
        target = Path(config["target_root"])
        require(target == ROOT / "owner-cancel-local-target-02", "original target path")
        # Original Hepta operations must both have gone terminal before this
        # separate reader ever opens a private SQLite connection.
        scopes = []
        for job in ("1a1b80aa46c-12894-d18", "1a1b80d2416-12894-d1e"):
            group = Path("/sys/fs/cgroup/user.slice/user-1000.slice/user@1000.service/app.slice") / ("hepta-runtime-job-" + job + ".service")
            scopes.append({"path": str(group), "absent": not group.exists() and not group.is_symlink()})
            require(scopes[-1]["absent"], "original job scope still exists; refuse racing DB snapshot")
        record["current_original_scope_observations"] = scopes
        result = subprocess.run(["/usr/bin/git", "-C", str(REPO), "rev-parse", COMMIT + "^{tree}"],
                                stdin=subprocess.DEVNULL, capture_output=True, timeout=30)
        require(result.returncode == 0 and result.stdout.decode().strip() == TREE, "exact C1b object tree")
        sources = []
        for rel in SOURCES:
            argv = ["/usr/bin/git", "-C", str(REPO), "show", COMMIT + ":" + rel]
            v = subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True, timeout=30)
            require(v.returncode == 0, "decoder source object absent")
            h.write(OUT / "public/source-originals" / rel, v.stdout)
            sources.append({"path": rel, "bytes": len(v.stdout), "sha256": hashlib.sha256(v.stdout).hexdigest(), "argv": argv, "exit": v.returncode})
        record["decoder_sources"] = sources
        databases = {
            "m12-generation": RUN / "native-generation-v2.sqlite",
            "native-node": NODE / "native.sqlite",
            "owner-fence": NODE / "native.sqlite.w1-generation-owner-v2.sqlite",
            "posix-target": target / "target-v2.sqlite"
        }
        summaries = {}
        for label, path in databases.items():
            data = h.private_db(path, label)
            summaries[label] = {"original_pin": data["original_pin"],
                "application_id": data["application_id"], "user_version": data["user_version"],
                "tables": {k: {"columns": v["columns"], "rows": v["total_rows"]} for k, v in data["tables"].items()}}
        record["database_summaries"] = summaries
        # Preserve the separate zero-dispatch preparation failure; later
        # success never overwrites or counts it as another generation trial.
        failure = ROOT / "owner-cancel-preparation-failure-02"
        require(failure.is_dir(), "prelaunch failure originals absent")
        preserved = []
        excluded = []
        for path in sorted(failure.rglob("*")):
            if path.is_file():
                raw = h.stable(path)
                if path.suffix not in (".json", ".log", ".txt", ".py", ".md", ".stdout", ".stderr"):
                    excluded.append({**h.INVENTORY[str(path)], "reason": "non-report attachment retained at original host path"})
                    continue
                h.write(OUT / "public/prelaunch-failure" / path.relative_to(failure), raw)
                preserved.append(h.INVENTORY[str(path)])
        record["prelaunch_failure_originals"] = preserved
        record["prelaunch_failure_nonreport_attachments"] = excluded
        for path in list(h.INVENTORY): h.stable(Path(path))
        record["original_files"] = sorted(h.INVENTORY.values(), key=lambda row: row["path"])
        record["collection_complete"] = True
    except BaseException as exc:
        record["errors"].append({"type": type(exc).__name__, "message": str(exc)})
    h.write(OUT / "collection.json", h.encode(record))
    raw = (OUT / "collection.json").read_bytes()
    print(json.dumps({"collection_complete": record["collection_complete"], "analysis_complete": False,
        "manifest": {"path": str(OUT / "collection.json"), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()},
        "database_summaries": record.get("database_summaries"), "errors": record["errors"]}), flush=True)
    return 0 if record["collection_complete"] else 1

if __name__ == "__main__":
    raise SystemExit(main())
