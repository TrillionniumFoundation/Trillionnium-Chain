#!/usr/bin/python3
"""One bounded, source-pinned mathematical replay; no repository writes."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tarfile
import time
import traceback

sys.dont_write_bytecode = True
TASK = Path("/workspace/scratch/7f73fe002713/daa-final-validation")
SOURCE = Path("/workspace/scratch/7f73fe002713/chain-daa")
RAW = Path("/workspace/scratch/7f73fe002713/daa-native-archive-recovery-v1/extracted/native-run-d23488c5-v1")
OUT = TASK / "four-profile-readers-recovery-v2"
HEAD = "d23488c5f9b4a6696c3799b12f14b8af0a1b81fc"
TREE = "72b106b4458299c37da146b0218b8f5276195b6d"
UNIT = "trnm-daa-readers-d23488c5-v1"
ARCHIVE = Path("/workspace/scratch/7f73fe002713/daa-native-archive-recovery-v1/native-run-d23488c5-v1.tar.gz")
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUNBUFFERED="1")
COMMANDS = []


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return {"bytes": path.stat().st_size, "sha256": h.hexdigest()}


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def run(label, argv, required=True):
    stdout, stderr = OUT / (label + ".stdout.log"), OUT / (label + ".stderr.log")
    row = {"label": label, "argv": list(map(str, argv)), "cwd": str(SOURCE),
           "started_utc": utc(), "required": required,
           "recorded_environment": {key: ENV[key] for key in
                                    ("PYTHONDONTWRITEBYTECODE", "PYTHONUNBUFFERED")}}
    start = time.monotonic()
    with stdout.open("xb") as out, stderr.open("xb") as err:
        try:
            row["returncode"] = subprocess.run(
                row["argv"], cwd=SOURCE, env=ENV, stdout=out, stderr=err,
                timeout=600, check=False).returncode
        except BaseException as error:
            row["returncode"] = None
            row["execution_error"] = repr(error)
    row.update(finished_utc=utc(), elapsed_seconds=time.monotonic() - start,
               stdout_path=str(stdout), stderr_path=str(stderr),
               stdout=digest(stdout), stderr=digest(stderr))
    COMMANDS.append(row)
    write(OUT / "commands.json", COMMANDS)
    print(json.dumps({"label": label, "returncode": row["returncode"]}), flush=True)
    return row


def inputs():
    found = {}
    for group in ("joint-daa", "monotone-daa"):
        for backend in ("pnh1-authenticated", "pgh2-growth"):
            folder = RAW / group / backend
            assert folder.is_dir() and not folder.is_symlink(), str(folder)
            for path in sorted(folder.rglob("*")):
                assert not path.is_symlink(), str(path)
                if path.is_file():
                    found[path.relative_to(RAW).as_posix()] = digest(path)
    return found


def archive_inputs():
    found = {}
    with tarfile.open(ARCHIVE, "r:gz") as bundle:
        for member in bundle:
            name = PurePosixPath(member.name)
            assert not name.is_absolute() and ".." not in name.parts, member.name
            assert name.parts[0] == RAW.name, member.name
            relative = PurePosixPath(*name.parts[1:]).as_posix()
            if member.isfile() and relative.startswith(("joint-daa/", "monotone-daa/")):
                assert relative not in found, relative
                with bundle.extractfile(member) as handle:
                    content = handle.read()
                found[relative] = {"bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()}
    return found


def local_runtime():
    import platform
    import resource
    limits = {}
    for label, key, bound in (("address_space", resource.RLIMIT_AS, 8589934592),
                              ("cpu_seconds", resource.RLIMIT_CPU, 1800)):
        soft, hard = resource.getrlimit(key)
        new_hard = bound if hard == resource.RLIM_INFINITY else min(bound, hard)
        new_soft = new_hard if soft == resource.RLIM_INFINITY else min(new_hard, soft)
        resource.setrlimit(key, (new_soft, new_hard))
        limits[label] = {"before": [soft, hard], "after": list(resource.getrlimit(key))}
    cgroups = {}
    for name in ("cpu.max", "memory.max", "pids.max"):
        path = Path("/sys/fs/cgroup") / name
        try:
            cgroups[name] = path.read_text().strip()
        except OSError as error:
            cgroups[name] = {"unavailable": str(error)}
    write(OUT / "local-runtime.json", {
        "platform": platform.platform(), "python_version": sys.version,
        "python_executable": sys.executable, "limits": limits,
        "actual_cgroup_root_files": cgroups,
        "proc_self_cgroup": Path("/proc/self/cgroup").read_text(),
        "commands_run_sequentially": True,
        "reader_is_scalar_python": True,
        "remote_resource_scope_executed": False,
        "physical_cost_or_security_bound_claimed": False})


def source_check(label):
    row = run(label, [sys.executable, "-B", "scripts/ci/verify_ci_source.py",
                     "--kind", "head", "--expected-head", HEAD,
                     "--output", str(OUT / (label + ".json"))])
    assert row["returncode"] == 0, label
    value = json.loads((OUT / (label + ".json")).read_text())
    assert value["tested_commit"] == HEAD and value["tested_tree"] == TREE
    assert value["tracked_worktree_verified"] is True
    return value


def execute(expected_archive_sha):
    OUT.mkdir(mode=0o700, exist_ok=False)
    result = {"schema": "pon-four-profile-scalar-reader-local-recovery-v2", "result": "FAIL",
              "started_utc": utc(), "expected_commit": HEAD, "expected_tree": TREE,
              "mathematically_independent_scalar_implementation": True,
              "independent_host_authentication": False, "public_network_qualification": False,
              "production_activation": False, "driver": digest(Path(__file__)), "profiles": []}
    result["remote_launch_recovery"] = {
        "original_launch_state": "UNKNOWN after two MCP request timeouts",
        "original_idempotency_key": "daa-four-profile-readers-d23488c5-v1-7f73",
        "original_driver_sha256": "4057e69c28267da0115c6eca4bdffdf695eecb3daf63f8e6bc3e9aeafa332875",
        "exclusive_fence_sha256": "b9c1336fe41972e9cba1f0e8bfeb1ea5072347ec82a2650bad249ddcc934cbfe",
        "exclusive_fence_version": "2050:55904516:905:1794444326755941070:1794444326844229556",
        "exclusive_fence_bytes": 905,
        "fence_regular_file_and_hash_rechecked_by_h_file_info": True,
        "fence_link_count": 1,
        "late_original_driver_cannot_pass_its_open_xb_gate": True,
        "remote_reader_execution_observed": False}
    write(OUT / "context.json", {**result, "result": "PENDING",
          "purpose": "pre-execution expected identity and scope; final outcome is result.json"})
    before = None
    scope_verified = False
    try:
        local_runtime()
        scope_verified = True
        source_check("source-before")
        archive = digest(ARCHIVE)
        assert archive["sha256"] == expected_archive_sha, "sealed native archive digest mismatch"
        result["native_archive"] = {"path": str(ARCHIVE), **archive}
        context = json.loads((RAW / "context.json").read_text())
        assert context["expected_commit"] == HEAD and context["expected_tree"] == TREE
        commands = json.loads((RAW / "commands.json").read_text())
        native = [row for row in commands if row["label"] == "native-daa-four-tests"]
        assert len(native) == 1 and native[0]["returncode"] == 0, "native four-test run not complete"
        log = (RAW / "native-daa-four-tests.log").read_text()
        assert "test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;" in log
        expected = re.findall(r"#\[test\]\s*fn\s+([A-Za-z0-9_]+)\s*\(",
                              (SOURCE / "trillionnium/crates/trnm-pon-node/tests/daa_joint_consensus.rs").read_text())
        assert len(expected) == 4 and sorted(re.findall(r"^test (\S+) \.\.\.", log, re.M)) == sorted(expected)
        result["native_tests"] = {"names": expected, "command": native[0],
                                  "log": digest(RAW / "native-daa-four-tests.log")}
        before = inputs()
        write(OUT / "inputs-before.json", before)
        assert len(before) == 460 and before == archive_inputs(), "inputs differ from sealed native archive"
        result["native_archive_inputs_match"] = True
        for group, stem, expected_count in (
                ("monotone-daa", "pon_monotone_daa_reader", 26),
                ("joint-daa", "pon_joint_daa_reader", 22)):
            for backend in ("pnh1-authenticated", "pgh2-growth"):
                label = group + "-" + backend
                raw_dir = RAW / group / backend
                report = group + ".json"
                pin = before[group + "/" + backend + "/" + report]["sha256"]
                reader = run(label + "-reader", [sys.executable, "-B", "scripts/" + stem + ".py",
                             "--raw-dir", str(raw_dir), "--expected-report-sha256", pin])
                suite = run(label + "-suite", [sys.executable, "-B", "scripts/ci/test_" + stem + ".py",
                            "--raw-dir", str(raw_dir), "-v"])
                observation = {"group": group, "backend": backend, "reader": reader, "suite": suite}
                try:
                    reader_value = json.loads(Path(reader["stdout_path"]).read_text())
                    observation["reader_summary"] = {key: reader_value[key] for key in (
                        "record_and_oracle_consistency", "header_profile", "observations",
                        "unique_full_python_verified_proofs", "ordinary_required_chainwork",
                        "selected_required_chainwork", "selected_height", "ordinary_height",
                        "qualification", "public_network_qualification", "production_activation",
                        "common_prefix_failure_bound", "chain_growth_failure_bound",
                        "chain_quality_failure_bound", "six_confirmations_failure_bound",
                        "actual_lifetime_failure_bound") if key in reader_value}
                    observation["signed_spans"] = [row["signed_span_seconds"] for row in reader_value["retargets"]]
                    assert reader["returncode"] == 0 and reader_value["record_and_oracle_consistency"] == "PASS"
                    assert reader_value["unique_full_python_verified_proofs"] == 114
                    stderr = Path(suite["stderr_path"]).read_text()
                    count = re.search(r"Ran (\d+) tests in ([0-9.]+)s", stderr)
                    assert count is not None, "missing unittest execution summary"
                    skips = re.search(r"OK \(skipped=(\d+)\)", stderr)
                    observed_skips = int(skips.group(1)) if skips else 0
                    observation["suite_summary"] = {
                        "methods_executed": int(count.group(1)), "seconds": count.group(2),
                        "skipped": observed_skips,
                        "passed": int(count.group(1)) - observed_skips if suite["returncode"] == 0 else None,
                        "skip_lines": [line for line in stderr.splitlines() if " ... skipped " in line]}
                    assert suite["returncode"] == 0 and int(count.group(1)) == expected_count
                    assert observed_skips == (1 if backend == "pnh1-authenticated" else 0)
                    observation["result"] = "PASS"
                except BaseException:
                    observation["result"] = "FAIL"
                    observation["validation_error"] = traceback.format_exc()
                result["profiles"].append(observation)
                write(OUT / "progress.json", result)
    except BaseException:
        result["error"] = traceback.format_exc()
    finally:
        if scope_verified:
            try:
                source_check("source-after")
                result["source_after_verified"] = True
            except BaseException:
                result["source_after_error"] = traceback.format_exc()
        else:
            result["source_after_not_run_without_recorded_local_limits"] = True
        if before is not None:
            try:
                after = inputs()
                write(OUT / "inputs-after.json", after)
                result["inputs_unchanged"] = after == before
                result["native_archive_unchanged"] = digest(ARCHIVE)["sha256"] == expected_archive_sha
            except BaseException:
                result["input_after_error"] = traceback.format_exc()
        if (len(result["profiles"]) == 4 and all(row["result"] == "PASS" for row in result["profiles"])
                and result.get("source_after_verified") and result.get("inputs_unchanged")
                and result.get("native_archive_unchanged") and not result.get("error")):
            result["result"] = "PASS"
        result["finished_utc"] = utc()
        write(OUT / "result.json", result)
        write(OUT / "files.json", {path.relative_to(OUT).as_posix(): digest(path)
                                 for path in sorted(OUT.rglob("*")) if path.is_file()})
        archive_path = TASK / (OUT.name + ".tar.gz")
        with archive_path.open("xb") as handle, tarfile.open(fileobj=handle, mode="w:gz") as bundle:
            bundle.add(OUT, arcname=OUT.name)
        descriptor = {"schema": "pon-four-profile-scalar-reader-recovery-archive-v2",
                      "path": str(archive_path), **digest(archive_path), "result": result["result"],
                      "expected_commit": HEAD, "expected_tree": TREE}
        write(TASK / (OUT.name + "-archive.json"), descriptor)
        print(json.dumps(descriptor), flush=True)
    return 0 if result["result"] == "PASS" else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--native-archive-sha256", required=True)
    args = parser.parse_args()
    assert re.fullmatch("[0-9a-f]{64}", args.native_archive_sha256)
    return execute(args.native_archive_sha256)


if __name__ == "__main__":
    sys.exit(main())
