#!/usr/bin/env python3
"""Read existing attempt-2 evidence; create one external reconciliation record."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path('/tmp/chain-pq-fa62381e')
OUT = Path('/tmp/chain-pq-fa62381e-c4-commit-attempt-2')
DESTINATION = OUT / 'source-reconciliation.json'
SOURCE = '35b7c47f65ad0442cf1c459f5b16c9e9bcca0ed8'
TREE = '15fd9e7a2f4121dce861e9e96b78d8196d3892fb'
PARENT = '454ae116159867ff6cddd91b964523df7f7e16f0'
BRANCH = 'fix/chain-pq-live-retry-20261111-fa62381e'
NS = 'evidence/pq-live-retry-20261111-fa62381e/'
FOUR = [NS + 'FINDINGS.md', NS + 'README.md',
        NS + 'evidence-artifact-manifest.json', 'config/pon/pq-cross-branch-corpus-v1.json']
OBSERVED_RECEIPT_SHA256 = {
    'commit.json': '75945d2452675662c1f096c717c1d7a945b0c821d8c09f70ccaf3f5669dc4002',
    'physical-source-check.json': '8d3a86f6a70e5b57514a174c99f14478d5cc9d65f7c922d652b51ac6fec417a2',
    'source.json': '2a0164e9ff47aba8782157e66cb214304f8b5ba9737e1e7710c6941f96aa7307',
    'failure.json': 'f83955169a93265fa51da2b3eeeae9baac2d289948d12d35aca785e5a728372c',
}


def require(value, message):
    if not value:
        raise ValueError(message)


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def fingerprint(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_nlink,
            value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def raw(path):
    path = Path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
                and before.st_size <= 32 * 1024 * 1024, 'unexpected evidence input')
        data = stream.read(32 * 1024 * 1024 + 1)
        require(len(data) == before.st_size and fingerprint(before)
                == fingerprint(os.fstat(stream.fileno())) == fingerprint(path.lstat()),
                'evidence changed during read: ' + str(path))
    return data


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)


def clean_exact_source():
    require(git('rev-parse', 'HEAD').decode().strip() == SOURCE
            and git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE,
            'current HEAD/tree differs from the observed committed source')
    require(git('branch', '--show-current').decode().strip() == BRANCH,
            'current branch differs')
    require(git('rev-list', '--parents', '-n', '1', SOURCE).decode().split() == [SOURCE, PARENT],
            'exact single parent differs')
    require(not git('status', '--porcelain=v1', '--untracked-files=all')
            and all(row.startswith(b'H ') for row in git('ls-files', '-v').splitlines()),
            'current source is not clean or has exceptional index flags')


def main():
    require(OUT.is_dir() and not DESTINATION.exists(), 'unique reconciliation destination required')
    names = ['commit.json', 'physical-source-check.json', 'source.json',
             'failure.json', 'admission.json']
    held = {name: raw(OUT / name) for name in names}
    for name, expected_sha in OBSERVED_RECEIPT_SHA256.items():
        require(identity(held[name])['sha256'] == expected_sha,
                'original receipt differs from independent controller readback: ' + name)
    docs = {name: json.loads(data) for name, data in held.items()}
    commit = docs['commit.json']
    physical_command = docs['physical-source-check.json']
    physical = docs['source.json']
    failure = docs['failure.json']
    admission = docs['admission.json']
    require(commit['actual_exit_code'] == 0 and commit['native_tests_executed'] is False
            and commit['argv'] == ['git', '--no-replace-objects', 'commit', '-m',
                'fix(pq): bind root register and retain source-bound validation evidence'],
            'existing commit command receipt does not record the expected successful commit')
    require(physical_command['actual_exit_code'] == 0
            and physical_command['native_tests_executed'] is False
            and physical_command['argv'] == ['/usr/bin/python3', '-B',
                'scripts/ci/verify_ci_source.py', '--kind', 'head', '--expected-head', SOURCE,
                '--output', str(OUT / 'source.json')],
            'existing physical-source command receipt differs')
    for prefix, record in [('commit', commit), ('physical-source-check', physical_command)]:
        for stream in ('stdout', 'stderr'):
            name = prefix + '.' + stream + '.log'
            held[name] = raw(OUT / name)
            require(identity(held[name]) == record[stream], 'existing command transcript differs: ' + name)
    require(physical['tested_commit'] == SOURCE and physical['tested_tree'] == TREE,
            'existing full physical-source receipt has a different source')
    require(failure['status'] == 'failed-preserve-observed-effects'
            and failure['error_type'] == 'FileExistsError'
            and str(OUT / 'commit.json') in failure['error']
            and failure['rollback_performed'] is False,
            'failure record is not the observed final-summary filename collision')
    state = failure['state']
    require(state['commit_attempted'] is True and state['commit_return_code'] == 0
            and state['observed_commit'] == SOURCE and state['prepared_index_tree'] == TREE
            and state['working_files_replaced'] == FOUR
            and failure['observed_head_after_failure'] == SOURCE,
            'failure record does not preserve the observed successful commit/tree')
    require(admission['schema'] == 'trnm-presentation-repair-commit-admission-v1'
            and admission['parent'] == PARENT and admission['branch'] == BRANCH
            and admission['repair_paths'] == FOUR
            and admission['initial_index_tree'] == state['initial_index_tree'],
            'existing attempt-2 admission differs')
    expected = admission['expected_new_file_identities']
    require(len(expected) == 36 and sorted(expected) == admission['paths'],
            'existing 36-path expectation differs')
    actual_paths = sorted(x.decode() for x in git('diff', '--name-only', '-z', PARENT, SOURCE).split(b'\0') if x)
    require(actual_paths == admission['paths'], 'committed path roster differs')
    clean_exact_source()
    for path, expected_identity in expected.items():
        require(identity(git('show', SOURCE + ':' + path)) == expected_identity
                and identity(raw(ROOT / path)) == expected_identity,
                'committed/current bytes differ from the held admission: ' + path)
    for name, data in held.items():
        require(raw(OUT / name) == data, 'original receipt/log changed during reconciliation: ' + name)
    clean_exact_source()
    record = {
        'schema': 'trnm-c4-source-reconciliation-v1',
        'status': 'committed-source-reconciled-original-outer-failure-retained',
        'source': SOURCE, 'tree': TREE, 'parent': PARENT, 'branch': BRANCH,
        'actual_git_commit_exit_code': 0,
        'existing_physical_source_command_exit_code': 0,
        'existing_full_physical_source_receipt_verified': True,
        'fresh_full_physical_source_check_executed_by_reconciler': False,
        'current_head_tree_exact_single_parent_and_clean_status_verified': True,
        'changed_paths_verified_against_existing_admission': 36,
        'original_outer_exit_code': 1,
        'original_outer_timed_out': False,
        'outer_status_source': 'retained durable-controller observation supplied by the parent task',
        'original_outer_failure_preserved': True,
        'original_failure_reason': 'final summary creation collided with existing successful commit command receipt at commit.json',
        'original_receipts_and_logs': {name: identity(data) for name, data in sorted(held.items())},
        'existing_source_guard': physical,
        'original_receipts_overwritten': False,
        'repository_files_modified': False,
        'commit_or_replay_performed': False,
        'native_tests_or_builds_executed': False,
        'pushed': False,
        'exact_committed_gates_still_required': True,
        'whole_chain_quantum_security_qualified': False,
        'production_activation': False,
    }
    data = (json.dumps(record, indent=2, sort_keys=True) + '\n').encode()
    fd = os.open(DESTINATION, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    require(raw(DESTINATION) == data, 'new reconciliation record readback differs')
    print(json.dumps({'path': str(DESTINATION), **identity(data),
                      'source': SOURCE, 'tree': TREE, 'original_outer_exit_code': 1}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
