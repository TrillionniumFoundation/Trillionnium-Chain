from pathlib import Path
import json,sys,resource,time
root=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');out=root/'repository-live-status-56';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);t=time.monotonic();b=resource.getrusage(resource.RUSAGE_SELF);d=root/'repository-truth-10';r={'result':json.loads((d/'RESULT.json').read_text())}
for n in ('stdout.log','stderr.log'):
 p=d/n
 with p.open('rb') as f:
  f.seek(max(0,p.stat().st_size-2500));raw=f.read()
 r[n]={'bytes':p.stat().st_size,'tail':raw.decode(errors='replace')}
a=resource.getrusage(resource.RUSAGE_SELF);r['read_cost']={'wall_seconds':time.monotonic()-t,'self_user_cpu_seconds':a.ru_utime-b.ru_utime,'self_system_cpu_seconds':a.ru_stime-b.ru_stime};(out/'READOUT.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
