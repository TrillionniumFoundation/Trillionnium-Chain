
import os,json,time,subprocess,re
from pathlib import Path
out=Path('/dev/shm/chain-throughput-0b5320/build-environment-readback-v1.json')
if out.exists():raise SystemExit('receipt exists')
roots={ '/tmp/chain-throughput-0b5320':'fixed5ec','/tmp/chain-throughput-before-ae-0b5320':'beforeae'}
allow={'RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS','CARGO_BUILD_TARGET','RUSTC','CARGO_HOME','RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_TARGET_DIR','OPENSSL_DIR','OPENSSL_STATIC','OPENSSL_LIB_DIR','OPENSSL_INCLUDE_DIR','OPENSSL_CONF','OPENSSL_MODULES','TRNM_PQ_OPENSSL','TRNM_PQ_OPENSSL_SHA256','TRNM_PQ_OPENSSL_VERSION'}
def selected(env):
 return {k:v for k,v in env.items() if k in allow or k.startswith('CARGO_PROFILE_') or re.fullmatch(r'CARGO_TARGET_[A-Z0-9_]+_(RUSTFLAGS|LINKER|RUNNER)',k)}
rows=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit() or int(p.name)==os.getpid():continue
 try:
  cwd=os.readlink(p/'cwd')
  if not any(cwd==r or cwd.startswith(r+'/') for r in roots):continue
  env=dict(x.split('=',1) for x in (p/'environ').read_text().split('\0') if '=' in x)
  if not env.get('CARGO_TARGET_DIR','').startswith('/dev/shm/chain-throughput-0b5320/'):continue
  comm=(p/'comm').read_text().strip()
  status=(p/'status').read_text()
  rss=re.findall(r'^VmRSS:\s*(.+)$',status,re.M)
  rows.append({'pid':int(p.name),'comm':comm,'cwd':cwd,'allowlisted_environment':selected(env),'rss':rss})
 except (FileNotFoundError,PermissionError,ProcessLookupError):continue
configs=[]
for d in ['/home/qian-qi/.cargo','/tmp/.cargo','/.cargo','/tmp/chain-throughput-0b5320/.cargo','/tmp/chain-throughput-before-ae-0b5320/.cargo']:
 for name in ['config','config.toml']:
  p=Path(d)/name;configs.append({'path':str(p),'exists':p.exists(),'symlink':p.is_symlink()})
candidates=[]
for root in [Path('/tmp'),Path('/home/qian-qi/work')]:
 for p in root.iterdir():
  if any(x in p.name.lower() for x in ('openssl','provider','pq-closure','d4d2')):
   candidates.append({'path':str(p),'directory':p.is_dir(),'symlink':p.is_symlink()})
payload={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'native_processes':rows,'cargo_config_presence':configs,'provider_candidates':candidates,'runtime_allowlist':selected(os.environ)}
p=subprocess.run(['/usr/bin/pkg-config','--modversion','openssl'],capture_output=True,text=True)
payload['system_openssl_pkg_config']={'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
out.write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload,sort_keys=True),flush=True)
