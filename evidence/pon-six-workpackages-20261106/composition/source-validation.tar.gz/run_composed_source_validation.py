import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import time

root = Path('/workspace/scratch/62902f6722b7/chain-work')
out = Path('/workspace/scratch/62902f6722b7/composed-source-validation')
out.mkdir(exist_ok=True)
expected = '361825dd1f924770562705d7a68c78170f0375c3'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
assert git('rev-parse', 'HEAD') == expected
assert not git('status', '--porcelain')
before = {'head': git('rev-parse','HEAD'), 'tree': git('rev-parse','HEAD^{tree}'),
          'lock_sha256': hashlib.sha256((root/'trillionnium/Cargo.lock').read_bytes()).hexdigest()}
commands = [
    ('preflight', ['bash','scripts/project-preflight.sh']),
    ('source-before', ['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',expected,'--output',str(out/'source-before.json')]),
    ('metadata-default', ['cargo','metadata','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','--format-version','1']),
    ('metadata-all-features', ['cargo','metadata','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','--all-features','--format-version','1']),
    ('rustfmt', ['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check']),
    ('repository', ['python3','-B','scripts/ci/check_repository.py']),
    ('inventory', ['python3','-B','scripts/refresh_distributed_source_inventory.py','--check']),
    ('corpus', ['python3','-B','scripts/ci/check_pq_research_integration.py']),
    ('repository-controls', ['python3','-B','scripts/ci/test_repository.py']),
    ('ci-contract-controls', ['python3','-B','scripts/ci/test_ci_contract.py']),
    ('source-integrity-controls', ['python3','-B','scripts/ci/test_ci_source_integrity.py']),
    ('pq-integration-controls', ['python3','-B','scripts/ci/test_pq_research_integration.py']),
    ('native-roster-controls', ['python3','-B','scripts/ci/test_six_workpackage_native_rosters.py']),
    ('proof-readback-controls', ['python3','-B','scripts/ci/test_w1_full_v2_disposition.py']),
    ('strategy-reader-controls', ['python3','-B','scripts/ci/test_pon_w1_preparation_strategy_reader_v4.py']),
    ('whitespace', ['git','diff','--check','HEAD']),
    ('source-after', ['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',expected,'--output',str(out/'source-after.json')]),
]
rows=[]
for name, command in commands:
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick=time.monotonic()
    usage_before=resource.getrusage(resource.RUSAGE_CHILDREN)
    path=out/(name+'.log')
    with path.open('wb') as stream:
        proc=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT,check=False)
    usage_after=resource.getrusage(resource.RUSAGE_CHILDREN)
    raw=path.read_bytes()
    row={'name':name,'argv':command,'started_utc':start,
         'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'returncode':proc.returncode,'wall_seconds':time.monotonic()-tick,
         'waited_children_cpu_seconds':(usage_after.ru_utime+usage_after.ru_stime)-(usage_before.ru_utime+usage_before.ru_stime),
         'log':path.name,'log_bytes':len(raw),'log_sha256':hashlib.sha256(raw).hexdigest()}
    matches=re.findall(rb'Ran (\d+) tests? in ([0-9.]+)s',raw)
    if matches: row['unittest_summaries']=[{'tests':int(n),'harness_seconds':float(s)} for n,s in matches]
    if name.startswith('metadata-') and proc.returncode==0:
        # Cargo may print diagnostic warning lines ahead of the JSON object.
        parsed=json.loads(raw[raw.index(b'{'):])
        row['workspace_members']=len(parsed['workspace_members'])
        row['packages']=len(parsed['packages'])
        row['resolve_nodes']=len(parsed['resolve']['nodes'])
    rows.append(row)
    (out/'progress.json').write_text(json.dumps({'source_before':before,'commands':rows},indent=2)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k not in ('argv','log_sha256')},sort_keys=True),flush=True)
after={'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),
       'lock_sha256':hashlib.sha256((root/'trillionnium/Cargo.lock').read_bytes()).hexdigest(),
       'status_porcelain':git('status','--porcelain')}
summary={'schema':'trnm-composed-source-validation-v1','source_before':before,'source_after':after,
         'source_unchanged':all(after[k]==v for k,v in before.items()) and not after['status_porcelain'],
         'commands':rows,'all_commands_exit_zero':all(r['returncode']==0 for r in rows),
         'strict_clippy_recorded_separately':True,
         'scope':'Source controls only; native tests and original-resource acceptance are separate.',
         'six_workpackages_accepted':False,'activation':False}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='commands'},sort_keys=True),flush=True)
