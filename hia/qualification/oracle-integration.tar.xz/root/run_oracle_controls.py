from pathlib import Path
import hashlib, json, os, subprocess, sys, time

BASE = Path('/workspace/scratch/a638c5cc4765')
ROOT = BASE / 'Trillionnium-Chain'
OUT = BASE / 'oracle-integration-controls'
OUT.mkdir(mode=0o700)
ENV = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1',
       'HIA_TOOLCHAIN_ROOT': '/workspace/scratch/bc089b09ffa5/Hepta-toolchain',
       'HIA_NATIVE_COMPILER': '/workspace/scratch/bc089b09ffa5/hia-bootstrap/native-compiler',
       'HIA_NATIVE_COMPILER_SHA256': '87c247e4d1c3c9a449d2947fd4227fdc186d519bffd203a04cafce7861a4ed54'}
def binding(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
def run(name, argv):
    start = time.monotonic_ns()
    with (OUT / (name + '.stdout.raw')).open('xb') as stdout, (OUT / (name + '.stderr.raw')).open('xb') as stderr:
        proc = subprocess.run(argv, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr)
    row = {'argv': argv, 'cwd': str(ROOT), 'exit_code': proc.returncode, 'wall_ns': time.monotonic_ns() - start,
           'stdout': binding(OUT / (name + '.stdout.raw')), 'stderr': binding(OUT / (name + '.stderr.raw'))}
    (OUT / (name + '.execution.json')).write_text(json.dumps(row, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'stage': name, 'exit_code': proc.returncode}), flush=True)
    assert proc.returncode == 0, name
run('preflight', ['bash', 'scripts/project-preflight.sh'])
run('migration', ['python3', '-B', '-m', 'hia.tools.check_migration'])
run('migration-composition-partition', ['python3', '-B', '-m', 'unittest', '-v',
    'hia.tests.test_migration_inventory', 'hia.tests.test_composition', 'hia.tests.test_component_partition'])
run('bootstrap', ['python3', '-B', '-m', 'unittest', '-v', 'scripts.ci.test_hia_workflow_bootstrap'])
sys.path.insert(0, str(ROOT))
import unittest
from hia.tools.component_partition import flatten, descriptor
suite = unittest.defaultTestLoader.discover(str(ROOT / 'hia/tests'), pattern='test_*.py', top_level_dir=str(ROOT))
ids = [case.id() for case in flatten(suite)]
groups = {group: descriptor(ids, group) for group in ('general', 'state-root')}
row = {'status': 'DISCOVERY_ONLY', 'runtime_executed': False, 'total': len(ids), 'partitions': groups}
(OUT / 'component-discovery.json').write_text(json.dumps(row, sort_keys=True, indent=2) + '\n')
print(json.dumps({'discovered': len(ids), 'general': len(groups['general']['selected_tests']),
                  'state_root': len(groups['state-root']['selected_tests']), 'runtime_executed': False}), flush=True)
