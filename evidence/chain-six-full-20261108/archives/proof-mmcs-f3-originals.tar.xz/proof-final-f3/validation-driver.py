import datetime
import hashlib
import json
import os
import pathlib
import stat
import subprocess
import sys
import time

ROOT = pathlib.Path('/data/chain-six-d9fb-20261108/source')
ADAPTER = ROOT / 'formal/pon-nakamoto-v1/w1_node_adapter_research'
EVIDENCE = pathlib.Path('/data/chain-six-d9fb-20261108/evidence/proof-final-f3')
TARGET = pathlib.Path('/data/chain-six-d9fb-20261108/targets/proof')
TASK_TMP = pathlib.Path('/data/chain-six-d9fb-20261108/tmp-proof')
CARGO = '/home/qian-qi/.cargo/bin/cargo'
ENV = os.environ.copy()
ENV.update(CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='2', RAYON_NUM_THREADS='2',
           RUSTFLAGS='-C target-cpu=native', PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(TASK_TMP))
RECORDS = []


def save(name, data):
    with (EVIDENCE / name).open('x') as handle:
        json.dump(data, handle, indent=2)
        handle.write('\n')


def command(name, args, cwd=ROOT, check=True):
    print(json.dumps({'stage_start': name, 'arguments': list(map(str, args)), 'cwd': str(cwd)}), flush=True)
    start = time.monotonic()
    with (EVIDENCE / (name + '.stdout')).open('xb') as out, (EVIDENCE / (name + '.stderr')).open('xb') as err:
        process = subprocess.run(args, cwd=cwd, env=ENV, stdout=out, stderr=err)
    record = {
        'name': name, 'arguments': list(map(str, args)), 'cwd': str(cwd),
        'exit_code': process.returncode, 'wall_seconds': time.monotonic() - start,
        'stdout_sha256': hashlib.sha256((EVIDENCE / (name + '.stdout')).read_bytes()).hexdigest(),
        'stderr_sha256': hashlib.sha256((EVIDENCE / (name + '.stderr')).read_bytes()).hexdigest(),
    }
    RECORDS.append(record)
    save(name + '.json', record)
    print(json.dumps(record), flush=True)
    if check and process.returncode:
        raise RuntimeError(name + ' failed: ' + str(process.returncode))
    return process.returncode


def full_source(name):
    print(json.dumps({'stage_start': name, 'scope': 'all tracked files actual byte comparison'}), flush=True)
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
    listing = subprocess.check_output(['git', 'ls-tree', '-r', '-z', '--full-tree', 'HEAD'], cwd=ROOT)
    entries, total = [], 0
    for item in listing.split(b'\0'):
        if not item:
            continue
        descriptor, rawpath = item.split(b'\t', 1)
        mode, kind, oid = descriptor.split()
        assert kind == b'blob', (mode, kind, rawpath)
        path = ROOT / os.fsdecode(rawpath)
        metadata = path.lstat()
        if mode == b'120000':
            assert stat.S_ISLNK(metadata.st_mode), str(path)
            content = os.fsencode(os.readlink(path))
            size = len(content)
            hasher = hashlib.sha1(b'blob ' + str(size).encode() + b'\0' + content)
        else:
            assert stat.S_ISREG(metadata.st_mode), str(path)
            assert (mode == b'100755') == bool(metadata.st_mode & 0o111), str(path)
            size = metadata.st_size
            hasher = hashlib.sha1(b'blob ' + str(size).encode() + b'\0')
            observed = 0
            with path.open('rb') as handle:
                while chunk := handle.read(1024 * 1024):
                    observed += len(chunk)
                    hasher.update(chunk)
            assert observed == size, str(path)
        assert hasher.hexdigest().encode() == oid, str(path)
        total += size
        entries.append({'path': os.fsdecode(rawpath), 'mode': mode.decode(),
                        'git_blob': oid.decode(), 'bytes': size})
    status = subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=ROOT, text=True)
    assert not status.strip(), status
    report = {'schema': 'trnm-w1-proof-owner-full-source-observation-v1',
              'head': head, 'tree': tree, 'entries': len(entries), 'bytes': total,
              'all_tracked_bytes_match_git': True, 'untracked_and_dirty': status,
              'entry_manifest_sha256': hashlib.sha256(json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()).hexdigest()}
    save(name + '.json', report)
    print(json.dumps(report), flush=True)
    return report


def main():
    import re
    expected = os.environ['TRNM_EXPECTED_SOURCE_HEAD']
    assert re.fullmatch(r'[0-9a-f]{40}', expected)
    assert not EVIDENCE.exists(), str(EVIDENCE)
    assert not EVIDENCE.is_relative_to(ROOT) and not TARGET.is_relative_to(ROOT)
    EVIDENCE.parent.mkdir(parents=True, exist_ok=True)
    TASK_TMP.mkdir(mode=0o700, exist_ok=True)
    EVIDENCE.mkdir()
    driver_source = sys.stdin.read()
    assert driver_source.startswith('import datetime\n') and len(driver_source) > 8000
    with (EVIDENCE / 'validation-driver.py').open('x') as handle:
        handle.write(driver_source)
    command('01-preflight', ['bash', 'scripts/project-preflight.sh'])
    before = full_source('02-source-before')
    assert before['head'] == expected, before
    save('environment.json', {
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'validation_driver_sha256': hashlib.sha256(driver_source.encode()).hexdigest(),
        'source': before, 'target_directory': str(TARGET), 'temporary_directory': str(TASK_TMP),
        'compiler_policy': {name: ENV[name] for name in ['CARGO_BUILD_JOBS', 'RAYON_NUM_THREADS', 'RUSTFLAGS']},
        'independent_source_validation': True,
        'native_io_boundary_qualification_claimed': False,
        'new_complete_proofs_generated': 0, 'qualification': 'HOLD_NO_GO', 'production_activation': False,
    })
    cargo = [CARGO, '+1.95.0']
    manifest = ['--manifest-path', str(ADAPTER / 'Cargo.toml')]
    command('03-toolchain', [CARGO, '+1.95.0', '--version'])
    command('04-metadata', cargo + ['metadata', *manifest, '--locked', '--offline', '--format-version', '1'])
    command('05-fmt-check', cargo + ['fmt', *manifest, '--all', '--', '--check'])
    command('06-tests', cargo + ['test', *manifest, '--release', '--locked', '--offline', '--all-targets', '--', '--test-threads=1'])
    names = []
    for test in ['tests/node_bridge.rs', 'tests/proof_start_owner.rs']:
        names.extend(re.findall(r'(?m)^#\[test\]\nfn (\w+)\(', (ADAPTER/test).read_text()))
    log = (EVIDENCE/'06-tests.stdout').read_text()
    passed = re.findall(r'(?m)^test (\w+) \.\.\. ok$', log)
    results = [tuple(map(int, row)) for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', log)]
    assert len(names) == len(set(names)) == 22
    assert sorted(names) == sorted(passed) and len(passed) == 22
    assert results and sum(row[0] for row in results)==22 and not any(any(row[1:]) for row in results)
    save('06-test-roster.json', {'registered': sorted(names), 'successful': sorted(passed),
                               'unique_passes': 22, 'results': results, 'qualification': 'HOLD_NO_GO'})
    command('07-clippy', cargo + ['clippy', *manifest, '--release', '--locked', '--offline', '--all-targets', '--all-features', '--', '-D', 'warnings'])
    command('08-release-build', cargo + ['build', *manifest, '--release', '--locked', '--offline'])
    binary = TARGET / 'release/w1-node-adapter-research'
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    command('09-independent-processes', ['python3', '-B', str(ADAPTER / 'run_node_controls.py'),
        '--binary', str(binary), '--expected-binary-sha256', digest,
        '--fixture', str(ADAPTER / 'fixtures/node-input-v1'),
        '--proof', str(ADAPTER / 'fixtures/node-input-v1'),
        '--output', str(EVIDENCE / 'independent-processes')])
    after = full_source('10-source-after')
    assert before == after
    save('summary.json', {
        'schema': 'trnm-w1-proof-start-owner-validation-v1', 'result': 'PASS',
        'source': before, 'binary_sha256': digest, 'commands': RECORDS,
        'test_scope': 'original 12 integration controls plus 10 durable-owner controls',
        'independent_process_scope': 'five exercises plus four cold reopens, one nine-slot owner',
        'new_complete_proofs_generated': 0, 'proofs_are_retained_input_replays': True,
        'lifetime_quantum_bound_established': False, 'backup_rollback_protection_established': False,
        'production_resource_profile': False, 'qualification': 'HOLD_NO_GO', 'production_activation': False,
    })
    print('VALIDATION_COMPLETE', flush=True)

try:
    main()
except BaseException as exception:
    if EVIDENCE.exists():
        save('failure.json', {'error': repr(exception), 'completed_commands': RECORDS,
                              'qualification': 'HOLD_NO_GO', 'production_activation': False})
    raise

