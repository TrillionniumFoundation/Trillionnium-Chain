# PQ local cancellation origin: read-only repair review

Status: production edit not performed; native baseline belongs to root. This
review is bound to the isolated branch source in `source-binding.json`.

## Minimal production change

Add an explicit `local_only` group to `error_codes!`. Its three entries are
`PqNetworkDeadline`, `PqNetworkExpired`, and `PqNetworkRevoked`. They participate
in the enum, exact `as_str` diagnostics and `kind=Cancelled`, but never in
`ErrorCode::parse`. Keep every current parseable variant/mapping unchanged.

Replace only the three control producers in `PqServer::handle` with explicit
`Err(Error::new(...))` on the same failed conditions, in the same order:
monotonic original deadline, current real wall-clock signed expiry, and current
durable revocation epoch. Do not change the `ensure` helper globally.

Consequently `Error::from("PQ_NETWORK_REVOKED")` and the other two exact strings
remain Unclassified. Other uses of those strings in the verifier/ledger keep
their original refusal semantics; they do not obtain cancellation authority.
`PqServer::response` still signs the original public diagnostic and still
replaces a response after signed expiry with `PQ_NETWORK_EXPIRED_UNCONFIRMED`.
No wire, profile, schema, deadline, sequence, cleanup SQL, CPU or PoN relation
changes are required by this repair.

## Text-to-error boundary inventory

| Boundary | Current conversion | Local cancellation from the three quoted strings |
| --- | --- | --- |
| `ingress::call` | untrusted JSON error is prefixed with `REMOTE:` then converted | No exact local code; remains Unclassified |
| `ingress::call_protected` | same mandatory `REMOTE:` prefix | No exact local code; remains Unclassified |
| `call_authenticated_inner` | verify canonical reply, session, nonce, digest and signature, then `authenticated_remote(terminal, text)` | Wrapper chooses only RemoteTerminal/RemoteRetryable, both RemoteRefusal |
| `call_authenticated_outbound` path | same authenticated verification, durable outbound finish on signed terminal status, then authenticated wrapper | Remote text does not choose a local code or determine terminality |
| `call_public_protected_v3_*` | canonical/context/signature checks, returns PublicReply data | No error-string parsing at this boundary |
| `public_submit::remote_error` | bounded string mapped via `Error::remote` | None code, RemoteRefusal |
| `peer_polling` business refusal | `Error::remote("PEER_REFUSAL:" + text)` | None code, RemoteRefusal; existing fallback comparisons are separate policy |
| `PqClient::send` | real pinned ML-DSA response verification and context, returns PqResponse data | No error-string parsing at this boundary |
| `PqNetworkPolicy::verify_response` | verifies signature, canonical JSON, schema, operation identity | Preserves response data; not local control |
| `Error::from(&str/String)` anywhere | exact `ErrorCode::parse` | New local_only entries deliberately absent, even if a future caller accidentally passes remote text |
| `Error::from(io/sqlite/json errors)` | typed source constructor with Transport/LocalStructure/Serialization | Source message is not reparsed into a local cancellation code |

The similarly named `growth_cli` expression `Error::from(error.error)` is a
`tempfile::PersistError`'s `std::io::Error`, not a remote JSON error field.
Existing PQ crypto-provider failures receive the fixed `PQ_NETWORK_CRYPTO:`
wrapper. Existing transaction/work relation errors are unchanged. This review
does not retroactively claim all older string-parsed Cancelled codes have
local-only provenance; its boundary is the three added PQ control identities.

## Meaningful negative controls after baseline

1. For each of the three codes, explicit construction must retain exact public
   bytes and Cancelled kind. Exact quoted text, owned String, whitespace/prefix
   lookalikes, wrapped I/O errors and serialization errors must not recover the
   local code. `Error::remote` and both authenticated terminality wrappers keep
   their original kinds and code identities. Existing parse mapping controls
   remain in the suite.
2. A real native ML-DSA signed response can quote each local diagnostic. Feed
   it through the actual PQ request/response binding, with a forged signature
   control. A valid refusal remains response data and any subsequent generic
   text conversion stays Unclassified; a forged signature is refused before
   consuming its claimed error. Preserve actual signed bytes and all cases.
3. At the actual `finish_or_cancel_reorg` boundary, use the existing explicit
   fault hook immediately after a genuine durable intent to compare a local
   constructed code with quoted-text and remote wrappers. The local case may
   cancel unpublished staging; the others must leave the pending intent
   unchanged. These are labeled origin/classification fault-injection controls,
   not reachable external-network attacks or actual elapsed-time evidence.
4. Keep the genuine production-listener deadline test, every original PQ test,
   and existing classic/authenticated remote wrapper regressions. No classical
   listener is used to recover the PQ deadline fixture.

## Real expiry extension to the regression

Predeclare five requests before the listener runs. The first real signed
request uses now+5 seconds, less than the unchanged ten-second server and
client deadlines. The three followups use their original now+60 second signed
expiry; no request is resigned or refreshed. Reuse the existing scheduling cut
after a real intent so the progress closure observes actual `now > expiry`.

Expected repaired result: lifecycle reason is `PQ_NETWORK_EXPIRED`, active
state is unchanged by cancellation, completed original record consumes its
sequence once under the existing rule, all three original honest followups
succeed, peer sequences remain exact, and live/cold State and owner fence stay
consistent. The retained signed failure's public error remains
`PQ_NETWORK_EXPIRED_UNCONFIRMED`.

The retained response can be checked historically at its original signed
expiry, with that checking time explicitly labeled. A verification at actual
current time must reject it. Replaying the identical expired request must also
be refused before live dispatch, leaving State and the ledger unchanged. It
must not inherit the deadline case's expectation that a still-valid exact
wire replay returns a cached live response. Record wall-clock observations,
all timeouts, all five calls and all failures; reaching no actual intent is a
failed/unknown cut observation, never successful expiry evidence.

## Durable revocation reachability

The successful `admit_shared_checked` call returns a MutexGuard<Node>. Both new
and existing Submit paths retain that guard across activation, durable intent,
the existing post-intent test pause, and cancellation. The real
`revoke_pq_network_peer(&mut Node)` needs the same exclusive Node and stores a
new epoch only after its revocation SQL transaction commits. No real operator
revocation can acquire that same Node while the post-intent code holds it.

Moreover the current production `serve_pq_authenticated` creates a private
Mutex and runs a serial listener. It does not expose a concurrent operator
revocation handle, and there is no remote revoke request. A test can expose a
Mutex to call private `PqServer::handle`, but that is a different concurrency
harness and must not be described as an existing service control path.

A truly durable revocation can invalidate a handle before reacquiring the Node
after unlocked work (if such a local caller is supplied), or between dispatch
return and final response accounting. Before activation it cannot create a
post-intent cancellation. After activation or deadline cleanup the reorg is
already complete/cancelled; the stale epoch prevents finish and keeps original
pending/revoked ledger rules. Original tests exercise real begin/revoke/finish,
reorg retention and cold persistence. They do not prove concurrent post-intent
revocation on the production serial listener.

Do not mutate an Atomic directly and label it revocation. A local-only Revoked
code can still express the real epoch check safely, but this round must retain
the stated reachability limit instead of manufacturing a third physical cut.

## Explicit non-claims

No original service profile or refill is relaxed. No paid CPU or callback
count is fabricated. A local test scheduling cut is not a process kill. A
successful PQ transport regression does not establish account migration,
whole-chain post-quantum security, public saturation, WAN qualification or
model improvement. Keep all corresponding qualification gates false.
