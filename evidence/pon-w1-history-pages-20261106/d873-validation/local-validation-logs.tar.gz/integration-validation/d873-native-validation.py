#!/usr/bin/env python3
"""Execute frozen local builds; never edit the candidate or claim Host acceptance."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/a66f84888260')
REPO = ROOT / 'chain-integration'
LOGS = ROOT / 'integration-validation'
HEAD = 'd87357de197db5ff750d08c96d52432e5d22a0b4'
TREE = '323d99df3155b2242aec70c1cc11215bbade2807'
CRITICAL = [
    'trillionnium/Cargo.toml',
    'trillionnium/Cargo.lock',
    'tests/fuzz/Cargo.toml',
    'tests/fuzz/Cargo.lock',
    'trillionnium/crates/trnm-pon-node/src/store.rs',
    'trillionnium/crates/trnm-pon-node/src/store/public_history.rs',
    'trillionnium/crates/trnm-pon-node/src/store/read_query_cache_tests.rs',
    'trillionnium/crates/trnm-pon-node/src/ancestry_index.rs',
    'trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs',
    'trillionnium/crates/trnm-pon-node/src/ingress/history_import.rs',
    'trillionnium/crates/trnm-pon-node/src/ingress/history_import_tests.rs',
    'trillionnium/crates/trnm-pon-node/src/peer_polling.rs',
    'trillionnium/crates/trnm-pon-node/src/public_submit.rs',
    'trillionnium/crates/trnm-crypto-primitives/src/pon_work/legal_attempt.rs',
    'trillionnium/crates/trnm-crypto-primitives/src/pon_work/legal_attempt/low_rank.rs',
    'trillionnium/crates/trnm-sqlite-io-boundary/build.rs',
]
TARGETS = [
    'public_submit_recovery', 'pinned_peer_polling', 'public_v3_from_zero',
    'public_v3_multiprocess', 'public_v3_service_campaign', 'mining_service_budget',
]


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def source_identity():
    blobs = subprocess.check_output(
        ['git', 'hash-object', '--stdin-paths'], cwd=REPO,
        input='\n'.join(CRITICAL) + '\n', text=True).splitlines()
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'parents': git('show', '-s', '--format=%P', 'HEAD').split(),
            'status_porcelain': git('status', '--porcelain'),
            'source_blobs': dict(zip(CRITICAL, blobs))}


def environment(debug0=False):
    env = os.environ.copy()
    overrides = {
        'CARGO_HOME': str(ROOT / 'cargo-home'),
        'RUSTUP_HOME': '/workspace/scratch/bf693a71b444/toolchain/rustup',
        'CARGO_TARGET_DIR': str(ROOT / 'build'),
        'CARGO_INCREMENTAL': '0',
        'CARGO_TERM_COLOR': 'never',
    }
    # The component-only debug0 override must not leak into original builds.
    for name in ('CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG'):
        env.pop(name, None)
    if debug0:
        overrides.update(CARGO_PROFILE_DEV_DEBUG='0', CARGO_PROFILE_TEST_DEBUG='0')
    env.update(overrides)
    prefix = '/workspace/scratch/bf693a71b444/toolchain/cargo/bin'
    env['PATH'] = prefix + ':' + env['PATH']
    return env, {**overrides, 'PATH_prefix': prefix}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def build(phase):
    preflight = subprocess.run(['bash', 'scripts/project-preflight.sh'], cwd=REPO,
                               capture_output=True, text=True)
    (LOGS / ('d873-' + phase + '.preflight.log')).write_text(preflight.stdout + preflight.stderr)
    assert preflight.returncode == 0, preflight.stdout + preflight.stderr
    before = source_identity()
    assert before['commit'] == HEAD and before['tree'] == TREE
    assert before['status_porcelain'] == ''
    debug0 = phase == 'debug0-library-build'
    env, recorded_env = environment(debug0)
    common = ['--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml']
    command = ['cargo', '+1.95.0']
    if phase == 'strict-clippy':
        command += ['clippy', *common, '--workspace', '--all-targets', '--all-features',
                    '-j', '1', '--message-format=json-render-diagnostics', '--', '-D', 'warnings']
    elif phase == 'release-six-build':
        command += ['test', *common, '--release', '-p', 'trnm-pon-node']
        for target in TARGETS:
            command += ['--test', target]
        command += ['--no-run', '-j', '1', '--message-format=json-render-diagnostics']
    elif debug0:
        command += ['test', *common, '-p', 'trnm-pon-node', '--lib', '--no-run', '-j', '1',
                    '--message-format=json-render-diagnostics']
    elif phase in ('metadata-workspace', 'metadata-fuzz'):
        manifest = 'trillionnium/Cargo.toml' if phase == 'metadata-workspace' else 'tests/fuzz/Cargo.toml'
        command += ['metadata', '--locked', '--offline', '--manifest-path', manifest,
                    '--all-features', '--format-version', '1']
    elif phase == 'fmt-check':
        command += ['fmt', '--manifest-path', 'trillionnium/Cargo.toml', '--all', '--', '--check']
    elif phase == 'fuzz-fmt-check':
        command += ['fmt', '--manifest-path', 'tests/fuzz/Cargo.toml', '--all', '--', '--check']
    else:
        raise ValueError(phase)
    stem = LOGS / ('d873-' + phase)
    result_path = stem.with_suffix('.result.json')
    assert not result_path.exists(), 'preserve every prior attempt'
    stdout_path = stem.with_suffix('.stdout.jsonl')
    stderr_path = stem.with_suffix('.stderr.log')
    record = {'schema': 'local-frozen-native-build-v1', 'phase': phase, 'command': command,
              'cwd': str(REPO), 'environment_overrides': recorded_env,
              'source_before': before, 'disk_free_before': shutil.disk_usage(ROOT).free,
              'stdout_log': str(stdout_path), 'stderr_log': str(stderr_path),
              'release_library_build_attempted': False, 'fixed_host_qualified': False,
              'profile_scope': 'explicit test/dev debug0 component functionality only' if debug0
                               else 'original Cargo release profile' if phase == 'release-six-build'
                               else 'strict Clippy, original default dev profile' if phase == 'strict-clippy'
                               else 'read-only dependency graph / format verification; no compilation'}
    stem.with_suffix('.command.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'phase_started': phase, 'command': command,
                      'disk_free_before': record['disk_free_before'],
                      'stderr_log': str(stderr_path)}), flush=True)
    start = time.monotonic()
    with stdout_path.open('w') as out, stderr_path.open('w') as err:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=out, stderr=err)
    record.update(returncode=result.returncode, elapsed_seconds=round(time.monotonic()-start, 3),
                  source_after=source_identity(), disk_free_after=shutil.disk_usage(ROOT).free)
    artifacts = []
    for line in stdout_path.read_text().splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if row.get('reason') == 'compiler-artifact' and row.get('executable'):
            binary = Path(row['executable'])
            artifacts.append({'target': row['target'], 'profile': row['profile'],
                              'features': row['features'], 'fresh': row['fresh'],
                              'path': str(binary), 'bytes': binary.stat().st_size,
                              'sha256': sha256(binary)})
    record['artifacts'] = artifacts
    if phase in ('metadata-workspace', 'metadata-fuzz') and result.returncode == 0:
        metadata = json.loads(stdout_path.read_text())
        record['metadata_summary'] = {
            'workspace_members': len(metadata['workspace_members']),
            'packages': len(metadata['packages']),
            'resolve_nodes': len(metadata['resolve']['nodes']),
            'full_dependencies_included': True,
        }
    record['source_unchanged'] = record['source_after'] == before
    record['complete_success'] = result.returncode == 0 and record['source_unchanged']
    result_path.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({k: v for k, v in record.items() if k not in
                      ('source_before', 'source_after', 'artifacts')}, indent=2), flush=True)
    if not record['complete_success']:
        print(stderr_path.read_text()[-5000:], flush=True)
    return 0 if record['complete_success'] else (result.returncode or 1)


if __name__ == '__main__':
    sys.exit(build(sys.argv[1]))
