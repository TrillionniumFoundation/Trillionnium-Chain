import os,sys,json,subprocess,pathlib,hashlib,datetime,time
D=pathlib.Path("/private/tmp/chain-audit-20261114-branch-graph/final-object-delta-review-v1")
O=D/"stable-recheck-v1"
O.mkdir(exist_ok=False)
R="/private/tmp/chain-audit-recovery-records-20261113/full-history-independent-v1/complete.git"
G=["/usr/bin/git","--git-dir="+R]
env={**os.environ,"GIT_NO_LAZY_FETCH":"1","GIT_OPTIONAL_LOCKS":"0","GIT_TERMINAL_PROMPT":"0"}
def run(args,**kw):
 return subprocess.run(G+args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kw)
def h(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def dump(name,v): (O/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n")
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
dump("started.json",{"started_utc":start,"pid":os.getpid(),"git_dir":R,"root_pause_message":"root paused all Git object/ref writes after 96643a2dd8a90cded0059216cae15e2cd620c77b; read-only recheck authorized","lazy_fetch":False,"git_optional_locks":False})
before=run(["for-each-ref","--format=%(refname) %(objectname)"]); before.check_returncode()
(O/"refs-before.txt").write_bytes(before.stdout)
missing=[]
for line in (D/"run-v1/git-fsck.log").read_text().splitlines():
 parts=line.split()
 if len(parts)==3 and parts[0]=="missing":
  missing.append((parts[1],parts[2]))
assert len(missing)==10,missing
paths={"original_baseline":pathlib.Path("/private/tmp/chain-consolidation-20261114-root/all-object-secret-inventory-v1/object-inventory.txt"),"delta_enumeration":D/"run-v1/object-inventory-after.txt"}
inventories={}
for k,p in paths.items():
 inventories[k]={l.split()[0]:l.split()[1:] for l in p.read_text().splitlines()}
q=run(["cat-file","--batch-check=%(objectname) %(objecttype) %(objectsize)"],input=("".join(oid+"\n" for _,oid in missing)).encode())
q.check_returncode()
(O/"missing-oid-cat-file.stdout").write_bytes(q.stdout)
(O/"missing-oid-cat-file.stderr").write_bytes(q.stderr)
rows=[]
for (kind,oid),line in zip(missing,q.stdout.decode().splitlines(),strict=True):
 p=line.split(); assert p[0]==oid
 rows.append({"oid":oid,"reported_missing_type":kind,"current_cat_file_line":line,"exists_now":len(p)==3 and p[1]==kind,"baseline_entry":inventories["original_baseline"].get(oid),"delta_enumeration_entry":inventories["delta_enumeration"].get(oid)})
root=run(["show","-s","--format=%H%n%T%n%P","96643a2dd8a90cded0059216cae15e2cd620c77b"]); root.check_returncode()
dump("missing-oid-triage.json",{"first_fsck_log_sha256":h(D/"run-v1/git-fsck.log"),"first_fsck_exit":2,"root_commit_readback":root.stdout.decode().splitlines(),"rows":rows,"all_exist_now":all(x["exists_now"] for x in rows),"all_absent_frozen_enumeration":all(x["delta_enumeration_entry"] is None for x in rows)})
print(json.dumps({"stage":"oid-triage","missing_count":len(rows),"all_exist_now":all(x["exists_now"] for x in rows),"all_absent_frozen_enumeration":all(x["delta_enumeration_entry"] is None for x in rows),"root_readback":root.stdout.decode().splitlines()},ensure_ascii=False),flush=True)
t=time.monotonic()
with (O/"git-fsck.log").open("xb") as f:
 p=subprocess.run(G+["fsck","--full","--no-reflogs"],env=env,stdout=f,stderr=subprocess.STDOUT)
elapsed=time.monotonic()-t
after=run(["for-each-ref","--format=%(refname) %(objectname)"]);after.check_returncode()
(O/"refs-after.txt").write_bytes(after.stdout)
result={"started_utc":start,"finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"command":G+["fsck","--full","--no-reflogs"],"exit_code":p.returncode,"elapsed_seconds":elapsed,"fsck_log_bytes":(O/"git-fsck.log").stat().st_size,"fsck_log_sha256":h(O/"git-fsck.log"),"refs_before_sha256":h(O/"refs-before.txt"),"refs_after_sha256":h(O/"refs-after.txt"),"refs_unchanged":before.stdout==after.stdout,"missing_triage_sha256":h(O/"missing-oid-triage.json"),"root_commit":"96643a2dd8a90cded0059216cae15e2cd620c77b","source_binding_commit":"b84568a714e24070d9554008660f1382e2c1b1b5","all_previous_missing_oids_exist_now":all(x["exists_now"] for x in rows),"all_previous_missing_oids_absent_initial_frozen_enumeration":all(x["delta_enumeration_entry"] is None for x in rows),"original_failed_fsck_preserved":True,"scope_note":"Read-only stable recheck; no repository writes/fetch/repair/prune/ref updates. Original pattern scan scope remains its frozen enumeration; post-enumeration root report/archive/doc objects are not silently included."}
dump("summary.json",result)
dump("terminal.json",{"exit":0 if p.returncode==0 and before.stdout==after.stdout else 1,"stage":"completed","summary_sha256":h(O/"summary.json")})
print(json.dumps(result,ensure_ascii=False),flush=True)
sys.exit(0 if p.returncode==0 and before.stdout==after.stdout else 1)
