from pathlib import Path
import subprocess,json,time,resource,sys,os,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=src.parent/'repository-truth-2';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);env=os.environ.copy();env['CARGO_TARGET_DIR']=str(src.parent/'target');env['TRNM_CI_RECEIPT_DIR']=str(out/'receipts')
res={'schema':'chain-original-repository-truth-local-v1','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'source_diff_sha256':__import__('hashlib').sha256(subprocess.check_output(['git','diff'],cwd=src)).hexdigest(),'command':['bash','scripts/ci/ci_job.sh','repository-truth'],'cwd':str(src),'complete':False}
(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
try:
 with (out/'stdout.log').open('xb') as so,(out/'stderr.log').open('xb') as se:rc=subprocess.call(res['command'],cwd=src,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);res.update({'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime,'complete':True});(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2),flush=True)
 print((out/'stderr.log').read_text(errors='replace')[-16000:],flush=True);sys.exit(rc)
except BaseException as e:
 if isinstance(e,SystemExit):raise
 res['error']=repr(e);(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');(out/'owner.error').write_text(traceback.format_exc());raise
