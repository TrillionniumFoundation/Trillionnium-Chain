#!/usr/bin/env python3
"""Replay the 36 task-local native transcript controls without native execution.

This is a NEW recording of controls previously evaluated in ephemeral tool cells.
It is not their original stdout and is not a product/native test execution.
All synthetic transcripts and receipt mutations remain in memory. The only
outputs are the requested report and stdout; the repository/reader stay read-only.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tarfile
import time
from unittest.mock import patch

sys.dont_write_bytecode = True
READER_SHA256 = "1020381741509dbd1694629bfe6f67bcd3db3c77064804ea6040400e6ec31934"


def expect(condition, message="control assertion failed"):
    if not condition:
        raise AssertionError(message)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def fingerprint(path):
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reader", type=Path, required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--native-output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--historical-archive", type=Path)
    args = parser.parse_args()
    args.reader = args.reader.resolve(strict=True)
    args.root = args.root.resolve(strict=True)
    args.native_output = args.native_output.resolve(strict=True)
    args.report = args.report.absolute()
    expect(digest(args.reader) == READER_SHA256, "frozen reader hash differs")
    expect(not args.report.resolve().is_relative_to(args.root), "control report must be outside source")
    expect(not args.report.exists(), "preserve previous reports; choose a new report path")
    started = datetime.now(timezone.utc).isoformat()
    monotonic = time.monotonic_ns()
    spec = importlib.util.spec_from_file_location("frozen_native_reader_controls_subject", args.reader)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    root, out = args.root, args.native_output
    runner = json.loads((out / "runner.json").read_text())
    base = json.loads((out / "compiler.json").read_text())
    compiler_log = (out / "compiler.log").read_bytes()
    results, observations = [], []

    def record(name, function, exception=None):
        item = {"id": f"C{len(results) + 1:02d}", "control": name,
                "expected": "refuse" if exception is not None else "accept/assert stated scope"}
        try:
            value = function()
            expect(exception is None, "expected refusal did not occur")
            if value is not None:
                item["observation"] = value
            item["status"] = "PASS"
        except Exception as error:
            item.update(observed_exception=type(error).__name__, observed_message=str(error))
            item["status"] = "PASS" if exception is not None and isinstance(error, exception) else "FAIL"
        results.append(item)
        print(json.dumps(item, sort_keys=True), flush=True)

    registry = module.parse_registry("a: test\nb: test\nchild: test\n\n3 tests, 0 benchmarks\n", "fixture registry")
    transcript = """running 3 tests
test a ... ok
test b ...
running 1 test
test child ... ok

test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 2 filtered out; finished in 0.00s

ok
test child ... ignored, process helper

successes:

---- b stdout ----
actual payload

successes:
    a
    b

test result: ok. 2 passed; 0 failed; 1 ignored; 0 measured; 0 filtered out; finished in 0.02s
"""

    def nested():
        value = module.parse_parent(transcript, registry, "nested control")
        expect(value["parent_passed_names"] == ["a", "b"])
        expect(value["parent_ignored_names"] == ["child"])
        expect(len(value["nested_summary_observations_not_credited"]) == 1)
        expect(value["inline_ok_names_outside_parent_pass_roster_not_credited"] == ["child"])
        expect(value["parent_pass_names_without_standalone_inline_ok"] == ["b"])

    record("nested child summary and inherited inline ok never inflate parent", nested)
    truncated = transcript[:transcript.rfind("test result:")]
    record("missing parent summary", lambda: module.parse_parent(truncated, registry, "truncated"), module.Invalid)
    record("duplicated eligible parent summary", lambda: module.parse_parent(transcript + transcript[transcript.rfind("test result:"):], registry, "duplicated"), module.Invalid)
    record("filtered child cannot replace full parent", lambda: module.parse_parent(truncated, registry, "only-child"), module.Invalid)
    record("success name roster omission", lambda: module.parse_parent(transcript.replace("    b\n", ""), registry, "omitted"), module.Invalid)
    record("success name roster duplication", lambda: module.parse_parent(transcript.replace("    b\n", "    a\n"), registry, "duplicate-name"), module.Invalid)
    record("pass/ignore overlap", lambda: module.parse_parent(transcript.replace("test child ... ignored", "test a ... ignored"), registry, "overlap"), module.Invalid)
    record("unregistered parent name", lambda: module.parse_parent(transcript.replace("    b\n", "    outsider\n"), registry, "unknown"), module.Invalid)
    record("registry summary mismatch", lambda: module.parse_registry("a: test\n\n2 tests, 0 benchmarks\n", "count"), module.Invalid)
    record("registry duplicate name", lambda: module.parse_registry("a: test\na: test\n\n2 tests, 0 benchmarks\n", "duplicate"), module.Invalid)
    record("registry missing summary", lambda: module.parse_registry("a: test\n", "no-summary"), module.Invalid)
    record("registry benchmark substitution", lambda: module.parse_registry("a: test\n\n1 test, 1 benchmark\n", "benchmark"), module.Invalid)

    def zero():
        listing = module.parse_registry("0 tests, 0 benchmarks\n", "zero-registry")
        value = module.parse_parent("running 0 tests\n\ntest result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s\n", listing, "zero-example")
        expect(value["zero_test_harness"] and not value["parent_passed_names"])

    record("zero example is explicit zero contribution", zero)

    def failed_parent():
        raw = "running 2 tests\ntest a ... ok\ntest b ... FAILED\n\nsuccesses:\n    a\n\nfailures:\n    b\n\ntest result: FAILED. 1 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s\n"
        listing = module.parse_registry("a: test\nb: test\n2 tests, 0 benchmarks\n", "fail-registry")
        value = module.parse_parent(raw, listing, "failed")
        expect(value["status"] == "FAIL" and value["parent_failed_names"] == ["b"])

    record("real parent failure retained", failed_parent)

    def separated_harnesses():
        raw = "    Finished test profile\n     Running tests/a.rs (/target/debug/deps/a-123abc)\na: test\n1 test, 0 benchmarks\n     Running tests/b.rs (/target/debug/deps/b-456def)\nb: test\n1 test, 0 benchmarks\n"
        blocks = module.split_harnesses(raw, "combined")
        expect([module.parse_registry(v["body"], v["descriptor"])["names"] for v in blocks] == [["a"], ["b"]])

    record("combined Cargo harnesses remain distinct", separated_harnesses)
    record("unbound test summary before Cargo harness", lambda: module.split_harnesses("test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s\n     Running tests/a.rs (/t/a-abc)\n", "unbound"), module.Invalid)
    record("unexpected doc harness cannot masquerade as all-targets", lambda: module.split_harnesses("     Running tests/a.rs (/t/a-abc)\n   Doc-tests a\n", "docs"), module.Invalid)
    record("duplicate JSON keys", lambda: module.decode_json('{"status":"PASS","status":"FAIL"}', "fixture"), module.Invalid)

    def new_reader():
        value = module.Reader(root, out)
        value.head, value.tree = runner["head"], runner["tree"]
        return value

    def receipt_fixture(change=None, missing_log=False):
        value = copy.deepcopy(base)
        if change is not None:
            change(value)

        def read_bytes(path):
            if path == out / "compiler.json":
                return json.dumps(value).encode()
            if path == out / "compiler.log":
                if missing_log:
                    raise module.Pending("control missing raw log")
                return compiler_log
            raise AssertionError("unexpected fixture path " + str(path))

        with patch.object(module, "read_bytes", read_bytes):
            result = new_reader().receipt("compiler")
        expect(result["status"] == "PASS")

    record("authentic source-bound compiler receipt accepted", receipt_fixture)
    record("raw transcript digest mismatch refused", lambda: receipt_fixture(lambda v: v.update(log_sha256="0" * 64)), module.Invalid)
    record("raw transcript byte count mismatch refused", lambda: receipt_fixture(lambda v: v.update(log_bytes=len(compiler_log) + 1)), module.Invalid)
    record("different before/after source refused", lambda: receipt_fixture(lambda v: v["after"].update(tested_tree="1" * 40)), module.Invalid)
    record("internally consistent wrong source refused", lambda: receipt_fixture(lambda v: (v["before"].update(tested_commit="1" * 40), v["after"].update(tested_commit="1" * 40))), module.Invalid)
    record("status exit contradiction refused", lambda: receipt_fixture(lambda v: v.update(status="command_failed")), module.Invalid)
    record("PQ qualification promotion refused", lambda: receipt_fixture(lambda v: v.update(whole_chain_quantum_security_qualified=True)), module.Invalid)
    record("running receipt stays pending", lambda: receipt_fixture(lambda v: v.update(status="running")), module.Pending)
    record("complete receipt with missing raw log stays pending", lambda: receipt_fixture(missing_log=True), module.Pending)

    def partial_report(known_failure):
        value = copy.deepcopy(base)
        if known_failure:
            value.update(status="command_failed", exit_code=7)
        mapping = {out / "runner.json": (out / "runner.json").read_bytes(), out / "compiler.json": json.dumps(value).encode()}
        final = {"phase": "native", "head": runner["head"], "tree": runner["tree"], "planned_commands": module.PLANNED,
                 "commands": [{"label": "compiler"}], "not_executed": sorted(set(module.PLANNED) - {"compiler"}),
                 "all_commands_succeeded": False, "native_execution_readback_required": True,
                 "whole_chain_pq_qualified": False, "public_wan_qualified": False, "production_activation": False}
        mapping[out / "result.json"] = json.dumps(final).encode()

        def read_bytes(path):
            if path in mapping:
                return mapping[path]
            raise module.Pending("control absent " + str(path))

        with patch.object(module, "read_bytes", read_bytes):
            result = module.Reader(root, out).read()
        expect(result["status"] == ("FAIL" if known_failure else "PENDING"), str(result["checks"]))

    record("whole report with complete receipt and missing log stays pending", lambda: partial_report(False))
    record("known failure dominates missing evidence", lambda: partial_report(True))

    def registry_text(names):
        return "".join(name + ": test\n" for name in names) + f"\n{len(names)} tests, 0 benchmarks\n"

    def transcript_text(names):
        return (f"running {len(names)} tests\n" + "".join("test " + name + " ... ok\n" for name in names)
                + "\nsuccesses:\n" + "".join("    " + name + "\n" for name in names)
                + f"\ntest result: ok. {len(names)} passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.01s\n")

    specs = [{"descriptor": "tests/a.rs", "stem": "a", "package": "test-only-control", "source": "tests/a.rs", "kind": "integration", "required_names": ["a" + str(i) for i in range(4)]},
             {"descriptor": "tests/b.rs", "stem": "b", "package": "test-only-control", "source": "tests/b.rs", "kind": "integration", "required_names": ["b" + str(i) for i in range(5)]}]
    listed, executed = "", ""
    for value in specs:
        header = "     Running " + value["descriptor"] + " (/target/debug/deps/" + value["stem"] + "-123abc)\n"
        listed += header + registry_text(value["required_names"])
        executed += header + transcript_text(value["required_names"])

    def grouped(listing, execution):
        reader = new_reader()
        reader.command = lambda label, argv: listing if label.endswith("-registry") else execution
        reader.hash_binding = lambda *a, **kw: {"control_fixture_only": True}
        result = reader.grouped("control", [], specs)
        expect([v["parent_summary"]["passed"] for v in result["harnesses"]] == [4, 5])
        expect(result["counts_added_to_node_library"] is False and result["doc_tests_status"] == "NOT_EXECUTED")

    record("4+5 grouped registry and executions remain two independent parent suites", lambda: grouped(listed, executed))
    record("missing first combined harness refused despite last passing summary", lambda: grouped(listed, executed[executed.index("     Running tests/b.rs"):]), module.Invalid)
    record("passing name from a different harness refused", lambda: grouped(listed, executed.replace("    a0\n", "    b0\n")), module.Invalid)
    record("registry/execution ELF mismatch refused", lambda: grouped(listed, executed.replace("/target/debug/deps/a-123abc", "/target/debug/deps/a-123def")), module.Invalid)

    valid = {"/target/debug/deps/a-123abc": {"sha256": "1" * 64, "bytes": 100},
             "/target/debug/trnm-pon-node": {"sha256": "2" * 64, "bytes": 200}}

    def binding(before, after):
        reader = new_reader()
        reader.receipts = {"control-registry": {"environment": {"CARGO_TARGET_DIR": "/target"}},
                           "control": {"environment": {"CARGO_TARGET_DIR": "/target"}}}
        with patch.object(module, "read_json", lambda path: before if path.name.endswith("-before.json") else after):
            result = reader.hash_binding("control", ["/target/debug/deps/a-123abc"], True)
        expect(result["ordinary_binary_separately_bound"])

    record("ordinary binary recorded separately from test ELF", lambda: binding(valid, valid))
    missing = {key: value for key, value in valid.items() if key.endswith("123abc")}
    record("ordinary binary identity omission refused", lambda: binding(missing, missing), module.Invalid)
    changed = {**valid, "/target/debug/trnm-pon-node": {"sha256": "3" * 64, "bytes": 200}}
    record("changed before/after ordinary binary identity refused", lambda: binding(valid, changed), module.Invalid)
    expect(len(results) == 36, "36 reviewed controls must remain complete")

    absent = out.parent / "reader-controls-deliberately-absent-input"
    expect(not absent.exists(), "missing-directory control path must not exist")
    value = module.Reader(root, absent).read()
    observations.append({"observation": "completely absent native phase stays PENDING", "status": "PASS" if value["status"] == "PENDING" else "FAIL",
                         "check_status_counts": value["check_status_counts"]})

    inputs = {"reader": fingerprint(args.reader), "control_script": fingerprint(Path(__file__).resolve()),
              "runner": fingerprint(out / "runner.json"), "compiler_receipt": fingerprint(out / "compiler.json"),
              "compiler_transcript": fingerprint(out / "compiler.log")}
    if args.historical_archive is not None:
        historical = args.historical_archive.resolve(strict=True)
        inputs["historical_archive"] = fingerprint(historical)
        with tarfile.open(historical, "r:gz") as archive:
            listing_raw = archive.extractfile("complete/node-registry.log").read()
            transcript_raw = archive.extractfile("complete/node-complete.log").read()
        listing_block = module.split_harnesses(listing_raw.decode(), "historical listing")[0]
        listing = module.parse_registry(listing_block["body"], "historical registry")
        execution = module.split_harnesses(transcript_raw.decode(), "historical execution")[0]
        value = module.parse_parent(execution["body"], listing, "historical parent")
        counts = (listing["tests"], value["parent_summary"]["passed"], value["parent_summary"]["ignored"],
                  value["parent_summary"]["failed"], len(value["nested_summary_observations_not_credited"]),
                  len(value["additional_running_observations_not_credited"]))
        observations.append({"observation": "authentic historical 1c14 parent transcript", "status": "PASS" if counts == (1282, 1249, 33, 0, 3, 13) and value["complete_registry_partition"] else "FAIL",
                             "registry": listing["tests"], "parent_summary": value["parent_summary"],
                             "nested_summaries_not_credited": counts[4], "additional_running_not_credited": counts[5],
                             "registry_raw_sha256": hashlib.sha256(listing_raw).hexdigest(),
                             "transcript_raw_sha256": hashlib.sha256(transcript_raw).hexdigest(),
                             "current_e36_execution_claim": False})
    for observation in observations:
        print(json.dumps(observation, sort_keys=True), flush=True)
    expect(digest(args.reader) == READER_SHA256, "frozen reader changed during controls")
    all_ok = all(v["status"] == "PASS" for v in [*results, *observations])
    report = {"schema": "task-native-reader-controls-v1", "recording_kind": "new_recording_not_original",
              "original_recording_note": "The earlier 36 controls were emitted by two ephemeral tool cells and were not spooled. This reusable script records a new execution of the same 36 assertions/refusals.",
              "scope": "cheap analysis-only parser/receipt controls; synthetic fixtures are in-memory controls, not product evidence",
              "started_utc": started, "completed_utc": datetime.now(timezone.utc).isoformat(),
              "elapsed_ns": time.monotonic_ns() - monotonic, "status": "PASS" if all_ok else "FAIL",
              "controls": results, "controls_passed": sum(v["status"] == "PASS" for v in results),
              "controls_failed": sum(v["status"] == "FAIL" for v in results), "supplementary_observations": observations,
              "inputs": inputs, "frozen_source_head": runner["head"], "frozen_source_tree": runner["tree"],
              "reader_modified": False, "repository_modified": False, "native_or_product_tests_executed": False,
              "whole_chain_pq_qualified": False, "public_wan_qualified": False, "production_activation": False,
              "does_not_override_actual_native_phase_failures": True}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    with args.report.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"status": report["status"], "report": str(args.report), "controls_passed": report["controls_passed"],
                      "controls_failed": report["controls_failed"], "recording_kind": report["recording_kind"]}, sort_keys=True), flush=True)
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
