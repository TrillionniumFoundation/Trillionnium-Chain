#!/usr/bin/env python3
"""R11 static/Python evidence only; never executes a native or Host command."""
import ast
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

import yaml

ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
OUT.mkdir(exist_ok=False)
BASE = 'ca4fcb2564c9747a9bd81df4e67bffd1a210634a'
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(ROOT/'scripts/ci'))
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT/'scripts/ci'), str(ROOT/'scripts')]


def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def same_source():
    paths = [
        'trillionnium/crates/trnm-pon-node/tests/public_v3_multiprocess.rs',
        'trillionnium/crates/trnm-pon-node/tests/support/multiprocess_phase_host.rs',
        'trillionnium/crates/trnm-pon-node/tests/support/multiprocess_support.rs',
        'scripts/ci/test_native_phase_host.py', 'scripts/ci/test_fixed_root_f0.py',
        'scripts/ci/test_fixed_root_phase_host.py', 'scripts/ci/run_native_phase_host.py',
        'scripts/ci/run_fixed_root_phase_host.py', 'scripts/ci/fixed_root_f0_ownership.py',
    ]
    rows = []
    for relative in paths:
        old, new = git('show', BASE+':'+relative), (ROOT/relative).read_bytes()
        rows.append({'path': relative, 'bytes': len(new), 'sha256': digest(new),
                     'exact_base_bytes_preserved': old == new})
        assert old == new, relative
    relative = 'trillionnium/crates/trnm-pon-node/tests/support/multiprocess_root_phase_host.rs'
    old, new = git('show', BASE+':'+relative), (ROOT/relative).read_bytes()
    operations = difflib.SequenceMatcher(None, old.splitlines(keepends=True),
                                        new.splitlines(keepends=True), autojunk=False).get_opcodes()
    assert all(op[0] in ('equal', 'insert') for op in operations)
    pins = []
    workflow = (ROOT/'.github/workflows/pon-recent-batch-acceptance.yml').read_text()
    for path, expected in re.findall(r'git hash-object ([^ )]+)\)" = ([0-9a-f]{40})', workflow):
        actual = git('hash-object', path).decode().strip()
        pins.append({'path': path, 'expected_blob': expected, 'actual_blob': actual})
        assert actual == expected, path
    assert len(pins) == 16
    return {'base': BASE, 'unchanged_files': rows, 'root_module_only_insertions': True,
            'root_module_inserted_blocks': sum(op[0] == 'insert' for op in operations),
            'root_module_original_bytes': len(old), 'root_module_current_bytes': len(new),
            'all_16_existing_workflow_blob_pins_match': True, 'pins': pins}


def syntax():
    python = ['scripts/ci/fixed_root_f0_resources.py', 'scripts/ci/test_fixed_root_resources.py',
              'scripts/run_fixed_host_root_f0.py', 'scripts/ci/finalize_fixed_root_f0.py']
    for path in python:
        ast.parse((ROOT/path).read_text(), filename=path)
    relative = '.github/workflows/pon-fixed-host-root-f0.yml'
    workflow = yaml.safe_load((ROOT/relative).read_text())
    base = yaml.safe_load(git('show', BASE+':'+relative))
    job = workflow['jobs']['fixed-host-root-f0']
    old_job = base['jobs']['fixed-host-root-f0']
    assert len(job['steps']) == len(old_job['steps']) == 10
    assert job['timeout-minutes'] == old_job['timeout-minutes']
    old_steps = {step['id']: step for step in old_job['steps'] if 'id' in step}
    for step in job['steps']:
        if step.get('id') in old_steps:
            old_step = old_steps[step['id']]
            assert step.get('timeout-minutes') == old_step.get('timeout-minutes')
        if step.get('id') in ('execution', 'preparation'):
            assert step['run'] == old_steps[step['id']]['run']
    shells, embedded = [], []
    for index, step in enumerate(job['steps']):
        if 'run' not in step:
            continue
        result = subprocess.run(['bash', '-n'], input=step['run'], text=True,
                                capture_output=True, timeout=10, env=ENV, cwd=ROOT)
        assert result.returncode == 0, result.stderr
        shells.append({'step': index, 'name': step['name'], 'bash_n_exit': result.returncode})
        for number, source in enumerate(re.findall(r"python3 - <<'PY'\n(.*?)^PY$", step['run'], re.M|re.S)):
            ast.parse(source, filename=f'{relative}:{index}:python:{number}')
            embedded.append({'step': index, 'python_block': number, 'ast_parse': True})
    return {'python_ast_files': python, 'workflow_steps': 10,
            'bash_syntax_only_no_commands_executed': shells,
            'embedded_python_ast_only': embedded,
            'original_execution_and_preparation_commands_and_all_timeouts_preserved': True}


def reader_readback():
    import run_fixed_host_root_f0 as runner
    import test_fixed_root_resources as controls
    value = controls.legacy_fixture()
    group = value['controller_identity_before']['process']['cgroup']
    outcomes = []
    for function in (runner.check_report, runner.check_f0_placement_and_timing):
        try:
            returned = function(value, group)
        except (ValueError, KeyError, TypeError) as error:
            outcomes.append({'function': function.__name__, 'accepted': False,
                             'exception': type(error).__name__, 'reason': str(error)})
        else:
            outcomes.append({'function': function.__name__, 'accepted': True, 'returned': returned})
    assert all(row['accepted'] is False for row in outcomes)
    assert all(row['reason'] == 'COMPLETE_CONTROLLER_RESOURCE_COVERAGE_REQUIRED' for row in outcomes)
    rss = value['phases'][1]['budget_samples'][0]['attacker_process_rss']
    assert rss['complete'] is False and rss['sum_rss_bytes'] is None and len(rss['processes']) == 24
    return {'scope': 'actual reader function calls over the exact retained synthetic fixture; no Host/native/resource measurement',
            'fixture_sha256': digest(controls.FIXTURE.read_bytes()),
            'fixture_bytes': controls.FIXTURE.stat().st_size,
            'rss_complete': rss['complete'], 'rss_sum_rss_bytes': rss['sum_rss_bytes'],
            'retained_actor_rows': len(rss['processes']), 'actual_function_results': outcomes}


def run(command, ordinal):
    start = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, env=ENV, capture_output=True, timeout=180)
    (OUT/f'command-{ordinal}.stdout.log').write_bytes(result.stdout)
    (OUT/f'command-{ordinal}.stderr.log').write_bytes(result.stderr)
    row = {'argv': command, 'exit_code': result.returncode, 'wall_seconds': time.monotonic()-start,
           'stdout_sha256': digest(result.stdout), 'stderr_sha256': digest(result.stderr),
           'stdout_file': f'command-{ordinal}.stdout.log', 'stderr_file': f'command-{ordinal}.stderr.log'}
    print(json.dumps(row), flush=True)
    return row


write('source-before.json', {'head': git('rev-parse','HEAD').decode().strip(),
      'tree': git('rev-parse','HEAD^{tree}').decode().strip(),
      'status': git('status','--porcelain').decode(), 'created_utc': datetime.now(timezone.utc).isoformat(),
      'audit_script_sha256': digest(Path(__file__).read_bytes()),
      'scope': 'source/Python only; no native command, Host, service, cgroup mutation or remote action'})
write('preservation.json', same_source())
write('syntax.json', syntax())
write('new-reader-counterexample-result.json', reader_readback())
commands = [
    ['bash', 'scripts/project-preflight.sh', '--audit'],
    ['python3', '-m', 'unittest', 'discover', '-s', 'scripts/ci', '-p', 'test_native_phase_host.py', '-v'],
    ['python3', '-m', 'unittest', 'discover', '-s', 'scripts/ci', '-p', 'test_fixed_root*.py', '-v'],
    ['python3', 'scripts/refresh_distributed_source_inventory.py', '--check'],
    ['python3', 'scripts/ci/check_repository.py'],
    ['git', 'diff', '--check'],
]
rows = [run(command, number) for number, command in enumerate(commands)]
write('commands.json', rows)
write('source-after.json', {'head': git('rev-parse','HEAD').decode().strip(),
      'tree': git('rev-parse','HEAD^{tree}').decode().strip(),
      'status': git('status','--porcelain').decode()})
assert all(row['exit_code'] == 0 for row in rows)
print(json.dumps({'result':'PASS', 'scope':'source/Python only', 'commands':len(rows)}))
