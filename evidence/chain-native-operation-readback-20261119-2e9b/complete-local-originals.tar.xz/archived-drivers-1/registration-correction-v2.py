from pathlib import Path
import json,subprocess,hashlib,time,resource
base=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b');src=base/'source';e=base/'current-source-registration-2';e.mkdir(exist_ok=False)
before=subprocess.check_output(['git','diff','--binary'],cwd=src)
oldres=json.loads((base/'source-gates-1/RESULT.json').read_text());assert oldres['source_unchanged'] and hashlib.sha256(before).hexdigest()==oldres['after']['tracked_patch_sha256']
with (e/'preflight.stdout').open('xb') as so,(e/'preflight.stderr').open('xb') as se:r=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=src,stdout=so,stderr=se)
assert r.returncode==0
required=[]
maturity=json.loads((src/'config/pon/module-maturity-v1.json').read_text())
for v in maturity['evidence_packages'].values():
 required.append(v['manifest'])
 if v['qualification'] is not None:required.append((Path(v['manifest']).parent/v['qualification']).as_posix())
restored=[]
for rel in sorted(set(required)):
 p=src/rel
 raw=subprocess.check_output(['git','show','HEAD:'+rel],cwd=src)
 if p.exists():assert p.read_bytes()==raw,rel
 else:
  p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:f.write(raw)
  restored.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
assert subprocess.check_output(['git','diff','--binary'],cwd=src)==before
p=src/'scripts/ci/test_w1_lifetime_current_observation.py';text=p.read_text();old="'9d79fd3c37db4a664d0a01b89e943276e07d2800cc64cb4986a1452ccf8fb820'";new="'cb063dff4cde5d2f0c60f123cd91cc4e7041964c790a05c1e2e75de6b88b2ec9'"
actual=(src/'trillionnium/crates/trnm-pon-node/src/store.rs').read_bytes();assert len(actual)==397703 and hashlib.sha256(actual).hexdigest()==new[1:-1]
assert text.count(old)==1;text=text.replace(old,new)
point="        self.assertEqual(self.contract['sources'][7]['current_sha256'],"
assert text.count(point)==1;text=text.replace(point,"        self.assertEqual(self.contract['sources'][7]['path'],\n                         'trillionnium/crates/trnm-pon-node/src/store.rs')\n        self.assertEqual(self.contract['sources'][7]['bytes'], 397703)\n"+point);p.write_text(text)
corpus=src/'config/pon/pq-cross-branch-corpus-v1.json';value=json.loads(corpus.read_text());rel=p.relative_to(src).as_posix();raw=p.read_bytes();sha=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();old_pin=value['pinned_blobs'][rel];value['pinned_blobs'][rel]=sha;corpus.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
diff=subprocess.check_output(['git','diff','--binary'],cwd=src);(e/'candidate.patch').write_bytes(diff)
res={'schema':'chain-operation-source-registration-correction-v1','restored_original_manifests_and_qualifications':restored,'preserved_first_gate_failures':'source-gates-1','historical_pin_unchanged':'b712a86b9997a098df5e8257f309d22445b2c749c9aa474457e958a0f65f5153','current_store_bytes':397703,'current_store_sha256':hashlib.sha256(actual).hexdigest(),'test_pin':{'path':rel,'previous':old_pin,'current':sha},'tracked_patch_sha256':hashlib.sha256(diff).hexdigest(),'f0_qualified':False}
(e/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res),flush=True)
