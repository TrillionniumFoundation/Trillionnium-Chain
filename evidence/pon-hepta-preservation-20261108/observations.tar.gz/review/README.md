# Independent evidence review for Chain PR #824

## Scope and conclusion

Reviewed the local runner, the original source recorder and full tracked-byte verifier, completed command receipts and logs, provider preparation and material identities, the current draft PR metadata, operating boundaries, and three observed GitHub CI failures. This review did not modify the frozen integrated source and did not run native tests or builds.

The design supports command-specific engineering evidence for runtime commit `91dd3082633ea0b3a5ec9b0ed91f28603229be01`, tree `8a14e5aa053af94d1f19cfb8b907a09c6ac4399b`. It does not support relabeling an evidence-only descendant as native-tested, and a successful selected local command roster would not establish complete hosted CI acceptance.

At the receipt observation captured in `receipt-review-observation.json`, ten commands were complete with successful, matching source-before/source-after and intact log hashes; one was running. The service crate recorded 71 tests plus two compile-fail doctests, the crypto library 186 tests, and the grouped-session example 12 tests. This is an intermediate observation, not a final campaign summary. Use the final original summary and receipts when publishing.

## Findings that support the source-specific claim

- Every recorded command calls the existing verifier before and after execution. The completed receipts identify the same runtime commit/tree and 26,120 raw tracked entries totaling 2,485,347,114 bytes. The verifier refuses sparse/hidden index entries, replacement/grafted history, dirty or missing tracked bytes, wrong modes, unsupported Git links, and changed source identity.
- Command logs retain merged stdout/stderr, exit code, bytes and SHA-256. The runner retains command failures and proceeds to collect independent results; a source-recording failure stops the campaign. Original incomplete records cannot be silently converted to successful ones by the summary.
- `--locked --offline`, explicit Rust 1.95.0, separate target storage, and provider configuration are recorded or reconstructible from the retained runner, command list and toolchain report.
- The provider preparation script hash matches the runtime source. All five listed provider inputs matched the preparation receipt when independently read during this review. Preparation truthfully claims only build and ML-DSA-65 smoke success, with native Rust testing, full upstream tests and production/whole-chain qualification explicitly not inferred.
- The Python/Rust integration command is preceded by the native example build, and the retained runner sets `TRNM_GROUPED_NATIVE` to that target. Confirm the final log contains all native test names and zero skips; a successful unittest process alone is insufficient because those classes are conditional on this environment variable.

## Remaining publication requirements

1. Seal the local run only after the final summary has every expected label exactly once, terminal receipt statuses, matching source before/after, log lengths/hashes and recorder/command return codes. Retain a failed or interrupted run as such. Do not replace its original receipt with the result of a rerun.
2. Keep native result scopes separate: affected libraries, session example, Python/native differential, the two Node integration targets, reference-model tests, lint/format, and repository/source controls. `cargo clippy --workspace` is not an executed workspace test suite.
3. Record full named-test summaries and ignored/skipped counts. In particular, include the three payment-readback regressions, all actual grouped native integration tests, four `native_task_operation_v2` tests, and two `no_gain_fees` tests when their final logs become available.
4. Preserve the prior development negative controls, including the initial factor fixture error and its correction. The settlement red run used the old `e798d7` implementation with three newly added tests. It was not execution of the unchanged base commit and has no full clean-tree before/after receipt. The separately retained `settlement-red-green-provenance.json` states the missing identity without synthesizing it.
5. Preserve the hosted CI observations as their own source-specific records, including failures, skipped stages and still-running statuses at an explicit observation time. They cannot be overwritten by local success.
6. After creating the evidence child, verify its parent and full changed-path list. Only the approved evidence paths and unlocked explanatory documents should differ from the tested runtime. Run artifact-hash/link/source-publication checks as needed, and label those checks as publication integrity, not native execution. Store the child commit ID in PR metadata after creation rather than creating a circular self-hash in its own committed manifest.

## Minimum complete evidence bundle

A deterministic archive plus a visible index is appropriate. The index should include each member's canonical relative path, bytes and SHA-256, plus the archive's own bytes and SHA-256. Retain:

- Final `summary.json`, `commands.json`, `toolchain.json`, the exact orchestration script and its SHA-256, and the supervisor log.
- Every original command receipt, raw log and recorder log, including unsuccessful records.
- Provider `provider.json` and `build-and-smoke.log`; retain the non-secret effective provider/native runner environment assignments used by the orchestration script.
- Settlement red/green/Clippy original logs and provenance; the reconstructed regression-only patch must retain its stated reconstruction provenance. Prior factored-producer logs and the original fixture-error/correction records remain development evidence.
- The original GitHub run/job metadata and raw failure logs with run attempt, job ID, source kind, candidate/base/tested commit, tested tree, observation time, and URL. Hosted prospective-merge results retain their own tested commit.
- The source-lineage declaration: tested runtime commit/tree, evidence-child parent/diff scope, `native_tests_rerun_on_evidence_child: false`, and unchanged HOLD_NO_GO/activation limits.
- The exact Hepta successor and its independent evidence reference, without asserting joint execution or borrowing historical actual-model results.

Optional additional provenance can hash the native example and provider inputs at campaign completion. Label this as a final file snapshot. The command recorder does not itself record `TRNM_GROUPED_NATIVE`, `OPENSSL_CONF` or `OPENSSL_MODULES`, or continuously attest external binary bytes; do not retroactively describe a post-run snapshot as a before/after binary measurement. The retained orchestration script and provider receipt already document how those inputs were selected.

The unrecorded pre-command Cargo preflight in the runner captures and discards its detailed output if it fails. No such failure was observed during this review. If this branch is hit, retain the supervisor failure and mark the campaign incomplete; do not reconstruct missing original output. This does not invalidate already completed, individually source-bound receipts.

## Hosted failures and inheritance evidence

`unchanged-ci-checker-inputs.json` compares ten relevant Git objects and raw byte sequences between base `e798d7125724d4b9f98c24d00cc80031f2eab4a9` and runtime `91dd3082633ea0b3a5ec9b0ed91f28603229be01`. All ten are identical. No base CI execution was performed by this review.

| Observed gate | Concrete mismatch retained | Accurate interpretation |
| --- | --- | --- |
| Run 42550894228, W1 QROM closure; head job 128945998961 | Ledger expects `store.rs` SHA-256 `b712a86b9997a098df5e8257f309d22445b2c749c9aa474457e958a0f65f5153`; base and runtime contain `108621f304255841ea2e1a7353858c3f0f5d8cb70a235f6a4aef6d57ebe0c554`. | The observed pin mismatch is present in unchanged base bytes. This PR did not introduce it. Gate remains failed. |
| Run 42550894232, W1 QROM implementation; head job 128945998920 | Historical contract bounds `w1_v2_verifier/src/main.rs` to 9,233 bytes; both base and runtime have 11,172 bytes. | The checker/contract/input mismatch is unchanged. Do not relax or repin the historical contract merely to obtain green status. |
| Run 42550894217, required baseline; prospective job 128945998654 | Durable-schema reader requires `SelectedOpen::InitializeOrRecover { growth_observation_only: bool }`; unchanged runtime uses `observation_only: bool`. Log reports 71 tests with 84 failing subcases and 22 errors. | The selected failure is explained by unchanged checker/input bytes. Preserve it as an open gate; do not claim a base run was executed. |

The prospective external-evidence job identifies tested commit `f6fd573c86cd9fa4dbb33b0a2ca854913981d6e8`, candidate `91dd3082633ea0b3a5ec9b0ed91f28603229be01`, base `e798d7125724d4b9f98c24d00cc80031f2eab4a9`, and the same tree `8a14e5aa053af94d1f19cfb8b907a09c6ac4399b`. Preserve all four identities; equal trees do not make the commits identical.

## NoGain and NoUpdate claim boundary

The native Node fee scenarios execute signed development Task funding/payment and durable reopening/reorganization under controlled resource and NoGain outcomes. They do not train a model or authenticate an independent NoUpdate evaluation, physical cost meter, real customer demand, or externally funded production settlement. A valid observed fee with NoGain is evidence that the service payment path does not require improvement; it is not a general NoUpdate qualification receipt.

The separate Python service/work settlement reference describes NoUpdate eligibility but is reference-model evidence. Neither result increases chainwork, supplies improvement-bonus qualification, or replaces a same-iteration independent evaluation/adoption/payment/next-use record. The current operating-boundaries document correctly preserves these distinctions.

## Suggested PR wording after final local results exist

> Native execution results in this evidence bundle were recorded against runtime commit `91dd3082633ea0b3a5ec9b0ed91f28603229be01`, tree `8a14e5aa053af94d1f19cfb8b907a09c6ac4399b`. The subsequent evidence-only commit carries original receipts, raw logs, their byte identities, and explanatory documentation. Native tests were not rerun against that evidence-only commit; its verification is limited to the parent/diff scope and integrity of the published artifacts. Each result retains its original tested source.
>
> The local command matrix and its final outcomes are listed in the retained summary. This is a selected native and repository validation campaign, not an assertion that all GitHub Actions passed. The observed W1 closure, W1 implementation and external-evidence-contract failures remain open and are retained with their original logs. Their checked source and checker inputs are byte-identical to the #821 base; no baseline execution is inferred from that comparison and no gate is waived.
>
> The Node scenarios establish controlled native NoGain service-fee and recovery behavior. They do not establish an independently evaluated NoUpdate, real external funding, or joint Chain/Hepta execution. Production activation and work qualification remain false; the PR remains HOLD_NO_GO.
