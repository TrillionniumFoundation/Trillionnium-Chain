# S2 — initialization, branch state and independent effects

This revision replaces the S1 storage layout; it is not an in-place database migration.
Exact code: `formal/pon-nakamoto-v1/ledger.py`; regression: `test_invariants.py` plus
all existing `DiskReorgTests` in `test_contracts.py`. The Python owner remains the
reference persistent owner; selecting native application execution does not make this
SQLite owner a completed native node.

## Owned initialization and schema identity

Before opening a new database, acquire the nonblocking exclusive owner lock. Reject
symlink leaf paths and nonempty unknown namespaces. Persist `initializing.json` containing
exact schema digest, parameter commitment and genesis. Use create-exclusive/no-follow,
fsync the intent and directory. Create all tables, indexes, metadata, genesis block,
initial KV and genesis snapshot in ONE IMMEDIATE transaction. Remove the intent and
sync the directory only after successful commit.

Four actual child-process cuts are `init-intent`, `init-schema`, `init-before-commit`
and `init-committed`. Reopening an exact owned intent recovers; an empty database without
that intent refuses `INITIALIZATION_INTENT_REQUIRED`. Wrong context refuses. Foreign
schema, extra triggers/views/indexes or different SQL projection refuse before writable
PRAGMAs. This is not protection against every hostile ancestor/sidecar replacement.

## Tables and authoritative writers

| Table | Identity | Responsibility |
|---|---|---|
| metadata | key | exact parameters and schema digest |
| blocks | block id | verified parent,height,512-bit work,header,body,proof,root |
| deltas | block,key | nullable before/after; absence differs from empty bytes |
| active | singleton | tip, logical generation, physical state_slot |
| kv | physical slot,key | canonical values for one published or staged view |
| reorg | singleton | old/new tips,logical generation,steps,cursor,status |
| events | generation,ordinal | ordered remove/add notifications |
| snapshots | block id | local root-verified checkpoint state |

`state_slot` is not a consensus field. Ordinary append applies only changed keys and
publishes head/generation/event inside one transaction. SQLite read transactions see
the complete prior or next state; logical generation increments without a full KV copy.

## Fork recovery

A real fork records exact ordered detach and attach steps and copies to one staging
slot. Each delta and cursor advancement commits together. Check expected old values,
recompute target root, then atomically publish tip/generation/slot/events and retire old
physical slots. Existing readers retain their SQLite snapshots. The eight original
cuts remain: intent; two detach cuts; three attach cuts; before-publish; published.
No partially changed state is published as a coherent root.

`recover` first completes the exact existing intent, then inspects the indexed set of
fully verified stored tips. A strictly heavier tip is activated even if a process died
between `admit` and `activate`. Equal work leaves the current tip unchanged. A peer's
claimed work total never becomes an indexed authoritative block record.

## Beyond4096 and bounded cache retention

Every128 admitted heights can retain a local checkpoint. Verify its state against the
immutable stored block root before using it. Keep at most64 non-genesis snapshots plus
genesis; missing cache falls back to original deltas, not an invented finality cutoff.
Parent heights decrease exactly and cycles reject. Progress callbacks occur every256
ancestry/replay records. All replayed delta preconditions and block roots are checked.

The storage regression above4100 includes an explicit previously-verified-history
premise; it is not generated work. The separate long_history campaign mines/verifies
actual proofs, includes signed transfers and executes a shallow fork beyond4096.
Its runtime/source/filesystem receipts are recorded separately. Replay spools the
ancestry index to an8KiB bounded buffer; state maps and root hashing remain full
reference values, not a complete incremental native authenticated tree.

## Effects and revoke linearization

Independent `EffectJournal` uses its own WAL/FULL database. `enter` validates exact
operation/payload/generation, then holds BEGIN IMMEDIATE across revocation lookup,
duplicate lookup and insert. `revoke` uses the same serialized write boundary. When
revoke commits first, entry leaves no row. When entry acquired the write boundary first,
a concurrent revoke waits; the existing entry is an observed fact, not proof the remote
effect has or has not occurred. Crash after commit cannot authorize a second dispatch.

A real Hepta final-use permit and current owner/generation must still be checked before
the physical call. This module does not issue that permit, undo an already performed
operation, or resist simultaneous rollback of every independent record. Local revocations
and effect history never follow chain undo. Compensation is a newly authorized action.

## Long-lived application records

Revision3 counts only live current-parent/current-round candidates against pending
capacity. Zero-score evaluated and expired candidates no longer consume that capacity.
Each signed contribution additionally binds its128-block intake round; a round admits
at most512 historical candidates. On a new round, old candidates and their same-round
artifact nullifiers retire, while the old signed payload is rejected by its round.
A new parent similarly invalidates old-parent admission. The new round is not evidence
of a new useful contribution: utility still requires current-parent evaluation.

Release claims verify the payee against the retained allocation root without requiring
a retired candidate row. Claim windows reserve mandatory-expiry capacity and refund
remaining escrow at the deadline. Expired task/quota objects have nonce/context-derived
identities; their deletion cannot reopen the same signed creation. Accounts, registered
work and full block/delta/event history still need a future bounded retention policy.

## Revision3: bounded-memory ancestry index

`state_at` stores ancestry IDs in an8KiB spooled file and seeks it backwards for replay.
Missing checkpoints no longer create an unbounded in-memory ID list. Strictly decreasing
validated heights rule out cycles; every recovered snapshot/delta is still root checked.
A progress callback every256 records can abort, closing the spool; a later call resumes
by verified replay rather than trusting a partial root. State maps and root recomputation
remain full reference values, and this is not a persistent resumable native WAN sync.

The storage-only4102-record regression labels its premise explicitly. The separate
`long_history.py` campaign creates actual proofs and signed transactions above4096 and
performs a shallow competing fork; its logical clock and real SQLite evidence are reported
separately from the physical-host UTC campaign. Neither establishes physical power loss.

## M08 procedure boundary and retry contract

`M08.PlanReorg` is the planning phase of `Ledger.activate(target, cut=None)`, not a
separate exported plan constructor. The target is an already admitted block identifier;
callers cannot supply its work or replacement undo steps. Existing pending intent is
completed first. Equal/lower work returns the active tip without new events. Ordinary
extension without a fault callback updates deltas/head/generation/event in one transaction
on the existing slot. An actual fork finds the common ancestor and persists the staging
copy plus exact detach/attach intent before any fork step. The current ancestry lists
are in memory and staging is a full copy: native bounded planning is still work to do.

`M08.RecoverAndPublish` is `Ledger._recover_intent(cut=None)`. It requires
`active == (old_tip, next_generation - 1)`, applies each step with its cursor transaction,
checks the final root, and publishes the active tuple/events/done/slot retirement together.
`Ledger.recover` then separately selects the best verified stored work. Do not conflate
completion of an existing intent with discovery and activation of a later heavier tip.

| Interruption or rejection | Durable state and required next action |
|---|---|
| Before staging commit | Old published state remains; caller may recompute the same target plan. |
| After intent commit | Old published state remains; resume this exact persisted intent before new admission. |
| During a delta transaction | Either prior cursor/state or next cursor/state survives; never advance one without the other. |
| Wrong before-image / generation / target root | Retain committed evidence and fence admission; diagnose corruption instead of deleting intent or manufacturing a new root. |
| Before final publication commit | Old active view remains; replay cursor/root check and retry publication. |
| After publication, before return/ACK | Done marker and events already exist; repeat recovery returns current tip, without duplicate events or effects. |
| After admission, before activation intent | Startup recovery inspects stored fully verified tips and activates strictly heavier work. |

`UNKNOWN_PARENT`, `GENERATION`, `SCHEMA`, `UNDO_ROOT`, `ROOT` and underlying SQLite/I/O
errors are not interchangeable. SQLite error or local capacity exhaustion is not proof
that the remote block is invalid. A process exception is not proof of a remote API effect.
No recovery operation clears `EffectJournal` or creates a local Hepta final-use token.
The concrete module contract and retained crash tests are linked from
[M08](../../../modules/M08_FINALITY_RECOVERY_TECHNICAL_SPEC_V1.md).

## Incoming history consumer at the existing owner

N2 in NETWORK_CLIENT defines the bounded page producer/receiver. It imports actual
header/body/proof records through Ledger.admit, never through the local checkpoint
trust premise. A per-page failure can retain a fully verified prefix; retry or reopen
uses those immutable records. Transport completion, local active-tip selection and
current transaction confirmation are separate observations. No new tables, authority
owner, genesis parameters or schema migration are introduced by this client continuation.

## Native compute caches do not replace this durable owner

The optional M06 native session and M00 compressed commitment tree are disposable
in-memory caches. `Ledger` remains the only block/delta/reorg/active-pointer SQLite owner.
A crash or ambiguous compute reply closes the cache. Restart recovers this same durable
namespace, selects the verified branch, and opens a new root-bound compute session.
Different parent state resets the session; no session sequence is a commit receipt,
undo checkpoint, authorization or evidence that a physical effect happened.

The native commitment updates changed paths, but durable maps, ancestry, application
scans and Python verification still have complete-state costs. Native paged storage,
state lifetime economics, the 16 MiB bridge capacity gap and physical power-loss testing
remain open. Existing M08 crash/reorg tests run with the explicit session backend too;
this tests composition with the reference persistent owner, not a complete native node.

## Native branch owner continuation

The M15 `trnm-pon-node` composition implements M07/M08 in `src/store.rs` without
opening the reference Ledger's database. Its fresh `native.sqlite` owns metadata,
blocks, before/after deltas, active generation/slot, KV, reorg intent/cursor, ordered
steps/events and root-checked local snapshots. A 512-bit big-endian indexed work value
is derived at native admission; no peer-supplied work total enters this table.

Initialization writes and syncs an exact context/schema intent before creating schema
and genesis in one SQLite transaction. Reopen checks the schema and context read-only
before a writable connection. Unknown empty stores, extra triggers, mismatched genesis
and duplicate native writers reject. WAL/FULL, owner file locks and inode/symlink checks
are implemented; full descriptor/sidecar race protection and coherent disk rollback
anchors remain unqualified. No process-exit test is called a physical power-cut test.

Block plus deltas commit together. A direct extension applies its deltas, checks its
root and publishes tip/generation/event atomically without copying all persistent KV.
A real fork prepares a separate slot and disk-backed ordered detach/attach steps in one
transaction. Each step validates before-images and advances its cursor atomically.
Only a matching final root permits one atomic active/events/done/old-slot publication.
Recovery completes the intent, then selects any strictly heavier verified stored block;
this includes an admission committed before its activation intent. Equal work retains
the current chain. Corrupt generation, steps, root or delta preconditions remain fenced.

Reconstruction spools ancestor identities on disk and checks snapshots/deltas/roots;
retention is not a finality threshold. Full maps/root computations and long history
remain resource costs. No Hepta operation journal, provider effect or user database is
inside this chain namespace or its undo transaction.

### Metadata-only native ancestry access

The existing native owner now separates metadata retrieval from full packet retrieval.
Ancestry/DAA/current-clock traversal uses block-ID-bound header projections, while work
admission and queried transaction inclusion still check complete packets. No stored
schema, genesis, reward, rollback or root rule changes. This removes repeated Rust-side
packet materialization but does not turn the complete-state root into persistent
incremental authenticated storage or qualify physical power loss.

### Complete-State arithmetic during Legacy persistence

The classical Legacy owner's staging, reorganization pre-COMMIT and final
publication root checks, plus ordinary admission's final current-active-State
fence, can reuse the existing M06 `FullRootArithmetic`. Its single retained
mathematical payload remains bounded to 2 MiB; every invocation supplies the complete
current State. Reuse requires the complete current leaf inputs for a partition to
match, with original canonical grammar, limits and collision checks. A contention,
poison or arithmetic failure uses the original full-root calculation. No stored
block id, expected root, cursor, cached State or validation verdict supplies the
answer. All actual SQL rows, including keys untouched by the block, are still read
and checked at their original transactional boundaries.

The ordinary-admission extension is restricted to that final active-State fence;
the generic readback wrapper and other direct-append call sites keep their
existing root paths. PQ profiles retain their complete account-State validation,
and authenticated storage and the distinct Growth commitment keep their own
relations. Original before-images,
step/cursor transactions, generation/slot checks, cancellation callbacks and one
atomic active/events publication remain. Signed-history process-cut, cold-resume,
untouched-corruption and original-error controls exercise this composition. Every
current State row and its bytes are still traversed, and the complete leaf set
is sorted. This is not touched-set authenticated execution or a COW storage
migration, and it does not qualify the original 4,105-block deadline,
four-second hostile-load screen, physical power loss or production throughput.

The ordinary-admission regression requires warmed arithmetic to reject both a
changed untouched active cell and a changed current stored root claim, after a
matched no-op trigger control succeeds. Its complete callback trace, SQL rollback,
child absence and cold reopen must preserve the original State and ROOT/owner-stop
semantics. [The source-bound continuation record](../../../../evidence/pon-business-gates-819309-final-20261107/README.md)
keeps prior native/CI failures and the new-source verification scope separate.

### Same-writer Legacy admission prefix

Classical Legacy admission may reuse one common parent prefix inside its original
post-write IMMEDIATE transaction. This is limited to a non-active parent and a
child outside the unchanged 128-height snapshot cadence. The original parent
reader first reconstructs actual SQL snapshot/delta data, checking every required
intermediate before-image, complete State root and continuity rule, then compares
that State with the executed parent. Only the following child read can consume
this private, single-use prefix. Its actual record/link, delta and complete child
root checks remain. An actual child snapshot is always read and validated when
present, including a snapshot at another height.

An active-parent read comes from KV; the child's original historical read may
instead require snapshots and intervening deltas. These are different SQL sources,
so an active parent cannot issue this prefix. PQ, Growth and Authenticated state
relations retain their original admission readers. No State or successful SQL
verdict survives the admission, and no new stored schema or commitment is created.

The original executed-transaction owner is captured before callbacks or writes.
After all intended writes and triggers, the existing `PostWriteReadback` constructor
checks the closed ordinary-table schema, normalizes prepared-schema state and
captures the no-write epoch. Prefix construction, consumption and the final check
AFTER active/ancestry/control callbacks require that same original writer. No-row
writes, DDL and transaction-control ABA invalidate reuse; the scope is never
re-stamped. An ineligible schema keeps the original two full reads, while a
replaced writer remains an integrity error, including when cancellation is its
original source. This observation is not a general immutability certificate:
Blob/backup APIs, arbitrary UDFs, virtual tables and external filesystem changes
are outside its admitted SQL graph.

Execution's prior parent check, actual inserted packet/delta readback, snapshot
retention, cancellation rollback and atomic publication remain. The component
controls compare complete SQL/State with the original reader and inject historical
corruption and same-connection writes. They do not establish the original 4,105
successful imports and cold activation under the unchanged 1,800-second server
lifetime and 30-second import deadline, or the four-second hostile-load gate.

## PN2 / P1 bounded-state delivery at the existing owner

This specifies the I03–I05 work order in the
[sole plan](../../../development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md#pn2--native-pon-chain-and-recovery),
using the existing
[permanent-account decision](../../../development/specs/pon/PERMANENT_ACCOUNT_STORAGE_BOUNDARY.md#pn2-implementation-work-order-and-interfaces).
These are required changes and gates, not newly implemented APIs. The source424
65,537-account signed complete-State reference succeeded; it did not establish
bounded-parent validation, witness-only execution or complete PN2 acceptance.

| Priority / owner | Interface change inside existing modules | Dependency and acceptance |
| --- | --- | --- |
| P1 / M00/M01 | Bind the separately selected growth profile, finite limits, account root/count/balance, complete bounded non-account root/count, issued supply and mandatory liabilities into the existing parameter/header/challenge context. | PN0 and explicit new profile/domain/namespace; independent vectors and anti-aliasing. Old-profile bytes, cap, validity and replay remain unchanged. |
| P1 / M07 -> M06, I03 | Authenticate the exact parent and aggregates before constructing the private bounded parent; replace the full-parent prerequisite only under the new root relation. | Prior profile binding; a cached block ID, supplied total or current active State cannot bind another parent. |
| P1 / M09 -> M06/M07, I04 | Supply canonical original-parent touched-account multiproofs plus complete mandatory/range inputs; return checked child commitment, reversible delta, retained roots and reservation changes. | I03 plus [complete monetary ranges](MONETARY_OBLIGATION_RANGES_V1.md#completeness-includes-future-and-zero-obligations); include due/future/zero obligations and mandatory recipients before optional transactions. |
| P1 / M07/M08 | Commit block, COW nodes, roots, deltas, branch references, reservation and active generation through the existing single writer. | I04 parity; no partial publish/ACK. Root/generation/slot fences, pending reorg cursors, cold integrity audit and independent local-effect history remain authoritative. |
| P1 / M09/M13, I05 | Reserve and retain reachable roots, undo/recovery anchors and acknowledged obligations; retrieve/repair with exact parent/query, byte bound and original deadline. | Prior durable reservation; GC cannot evict required roots or mandatory duties. Missing bytes are Unavailable, never authenticated absence or invented finality. |
| P1 / M07/M08/M15/M17 | Extend the existing [source-preserving migration](NATIVE_AUTHENTICATED_STORAGE_V1.md#explicit-migration-into-a-fresh-destination) and ordinary Node qualification to the selected growth profile. | Validate every source branch/root/account/nonce/liability and local durable fact; publish only an isolated fresh destination after exact disk readback. Preserve the recoverable source and pending reorg position. |

Freeze numeric parameters in the selected profile and the existing
[PN2 campaign](PERFORMANCE_ACCEPTANCE.md#pn1pn5-frozen-performance-and-product-campaign)
before implementation acceptance. The frozen record must contain finite
integer ceilings for permanent accounts A, working keys, all touched accounts W
(including mandatory recipients), mandatory/range rows, account/range witness
bytes, complete packet/sync-page bytes, concurrent retrievals and disk/WAL
headroom. It must also specify wall/CPU/RSS and recovery/confirmation limits,
sample counts, p95/p99 objectives and tolerances for scaling. No unspecified
limit, post-run increase or changed denominator can close the gate. Complete
packet accounting includes header, transactions, the 49,188-byte W1 certificate
and every witness. Reserve maximum future mandatory fanout before originating
optional obligations; refuse that optional admission if its future due set
cannot fit, rather than later omit maturity/refund work.

Acceptance follows the existing dependency order: profile/context -> I03/I04
differential verification -> atomic persistence/reorg -> I05 retention and
migration -> signed scaling/fault campaign. Require actual ordinary native
signed admission at 65,537 accounts and the frozen larger A points, holding W
and non-account partition within the fixed ceilings. Measure the full path at
increasing A and retained history; the target is O(W log A + bounded range/input)
validation without a full-state or per-block full-history hot-path walk.
Complete-State reference success is a differential oracle, not that cost result.

Every cohort must pass wrong-parent, omitted/extra/noncanonical proof, present
zero-balance versus absence, nonce re-entry, overflow/conservation, due/future/zero
liability completeness, mandatory expiry/refund and optional-load backpressure.
Retain all disk-full, cancellation, each persistence cut, reopen, provider loss,
GC, migration-failure, deep-fork and verified-resync results; a failed cohort
cannot disappear into aggregate throughput. Assert the old or complete new
published state, exact once-only events and no local journal/revocation rewind.
Explicitly test accessed and untouched corruption plus delayed detection/audit:
replacing full scans changes the detection model and must not silently drop the
existing pre-COMMIT/final publication protection. Process cuts remain distinct
from physical power-loss qualification.
