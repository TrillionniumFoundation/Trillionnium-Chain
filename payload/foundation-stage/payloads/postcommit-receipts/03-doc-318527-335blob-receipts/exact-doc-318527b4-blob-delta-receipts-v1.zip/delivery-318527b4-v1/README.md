# Exact documentation-head blob delta scan

Base: 96643a2dd8a90cded0059216cae15e2cd620c77b

Head: 318527b4b2a07b5037d755547acd92e46ae3aded

Tree: 91d6b1a45fc759ddf9cbc61f795a65d02d699fde

The exact diff has 531 changed paths (529 added, 2 modified), selecting 335 unique blob OIDs. Every selected blob was scanned in full: 51,101,476 raw bytes, with every Git content address verified. All five explicitly defined regex categories returned zero matches. There are no hits requiring fixture classification.

The previous 527-artifact accounting and this complete Git-diff path accounting are different scopes; path-scope-accounting.json binds every changed path to its scanned OID. No path was excluded merely because it is outside the artifact directory.

This reused the disclosed new regex definitions exactly (SHA256 33cdf0d872006fd692c72388443f0e8a47e804cfe679b28c6e612074ef5cf479), not an unknown earlier scanner. No complete-object rescan, fsck, fetch, checkout/ref mutation or recursive archive decoding occurred. No claim excludes every possible secret type. These external receipts and any newer publication/archive objects are outside this audited commit.

Raw NUL-delimited Git diff, all path/OID mappings, individual blob hashes/coverage, exact driver, timestamps, explicit scope, result and authoritative terminal are included. The external delivery.json hashes the ZIP and receipt index; the index does not hash itself.
