//! Full fresh-State binding versus the retained full-map preparation path.
use super::*;
use serde_json::json;

fn fixture(count: usize, width: usize) -> State {
    (0..count)
        .map(|index| (format!("unchanged:{index:05}"), json!("x".repeat(width))))
        .collect()
}

// Bypass checked_snapshot's sharing selector. This is the original entry path,
// including every actual encoder allocation, budget decision and tree check.
fn original(
    state: &State,
    expected: Hash,
    prior: Option<&CheckedCommitment>,
    limits: CacheLimits,
    arithmetic: Option<&FullRootArithmetic>,
) -> Result<PreparedCommitment> {
    let prepared = prepare_state_with_arithmetic(state, prior, None, limits, arithmetic)?;
    if prepared.root != expected {
        return Err("COMMITMENT_ROOT");
    }
    Ok(prepared)
}

fn equal(actual: &PreparedCommitment, reference: &PreparedCommitment) {
    assert_eq!(actual.root, reference.root);
    assert_eq!(actual.observation, reference.observation);
    let changes = |prepared: &PreparedCommitment| {
        prepared
            .changes
            .iter()
            .map(|change| {
                (
                    change.key.clone(),
                    change.before.clone(),
                    change.after.clone(),
                )
            })
            .collect::<Vec<_>>()
    };
    assert_eq!(changes(actual), changes(reference));
    assert_eq!(actual.snapshot.is_some(), reference.snapshot.is_some());
    if let (Some(actual), Some(reference)) = (&actual.snapshot, &reference.snapshot) {
        assert_eq!(actual.values, reference.values);
        assert_eq!(actual.tree.root(), reference.tree.root());
        assert_eq!(
            actual.retained_charge_bytes(),
            reference.retained_charge_bytes()
        );
    }
}

fn compare(
    state: &State,
    expected: Hash,
    prior: Option<&CheckedCommitment>,
    limits: CacheLimits,
    arithmetic: Option<&FullRootArithmetic>,
) -> Result<PreparedCommitment> {
    ALLOCATION_STAGES.with(|stages| stages.borrow_mut().clear());
    let reference = original(state, expected, prior, limits, arithmetic);
    let reference_stages = ALLOCATION_STAGES.with(|stages| stages.take());
    let actual =
        checked_snapshot_with_optional_arithmetic(state, expected, prior, limits, arithmetic);
    let actual_stages = ALLOCATION_STAGES.with(|stages| stages.take());
    assert_eq!(actual_stages, reference_stages);
    match (&actual, &reference) {
        (Ok(actual), Ok(reference)) => equal(actual, reference),
        (Err(actual), Err(reference)) => assert_eq!(actual, reference),
        _ => panic!("binding disagrees: actual={actual:?}, reference={reference:?}"),
    }
    actual
}

#[test]
fn unchanged_snapshot_shares_only_after_full_actual_bytes_match() {
    for state in [State::new(), fixture(1, 0), fixture(257, 512)] {
        let limits = CacheLimits::default();
        let root = pon_executor::root(&state).unwrap();
        let seed = original(&state, root, None, limits, None)
            .unwrap()
            .snapshot
            .unwrap();
        let independent_state = state.clone();
        for actual in [&state, &independent_state] {
            let prepared = compare(actual, root, Some(&seed), limits, None).unwrap();
            let snapshot = prepared.snapshot.as_ref().unwrap();
            assert!(Arc::ptr_eq(&snapshot.values, &seed.values));
            assert_eq!(prepared.observation.changed_keys, 0);
            assert_eq!(prepared.observation.method, CommitmentMethod::CheckedApply);
            let prior_path = original(actual, root, Some(&seed), limits, None).unwrap();
            assert!(!Arc::ptr_eq(
                &prior_path.snapshot.unwrap().values,
                &seed.values
            ));
        }
        assert_eq!(seed.values.as_ref(), &encode(&state).unwrap());
    }
}

#[test]
fn unchanged_snapshot_retains_exact_capacity_charges_and_all_budget_boundaries() {
    // Include canonical encoder growth boundaries and nested/escaped values.
    let mut state: State = [0, 1, 126, 127, 128, 129, 4080, 4094]
        .into_iter()
        .enumerate()
        .map(|(index, width)| (format!("capacity:{index}"), json!("x".repeat(width))))
        .collect();
    state.insert("nested".into(), json!({"array":[1,true,null,"a\"b\\c\n"]}));
    let root = pon_executor::root(&state).unwrap();
    let seed = original(&state, root, None, CacheLimits::default(), None)
        .unwrap()
        .snapshot
        .unwrap();
    let current = charges(&seed.values).unwrap();
    let workspace = workspace_charge(current, current, 0).unwrap();
    let arithmetic = FullRootArithmetic::default();
    for keys in [state.len() - 1, state.len(), state.len() + 1] {
        for payload in [current.payload - 1, current.payload, current.payload + 1] {
            for bound in [workspace - 1, workspace, workspace + 1] {
                let limits = CacheLimits {
                    max_keys: keys,
                    max_payload_bytes: payload,
                    max_workspace_charge_bytes: bound,
                };
                for arithmetic in [None, Some(&arithmetic)] {
                    let prepared = compare(&state, root, Some(&seed), limits, arithmetic).unwrap();
                    if let Some(snapshot) = prepared.snapshot {
                        assert!(Arc::ptr_eq(&snapshot.values, &seed.values));
                    }
                }
            }
        }
    }
    for limits in [
        CacheLimits {
            max_keys: 0,
            ..CacheLimits::default()
        },
        CacheLimits {
            max_payload_bytes: 0,
            ..CacheLimits::default()
        },
        CacheLimits {
            max_workspace_charge_bytes: 0,
            ..CacheLimits::default()
        },
    ] {
        assert!(
            compare(&state, root, Some(&seed), limits, Some(&arithmetic))
                .unwrap()
                .snapshot
                .is_none()
        );
    }
}

#[test]
fn unchanged_snapshot_misleading_root_and_changed_bytes_take_original_repair_path() {
    let state = fixture(8, 32);
    let limits = CacheLimits::default();
    let root = pon_executor::root(&state).unwrap();
    let seed = original(&state, root, None, limits, None)
        .unwrap()
        .snapshot
        .unwrap();
    let arithmetic = FullRootArithmetic::default();
    for key in ["unchanged:00000", "unchanged:00007"] {
        let mut changed = state.clone();
        changed.insert(key.into(), json!("y".repeat(32)));
        assert_eq!(
            compare(&changed, root, Some(&seed), limits, Some(&arithmetic)).unwrap_err(),
            "COMMITMENT_ROOT"
        );
        let changed_root = pon_executor::root(&changed).unwrap();
        let updated = compare(&changed, changed_root, Some(&seed), limits, None).unwrap();
        assert_eq!(updated.observation.changed_keys, 1);
        assert!(!Arc::ptr_eq(
            &updated.snapshot.unwrap().values,
            &seed.values
        ));
        // Even an internally damaged matching root is only a hint. Actual bytes
        // differ; the original path checks/repairs the inconsistent prior tree.
        let mut misleading = seed.clone();
        misleading.root = changed_root;
        let repaired = compare(&changed, changed_root, Some(&misleading), limits, None).unwrap();
        assert_eq!(
            repaired.observation.method,
            CommitmentMethod::FullRoot(FullRootReason::InternalSnapshotMismatch)
        );
        assert!(repaired.snapshot.is_none());
    }
    let mut inserted = state.clone();
    inserted.insert("new".into(), json!(1));
    assert_eq!(
        compare(&inserted, root, Some(&seed), limits, None).unwrap_err(),
        "COMMITMENT_ROOT"
    );
    compare(
        &inserted,
        pon_executor::root(&inserted).unwrap(),
        Some(&seed),
        limits,
        None,
    )
    .unwrap();
    let mut removed = state.clone();
    removed.remove("unchanged:00000");
    compare(
        &removed,
        pon_executor::root(&removed).unwrap(),
        Some(&seed),
        limits,
        None,
    )
    .unwrap();
    assert_eq!(seed.values.as_ref(), &encode(&state).unwrap());
    assert!(Arc::ptr_eq(
        &compare(&state, root, Some(&seed), limits, None)
            .unwrap()
            .snapshot
            .unwrap()
            .values,
        &seed.values
    ));
}

#[test]
fn unchanged_snapshot_keeps_late_canonical_errors_before_wire_and_cache_limits() {
    let state = fixture(4, 8);
    let root = pon_executor::root(&state).unwrap();
    let seed = original(&state, root, None, CacheLimits::default(), None)
        .unwrap()
        .snapshot
        .unwrap();
    let invalid = CacheLimits {
        max_keys: MAX_CACHE_KEYS + 1,
        ..CacheLimits::default()
    };
    for limits in [CacheLimits::default(), invalid] {
        for expected in [root, [9; 32]] {
            let mut changed = state.clone();
            changed.insert("unchanged:00000".into(), json!("x".repeat(4095)));
            assert_eq!(
                compare(&changed, expected, Some(&seed), limits, None).unwrap_err(),
                "LIMIT"
            );
            for (malformed, error) in [(json!("非ASCII"), "NONCANONICAL"), (json!(1.5), "RANGE")] {
                changed.insert("unchanged:00003".into(), malformed);
                assert_eq!(
                    compare(&changed, expected, Some(&seed), limits, None).unwrap_err(),
                    error
                );
            }
            let mut long_key = state.clone();
            let value = long_key.remove("unchanged:00000").unwrap();
            long_key.insert("z".repeat(161), value);
            assert_eq!(
                compare(&long_key, expected, Some(&seed), limits, None).unwrap_err(),
                "LIMIT"
            );
        }
    }
    assert_eq!(
        compare(&state, root, Some(&seed), invalid, None).unwrap_err(),
        "COMMITMENT_CACHE_LIMIT"
    );
    assert_eq!(
        compare(&state, [9; 32], Some(&seed), CacheLimits::default(), None).unwrap_err(),
        "COMMITMENT_ROOT"
    );
}

#[test]
fn unchanged_candidate_early_miss_retains_complete_late_validation() {
    let state = fixture(4, 8);
    let limits = CacheLimits::default();
    let root = pon_executor::root(&state).unwrap();
    let seed = original(&state, root, None, limits, None)
        .unwrap()
        .snapshot
        .unwrap();
    let check = |actual: &State, expected_error| {
        // The candidate deliberately stops before reaching the late error.
        // Its miss is not an acceptance/rejection decision: the public entry
        // must still return the original complete preparation's final error.
        assert!(!matches_unchanged_candidate(actual, &seed.values).unwrap());
        assert_eq!(
            compare(actual, root, Some(&seed), limits, None).unwrap_err(),
            expected_error
        );
    };
    let mut actual = state.clone();
    actual.insert("unchanged:00000".into(), json!("y".repeat(8)));
    for (late, error) in [
        (json!("非ASCII"), "NONCANONICAL"),
        (json!(1.5), "RANGE"),
        (json!("x".repeat(4095)), "LIMIT"),
    ] {
        actual.insert("unchanged:00003".into(), late);
        check(&actual, error);
    }
    actual.remove("unchanged:00003");
    actual.insert("z".repeat(161), json!(0));
    check(&actual, "LIMIT");
    actual.insert("unchanged:00002".into(), json!("非ASCII"));
    check(&actual, "NONCANONICAL");

    let mut key_mismatch = state.clone();
    let value = key_mismatch.remove("unchanged:00000").unwrap();
    key_mismatch.insert("early-key-mismatch".into(), value);
    key_mismatch.insert("unchanged:00002".into(), json!("x".repeat(4095)));
    key_mismatch.insert("unchanged:00003".into(), json!(1.5));
    check(&key_mismatch, "RANGE");

    // With no earlier difference, a candidate cannot hide a late canonical error.
    let mut late_only = state.clone();
    late_only.insert("unchanged:00003".into(), json!("非ASCII"));
    assert_eq!(
        matches_unchanged_candidate(&late_only, &seed.values).unwrap_err(),
        "NONCANONICAL"
    );
    assert_eq!(
        compare(&late_only, root, Some(&seed), limits, None).unwrap_err(),
        "NONCANONICAL"
    );
}

#[test]
fn unchanged_snapshot_empty_delta_still_checks_the_original_tree_root() {
    let state = fixture(17, 64);
    let limits = CacheLimits::default();
    let root = pon_executor::root(&state).unwrap();
    let seed = original(&state, root, None, limits, None)
        .unwrap()
        .snapshot
        .unwrap();
    let mut broken = seed.clone();
    broken.tree = StateTree::default();
    let prepared = compare(&state, root, Some(&broken), limits, None).unwrap();
    assert_eq!(
        prepared.observation.method,
        CommitmentMethod::FullRoot(FullRootReason::InternalSnapshotMismatch)
    );
    assert!(prepared.snapshot.is_none());
    assert!(broken.tree.is_empty());
    assert_eq!(broken.values, seed.values);
    let (bound, observation) =
        CheckedExecutionParent::check_and_bind(&state, root, Some(&seed), limits).unwrap();
    assert!(std::ptr::eq(bound.state, &state));
    assert!(Arc::ptr_eq(&bound.actual, &seed.values));
    assert_eq!(observation.method, CommitmentMethod::CheckedApply);
}

#[test]
#[ignore = "explicit paired component cost, including adversarial same-root hints; no throughput qualification"]
fn unchanged_snapshot_full_binding_cost() {
    use std::hint::black_box;
    use std::time::Instant;
    let limits = CacheLimits::default();
    for (keys, width) in [(128, 64), (1024, 512), (4096, 512)] {
        let state = fixture(keys, width);
        let root = pon_executor::root(&state).unwrap();
        let seed = original(&state, root, None, limits, None)
            .unwrap()
            .snapshot
            .unwrap();
        let mut first_mismatch = state.clone();
        first_mismatch.insert("unchanged:00000".into(), json!("y".repeat(width)));
        let mut last_mismatch = state.clone();
        last_mismatch.insert(
            format!("unchanged:{:05}", keys - 1),
            json!("y".repeat(width)),
        );
        for (case, actual) in [
            ("unchanged", &state),
            ("same_root_hint_first_value_changed", &first_mismatch),
            ("same_root_hint_last_value_changed", &last_mismatch),
        ] {
            let reference = original(actual, root, Some(&seed), limits, None);
            let checked = checked_snapshot(actual, root, Some(&seed), limits);
            match (&reference, &checked) {
                (Ok(reference), Ok(checked)) => equal(checked, reference),
                (Err(reference), Err(checked)) => assert_eq!(checked, reference),
                _ => panic!("component arms disagree"),
            }
            let mut samples: [Vec<u128>; 2] = [Vec::new(), Vec::new()];
            for sample in 0..12 {
                for arm in if sample % 2 == 0 { [0, 1] } else { [1, 0] } {
                    let start = Instant::now();
                    for _ in 0..8 {
                        let result = if arm == 0 {
                            original(black_box(actual), root, Some(&seed), limits, None)
                        } else {
                            checked_snapshot(black_box(actual), root, Some(&seed), limits)
                        };
                        drop(black_box(result));
                    }
                    samples[arm].push(start.elapsed().as_nanos());
                }
            }
            println!(
                "{}",
                json!({
                    "schema":"unchanged-snapshot-full-binding-cost-v1",
                    "case":case, "state_keys":keys, "value_width":width,
                    "bindings_per_sample":8, "samples_per_arm":12,
                    "original_full_map_ns":samples[0], "checked_shared_map_ns":samples[1],
                    "order":"alternating paired arms", "equal_result":true,
                    "complete_actual_state_compared":true, "expected_root_checked":true,
                    "tree_empty_delta_check_retained":true,
                    "mismatch_path":"candidate stops at first mismatch; original full-map preparation rechecks all actual rows",
                    "scope":"full component binding and output destruction; unchanged cache limits",
                    "public_tps_measured":false, "node_owner_measured":false,
                    "physical_memory_bound":false
                })
            );
        }
    }
}
