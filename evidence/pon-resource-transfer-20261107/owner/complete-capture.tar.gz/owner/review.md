# Native owner exact-source review

**PASS.** The exact-source campaign and the separate read-only audit agree. This record concerns source `e95e2eb9f456a37ec8841def69db79f49fbba7cb` (tree `c815d3710d5f7feffc043aed1aa6e003e03d3a10`), binary SHA-256 `b3919ad3b5983f727a0dc11178d2d7d5363193a179567bf0ce264f4e5fadff48`, one protected journal and one explicitly trusted owner. The audit passed **308 checks**, including **62 independent Ed25519 signature checks** (2 capsule, 30 receiver, 30 owner), 30 raw frame pairs, the final SQLite rows and all 13 native child exits.

## Observed result

| Quantity | Exact campaign observation |
| --- | ---: |
| Reserved slots / cap | 12 / 12 |
| Full completed owner callbacks | 11 |
| Reserved slot left unused after candidate closure | 1 |
| Owner chain-step calls / conditional cap | 704 / 768 |
| Owner seed calls | 11 |
| Verified Cell calls | 11 |
| Rejected relation endpoints / verified hits | 8 / 3 |
| Request / response retained application bytes | 53,460 / 34,333 |
| New chainwork | 0 |

Two registered public fixture identities ran in eight receiver process instances across four owner restarts. All contenders used the same journal. Cached responses created no additional callback and represent historical receipts; current expiry or branch context is not revalidated by a cached reply.

## Cost reconciliation

Five preparations (initial preparation plus four owner startups) each recomputed 16 direct business observations. Each preparation cost 394,752 direct MACs and 2,313 cached model merge additions: the totals are **1,973,760 direct MACs** and **11,565 merge additions**, outside callback K. The 11 completely verified owner Cells cost **407,088 reference MACs**. The original campaign also performed an independent Python reference of **37,008 MACs and 48 additions**, plus producer **192 step and 3 seed queries**. Forged-zero endpoint requests required zero producer chain steps but still triggered the counted full owner replay.

Original campaign controller interval: **1.416463437 s wall**, **0.467804997 s parent CPU**, **0.951599 s all-child CPU**. All-child CPU includes source replay and git helpers. Native wait4 CPU is a subset: owner **0.092682 s**, receivers **0.021802 s**, initial preparation **0.018605 s**, total **0.133089 s**. Nested callback timing is already included in these process costs and must not be added again. Parent startup/import/exit, final report encoding, WAN/TLS and production services are outside the recorded interval.

The additional audit used **384 chain steps, 6 seeds, 37,008 reference MACs and 48 additions**; its measured interval was **0.077015886 s wall / 0.066214721 s CPU**. These are post-campaign costs and are not inside the owner's K cap or the original campaign timing. Audit report and script are preserved in `audit/`.

## Accounting and authority limits

These are single-run, single-journal observations. The smoke runs and native tests reused deterministic historical fixtures; fixing this run's schedule before its recorded probes does not establish a challenge that had never been tried before. An expanded accounting horizon must include earlier assistance and subsequent audit work. Partial failed-run costs that were never captured remain unknown. The three scheduled verified hits are observations, not a success-rate estimate or a proof of random-oracle premises.

The callback result is conditional on a sole protected owner: `Q_V_callbacks <= K * R * L = 12 * 1 * 64 = 768`. It does not include other services or cloned ledgers, and it does not imply a universal CPU/GPU/energy/funding or fresh-neural-computation lower bound. Step-domain queries are separate units from seed hashes, signatures, all SHA-256 calls, MACs, bytes or elapsed time. Public fixture signatures do not establish independent authorization, real demand or key custody. Preparing canonical products supplies the producer with neural results. Production activation remains false.

Retained byte counts describe one-frame-per-connection fixture traffic, not complete TCP wire traffic or adversarial trailing bytes. SQLite/crash checks here exercise process-restart behavior on tmpfs, not power-loss durability or hostile host rollback. No timing speedup is inferred from comparison with the separate fanout workload.

## Preserved evidence

`formal-campaign/` is a byte-identical copy of the exact run. `development/` preserves both smoke captures, early observations and the original development manifest unchanged. `logs/` includes failed and passed builds, tests, Clippy, smoke and formal/audit runs. `build/` records the final frozen source hashes and successful release build plus **18 passing native tests**. The strict Clippy pass retains the local SQLite loader-path qualification warning. `archive-manifest.json` maps every copied file to its original path, byte count and SHA-256; no historical source or evidence was overwritten.
