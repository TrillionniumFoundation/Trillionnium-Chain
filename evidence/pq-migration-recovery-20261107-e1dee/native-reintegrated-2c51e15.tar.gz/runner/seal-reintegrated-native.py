#!/usr/bin/env python3
"""Seal reintegrated validation and raw failed preparation with original file bytes."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tarfile

TASK = Path('/home/qian-qi/work/chain-pq-migration-recovery-e1dee-20261106')
OUT = TASK / 'records/native-reintegrated-r2'
PRIOR_OUT = TASK / 'records/native-reintegrated'
HEAD = '2c51e15e5b4f57b133b53cc9c386431e29563db5'
TREE = '3f62762d719765b920cb7c7f1c1621440f98818e'
STEM = 'native-reintegrated-evidence-2c51e15'
ENVIRONMENT_SHA256 = '5c9c21a7045e09aca9eab347a222c886dc56e5e10b7935f51b7dfe9f5a4a937a'
RUNNER_SHA256 = '213204867ab9931bd62f4355298bc02fa62c7440882da6ce47eb3dc897816939'
HELPER_SHA256 = 'fdd330aacfa3ccd65aa5740c433c76a284df8241e14ab80f31e9396fed4ed1b9'
PUBLIC_ENV = {'OPENSSL_DIR', 'OPENSSL_MODULES', 'OPENSSL_STATIC', 'OPENSSL_CONF',
              'TRNM_PQ_OPENSSL', 'TRNM_PQ_OPENSSL_VERSION', 'TRNM_PQ_OPENSSL_SHA256',
              'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
              'RUSTUP_TOOLCHAIN', 'RUSTC', 'RUSTDOC', 'RUST_TEST_THREADS', 'PATH',
              'PYTHONDONTWRITEBYTECODE'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def stable_read(path):
    path = Path(path)
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise RuntimeError('nonregular evidence member: ' + str(path))
    data = path.read_bytes()
    after = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    if any(getattr(before, k) != getattr(after, k) for k in fields) or len(data) != after.st_size:
        raise RuntimeError('evidence changed during read: ' + str(path))
    if data.startswith(b'\x7fELF'):
        raise RuntimeError('ELF bodies are outside this evidence archive')
    return data


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def publish(path, data):
    with Path(path).open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.chmod(path, 0o444)
    with Path(path).open('rb') as stream:
        os.fsync(stream.fileno())


def main():
    runtime = json.load(sys.stdin)
    terminal = json.loads(next(c['text'] for c in runtime['native_terminal']['content'] if c['type'] == 'text'))
    if not (terminal['job_id'] == '1a1b3a2b972-fc05-83fc' and terminal['state'] == 'succeeded'
            and terminal['exit_code'] == 0 and terminal['output_complete'] and terminal['output_durable']
            and not terminal['automatic_retry'] and not terminal['timed_out'] and not terminal['cancelled']):
        raise RuntimeError('native job has no successful complete terminal receipt')
    previous_terminal = json.loads(next(c['text'] for c in runtime['attempt1_terminal']['content'] if c['type'] == 'text'))
    if not (previous_terminal['job_id'] == '1a1b39e541b-fc05-83e0'
            and previous_terminal['state'] == 'failed' and previous_terminal['exit_code'] == 1
            and previous_terminal['output_complete'] and previous_terminal['output_durable']
            and not previous_terminal['automatic_retry'] and not previous_terminal['timed_out']
            and not previous_terminal['cancelled']):
        raise RuntimeError('first failed preparation lacks its complete terminal receipt')
    prior_failure_bytes = stable_read(PRIOR_OUT / 'failure.json')
    if sha(prior_failure_bytes) != '4411029a20fa5c903656b7fe5e341adb66bbec555ea3dd2bfa36a4a2b7f77066':
        raise RuntimeError('original failed preparation record changed')
    prior_failure = json.loads(prior_failure_bytes)
    prior_source = {'head': '9fb011c4af1f9f54353207f9ad9fbc54ab6235e3',
                    'tree': '5f4f1730e0f5218e4db9706e6daf2c25cde5c182', 'status_porcelain': ''}
    if (prior_failure['commands'] or prior_failure['status'] != 'failed'
            or prior_failure['reintegrated_source_after_failure'] != prior_source):
        raise RuntimeError('first attempt is not the preserved zero-test preparation failure')
    retention_bytes = stable_read(PRIOR_OUT / 'prior-9fb-elf-retention.json')
    if sha(retention_bytes) != 'b24eb77a0b6b2d520e71e71df68654af53e87f134c82136a1982589ed265b938':
        raise RuntimeError('original eleven-ELF retention record changed')
    retention = json.loads(retention_bytes)
    reference = json.loads(stable_read(OUT / 'prior-9fb-elf-retention-reference.json'))
    if (len(retention) != 11 or reference['entries'] != retention or reference['new_elf_copies'] != 0
            or not reference['rechecked_existing_copies']
            or reference['source_record_sha256'] != sha(retention_bytes)):
        raise RuntimeError('second attempt did not reference the preserved original eleven ELF copies')
    for row in retention:
        path = Path(row['retained'])
        if path.is_symlink() or path.stat().st_size != row['size'] or file_sha(path) != row['sha256']:
            raise RuntimeError('previously retained ELF identity changed before sealing')
    prior_archive = TASK / 'records/native-integrated-evidence-9fb011c.tar.gz'
    if (prior_archive.stat().st_size != 84068
            or file_sha(prior_archive) != '278b6ac2f1266f8c881d8cf114e1effa52bde7a6a530e4a72e718d480e273ff5'):
        raise RuntimeError('previously sealed 9fb archive changed')
    if json.loads(stable_read(OUT / 'prior-9fb-source-before.json')) != prior_source:
        raise RuntimeError('prior 9fb source before qualification differs')
    if json.loads(stable_read(OUT / 'prior-9fb-source-after.json')) != prior_source:
        raise RuntimeError('prior 9fb source after qualification differs')
    complete = json.loads(stable_read(OUT / 'complete.json'))
    if complete['status'] != 'completed' or complete['tested_source'] != HEAD or complete['tested_tree'] != TREE:
        raise RuntimeError('native completion does not name the integrated tested source')
    expected_counts = {'checkpoint': 56, 'node-migration': 7, 'm06-migration': 7,
                       'root-separation': 7, 'sealed': 7,
                       'integration-claim-cold-open': 1, 'integration-signatures-domain': 1,
                       'integration-unsupported-source': 1}
    if set(complete['tests']) != set(expected_counts):
        raise RuntimeError('integrated completion has a different native suite set')
    for name, count in expected_counts.items():
        observed = complete['tests'][name]
        if observed['failed'] or observed['ignored'] or len(observed['passed']) != count:
            raise RuntimeError('integrated suite was not fully passed: ' + name)
    environment_bytes = stable_read(TASK / 'environment.json')
    if sha(environment_bytes) != ENVIRONMENT_SHA256:
        raise RuntimeError('configured native environment changed')
    extra = json.loads(environment_bytes)
    if set(extra) != PUBLIC_ENV or not all(isinstance(v, str) for v in extra.values()):
        raise RuntimeError('environment is not the exact public selected configuration')
    provider = Path(extra['TRNM_PQ_OPENSSL'])
    before = file_sha(provider)
    if before != extra['TRNM_PQ_OPENSSL_SHA256']:
        raise RuntimeError('provider digest changed')
    environment = os.environ.copy()
    environment.update(extra)
    version = subprocess.run([str(provider), 'version'], env=environment, capture_output=True,
                             text=True, timeout=20, check=False)
    after = file_sha(provider)
    if version.returncode or before != after or 'OpenSSL ' + extra['TRNM_PQ_OPENSSL_VERSION'] not in version.stdout:
        raise RuntimeError('provider version/digest observation failed')
    observation = {'scope': 'public-provider-executable-identity-only', 'host_alias': 'rog',
                   'observed_utc': datetime.now(timezone.utc).isoformat(),
                   'path': str(provider), 'size': provider.stat().st_size,
                   'sha256_before': before, 'sha256_after': after,
                   'argv': [str(provider), 'version'], 'exit_code': version.returncode,
                   'stdout': version.stdout, 'stderr': version.stderr}
    members = {}
    recorded_environment = None
    for path in sorted(OUT.rglob('*')):
        if path.is_dir():
            continue
        if path.suffix not in ('.json', '.log'):
            raise RuntimeError('unselected evidence file: ' + str(path))
        data = stable_read(path)
        members['records/native-reintegrated-r2/' + path.relative_to(OUT).as_posix()] = data
        if path.suffix == '.json':
            receipt = json.loads(data)
            if isinstance(receipt, dict) and receipt.get('schema') == 'trnm-pq-native-command-v1':
                if not (receipt['status'] == 'command_succeeded' and receipt['exit_code'] == 0
                        and receipt['before'] == receipt['after']
                        and receipt['before']['tested_commit'] == HEAD
                        and receipt['before']['tested_tree'] == TREE):
                    raise RuntimeError('unsuccessful/wrong-source command receipt: ' + str(path))
                if recorded_environment is None:
                    recorded_environment = receipt['environment']
                elif receipt['environment'] != recorded_environment:
                    raise RuntimeError('command public environment changed between native gates')
                log_name = receipt['log_file']
                if Path(log_name).name != log_name:
                    raise RuntimeError('unexpected command log path')
                log = stable_read(OUT / log_name)
                if sha(log) != receipt['log_sha256'] or len(log) != receipt['log_bytes']:
                    raise RuntimeError('command log differs from original receipt')
    for path in sorted(PRIOR_OUT.rglob('*')):
        if path.is_dir():
            continue
        if path.suffix not in ('.json', '.log'):
            raise RuntimeError('unselected first-attempt evidence file: ' + str(path))
        members['records/native-reintegrated/' + path.relative_to(PRIOR_OUT).as_posix()] = stable_read(path)
    if (recorded_environment is None
            or recorded_environment['CARGO_TARGET_DIR'] != str(TASK / 'target-fixed')
            or recorded_environment['CARGO_BUILD_JOBS'] != '2'
            or recorded_environment['RUST_TEST_THREADS'] != '1'
            or any(recorded_environment[k] is not None for k in
                   ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'])):
        raise RuntimeError('recorded public native environment differs from the selected configuration')
    for name, expected in [('native-reintegration-validation-r2.py', RUNNER_SHA256),
                           ('native-reintegration-validation-v1.py', 'ec06cb4f7bc32e9618d57edef35452c44a3345595534b1a935fcac46c96ec01a'),
                           ('native-validation-v1.py', HELPER_SHA256)]:
        data = stable_read(TASK / name)
        if sha(data) != expected:
            raise RuntimeError('selected runner/helper changed')
        members['runner/' + name] = data
    members['runner/seal-reintegrated-native.py'] = stable_read(__file__)
    members['environment/configured-environment.json'] = environment_bytes
    members['environment/public-provider-observation.json'] = encoded(observation)
    members['environment/recorded-command-environment.json'] = encoded(recorded_environment)
    bundle = TASK / 'pq-reintegration-m15.bundle'
    if file_sha(bundle) != complete['bundle_sha256']:
        raise RuntimeError('integrated bundle changed before sealing')
    members['source/frozen-bundle-identity.json'] = encoded({
        'path': str(bundle), 'bytes': bundle.stat().st_size, 'sha256': file_sha(bundle),
        'tested_source': HEAD, 'tested_tree': TREE})
    members['runtime/native-controller-receipts.json'] = encoded(runtime)
    manifest = {'schema': 'trnm-reintegrated-native-evidence-manifest-v1',
                'tested_source': HEAD, 'tested_tree': TREE, 'native_job_id': terminal['job_id'],
                'native_status': terminal['state'], 'native_exit_code': terminal['exit_code'],
                'elf_bodies_included': False, 'private_environment_dump_included': False,
                'prior_attempt': {'job_id': previous_terminal['job_id'], 'state': 'failed',
                                  'exit_code': 1, 'tests_run': 0,
                                  'phase': 'prerequisite-0', 'actual_source': prior_source},
                'retained_prior_elf_count': 11, 'additional_elf_copies_in_attempt2': 0,
                'prior_integrated_archive': {
                    'path': str(TASK / 'records/native-integrated-evidence-9fb011c.tar.gz'),
                    'bytes': 84068,
                    'sha256': '278b6ac2f1266f8c881d8cf114e1effa52bde7a6a530e4a72e718d480e273ff5'},
                'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data)}
                            for name, data in sorted(members.items())]}
    manifest_data = encoded(manifest)
    manifest_path = TASK / 'records' / (STEM + '.manifest.json')
    archive_path = TASK / 'records' / (STEM + '.tar.gz')
    seal_path = TASK / 'records' / (STEM + '.seal.json')
    if any(path.exists() for path in (manifest_path, archive_path, seal_path)):
        raise RuntimeError('sealed evidence path already exists; no overwrite or automatic retry')
    publish(manifest_path, manifest_data)
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for name, data in sorted({**members, 'MANIFEST.json': manifest_data}.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o444
                    info.mtime = 0
                    archive.addfile(info, io.BytesIO(data))
        raw.flush()
        os.fsync(raw.fileno())
    os.chmod(archive_path, 0o444)
    with archive_path.open('rb') as stream:
        os.fsync(stream.fileno())
    seal = {'schema': 'trnm-reintegrated-native-evidence-seal-v1', 'tested_source': HEAD,
            'tested_tree': TREE, 'native_job_id': terminal['job_id'],
            'archive': str(archive_path), 'archive_bytes': archive_path.stat().st_size,
            'archive_sha256': file_sha(archive_path), 'manifest': str(manifest_path),
            'manifest_bytes': len(manifest_data), 'manifest_sha256': sha(manifest_data),
            'manifest_members': len(members), 'tar_members': len(members) + 1,
            'read_only_mode': '0444', 'automatic_retry': False}
    publish(seal_path, encoded(seal))
    fd = os.open(TASK / 'records', os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    print(json.dumps(seal, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
