text = (Path(os.environ['OUT'])/name).read_text()
runs = re.findall(r'^Ran ([0-9]+) tests? in .+$', text, re.M)
terminal = re.search(r'(?:\A|\n)Ran ([1-9][0-9]*) tests? in [0-9]+(?:\.[0-9]+)?s\n\nOK\s*\Z', text)
if len(runs) != 1 or terminal is None or terminal.group(1) != runs[0]:
    raise SystemExit('missing, empty, skipped or unsuccessful suite: ' + name)
