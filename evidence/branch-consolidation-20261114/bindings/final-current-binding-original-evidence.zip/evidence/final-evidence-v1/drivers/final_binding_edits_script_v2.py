import pathlib,subprocess,json,hashlib,copy,ast,os,sys
wt=pathlib.Path('/private/tmp/chain-final-current-bindings-20261114');rev='5c04c60e463462d9df8884786e0d5bb32af08a64'
ev=pathlib.Path('/private/tmp/chain-final-current-bindings-evidence-20261114/edits-v2');ev.mkdir(exist_ok=False)
(ev/'prior-generator-refusal.json').write_text(json.dumps(json.loads(sys.argv[1]),indent=2)+'\n')
env=dict(os.environ,PATH='/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',TMPDIR='/private/tmp/chain-final-current-bindings-evidence-20261114/final-checkpoint-v1/canonical-tmp',PYTHONDONTWRITEBYTECODE='1',GIT_NO_LAZY_FETCH='1')
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-c','core.commitGraph=false','-C',str(wt),*args],env=env)
assert git('rev-parse','HEAD').decode().strip()==rev and not git('status','--porcelain=v1').strip()
r=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=wt,env=env,capture_output=True)
(ev/'preflight.stdout').write_bytes(r.stdout);(ev/'preflight.stderr').write_bytes(r.stderr);assert r.returncode==0
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(j):return json.dumps(j,sort_keys=True,separators=(',',':')).encode()
before={};edits={}
def text(p):
 if p not in before:
  b=(wt/p).read_bytes();assert b==git('show',rev+':'+p),p;before[p]=b
 return edits.get(p,before[p].decode())
def put(p,s):text(p);edits[p]=s
def load(p):return json.loads(text(p))
def putj(p,j):put(p,json.dumps(j,indent=2,ensure_ascii=False)+'\n')
def replace(p,old,new,count=1):
 s=text(p);assert s.count(old)==count,(p,'replace count',old[:100],s.count(old),count);put(p,s.replace(old,new))
def assign(p,name,value):
 s=text(p);nodes=[n for n in ast.parse(s).body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id==name];assert len(nodes)==1,(p,name)
 n=nodes[0];ls=s.splitlines(keepends=True);put(p,''.join(ls[:n.lineno-1])+name+' = '+value+'\n'+''.join(ls[n.end_lineno:]))
def current_pin(p):
 b=git('show',rev+':'+p);return {'path':p,'bytes':len(b),'sha256':sha(b)}
def appendix(p,body):
 s=text(p);heading='\n## Consolidated current source review, 2026-11-14\n';assert heading not in s;put(p,s.rstrip()+'\n'+heading+'\n'+body.strip()+'\n')
delta=json.loads(pathlib.Path('/private/tmp/chain-final-current-bindings-evidence-20261114/source-delta-dba-v1/source-delta.json').read_text())
checkpoint=json.loads(pathlib.Path('/private/tmp/chain-final-current-bindings-evidence-20261114/final-checkpoint-v1/checkpoint.json').read_text())
assert checkpoint['fixed_source']==rev and len(checkpoint['inputs_unchanged_from_dba'])==232
assert 'scripts/ci/test_ci_contract.py' not in {row['path'] for row in checkpoint['inputs_unchanged_from_dba']}
a_path='config/pon/pq-authority-effects-v1.json';a=load(a_path);a0=copy.deepcopy(a)
assert a['source_revision']=='332d7f723d71707d88a2cffa52b3754579a46926' and len(a['source_files_sha256'])==44
a['source_revision']=rev;a['source_files_sha256']={p:current_pin(p)['sha256'] for p in a['source_files_sha256']}
a_changed=[p for p in a['source_files_sha256'] if a['source_files_sha256'][p]!=a0['source_files_sha256'][p]];assert len(a_changed)==7
a_digest=sha(canonical({'source_revision':rev,'files':a['source_files_sha256']}));putj(a_path,a)
ar='scripts/ci/pq_authority_effect_register.py';assign(ar,'SOURCE_REVISION',repr(rev));assign(ar,'REVIEWED_SOURCE_LOCK_SHA256',repr(a_digest))
at='scripts/ci/test_pq_authority_effect_register.py';replace(at,repr(a0['source_revision']),repr(rev))
replace(at,"for field, value in (('source_revision', '0' * 40),","for field, value in (('source_revision', '0' * 40),\n                             ('source_revision', '"+a0['source_revision']+"'),")
replace(at,"        self.assertEqual(result['curated_routes_checked'], 7)","        self.assertEqual(result['curated_routes_checked'], 7)\n        self.assertEqual(len(result['source_files_sha256']), 44)\n        self.assertEqual(result['reviewed_source_lock_sha256'],\n                         '"+a_digest+"')")
appendix('docs/security/PQ_AUTHORITY_EFFECT_REGISTER_V1.md',f"""
Current source checkpoint {rev} keeps the same seven curated routes and 44
selected paths. Seven selected files changed from the preceding 332d7f72
review: Cell fetch ordering and controlled cache restoration, the per-call PQ
account configuration and its controls, Node advisory/store integration, and
the explicit THP2 fresh-time comparator plus its controls. Each full path and
Git identity was compared before this new lock was formed.

Canonical source-lock SHA-256: {a_digest}. The strict reader and independent
test literals select this checkpoint explicitly. Prior revision and hash
refusals, exact route fields, bounded regular-file reads and all false
qualification flags remain. These 44 paths are a curated inventory; source
consistency supplies no complete call graph, runtime reachability or whole-chain
security result. Earlier dated review records retain their original identities.
""")
l_path='config/pon/w1-lifetime-current-source-v2.json';l=load(l_path);l0=copy.deepcopy(l)
assert len(l['sources'])==20 and l['source_base_commit']==a0['source_revision']
l['source_base_commit']=rev;l_changed=[]
for row in l['sources']:
 pin=current_pin(row['path'])
 if (row['bytes'],row['current_sha256'])!=(pin['bytes'],pin['sha256']):l_changed.append(row['path'])
 row['bytes']=pin['bytes'];row['current_sha256']=pin['sha256']
assert len(l_changed)==4
changed=[row['path'] for row in l['sources'] if row['historical_sha256']!=row['current_sha256']]
assert len(changed)==8;l['changed_paths']=changed;putj(l_path,l);l_sha=sha(edits[l_path].encode())
lr='scripts/w1_lifetime_current_observation.py';assign(lr,'CURRENT',repr(rev));assign(lr,'CONTRACT_SHA256',repr(l_sha));assign(lr,'CHANGED','(\n'+''.join('    '+repr(p)+',\n' for p in changed)+')')
lt='scripts/ci/test_w1_lifetime_current_observation.py';replace(lt,'exact six reviewed deltas','exact eight reviewed deltas')
old_changed="        self.assertEqual(changed, [\n"+''.join('            '+repr(p)+',\n' for p in l0['changed_paths'])+"        ])"
new_changed="        self.assertEqual(changed, [\n"+''.join('            '+repr(p)+',\n' for p in changed)+"        ])"
replace(lt,old_changed,new_changed);replace(lt,repr(l0['sources'][7]['current_sha256']),repr(l['sources'][7]['current_sha256']));replace(lt,repr(a0['source_revision']),repr(rev))
appendix('docs/security/W1_LIFETIME_CURRENT_SOURCE_OBSERVATION_V2.md',f"""
Current checkpoint {rev} retains the exact ordered 20-path roster and all
20 historical SHA-256 values from 7150d96a. Four current rows changed from
332d7f72: the crypto Cargo manifest, pon_work.rs, pq_accounts_v2.rs and Node
store.rs. The historical-versus-current difference list now has eight paths,
including the two newly different pon_work.rs and pq_accounts_v2.rs.

Current contract SHA-256: {l_sha}. The current reader still calls the original
byte-pinned survey function in a private copied context. The 7150 fixture,
the separate 1f2b0187 ledger and the 0f9b3054 PQ128 source lock retain their
bytes and identities. All source limits, arithmetic rules, missing/symlink
refusals and unknown qualification outputs remain. Current observation does
not reproduce a historical execution or establish a lifetime failure bound.
""")
r_path='config/pon/pq-root-dependency-register-v3.json';root=load(r_path);r0=copy.deepcopy(root)
assert root['review_base_revision']==delta['root']['old_source']
root['review_base_revision']=rev;root['source_files_sha256']={row['path']:row['sha256'] for row in delta['root']['all_inputs']};assert len(root['source_files_sha256'])==46
r_digest=sha(canonical({'review_base_revision':rev,'source_files_sha256':root['source_files_sha256']}));putj(r_path,root)
rr='scripts/ci/pq_root_dependency_register.py';assign(rr,'REVIEW_BASE',repr(rev));assign(rr,'REVIEWED_SOURCE_SNAPSHOT_SHA256',repr(r_digest))
rt='scripts/ci/test_pq_root_dependency_register.py';cost='trillionnium/crates/trnm-crypto-primitives/examples/pq_root_v3_cost_observation.rs'
replace(rt,'NATIVE_OWNER = "trillionnium/crates/trnm-pon-node/src/root_recovery_v3.rs"','NATIVE_OWNER = "trillionnium/crates/trnm-pon-node/src/root_recovery_v3.rs"\nCOST_EXAMPLE = "'+cost+'"')
prevnode=next(n for n in ast.parse(text(rt)).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PREVIOUS_SOURCE_PINS' for t in n.targets));prevpins=ast.literal_eval(prevnode.value)
prevbase='225ab38e1e5f7e0852a28372bd8dd769eec1084b';allprev=dict(r0['source_files_sha256']);allprev.update(prevpins)
assert all(allprev[p]==v for p,v in prevpins.items());assert sha(canonical({'review_base_revision':prevbase,'source_files_sha256':allprev}))=='844d27717babb9b3a286cd28915a06b0cd1152ffcf151ffdf6c30a01708bd9fe'
for p in ('trillionnium/crates/trnm-crypto-primitives/src/pq_root_v3.rs','trillionnium/crates/trnm-crypto-primitives/src/pq_root_v3/tests.rs','trillionnium/crates/trnm-crypto-primitives/tests/pq_root_v3_native.rs'):prevpins[p]=allprev[p]
assign(rt,'PREVIOUS_SOURCE_PINS','{\n'+''.join('    '+json.dumps(p)+':\n        '+json.dumps(v)+',\n' for p,v in prevpins.items())+'}')
replace(rt,'        previous["source_files_sha256"].update(PREVIOUS_SOURCE_PINS)','        # The separately added cost example was absent from the original review.\n        previous["source_files_sha256"].pop(COST_EXAMPLE)\n        previous["source_files_sha256"].update(PREVIOUS_SOURCE_PINS)')
replace(rt,'        self.assertIn(NATIVE_CRYPTO, report["source_files_sha256"])','        self.assertIn(NATIVE_CRYPTO, report["source_files_sha256"])\n        self.assertEqual(len(report["source_files_sha256"]), 46)\n        self.assertEqual(report["review_base_revision"], "'+rev+'")\n        self.assertEqual(report["declared_source_snapshot_sha256"],\n                         "'+r_digest+'")')
priorpins={row['new']['path']:r0['source_files_sha256'][row['new']['path']] for row in delta['root']['changed']};assert len(priorpins)==5
block='''
    def test_preceding_forty_five_input_snapshot_keeps_its_original_identity(self):
        previous = deepcopy(self.data)
        previous["review_base_revision"] = "975af9eb4a7f15b405de602552fa05021a176c11"
        previous["source_files_sha256"].pop(COST_EXAMPLE)
        previous["source_files_sha256"].update(PREVIOUS_CURRENT_SOURCE_PINS)
        canonical = json.dumps({
            "review_base_revision": previous["review_base_revision"],
            "source_files_sha256": previous["source_files_sha256"],
        }, sort_keys=True, separators=(",", ":")).encode()
        self.assertEqual(len(previous["source_files_sha256"]), 45)
        self.assertEqual(hashlib.sha256(canonical).hexdigest(),
                         "8cfc6a3d9a0347cb8bd7e6c41f5286523d85bba48b3b392922ad8aae8c8d2435")
        self.data = previous
        self.write()
        self.inspect_refuses("review_base_revision")

    def test_cost_observation_source_is_required_and_cannot_repin_its_own_review(self):
        path = self.root / COST_EXAMPLE
        original = path.read_bytes()
        self.assertEqual(len(original), 21222)
        self.assertEqual(hashlib.sha256(original).hexdigest(),
                         "2af82ca049a155882b8577c32f45d7867ad24adf04dd0d42b8d960d58ecbb1fb")
        path.unlink()
        self.inspect_refuses("missing source")
        path.write_bytes(original + b"\\n")
        self.inspect_refuses("source hash mismatch")
        self.data["source_files_sha256"][COST_EXAMPLE] = hashlib.sha256(path.read_bytes()).hexdigest()
        self.write()
        self.inspect_refuses("frozen reviewed snapshot")
        path.write_bytes(original)
        del self.data["source_files_sha256"][COST_EXAMPLE]
        self.write()
        self.inspect_refuses("source_files_sha256")

'''
replace(rt,'    def test_reverted_lock_dependency_is_refused_even_with_rewritten_manifest_hash(self):',block+'    def test_reverted_lock_dependency_is_refused_even_with_rewritten_manifest_hash(self):')
replace(rt,'\n\ndef manifest():','\n\n# Exact preceding 975af9eb values; preserve its 45-input canonical identity.\nPREVIOUS_CURRENT_SOURCE_PINS = {\n'+''.join('    '+json.dumps(p)+':\n        '+json.dumps(v)+',\n' for p,v in priorpins.items())+'}\n\n\ndef manifest():')
appendix('docs/security/PQ_ROOT_DEPENDENCY_REGISTER_V3.md',f"""
The declared current source snapshot now selects {rev} with 46 explicit
paths. Five prior inputs changed: the crypto Cargo manifest, immutable roster
implementation, its unit/native controls, and Node module exports. The explicit
pq_root_v3_cost_observation.rs example is the additional path already selected
by the reader's source roster. Canonical snapshot SHA-256: {r_digest}.

The roster cache retains only successful expansion of an immutable ML-DSA key.
Each current message/signature still verifies after the original reservation
and deadline checks. Both families, quorum sizes, caller trust, refusal caps,
no-refund accounting and lifetime unknowns remain. The example retains bounded
ABBA observations and false activation flags; source inclusion supplies no new
performance result. The six role contracts, unwired effect-entry boundary and
V5/V6 external ownership requirements are unchanged.

Tests reconstruct the earlier 45-input 975af9eb snapshot and the original
225ab38e declared snapshot with their original canonical digests, and reject both as
current input. Earlier review records and all historical manifests remain.
""")
q_path='config/pon/w1-qrom-implementation-current-v2.json';q=load(q_path);q0=copy.deepcopy(q);assert q['source_base_commit']==delta['qrom']['old_source']
q['source_base_commit']=rev;q['project_files']=[current_pin(row['path']) for row in q['project_files']]
q['local_path_closure']['files']=[{k:row[k] for k in ('path','bytes','sha256')} for row in delta['qrom']['all_inputs']];assert len(q['local_path_closure']['files'])==145
q['reviewed_changes']['all_branch_source_consolidation_20261114']=('Reviewed source '+rev+' changes nine of the prior 140 local-closure records and adds five crypto sources: the explicit root cost example, low_rank_prefix, statement_boundaries, task_product_facts and its tests. The nine changed inputs are the crypto manifest, rank-batch diagnostic, pon_work entry, legal_attempt, rejection_cache and its controls, and the pq_root_v3 implementation plus unit/native controls. The 131 other prior closure inputs, six Cargo-reachable crate roots, eight literal includes, saved proof materials, guest lock/image, historical reader/contract, audit helpers, proof parameters and 15 unresolved obligations retain their identities. The selected 16-path project map changes only pon_work.rs from the preceding current checkpoint; its historical-V1 difference set therefore contains four paths. Native product reuse, cheap-statement checks, cooperative task hashing and explicit structured producers are separately reviewed source capabilities. Immutable root-key expansion preserves each-call quorum verification and the original budget. This mapping adds no native execution, lower cost bound, current-profile approval, full Rust #[path] closure, external implementation proof or security qualification. The SP27 example belongs to trnm-research-protocol and is outside these six crates.')
putj(q_path,q);q_sha=sha(edits[q_path].encode());q_size=len(edits[q_path].encode())
qr='scripts/w1_qrom_current_implementation_audit.py';assign(qr,'SOURCE',repr(rev));assign(qr,'CONTRACT_SHA256',repr(q_sha));qchanged=sorted(delta['qrom']['historical_project_changed']);assign(qr,'CHANGED','frozenset({\n'+''.join('    '+repr(p)+',\n' for p in qchanged)+'})')
qt='scripts/ci/test_w1_qrom_current_implementation_audit.py'
replace(qt,"self.assertEqual(result['source_files_checked'], 140)","self.assertEqual(result['source_files_checked'], 145)");replace(qt,repr(q0['source_base_commit']),repr(rev))
replace(qt,"            'trillionnium/crates/trnm-protocol/src/pon_wire.rs',","            'trillionnium/crates/trnm-crypto-primitives/src/pon_work.rs',\n            'trillionnium/crates/trnm-protocol/src/pon_wire.rs',")
newpins={row['path']:(row['bytes'],row['sha256']) for row in delta['qrom']['added']};assert len(newpins)==5
newpins_literal='{\n'+''.join('    '+repr(p)+':\n        ('+str(v[0])+', '+repr(v[1])+'),\n' for p,v in newpins.items())+'}'
replace(qt,'\n\nclass CurrentImplementationTests(unittest.TestCase):','\n\n# Independently reviewed additions at the consolidated source checkpoint.\nCONSOLIDATED_LOCAL_SOURCE_PINS = '+newpins_literal+'\n\n\nclass CurrentImplementationTests(unittest.TestCase):')
qblock='''
    def test_consolidated_local_sources_have_independent_reviewed_pins(self):
        rows = {row["path"]: row for row in self.contract["local_path_closure"]["files"]}
        for path, expected in CONSOLIDATED_LOCAL_SOURCE_PINS.items():
            with self.subTest(path=path):
                self.assertIn(path, rows)
                self.assertEqual((rows[path]["bytes"], rows[path]["sha256"]), expected)
        self.assertNotIn(
            "trillionnium/crates/trnm-research-protocol/examples/sp27_03_authorization_adapter.rs",
            rows)

    def test_each_consolidated_source_refuses_omission_and_mutation(self):
        for name in CONSOLIDATED_LOCAL_SOURCE_PINS:
            for mode in ("missing", "changed"):
                with self.subTest(path=name, mode=mode):
                    self.copy_inputs()
                    path = self.root / name
                    if mode == "missing":
                        path.unlink()
                    else:
                        path.write_bytes(path.read_bytes() + b"\\n")
                    with self.assertRaises((current.AuditError, OSError)):
                        current.build_report(self.root)

'''
replace(qt,'    def test_cli_report_is_created_once_and_never_replaces_prior_evidence(self):',qblock+'    def test_cli_report_is_created_once_and_never_replaces_prior_evidence(self):')
ponpin=current_pin('trillionnium/crates/trnm-crypto-primitives/src/pon_work.rs')
replace(qt,"        old, _ = self.audit.load_contract(current.ROOT)","        pon_work = next(row for row in self.contract['project_files']\n                        if row['path'] == 'trillionnium/crates/trnm-crypto-primitives/src/pon_work.rs')\n        self.assertEqual((pon_work['bytes'], pon_work['sha256']),\n                         ("+str(ponpin['bytes'])+", '"+ponpin['sha256']+"'))\n        old, _ = self.audit.load_contract(current.ROOT)")
appendix('docs/security/W1_QROM_CURRENT_SOURCE_MAPPING_V2.md',f"""
Current mapping checkpoint {rev} enumerates 145 inputs across the same six
Cargo-reachable crates. Nine prior inputs changed and five Rust files were
added. The new paths are the explicit root cost example, low_rank_prefix.rs,
the test-only statement_boundaries.rs, task_product_facts.rs and its tests.
All 131 other prior closure inputs and the eight literal includes keep their
bytes. The SP27 example is in trnm-research-protocol, outside this closure.

Only pon_work.rs changes among the 16 selected project paths compared with
the preceding current mapping. The historical-V1 difference set contains four
paths. Saved proof assets, guest lock/image, historical reader and contract,
helpers, proof parameters and all 15 unresolved obligations remain unchanged.
The original historical refusal still names the V2 verifier src/main.rs
byte bound. Current contract: {q_size} bytes, SHA-256 {q_sha}.

The real Cargo edges and complete Rust directory inventory within these roots
were enumerated from fixed Git bytes. External Rust #[path] imports and
third-party implementations remain outside this selected inventory. Independent
controls require every new source and reject missing or changed bytes. Source
mapping performs no native verification and grants no current proof-use approval
or security qualification.
""")
p_path='config/pon/pq-proof-profile-binding-v1.json';p=load(p_path);u_path='config/pon/w1-upstream-security-v1.json';u=load(u_path)
newmapping={'path':q_path,'bytes':q_size,'sha256':q_sha};p['mapping_contract']=copy.deepcopy(newmapping);u['mapping_contract']=copy.deepcopy(newmapping)
assert u['approved_current_profile_ids']==[] and u['observed_on']=='2026-11-11';putj(p_path,p);putj(u_path,u)
descriptor={'profile_id':p['selected_profile_id'],'mapping_contract_sha256':q_sha,'identity':p['expected_identity'],'source_inputs':{row['path']:row['sha256'] for row in q['project_files']+q['saved_v2_files']},'upstream_snapshot_sha256':q['upstream_snapshot']['sha256']};profile_digest=sha(canonical(descriptor))
pt='scripts/ci/test_pq_proof_profile_binding.py';replace(pt,'d9e6aa1e independent lock review','5c04c60e consolidated source review');replace(pt,"'bytes': 47790","'bytes': "+str(q_size));replace(pt,repr(sha(before[q_path])),repr(q_sha))
old_descriptor='9e5766a7eb14cb972531e12aa0be6d21a1e545400d89add72656b63c0f6407ad';replace(pt,repr(old_descriptor),repr(profile_digest));replace(pt,"        for digest in ('0' * 64,","        for digest in ('0' * 64,\n                       '"+old_descriptor+"',")
wf='.github/workflows/chain-hepta-closure-candidate.yml';replace(wf,old_descriptor,profile_digest)
route_path='config/pon/w1-stark-route-registry-v1.json';route=load(route_path);route0=copy.deepcopy(route)
for row in route['source_inputs']:
 if row['path']==q_path:row.update(bytes=q_size,sha256=q_sha)
 else:assert row==current_pin(row['path']),(row,current_pin(row['path']))
putj(route_path,route);route_digest=sha(canonical(route['source_inputs']));route_reader='scripts/w1_stark_route_audit.py'
replace(route_reader,'Current QROM mapping and its V2 lock reviewed at d9e6aa1e (140 local inputs).','Current QROM mapping reviewed at 5c04c60e (145 local inputs); V2 lock retained.');assign(route_reader,'FROZEN_SOURCE_SET_SHA256',json.dumps(route_digest))
appendix('docs/security/PQ_PROOF_PROFILE_BINDING_V1.md',f"""
The explicit current mapping now binds source {rev} and its 145-input local
inventory. Its descriptor SHA-256 is {profile_digest}. The mapping,
profile descriptor, upstream-policy mapping pin and route-source pin are
updated together; the candidate workflow and independent controls require the
same descriptor. The preceding 9e5766a7 descriptor remains a rejected current
identity.

The selected SDK, guest image, control root, verifier parameters, fixed proof
assets and all 15 open obligations retain their original identities. The
upstream policy remains the dated 2026-11-11 observation, with an empty current
approval list. No new upstream advisory check or reinstatement is claimed.
The diagnostic status remains PROFILE_BOUND_UPSTREAM_REVOKED_HOLD and
--require-current continues to refuse.
""")
plan='docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md';s=text(plan)
put(plan,s.rstrip()+f"""

### Final consolidated current source bindings — 2026-11-14

Reviewed source {rev} separately rebinds the existing authority44,
current-lifetime20, six-crate QROM145 and root-dependency46 inventories.
The selected source union contains 232 distinct paths; each fixed Git blob
and physical source byte matched the preceding reviewed dba81d56 inputs.
Current reader constants, paired profile/upstream/route descriptors, independent
test expectations and corpus pins move together. Historical 7150/1f2b/0f9
namespaces, original proofs and guest identity, all limits, prior refusal
records and false/null qualification fields remain. No Rust source is changed.

T03's original Linux 59-control run also has a separate post-merge readback:
all 67 actually observed absolute project inputs match this checkpoint, with
60 modules loaded before and 61 afterward. This selected-input comparison
does not claim a complete checkout or resolve the 7,331 relative open events.
""")
function_proofs=[]
for pth in [ar,lr,rr,qr,route_reader]:
 def fs(src):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(src).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
 oldf,newf=fs(before[pth].decode()),fs(edits[pth]);assert oldf==newf,pth;function_proofs.append({'path':pth,'definitions_unchanged':len(oldf)})
assert {k:a[k] for k in a if k not in ('source_revision','source_files_sha256')}=={k:a0[k] for k in a0 if k not in ('source_revision','source_files_sha256')}
assert [r['historical_sha256'] for r in l['sources']]==[r['historical_sha256'] for r in l0['sources']]
assert {k:root[k] for k in root if k not in ('review_base_revision','source_files_sha256')}=={k:r0[k] for k in r0 if k not in ('review_base_revision','source_files_sha256')}
assert {k:q[k] for k in q if k not in ('source_base_commit','project_files','local_path_closure','reviewed_changes')}=={k:q0[k] for k in q0 if k not in ('source_base_commit','project_files','local_path_closure','reviewed_changes')}
assert {k:route[k] for k in route if k!='source_inputs'}=={k:route0[k] for k in route0 if k!='source_inputs'}
for pth,s in edits.items():
 assert not pth.endswith('.rs') and not pth.endswith('Cargo.toml') and not pth.endswith('Cargo.lock'),pth
 if pth.endswith('.py'):ast.parse(s)
 if pth.endswith('.json'):json.loads(s)
cp='config/pon/pq-cross-branch-corpus-v1.json';c=load(cp);c0=copy.deepcopy(c)
for pth,s in list(edits.items()):
 if pth in c['pinned_blobs']:
  raw=s.encode();c['pinned_blobs'][pth]=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
putj(cp,c);assert set(c['pinned_blobs'])==set(c0['pinned_blobs']) and c['required_paths']==c0['required_paths']
review={'fixed_source':rev,'authority_changed':a_changed,'lifetime_current_changed':l_changed,'lifetime_historical_changed':changed,'authority_lock_sha256':a_digest,'lifetime_contract_sha256':l_sha,'root_snapshot_sha256':r_digest,'qrom_contract':newmapping,'profile_descriptor_sha256':profile_digest,'route_source_set_sha256':route_digest,'root_previous_225ab_declared_snapshot_reconstructed_without_full_git_provenance_claim':True,'production_reader_functions_unchanged':function_proofs,'rust_sources_changed':False,'qualification_changed':False,'files':[]}
for pth,s in edits.items():
 raw=s.encode();(ev/(pth.replace('/','--')+'.before')).write_bytes(before[pth]);(wt/pth).write_bytes(raw)
 review['files'].append({'path':pth,'old_bytes':len(before[pth]),'old_sha256':sha(before[pth]),'new_bytes':len(raw),'new_sha256':sha(raw)})
(ev/'review.json').write_text(json.dumps(review,indent=2)+'\n');patch=git('diff','--binary','--full-index');(ev/'working.patch').write_bytes(patch)
print(json.dumps({'changed_paths':len(edits),'review':str(ev/'review.json'),'patch':str(ev/'working.patch'),'patch_bytes':len(patch),'patch_sha256':sha(patch),'authority_sha':a_digest,'lifetime_sha':l_sha,'root_sha':r_digest,'qrom_mapping':newmapping,'profile_digest':profile_digest,'route_digest':route_digest,'production_reader_function_AST_preserved':True,'rust_source_changes':False},indent=2),flush=True)
