#!/usr/bin/env python3
import subprocess,pathlib,json,os,hashlib,time,sys
root=pathlib.Path("/home/qq/chain-source-settlement-20261112-eb070ca2")
out=pathlib.Path("/home/qq/chain-source-incentive-receipts-eb070ca2")
out.mkdir(exist_ok=True)
summary={"schema":"source-incentive-validation-run-v1","phase":"preparing","checks":[],"production_activation":False,"economic_security_qualified":False}
summary_path=out/"source-validation-summary.json"
def save():
 summary_path.write_text(json.dumps(summary,sort_keys=True,indent=2)+"\n")
def run(cmd,**kw):
 return subprocess.run(cmd,cwd=root,text=True,capture_output=True,**kw)
env=os.environ.copy()
tool="/home/qq/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin"
env.update(PATH=tool+":"+env.get("PATH",""),RUSTC=tool+"/rustc",CARGO_BUILD_JOBS="4",CARGO_INCREMENTAL="0",CARGO_TARGET_DIR="/home/qq/chain-source-incentive-target-eb070ca2",RUST_TEST_THREADS="1")
for key in ("RUSTC_WRAPPER","RUSTC_WORKSPACE_WRAPPER","RUSTFLAGS","CARGO_ENCODED_RUSTFLAGS"):
 env.pop(key,None)
def checked(cmd,**kw):
 r=run(cmd,**kw)
 if r.returncode: raise RuntimeError(json.dumps({"argv":cmd,"exit_code":r.returncode,"stdout":r.stdout[-8000:],"stderr":r.stderr[-8000:]}))
 return r.stdout
try:
 summary["preflight"]=json.loads(checked(["bash","scripts/project-preflight.sh"]).strip())
 baseline="4a59131acdf9b8c3210c9b6cd728aeb6c48291fc"
 if checked(["git","rev-parse","HEAD"]).strip()!=baseline:
  raise RuntimeError("unexpected pre-freeze HEAD")
 test=root/"trillionnium/crates/trnm-pon-node/tests/model_composition_v6.rs"
 data=test.read_text()
 old="assert!(pon_executor::canonical(value).unwrap().len() <= 4096);"
 new="assert!(serde_json::to_vec(value).unwrap().len() <= 4096);"
 if data.count(old)!=1: raise RuntimeError("native test private encoder fix does not match once")
 test.write_text(data.replace(old,new))
 checked(["cargo","fmt","--manifest-path","trillionnium/Cargo.toml","--all"],env=env)
 changed=[
 "trillionnium/crates/trnm-mvcc-fee/src/lib.rs",
 "trillionnium/crates/trnm-mvcc-fee/src/pon_executor.rs",
 "trillionnium/crates/trnm-mvcc-fee/src/model_evidence_v3.rs",
 "trillionnium/crates/trnm-mvcc-fee/src/model_composition_v6.rs",
 "trillionnium/crates/trnm-pon-node/src/error.rs",
 "trillionnium/crates/trnm-pon-node/tests/model_composition_v6.rs",
 "trillionnium/crates/trnm-task-kernel/src/tests.rs",
 "config/pon/model-composition-v6.json",
 "config/pon/public-evaluation-source-composition-v6.json",
 "scripts/experiments/source_incentive_reference_v6.py",
 "docs/development/SOURCE_INCENTIVE_RESEARCH_CONTRACT_20261112.md",
 "docs/development/INCENTIVE_LIABILITY_BOUNDARIES_20261112.md",
 "docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md"]
 corpus=root/"config/pon/pq-cross-branch-corpus-v1.json"
 manifest=json.loads(corpus.read_text())
 rebound=[]
 for p in changed:
  if p in manifest["pinned_blobs"]:
   actual=checked(["git","hash-object",p]).strip()
   rebound.append({"path":p,"old":manifest["pinned_blobs"][p],"new":actual})
   manifest["pinned_blobs"][p]=actual
 required_add=[
 "trillionnium/crates/trnm-mvcc-fee/src/model_composition_v6.rs",
 "trillionnium/crates/trnm-mvcc-fee/src/model_evidence_v3.rs",
 "trillionnium/crates/trnm-mvcc-fee/src/integer_factor_candidate_v2.rs",
 "trillionnium/crates/trnm-pon-node/tests/model_composition_v6.rs",
 "config/pon/model-composition-v6.json",
 "config/pon/public-evaluation-source-composition-v6.json",
 "config/pon/model-evidence-v3.json",
 "config/pon/integer-factor-candidate-v2.json"]
 for p in required_add:
  if not (root/p).is_file(): raise RuntimeError("source closure input absent: "+p)
  manifest["pinned_blobs"][p]=checked(["git","hash-object",p]).strip()
  if p not in manifest["required_paths"]:manifest["required_paths"].append(p)
 corpus.write_text(json.dumps(manifest,sort_keys=True,indent=2)+"\n")
 changed.append("config/pon/pq-cross-branch-corpus-v1.json")
 actual=set(checked(["git","diff","--name-only"]).splitlines())|set(checked(["git","ls-files","--others","--exclude-standard"]).splitlines())
 if actual-set(changed): raise RuntimeError("unexpected changes: "+repr(sorted(actual-set(changed))))
 if set(changed)-actual: raise RuntimeError("missing intended changes: "+repr(sorted(set(changed)-actual)))
 checked(["git","diff","--check"])
 checked(["git","add","--",*changed])
 summary["diff_stat"]=checked(["git","diff","--cached","--stat"])
 summary["rebound_existing_pins"]=rebound
 summary["added_source_closure"]=required_add
 checked(["git","-c","user.name=OpenAI Codex","-c","user.email=codex@openai.com","commit","-s","-m","fix(pon): settle canonical source updates before attribution"])
 head=checked(["git","rev-parse","HEAD"]).strip()
 tree=checked(["git","rev-parse","HEAD^{tree}"]).strip()
 if checked(["git","status","--porcelain"]).strip():raise RuntimeError("source is not clean after freeze")
 summary.update(phase="executing-frozen-source",tested_commit=head,tested_tree=tree)
 save()
 print(json.dumps({"phase":summary["phase"],"tested_commit":head,"tested_tree":tree}),flush=True)
 recorder=["python3","scripts/ci/record_pq_native_command.py","--kind","head","--candidate",head,"--tested",head,"--output",str(out/"frozen-source-1")]
 def recorded(label,cmd,elf_pin=None):
  args=recorder+["--label",label]
  if elf_pin:args+=["--native-executable-sha256",elf_pin]
  args+=["--",*cmd]
  start=time.monotonic()
  r=run(args,env=env)
  row={"label":label,"runner_exit_code":r.returncode,"elapsed_seconds":round(time.monotonic()-start,3),"stdout":r.stdout[-2500:],"stderr":r.stderr[-2500:]}
  receipt=out/"frozen-source-1"/(label+".json")
  if receipt.exists():
   d=json.loads(receipt.read_text());row.update(status=d.get("status"),command_exit_code=d.get("exit_code"),log_file=str(out/"frozen-source-1"/(label+".log")),log_sha256=d.get("log_sha256"))
  summary["checks"].append(row);save();print(json.dumps(row),flush=True)
  return r.returncode
 cargo=["cargo"]
 common=["--locked","--offline","--manifest-path","trillionnium/Cargo.toml"]
 recorded("source-identity",["python3","scripts/ci/verify_ci_source.py","--kind","head","--expected-head",head])
 recorded("fmt",cargo+["fmt","--manifest-path","trillionnium/Cargo.toml","--all","--","--check"])
 recorded("metadata",cargo+["metadata",*common,"--format-version","1"])
 recorded("metadata-all-features",cargo+["metadata",*common,"--all-features","--format-version","1"])
 build_rc=recorded("build-native-v6",cargo+["test",*common,"-p","trnm-pon-node","--test","model_composition_v6","--no-run","--message-format=json"])
 if build_rc==0:
  binaries=[]
  for line in (out/"frozen-source-1/build-native-v6.log").read_text().splitlines():
   try:item=json.loads(line)
   except ValueError:continue
   if item.get("reason")=="compiler-artifact" and item.get("target",{}).get("name")=="model_composition_v6" and item.get("executable"):
    binaries.append(item["executable"])
  if len(binaries)!=1:raise RuntimeError("ambiguous native V6 executable")
  binary=pathlib.Path(binaries[0])
  binary_hash=hashlib.sha256(binary.read_bytes()).hexdigest()
  summary["native_binary"]={"path":str(binary),"sha256":binary_hash};save()
  recorded("native-v6", [str(binary),"--nocapture","--test-threads=1"],binary_hash)
 recorded("mvcc-fee-retained",cargo+["test",*common,"-p","trnm-mvcc-fee","--lib","--","--nocapture","--test-threads=1"])
 recorded("native-v4-retained",cargo+["test",*common,"-p","trnm-pon-node","--test","model_composition_v4","--","--nocapture","--test-threads=1"])
 recorded("task-kernel-retained",cargo+["test",*common,"-p","trnm-task-kernel","--lib","--","--nocapture","--test-threads=1"])
 recorded("native-source-errors",cargo+["test",*common,"-p","trnm-pon-node","--lib","source_composition_errors_keep_exact_identity_without_owner_stop","--","--nocapture","--test-threads=1"])
 recorded("strict-clippy",cargo+["clippy",*common,"--workspace","--all-targets","--all-features","--","-D","warnings"])
 recorded("repository-links",["python3","scripts/ci/check_repository.py"])
 recorded("source-corpus",["python3","scripts/ci/check_pq_research_integration.py"])
 recorded("source-integrity-negatives",["python3","scripts/ci/test_ci_source_integrity.py"])
 recorded("independent-math-self-tests",["python3","scripts/experiments/source_incentive_reference_v6.py","--self-test"])
 summary["phase"]="completed"
 summary["all_commands_succeeded"]=all(r["runner_exit_code"]==0 for r in summary["checks"])
 summary["post_status"]=checked(["git","status","--porcelain"])
 save()
 print(json.dumps({"phase":"completed","all_commands_succeeded":summary["all_commands_succeeded"],"checks":len(summary["checks"]),"tested_commit":head}),flush=True)
 sys.exit(0 if summary["all_commands_succeeded"] else 1)
except Exception as error:
 summary.update(phase="blocked",error=str(error))
 save();print(json.dumps({"phase":"blocked","error":str(error)}),flush=True);raise
