"""Offline, create-only directory source for one exact locked metadata query.

Shared archive/source contents are read only. Hard links intentionally increase
source inode link counts; no linked file is written or chmodded. This script
does not create registry index records or run a build.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import resource
import stat
import subprocess
import tarfile
import time
import tomllib

BASE = Path('/workspace/scratch/10a9f8f2cba0')
REPO = BASE / 'chain-fairness'
OUT = BASE / 'fresh-work-observations/fuzz-metadata-repair'
CARGO = BASE / 'fresh-fuzz-metadata-cargo'
PRIOR = REPO / 'evidence/pon-legal-work-fairness-20261107/validation/fuzz-cache-followup/repair-provenance.json'
ENVIRONMENT = Path('/workspace/scratch/62902f6722b7/env-next.sh')
TOOLCHAIN = Path('/workspace/scratch/62902f6722b7/native-next/rust-1.95.0/bin')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def file_digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(name, value):
    raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
    with (OUT / name).open('xb') as stream:
        stream.write(raw)
    return digest(raw)


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=REPO, text=True).strip()


def snapshot():
    paths = git('ls-files', '*Cargo.toml', '*Cargo.lock', 'rust-toolchain*', '.cargo/config*').splitlines()
    return dict(head=git('rev-parse', 'HEAD'), tracked_status=git('status', '--porcelain', '--untracked-files=no'),
                files={path: file_digest(REPO / path) for path in paths})


def shell_environment(command):
    # All paths and commands are fixed constants from the authorized task.
    return '\n'.join((f'source {ENVIRONMENT}', f'export CARGO_HOME={CARGO}', f'exec {command}'))


def restore():
    started = time.time_ns()
    before = snapshot()
    write_json('source-before.json', before)
    prior_raw = PRIOR.read_bytes()
    previous = json.loads(prior_raw)
    lock_path = REPO / 'tests/fuzz/Cargo.lock'
    lock_raw = lock_path.read_bytes()
    lock_sha = digest(lock_raw)
    assert lock_sha == previous['fuzz_lock_sha256_before'], 'LOCK_DIFFERS_FROM_PRIOR'
    packages = {(p['name'], p['version']): p for p in tomllib.loads(lock_raw.decode())['package']
                if 'source' in p}
    archives = {(a['name'], a['version']): a for a in previous['archives']}
    assert len(archives) == 135 and set(archives) == set(packages), 'LOCK_ARCHIVE_SET'
    for key, package in packages.items():
        entry = archives[key]
        assert package['source'] == 'registry+https://github.com/rust-lang/crates.io-index'
        assert package['checksum'] == entry['expected_lock_checksum'] == entry['archive_sha256']
        path = Path(entry['source_archive'])
        assert stat.S_ISREG(path.lstat().st_mode), 'ARCHIVE_NOT_REGULAR'
        assert file_digest(path) == package['checksum'], 'ARCHIVE_CHECKSUM'
    CARGO.mkdir(exist_ok=False)
    vendor = CARGO / 'vendor'
    vendor.mkdir()
    counters = Counter()
    crate_rows, source_records = [], []
    archive_sources = Counter()
    with (OUT / 'source-files.ndjson').open('x', encoding='utf-8') as log:
        for key in sorted(packages):
            package, old = packages[key], archives[key]
            archive = Path(old['source_archive'])
            crate = f'{key[0]}-{key[1]}'
            cached = archive.parent.parent.parent / 'src' / archive.parent.name / crate
            destination = vendor / crate
            destination.mkdir()
            files, linked, extracted, expanded_bytes = {}, 0, 0, 0
            archive_sources[str(archive.parent.parent.parent.parent)] += 1
            with tarfile.open(archive, 'r:gz') as tar:
                for member in tar:
                    relative = PurePosixPath(member.name)
                    assert not relative.is_absolute() and '..' not in relative.parts
                    assert relative.parts and relative.parts[0] == crate, 'ARCHIVE_ROOT'
                    if member.isdir():
                        continue
                    assert member.isfile(), 'NONREGULAR_ARCHIVE_MEMBER'
                    name = PurePosixPath(*relative.parts[1:]).as_posix()
                    assert name not in ('', '.', '.cargo-checksum.json') and name not in files
                    raw = tar.extractfile(member).read()
                    assert len(raw) == member.size
                    expected = digest(raw)
                    files[name] = expected
                    expanded_bytes += len(raw)
                    shared = cached / name
                    target = destination / name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    prior_stat = None
                    shared_hash = None
                    try:
                        prior_stat = shared.lstat()
                    except FileNotFoundError:
                        pass
                    if prior_stat is not None and stat.S_ISREG(prior_stat.st_mode):
                        shared_hash = file_digest(shared)
                        source_records.append((str(shared), shared_hash, prior_stat.st_mode,
                                               prior_stat.st_size, prior_stat.st_mtime_ns))
                    identical = (shared_hash == expected and prior_stat.st_size == len(raw)) if shared_hash else False
                    if identical:
                        os.link(shared, target, follow_symlinks=False)
                        linked += 1
                        counters['hardlinked_files'] += 1
                        counters['hardlinked_content_bytes'] += len(raw)
                        action = 'hardlink_exact_regular_shared_source'
                    else:
                        with target.open('xb') as stream:
                            stream.write(raw)
                        os.chmod(target, member.mode & 0o777)
                        extracted += 1
                        counters['extracted_files'] += 1
                        counters['extracted_content_bytes'] += len(raw)
                        action = 'extract_missing_or_differing_archive_member'
                    target_stat = target.lstat()
                    assert stat.S_ISREG(target_stat.st_mode) and file_digest(target) == expected
                    if identical:
                        assert (target_stat.st_dev, target_stat.st_ino) == (prior_stat.st_dev, prior_stat.st_ino)
                        assert target_stat.st_nlink >= prior_stat.st_nlink + 1
                        assert target_stat.st_mode == prior_stat.st_mode
                    row = dict(crate=crate, file=name, archive_member_sha256=expected, bytes=len(raw),
                        action=action, source=str(shared), source_sha256_before=shared_hash,
                        source_inode=None if prior_stat is None else prior_stat.st_ino,
                        source_device=None if prior_stat is None else prior_stat.st_dev,
                        source_nlink_before=None if prior_stat is None else prior_stat.st_nlink,
                        destination=str(target), destination_inode=target_stat.st_ino,
                        destination_device=target_stat.st_dev, destination_nlink=target_stat.st_nlink)
                    log.write(json.dumps(row, sort_keys=True) + '\n')
            checksum = json.dumps({'files': files, 'package': package['checksum']}, sort_keys=True,
                                  separators=(',', ':')).encode()
            with (destination / '.cargo-checksum.json').open('xb') as stream:
                stream.write(checksum)
            counters['checksum_manifests'] += 1
            counters['checksum_manifest_bytes'] += len(checksum)
            crate_rows.append(dict(name=key[0], version=key[1], archive=str(archive),
                archive_sha256=package['checksum'], archive_bytes=archive.stat().st_size,
                destination=str(destination), cached_source=str(cached), regular_files=len(files),
                expanded_bytes=expanded_bytes, hardlinked_files=linked, extracted_files=extracted,
                checksum_manifest_sha256=digest(checksum)))
    configuration = ('[net]\noffline = true\n\n[source.crates-io]\n'
                     'replace-with = "verified-locked-fuzz-archives"\n\n'
                     '[source.verified-locked-fuzz-archives]\n'
                     f'directory = "{vendor}"\n')
    with (CARGO / 'config.toml').open('x', encoding='utf-8') as stream:
        stream.write(configuration)
    for tool in ('cargo', 'rustc'):
        arguments = '--version --verbose' if tool == 'rustc' else '--version'
        process = subprocess.run(['bash', '-c', shell_environment(f'{TOOLCHAIN / tool} {arguments}')],
                                 cwd=REPO, text=True, capture_output=True, check=True)
        with (OUT / f'{tool}-version.log').open('x', encoding='utf-8') as stream:
            stream.write(process.stdout + process.stderr)
        assert '1.95.0' in process.stdout, 'WRONG_RUST_TOOLCHAIN'
    command = (f'{TOOLCHAIN / "cargo"} metadata --offline --locked --manifest-path '
               'tests/fuzz/Cargo.toml --all-features --format-version 1')
    run_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    wall = time.monotonic_ns()
    with (OUT / 'metadata.json').open('xb') as stdout, (OUT / 'metadata.stderr.log').open('xb') as stderr:
        process = subprocess.run(['bash', '-c', shell_environment(command)], cwd=REPO,
                                 stdout=stdout, stderr=stderr, timeout=60)
    wall = time.monotonic_ns() - wall
    run_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    after = snapshot()
    write_json('source-after.json', after)
    assert lock_sha == file_digest(lock_path), 'LOCK_CHANGED'
    assert before['files'] == after['files'], 'CARGO_GRAPH_SOURCE_CHANGED'
    checked_shared = 0
    for raw_path, expected, mode, size, mtime in source_records:
        path = Path(raw_path)
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and file_digest(path) == expected, 'SHARED_CONTENT_CHANGED'
        assert (info.st_mode, info.st_size, info.st_mtime_ns) == (mode, size, mtime), 'SHARED_FILE_ATTRIBUTES_CHANGED'
        checked_shared += 1
    for row in crate_rows:
        assert file_digest(Path(row['archive'])) == row['archive_sha256'], 'ARCHIVE_CHANGED'
        manifest = json.loads((Path(row['destination']) / '.cargo-checksum.json').read_text())
        assert manifest['package'] == row['archive_sha256']
        for name, expected in manifest['files'].items():
            assert file_digest(Path(row['destination']) / name) == expected, 'VENDOR_CHANGED'
    graph = json.loads((OUT / 'metadata.json').read_text()) if process.returncode == 0 else None
    report = dict(schema='pon-fresh-fuzz-offline-metadata-repair-v0',
        status='PASS' if process.returncode == 0 else 'METADATA_FAILED',
        started_at_unix_ns=started, completed_at_unix_ns=time.time_ns(),
        prior_provenance=str(PRIOR), prior_provenance_sha256=digest(prior_raw),
        script_sha256=file_digest(Path(__file__)), environment_script=str(ENVIRONMENT),
        environment_script_sha256=file_digest(ENVIRONMENT),
        cargo_binary_sha256=file_digest(TOOLCHAIN / 'cargo'), rustc_binary_sha256=file_digest(TOOLCHAIN / 'rustc'),
        source_head_before=before['head'], source_head_after=after['head'],
        fuzz_lock_sha256_before=lock_sha, fuzz_lock_sha256_after=file_digest(lock_path),
        graph_source_hashes_unchanged=True, isolated_cargo_home=str(CARGO), configuration=configuration,
        configuration_sha256=digest(configuration.encode()), crate_count=len(crate_rows),
        source_archive_counts=dict(archive_sources), archives=crate_rows, file_counts=dict(counters),
        source_file_log_sha256=file_digest(OUT / 'source-files.ndjson'),
        shared_regular_files_rechecked=checked_shared,
        shared_file_contents_modes_and_mtimes_unchanged=True,
        shared_inode_link_counts_increased_by_authorized_hardlinks=True,
        shared_cache_files_written_or_chmodded=False, registry_index_records_synthesized=False,
        network_used=False, cargo_build_run=False, repository_files_written=False,
        metadata_command=command, metadata_exit_code=process.returncode, metadata_wall_ns=wall,
        metadata_child_user_seconds=run_after.ru_utime-run_before.ru_utime,
        metadata_child_system_seconds=run_after.ru_stime-run_before.ru_stime,
        metadata_json_sha256=file_digest(OUT / 'metadata.json'),
        metadata_stderr_sha256=file_digest(OUT / 'metadata.stderr.log'),
        metadata_packages=None if graph is None else len(graph['packages']),
        metadata_workspace_members=None if graph is None else len(graph['workspace_members']),
        metadata_resolve_nodes=None if graph is None else len(graph['resolve']['nodes']))
    write_json('repair-provenance.json', report)
    print(json.dumps({k:report[k] for k in ('status','crate_count','file_counts','metadata_exit_code',
        'metadata_packages','metadata_resolve_nodes','fuzz_lock_sha256_after','isolated_cargo_home')}, sort_keys=True))
    if process.returncode:
        raise SystemExit(process.returncode)


if __name__ == '__main__':
    try:
        restore()
    except BaseException as error:
        write_json('failed-observation.json', dict(type=type(error).__name__, message=str(error),
            cargo_home_created=CARGO.exists(), network_used=False, repository_files_written=False))
        raise
