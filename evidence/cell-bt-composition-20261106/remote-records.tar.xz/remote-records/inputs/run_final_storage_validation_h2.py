#!/usr/bin/env python3
"""Validate the immutable combined candidate using the original Cargo profiles."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys

import run_storage_validation as audit

COMMIT = 'c16c7e0e93cf5eb14f6dac140358441a47d82c7e'
TREE = '4aa564ca3eb297f6afa03976f16eacb6ffd7554a'


def run_test(out, name, package, target, selector, env):
    command = [
        'cargo', 'test', '--manifest-path', 'trillionnium/Cargo.toml',
        '--locked', '--offline', '-p', package, '--all-features', '--lib',
        '--no-run', '--message-format=json', '-j', '2',
    ]
    build = audit.run(out, name + '-build', command, env)
    result = {'build_exit_code': build, 'test_started': False}
    if build:
        return result
    artifacts = []
    for line in (out / (name + '-build.stdout.log')).read_text().splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if (value.get('reason') == 'compiler-artifact'
                and value.get('target', {}).get('name') == target
                and value.get('profile', {}).get('test') is True
                and value.get('executable')):
            artifacts.append(value)
    assert len(artifacts) == 1, (name, len(artifacts))
    binary = Path(artifacts[0]['executable'])
    preserved = out / (name + '-test-binary')
    shutil.copyfile(binary, preserved)
    preserved.chmod(binary.stat().st_mode & 0o777)
    digest = audit.sha256(binary)
    assert audit.sha256(preserved) == digest
    identity = {'built_path': str(binary), 'preserved_path': str(preserved),
                'size': binary.stat().st_size, 'sha256': digest,
                'features': artifacts[0]['features'],
                'profile': artifacts[0]['profile']}
    audit.save_json(out / (name + '-binary.identity.json'), identity)
    test = audit.run(out, name + '-test',
                     [str(binary), selector, '--test-threads=1', '--nocapture'], env)
    stdout = (out / (name + '-test.stdout.log')).read_text()
    stderr = (out / (name + '-test.stderr.log')).read_text()
    print(stdout, end='', flush=True)
    if stderr:
        print(stderr, end='', file=sys.stderr, flush=True)
    match = re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', stdout)
    result.update({'test_started': True, 'test_exit_code': test,
                   'test_summary_present': match is not None,
                   'binary_sha256': digest})
    if match:
        result.update({'passed': int(match[1]), 'failed': int(match[2])})
    return result


def main():
    root, repo = audit.ROOT, audit.REPO
    out = root / 'evidence' / 'green-final-combined'
    out.mkdir(exist_ok=False)
    assert audit.capture(['git', 'rev-parse', 'HEAD']).decode().strip() == COMMIT
    assert audit.capture(['git', 'rev-parse', 'HEAD^{tree}']).decode().strip() == TREE
    assert audit.capture(['git', 'status', '--porcelain']) == b'', 'candidate must be clean'
    assert audit.sha256(repo / audit.PRODUCTION) == audit.PRODUCTION_SHA['green-storage-only']
    for name, digest in audit.TESTS.items():
        assert audit.sha256(repo / name) == digest, name
    env = os.environ.copy()
    forbidden = [key for key in env if env[key] and
                 (key.startswith('CARGO_PROFILE_') or key in
                  ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'))]
    assert not forbidden, 'unexpected override keys: ' + ','.join(forbidden)
    provider_path = root / 'inputs' / 'provider-env.json'
    provider_env = json.loads(provider_path.read_text())
    provider_proof = json.loads((root / 'evidence/provider-reuse/provider-reuse.json').read_text())
    assert provider_proof['result'] == 'REUSED_EXACT_PROVIDER_AND_FRESH_SMOKE_VERIFIED'
    assert provider_env['TRNM_PQ_OPENSSL_VERSION'] == '3.5.9'
    assert provider_env['OPENSSL_STATIC'] == '1'
    for item in provider_proof['native_backend_inputs']:
        assert audit.sha256(Path(item['path'])) == item['sha256'], item['path']
    compiler = audit.TOOLCHAIN / 'rustc'
    assert compiler.resolve(strict=True) == compiler
    env.update(provider_env)
    env.update({'PATH': str(audit.TOOLCHAIN) + ':' + env['PATH'],
                'RUSTC': str(compiler), 'CARGO_HOME': '/home/qq/.cargo',
                'CARGO_TARGET_DIR': str(root / 'target'), 'CARGO_BUILD_JOBS': '2'})
    keys = ('PATH', 'RUSTC', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
            'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'LD_LIBRARY_PATH', *provider_env)
    audit.save_json(out / 'environment.json', {key: env.get(key) for key in keys})
    audit.save_json(out / 'runner.identity.json', {
        'runner': str(Path(__file__).resolve()),
        'runner_sha256': audit.sha256(Path(__file__)),
        'helper': str(Path(audit.__file__).resolve()),
        'helper_sha256': audit.sha256(Path(audit.__file__)),
        'provider_environment_sha256': audit.sha256(provider_path),
        'commit': COMMIT, 'tree': TREE,
    })
    before = audit.snapshot(out, 'before')
    assert audit.run(out, 'preflight', ['bash', 'scripts/project-preflight.sh'], env) == 0
    for label, command in [('rustc', ['rustc', '--version', '--verbose']),
                           ('cargo', ['cargo', '--version', '--verbose']),
                           ('provider-version', [provider_env['TRNM_PQ_OPENSSL'], 'version'])]:
        assert audit.run(out, label, command, env) == 0
    archive = out / 'source.tar.gz'
    assert audit.run(out, 'source-archive',
                     ['git', 'archive', '--format=tar.gz', '--output=' + str(archive), COMMIT], env) == 0
    audit.save_json(out / 'source-archive.identity.json',
                    {'commit': COMMIT, 'tree': TREE, 'path': str(archive),
                     'size': archive.stat().st_size, 'sha256': audit.sha256(archive)})
    results = {}
    results['node_storage'] = run_test(out, 'node-storage', 'trnm-pon-node',
                                       'trnm_pon_node', 'storage_service::tests', env)
    results['native_budget'] = run_test(out, 'native-budget', 'trnm-service-settlement',
                                        'trnm_service_settlement', 'native_budget', env)
    clippy = [
        'cargo', 'clippy', '--manifest-path', 'trillionnium/Cargo.toml', '--locked', '--offline',
        '-p', 'trnm-pon-node', '-p', 'trnm-data-availability', '-p', 'trnm-service-settlement',
        '--all-targets', '--all-features', '-j', '2', '--', '-D', 'warnings',
    ]
    results['strict_clippy_exit_code'] = audit.run(out, 'strict-clippy', clippy, env)
    after = audit.snapshot(out, 'after')
    assert before == after, 'validation modified source checkout'
    summary = {'commit': COMMIT, 'tree': TREE, 'stage': 'green-final-combined',
               'source_unchanged': True,
               'source_files_sha256': before['files_manifest_sha256'],
               'provider_version': '3.5.9',
               'canonical_rustc': str(compiler), 'results': results}
    passed = all(result.get('build_exit_code') == 0
                 and result.get('test_exit_code') == 0
                 and result.get('passed', 0) > 0
                 and result.get('failed') == 0
                 for result in (results['node_storage'], results['native_budget']))
    summary['result'] = 'PASS' if passed and results['strict_clippy_exit_code'] == 0 else 'FAIL'
    audit.save_json(out / 'summary.json', summary)
    print(json.dumps(summary), flush=True)
    return 0 if summary['result'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
