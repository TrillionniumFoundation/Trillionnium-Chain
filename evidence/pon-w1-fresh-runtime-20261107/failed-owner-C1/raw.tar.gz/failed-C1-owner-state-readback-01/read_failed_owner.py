#!/usr/bin/env python3
"""Read closed C1 trial state from private copies; no Node/M12/target execution."""
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
import struct
import subprocess
import time

ROOT = Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
REPO = ROOT / 'integration-repo'
OUT = Path(__file__).resolve().parent
RUN = ROOT / 'owner-cancel-run-01'
NODE = ROOT / 'owner-cancel-research-node-01'
CONFIG = ROOT / 'owner-cancel-launch-plans-01/config.json'
C1 = 'cb557c5e59b00ba7c6b1d40f78fbe51031a26f11'
TREE = '7971aca2ff432ec8907bb69545a2c58d70b4a215'
SOURCES = {
    'trillionnium/crates/trnm-service-settlement/src/native_generation_budget_v2.rs': 'acf3c206be4d1ffad879dade186cd70fa0cdf5d8c0a8cf821b8bfce086eb6484',
    'trillionnium/crates/trnm-service-settlement/src/native_budget.rs': 'dd200bb218967dc4456ad48cf81a4e648202f0ed6593972717d7ee4a5eafe4db',
}
INVENTORY = {}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open('xb') as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())


def stable(path, limit=8 * 1024 * 1024):
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_size <= limit, 'ordinary bounded original required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        data = stream.read(limit + 1)
    after = path.lstat()
    require(len(data) <= limit and len(data) == before.st_size and
            all(getattr(before, k) == getattr(after, k) for k in
                ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')), 'original changed')
    row = {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    old = INVENTORY.get(str(path))
    require(old is None or old == row, 'original bytes changed across observations')
    INVENTORY[str(path)] = row
    return data


def obj(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'duplicate retained JSON field')
            result[key] = value
        return result
    return json.loads(stable(path), object_pairs_hook=pairs)


def private_db(path, label):
    for suffix in ('-wal', '-shm', '-journal'):
        p = Path(str(path) + suffix)
        require(not p.exists() and not p.is_symlink(), 'DB sidecar present; no stable single-file copy allowed')
    raw = stable(path)
    destination = OUT / 'private-analysis-only' / (label + '.sqlite')
    write(destination, raw)
    c = sqlite3.connect('file:' + str(destination) + '?mode=ro&immutable=1', uri=True)
    c.execute('PRAGMA query_only=ON')
    require(c.execute('PRAGMA integrity_check').fetchall() == [('ok',)], 'private SQLite integrity')
    result = {'tables': {}, 'application_id': c.execute('PRAGMA application_id').fetchone()[0],
              'user_version': c.execute('PRAGMA user_version').fetchone()[0]}
    schemas = c.execute("SELECT name,sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()
    for name, sql in schemas:
        require(re.fullmatch('[A-Za-z_][A-Za-z_0-9]*', name), 'ordinary table name')
        count = c.execute('SELECT count(*) FROM "' + name + '"').fetchone()[0]
        require(count <= 512, 'closed research database table bound')
        cursor = c.execute('SELECT * FROM "' + name + '"')
        columns = [v[0] for v in cursor.description]
        rows = [dict(zip(columns, row)) for row in cursor]
        require(len(rows) == count, 'complete private table readback')
        result['tables'][name] = {'sql': sql, 'columns': columns, 'rows': rows, 'total_rows': count}
    c.close()
    require(stable(path) == raw, 'original database changed after private query')
    for suffix in ('-wal', '-shm', '-journal'):
        p = Path(str(path) + suffix)
        require(not p.exists() and not p.is_symlink(), 'original DB sidecar appeared')
    dump = json.dumps(result, sort_keys=True, indent=2,
                      default=lambda v: {'bytes_hex': v.hex()} if isinstance(v, bytes) else None).encode() + b'\n'
    write(OUT / 'private-analysis-only' / (label + '-readback.json'), dump)
    result['original_pin'] = INVENTORY[str(path)]
    return result


class Reader:
    def __init__(self, raw):
        self.raw, self.at = raw, 0

    def take(self, n):
        require(self.at + n <= len(self.raw), 'truncated Borsh payload')
        value = self.raw[self.at:self.at + n]
        self.at += n
        return value

    def u8(self): return self.take(1)[0]
    def u32(self): return struct.unpack('<I', self.take(4))[0]
    def u64(self): return struct.unpack('<Q', self.take(8))[0]
    def digest(self): return self.take(32).hex()
    def end(self): require(self.at == len(self.raw), 'trailing Borsh bytes')


def anchor(r):
    value = {name: r.digest() for name in ('network', 'parameters', 'genesis', 'block', 'state_root')}
    value.update(height=r.u64(), generation=r.u64())
    return value


def clock(r): return {'clock_domain': r.digest(), 'now_ns': r.u64()}


def prepare(raw):
    r = Reader(raw); require(r.u8() == 0, 'Prepare Borsh tag')
    a, t = anchor(r), clock(r)
    start = r.at
    require(r.u8() == 0, 'FullW1ProofGeneration lane tag')
    s = {name: r.digest() for name in ('task', 'owner', 'provider', 'input_sha256', 'header_sha256',
        'expected_artifacts_sha256', 'expected_journal_sha256', 'expected_work_id')}
    s['image_id'] = [r.u32() for _ in range(8)]
    s.update({name: r.digest() for name in ('guest_sha256', 'verifier_binary_sha256', 'execution_source_commitment')})
    s['original_deadline'] = {'clock_domain': r.digest(), 'winner_ns': r.u64(), 'deadline_ns': r.u64()}
    s['chain_deadline'] = r.u64()
    s.update({name: r.digest() for name in ('provider_namespace', 'provider_operation', 'request_digest')})
    s['resource_cap'] = {name: r.u64() for name in ('cpu_ns', 'gpu_ns', 'memory_peak_upper_bound_bytes', 'receipt_bytes')}
    statement_raw = raw[start:r.at]
    domain = b'native-w1-generation-statement-v2'
    sid = hashlib.sha256(struct.pack('<Q', len(domain)) + domain + struct.pack('<Q', len(statement_raw)) + statement_raw).hexdigest()
    funding = {'owner': r.digest(), 'provider': r.digest(), 'whole_obligation': r.u64(), 'deadline': r.u64()}
    r.end()
    return {'anchor': a, 'clock': t, 'statement': s, 'statement_id': sid, 'funding': funding}


def intent_event(raw):
    r = Reader(raw); require(r.u8() == 1, 'Intent Borsh tag')
    value = {'id': r.digest(), 'anchor': anchor(r), 'clock': clock(r)}
    r.end(); return value


def main():
    os.umask(0o077); os.sched_setaffinity(0, {10, 11})
    result = {'schema': 'TRNM-W1-FAILED-C1-OWNER-READONLY-STATE1', 'analysis_complete': False, 'errors': [],
              'source_commit': C1, 'source_tree': TREE, 'original_database_connections_opened': 0,
              'original_databases_written': False, 'begin_dispatch_cancel_admit_payment_calls': 0,
              'fresh_proof_generations': 0, 'cold_Rust_replay_executed': False,
              'publish_exclusion': ['private-analysis-only/**'], 'started_monotonic_ns': time.monotonic_ns()}
    try:
        terminal = obj(OUT / 'original-terminal.json')
        require(terminal['job_id'] == '1a1b7db09a3-12894-c8e' and terminal['state'] == 'failed'
                and terminal['exit_code'] == 101 and terminal['output_complete'] is True
                and terminal['output_durable'] is True, 'original failed trial terminal')
        result['original_terminal'] = INVENTORY[str(OUT / 'original-terminal.json')]
        sources = {}
        for relative, expected in SOURCES.items():
            argv = ['/usr/bin/git', '-C', str(REPO), 'show', C1 + ':' + relative]
            run = subprocess.run(argv, stdin=subprocess.DEVNULL, capture_output=True, timeout=30, check=False)
            require(run.returncode == 0 and hashlib.sha256(run.stdout).hexdigest() == expected, 'exact C1 decoder source object')
            write(OUT / 'source-originals' / relative, run.stdout)
            sources[relative] = {'sha256': expected, 'bytes': len(run.stdout), 'argv': argv, 'exit': run.returncode}
        result['decoder_sources'] = sources
        m12_source = (OUT / 'source-originals' / next(iter(SOURCES))).read_text()
        expected_sql = {}
        for constant, table in (('META', 'native_generation_meta_v2'), ('EVENTS', 'native_generation_events_v2')):
            match = re.search(r'const ' + constant + r': &str = ("[^\n]*");', m12_source)
            require(match is not None, 'exact table schema source')
            expected_sql[table] = json.loads(match.group(1))
        config, retained_intent, request = obj(CONFIG), obj(RUN / 'native-funded-intent.json'), obj(RUN / 'target-request.json')
        require(config['expected_commit'] == C1 and config['expected_tree'] == TREE
                and config['out'] == str(RUN) and config['research_node_path'] == str(NODE), 'original config identity')
        require(retained_intent['schema'] == 'TRNM-W1-FUNDED-DISPATCH2'
                and retained_intent['research_node_path'] == str(NODE), 'original retained funding intent')
        raw_request = stable(RUN / 'target-request.json')
        canonical = json.dumps(request, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
        normalized = json.dumps({k: v for k, v in request.items() if k != 'statement'},
                                sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
        require(len(raw_request) == 68909 and len(canonical) == 66550 and len(request['file_pins']) == 339,
                'original actual oversize request regression changed')
        require(hashlib.sha256(canonical).hexdigest() == retained_intent['target_request_sha256']
                and hashlib.sha256(normalized).hexdigest() == retained_intent['normalized_request_digest'],
                'original actual request digest binding')
        m12 = private_db(RUN / 'native-generation-v2.sqlite', 'm12-generation')
        require(m12['application_id'] == 0x504e4732 and m12['user_version'] == 2
                and set(m12['tables']) == set(expected_sql), 'exact V2 M12 database namespace')
        for table, sql in expected_sql.items(): require(m12['tables'][table]['sql'] == sql, 'M12 SQL bytes changed')
        meta_rows = m12['tables']['native_generation_meta_v2']['rows']
        require(len(meta_rows) == 1, 'single journal metadata row')
        meta = meta_rows[0]; journal = meta['journal']
        require(journal.hex() == retained_intent['journal_identity'], 'original journal binding')
        events = sorted(m12['tables']['native_generation_events_v2']['rows'], key=lambda r: r['sequence'])
        names = ['Prepare', 'Intent', 'BindJob', 'Verified', 'Failure', 'Cancel', 'Settlement', 'Payment']
        previous = bytes(32); rows = []
        for sequence, event in enumerate(events, 1):
            payload = event['payload']
            require(1 <= len(payload) <= 16384 and payload[0] < len(names), 'exact bounded Borsh event tag')
            calculated = hashlib.sha256(b'pon-native-owner-w1-generation-budget-v2' + journal + previous
                                        + struct.pack('<QQ', sequence, len(payload)) + payload).digest()
            require(event['sequence'] == sequence and event['root'] == calculated, 'exact M12 hash chain')
            rows.append({'sequence': sequence, 'kind': names[payload[0]], 'payload_bytes': len(payload),
                         'payload_sha256': hashlib.sha256(payload).hexdigest(), 'root': calculated.hex()})
            previous = calculated
        require(meta['sequence'] == len(events) and meta['root'] == previous, 'exact M12 terminal head')
        require([row['kind'] for row in rows] == ['Prepare', 'Intent'], 'observed failed-before-provider journal')
        prep, intent = prepare(events[0]['payload']), intent_event(events[1]['payload'])
        s = prep['statement']
        require(prep['statement_id'] == intent['id'] == retained_intent['statement'] == request['statement'], 'exact statement ID')
        require(s['task'] == retained_intent['task'] and s['provider_operation'] == retained_intent['provider_operation']
                == request['operation'] == config['provider_operation'], 'original task/operation binding')
        require(s['request_digest'] == retained_intent['normalized_request_digest']
                and s['execution_source_commitment'] == INVENTORY[str(CONFIG)]['sha256'], 'original request/config commitment')
        require(s['resource_cap'] == config['resource_cap'] and prep['funding']['whole_obligation'] == 1000
                and prep['funding']['owner'] == s['owner'] and prep['funding']['provider'] == s['provider'], 'exact funding/resource cap')
        require(s['original_deadline']['deadline_ns'] == config['original_deadline_ns']
                and s['original_deadline']['winner_ns'] == retained_intent['winner_monotonic_ns'], 'original clock/deadline unchanged')
        for observation in (prep, intent):
            require(observation['anchor']['block'] == retained_intent['native_reserve_tip']
                    and observation['anchor']['height'] == 1
                    and observation['clock']['clock_domain'] == s['original_deadline']['clock_domain']
                    and s['original_deadline']['winner_ns'] <= observation['clock']['now_ns'] < s['original_deadline']['deadline_ns'],
                    'actual original Prepare/Intent anchors and clocks')
        native = private_db(NODE / 'native.sqlite', 'native-node')
        tables = native['tables']; active = tables['active']['rows']; blocks = tables['blocks']['rows']; deltas = tables['deltas']['rows']
        require(len(active) == 1 and active[0]['tip'].hex() == retained_intent['native_reserve_tip']
                and len(blocks) == 2 and sorted(b['height'] for b in blocks) == [0, 1], 'canonical original Reserve-only chain')
        require(next(b for b in blocks if b['height'] == 0)['id'].hex() == retained_intent['native_reserve_parent']
                and next(b for b in blocks if b['height'] == 1)['id'] == active[0]['tip']
                and all(d['block'] == active[0]['tip'] for d in deltas), 'exact original canonical chain ancestry')
        task_key = 'task:' + retained_intent['task']
        task_rows = [d for d in deltas if d['key'] == task_key]
        require(len(task_rows) == 1 and task_rows[0]['before'] is None, 'single original TaskReserve transition')
        task = json.loads(task_rows[0]['after'])
        require(task['status'] == 'reserved' and task['remaining'] == 1000 and task['output'] is None
                and task['owner'] == s['owner'] and task['provider'] == s['provider'], 'actual native remaining obligation')
        require(not any(d['key'] == 'account:' + task['provider'] for d in deltas), 'no provider account change in Reserve-only chain')
        fence = private_db(NODE / 'native.sqlite.w1-generation-owner-v2.sqlite', 'owner-fence')
        assignments = fence['tables']['w1_generation_owner_tasks_v2']['rows']
        require(len(assignments) == 1, 'single original owner assignment')
        assigned = assignments[0]
        for key, wanted in (('task', s['task']), ('statement', prep['statement_id']), ('journal', journal.hex()),
                            ('operation', s['provider_operation']), ('request', s['request_digest'])):
            require(assigned[key].hex() == wanted, 'owner fence binding changed')
        absent = {}
        for name, path in (('target_root', Path(config['target_root'])), ('proof', RUN / 'proof')):
            absent[name] = not path.exists() and not path.is_symlink()
            require(absent[name], 'unexpected target/proof output exists')
        group = Path(request['cgroup_parent'])
        require(group.is_absolute() and '/sys/fs/cgroup/' in str(group)
                and group.name == 'hepta-runtime-job-1a1b7db09a3-12894-c8e.service', 'original scope path identity')
        absent['original_outer_cgroup'] = not group.exists() and not group.is_symlink()
        for original in list(INVENTORY):
            stable(Path(original))
        result.update(analysis_complete=True, original_files=sorted(INVENTORY.values(), key=lambda p: p['path']),
            journal_identity=journal.hex(), event_tags=rows, event_counts=dict(collections.Counter(row['kind'] for row in rows)),
            exact_Prepare_and_Intent_Borsh_payloads_decoded=True, journal_raw_hash_chain_verified=True,
            dispatch_intent_persisted=True, bound_provider_job_present=False, cancel_event_present=False,
            verified_event_present=False, failure_event_present=False, settlement_event_present=False, payment_event_present=False,
            original_resource_cap=s['resource_cap'], resource_charge_derived_from_exact_source=s['resource_cap'],
            resource_charge_scope='No Verified or Failure-with-consumption event exists; unchanged V2 Record::readback retains original full cap. This reader never invoked Rust readback/begin or granted credit.',
            gpu_usage_ns=None, native_task_status='reserved', native_remaining_units=task['remaining'],
            native_post_genesis_blocks=1, native_current_tip=active[0]['tip'].hex(), native_cancel_or_settlement_block_present=False,
            provider_account_delta_present=False, provider_current_balance_independently_decoded=False,
            owner_assignment_count=1, original_operation=s['provider_operation'], original_statement=prep['statement_id'],
            original_deadline=s['original_deadline'], original_request={'raw_bytes': len(raw_request), 'canonical_bytes': len(canonical),
                'file_pins': len(request['file_pins']), 'raw_sha256': INVENTORY[str(RUN / 'target-request.json')]['sha256']},
            absent_paths=absent, all_descendants_wait_reaped=None, current_native_payment_authorized=False,
            private_database_copies_and_dumps_excluded_from_publication=True,
            scope='Closed failed C1 trial, no dispatch retry. Independent bounded byte/schema/hash-chain/canonical-row readback on private SQLite copies only. No successful cancellation, cold executable replay or payment qualification inferred.')
    except BaseException as exc:
        result['errors'].append({'type': type(exc).__name__, 'message': str(exc)})
    result['finished_monotonic_ns'] = time.monotonic_ns()
    path = OUT / 'state-readback.json'; write(path, encode(result)); raw = path.read_bytes()
    print(json.dumps({'analysis_complete': result['analysis_complete'], 'report': {'path': str(path), 'bytes': len(raw),
        'sha256': hashlib.sha256(raw).hexdigest()}, 'event_counts': result.get('event_counts'),
        'native_remaining_units': result.get('native_remaining_units'), 'errors': result['errors']}), flush=True)
    return 0 if result['analysis_complete'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
