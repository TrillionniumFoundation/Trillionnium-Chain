## Why this change is needed

The PQ implementations span several retained branches, while development-account scope, witnessed recovery and historical/current source evidence still have independent gaps. This continuation composes the reviewed implementations on #894 without turning source consistency into a whole-chain security claim.

## Changes

- Require the explicit development-only scope before M06 account effects, state roots and fresh/cold/warm Node ownership. Refuse missing, null, mistyped or production-like fields and stranded native-PQ configuration. Preserve #894's explicit-selector rejection, complete ML-DSA SPKI checks and live provider-history fence.
- Integrate #896's typed V5 witnessed Root owner and durable SQLite witness register, including pending/CAS/ACK recovery and its exact native rosters. The provider journal remains its separate V3 consumer; no unimplemented daemon, wire transport or effect sink is represented as complete.
- Integrate the hash-purpose contract and review the exact authority, Root and lifetime source pins. Historical lifetime reports remain unchanged; current input/report have a new evidence namespace. Unknown reductions, query budgets and bounds remain unknown.
- Materialize the QROM historical fixture from the original Git objects, distinguish current V1 refusal from current V2 mapping, and recompute complete source reports at the gate. Six report mutations that the first converged gate accepted are now rejected. Keep the original 81-control roster unchanged and require actual once-only completion of eight historical and fourteen current supplemental controls.
- Run the retained six-grid local CodeQL/SARIF lane for ordinary stacked PR bases under the existing same-repository guard. Default CodeQL setup is unchanged; local artifacts do not replace exact-source Code Scanning API results.
- Preserve exact native test names while sanitizing artifact filenames, and replace an obsolete consensus-count grep with an exact roster check.

- Repair the durable readiness checker's stale complete-body digest after reviewing the account guard before namespace effects. The prior digest is not a fallback. Add four guard-bypass mutations inside the existing 71-test roster: deletion, commenting, ignoring refusal and moving the guard after filesystem effects. Rebind the two changed corpus pins.

## Exact source

- Parent: `31543fb6dde565b62b47436e0b1d399b6d0bd772` (#894).
- Runtime checkpoint: `8add285b6c0a91d8b7812efe2d02c9342f74c91b`, tree `8aaa486aa4ccd4e41e33241fb4e7e273d3c3d5f6`.
- C1 native/hosted observation source: `c09dbbe9921da12db8bf7240a8a95a0e9a789e50`, tree `f15a7ee4a0f5455eaf965db01dcd49e02a5f22b6`.
- C2 readiness correction: `0e554f36ffdde3053a5eb1756eb5e526b1935032`, tree `753cdbad6714f00d8ccb9ddbb47f0fd71280ee62`. Rust source blobs are unchanged from C1, but the source corpus is embedded in native consumers; C2 is not an evidence-only revision.

## Validation and retained failures

C1 has 709 completed top-level Python test/control executions across the selected, resumed and required-gate observations. This is an execution count, not a count of independent security properties. The original incomplete cloud command remains terminal-state unknown; the later complete observation does not invent its missing exit. Locked/offline default, all-features and fuzz graphs and formatting passed. Native C1 tests and strict workspace/all-target/all-feature Clippy are still running with full tracked-source/provider readback; selected or in-progress cases are not counted as passes. The original 14-case provider target hit its 1,200-second limit after four completed cases, and the original 17-case V5 witness target also hit 1,200 seconds after six completed cases. Both targets remain failed; partial named completions are recorded separately.

C1 hosted QROM implementation passed for head and prospective merge, each with the exact 103 required IDs (unchanged 81 plus separate 8/14 controls). The six local CodeQL/SARIF grids all completed successfully. Each Rust lane retains 857 raw `rust/hard-coded-cryptographic-value` findings, each Python lane retains two `py/redos` findings, and Actions retains zero. These results are not a zero-finding security approval. The two Python locations are unchanged historical evidence scripts; the bounded source review does not resolve or suppress the findings. The separate Code Scanning API exporter performed **39 actual polls**, with empty required analyses/checks, and failed its original completion/authentication requirement. Local SARIF does not satisfy that API gate.

C1's original three-run native campaign failed all 9 phase criteria: each baseline confirmed 1/3 rounds, and all six attack phases confirmed 0/3 with `PUBLIC_REQUEST_DEADLINE`. All service observers completed and all three economics reports completed; the business result remains false. Both architecture cost lanes also failed the original four-second confirmation target under 16-worker pressure. Both x64 fresh-challenge lanes ran real native processes and exited 101 on the original four-second/six-depth target. Source/build/finalization success and invariant-test success do not change these business failures. No deadline, round count, depth or attack workload was relaxed.

The C1 readiness job exposed the stale source digest fixed by C2. C2 cloud corpus controls (60) and seven source-checker commands passed. Its full 71-test readiness run ended with three actual errors because `/usr/bin/time` is absent in that cloud environment; that unsuccessful run is retained. The same C2 roster independently passed all 71 tests on the desktop with real GNU time and exact source readback. Its wrapper initially used a nonexistent inventory-script pathname; that exit-2 failure is retained separately from the corrected inventory command. C2 native input/Clippy revalidation and final evidence packaging are pending. Earlier-source results are not relabeled as current-source execution.

Raw streams, source identities, original failures and immutable manifests are being retained for the evidence follow-up. PR remains draft.

## Qualification

**HOLD / NO-GO.** No whole-chain PQ/PQ-128 claim, production activation, protected-main bypass or self-approval is requested. Remaining obligations include complete deployed account/migration coverage; independent custody and non-co-restored Root freshness; public/WAN/recovery transport coverage; old commitment/root migration; quantum work/DAA/timestamp/chainwork composition; and the actual lifetime reduction/query budget. A complete reversible W1 oracle and a source mapping do not prove quantum mining safety.
