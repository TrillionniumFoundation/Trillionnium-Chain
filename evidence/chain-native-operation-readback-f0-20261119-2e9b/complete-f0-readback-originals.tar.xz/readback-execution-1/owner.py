from pathlib import Path
import json,subprocess,time,resource,hashlib,sys,traceback,os
root=Path('/home/qian-qi/work/chain-native-operation-readback-f0-20261119-2e9b');out=root/'readback-execution-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
res={'schema':'chain-original-f0-readback-execution-v1','business_reexecuted':False,'head':'3db79eb2682ba3bcbbf33557c5eee3b67731028f','run_id':44451798839,'invocation_count':0}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
save()
try:
 prepared=json.loads((root/'readers-preparation-1/RESULT.json').read_text());assert prepared['finished'] is True
 assert hashlib.sha256((root/'f0-readback.py').read_bytes()).hexdigest()==prepared['wrapper_sha256']=='82e51b28636e14328b4fec29acf65c7bd6dda8451c9d98531021670b946df7c3'
 for attempt in range(150):
  receipt=json.loads((root/'collection/COLLECTION.json').read_text())
  if receipt.get('error'):raise RuntimeError('original collection failed: '+receipt['error'])
  if receipt['complete_download'] is True:break
  if attempt%15==0:print(json.dumps({'waiting_for_original_collection':True,'checks':attempt}),flush=True)
  time.sleep(2)
 else:raise RuntimeError('original artifact not complete; no business run retried')
 command=['/usr/bin/python3',str(root/'f0-readback.py')];start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
 res['invocation_count']=1;res['command']=command;save()
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:
  p=subprocess.Popen(command,cwd=root,env=env,stdout=so,stderr=se);res['pid']=p.pid;save();rc=p.wait()
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 res.update(exit_code=rc,wall_seconds=time.monotonic()-start,child_user_cpu_seconds=after.ru_utime-before.ru_utime,child_system_cpu_seconds=after.ru_stime-before.ru_stime,outputs=[])
 for name in ('f0-independent-readback.json','current-cost-profile.json'):
  path=root/name
  if path.exists():res['outputs'].append({'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 save();print((out/'stdout').read_text(),flush=True);print(json.dumps(res),flush=True)
 if rc:print((out/'stderr').read_text(),flush=True)
 sys.exit(rc)
except BaseException as exc:
 if not isinstance(exc,SystemExit):res['error']=repr(exc);save();(out/'error.log').write_text(traceback.format_exc())
 raise
