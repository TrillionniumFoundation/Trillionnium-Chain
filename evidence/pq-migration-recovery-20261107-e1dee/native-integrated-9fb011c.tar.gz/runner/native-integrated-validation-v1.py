#!/usr/bin/env python3
"""Validate the integrated frozen source, retaining all earlier observations."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
TASK = Path('/home/qian-qi/work/chain-pq-migration-recovery-e1dee-20261106')
ORIGINAL = TASK / 'source'
ORIGINAL_HEAD = '2058225aa0d50ca57b1eb0d5f520d7f4eefae69b'
SOURCE = TASK / 'corrected-source'
HEAD = '9fb011c4af1f9f54353207f9ad9fbc54ab6235e3'
PRIOR_HEAD = '37ef49311db7e62df1b152b8a7b0fc9104d56c17'
PRIOR_TREE = '15f31d721e62f0766d0a9b13b42e163c93267d22'
TREE = '5f4f1730e0f5218e4db9706e6daf2c25cde5c182'
BUNDLE = TASK / 'pq-migration-integrated.bundle'
BUNDLE_SHA256 = 'f13ce4aa2bd5d53e403046c6fdc2822d3c12385211454775aca675d353b76331'
ENVIRONMENT_SHA256 = '5c9c21a7045e09aca9eab347a222c886dc56e5e10b7935f51b7dfe9f5a4a937a'
HELPER = TASK / 'native-validation-v1.py'
HELPER_SHA256 = 'fdd330aacfa3ccd65aa5740c433c76a284df8241e14ab80f31e9396fed4ed1b9'
TARGET = TASK / 'target-fixed'
OUT = TASK / 'records/native-integrated'
ORIGIN = 'https://github.com/TrillionniumFoundation/Trillionnium-Chain.git'
EXPECTED = {
    'node-migration': {
        'store::pq_migration_inventory::tests::fixed_admitted_checkpoint_keeps_inventory_across_forks_reorg_and_cold_open',
        'store::pq_migration_inventory::tests::inventory_requires_independent_source_pins_and_actual_admission',
        'store::pq_migration_inventory::tests::inventory_rechecks_actual_state_packet_and_storage_context_after_a_prior_success',
        'store::pq_migration_inventory::tests::inventory_refuses_durable_pending_reorg_then_uses_recovered_snapshot',
        'store::pq_migration_inventory::tests::inventory_does_not_substitute_growth_working_partition_for_complete_state',
        'store::pq_migration_inventory::handoff_tests::admitted_restricted_source_handoff_preserves_nonce_liability_and_claim_on_cold_open',
        'store::pq_migration_inventory::handoff_tests::admitted_source_handoff_refuses_wrong_registry_pins_and_unsupported_source_rows',
    },
    'm06-migration': {
        'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::empty_ledger_inventory_never_certifies_external_obligations_or_retirement',
        'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::zero_accounts_and_nonce_floors_are_preserved_as_identity_obligations',
        'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::all_monetary_namespaces_and_zero_obligations_are_counted_without_netting',
        'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::unknown_debt_revocation_execution_and_active_model_rows_block_empty_inference',
        'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::inventory_counts_every_opaque_row_but_bounds_diagnostic_key_examples',
        'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::inventory_rejects_wrong_pins_changed_state_and_inconsistent_issued_supply',
        'pon_executor::pq_accounts_v2::migration_inventory_v1::tests::malformed_account_is_not_relabelled_as_an_empty_ledger',
    },
}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def emit(value):
    print(json.dumps(value, sort_keys=True), flush=True)


def identity(source):
    def git(*args):
        return subprocess.check_output(
            ['/usr/bin/git', '--no-optional-locks', '-C', str(source), *args],
            text=True).strip()
    return {'head': git('rev-parse', 'HEAD'),
            'tree': git('rev-parse', 'HEAD^{tree}'),
            'status_porcelain': git('status', '--porcelain=v1', '--untracked-files=all')}


def load_helper():
    if digest(HELPER) != HELPER_SHA256:
        raise RuntimeError('original native helper digest changed')
    spec = importlib.util.spec_from_file_location('corrected_native_helpers', HELPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.PREP = OUT / 'source-preparation'
    return helper


def binary_rows(helper, build_log):
    rows = helper.executables(build_log, TARGET)
    for row in rows:
        path = Path(row['path'])
        if path.is_symlink():
            raise RuntimeError('test executable is a symlink')
        with path.open('rb') as stream:
            header = stream.read(64)
        if header[:4] != b'\x7fELF':
            raise RuntimeError('test executable is not native ELF')
        if not Path(row['target']['src_path']).resolve().is_relative_to(SOURCE.resolve()):
            raise RuntimeError('test executable artifact is not from corrected source')
        row['format'] = 'ELF'
        row['elf_header_sha256'] = hashlib.sha256(header).hexdigest()
    return rows


INTEGRATION_CASES = [
    ('integration-claim-cold-open', 'npq6_anchored_claim_preserves_obligations_rotates_and_cold_reopens'),
    ('integration-signatures-domain', 'npq6_migration_requires_both_claim_signatures_and_the_selected_domain'),
    ('integration-unsupported-source', 'admitted_legacy_checkpoint_cannot_drop_unhandled_work_state_for_migration'),
]


def retain_prior_binaries(helper):
    retained = TASK / 'retained-native-before-integrated'
    retained.mkdir(mode=0o700)
    entries = []
    paths = set()
    for label, previous in [
        ('checkpoint', TASK / 'records/native-fixed/checkpoint-binaries-after.json'),
        ('node-migration', TASK / 'records/native-corrected/node-migration-binaries-after.json'),
        ('m06-migration', TASK / 'records/native-corrected/m06-migration-binaries-after.json'),
    ]:
        rows = json.loads(previous.read_text())
        helper.recheck_binaries(rows)
        for index, row in enumerate(rows):
            original = Path(row['path'])
            if str(original) in paths:
                continue
            paths.add(str(original))
            if not original.resolve().is_relative_to(TARGET.resolve()):
                raise RuntimeError('prior binary outside selected target')
            copied = retained / (label + '-' + str(index) + '-' + original.name)
            with original.open('rb') as source, copied.open('xb') as target:
                shutil.copyfileobj(source, target)
                target.flush()
                os.fsync(target.fileno())
            os.chmod(copied, 0o555)
            if copied.stat().st_size != row['size'] or digest(copied) != row['sha256']:
                raise RuntimeError('retained prior binary differs from original receipt')
            entries.append({'source_record': str(previous), 'source_record_sha256': digest(previous),
                            'original': str(original), 'retained': str(copied),
                            'size': row['size'], 'sha256': row['sha256']})
    helper.save(OUT / 'prior-elf-retention.json', entries)
    return entries


def main(helper):
    if digest(BUNDLE) != BUNDLE_SHA256:
        raise RuntimeError('integrated bundle digest mismatch')
    if digest(TASK / 'environment.json') != ENVIRONMENT_SHA256:
        raise RuntimeError('fixed environment file changed')
    original_before = identity(ORIGINAL)
    if original_before['head'] != ORIGINAL_HEAD or original_before['status_porcelain']:
        raise RuntimeError('retained probe source is not the clean expected original')
    prior = identity(SOURCE)
    if prior != {'head': PRIOR_HEAD, 'tree': PRIOR_TREE, 'status_porcelain': ''}:
        raise RuntimeError('corrected source is not the exact clean prior qualified source')
    helper.save(OUT / 'original-source-before.json', original_before)
    helper.save(OUT / 'prior-corrected-source.json', prior)
    helper.preparation('prior-preflight', ['/bin/bash', 'scripts/project-preflight.sh'], SOURCE)
    retained = retain_prior_binaries(helper)
    checkpoint_input = TASK / 'records/native-fixed/checkpoint-tests-observation.json'
    checkpoint_roster = json.loads(checkpoint_input.read_text())
    if (len(checkpoint_roster['passed']) != 56 or len(set(checkpoint_roster['passed'])) != 56
            or checkpoint_roster['failed'] or checkpoint_roster['ignored']):
        raise RuntimeError('prior checkpoint roster is not the original 56 passed tests')
    helper.save(OUT / 'prior-checkpoint-roster.json', {
        'path': str(checkpoint_input), 'sha256': digest(checkpoint_input), 'observation': checkpoint_roster})
    helper.preparation('integrated-bundle-verify', ['/usr/bin/git', 'bundle', 'verify', str(BUNDLE)], SOURCE)
    helper.preparation('integrated-bundle-import', ['/usr/bin/git', 'fetch', '--no-tags', str(BUNDLE), HEAD], SOURCE)
    helper.preparation('integrated-fast-forward', ['/usr/bin/git', 'merge', '--ff-only', HEAD], SOURCE)
    source_before = identity(SOURCE)
    if source_before != {'head': HEAD, 'tree': TREE, 'status_porcelain': ''}:
        raise RuntimeError('integrated source identity mismatch')
    helper.save(OUT / 'integrated-source-before.json', source_before)
    environment = helper.load_environment('target-fixed')
    if (environment['CARGO_BUILD_JOBS'] != '2' or environment['CARGO_INCREMENTAL'] != '0'
            or environment['RUST_TEST_THREADS'] != '1' or environment['RUSTUP_TOOLCHAIN'] != '1.95.0'):
        raise RuntimeError('original native concurrency/toolchain selection changed')
    if digest(environment['TRNM_PQ_OPENSSL']) != environment['TRNM_PQ_OPENSSL_SHA256']:
        raise RuntimeError('pinned original native provider digest changed')
    cargo = str(Path(environment['RUSTC']).with_name('cargo'))
    flags = ['--locked', '--offline', '--manifest-path', 'trillionnium/Cargo.toml']
    def record(label, command):
        return helper.record(SOURCE, HEAD, OUT, environment, label, command)
    def preflight(label):
        return record(label, ['/bin/bash', 'scripts/project-preflight.sh'])
    preflight('preflight')
    record('rustc', [environment['RUSTC'], '-Vv'])
    record('cargo', [cargo, '-V'])
    all_binaries = []
    observations = {}
    scopes = [
        ('checkpoint', 'trnm-checkpoint-store', ['--all-targets'], [], 56, set(checkpoint_roster['passed'])),
        ('node-migration', 'trnm-pon-node', ['--lib', '--all-features'], ['pq_migration_inventory'], 7, EXPECTED['node-migration']),
        ('m06-migration', 'trnm-mvcc-fee', ['--lib'], ['migration_inventory_v1'], 7, EXPECTED['m06-migration']),
    ]
    for name, package, target_args, selectors, expected_count, expected_names in scopes:
        args = [cargo, 'test', *flags, '-p', package, *target_args]
        preflight(name + '-build-preflight')
        build = record(name + '-build', [*args, '--no-run', '--message-format=json'])
        binaries = binary_rows(helper, build)
        helper.save(OUT / (name + '-binaries-before.json'), binaries)
        all_binaries.extend(binaries)
        preflight(name + '-run-preflight')
        log = OUT / (name + '-tests.log')
        try:
            record(name + '-tests', [*args, '--no-fail-fast', *selectors, '--', '--test-threads=1'])
        finally:
            helper.recheck_binaries(binaries)
            helper.save(OUT / (name + '-binaries-after.json'), binaries)
            if log.exists():
                tests = helper.actual_tests(log)
                helper.save(OUT / (name + '-tests-observation.json'), tests)
        if (tests['failed'] or tests['ignored'] or len(tests['passed']) != expected_count
                or set(tests['passed']) != expected_names or not tests['summaries']):
            raise RuntimeError('required exact native test roster was not passed: ' + name)
        if selectors and (len(tests['summaries']) != 1 or not re.fullmatch(
                r'test result: ok\. 7 passed; 0 failed; 0 ignored; 0 measured; [0-9]+ filtered out; finished in [0-9]+(?:\.[0-9]+)?s', tests['summaries'][0])):
            raise RuntimeError('required migration summary was not passed: ' + name)
        observations[name] = tests
    args = [cargo, 'test', *flags, '-p', 'trnm-pon-node', '--test', 'pq_application_migration_v6']
    preflight('integration-build-preflight')
    build = record('integration-build', [*args, '--no-run', '--message-format=json'])
    integration_binaries = binary_rows(helper, build)
    helper.save(OUT / 'integration-binaries-before.json', integration_binaries)
    all_binaries.extend(integration_binaries)
    for label, selector in INTEGRATION_CASES:
        preflight(label + '-preflight')
        log = OUT / (label + '.log')
        try:
            record(label, [*args, selector, '--', '--exact', '--show-output', '--test-threads=1'])
        finally:
            helper.recheck_binaries(integration_binaries)
            helper.save(OUT / (label + '-binaries-after.json'), integration_binaries)
            if log.exists():
                tests = helper.actual_tests(log)
                helper.save(OUT / (label + '-observation.json'), tests)
        record(label + '-execution', ['/usr/bin/python3', 'scripts/ci/check_required_native_test.py',
                                     str(log), '--test', selector])
        if tests['failed'] or tests['ignored'] or tests['passed'] != [selector]:
            raise RuntimeError('required exact integration test was not passed: ' + selector)
        observations[label] = tests
    preflight('workspace-clippy-preflight')
    record('workspace-clippy', [cargo, 'clippy', *flags, '--workspace', '--all-targets',
                               '--all-features', '--', '-D', 'warnings'])
    helper.recheck_binaries(all_binaries)
    helper.save(OUT / 'binaries-after-all-gates.json', all_binaries)
    for row in retained:
        if Path(row['retained']).stat().st_size != row['size'] or digest(row['retained']) != row['sha256']:
            raise RuntimeError('prior retained ELF changed during integration validation')
    source_after = identity(SOURCE)
    original_after = identity(ORIGINAL)
    helper.save(OUT / 'integrated-source-after.json', source_after)
    helper.save(OUT / 'original-source-after.json', original_after)
    if source_before != source_after or original_before != original_after:
        raise RuntimeError('source identity changed during integrated validation')
    if digest(TASK / 'environment.json') != ENVIRONMENT_SHA256 or digest(HELPER) != HELPER_SHA256:
        raise RuntimeError('original environment/helper changed during validation')
    result = {'schema': 'trnm-integrated-pq-native-validation-v1', 'status': 'completed',
              'tested_source': HEAD, 'tested_tree': TREE,
              'retained_probe_source': ORIGINAL_HEAD, 'retained_probe_source_unchanged': True,
              'prior_corrected_source': PRIOR_HEAD, 'prior_corrected_elf_retained': True,
              'environment_sha256': ENVIRONMENT_SHA256, 'helper_sha256': HELPER_SHA256,
              'bundle_sha256': BUNDLE_SHA256, 'commands': helper.COMMANDS,
              'tests': observations, 'native_elf_identity_unchanged': True,
              'automatic_retry': False, 'source_finality_or_retirement_qualified': False,
              'whole_chain_quantum_security_qualified': False, 'production_activation': False}
    helper.save(OUT / 'complete.json', result)
    emit({'event': 'integrated_native_complete', 'source': HEAD, 'checkpoint_passed': 56,
          'node_all_features_passed': 7, 'm06_passed': 7, 'integration_default_features_passed': 3,
          'strict_workspace_clippy': 'passed', 'automatic_retry': False})


if __name__ == '__main__':
    helper = None
    try:
        helper = load_helper()
        OUT.mkdir(mode=0o700)
        helper.PREP.mkdir(mode=0o700)
        main(helper)
    except Exception as error:
        if helper is not None and OUT.is_dir():
            failure = {'status': 'failed', 'error': str(error), 'commands': helper.COMMANDS,
                       'tested_source': HEAD, 'automatic_retry': False}
            for label, source in [('corrected', SOURCE), ('original', ORIGINAL)]:
                if (source / '.git').is_dir():
                    try:
                        failure[label + '_source_after_failure'] = identity(source)
                    except Exception as identity_error:
                        failure[label + '_source_identity_error'] = str(identity_error)
            path = OUT / 'failure.json'
            if not path.exists():
                helper.save(path, failure)
        emit({'event': 'integrated_native_failed', 'error': str(error), 'automatic_retry': False})
        sys.exit(1)
