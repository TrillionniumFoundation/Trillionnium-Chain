"""Observed pre-fix source-consistency counterexample, not a remote attack.

Run from formal/pon-nakamoto-v1 with that directory in PYTHONPATH.  This changes
only the isolated Python process's imported binding and restores it on exit.
"""
from test_useful_cell_relation_v2 import StatefulCellRelationTests as T
import useful_cell_execution_v2 as execution
import useful_cell_relation_v2 as relation

T.setUpClass()
original = execution.execute
identity_before = relation.current_identity()


def foreign_execute(model, rows, before, policy, *, verified_products=None):
    result = original(model, rows, before, policy, verified_products=verified_products)
    result['after_state']['memory'][0] += 1
    result['trace'][-1]['outputs']['after']['memory'][0] += 1
    return result


try:
    execution.execute = foreign_execute
    identity_equal = relation.current_identity() == identity_before
    forged = relation.prove_reference(T.raw, T.model, T.rows, T.before, max_attempts=1)
    accepted = relation.verify_historical_relation(
        T.raw, T.before, forged['output'], forged['after_state'], forged['witness'], expected=T.expected)
    print({'foreign_module': foreign_execute.__module__, 'identity_unchanged': identity_equal,
           'correct_memory': T.proved['after_state']['memory'],
           'forged_memory': forged['after_state']['memory'], 'accepted': accepted['relation_valid'],
           'complete_w1_transcripts': accepted['complete_w1_transcripts_verified']})
finally:
    execution.execute = original
