from pathlib import Path
from datetime import datetime,timezone
import ast,base64,hashlib,json,subprocess,time,resource,sys,traceback
root=Path('/home/qian-qi/work/chain-native-owned-append-f0-20261119-2e9b');old=Path('/home/qian-qi/work/chain-native-operation-readback-f0-20261119-2e9b')
out=root/'readers-preparation-1';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1])
head='e8b0ec93ab6a6a1ff5e36cfcf9d1179e030a5975';source=root/'readers-source';source.mkdir(exist_ok=False)
res={'schema':'chain-f0-exact-pinned-reader-preparation-v1','head':head,'requests':[],'files':[],'reader_semantics_changed':False,'finished':False}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def create(path,raw):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb') as stream:stream.write(raw)
try:
 copies=[('prior-f0-readback.py','e7c17ba2ffe48107dde6e7905f2de6ac6e9718571c2b497113383efff04c3f99'),('prior-cost-profile.py','68a5fc3877527c66491fb20fb5dd35a8b61d93ee090e9dc9a6076fca8d8a66d3')]
 for name,expected in copies:
  raw=(old/name).read_bytes();assert sha(raw)==expected;create(root/name,raw)
 expected=None
 for node in ast.parse((root/'prior-f0-readback.py').read_text()).body:
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ORIGINAL_READER_SHA256' for t in node.targets):expected=ast.literal_eval(node.value)
 assert isinstance(expected,dict) and len(expected)==12
 configs=json.loads((old/'READERS_CONFIGS.json').read_text());assert configs['head']=='3db79eb2682ba3bcbbf33557c5eee3b67731028f'
 prior_configs={r['path']:r for r in configs['files']};assert len(prior_configs)==5
 allpaths={**expected,**{p:r['sha256'] for p,r in prior_configs.items()}}
 for i,(path,expected_sha) in enumerate(allpaths.items()):
  dest=out/(str(i)+'.response.json');err=out/(str(i)+'.stderr')
  command=['/usr/bin/gh','api','repos/TrillionniumFoundation/Trillionnium-Chain/contents/'+path+'?ref='+head]
  start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
  with dest.open('xb') as so,err.open('xb') as se:p=subprocess.Popen(command,stdout=so,stderr=se);rc=p.wait()
  after=resource.getrusage(resource.RUSAGE_CHILDREN)
  row={'path':path,'command':command,'exit_code':rc,'wall_seconds':time.monotonic()-start,'child_user_cpu_seconds':after.ru_utime-before.ru_utime,'child_system_cpu_seconds':after.ru_stime-before.ru_stime}
  res['requests'].append(row);save();assert rc==0
  response=json.loads(dest.read_text());assert response['type']=='file' and response['encoding']=='base64'
  raw=base64.b64decode(response['content']);blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
  assert sha(raw)==expected_sha and response['sha']==blob and response['size']==len(raw)
  if path in prior_configs:assert prior_configs[path]['git_blob']==blob and prior_configs[path]['bytes']==len(raw)
  create(source/path,raw);res['files'].append({'path':path,'sha256':sha(raw),'bytes':len(raw),'git_blob':blob});save()
 configs['head']=head;create(root/'READERS_CONFIGS.json',(json.dumps(configs,indent=2)+'\n').encode())
 oldwrapper=(old/'f0-readback.py').read_text()
 assert sha(oldwrapper.encode())=='82e51b28636e14328b4fec29acf65c7bd6dda8451c9d98531021670b946df7c3'
 wrapper=oldwrapper.replace("HEAD='3db79eb2682ba3bcbbf33557c5eee3b67731028f'","HEAD='"+head+"'").replace("TREE='4877dd4e945841e734a57234e89fb1eb0440805e'","TREE='c896826d4f376d6643b05c15486f573e9aff6546'").replace('RUN=44451798839','RUN=44465153982')
 expected_wrapper=sys.argv[2];assert wrapper==expected_wrapper
 create(root/'f0-readback.py',wrapper.encode())
 res['wrapper_sha256']=sha(wrapper.encode());res['only_wrapper_identity_fields_changed']=['HEAD','TREE','RUN'];res['finished']=True;save()
 print(json.dumps({'reader_preparation_complete':True,'head':head,'original_imported_reader_files':len(expected),'original_configs':len(configs['files']),'wrapper_sha256':res['wrapper_sha256']}),flush=True)
except BaseException as exc:
 res['error']=repr(exc);save();(out/'error.log').write_text(traceback.format_exc());raise
