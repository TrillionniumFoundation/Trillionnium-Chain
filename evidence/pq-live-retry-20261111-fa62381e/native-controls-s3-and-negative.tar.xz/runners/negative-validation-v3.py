#!/usr/bin/env python3
"Isolated negative-control observation. Actual native failures remain failures.\nThis temporary observer retains the default workspace build and original helpers.\nOnly a separate expectation assessment can succeed for the intended 2 PASS / 5 FAIL pattern.\n"
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

GROUPS = [['account', ['ingress::account_scope_tests::invalid_account_scope_refuses_classical_session_and_signed_request', 'ingress::account_scope_tests::current_local_scope_refuses_previously_valid_classical_request', 'ingress::account_scope_tests::invalid_account_scope_never_connects_or_advances_classical_clients', 'ingress::account_scope_tests::valid_development_scope_retains_classical_signature_and_socket_path', 'ingress::account_scope_tests::explicit_pq_selector_retains_classical_route_refusal_precedence']], ['witness-new', ['pq_rollback_witness::tests::live_retry_refuses_changed_durable_predecessor_at_the_same_head', 'pq_rollback_witness::tests::cold_reopen_refuses_database_retry_history_and_accepts_new_successors']]]
SELECTION = [(f"{group}-{index + 1:02d}", name)
             for group, names in GROUPS for index, name in enumerate(names)]


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def read_pinned_artifact(path, expected):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected:
        raise ValueError("build provenance artifact changed")
    return json.loads(raw)


def imports(root):
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(root / "scripts/ci"))


def verify_runner(expected):
    if digest(Path(__file__).resolve()) != expected:
        raise ValueError("temporary runner digest changed")


def native_worker(argv):
    root, executable, expected, out_text, runner_pin, *native_args = argv
    root, out = Path(root), Path(out_text)
    verify_runner(runner_pin)
    imports(root)
    from pinned_native_process import run_pinned
    record = {"argv": [executable, *native_args], "status": "running",
              "native_exit_code": None, "native_execution": None,
              "expected_executable_sha256": expected, "runner_sha256": runner_pin}
    receipt, log = out.with_suffix(".native.json"), out.with_suffix(".log")
    with receipt.open("x") as stream:
        json.dump(record, stream)
    exit_code = 1
    started = time.monotonic_ns()
    try:
        with log.open("xb") as stream:
            code, identity = run_pinned(record["argv"], root, stream, expected)
        record.update(native_exit_code=code, native_execution=identity)
        success = code == 0 and identity["status"] == "PINNED_AND_OBSERVED"
        record["status"] = "command_succeeded" if success else "command_failed"
        exit_code = (code if code >= 0 else 128 - code) if code else int(not success)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        record.update(status="record_failed", error=str(exc))
    finally:
        record["elapsed_ns"] = time.monotonic_ns() - started
        if log.exists():
            record.update(log=log.name, log_bytes=log.stat().st_size, log_sha256=digest(log))
        write_json(receipt, record)
    return exit_code


def validate_failed(text, expected):
    """Require one real failed test at the reviewed old-behavior assertion."""
    name = expected["test"]
    lines = text.splitlines()
    if [line for line in lines if line.startswith("running ")] != ["running 1 test"]:
        raise ValueError("negative control requires exactly one actual test")
    announcements = [line for line in lines if re.fullmatch(
        r"test [A-Za-z0-9_:]+ \.\.\.(?: .*)?", line)]
    if announcements != [f"test {name} ... FAILED"]:
        raise ValueError("negative control requires the exact failed test identity")
    summaries = [line for line in lines if line.startswith("test result:")]
    if len(summaries) != 1 or re.fullmatch(
        r"test result: FAILED\. 0 passed; 1 failed; 0 ignored; 0 measured; "
        r"[0-9]+ filtered out; finished in [0-9]+(?:\.[0-9]+)?s", summaries[0]
    ) is None:
        raise ValueError("negative control requires one failure without skips")
    panics = re.findall(
        r"^thread '" + re.escape(name)
        + r"'(?: \([0-9]+\))? panicked at (.+):([0-9]+):([0-9]+):$",
        text, re.M)
    suffix = expected["source_file"].removeprefix("trillionnium/")
    if (len(panics) != 1 or not panics[0][0].endswith(suffix)
            or int(panics[0][1]) != expected["panic_line"]):
        raise ValueError("negative control failed outside the reviewed assertion")
    if any(marker not in text for marker in expected["markers"]):
        raise ValueError("negative control lacks its reviewed semantic failure")
    if len(re.findall(r"\nfailures:\n[ \t]+" + re.escape(name) + r"\n\n", text)) != 1:
        raise ValueError("negative control lacks its one exact failure listing")
    return {
        "result": "FAIL", "test": name, "executed_tests": 1,
        "expected_assertion_failure_observed": True,
        "panic_file": panics[0][0], "panic_line": int(panics[0][1]),
        "scope": "named-libtest-failure-at-reviewed-assertion-only",
    }


def verify_lineage(root, negative_source, positive_source, lineage_path):
    data = json.loads(lineage_path.read_text())
    if (data["schema"] != "trnm-isolated-pq-negative-source-v1"
            or data["negative_source"] != negative_source
            or data["positive_source"] != positive_source
            or data["base_behavior_source"] != "6c35f94d9387fac41c1547f05742d70150320b2e"):
        raise ValueError("negative source lineage mismatch")
    def git(*args):
        return subprocess.check_output(
            ["git", "--no-replace-objects", *args], cwd=root, text=True).strip()
    paths = [
        "trillionnium/crates/trnm-pon-node/src/ingress.rs",
        "trillionnium/crates/trnm-pon-node/src/pq_rollback_witness.rs",
    ]
    if (git("rev-parse", "HEAD") != negative_source
            or git("rev-parse", "HEAD^") != positive_source
            or git("diff-tree", "--no-commit-id", "--name-only", "-r", negative_source).splitlines() != paths
            or data["changed_paths"] != paths):
        raise ValueError("negative source is not the exact two-file child")
    for path, expected in data["source_files_sha256"].items():
        if digest(root / path) != expected:
            raise ValueError("negative lineage source bytes changed: " + path)
    manifest = json.loads((root / "config/pon/pq-system-supplemental-tests-v1.json").read_text())
    if (manifest["schema"] != "trnm-pq-system-supplemental-tests-v1"
            or manifest["expected_meaningful_controls"] != 7
            or manifest["tests"] != [name for _, name in SELECTION]
            or manifest["whole_chain_quantum_security_qualified"] is not False):
        raise ValueError("seven frozen supplemental selectors changed")
    account = "trillionnium/crates/trnm-pon-node/src/ingress/account_scope_tests.rs"
    witness = "trillionnium/crates/trnm-pon-node/src/pq_rollback_witness/tests.rs"
    account_bytes = (root / account).read_bytes()
    if hashlib.sha256(account_bytes).hexdigest() != "7da5594a8b7e9a61ce147426272ec4b74e167f2b9a55c8fe5c525269082e610d":
        raise ValueError("reviewed committed S3 account test bytes changed")
    account_lines = account_bytes.decode("utf-8").splitlines()
    if (account_lines[72].strip() != ".unwrap_err();"
            or account_lines[89].strip() != "let error = authenticate_request(&wire, &settings, &server).unwrap_err();"
            or account_lines[153].strip() != "assert_eq!("):
        raise ValueError("reviewed account assertion positions changed")
    witness_raw = (root / witness).read_text()
    live_at = witness_raw.index("retry.advance(forged, next).unwrap_err().to_string(),")
    cold_start = witness_raw.index(
        "fn cold_reopen_refuses_database_retry_history_and_accepts_new_successors()")
    cold_at = witness_raw.index(".unwrap_err()", cold_start)
    marker = "called " + chr(96) + "Result::unwrap_err()" + chr(96) + " on an " + chr(96) + "Ok" + chr(96) + " value"
    expected = [
        {"test": SELECTION[0][1], "source_file": account, "panic_line": 73, "markers": [marker]},
        {"test": SELECTION[1][1], "source_file": account, "panic_line": 90, "markers": [marker]},
        {"test": SELECTION[2][1], "source_file": account, "panic_line": 154,
         "markers": ["authenticated production_activation-wrong, protected=false", "left: 1", "right: 0"]},
        {"test": SELECTION[5][1], "source_file": witness,
         "panic_line": witness_raw[:live_at].count("\n") + 1, "markers": [marker]},
        {"test": SELECTION[6][1], "source_file": witness,
         "panic_line": witness_raw[:cold_at].count("\n") + 1, "markers": [marker]},
    ]
    if data["failure_expectations"] != expected:
        raise ValueError("negative assertion expectations differ from reviewed tests")
    return data


def await_negative_release(output, release_path, artifact_path, artifact_pin,
                           source, positive_source, runner_pin, timeout):
    """Separate build completion from seven negative executions."""
    import stat
    artifact = read_pinned_artifact(artifact_path, artifact_pin)
    expected = {
        "schema": "trnm-pq-negative-native-release-v1",
        "status": "positive-native-controls-complete",
        "negative_source": source, "positive_source": positive_source,
        "native_artifact_sha256": artifact_pin,
        "executable_sha256": artifact["executable_sha256"],
    }
    ready = {
        "status": "native-build-complete-awaiting-negative-release",
        "negative_source": source, "positive_source": positive_source,
        "native_artifact_sha256": artifact_pin,
        "executable_sha256": artifact["executable_sha256"],
        "build_receipt_sha256": artifact["build_receipt_sha256"],
        "runner_sha256": runner_pin, "native_tests_started": False,
        "component_validation_passed": False,
        "release_path": str(release_path), "required_release_value": expected,
        "barrier_timeout_seconds": timeout,
    }
    with (output / "build-ready.json").open("x") as stream:
        json.dump(ready, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"status": ready["status"],
                      "build_ready": str(output / "build-ready.json")}), flush=True)
    started = time.monotonic_ns()
    deadline = time.monotonic() + timeout
    while True:
        if time.monotonic() >= deadline:
            raise ValueError("negative execution barrier timed out; no native tests started")
        try:
            fd = os.open(release_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except FileNotFoundError:
            time.sleep(min(0.25, max(0, deadline - time.monotonic())))
            continue
        with os.fdopen(fd, "rb") as stream:
            before = os.fstat(stream.fileno())
            if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                    or not 0 < before.st_size <= 8192):
                raise ValueError("negative release must be a bounded regular single-link file")
            raw = stream.read(8193)
            after = os.fstat(stream.fileno())
            if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                    != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
                    or len(raw) != before.st_size):
                raise ValueError("negative release changed during its read")
        def unique(pairs):
            value = {}
            for key, item in pairs:
                if key in value:
                    raise ValueError("duplicate negative release field")
                value[key] = item
            return value
        value = json.loads(raw, object_pairs_hook=unique)
        if value != expected:
            raise ValueError("negative release is not bound to this source and ELF")
        if digest(artifact_path) != artifact_pin:
            raise ValueError("native artifact changed while awaiting negative release")
        verify_runner(runner_pin)
        if time.monotonic() >= deadline:
            raise ValueError("negative execution barrier timed out before accepting release")
        write_json(output / "negative-release-observation.json", {
            "value": value, "release_sha256": hashlib.sha256(raw).hexdigest(),
            "elapsed_ns": time.monotonic_ns() - started,
            "native_tests_started_before_release": False,
        })
        return


def native_batch(argv):
    root_text, artifact_text, artifact_pin, out_text, runner_pin, timeout_text = argv
    root, artifact_path, output = Path(root_text), Path(artifact_text), Path(out_text)
    timeout = int(timeout_text)
    verify_runner(runner_pin)
    artifact = read_pinned_artifact(artifact_path, artifact_pin)
    executable, expected = artifact["executable"], artifact["executable_sha256"]
    failures = {row["test"]: row for row in artifact["failure_expectations"]}
    if set(failures) != {SELECTION[i][1] for i in (0, 1, 2, 5, 6)}:
        raise ValueError("expected five old-behavior assertion failures changed")
    imports(root)
    from ci_observation import run as run_observed
    from check_required_native_test import validate
    records = []
    actual_passed = actual_failed = matched = 0

    def run_one(label, native_args, required_name=None):
        prefix = output / label
        worker = [sys.executable, str(Path(__file__).resolve()), "_native_worker",
                  str(root), executable, expected, str(prefix), runner_pin, *native_args]
        owner = run_observed(worker, output / (label + ".owner.log"),
                             cwd=root, timeout=timeout)
        error, execution, validation = None, None, None
        log = prefix.with_suffix(".log")
        expected_failure = required_name in failures
        expected_code = 101 if expected_failure else 0
        try:
            execution = json.loads(prefix.with_suffix(".native.json").read_text())
            if (owner["exit_code"] != expected_code or owner["timed_out"]
                    or execution["status"] != ("command_failed" if expected_failure else "command_succeeded")
                    or execution["native_exit_code"] != expected_code
                    or execution["native_execution"]["status"] != "PINNED_AND_OBSERVED"):
                raise ValueError("native exit, timeout, or live ELF identity differs from the observation contract")
            if execution["log_sha256"] != digest(log):
                raise ValueError("native transcript digest changed")
            if required_name is not None:
                if expected_failure:
                    validation = validate_failed(log.read_text(), failures[required_name])
                else:
                    with log.open() as stream:
                        validation = validate(stream, required_name)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            error = str(exc)
        row = {
            "label": label, "required_test": required_name, "owner": owner,
            "native_receipt": execution, "named_execution": validation, "error": error,
            "expected_native_exit_code": expected_code,
            "expected_assertion_failure": expected_failure,
            "negative_expectation_matched": error is None,
        }
        if log.exists():
            row.update(log=log.name, log_bytes=log.stat().st_size, log_sha256=digest(log))
        records.append(row)
        write_json(output / "batch-observations.json", records)
        print(json.dumps({"label": label, "owner_exit": owner["exit_code"],
                          "native_exit": execution.get("native_exit_code") if execution else None,
                          "expected_native_exit": expected_code,
                          "timed_out": owner["timed_out"], "error": error}), flush=True)
        return error is None, execution

    phase_error = None
    try:
        valid, _ = run_one("native-list", ["--list", "--format", "pretty"])
        if not valid:
            raise ValueError("pinned native inventory failed")
        listing = (output / "native-list.log").read_text()
        names = Counter(line[:-6] for line in listing.splitlines() if line.endswith(": test"))
        bad = {name: names[name] for _, name in SELECTION if names[name] != 1}
        write_json(output / "named-inventory.json", {
            "required": [name for _, name in SELECTION], "bad_matches": bad,
            "all_required_exactly_once": not bad,
        })
        if bad:
            raise ValueError("missing or duplicate exact native names: " + str(bad))
        for label, name in SELECTION:
            valid, execution = run_one(
                label, [name, "--exact", "--show-output", "--test-threads=1",
                        "--format", "pretty"], name)
            code = execution.get("native_exit_code") if execution else None
            actual_passed += int(code == 0)
            actual_failed += int(code is not None and code != 0)
            matched += int(valid)
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        phase_error = str(exc)
    expected = matched == 7 and actual_passed == 2 and actual_failed == 5 and phase_error is None
    # A correctly reproduced negative batch really has failed native tests.
    # Its nonzero command/source receipt is retained independently of the
    # experiment's separate expectation assessment.
    batch_code = 1 if actual_failed or phase_error is not None or matched != 7 else 0
    write_json(output / "batch-summary.json", {
        "negative_control_expectations_met": expected,
        "component_validation_passed": False,
        "native_tests_passed": actual_passed, "native_tests_failed": actual_failed,
        "expected_outcomes_matched": matched, "named_tests_required": 7,
        "native_batch_exit_code": batch_code, "phase_error": phase_error,
        "executable": executable, "executable_sha256": artifact["executable_sha256"],
        "artifact_sha256": artifact_pin, "runner_sha256": runner_pin,
        "positive_source": artifact["positive_source"], "negative_source": artifact["source"],
        "original_business_budgets_changed": False,
        "retained_pnq2_roster_executed_in_full": False,
        "whole_chain_quantum_security_qualified": False, "production_activation": False,
    })
    return batch_code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--positive-source", required=True)
    parser.add_argument("--lineage", type=Path, required=True)
    parser.add_argument("--build-barrier", type=Path, required=True)
    parser.add_argument("--build-barrier-timeout", type=int, default=1800)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--build-timeout", type=int, default=3600)
    parser.add_argument("--test-timeout", type=int, default=900)
    args = parser.parse_args()
    root, output, target = (p.resolve() for p in (args.root, args.out, args.target))
    if not all(re.fullmatch("[0-9a-f]{40}", value)
               for value in (args.source, args.positive_source)):
        raise ValueError("full committed negative and positive source SHAs required")
    if min(args.build_timeout, args.test_timeout) <= 0:
        raise ValueError("positive owner wall-time caps required")
    if any(p.is_relative_to(root) for p in (output, target)):
        raise ValueError("output and target must remain outside source")
    if output == target or output.is_relative_to(target) or target.is_relative_to(output):
        raise ValueError("separate output and target directories required")
    if output.exists() or target.exists():
        raise ValueError("fresh output and target paths required")
    if len(SELECTION) != 7 or len({name for _, name in SELECTION}) != 7:
        raise ValueError("focused test selection changed")
    overrides = [key for key, value in os.environ.items()
                 if value and (key.startswith("CARGO_PROFILE_")
                               or key.endswith(("_RUSTFLAGS", "_RUSTC", "_RUSTC_WRAPPER",
                                                "_RUSTC_WORKSPACE_WRAPPER"))
                               or key in ("RUSTFLAGS", "RUSTC", "RUSTC_WRAPPER",
                                          "RUSTC_WORKSPACE_WRAPPER"))]
    if overrides:
        raise ValueError("remove default-profile overrides: " + ", ".join(sorted(overrides)))
    provider_keys = ("OPENSSL_DIR", "OPENSSL_STATIC", "TRNM_PQ_OPENSSL",
                     "TRNM_PQ_OPENSSL_SHA256", "TRNM_PQ_OPENSSL_VERSION",
                     "OPENSSL_CONF", "OPENSSL_MODULES")
    provider = {key: os.environ.get(key) for key in provider_keys}
    if not all(provider.values()):
        raise ValueError("official prepared provider environment is required")
    if (provider["OPENSSL_STATIC"] != "1" or provider["TRNM_PQ_OPENSSL_VERSION"] != "3.5.9"
            or provider["OPENSSL_CONF"] != "/dev/null"
            or not re.fullmatch("[0-9a-f]{64}", provider["TRNM_PQ_OPENSSL_SHA256"])
            or digest(provider["TRNM_PQ_OPENSSL"]) != provider["TRNM_PQ_OPENSSL_SHA256"]):
        raise ValueError("prepared provider environment or CLI digest mismatch")
    lineage_path = args.lineage.resolve(strict=True)
    lineage_pin = digest(lineage_path)
    lineage = verify_lineage(root, args.source, args.positive_source, lineage_path)
    if not args.build_barrier.is_absolute() or ".." in args.build_barrier.parts:
        raise ValueError("absolute canonical negative release path required")
    release_path = args.build_barrier.resolve()
    if release_path.is_relative_to(root) or release_path.exists():
        raise ValueError("fresh outside-source negative release path required")
    if args.build_barrier_timeout <= 0:
        raise ValueError("positive negative-release barrier timeout required")
    output.mkdir(parents=True)
    target.mkdir(parents=True)
    commands, owners, batch = (output / p for p in ("commands", "owners", "batch"))
    for directory in (commands, owners, batch):
        directory.mkdir()
    os.environ.update(CARGO_BUILD_JOBS="2", CARGO_INCREMENTAL="0",
                      RUST_TEST_THREADS="1", PYTHONDONTWRITEBYTECODE="1",
                      CARGO_TARGET_DIR=str(target))
    imports(root)
    from ci_observation import run as run_observed
    from verify_ci_source import verify
    from pinned_native_process import descriptor_digest
    runner_pin = digest(Path(__file__).resolve())
    observations = []
    write_json(output / "plan.json", {
        "source": args.source, "positive_source": args.positive_source,
        "source_lineage_sha256": lineage_pin,
        "runner_sha256": runner_pin, "selected_controls": 7,
        "expected_native_passes": 2, "expected_native_assertion_failures": 5,
        "groups": GROUPS, "provider_environment": provider,
        "build_timeout_seconds": args.build_timeout,
        "per_test_timeout_seconds": args.test_timeout, "default_workspace_profiles": True,
        "business_budgets_changed": False, "retained_pnq2_roster_executed_in_full": False,
        "whole_chain_quantum_security_qualified": False,
    })

    def observed(label, command, timeout, record_source):
        argv = command
        if record_source:
            argv = [sys.executable, str(root / "scripts/ci/record_pq_native_command.py"),
                    "--kind", "head", "--candidate", args.source, "--tested", args.source,
                    "--label", label, "--output", str(commands), "--", *command]
        if label == "negative-native-batch":
            # Its native children each have their own original bounded owner.
            # Do not create a second timed process group around those groups:
            # killing only that parent group could strand an active owner.
            # The durable job remains the overall execution/cancellation owner.
            started = time.monotonic_ns()
            outer_log = owners / (label + ".log")
            with outer_log.open("xb") as stream:
                process = subprocess.run(argv, cwd=root, stdout=stream,
                                         stderr=subprocess.STDOUT, check=False)
            owner = {"command": argv, "cwd": str(root), "exit_code": process.returncode,
                     "process_exit_code": process.returncode, "timed_out": False,
                     "elapsed_ns": time.monotonic_ns() - started,
                     "log": outer_log.name, "executed": True,
                     "timeout_scope": "each native invocation; durable job owns whole batch",
                     "owns_process_group": False}
        else:
            owner = run_observed(argv, owners / (label + ".log"), cwd=root, timeout=timeout)
        receipt, error = None, None
        expected_exit = 1 if label == "negative-native-batch" else 0
        try:
            if owner["exit_code"] != expected_exit or owner["timed_out"]:
                raise ValueError("bounded owner command failed or timed out")
            if record_source:
                receipt = json.loads((commands / (label + ".json")).read_text())
                expected_status = "command_failed" if expected_exit else "command_succeeded"
                if (receipt["status"] != expected_status or receipt["exit_code"] != expected_exit
                        or receipt["before"] != receipt["after"]
                        or receipt["before"]["tested_commit"] != args.source):
                    raise ValueError("exact source command receipt failed")
        except (OSError, ValueError, KeyError) as exc:
            error = str(exc)
        row = {"label": label, "owner": owner, "source_recorded": record_source,
               "expected_command_exit_code": expected_exit,
               "native_failures_are_successes": False,
               "source_receipt": str(commands / (label + ".json")) if record_source else None,
               "error": error}
        observations.append(row)
        write_json(output / "observations.json", observations)
        print(json.dumps({"label": label, "exit_code": owner["exit_code"],
                          "timed_out": owner["timed_out"], "error": error}), flush=True)
        return error is None, receipt

    before, passed, phase_error = None, False, None
    batch_result = {}
    try:
        registry = json.loads((root / "config/pon/pq-system-required-tests-v1.json").read_text())
        if (registry["schema"] != "trnm-pq-system-required-tests-v1"
                or registry["expected_meaningful_controls"] != 52
                or len(registry["tests"]) != 52 or len(set(registry["tests"])) != 52
                or registry["whole_chain_quantum_security_qualified"] is not False):
            raise ValueError("original PNQ2 52-control registry changed")
        for label, command in (
            ("preflight", ["bash", "scripts/project-preflight.sh", "--audit"]),
            ("compiler", ["rustc", "+1.95.0", "-Vv"]),
        ):
            ok, _ = observed(label, command, 180, False)
            if not ok:
                raise ValueError(label + " failed")
        cargo = ["cargo", "+1.95.0", "test", "--locked", "--manifest-path",
                 "trillionnium/Cargo.toml", "-p", "trnm-pon-node", "--lib",
                 "--all-features", "--no-run", "--message-format=json"]
        ok, receipt = observed("node-lib-build", cargo, args.build_timeout, True)
        if receipt is not None:
            before = receipt.get("before")
            write_json(output / "source-before.json", before)
        if not ok:
            raise ValueError("source-recorded native build failed")
        artifacts = []
        source_file = root / "trillionnium/crates/trnm-pon-node/src/lib.rs"
        for line in (commands / "node-lib-build.log").read_text().splitlines():
            try:
                value = json.loads(line)
            except ValueError:
                continue
            if (value.get("reason") == "compiler-artifact"
                    and value.get("target", {}).get("kind") == ["lib"]
                    and value.get("profile", {}).get("test") is True
                    and value.get("executable")
                    and Path(value["target"]["src_path"]).resolve() == source_file):
                artifacts.append(value)
        if len(artifacts) != 1:
            raise ValueError("expected exactly one actual Node libtest Cargo artifact")
        artifact = artifacts[0]
        executable = Path(artifact["executable"])
        if (not executable.is_absolute() or ".." in executable.parts
                or not executable.resolve().is_relative_to(target)
                or artifact.get("fresh") is not False
                or not {"pq-native-openssl", "pq-root-v3"}.issubset(artifact["features"])):
            raise ValueError("native artifact is not the fresh all-features target")
        fd = os.open(executable, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
        try:
            executable_sha, info = descriptor_digest(fd)
            if os.pread(fd, 4, 0) != b"\x7fELF":
                raise ValueError("Cargo native test artifact is not ELF")
        finally:
            os.close(fd)
        artifact_path = output / "native-artifact.json"
        write_json(artifact_path, {
            "source": args.source, "positive_source": args.positive_source,
            "source_lineage_sha256": lineage_pin,
            "failure_expectations": lineage["failure_expectations"],
            "executable": str(executable),
            "executable_sha256": executable_sha, "executable_bytes": info.st_size,
            "device": info.st_dev, "inode": info.st_ino, "cargo_artifact": artifact,
            "build_receipt_sha256": digest(commands / "node-lib-build.json"),
            "build_log_sha256": digest(commands / "node-lib-build.log"),
            "runner_sha256": runner_pin,
        })
        artifact_pin = digest(artifact_path)
        await_negative_release(output, release_path, artifact_path, artifact_pin,
                               args.source, args.positive_source, runner_pin,
                               args.build_barrier_timeout)
        command = [sys.executable, str(Path(__file__).resolve()), "_native_batch",
                   str(root), str(artifact_path), artifact_pin, str(batch),
                   runner_pin, str(args.test_timeout)]
        ok, receipt = observed("negative-native-batch", command, None, True)
        if receipt is not None:
            write_json(output / "source-after-batch.json", receipt.get("after"))
        result = json.loads((batch / "batch-summary.json").read_text())
        batch_result = result
        passed = (ok and result["negative_control_expectations_met"] is True
                  and result["native_tests_passed"] == 2
                  and result["native_tests_failed"] == 5
                  and result["expected_outcomes_matched"] == 7
                  and result["native_batch_exit_code"] == 1)
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as exc:
        phase_error = str(exc)
    try:
        final = verify("head", args.source, root=root)
        write_json(output / "source-final.json", final)
        verify_runner(runner_pin)
        if digest(lineage_path) != lineage_pin:
            raise ValueError("negative source lineage changed during observation")
        verify_lineage(root, args.source, args.positive_source, lineage_path)
        passed = passed and before is not None and final == before
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        passed = False
        phase_error = (phase_error + "; " if phase_error else "") + str(exc)
    summary = {
        "source": args.source, "positive_source": args.positive_source,
        "source_lineage_sha256": lineage_pin,
        "negative_control_expectations_met": passed,
        "component_validation_passed": False,
        "native_tests_passed": batch_result.get("native_tests_passed"),
        "native_tests_failed": batch_result.get("native_tests_failed"),
        "phase_error": phase_error, "observations": observations,
        "runner_sha256": runner_pin, "default_workspace_profiles": True,
        "original_business_budgets_changed": False,
        "retained_pnq2_roster_executed_in_full": False,
        "whole_chain_quantum_security_qualified": False, "production_activation": False,
    }
    write_json(output / "summary.json", summary)
    print(json.dumps({"negative_control_expectations_met": passed,
                      "component_validation_passed": False, "output": str(output),
                      "phase_error": phase_error}, sort_keys=True), flush=True)
    return 0 if passed else 1


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "_native_worker":
        raise SystemExit(native_worker(sys.argv[2:]))
    if len(sys.argv) > 1 and sys.argv[1] == "_native_batch":
        raise SystemExit(native_batch(sys.argv[2:]))
    raise SystemExit(main())
