#!/usr/bin/env python3
"""Exact-source static checks only; preserves every terminal command receipt."""
from __future__ import annotations
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import traceback

ROOT = Path('/workspace/scratch/1eed767ad985')
REPO = ROOT / 'chain-throughput-base-sync-5689'
OUT = ROOT / 'ci-validation/composed-source-7586d3e2'
HEAD = '7586d3e209b38246402e34cf73a27aa9b907bc9c'
TREE = 'fc0e51b1235470b972de41f2d677f6d5948f4868'
HELPER = ROOT / 'validation/run_exact_selected_controls.py'
HELPER_SHA256 = 'a8f8656fe25038fb67939b360b42631b6856dab9bd302365cd53591be2108e55'
RUST_BIN = ROOT / 'rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin'
TESTS = [
 ('ci-contract','test_ci_contract.py'),
 ('source-integrity-negatives','test_ci_source_integrity.py'),
 ('pq-record-command-controls','test_record_pq_native_command.py'),
 ('pq-corpus-controls','test_pq_research_integration.py'),
 ('pq-claim-controls','test_pq_chain_claim_guard.py'),
 ('pq-authority-controls','test_pq_authority_surface_scan.py'),
 ('project-boundary-controls','test_project_boundary.py'),
 ('repository-mutants','test_repository.py'),
 ('six-workpackage-native-rosters','test_six_workpackage_native_rosters.py'),
 ('w1-full-v2-disposition','test_w1_full_v2_disposition.py'),
 ('w1-preparation-strategy-v4','test_pon_w1_preparation_strategy_reader_v4.py'),
]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git',*args],cwd=REPO).decode().strip()

def locks():
    out={}
    for name in ['trillionnium/Cargo.lock','tests/fuzz/Cargo.lock']:
        p=REPO/name
        data=p.read_bytes()
        actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        committed=git('rev-parse',HEAD+':'+name)
        if actual != committed:
            raise ValueError('lockfile does not equal exact committed bytes: '+name)
        out[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob':actual,'matches_committed_source':True}
    return out

if digest(HELPER)!=HELPER_SHA256:
    raise SystemExit('capture helper changed')
spec=importlib.util.spec_from_file_location('capture_helper',HELPER)
helper=importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
OUT.mkdir(parents=True,exist_ok=False)
shutil.copyfile(__file__,OUT/'runner.py')
shutil.copyfile(HELPER,OUT/'capture-helper.py')
env=os.environ.copy()
env.update({
 'PYTHONDONTWRITEBYTECODE':'1',
 'RUSTUP_HOME':str(ROOT/'rustup'),
 'CARGO_HOME':str(ROOT/'cargo'),
 'RUSTUP_TOOLCHAIN':'1.95.0',
 'CARGO_NET_OFFLINE':'true',
 'PATH':str(RUST_BIN)+os.pathsep+env.get('PATH',''),
})
prior_paths=[ROOT/'ci-validation/published-source/summary.json',ROOT/'ci-validation/history-counter-fix-source-1986fa08/summary.json',ROOT/'ci-validation/composed-source-285982d7/summary.json',ROOT/'ci-validation/composed-source-285982d7/summary-corrected.json',ROOT/'ci-validation/composed-source-285982d7/final-summary.json',ROOT/'ci-validation/composed-fuzz-metadata-285982d7-attempt2/summary.json']
prior={str(p):digest(p) for p in prior_paths}
summary={
 'schema':'trnm-composed-source-static-observation-v1',
 'scope':'fresh-head static/source checks and unfiltered locked Cargo metadata; no native build, test, or Clippy',
 'tested_commit':HEAD,'tested_tree':TREE,'checks':{},'metadata':{},
 'prior_results_credited_as_fresh_head':False,'prior_summary_hashes_before':prior,
 'capture_helper_sha256':HELPER_SHA256,'source_before':None,'source_after':None,
 'unittest_cases_observed':0,'all_checks_passed':False,'result':'INCOMPLETE',
}
helper.write_json(OUT/'context.json',{
 'head':HEAD,'tree':TREE,'repo':str(REPO),'runner_sha256':digest(Path(__file__)),
 'helper_sha256':HELPER_SHA256,'test_scripts':[p for _,p in TESTS],
 'environment':{k:env.get(k) for k in ['PYTHONDONTWRITEBYTECODE','RUSTUP_HOME','CARGO_HOME','RUSTUP_TOOLCHAIN','CARGO_NET_OFFLINE','PATH']},
 'cargo_metadata_scope':'No --filter-platform: retains the complete resolved graph and every declared target. Metadata has no --all-targets flag and executes no Rust build/test.',
})

def run(label,argv,unittest=False):
    print('START '+label,flush=True)
    result=helper.run_capture(argv,REPO,env,OUT/label)
    passed=helper.capture_passed(result)
    entry={'execution':result,'passed':passed}
    if unittest:
        log=Path(result['stderr_path']).read_text(errors='replace')
        entry['unittest_summary_stream']='stderr: original framework stream; negative-fixture stdout is retained separately'
        matches=list(re.finditer(r'^Ran (\d+) tests? in ([0-9.]+)s$',log,re.M))
        if len(matches)!=1:
            entry['summary_error']='expected exactly one terminal unittest count'
            entry['passed']=False
        else:
            match=matches[0]
            tail=log[match.end():].strip()
            entry['tests']=int(match[1]);entry['test_elapsed_seconds']=float(match[2]);entry['terminal_summary']=tail
            entry['passed'] = passed and entry['tests']>0 and tail=='OK'
            summary['unittest_cases_observed']+=entry['tests']
    summary['checks'][label]=entry
    print('DONE '+label+' '+json.dumps({'exit':result['native_exit'],'capture_exit':result['log_exit'],'passed':entry['passed'],'tests':entry.get('tests')}),flush=True)
    return entry

try:
    preflight=run('preflight-audit',['bash','scripts/project-preflight.sh','--audit'])
    if not preflight['passed']:
        raise ValueError('preflight audit refused before source tests')
    summary['source_before']=helper.source_checkpoint(REPO,HEAD,OUT,'source-before',env)
    before=summary['source_before']
    if not before['passed'] or before['receipt']['tested_tree']!=TREE:
        raise ValueError('source-before does not match exact committed source')
    summary['locks_before']=locks()
    for label,name in TESTS:
        run(label,[sys.executable,str(REPO/'scripts/ci'/name)],unittest=True)
    for label,script,args in [
        ('pq-source-integration','scripts/ci/check_pq_research_integration.py',[]),
        ('pq-hold','scripts/ci/pq_chain_claim_guard.py',[]),
        ('pq-authority-report','scripts/ci/pq_authority_surface_scan.py',['--summary-only']),
        ('source-inventory','scripts/refresh_distributed_source_inventory.py',['--check']),
        ('repository-and-markdown-links','scripts/ci/check_repository.py',[]),
    ]:
        run(label,[sys.executable,str(REPO/script),*args])
    run('formatter-toolchain',[str(RUST_BIN/'rustc'),'-Vv'])
    run('format',[str(RUST_BIN/'cargo'),'fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'])
    for label,manifest,feature_args in [
        ('cargo-metadata-default','trillionnium/Cargo.toml',[]),
        ('cargo-metadata-all-features','trillionnium/Cargo.toml',['--all-features']),
        ('cargo-metadata-fuzz-all-features','tests/fuzz/Cargo.toml',['--all-features']),
    ]:
        entry=run(label,[str(RUST_BIN/'cargo'),'metadata','--locked','--offline',*feature_args,'--format-version','1','--manifest-path',manifest])
        if entry['passed']:
            data=json.loads(Path(entry['execution']['stdout_path']).read_text())
            packages=data['packages']; members=set(data['workspace_members']); nodes=data['resolve']['nodes']
            targets=[{'package':p['name'],'target':t['name'],'kind':t['kind'],'crate_types':t['crate_types'],'test':t['test'],'doctest':t['doctest'],'required_features':t.get('required-features',[])} for p in packages if p['id'] in members for t in p['targets']]
            graph={'packages':len(packages),'workspace_members':len(members),'resolve_nodes':len(nodes),'platform_filter':None,'all_features':bool(feature_args),'workspace_targets':targets,'raw_metadata_sha256':digest(Path(entry['execution']['stdout_path'])),'native_execution_qualified':False}
            helper.write_json(OUT/(label+'.graph.json'),graph)
            summary['metadata'][label]={'packages':len(packages),'workspace_members':len(members),'resolve_nodes':len(nodes),'workspace_targets':len(targets),'graph_receipt':label+'.graph.json','raw_metadata_sha256':graph['raw_metadata_sha256'],'passed':True}
        else:
            summary['metadata'][label]={'passed':False,'error':'Cargo metadata command or capture did not succeed; no graph inferred'}
    summary['locks_after']=locks()
    summary['lockfiles_unchanged']=summary['locks_before']==summary['locks_after']
except BaseException as error:
    summary['runner_error']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
    print('RUNNER_ERROR '+repr(error),flush=True)
finally:
    try:
        summary['source_after']=helper.source_checkpoint(REPO,HEAD,OUT,'source-after',env)
        summary['source_before_equals_after']=bool(summary['source_before'] and summary['source_before']['passed'] and summary['source_after']['passed'] and summary['source_before']['receipt']==summary['source_after']['receipt'])
    except BaseException as error:
        summary['source_after_error']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
        summary['source_before_equals_after']=False
    summary['prior_summary_hashes_after']={str(p):digest(p) for p in prior_paths}
    summary['prior_summaries_unchanged']=summary['prior_summary_hashes_before']==summary['prior_summary_hashes_after']
    summary['capture_helper_unchanged']=digest(HELPER)==HELPER_SHA256
    summary['all_checks_passed']=bool(summary['checks']) and all(x['passed'] for x in summary['checks'].values())
    summary['result']='PASS' if (summary['all_checks_passed'] and summary['source_before_equals_after'] and summary.get('lockfiles_unchanged') and summary['prior_summaries_unchanged'] and summary['capture_helper_unchanged'] and 'runner_error' not in summary) else 'FAIL'
    summary['finished_utc']=helper.utc_now()
    helper.write_json(OUT/'summary.json',summary)
    paths=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name!='artifacts.sha256')
    (OUT/'artifacts.sha256').write_text(''.join(digest(p)+'  '+p.relative_to(OUT).as_posix()+'\n' for p in paths))
    print(json.dumps({'result':summary['result'],'unittest_cases_observed':summary['unittest_cases_observed'],'source_before_equals_after':summary['source_before_equals_after'],'artifacts':len(paths),'summary':str(OUT/'summary.json')}),flush=True)
    raise SystemExit(0 if summary['result']=='PASS' else 1)
