from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback,re
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=s.parent/'native-final-controls-6';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);env=os.environ.copy();env['CARGO_TARGET_DIR']=str(s.parent/'target');env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];res={'schema':'chain-original-native-final-scope-validation-v1','complete':False,'all_stages_passed':False,'stages':[],'source_diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff'],cwd=s)).hexdigest()}
lock=s/'trillionnium/Cargo.lock';res['lock_sha256_before']=hashlib.sha256(lock.read_bytes()).hexdigest()
names=json.loads((s.parent/'native-registry-5/names.json').read_text())
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args,filter=None):
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=s,env=env,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'command':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};stdout=(out/(name+'.stdout')).read_text(errors='replace')
 if filter:
  row['actual_registered_denominator']=sum(filter in x for x in names)
  row['result_lines']=[x for x in stdout.splitlines() if x.startswith('test result:')]
 res['stages'].append(row);save();print(json.dumps(row),flush=True)
 if rc:
  print(stdout[-16000:],flush=True);print((out/(name+'.stderr')).read_text(errors='replace')[-6000:],flush=True)
 return rc
try:
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 base=['/home/qq/.cargo/bin/cargo','test','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--release','--locked','--offline','--lib']
 for name,filter in [
  ('authenticated-original-complete','store::native_authenticated::'),
  ('native-apply-and-reader-original-complete','account_archive_prototype::native_store::'),
  ('detached-original-complete','store::detached_admission::'),
  ('history-original-complete','ingress::history_import::'),
  ('public-v3-original-complete','ingress::public_v3::')]:
  assert sum(filter in x for x in names)>0
  run(name,base+[filter,'--','--nocapture','--test-threads=1'],filter)
 run('strict-all-target-clippy',['/home/qq/.cargo/bin/cargo','clippy','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--release','--locked','--offline','--all-targets','--','-D','warnings'])
 run('format-check',['/home/qq/.cargo/bin/cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check'])
 run('actual-node-linux-graph',['/home/qq/.cargo/bin/cargo','tree','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--locked','--offline','--target','x86_64-unknown-linux-gnu'])
 run('workspace-linux-metadata-fetch',['/home/qq/.cargo/bin/cargo','metadata','--manifest-path','trillionnium/Cargo.toml','--locked','--filter-platform','x86_64-unknown-linux-gnu','--format-version','1'])
 res['lock_sha256_after']=hashlib.sha256(lock.read_bytes()).hexdigest();assert res['lock_sha256_after']==res['lock_sha256_before']
 run('diff-check',['git','diff','--check'])
 res['all_stages_passed']=all(x['exit_code']==0 for x in res['stages']);res['complete']=True;save();print(json.dumps(res,indent=2),flush=True)
except BaseException as e:
 res['error']=repr(e);save();(out/'error.log').write_text(traceback.format_exc());raise
