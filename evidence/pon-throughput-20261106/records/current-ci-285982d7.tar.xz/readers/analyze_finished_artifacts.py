#!/usr/bin/env python3
"""Derive bounded notes from already downloaded original CI artifacts."""
import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HEAD = '285982d78a4f62a064841cb0f106d18c865e19c5'
TREE = 'ce074eb1857a92c9b47ea317b841777fcfc63c04'


def source_matches(value):
    return isinstance(value, dict) and value.get('candidate') == HEAD and value.get('tested_tree') == TREE and value.get('tracked_worktree_verified') is True


def json_lines(text):
    for line in text.splitlines():
        if '{' in line:
            try:
                value, _ = json.JSONDecoder().raw_decode(line[line.index('{'):])
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                yield value


def analyze(path):
    metadata = json.loads(path.with_suffix('.json').read_text())
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert metadata['digest'] == 'sha256:' + digest
    row = dict(artifact_id=metadata['id'], artifact_name=metadata['name'],
               run_id=metadata['workflow_run']['id'], source_head=HEAD,
               zip_bytes=len(raw), zip_sha256=digest,
               artifact_url=metadata['url'], commands=[], selected_results=[])
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        for name in sorted(names):
            if not name.endswith('.json'):
                continue
            try:
                data = json.loads(archive.read(name))
            except (json.JSONDecodeError, UnicodeError):
                continue
            if not isinstance(data, dict):
                continue
            if data.get('schema') == 'trnm-pq-native-command-v1':
                log = data.get('log_file')
                log_ok = log in names and len(archive.read(log)) == data.get('log_bytes') and hashlib.sha256(archive.read(log)).hexdigest() == data.get('log_sha256')
                row['commands'].append(dict(entry=name, status=data.get('status'),
                    exit_code=data.get('exit_code'), elapsed_ns=data.get('elapsed_ns'),
                    source_kind=data['before']['kind'], tested_commit=data['before']['tested_commit'],
                    tested_tree=data['before']['tested_tree'],
                    source_before_after_verified=source_matches(data.get('before')) and source_matches(data.get('after')),
                    log_sha256_verified=log_ok, log_file=log, log_sha256=data.get('log_sha256')))
            if name == 'differential.json':
                fields = ['schema', 'result', 'scope', 'production_activation',
                          'independent_security_accepted', 'full_tuf_updater_qualified',
                          'fixed_seed_signatures', 'native_verification_cases', 'rust_verification_cases',
                          'categories', 'wycheproof', 'positive_metadata_pairs',
                          'sdk_verifications', 'rust_verifications']
                row['selected_results'].append(dict(entry=name, **{k:data[k] for k in fields if k in data}))
            if name.endswith('.execution.json'):
                row['selected_results'].append(dict(entry=name, data=data))
        for name in ['independent-readback.log', 'cell-current-api-readback.log']:
            if name in names:
                row['selected_results'].append(dict(entry=name, records=list(json_lines(archive.read(name).decode()))))
        if metadata['name'].startswith('original-large-state-'):
            row['source_before'] = json.loads(archive.read('source-before.json'))
            row['source_after'] = json.loads(archive.read('source-after.json'))
            row['source_before_after_verified'] = source_matches(row['source_before']) and source_matches(row['source_after'])
            row['test_exit_table'] = archive.read('test-exits.tsv').decode()
            row['native_cpu_receipts'] = []
            for name in sorted(names):
                if not name.endswith('.log'):
                    continue
                text = archive.read(name).decode()
                summaries = re.findall(r'test result:.*', text)
                if summaries:
                    row['selected_results'].append(dict(entry=name, test_summaries=summaries))
                for data in json_lines(text):
                    if data.get('schema') == 'native-large-parent-schedule-parity-v1':
                        row['native_cpu_receipts'].append(dict(entry=name, data=data))
    return row


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run-id', type=int, action='append', default=[])
args = parser.parse_args()
paths = sorted(ROOT.glob('artifact-*.zip'))
if args.run_id:
    paths = [path for path in paths if json.loads(path.with_suffix('.json').read_text())['workflow_run']['id'] in args.run_id]
rows = [analyze(path) for path in paths]
report = dict(schema='trnm-pr736-retained-artifact-rollup-v1', source_head=HEAD, source_tree=TREE,
              scope='Artifact observations only; a successful subjob is not a completed whole workflow or public throughput qualification.',
              artifacts=rows)
temp = ROOT / 'artifact-rollup-latest.json.tmp'
temp.write_text(json.dumps(report, ensure_ascii=False, indent=2) + chr(10))
temp.replace(ROOT / 'artifact-rollup-latest.json')
print(json.dumps(dict(artifacts=len(rows), commands=sum(len(row['commands']) for row in rows),
    failed_commands=[dict(artifact_id=row['artifact_id'], command=cmd) for row in rows for cmd in row['commands'] if cmd['exit_code'] != 0],
    source_or_log_verification_failures=[dict(artifact_id=row['artifact_id'], command=cmd) for row in rows for cmd in row['commands'] if not cmd['source_before_after_verified'] or not cmd['log_sha256_verified']])))
