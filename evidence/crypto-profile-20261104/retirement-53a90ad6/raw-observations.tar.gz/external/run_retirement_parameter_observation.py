#!/usr/bin/env python3
"""Measure only an already-built binary, preserving raw output and host context."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

OUT = Path('/workspace/scratch/9d99fced0bf1/retirement-validation')
binary = Path(sys.argv[1]).resolve(strict=True)
stdout = OUT / 'parameter-observations.jsonl'
stderr = OUT / 'parameter-observations.stderr'

def file_text(path):
    try:
        return Path(path).read_text()
    except OSError:
        return None

def snapshot():
    return {'utc': datetime.now(timezone.utc).isoformat(),
            'load_average': os.getloadavg(),
            'cpu_stat': file_text('/sys/fs/cgroup/cpu.stat'),
            'memory_current': file_text('/sys/fs/cgroup/memory.current')}

status = file_text('/proc/self/status') or ''
cpuinfo = file_text('/proc/cpuinfo') or ''
meta = {
    'schema': 'trnm-crypto-profile-parameter-observation-v1',
    'binary': {'path': str(binary), 'bytes': binary.stat().st_size,
               'sha256': hashlib.sha256(binary.read_bytes()).hexdigest()},
    'argv': [str(binary), '--samples', '64'],
    'host': {'uname': tuple(os.uname()), 'logical_cpu_count': os.cpu_count(),
             'cpu_model': next((x.split(':', 1)[1].strip() for x in cpuinfo.splitlines()
                                if x.startswith('model name')), None),
             'cpu_allowed': next((x.split(':', 1)[1].strip() for x in status.splitlines()
                                 if x.startswith('Cpus_allowed_list')), None),
             'cpu_max': file_text('/sys/fs/cgroup/cpu.max'),
             'cpuset_effective': file_text('/sys/fs/cgroup/cpuset.cpus.effective'),
             'memory_max': file_text('/sys/fs/cgroup/memory.max'),
             'memory_info': file_text('/proc/meminfo'),
             'shared_load_controlled': False},
    'before': snapshot(), 'exit_code': None,
    'whole_chain_quantum_security_qualified': False,
    'candidate_87_activated': False,
    'production_tail_latency_qualified': False,
}
path = OUT / 'parameter-run.json'
path.write_text(json.dumps(meta, indent=2) + '\n')
start = time.monotonic_ns()
with stdout.open('xb') as output, stderr.open('xb') as errors:
    result = subprocess.run(meta['argv'], stdout=output, stderr=errors)
meta['elapsed_ns'] = time.monotonic_ns() - start
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
meta.update(exit_code=result.returncode, after=snapshot(),
            binary_process_peak_rss_kib=usage.ru_maxrss,
            binary_process_user_seconds=usage.ru_utime,
            binary_process_system_seconds=usage.ru_stime)
for name, file in [('stdout', stdout), ('stderr', stderr)]:
    data = file.read_bytes()
    meta[name] = {'file': file.name, 'bytes': len(data),
                  'sha256': hashlib.sha256(data).hexdigest()}
assert hashlib.sha256(binary.read_bytes()).hexdigest() == meta['binary']['sha256']
path.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps({'exit_code': result.returncode, 'elapsed_ns': meta['elapsed_ns'],
                  'stdout_sha256': meta['stdout']['sha256'],
                  'binary_sha256': meta['binary']['sha256']}), flush=True)
raise SystemExit(result.returncode if result.returncode >= 0 else 128-result.returncode)
