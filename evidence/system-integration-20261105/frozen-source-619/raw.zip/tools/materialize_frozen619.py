#!/usr/bin/env python3
"""Materialize only the already-published frozen Chain commit, using exact blobs."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import tempfile

ROOT = Path('/workspace/scratch/baeed38792e5/chain')
WORK = Path('/workspace/scratch/baeed38792e5/liveness-work/frozen-619-materialization-20261105')
INPUT = Path('/workspace/scratch/baeed38792e5/chain-frozen-materialization-input.json')
CONFIG = Path('/workspace/scratch/baeed38792e5/chain-frozen-code-config.json')
OLD_HEAD = '2a8fee974b41fab6e2c4e662dcce1807fcd19bdd'
OLD_INDEX = 'ba8dba6eec9426381bc7d489103030a955d274a0'
FROZEN = '619c5f80856fb15bb6896d8008df91f58c215229'
FROZEN_TREE = '501607a6f76d4e5fc4e31a79bfdbff00c4bb007f'
INCOMING = 'e0fc4df37bed96050db2a07d91d427829921e5fa'
INCOMING_TREE = '7f1b7af0351d87032950e01858ea767074c0d032'
COVERAGE = ('config/pon/pq-cross-branch-corpus-v1.json',
            'scripts/ci/check_pq_research_integration.py',
            'scripts/ci/test_pq_research_integration.py')
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0',
           GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')


def git(*args, repo=ROOT, data=None, environment=None):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(repo),
                                    '-c', 'remote.origin.promisor=false', *args],
                                   input=data, env=environment or ENV)


def oid(data, kind='blob'):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def identity(data):
    return {'bytes': len(data), 'git_blob': oid(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def save(name, value):
    (WORK / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def disk_space():
    value = os.statvfs(ROOT)
    return {'free_bytes': value.f_bfree * value.f_frsize,
            'unprivileged_available_bytes': value.f_bavail * value.f_frsize,
            'effective_uid': os.geteuid()}


def rows(entries):
    return b''.join(('100644 ' + value + '\t' + path).encode() + b'\0'
                    for path, value in sorted(entries.items()))


def reconstruct(commit):
    # REST normalizes dates to UTC, losing the serialized timezone. Accept a
    # representation only if its full Git object hash equals the published SHA.
    zones = ['-0500', '+0000', '-0000'] + [
        f'{sign}{m // 60:02d}{m % 60:02d}'
        for sign in ('+', '-') for m in range(15, 14 * 60 + 1, 15)]
    def person(value, zone):
        stamp = int(datetime.datetime.fromisoformat(value['date'].replace('Z', '+00:00')).timestamp())
        return f"{value['name']} <{value['email']}> {stamp} {zone}"
    prefix = ('tree ' + commit['tree']['sha'] + '\n' +
              ''.join('parent ' + p['sha'] + '\n' for p in commit['parents']))
    for author_zone in zones:
        for committer_zone in zones:
            header = (prefix + 'author ' + person(commit['author'], author_zone) +
                      '\ncommitter ' + person(commit['committer'], committer_zone) + '\n')
            for extra in ('', 'encoding UTF-8\n'):
                for tail in ('', '\n', '\n\n'):
                    data = (header + extra + '\n' + commit['message'] + tail).encode()
                    if oid(data, 'commit') == commit['sha']:
                        return data, {'author_timezone': author_zone,
                                      'committer_timezone': committer_zone,
                                      'extra_header': extra, 'message_tail': tail}
    raise AssertionError('could not reconstruct exact commit ' + commit['sha'])


def main():
    space = disk_space()
    available = space['free_bytes'] if os.geteuid() == 0 else space['unprivileged_available_bytes']
    assert available > 1024 * 1024 * 1024 + 20 * 1024 * 1024, space
    assert git('rev-parse', 'HEAD').decode().strip() == OLD_HEAD
    assert git('write-tree').decode().strip() == OLD_INDEX
    assert not git('diff', '--name-only')
    inputs = json.loads(INPUT.read_bytes())
    assert inputs['incoming_commit']['sha'] == INCOMING
    assert inputs['incoming_commit']['tree']['sha'] == INCOMING_TREE
    assert inputs['frozen_commit']['sha'] == FROZEN
    assert inputs['frozen_commit']['tree']['sha'] == FROZEN_TREE
    assert inputs['compare']['base_commit']['sha'] == '4e42b620ed1ce306bca6e7d5da3819417aa0f397'
    assert inputs['compare']['merge_base_commit']['sha'] == inputs['compare']['base_commit']['sha']
    changed = {f['filename']: f for f in inputs['compare']['files']}
    found = json.loads((WORK / 'local-object-availability.json').read_text())
    sources = {f['path']: f for f in found['file_sources']}
    assert len(changed) == len(sources) == 28
    files = {}
    materials = []
    for path, change in changed.items():
        assert change['status'] in ('added', 'modified')
        assert sources[path]['sha'] == change['sha'] and sources[path]['repo']
        assert not Path(path).is_absolute() and '..' not in Path(path).parts
        assert (ROOT / path).resolve().is_relative_to(ROOT.resolve())
        assert not (ROOT / path).is_symlink()
        data = git('cat-file', 'blob', change['sha'], repo=Path(sources[path]['repo']))
        assert oid(data) == change['sha']
        files[path] = data
        materials.append({'path': path, **identity(data),
                          'source_repo': sources[path]['repo'],
                          'source_kind': 'exact-local-git-object',
                          'mode': '100644', 'mode_validation': 'full-incoming-tree-hash'})

    coverage = {p: git('show', ':' + p) for p in COVERAGE[1:]}
    coverage[COVERAGE[0]] = CONFIG.read_bytes()
    incoming_corpus = json.loads(files[COVERAGE[0]])
    frozen_corpus = json.loads(coverage[COVERAGE[0]])
    for key in incoming_corpus:
        if key not in ('pinned_blobs', 'required_paths'):
            assert frozen_corpus[key] == incoming_corpus[key], key
    required_added = set(frozen_corpus['required_paths']) - set(incoming_corpus['required_paths'])
    assert required_added == {
        'trillionnium/crates/trnm-pon-node/src/account_archive_prototype/multiproof.rs',
        'trillionnium/crates/trnm-pon-node/src/account_archive_prototype/multiproof_tests.rs',
        'trillionnium/crates/trnm-pon-node/src/store/growth/observation.rs',
    }
    assert set(frozen_corpus['pinned_blobs']) - set(incoming_corpus['pinned_blobs']) == required_added
    assert set(incoming_corpus['required_paths']) <= set(frozen_corpus['required_paths'])
    for path, expected in incoming_corpus['pinned_blobs'].items():
        if path not in COVERAGE[1:]:
            assert frozen_corpus['pinned_blobs'][path] == expected, path
    for path in COVERAGE[1:]:
        assert frozen_corpus['pinned_blobs'][path] == oid(coverage[path])

    guard = json.loads(Path('/workspace/scratch/baeed38792e5/chain-architecture-composition-input.json').read_text())['guard_commit']
    commit_materials = []
    commits = {}
    for name, commit in (('incoming', inputs['incoming_commit']),
                         ('guard', guard), ('frozen', inputs['frozen_commit'])):
        raw, parameters = reconstruct(commit)
        actual_local = git('cat-file', 'commit', commit['sha'],
                           repo=Path('/workspace/scratch/1790ff0f3cc3/chain'))
        assert actual_local == raw
        commits[commit['sha']] = raw
        (WORK / (name + '-commit.raw')).write_bytes(raw)
        commit_materials.append({'name': name, 'git_commit': commit['sha'],
                                'tree': commit['tree']['sha'], 'bytes': len(raw),
                                'sha256': hashlib.sha256(raw).hexdigest(),
                                'exact_hash_verified': True, **parameters})
    save('before.json', {'head': OLD_HEAD, 'index_tree': OLD_INDEX,
                         'input_sha256': hashlib.sha256(INPUT.read_bytes()).hexdigest(),
                         'frozen_config': identity(CONFIG.read_bytes()),
                         'disk_space': disk_space()})
    save('materials.json', {'schema': 'chain-frozen-materials-v1', 'files': materials,
                            'commits': commit_materials,
                            'prior_lookup_incident': 'Initial availability query in a partial clone triggered automatic lazy fetch. A termination was attempted, but the batch eventually returned exit 0. Pre-existing locality of every object and zero network reads are not claimed. All subsequent retrievals use exact local Git blobs with lazy fetch disabled; reconstructed commits also match the local raw objects byte for byte.',
                            'remote_writes': False})

    for data in list(files.values()) + list(coverage.values()):
        assert git('hash-object', '-w', '--stdin', data=data).decode().strip() == oid(data)
    temp_index = WORK / 'tree-verification.index'
    assert not temp_index.exists()
    environment = dict(ENV, GIT_INDEX_FILE=str(temp_index))
    git('read-tree', inputs['compare']['base_commit']['sha'], environment=environment)
    git('update-index', '-z', '--index-info', data=rows({p: oid(d) for p, d in files.items()}), environment=environment)
    rebuilt_incoming = git('write-tree', environment=environment).decode().strip()
    save('incoming-tree-check.json', {'expected': INCOMING_TREE, 'actual': rebuilt_incoming})
    assert rebuilt_incoming == INCOMING_TREE
    git('update-index', '-z', '--index-info', data=rows({p: oid(d) for p, d in coverage.items()}), environment=environment)
    rebuilt_frozen = git('write-tree', environment=environment).decode().strip()
    save('frozen-tree-check.json', {'expected': FROZEN_TREE, 'actual': rebuilt_frozen})
    assert rebuilt_frozen == FROZEN_TREE
    for expected, raw in commits.items():
        assert git('hash-object', '-t', 'commit', '-w', '--stdin', data=raw).decode().strip() == expected

    assert git('rev-parse', 'HEAD').decode().strip() == OLD_HEAD
    assert git('write-tree').decode().strip() == OLD_INDEX
    assert not git('diff', '--name-only')
    final_files = {**files, **coverage}
    for path, data in final_files.items():
        target = ROOT / path
        if target.exists() and target.read_bytes() == data:
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix='.frozen619-', delete=False) as stream:
            pending = Path(stream.name)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        pending.chmod(0o644)
        os.replace(pending, target)
    git('update-index', '-z', '--index-info', data=rows({p: oid(d) for p, d in final_files.items()}))
    assert git('write-tree').decode().strip() == FROZEN_TREE
    assert not git('diff', '--name-only')
    git('update-ref', '-m', 'materialize fixed published 619c5f8 source', 'HEAD', FROZEN, OLD_HEAD)
    assert git('rev-parse', 'HEAD').decode().strip() == FROZEN
    assert not git('status', '--porcelain', '--untracked-files=all', '--ignore-submodules=none')
    temp_index.unlink()
    after = {'schema': 'chain-frozen-materialization-v1', 'commit': FROZEN,
             'tree': FROZEN_TREE, 'incoming_commit': INCOMING,
             'incoming_tree': rebuilt_incoming, 'previous_head': OLD_HEAD,
             'previous_index_tree': OLD_INDEX, 'clean_worktree': True,
             'local_head_updated_with_expected_old': True,
             'changed_input_blobs': len(files), 'input_blob_bytes': sum(map(len, files.values())),
             'frozen_config': identity(CONFIG.read_bytes()),
             'three_coverage_blobs': {p: identity(d) for p, d in coverage.items()},
             'exact_commit_object_verified': True,
             'remote_writes': False, 'later_remote_heads_followed': False,
             'no_cargo': True, 'disk_space': disk_space()}
    save('after.json', after)
    print(json.dumps(after, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
