#!/usr/bin/env python3
"""Record the sole local reader-driver invocation and preserve its outer exit/logs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

STAGE = Path(__file__).resolve().parent
DRIVER = STAGE / "readers-driver-local-recovery-v2.py"
OUT = Path("/workspace/scratch/7f73fe002713/daa-final-validation/four-profile-reader-recovery-v2-launch")
SOURCE = Path("/workspace/scratch/7f73fe002713/chain-daa")


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    return {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def write_new(path, value):
    with path.open("x") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def main():
    OUT.mkdir(mode=0o700, exist_ok=False)
    argv = [sys.executable, "-B", str(DRIVER), "--native-archive-sha256",
            "6c33da56842862608e365acb7c69d72175538556a2a76b74254f7b0357de9c81"]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUNBUFFERED="1")
    row = {"schema": "pon-local-reader-recovery-outer-execution-v2", "argv": argv,
           "cwd": str(SOURCE), "started_utc": utc(), "driver": digest(DRIVER),
           "recorded_environment": {key: env[key] for key in ("PYTHONDONTWRITEBYTECODE", "PYTHONUNBUFFERED")},
           "result": "PENDING", "execution_site": "local managed /workspace runtime"}
    write_new(OUT / "execution.started.json", row)
    start = time.monotonic()
    stdout, stderr = OUT / "stdout.log", OUT / "stderr.log"
    with stdout.open("xb") as out, stderr.open("xb") as err:
        try:
            row["returncode"] = subprocess.run(argv, cwd=SOURCE, env=env, stdout=out, stderr=err,
                                               check=False, timeout=7200).returncode
        except BaseException as error:
            row["returncode"] = None
            row["execution_error"] = repr(error)
    row.update(finished_utc=utc(), elapsed_seconds=time.monotonic() - start,
               stdout=digest(stdout), stderr=digest(stderr),
               result="PASS" if row["returncode"] == 0 else "FAIL")
    write_new(OUT / "execution.json", row)
    print(json.dumps(row), flush=True)
    return 0 if row["returncode"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
