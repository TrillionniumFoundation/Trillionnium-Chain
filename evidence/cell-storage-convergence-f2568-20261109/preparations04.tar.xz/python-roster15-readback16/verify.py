#!/usr/bin/env python3
"""Read existing fix16 evidence only; never execute tests, Cargo, or a model."""
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
ADDED = [
    "test_project_source_compiler_preserves_original_annotation_semantics",
    "test_failed_supervisor_cancels_connector_before_handshake",
    "test_failed_supervisor_cancels_ready_wait_after_sealed_handoff",
]
PREFIX = "test_llm_cell_sealed_worker_v1.SealedHandoffControls."
SOURCE_ROOT = "/home/qq/work/chain-cell-storage-convergence-loader-fix16-preparation"
TEST_PATH = SOURCE_ROOT + "/original-worker-new-controls/test_llm_cell_sealed_worker_v1.py"
PINS = {
    "input/receipt-original.json": "a44a0400d2b3799f65b9aeaa5b1d924798cffbd801d43e7c720e4a4d890198be",
    "input/fixed21.stderr": "5ec966e4559ee5af66f912ea7e327bc43eb71de5e80ff964fc92921a14efd8e2",
    "input/original3-regression.stderr": "ce353302f36c096da1dbd6db27e62c05d0e3d5295523baeafdc8c1043188870c",
    "input/fixed-controls.py": "7da9c70cf7837af07574fcbdc5c22742de0223fbdc4785931566892b25ac570a",
    "input/baseline-controls.py": "7da9c70cf7837af07574fcbdc5c22742de0223fbdc4785931566892b25ac570a",
    "input/fixed-worker.py": "cd9218492db7cb272772cf4dd4379e535fd7e865b42e9f7d670b3cdb40a8acf2",
    "input/baseline-worker.py": "f330b0fd0563c83e584f14c6bbb82fb8601cbd4916b510322adccb94b1e9c94c",
    "parsers/frozen-runner.py": "ea3698f8d89ab0cf49fb68210eb03d73dfec1ddd95948dca5cc8a16856f1adf6",
    "parsers/frozen-ci-guard.py": "6d99da2f530e7f6164f14f7e3f5fdbfece9559d86ce04356d554b221a3445f85",
}

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def file_id(relative):
    raw = (ROOT / relative).read_bytes()
    return {"path": relative, "bytes": len(raw), "sha256": sha(raw)}

def load_parser(relative, name):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def dump(node):
    return ast.dump(node, include_attributes=False)

inputs = json.loads((ROOT / "input-identities.json").read_bytes())
before = {}
for relative, pin in inputs["files"].items():
    row = file_id(relative)
    require(row["bytes"] == pin["bytes"] and row["sha256"] == pin["sha256"],
            "copied input does not match remote read: " + relative)
    if relative in PINS:
        require(row["sha256"] == PINS[relative], "independent frozen pin changed: " + relative)
    before[relative] = row
require((ROOT / "input/fixed21.stdout").read_bytes() == b""
        and (ROOT / "input/original3-regression.stdout").read_bytes() == b"",
        "unexpected stdout ordering")

receipt = json.loads((ROOT / "input/receipt-original.json").read_bytes())
require(receipt["schema"] == "cell-sealed-corrective-python-preparation-v1", "receipt schema changed")
require(receipt["passed"] is False and receipt["fixed21_passed"] is True
        and receipt["original3_target_failures"] is False,
        "original failed controller verdict must be retained")
require(receipt["model_executed"] is False and receipt["native_cargo_executed"] is False,
        "unexpected model/native execution scope")
require(receipt["source_unchanged"] is True and receipt["source_before"] == receipt["source_after"],
        "fixed source changed during recorded execution")
require(receipt["original_project_source_unchanged"] is True
        and receipt["original_project_source_before"] == receipt["original_project_source_after"],
        "original helper source changed")
require(receipt["source_before"]["scripts/llm_cell_sealed_worker_v1.py"]["sha256"] == PINS["input/fixed-worker.py"]
        and receipt["source_before"]["scripts/test_llm_cell_sealed_worker_v1.py"]["sha256"] == PINS["input/fixed-controls.py"],
        "execution receipt does not bind the frozen candidate and tests")
commands = receipt["commands"]
require(len({row["label"] for row in commands}) == len(commands), "duplicate command label")
commands = {row["label"]: row for row in commands}
fixed, old = commands["fixed21"], commands["original3-regression"]
require(type(fixed["exit_code"]) is int and fixed["exit_code"] == 0 and fixed["timed_out"] is False,
        "actual fixed21 did not exit successfully")
require(type(old["exit_code"]) is int and old["exit_code"] == 1 and old["timed_out"] is False,
        "actual baseline did not exit with ordinary unittest failure")
require(fixed["argv"] == ["/usr/bin/python3", "-B", "-m", "unittest", "discover",
        "-s", SOURCE_ROOT + "/scripts", "-p", "test_llm_cell_sealed_worker_v1.py", "-v"]
        and fixed["cwd"] == SOURCE_ROOT, "fixed command or source directory changed")
require(old["argv"] == ["/usr/bin/python3", "-B", "-m", "unittest", "-v"]
        + [PREFIX + name for name in ADDED]
        and old["cwd"] == SOURCE_ROOT + "/original-worker-new-controls",
        "baseline selected another roster or source directory")
for row, stem in ((fixed, "fixed21"), (old, "original3-regression")):
    for stream in ("stdout", "stderr"):
        observed = before["input/" + stem + "." + stream]
        require(row[stream]["path"] == SOURCE_ROOT + "/" + stem + "." + stream
                and row[stream]["bytes"] == observed["bytes"]
                and row[stream]["sha256"] == observed["sha256"],
                "command log identity mismatch")
require(commands["head-before"]["stdout"]["sha256"] == commands["head-after"]["stdout"]["sha256"],
        "canonical head changed")
for name in ("status-before", "status-after"):
    require(commands[name]["exit_code"] == 0 and commands[name]["stdout"]["bytes"] == 0,
            "canonical source was not clean at recorded boundary")

runner = load_parser("parsers/frozen-runner.py", "fix16_frozen_runner")
guard = load_parser("parsers/frozen-ci-guard.py", "fix16_frozen_guard")
fixed_raw = (ROOT / "input/fixed21.stderr").read_text()
parsed = {"runner": runner.exact_sealed_python_execution(fixed_raw),
          "ci_guard": guard.exact_sealed_python_execution(fixed_raw)}
require(parsed["runner"] == parsed["ci_guard"] and parsed["runner"]["passed"] == 21,
        "two frozen positive parsers disagree")
source = (ROOT / "input/fixed-controls.py").read_text()
require(source == (ROOT / "input/baseline-controls.py").read_text(), "baseline tests differ")
source_tree = ast.parse(source)
classes = [node for node in source_tree.body if isinstance(node, ast.ClassDef)
           and node.name == "SealedHandoffControls"]
require(len(classes) == 1, "control class missing")
methods = {node.name: node for node in classes[0].body if isinstance(node, ast.FunctionDef)}
test_names = sorted(name for name in methods if name.startswith("test_"))
require(len(test_names) == 21 and test_names == sorted(parsed["runner"]["test_names"]),
        "actual output does not execute the entire pinned test source")
require(set(ADDED) <= set(test_names), "one added case missing")
require(not any(methods[name].decorator_list for name in test_names), "decorated control requires review")

# Verify the complete original three-test FAIL transcript. Annotation failure
# is an explicit subtest; that known shape is checked rather than counted twice.
original_raw = (ROOT / "input/original3-regression.stderr").read_text()
for parser in (runner, guard):
    try:
        parser.exact_sealed_python_execution(original_raw)
    except (runner.GateError, ValueError):
        pass
    else:
        raise RuntimeError("failed baseline was accepted as the complete positive suite")
prefix = (
    f"{ADDED[0]} ({PREFIX + ADDED[0]}) ... \n"
    f"  {ADDED[0]} ({PREFIX + ADDED[0]}) (explicit_future=False) ... FAIL\n"
    f"{ADDED[1]} ({PREFIX + ADDED[1]}) ... FAIL\n"
    f"{ADDED[2]} ({PREFIX + ADDED[2]}) ... FAIL\n\n"
)
parts = original_raw.split("=" * 70 + "\n")
require(len(parts) == 4 and parts[0] == prefix, "baseline case banners changed")
footer = re.compile(r"\n\n" + "-" * 70 + r"\nRan 3 tests in (\d+(?:\.\d+)?)s\n\nFAILED \(failures=3\)\n$")
match = footer.search(parts[-1])
require(match is not None, "baseline did not report exactly three assertion failures")
baseline_seconds = float(match.group(1))
parts[-1] = parts[-1][:match.start()] + "\n\n"
source_lines = source.splitlines()
failures = []
expected_frames = {
    ADDED[0]: [("test_project_source_compiler_preserves_original_annotation_semantics", 306)],
    ADDED[1]: [("test_failed_supervisor_cancels_connector_before_handshake", 366),
               ("_failed_original_supervisor", 352)],
    ADDED[2]: [("test_failed_supervisor_cancels_ready_wait_after_sealed_handoff", 369),
               ("_failed_original_supervisor", 352)],
}
frame_re = re.compile(r'  File "([^"]+)", line (\d+), in ([a-z0-9_]+)')
for index, name in enumerate(ADDED):
    block = parts[index + 1]
    header = f"FAIL: {name} ({PREFIX + name})"
    if index == 0:
        header += " (explicit_future=False)"
    body_prefix = header + "\n" + "-" * 70 + "\nTraceback (most recent call last):\n"
    require(block.startswith(body_prefix), "wrong FAIL block identity: " + name)
    lines = block[len(body_prefix):].splitlines()
    frames = []
    assertion = None
    at = 0
    while at < len(lines):
        line = lines[at]
        if not line:
            at += 1
            continue
        frame = frame_re.fullmatch(line)
        if frame:
            path, line_number, function = frame.group(1), int(frame.group(2)), frame.group(3)
            require(path == TEST_PATH and 1 <= line_number <= len(source_lines), "foreign traceback source")
            require(at + 1 < len(lines) and lines[at + 1].strip() == source_lines[line_number - 1].strip(),
                    "traceback statement differs from pinned source")
            frames.append((function, line_number))
            at += 2
            if at < len(lines) and re.fullmatch(r" +[~^]+", lines[at]):
                at += 1
            continue
        if line.startswith("AssertionError: "):
            require(assertion is None and all(not tail for tail in lines[at + 1:]),
                    "extra assertion/error output")
            assertion = line.removeprefix("AssertionError: ")
            at = len(lines)
            continue
        raise RuntimeError("unexpected traceback line: " + line)
    require(frames == expected_frames[name] and assertion is not None, "target assertion not reached")
    row = {"test_name": name, "frames": [{"function": fun, "line": line} for fun, line in frames],
           "assertion": assertion, "status": "target-assertion-failure"}
    if index == 0:
        require(assertion in ("'Optional[str]' != str | None", "'Optional[str]' != typing.Optional[str]"),
                "annotation failure was not the inherited-future mismatch")
    else:
        timing = re.fullmatch(
            r"(\d+(?:\.\d+)?) not less than 3\.0 : connector kept waiting after the original failed child was reaped",
            assertion)
        require(timing is not None, "connector failure was not its original three-second timing assertion")
        elapsed = float(timing.group(1))
        require(math.isfinite(elapsed) and elapsed >= 3.0, "invalid observed elapsed time")
        row.update(observed_elapsed_seconds=elapsed, required_elapsed_less_than=3.0)
    failures.append(row)

# Source-level reachability: these direct assertions precede the exact timing
# statement reached in both real baseline tracebacks.
helper = methods["_failed_original_supervisor"]
tries = [node for node in helper.body if isinstance(node, ast.Try)]
require(len(tries) == 1, "supervisor control flow changed")
direct = tries[0].body
timing_source = "self.assertLess(elapsed, 3.0, 'connector kept waiting after the original failed child was reaped')"
timing_node = ast.parse(timing_source).body[0]
timings = [node for node in direct if dump(node) == dump(timing_node)]
require(len(timings) == 1 and timings[0].lineno == 352, "timing threshold or position changed")
required_before = [
    "self.assertTrue(result['connector_complete'])",
    "self.assertEqual(result['observations'], 0)",
    "self.assertTrue(result['failures'])",
    "self.assertEqual(result['supervisor']['outcome'], 'failed')",
    "self.assertEqual(result['supervisor']['exit_code'], 7)",
    "self.assertTrue(result['supervisor']['waited_child_reaped'])",
    "self.assertTrue(result['supervisor']['owned_child_reap_resolved'])",
    "self.assertEqual(worker.read_observation(Path(self.root.name) / 'next-use-observations.json'), [])",
    "self.assertFalse((Path(self.root.name) / 'fd.sock').exists())",
    "self.assertFalse(any(t.name == 'sealed-research-original-requests' and t.is_alive() for t in threading.enumerate()))",
    "self.assertEqual(inputs.deadline, deadline)",
]
premises = []
for expression in required_before:
    expected = ast.parse(expression).body[0]
    matched = [node for node in direct if dump(node) == dump(expected)]
    require(len(matched) == 1 and matched[0].lineno < timings[0].lineno,
            "a child-reap/deadline premise does not precede timing: " + expression)
    premises.append({"line": matched[0].lineno, "assertion": expression})
for name, value in ((ADDED[1], False), (ADDED[2], True)):
    require(len(methods[name].body) == 1
            and dump(methods[name].body[0]) == dump(ast.parse(f"self._failed_original_supervisor({value})").body[0]),
            "supervisor test does not exercise its declared handoff state")

after = {relative: file_id(relative) for relative in before}
require(before == after, "input changed during readback")
result = {
    "schema": "cell-storage-fix16-independent-readback-verification-v1",
    "passed": True,
    "scope": "Independent readback of existing preparation controls and their baseline; not final-commit, native, or model acceptance",
    "test_commands_executed_here": 0, "native_commands_executed_here": 0, "model_commands_executed_here": 0,
    "original_receipt_retained_unchanged": before["input/receipt-original.json"],
    "original_controller_passed": receipt["passed"],
    "original_controller_original3_target_failures": receipt["original3_target_failures"],
    "fixed21": {"recorded_exit_code": fixed["exit_code"], "recorded_timed_out": fixed["timed_out"],
                "both_frozen_parsers": parsed, "source_sha256": PINS["input/fixed-worker.py"],
                "test_sha256": PINS["input/fixed-controls.py"]},
    "original3": {"recorded_exit_code": old["exit_code"], "recorded_timed_out": old["timed_out"],
                  "passed": 0, "assertion_failures": 3, "errors": 0,
                  "reported_seconds": baseline_seconds, "failures": failures,
                  "worker_readback_sha256": PINS["input/baseline-worker.py"],
                  "identical_test_source_sha256": PINS["input/baseline-controls.py"],
                  "child_reap_and_unchanged_deadline_premises_reached_before_timing": premises,
                  "both_positive_suite_parsers_refused_this_failed_log": True},
    "receipt_source_before_equals_after": True,
    "receipt_original_helper_source_before_equals_after": True,
    "baseline_source_identity_scope": "Post-run baseline file readback matches original f330 worker and identical test bytes; original receipt separately records clean unchanged canonical source and fixed/helper before-after maps.",
    "controller_text_predicate_mismatch": {
        "owner_report": "Controller expected typing.Optional[str] and counted the timing marker across traceback source and assertion lines.",
        "actual_annotation_assertion": failures[0]["assertion"],
        "timing_marker_whole_log_occurrences": original_raw.count("connector kept waiting after the original failed child was reaped"),
        "timing_marker_target_assertion_occurrences": sum("connector kept waiting" in row["assertion"] for row in failures),
        "independent_method": "Exact named FAIL blocks, pinned traceback statements, and one terminal AssertionError per case",
        "original_failed_controller_verdict_overwritten": False,
    },
    "inputs_before": before, "inputs_after": after,
    "python_version_recorded_by_original_controller": receipt["python_version"],
}
output = ROOT / "readback-verification.json"
with output.open("x") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps({"passed": True, "fixed21": 21, "original3_target_assertions": 3,
                  "original_controller_passed": False, "receipt": file_id("readback-verification.json")}, sort_keys=True))
