#!/usr/bin/env python3
"""Reproduce the fresh-ledger context gap on the exact pre-fix source.

This reads the pinned Git tree into a temporary directory. It uses complete
scalar W1 proofs and actual partition/evaluation replay, then interrupts at
the Ledger constructor. No ledger succeeds, no payment executes, and no
training or public efficacy is asserted.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
from unittest.mock import patch


SOURCE_COMMIT = "d320b92370cfc64dd2be5408e6a3f7122880443a"
SOURCE_PATH = "formal/pon-nakamoto-v1/experiments/settle_model.py"


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    revision = subprocess.check_output(
        ["git", "-C", str(args.repository), "rev-parse", SOURCE_COMMIT + "^{commit}"],
        text=True,
    ).strip()
    if revision != SOURCE_COMMIT:
        raise RuntimeError("wrong source revision")
    archive = subprocess.check_output([
        "git", "-C", str(args.repository), "archive", "--format=tar", SOURCE_COMMIT,
        "formal/pon-nakamoto-v1", "config/pon",
    ])
    # This replay deliberately selects the scalar development oracle. It must
    # not inherit a native executable or another process-start policy selection.
    selected_environment = (
        "TRNM_NATIVE_WORK", "TRNM_NATIVE_EXECUTOR", "TRNM_NATIVE_SESSION",
        "TRNM_PON_EVALUATION_POLICY",
    )
    for name in selected_environment:
        os.environ.pop(name, None)
    with tempfile.TemporaryDirectory(prefix="settlement-context-red-") as temporary:
        root = Path(temporary)
        with tarfile.open(fileobj=io.BytesIO(archive), mode="r:") as source:
            for member in source.getmembers():
                if not (member.isfile() or member.isdir()):
                    raise RuntimeError("non-file archive member")
                if not (root / member.name).resolve().is_relative_to(root):
                    raise RuntimeError("archive path outside temporary checkout")
            source.extractall(root, filter="data")
        source_raw = (root / SOURCE_PATH).read_bytes()
        source_text = source_raw.decode("utf-8")
        functions = {}
        for node in ast.parse(source_text).body:
            if isinstance(node, ast.FunctionDef) and node.name in ("_read_observation", "run"):
                functions[node.name] = sha256(ast.get_source_segment(source_text, node).encode("utf-8"))
        sys.path.insert(0, str(root / "formal/pon-nakamoto-v1"))
        from contract_wire import H, canonical
        from evaluation_bundle import evaluate_bundle
        from experiments import settle_model as settle
        from test_settlement_inputs import frozen_files, generator_work
        import work_oracle as oracle

        original_files, original_digest = frozen_files()
        a, b, challenge = generator_work(original_files)
        proof = oracle.prove(challenge, a, b)
        results = []
        for name, parent, round_number in (
            ("legal-initial-control", "00" * 32, 1),
            ("foreign-parent-only", "a1" * 32, 1),
            ("later-round-only", "00" * 32, 2),
            ("foreign-parent-and-later-round", "a1" * 32, 7),
        ):
            files = dict(original_files)
            bundle = json.loads(files["evaluation-bundle.json"])
            bundle["parent_release"] = parent
            bundle["round"] = round_number
            raw = canonical(bundle)
            digest = H("evaluation-bundle-v3", raw).hex()
            files["evaluation-bundle.json"] = raw
            report = json.loads(files["report.json"])
            report["evaluation_bundle"] = digest
            for partition in ("evaluation_a", "evaluation_b", "consumer"):
                observed = evaluate_bundle(
                    raw, digest, json.loads(files[partition + ".json"]), partition,
                    calibration_rows=json.loads(files["calibration.json"]),
                )
                record = report["results"][partition]
                record["evaluation_bundle"] = digest
                record["value_claim"] = observed["value_claim"]
                record["whole_gain"] = dict(
                    observed["primary"], score=observed["primary"]["exploratory_score"])
                record["marginal"] = [dict(value, score=value["exploratory_score"])
                                      for value in observed["marginal"]]
                files[partition + "-result.json"] = canonical(record)
            files["report.json"] = canonical(report)
            files["model-work.bin"] = proof
            directory = root / "inputs" / name
            directory.mkdir(parents=True)
            for filename, content in files.items():
                (directory / filename).write_bytes(content)
            snapshot = settle._read_observation(directory, digest)
            if settle._verify_model_work(snapshot, proof) != (a, b):
                raise RuntimeError("work-material mismatch")
            output = root / "outputs" / name
            with patch.object(settle, "Ledger", side_effect=RuntimeError("LEDGER_BOUNDARY_REACHED")) as ledger:
                try:
                    settle.run(directory, output, digest)
                except RuntimeError as error:
                    if str(error) != "LEDGER_BOUNDARY_REACHED":
                        raise
                else:
                    raise RuntimeError("expected constructor interruption")
                if ledger.call_count != 1:
                    raise RuntimeError("unexpected Ledger constructor count")
            results.append({
                "case": name, "bundle_parent_release": parent, "bundle_round": round_number,
                "expected_bundle_digest": digest,
                "input_files_sha256": {filename: sha256(content)
                                       for filename, content in sorted(files.items())},
                "complete_partition_evaluation_replay": "PASS",
                "complete_scalar_w1_model_binding_replay": "PASS",
                "new_ledger_constructor_reached": True,
                "constructor_interrupted": True, "actual_ledger_executed": False,
                "actual_payment_executed": False,
            })
        result = {
            "schema": "pon-settlement-context-red-v1", "source_commit": SOURCE_COMMIT,
            "source_path": SOURCE_PATH, "source_file_sha256": sha256(source_raw),
            "old_function_utf8_sha256": functions,
            "fixture_source_path": "formal/pon-nakamoto-v1/test_settlement_inputs.py",
            "fixture_source_sha256": sha256((root / "formal/pon-nakamoto-v1/test_settlement_inputs.py").read_bytes()),
            "initial_fixture_bundle_digest": original_digest,
            "scalar_work_challenge": challenge.hex(), "scalar_work_proof_sha256": sha256(proof),
            "work_backend": "scalar work_oracle, complete PNW1 proof",
            "excluded_process_environment_selectors": list(selected_environment),
            "cases": results,
            "finding": "The three unsupported contexts reach the initial-ledger constructor despite fully replayed inputs.",
            "supported_initial_context": {"bundle_parent_release": "00" * 32,
                                          "bundle_round": 1,
                                          "ledger_submission_round": 0},
            "scope": "controlled boundary counterexample; no ledger success, payment, training, or efficacy claim",
        }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"source_commit": SOURCE_COMMIT, "cases": len(results),
                      "unsupported_contexts_reaching_constructor": 3,
                      "actual_ledger_executed": False, "result": str(args.out)}, sort_keys=True))


if __name__ == "__main__":
    main()
