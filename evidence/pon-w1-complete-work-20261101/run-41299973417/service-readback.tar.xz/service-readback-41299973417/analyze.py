#!/usr/bin/env python3
"""Read-only, source-pinned failure analysis of run 41299973417 service captures.

No native execution, work verification, timing authentication, or acceptance is
claimed. Failed outcomes stay failed; the original validator is not patched.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import struct
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SOURCE = HERE / 'source'
sys.path.insert(0, str(SOURCE / 'scripts/ci'))
import run_w1_fresh_service_v1 as runner
import run_from_zero_native as native

RUN = 41299973417
HEAD = '7c5caf5bce1396976808a0f504c4163fbc1aed44'
MERGE = 'c2d5f9ad0ed9402a919e4c87be3825f9aa91837d'
ARTIFACTS = [('13080962608', 'head', HEAD), ('13081315308', 'prospective-merge', MERGE)]
WINDOW = 4_000_000_000
Q = (1 << 32) - 5
ALL_CHECKS = 0


def check(value, label):
    global ALL_CHECKS
    ALL_CHECKS += 1
    if not value:
        raise AssertionError(label)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    return native.json_load(path.read_bytes())


def failure(call):
    try:
        result = call()
    except (ValueError, KeyError, TypeError, OSError) as exc:
        return {'outcome': 'rejected', 'type': type(exc).__name__, 'failure': str(exc)}
    return {'outcome': 'accepted', 'result': result}


def count_strings(values):
    return dict(sorted(Counter(str(x) for x in values).items()))


def compact_call(row):
    keys = ('packet_index', 'height', 'status', 'error', 'started_ns', 'ended_ns',
            'elapsed_wall_ns', 'client_thread_cpu_ns', 'deadline_ms',
            'returned_after_deadline', 'returned_after_window', 'metrics')
    result = {key: row[key] for key in keys if key in row}
    response = row.get('response')
    if isinstance(response, dict):
        value = response.get('value')
        if isinstance(value, dict):
            result['response_scalars'] = {k: v for k, v in value.items() if not isinstance(v, (dict, list))}
            if 'packets' in value:
                result['response_packet_sha256'] = [digest(bytes.fromhex(x)) for x in value['packets']]
                result['response_packet_count'] = len(value['packets'])
    return result


def database(path, packets, genesis):
    connection = sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True)
    check(connection.execute('PRAGMA integrity_check').fetchall() == [('ok',)], 'SQLITE_INTEGRITY')
    active = connection.execute('SELECT b.height, a.tip, a.generation, a.state_slot, b.chainwork, b.state_root FROM active a JOIN blocks b ON a.tip=b.id').fetchone()
    blocks = connection.execute('SELECT height,id,packet,parent FROM blocks ORDER BY height').fetchall()
    check(active is not None and blocks, 'SQLITE_ACTIVE_AND_BLOCKS')
    for height, block, packet, parent in blocks:
        if height == 0:
            check(block.hex() == genesis and packet is None, 'SQLITE_GENESIS')
        else:
            check(1 <= height <= len(packets) and packet.hex() == packets[height - 1], 'SQLITE_ONLY_EXACT_HONEST_PACKETS')
            header, _, block_id = native.ConfirmationReportChecks.packet_metadata(packet.hex())
            check(block_id == block and header['parent'] == parent, 'SQLITE_PACKET_ID')
    reorg = [dict(zip(('generation', 'old_slot', 'outcome', 'cancelled_cursor', 'reason'), row))
             for row in connection.execute('SELECT generation,old_slot,outcome,cancelled_cursor,reason FROM reorg_lifecycle_v1')]
    metadata = {name: {'bytes': len(raw), 'sha256': digest(raw), 'hex': raw.hex()}
                for name, raw in connection.execute("SELECT key,value FROM metadata WHERE key LIKE '%epoch%' OR key LIKE '%cpu%'")}
    slots = {slot: [(key, raw.hex()) for key, raw in connection.execute('SELECT key,value FROM kv WHERE slot=? ORDER BY key', (slot,))]
             for slot, in connection.execute('SELECT DISTINCT slot FROM kv')}
    active_state = slots.get(active[3], [])
    connection.close()
    return {'sha256': digest(path.read_bytes()), 'active_height': active[0], 'active_tip': active[1].hex(),
            'generation': active[2], 'state_slot': active[3], 'active_chainwork': active[4].hex(),
            'active_state_root': active[5].hex(), 'active_state_rows': len(active_state),
            'active_state_rows_sha256': digest(json.dumps(active_state, separators=(',', ':')).encode()),
            'stored_heights': [row[0] for row in blocks], 'stored_max_height': max(row[0] for row in blocks),
            'reorg_lifecycle': reorg, 'resource_epoch_metadata': metadata,
            'all_stored_non_genesis_packets_equal_expected_honest_prefix': True}


def construction(con, context):
    header_bytes = bytes.fromhex(con['header'])
    header = native.header_decode(header_bytes)
    challenge = native.H('challenge', header_bytes)
    check(con['challenge'] == challenge.hex(), 'CONSTRUCTION_CHALLENGE')
    for key in ('target', 'work_task', 'network', 'parameters'):
        check(header[key].hex() == context['task' if key == 'work_task' else key], 'CONSTRUCTION_CONTEXT')
    check(header['parent'].hex() == context['genesis'] and header['height'] == 1, 'CONSTRUCTION_PARENT')
    check(con['attempt_budget'] == 4096 and con['setup_calls'] == 1, 'CONSTRUCTION_BUDGET')
    attempts = con['attempts']
    check(0 < len(attempts) <= 4096, 'TRIAL_COUNT')
    for i, trial in enumerate(attempts):
        trace = native.H('public-v3-from-zero-v1', challenge, struct.pack('<Q', i))
        ticket = native.H('ticket', challenge, trace)
        hit = ticket <= bytes.fromhex(context['target'])
        check(trial == {'nonce': i, 'trace': trace.hex(), 'ticket': ticket.hex(), 'target_hit': hit}, 'EXACT_TRIAL')
        check(not hit or i + 1 == len(attempts), 'FIRST_TICKET_HIT')
    hit = attempts[-1]['target_hit']
    check(con['status'] == ('target_hit_unverified' if hit else 'exhausted'), 'CONSTRUCTION_OUTCOME')
    check(con['winner_nonce'] == (len(attempts) - 1 if hit else None), 'CONSTRUCTION_WINNER')
    nested = sum(con[k] for k in ('setup_cpu_ns', 'search_cpu_ns', 'packet_encoding_cpu_ns'))
    check(nested <= con['attacker_cpu_ns'], 'CONSTRUCTION_CPU_CONTAINMENT')
    a = b''.join(struct.pack('<I', i % 31) for i in range(4096))
    b = b''.join(struct.pack('<I', (i * 7) % 37) for i in range(4096))
    check(native.H('task', a, b).hex() == context['task'], 'MAINTENANCE_TASK')
    packet = header_bytes + bytes(2) + b'PNW1' + a + b + bytes(16384) + bytes.fromhex(attempts[-1]['trace']) if hit else None
    if 'packet' in con:
        check(con['packet'] == (packet.hex() if hit else None), 'EXACT_ORIGINAL_CONSTRUCTION')
    else:
        check(con['packet_digest'] == (native.H('fresh-challenge-attack-packet-v1', packet).hex() if hit else None), 'EXACT_FRESH_CONSTRUCTION')
    return header, packet, len(attempts), challenge.hex()


def phase_report(phase, doc, mode, dbroot, metadata, constructions):
    check(phase['requested_window_ns'] == WINDOW and phase['workers'] in (0, 16), 'ORIGINAL_PHASE_BUDGET')
    pressured = phase['workers'] == 16
    packets = doc['signed_honest_packets']
    calls = []
    construction_count = 0
    attempts = 0
    challenges = set()
    packet_indices = set()
    nested_cpu = 0
    worker_summary = []
    for worker_index, worker in enumerate(phase['attacks']):
        check(worker['worker'] == worker_index and worker['attempt_cap_reached'] is False and len(worker['calls']) < 1024, 'WORKER_BOUNDS')
        prior = 0
        worker_construction_cpu = 0
        worker_call_cpu = 0
        for ordinal, row in enumerate(worker['calls']):
            if mode == 'fresh':
                con = row['from_zero_construction']
                header, packet, tried, challenge = construction(con, doc)
                index = ordinal * 16 + worker_index
                check(row['packet_index'] == index and header['nonce'] == 200_000 + index, 'FRESH_INDEX_NONCE')
                check(index not in packet_indices and challenge not in challenges, 'FRESH_UNIQUE')
                packet_indices.add(index)
                challenges.add(challenge)
                construction_count += 1
                attempts += tried
                worker_construction_cpu += con['attacker_cpu_ns']
            else:
                check(row['packet_index'] == worker_index, 'REPEATED_INDEX')
                _, packet, _, challenge = constructions[worker_index]
                challenges.add(challenge)
                packet_indices.add(worker_index)
            if row['status'] == 'not_submitted_exhausted':
                check(packet is None, 'EXHAUSTION_RETAINED')
                continue
            native.ConfirmationReportChecks.call(row, WINDOW)
            native.ConfirmationReportChecks.compact_request(row, {'op': 'submit', 'packet': packet.hex()}, row['packet_index'])
            check(prior <= row['started_ns'] and row['status'] != 'ok', 'NO_ATTACK_ACCEPTED')
            prior = row['ended_ns']
            worker_call_cpu += row['client_thread_cpu_ns']
            calls.append(row)
        check(worker_construction_cpu + worker_call_cpu <= worker['calling_thread_cpu_ns'], 'WORKER_CPU_CONTAINMENT')
        nested_cpu += worker_construction_cpu
        worker_summary.append({'worker': worker_index, 'calls': len(worker['calls']), 'calling_thread_cpu_ns': worker['calling_thread_cpu_ns'], 'nested_construction_cpu_ns': worker_construction_cpu, 'nested_client_call_cpu_ns': worker_call_cpu})
    check(sum(w['calling_thread_cpu_ns'] for w in phase['attacks']) == phase['attacker_workers_cpu_ns'], 'ATTACKER_CPU_SUM')
    submits = phase['honest_submissions']
    acknowledged = []
    prior = phase['business_started_ns']
    for row in submits:
        ontime = native.ConfirmationReportChecks.call(row, WINDOW)
        index = row['packet_index']
        check(row['height'] == index + 1 and prior <= row['started_ns'], 'SUBMIT_CHRONOLOGY')
        native.ConfirmationReportChecks.compact_request(row, {'op': 'submit', 'packet': packets[index]}, index)
        if ontime:
            acknowledged.append(index + 1)
        prior = row['ended_ns']
    check(acknowledged == list(range(1, 8)), 'ALL_SEVEN_ACTUAL_ACKS')
    history = phase['honest_history']
    fetched = []
    after = doc['genesis']
    tip = metadata[-1][2].hex()
    for row in history:
        ontime = native.ConfirmationReportChecks.call(row, WINDOW)
        check(prior <= row['started_ns'], 'HISTORY_CHRONOLOGY')
        check(row['request'] == {'op': 'history', 'tip': tip, 'after': after}, 'HISTORY_REQUEST')
        prior = row['ended_ns']
        if ontime:
            page = row['response']['value']
            chunk = page['packets']
            check(page['after'] == after and page['tip'] == tip and chunk, 'HISTORY_PAGE')
            check(chunk == packets[len(fetched):len(fetched) + len(chunk)], 'HISTORY_EXACT_PREFIX')
            fetched.extend(chunk)
            after = native.ConfirmationReportChecks.packet_metadata(chunk[-1])[2].hex()
            check(page['next'] == after and page['complete'] is (after == tip), 'HISTORY_CURSOR')
    successful_heads = []
    for row in phase['honest_heads']:
        ontime = native.ConfirmationReportChecks.call(row, WINDOW)
        native.ConfirmationReportChecks.compact_request(row, {'op': 'head'}, None)
        if ontime:
            successful_heads.append(row)
    check(len(successful_heads) == phase['honest_head_successes_in_window'], 'READ_SUCCESS_COUNT')
    metrics = phase['service']['metrics']
    check(phase['service']['error'] is None, 'NO_SERVICE_PROCESS_ERROR')
    check(metrics['work_started'] == metrics['work_finished'], 'WORK_CLOSED')
    check(metrics['mutation_cpu_charged_ns'] == metrics['mutation_full_work_cpu_ns'] + metrics['mutation_dispatch_excluding_work_cpu_ns'], 'CPU_DISJOINT_SUM')
    check(metrics['mutation_cpu_clock_failures'] == 0 and metrics['mutation_cpu_in_flight_after_shutdown'] == 0, 'CPU_ACCOUNTING_CLOSED')
    observed = phase['observations']
    native.observer_cpu_scope(observed)
    records = observed['records']
    check(observed['accepted_connections_seen'] == len(records) == metrics['accepted_connections'], 'ALL_CONNECTIONS_RETAINED')
    check(observed['records_not_retained'] == observed['measurement_failures'] == 0 and observed['counter_overflow'] is False, 'OBSERVATION_COVERAGE')
    check(all(r['complete'] and not r['observation_failed'] for r in records), 'RECORDS_COMPLETE')
    check(sum(r['full_work_started'] for r in records) == metrics['work_started'], 'OBSERVED_WORK_COUNT')
    check(sum(r['full_work_started'] and r['full_work_accepted'] is False for r in records) == metrics['work_failed'], 'OBSERVED_FAILURE_COUNT')
    check(sum(r['full_work_thread_cpu_ns'] or 0 for r in records) == metrics['mutation_full_work_cpu_ns'], 'OBSERVED_WORK_CPU')
    grouped = defaultdict(lambda: {'records': 0, 'work_started': 0, 'work_cpu_ns': 0, 'dispatch_cpu_ns': 0, 'submit_phase_cpu_ns': Counter(), 'submit_phase_wall_ns': Counter()})
    for record in records:
        group = 'accepted-complete-work' if record['full_work_accepted'] is True else 'failed-or-cancelled-work' if record['full_work_started'] else 'no-full-work'
        item = grouped[group]
        item['records'] += 1
        item['work_started'] += int(record['full_work_started'])
        item['work_cpu_ns'] += record['full_work_thread_cpu_ns'] or 0
        item['dispatch_cpu_ns'] += record['dispatch_thread_cpu_ns'] or 0
        for point in record['submit_phases']:
            item['submit_phase_cpu_ns'][point['phase']] += point['thread_cpu_ns'] or 0
            item['submit_phase_wall_ns'][point['phase']] += point['wall_ns'] or 0
    receiver = database(dbroot / 'receiver/native.sqlite', packets, doc['genesis'])
    independent = database(dbroot / 'independent-client/native.sqlite', packets, doc['genesis'])
    check(receiver['active_height'] == 7, 'RECEIVER_TRUE_SEVEN_BLOCKS')
    equal = receiver['active_tip'] == independent['active_tip'] and receiver['active_state_rows_sha256'] == independent['active_state_rows_sha256']
    check(equal is phase['full_native_state_equal'], 'FULL_STATE_EQUALITY_READBACK')
    if pressured:
        check(phase['client_confirmed_transactions'] == 0 and phase['independent_client_confirmation'] is None and phase['finite_business_target_met'] is False, 'ACTUAL_PRESSURE_UNCONFIRMED')
    else:
        confirmed = phase['independent_client_confirmation']
        check(phase['client_confirmed_transactions'] == 1 and confirmed['confirmed'] and confirmed['depth'] == 6 and not confirmed['finalized'] and not confirmed['execution_authority'], 'ACTUAL_BASELINE_CONFIRMATION')
        check(phase['confirmation_ended_ns'] < WINDOW and independent['active_height'] == 7, 'BASELINE_IN_WINDOW')
    coverage = {'unique_challenges': len(challenges), 'unique_packet_indices': len(packet_indices), 'constructed_in_workers': construction_count, 'trial_count_in_workers': attempts, 'nested_construction_cpu_ns': nested_cpu}
    if mode == 'fresh' and pressured:
        c = doc['construction_coverage']
        check(c['constructed'] == c['submitted'] == len(calls) == construction_count and c['exhausted'] == 0, 'FRESH_COVERAGE_COUNTS')
        check(c['unique_challenges'] == len(challenges) and c['unique_packet_indices'] == len(packet_indices), 'FRESH_UNIQUE_COUNTS')
        check(c['nested_from_zero_construction_cpu_ns'] == nested_cpu, 'FRESH_NESTED_CPU')
        check(doc['attacker_setup_and_workers_cpu_ns'] == doc['shared_material_setup_cpu_ns'] + phase['attacker_workers_cpu_ns'], 'FRESH_TOTAL_CPU')
    replay_start = history[0]['started_ns'] if history else None
    intercall_spans = [history[i + 1]['started_ns'] - row['ended_ns'] for i, row in enumerate(history[:-1])]
    return {
        'mode': phase['mode'], 'requested_window_ns': WINDOW, 'workers': phase['workers'],
        'business_started_ns': phase['business_started_ns'],
        'client_confirmation_latency_ns': phase['client_confirmation_latency_ns'],
        'acknowledged_honest_heights': acknowledged, 'last_ack_ended_ns': submits[-1]['ended_ns'],
        'baseline_or_pressure_business_target_met': phase['finite_business_target_met'],
        'invariant_target_met': phase['invariant_target_met'], 'no_attack_accepted': phase['no_attack_accepted'],
        'confirmation': phase['independent_client_confirmation'], 'confirmation_ended_ns': phase['confirmation_ended_ns'],
        'client_confirmed_transactions': phase['client_confirmed_transactions'], 'verification_errors': phase['verification_errors'],
        'business_failure_path': ('native-public-history-import-deadline' if phase['verification_errors'] == ['PUBLIC_REQUEST_DEADLINE'] else 'public-history-network-error-before-import' if pressured and history and history[-1]['status'] == 'error' else 'other-unconfirmed-path' if pressured else None),
        'honest_submissions': [compact_call(x) for x in submits], 'honest_history': [compact_call(x) for x in history],
        'history_fetched_packet_count': len(fetched), 'history_fetched_prefix_after': after,
        'independent_replay_and_confirmation_cpu_ns': phase['independent_replay_and_confirmation_cpu_ns'],
        'independent_replay_and_confirmation_wall_ns': phase['independent_replay_and_confirmation_wall_ns'],
        'inter_history_call_span_ns': intercall_spans,
        'inter_history_call_scope': 'Includes native import plus local loop/JSON processing; not an isolated native replay timing.',
        'honest_head_requests': len(phase['honest_heads']), 'honest_head_successes_in_window': len(successful_heads),
        'maximum_honest_head_gap_ns': phase['maximum_honest_head_gap_ns'], 'reader_cpu_ns': phase['reader_cpu_ns'],
        'attack_calls': len(calls), 'attack_call_statuses': count_strings(row['status'] for row in calls),
        'attack_client_errors': count_strings(row['error'] for row in calls if row['error'] is not None),
        'attack_remote_refusals': count_strings(row['response']['value']['error'] for row in calls if row['status'] == 'refused'),
        'attack_returns_after_window': sum(row['returned_after_window'] for row in calls),
        'attacker_workers_cpu_ns': phase['attacker_workers_cpu_ns'], 'worker_measurements': worker_summary,
        'construction_coverage_recomputed': coverage,
        'initial_meter': phase['initial_meter'], 'final_meter': phase['final_meter'],
        'receiver_service_metrics': metrics, 'receiver_observation_group_totals': dict(grouped),
        'observation_scope': {key: value for key, value in observed.items() if key != 'records'},
        'receiver_sqlite': receiver, 'independent_client_sqlite': independent,
        'full_native_state_equal_readback': equal,
        'service_cpu_depletion_demonstrated': metrics['mutation_cpu_refusals'] > 0,
        'per_phase_host_cgroup_cpu_available': False,
    }


def work_check_counts(packets):
    result = []
    for packet in packets:
        header = bytes.fromhex(packet)[:318]
        challenge = native.H('challenge', header)
        noise = []
        for label in range(4):
            values = 0
            counter = 0
            while values < 512:
                values += sum(x < Q for x in struct.unpack('<8I', native.H('noise', challenge, bytes([label]), struct.pack('<I', counter))))
                counter += 1
            noise.append(counter)
        points = 3 + sum(noise) + 328 + 512
        sparse = 3 + sum((n + 31) // 32 for n in noise) + 11 + 8
        result.append({'challenge': challenge.hex(), 'noise_callbacks_by_label': noise,
                       'all_w1_callbacks': points, 'additional_sparse_host_checks': sparse,
                       'minimum_physical_host_checks_inside_complete_w1_callback_path': points + sparse,
                       'minimum_file_content_reads_at_seven_per_host_check': (points + sparse) * 7})
    return result


def artifact(aid, lane, commit):
    base = ROOT / 'ci-captures' / f'run-{RUN}' / aid
    capture = base / 'fresh-service'
    manifest = read_json(capture / 'manifest.json')
    before = read_json(base / 'source-before.json')
    after = read_json(base / 'source-after.json')
    check(before == after and before['tested_commit'] == commit and before['tracked_worktree_verified'], 'SOURCE_IDENTITY')
    check(before['tested_tree'] == 'fef6125b338e5697896c0a32d0488458d8d93244', 'SOURCE_TREE')
    check(manifest['source_expected'] == commit and manifest['source_before'] == manifest['source_after'], 'NESTED_SOURCE_IDENTITY')
    check(manifest['source_before']['commit'] == commit and manifest['source_before']['tree'] == before['tested_tree'], 'NESTED_COMMIT_AND_TREE')
    check(manifest['source_before']['test_sha256'] == digest((SOURCE / 'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero.rs').read_bytes()), 'PINNED_NATIVE_TEST_SOURCE')
    inventory = []
    for p in sorted(base.rglob('*')):
        if not p.is_file():
            continue
        raw = p.read_bytes()
        rel = str(p.relative_to(base))
        check(not p.is_symlink(), 'NO_SYMLINK_ARTIFACT')
        item = {'path': rel, 'bytes': len(raw), 'sha256': digest(raw)}
        if p.suffix == '.log' or p.name in ('stdout', 'stderr'):
            text = raw.decode()
            item['text_lines'] = len(text.splitlines())
            item['outcome_lines'] = [line[:2000] for line in text.splitlines() if re.search(r'(^Ran |^OK$|test result:|panicked|finite_target_met|^FAILED$|Main processes terminated|CPU time consumed|Service runtime|"reason":"build-finished")', line)]
        inventory.append(item)
    for path, sha in manifest['files'].items():
        check(digest((capture / path).read_bytes()) == sha, 'MANIFEST_MEMBER_SHA')
    check(manifest['binary_sha256_before'] == manifest['binary_sha256_after'] == digest((capture / 'public_v3_from_zero').read_bytes()), 'BINARY_IDENTITY')
    check(manifest['build']['exit_code'] == 0 and not manifest['build']['timed_out'], 'ACTUAL_BUILD_SUCCESS')
    check(manifest['passed'] is False and manifest['execution_finished'] is True, 'GENUINE_FAILED_SERVICE_RESULT')
    host_before = read_json(base / 'fresh-service-host/inside-before.json')
    host_after = read_json(base / 'fresh-service-host/inside-after.json')
    check(host_before['limits'] == host_after['limits'] == {'cpu.max': '25000 100000', 'cpu.max.burst': '0', 'memory.max': '2147483648', 'memory.swap.max': '0', 'pids.max': '256'}, 'UNCHANGED_HOST_BUDGET')
    check(host_before['boot_id'] == host_after['boot_id'] and host_before['parent'] == host_after['parent'], 'HOST_CONTEXT_STABLE')
    host_child = read_json(base / 'fresh-service-host/child-result.json')
    host_controller = read_json(base / 'fresh-service-host/controller-result.json')
    check(not host_child['host_errors'] and not host_controller['final_host_errors'] and host_controller['failure'] is None, 'NO_HOST_PROVISION_FAILURE')
    stats = [{k: int(v) for k, v in (line.split() for line in host['counters']['cpu.stat'].splitlines())} for host in (host_before, host_after)]
    host_delta = {key: stats[1][key] - value for key, value in stats[0].items()}
    cases = []
    all_packets = None
    for index, mode in enumerate(('original', 'fresh')):
        run = manifest['runs'][index]
        path = capture / mode / 'report.json'
        doc = read_json(path)
        log = capture / (mode + '.log')
        validation = failure(lambda: runner.validate_execution(run['process'], log, run['name'], path))
        check(validation.get('failure') == run['failure'], 'EXACT_ORIGINAL_READER_REJECTION')
        direct_validation = failure(lambda: native.validate_confirmation_report(path) if index == 0 else runner.validate_fresh_report(path))
        check(run['process']['executed'] is True and not run['process']['timed_out'] and run['process']['source_verified'] is True, 'NATIVE_ACTUALLY_EXECUTED')
        check(run['process']['process_exit_code'] == (0 if index == 0 else 101), 'NATIVE_EXPECTED_EXIT')
        check(digest(log.read_bytes()) == run['log_sha256'], 'NAMED_LOG_SHA')
        packets = doc['signed_honest_packets']
        if all_packets is None:
            all_packets = packets
        check(all_packets == packets, 'SAME_HONEST_PACKETS_ACROSS_MODES')
        metadata = [native.ConfirmationReportChecks.packet_metadata(packet) for packet in packets]
        parent = bytes.fromhex(doc['genesis'])
        for height, (header, transactions, block) in enumerate(metadata, 1):
            check(header['parent'] == parent and header['height'] == height and len(transactions) == (1 if height == 1 else 0), 'HONEST_LINKED_CHAIN')
            check(all(header[key].hex() == doc[key] for key in ('network', 'parameters', 'target')) and header['work_task'].hex() == doc['task'], 'HONEST_CHAIN_CONTEXT')
            parent = block
        check(doc['finite_target_met'] is False, 'FAILED_BUSINESS_TARGET_RETAINED')
        constructions = [construction(c, doc) for c in doc['from_zero_construction']] if index == 0 else []
        phases = [phase_report(phase, doc, mode, capture / mode / ('baseline' if i == 0 else 'pressure'), metadata, constructions) for i, phase in enumerate(doc['phases'])]
        if index == 0:
            attacker_total = doc['attacker_construction_cpu_ns'] + phases[1]['attacker_workers_cpu_ns']
        else:
            attacker_total = doc['attacker_setup_and_workers_cpu_ns']
        cases.append({'mode': mode, 'schema': doc['schema'], 'raw_report_sha256': digest(path.read_bytes()),
                      'raw_report_bytes': path.stat().st_size, 'manifest_native_run': run,
                      'source_pinned_execution_readback': validation, 'direct_report_readback': direct_validation,
                      'report_context': {k: doc[k] for k in ('network', 'parameters', 'genesis', 'target', 'task', 'policy_id')},
                      'legal_packet_sha256': [digest(bytes.fromhex(x)) for x in packets],
                      'honest_chain_acquisition_wall_ns': doc['honest_chain_acquisition_wall_ns'],
                      'honest_chain_process_cpu_ns': doc['honest_chain_process_cpu_ns'],
                      'attacker_inclusive_setup_and_workers_cpu_ns': attacker_total,
                      'attacker_cost_scope': 'Shared from-zero setup plus disjoint joined worker CPU; fresh per-call construction is already nested in worker CPU and is not added twice.',
                      'phases': phases})
    return {'artifact_id': aid, 'lane': lane, 'source_before': before, 'source_after': after,
            'binary_sha256': manifest['binary_sha256_before'], 'manifest_sha256': digest((capture / 'manifest.json').read_bytes()),
            'receipt_failures': manifest['failures'], 'manifest_member_hashes_verified': len(manifest['files']),
            'entire_artifact_files_read': inventory, 'entire_artifact_bytes_read': sum(x['bytes'] for x in inventory),
            'host_limits': host_before['limits'], 'host_cpu_stat_delta': host_delta,
            'host_context': {key: host_before[key] for key in ('boot_id', 'parent', 'thread_cgroup', 'thread_privileges', 'installed_unit_sha256')},
            'host_whole_wrapper_wall_ns': round((datetime.fromisoformat(host_after['observed_utc']) - datetime.fromisoformat(host_before['observed_utc'])).total_seconds() * 1e9),
            'host_cpu_scope': 'Fixed ancestor includes controller, report/build recheck and all test receiver, attacker, reader and independent-client threads. This is not a per-phase or receiver-only measurement.',
            'host_allocation_or_authentication_error': False, 'native_rejected_business_target': True,
            'cases': cases, 'honest_w1_callback_count_source_inference': work_check_counts(all_packets)}


def main():
    import zipfile
    import subprocess
    metadata_path = ROOT / 'ci-monitor/run-41299973417-initial-artifacts.json'
    artifact_metadata = {str(a['id']): a for a in read_json(metadata_path)['artifacts']}
    integrity = []
    for aid, _, _ in ARTIFACTS:
        expected = artifact_metadata[aid]
        path = ROOT / 'ci-downloads' / f'run-{RUN}-artifact-{aid}.zip'
        raw = path.read_bytes()
        check(digest(raw) == expected['digest'].split(':')[1] and len(raw) == expected['size_in_bytes'], 'GITHUB_ARCHIVE_IDENTITY')
        with zipfile.ZipFile(path) as archive:
            check(archive.testzip() is None, 'ARCHIVE_CRC')
            names = archive.namelist()
            check(len(names) == len(set(names)), 'UNIQUE_ARCHIVE_MEMBERS')
            member_bytes = 0
            for item in archive.infolist():
                if item.is_dir():
                    continue
                member = ROOT / 'ci-captures' / f'run-{RUN}' / aid / item.filename
                check(member.resolve().is_relative_to((ROOT / 'ci-captures' / f'run-{RUN}' / aid).resolve()), 'MEMBER_PATH')
                data = archive.read(item)
                check(member.read_bytes() == data, 'EXTRACTED_MEMBER_EXACT')
                member_bytes += len(data)
        integrity.append({'artifact_id': aid, 'zip_sha256': digest(raw), 'zip_bytes': len(raw),
                          'github_digest_and_size_match': True, 'zip_crc_checked': True,
                          'zip_members': len(names), 'uncompressed_member_bytes': member_bytes,
                          'extracted_files_byte_equal_to_zip': True})
    artifacts = [artifact(*row) for row in ARTIFACTS]
    check(artifacts[0]['binary_sha256'] == artifacts[1]['binary_sha256'], 'IDENTICAL_SERVICE_BINARIES')
    work_source = (SOURCE / 'trillionnium/crates/trnm-crypto-primitives/src/pon_work.rs').read_text()
    default_body = work_source.split('pub fn verify_with_progress<E>', 1)[1].split('pub fn verify_transposed(', 1)[0]
    check('VerificationKernel::FullLimb' in default_body and 'VerificationKernel::Transposed' not in default_body, 'ACTUAL_SOURCE_DEFAULT_FULL_LIMB')
    previous = read_json(ROOT / 'service-readback-41298626837/service-failure-report.json')
    check(all(a['binary_sha256'] == artifacts[0]['binary_sha256'] for a in previous['artifacts']), 'BIT_IDENTICAL_TO_PREVIOUS_SERVICE_BINARY')
    changed_files = subprocess.check_output(['git', 'diff', '--name-only', previous['immutable_reader_source'], HEAD], cwd=ROOT / 'chain-work', text=True).splitlines()
    check(changed_files == ['.github/workflows/pon-recent-batch-acceptance.yml', '.github/workflows/pon-w1-work-security.yml'], 'ONLY_TWO_CI_WORKFLOWS_CHANGED')
    observations = []
    for artifact_row in artifacts:
        for case in artifact_row['cases']:
            for phase in case['phases']:
                observations.append({'lane': artifact_row['lane'], 'case': case['mode'], 'phase': phase['mode'],
                    'ack_count': len(phase['acknowledged_honest_heights']),
                    'client_confirmed_transactions': phase['client_confirmed_transactions'],
                    'client_confirmation_latency_ns': phase['client_confirmation_latency_ns'],
                    'last_ack_ended_ns': phase['last_ack_ended_ns'],
                    'attack_calls': phase['attack_calls'],
                    'transcript_refusals': phase['attack_remote_refusals'].get('WORK:Transcript', 0),
                    'attack_remote_refusals': phase['attack_remote_refusals'],
                    'history_fetched_packet_count': phase['history_fetched_packet_count'],
                    'independent_stored_max_height': phase['independent_client_sqlite']['stored_max_height'],
                    'independent_active_height': phase['independent_client_sqlite']['active_height'],
                    'receiver_active_height': phase['receiver_sqlite']['active_height'],
                    'verification_errors': phase['verification_errors'],
                    'no_attack_accepted': phase['no_attack_accepted'],
                    'mutation_cpu_refusals': phase['receiver_service_metrics']['mutation_cpu_refusals'],
                    'mutation_cpu_clock_failures': phase['receiver_service_metrics']['mutation_cpu_clock_failures'],
                    'receiver_mutation_cpu_charged_ns': phase['receiver_service_metrics']['mutation_cpu_charged_ns'],
                    'receiver_full_work_cpu_ns': phase['receiver_service_metrics']['mutation_full_work_cpu_ns'],
                    'independent_replay_and_confirmation_cpu_ns': phase['independent_replay_and_confirmation_cpu_ns'],
                    'independent_replay_and_confirmation_wall_ns': phase['independent_replay_and_confirmation_wall_ns'],
                    'attacker_workers_cpu_ns': phase['attacker_workers_cpu_ns']})
    pressure = [row for row in observations if row['phase'] == 'from-zero-pressure']
    baseline = [row for row in observations if row['phase'] == 'attack-free-baseline']
    report = {
        'schema': 'pon-w1-service-independent-failure-readback-v1', 'run_id': RUN,
        'immutable_reader_source': HEAD, 'original_budgets_changed': False,
        'source_or_test_files_modified': False, 'native_reexecution_performed': False,
        'default_verifier_kernel': 'FullLimb', 'work_relation_reverified': False,
        'clock_or_artifact_origin_authenticated': False,
        'source_snapshots': {str(p.relative_to(SOURCE)): digest(p.read_bytes()) for p in sorted(SOURCE.rglob('*')) if p.is_file()},
        'source_change_since_previous_run': {'previous_commit': previous['immutable_reader_source'], 'changed_files': changed_files,
            'native_binary_byte_identical': True, 'native_binary_sha256': artifacts[0]['binary_sha256'],
            'reader_source_identity': read_json(HERE / 'reader-source-identity.json')},
        'artifact_integrity': integrity, 'validation_assertions_passed': ALL_CHECKS,
        'artifacts': artifacts, 'compact_observations': observations,
        'findings': [
            {'id': 'CURRENT_OBSERVATIONS', 'confidence': 'current raw reports, exact source reader and retained SQLite',
             'pressure_cases': len(pressure), 'pressure_cases_with_zero_confirmations': sum(r['client_confirmed_transactions'] == 0 for r in pressure),
             'pressure_cases_with_seven_acks': sum(r['ack_count'] == 7 for r in pressure),
             'baseline_cases_confirmed': sum(r['client_confirmed_transactions'] == 1 for r in baseline),
             'finding': 'Counts are recomputed from this run. ACK, stored height, active height and confirmation are retained separately.'},
            {'id': 'CURRENT_FAILURE_PATHS', 'confidence': 'current raw history calls and retained independent SQLite',
             'paths': [{'lane': r['lane'], 'case': r['case'], 'errors': r['verification_errors'],
                        'fetched': r['history_fetched_packet_count'], 'stored_height': r['independent_stored_max_height'],
                        'active_height': r['independent_active_height']} for r in pressure],
             'finding': 'All four current pressure cases have a native public History import deadline. No previous network-stage exception is carried into this result.'},
            {'id': 'NATIVE_EXECUTION_VERSUS_READER_ACCEPTANCE', 'confidence': 'current process receipts and unchanged source-pinned validators',
             'finding': 'Original diagnostics actually exit zero under their safety/accounting invariant scope, then the strict report reader rejects CONFIRMATION_TARGET. Fresh tests actually execute and exit 101 at the explicit business target assert; FRESH_NATIVE_PROCESS_REQUIRED is the wrapper exit guard, not absent native execution.'},
            {'id': 'SAME_BINARY_NEW_CI_SOURCE', 'confidence': 'Git source delta plus hashes of both current and previous retained native binaries',
             'finding': 'This commit changes only two CI workflows. Both current service lanes retain the exact same native binary as the previous FullLimb run. Source SHA changed while the service executable bytes did not.'},
            {'id': 'NO_FALSE_ACCEPTANCE', 'confidence': 'current attack calls, full receiver observation and retained SQLite',
             'finding': 'All observed attacker calls are rejected or fail; all stored non-genesis packets in the inspected databases are exact honest packets. This finite observation is not a general soundness proof.'},
            {'id': 'CPU_AND_HOST_SCOPE', 'confidence': 'current Host receipts and nested per-thread accounting',
             'finding': 'Each wrapper retains the unchanged common 0.25 CPU/2 GiB/pids256 Host, with all receiver, attacker, independent client, reader and controller work sharing that resource domain. Whole-wrapper cgroup counters are neither per-phase nor receiver-only. Mutation-budget refusals and clock failures remain explicit observations, independent of OS throttling.'},
            {'id': 'NO_SERVICE_CAUSALITY_CLAIM', 'confidence': 'no paired randomized same-Host intervention',
             'finding': 'Current and previous service binaries are byte-identical. Timing differences across these hosted runs do not identify an algorithmic improvement or regression; local primitive measurements do not imply the service confirmation target has passed.'},
        ],
        'source_locations': [
            {'path': 'scripts/ci/run_w1_fresh_service_v1.py', 'function': 'validate_execution', 'purpose': 'Fresh native nonzero process guard before report validation.'},
            {'path': 'scripts/ci/run_from_zero_native.py', 'function': 'validate_confirmation_report / validate_confirmation_phases', 'purpose': 'Explicit finite confirmation target independent of diagnostic native exit zero.'},
            {'path': 'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero.rs', 'function': 'signed_confirmation_phase_with_builder', 'purpose': 'Shared original deadline for honest submissions and complete independent History verification.'},
            {'path': 'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero/fresh_challenge.rs', 'function': 'fresh_challenge_signed_confirmation_keeps_original_pressure_budget', 'purpose': 'Explicit four-second business target assertion.'},
            {'path': 'trillionnium/crates/trnm-pon-node/src/ingress/history_import.rs', 'function': 'admit_packet / receive', 'purpose': 'Full native work/state verification and Host controls; complete page activates tip.'},
            {'path': 'trillionnium/crates/trnm-crypto-primitives/src/pon_work.rs', 'function': 'verify_with_progress', 'purpose': 'Actual retained source selects FullLimb.'},
        ],
        'qualification': {'service_target_accepted': False, 'work_hardness_accepted': False,
            'resource_fairness_qualified': False, 'independent_wan_accepted': False, 'production_activation': False},
    }
    out = HERE / 'service-failure-report.json'
    out.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'path': str(out), 'sha256': digest(out.read_bytes()), 'bytes': out.stat().st_size,
                      'checks': ALL_CHECKS, 'artifacts': len(artifacts)}))
    for row in observations:
        print(json.dumps(row, ensure_ascii=False))


if __name__ == '__main__':
    main()

