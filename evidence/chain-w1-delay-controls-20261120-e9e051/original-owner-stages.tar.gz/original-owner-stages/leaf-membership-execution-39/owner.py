from pathlib import Path
import subprocess,json,time,resource,sys,os,hashlib,traceback,shutil
base=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b');src=base/'source';proposal=base/'leaf-membership-proposal-31';out=base/'leaf-membership-execution-39';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);env=os.environ.copy();env['CARGO_TARGET_DIR']=str(base/'target');env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];env['TRNM_LEAF_MEMBERSHIP_COST_OUTPUT']=str(out/'paired-actual-sql.jsonl')
res={'schema':'chain-first-graph-membership-original-comparison-v1','original_head':'e8b0ec93ab6a6a1ff5e36cfcf9d1179e030a5975','commands':[],'complete':False,'business_qualified':False};started=time.monotonic()
def sha(x):return hashlib.sha256(x).hexdigest()
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,argv,cwd):
 start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(argv,cwd=cwd,env=env,stdout=so,stderr=se)
 after=resource.getrusage(resource.RUSAGE_CHILDREN);res['commands'].append({'name':name,'argv':argv,'exit_code':rc,'wall_seconds':time.monotonic()-start,'child_user_cpu_seconds':after.ru_utime-before.ru_utime,'child_system_cpu_seconds':after.ru_stime-before.ru_stime,'stdout_bytes':(out/(name+'.stdout')).stat().st_size,'stdout_sha256':sha((out/(name+'.stdout')).read_bytes()),'stderr_bytes':(out/(name+'.stderr')).stat().st_size,'stderr_sha256':sha((out/(name+'.stderr')).read_bytes())});save();print(json.dumps(res['commands'][-1]),flush=True);return rc
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()==res['original_head']
 assert json.loads((base/'source-link-input-restore-30/RESULT.json').read_text())['complete'] is True
 assert run('preflight',['bash','scripts/project-preflight.sh'],src)==0
 p=src/'trillionnium/crates/trnm-pon-node/src/store/native_authenticated/post_write_readback/frontier_tests.rs'
 assert sha(p.read_bytes())=='2de24487782f50181b8e6a20d979231951e93b9adec94a5082068dd3f44795a9'
 res['continuation_of_original_partial_experiment']='leaf-membership-execution-34'
 res['small_graph_observations_reexecuted']=False
 (out/'complete-source.patch').write_bytes(subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src))
 save()
 rc=0
 if rc==0:rc=run('paired-actual-sql',['/home/qq/.cargo/bin/cargo','test','--release','--locked','-p','trnm-pon-node','--lib','first_full_leaf_membership_paired_actual_sql_cost','--','--ignored','--nocapture','--test-threads=1'],src/'trillionnium')
 if rc==0:rc=run('all-original-post-write',['/home/qq/.cargo/bin/cargo','test','--release','--locked','-p','trnm-pon-node','--lib','store::native_authenticated::post_write_readback','--','--nocapture','--test-threads=1'],src/'trillionnium')
 res.update(complete=True,exit_code=rc,total_wall_seconds=time.monotonic()-started);save();print(json.dumps(res),flush=True);sys.exit(rc)
except BaseException as e:
 if isinstance(e,SystemExit):raise
 res.update(error=repr(e),total_wall_seconds=time.monotonic()-started);save();(out/'error.log').write_text(traceback.format_exc());raise
