# Sequential UNFUNDED experiment harness

This external artifact prepares one research run. It does not add repository
source, alter the frozen A source, reserve funds, invoke a Node owner, or start a
proof when imported or prepared. Only the explicit `run` subcommand dispatches a
native winner and the existing full postwin wrapper. Root is the sole launcher.

## Preparation status

The script parses successfully and its four small pure-data controls pass.
They cover incomplete build qualification / wrong fixed CPU r0vm pin / duplicate
JSON keys; changed bytes / symlinks / output overwrite; and original deadline,
boot identity, and downward conversion to the observer's seconds API; and exact
visible membership quota / memory observations with unknown and mismatched
values rejected. They do
not import the repository observer, run a native winner, run a proof, exercise
signals, or establish performance or deployment qualification.

The clean A qualification manifest has not been consumed by this preparation
artifact. `prepare` requires its actual terminal `qualification_complete: true`,
`repo_path`, `source_commit`, `source_tree`, and all five real binary records.
It rehashes those files and binds the original qualification bytes. Cached build
qualification is not described as an independent cleanroom reconstruction.

## Fixed plan and inputs

The plan is segment workers 1, sequential compression workers 1, and Rayon 8.
The existing postwin wrapper performs ten ABBA repetitions under the same
original deadline. Native search is bounded by 10,000 attempts and by that
deadline. There is no nonce reselection or automatic retry.

The selected files are in the actually observed
`/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/experiment-inputs-01`:

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `material.bin` | 32768 | `6a0400bbe34f342e7fc2f89221884482f5e7ec0743745ed0916053ab97a22ce3` |
| `header-template-search0.bin` | 318 | `7b96038f228a1eedccf7b29ffc54802aba691be7259e33937846c6bf6126d78f` |
| `expected-artifacts.bin` | 64 | `802adcdd951cfb4cd7271df22c3bca6af66fee9f40454c74f8b5ff2c98a1b683` |
| `guest.bin` | 375928 | `25718312ec3c6f5219d832e3516adfb5f82983156f669c5e7daa15bd22d1798f` |

The generation manifest SHA is
`0f2aacaf579f37d9b21bdf5f8e1df5d018b77ff032554d0758a8b16397af3a8d`.
The original header nonce was already zero. This is not a new random starting
point. The real native executable must produce the winner input in a new output
directory; `historical-full-input.bin` is never read by the harness. No historical
receipt is imported. Deterministic output bytes may equal historical bytes;
freshness depends on the retained real process dispatch and new checkpoint, not
on a claim that the resulting digest must be different.

## Exact preparation command

Run only after root has produced the real clean A qualification:

```sh
/usr/bin/python3 -B /home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/sequential-unfunded-harness-01/run_sequential_unfunded.py prepare \
  --qualification /home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/clean-A-build-qualification-01/qualification.json \
  --prepared /home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/sequential-unfunded-prepared-01
```

This writes a new `prepared.json`, the original qualification bytes, and a
`preparation-result.json`. It does not execute either experiment process. The
reported exact `prepared.json` SHA must be supplied to `run`.

## Exact launch contract — root only, not executed here

The caller sets actual CPU affinity to 12–19 and supplies one integer absolute
deadline and its actual local boot ID. Remaining time must be in `(0,7200]`
seconds both on entry and immediately before the first retained intent. The
harness never constructs `now + 7200` as a replacement deadline.

The Hepta job declaration is CPU quota 800% and memory max 8 GiB. Affinity is
checked rather than changed by the harness. Raw observations of the actual
membership cgroup must also show quota / period exactly 8 and memory.max exactly
8589934592; unknown or conflicting observations refuse winner dispatch and
terminal eligibility. Those samples do not prove continuous enforcement or
complete billing. The root caller must set the resources before
executing this argv:

```text
/usr/bin/python3
-B
/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/sequential-unfunded-harness-01/run_sequential_unfunded.py
run
--prepared
/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/sequential-unfunded-prepared-01
--prepared-sha256
<actual preparation-result.json prepared.sha256>
--out
/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery/sequential-unfunded-run-01
--original-deadline-monotonic-ns
<root's once-selected absolute integer deadline>
--original-deadline-boot-id
<actual local /proc/sys/kernel/random/boot_id>
```

The concrete native argv is bound into the run intent:

```text
QUALIFIED_NATIVE_WINNER MATERIAL EXPECTED64 SEARCH0_HEADER NEW_NATIVE_OUT ORIGINAL_DEADLINE_NS ORIGINAL_BOOT_ID 10000
```

The concrete postwin argv is also retained with all real executable hashes:

```text
QUALIFIED_PYTHON scripts/run_w1_postwin_proof.py
  --winner-dir NEW_NATIVE_OUT --out NEW_POSTWIN_OUT
  --runner QUALIFIED_RUNNER --runner-sha256 QUALIFIED_RUNNER_SHA
  --r0vm FIXED_CPU_R0VM --r0vm-sha256 2acdf550f9aca4d05b74072463e4ed307c3824309c754a5cb5f93aa84f3390e6
  --verifier QUALIFIED_VERIFIER --verifier-sha256 QUALIFIED_VERIFIER_SHA
  --segment-workers 1 --compression-mode sequential --compression-workers 1
  --rayon-threads 8 --comparison-repeats 10
```

The wrapper obtains the same original deadline from the retained actual native
winner. It independently replays the statement, invokes the complete staged
backend using a new checkpoint, runs the independent receiver, and performs the
requested comparisons. The harness never substitutes a receipt or success stub.

## Deadline, cancellation and raw evidence boundaries

The outer native/postwin observer has explicit 30-second termination grace.
The actual postwin controller grace is 12 seconds, and inner stages use 5
seconds. These are cleanup allowances: 30 > 12 > 5. None extends proof execution.

Full `verify_ci_source.py --kind head --expected-head ...` observations run before
and after execution. The after check has a separate bounded 60-second **read-only
evidence audit** allowance so its raw result can survive an expired experiment.
No winner, proof, receiver, comparison or retry is dispatched after execution
ends. An original deadline that expires during any final hash, audit, fsync or
print still causes nonzero exit (124 for an expired deadline).

The final `result.json` is explicitly a pre-handoff snapshot. A successful
completion requires its eligibility, the actual harness exit 0, no cancellation
sidecar and the original deadline. A late or canceled operation never rewrites
an already observed proof-verification fact or receiver ACK. The raw controller,
postwin, receiver and outer process observations remain separate files with
their original bytes and SHA identities.

Before and after records include all selected binary/source/input file hashes,
the complete source check output and process logs, cwd, boot, observer PID/PGID,
affinity, namespace identities, and bounded raw `/proc` and cgroup files. Read
errors remain explicit `UNKNOWN` observations.

Process-group/session sampling and `wait4` are not complete process-tree billing.
Aggregate process-tree memory and GPU time remain unknown. The harness does not
infer enforced isolated resource scope merely from a requested Hepta quota or a
visible shared cgroup. Funding, Node admission, complete cryptographic/security
qualification, deployment benefit, complete resource billing and population p99
qualification remain false throughout this UNFUNDED experiment.

The postwin latency field retains the wrapper's existing definition: actual
native ticket hit through parent-clock independent receiver process completion.
Build time before the winner is excluded from that interval. Full harness and
evidence publication timing is separately retained and still subject to the
original operation deadline.
