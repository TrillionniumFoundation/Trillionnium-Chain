#!/usr/bin/env python3
"""Bounded exact-source Chain formatting/graph/strict-Clippy qualification."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

ROOT = Path('/workspace/scratch/56818e4fba76/chain-recovered')
OUT = Path(__file__).resolve().parent / 'chain-source-gates-r8'
OUT.mkdir(exist_ok=False)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
commit = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
prefix = Path('/tmp/pure-pon-openssl-3.5.9')
cli = prefix/'bin/openssl'
env = dict(os.environ, PATH='/tmp/pure-pon-toolchain-20261027/bin:'+os.environ['PATH'],
           CARGO_HOME='/tmp/pure-pon-cargo-20261027',
           CARGO_TARGET_DIR='/tmp/chain-pq-target-56818e4fba76',
           CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_NET_OFFLINE='true',
           OPENSSL_DIR=str(prefix), OPENSSL_STATIC='1', TRNM_PQ_OPENSSL=str(cli),
           TRNM_PQ_OPENSSL_SHA256=hashlib.sha256(cli.read_bytes()).hexdigest(),
           TRNM_PQ_OPENSSL_VERSION='3.5.9', OPENSSL_CONF='/dev/null',
           OPENSSL_MODULES=str(prefix/'lib/ossl-modules'), PYTHONDONTWRITEBYTECODE='1')
commands = [
    ('preflight',['bash','scripts/project-preflight.sh']),
    ('source-before',['python3','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',commit,'--output',str(OUT/'source-before.json')]),
    ('format',['cargo','fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check']),
    ('locked-graph',['cargo','metadata','--manifest-path','trillionnium/Cargo.toml','--locked','--offline','--all-features','--format-version','1']),
    ('strict-clippy',['cargo','clippy','--manifest-path','trillionnium/Cargo.toml','--locked','--offline','--workspace','--all-targets','--all-features','--','-D','warnings']),
    ('source-after',['python3','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',commit,'--output',str(OUT/'source-after.json')]),
]
record = {'schema':'pon-r8-exact-chain-source-gates-v1','commit':commit,
          'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'wall_limit_seconds':600,'minimum_free_bytes':1073741824,
          'commands':[], 'whole_chain_acceptance':False}
(OUT/'intent.json').write_text(json.dumps(dict(record,planned_commands=commands),indent=2)+'\n')
start=time.monotonic()
for label,argv in commands:
    began=time.monotonic()
    with (OUT/(label+'.stdout')).open('wb') as stdout, (OUT/(label+'.stderr')).open('wb') as stderr:
        child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        reason=None
        while True:
            pid,status,usage=os.wait4(child.pid,os.WNOHANG)
            if pid:
                child.returncode=os.waitstatus_to_exitcode(status);break
            if time.monotonic()-start>600 or shutil.disk_usage(OUT).free<1073741824:
                reason='wall-budget' if time.monotonic()-start>600 else 'disk-floor'
                os.killpg(child.pid,signal.SIGKILL)
                _,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status);break
            time.sleep(.25)
    row={'label':label,'argv':argv,'returncode':child.returncode,'wall_seconds':time.monotonic()-began,
         'user_cpu_seconds':usage.ru_utime,'system_cpu_seconds':usage.ru_stime,'max_rss_kib':usage.ru_maxrss,
         'stop_reason':reason,'interrupted_descendant_cpu_complete':False if reason else None}
    record['commands'].append(row)
    (OUT/'running.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if child.returncode:break
record.update(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              wall_seconds=time.monotonic()-start,passed=len(record['commands'])==len(commands) and all(x['returncode']==0 for x in record['commands']))
record['logs']={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
                for p in OUT.iterdir() if p.suffix in ('.stdout','.stderr')}
(OUT/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'commit':commit,'passed':record['passed'],'wall_seconds':record['wall_seconds']}),flush=True)
raise SystemExit(0 if record['passed'] else 1)
