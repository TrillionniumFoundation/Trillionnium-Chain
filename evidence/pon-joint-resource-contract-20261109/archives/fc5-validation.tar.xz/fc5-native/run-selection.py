from pathlib import Path
import json,os,subprocess,sys,time
root=Path('/workspace/scratch/pon-joint-58fd59-build/chain')
out=root.parent/'fc5-native'
tool=Path('/workspace/scratch/5faaca703596/toolchain/rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
env=os.environ.copy();env.update(json.loads((out/'environment.json').read_text())['environment']);env['PATH']=str(tool)+os.pathsep+env['PATH']
head=json.loads((out/'environment.json').read_text())['head']
argv=[str(tool/'cargo'),'test','--release','--locked','--offline','--manifest-path','trillionnium/Cargo.toml','-p','trnm-pon-node','--lib','--test','daa_joint_consensus','--example','pon_w1_cost_matrix_v2','--example','pon_w1_reused_cost_v3','--example','pon_w1_lifecycle_cost_v4','--no-run','--message-format=json']
wrapped=[sys.executable,'scripts/ci/record_pq_native_command.py','--kind','head','--candidate',head,'--tested',head,'--label','native-build','--output',str(out),'--',*argv]
with (out/'launcher.stdout').open('x') as stdout,(out/'launcher.stderr').open('x') as stderr:
 r=subprocess.run(wrapped,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=2400)
print(json.dumps({'build_returncode':r.returncode,'receipt':str(out/'native-build.json')}),flush=True)
raise SystemExit(r.returncode)
