from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time

ROOT = Path('/data/chain-six-d9fb-20261108/source')
TARGET = Path('/data/chain-six-d9fb-20261108/targets/consensus')
TEMP_ROOT = Path('/data/chain-six-d9fb-20261108/tmp-consensus')
TEMP_ROOT.mkdir(parents=True, exist_ok=True)
HEAD = sys.argv[1]
OUT = Path(sys.argv[2])
assert not OUT.resolve().is_relative_to(ROOT.resolve()), 'OUTPUT_MUST_BE_OUTSIDE_SOURCE'
OUT.mkdir(parents=True, exist_ok=False)
CARGO = '/home/qian-qi/.cargo/bin/cargo'
PREFIX = Path('/home/qian-qi/workspace/pon-demand-acceptance-20261107-root525798dad3c2/build-runtime/trnm-pq-provider-3.5.9.DYf2qEaX/install')
PROVIDER = PREFIX / 'bin/openssl'
PROVIDER_SHA = '8ff7dd91270fd4a8fc377031f0fd2f2cee1cd17a32ce30e4fd773a25730a120f'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT, text=True).strip()


def source():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain', '--untracked-files=all')}


initial = source()
assert initial['head'] == HEAD and not initial['status'], initial
assert sha(PROVIDER) == PROVIDER_SHA
assert subprocess.check_output([str(PROVIDER), 'version'], text=True).startswith('OpenSSL 3.5.9')
lock_path = TARGET / '.final-consensus-cell-owner.lock'
lock_fd = os.open(lock_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
os.write(lock_fd, (HEAD + '\n').encode())
os.close(lock_fd)
env = dict(os.environ, TMPDIR=str(TEMP_ROOT),
           CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='2', CARGO_TERM_COLOR='never',
           PYTHONDONTWRITEBYTECODE='1', OPENSSL_DIR=str(PREFIX), OPENSSL_STATIC='1',
           OPENSSL_NO_VENDOR='1', OPENSSL_CONF='/dev/null',
           OPENSSL_MODULES=str(PREFIX / 'lib/ossl-modules'),
           TRNM_PQ_OPENSSL=str(PROVIDER), TRNM_PQ_OPENSSL_VERSION='3.5.9',
           TRNM_PQ_OPENSSL_SHA256=PROVIDER_SHA)
lock_sha = sha(ROOT / 'trillionnium/Cargo.lock')
receipt = {'schema': 'chain-six-final-native-cell-v1', 'source': initial,
           'runner_sha256': sha(Path(__file__).resolve()),
           'provider_sha256': PROVIDER_SHA, 'target_directory': str(TARGET),
           'temporary_directory': str(TEMP_ROOT),
           'cargo_jobs': 2, 'test_threads': 1, 'lock_sha256': lock_sha,
           'checks': [], 'complete': False, 'qualification': 'HOLD_NO_GO'}


def save():
    (OUT / 'checks.json').write_text(json.dumps(receipt, indent=2) + '\n')


def run(name, command, *, timeout=1200, minimum=None, ignored=(),
        python_tests=None, extra_env=None, expected_code=0):
    before = source()
    assert before == initial, 'SOURCE_CHANGED_BEFORE:' + name
    started = time.monotonic()
    log = OUT / (name + '.log')
    error = None
    code = None
    with log.open('xb') as stream:
        try:
            code = subprocess.run(command, cwd=ROOT, env=env | (extra_env or {}), stdout=stream,
                                  stderr=subprocess.STDOUT, timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            error = 'TIMEOUT'
    text = log.read_text(errors='replace')
    after = source()
    summaries = [dict(status=x[0], passed=int(x[1]), failed=int(x[2]),
                      ignored=int(x[3]), measured=int(x[4]), filtered=int(x[5]))
                 for x in re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', text)]
    named = re.findall(r'^test (.*?) \.\.\. (ok|ignored)(?:,|\s|$)', text, re.MULTILINE)
    passed_names = sorted(set(n for n, state in named if state == 'ok'))
    ignored_names = sorted(set(n for n, state in named if state == 'ignored'))
    acceptance = code == expected_code and error is None and before == after == initial
    if minimum is not None:
        acceptance = acceptance and bool(summaries) and summaries[-1]['passed'] >= minimum
        acceptance = acceptance and all(x['status'] == 'ok' and x['failed'] == 0 for x in summaries)
        acceptance = acceptance and ignored_names == sorted(ignored)
        acceptance = acceptance and summaries[-1]['ignored'] == len(ignored)
    python_counts = [int(x) for x in re.findall(r'Ran (\d+) tests?', text)]
    if python_tests is not None:
        acceptance = acceptance and python_counts == [python_tests]
        acceptance = acceptance and re.search(r'^OK$', text, re.MULTILINE) is not None
        acceptance = acceptance and re.search(r'^OK \(', text, re.MULTILINE) is None
    row = {'name': name, 'command': command, 'returncode': code, 'error': error,
           'elapsed_seconds': time.monotonic() - started, 'before': before, 'after': after,
           'source_unchanged': before == after == initial, 'log_sha256': sha(log),
           'summaries': summaries, 'python_tests_run': python_counts,
           'passed_names': passed_names, 'ignored_names': ignored_names,
           'passed': acceptance}
    receipt['checks'].append(row)
    save()
    print(json.dumps({k: v for k, v in row.items() if k not in ('passed_names', 'before', 'after')}), flush=True)
    if not acceptance:
        print(text[-10000:], flush=True)
    assert row['source_unchanged'], 'SOURCE_CHANGED_AFTER:' + name
    return row


def cargo_test(*args, exact=False):
    return [CARGO, '+1.95.0', 'test', '--locked', '--offline', '--manifest-path',
            'trillionnium/Cargo.toml', '-p', 'trnm-pon-node', *args,
            '--', '--test-threads=1', *(['--exact'] if exact else [])]


try:
    assert run('preflight', ['bash', 'scripts/project-preflight.sh', '--audit'])['passed']
    assert run('source-before', ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py',
                                '--kind', 'head', '--expected-head', HEAD,
                                '--output', str(OUT / 'source-before.json')])['passed']
    growth = run('native-growth', cargo_test('--lib', 'store::growth::'), minimum=77,
        ignored=('store::growth::tests::native_growth_v2_signed_cross_65536_bounded_io_zero_nonce_and_reopen',
                 'store::growth::tests::scale_observation::native_growth_v2_fixed_owner_account_history_scale_observation'))
    growth_confirmation = (
        'growth_confirmation_reaches_independent_native_receiver_and_cold_reopen',
        'growth_confirmation_batch_shares_body_and_rejects_missing_or_duplicate_membership',
        'growth_confirmation_cancellation_keeps_native_work_execution_and_snapshot_boundaries',
        'growth_confirmation_rechecks_future_ancestor_even_when_tip_and_old_clock_pass',
        'growth_confirmation_uses_required_work_after_legal_difficulty_decrease',
        'growth_confirmation_tracks_actual_reorg_and_re_adoption_without_rewriting_history',
        'growth_confirmation_replays_included_work_even_with_unchanged_header_and_trace',
        'growth_confirmation_refuses_foreign_wal_commits_hidden_inside_the_read_snapshot',
    )
    growth['required_confirmation_controls'] = list(growth_confirmation)
    growth['passed'] = growth['passed'] and all(any(n.endswith('::' + required) for n in growth['passed_names']) for required in growth_confirmation)
    save()
    run('native-consensus', cargo_test('--lib', 'consensus::tests'), minimum=10)
    run('native-legacy-reorg-root', cargo_test('--lib', 'store::legacy_reorg_root_tests'), minimum=5)
    run('native-reorg-readback', cargo_test('--lib', 'store::reorg_readback_tests'), minimum=6)
    run('native-original-target-confirmation', cargo_test('--lib', 'store::evaluation_observation::tests::confirmation_uses_actual_target_work_not_just_height_difference', exact=True), minimum=1)
    run('native-observed-history', cargo_test('--lib', 'ingress::history_import::tests::observed_history_retains_complete_native_path_and_real_w1_cancellation', exact=True), minimum=1)
    cli = run('packet-observer-cli', cargo_test('--bin', 'trnm-pon-node', 'packet_observer_cli::tests'), minimum=4)
    cli_names = ('actual_scoped_workers_hit_one_absolute_kernel_cpu_ceiling',
                 'wall_timeout_reaps_the_reader_and_private_snapshot',
                 'child_output_cannot_grow_parent_memory_without_a_bound')
    cli['passed'] = cli['passed'] and all(any(n.endswith('::' + required) for n in cli['passed_names']) for required in cli_names)
    cli['required_budget_controls'] = list(cli_names)
    save()
    run('native-packet-observer', cargo_test('--test', 'native_packet_observer'), minimum=10)
    run('accepted-task-observation', cargo_test('--test', 'accepted_task_observation'), minimum=4)
    run('native-node-packet-status', cargo_test('--test', 'native_node', 'packet_status'), minimum=2)
    schedule_out = OUT / 'work-schedule'
    joint_out = OUT / 'joint-daa'
    run('native-work-schedule', cargo_test('--test', 'research_work_schedule'), minimum=12,
        extra_env={'TRNM_WORK_SCHEDULE_RESEARCH_DIR': str(schedule_out)})
    run('native-joint-daa', cargo_test('--test', 'daa_joint_consensus'), minimum=2,
        extra_env={'TRNM_JOINT_DAA_EVIDENCE_DIR': str(joint_out)})
    for backend in ('pnh1-authenticated', 'pgh2-growth'):
        schedule = schedule_out / backend
        joint = joint_out / backend
        schedule_digest = sha(schedule / 'report.json')
        joint_digest = sha(joint / 'joint-daa.json')
        receipt.setdefault('fresh_native_reports', []).append({
            'backend': backend, 'work_schedule_sha256': schedule_digest,
            'joint_daa_sha256': joint_digest, 'current_source': HEAD})
        run('work-schedule-reader-' + backend,
            ['/usr/bin/python3', '-B', 'scripts/pon_branch_work_schedule_reader.py',
             '--raw-dir', str(schedule), '--report-sha256', schedule_digest])
        run('work-schedule-reader-controls-' + backend,
            ['/usr/bin/python3', '-B', 'scripts/ci/test_pon_branch_work_schedule_reader.py',
             '--raw-dir', str(schedule), '--report-sha256', schedule_digest, '-v'], python_tests=9)
        run('joint-daa-reader-' + backend,
            ['/usr/bin/python3', '-B', 'scripts/pon_joint_daa_reader.py',
             '--raw-dir', str(joint), '--expected-report-sha256', joint_digest])
        run('joint-daa-reader-controls-' + backend,
            ['/usr/bin/python3', '-B', 'scripts/ci/test_pon_joint_daa_reader.py',
             '--raw-dir', str(joint), '-v'], python_tests=22)
        assert schedule_digest == sha(schedule / 'report.json')
        assert joint_digest == sha(joint / 'joint-daa.json')
    run('cell-complete-version-vector', ['/usr/bin/python3', '-B', 'scripts/cell_complete_version_vector.py', '--check'])
    cell = run('cell-default-complete-crate',
               [CARGO, '+1.95.0', 'test', '--locked', '--offline', '--manifest-path',
                'trillionnium/Cargo.toml', '-p', 'trnm-data-availability', '--', '--test-threads=1'],
               timeout=1800)
    roster_path = ROOT / 'evidence/cell-six-capabilities-20261108/required-new-tests.json'
    original_roster_source = '0dc13a92cc49e9a751a2b6cf7cc96524f1244a2a'
    original_roster = subprocess.check_output(
        ['git', '--no-replace-objects', 'show', original_roster_source + ':' + str(roster_path.relative_to(ROOT))], cwd=ROOT)
    assert original_roster == roster_path.read_bytes(), 'CELL_ORIGINAL_ROSTER_CHANGED'
    roster = json.loads(roster_path.read_text())
    assert len(roster) == len(set(roster)) == 51
    found = {name: [actual for actual in cell['passed_names']
                    if actual == name or actual.endswith('::' + name)] for name in roster}
    cell['required_new_test_matches'] = found
    cell['required_roster_sha256'] = sha(roster_path)
    cell['original_roster_source'] = original_roster_source
    cell['harness_passed_total'] = sum(row['passed'] for row in cell['summaries'])
    cell['passed'] = (cell['passed'] and bool(cell['summaries']) and all(found.values())
                      and cell['harness_passed_total'] >= 473
                      and not cell['ignored_names']
                      and all(row['status'] == 'ok' and row['failed'] == 0 and row['ignored'] == 0
                              and row['filtered'] == 0 for row in cell['summaries']))
    save()
    frozen_out = OUT / 'work-time-frozen-replay'
    frozen = run('work-time-frozen-replay',
                 ['/usr/bin/python3', '-B', 'scripts/ci/run_work_time_contract_v1.py',
                  '--output-dir', str(frozen_out), '--campaign', '--frozen-baseline-source',
                  '/home/qian-qi/work/chain-six-frozen-baseline-d9fb-20261108'])
    execution = json.loads((frozen_out / 'execution.json').read_text())
    named = json.loads((frozen_out / 'named-controls.json').read_text())
    boundaries = json.loads((frozen_out / 'reference-controls.json').read_text())
    frozen['original_controls'] = named['tests_run']
    frozen['reference_controls'] = boundaries['tests_run']
    frozen['original_current_contract'] = execution['original_current_contract']
    frozen['passed'] = (frozen['passed'] and execution['passed_research_controls']
                        and execution['schema'] == 'pon-work-time-frozen-replay-execution-v1'
                        and execution['head_at_execution'] == HEAD
                        and named['controls_passed'] and named['tests_run'] == 104
                        and boundaries['passed'] and boundaries['tests_run'] == 13
                        and execution['original_current_contract']['matched'] is False
                        and execution['original_current_contract']['error']['message'].startswith('SOURCE_BYTES:')
                        and execution['current_native_cost_qualified'] is False)
    save()
    refusal_out = OUT / 'work-time-original-refusal'
    refusal = run('work-time-original-refusal',
                  ['/usr/bin/python3', '-B', 'scripts/ci/run_work_time_contract_v1.py',
                   '--output-dir', str(refusal_out), '--campaign'], expected_code=1)
    refused = json.loads((refusal_out / 'execution.json').read_text())
    refusal['expected_refusal'] = refused.get('error')
    refusal['passed'] = (refusal['passed'] and not refused['passed_research_controls']
                         and refused.get('error', {}).get('message', '').startswith('SOURCE_BYTES:'))
    save()
    assert run('source-after', ['/usr/bin/python3', '-B', 'scripts/ci/verify_ci_source.py',
                               '--kind', 'head', '--expected-head', HEAD,
                               '--output', str(OUT / 'source-after.json')])['passed']
    receipt['lock_unchanged'] = lock_sha == sha(ROOT / 'trillionnium/Cargo.lock')
    receipt['complete'] = True
    receipt['all_passed'] = receipt['lock_unchanged'] and all(row['passed'] for row in receipt['checks'])
    save()
    print(json.dumps({'complete': True, 'all_passed': receipt['all_passed'], 'head': HEAD,
                      'cell_required_roster_complete': all(found.values())}), flush=True)
    raise SystemExit(0 if receipt['all_passed'] else 1)
finally:
    lock_path.unlink()
