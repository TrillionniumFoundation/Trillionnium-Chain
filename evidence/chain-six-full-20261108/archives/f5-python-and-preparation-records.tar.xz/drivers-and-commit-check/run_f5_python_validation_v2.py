import pathlib,subprocess,json,hashlib,time,re,traceback,os
root=pathlib.Path('/data/chain-six-d9fb-20261108/publish-source')
parent=pathlib.Path('/data/chain-six-d9fb-20261108/evidence/final-integration')
out=parent/'f5-python-validation'
out.mkdir(exist_ok=False)
head='ab610cf95a6ec39b38e20e64e6367f5b529b3633'
tree='abd4442d789b29889960f9b0acc712b9fefed498'
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_NO_LAZY_FETCH':'1','PYTHONUNBUFFERED':'1'}
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root).decode().strip()
previous_raw=(parent/'proof-pq-f4-validation/summary.json').read_bytes()
assert sha(previous_raw)=='54121debfe45e6ab740a08080a9c7a80ba2ad962cf1095b037f11269ae143937'
previous=json.loads(previous_raw)
expected_rosters={x['name']:x['tests']['ids'] for x in previous['commands'] if x.get('tests',{}).get('ids')}
rows=[]
def command(name,argv,roster_name=None,expected_count=None,timeout=1200):
 started=time.monotonic()
 record={'name':name,'argv':argv,'timeout_seconds':timeout,'expected_exit_code':0}
 try:
  p=subprocess.run(argv,cwd=root,env=env,capture_output=True,timeout=timeout)
  (out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr)
  record.update({'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'accepted':p.returncode==0})
  if roster_name:
   assert expected_count==len(expected_rosters[roster_name])
   text=p.stderr.decode()
   matches=re.findall(r'^(test_\S+) \(([^)]+)\) \.\.\. (.*)$',text,re.M)
   expected=sorted(expected_rosters[roster_name])
   ids=[identity for method,identity,status in matches]
   frame=(len(matches)==expected_count and len(set(ids))==expected_count and sorted(ids)==expected and all(status=='ok' and identity.rsplit('.',1)[-1]==method for method,identity,status in matches) and re.findall(r'^Ran ([0-9]+) tests in ',text,re.M)==[str(expected_count)] and re.findall(r'^OK(?: \(.*\))?$',text,re.M)==['OK'])
   record['tests']={'expected':expected_count,'actual_named':len(matches),'distinct':len(set(ids)),'exact_success_roster':frame,'ids':ids}
   record['accepted']=record['accepted'] and frame
 except Exception as e:
  record.update({'accepted':False,'error':repr(e),'traceback':traceback.format_exc()})
 record['elapsed_seconds']=time.monotonic()-started
 record['source_head_after']=git('rev-parse','HEAD')
 record['source_tree_after']=git('rev-parse','HEAD^{tree}')
 record['source_clean_after']=git('status','--porcelain')==''
 record['accepted']=record['accepted'] and record['source_head_after']==head and record['source_tree_after']==tree and record['source_clean_after']
 rows.append(record);(out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps({'name':name,'exit_code':record.get('exit_code'),'accepted':record['accepted'],'seconds':record['elapsed_seconds']}),flush=True)
 return record
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==tree and git('status','--porcelain')==''
command('preflight',['bash','scripts/project-preflight.sh'])
command('source-before',['/usr/bin/python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',head,'--output',str(out/'source-before.json')])
try:
 command('ci-contract-164',['/usr/bin/python3','-B','scripts/ci/test_ci_contract.py','-v'],'ci-contract-164',164)
 command('ci-source-integrity-43',['/usr/bin/python3','-B','scripts/ci/test_ci_source_integrity.py','-v'],'ci-source-integrity-43',43)
 command('repository-50',['/usr/bin/python3','-B','scripts/ci/test_repository.py','-v'],'repository-50',50)
 for name,path,args in [('ci-contract-gate','scripts/ci/check_ci_contract.py',[]),('repository-gate','scripts/ci/check_repository.py',[]),('inventory-gate','scripts/refresh_distributed_source_inventory.py',['--check']),('corpus-gate','scripts/ci/check_pq_research_integration.py',[])]:
  command(name,['/usr/bin/python3','-B',path,*args])
 inputs=parent/'mldsa-readback-proposal/chain-f3-mldsa-readback-proposal-d9fb'
 assert sha((inputs/'replay_reader.py').read_bytes())=='952fa0aec2aa635fb8411fd80698d778c8fc4e2b3430342c029b10bc402c851c'
 command('mldsa-integrated-reader',['/usr/bin/python3','-B',str(inputs/'replay_reader.py'),'--workflow',str(root/'.github/workflows/pon-pq-system-continuation.yml'),'--output',str(out/'mldsa-readback')])
 command('native-learning-517',['/usr/bin/python3','-B','evidence/hepta-real-native-learning-20261108/verify_originals.py'])
 command('diff-check',['git','diff','--check'])
finally:
 command('source-after',['/usr/bin/python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',head,'--output',str(out/'source-after.json')])
equal=(out/'source-before.json').read_bytes()==(out/'source-after.json').read_bytes()
mldsa=json.loads((out/'mldsa-readback/result.json').read_bytes())
assert mldsa['original_refusals_reproduced']==4 and mldsa['actual_original_logs_accepted']==4 and mldsa['negative_controls_rejected']==19
corpus=json.loads((root/'config/pon/pq-cross-branch-corpus-v1.json').read_bytes())
result={'schema':'chain-six-f5-integrated-python-validation-v1','head':head,'tree':tree,'source_before_after_equal':equal,'commands':rows,'all_passed':equal and all(r['accepted'] for r in rows),'named_python_controls':sum(r.get('tests',{}).get('actual_named',0) for r in rows),'corpus_pins':len(corpus['pinned_blobs']),'required_paths':len(corpus['required_paths']),'original_f4_result':'FAIL_RETAINED','mldsa_original_refusals_reproduced':4,'mldsa_original_logs_rechecked':4,'mldsa_mutated_logs_refused':19,'raw_storage_controls_original_verifier_sha256':'1dc97b04d1c38c72a7f4d99a494998fdf8d615584b0e074e212ff6b053fe18de','native_or_model_execution_rerun':False,'new_cryptographic_executions':0,'qualification':'HOLD_NO_GO'}
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'all_passed':result['all_passed'],'head':head,'named_controls':result['named_python_controls'],'summary_sha256':sha((out/'summary.json').read_bytes()),'failed':[r['name'] for r in rows if not r['accepted']]}),flush=True)
raise SystemExit(0 if result['all_passed'] else 1)
