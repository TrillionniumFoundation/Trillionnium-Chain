# M16 Bounded composition proposals and local intelligence

Revision: invariant-driven revision3. Selected target: `pon-nakamoto-v1`.
[Sole development plan](../development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md); [exact invariant registry](../../config/pon/invariants-v2.json).

## Scope and ownership

Bounded local optimization and non-authoritative proposals only.

The claims below apply to their named component and tests, not to an independently accepted full native node.

## PoN State machine

### M16.TrainCompatibleCandidate

Use explicit full-batch softmax recipe,120stepslocal androuter, inverseclassfrequency, boundedquantization; selectroutertargets on calibration only. Emitnewimmutableartifact, never mutate activebundle.

**Atomic/commit boundary:** Training records owned by localproducer; chain receives only parameter/evidenceclaims.

### M16.CompareOrAbstain

The producer must retain all required deployable controls and reject overlapping training/calibration identities; a weaker composition need not be adopted. Train and calibrate before frozen evaluation; emit immutable candidate and reference records.

**Atomic/commit boundary:** Train and calibrate before frozen evaluation; emit immutable candidate and reference records.

## M16.NoForcedAdoption

**Invariant:** The producer must retain all required deployable controls and reject overlapping training/calibration identities; a weaker composition need not be adopted.

**Scope:** Bounded local optimization and non-authoritative proposals only.

**Atomic boundary:** Train and calibrate before frozen evaluation; emit immutable candidate and reference records.

**Failure schedule:** Omit a control; Overlap task identities; Composition loses to selected control.

**Expected result:** The producer must retain all required deployable controls and reject overlapping training/calibration identities; a weaker composition need not be adopted.

**Resource and retention rule:** Finite local optimization, disclosed training budget, no paid provider invocation.

## Concrete regression selectors

`formal/pon-nakamoto-v1/test_evaluation.py::ModelGateTests.test_reference_cannot_silently_omit_a_control`

`formal/pon-nakamoto-v1/test_evaluation.py::ModelGateTests.test_duplicate_task_and_partition_overlap_reject`

These exact functions contain executable assertions. The registry only checks binding; actual outcomes and source/input identities belong to the separate qualification report.

## Module-specific threat and residual work

Reward hacking, self-evaluation, adapting after seeing outcomes and absorbing existing Hepta owners.

Real chronological multi-generation learning and authenticated data withdrawals are not replaced by experimental splits.

## Current source and verification

- [`formal/pon-nakamoto-v1/evaluation.py`](../../formal/pon-nakamoto-v1/evaluation.py).
- [`formal/pon-nakamoto-v1/experiments/model_loop.py`](../../formal/pon-nakamoto-v1/experiments/model_loop.py).

No test binding or local campaign grants independent acceptance, ordinary Hepta execution or production activation. Preserve the exact source, profile and environment of every outcome.

## Executed evidence and scope

[Responsibility-level evidence navigation](README.md#responsibility-and-evidence) reads
measured commits from immutable receipts. The module's entries in
[module-maturity-v1.json](../../config/pon/module-maturity-v1.json) identify actual callable
owners, controlled entrypoints, backends, persistence and exact observed test selectors.
Run `python3 scripts/ci/report_module_evidence.py --module M16` from the repository
root to see subject-byte and complete recorded-runtime matches separately, plus scenarios
not observed in each package. A byte match is not a new test run or product acceptance.
Historical v1/v3/v4 results are never repinned. The sole plan selects further work.

## Frozen evaluation and consent continuation

See [E3](../protocol/pon-nakamoto-v1/details/EVALUATION_BUNDLE.md) for exact bytes,
owner boundaries and failure schedules. No public export or future-window authority
is created by a frozen artifact. The following additional regressions are executable:

- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::FrozenEvaluationTests.test_control_current_must_be_actual_parent`.
- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::FrozenEvaluationTests.test_cross_partition_exact_content_overlap_rejects`.
- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::FrozenEvaluationTests.test_cross_partition_source_group_overlap_rejects`.
- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::FrozenEvaluationTests.test_write_once_plan_survives_readback_and_cannot_be_overwritten`.
- `formal/pon-nakamoto-v1/test_evaluation_bundle.py::StatisticalBoundaryTests.test_caller_future_flag_is_not_observation_or_reward`.

Actual producer/evaluator implementation: `formal/pon-nakamoto-v1/evaluation_bundle.py`;
normal controlled worker and three-attempt caller consume it rather than a parallel trainer.
