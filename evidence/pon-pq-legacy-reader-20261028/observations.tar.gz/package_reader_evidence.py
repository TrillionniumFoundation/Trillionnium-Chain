"""Package the retained reader observations without rewriting their identities."""
from __future__ import annotations
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

BASE=Path('/workspace/scratch/bb9b841c1d43')
RAW=BASE/'pq-reader-evidence'
ROOT=BASE/'pq-reader-closure'
OUT=ROOT/'evidence/pon-pq-legacy-reader-20261028'

def sha(data): return hashlib.sha256(data).hexdigest()
def read(name): return json.loads((RAW/name).read_text())
def write(name,value): (OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

observations=[]
for stem,expected in [('reader-suite-01',False),('reader-repair-targeted-02',True),
                      ('reader-suite-final',True),('source-negatives-final',True),
                      ('evidence-sources-final',True),('ci-contract-composed',False),
                      ('ci-contract-composed-final',True)]:
    report=read(stem+'.json')
    assert report['passed'] is expected and report['source_unchanged']
    log=(RAW/(stem+'.stderr.log')).read_text()
    count=re.search(r'Ran (\d+) tests in ([0-9.]+)s',log)
    observations.append({'stem':stem,'passed':report['passed'],
                         'exit_code':report['exit_code'],'timed_out':report['timed_out'],
                         'budget_seconds':report['timeout_seconds'],
                         'elapsed_ns':report['elapsed_ns'],
                         'tests_run':int(count[1]) if count else None,
                         'unittest_seconds':float(count[2]) if count else None,
                         'source_unchanged_during_run':True})
assert observations[2]['tests_run']==74
assert observations[3]['tests_run']==34
assert observations[4]['tests_run']==38
retention=read('test-selector-retention-final.json')
assert retention['retained']==53 and retention['removed']==[] and retention['current_discovered']==74
files={str(p.relative_to(RAW)):p.read_bytes() for p in sorted(RAW.rglob('*'))
       if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
inventory={'members':{name:{'bytes':len(raw),'sha256':sha(raw)} for name,raw in files.items()},
           'member_count':len(files),'member_bytes':sum(map(len,files.values()))}
write('raw-inventory.json',inventory)
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name,raw in files.items():
        info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0
        archive.addfile(info,io.BytesIO(raw))
plain=buffer.getvalue();compressed=gzip.compress(plain,mtime=0)
(OUT/'observations.tar.gz').write_bytes(compressed)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(compressed)),mode='r:') as archive:
    assert set(archive.getnames())==set(files)
    for name,raw in files.items(): assert archive.extractfile(name).read()==raw
summary={'schema':'pq-legacy-reader-compatibility-observations-v1',
         'scope':'legacy evidence source reader, namespace refusal and retained failure observations',
         'frozen_local_base':'969150c1f1ad1821ee5ac3c11f0535677e9bb8e9',
         'remote_parent':'a1e40747746772d1326bb3e656aec4ba10440147',
         'parent_tree':'f90cd9f63fce5fb785061419c9cb12b57ae24873',
         'original_methods_retained':53,'complete_reader_methods':74,
         'source_integrity_negative_methods':34,'evidence_source_methods':38,
         'failed_initial_reader_subcases_retained':5,
         'original_parser_false_accepts_retained':2,
         'initial_pq_source_refusal_retained':True,
         'observations':observations,'environment':read('environment.json'),
         'reader_helpers':retention['helpers'],
         'source_identity_join':read('source-identity-join.json'),
         'raw_archive':{'path':'observations.tar.gz','sha256':sha(compressed),
                        'bytes':len(compressed),'tar_bytes':len(plain),
                        'members':len(files),'all_members_readback':True},
         'runtime_source_changed':False,
         'local_git_inherited_objects_complete':False,
         'missing_inherited_blob':'7f4d96ac57a7907f68f186f302da8082b215bd4e',
         'inherited_object_references_preserved':True,
         'new_recent_batch_workflow_executed':False,
         'full_evidence_package_qualified':False,
         'full_workspace_qualified':False,'p1_complete':False,
         'public_network_ready':False,'production_activation':False}
write('summary.json',summary)
print(json.dumps({'observations':observations,'archive':summary['raw_archive']},indent=2))
