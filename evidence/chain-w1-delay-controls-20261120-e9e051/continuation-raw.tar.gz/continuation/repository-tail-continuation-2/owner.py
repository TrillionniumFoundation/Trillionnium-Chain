from pathlib import Path
import os,sys,json,time,resource,subprocess,hashlib,traceback
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/resume-20261120-e9e051/source');out=src.parent/'repository-tail-continuation-2';out.mkdir(exist_ok=False)
(out/'owner.py').write_text(sys.argv[1]);res={'schema':'chain-original-repository-input-continuation-v1','complete':False,'commands':[],'source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'runtime_source_unchanged':True,'f0_repeated':False}
env=os.environ.copy();env['PATH']='/home/qq/.cargo/bin:'+env['PATH'];env['RUST_TEST_THREADS']='1';env['CARGO_TARGET_DIR']=str(src.parent/'target')
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 localenv=dict(env,TRNM_CI_RECEIPT_DIR=str(out/(name+'-receipts')))
 t=time.monotonic();b=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:rc=subprocess.call(args,cwd=src,env=localenv,stdout=so,stderr=se)
 a=resource.getrusage(resource.RUSAGE_CHILDREN);row={'name':name,'argv':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':a.ru_utime-b.ru_utime,'child_system_cpu_seconds':a.ru_stime-b.ru_stime};res['commands'].append(row);save();print(json.dumps(row),flush=True)
 if rc:print((out/(name+'.stderr')).read_text(errors='replace')[-6500:],flush=True);raise RuntimeError(name+' failed')
try:
 run('preflight',['bash','scripts/project-preflight.sh'])
 rel='evidence/pon-w1-complete-succinct-20261028/full-proof/input.bin'
 p=src/rel;gitsha=subprocess.check_output(['git','rev-parse','HEAD:'+rel],cwd=src,text=True).strip()
 got=subprocess.run(['git','cat-file','blob',gitsha],cwd=src,capture_output=True)
 (out/'input-git.stderr').write_bytes(got.stderr);assert got.returncode==0
 data=got.stdout;assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==gitsha
 if p.exists():assert p.read_bytes()==data
 else:
  p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:f.write(data)
 (out/'restored-inputs.json').write_text(json.dumps([{'path':rel,'git_blob':gitsha,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}],indent=2)+'\n')

 original=(src.parent.parent/'repository-tail-diagnostic-75/original-tail.sh').read_bytes();marker=b'    python3 scripts/ci/test_w1_full_v2_disposition.py\n'
 assert original.count(marker)==1
 suffix=original[original.index(marker):]
 body=b'#!/usr/bin/env bash\nset -euo pipefail\nexport RUST_TEST_THREADS="${RUST_TEST_THREADS:-1}"\n# Exact original suffix; not a complete repository qualification.\n'+suffix
 (out/'original-suffix.sh').write_bytes(body);res['original_suffix_sha256']=hashlib.sha256(suffix).hexdigest();res['source_diff_sha256']=hashlib.sha256(subprocess.check_output(['git','diff','--full-index','HEAD'],cwd=src)).hexdigest();save()
 run('original-suffix',['bash',str(out/'original-suffix.sh')])
 run('complete-original-repository-truth',['bash','scripts/ci/ci_job.sh','repository-truth'])
 res['complete']=True;res['passed']=True;save();print(json.dumps({'complete':True,'passed':True}),flush=True)
except BaseException as e:
 res['complete']=True;res['passed']=False;res['error']=repr(e);save();(out/'owner.error').write_text(traceback.format_exc());raise
