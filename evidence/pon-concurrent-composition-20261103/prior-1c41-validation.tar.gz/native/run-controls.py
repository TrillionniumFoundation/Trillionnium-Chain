#!/usr/bin/env python3
"""Direct controls on one exact complete-workspace test build. Never builds workspace."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/abae1861b451/chain-post-ci')
TARGET = Path('/workspace/scratch/abae1861b451/post-ci-native-target')
PROVIDER = Path('/workspace/scratch/abae1861b451/original-pq-provider/provider.env')
PROVIDER_RECEIPT = Path('/workspace/scratch/abae1861b451/original-pq-provider/receipts/pq-provider/provider.json')
COMMIT = '1c41b3b7add7541d86a8112869bd21ce5343d2fd'
TREE = '4524f8c5f96e1c73984b38d16d4fc9955b7ad8ce'
CARGO = '/root/.cargo/bin/cargo'
CPU = [
 'store::detached_admission::tests::admitted_custom_genesis_over_eight_mib_keeps_original_held_schedule_and_cpu_owner',
 'store::detached_admission::tests::authenticated_large_parent_original_schedule_supplementary_denominator',
 'ingress::public_v2::tests::public_loop_exit_records_lifetime_before_internal_stop',
 'ingress::public_v2::tests::public_loop_exit_records_external_stop_after_signed_read',
]
SEMANTIC = [
 ('m06', 'full-root-arithmetic', 'pon_commitment::full_root_arithmetic_tests::', 5),
 ('m06', 'canonical-ascii', [
  'pon_executor::root_arithmetic_tests::canonical_ascii_guard_matches_exhaustive_bytes_pairs_and_borrow_chains',
  'pon_executor::root_arithmetic_tests::canonical_ascii_keeps_original_serde_bytes_and_vec_capacities',
  'pon_executor::root_arithmetic_tests::canonical_ascii_into_keeps_reused_capacity_and_failed_input_untouched',
  'pon_executor::root_arithmetic_tests::canonical_ascii_commitment_keeps_late_grammar_before_wire_and_cache_errors',
  'pon_executor::root_arithmetic_tests::arithmetic_root_ascii_encoding_matches_independent_serde_reference',
  'pon_executor::root_arithmetic_tests::arithmetic_root_preserves_complete_grammar_before_all_wire_limits',
  'pon_commitment::bounded_encoding_tests::canonical_ascii_fast_encoding_keeps_direct_serde_budget_decisions_and_charges'], 7),
 ('node', 'reorg-tail', 'store::reorg_readback_tests::', 6),
 ('node', 'current-sql-root', [
  'store::detached_admission::tests::large_parent_root_arithmetic_keeps_current_sql_and_original_read_checkpoints'], 1),
 ('node', 'prepared-current-history', [
  'store::historical_commitment_tests::legacy_prepared_history_reads_observe_current_rows_writes_and_rollback',
  'store::historical_commitment_tests::legacy_prepared_history_reads_reprepare_after_schema_and_authorizer_changes',
  'store::historical_commitment_tests::actual_foreign_snapshot_delta_and_root_damage_preserve_original_failures'], 3),
 ('node', 'postwrite-readback', 'store::native_authenticated::post_write_readback::tests::', 23),
]
GROUPS = [
 ('protocol', 'protocol-wire', 'pon_wire::', 27, 1, False),
 ('m06', 'm06-root', 'pon_executor::root_arithmetic_tests::', 9, 0, False),
 ('node', 'pq-observation', 'pq_rollback_witness::test_observation::tests::', 2, 0, False),
 ('cell', 'cell-sequence', 'cell::discovery::sequence_tests::', 3, 0, False),
 ('node', 'native-authenticated', 'store::native_authenticated::', 83, 0, True),
]
CRATES = {'node': ('trnm-pon-node', 'trnm_pon_node', '3'),
          'm06': ('trnm-mvcc-fee', 'trnm_mvcc_fee', '1'),
          'protocol': ('trnm-protocol', 'trnm_protocol', '3'),
          'cell': ('trnm-data-availability', 'trnm_data_availability', '0')}
SUMMARY = re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in [0-9.]+s$')
NATIVE_LINE = re.compile(r'^test ([A-Za-z_][A-Za-z0-9_:]*) \.\.\. (ok|FAILED|ignored(?:, .*)?)$')


def now():
 return dt.datetime.now(dt.timezone.utc).isoformat()


def sha(path):
 h = hashlib.sha256()
 with open(path, 'rb') as f:
  for data in iter(lambda: f.read(1024*1024), b''): h.update(data)
 return h.hexdigest()


def save(path, value):
 pending = path.with_name(path.name + '.pending')
 with open(pending, 'w') as f:
  json.dump(value, f, indent=2, sort_keys=True); f.write('\n'); f.flush(); os.fsync(f.fileno())
 os.replace(pending, path)


def env():
 values = {}
 for line in PROVIDER.read_text().splitlines():
  key, value = line.split('=', 1)
  assert key not in values and re.fullmatch(r'[A-Z0-9_]+', key)
  assert value and not any(c in value for c in '\r\n$`\"\';')
  values[key] = value
 assert set(values) == {'OPENSSL_DIR','OPENSSL_STATIC','TRNM_PQ_OPENSSL','TRNM_PQ_OPENSSL_SHA256','TRNM_PQ_OPENSSL_VERSION','OPENSSL_CONF','OPENSSL_MODULES'}
 assert values['OPENSSL_STATIC'] == '1' and values['TRNM_PQ_OPENSSL_VERSION'] == '3.5.9'
 assert sha(PROVIDER) == json.loads((BASE/'build.json').read_text())['provider_env_sha256']
 assert sha(values['TRNM_PQ_OPENSSL']) == values['TRNM_PQ_OPENSSL_SHA256']
 provider = json.loads(PROVIDER_RECEIPT.read_text())
 assert provider['result'] == 'PREPARED_AND_SMOKE_VERIFIED' and provider['exit_code'] == 0
 assert provider['cli_sha256'] == values['TRNM_PQ_OPENSSL_SHA256']
 result = os.environ.copy()
 forbidden = ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTC','RUSTC_BOOTSTRAP','RUSTDOC','RUSTDOCFLAGS','CARGO_ENCODED_RUSTDOCFLAGS','CARGO_BUILD_RUSTC','CARGO_BUILD_RUSTDOC','CARGO_BUILD_RUSTFLAGS','CARGO_BUILD_TARGET','CARGO_BUILD_RUSTC_WRAPPER','CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER')
 assert not any(result.get(k) for k in forbidden), 'unexpected compiler override'
 assert not any(k.startswith('CARGO_PROFILE_') for k in result), 'profile override'
 assert not any(v for k,v in result.items() if k.startswith('CARGO_TARGET_') and k.endswith(('_RUSTFLAGS','_LINKER','_RUNNER'))), 'target override'
 result.update(values)
 result.update(CI='true', CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0', RUST_TEST_THREADS='1', PYTHONDONTWRITEBYTECODE='1', TRNM_CI_RECEIPT_DIR=str(BASE))
 return result


def command(directory, name, argv, cwd, environment):
 log = directory/(name+'.log')
 before = resource.getrusage(resource.RUSAGE_CHILDREN)
 record = {'name': name, 'argv': argv, 'cwd': str(cwd), 'started_utc': now(), 'status': 'running', 'exit_code': None,
           'resource_scope': 'Python child rusage CPU snapshots; child maxrss is cumulative high-water, not GNU time or isolated process-tree peak. Original in-test CPU observations remain authoritative.'}
 save(directory/(name+'.json'), record)
 started = time.monotonic_ns()
 print(json.dumps({'event':'command_start','phase':directory.name,'name':name,'argv':argv}), flush=True)
 try:
  with open(log,'xb') as output:
   process = subprocess.run(argv, cwd=cwd, env=environment, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, check=False)
  record['exit_code'] = process.returncode
 except OSError as error:
  record['exception'] = {'class':type(error).__name__, 'errno':error.errno, 'message':str(error)}
 record['wall_ns'] = time.monotonic_ns()-started
 after = resource.getrusage(resource.RUSAGE_CHILDREN)
 record.update(finished_utc=now(), child_user_seconds=after.ru_utime-before.ru_utime, child_system_seconds=after.ru_stime-before.ru_stime, cumulative_children_maxrss_kib_after=after.ru_maxrss)
 record['status'] = 'passed' if record['exit_code'] == 0 else 'failed'
 if log.exists(): record.update(log=log.name, log_sha256=sha(log), log_bytes=log.stat().st_size)
 save(directory/(name+'.json'), record)
 print(json.dumps({'event':'command_end','phase':directory.name,'name':name,'exit_code':record['exit_code'],'wall_ns':record['wall_ns']}), flush=True)
 return record


def source_check(directory, label, environment):
 record = command(directory, label, ['python3',str(REPO/'scripts/ci/verify_ci_source.py'),'--kind','head','--expected-head',COMMIT,'--output',str(directory/(label+'-identity.json'))], REPO, environment)
 assert record['exit_code'] == 0, 'original exact-source verification failed'
 value = json.loads((directory/(label+'-identity.json')).read_text())
 assert value['tested_commit'] == COMMIT and value['tested_tree'] == TREE and value['tracked_worktree_verified'] is True
 return value


def binaries_current(artifacts):
 for item in artifacts['binaries'].values():
  p = Path(item['executable'])
  assert p.is_file() and not p.is_symlink() and p.resolve().parent == TARGET/'debug/deps'
  assert sha(p) == item['sha256'], 'selected ELF changed'


def inspect():
 directory = BASE/'artifact-inspection'; directory.mkdir()
 environment = env()
 build = json.loads((BASE/'build.json').read_text())
 assert build['commit'] == COMMIT and build['tree'] == TREE and build['target'] == str(TARGET)
 assert build['exit_code'] == 0 and build['status'] in ('passed','completed','success'), 'build not successfully complete'
 assert build['command'] == [CARGO,'+1.95.0','test','--locked','--manifest-path','trillionnium/Cargo.toml','--workspace','--all-targets','--all-features','--no-run','--message-format=json']
 source_before = source_check(directory, 'source-before', environment)
 rows = [json.loads(line) for line in (BASE/'build.jsonl').read_text().splitlines() if line.strip()]
 assert [r for r in rows if r.get('reason') == 'build-finished'] == [{'reason':'build-finished','success':True}]
 artifacts = [r for r in rows if r.get('reason') == 'compiler-artifact']
 selected = {}; profiles = {}
 for label, (package, target, opt) in CRATES.items():
  choices = [r for r in artifacts if r['target']['name'] == target and r['target']['kind'] == ['lib']]
  assert choices, f'missing library artifacts {label}'
  for row in choices:
   assert Path(row['target']['src_path']).resolve() == REPO/'trillionnium/crates'/package/'src/lib.rs'
   assert row['profile']['opt_level'] == opt and row['profile']['debug_assertions'] and row['profile']['overflow_checks'], f'original profile mismatch {label}'
   if label in ('node','m06'): assert row['features'] == ['default','pq-native-openssl'], f'wrong full-workspace feature closure {label}'
  profiles[label] = choices
  tests = [r for r in choices if r['profile']['test'] and r.get('executable')]
  assert len(tests) == 1, f'expected one exact libtest ELF {label}'
  row = tests[0]; binary = Path(row['executable'])
  assert binary.is_file() and not binary.is_symlink() and binary.resolve().parent == TARGET/'debug/deps'
  with binary.open('rb') as stream: assert stream.read(4) == b'\x7fELF'
  selected[label] = {'executable':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size,'cwd':str(REPO/'trillionnium/crates'/package),'artifact':row}
 m06_dependencies = [r for r in profiles['m06'] if not r['profile']['test'] and any(Path(p).suffix == '.rlib' for p in r['filenames'])]
 assert len(m06_dependencies) == 1, 'exact M06 dependency rlib required'
 crypto = [r for r in artifacts if r['target']['name']=='trnm_crypto_primitives' and r['target']['kind']==['lib']]
 assert crypto and all('pq-native-openssl' in r['features'] for r in crypto), 'Cell transitive full-workspace crypto feature closure'
 assert len({v['executable'] for v in selected.values()}) == 4
 result = {'schema':'post-ci-native-artifacts-v1','commit':COMMIT,'tree':TREE,'script_sha256':sha(Path(__file__)),
           'provider_env_sha256':sha(PROVIDER),'provider_receipt_sha256':sha(PROVIDER_RECEIPT),'build_jsonl_sha256':sha(BASE/'build.jsonl'),
           'source_before':source_before,'binaries':selected,'profile_evidence':profiles,'crypto_profile_evidence':crypto,
           'm06_dependency':m06_dependencies[0], 'status':'passed',
           'scope':'Exact full-workspace original test-profile compilation and artifact identity; no native tests executed by this artifact inspection.'}
 registries = {}
 for label, item in selected.items():
  record = command(directory, label+'-registry', [item['executable'],'--list','--format','terse'], item['cwd'], environment)
  assert record['exit_code'] == 0
  names = [m[1] for line in (directory/record['log']).read_text().splitlines() if (m:=re.fullmatch(r'([A-Za-z_][A-Za-z0-9_:]*): test',line))]
  assert names and len(names) == len(set(names)), f'invalid registry {label}'
  registries[label] = sorted(names)
 result['registries'] = registries
 binaries_current(result)
 result['source_after'] = source_check(directory,'source-after',environment)
 assert result['source_before'] == result['source_after']
 save(BASE/'artifacts.json',result)
 print(json.dumps({'event':'artifacts_validated','status':'passed','registries':{k:len(v) for k,v in registries.items()},'sha256':{k:v['sha256'] for k,v in selected.items()}}),flush=True)


def exact(directory, name, label, selector, artifacts, environment, output_mode='--nocapture'):
 item = artifacts['binaries'][label]
 record = command(directory,name,[item['executable'],selector,'--exact',output_mode,'--test-threads=1'],item['cwd'],environment)
 reader = command(directory,name+'-reader',['python3',str(REPO/'scripts/ci/check_required_native_test.py'),str(directory/record['log']),'--test',selector],REPO,environment)
 return {'name':name,'crate':label,'selector':selector,'kind':'exact','native':record,'reader':reader,'passed':record['exit_code']==0 and reader['exit_code']==0}


def parse_group(text, expected_names, passed, ignored):
 lines = text.splitlines()
 found = [m.groups() for line in lines if (m:=NATIVE_LINE.fullmatch(line))]
 summaries = [m.groups() for line in lines if (m:=SUMMARY.fullmatch(line))]
 starts = [line for line in lines if re.fullmatch(r'running [0-9]+ tests?',line)]
 if len(starts)!=1 or starts[0] != f'running {len(expected_names)} tests':
  raise ValueError('wrong/ambiguous group invocation count')
 if len(found)!=len(expected_names) or sorted(name for name,status in found)!=sorted(expected_names):
  raise ValueError('missing/duplicate/different named executions')
 if len(summaries)!=1: raise ValueError('missing/ambiguous native summary')
 state,p,f,i,m,filtered = summaries[0]
 if state!='ok' or (int(p),int(f),int(i),int(m))!=(passed,0,ignored,0): raise ValueError('native group did not satisfy original counts')
 if sum(status=='ok' for _,status in found)!=passed or sum(status.startswith('ignored') for _,status in found)!=ignored: raise ValueError('named outcomes disagree with summary')
 return {'result':'PASS','passed':passed,'ignored':ignored,'executed_names':[name for name,status in found if status=='ok'],'ignored_names':[name for name,status in found if status.startswith('ignored')],'scope':'actual named group execution and original counts, not workload acceptance beyond test assertions'}


def group(directory,name,label,prefix,passed,ignored,include_ignored,artifacts,environment,whole=False):
 item = artifacts['binaries'][label]
 names = [n for n in artifacts['registries'][label] if n.startswith(prefix)]
 if passed is not None: assert len(names)==passed+ignored, f'{name} registry count mismatch'
 argv = [item['executable']]+([] if whole else [prefix])
 if include_ignored: argv.append('--include-ignored')
 argv += ['--show-output','--test-threads=1']
 record = command(directory,name,argv,item['cwd'],environment)
 try:
  text = (directory/record['log']).read_text(errors='replace')
  if whole:
   summaries = [m.groups() for line in text.splitlines() if (m:=SUMMARY.fullmatch(line))]
   if len(summaries)!=1: raise ValueError('full Node library summary missing/ambiguous')
   passed,ignored = int(summaries[0][1]),int(summaries[0][3])
   if passed+ignored != len(names): raise ValueError('full library registry coverage mismatch')
  reader = parse_group(text,names,passed,ignored)
  if name == 'native-authenticated':
   subset = [n for n in reader['executed_names'] if n.startswith('store::native_authenticated::post_write_readback::tests::')]
   assert len(subset)==23, 'all 23 post-write controls required inside original 83 run'
  ok=True
 except (ValueError,AssertionError) as error:
  reader={'result':'FAIL','error':str(error)};ok=False
 save(directory/(name+'-reader.json'),reader)
 return {'name':name,'crate':label,'prefix':prefix,'kind':'group','expected_passed':passed,'expected_ignored':ignored,'include_ignored':include_ignored,'native':record,'reader':reader,'passed':record['exit_code']==0 and ok}


def load_artifacts():
 result=json.loads((BASE/'artifacts.json').read_text())
 assert result['status']=='passed' and result['commit']==COMMIT and result['tree']==TREE
 assert result['build_jsonl_sha256']==sha(BASE/'build.jsonl')
 assert result['script_sha256']==sha(Path(__file__)), 'control script changed after artifact inspection'
 binaries_current(result)
 return result


def phase_start(name, artifacts, environment):
 directory=BASE/name;directory.mkdir()
 result={'schema':'post-ci-direct-controls-v1','phase':name,'commit':COMMIT,'tree':TREE,'status':'running','started_utc':now(),'script_sha256':sha(Path(__file__)),'artifacts_sha256':sha(BASE/'artifacts.json'),'source_before':source_check(directory,'source-before',environment),'controls':[],
         'scope':'Local x86_64 exact-commit original workspace test-profile controls; not ARM, release, hosted resource measurement or full baseline acceptance.'}
 save(directory/'summary.json',result)
 return directory,result


def phase_end(directory,result,artifacts,environment):
 try:
  binaries_current(artifacts)
  result['source_after']=source_check(directory,'source-after',environment)
  assert result['source_before']==result['source_after']
  result['identity_after']='passed'
 except Exception as error:
  result['identity_after']='failed';result['identity_error']=repr(error)
 result['finished_utc']=now()
 result['status']='passed' if result['identity_after']=='passed' and not result.get('fatal') and all(r['passed'] for r in result['controls']) else 'failed'
 save(directory/'summary.json',result)
 print(json.dumps({'event':'phase_complete','phase':result['phase'],'status':result['status'],'controls':len(result['controls']),'failed':[r['name'] for r in result['controls'] if not r['passed']]}),flush=True)
 return 0 if result['status']=='passed' else 1


def controls(mode):
 environment=env();artifacts=load_artifacts()
 directory,result=phase_start(mode,artifacts,environment)
 def retain(row):
  result['controls'].append(row);save(directory/'summary.json',result)
 try:
  if mode=='minimum':
   for index,selector in enumerate(CPU):
    assert selector in artifacts['registries']['node']
    retain(exact(directory,f'cpu-exit-{index:02}','node',selector,artifacts,environment))
   print(json.dumps({'event':'original_cpu_and_reactor_complete','native_exits':[r['native']['exit_code'] for r in result['controls']]}),flush=True)
   semantic=[]
   for label,group_name,selection,count in SEMANTIC:
    names=sorted(n for n in artifacts['registries'][label] if n.startswith(selection)) if isinstance(selection,str) else selection
    assert len(names)==count and len(set(names))==count and set(names)<=set(artifacts['registries'][label]), f'{group_name} registry mismatch'
    semantic += [(label,group_name,name) for name in names]
   assert len(semantic)==45 and len({(label,name) for label,group,name in semantic})==45
   save(directory/'semantic-selection.json',semantic)
   for index,(label,group_name,selector) in enumerate(semantic):
    retain(exact(directory,f'semantic-{index:02}-{group_name}',label,selector,artifacts,environment))
   for label,name,prefix,passed,ignored,include in GROUPS:
    retain(group(directory,name,label,prefix,passed,ignored,include,artifacts,environment))
   # This final doctest is outside the original CPU selector window. No workspace rebuild.
   preflight=command(directory,'doctest-preflight',['bash','scripts/project-preflight.sh'],REPO,environment)
   if preflight['exit_code']==0:
    record=command(directory,'opaque-doctest',[CARGO,'+1.95.0','test','--locked','--manifest-path','trillionnium/Cargo.toml','-p','trnm-protocol','--all-features','--doc','StateRootInputBuilder','--','--show-output','--test-threads=1'],REPO,environment)
    text=(directory/record['log']).read_text(errors='replace')
    summaries=[m.groups() for line in text.splitlines() if (m:=SUMMARY.fullmatch(line))]
    doc_lines=[line for line in text.splitlines() if line.startswith('test ') and 'StateRootInputBuilder' in line and 'compile fail' in line and line.endswith(' ... ok')]
    ok=len(summaries)==1 and summaries[0][:5]==('ok','1','0','0','0') and len(doc_lines)==1
    reader={'result':'PASS' if ok else 'FAIL','summaries':summaries,'compile_fail_lines':doc_lines}
    save(directory/'opaque-doctest-reader.json',reader)
    retain({'name':'opaque-doctest','kind':'compile-fail-doctest','native':record,'reader':reader,'passed':record['exit_code']==0 and ok})
   else:
    retain({'name':'opaque-doctest','passed':False,'not_run_reason':'preflight failed','preflight':preflight})
   assert len(result['controls'])==55, 'minimum planned command coverage'
  elif mode=='pq43':
   contract=json.loads((REPO/'config/pon/pq-system-required-tests-v1.json').read_text())
   selectors=contract['tests']
   assert contract['schema']=='trnm-pq-system-required-tests-v1' and contract['whole_chain_quantum_security_qualified'] is False
   assert contract['expected_meaningful_controls']==len(selectors)==len(set(selectors))==43
   assert not set(selectors)&set(contract['child_process_harnesses_not_counted'])
   assert set(selectors)<=set(artifacts['registries']['node'])
   for index,selector in enumerate(selectors):
    retain(exact(directory,f'pq-{index:02}','node',selector,artifacts,environment,output_mode='--show-output'))
  elif mode=='node-library':
   retain(group(directory,'complete-node-library','node','',None,None,False,artifacts,environment,whole=True))
 except Exception as error:
  result['fatal']=repr(error);save(directory/'summary.json',result)
  print(json.dumps({'event':'phase_fatal','phase':mode,'error':repr(error)}),flush=True)
 return phase_end(directory,result,artifacts,environment)


def plan():
 return {'schema':'post-ci-direct-control-plan-v1','commit':COMMIT,'tree':TREE,'repo':str(REPO),'target':str(TARGET),'provider_env':str(PROVIDER),'provider_env_sha256':sha(PROVIDER),
         'build_owner':'root: already running original complete workspace argv; this script never starts another workspace build',
         'minimum_exact_cpu_and_reactor':CPU,'original_semantic_groups':SEMANTIC,'additional_required_groups':GROUPS,'opaque_doctest':1,
         'minimum_planned_commands':55,'minimum_expected_passes':174,'minimum_expected_ignored':1,
         'optional_stages':['pq43','node-library'],'cpu_barrier':'Notify root and run only after root confirms no parallel compilation; actual CPU metrics are original test observations.',
         'native_process_timeouts':None,'retries':0,'exclude_failed_observations':False,
         'resource_scope':'Python RUSAGE_CHILDREN only; GNU time is unavailable locally and original failed wrapper preparation is preserved by root.',
         'scope':'Exact local x86_64 original test-profile build/controls; no release/ARM/full-runtime or service acceptance claim.'}


def selfcheck():
 text='running 2 tests\ntest a::one ... ok\ntest a::two ... ignored, original reason\ntest result: ok. 1 passed; 0 failed; 1 ignored; 0 measured; 7 filtered out; finished in 0.01s\n'
 assert parse_group(text,['a::one','a::two'],1,1)['result']=='PASS'
 negatives=[text.replace('running 2','running 0'),text.replace('a::two','a::one'),text.replace('1 passed; 0 failed','0 passed; 1 failed'),text.replace('a::one ... ok','a::wrong ... ok'),text+text,text.replace('test result: ok.','test result: FAILED.')]
 for bad in negatives:
  try:parse_group(bad,['a::one','a::two'],1,1)
  except ValueError:continue
  raise AssertionError('bad synthetic transcript accepted')
 assert len(CPU)==4 and sum(group[-1] for group in SEMANTIC)==45
 assert sum(group[3] for group in GROUPS)+4+45+1==174
 print(json.dumps({'script_parser_selfcheck':'passed','synthetic_negative_controls':len(negatives),'native_tests_executed':0}))


if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('mode',choices=['plan','selfcheck','inspect','minimum','pq43','node-library'])
 parser.add_argument('--commit',default=COMMIT)
 parser.add_argument('--cpu-window-confirmed',action='store_true')
 args=parser.parse_args()
 assert args.commit==COMMIT, 'wrong exact commit'
 try:
  if args.mode=='plan':print(json.dumps(plan(),indent=2))
  elif args.mode=='selfcheck':selfcheck()
  elif args.mode=='inspect':inspect()
  else:
   assert args.cpu_window_confirmed, 'CPU/quota controls require root quiet-window confirmation'
   sys.exit(controls(args.mode))
 except Exception as error:
  save(BASE/f'invocation-failure-{time.time_ns()}.json',{'mode':args.mode,'error':repr(error),'commit':COMMIT,'created_utc':now()})
  raise
