#!/usr/bin/env python3
"""Correct one wrapper path in a separate observation; preserve the first run."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

RUNNER = Path('/data/pq-closure-c2-publish-validate-d4d2.py')
ORIGINAL = Path('/data/pq-closure-c2-publish-validation-0e554f36ff-d4d2')
SUPPLEMENT = Path('/data/pq-closure-c2-inventory-correction-0e554f36ff-d4d2')
assert hashlib.sha256(RUNNER.read_bytes()).hexdigest() == '024dd83c5bc1fc2bd8250b0e25a3ee5b57afe92480bc6f385a55fbfc4f8cd336'
spec = importlib.util.spec_from_file_location('original_publish_runner', RUNNER)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
original_summary = json.loads((ORIGINAL / 'summary.json').read_bytes())
assert original_summary['all_commands_passed'] is False
assert original_summary['source'] == {'commit':runner.C2,'tree':runner.C2_TREE}
failed = [row for row in original_summary['commands'] if not row['passed']]
assert len(failed) == 1 and failed[0]['name'] == 'distributed-inventory' and failed[0]['exit_code'] == 2
assert failed[0]['argv'] == ['/usr/bin/python3','-B','scripts/ci/refresh_distributed_source_inventory.py','--check']
original_stderr = (ORIGINAL / 'distributed-inventory.stderr.log').read_text()
assert "can't open file" in original_stderr and 'No such file or directory' in original_stderr
original_tests = next(row for row in original_summary['commands'] if row['name'] == 'public-readiness-tests')
assert original_tests['passed'] is True and original_tests['complete_71_without_skip'] is True
assert not SUPPLEMENT.exists()
SUPPLEMENT.mkdir(mode=0o700)
runner.OUT = SUPPLEMENT
runner.write('supplement-runner-identity.json', runner.file_identity(Path(__file__).resolve()))
runner.write('original-summary-identity.json', runner.file_identity(ORIGINAL / 'summary.json'))
runner.write('original-failed-command.json', failed[0])
source_before = runner.identity(runner.SOURCE, runner.C1, runner.C1_TREE)
assert source_before == json.loads((ORIGINAL / 'original-c1-before.json').read_bytes())
runner.write('original-c1-before.json', source_before)
before_args = ['/usr/bin/python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',runner.C2]
runner.run('source-before', before_args + ['--output',str(SUPPLEMENT / 'source-before.json')], runner.DEST)
runner.run('distributed-inventory-corrected', ['/usr/bin/python3','-B','scripts/refresh_distributed_source_inventory.py','--check'], runner.DEST)
runner.run('source-after', before_args + ['--output',str(SUPPLEMENT / 'source-after.json')], runner.DEST)
assert (SUPPLEMENT / 'source-before.json').read_bytes() == (SUPPLEMENT / 'source-after.json').read_bytes()
source_after = runner.identity(runner.SOURCE, runner.C1, runner.C1_TREE)
assert source_before == source_after
runner.write('original-c1-after.json', source_after)
runner.write('publish-c2-after.json', runner.identity(runner.DEST, runner.C2, runner.C2_TREE))
runner.write('summary.json', {
    'schema':'TRNM-C2-INVENTORY-COMMAND-CORRECTION1',
    'source':{'commit':runner.C2,'tree':runner.C2_TREE},
    'scope':'Only the incorrect wrapper inventory pathname is corrected; no 71-test rerun.',
    'original_run_summary':str(ORIGINAL / 'summary.json'),
    'original_all_commands_passed':False,
    'original_failure_preserved':True,
    'original_71_tests_passed':True,
    'supplemental_commands':runner.RECEIPTS,
    'supplemental_all_commands_passed':True,
    'full_source_before_after_equal':True,
    'original_c1_identity_unchanged':True,
    'combined_required_publish_validation_complete':True,
    'push_performed':False,'pr_edit_performed':False,
    'whole_chain_pq_qualified':False,'production_activation':False,
    'finished_utc':runner.now(),
})
print(json.dumps({'combined_publish_ready':True,'original_all_commands_passed':False,
                  'corrected_inventory_passed':True,'original_71_tests_passed':True,
                  'publish_checkout':str(runner.DEST),'source':runner.C2,'output':str(SUPPLEMENT)}),flush=True)
