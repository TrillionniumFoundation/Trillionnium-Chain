from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import sys

out = Path(sys.argv[1])
steps = json.loads(os.environ['W1_QROM_STEP_RESULTS'])
expected_digest = 'ca685b61914435e0be6defdaa0bc4f2368f7430060663315cd96f226adab5bd8'
required_modules = (
    'test_w1_control_tree_audit',
    'test_w1_qrom_conditional_budget',
    'test_w1_qrom_implementation_audit',
    'test_w1_fri_transcript_audit',
    'test_w1_qrom_workflow_gate',
)
def strict_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key: ' + key)
        result[key] = value
    return result

def refuse_constant(value):
    raise ValueError('nonfinite JSON number: ' + value)

def strict_json(raw):
    return json.loads(raw, object_pairs_hook=strict_object, parse_constant=refuse_constant)

def check_named_completion():
    roster_raw = (out / 'required-tests.json').read_bytes()
    if (hashlib.sha256(roster_raw).hexdigest() != expected_digest
            or roster_raw != Path('config/pon/w1-qrom-required-tests-v1.json').read_bytes()):
        raise ValueError('retained named-test roster differs from the reviewed source pin')
    manifest = strict_json(roster_raw)
    if (type(manifest) is not dict
            or manifest.get('schema') != 'TRNM-W1-QROM-REQUIRED-TESTS1'
            or type(manifest.get('suites')) is not list
            or any(type(row) is not dict for row in manifest['suites'])
            or tuple(row.get('module') for row in manifest['suites']) != required_modules
            or type(manifest.get('expected_tests')) is not int):
        raise ValueError('fixed roster schema, suite order or total invalid')
    completion_raw = (out / 'named-tests.json').read_bytes()
    completion = strict_json(completion_raw)
    expected_fields = {
        'schema', 'roster_sha256', 'required_tests', 'suites',
        'all_named_controls_passed', 'post_quantum_soundness_qualified',
        'unconditional_project_security_bits',
    }
    if (type(completion) is not dict or set(completion) != expected_fields
            or completion['schema'] != 'TRNM-W1-QROM-NAMED-TEST-OBSERVATION1'
            or completion['roster_sha256'] != expected_digest
            or type(completion['required_tests']) is not int
            or completion['required_tests'] != manifest['expected_tests']
            or completion['all_named_controls_passed'] is not True
            or completion['post_quantum_soundness_qualified'] is not False
            or completion['unconditional_project_security_bits'] is not None
            or type(completion['suites']) is not list
            or len(completion['suites']) != len(required_modules)):
        raise ValueError('named-test completion schema, total or scope invalid')
    suite_fields = {
        'module', 'expected_ids', 'passed', 'registered_ids', 'loader_errors',
        'tests_run', 'started_ids', 'success_ids', 'skipped', 'failures', 'errors',
        'expected_failures', 'unexpected_successes',
    }
    total = 0
    all_required = []
    for required_suite, observed in zip(manifest['suites'], completion['suites']):
        names, count = required_suite.get('tests'), required_suite.get('expected_tests')
        if (type(names) is not list or any(type(name) is not str for name in names)
                or type(count) is not int or count <= 0
                or len(names) != count or len(set(names)) != count
                or type(observed) is not dict or set(observed) != suite_fields
                or observed['module'] != required_suite['module']
                or observed['passed'] is not True
                or type(observed['tests_run']) is not int or observed['tests_run'] != count):
            raise ValueError('named-test suite identity, fields or count invalid')
        for field in ('expected_ids', 'registered_ids', 'started_ids', 'success_ids'):
            actual = observed[field]
            if (type(actual) is not list or any(type(name) is not str for name in actual)
                    or Counter(actual) != Counter(names)):
                raise ValueError('named-test completion lost exact identities: '
                                 + required_suite['module'] + '.' + field)
        for field in ('loader_errors', 'skipped', 'failures', 'errors',
                      'expected_failures', 'unexpected_successes'):
            if type(observed[field]) is not list or observed[field]:
                raise ValueError('named-test completion retained a non-success outcome: '
                                 + required_suite['module'] + '.' + field)
        total += count
        all_required.extend(names)
    if total != manifest['expected_tests'] or len(set(all_required)) != total:
        raise ValueError('named-test completion has an invalid total or duplicate required ID')
    return hashlib.sha256(completion_raw).hexdigest()

named_completion_error = None
named_completion_sha256 = None
try:
    named_completion_sha256 = check_named_completion()
except Exception as error:
    named_completion_error = str(error)
required = (
    'observations', 'checkout', 'source_before', 'preflight', 'named_tests',
    'implementation', 'budget_unknown', 'budget_hypothetical',
    'report_scopes', 'source_after',
)
incomplete = [name for name in required if
              steps.get(name, {}).get('outcome') != 'success'
              or steps.get(name, {}).get('conclusion') != 'success']
identity_error = None
if not incomplete:
    try:
        before = json.loads((out / 'source-before.json').read_text())
        after = json.loads((out / 'source-after.json').read_text())
        if (before != after or before.get('schema') != 'trnm-ci-source-v1'
                or before.get('kind') != os.environ['SOURCE_KIND']
                or before.get('tested_commit') != os.environ['EXPECTED_SOURCE']
                or before.get('candidate') != os.environ['EXPECTED_HEAD']
                or before.get('tracked_worktree_verified') is not True):
            raise ValueError('source identities disagree or do not bind the requested source')
    except (OSError, ValueError, TypeError) as error:
        identity_error = str(error)
report = {
    'schema': 'TRNM-W1-QROM-CI-OBSERVATION1',
    'source_kind': os.environ['SOURCE_KIND'],
    'expected_source': os.environ['EXPECTED_SOURCE'],
    'expected_candidate': os.environ['EXPECTED_HEAD'],
    'expected_base': os.environ['EXPECTED_BASE'],
    'steps': steps,
    'required_stages': required,
    'failed_or_skipped_stages': incomplete,
    'source_identity_error': identity_error,
    'named_test_completion_error': named_completion_error,
    'named_test_completion_sha256': named_completion_sha256,
    'named_test_completion_verified': named_completion_error is None,
    'all_required_observations_passed': not incomplete and identity_error is None
        and named_completion_error is None,
    'scope': 'Offline construction and saved-fixture mapping with conditional arithmetic. This workflow does not establish proof or quantum security.',
    'post_quantum_soundness_qualified': False,
    'complete_w1_soundness_qualified': False,
    'quantum_work_qualified': False,
    'pq_signature_qualification_inferred': False,
    'production_qualified': False,
    'consensus_admission': False,
    'unconditional_project_security_bits': None,
}
with (out / 'ci-status.json').open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True, allow_nan=False)
    stream.write('\n')
if report['all_required_observations_passed'] is not True:
    raise SystemExit('required observations failed, were skipped or lost source identity: '
                     + ', '.join(incomplete) + '; ' + str(identity_error)
                     + '; named completion: ' + str(named_completion_error))
print('All required exact-source observations completed; project security remains unqualified.')
