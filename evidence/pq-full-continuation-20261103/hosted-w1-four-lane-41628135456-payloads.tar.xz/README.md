# Hosted W1 research verifier: four-lane artifact readback

This bundle retains evidence from GitHub Actions run 41628135456, attempt 1,
for the isolated SDK 3.0.6 W1 research verifier. It does not qualify the parallel
native network/witness jobs, whole-chain PQ security, PQ-128, WAN or production.

Candidate: 12fe5f2c1f19704fe7eb635dede6839ed8b1e91e.
Actual prospective merge: 0357031364787574cb7058b05329aa2e2730f947.
Merge parents, in order: 2e72a989d001cf51bd0aed0e1401526e45db31f1,
12fe5f2c1f19704fe7eb635dede6839ed8b1e91e.
Both tested trees: c44112da731e3f958e55eb024e5762d6723ea2c9.

| Lane | Job | Artifact |
| --- | --- | --- |
| x64 head | 125890592176 | 13226234301 |
| x64 prospective merge | 125890591419 | 13226169545 |
| ARM head | 125890592077 | 13226363199 |
| ARM prospective merge | 125890591942 | 13225943961 |

All four original ZIP downloads matched the GitHub artifact size and SHA-256.
All 82 entries per artifact are retained byte-for-byte under lanes/: 328 entries
in total. The full bundle also includes all four original ZIP files. The smaller
payload bundle omits only the ZIP containers; it retains every uncompressed
artifact entry and their member hashes, original ZIP identities, source files,
raw decoded job logs, API snapshots, readback code and summaries.

For each lane, the readback verified all 12 source-bound command records:
successful exit/status, exact argv, raw log size/SHA-256, runner architecture,
run/attempt, and matching before/after full tracked-worktree identity. Each
source identity records 6,831 tracked entries and 782,174,381 bytes verified by
the existing source checker; that identity check itself claims no test execution.
Actual checkout commit output in each job log agrees with the recorded source.
The API commit objects independently bind the head and merge trees and parents.

Each lane's raw results establish four executed unit tests, zero failed/ignored/
filtered; actual complete saved-receipt verification; all 26 named full-receipt
controls (one acceptance, 25 rejections, no panics); actual real prefix-lift
verification; and successful locked graph, format and strict Clippy commands.
Every control header/receipt file was hashed against its result row. Full/lift
inputs, SDK, Poseidon2 suite, verifier-parameter digest, control IDs and claim
limits were checked. The lift retains complete_w1_claim=false and
consensus_admission=false. The overall command records retain
whole_chain_quantum_security_qualified=false.

This is readback of actual execution records, not a new local proof execution.
The uploaded artifacts do not contain the compiled verifier binaries, so this
record makes no hosted binary-digest claim. The original real lift remains a
source-controlled input; its actual hash and verification result are present in
every lane's frozen-input and recursion records.

The original downloaded ZIPs remain alongside this directory while preparing
the bundles. To repeat the full ZIP and semantic readback, extract the full
bundle and run: python3 readback.py. For either bundle, archive-manifest.json
enumerates every included file's size/SHA-256. The payload-only bundle preserves
all evidence contents but requires the original ZIP downloads to repeat the
ZIP-container portion of readback.py.

Two initial artifact-download bridge requests returned storage ServerBusy;
sequential retries retrieved complete, digest-matching archives. These retrieval
failures are recorded separately from CI results. The local readback parser's
initial Cargo combined-log assumption and its correction are also recorded;
neither changes a CI receipt or raw artifact.
