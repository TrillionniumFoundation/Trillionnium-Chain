from dataclasses import replace
from pathlib import Path
import argparse
import hashlib
import json
import sys
parser = argparse.ArgumentParser(description="Reproduce the physical-resource validation control.")
parser.add_argument("--repo", type=Path, default=Path.cwd(),
                    help="Repository root (default: current working directory)")
repo = parser.parse_args().repo.expanduser().resolve()
module_dir = repo / "formal" / "pon-nakamoto-v1"
if not (module_dir / "quantum_oracle_resources.py").is_file():
    parser.error(f"Repository resource module not found under {repo}")
sys.path.insert(0, str(module_dir))
import quantum_oracle_resources as q

model = replace(q.example(True).physical_models[0], physical_error="1e-100",
                logical_error_prefactor="1e-100", magic_state_error="0", maximum_distance=3)
cases = {
    "hundred_gates_one_wire_one_layer": q.Circuit(1,100,1,0,0,0,0,"width-control"),
    "one_toffoli_on_two_wires": q.Circuit(2,1,1,1,1,0,0,"width-control"),
    "three_toffolis_two_layers_five_wires": q.Circuit(5,3,3,3,2,0,0,"width-control"),
    "three_Ts_one_T_layer_two_wires": q.Circuit(2,3,3,0,0,3,1,"width-control"),
    "mixed_layer_overfull": q.Circuit(3,2,1,1,1,0,0,"width-control"),
}
print(json.dumps({"source_sha256": hashlib.sha256(Path(q.__file__).read_bytes()).hexdigest()}))
accepted = 0
for name, stage in cases.items():
    request = replace(q.example(True), circuits={key: stage for key in q.STAGES},
                      physical_models=(model,), workload=q.Workload(1,1,1,1,1,(),0))
    try:
        report = q.account(request)
    except ValueError as error:
        print(json.dumps({"case": name, "rejected": str(error)}))
        continue
    accepted += 1
    physical = report["physical_sensitivity"][0]
    print(json.dumps({"case": name, "accepted": physical["status"],
                      "allocated_code_cycles": physical["estimate"]["allocated_code_cycles_per_instance"]}))
print(json.dumps({"malformed_accepted": accepted, "required": 0}))
sys.exit(bool(accepted))
