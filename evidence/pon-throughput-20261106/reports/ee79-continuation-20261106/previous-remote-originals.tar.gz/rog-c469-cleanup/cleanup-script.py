#!/usr/bin/env python3
"""Remove only the authorized failed ee79 target; preserve failure evidence."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess

BASE = Path('/home/qian-qi/work/chain-throughput-20261106-ee79')
TARGET = Path('/home/qian-qi/work/chain-throughput-20261106-ee79/target')
REPO = BASE / 'repo'
RAW = BASE / 'raw/c469-native'
HEAD = 'c4693ef2c748e96cec22dd819f6ca2e6e03c6f80'
TREE = 'd3e3824c0a2e163ec60bde8c57628d63e4dee0d5'
KEY = 'chain-ee79-c469-failed-target-cleanup-v1'
PROVIDER = Path('/home/qian-qi/work/chain-throughput-20261106-1eed/provider-temp/trnm-pq-provider-3.5.9.8DrdJ490/install/bin/openssl')
PROVIDER_SHA = '253724b900b96c194ce4da7c59b158ea477eba0be651df8c72ab899c65cca93d'
LEDGER = RAW / 'target-cleanup-v1.jsonl'
COMPRESSED = RAW / 'build.failed-target-cleanup-v1.log.gz'
MANIFEST = RAW / 'target-cleanup-v1-archive-manifest.json'


def require(value, reason):
    if not value:
        raise RuntimeError(reason)


def utc():
    return datetime.now(timezone.utc).isoformat()


def fingerprint(value):
    return [value.st_dev, value.st_ino, value.st_mode, value.st_size,
            value.st_mtime_ns, value.st_ctime_ns]


def regular_file(path, elf=False):
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), 'not a regular file: ' + str(path))
    flags = os.O_RDONLY | os.O_NOFOLLOW
    fd = os.open(path, flags)
    try:
        opened = os.fstat(fd)
        require(fingerprint(opened) == fingerprint(before), 'file changed before open')
        digest = hashlib.sha256()
        first = os.read(fd, 1024 * 1024)
        if elf:
            require(first.startswith(b'\x7fELF') and before.st_mode & 0o111,
                    'selected compiler artifact is not an executable ELF')
        digest.update(first)
        while chunk := os.read(fd, 1024 * 1024):
            digest.update(chunk)
        require(fingerprint(os.fstat(fd)) == fingerprint(before)
                and fingerprint(path.lstat()) == fingerprint(before),
                'file changed while hashing: ' + str(path))
    finally:
        os.close(fd)
    return {'path': str(path), 'bytes': before.st_size,
            'sha256': digest.hexdigest(), 'fingerprint': fingerprint(before)}


def command(argv, cwd=None):
    result = subprocess.run(argv, cwd=cwd, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT,
                            env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), check=True)
    return result.stdout


def system_state():
    usage = shutil.disk_usage(BASE)
    return {'utc': utc(), 'disk_total_bytes': usage.total, 'disk_used_bytes': usage.used,
            'disk_free_bytes': usage.free,
            'df_B1': command(['df', '-B1', str(BASE)]),
            'free_b': command(['free', '-b'])}


def siblings():
    return {entry.name: [item.st_dev, item.st_ino, item.st_mode]
            for entry in BASE.iterdir() if entry.name != 'target'
            for item in [entry.lstat()]}


def scan_target():
    result = dict(regular_files=0, directories=0, symlinks=0, special_entries=0,
                  logical_regular_file_bytes=0, unique_regular_file_bytes=0,
                  unique_allocated_bytes=0, entries_with_multiple_links=0)
    seen = set()
    root_stat = TARGET.lstat()
    for _, directory_names, file_names, fd in os.fwalk(TARGET, follow_symlinks=False):
        directory = os.fstat(fd)
        require(directory.st_dev == root_stat.st_dev, 'cross-device target subtree')
        result['directories'] += 1
        inode = (directory.st_dev, directory.st_ino)
        if inode not in seen:
            seen.add(inode)
            result['unique_allocated_bytes'] += directory.st_blocks * 512
        for name in directory_names + file_names:
            item = os.stat(name, dir_fd=fd, follow_symlinks=False)
            if stat.S_ISDIR(item.st_mode):
                continue
            inode = (item.st_dev, item.st_ino)
            if stat.S_ISREG(item.st_mode):
                result['regular_files'] += 1
                result['logical_regular_file_bytes'] += item.st_size
                result['entries_with_multiple_links'] += int(item.st_nlink > 1)
                if inode not in seen:
                    result['unique_regular_file_bytes'] += item.st_size
            elif stat.S_ISLNK(item.st_mode):
                result['symlinks'] += 1
            else:
                result['special_entries'] += 1
            if inode not in seen:
                seen.add(inode)
                result['unique_allocated_bytes'] += item.st_blocks * 512
    result['non_directory_entry_count'] = (result['regular_files'] + result['symlinks']
                                           + result['special_entries'])
    require(result['special_entries'] == 0, 'unexpected special file inside target')
    return result


def compiler_artifacts(log):
    found = {}
    for line in log.read_text().splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if (not isinstance(value, dict) or value.get('reason') != 'compiler-artifact'
                or value.get('target', {}).get('name') not in {'trnm_pon_node', 'trnm_mvcc_fee'}
                or value.get('target', {}).get('kind') != ['lib']
                or value.get('profile', {}).get('test') is not True
                or not value.get('executable')):
            continue
        path = Path(value['executable'])
        require(path.is_absolute() and path.is_relative_to(TARGET)
                and path.resolve() == path, 'compiler artifact escapes exact target')
        if path.exists():
            found[str(path)] = dict(regular_file(path, elf=True),
                target_name=value['target']['name'], compiler_artifact_fresh=value.get('fresh'),
                binary_executed_by_cleanup=False, binary_preserved=False,
                qualification_granted=False)
        else:
            found[str(path)] = {'path': str(path), 'present': False,
                               'target_name': value['target']['name'],
                               'qualification_granted': False}
    return list(found.values())


def main():
    require(str(TARGET) == '/home/qian-qi/work/chain-throughput-20261106-ee79/target'
            and TARGET.parent == BASE and TARGET.name == 'target', 'cleanup scope mismatch')
    for path in [*reversed(TARGET.parents), TARGET, RAW]:
        require(path.resolve(strict=True) == path and not path.is_symlink(),
                'symlink/noncanonical cleanup path: ' + str(path))
    require(TARGET.is_dir() and RAW.is_dir(), 'cleanup directories absent')
    require(not TARGET.is_mount() and shutil.rmtree.avoids_symlink_attacks,
            'target mount or unsafe rmtree implementation')
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        mounted = re.sub(r'\\([0-7]{3})', lambda m: chr(int(m[1], 8)), line.split()[4])
        require(mounted != str(TARGET) and not mounted.startswith(str(TARGET) + '/'),
                'mounted target subtree')
    require(not LEDGER.exists() and not COMPRESSED.exists() and not MANIFEST.exists(),
            'cleanup outputs already exist; reconcile original durable job')
    with LEDGER.open('x', encoding='utf-8') as ledger:
        def record(phase, **values):
            row = {'schema': 'trnm-failed-target-cleanup-v1', 'phase': phase,
                   'idempotency_key': KEY, 'utc': utc(), 'target': str(TARGET), **values}
            ledger.write(json.dumps(row, sort_keys=True) + '\n')
            ledger.flush()
            os.fsync(ledger.fileno())
            print(json.dumps({'phase': phase, 'ledger': str(LEDGER)}, sort_keys=True), flush=True)

        record('started', authorization_scope='only this isolated failed target cache',
               cleanup_script_sha256=os.environ.get('TRNM_CLEANUP_SCRIPT_SHA256'),
               source_changes=False, compilation=False, acceptance_granted=False)
        try:
            build_path, stage_path, build_log = RAW / 'build.json', RAW / 'build-stage.json', RAW / 'build.log'
            build_meta, stage_meta, log_meta = map(regular_file, (build_path, stage_path, build_log))
            build = json.loads(build_path.read_text())
            stage = json.loads(stage_path.read_text())
            require(build['status'] == 'command_failed' and build['exit_code'] == 101,
                    'original build is not authoritative failed/101')
            require(build['before'] == build['after'] and build['before']['tested_commit'] == HEAD
                    and build['before']['tested_tree'] == TREE
                    and build['before']['tracked_worktree_verified'] is True,
                    'original build source identity mismatch')
            require(build['cwd'] == str(REPO)
                    and build['environment']['CARGO_TARGET_DIR'] == str(TARGET),
                    'original build does not own exact target')
            require(stage['status'] == 'failed' and stage['stage'] == 'build'
                    and stage['head'] == HEAD and stage['repo'] == str(REPO)
                    and stage['commands'][0]['command_exit_code'] == 101
                    and stage['commands'][0]['source'] == build['before'],
                    'original stage is not failed for this build')
            require(log_meta['sha256'] == build['log_sha256'], 'original build log hash mismatch')
            require(build['environment']['TRNM_PQ_OPENSSL'] == str(PROVIDER), 'provider identity mismatch')
            provider_before = regular_file(PROVIDER)
            require(provider_before['sha256'] == PROVIDER_SHA, 'original provider bytes changed')
            preflight = command(['bash', 'scripts/project-preflight.sh'], cwd=REPO)
            source_before = {'head': command(['git', 'rev-parse', 'HEAD'], REPO).strip(),
                             'status': command(['git', 'status', '--porcelain=v1'], REPO)}
            before = system_state()
            target_stat = TARGET.lstat()
            target_inventory = scan_target()
            artifacts = compiler_artifacts(build_log)
            protected = siblings()
            receipt_rows = []
            for path in sorted(RAW.glob('*.json')):
                if not re.fullmatch(r'(?:fmt|format|clippy|build)(?:-.+)?\.json', path.name):
                    continue
                value = json.loads(path.read_text())
                meta = regular_file(path)
                source = value.get('before') or (value.get('commands') or [{}])[0].get('source')
                receipt_rows.append(dict(meta, status=value.get('status'), exit_code=value.get('exit_code'),
                    stage=value.get('stage'), head=value.get('head'), source=source,
                    before_after_equal=value.get('before') == value.get('after') if 'before' in value else None))
            record('prepared', failed_build=build_meta, failed_stage=stage_meta, original_log=log_meta,
                   source=build['before'], current_repo=source_before, preflight=preflight,
                   system_before=before, target_inventory=target_inventory,
                   libtest_artifacts_metadata_only=artifacts, original_receipts=receipt_rows,
                   provider=provider_before, protected_sibling_identities=protected)
            require(fingerprint(TARGET.lstat()) == fingerprint(target_stat), 'target changed after inventory')
            require(regular_file(build_path)['sha256'] == build_meta['sha256']
                    and regular_file(stage_path)['sha256'] == stage_meta['sha256'],
                    'failed build evidence changed before deletion')
            base_fd = os.open(BASE, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                current = os.stat('target', dir_fd=base_fd, follow_symlinks=False)
                require(stat.S_ISDIR(current.st_mode)
                        and (current.st_dev, current.st_ino) == (target_stat.st_dev, target_stat.st_ino),
                        'target directory identity changed')
                shutil.rmtree('target', dir_fd=base_fd)
            finally:
                os.close(base_fd)
            require(not os.path.lexists(TARGET), 'target remains after cleanup')
            after_removal = system_state()
            record('target_removed', system_after_removal=after_removal,
                   observed_disk_free_delta_bytes=after_removal['disk_free_bytes'] - before['disk_free_bytes'])
            with COMPRESSED.open('xb') as output:
                subprocess.run(['gzip', '-n', '-c', '--', str(build_log)], stdout=output, check=True)
                output.flush()
                os.fsync(output.fileno())
            with gzip.open(COMPRESSED, 'rb') as compressed:
                digest = hashlib.sha256()
                while chunk := compressed.read(1024 * 1024):
                    digest.update(chunk)
            require(digest.hexdigest() == log_meta['sha256'], 'compressed log differs from retained original')
            for metadata in [build_meta, stage_meta, log_meta, *receipt_rows]:
                require(regular_file(Path(metadata['path']))['sha256'] == metadata['sha256'],
                        'original receipt/log changed')
            provider_after = regular_file(PROVIDER)
            require(provider_after == provider_before, 'provider changed during cleanup')
            require(siblings() == protected, 'non-target sibling identity changed')
            source_after = {'head': command(['git', 'rev-parse', 'HEAD'], REPO).strip(),
                            'status': command(['git', 'status', '--porcelain=v1'], REPO)}
            require(source_after == source_before, 'repo identity changed during cleanup')
            compressed_meta = regular_file(COMPRESSED)
            manifest = {'schema': 'trnm-failed-target-cleanup-archive-v1', 'scope': 'failure evidence only',
                        'cleanup_key': KEY, 'original_build_log': log_meta,
                        'compressed_build_log': compressed_meta, 'receipts': receipt_rows,
                        'libtest_artifacts_metadata_only': artifacts, 'acceptance_granted': False}
            with MANIFEST.open('x') as output:
                json.dump(manifest, output, sort_keys=True, indent=2)
                output.write('\n')
                output.flush()
                os.fsync(output.fileno())
            final = system_state()
            record('complete', target_absent=True, system_after=final,
                   observed_disk_free_delta_bytes=final['disk_free_bytes'] - before['disk_free_bytes'],
                   source_after=source_after, original_provider_preserved=True,
                   original_receipts_and_log_preserved=True, compressed_log=compressed_meta,
                   archive_manifest=regular_file(MANIFEST), acceptance_granted=False)
            summary = {'status': 'completed', 'cleanup_key': KEY,
                       'target': str(TARGET), 'target_inventory': target_inventory,
                       'disk_free_before_bytes': before['disk_free_bytes'],
                       'disk_free_after_bytes': final['disk_free_bytes'],
                       'disk_free_delta_bytes': final['disk_free_bytes'] - before['disk_free_bytes'],
                       'compressed_log': compressed_meta, 'archive_manifest': regular_file(MANIFEST),
                       'source_before': source_before, 'source_after': source_after,
                       'acceptance_granted': False}
        except BaseException as error:
            try:
                record('failed', error_type=type(error).__name__, error=str(error),
                       target_present=os.path.lexists(TARGET))
            finally:
                raise
    summary['ledger'] = regular_file(LEDGER)
    print(json.dumps(summary, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
