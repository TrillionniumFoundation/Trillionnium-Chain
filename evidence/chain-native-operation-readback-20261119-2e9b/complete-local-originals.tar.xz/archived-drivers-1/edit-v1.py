from pathlib import Path
import json,subprocess,sys,time,hashlib,resource
base=Path('/home/qq/work/chain-native-operation-readback-20261119-2e9b');src=base/'source';e=base/'completed-graph-edit-1';e.mkdir(exist_ok=False)
v=json.loads((base/'completed-graph-edit-payload-1.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip()==v['base']
with (e/'preflight.stdout').open('xb') as out,(e/'preflight.stderr').open('xb') as err:
 r=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=src,stdout=out,stderr=err)
assert r.returncode==0
assert json.loads((base/'original-repeat-control-1/RESULT.json').read_text())['native_exit_code']==101
olderr=(base/'original-repeat-control-1/original-production-repeat.stderr').read_text()
assert 'full=140 first=44 repeated=44 actual_graphs=3' in olderr
files=v['files'];rp=v['replace'];p=src/rp['path'];before=p.read_text();assert before.count(rp['old'])==1
files.append({'path':rp['path'],'old':before,'text':before.replace(rp['old'],rp['text'])})
for f in files:assert (src/f['path']).read_text()==f['old'],f['path']
for f in files:(src/f['path']).write_text(f['text'])
env=dict(__import__('os').environ);env['PATH']='/home/qq/.cargo/bin:'+env['PATH']
with (e/'fmt.stdout').open('xb') as out,(e/'fmt.stderr').open('xb') as err:
 r=subprocess.run(['/home/qq/.cargo/bin/cargo','+1.95.0','fmt','--manifest-path','trillionnium/Cargo.toml','--all'],cwd=src,stdout=out,stderr=err,env=env)
assert r.returncode==0
diff=subprocess.check_output(['git','diff','--binary'],cwd=src);(e/'candidate.patch').write_bytes(diff)
prod=subprocess.check_output(['git','diff','--binary','--','trillionnium/crates/trnm-pon-node/src/store/native_authenticated.rs','trillionnium/crates/trnm-pon-node/src/store/native_authenticated/post_write_readback.rs','trillionnium/crates/trnm-pon-node/src/account_archive_prototype/native_scoped_readback.rs'],cwd=src);(e/'production.patch').write_bytes(prod)
rows=[]
for f in files:
 b=(src/f['path']).read_bytes();rows.append({'path':f['path'],'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
res={'schema':'chain-completed-graph-edit-v1','base':v['base'],'files':rows,'patch_bytes':len(diff),'patch_sha256':hashlib.sha256(diff).hexdigest(),'production_patch_bytes':len(prod),'production_patch_sha256':hashlib.sha256(prod).hexdigest(),'preflight_exit':0,'format_exit':0,'original_failure_preserved':True,'scope_slots':4,'source_frontier_slots':16,'no_budget_or_workflow_or_time_changes':True}
(e/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res),flush=True)
