from pathlib import Path
import json, re, sys
prefix, selector, output = sys.argv[1:]
if prefix not in ("native-storage", "native-storage-component"):
    raise SystemExit("invalid native artifact prefix")
if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)*", selector) is None:
    raise SystemExit("invalid ASCII Rust selector")
# Identifiers contain no hyphen; '-' reverses to '::'. The '--'
# prefix boundary cannot occur in a nonempty encoded Rust path.
label = prefix + "--" + selector.replace("::", "-")
record = {"schema": "trnm-native-selector-artifact-v1",
          "prefix": prefix, "selector": selector, "label": label}
with (Path(output) / (label + ".selector.json")).open("x", encoding="utf-8") as stream:
    json.dump(record, stream, sort_keys=True)
    stream.write("\n")
print(label)
