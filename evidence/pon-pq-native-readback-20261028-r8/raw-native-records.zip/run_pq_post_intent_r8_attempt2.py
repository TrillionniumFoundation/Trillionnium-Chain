#!/usr/bin/env python3
"""Bounded exact synthetic PQ regression using a settled process-tree guard.

Only an ephemeral Node and loopback TCP listener are used. This is a new scoped
baseline, not a restart of the previously interrupted broad PQ qualification.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/scratch/56818e4fba76/chain-recovered')
GUARD = Path('/tmp/w1-batch-phase0-guard-20261028-r8.py')
SELECTOR = 'ingress::pq_network::tests::post_intent_cancellation::actual_pq_deadline_after_intent_preserves_owner_nonce_and_other_peer_service'
EXPECTED_GUARD = '9981c3a138c4aefb6c4662f1e2c4c05cf5ef26e302c46763a42a2366a6334217'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 ** 2), b''):
            h.update(block)
    return h.hexdigest()


def source_identity():
    paths = subprocess.check_output(['git', 'ls-files', '-z', '--', 'trillionnium', 'formal/pon-nakamoto-v1'], cwd=ROOT).decode().split('\0')
    return {'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'files': {p: sha(ROOT/p) for p in sorted(paths) if p and Path(p).suffix in ('.rs', '.py', '.toml', '.lock', '.json')}}


parser = argparse.ArgumentParser()
parser.add_argument('label', choices=['baseline-attempt2'])
args = parser.parse_args()
out = Path(__file__).resolve().parent / ('pq-post-intent-' + args.label)
out.mkdir(exist_ok=False)
preflight = subprocess.run(['bash', 'scripts/project-preflight.sh'], cwd=ROOT, capture_output=True)
(out/'preflight.stdout').write_bytes(preflight.stdout)
(out/'preflight.stderr').write_bytes(preflight.stderr)
assert preflight.returncode == 0
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
assert sha(GUARD) == EXPECTED_GUARD
before = source_identity()
(out/'source-before.json').write_text(json.dumps(before, indent=2)+'\n')
prefix = Path('/tmp/pure-pon-openssl-3.5.9')
cli = prefix/'bin/openssl'
assert sha(cli) == '0f9db29e103b1c7da08c7fe45ae47f84a0e9c388775520114598646a9041867f'
env = dict(os.environ, PATH='/tmp/pure-pon-toolchain-20261027/bin:'+os.environ['PATH'],
           CARGO_HOME='/tmp/pure-pon-cargo-20261027', CARGO_TARGET_DIR='/tmp/chain-pq-target-56818e4fba76',
           CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_NET_OFFLINE='true',
           OPENSSL_DIR=str(prefix), OPENSSL_STATIC='1', TRNM_PQ_OPENSSL=str(cli),
           TRNM_PQ_OPENSSL_SHA256=sha(cli), TRNM_PQ_OPENSSL_VERSION='3.5.9',
           OPENSSL_CONF='/dev/null', OPENSSL_MODULES=str(prefix/'lib64/ossl-modules'))
argv = ['cargo', 'test', '--manifest-path', 'trillionnium/Cargo.toml', '--locked', '--offline',
        '-p', 'trnm-pon-node', '--lib', '--features', 'pq-native-openssl', SELECTOR,
        '--', '--exact', '--nocapture', '--test-threads=1']
limits = {'wall_seconds': 600, 'cpu_seconds': 800, 'rss_bytes': 2684354560,
          'target_growth_bytes': 805306368, 'min_free_bytes': 1073741824}
intent = {'schema': 'pon-r8-real-pq-post-intent-v1', 'label': args.label,
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'argv': argv, 'limits': limits, 'guard_sha256': EXPECTED_GUARD,
          'expected_selected_tests': 1, 'expected_baseline': 'actual liveness failure, not compile failure',
          'planned_signed_calls': 5, 'planned_honest_followups': 3,
          'synthetic_ephemeral_state_only': True, 'loopback_only': True,
          'external_network': False, 'deployed_keys_or_state': False,
          'whole_chain_pq_acceptance': False, 'paid_cpu_or_physical_kill_acceptance': False,
          'earlier_interruption_preserved': True,
          'backend': {k: env[k] for k in ('OPENSSL_DIR', 'OPENSSL_STATIC', 'TRNM_PQ_OPENSSL',
                       'TRNM_PQ_OPENSSL_SHA256', 'TRNM_PQ_OPENSSL_VERSION', 'OPENSSL_CONF', 'OPENSSL_MODULES')}}
prior_path = out.parent/'pq-post-intent-baseline/result.json'
prior = json.loads(prior_path.read_text())
intent['runner_sha256'] = sha(Path(__file__))
intent['previous_attempt'] = {'path': str(prior_path), 'sha256': sha(prior_path), 'status': prior['guard']['status'], 'wall_seconds': prior['guard']['elapsed_seconds'], 'cpu_seconds': prior['guard']['cpu_peak_seconds'], 'selected_tests': prior['test_result'], 'reason_for_new_attempt': 'Test-only serde_json macro syntax correction; no production fix or observed liveness counterexample in attempt1.'}
(out/'intent.json').write_text(json.dumps(intent, indent=2)+'\n')
guard_argv = ['python3', str(GUARD), '--out', str(out/'guard'),
              '--target', env['CARGO_TARGET_DIR']]
for key, value in limits.items():
    guard_argv += ['--'+key.replace('_', '-'), str(value)]
guard_argv += ['--'] + argv
result = subprocess.run(guard_argv, cwd=ROOT, env=env, capture_output=True)
(out/'supervisor.stdout').write_bytes(result.stdout)
(out/'supervisor.stderr').write_bytes(result.stderr)
after = source_identity()
(out/'source-after.json').write_text(json.dumps(after, indent=2)+'\n')
guard = json.loads((out/'guard/result.json').read_text())
stdout = (out/'guard/stdout.log').read_text()
observations = []
for line in stdout.splitlines():
    if line.startswith('{'):
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if row.get('schema') == 'pq-post-intent-native-observation-v1':
            observations.append(row)
denominator = re.search(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout)
record = {'intent': intent, 'guard': guard, 'source_unchanged': before == after,
          'test_result': None if denominator is None else {'status': denominator[1], 'passed': int(denominator[2]), 'failed': int(denominator[3]), 'ignored': int(denominator[4])},
          'full_observation_records': len(observations),
          'observations': observations,
          'log_files': {str(p.relative_to(out)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in (out/'guard/stdout.log', out/'guard/stderr.log')},
          'supervisor_returncode': result.returncode,
          'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'result.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({k: v for k, v in record.items() if k not in ('intent', 'observations')}, indent=2))
raise SystemExit(result.returncode)
