import pathlib,subprocess,hashlib,json,time,resource,tarfile,shutil,sys,stat,os
s=pathlib.Path('/home/qq/chain-host-stat-20261118-2e9b-source');v=pathlib.Path('/home/qq/chain-native-root-body-delay-20261118-2e9b-validation');b=pathlib.Path('/home/qq/work/chain-prepaid-d952-original-control-20261119-2e9b');out=pathlib.Path('/home/qq/work/chain-native-root-body-delay-publication-20261119-2e9b')
assert not out.exists();out.mkdir();data=json.loads(sys.argv[1]);start=time.monotonic();started_ns=time.time_ns();usage0=resource.getrusage(resource.RUSAGE_SELF)
repro=out/'reproduction';repro.mkdir()
for name,code in data['drivers'].items():assert '/' not in name;(repro/name).write_text(code)
(repro/'archive_owner.py').write_text(sys.argv[2]);(repro/'archive_payload.json').write_text(json.dumps(data,indent=2)+'\n')
pre=subprocess.run(['bash','scripts/project-preflight.sh'],cwd=s,capture_output=True);(out/'preflight.stdout').write_bytes(pre.stdout);(out/'preflight.stderr').write_bytes(pre.stderr);assert pre.returncode==0
plan=s/'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md';blob=lambda raw:hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
assert blob(plan.read_bytes())=='efc7fbc5831f03960808596fc1e71799b889bfc0'
(out/'plan-before.md').write_bytes(plan.read_bytes());plan.write_text(plan.read_text()+data['plan_append'])
cpath=s/'config/pon/pq-cross-branch-corpus-v1.json';c=json.loads(cpath.read_text());plan_rel=str(plan.relative_to(s));plan_pinned=plan_rel in c['pinned_blobs']
if plan_pinned:c['pinned_blobs'][plan_rel]=blob(plan.read_bytes());cpath.write_text(json.dumps(c,indent=2,sort_keys=True)+'\n')
stages=[]
for name,args in [('ci-contract',['python3','-B','scripts/ci/check_ci_contract.py']),('pq-exact-source',['python3','-B','scripts/ci/check_pq_research_integration.py'])]:
 t=time.monotonic();ru=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:r=subprocess.run(args,cwd=s,stdout=so,stderr=se,timeout=1800)
 ra=resource.getrusage(resource.RUSAGE_CHILDREN);stages.append({'name':name,'command':args,'returncode':r.returncode,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':ra.ru_utime-ru.ru_utime,'child_system_cpu_seconds':ra.ru_stime-ru.ru_stime});assert r.returncode==0,stages[-1]
sources=[]
for rel in data['source_paths']:
 p=s/rel;raw=p.read_bytes();dest=out/'frozen-source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);sources.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'git_blob':blob(raw)})
(out/'FROZEN_SOURCE.json').write_text(json.dumps({'schema':'chain-native-root-body-delay-frozen-source-v1','base_commit':'8d8e50e4256c1f4a5e0bcaa6dfb4d0e19eb5510f','base_tree':'4b45692a1c356dad66aa8076e59a382085427e4e','only_listed_files_overlay_base':True,'execution_checkout_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'qualification':False,'f0_run':'NOT_RUN','plan_pinned':plan_pinned,'source_files':sources,'source_gate_stages':stages},indent=2)+'\n')
members=[]
for p in sorted(v.rglob('*')):
 if p.is_file():members.append((p,'validation/'+str(p.relative_to(v))))
 elif not p.is_dir():raise RuntimeError('nonregular validation object: '+str(p))
for directory in ['evidence','evidence-2','evidence-full-public-1']:
 for p in sorted((b/directory).rglob('*')):
  if p.is_file():members.append((p,'d952-original-control/'+directory+'/'+str(p.relative_to(b/directory))))
  elif not p.is_dir():raise RuntimeError('nonregular original object: '+str(p))
for p in sorted(out.rglob('*')):
 if p.is_file():members.append((p,'publication/'+str(p.relative_to(out))))
inventory=[]
for p,rel in members:
 st=p.lstat();assert stat.S_ISREG(st.st_mode) and not p.is_symlink();raw=p.read_bytes();st2=p.lstat();assert(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)==(st2.st_dev,st2.st_ino,st2.st_size,st2.st_mtime_ns)
 inventory.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
index={'schema':'chain-complete-native-root-delay-pre-f0-archive-v1','created_ns':str(time.time_ns()),'complete_validation_root':str(v),'complete_original_control_evidence':['evidence','evidence-2','evidence-full-public-1'],'excluded_original_build_cache_and_git_checkout':True,'files':inventory,'all_original_validation_files_retained':True,'native_all_green':False,'full_physical_cost_closed':False,'f0_qualified':False}
(out/'ARCHIVE_INDEX.json').write_text(json.dumps(index,indent=2)+'\n');members.append((out/'ARCHIVE_INDEX.json','ARCHIVE_INDEX.json'))
archive=out/'complete-pre-f0-validation.tar.xz'
with tarfile.open(archive,'x:xz',preset=6) as tf:
 for p,rel in members:tf.add(p,arcname=rel,recursive=False)
with tarfile.open(archive,'r:xz') as tf:
 got=tf.getmembers();assert len(got)==len(members)
 for row in inventory:
  raw=tf.extractfile(row['path']).read();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
ru=resource.getrusage(resource.RUSAGE_SELF)
result={'schema':'chain-native-root-delay-pre-f0-publication-receipt-v1','started_ns':str(started_ns),'finished_ns':str(time.time_ns()),'archive_members':len(members),'original_validation_files':sum(1 for _,rel in members if rel.startswith('validation/')),'archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'archive_index':{'file':'ARCHIVE_INDEX.json','bytes':(out/'ARCHIVE_INDEX.json').stat().st_size,'sha256':hashlib.sha256((out/'ARCHIVE_INDEX.json').read_bytes()).hexdigest()},'frozen_source':sources,'archive_all_members_readback_verified':True,'wall_seconds':time.monotonic()-start,'self_user_cpu_seconds':ru.ru_utime-usage0.ru_utime,'self_system_cpu_seconds':ru.ru_stime-usage0.ru_stime,'full_physical_cost_closed':False,'native_all_green':False,'f0_qualified':False}
(out/'PUBLICATION_RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
