import hashlib,json,lzma,os,sys,tarfile,time
from pathlib import Path
ROOT=Path("/tmp/trnm-continuity-original-20261116-jvd8w4er")
SOURCE=Path("/tmp/trnm-continuity-recovery-20261116-1b30xc0r/continuity-native-v3-original-bundle.tar.xz")
def require(ok,msg):
 if not ok:raise ValueError(msg)
def sha(raw):return hashlib.sha256(raw).hexdigest()
(ROOT/"launch_v3_after_journal_admission.py").write_text(sys.orig_argv[sys.orig_argv.index("-c")+1])
require(sha(SOURCE.read_bytes())=="e369ca94f46f70956e32774ce5e4246ac31000836e80011e5ffebd06f93dd4b6","Immutable native bundle changed")
with tarfile.open(SOURCE,"r:xz") as t:
 raw_comparison=t.extractfile("bundle/native-comparison.json").read()
 comparison=json.loads(raw_comparison)
 report=json.loads(t.extractfile("bundle/native-report.json").read())
 raw_controls=lzma.decompress(t.extractfile("bundle/control-records.jsonl.xz").read(),memlimit=64<<20)
 raw_matches=lzma.decompress(t.extractfile("bundle/comparison-records.jsonl.xz").read(),memlimit=64<<20)
 context_report=json.loads(t.extractfile("bundle/context-report.json").read())
 build=json.loads(t.extractfile("bundle/build.json").read())
require(build==comparison["build"]==report["build"],"Final complete build receipts differ")
require(report["status"]=="NATIVE_PASS_ORIGINAL_NOT_RUN" and report["control_count"]==659 and report["semantic_cases"]==572 and report["source_inputs_stable"] is True,"Complete native status")
require(report["contexts"]==comparison["contexts"] and len(comparison["contexts"])==4,"Four actual native contexts")
lines=raw_controls.splitlines(keepends=True);require(len(lines)==len(report["controls"])==659,"Complete native control index")
offset=0
for index,(raw,row) in enumerate(zip(lines,report["controls"],strict=True)):
 actual=json.loads(raw);ref=row["complete_record"]
 require(ref["record"]==index and ref["offset"]==offset and ref["bytes"]==len(raw) and ref["sha256"]==sha(raw),"Actual control journal pointer/hash")
 require(actual["name"]==row["name"] and actual["status"]==row["status"]=="PASS","Actual control/journal status")
 offset+=len(raw)
matches=[json.loads(line) for line in raw_matches.splitlines()]
require(matches==comparison["cases"] and len(matches)==572,"Complete native comparison values differ from full actual journal")
admission={"schema":"trnm.hia.continuity-v3-complete-native-journal-admission.v1","status":"PASS_ORIGINAL_ABOUT_TO_RUN","source_set_sha256":build["source_set_sha256"],"actual_control_records":659,"actual_semantic_records":572,"complete_control_index_recomputed":True,"complete_comparison_journal_equals_bundle":True,"actual_contexts":comparison["contexts"],"build_matches_report_and_comparison":True,"context_report_keys":list(context_report),"comparison_sha256":sha(raw_comparison),"checked_unix_ns":time.time_ns()}
(ROOT/"complete-journal-admission.json").write_text(json.dumps(admission,sort_keys=True,indent=2)+"\n")
print(json.dumps({"status":admission["status"],"native_controls":659,"semantic_cases":572,"comparison_sha256":admission["comparison_sha256"]}),flush=True)
driver=ROOT/"desktop_run_continuity_v1.py"
require(sha(driver.read_bytes())=="dacb15e8ca501d31a072c861c1850c967dd3f12a183a22f32c61ed5791a9ad6b","Private execution driver changed")
os.execv("/usr/bin/python3",["/usr/bin/python3","-B",str(driver),"--package-sha256","e369ca94f46f70956e32774ce5e4246ac31000836e80011e5ffebd06f93dd4b6","--package-bytes","2655516","--comparison-sha256","d9fa9bbe83eb4676a6cba0f02af0276f2128dae29179b46f570f9c15724bb5c4","--source-count","61","--owned-count","18","--typed-count","13","--case-count","572"])
