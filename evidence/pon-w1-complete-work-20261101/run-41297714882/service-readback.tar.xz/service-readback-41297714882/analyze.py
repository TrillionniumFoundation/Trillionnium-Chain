#!/usr/bin/env python3
"""Read-only, source-pinned failure analysis of run 41297714882 service captures.

No native execution, work verification, timing authentication, or acceptance is
claimed. Failed outcomes stay failed; the original validator is not patched.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import struct
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SOURCE = HERE / 'source'
sys.path.insert(0, str(SOURCE / 'scripts/ci'))
import run_w1_fresh_service_v1 as runner
import run_from_zero_native as native

RUN = 41297714882
HEAD = 'e885a4a284d83019077c9b8f3420d39988a11eef'
MERGE = '48b7a10a9950278815cfa002a3369a5763329944'
ARTIFACTS = [('13079922394', 'head', HEAD), ('13079843691', 'prospective-merge', MERGE)]
WINDOW = 4_000_000_000
Q = (1 << 32) - 5
ALL_CHECKS = 0


def check(value, label):
    global ALL_CHECKS
    ALL_CHECKS += 1
    if not value:
        raise AssertionError(label)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    return native.json_load(path.read_bytes())


def failure(call):
    try:
        result = call()
    except (ValueError, KeyError, TypeError, OSError) as exc:
        return {'outcome': 'rejected', 'type': type(exc).__name__, 'failure': str(exc)}
    return {'outcome': 'accepted', 'result': result}


def count_strings(values):
    return dict(sorted(Counter(str(x) for x in values).items()))


def compact_call(row):
    keys = ('packet_index', 'height', 'status', 'error', 'started_ns', 'ended_ns',
            'elapsed_wall_ns', 'client_thread_cpu_ns', 'deadline_ms',
            'returned_after_deadline', 'returned_after_window', 'metrics')
    result = {key: row[key] for key in keys if key in row}
    response = row.get('response')
    if isinstance(response, dict):
        value = response.get('value')
        if isinstance(value, dict):
            result['response_scalars'] = {k: v for k, v in value.items() if not isinstance(v, (dict, list))}
            if 'packets' in value:
                result['response_packet_sha256'] = [digest(bytes.fromhex(x)) for x in value['packets']]
                result['response_packet_count'] = len(value['packets'])
    return result


def database(path, packets, genesis):
    connection = sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True)
    check(connection.execute('PRAGMA integrity_check').fetchall() == [('ok',)], 'SQLITE_INTEGRITY')
    active = connection.execute('SELECT b.height, a.tip, a.generation, a.state_slot, b.chainwork, b.state_root FROM active a JOIN blocks b ON a.tip=b.id').fetchone()
    blocks = connection.execute('SELECT height,id,packet,parent FROM blocks ORDER BY height').fetchall()
    check(active is not None and blocks, 'SQLITE_ACTIVE_AND_BLOCKS')
    for height, block, packet, parent in blocks:
        if height == 0:
            check(block.hex() == genesis and packet is None, 'SQLITE_GENESIS')
        else:
            check(1 <= height <= len(packets) and packet.hex() == packets[height - 1], 'SQLITE_ONLY_EXACT_HONEST_PACKETS')
            header, _, block_id = native.ConfirmationReportChecks.packet_metadata(packet.hex())
            check(block_id == block and header['parent'] == parent, 'SQLITE_PACKET_ID')
    reorg = [dict(zip(('generation', 'old_slot', 'outcome', 'cancelled_cursor', 'reason'), row))
             for row in connection.execute('SELECT generation,old_slot,outcome,cancelled_cursor,reason FROM reorg_lifecycle_v1')]
    metadata = {name: {'bytes': len(raw), 'sha256': digest(raw), 'hex': raw.hex()}
                for name, raw in connection.execute("SELECT key,value FROM metadata WHERE key LIKE '%epoch%' OR key LIKE '%cpu%'")}
    slots = {slot: [(key, raw.hex()) for key, raw in connection.execute('SELECT key,value FROM kv WHERE slot=? ORDER BY key', (slot,))]
             for slot, in connection.execute('SELECT DISTINCT slot FROM kv')}
    active_state = slots.get(active[3], [])
    connection.close()
    return {'sha256': digest(path.read_bytes()), 'active_height': active[0], 'active_tip': active[1].hex(),
            'generation': active[2], 'state_slot': active[3], 'active_chainwork': active[4].hex(),
            'active_state_root': active[5].hex(), 'active_state_rows': len(active_state),
            'active_state_rows_sha256': digest(json.dumps(active_state, separators=(',', ':')).encode()),
            'stored_heights': [row[0] for row in blocks], 'stored_max_height': max(row[0] for row in blocks),
            'reorg_lifecycle': reorg, 'resource_epoch_metadata': metadata,
            'all_stored_non_genesis_packets_equal_expected_honest_prefix': True}


def construction(con, context):
    header_bytes = bytes.fromhex(con['header'])
    header = native.header_decode(header_bytes)
    challenge = native.H('challenge', header_bytes)
    check(con['challenge'] == challenge.hex(), 'CONSTRUCTION_CHALLENGE')
    for key in ('target', 'work_task', 'network', 'parameters'):
        check(header[key].hex() == context['task' if key == 'work_task' else key], 'CONSTRUCTION_CONTEXT')
    check(header['parent'].hex() == context['genesis'] and header['height'] == 1, 'CONSTRUCTION_PARENT')
    check(con['attempt_budget'] == 4096 and con['setup_calls'] == 1, 'CONSTRUCTION_BUDGET')
    attempts = con['attempts']
    check(0 < len(attempts) <= 4096, 'TRIAL_COUNT')
    for i, trial in enumerate(attempts):
        trace = native.H('public-v3-from-zero-v1', challenge, struct.pack('<Q', i))
        ticket = native.H('ticket', challenge, trace)
        hit = ticket <= bytes.fromhex(context['target'])
        check(trial == {'nonce': i, 'trace': trace.hex(), 'ticket': ticket.hex(), 'target_hit': hit}, 'EXACT_TRIAL')
        check(not hit or i + 1 == len(attempts), 'FIRST_TICKET_HIT')
    hit = attempts[-1]['target_hit']
    check(con['status'] == ('target_hit_unverified' if hit else 'exhausted'), 'CONSTRUCTION_OUTCOME')
    check(con['winner_nonce'] == (len(attempts) - 1 if hit else None), 'CONSTRUCTION_WINNER')
    nested = sum(con[k] for k in ('setup_cpu_ns', 'search_cpu_ns', 'packet_encoding_cpu_ns'))
    check(nested <= con['attacker_cpu_ns'], 'CONSTRUCTION_CPU_CONTAINMENT')
    a = b''.join(struct.pack('<I', i % 31) for i in range(4096))
    b = b''.join(struct.pack('<I', (i * 7) % 37) for i in range(4096))
    check(native.H('task', a, b).hex() == context['task'], 'MAINTENANCE_TASK')
    packet = header_bytes + bytes(2) + b'PNW1' + a + b + bytes(16384) + bytes.fromhex(attempts[-1]['trace']) if hit else None
    if 'packet' in con:
        check(con['packet'] == (packet.hex() if hit else None), 'EXACT_ORIGINAL_CONSTRUCTION')
    else:
        check(con['packet_digest'] == (native.H('fresh-challenge-attack-packet-v1', packet).hex() if hit else None), 'EXACT_FRESH_CONSTRUCTION')
    return header, packet, len(attempts), challenge.hex()


def phase_report(phase, doc, mode, dbroot, metadata, constructions):
    check(phase['requested_window_ns'] == WINDOW and phase['workers'] in (0, 16), 'ORIGINAL_PHASE_BUDGET')
    pressured = phase['workers'] == 16
    packets = doc['signed_honest_packets']
    calls = []
    construction_count = 0
    attempts = 0
    challenges = set()
    packet_indices = set()
    nested_cpu = 0
    worker_summary = []
    for worker_index, worker in enumerate(phase['attacks']):
        check(worker['worker'] == worker_index and worker['attempt_cap_reached'] is False and len(worker['calls']) < 1024, 'WORKER_BOUNDS')
        prior = 0
        worker_construction_cpu = 0
        worker_call_cpu = 0
        for ordinal, row in enumerate(worker['calls']):
            if mode == 'fresh':
                con = row['from_zero_construction']
                header, packet, tried, challenge = construction(con, doc)
                index = ordinal * 16 + worker_index
                check(row['packet_index'] == index and header['nonce'] == 200_000 + index, 'FRESH_INDEX_NONCE')
                check(index not in packet_indices and challenge not in challenges, 'FRESH_UNIQUE')
                packet_indices.add(index)
                challenges.add(challenge)
                construction_count += 1
                attempts += tried
                worker_construction_cpu += con['attacker_cpu_ns']
            else:
                check(row['packet_index'] == worker_index, 'REPEATED_INDEX')
                _, packet, _, challenge = constructions[worker_index]
                challenges.add(challenge)
                packet_indices.add(worker_index)
            if row['status'] == 'not_submitted_exhausted':
                check(packet is None, 'EXHAUSTION_RETAINED')
                continue
            native.ConfirmationReportChecks.call(row, WINDOW)
            native.ConfirmationReportChecks.compact_request(row, {'op': 'submit', 'packet': packet.hex()}, row['packet_index'])
            check(prior <= row['started_ns'] and row['status'] != 'ok', 'NO_ATTACK_ACCEPTED')
            prior = row['ended_ns']
            worker_call_cpu += row['client_thread_cpu_ns']
            calls.append(row)
        check(worker_construction_cpu + worker_call_cpu <= worker['calling_thread_cpu_ns'], 'WORKER_CPU_CONTAINMENT')
        nested_cpu += worker_construction_cpu
        worker_summary.append({'worker': worker_index, 'calls': len(worker['calls']), 'calling_thread_cpu_ns': worker['calling_thread_cpu_ns'], 'nested_construction_cpu_ns': worker_construction_cpu, 'nested_client_call_cpu_ns': worker_call_cpu})
    check(sum(w['calling_thread_cpu_ns'] for w in phase['attacks']) == phase['attacker_workers_cpu_ns'], 'ATTACKER_CPU_SUM')
    submits = phase['honest_submissions']
    acknowledged = []
    prior = phase['business_started_ns']
    for row in submits:
        ontime = native.ConfirmationReportChecks.call(row, WINDOW)
        index = row['packet_index']
        check(row['height'] == index + 1 and prior <= row['started_ns'], 'SUBMIT_CHRONOLOGY')
        native.ConfirmationReportChecks.compact_request(row, {'op': 'submit', 'packet': packets[index]}, index)
        if ontime:
            acknowledged.append(index + 1)
        prior = row['ended_ns']
    check(acknowledged == list(range(1, 8)), 'ALL_SEVEN_ACTUAL_ACKS')
    history = phase['honest_history']
    fetched = []
    after = doc['genesis']
    tip = metadata[-1][2].hex()
    for row in history:
        ontime = native.ConfirmationReportChecks.call(row, WINDOW)
        check(prior <= row['started_ns'], 'HISTORY_CHRONOLOGY')
        check(row['request'] == {'op': 'history', 'tip': tip, 'after': after}, 'HISTORY_REQUEST')
        prior = row['ended_ns']
        if ontime:
            page = row['response']['value']
            chunk = page['packets']
            check(page['after'] == after and page['tip'] == tip and chunk, 'HISTORY_PAGE')
            check(chunk == packets[len(fetched):len(fetched) + len(chunk)], 'HISTORY_EXACT_PREFIX')
            fetched.extend(chunk)
            after = native.ConfirmationReportChecks.packet_metadata(chunk[-1])[2].hex()
            check(page['next'] == after and page['complete'] is (after == tip), 'HISTORY_CURSOR')
    successful_heads = []
    for row in phase['honest_heads']:
        ontime = native.ConfirmationReportChecks.call(row, WINDOW)
        native.ConfirmationReportChecks.compact_request(row, {'op': 'head'}, None)
        if ontime:
            successful_heads.append(row)
    check(len(successful_heads) == phase['honest_head_successes_in_window'], 'READ_SUCCESS_COUNT')
    metrics = phase['service']['metrics']
    check(phase['service']['error'] is None, 'NO_SERVICE_PROCESS_ERROR')
    check(metrics['work_started'] == metrics['work_finished'], 'WORK_CLOSED')
    check(metrics['mutation_cpu_charged_ns'] == metrics['mutation_full_work_cpu_ns'] + metrics['mutation_dispatch_excluding_work_cpu_ns'], 'CPU_DISJOINT_SUM')
    check(metrics['mutation_cpu_clock_failures'] == 0 and metrics['mutation_cpu_in_flight_after_shutdown'] == 0, 'CPU_ACCOUNTING_CLOSED')
    observed = phase['observations']
    native.observer_cpu_scope(observed)
    records = observed['records']
    check(observed['accepted_connections_seen'] == len(records) == metrics['accepted_connections'], 'ALL_CONNECTIONS_RETAINED')
    check(observed['records_not_retained'] == observed['measurement_failures'] == 0 and observed['counter_overflow'] is False, 'OBSERVATION_COVERAGE')
    check(all(r['complete'] and not r['observation_failed'] for r in records), 'RECORDS_COMPLETE')
    check(sum(r['full_work_started'] for r in records) == metrics['work_started'], 'OBSERVED_WORK_COUNT')
    check(sum(r['full_work_started'] and r['full_work_accepted'] is False for r in records) == metrics['work_failed'], 'OBSERVED_FAILURE_COUNT')
    check(sum(r['full_work_thread_cpu_ns'] or 0 for r in records) == metrics['mutation_full_work_cpu_ns'], 'OBSERVED_WORK_CPU')
    grouped = defaultdict(lambda: {'records': 0, 'work_started': 0, 'work_cpu_ns': 0, 'dispatch_cpu_ns': 0, 'submit_phase_cpu_ns': Counter(), 'submit_phase_wall_ns': Counter()})
    for record in records:
        group = 'accepted-complete-work' if record['full_work_accepted'] is True else 'failed-or-cancelled-work' if record['full_work_started'] else 'no-full-work'
        item = grouped[group]
        item['records'] += 1
        item['work_started'] += int(record['full_work_started'])
        item['work_cpu_ns'] += record['full_work_thread_cpu_ns'] or 0
        item['dispatch_cpu_ns'] += record['dispatch_thread_cpu_ns'] or 0
        for point in record['submit_phases']:
            item['submit_phase_cpu_ns'][point['phase']] += point['thread_cpu_ns'] or 0
            item['submit_phase_wall_ns'][point['phase']] += point['wall_ns'] or 0
    receiver = database(dbroot / 'receiver/native.sqlite', packets, doc['genesis'])
    independent = database(dbroot / 'independent-client/native.sqlite', packets, doc['genesis'])
    check(receiver['active_height'] == 7, 'RECEIVER_TRUE_SEVEN_BLOCKS')
    equal = receiver['active_tip'] == independent['active_tip'] and receiver['active_state_rows_sha256'] == independent['active_state_rows_sha256']
    check(equal is phase['full_native_state_equal'], 'FULL_STATE_EQUALITY_READBACK')
    if pressured:
        check(phase['client_confirmed_transactions'] == 0 and phase['independent_client_confirmation'] is None and phase['verification_errors'] == ['PUBLIC_REQUEST_DEADLINE'], 'ACTUAL_PRESSURE_DEADLINE')
    else:
        confirmed = phase['independent_client_confirmation']
        check(phase['client_confirmed_transactions'] == 1 and confirmed['confirmed'] and confirmed['depth'] == 6 and not confirmed['finalized'] and not confirmed['execution_authority'], 'ACTUAL_BASELINE_CONFIRMATION')
        check(phase['confirmation_ended_ns'] < WINDOW and independent['active_height'] == 7, 'BASELINE_IN_WINDOW')
    coverage = {'unique_challenges': len(challenges), 'unique_packet_indices': len(packet_indices), 'constructed_in_workers': construction_count, 'trial_count_in_workers': attempts, 'nested_construction_cpu_ns': nested_cpu}
    if mode == 'fresh' and pressured:
        c = doc['construction_coverage']
        check(c['constructed'] == c['submitted'] == len(calls) == construction_count and c['exhausted'] == 0, 'FRESH_COVERAGE_COUNTS')
        check(c['unique_challenges'] == len(challenges) and c['unique_packet_indices'] == len(packet_indices), 'FRESH_UNIQUE_COUNTS')
        check(c['nested_from_zero_construction_cpu_ns'] == nested_cpu, 'FRESH_NESTED_CPU')
        check(doc['attacker_setup_and_workers_cpu_ns'] == doc['shared_material_setup_cpu_ns'] + phase['attacker_workers_cpu_ns'], 'FRESH_TOTAL_CPU')
    replay_start = history[0]['started_ns'] if history else None
    intercall_spans = [history[i + 1]['started_ns'] - row['ended_ns'] for i, row in enumerate(history[:-1])]
    return {
        'mode': phase['mode'], 'requested_window_ns': WINDOW, 'workers': phase['workers'],
        'acknowledged_honest_heights': acknowledged, 'last_ack_ended_ns': submits[-1]['ended_ns'],
        'baseline_or_pressure_business_target_met': phase['finite_business_target_met'],
        'invariant_target_met': phase['invariant_target_met'], 'no_attack_accepted': phase['no_attack_accepted'],
        'confirmation': phase['independent_client_confirmation'], 'confirmation_ended_ns': phase['confirmation_ended_ns'],
        'client_confirmed_transactions': phase['client_confirmed_transactions'], 'verification_errors': phase['verification_errors'],
        'honest_submissions': [compact_call(x) for x in submits], 'honest_history': [compact_call(x) for x in history],
        'history_fetched_packet_count': len(fetched), 'history_fetched_prefix_after': after,
        'independent_replay_and_confirmation_cpu_ns': phase['independent_replay_and_confirmation_cpu_ns'],
        'independent_replay_and_confirmation_wall_ns': phase['independent_replay_and_confirmation_wall_ns'],
        'inter_history_call_span_ns': intercall_spans,
        'inter_history_call_scope': 'Includes native import plus local loop/JSON processing; not an isolated native replay timing.',
        'honest_head_requests': len(phase['honest_heads']), 'honest_head_successes_in_window': len(successful_heads),
        'maximum_honest_head_gap_ns': phase['maximum_honest_head_gap_ns'], 'reader_cpu_ns': phase['reader_cpu_ns'],
        'attack_calls': len(calls), 'attack_call_statuses': count_strings(row['status'] for row in calls),
        'attack_client_errors': count_strings(row['error'] for row in calls if row['error'] is not None),
        'attack_remote_refusals': count_strings(row['response']['value']['error'] for row in calls if row['status'] == 'refused'),
        'attack_returns_after_window': sum(row['returned_after_window'] for row in calls),
        'attacker_workers_cpu_ns': phase['attacker_workers_cpu_ns'], 'worker_measurements': worker_summary,
        'construction_coverage_recomputed': coverage,
        'initial_meter': phase['initial_meter'], 'final_meter': phase['final_meter'],
        'receiver_service_metrics': metrics, 'receiver_observation_group_totals': dict(grouped),
        'observation_scope': {key: value for key, value in observed.items() if key != 'records'},
        'receiver_sqlite': receiver, 'independent_client_sqlite': independent,
        'full_native_state_equal_readback': equal,
        'service_cpu_depletion_demonstrated': metrics['mutation_cpu_refusals'] > 0,
        'per_phase_host_cgroup_cpu_available': False,
    }


def work_check_counts(packets):
    result = []
    for packet in packets:
        header = bytes.fromhex(packet)[:318]
        challenge = native.H('challenge', header)
        noise = []
        for label in range(4):
            values = 0
            counter = 0
            while values < 512:
                values += sum(x < Q for x in struct.unpack('<8I', native.H('noise', challenge, bytes([label]), struct.pack('<I', counter))))
                counter += 1
            noise.append(counter)
        points = 3 + sum(noise) + 328 + 512
        sparse = 3 + sum((n + 31) // 32 for n in noise) + 11 + 8
        result.append({'challenge': challenge.hex(), 'noise_callbacks_by_label': noise,
                       'all_w1_callbacks': points, 'additional_sparse_host_checks': sparse,
                       'minimum_physical_host_checks_inside_complete_w1_callback_path': points + sparse,
                       'minimum_file_content_reads_at_seven_per_host_check': (points + sparse) * 7})
    return result


def artifact(aid, lane, commit):
    base = ROOT / 'ci-captures' / f'run-{RUN}' / aid
    capture = base / 'fresh-service'
    manifest = read_json(capture / 'manifest.json')
    before = read_json(base / 'source-before.json')
    after = read_json(base / 'source-after.json')
    check(before == after and before['tested_commit'] == commit and before['tracked_worktree_verified'], 'SOURCE_IDENTITY')
    check(before['tested_tree'] == '92e722c38ad4daa206be3d4dfd57d6955c580551', 'SOURCE_TREE')
    check(manifest['source_expected'] == commit and manifest['source_before'] == manifest['source_after'], 'NESTED_SOURCE_IDENTITY')
    check(manifest['source_before']['commit'] == commit and manifest['source_before']['tree'] == before['tested_tree'], 'NESTED_COMMIT_AND_TREE')
    check(manifest['source_before']['test_sha256'] == digest((SOURCE / 'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero.rs').read_bytes()), 'PINNED_NATIVE_TEST_SOURCE')
    inventory = []
    for p in sorted(base.rglob('*')):
        if not p.is_file():
            continue
        raw = p.read_bytes()
        rel = str(p.relative_to(base))
        check(not p.is_symlink(), 'NO_SYMLINK_ARTIFACT')
        item = {'path': rel, 'bytes': len(raw), 'sha256': digest(raw)}
        if p.suffix == '.log' or p.name in ('stdout', 'stderr'):
            text = raw.decode()
            item['text_lines'] = len(text.splitlines())
            item['outcome_lines'] = [line[:2000] for line in text.splitlines() if re.search(r'(^Ran |^OK$|test result:|panicked|finite_target_met|^FAILED$|Main processes terminated|CPU time consumed|Service runtime|"reason":"build-finished")', line)]
        inventory.append(item)
    for path, sha in manifest['files'].items():
        check(digest((capture / path).read_bytes()) == sha, 'MANIFEST_MEMBER_SHA')
    check(manifest['binary_sha256_before'] == manifest['binary_sha256_after'] == digest((capture / 'public_v3_from_zero').read_bytes()), 'BINARY_IDENTITY')
    check(manifest['build']['exit_code'] == 0 and not manifest['build']['timed_out'], 'ACTUAL_BUILD_SUCCESS')
    check(manifest['passed'] is False and manifest['execution_finished'] is True, 'GENUINE_FAILED_SERVICE_RESULT')
    host_before = read_json(base / 'fresh-service-host/inside-before.json')
    host_after = read_json(base / 'fresh-service-host/inside-after.json')
    check(host_before['limits'] == host_after['limits'] == {'cpu.max': '25000 100000', 'cpu.max.burst': '0', 'memory.max': '2147483648', 'memory.swap.max': '0', 'pids.max': '256'}, 'UNCHANGED_HOST_BUDGET')
    check(host_before['boot_id'] == host_after['boot_id'] and host_before['parent'] == host_after['parent'], 'HOST_CONTEXT_STABLE')
    host_child = read_json(base / 'fresh-service-host/child-result.json')
    host_controller = read_json(base / 'fresh-service-host/controller-result.json')
    check(not host_child['host_errors'] and not host_controller['final_host_errors'] and host_controller['failure'] is None, 'NO_HOST_PROVISION_FAILURE')
    stats = [{k: int(v) for k, v in (line.split() for line in host['counters']['cpu.stat'].splitlines())} for host in (host_before, host_after)]
    host_delta = {key: stats[1][key] - value for key, value in stats[0].items()}
    cases = []
    all_packets = None
    for index, mode in enumerate(('original', 'fresh')):
        run = manifest['runs'][index]
        path = capture / mode / 'report.json'
        doc = read_json(path)
        log = capture / (mode + '.log')
        validation = failure(lambda: runner.validate_execution(run['process'], log, run['name'], path))
        check(validation.get('failure') == run['failure'], 'EXACT_ORIGINAL_READER_REJECTION')
        direct_validation = failure(lambda: native.validate_confirmation_report(path) if index == 0 else runner.validate_fresh_report(path))
        check(run['process']['executed'] is True and not run['process']['timed_out'] and run['process']['source_verified'] is True, 'NATIVE_ACTUALLY_EXECUTED')
        check(run['process']['process_exit_code'] == (0 if index == 0 else 101), 'NATIVE_EXPECTED_EXIT')
        check(digest(log.read_bytes()) == run['log_sha256'], 'NAMED_LOG_SHA')
        packets = doc['signed_honest_packets']
        if all_packets is None:
            all_packets = packets
        check(all_packets == packets, 'SAME_HONEST_PACKETS_ACROSS_MODES')
        metadata = [native.ConfirmationReportChecks.packet_metadata(packet) for packet in packets]
        parent = bytes.fromhex(doc['genesis'])
        for height, (header, transactions, block) in enumerate(metadata, 1):
            check(header['parent'] == parent and header['height'] == height and len(transactions) == (1 if height == 1 else 0), 'HONEST_LINKED_CHAIN')
            check(all(header[key].hex() == doc[key] for key in ('network', 'parameters', 'target')) and header['work_task'].hex() == doc['task'], 'HONEST_CHAIN_CONTEXT')
            parent = block
        check(doc['finite_target_met'] is False, 'FAILED_BUSINESS_TARGET_RETAINED')
        constructions = [construction(c, doc) for c in doc['from_zero_construction']] if index == 0 else []
        phases = [phase_report(phase, doc, mode, capture / mode / ('baseline' if i == 0 else 'pressure'), metadata, constructions) for i, phase in enumerate(doc['phases'])]
        if index == 0:
            attacker_total = doc['attacker_construction_cpu_ns'] + phases[1]['attacker_workers_cpu_ns']
        else:
            attacker_total = doc['attacker_setup_and_workers_cpu_ns']
        cases.append({'mode': mode, 'schema': doc['schema'], 'raw_report_sha256': digest(path.read_bytes()),
                      'raw_report_bytes': path.stat().st_size, 'manifest_native_run': run,
                      'source_pinned_execution_readback': validation, 'direct_report_readback': direct_validation,
                      'report_context': {k: doc[k] for k in ('network', 'parameters', 'genesis', 'target', 'task', 'policy_id')},
                      'legal_packet_sha256': [digest(bytes.fromhex(x)) for x in packets],
                      'honest_chain_acquisition_wall_ns': doc['honest_chain_acquisition_wall_ns'],
                      'honest_chain_process_cpu_ns': doc['honest_chain_process_cpu_ns'],
                      'attacker_inclusive_setup_and_workers_cpu_ns': attacker_total,
                      'attacker_cost_scope': 'Shared from-zero setup plus disjoint joined worker CPU; fresh per-call construction is already nested in worker CPU and is not added twice.',
                      'phases': phases})
    return {'artifact_id': aid, 'lane': lane, 'source_before': before, 'source_after': after,
            'binary_sha256': manifest['binary_sha256_before'], 'manifest_sha256': digest((capture / 'manifest.json').read_bytes()),
            'receipt_failures': manifest['failures'], 'manifest_member_hashes_verified': len(manifest['files']),
            'entire_artifact_files_read': inventory, 'entire_artifact_bytes_read': sum(x['bytes'] for x in inventory),
            'host_limits': host_before['limits'], 'host_cpu_stat_delta': host_delta,
            'host_whole_wrapper_wall_ns': round((datetime.fromisoformat(host_after['observed_utc']) - datetime.fromisoformat(host_before['observed_utc'])).total_seconds() * 1e9),
            'host_cpu_scope': 'Fixed ancestor includes controller, report/build recheck and all test receiver, attacker, reader and independent-client threads. This is not a per-phase or receiver-only measurement.',
            'host_allocation_or_authentication_error': False, 'native_rejected_business_target': True,
            'cases': cases, 'honest_w1_callback_count_source_inference': work_check_counts(all_packets)}


def main():
    artifacts = [artifact(*row) for row in ARTIFACTS]
    check(artifacts[0]['binary_sha256'] == artifacts[1]['binary_sha256'], 'IDENTICAL_SERVICE_BINARIES')
    report = {
        'schema': 'pon-w1-service-independent-failure-readback-v1', 'run_id': RUN,
        'immutable_reader_source': HEAD, 'original_budgets_changed': False,
        'source_or_test_files_modified': False, 'native_reexecution_performed': False,
        'work_relation_reverified': False, 'clock_or_artifact_origin_authenticated': False,
        'source_snapshots': {str(p.relative_to(SOURCE)): digest(p.read_bytes()) for p in sorted(SOURCE.rglob('*')) if p.is_file()},
        'validation_assertions_passed': ALL_CHECKS,
        'artifacts': artifacts,
        'findings': [
            {'id': 'ACTUAL_BUSINESS_DEADLINE_FAILURE', 'confidence': 'raw receipts, original reader and retained SQLite agree',
             'finding': 'Both native original diagnostics exit zero because they assert safety/accounting only; original reader correctly rejects finite_target_met=false. Both fresh tests actually execute and exit 101 at the explicit four-second/six-depth assertion; FRESH_NATIVE_PROCESS_REQUIRED is a wrapper first-failure label, not a missing execution.'},
            {'id': 'ACK_IS_NOT_CONFIRMATION', 'confidence': 'raw calls and SQLite',
             'finding': 'All four pressure scenarios acknowledge seven honest packets, receiver active height is seven. All four independent clients admit no non-genesis packet and all four active tips remain genesis. Only a complete final page would activate the requested tip. All four confirm zero transactions.'},
            {'id': 'BASELINE_SUCCEEDS_WITHIN_ORIGINAL_BUDGET', 'confidence': 'raw receipts and SQLite',
             'finding': 'All four attack-free baselines complete independent depth six in the same fixed four-second window; confirmation means probabilistic depth/work, never finality or execution authority.'},
            {'id': 'NO_RECEIVER_MUTATION_CREDIT_DEPLETION', 'confidence': 'original meter and nested CPU accounting',
             'finding': 'All phases start with two-second mutation credit and end with approximately two-second credit, zero CPU budget refusals and zero accounting failures. Endpoints do not prove the credit never dipped in between. Parent cgroup is 0.25 CPU shared by receiver and every client; whole-wrapper CPU counters show throttling, but there is no per-phase kernel sample to attribute exact CPU loss.'},
            {'id': 'EXACT_HISTORY_PATH_COST_LOCATION', 'confidence': 'source-established call topology; cost share not measured',
             'finding': 'history_import::admit_packet intentionally supplies control.check to every history_checkpoint, and scalar_cpu::observe_with_control invokes it before CPU observation and throughout refill. Thus every W1 callback physically verifies the Host. An additional sparse history_kernel_work_checkpoint branch verifies the Host again at 30 of 1099 actual callbacks per retained legal proof. The 1099 guards are the current resource/revocation contract, not a proved bug; deleting them would change that contract. The sparse-selector unit test alone is not an end-to-end count. No per-stage native trace identifies how much of failure those checks cause.'},
            {'id': 'DEFAULT_KERNEL_COVERS_BOTH_SERVICE_FIXTURES', 'confidence': 'exact source routing',
             'finding': 'Both fixtures create PublicServer::new with arithmetic_facts=None and rejection_cache=None. Public Submit and independent History both call WorkCheckedPacket::verify_with_progress then the default pon_work::verify_with_progress. A FullLimb default change covers both; ArithmeticFactCache fixed Transposed is unused in these experiments.'},
            {'id': 'FMT_IS_SEPARATE', 'confidence': 'native binary and named test process evidence',
             'finding': 'The service build succeeds and both named service tests execute for each lane. Their failures are actual business deadline failures. The preceding run cargo fmt failure cannot explain these separately executed native service outcomes.'},
        ],
        'next_discriminating_checks': [
            'Rerun identical four-second, sixteen-worker fixtures after the isolated FullLimb default switch; retain all failed receipts and exact before/after source and kernel identity.',
            'If additional instrumentation is authorized, separately record independent History per-page decode, W1, Host-check, M06 admission, activation, and SQLite commit CPU/wall under the same budget. Preserve all 1099 boundary guards and refill controls.',
            'Instrument actual Host verifier invocation counts inside history_checkpoint and the sparse branch, including cancellation/resource-change tests; do not infer integrated cadence solely from the helper predicate test.',
            'Any Host-read implementation optimization must preserve current boot ID, parent inode/ownership, actual calling thread cgroup membership, all five physical limit reads, deadline/refill semantics, and error propagation; do not increase the resource budget.',
        ],
        'source_locations': [
            {'path': 'scripts/ci/run_w1_fresh_service_v1.py', 'function': 'validate_execution', 'purpose': 'The process-exit guard precedes report validation; fresh exit 101 yields FRESH_NATIVE_PROCESS_REQUIRED.'},
            {'path': 'scripts/ci/run_from_zero_native.py', 'function': 'validate_confirmation_report / validate_confirmation_phases', 'purpose': 'The original diagnostic exit zero cannot pass a false finite_target_met report.'},
            {'path': 'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero.rs', 'function': 'signed_confirmation_phase_with_builder, lines 1277-1603', 'purpose': 'Seven ACKs precede History import; one original deadline is passed to every page; no post-pressure import credit.'},
            {'path': 'trillionnium/crates/trnm-pon-node/tests/public_v3_from_zero/fresh_challenge.rs', 'function': 'fresh_challenge_signed_confirmation_keeps_original_pressure_budget, line 220', 'purpose': 'The explicit business target assert is the actual panic.'},
            {'path': 'trillionnium/crates/trnm-pon-node/src/ingress/history_import.rs', 'function': 'admit_packet / receive', 'purpose': 'Every native progress checkpoint retains Host and CPU controls; only a complete final page activates the requested tip.'},
            {'path': 'trillionnium/crates/trnm-pon-node/src/ingress/public_v3/scalar_cpu.rs', 'function': 'observe_with_control, lines 685-718 / history_checkpoint', 'purpose': 'Resource closure runs before CPU observation and again during refill waits.'},
            {'path': 'trillionnium/crates/trnm-pon-node/src/ingress.rs', 'function': 'history_kernel_work_checkpoint, lines 2385-2398 / kernel_progress_rechecks_original_host_at_most_every_64_tiles', 'purpose': 'Sparse branch adds a second physical Host check at selected points; unit test counts predicate matches, not integrated calls.'},
            {'path': 'trillionnium/crates/trnm-pon-node/src/host_kernel_parent.rs', 'function': 'KernelBudget::check / verify, lines 259-341', 'purpose': 'Every verify reopens actual boot/cgroup/five limits and checks original parent identity.'},
            {'path': 'trillionnium/crates/trnm-pon-node/src/ingress/public_v3.rs', 'function': 'PublicServer::new_identity, lines 729-739 / dispatch Submit, lines 1563-1573', 'purpose': 'Fixture has no arithmetic or negative cache; plain callback verifier selected.'},
            {'path': 'trillionnium/crates/trnm-pon-node/src/store.rs', 'function': 'WorkCheckedPacket::verify_with_progress, lines 624-649', 'purpose': 'Both receiver and History reach the default primitive.'},
        ],
        'qualification': {'service_target_accepted': False, 'work_hardness_accepted': False, 'resource_fairness_qualified': False, 'independent_wan_accepted': False, 'production_activation': False},
    }
    out = HERE / 'service-failure-report.json'
    out.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'path': str(out), 'sha256': digest(out.read_bytes()), 'bytes': out.stat().st_size, 'checks': ALL_CHECKS, 'artifacts': len(artifacts)}))


if __name__ == '__main__':
    main()
