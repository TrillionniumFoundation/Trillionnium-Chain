# Host five-limit parser component observation

This directory retains one actual standalone Rust 1.95.0 experiment. It does
not contain a Node/libtest execution, a new Host authorization check, or a
service campaign. No production source, resource budget, checkpoint frequency,
CPU account, original deadline, or live Host verdict was changed.

## Decision supported by this observation

Do not implement the proposed parser fast path on the strength of the original
89.81% Host-check CPU observation. That original interval includes fresh I/O,
identity and membership verification. This component's absolute parsing cost
is too small to explain the observed missed confirmation.

| Measured arm | Samples | Median caller CPU per call | Observed minimum–maximum |
| --- | ---: | ---: | ---: |
| Original five-field parsing and comparison | 32 | 91.754438 ns | 74.772876–111.087412 ns |
| Exact canonical comparison, original parser on mismatch | 32 | 21.346030 ns | 16.415232–43.961500 ns |
| Within-round paired CPU difference | 16 pairs | 71.438187 ns | 49.580684–84.291254 ns |

These are descriptive ranges from this run, not confidence intervals or
hardware-independent bounds. Even the full original-arm cost includes common
black-box, result-check and wrapper overhead. It is a conservative component
cost scale, not a proved upper bound for another machine.

The retained original pressure run made 3,568 Host checkpoints over its first
three accepted pages. Multiplying that count by this component's median paired
difference gives about **0.255 ms of CPU**. This is explicitly a **cross-host
order-of-magnitude calculation**, not a service measurement, a latency
prediction, a measured saving in the original cgroup, or evidence that a
confirmation target can now be met. The original checkpoints used 185.562777 ms
of caller CPU inside 206.615550 ms of complete page replay caller CPU. These
nested intervals must not be added.

## Exact experiment and retained identities

`measure-original.py` is the unchanged script used for the retained run.
It extracts the original `Limits`, `numeric` and `validate_limits` source from
`host_kernel_parent.rs`, then compiles `component.rs` directly with the actual
pinned Rust 1.95.0 executable. There is no Cargo build or external dependency.
`source-binding.json` records that the complete measured source bytes equal
the original e4abb source:

```text
source revision: e4abb172147e941b62483652b0ceabaae4317624
source SHA-256:   6f4cf524831e8af8e23c954764e388d6d167f125c3de0dd19ce235630ce7df7d
rustc commit:    59807616e1fa2540724bfbac14d7976d7e4a3860
rustc release:   1.95.0
target host:     x86_64-unknown-linux-gnu
```

The standalone adapter uses static error labels instead of the production
error type. Only successful canonical inputs are timed; production error
allocation costs are not measured. Fifteen input variants compare the exact
original and proposed `Result` before timing. `equivalence-variants.json`
lists these inputs, including malformed and changed-limit cases. The original
compiled assertions and their successful completion remain in `component.rs`,
`run.stderr` and `run.process.json`.

There are 16 ABBA rounds, each containing four samples of 250,000 calls.
The order is original, comparison, comparison, original. All 64 samples are
in `run.stdout`. Linux `CLOCK_THREAD_CPUTIME_ID` supplies actual caller-thread
CPU; `Instant` independently records wall time. Every timed input passes
through `black_box`, and every timed result must equal the original parser's
exact four `Limits` values. The common checks remain inside both timings.

The measured prototype compares freshly supplied in-memory strings with
canonical expectations generated from already validated immutable `Limits`.
Every mismatch takes the unchanged parser. This experiment performs **none**
of the surrounding fresh opens, complete reads, EOF checks, UTF-8 checks,
boot/inode/ownership checks, calling-thread membership checks, current-limit
reads, or request deadline/CPU-account checks. Their absence from this
isolated experiment does not authorize removing them from production.

All commands, version output, return codes, raw stdout/stderr, original
generated-source and binary digests are retained. `component.xz` is the
losslessly compressed actual executed component binary.
`binary-retention.json` records raw/compressed sizes and SHA-256 identities;
decompression was verified byte-for-byte against the executed binary.
The uncompressed binary is intentionally absent from this bundle.

## Original confirmation failure and remaining bottlenecks

`original-observation-excerpt.json` is a read-only extraction from the already
retained original protocol-contract artifact. It names the archive, the member,
and the exact JSON pointer for every page. The original member is:

```text
archive: evidence/chain-throughput-budget-20261110-065438/ci-origin/raw-observations.tar.xz
member:  from-zero-native/confirmation/report.json
SHA-256: 4bdfff596979fb8e816b49a1e0aa8c811b7ed159968d5531fa15ba655c41fd7e
```

| Original pressure observation | Retained value | Consequence |
| --- | --- | --- |
| Seventh timely Submit ACK | 1.235683729 s from the original epoch | Independent confirmation work still remains. |
| Initial page CPU reservation | 400.580749 ms; 57 budget refusals followed by one grant | The Exclusive importer already performs real waits under its original account. No prewarming or extra credit is justified. |
| First three accepted independent pages | End at 2.353604870, 3.134174838 and 3.838626094 s | Only three of seven one-packet pages finished replay. |
| Host checkpoints on those pages | 1,221 / 1,167 / 1,180; 185.562777 ms caller CPU total | Whole fresh Host checking dominates caller CPU in this observation; the numeric parser alone does not. |
| Fourth page | Starts at 3.935040290 s; ends at 4.031893137 s | The original four-second deadline is reached during Work. |
| Fourth packet Work phase | 94.163351 ms wall; 4.026699 ms caller CPU; `PUBLIC_REQUEST_DEADLINE` | Admission, M06 and Commit never begin for this packet. |
| Final independent confirmation | Absent | The report remains 0/1, independently of successful Submit ACKs. |

All page attribution records say `owner_mode=exclusive`. In e4abb,
`receive_public_page_from_before_observed` selects `Owner::Exclusive`, and
`history_checkpoint(false, ...)` allows an already verified eligible
continuation to wait on the same account with the same original deadline.
All packet reservations in the four pressure pages succeed on their first
attempt. The new Shared-owner boundary correction cannot be counted as a
repair of this original Exclusive campaign.

The full Host-check implementation is in the retained source:
`KernelBudget::check`, `read_limits`, `read_limit_text`, `read_context_text`,
and `in_parent_cgroup`. The original implementation already preconstructs
immutable limit paths, uses stack buffers for common short reads, and borrows
membership text. Every checkpoint still freshly opens boot ID, current-thread
membership and five limit files, checks the actual parent identity and
ownership, and fully parses the new bytes. Existing adjacent duplicate Host
reads were already removed in e4abb. Neither optimization is a new result of
this experiment.

The useful next measurement, if pursued, is the complete fresh
`KernelBudget::check` under the original fixed parent, with its I/O, identity,
membership and parsing costs distinguished. No remaining source change is
selected by this bundle. Public V3's one-packet History profile and the
campaign's submit-all-then-replay sequence also remain unchanged. Altering
those contracts would require a separate reviewed experiment.

Any future Host-check change still needs the original short-read/EINTR,
real-EOF, 128-byte limit, invalid-UTF-8, late-I/O-error precedence, current-file
replacement/removal, live-limit-change, parent identity/ownership and actual
calling-thread membership refusals. It also needs the original absolute
deadline and Host-rejection controls around W1/M06, then the unchanged real
2-by-4-second campaign. A parser component result cannot replace those gates.

## Reproduce into a new directory

First verify the retained files:

```sh
sha256sum -c SHA256SUMS
```

Then supply an actual Rust 1.95.0 compiler. The wrapper imports the unchanged
original script and overrides only the source/tool/output paths. It refuses
an existing output directory and verifies the retained original source hash.
The original script checks the compiler's actual release before compiling.

```sh
RUN_DIR=$(mktemp -d)
python3 -B reproduce.py \
  --rustc /absolute/path/to/rust-1.95.0/bin/rustc \
  --out "$RUN_DIR/observation"
```

The rerun writes its own generated source, binary, process records and raw
samples to the new directory. Old observations are not overwritten. Numerical
timings are expected to vary. The retained bundle is not itself a new native
campaign or a production patch.
