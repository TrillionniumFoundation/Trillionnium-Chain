from pathlib import Path
import subprocess,json,hashlib,time,resource,sys,traceback
s=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/source');out=s.parent/'published-source-15';out.mkdir(exist_ok=False);(out/'owner.py').write_text(sys.argv[1]);inp=json.loads(sys.argv[2]);(out/'publication.json').write_text(json.dumps(inp,indent=2)+'\n');m=inp['manifest'];head=inp['commit']['sha'];res={'schema':'chain-owned-append-published-source-readback-v1','complete':False,'stages':[],'head':head,'tree':m['tree']}
def save():(out/'RESULT.json').write_text(json.dumps(res,indent=2)+'\n')
def run(name,args):
 t=time.monotonic();a=resource.getrusage(resource.RUSAGE_CHILDREN)
 with (out/(name+'.stdout')).open('xb') as o,(out/(name+'.stderr')).open('xb') as e:rc=subprocess.call(args,cwd=s,stdout=o,stderr=e)
 b=resource.getrusage(resource.RUSAGE_CHILDREN);res['stages'].append({'name':name,'command':args,'exit_code':rc,'wall_seconds':time.monotonic()-t,'child_user_cpu_seconds':b.ru_utime-a.ru_utime,'child_system_cpu_seconds':b.ru_stime-a.ru_stime});save();return rc
try:
 assert run('preflight',['bash','scripts/project-preflight.sh'])==0
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==m['source_parent']
 assert subprocess.check_output(['git','symbolic-ref','HEAD'],cwd=s,text=True).strip()=='refs/heads/fix/chain-native-first-graph-host-20261119-2e9b'
 assert subprocess.check_output(['git','write-tree'],cwd=s,text=True).strip()==m['tree']
 assert run('fetch-published-exact-head',['git','fetch','--no-write-fetch-head','origin',head])==0
 assert subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=s,text=True).strip()==m['tree']
 assert subprocess.check_output(['git','show','-s','--format=%P',head],cwd=s,text=True).strip()==m['source_parent']
 for row in m['items']:
  raw=(s/row['path']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],row['path']
 assert run('advance-own-branch-exact-lease',['git','update-ref','refs/heads/fix/chain-native-first-graph-host-20261119-2e9b',head,m['source_parent']])==0
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=s).strip()
 res['complete']=True;res['exact_git_commit_and_index_and_worktree_verified']=True;save();print(json.dumps(res,indent=2))
except BaseException as e:res['error']=repr(e);save();traceback.print_exc();raise
