This archive copies the original applied-candidate maintenance observation.
source-before.json is the clean S3 baseline BEFORE applying the reviewed patch.
The 43 tests ran on an uncommitted selected maintenance snapshot, not a fully
attested committed C4 source. suite43.json retains that scope explicitly.
The inspector report remains HOLD, with source_revision_bound=false.
The later final committed-source checks are separate observations.
Packaging executed no additional tests, native programs or builds.
