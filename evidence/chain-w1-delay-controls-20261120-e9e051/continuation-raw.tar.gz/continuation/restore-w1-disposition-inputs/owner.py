from pathlib import Path
import json,hashlib,subprocess,sys,time
src=Path('/home/qq/work/chain-native-first-graph-host-20261119-2e9b/resume-20261120-e9e051/source')
out=src.parent/'restore-w1-disposition-inputs';out.mkdir(exist_ok=False)
(out/'owner.py').write_text(sys.argv[1])
with (out/'preflight.stdout').open('wb') as so,(out/'preflight.stderr').open('wb') as se:subprocess.run(['bash','scripts/project-preflight.sh'],cwd=src,stdout=so,stderr=se,check=True)
raw=(src/'config/pon/w1-retained-disposition-v1.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='322420b8b58184fa5887770f76fb1f622a5a40afafbca8f5d2ca51e268a9846f'
manifest=json.loads(raw);rows=[]
for rel,expected in manifest['inputs'].items():
 assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
 p=src/rel; restored=not p.exists()
 gitsha=subprocess.check_output(['git','rev-parse','HEAD:'+rel],cwd=src,text=True).strip()
 if restored:
  t=time.monotonic();result=subprocess.run(['git','cat-file','blob',gitsha],cwd=src,capture_output=True)
  (out/(str(len(rows))+'.git.stderr')).write_bytes(result.stderr)
  assert result.returncode==0,(rel,result.returncode)
  data=result.stdout
 else:data=p.read_bytes()
 actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert actual==gitsha and len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256'],rel
 if restored:
  p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:f.write(data)
 rows.append({'path':rel,'restored':restored,'git_blob':gitsha,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 (out/'restored-inputs.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(rows[-1]),flush=True)
print(json.dumps({'complete':True,'files':len(rows),'restored':sum(x['restored'] for x in rows),'bytes':sum(x['bytes'] for x in rows)}),flush=True)
