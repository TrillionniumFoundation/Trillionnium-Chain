from pathlib import Path
import ast,hashlib,json,os,subprocess,sys,time
root=Path('/private/tmp/chain-final-current-bindings-20261114')
out=Path('/private/tmp/chain-final-current-bindings-evidence-20261114/semantics-coupling-v1')
out.mkdir();(out/'pid.json').write_text(json.dumps({'pid':os.getpid(),'started':time.time()})+'\n')
env={**os.environ,'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','GIT_NO_LAZY_FETCH':'1','TMPDIR':'/private/tmp/chain-final-current-bindings-evidence-20261114/final-checkpoint-v1/canonical-tmp','PYTHONDONTWRITEBYTECODE':'1'}
first=json.loads(Path('/private/tmp/chain-final-current-bindings-evidence-20261114/validation-v1/summary.json').read_bytes())
assert first['edited_inputs_before_after_equal'] is True
assert {x['name'] for x in first['steps'] if not x['passed']}=={'06-workflow-gate-controls','08-closure-current-controls'}
with (out/'preflight.stdout').open('xb') as so,(out/'preflight.stderr').open('xb') as se:
    assert subprocess.run(['bash','scripts/project-preflight.sh'],cwd=root,env=env,stdout=so,stderr=se).returncode==0
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git','--no-replace-objects','-c','core.commitGraph=false',*args],cwd=root,env=env)
assert git('rev-parse','HEAD').decode().strip()=='5c04c60e463462d9df8884786e0d5bb32af08a64'
edits={};before={}
def read(name):
    if name not in before:before[name]=(root/name).read_bytes()
    return edits.get(name,before[name]).decode()
def put(name,s):edits[name]=s.encode()
def once(s,old,new):
    assert s.count(old)==1,(old,s.count(old))
    return s.replace(old,new)
name='scripts/ci/test_w1_qrom_workflow_gate.py';s=read(name)
s=once(s,'import w1_qrom_supplemental_controls as supplemental\n','import w1_qrom_supplemental_controls as supplemental\nimport w1_qrom_current_ci as current_ci\n')
old="""        cls.workflow_text = WORKFLOW.read_text()
        cls.codes = {step: embedded_python(cls.workflow_text, step)
                     for step in ('named_tests', 'report_scopes', 'status')}
"""
new="""        cls.workflow_text = WORKFLOW.read_text()
        # The two source jobs deliberately reuse step IDs. Bind the original
        # historical job before selecting its exact embedded gate boundaries.
        current_ci.validate_historical_job(cls.workflow_text)
        historical_job = cls.workflow_text.split(
            '  qrom-historical-implementation:\\n', 1)[1].split(
            '  qrom-current-implementation:\\n', 1)[0]
        cls.codes = {step: embedded_python(historical_job, step)
                     for step in ('named_tests', 'report_scopes', 'status')}
"""
s=once(s,old,new);put(name,s)
name='scripts/ci/w1_qrom_closure_current_controls.py';s=read(name)
old="""REVIEWED_LOCK = 'formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock'
HISTORICAL_LOCK_SHA256 = 'af7ee60b8f9f95c200d3dddac41b70c037e2bb3395122fe67ab20885140f247f'
CURRENT_LOCK_SHA256 = 'ed6ea70f20cbe45bf0bdef7f841adbdaa7c3b2a9838ffdfed64fa88f129b707a'
"""
new="""# Exact report index, source path, frozen historical SHA, and reviewed current SHA.
REVIEWED_LOCK_CHANGES = (
    (0, 'formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock',
     '9756a0d8cb88c4f0e67f722dad933d30dcbe93d5bb2b6ca2be15f23fd0a3f2ef',
     '93a68edce98e5c61e0cba33ebfbe392ff52df24633347da5a214ac8eb6eae24b'),
    (2, 'formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock',
     'af7ee60b8f9f95c200d3dddac41b70c037e2bb3395122fe67ab20885140f247f',
     'ed6ea70f20cbe45bf0bdef7f841adbdaa7c3b2a9838ffdfed64fa88f129b707a'),
)
"""
s=once(s,old,new)
old=s[s.index('def check_semantics(root, current_report):'):s.index('\ndef main():',s.index('def check_semantics(root, current_report):'))]
new='''def check_semantics(root, current_report):
    """Require exact report correspondence except two independently pinned lock SHAs.

    Both saved historical observations retain their original bytes. This
    current namespace is neither a new execution nor a dependency equivalence
    theorem. The unchanged guest lock and every other report property must
    still equal the frozen historical report.
    """
    original = bounded_regular(Path(root) / HISTORICAL_SEMANTICS)
    require(hashlib.sha256(original).hexdigest() == HISTORICAL_SEMANTICS_SHA256,
            'historical semantics report bytes changed')
    expected = strict_json(original)
    actual = strict_json(bounded_regular(current_report))
    historical_rows = expected['provenance']['lock_checks']
    actual_rows = actual['provenance']['lock_checks']
    require(type(historical_rows) is list and len(historical_rows) == 3,
            'historical lock provenance differs')
    require(type(actual_rows) is list and len(actual_rows) == 3,
            'current reviewed lock provenance differs')
    changes = []
    for index, path, historical_sha, current_sha in REVIEWED_LOCK_CHANGES:
        lock = bounded_regular(Path(root) / path)
        require(hashlib.sha256(lock).hexdigest() == current_sha,
                'reviewed current lock bytes changed: ' + path)
        require(historical_rows[index]['path'] == path
                and historical_rows[index]['sha256'] == historical_sha,
                'historical lock provenance differs')
        require(actual_rows[index]['path'] == path
                and actual_rows[index]['sha256'] == current_sha,
                'current reviewed lock provenance differs')
        historical_rows[index]['sha256'] = current_sha
        changes.append({
            'json_pointer': '/provenance/lock_checks/' + str(index) + '/sha256',
            'path': path, 'historical_sha256': historical_sha,
            'current_sha256': current_sha,
        })
    # Only these two exact properties may differ. Canonical JSON also refuses
    # bool/int or int/float aliases that ordinary dictionary equality accepts.
    canonical = lambda value: json.dumps(value, sort_keys=True,
                                        separators=(',', ':'), allow_nan=False)
    require(canonical(actual) == canonical(expected),
            'semantics report differs outside reviewed lock provenance')
    return {
        'schema': 'TRNM-W1-SEMANTICS-CURRENT-CORRESPONDENCE3',
        'historical_report_sha256': HISTORICAL_SEMANTICS_SHA256,
        'reviewed_lock_changes': changes,
        'only_changed_json_pointers': [row['json_pointer'] for row in changes],
        'all_other_report_fields_identical': True,
        'historical_report_bytes_rewritten': False,
        'new_native_execution_or_dependency_equivalence_proved': False,
        'qualification': dict(QUALIFICATION),
    }

'''
s=once(s,old,new);put(name,s)
name='scripts/ci/test_w1_qrom_closure_current_controls.py';s=read(name)
s=once(s,"        for name in (gate.HISTORICAL_SEMANTICS, gate.REVIEWED_LOCK):\n","        for name in (gate.HISTORICAL_SEMANTICS,\n                     *(row[1] for row in gate.REVIEWED_LOCK_CHANGES)):\n")
s=once(s,"        self.assertEqual(result['only_changed_json_pointer'], '/provenance/lock_checks/2/sha256')\n","        self.assertEqual(result['only_changed_json_pointers'], [\n            '/provenance/lock_checks/0/sha256', '/provenance/lock_checks/2/sha256'])\n        self.assertEqual([(row['path'], row['current_sha256'])\n                          for row in result['reviewed_lock_changes']], [\n            ('formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock',\n             '93a68edce98e5c61e0cba33ebfbe392ff52df24633347da5a214ac8eb6eae24b'),\n            ('formal/pon-nakamoto-v1/w1_zkvm/Cargo.lock',\n             'ed6ea70f20cbe45bf0bdef7f841adbdaa7c3b2a9838ffdfed64fa88f129b707a'),\n        ])\n")
old="""    def test_missing_or_relabelled_reviewed_lock_entry_is_refused(self):
        value = json.loads(self.actual_bytes)
        value['provenance']['lock_checks'].pop(2)
        self.current.write_text(json.dumps(value))
        self.reject()
        value = json.loads(self.actual_bytes)
        value['provenance']['lock_checks'][2]['path'] = 'unrelated/Cargo.lock'
        self.current.write_text(json.dumps(value))
        self.reject()

    def test_changed_other_lock_sha_is_refused(self):
        value = json.loads(self.actual_bytes)
        value['provenance']['lock_checks'][0]['sha256'] = '0' * 64
        self.current.write_text(json.dumps(value))
        self.reject()

    def test_changed_current_lock_bytes_cannot_be_relabelled_in_report(self):
        path = self.root / gate.REVIEWED_LOCK
        changed = path.read_bytes() + b'\\n'
        path.write_bytes(changed)
        value = json.loads(self.actual_bytes)
        value['provenance']['lock_checks'][2]['sha256'] = hashlib.sha256(changed).hexdigest()
        self.current.write_text(json.dumps(value))
        self.reject()
"""
new="""    def test_missing_or_relabelled_reviewed_lock_entry_is_refused(self):
        for index in (0, 2):
            with self.subTest(index=index):
                value = json.loads(self.actual_bytes)
                value['provenance']['lock_checks'].pop(index)
                self.current.write_text(json.dumps(value))
                self.reject()
                value = json.loads(self.actual_bytes)
                value['provenance']['lock_checks'][index]['path'] = 'unrelated/Cargo.lock'
                self.current.write_text(json.dumps(value))
                self.reject()

    def test_changed_other_lock_sha_is_refused(self):
        for index in (0, 1, 2):
            with self.subTest(index=index):
                value = json.loads(self.actual_bytes)
                value['provenance']['lock_checks'][index]['sha256'] = '0' * 64
                self.current.write_text(json.dumps(value))
                self.reject()

    def test_changed_current_lock_bytes_cannot_be_relabelled_in_report(self):
        for index, name, _, _ in gate.REVIEWED_LOCK_CHANGES:
            with self.subTest(index=index):
                path = self.root / name
                original = path.read_bytes()
                changed = original + b'\\n'
                try:
                    path.write_bytes(changed)
                    value = json.loads(self.actual_bytes)
                    value['provenance']['lock_checks'][index]['sha256'] = hashlib.sha256(changed).hexdigest()
                    self.current.write_text(json.dumps(value))
                    self.reject()
                finally:
                    path.write_bytes(original)
"""
s=once(s,old,new)
s=once(s,"'TRNM-W1-SEMANTICS-CURRENT-CORRESPONDENCE2'","'TRNM-W1-SEMANTICS-CURRENT-CORRESPONDENCE3'")
put(name,s)
name='scripts/ci/test_w1_qrom_semantics_audit.py';s=read(name)
s=once(s,"        # A current lock observation has a separate fixture. Retain the old\n        # report as an exact historical observation, not a passing current cmp.\n","        # Both preceding source observations remain frozen. The present two-lock\n        # correspondence is explicit; neither saved report is rewritten as current.\n")
s=once(s,"        self.assertEqual(encoded, current_raw)\n","        self.assertNotEqual(encoded, current_raw)\n")
old="""        # Compare JSON values; the audit's in-memory structures include tuples.
        self.assertEqual(historical, json.loads(encoded))
"""
new="""        # Preserve the preceding one-lock observation under its original SHA.
        self.assertEqual(historical, json.loads(current_raw))
        self.assertEqual(historical['provenance']['lock_checks'][0]['path'],
                         'formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.lock')
        self.assertEqual(historical['provenance']['lock_checks'][0]['sha256'],
                         '9756a0d8cb88c4f0e67f722dad933d30dcbe93d5bb2b6ca2be15f23fd0a3f2ef')
        historical['provenance']['lock_checks'][0]['sha256'] = (
            '93a68edce98e5c61e0cba33ebfbe392ff52df24633347da5a214ac8eb6eae24b')
        # Compare all JSON values; the audit's in-memory structures include tuples.
        self.assertEqual(historical, json.loads(encoded))
"""
s=once(s,old,new);put(name,s)
name='scripts/ci/test_w1_qrom_current_ci.py';s=read(name)
s=once(s,"        for mutation in ('missing', 'extra', 'wrong_digest', 'self_consistent_omission',\n                         'self_consistent_extra', 'wrong_reason', 'exit_zero', 'old_source', 'scope'):\n","        for mutation in ('missing', 'extra', 'wrong_digest', 'self_consistent_omission',\n                         'self_consistent_extra', 'self_consistent_substitution',\n                         'self_consistent_reorder', 'wrong_reason', 'exit_zero', 'old_source', 'scope'):\n")
anchor="""                elif mutation == 'wrong_reason':
                    report['historical_result']['reason'] = 'unrelated missing file'
"""
extra="""                elif mutation == 'self_consistent_substitution':
                    removed = report['selected_source_differences'].pop(2)
                    for row in contract['project_files']:
                        if row['path'] == removed['path']:
                            row.update(removed['historical'])
                    old = {row['path']: row for row in self.legacy['project_files']}
                    added = next(row for row in contract['project_files']
                                 if row['path'] not in ci.REVIEWED_DIFFERENCE_PATHS)
                    added['sha256'] = '0' * 64
                    report['selected_source_differences'].append({
                        'path': added['path'], 'historical': old[added['path']], 'current': added,
                        'observed_bytes': added['bytes'], 'observed_sha256': added['sha256']})
                    order = {row['path']: i for i, row in enumerate(contract['project_files'])}
                    report['selected_source_differences'].sort(key=lambda row: order[row['path']])
                    self.assertEqual(len(report['selected_source_differences']), 4)
                elif mutation == 'self_consistent_reorder':
                    contract['project_files'].reverse()
                    report['selected_source_differences'].reverse()
                    self.assertEqual(len(report['selected_source_differences']), 4)
"""
s=once(s,anchor,extra+anchor);put(name,s)
name='docs/security/W1_QROM_CURRENT_SOURCE_MAPPING_V2.md';s=read(name)
s+="""
### Exact current semantics correspondence

The frozen 2026-11-07 semantics report and the 2026-11-09 observation retain
their original SHA-256 values and bytes. The current correspondence reader
uses the explicit TRNM-W1-SEMANTICS-CURRENT-CORRESPONDENCE3 namespace. It
checks the V2 verifier lock and the zkVM lock against independently reviewed
current digests, then permits only provenance lock-check SHA fields 0 and 2
to differ from the original historical report. Guest lock field 1, every other
report property, and all qualification values must match exactly. This does
not assert that the full dependency graphs are equivalent.

The original embedded-workflow negative controls select the fixed historical
job by its exact job boundaries and unchanged hash before requiring one matching
step ID inside that job. Reused step names in the separate current job do not
weaken step or completion validation. The original Mac compiler refusal is
retained; its eight native C controls subsequently pass with the installed
GCC 15 compiler and the original OpenMP and warning flags.
"""
put(name,s)
def tests(raw):
    t=ast.parse(raw)
    return [(c.name,n.name) for c in t.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
for name,raw in edits.items():
    if name.endswith('.py'):
        ast.parse(raw,filename=name)
        if '/test_' in name:assert tests(before[name])==tests(raw),name
historical_frozen=[
'evidence/pon-w1-qrom-semantics-20261107/report.json',
'evidence/pon-w1-qrom-semantics-current-20261109/report.json',
'.github/workflows/pon-w1-qrom-implementation.yml',
'.github/workflows/pon-w1-qrom-closure.yml',
'config/pon/w1-qrom-closure-current-required-tests-v2.json']
frozen=[]
for name in historical_frozen:
    current=(root/name).read_bytes();base=git('show','HEAD:'+name)
    assert current==base,name
    frozen.append({'path':name,'bytes':len(current),'sha256':sha(current)})
for name,raw in edits.items():
    (out/(name.replace('/','--')+'.before')).write_bytes(before[name])
    (root/name).write_bytes(raw)
corpus_name='config/pon/pq-cross-branch-corpus-v1.json'
corpus=(root/corpus_name).read_text();parsed=json.loads(corpus);pins=[]
for name,raw in edits.items():
    if name not in parsed['pinned_blobs']:continue
    old=parsed['pinned_blobs'][name]
    new=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    corpus=once(corpus,json.dumps(name)+': '+json.dumps(old),json.dumps(name)+': '+json.dumps(new))
    pins.append({'path':name,'old':old,'new':new})
(root/corpus_name).write_text(corpus)
assert subprocess.run(['git','diff','--check'],cwd=root,env=env).returncode==0
patch=git('diff','--binary','--full-index');(out/'working.patch').write_bytes(patch)
# This focused delta is relative to the already reviewed 30-path candidate.
import difflib
focused=''.join(''.join(difflib.unified_diff(before[n].decode().splitlines(True),r.decode().splitlines(True),fromfile='a/'+n,tofile='b/'+n)) for n,r in edits.items())
(out/'focused.patch').write_text(focused)
summary={'source_base':'5c04c60e463462d9df8884786e0d5bb32af08a64','new_current_semantics_schema':'TRNM-W1-SEMANTICS-CURRENT-CORRESPONDENCE3','changed_json_pointers':['/provenance/lock_checks/0/sha256','/provenance/lock_checks/2/sha256'],'preserved_frozen_files':frozen,'preserved_original_test_method_rosters':True,'new_files_edited':[{'path':n,'before_sha256':sha(before[n]),'after_sha256':sha(r)} for n,r in edits.items()],'corpus_pins':pins,'working_patch':{'bytes':len(patch),'sha256':sha(patch)},'focused_patch':{'bytes':len(focused.encode()),'sha256':sha(focused.encode())},'rust_sources_changed':False}
(out/'review.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2))
