import hashlib,json,os,subprocess,sys
from pathlib import Path
repo=Path('/home/qian/trillionnium-review-source/pq-composed-60dae3-20261104')
out=Path('/home/qian/trillionnium-review-source/pq-composed-60dae3-20261104-observations')
expected='60dae3cf66d1e651af8e61eccf761abf43285e63'
env=os.environ.copy()
env['PATH']='/home/qian/.cargo/bin:'+env['PATH']
env.update(CARGO_TARGET_DIR='/home/qian/.cache/trnm-pq-composed-60dae3-target',CARGO_BUILD_JOBS='2',PYTHONDONTWRITEBYTECODE='1')
assert not any(k.startswith('CARGO_PROFILE_') or k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER') for k in env)
pr=Path('/home/qian/trillionnium-review-source/pq-b8aa-provider-20261103')
provider=json.loads((pr/'ci-observations/pq-provider/provider.json').read_text())
assert provider['result']=='PREPARED_AND_SMOKE_VERIFIED' and provider['version']=='3.5.9'
for item in provider['native_backend_inputs']:
 p=Path(item['path'])
 assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
for line in (pr/'environment').read_text().splitlines():
 k,v=line.split('=',1);env[k]=v
(out/'provider-current-revalidated.json').write_text(json.dumps({'source_commit':expected,'current_inputs_match_original_receipt':True,'original_preparation':provider,'fresh_rebuild_claim':False},indent=2)+'\n')
def run(label,cmd):
 args=['python3','-B','scripts/ci/record_pq_native_command.py','--kind','head','--candidate',expected,'--tested',expected,'--label',label,'--output',str(out),'--']+cmd
 result=subprocess.run(args,cwd=repo,env=env)
 print(json.dumps({'label':label,'exit_code':result.returncode}),flush=True)
 return result.returncode
cargo=['/home/qian/.cargo/bin/cargo','+1.95.0']
manifest=['--locked','--offline','--manifest-path','trillionnium/Cargo.toml']
ok=[]
for label,cmd in [('native-preflight',['bash','scripts/project-preflight.sh']),('native-compiler',['/home/qian/.cargo/bin/rustc','+1.95.0','-Vv']),('native-format',cargo+['fmt','--manifest-path','trillionnium/Cargo.toml','--all','--','--check']),('native-graph',cargo+['metadata']+manifest+['--all-features','--format-version','1']),('native-build',cargo+['test']+manifest+['-p','trnm-pon-node','--lib','--all-features','--no-run','--message-format=json'])]:
 code=run(label,cmd);ok.append(code==0)
 if code:raise SystemExit(code)
spec=json.loads((repo/'config/pon/pq-system-required-tests-v1.json').read_text())
tests=spec['tests']
assert len(tests)==len(set(tests))==spec['expected_meaningful_controls']==45
assert not spec['whole_chain_quantum_security_qualified']
assert not set(tests)&set(spec['child_process_harnesses_not_counted'])
native=[]
for index,test in enumerate(tests):
 label='native-'+str(index).zfill(2)
 code=run(label,cargo+['test']+manifest+['-p','trnm-pon-node','--lib','--all-features',test,'--','--exact','--show-output','--test-threads=1'])
 with (out/(label+'-execution.json')).open('x') as record:
  check=subprocess.run(['python3','-B','scripts/ci/check_required_native_test.py',str(out/(label+'.log')),'--test',test],cwd=repo,env=env,stdout=record,stderr=subprocess.STDOUT)
 native.append({'name':test,'command_exit':code,'named_execution_exit':check.returncode})
 ok.append(code==0 and check.returncode==0)
(out/'native-45-summary.json').write_text(json.dumps({'source_commit':expected,'source_tree':'38d77248282cec7c8fb96a5d9f681cbe6d6cd06c','tests':native,'passed':sum(r['command_exit']==0 and r['named_execution_exit']==0 for r in native),'total':45,'whole_chain_qualified':False,'full_node_suite_executed':False},indent=2)+'\n')
ok.append(run('native-clippy',cargo+['clippy']+manifest+['-p','trnm-pon-node','--lib','--tests','--all-features','--','-D','warnings'])==0)
verifier=['--offline','--locked','--release','--manifest-path','formal/pon-nakamoto-v1/w1_hardened_verifier/Cargo.toml']
for label,cmd in [('verifier-tests',cargo+['test']+verifier),('verifier-clippy',cargo+['clippy']+verifier+['--all-targets','--','-D','warnings']),('verifier-build',cargo+['build']+verifier)]:
 code=run(label,cmd);ok.append(code==0)
 if code:break
else:
 binary=Path(env['CARGO_TARGET_DIR'])/'release/trnm-w1-hardened-verifier'
 (out/'verifier-binary.json').write_text(json.dumps({'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'path':str(binary),'source_commit':expected},indent=2)+'\n')
 proof='evidence/pon-w1-complete-succinct-20261028/full-proof/'
 ok.append(run('verifier-existing-complete-w1',[str(binary),'verify',proof+'header.bin',proof+'succinct.bin'])==0)
print(json.dumps({'native_controls_passed':sum(r['command_exit']==0 and r['named_execution_exit']==0 for r in native),'all_commands_passed':all(ok),'whole_chain_qualified':False}),flush=True)
raise SystemExit(0 if all(ok) else 1)
