#!/usr/bin/env python3
"""Single local C8 merge freeze; never pushes or launches qualification."""
from pathlib import Path
import hashlib,json,re,subprocess,time

REPO=Path('/home/qian-qi/work/chain-w1-base9417-integration-20261108-ec265b')
OLD=Path('/home/qian-qi/work/chain-w1-base96-integration-20261108-ec265b')
ROOT=Path('/home/qian-qi/work/chain-w1-base9417-adversarial-integration-20261108-ec265b-01')
OUT=ROOT/'freeze-01'
C7='40a3a45d6b8afc5c4706c5235fec47634f4aabbe'
BASE='9417e495165865ef6c1288b39084856e31020634'
MANIFEST_SHA='2b1659a56353c8096646e72b7447921ba3d79501424a11c35a38b31c91e1e57d'
DIFF_SHA='5d115e88325dcfb963e12c87591285a05d9c2323324301ee06b5da21edf6bd52'
EXPECTED={'.github/workflows/pon-recent-batch-acceptance.yml','config/pon/pq-cross-branch-corpus-v1.json',
'docs/development/TRNM_AI_NATIVE_BLOCKCHAIN_DEVELOPMENT_PLAN.md','scripts/ci/test_history_stage_diagnostic.py',
'trillionnium/crates/trnm-pon-node/src/store.rs','trillionnium/crates/trnm-pon-node/src/store/historical_commitment.rs',
'trillionnium/crates/trnm-pon-node/src/store/historical_commitment_tests.rs','trillionnium/crates/trnm-pon-node/tests/history_stage_diagnostic.rs'}
OUT.mkdir()  # Atomic create-only claim: never resume through a second commit attempt.
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
def write(name,b):
    with (OUT/name).open('xb') as f:f.write(b)
rows=[]
def run(label,argv,cwd=REPO):
    t=time.monotonic_ns()
    p=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
    write(label+'.stdout',p.stdout);write(label+'.stderr',p.stderr)
    row={'label':label,'argv':argv,'cwd':str(cwd),'exit':p.returncode,
         'started_monotonic_ns':t,'finished_monotonic_ns':time.monotonic_ns(),
         'stdout_bytes':len(p.stdout),'stdout_sha256':sha(p.stdout),
         'stderr_bytes':len(p.stderr),'stderr_sha256':sha(p.stderr)}
    rows.append(row)
    with (OUT/'commands.jsonl').open('ab') as f:f.write((json.dumps(row,sort_keys=True)+'\n').encode())
    print(json.dumps(row),flush=True)
    assert p.returncode==0,(label,p.returncode,p.stderr.decode(errors='replace'))
    return p.stdout

run('00-preflight',['bash','scripts/project-preflight.sh'])
assert run('01-before-head',['git','rev-parse','HEAD']).decode().strip()==C7
assert run('02-before-merge',['git','rev-parse','MERGE_HEAD']).decode().strip()==BASE
assert run('03-before-unmerged',['git','ls-files','-u'])==b''
assert run('04-before-unstaged',['git','diff','--exit-code'])==b''
assert run('05-before-untracked',['git','ls-files','--others','--exclude-standard'])==b''
assert set(run('06-before-paths',['git','diff','--cached','--name-only',C7]).decode().splitlines())==EXPECTED
diff=run('07-before-diff',['git','diff','--cached','--binary',C7])
assert sha(diff)==DIFF_SHA
assert run('08-old-head-before',['git','rev-parse','HEAD'],OLD).decode().strip()==C7
assert run('09-old-status-before',['git','status','--porcelain=v1','--untracked-files=all'],OLD)==b''

mb=(ROOT/'precommit-checks-01/manifest.json').read_bytes()
assert sha(mb)==MANIFEST_SHA
m=json.loads(mb)
assert m['complete'] is True and m['candidate_unchanged_during_checks'] is True
assert m['candidate_diff_sha256']==DIFF_SHA and m['actual_command_count']==9 and len(m['commands'])==9
assert m['python_method_executions']==160 and m['all_reported_suites_have_exact_OK'] is True
expect_tests={'06-ci-contract-negative-controls':115,'07-pq-source-negative-controls':39,'08-history-diagnostic-controls':6}
for c in m['commands']:
    assert type(c['exit']) is int and c['exit']==0 and c['timed_out'] is False
    for stream in ('stdout','stderr'):
        b=(ROOT/'precommit-checks-01'/(c['label']+'.'+stream)).read_bytes()
        assert len(b)==c[stream+'_bytes'] and sha(b)==c[stream+'_sha256']
    if c['label'] in expect_tests:
        b=(ROOT/'precommit-checks-01'/(c['label']+'.stderr')).read_text()
        n=expect_tests[c['label']]
        assert len(re.findall(r'^test_.* \.\.\. ok$',b,re.M))==n
        assert re.findall(r'^Ran ([0-9]+) tests? in ',b,re.M)==[str(n)]
        assert len(re.findall(r'^OK$',b,re.M))==1
        assert not re.search(r'^FAILED|^ERROR:|^FAIL:|\.\.\. skipped',b,re.M)
write('precommit-manifest-binding.json',enc({'original_path':str(ROOT/'precommit-checks-01/manifest.json'),
    'sha256':sha(mb),'all_18_output_bytes_rehashed':True,'actual_test_methods_with_ok_lines':160,
    'candidate_diff_sha256':DIFF_SHA,'candidate_checks_only':True}))
tree=run('10-staged-tree',['git','write-tree']).decode().strip()
write('commit-message.txt',b'Merge fixed history base 9417 into W1 C8 candidate\n\nPreserve W1 source guards and controls while rebinding exact merged pins.\nRetain bounded historical replay-prefix arithmetic and current-parent tests.\nRecord candidate scope without inheriting C7 qualification or lifecycle claims.\n')
run('11-local-merge-commit',['git','commit','--file',str(OUT/'commit-message.txt')])
identity=run('12-committed-identity',['git','show','-s','--format=%H%n%T%n%P%n%s','HEAD']).decode().splitlines()
assert len(identity)==4 and identity[1]==tree and identity[2].split()==[C7,BASE]
head=identity[0]
assert run('13-new-status-after',['git','status','--porcelain=v1','--untracked-files=all'])==b''
assert run('14-old-head-after',['git','rev-parse','HEAD'],OLD).decode().strip()==C7
assert run('15-old-status-after',['git','status','--porcelain=v1','--untracked-files=all'],OLD)==b''
after=run('16-committed-diff',['git','diff','--binary',C7,head])
assert after==diff
run('17-committed-stat',['git','diff','--stat',C7,head])
run('18-committed-name-status',['git','diff','--name-status',C7,head])
report={'schema':'TRNM-W1-C8-LOCAL-FREEZE1','complete':True,'repo':str(REPO),
    'commit':head,'tree':tree,'parents':[C7,BASE],'source_clean_after':True,
    'old_c7_checkout_head_unchanged':True,'old_c7_checkout_clean_before_after':True,
    'precommit_manifest_sha256':MANIFEST_SHA,'candidate_and_committed_diff_sha256':DIFF_SHA,
    'actual_freeze_command_count':len(rows),'commands':rows,'pushed':False,
    'new_proofs':0,'new_operations':0,'postcommit_qualification_executed':False,
    'scope':'Local merge freeze only. The 160 precommit Python method executions do not establish full exact committed C8 qualification.'}
write('manifest.json',enc(report))
print(json.dumps({'complete':True,'commit':head,'tree':tree,'parents':[C7,BASE],
    'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'out':str(OUT),'pushed':False}),flush=True)
