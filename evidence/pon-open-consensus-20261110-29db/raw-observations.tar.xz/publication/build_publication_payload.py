#!/usr/bin/env python3
"""Serialize exact local commits for reviewed, nonforce remote publication."""
import base64
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


def main():
    root, base, tip, output = sys.argv[1:]

    def git(*args):
        return subprocess.check_output(['git', '-C', root, *args])

    def person(raw):
        match = re.fullmatch(rb'(.*) <([^\r\n<>]+)> ([0-9]+) \+0000', raw)
        if match is None:
            raise ValueError('Identity must be canonical UTC')
        name, email, stamp = match.groups()
        return {'name': name.decode(), 'email': email.decode(),
                'date': datetime.datetime.fromtimestamp(int(stamp), datetime.timezone.utc)
                    .isoformat().replace('+00:00', 'Z')}

    subprocess.run(['git', '-C', root, 'merge-base', '--is-ancestor', base, tip], check=True)
    payload = {'schema': 'pon-exact-continuation-publication-v1',
               'repository': 'TrillionniumFoundation/Trillionnium-Chain',
               'branch': 'fix/chain-pon-native-boundaries-20261110-02769a',
               'expected_remote': base, 'commits': []}
    prior = base
    for sha in git('rev-list', '--reverse', base + '..' + tip).decode().splitlines():
        raw = git('cat-file', 'commit', sha)
        header, message = raw.split(b'\n\n', 1)
        lines = header.splitlines()
        if len(lines) != 4 or not all(line.startswith(key) for line, key in zip(
                lines, [b'tree ', b'parent ', b'author ', b'committer '])):
            raise ValueError('Only exact ordinary single-parent commits are supported')
        tree, parent = (line.split(b' ', 1)[1].decode() for line in lines[:2])
        if parent != prior:
            raise ValueError('Commit chain is not linear')
        record = {'commit': sha, 'tree': tree, 'parent': parent,
                  'parent_tree': git('rev-parse', parent + '^{tree}').decode().strip(),
                  'author': person(lines[2][7:]), 'committer': person(lines[3][10:]),
                  'message': message.decode(), 'entries': []}
        names = git('diff-tree', '--no-commit-id', '--name-only', '-r', '-z', parent, sha)
        for name in names.split(b'\0'):
            if not name:
                continue
            path = name.decode()
            row = git('ls-tree', '-z', sha, '--', path).rstrip(b'\0')
            if not row:
                raise ValueError('Deletion is not supported')
            metadata, observed = row.split(b'\t', 1)
            if observed != name:
                raise ValueError('Path identity mismatch')
            mode, kind, blob = metadata.decode().split()
            if kind != 'blob':
                raise ValueError('Only ordinary file blobs are supported')
            data = git('cat-file', 'blob', blob)
            record['entries'].append({'path': path, 'mode': mode, 'type': kind,
                                      'sha': blob, 'data_base64': base64.b64encode(data).decode()})
        payload['commits'].append(record)
        prior = sha
    if prior != tip or not payload['commits']:
        raise ValueError('Requested tip was not serialized')
    compressed = gzip.compress(json.dumps(payload, separators=(',', ':')).encode(), mtime=0)
    Path(output).write_bytes(compressed)
    print(json.dumps({'path': output, 'bytes': len(compressed),
                      'sha256': hashlib.sha256(compressed).hexdigest(),
                      'commits': [{'commit': x['commit'], 'tree': x['tree'],
                                   'changed_paths': len(x['entries'])} for x in payload['commits']]}))


if __name__ == '__main__':
    main()
