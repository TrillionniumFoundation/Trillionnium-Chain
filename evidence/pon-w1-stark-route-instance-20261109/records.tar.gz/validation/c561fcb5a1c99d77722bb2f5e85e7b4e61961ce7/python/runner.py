import argparse
import concurrent.futures
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('group', choices=['python', 'rust'])
parser.add_argument('head')
args = parser.parse_args()
root = Path('/workspace/scratch/7e8b6061b88c/chain-stark-work')
out = Path('/workspace/scratch/7e8b6061b88c/validation') / args.head / args.group
out.mkdir(parents=True, exist_ok=False)
def git(*values):
    return subprocess.check_output(['git', *values], cwd=root, text=True).strip()
assert git('rev-parse', 'HEAD') == args.head
assert git('status', '--porcelain') == ''
source = {'head': args.head, 'tree': git('rev-parse', 'HEAD^{tree}'), 'clean_before': True}
env = dict(os.environ)
env['PATH'] = '/home/agent/.cargo/bin:' + env.get('PATH', '')
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['CARGO_INCREMENTAL'] = '0'
env['CARGO_BUILD_JOBS'] = '1'
env['CARGO_TARGET_DIR'] = str(Path('/workspace/scratch/7e8b6061b88c/rust-target'))

def run(row):
    name, command = row
    start = time.monotonic()
    started = datetime.now(timezone.utc).isoformat()
    with (out/(name+'.stdout')).open('xb') as stdout, (out/(name+'.stderr')).open('xb') as stderr:
        p = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr)
    logs = {}
    for stream in ['stdout', 'stderr']:
        raw = (out/(name+'.'+stream)).read_bytes()
        logs[stream] = {'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest()}
    text = (out/(name+'.stderr')).read_text(errors='replace')
    counts = re.findall(r'^Ran ([0-9]+) tests? in ', text, re.M)
    result = {'name':name, 'argv':command, 'source':source, 'started_utc':started,
              'elapsed_seconds':time.monotonic()-start, 'exit_code':p.returncode,
              'logs':logs, 'unittest_method_counts':[int(x) for x in counts],
              'unittest_outcomes':re.findall(r'^(?:OK(?: \(.*\))?|FAILED(?: \(.*\))?)$',text,re.M)}
    (out/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['name','exit_code','elapsed_seconds','unittest_method_counts','unittest_outcomes']}),flush=True)
    return result

if args.group == 'python':
    names = ['test_w1_stark_field_certificates','test_w1_stark_route_audit',
             'test_w1_qrom_current_implementation_audit','test_ci_contract',
             'test_ci_source_integrity','test_pq_research_integration',
             'test_repository','test_pq_chain_claim_guard']
    rows = [(n,['python3','-B','scripts/ci/'+n+'.py']) for n in names]
    rows += [('field-report',['python3','-B','scripts/w1_stark_field_certificates.py']),
             ('route-report',['python3','-B','scripts/w1_stark_route_audit.py']),
             ('current-risc-map',['python3','-B','scripts/w1_qrom_current_implementation_audit.py']),
             ('repository-check',['python3','-B','scripts/ci/check_repository.py']),
             ('source-corpus',['python3','-B','scripts/ci/check_pq_research_integration.py']),
             ('ci-contract',['python3','-B','scripts/ci/check_ci_contract.py']),
             ('inventory',['python3','-B','scripts/refresh_distributed_source_inventory.py','--check']),
             ('preflight',['bash','scripts/project-preflight.sh'])]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(run, rows))
else:
    cargo = ['/home/agent/.cargo/bin/cargo','+1.95.0']
    workspace = 'trillionnium/Cargo.toml'
    rows = [('cargo-version',cargo+['--version']),
            ('rustc-version',['/home/agent/.cargo/bin/rustc','+1.95.0','-vV']),
            ('workspace-metadata-default',cargo+['metadata','--manifest-path',workspace,'--locked','--offline','--format-version=1']),
            ('workspace-metadata-all',cargo+['metadata','--manifest-path',workspace,'--all-features','--locked','--offline','--format-version=1']),
            ('p3-metadata',cargo+['metadata','--manifest-path','formal/pon-nakamoto-v1/w1_public_stark_research/Cargo.toml','--locked','--offline','--format-version=1']),
            ('risc-v2-metadata',cargo+['metadata','--manifest-path','formal/pon-nakamoto-v1/w1_v2_verifier/Cargo.toml','--locked','--offline','--format-version=1']),
            ('workspace-format',cargo+['fmt','--manifest-path',workspace,'--all','--','--check']),
            ('p3-format',cargo+['fmt','--manifest-path','formal/pon-nakamoto-v1/w1_public_stark_research/Cargo.toml','--all','--','--check']),
            ('strict-clippy',cargo+['clippy','--manifest-path',workspace,'--workspace','--all-targets','--all-features','--locked','--offline','--','-D','warnings'])]
    results = [run(row) for row in rows]
source['clean_after'] = git('status','--porcelain') == ''
source['head_after'] = git('rev-parse','HEAD')
source['tree_after'] = git('rev-parse','HEAD^{tree}')
summary = {'source':source,'group':args.group,'results':results,
           'all_commands_exit_zero':all(row['exit_code']==0 for row in results),
           'native_proof_execution_claimed':False,'production_qualified':False}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'summary':str(out/'summary.json'),'all_commands_exit_zero':summary['all_commands_exit_zero'],'source':source}),flush=True)
