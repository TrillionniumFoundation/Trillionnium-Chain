#!/usr/bin/env python3
"""Scratch orchestration of existing immutable-source command receipts."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/9d99fced0bf1/chain')
OUT = Path('/workspace/scratch/9d99fced0bf1/final-validation')
OUT.mkdir(exist_ok=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
label, *command = sys.argv[1:]
if not command:
    raise SystemExit('need label and command')
args = ['python3', 'scripts/ci/record_pq_native_command.py', '--kind', 'head',
        '--candidate', head, '--tested', head, '--label', label,
        '--output', str(OUT), '--', *command]
raise SystemExit(subprocess.run(args, cwd=ROOT).returncode)
