# Closed public F4 failures and reviewed repairs

This capsule preserves original public Chain failures and their reviewed repair
materials. **It does not claim that F4, the hosted ML-DSA workflow, or the CodeQL
export passed.** Archive validation checks membership and bytes. F5 and any later
hosted run need their own exact-source execution records.

## Exact scope

All inputs were selected from explicitly pinned files or closed original
indices. No integration directory or prepublication directory was recursively
copied. The outer manifest records every member's size, SHA-256 and provenance;
the original source indices are preserved byte for byte.

| Group | Preserved inputs |
| --- | --- |
| Original F4 proof/PQ validation | Exact 59 entries from its original `SHA256SUMS.json`, plus that index |
| CI literal repair review v2 | Exact 15 entries plus its index; `isolated-fixture` is excluded |
| Empty stdout preservation proposal | Original 77,325-byte reviewed archive, SHA-256 beginning `3741891c7655` |
| Distributed source inventory diagnosis | Original 128,132-byte archive, SHA-256 beginning `43d317e6b8f1` |
| ML-DSA rustdoc readback repair | Original 33,845-byte archive, SHA-256 beginning `926632e8f9a6` |
| Original ML-DSA hosted artifacts | Four complete original ZIPs, their public Chain API metadata and original member/source/run/job reviews: 12 explicit files |
| CodeQL export diagnosis | Exact 41 entries plus the original manifest, including the complete original artifact ZIP |
| F4 evidence validation | Exact 21 original records plus a separately closed index |
| Scoped closure preparation refusal | One explicit read-only preparation failure record; it is separate from F4 validation |

Preparatory material is included only where these specific public indices or
pinned packages already identify it. Unrelated publication or preparation
directories were not collected. Private Hepta publisher directories, source
patches, private API metadata, credentials, model base weights and temporary
checkouts are outside this capsule. Public source digests, machine paths and
Runtime identifiers remain part of the original observations.

## Original failures remain failures

The original F4 source is
`e9b7a60b9519e39b792199dc8756fb9d1245bab8`, tree
`d7d107818a74fdf4fe95e97d1de5c82664126363`. Its original summary records
`scoped_validation_completed=false` and `HOLD_NO_GO`. The repository suite ran
50 tests with one error: genuine empty stdout from an earlier failed archive
command had been stored with a `.json` suffix. The repair keeps the zero bytes,
the original export manifest and all 517 logical original identities, with one
explicit `.json.raw` storage mapping. Its 517-record replay and 19 refusal
controls are separate observations, not a revision of the original F4 result.

The original CI contract suite ran 164 tests with three errors. The bounded
literal repair preserves the full executable command block and its negative
controls; its isolated 164-test pass does not replace the original failure.
The distributed source inventory check also failed. Its original/generated
public inventory, exact patch, inputs and source-preservation observations stay
inside the pinned diagnosis archive.

The retained-candidate current CLI refusal is also preserved. A correctly
observed expected refusal and an offline historical replay do not become a new
cryptographic execution or a hosted qualification.

## Hosted evidence

The four original ML-DSA ZIPs belong to public Chain run `42518203722` and source
`1a446a79700cc093a2b1a7f10367ef4a5ddbd680`. Artifact IDs are `13632955616`,
`13633206199`, `13632997057` and `13632369322`; their original reviews identify
jobs `128845753787`, `128845753838`, `128845753932` and `128845753947`.
Every ZIP's metadata digest and all 12 members are checked. Its four API/readback
files are also matched against the repair package's original input manifest.

The original rustdoc compile-fail control passed with `E0308`; the next readback
step failed because its frozen line literal was 353 while the exact source test
was at line 359. The reviewed patch changes only that literal and retains the
exact test, diagnostic, type, argument and count requirements. Four original
readbacks and 19 labelled negative copies were replayed. The later independent
C stage was not executed in those original hosted jobs. This capsule adds no
claim of independent-C success or whole-chain quantum security.

The original CodeQL exporter correctly refused after its wait deadline. All 39
retained polls returned no API analyses and no head/merge checks. It resolved
the intended PR and source; an empty `EXPORT_PR_NUMBER` environment value was not
the cause. The inspected producer's branch filters did not match that PR, and
its `upload: never` local SARIF lane was not an API analysis source. The deeper
reason no other API producer supplied results remains unestablished. The
original exporter was not rerun or relaxed.

## Integrity and reproduction

`MANIFEST.json` is the closed member index, excluding only itself from its own
hash roster. Original indices, nested archive indices, every outer member, and
the four hosted ZIPs are checked before publication. All paths are relative and
canonical; duplicate paths, traversal and symbolic links are rejected. Original
inputs are read again after packaging to detect drift.

The tar headers use sorted member names, fixed zero timestamps, fixed ownership
and regular-file mode. Two independent deterministic tar/xz serializations
must agree byte for byte. The finished archive is fully read back and every
member is checked against the outer manifest. The build receipt records that
archive identity and the successful **archive integrity** result only.

The capsule builder, fixed input specification and detailed scope review are
included. Building or reading this capsule executes no tests, model training,
cryptographic campaign, workflow or production action. No source checkout or
original evidence file is modified.
