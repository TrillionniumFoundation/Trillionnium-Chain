#!/usr/bin/env python3
"""Package retained raw observations, including original failed business runs."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/1790ff0f3cc3/chain')
WORK = Path('/workspace/scratch/1790ff0f3cc3/work')
OUT = ROOT/'evidence/pon-architecture-continuation-20261105'
SOURCE = 'd992451cc8bfb3d69a1c9f1906bee6732255fad6'
TREE = 'e5bfe7c1dabdae738173e0f6699cfaa3960cbbaf'
ORIGINAL = 'c54e1e325b3174b0f671bb064ab8b07924cba62d'
REMOTE = 'dda4cc47362065819e9591f11f713933e7a853bf'
PIN_SOURCE = '28b379ed75d4503da634ef71fb54ce51edb96d57'
PIN_TREE = '7f9d85e33a8ab7f5e3a96dfa2ea9ef47a4d397a9'

def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text())
def dump(path, value): path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)

assert git('rev-parse','HEAD').decode().strip()==PIN_SOURCE
assert git('rev-parse','HEAD^{tree}').decode().strip()==PIN_TREE
assert not git('status','--porcelain').strip()
assert git('diff','--name-only',SOURCE,PIN_SOURCE).decode().splitlines()==['config/pon/pq-cross-branch-corpus-v1.json']
subprocess.run(['bash','scripts/project-preflight.sh'],cwd=ROOT,check=True)
native=read(WORK/'integrated/native/commands.json')
before=read(WORK/'integrated/native/source-before.json')
after=read(WORK/'integrated/native/source-after.json')
assert before==after and before['tested_commit']==SOURCE
assert native['required_local_controls_passed']
models=read(WORK/'frozen/models/summary.json')
ci_original=read(WORK/'frozen/ci-controls/summary.json')
registration=read(WORK/'integrated/pin-registration/summary.json')
assert registration['source_commit']==PIN_SOURCE and registration['all_checks_passed']
assert registration['source_before']==registration['source_after']
pin_native=read(WORK/'integrated/pin-native/summary.json')
assert pin_native['source_commit']==PIN_SOURCE and pin_native['exact_same_binary']
campaign=read(WORK/'integrated/ghostdag/ghostdag-order-max6.json')
replay=read(WORK/'integrated/ghostdag/replay.stdout.log')
assert campaign['source']['git_head']==SOURCE and campaign['source']['all_source_files_committed_at_head']
assert campaign['observation']['oracle_differences']==0 and replay['result']=='PASS'
assert replay['source_head']==SOURCE
assert replay['cases']==campaign['observation']['cases']
assert replay['transcript_sha256']==campaign['observation']['transcript_sha256']
business=read(WORK/'integrated/native/business/manifest.json')
report_path=WORK/'integrated/native/business/native/report.json'
report=read(report_path)
assert business['passed'] is False and len(report['samples'])==18
assert all(x['errors']==['PUBLIC_HOST_KERNEL_PARENT'] and not x['finite_business_target_met'] for x in report['samples'])

records={}
def add(path, archive_name):
    assert path.is_file() and not path.is_symlink(), str(path)
    assert not archive_name.startswith('/') and '..' not in Path(archive_name).parts
    assert archive_name not in records
    records[archive_name]=path.read_bytes()
def folder(path, prefix):
    for file in sorted(path.rglob('*')):
        if file.is_file() and '__pycache__' not in file.parts:
            add(file,prefix+'/'+file.relative_to(path).as_posix())

for stage in ('frozen','integrated'):
    for group in ('ghostdag','ci-controls'):
        folder(WORK/stage/group,stage+'/'+group)
    if stage=='frozen': folder(WORK/stage/'models',stage+'/models')
    else:
        folder(WORK/stage/'composition-review',stage+'/composition-review')
        folder(WORK/stage/'pin-registration',stage+'/pin-registration')
        folder(WORK/stage/'pin-native',stage+'/pin-native')
    path=WORK/stage/'native'
    for file in sorted(path.iterdir()):
        if file.is_file(): add(file,stage+'/native/'+file.name)
    selected=['manifest.json','build/stdout','build/stderr',
        'reference_dag_rejects_withheld_body_equivocation_and_changed_signed_history/stdout',
        'reference_dag_rejects_withheld_body_equivocation_and_changed_signed_history/stderr',
        'signed_dag_delivery_comparison_uses_same_native_business_and_confirmation_contract/stdout',
        'signed_dag_delivery_comparison_uses_same_native_business_and_confirmation_contract/stderr',
        'native/report.json']
    for relative in selected: add(path/'business'/relative,stage+'/native/business/'+relative)

for relative in ('audit-summary.json','conflict-prefix-reproduction.json','conflict-prefix-reproduction.log',
                 'conflict-prefix-reproduction.exit','standard-scenario-differential.json',
                 'standard-scenario-differential.log','standard-scenario-differential.exit',
                 'before/new-tests.log','before/new-tests.exit','after/new-tests.log','after/new-tests.exit',
                 'after/full-tests.log','after/full-tests.exit'):
    add(WORK/'ohie-audit'/relative,'pre-freeze/ohie/'+relative)
for relative in ('old-reader-new-tests.log','old-reader-new-tests.json','new-reader-all-tests.log',
                 'new-reader-all-tests.json','new-reader-host-adapter.log','new-reader-host-adapter.json',
                 'final-sources.json','before.sha256','base-head.txt'):
    add(WORK/'architecture-reader'/relative,'pre-freeze/reader/'+relative)
for relative in ('legacy_socket_timeout.rs','legacy-socket-counterexample.json'):
    add(WORK/'native-deadline'/relative,'pre-freeze/socket/'+relative)
folder(WORK/'ghostdag-review','pre-freeze/independent-ghostdag-review')
folder(WORK/'ghostdag-research','pre-freeze/ghostdag-research')
for name in ('run_frozen_checks.py','run_integrated_checks.py','package_architecture_evidence.py'):
    add(WORK/name,'capture-scripts/'+name)

index={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(records.items())}
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0,filename='') as gz:
    with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
        for name,data in sorted(records.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644
            tar.addfile(info,io.BytesIO(data))
archive=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
    assert len(tar.getmembers())==len(index)
    for member in tar.getmembers():
        data=tar.extractfile(member).read()
        assert {'bytes':len(data),'sha256':sha(data)}==index[member.name]
(OUT/'raw-records.tar.gz').write_bytes(archive)
dump(OUT/'records-index.json',dict(schema='pon-architecture-records-index-v1',
    archive='raw-records.tar.gz',archive_sha256=sha(archive),archive_bytes=len(archive),files=index,
    omissions='Native executables, Cargo caches and generated SQLite stores are not archived. Both complete failed native report.json files, execution manifests and stdout/stderr are retained. Manifest paths/hashes of omitted runtime stores remain original observations.'))
for name,path in [('ghostdag-order-max6.json',WORK/'integrated/ghostdag/ghostdag-order-max6.json'),
                  ('ghostdag-replay.json',WORK/'integrated/ghostdag/replay.stdout.log'),
                  ('business-manifest.json',WORK/'integrated/native/business/manifest.json')]:
    (OUT/name).write_bytes(path.read_bytes())

failure=dict(schema='pon-architecture-business-failure-v1',source_commit=SOURCE,
    execution_owner_exit_code=next(x['exit_code'] for x in native['runs'] if x['name']=='business-execution-owner'),
    native_selector_exit_code=business['runs'][-1]['process']['exit_code'],
    samples=18,passed_samples=0,errors=['PUBLIC_HOST_KERNEL_PARENT'],
    raw_report_sha256=sha(report_path.read_bytes()),raw_report_bytes=report_path.stat().st_size,
    raw_report_archive_path='integrated/native/business/native/report.json',
    qualified_business_comparison=False,original_4s_16_hostile_w1_acceptance=False,
    production_activation=False,
    observations=[{key:row[key] for key in ('scenario','sample','position','mode','errors','finite_business_target_met','native_state_equal','cold_reopen_equal')}
                  for row in report['samples']])
dump(OUT/'business-failure.json',failure)

changed=[]
for name in git('diff','--name-only',REMOTE,PIN_SOURCE).decode().splitlines():
    data=git('show',PIN_SOURCE+':'+name)
    changed.append(dict(path=name,bytes=len(data),sha256=sha(data),git_blob=git('rev-parse',PIN_SOURCE+':'+name).decode().strip()))
metadata=read(WORK/'integrated/native/cargo-metadata.stdout')
summary=dict(schema='pon-architecture-continuation-execution-v1',
    original_branch_head='6ee529046d295e3175f09112492abee373f1f54c',
    first_source_commit=ORIGINAL,first_source_tree='848872af917fc085696c94f98b35ab85b99af38b',
    concurrent_remote_head=REMOTE,integrated_source_commit=SOURCE,integrated_source_tree=TREE,
    registered_source_commit=PIN_SOURCE,registered_source_tree=PIN_TREE,
    registered_source_validation=registration,
    registered_source_native_binary_check=pin_native,
    integrated_parents=[REMOTE,ORIGINAL],protected_main_at_inspection='dd6e1c3cbeacbdc532b0679297835b3a0aac78f0',
    source_before=before,source_after=after,source_snapshots_equal=before==after,
    source_changes_relative_to_concurrent_remote=changed,source_changes_recorded_at=PIN_SOURCE,
    native_binary_sha256=business['binary_sha256'],cargo_workspace_packages=len(metadata['workspace_members']),
    cargo_resolved_packages=len(metadata['packages']),rustc=(WORK/'integrated/native/rustc-version.stdout').read_text(),
    original_model_reader_adapter=dict(source_commit=ORIGINAL,tests=75,ohie_tests=36,reader_tests=22,host_adapter_tests=17,passed=models['all_passed']),
    original_ci=dict(source_commit=ORIGINAL,executions=233,unique_test_methods=190,passed=ci_original['all_commands_passed'],
                     duplicate_executions='test_ci_execution imports 43 ci_source_integrity tests; do not sum them as distinct tests'),
    integrated_ci_receipt_directory='integrated/ci-controls',
    composition_review_directory='integrated/composition-review',
    integrated_native_components=dict(passed=12,failed=0,filtered=1,
        filtered_selector='signed_dag_delivery_comparison_uses_same_native_business_and_confirmation_contract',
        selector_executed_separately=True),
    integrated_ghostdag=dict(unit_tests=29,graphs=campaign['observation']['graphs'],cases=campaign['observation']['cases'],
        oracle_differences=0,replay_passed=True,all_source_files_committed_at_head=True,
        transcript_sha256=campaign['observation']['transcript_sha256']),
    native_commands=native['runs'],business=failure,
    retained_red_controls=dict(ohie_old_new_tests_failed=6,ohie_old_new_tests_passed=2,ohie_new_tests_passed=8,
        ohie_standard_runs_byte_equal=18,reader_old_failing_subtest_assertions=22,
        reader_new_total_test_methods=22,reader_new_added_test_methods=8,
        socket_legacy='real loopback per-syscall timeout counterexample with 75ms logical/1s syscall budgets; not the original full campaign'),
    result='SCOPED_ENGINEERING_AND_FINITE_ORDERING_COMPLETE_BUSINESS_HOLD',
    full_alternative_protocol_implemented=False,native_w1_or_pq_qualified=False,wan_tested=False,
    independent_accepted=False,production_activation=False,security_theorem=False,
    raw_records_sha256=sha(archive),raw_records_count=len(index))
dump(OUT/'execution-summary.json',summary)
print(json.dumps({'record_count':len(index),'archive_bytes':len(archive),'archive_sha256':sha(archive),'source_commit':SOURCE}))
