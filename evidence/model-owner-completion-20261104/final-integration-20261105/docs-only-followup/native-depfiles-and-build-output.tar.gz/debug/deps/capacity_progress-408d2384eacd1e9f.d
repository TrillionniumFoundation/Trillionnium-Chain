/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/capacity_progress-408d2384eacd1e9f.d: crates/trnm-mvcc-fee/tests/capacity_progress.rs Cargo.toml

/dev/shm/trnm-model-owner-f4976366a32a-native-target/debug/deps/libcapacity_progress-408d2384eacd1e9f.rmeta: crates/trnm-mvcc-fee/tests/capacity_progress.rs Cargo.toml

crates/trnm-mvcc-fee/tests/capacity_progress.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
