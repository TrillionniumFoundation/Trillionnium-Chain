"""First real process/file loop for the source-specific genesis owner candidate."""
from pathlib import Path
import fcntl,hashlib,json,os,resource,select,signal,struct,subprocess,sys,time
BASE=Path("/tmp/trnm-genesis-owner-20261116-8ppak97a")
ROOT=BASE/"repo";BUILD=BASE/"build-v1";OUT=BASE/"smoke-v1"
def need(condition,message):
    if not condition:raise ValueError(message)
def ident(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}
def save(name,raw): (OUT/name).write_bytes(raw)
def snapshot(directory):
    return {p.name:{"mode":p.stat().st_mode,"inode":p.stat().st_ino,"bytes":p.stat().st_size,
        "sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(directory.iterdir()) if p.is_file()}
def boot(fd,mode=0,timestamp=None,workers=1):
    return b"NGBOOT01"+struct.pack("<7Q",fd,mode,int(timestamp is not None),timestamp or 0,workers,(1<<64)-1,(1<<64)-1)
def command(op):return b"NGCMD001"+struct.pack("<Q",op)
def run(directory,label,mode=0,timestamp=None,workers=1,ops=(1,2)):
    fd=os.open(directory,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
    payload=boot(fd,mode,timestamp,workers)+b"".join(command(op) for op in ops)
    start=time.monotonic_ns()
    process=subprocess.Popen([str(ELF)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
      pass_fds=(fd,),env={"PATH":""},cwd=OUT,start_new_session=True,umask=0o077)
    os.close(fd);timed_out=False
    try: stdout,stderr=process.communicate(payload,timeout=240)
    except subprocess.TimeoutExpired:
        timed_out=True;os.killpg(process.pid,signal.SIGKILL);stdout,stderr=process.communicate(timeout=3)
    row={"name":label,"exit":process.returncode,"timeout":timed_out,"elapsed_ns":time.monotonic_ns()-start,
      "stdin":ident(payload),"stdout":ident(stdout),"stderr":ident(stderr),"diagnostic":list(struct.unpack("<7Q",stderr)) if len(stderr)==56 else None}
    save(label+".stdin.raw",payload);save(label+".stdout.raw",stdout);save(label+".stderr.raw",stderr)
    rows.append(row)
    (OUT/"observations.json").write_text(json.dumps(rows,sort_keys=True,indent=2)+"\n")
    return row,stdout
def read_exact(stream,n):
    data=bytearray();end=time.monotonic()+240
    while len(data)<n:
        left=end-time.monotonic()
        need(left>0,"Read timeout")
        ready,_,_=select.select([stream],[],[],left)
        need(bool(ready),"Read timeout")
        part=os.read(stream.fileno(),n-len(data));need(bool(part),"Unexpected EOF")
        data+=part
    return bytes(data)
rows=[]
def main():
    global ELF
    need(__debug__,"Optimized Python refused")
    OUT.mkdir(mode=0o700)
    sys.path.insert(0,str(ROOT))
    from hia.platform.genesis_store.build import source_manifest
    receipt=json.loads((BUILD/"build.json").read_bytes())
    need(source_manifest(ROOT)==receipt["source_inputs"],"Source changed after build")
    raw=(BUILD/"genesis-owner.elf").read_bytes()
    need(ident(raw)=={k:receipt["executable"][k] for k in ("bytes","sha256")},"ELF changed")
    ELF=OUT/"genesis-owner.elf";ELF.write_bytes(raw);ELF.chmod(0o500)
    directory=OUT/"owned";directory.mkdir(mode=0o700)
    try:
        row,stdout=run(directory,"fresh")
        need(row["exit"]==0 and not row["timeout"] and row["stderr"]["bytes"]==0,"First native loop failed")
        need(stdout[:8]==b"NGOPEN01" and stdout[256:264]==b"NGREAD01","Native receipts differ")
        length=struct.unpack_from("<Q",stdout,264)[0]
        need(len(stdout)==320+length,"Native READ length differs")
        record=stdout[320:]
        names=sorted(p.name for p in directory.iterdir())
        need(len(names)==2 and "ng1.owner.lock" in names,"Unexpected native namespace")
        data_path=next(p for p in directory.iterdir() if p.name.endswith(".state"))
        need(data_path.read_bytes()==record,"Real file/readback differs")
        need(record[:8]==b"NGSTATE1" and struct.unpack_from("<Q",record,8)[0]==len(record),"Catalog framing")
        need(record[96:128]==stdout[96:128] and record[128:160]==stdout[128:160],"Stored identities differ")
        need(data_path.name=="ng1."+record[96:128].hex()+".state","Filename is not actual native genesis")
        state_at,state_bytes=struct.unpack_from("<Q",record,416)[0],struct.unpack_from("<Q",record,392)[0]
        need(record[state_at:state_at+4]==b"SRV1" and struct.unpack_from("<I",record,state_at+4)[0]==7,"Complete State framing")
        at=state_at+8;keys=[];values=[]
        for _ in range(7):
            kn,vn=struct.unpack_from("<II",record,at);at+=8
            keys.append(record[at:at+kn].decode());at+=kn
            values.append(json.loads(record[at:at+vn]));at+=vn
        need(at==state_at+state_bytes==len(record) and keys==sorted(set(keys)),"Complete seven State rows")
        before=snapshot(directory)
        row,reopened=run(directory,"reopen",mode=1,workers=4)
        need(row["exit"]==0 and row["stderr"]["bytes"]==0 and reopened[320:]==record,"Cold reopening differs")
        need(snapshot(directory)==before,"Cold reopening mutated namespace")
        row,_=run(directory,"wrong-context",mode=1,timestamp=1,ops=(2,))
        need(row["exit"]==65 and row["stdout"]["bytes"]==0,"Wrong context admitted")
        need(snapshot(directory)==before,"Wrong context mutated disk")
        row,_=run(directory,"fresh-existing",mode=0,ops=(2,))
        need(row["exit"]==65 and row["stdout"]["bytes"]==0,"Fresh mode accepted initialized directory")
        need(snapshot(directory)==before,"Fresh refusal mutated disk")
        row,invalid=run(directory,"no-commit-interface",mode=1,ops=(3,))
        need(row["exit"]==64 and len(invalid)==256,"Unknown mutation command accepted")
        need(snapshot(directory)==before,"Rejected command mutated disk")
        fd=os.open(directory,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
        p=subprocess.Popen([str(ELF)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            pass_fds=(fd,),env={"PATH":""},cwd=OUT,start_new_session=True,umask=0o077)
        payload=boot(fd,1);os.close(fd);p.stdin.write(payload);p.stdin.flush()
        head=read_exact(p.stdout,256);need(head[:8]==b"NGOPEN01","Lock holder failed")
        try:
            row,_=run(directory,"real-lock-contention",mode=1,ops=(2,))
            need(row["exit"]==67 and row["stdout"]["bytes"]==0,"Concurrent owner acquired real held lock")
        finally:
            p.stdin.write(command(2));p.stdin.flush()
            tail,error=p.communicate(timeout=3)
            save("lock-holder.stdin.raw",payload+command(2))
            save("lock-holder.stdout.raw",head+tail);save("lock-holder.stderr.raw",error)
            need(p.returncode==0 and not tail and not error,"Holder close failed")
        need(snapshot(directory)==before,"Lock contention mutated disk")
        need(source_manifest(ROOT)==receipt["source_inputs"],"Source changed during smoke")
        report={"schema":"trnm.native-genesis-first-physical-loop.v1","status":"PASS","build":str(BUILD/"build.json"),
          "source_set_sha256":receipt["source_set_sha256"],"executable":ident(raw),"controls":rows,
          "actual_file":str(data_path),"record":ident(record),"keys":keys,"values":values,
          "original_rust":"NOT_RUN","power_loss":False,"complete_node":False}
        (OUT/"report.json").write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
        print(json.dumps({"status":"PASS","controls":len(rows),"executable":ident(raw),"record":ident(record),"keys":keys}))
    except BaseException as error:
        (OUT/"failure.json").write_text(json.dumps({"status":"FAIL","error":repr(error),"observations":rows},sort_keys=True,indent=2)+"\n")
        raise
if __name__=="__main__":main()
