#!/usr/bin/env python3
"""Copy an isolated cache for a supplied clean source, then exec the exact gate.

The original C2 target is a read-only cache source. The copied owner ELF is not
qualified for the supplied source: only the real Cargo commands and retained
artifact/list output of the unchanged exact gate can provide that qualification.
This adapter never selects a source commit, starts a proof or runs ignored tests.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import time

ROOT=Path('/home/qian-qi/work/chain-w1-postwin-runtime-20261107-recovery')
REPO=ROOT/'integration-repo'
SOURCE_TARGET=ROOT/'target-owner-exact-source-cc4dd8bdd89309c635831db30b508af2f89419d7-01'
GATE=ROOT/'qualify-w1-owner-retained-exact-source.py'
GATE_SHA='c6a8c0e83d47ee9bdb79cf91f8ffec0cea4f570e7d55598b77bcd099edec4148'
C2_MANIFEST=ROOT/'clean-C2-build-qualification-01/owner-node-m12-01/manifest.json'
C2_MANIFEST_SHA='8e0eb2105eb92385321123797eb6b31c5c59654e19c6a3386dbe4a0028aa8b76'
C2='cc4dd8bdd89309c635831db30b508af2f89419d7'

def require(ok,message):
    if not ok:raise ValueError(message)

def pin(path):
    s=path.lstat();require(stat.S_ISREG(s.st_mode),'regular pinned file')
    h=hashlib.sha256()
    with path.open('rb')as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    e=path.lstat()
    require(all(getattr(s,k)==getattr(e,k)for k in('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns')),'pin changed during read')
    return {'path':str(path),'bytes':s.st_size,'sha256':h.hexdigest()}

def save(path,v):
    with path.open('x')as f:json.dump(v,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
    fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)

def snapshot(root):
    rows={}
    for p in sorted(root.rglob('*')):
        st=p.lstat();relative=str(p.relative_to(root))
        row={'mode':st.st_mode,'device':st.st_dev,'inode':st.st_ino,'bytes':st.st_size,
             'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}
        if stat.S_ISLNK(st.st_mode):
            target=os.readlink(p)
            require(not Path(target).is_absolute() and p.resolve().is_relative_to(root),'cache symlink must remain within this target')
            row.update(kind='symlink',target=target)
        elif stat.S_ISREG(st.st_mode):row['kind']='file'
        elif stat.S_ISDIR(st.st_mode):row['kind']='directory'
        else:raise ValueError('special cache entry refused')
        rows[relative]=row
    require(len(rows)<=100000,'bounded cache inventory')
    return rows

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--commit',required=True);p.add_argument('--tree',required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    require(re.fullmatch('[0-9a-f]{40}',a.commit) and re.fullmatch('[0-9a-f]{40}',a.tree) and a.commit!=C2,
            'explicit new real source commit/tree required')
    require(a.out.is_absolute() and a.out==a.out.resolve() and a.out.is_relative_to(ROOT)
            and not a.out.is_relative_to(REPO) and not a.out.is_relative_to(SOURCE_TARGET)
            and not a.out.exists(),'new external gate output under the owned root required')
    require(not a.out.is_relative_to(ROOT/'repo')
            and not a.out.relative_to(ROOT).parts[0].startswith('target'),
            'gate output cannot be inside either repository or any target cache')
    def git(*v):return subprocess.check_output(['/usr/bin/git','-C',str(REPO),*v],text=True).strip()
    require(git('rev-parse','HEAD')==a.commit and git('rev-parse','HEAD^{tree}')==a.tree
            and git('status','--porcelain=v1','--untracked-files=normal')=='','actual clean supplied source required')
    require(pin(GATE)['sha256']==GATE_SHA and pin(C2_MANIFEST)['sha256']==C2_MANIFEST_SHA,'reviewed gate and original C2 qualification')
    q=json.loads(C2_MANIFEST.read_bytes());owner=q['binaries']['owner_test']
    owner_expected={k:owner[k]for k in('path','bytes','sha256')}
    owner_path=Path(owner['path'])
    require(q['qualification_complete']is True and q['source_commit']==C2 and owner_path.is_relative_to(SOURCE_TARGET)
            and pin(owner_path)==owner_expected,'original C2 qualified ELF unchanged')
    target=ROOT/('target-owner-exact-source-'+a.commit+'-01')
    cache_out=a.out.with_name(a.out.name+'-cache-setup')
    require(not target.exists() and not target.is_symlink() and not cache_out.exists()
            and not cache_out.is_symlink() and not a.out.is_relative_to(target)
            and not target.is_relative_to(a.out),'one isolated cache target and setup observation')
    a.out.parent.mkdir(parents=True,exist_ok=True);cache_out.mkdir()
    report={'schema':'TRNM-W1-EXACT-SOURCE-OWNER-CACHE-SETUP1','source_commit':a.commit,'source_tree':a.tree,
        'source_target':str(SOURCE_TARGET),'destination_target':str(target),'fresh_cargo_target':False,
        'independent_reproducible_build_established':False,'copied_cache_from_C2':True,
        'exact_gate_manifest':str(a.out/'manifest.json'),'cargo_artifact_fresh':None,
        'cargo_artifact_fresh_authority':'actual Cargo compiler-artifact row retained by the exact gate',
        'qualification_established_by_cache_copy':False,'ignored_entries_executed':False,
        'original_C2_owner_before':owner_expected,'cache_setup_complete':False,'errors':[],
        'copy_method_requested':'cp --reflink=auto --recursive --preserve=mode,timestamps; no hardlink option',
        'actual_reflink_vs_byte_copy_split':'unobserved; neither mode is an independent fresh build',
        'started_monotonic_ns':time.monotonic_ns(),'adapter':pin(Path(__file__).resolve())}
    save(cache_out/'declaration.json',report)
    try:
        preflight=['/bin/bash','scripts/project-preflight.sh','--dev']
        with (cache_out/'preflight.stdout.log').open('xb')as so,(cache_out/'preflight.stderr.log').open('xb')as se:
            checked=subprocess.run(preflight,cwd=REPO,stdout=so,stderr=se,
                                   stdin=subprocess.DEVNULL,timeout=90,check=False)
            for f in(so,se):f.flush();os.fsync(f.fileno())
        report['preflight']={'argv':preflight,'cwd':str(REPO),'exit':checked.returncode,
            'stdout':pin(cache_out/'preflight.stdout.log'),'stderr':pin(cache_out/'preflight.stderr.log')}
        require(checked.returncode==0,'preflight failed before cache copy')
        lock=SOURCE_TARGET/'debug/.cargo-lock'
        require(lock.is_file() and not lock.is_symlink(),'existing original Cargo lock required')
        with lock.open('rb')as held:
            fcntl.flock(held,fcntl.LOCK_SH|fcntl.LOCK_NB)
            before=snapshot(SOURCE_TARGET)
            cache_bytes=sum(r['bytes']for r in before.values()if r['kind']=='file')
            free=os.statvfs(ROOT);available=free.f_bavail*free.f_frsize
            require(cache_bytes<=32*1024**3 and available>=cache_bytes+1024**3,'bounded full-copy disk budget')
            save(cache_out/'source-cache-before.json',before)
            target.mkdir()
            argv=['/usr/bin/cp','--reflink=auto','--recursive','--preserve=mode,timestamps',str(SOURCE_TARGET)+'/.',str(target)]
            with (cache_out/'copy.stdout.log').open('xb')as so,(cache_out/'copy.stderr.log').open('xb')as se:
                copied=subprocess.run(argv,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300,check=False)
                for f in(so,se):f.flush();os.fsync(f.fileno())
            report['copy_command']={'argv':argv,'exit':copied.returncode,'stdout':pin(cache_out/'copy.stdout.log'),'stderr':pin(cache_out/'copy.stderr.log')}
            require(copied.returncode==0,'cache copy failed; retain partial destination')
            after=snapshot(SOURCE_TARGET);destination=snapshot(target)
            require(before==after and set(destination)==set(before),'original cache changed or clone incomplete')
            count=0
            for rel,row in before.items():
                d=destination[rel]
                require(d['kind']==row['kind'],'cache kind changed')
                if row['kind']=='file':
                    require((row['device'],row['inode'])!=(d['device'],d['inode'])and row['bytes']==d['bytes'],'shared original inode or truncated copy refused')
                    count+=1
                elif row['kind']=='symlink':require(row['target']==d['target'],'isolated relative symlink changed')
            require(pin(owner_path)==owner_expected,'C2 qualified ELF changed during cache copy')
            copied_owner=target/owner_path.relative_to(SOURCE_TARGET)
            require(pin(copied_owner)['sha256']==owner_expected['sha256'],'copied original owner bytes changed')
            save(cache_out/'destination-cache.json',destination)
            report.update(cache_setup_complete=True,regular_files_copied=count,shared_original_regular_inodes=0,
                original_cache_snapshot_unchanged=True,original_C2_owner_after_copy=pin(owner_path),
                copied_C2_owner=pin(copied_owner),cache_logical_bytes=cache_bytes,available_bytes_before=available)
        require(pin(GATE)['sha256']==GATE_SHA,'reviewed gate changed before exec')
        require(pin(owner_path)==owner_expected,'original C2 owner changed before exact gate')
        require(git('rev-parse','HEAD')==a.commit and git('rev-parse','HEAD^{tree}')==a.tree
                and git('status','--porcelain=v1','--untracked-files=normal')=='','supplied clean source changed before exact gate')
    except BaseException as exc:
        report['cache_setup_complete']=False
        report['errors'].append({'type':type(exc).__name__,'message':str(exc)})
    report['completed_monotonic_ns']=time.monotonic_ns();save(cache_out/'manifest.json',report)
    print(json.dumps({'cache_setup_complete':report['cache_setup_complete'],'manifest':pin(cache_out/'manifest.json'),'errors':report['errors']}),flush=True)
    if not report['cache_setup_complete']:return 1
    argv=['/usr/bin/python3','-B',str(GATE),'--commit',a.commit,'--tree',a.tree,'--repo',str(REPO),
          '--target',str(target),'--out',str(a.out)]
    save(cache_out/'exact-gate-exec-intent.json',{'argv':argv,'source_commit':a.commit,'source_tree':a.tree,
        'original_C2_target_will_not_be_used_for_build':True,'same_PID_exec':True,'outcome':'NOT_YET_OBSERVED',
        'original_C2_owner_before_gate':pin(owner_path),
        'original_C2_owner_after_gate_readback_required':True,
        'cache_copy_is_not_source_qualification':True})
    os.execv(argv[0],argv)

if __name__=='__main__':raise SystemExit(main())
