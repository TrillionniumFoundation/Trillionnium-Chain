//! Candidate-only deterministic object-MVCC and fee-delta kernel.
//!
//! The crate now contains a bounded in-process worker pool whose workers
//! compute programs, meters, fee deltas and tentative object successors against
//! one immutable parent snapshot. Canonical transaction-index
//! commit and deterministic conflict re-execution keep state, receipt and fee
//! roots invariant across worker counts. This is still candidate-only: it does
//! not implement global CEV1 authorization, a production state tree, Order
//! proof authority, Node runtime activation, settlement movement or portable application
//! weight.
//!
//! A durable block confirmation is store-bound and cannot be forged or cloned:
//!
//! ```compile_fail
//! use trnm_mvcc_fee::ConfirmedMvccBlockV1;
//! let _forged = ConfirmedMvccBlockV1 {};
//! ```
//!
//! ```compile_fail
//! use trnm_mvcc_fee::ConfirmedMvccBlockV1;
//! fn copy(value: ConfirmedMvccBlockV1) { let _copy = value.clone(); }
//! ```

#![forbid(unsafe_code)]

pub mod checkpoint_tile_material_v1;
pub mod checkpoint_tile_policy_v1;
mod codec;
pub mod continuity_v1;
pub mod deployment_actors;
pub mod deployment_checkpoint_tile_v1;
pub mod deterministic_parallel_v1;
mod engine;
mod error;
pub mod growth_profile_v2;
pub mod public_evaluation;
pub mod qualified_task_lifecycle;
mod store;
mod types;

pub use engine::{derive_block_id_v1, derive_state_root_v1, derive_transaction_id_v1};
pub use error::{MvccFeeErrorCodeV1, MvccFeeErrorV1, MvccFeeResultV1};
pub use store::{
    ConfirmedMvccBlockV1, MvccBlockOutcomeV1, MvccFeeExecutionPreviewV1, MvccFeeFreshReadbackV1,
    MvccFeeStoreV1,
};
pub use types::*;

#[cfg(test)]
mod tests;

/// Revision-2 PoN commands with validated ordered speculation.
pub mod pon_executor;

/// Pure derived state commitments; no ledger owner or admission authority.
pub mod pon_commitment;

/// Fresh model profile with complete native parent and factor witnesses.
pub mod integer_factor_candidate_v2;

pub mod model_composition_v4;
/// Native fixed-dataset evidence, known-source caps and bounded pre-adoption review.
pub mod model_evidence_v3;
/// Explicit complete-model evolution with typed base/router/expert updates and bounded routing.
pub mod model_evolution_v5;
/// Owner-pinned external data snapshots and precommitted evaluation task windows.
pub mod model_task_windows_v1;
