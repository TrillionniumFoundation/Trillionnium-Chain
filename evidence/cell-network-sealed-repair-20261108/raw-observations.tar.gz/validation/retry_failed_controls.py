#!/usr/bin/env python3
"""Repeat only two ENOSPC-blocked controls on the identical frozen source."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path('/workspace/scratch/277c778f9cb0/chain')
out = Path('/workspace/scratch/277c778f9cb0/validation/final-02')
temporary = Path('/workspace/scratch/277c778f9cb0/qualification-tmp')
source = '09b584bea2e1a265a7e4be10c7aa98cf8e34629b'
out.mkdir(exist_ok=False)
temporary.mkdir(exist_ok=False)
env = os.environ.copy()
env.update({'TMPDIR': str(temporary), 'PYTHONDONTWRITEBYTECODE': '1'})
rows = []

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

runner_before = digest(__file__)
save(out/'environment.json', {'source':source, 'TMPDIR':str(temporary), 'runner_sha256':runner_before, 'retry_reason':'canonical-plan and ci-contract-negative-controls failed with ENOSPC on the shared /tmp; original final-01 failure retained', 'source_or_assertions_changed':False, 'original_timeouts_changed':False})

def run(name, command):
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    begin = time.monotonic()
    print(json.dumps({'started':name,'utc':started}),flush=True)
    stdout = out/(name+'.stdout.log')
    stderr = out/(name+'.stderr.log')
    with stdout.open('xb') as so, stderr.open('xb') as se:
        p=subprocess.Popen(command,cwd=root,env=env,stdout=so,stderr=se,start_new_session=True)
        try:
            code=p.wait(timeout=900)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGTERM)
            try: p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid,signal.SIGKILL)
                p.wait()
            code=124
    row={'name':name,'argv':command,'cwd':str(root),'source':source,'started_utc':started,'elapsed_seconds':round(time.monotonic()-begin,6),'timeout_seconds':900,'exit_code':code,'stdout':stdout.name,'stderr':stderr.name,'stdout_sha256':digest(stdout),'stderr_sha256':digest(stderr)}
    rows.append(row)
    save(out/(name+'.command.json'),row)
    print(json.dumps({'finished':name,'exit_code':code,'elapsed_seconds':row['elapsed_seconds']}),flush=True)
    return code==0

guard=['python3','-B','scripts/ci/verify_ci_source.py','--kind','head','--expected-head',source]
admitted=run('source-before',guard+['--output',str(out/'source-before.receipt.json')])
if admitted:
    admitted=run('preflight',['bash','scripts/project-preflight.sh'])
if admitted:
    run('canonical-plan',['bash','scripts/ci/check_canonical_development_plan.sh'])
    run('ci-contract-negative-controls',['python3','-B','scripts/ci/test_ci_contract.py'])
run('source-after',guard+['--output',str(out/'source-after.receipt.json')])
same=(out/'source-before.receipt.json').is_file() and (out/'source-after.receipt.json').is_file() and (out/'source-before.receipt.json').read_bytes()==(out/'source-after.receipt.json').read_bytes()
passed=admitted and len(rows)==5 and all(r['exit_code']==0 for r in rows) and same and runner_before==digest(__file__)
save(out/'summary.json',{'schema':'trnm-cell-failed-control-retry-v1','result':'PASS_SAME_SOURCE_FAILED_CONTROLS' if passed else 'FAIL','source':source,'source_before_after_identical':same,'original_failure_preserved_in':'../final-01','commands':rows,'tests_not_weakened':True,'runtime_tests_repeated':False,'production_activation':False})
print(json.dumps({'result':'PASS_SAME_SOURCE_FAILED_CONTROLS' if passed else 'FAIL','source':source}),flush=True)
raise SystemExit(0 if passed else 1)
