import hashlib,json,os,signal,subprocess,sys,tempfile,time,traceback
from pathlib import Path
REPO=Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/repo")
TARGET=Path("/tmp/trnm-typedstore-rust-20261116-jqi3qetj/isolated-cargo-target")
TOOLCHAIN=Path("/tmp/trnm-threadcpu-native-20261116-qvgbgeb_/pinned-hepta-f33d")
COMPILER=Path("/tmp/trnm-threadcpu-native-20261116-qvgbgeb_/native-bootstrap/native-compiler")
ROOT=Path(tempfile.mkdtemp(prefix="trnm-resource-current52-original-20261116-"))
OUT=ROOT/"qualification"
env=dict(os.environ,HIA_TOOLCHAIN_ROOT=str(TOOLCHAIN),HIA_NATIVE_COMPILER=str(COMPILER),HIA_NATIVE_COMPILER_SHA256="87c247e4d1c3c9a449d2947fd4227fdc186d519bffd203a04cafce7861a4ed54",PYTHONDONTWRITEBYTECODE="1")
env.pop("PYTHONOPTIMIZE",None)
record={"schema":"trnm.hia.resource-current52-original-execution.v1","status":"FAIL","root":str(ROOT),"repository":str(REPO),"target":str(TARGET),"started_unix_ns":time.time_ns(),"stages":[]}
def save():
 (ROOT/"execution.json").write_text(json.dumps(record,sort_keys=True,indent=2)+"\n")
def require(ok,message):
 if not ok:raise ValueError(message)
def ident(p):
 h=hashlib.sha256();size=0
 with p.open("rb") as f:
  while chunk:=f.read(1048576):h.update(chunk);size+=len(chunk)
 return {"bytes":size,"sha256":h.hexdigest()}
def cmd(label,argv,timeout):
 start=time.monotonic_ns()
 with (ROOT/(label+".stdout")).open("wb") as out,(ROOT/(label+".stderr")).open("wb") as err:
  p=subprocess.Popen(argv,cwd=REPO,env=env,stdout=out,stderr=err,start_new_session=True)
  cleanup=None
  try:result=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   try:os.killpg(p.pid,signal.SIGKILL);cleanup="sent"
   except ProcessLookupError:cleanup="already_exited"
   result=p.wait(timeout=5)
   row={"label":label,"argv":argv,"exit_code":result,"elapsed_ns":time.monotonic_ns()-start,"timed_out":True,"cleanup":cleanup}
   record["stages"].append(row);save();raise
 row={"label":label,"argv":argv,"exit_code":result,"elapsed_ns":time.monotonic_ns()-start,"timed_out":False,"stdout":ident(ROOT/(label+".stdout")),"stderr":ident(ROOT/(label+".stderr"))}
 record["stages"].append(row);save()
 return result,(ROOT/(label+".stdout")).read_bytes()
(ROOT/"driver.py").write_text(sys.orig_argv[sys.orig_argv.index("-c")+1])
print(json.dumps({"root":str(ROOT),"status":"STARTED","driver":ident(ROOT/"driver.py")}),flush=True)
sources=None;original=None
try:
 rc,out=cmd("git-head",["git","rev-parse","HEAD"],10);require(rc==0 and out.strip()==b"34ecf1bd11264bb78df19836e0eb4b6665ed2cec","Unexpected exact base HEAD")
 rc,out=cmd("git-tree",["git","rev-parse","HEAD^{tree}"],10);require(rc==0 and out.strip()==b"6e21f6fe51fad0a7e89fbbe6042c175bb5cba246","Unexpected exact base tree")
 rc,out=cmd("git-status",["git","status","--porcelain=v1"],20);require(rc==0,"git status")
 rc,out=cmd("preflight",["bash","scripts/project-preflight.sh"],30);require(rc==0,"Actual repository preflight failed")
 require(COMPILER.is_file() and not COMPILER.is_symlink(),"Missing regular compiler")
 record["compiler"]=ident(COMPILER)
 require(record["compiler"]["sha256"]==env["HIA_NATIVE_COMPILER_SHA256"],"Pinned compiler identity mismatch")
 sys.path.insert(0,str(REPO))
 from hia.platform.host_resource.rust_oracle import complete_source_manifest,original_manifest
 sources=complete_source_manifest();original=original_manifest(REPO)
 require(len(sources)==52,"Expected current complete 52 source inputs")
 prior=json.loads(Path("/tmp/trnm-resource-prod-integrate-20261116-7r00baeh/production-native-v2/native/qualification/report.json").read_bytes())
 require(prior["status"]=="PASS" and prior["build"]["source_inputs"]==sources,"Current52 differs from root native source qualification")
 record["source_inputs_before"]=sources;record["original_sources_before"]=original
 record["original_source_set_sha256"]=hashlib.sha256(json.dumps(original,sort_keys=True,separators=(",",":")).encode()).hexdigest()
 record["source_set_sha256"]=hashlib.sha256(json.dumps(sources,sort_keys=True,separators=(",",":")).encode()).hexdigest()
 record["base_head"]="34ecf1bd11264bb78df19836e0eb4b6665ed2cec"
 record["base_tree"]="6e21f6fe51fad0a7e89fbbe6042c175bb5cba246"
 record["status"]="RUNNING_ACTUAL_NATIVE_AND_ORIGINAL";save()
 print(json.dumps({"status":record["status"],"root":str(ROOT),"source_inputs":len(sources),"original_inputs":len(original),"source_set_sha256":record["source_set_sha256"]}),flush=True)
 rc,_=cmd("actual-resource-qualifier",[sys.executable,"-B","-m","hia.platform.host_resource.rust_oracle","--repository",str(REPO),"--output",str(OUT),"--target-dir",str(TARGET)],1720)
 require(rc==0,"Actual native/original qualifier exited nonzero")
 native=json.loads((OUT/"native/physical/report.json").read_bytes())
 result=json.loads((OUT/"original/report.json").read_bytes())
 require(native["status"]=="PASS","Actual native report not PASS")
 require(result["status"]=="PASS" and result["controls"]==172 and result["operations"]==180 and result["failed"]==0,"Original semantic comparison not complete")
 require(result["source_inputs"]==sources and result["original_sources"]==original and result["source_inputs_stable"] is True,"Actual original binding mismatch")
 require(any("44 passed; 0 failed" in row for row in result["retained_original_summary"]),"Expected all 44 retained Host tests")
 binary=Path(next(row["argv"][0] for row in result["stages"] if row["stage"]=="list-original-tests"))
 require(ident(binary)==result["executable"],"Actual original executable changed before independent copy")
 dest=ROOT/"original-test-binary"
 import shutil
 with binary.open("rb") as inp,dest.open("xb") as dst:shutil.copyfileobj(inp,dst,1048576)
 require(ident(dest)==result["executable"]==ident(binary),"Original binary copy identity mismatch")
 record["independent_original_executable"]={"path":str(dest),**ident(dest)}
 record["native_report"]=ident(OUT/"native/physical/report.json")
 record["original_report"]=ident(OUT/"original/report.json")
 record["native_cases"]=len(native["semantic"]);record["native_controls"]=len(native["controls"])
 record["original_cases"]=result["controls"];record["original_operations"]=result["operations"]
 record["retained_original_summary"]=result["retained_original_summary"]
 record["status"]="PASS"
except BaseException as error:
 record["failure"]=repr(error);record["traceback"]=traceback.format_exc()
finally:
 try:
  if sources is not None:
   after=complete_source_manifest();record["source_inputs_after"]=after
   require(after==sources,"Complete52 source inputs changed")
  if original is not None:
   after=original_manifest(REPO);record["original_sources_after"]=after
   require(after==original,"Original source inputs changed")
 except BaseException as error:
  record["source_fence_failure"]=repr(error);record["status"]="FAIL"
 record["finished_unix_ns"]=time.time_ns();save()
 print(json.dumps({k:record[k] for k in ("status","root","failure","source_fence_failure","source_set_sha256","native_cases","native_controls","original_cases","original_operations","retained_original_summary","independent_original_executable") if k in record}),flush=True)
 print(json.dumps({"execution_record":ident(ROOT/"execution.json")}),flush=True)
sys.exit(0 if record["status"]=="PASS" else 1)
