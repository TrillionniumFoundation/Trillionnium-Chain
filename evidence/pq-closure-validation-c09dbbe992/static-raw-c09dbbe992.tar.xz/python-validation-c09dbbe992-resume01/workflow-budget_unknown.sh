set -euo pipefail
python3 scripts/w1_qrom_conditional_budget.py > "$W1_QROM_OUT/budget-unknown.json" 2> "$W1_QROM_OUT/budget-unknown.log"
