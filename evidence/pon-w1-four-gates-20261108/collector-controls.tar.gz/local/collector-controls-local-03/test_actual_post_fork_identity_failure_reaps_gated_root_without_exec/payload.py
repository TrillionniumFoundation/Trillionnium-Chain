from pathlib import Path
Path('/workspace/scratch/ec265b67753e/collector-controls-local-03/test_actual_post_fork_identity_failure_reaps_gated_root_without_exec/must-not-execute').write_text('bad')
